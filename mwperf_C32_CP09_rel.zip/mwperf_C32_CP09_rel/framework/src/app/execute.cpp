#include "mwperf/app/surrogate_build_flow.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <concepts>
#include <cstdint>
#include <exception>
#include <filesystem>
#include <iomanip>
#include <iterator>
#include <limits>
#include <locale>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <ranges>
#include <sstream>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/app/execution_plan.hpp"
#include "mwperf/arrival/build_services.hpp"
#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/metrics/palm_fifo.hpp"
#include "mwperf/metrics/temporal.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "metrics/c23_bounded_internal.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/reduction/exact_reductions.hpp"
#include "mwperf/sampling/conditional_generator.hpp"
#include "mwperf/sampling/estimators.hpp"
#include "mwperf/stationary/flux.hpp"
#include "mwperf/stationary/analytic.hpp"
#include "mwperf/stationary/finite_prefix_summary.hpp"
#include "mwperf/stationary/suspension.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"
#include "stationary/c18_stationary_quotient_internal.hpp"
#include "stationary/c21_bounded_projection_internal.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/kernel_access.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/temporal/romr.hpp"
#include "surrogate/providers/full_orbit_sampler_provider.hpp"
#include "surrogate/target_specialization.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> fail(std::string code, std::string message,
                             DiagnosticCategory category =
                                 DiagnosticCategory::internal) {
  return Result<T>::failure(Diagnostic{category, std::move(code),
                                        std::move(message), std::nullopt,
                                        std::nullopt, {}});
}

// Capture the exact coefficient profile actually produced by C16's portable
// decoder.  The normalized record retains the supporting exposure/service
// masses separately from the consumed coefficients, so the diagnostic plane
// never has to infer either object from the other.
[[nodiscard]] Result<SuppliedResponseProfileV1>
decoder_consumed_finite_prefix_profile(
    const PortableFinitePrefixConstantTailResponseV1& response) {
  const auto& identifications =
      response.normalized_record.raw_response.identifications;
  const std::size_t prefix_size = response.service_by_level.size();
  if (prefix_size == 0U || identifications.size() != prefix_size + 1U) {
    return fail<SuppliedResponseProfileV1>(
        "c30.decoder_profile_shape",
        "the adapted finite-prefix response does not retain one mass row "
        "for every prefix coefficient and its constant tail");
  }

  std::vector<ExactRational> prefix_exposure;
  std::vector<ExactRational> prefix_served;
  prefix_exposure.reserve(prefix_size);
  prefix_served.reserve(prefix_size);
  for (std::size_t ordinal = 0U; ordinal < prefix_size; ++ordinal) {
    const FinitePrefixCoefficientIdentificationV1& identification =
        identifications[ordinal];
    const FinitePrefixResponseCoordinateV1& coordinate =
        identification.coordinate;
    const bool expected_coordinate =
        (ordinal == 0U &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::structural_level_zero &&
         coordinate.level_or_tail_from.is_zero()) ||
        (ordinal > 0U &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::exact_level &&
         coordinate.level_or_tail_from == BigNat{ordinal});
    if (!expected_coordinate ||
        identification.pooled_unserved_mass.kind() !=
            PortableScientificScalarKind::rational ||
        identification.pooled_served_mass.kind() !=
            PortableScientificScalarKind::rational) {
      return fail<SuppliedResponseProfileV1>(
          "c30.decoder_profile_prefix_invalid",
          "the adapted finite-prefix response does not retain canonical "
          "exact prefix mass rows");
    }
    const ExactRational& unserved =
        identification.pooled_unserved_mass.rational_value();
    const ExactRational& served =
        identification.pooled_served_mass.rational_value();
    prefix_exposure.push_back(unserved + served);
    prefix_served.push_back(served);
  }

  const FinitePrefixCoefficientIdentificationV1& tail =
      identifications.back();
  if (tail.coordinate.kind !=
          FinitePrefixResponseCoordinateKindV1::constant_tail ||
      tail.coordinate.level_or_tail_from != response.constant_tail_from ||
      tail.pooled_unserved_mass.kind() !=
          PortableScientificScalarKind::rational ||
      tail.pooled_served_mass.kind() !=
          PortableScientificScalarKind::rational) {
    return fail<SuppliedResponseProfileV1>(
        "c30.decoder_profile_tail_invalid",
        "the adapted finite-prefix response does not retain its canonical "
        "exact tail mass row");
  }
  const ExactRational& tail_unserved =
      tail.pooled_unserved_mass.rational_value();
  const ExactRational& tail_served =
      tail.pooled_served_mass.rational_value();
  return Result<SuppliedResponseProfileV1>::success(
      SuppliedResponseProfileV1{
          response.response_cutoff,
          response.service_by_level,
          response.constant_tail_service,
          std::move(prefix_exposure),
          std::move(prefix_served),
          tail_unserved + tail_served,
          tail_served});
}

// Preserve the provider-authored coefficients before C16 rationalizes or
// otherwise adapts the payload.  Binary64 values are converted to their
// identical exact dyadics; this is a representation readout, not a refit.
[[nodiscard]] Result<SuppliedResponseProfileV1>
provider_supplied_finite_prefix_profile(
    const FinitePrefixConstantTailResponseV1& response) {
  const auto& identifications = response.raw_response.identifications;
  if (identifications.size() < 2U) {
    return fail<SuppliedResponseProfileV1>(
        "c30.provider_profile_shape",
        "the validated provider response has no complete prefix and tail "
        "profile");
  }
  const std::size_t prefix_size = identifications.size() - 1U;
  if (response.response_cutoff !=
          BigNat{static_cast<std::uint64_t>(prefix_size - 1U)} ||
      response.raw_response.response_cutoff != response.response_cutoff) {
    return fail<SuppliedResponseProfileV1>(
        "c30.provider_profile_cutoff",
        "the validated provider response profile disagrees with its cutoff");
  }

  const auto exact_value =
      [](const PortableScientificScalar& value) -> ExactRational {
    if (value.kind() == PortableScientificScalarKind::rational) {
      return value.rational_value();
    }
    return binary64_as_exact_rational(value);
  };
  std::vector<ExactRational> service_by_level;
  std::vector<ExactRational> prefix_exposure;
  std::vector<ExactRational> prefix_served;
  service_by_level.reserve(prefix_size);
  prefix_exposure.reserve(prefix_size);
  prefix_served.reserve(prefix_size);
  for (std::size_t ordinal = 0U; ordinal < prefix_size; ++ordinal) {
    const FinitePrefixCoefficientIdentificationV1& identification =
        identifications[ordinal];
    const FinitePrefixResponseCoordinateV1& coordinate =
        identification.coordinate;
    const bool expected_coordinate =
        (ordinal == 0U &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::structural_level_zero &&
         coordinate.level_or_tail_from.is_zero()) ||
        (ordinal > 0U &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::exact_level &&
         coordinate.level_or_tail_from == BigNat{ordinal});
    if (!expected_coordinate) {
      return fail<SuppliedResponseProfileV1>(
          "c30.provider_profile_prefix_invalid",
          "the validated provider response does not retain canonical "
          "prefix coordinates");
    }
    const ExactRational unserved =
        exact_value(identification.pooled_unserved_mass);
    const ExactRational served =
        exact_value(identification.pooled_served_mass);
    service_by_level.push_back(exact_value(identification.raw_point));
    prefix_exposure.push_back(unserved + served);
    prefix_served.push_back(served);
  }

  const FinitePrefixCoefficientIdentificationV1& tail =
      identifications.back();
  const BigNat tail_from = response.response_cutoff + BigNat{1U};
  if (tail.coordinate.kind !=
          FinitePrefixResponseCoordinateKindV1::constant_tail ||
      tail.coordinate.level_or_tail_from != tail_from) {
    return fail<SuppliedResponseProfileV1>(
        "c30.provider_profile_tail_invalid",
        "the validated provider response does not retain its canonical tail "
        "coordinate");
  }
  const ExactRational tail_unserved =
      exact_value(tail.pooled_unserved_mass);
  const ExactRational tail_served =
      exact_value(tail.pooled_served_mass);
  return Result<SuppliedResponseProfileV1>::success(
      SuppliedResponseProfileV1{
          response.response_cutoff,
          std::move(service_by_level),
          exact_value(tail.raw_point),
          std::move(prefix_exposure),
          std::move(prefix_served),
          tail_unserved + tail_served,
          tail_served});
}

// C27 fails closed here. Several inherited mathematical backends use the
// broad `unavailable` diagnostic category for both a genuinely undefined or
// unestablished requested quantity and for structural, binding, mark, seal,
// solver, or numerical failures. Only these exact scientific terminal
// reasons may become result-v1 `unavailable`; every other backend diagnostic,
// including a future unavailable code not reviewed here, is a failed
// execution. Validated wire Unavailable is handled separately by the typed
// C15 union branch and does not pass through this predicate.
[[nodiscard]] bool is_permitted_scientific_unavailability(
    const Diagnostic& diagnostic) noexcept {
  if (diagnostic.category != DiagnosticCategory::unavailable) {
    return false;
  }
  static constexpr std::array<std::string_view, 16U> permitted{
      "c19.stationary_unique_not_established",
      "c22.zero_departure_intensity_for_persistence",
      "c22.zero_event_intensity",
      "c22.zero_run_start_intensity",
      "c23.admission_palm_zero_intensity",
      "c23.event_palm_zero_intensity",
      "c23.fifo_condition_zero_palm_mass",
      "c27.conditioning_mass_not_positive",
      "c27.fifo_moment_unresolved",
      "c27.fifo_quantile_unresolved_horizon",
      "c27.stationary_first_hit_entrance_not_outside_set",
      "c27.stationary_first_hit_mean_not_established",
      "c27.stationary_publication_not_established",
      "c27.stationary_throughput_not_established",
      "c27.k_bin_metric_not_established",
      "c27.three_bin_metric_not_established",
  };
  return std::ranges::find(permitted, std::string_view{diagnostic.code}) !=
         permitted.end();
}

[[nodiscard]] std::string_view analytic_stationary_status_text(
    const AnalyticStationaryStatusV1 status) noexcept {
  switch (status) {
    case AnalyticStationaryStatusV1::finite:
      return "finite";
    case AnalyticStationaryStatusV1::infinite:
      return "infinite";
    case AnalyticStationaryStatusV1::not_established:
      return "not_established";
    case AnalyticStationaryStatusV1::strict_tail_stable:
      return "strict_tail_stable";
    case AnalyticStationaryStatusV1::finite_closed_tail_unreachable:
      return "finite_closed_tail_unreachable";
    case AnalyticStationaryStatusV1::outside_strict_tail_profile:
      return "outside_strict_tail_profile";
    case AnalyticStationaryStatusV1::degenerate_or_selected_closed_class:
      return "degenerate_or_selected_closed_class";
    case AnalyticStationaryStatusV1::required_moment_unavailable:
      return "required_moment_unavailable";
    case AnalyticStationaryStatusV1::not_summable:
      return "not_summable";
    case AnalyticStationaryStatusV1::incomplete_tail:
      return "incomplete_tail";
    case AnalyticStationaryStatusV1::multiple_classes_or_roots:
      return "multiple_classes_or_roots";
    case AnalyticStationaryStatusV1::unsupported_assumptions:
      return "unsupported_assumptions";
    case AnalyticStationaryStatusV1::numerically_unresolved:
      return "numerically_unresolved";
  }
  return "invalid";
}

[[nodiscard]] std::string_view tail_slack_applicability_text(
    const TailSlackApplicabilityV1 applicability) noexcept {
  switch (applicability) {
    case TailSlackApplicabilityV1::applicable:
      return "applicable";
    case TailSlackApplicabilityV1::not_applicable_off_class:
      return "not_applicable_off_class";
    case TailSlackApplicabilityV1::stationary_law_not_established:
      return "stationary_law_not_established";
  }
  return "invalid";
}

[[nodiscard]] std::vector<QueueId> result_targets(
    const MetricRequestHeader& header) {
  std::vector<QueueId> result;
  result.reserve(header.ordered_targets.size());
  for (const ResolvedMetricTargetV1& target : header.ordered_targets) {
    result.push_back(target.queue_id);
  }
  return result;
}

[[nodiscard]] std::string_view metric_units(
    const MetricKindV1 kind) noexcept {
  switch (kind) {
    case MetricKindV1::stationary_throughput:
      return "packets/slot";
    case MetricKindV1::mean_sojourn:
    case MetricKindV1::mean_event_gap:
    case MetricKindV1::fifo_delay:
    case MetricKindV1::fifo_delay_conditioned:
      return "slots";
    case MetricKindV1::joint_backlog_covariance:
      return "packets^2";
    case MetricKindV1::stationary_backlog_moment:
      return "packets^order";
    case MetricKindV1::stationary_backlog_quantile:
      return "packets";
    case MetricKindV1::service_window_count:
      return "departures";
    case MetricKindV1::counterfactual_opportunity_gap:
      return "objective_weight";
    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::service_persistence:
    case MetricKindV1::stationary_backlog_pmf:
    case MetricKindV1::stationary_backlog_pgf:
    case MetricKindV1::stationary_backlog_tail:
    case MetricKindV1::backlog_conditioned_service:
    case MetricKindV1::stationary_edge_reward:
    case MetricKindV1::service_autocovariance:
    case MetricKindV1::lagged_cross_queue_covariance:
    case MetricKindV1::service_spectrum:
    case MetricKindV1::event_gap_distribution:
    case MetricKindV1::mean_binary_run:
    case MetricKindV1::binary_run_distribution:
    case MetricKindV1::first_hit:
    case MetricKindV1::threshold_excursion:
    case MetricKindV1::transient_backlog_law:
    case MetricKindV1::joint_backlog_event:
    case MetricKindV1::joint_delay:
    case MetricKindV1::ordered_schedule_sequence:
      return "dimensionless";
  }
  return "dimensionless";
}

[[nodiscard]] SelectionKindV1 selection_kind(
    const PortableAnalysisSelectionV1& selection) noexcept {
  return std::visit(
      [](const auto& value) {
        using Selection = std::remove_cvref_t<decltype(value)>;
        if constexpr (std::same_as<Selection,
                                   PortableTransientSelectionV1>) {
          return SelectionKindV1::transient_initial;
        } else if constexpr (std::same_as<
                                 Selection,
                                 PortableStationaryUniqueSelectionV1>) {
          return SelectionKindV1::stationary_unique;
        } else if constexpr (std::same_as<
                                 Selection,
                                 PortableStationaryClassSelectionV1>) {
          return SelectionKindV1::stationary_class;
        } else if constexpr (std::same_as<
                                 Selection,
                                 PortableStationaryMixtureSelectionV1>) {
          return SelectionKindV1::stationary_mixture;
        } else if constexpr (std::same_as<
                                 Selection,
                                 PortableFixedPointUniqueSelectionV1>) {
          return SelectionKindV1::fixed_point_unique;
        } else {
          return SelectionKindV1::fixed_point_id;
        }
      },
      selection);
}

[[nodiscard]] AnalysisExecutionIdentityV1 plan_identity(
    const ExecutionPlan& plan) {
  std::vector<std::string> metric_ids;
  std::vector<BackendRouteKindV1> backend_routes;
  metric_ids.reserve(plan.metric_requests().size());
  backend_routes.reserve(plan.metric_plans().size());
  for (const MetricRequest& request : plan.metric_requests()) {
    metric_ids.push_back(metric_request_header(request).metric_id);
  }
  for (const PlannedMetricV1& metric : plan.metric_plans()) {
    backend_routes.push_back(metric.route_kind());
  }
  return AnalysisExecutionIdentityV1{
      plan.resolved_request().fingerprints(),
      plan.provider().identity(),
      plan.provider_manifest().scientific_contract_digest(),
      plan.capability_contract().contract_digest(),
      plan.construction_method(),
      plan.producer_mode(),
      plan.master_seed(),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      std::vector<QueueId>(
          plan.problem_view().target_selection().ordered_targets.begin(),
          plan.problem_view().target_selection().ordered_targets.end()),
      plan.problem_view().analysis_selection(),
      plan.solver_regime(),
      std::move(metric_ids),
      std::move(backend_routes),
      std::nullopt};
}

[[nodiscard]] ResultDiagnosticV1 execution_diagnostic(
    const std::string& id, const Diagnostic& diagnostic) {
  return ResultDiagnosticV1{id,
                            diagnostic.category,
                            diagnostic.code,
                            diagnostic.message,
                            std::nullopt,
                            ResultDiagnosticKindV1::execution,
                            std::nullopt,
                            std::nullopt,
                            diagnostic.notes,
                            {}};
}

[[nodiscard]] constexpr std::string_view provider_failure_kind_name(
    const ProviderFailureKindV1 kind) noexcept {
  switch (kind) {
    case ProviderFailureKindV1::construction_failure:
      return "construction_failure";
    case ProviderFailureKindV1::resource_exhausted:
      return "resource_exhausted";
    case ProviderFailureKindV1::invariant_violation:
      return "invariant_violation";
    case ProviderFailureKindV1::provider_internal_error:
      return "provider_internal_error";
  }
  return "unknown";
}

[[nodiscard]] constexpr DiagnosticCategory provider_failure_category(
    const ProviderFailureKindV1 kind) noexcept {
  return kind == ProviderFailureKindV1::resource_exhausted
             ? DiagnosticCategory::resource_limit
             : DiagnosticCategory::internal;
}

[[nodiscard]] constexpr std::string_view unavailable_reason_kind_name(
    const UnavailableReasonKindV1 kind) noexcept {
  switch (kind) {
    case UnavailableReasonKindV1::inapplicable_target_structure:
      return "inapplicable_target_structure";
    case UnavailableReasonKindV1::coefficient_proved_zero:
      return "coefficient_proved_zero";
    case UnavailableReasonKindV1::coefficient_unresolved:
      return "coefficient_unresolved";
    case UnavailableReasonKindV1::interval_only_without_authorized_point:
      return "interval_only_without_authorized_point";
    case UnavailableReasonKindV1::unmet_construction_assumption:
      return "unmet_construction_assumption";
    case UnavailableReasonKindV1::construction_domain_unavailable:
      return "construction_domain_unavailable";
    case UnavailableReasonKindV1::required_evidence_unavailable:
      return "required_evidence_unavailable";
    case UnavailableReasonKindV1::realized_capability_narrower_than_accepted:
      return "realized_capability_narrower_than_accepted";
  }
  return "unknown";
}

// ResultArtifact deliberately forward-declares C25's two fixed wire enums so
// this translation unit can also include C18/C19, whose historical
// DiagnosticBundle name collides with C25's.  The ordinals below are the
// frozen C25 v1 ComponentScope values and are checked again by result-v1.
[[nodiscard]] constexpr ComponentScopeV1 component_scope_from_ordinal(
    const std::uint8_t ordinal) noexcept {
  return static_cast<ComponentScopeV1>(ordinal);
}

[[nodiscard]] constexpr ComponentScopeV1 component_scope(
    const ArtifactDiagnosticScopeV1 scope) noexcept {
  return component_scope_from_ordinal(static_cast<std::uint8_t>(scope));
}

[[nodiscard]] constexpr ProductKindV1 product_kind_from_ordinal(
    const std::uint8_t ordinal) noexcept {
  return static_cast<ProductKindV1>(ordinal);
}

[[nodiscard]] std::string typed_label_text(const TypedLabel& label) {
  if (const std::string* text = label.text_value()) return *text;
  return label.numeric_value()->to_decimal_string();
}

[[nodiscard]] std::string exact_text(const ExactRational& value) {
  return to_string(value);
}

[[nodiscard]] std::string floating_text(const long double value) {
  std::ostringstream output;
  output << std::setprecision(std::numeric_limits<long double>::max_digits10)
         << value;
  return output.str();
}

[[nodiscard]] std::string_view response_bin_text(
    const ThreeBinCoefficientV1 bin) noexcept {
  switch (bin) {
    case ThreeBinCoefficientV1::one:
      return "one";
    case ThreeBinCoefficientV1::two:
      return "two";
    case ThreeBinCoefficientV1::tail_from_three:
      return "tail_from_three";
  }
  return "unknown";
}

[[nodiscard]] std::string_view proposal_conditioning_source_text(
    const ProposalConditioningSourceV1 source) noexcept {
  switch (source) {
    case ProposalConditioningSourceV1::exact_population:
      return "exact_population";
    case ProposalConditioningSourceV1::empirical_average:
      return "empirical_average";
  }
  return "unknown";
}

[[nodiscard]] std::string_view population_conditioning_status_text(
    const PopulationConditioningStatusV1 status) noexcept {
  switch (status) {
    case PopulationConditioningStatusV1::proved_positive:
      return "proved_positive";
    case PopulationConditioningStatusV1::proved_zero:
      return "proved_zero";
    case PopulationConditioningStatusV1::positive_with_confidence:
      return "positive_with_confidence";
    case PopulationConditioningStatusV1::unresolved:
      return "unresolved";
  }
  return "unknown";
}

[[nodiscard]] std::string_view raw_value_status_text(
    const RawValueStatusV1 status) noexcept {
  switch (status) {
    case RawValueStatusV1::exact_point:
      return "exact_point";
    case RawValueStatusV1::interval_only:
      return "interval_only";
    case RawValueStatusV1::absent:
      return "absent";
  }
  return "unknown";
}

[[nodiscard]] std::optional<ResponseProductValueFormV1>
raw_product_value_form(const RawValueStatusV1 status) noexcept {
  switch (status) {
    case RawValueStatusV1::exact_point:
      return ResponseProductValueFormV1::exact_point;
    case RawValueStatusV1::interval_only:
      return ResponseProductValueFormV1::interval_only;
    case RawValueStatusV1::absent:
      return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] ResultProductBindingV1 raw_product_binding(
    const SurrogateArtifactV1& artifact,
    const BuildIdentityDigest& build_identity,
    const ThreeBinScalarResponseV1& response,
    const ThreeBinCoefficientV1 bin,
    std::optional<TypedLabel> final_probe_id,
    std::optional<ResponseProductValueFormV1> value_form) {
  return ResultProductBindingV1{
      product_kind_from_ordinal(0U),
      artifact.provider,
      std::nullopt,
      artifact.payload_identity,
      build_identity.digest(),
      artifact.request_digest,
      response.raw_response.product_id.identity(),
      response.deployed_target,
      {},
      std::nullopt,
      artifact.provenance.frozen_input_bank_id,
      std::move(final_probe_id),
      value_form,
      bin,
      std::nullopt};
}

[[nodiscard]] std::string_view raw_envelope_coverage_text(
    const RawEnvelopeCoverageV1 coverage) noexcept {
  switch (coverage) {
    case RawEnvelopeCoverageV1::deterministic:
      return "deterministic";
    case RawEnvelopeCoverageV1::marginal:
      return "marginal";
    case RawEnvelopeCoverageV1::simultaneous:
      return "simultaneous";
  }
  return "unknown";
}

[[nodiscard]] std::string_view population_premise_text(
    const PopulationConditioningPremiseV1 premise) noexcept {
  switch (premise) {
    case PopulationConditioningPremiseV1::unconditional:
      return "unconditional";
    case PopulationConditioningPremiseV1::
        conditional_on_population_positivity:
      return "conditional_on_population_positivity";
  }
  return "unknown";
}

[[nodiscard]] std::string_view raw_envelope_scope_text(
    const RawEnvelopeScopeV1 scope) noexcept {
  switch (scope) {
    case RawEnvelopeScopeV1::proposal_raw:
      return "proposal_raw";
    case RawEnvelopeScopeV1::optimizer_interval_raw:
      return "optimizer_interval_raw";
    case RawEnvelopeScopeV1::deterministic_quadrature_raw:
      return "deterministic_quadrature_raw";
    case RawEnvelopeScopeV1::physical_response_bound:
      return "physical_response_bound";
  }
  return "unknown";
}

[[nodiscard]] std::string_view arrival_categorical_row_kind_text(
    const ArrivalCategoricalRowKind kind) noexcept {
  switch (kind) {
    case ArrivalCategoricalRowKind::finite_interarrival:
      return "finite_interarrival";
    case ArrivalCategoricalRowKind::geometric_trial:
      return "geometric_trial";
    case ArrivalCategoricalRowKind::destination:
      return "destination";
    case ArrivalCategoricalRowKind::joint_gap_destination:
      return "joint_gap_destination";
    case ArrivalCategoricalRowKind::private_initial_state:
      return "private_initial_state";
    case ArrivalCategoricalRowKind::private_transition:
      return "private_transition";
    case ArrivalCategoricalRowKind::shared_initial_state:
      return "shared_initial_state";
    case ArrivalCategoricalRowKind::shared_outcome:
      return "shared_outcome";
    case ArrivalCategoricalRowKind::iid_count_outcome:
      return "iid_count_outcome";
    case ArrivalCategoricalRowKind::mixed_poisson_state:
      return "mixed_poisson_state";
  }
  return "unknown";
}

void append_input_normalization_diagnostics(
    const ResolvedRequest& request,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  std::size_t index = 0U;
  for (const PmfNormalizationRecord& record :
       request.normalization_diagnostics()) {
    std::string code;
    std::string message;
    switch (record.kind) {
      case PmfNormalizationKind::configured_arrival_stationary_phase:
        code = "c27.configured_arrival_normalization";
        message =
            "configured-arrival stationary-phase PMF normalization";
        break;
      case PmfNormalizationKind::transient_initial_law:
        code = "c27.transient_initial_law_normalization";
        message = "coupled transient initial-law PMF normalization";
        break;
      case PmfNormalizationKind::configured_arrival_categorical_row:
        code =
            "c27.configured_arrival_categorical_row_normalization";
        message =
            "configured-arrival categorical-row PMF normalization";
        break;
    }
    std::vector<std::string> assumptions{
        "identity=" + record.identity,
        "authored_sum=" + exact_text(record.authored_sum),
        "normalization_delta=" +
            exact_text(record.normalization_delta)};
    if (record.kind ==
        PmfNormalizationKind::configured_arrival_categorical_row) {
      if (record.arrival_row_kind) {
        assumptions.push_back(
            "arrival_row_kind=" +
            std::string(arrival_categorical_row_kind_text(
                *record.arrival_row_kind)));
      }
      if (record.source_ordinal) {
        assumptions.push_back(
            "source_ordinal=" + std::to_string(*record.source_ordinal));
      }
      if (record.state_ordinal) {
        assumptions.push_back(
            "state_ordinal=" + std::to_string(*record.state_ordinal));
      }
    }
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.input_normalization." + std::to_string(index++),
        DiagnosticCategory::information,
        std::move(code),
        std::move(message),
        component_scope_from_ordinal(1U),
        ResultDiagnosticKindV1::component,
        std::nullopt,
        std::nullopt,
        std::move(assumptions),
        {}});
  }
}

void append_artifact_diagnostics(
    const SurrogateArtifactV1& artifact,
    const BuildIdentityDigest& build_identity,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  std::size_t index = 0U;
  for (const ArtifactDiagnosticComponentV1& component :
       artifact.diagnostic_components) {
    std::vector<std::string> evidence;
    evidence.reserve(component.subject_references.size() +
                     component.evidence_references.size());
    for (const ArtifactObjectReferenceV1& subject :
         component.subject_references) {
      evidence.push_back(
          "subject:id=" + typed_label_text(subject.object_id) +
          ",digest=" + subject.object_digest.hex());
    }
    for (const ArtifactObjectReferenceV1& item :
         component.evidence_references) {
      evidence.push_back(
          "evidence:id=" + typed_label_text(item.object_id) +
          ",digest=" + item.object_digest.hex());
    }
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.artifact_component." + std::to_string(index++),
        DiagnosticCategory::information,
        component.code,
        component.message,
        component_scope(component.scope),
        ResultDiagnosticKindV1::component,
        std::nullopt,
        std::nullopt,
        {"artifact_diagnostic_id=" +
             typed_label_text(component.diagnostic_id),
         "typed_product_binding=not_reconstructible_from_artifact_v1"},
        std::move(evidence)});
  }

  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact.payload)) {
    std::size_t coefficient_index = 0U;
    for (const CoefficientIdentificationV1& identification :
         response->raw_response.identifications) {
      std::vector<std::string> assumptions{
          "scientific_scope=proposal_raw",
          "artifact_identity=not_reported_by_artifact_v1",
          "not_a_deployed_response_bound",
          "not_physical_fidelity",
          "build_identity=" + build_identity.digest().hex(),
          "build_request_identity=" + artifact.request_digest.hex(),
          "source_product_id=" + typed_label_text(
              response->raw_response.product_id.identity().object_id),
          "source_product_digest=" + response->raw_response.product_id
                                             .identity()
                                             .object_digest.hex(),
          "coefficient_id=" +
              typed_label_text(identification.coefficient_id.object_id),
          "coefficient_digest=" +
              identification.coefficient_id.object_digest.hex(),
          "response_target=" +
              typed_label_text(response->deployed_target.label()),
          "response_bin=" + std::string(response_bin_text(
                                identification.target_bin_binding)),
          "proposal_conditioning_source=" +
              std::string(proposal_conditioning_source_text(
                  identification.proposal_conditioning.source)),
          "proposal_conditioning_observed_value=" +
              identification.proposal_conditioning
                  .observed_nonnegative_value.canonical_tagged_encoding(),
          "population_conditioning_status=" +
              std::string(population_conditioning_status_text(
                  identification.coefficient_status
                      .population_conditioning_status)),
          "raw_value_status=" +
              std::string(raw_value_status_text(
                  identification.coefficient_status.raw_value_status)),
          "configured_arrival_binding=" +
              response->raw_response.configured_arrival_binding.hex(),
          "proposal_law_digest=" +
              response->raw_response.proposal_law_digest.hex()};
      if (identification.raw_point) {
        assumptions.push_back(
            "raw_point=" +
            identification.raw_point->canonical_tagged_encoding());
      }
      if (identification.proposal_conditioning.frozen_evaluation_id) {
        assumptions.push_back(
            "frozen_evaluation_id=" +
            typed_label_text(*identification.proposal_conditioning
                                  .frozen_evaluation_id));
      }
      std::vector<std::string> evidence{
          "provider_conformance_report:id=" +
              typed_label_text(identification.provider_conformance_report_ref
                                   .report_id) +
              ",digest=" +
              identification.provider_conformance_report_ref.report_digest
                  .hex()};
      evidence.reserve(
          1U + identification.family_evidence_envelope_ids.size() +
          (identification.completion_policy_id ? 1U : 0U));
      for (const ArtifactObjectReferenceV1& item :
           identification.family_evidence_envelope_ids) {
        evidence.push_back(
            "proposal_interval_evidence:id=" +
            typed_label_text(item.object_id) +
            ",digest=" + item.object_digest.hex());
      }
      if (identification.completion_policy_id) {
        evidence.push_back(
            "authorized_completion:id=" +
            typed_label_text(
                identification.completion_policy_id->object_id) +
            ",digest=" +
            identification.completion_policy_id->object_digest.hex());
      }
      std::optional<ResultDiagnosticIntervalV1> value;
      if (identification.raw_point) {
        value = ResultDiagnosticIntervalV1{
            CertificateClaimStateV1::established,
            BoundValueStatusV1::finite, identification.raw_point,
            identification.raw_point};
      }
      std::optional<ResultProductBindingV1> product;
      const auto value_form = raw_product_value_form(
          identification.coefficient_status.raw_value_status);
      if (value_form) {
        product = raw_product_binding(
            artifact, build_identity, *response,
            identification.target_bin_binding,
            identification.proposal_conditioning.frozen_evaluation_id,
            value_form);
      } else {
        // C25's raw-response product vocabulary has only exact-point and
        // interval-only values.  An absent coefficient is scientifically
        // important population-conditioning evidence, but it is not a raw
        // product and must not be serialized as one with a fabricated value
        // form.
        assumptions.push_back(
            "typed_product_binding=absent_raw_value_has_no_product");
      }
      diagnostics.push_back(ResultDiagnosticV1{
          "c27.raw_coefficient_identification." +
              std::to_string(coefficient_index++),
          DiagnosticCategory::information,
          "c27.raw_coefficient_identification",
          "provider proposal-population coefficient identification",
          component_scope_from_ordinal(3U),
          ResultDiagnosticKindV1::component,
          std::move(product),
          std::move(value), std::move(assumptions),
          std::move(evidence)});
    }

    std::size_t envelope_index = 0U;
    for (const RawResponseEnvelopeV1& envelope :
         response->raw_envelopes) {
      for (std::size_t bin_index = 0U;
           bin_index < envelope.covered_bins.size(); ++bin_index) {
        std::vector<std::string> assumptions{
            "artifact_identity=not_reported_by_artifact_v1",
            "scientific_scope=proposal_raw",
            "not_a_deployed_response_bound",
            "not_physical_fidelity",
            "build_identity=" + build_identity.digest().hex(),
            "build_request_identity=" + artifact.request_digest.hex(),
            "source_product_kind=raw_response",
            "source_product_id=" + typed_label_text(
                envelope.source_product.identity().object_id),
            "source_product_digest=" +
                envelope.source_product.identity().object_digest.hex(),
            "response_target=" +
                typed_label_text(response->deployed_target.label()),
            "response_bin=" +
                std::string(response_bin_text(
                    envelope.covered_bins[bin_index])),
            "construction_law_digest=" +
                envelope.construction_law_digest.hex(),
            "certification_method=" + envelope.certification_method,
            "coverage=" +
                std::string(raw_envelope_coverage_text(
                    envelope.coverage)),
            "population_conditioning_premise=" +
                std::string(population_premise_text(
                    envelope.population_conditioning_premise)),
            "bound_scope=" +
                std::string(raw_envelope_scope_text(envelope.scope))};
        if (envelope.frozen_evaluation_id) {
          assumptions.push_back(
              "frozen_evaluation_id=" +
              typed_label_text(*envelope.frozen_evaluation_id));
        }
        if (envelope.sample_size) {
          assumptions.push_back(
              "sample_size=" +
              envelope.sample_size->to_decimal_string());
        }
        std::vector<std::string> evidence{
            "envelope:id=" +
                typed_label_text(envelope.envelope_id.object_id) +
                ",digest=" + envelope.envelope_id.object_digest.hex()};
        evidence.reserve(
            1U + envelope.family_evidence_envelope_ids.size());
        for (const ArtifactObjectReferenceV1& item :
             envelope.family_evidence_envelope_ids) {
          evidence.push_back(
              "family_evidence:id=" + typed_label_text(item.object_id) +
              ",digest=" + item.object_digest.hex());
        }
        diagnostics.push_back(ResultDiagnosticV1{
            "c27.raw_response_envelope." +
                std::to_string(envelope_index) + "." +
                std::to_string(bin_index),
            DiagnosticCategory::information,
            "c27.raw_response_envelope",
            "provider raw-response coefficient envelope",
            component_scope_from_ordinal(3U),
            ResultDiagnosticKindV1::component,
            raw_product_binding(
                artifact, build_identity, *response,
                envelope.covered_bins[bin_index],
                envelope.frozen_evaluation_id,
                ResponseProductValueFormV1::interval_only),
            ResultDiagnosticIntervalV1{
                CertificateClaimStateV1::established,
                BoundValueStatusV1::finite,
                envelope.lower[bin_index], envelope.upper[bin_index]},
            std::move(assumptions), std::move(evidence)});
      }
      ++envelope_index;
    }
  }

  index = 0U;
  for (const SeedStreamCountV1& stream :
       artifact.provenance.seed_stream_counts) {
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.construction_stream." + std::to_string(index++),
        DiagnosticCategory::information,
        "c27.construction_stream_consumption",
        "request-bound construction stream consumption",
        component_scope_from_ordinal(1U),
        ResultDiagnosticKindV1::component,
        std::nullopt,
        std::nullopt,
        {"stage_tag=" +
             std::to_string(stage_tag_value(stream.stage)),
         "stream_instance_id=" +
             typed_label_text(stream.stream_instance_id),
         "draw_count=" + stream.draw_count.to_decimal_string(),
         "stream_digest=not_reconstructible_from_artifact_v1"},
        {}});
  }
}

[[nodiscard]] ResultDiagnosticV1 execution_diagnostic(
    const std::string& id, const DiagnosticCategory category,
    std::string code, std::string message,
    std::vector<std::string> assumptions = {}) {
  return ResultDiagnosticV1{id,
                            category,
                            std::move(code),
                            std::move(message),
                            std::nullopt,
                            ResultDiagnosticKindV1::execution,
                            std::nullopt,
                            std::nullopt,
                            std::move(assumptions),
                            {}};
}

class ExecutionWorkspace final {
 public:
  ExecutionWorkspace() = delete;
  ExecutionWorkspace(const ExecutionWorkspace&) = delete;
  ExecutionWorkspace& operator=(const ExecutionWorkspace&) = delete;
  ExecutionWorkspace(ExecutionWorkspace&&) = delete;
  ExecutionWorkspace& operator=(ExecutionWorkspace&&) = delete;

  ~ExecutionWorkspace() {
    if (!path_.empty()) {
      std::error_code ignored;
      std::filesystem::remove_all(path_, ignored);
    }
  }

  [[nodiscard]] static Result<std::unique_ptr<ExecutionWorkspace>> create(
      const SurrogateBuildRequestDigest& request) {
    try {
      std::error_code error;
      std::filesystem::path root = std::filesystem::temp_directory_path(error);
      if (error || root.empty()) {
        return fail<std::unique_ptr<ExecutionWorkspace>>(
            "c27.execution_workspace_unavailable",
            "the execution-local workspace root is unavailable",
            DiagnosticCategory::resource_limit);
      }
      const std::string prefix =
          "mwperf-c27-" + request.value().hex().substr(0U, 16U) + "-";
      for (std::uint32_t attempt = 0U; attempt < 1024U; ++attempt) {
        std::filesystem::path candidate =
            root / (prefix + std::to_string(attempt));
        error.clear();
        if (std::filesystem::create_directory(candidate, error)) {
          candidate = std::filesystem::canonical(candidate, error);
          if (!error) {
            return Result<std::unique_ptr<ExecutionWorkspace>>::success(
                std::unique_ptr<ExecutionWorkspace>(
                    new ExecutionWorkspace(std::move(candidate))));
          }
          std::error_code ignored;
          std::filesystem::remove_all(candidate, ignored);
          break;
        }
        if (error && error != std::errc::file_exists) {
          break;
        }
      }
      return fail<std::unique_ptr<ExecutionWorkspace>>(
          "c27.execution_workspace_unavailable",
          "a private execution-local workspace could not be created",
          DiagnosticCategory::resource_limit);
    } catch (const std::exception&) {
      return fail<std::unique_ptr<ExecutionWorkspace>>(
          "c27.execution_workspace_unavailable",
          "creating the execution-local workspace raised an exception",
          DiagnosticCategory::resource_limit);
    }
  }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }

 private:
  explicit ExecutionWorkspace(std::filesystem::path path)
      : path_(std::move(path)) {}
  std::filesystem::path path_;
};

[[nodiscard]] ArtifactParseLimits parse_limits(
    const ValidatedProviderManifest& manifest) {
  const std::size_t maximum = std::min(
      kSurrogateBuildProtocolV1MaximumResultBytes,
      manifest.value().transport_limits.maximum_result_bytes);
  constexpr std::size_t kDecodedAllocationMultiplier = 8U;
  const std::size_t decoded_allocation =
      maximum > std::numeric_limits<std::size_t>::max() /
                    kDecodedAllocationMultiplier
          ? std::numeric_limits<std::size_t>::max()
          : maximum * kDecodedAllocationMultiplier;
  return ArtifactParseLimits{maximum,
                             128U,
                             std::numeric_limits<std::size_t>::max(),
                             std::numeric_limits<std::size_t>::max(),
                             maximum,
                             std::numeric_limits<std::size_t>::max(),
                             std::min(decoded_allocation,
                                      kNonScientificByteCeiling)};
}

[[nodiscard]] bool needs_process_local_arrival_service(
    const SurrogateBuildRequest& request) {
  if (request.classifications().producer_mode !=
      ProducerModeV1::in_process_builder) {
    return false;
  }
  for (const ArrivalAssumptionV1& assumption :
       request.accepted_capability_contract()
           .construction_prerequisites.arrival) {
    if (assumption.provision == CapabilityProvisionNeedV1::process_local) {
      return true;
    }
  }
  return false;
}

[[nodiscard]] std::vector<ResultBudgetUsageV1> construction_budget_usage(
    const ConstructionBudget& grant,
    const std::optional<CommonBuildReportV1>& report) {
  const auto count = [&](std::string name,
                         const CountConstructionGrantV1& allowed,
                         const CommonWorkCounterV1* used) {
    return ResultBudgetUsageV1{
        std::move(name),
        allowed.applicability == BudgetApplicabilityV1::applicable
            ? ResultBudgetApplicabilityV1::applicable
            : ResultBudgetApplicabilityV1::not_applicable,
        allowed.amount,
        used == nullptr ? BigNat{0U} : used->used,
        "count"};
  };
  return {
      count("construction.exact_optimizer_calls",
            grant.exact_optimizer_calls,
            report ? &report->optimizer_calls : nullptr),
      count("construction.optimizer_search_states",
            grant.optimizer_search_states,
            report ? &report->optimizer_search_states : nullptr),
      count("construction.configured_generator_draws",
            grant.configured_generator_draws,
            report ? &report->configured_generator_draws : nullptr)};
}

[[nodiscard]] Result<BigNat> observed_optimizer_search_states(
    const CommonBuildReportV1& report) {
  if (report.optimizer_search_states.applicability ==
      WorkCounterApplicabilityV1::applicable) {
    return Result<BigNat>::success(report.optimizer_search_states.used);
  }

  constexpr std::string_view kTelemetryName =
      "optimizer_search_states_observed";
  const auto found = std::lower_bound(
      report.optional_method_counters.begin(),
      report.optional_method_counters.end(), kTelemetryName,
      [](const NamedPortableValueV1& value, const std::string_view name) {
        return value.name < name;
      });
  if (found == report.optional_method_counters.end() ||
      found->name != kTelemetryName) {
    // Non-search optimizers legitimately have no observed-search extension.
    return Result<BigNat>::success(BigNat{0U});
  }
  const auto* scalar = std::get_if<PortableScientificScalar>(&found->value);
  if (scalar == nullptr) {
    return fail<BigNat>(
        "c27.optimizer_search_telemetry_not_scalar",
        "optimizer_search_states_observed must be one exact nonnegative integer");
  }
  const ExactRational exact =
      scalar->kind() == PortableScientificScalarKind::rational
          ? scalar->rational_value()
          : binary64_as_exact_rational(*scalar);
  if (!exact.is_nonnegative() || exact.denominator() != 1) {
    return fail<BigNat>(
        "c27.optimizer_search_telemetry_not_natural",
        "optimizer_search_states_observed must be one exact nonnegative integer");
  }
  auto natural = BigNat::from_big_int(exact.numerator());
  if (!natural) {
    return Result<BigNat>::failure(natural.error());
  }
  return Result<BigNat>::success(std::move(natural).value());
}

[[nodiscard]] Result<void> charge_local_reported_optimizer_calls(
    const ProducerModeV1 producer_mode,
    const CommonBuildReportV1& report,
    OptimizerExecutionContext& optimizer) {
  if (producer_mode == ProducerModeV1::inline_immediate) {
    const BigNat expected{0U};
    if (!(report.optimizer_calls.used == expected) ||
        !(report.optimizer_search_states.used == expected)) {
      return fail<void>(
          "c27.inline_optimizer_usage_forbidden",
          "an inline-immediate provider has no authorized exact-query service and must report zero optimizer calls and search states");
    }
    return Result<void>::success();
  }
  if (producer_mode != ProducerModeV1::local_executable_builder) {
    return Result<void>::success();
  }
  const BigNat expected{0U};
  if (!(optimizer.ledger_snapshot().calls_reserved() == expected)) {
    return fail<void>(
        "c27.local_optimizer_ledger_not_pristine",
        "local-executable optimizer accounting must enter one pristine shared ledger before V0");
  }
  BigNat charged{0U};
  while (charged < report.optimizer_calls.used) {
    auto reservation = begin_search_budget(optimizer);
    if (!reservation) return Result<void>::failure(reservation.error());
    ++charged;
  }
  if (!(optimizer.ledger_snapshot().calls_reserved() ==
        report.optimizer_calls.used)) {
    return fail<void>(
        "c27.local_optimizer_ledger_reconciliation_failed",
        "validated local-executable optimizer-call usage was not charged exactly once");
  }
  auto observed_search = observed_optimizer_search_states(report);
  if (!observed_search) {
    return Result<void>::failure(observed_search.error());
  }
  if (report.optimizer_calls.used.is_zero() &&
      !observed_search.value().is_zero()) {
    return fail<void>(
        "c27.local_optimizer_search_states_without_calls",
        "a local-executable build report cannot consume recursive optimizer search states without consuming an optimizer call");
  }
  if (optimizer.base_policy().effective_per_call.has_value()) {
    try {
      const BigNat maximum_reported_search_states =
          report.optimizer_calls.used *
          *optimizer.base_policy().effective_per_call;
      if (observed_search.value() > maximum_reported_search_states) {
        return fail<void>(
            "c27.local_optimizer_search_states_exceed_call_bound",
            "a local-executable build report consumes more recursive optimizer search states than its reported calls can authorize under the frozen per-call limit");
      }
    } catch (const std::exception&) {
      return fail<void>(
          "c27.local_optimizer_search_state_bound_failure",
          "computing the local-executable build report's exact recursive optimizer search-state bound failed");
    } catch (...) {
      return fail<void>(
          "c27.local_optimizer_search_state_bound_failure",
          "computing the local-executable build report's exact recursive optimizer search-state bound raised an unknown exception");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> reconcile_in_process_optimizer_calls(
    const ProducerModeV1 producer_mode,
    const CommonBuildReportV1& report,
    const OptimizerExecutionContext& optimizer) {
  if (producer_mode != ProducerModeV1::in_process_builder) {
    return Result<void>::success();
  }
  const BigNat actual = optimizer.ledger_snapshot().calls_reserved();
  if (actual > report.optimizer_calls.used) {
    return fail<void>(
        "c27.in_process_optimizer_calls_underreported",
        "the in-process provider used more shared optimizer calls than its validated build report declares");
  }
  if (actual < report.optimizer_calls.used) {
    return fail<void>(
        "c27.in_process_optimizer_calls_overreported",
        "the in-process provider declared optimizer calls that were not charged to the shared execution ledger");
  }
  const BigNat actual_search_states =
      optimizer.ledger_snapshot().search_states_expanded();
  if (actual_search_states > report.optimizer_search_states.used) {
    return fail<void>(
        "c27.in_process_optimizer_search_states_underreported",
        "the in-process provider used more shared recursive optimizer search states than its validated build report declares");
  }
  if (actual_search_states < report.optimizer_search_states.used) {
    return fail<void>(
        "c27.in_process_optimizer_search_states_overreported",
        "the in-process provider declared recursive optimizer search states that were not charged to the shared execution ledger");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> append_shared_optimizer_accounting(
    const ExecutionPlan& plan,
    const OptimizerCallLedgerObserver& observer,
    const std::optional<CommonBuildReportV1>& build_report,
    const bool inactive_owner_permitted,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& execution_budgets,
    BigNat& optimizer_calls_observed,
    BigNat& optimizer_search_states_observed) {
  const OptimizerCallLedgerSnapshot snapshot = observer.snapshot();
  const std::optional<BigNat>& planned =
      plan.work_bounds().optimizer_calls;
  const std::optional<BigNat>& planned_search_states =
      plan.work_bounds().optimizer_search_states;
  const std::optional<BigNat>& effective_per_call =
      plan.resolved_instance().optimizer_budget().effective_per_call;
  std::optional<BigNat> expected_assigned_search_states;
  // C05 independently retains an internal aggregate safety cap even when a
  // route declares recursive search-state work NotApplicable for provider
  // accounting.  Reproduce C05's exact construction rule here to validate
  // the private ledger invariant; planned_search_states remains the distinct
  // reportable work bound below.
  if (planned.has_value() && effective_per_call.has_value()) {
    expected_assigned_search_states = *planned * *effective_per_call;
  } else if (planned.has_value() && planned->is_zero()) {
    expected_assigned_search_states = BigNat{0U};
  }
  const bool search_states_not_applicable =
      (detail::is_full_orbit_k_wide_provider(
           plan.provider().identity()) ||
       detail::is_full_orbit_observation_provider(
           plan.provider().identity()) ||
       detail::is_full_orbit_cp09_provider(
           plan.provider().identity())) &&
      !planned_search_states.has_value();
  BigNat actual_search_states = snapshot.search_states_expanded();
  BigNat local_executable_search_states{0U};
  // A local executable cannot mutate the process-local C05 context. Its C15
  // report is therefore the one trusted construction subaccount and is added
  // exactly once here. In-process construction already charged the shared
  // state, so adding its report would double count it.
  if (plan.producer_mode() ==
          ProducerModeV1::local_executable_builder &&
      build_report.has_value()) {
    auto observed_search = observed_optimizer_search_states(*build_report);
    if (!observed_search) {
      return Result<void>::failure(observed_search.error());
    }
    local_executable_search_states = std::move(observed_search).value();
    actual_search_states += local_executable_search_states;
  }
  optimizer_calls_observed = snapshot.calls_reserved();
  optimizer_search_states_observed = actual_search_states;

  diagnostics.push_back(ResultDiagnosticV1{
      "c27.execution.shared_optimizer_ledger",
      DiagnosticCategory::information,
      "c27.shared_optimizer_ledger_accounting",
      "Final committed call accounting for the one execution-wide optimizer ledger",
      std::nullopt,
      ResultDiagnosticKindV1::budget_termination,
      std::nullopt,
      std::nullopt,
      {"planned_max_calls=" +
           (planned ? planned->to_decimal_string()
                    : std::string("unbounded")),
       "assigned_max_calls=" +
           (snapshot.assigned_max_calls()
                ? snapshot.assigned_max_calls()->to_decimal_string()
                : std::string("unbounded")),
       "actual_calls=" + snapshot.calls_reserved().to_decimal_string(),
       "planned_max_search_states=" +
           (planned_search_states
                ? planned_search_states->to_decimal_string()
                : std::string(search_states_not_applicable
                                  ? "not_applicable"
                                  : "unbounded")),
       "assigned_max_search_states=" +
           (snapshot.assigned_max_search_states()
                ? snapshot.assigned_max_search_states()->to_decimal_string()
                : std::string("unbounded")),
       "in_process_search_states=" +
           snapshot.search_states_expanded().to_decimal_string(),
       "actual_search_states=" +
           actual_search_states.to_decimal_string(),
       "local_executable_construction_search_states=" +
           ((plan.producer_mode() ==
                 ProducerModeV1::local_executable_builder &&
             build_report.has_value())
                ? local_executable_search_states.to_decimal_string()
                : std::string("0")),
       "context_active_at_finalization=" +
           std::string(snapshot.context_active() ? "true" : "false"),
       "recursive_search_state_accounting=execution_total_with_separate_construction_subaccount"},
      {}});
  // Result-v1 budget rows require a finite reportable planned bound.  Its
  // absence can mean either unbounded work or a route-validated
  // NotApplicable category; the diagnostic above preserves that distinction
  // without inventing a grant or a zero-use record.
  const bool calls_within_planned_cap =
      !planned || snapshot.calls_reserved() <= *planned;
  if (planned && calls_within_planned_cap) {
    execution_budgets.push_back(ResultBudgetUsageV1{
        "execution.shared_optimizer_calls",
        ResultBudgetApplicabilityV1::applicable,
        *planned,
        snapshot.calls_reserved(),
        "calls"});
  }
  if (planned_search_states &&
      actual_search_states <= *planned_search_states &&
      calls_within_planned_cap) {
    execution_budgets.push_back(ResultBudgetUsageV1{
        "execution.shared_optimizer_search_states",
        ResultBudgetApplicabilityV1::applicable,
        *planned_search_states,
        actual_search_states,
        "states"});
  }

  if (!snapshot.context_active() && !inactive_owner_permitted) {
    return fail<void>(
        "c27.shared_optimizer_ledger_owner_lost",
        "the execution-wide optimizer context became inactive before a terminal path that retains its live owner");
  }
  if (snapshot.assigned_max_calls() != planned) {
    return fail<void>(
        "c27.shared_optimizer_ledger_bound_mismatch",
        "the observed optimizer ledger does not retain the exact planned execution-wide call cap");
  }
  if (snapshot.assigned_max_search_states() !=
      expected_assigned_search_states) {
    return fail<void>(
        "c27.shared_optimizer_search_state_bound_mismatch",
        "the observed optimizer ledger does not retain the exact call-derived internal recursive search-state safety cap");
  }
  if (planned && snapshot.calls_reserved() > *planned) {
    return fail<void>(
        "c27.shared_optimizer_ledger_cap_exceeded",
        "the committed execution-wide optimizer-call count exceeds its frozen planned cap");
  }
  if (planned_search_states &&
      actual_search_states > *planned_search_states) {
    return fail<void>(
        "c27.shared_optimizer_search_state_cap_exceeded",
        "the committed execution-wide recursive optimizer search-state count exceeds its frozen planned cap");
  }
  return Result<void>::success();
}

void append_uncreated_optimizer_accounting(
    const ExecutionPlan& plan,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& execution_budgets) {
  const std::optional<BigNat>& planned = plan.work_bounds().optimizer_calls;
  const std::optional<BigNat>& planned_search_states =
      plan.work_bounds().optimizer_search_states;
  const bool search_states_not_applicable =
      (detail::is_full_orbit_k_wide_provider(
           plan.provider().identity()) ||
       detail::is_full_orbit_observation_provider(
           plan.provider().identity()) ||
       detail::is_full_orbit_cp09_provider(
           plan.provider().identity())) &&
      !planned_search_states.has_value();
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.execution.shared_optimizer_ledger",
      DiagnosticCategory::information,
      "c27.shared_optimizer_ledger_accounting",
      "Planned optimizer accounting when the execution-wide context could not be constructed",
      std::nullopt,
      ResultDiagnosticKindV1::budget_termination,
      std::nullopt,
      std::nullopt,
      {"planned_max_calls=" +
           (planned ? planned->to_decimal_string()
                    : std::string("unbounded")),
       "assigned_max_calls=not_created",
       "actual_calls=0",
       "planned_max_search_states=" +
           (planned_search_states
                ? planned_search_states->to_decimal_string()
                : std::string(search_states_not_applicable
                                  ? "not_applicable"
                                  : "unbounded")),
       "assigned_max_search_states=not_created",
       "in_process_search_states=0",
       "actual_search_states=0",
       "local_executable_construction_search_states=0",
       "context_active_at_finalization=false",
       "context_created=false",
       "recursive_search_state_accounting=execution_total_with_separate_construction_subaccount"},
      {}});
  if (planned) {
    execution_budgets.push_back(ResultBudgetUsageV1{
        "execution.shared_optimizer_calls",
        ResultBudgetApplicabilityV1::applicable,
        *planned,
        BigNat{0U},
        "calls"});
  }
  if (planned_search_states) {
    execution_budgets.push_back(ResultBudgetUsageV1{
        "execution.shared_optimizer_search_states",
        ResultBudgetApplicabilityV1::applicable,
        *planned_search_states,
        BigNat{0U},
        "states"});
  }
}

void append_u64(std::vector<std::byte>& bytes, const std::uint64_t value) {
  for (int shift = 56; shift >= 0; shift -= 8) {
    bytes.push_back(
        static_cast<std::byte>((value >> static_cast<unsigned>(shift)) &
                               0xffU));
  }
}

void append_bytes(std::vector<std::byte>& output,
                  const std::span<const std::byte> value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  output.insert(output.end(), value.begin(), value.end());
}

void append_natural(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> magnitude = value.canonical_magnitude_bytes();
  append_u64(output, static_cast<std::uint64_t>(magnitude.size()));
  for (const std::uint8_t byte : magnitude) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

struct ScalarResponseStateRegistry final {
  std::mutex mutex;
  std::map<std::string, ExactReducedCoordinatesV1> states;
};

[[nodiscard]] bool same_phase_value(const ArrivalPhase& left,
                                    const ArrivalPhase& right) {
  return arrival_phase_family(left) == arrival_phase_family(right) &&
         arrival_phase_digest(left) == arrival_phase_digest(right) &&
         std::ranges::equal(arrival_phase_canonical_state(left),
                            arrival_phase_canonical_state(right));
}

[[nodiscard]] bool same_scalar_response_coordinates(
    const ExactReducedCoordinatesV1& left,
    const ExactReducedCoordinatesV1& right) {
  return left.backlog == right.backlog &&
         same_phase_value(left.arrival_phase, right.arrival_phase) &&
         left.boundary_index == right.boundary_index &&
         left.resources == right.resources && left.margins == right.margins &&
         left.controller == right.controller &&
         left.unresolved_fields == right.unresolved_fields;
}

[[nodiscard]] Result<ExactReducedStateSchemaV1>
make_scalar_response_state_schema(
    const ExecutionPlan& plan, const PlugDescriptor& descriptor) {
  const auto target_span =
      plan.problem_view().target_selection().ordered_targets;
  std::vector<QueueId> targets(target_span.begin(), target_span.end());
  std::vector<BigNat> zeros(targets.size(), BigNat{0U});
  auto prototype = TargetBacklogV1::from_values(
      plan.resolved_instance(), targets, std::move(zeros));
  if (!prototype) {
    return Result<ExactReducedStateSchemaV1>::failure(prototype.error());
  }
  const bool finite_prefix =
      descriptor.core.payload_class == PayloadClassV1{
          PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U};
  const CodecIdentityV1 codec{
      finite_prefix ? "mwperf.c29.scalar-response-state"
                    : "mwperf.c27.closed-three-bin-state",
      1U};
  const std::string digest_prefix =
      finite_prefix ? "mwperf.c29.scalar-response" : "mwperf.c27.three-bin";
  const std::string state_shape_code =
      finite_prefix ? "c29.scalar_response_state_shape_mismatch"
                    : "c27.three_bin_state_shape_mismatch";
  const std::string state_not_materialized_code =
      finite_prefix ? "c29.scalar_response_state_not_materialized"
                    : "c27.three_bin_state_not_materialized";
  const std::string rebuild_domain_code =
      finite_prefix ? "c29.scalar_response_rebuild_domain_mismatch"
                    : "c27.three_bin_rebuild_domain_mismatch";
  const std::string digest_collision_code =
      finite_prefix ? "c29.scalar_response_state_digest_collision"
                    : "c27.three_bin_state_digest_collision";
  const std::string mark_shape_code =
      finite_prefix ? "c29.scalar_response_mark_decoder_shape_mismatch"
                    : "c27.three_bin_mark_decoder_shape_mismatch";
  const std::string mark_cardinality_code =
      finite_prefix
          ? "c29.scalar_response_mark_target_cardinality_mismatch"
          : "c27.three_bin_mark_target_cardinality_mismatch";
  const auto schema_digest = [&](const std::string_view domain) {
    return sha256_domain_separated(
        domain, plan.problem_view().canonical_digest().value().bytes());
  };
  auto exact = schema_digest(digest_prefix + ".exact-state.v1");
  auto reduced = schema_digest(digest_prefix + ".reduced-state.v1");
  auto ownership = schema_digest(digest_prefix + ".ownership.v1");
  auto update = schema_digest(digest_prefix + ".exact-update.v1");
  if (!exact) return Result<ExactReducedStateSchemaV1>::failure(exact.error());
  if (!reduced) {
    return Result<ExactReducedStateSchemaV1>::failure(reduced.error());
  }
  if (!ownership) {
    return Result<ExactReducedStateSchemaV1>::failure(ownership.error());
  }
  if (!update) {
    return Result<ExactReducedStateSchemaV1>::failure(update.error());
  }

  auto registry = std::make_shared<ScalarResponseStateRegistry>();
  const ArrivalBinding arrival_binding =
      arrival_law_binding(plan.compiled_arrival_law());
  const std::size_t cardinality = targets.size();
  auto decode = [registry, codec, cardinality, finite_prefix,
                 state_shape_code, state_not_materialized_code,
                 target = std::move(prototype).value()](
                    const ReducedStateV1& state)
      -> Result<ExactReducedCoordinatesV1> {
    if (state.codec != codec || state.canonical_value.size() !=
                                    Digest256::kSize) {
      return fail<ExactReducedCoordinatesV1>(
          state_shape_code,
          finite_prefix
              ? "the reduced state is outside the closed scalar-response schema"
              : "the reduced state is outside the C27 closed ThreeBin schema",
          DiagnosticCategory::input_validation);
    }
    const std::string key(
        reinterpret_cast<const char*>(state.canonical_value.data()),
        state.canonical_value.size());
    std::lock_guard lock(registry->mutex);
    const auto found = registry->states.find(key);
    if (found == registry->states.end() ||
        found->second.backlog.size() != cardinality) {
      return fail<ExactReducedCoordinatesV1>(
          state_not_materialized_code,
          finite_prefix
              ? "the content-addressed scalar-response state was not minted "
                "by its exact rebuild operation"
              : "the content-addressed ThreeBin state was not minted by its "
                "exact rebuild operation",
          DiagnosticCategory::input_validation);
    }
    (void)target;
    return Result<ExactReducedCoordinatesV1>::success(found->second);
  };
  auto rebuild = [registry, codec, arrival_binding, cardinality,
                  digest_prefix, finite_prefix, rebuild_domain_code,
                  digest_collision_code](
                     const ExactReducedCoordinatesV1& coordinates,
                     const UnresolvedPatch& unresolved)
      -> Result<ReducedStateV1> {
    if (coordinates.backlog.size() != cardinality ||
        arrival_phase_family(coordinates.arrival_phase) !=
            arrival_binding.family ||
        coordinates.resources.has_value() || !coordinates.margins.empty() ||
        coordinates.controller.has_value() ||
        !coordinates.unresolved_fields.empty() ||
        !unresolved.fields().empty()) {
      return fail<ReducedStateV1>(
          rebuild_domain_code,
          finite_prefix
              ? "the closed scalar-response schema retains exactly target "
                "backlog, configured arrival phase, and physical boundary "
                "index"
              : "the closed ThreeBin schema retains exactly target backlog, "
                "configured arrival phase, and physical boundary index",
          DiagnosticCategory::input_validation);
    }
    std::vector<std::byte> canonical;
    append_u64(canonical, static_cast<std::uint64_t>(cardinality));
    for (const BigNat& value : coordinates.backlog.values()) {
      append_natural(canonical, value);
    }
    canonical.push_back(static_cast<std::byte>(
        static_cast<std::uint8_t>(arrival_phase_family(
            coordinates.arrival_phase))));
    const ArrivalStateDigest phase_digest =
        arrival_phase_digest(coordinates.arrival_phase);
    append_bytes(canonical, phase_digest.value().bytes());
    append_bytes(canonical,
                 arrival_phase_canonical_state(coordinates.arrival_phase));
    append_natural(canonical, coordinates.boundary_index);
    auto digest = sha256_domain_separated(
        digest_prefix + ".state-value.v1", canonical);
    if (!digest) return Result<ReducedStateV1>::failure(digest.error());
    std::vector<std::byte> value(digest.value().bytes().begin(),
                                 digest.value().bytes().end());
    const std::string key(reinterpret_cast<const char*>(value.data()),
                          value.size());
    {
      std::lock_guard lock(registry->mutex);
      auto [found, inserted] = registry->states.emplace(key, coordinates);
      if (!inserted &&
          !same_scalar_response_coordinates(found->second, coordinates)) {
        return fail<ReducedStateV1>(
            digest_collision_code,
            finite_prefix
                ? "two distinct exact scalar-response states produced one "
                  "canonical state digest"
                : "two distinct exact ThreeBin states produced one canonical "
                  "state digest");
      }
    }
    return Result<ReducedStateV1>::success(
        ReducedStateV1{codec, std::move(value)});
  };
  auto validate = [decode](const ReducedStateV1& state) -> Result<void> {
    auto decoded = decode(state);
    if (!decoded) return Result<void>::failure(decoded.error());
    return Result<void>::success();
  };

  std::vector<DeterministicRuntimeMarkDecoderOperationV1> mark_decoders;
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    if (mark.decoder_source != MarkDecoderSourceV1::predecision_state) {
      continue;
    }
    if (mark.c14_mark.kind != MetricMarkKindV1::target_backlog ||
        mark.decoder_input_codec != codec) {
      return fail<ExactReducedStateSchemaV1>(
          mark_shape_code,
          finite_prefix
              ? "the closed scalar-response state supports only "
                "target-backlog predecision marks bound to its exact "
                "reduced-state codec"
              : "the closed ThreeBin state supports only target-backlog "
                "predecision marks bound to its exact reduced-state codec",
          DiagnosticCategory::input_validation);
    }
    mark_decoders.emplace_back(
        DeterministicRuntimeMarkDecoderSchemaV1{
            mark.decoder_id, mark.id, mark.decoder_source,
            mark.decoder_input_codec, mark.c14_mark.codec},
        [decode, finite_prefix, mark_cardinality_code,
         output_codec = mark.c14_mark.codec](
            const CanonicalRuntimeValueV1& input)
            -> Result<CanonicalRuntimeValueV1> {
          auto coordinates = decode(
              ReducedStateV1{input.codec, input.canonical_value});
          if (!coordinates) {
            return Result<CanonicalRuntimeValueV1>::failure(
                coordinates.error());
          }
          if (coordinates.value().backlog.size() != 1U) {
            return fail<CanonicalRuntimeValueV1>(
                mark_cardinality_code,
                finite_prefix
                    ? "the scalar-response target-backlog decoder requires "
                      "one deployed target"
                    : "the scalar ThreeBin target-backlog decoder requires "
                      "one deployed target");
          }
          const std::vector<std::uint8_t> magnitude =
              coordinates.value()
                  .backlog.value_at_target_ordinal(0U)
                  .canonical_magnitude_bytes();
          std::vector<std::byte> encoded;
          encoded.reserve(magnitude.size());
          for (const std::uint8_t byte : magnitude) {
            encoded.push_back(static_cast<std::byte>(byte));
          }
          return Result<CanonicalRuntimeValueV1>::success(
              CanonicalRuntimeValueV1{output_codec, std::move(encoded)});
        });
  }
  return Result<ExactReducedStateSchemaV1>::success(
      ExactReducedStateSchemaV1{
          codec,
          std::move(exact).value(),
          std::move(reduced).value(),
          std::move(ownership).value(),
          std::move(update).value(),
          std::move(decode),
          std::move(rebuild),
          std::move(validate),
          std::move(mark_decoders),
          {},
          {}});
}

struct ActivatedFrameworkV1 final {
  AuditedCompiledFramework framework;
  ExactReducedStateSchemaV1 state_schema;
  std::vector<ReducedStateV1> finite_backend_domain_states;
  bool exact_closed_boundary_proven;
  std::optional<RuntimeFrameworkActivationV1::
                    SingleConditioningStateBindingV1>
      single_conditioning_state;
  std::vector<RuntimeFrameworkActivationV1::ConditionalRewardDecoderBindingV1>
      conditional_reward_decoders;
};

[[nodiscard]] Result<ActivatedFrameworkV1> audit_built_framework(
    const ExecutionPlan& plan, const SurrogateBuildRequest& request,
    const ValidatedSurrogateArtifact& artifact,
    const PortablePlugPayload& portable_payload, ValidatedSurrogatePlug plug,
    KernelAccess access,
    OptimizerExecutionContext optimizer) {
  const PlugDescriptor descriptor = plug.descriptor();
  auto access_digest =
      detail::canonical_kernel_access_identity_for_candidate(access);
  if (!access_digest) {
    return Result<ActivatedFrameworkV1>::failure(access_digest.error());
  }
  auto ordered_target_digest =
      artifact::detail::canonical_ordered_metric_targets_digest_v1(
          plan.problem_view().target_selection().ordered_targets);
  if (!ordered_target_digest) {
    return Result<ActivatedFrameworkV1>::failure(
        ordered_target_digest.error());
  }
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          plan.selection_spec());
  if (!selection_digest) {
    return Result<ActivatedFrameworkV1>::failure(
        selection_digest.error());
  }
  const std::vector<QueueId> payload_targets(
      descriptor.core.deployed_targets.begin(),
      descriptor.core.deployed_targets.end());
  auto realized = validate_realized_metric_bindings_v1(
      plan.capability_contract().structural_manifest(),
      RealizedBindingValidationContextV1{
          RealizedBindingTargetContextV1{
              payload_targets,
              payload_targets.size() == 1U
                  ? std::optional<QueueId>{payload_targets.front()}
                  : std::nullopt,
              std::vector<QueueId>(
                  plan.capability_contract().construction_target_scope()
                      .begin(),
                  plan.capability_contract().construction_target_scope()
                      .end())},
          plan.capability_contract().policies()},
      artifact.value().realized_metric_bindings.bindings);
  if (!realized) {
    return Result<ActivatedFrameworkV1>::failure(realized.error());
  }

  std::optional<ExactMetricDecoderDomainV1> direct_domain;
  if (const auto* direct = std::get_if<RawDirectDecoderAccess>(&access)) {
    direct_domain = direct->domain().metric_domain;
  }
  RuntimeFrameworkBindingContextV1 binding_context{
      plan.problem_view().fingerprints(),
      plan.problem_view().canonical_digest(),
      descriptor.descriptor_digest,
      std::move(access_digest).value(),
      plan.capability_contract().contract_digest(),
      plan.capability_contract().requirements_digest(),
      std::move(ordered_target_digest).value(),
      std::move(selection_digest).value(),
      request.request_digest().value(),
      std::move(direct_domain)};

  auto activation_result = [&]()
      -> Result<RuntimeFrameworkActivationV1> {
    // The framework owns both closed scalar compositions: their V0 state is
    // one target backlog plus the configured external arrival phase.  The
    // dynamic response changes only the exact scalar lookup, never the state
    // dimension.  Other payloads require the statically registered provider
    // recipe that owns their exact state schema and initial projection.
    const bool three_bin_payload =
        descriptor.core.payload_class.tag ==
        PayloadClassTagV1::three_bin_scalar_response_v1;
    const bool finite_prefix_constant_tail_payload =
        descriptor.core.payload_class.tag ==
        PayloadClassTagV1::finite_prefix_constant_tail_response_v1;
    if (descriptor.core.semantic ==
            SemanticTagV1::scalar_backlog_response &&
        descriptor.core.runtime_access ==
            RuntimeAccessTagV1::finite_parameter_analytic_family &&
        (three_bin_payload || finite_prefix_constant_tail_payload)) {
      auto state_schema =
          make_scalar_response_state_schema(plan, descriptor);
      if (!state_schema) {
        return Result<RuntimeFrameworkActivationV1>::failure(
            state_schema.error());
      }
      const ExactReducedStateSchemaV1 schema_copy = state_schema.value();
      const Digest256 instance_digest =
          plan.resolved_instance().fingerprints().combined;
      const SelectionKindV1 configured_selection =
          selection_kind(plan.problem_view().analysis_selection());
      const auto domain_validator = schema_copy.validate_domain;
      AuditedFrameworkSeedV1 seed{
          binding_context.bind_state_schema(schema_copy),
          plan.problem_view().target_selection(),
          schema_copy.reduced_state_codec,
          descriptor.core.selection,
          InitialSelectionAuthorityV1{configured_selection, std::nullopt},
          [finite_prefix_constant_tail_payload](const SelectionSpec&,
             const std::optional<InitialPhysicalLaw>&)
              -> Result<ReducedInitialLawCandidateV1> {
            return fail<ReducedInitialLawCandidateV1>(
                finite_prefix_constant_tail_payload
                    ? "c29.scalar_response_initial_law_not_materialized"
                    : "c27.three_bin_initial_law_not_materialized",
                finite_prefix_constant_tail_payload
                    ? "the closed analytic scalar-response route does not "
                      "manufacture a reduced transient or invariant initial "
                      "law"
                    : "the closed analytic ThreeBin route does not "
                      "manufacture a reduced transient or invariant initial "
                      "law");
          },
          [finite_prefix_constant_tail_payload, instance_digest,
           exact_digest = schema_copy.exact_state_schema_digest](
              const ResolvedInstance& instance, const Digest256& supplied) {
            if (instance.fingerprints().combined != instance_digest ||
                supplied != exact_digest) {
              return fail<void>(
                  finite_prefix_constant_tail_payload
                      ? "c29.scalar_response_initial_schema_binding_mismatch"
                      : "c27.three_bin_initial_schema_binding_mismatch",
                  "the initial-state validator received a foreign instance or exact schema",
                  DiagnosticCategory::input_validation);
            }
            return Result<void>::success();
          },
          domain_validator,
          [finite_prefix_constant_tail_payload](
             std::size_t, const InitialPhysicalAtom&,
             const ReducedStateV1&) -> Result<void> {
            return fail<void>(
                finite_prefix_constant_tail_payload
                    ? "c29.scalar_response_physical_projection_unavailable"
                    : "c27.three_bin_physical_projection_unavailable",
                finite_prefix_constant_tail_payload
                    ? "the analytic scalar-response route has no declared "
                      "physical-to-reduced transient projection"
                    : "the analytic ThreeBin route has no declared "
                      "physical-to-reduced transient projection");
          }};
      return Result<RuntimeFrameworkActivationV1>::success(
          RuntimeFrameworkActivationV1{
          std::move(state_schema).value(),
          std::make_shared<const ExactCausalProgramV1>(
              ExactCausalProgramV1{
                  finite_prefix_constant_tail_payload
                      ? ExactCausalProgramModeV1::
                            closed_finite_prefix_constant_tail_scalar
                      : ExactCausalProgramModeV1::closed_three_bin_scalar,
                  physical_pmf_tolerance(),
                  PmfRepresentationBudget::unbounded(),
                  {}}),
          std::make_shared<const AuditedFrameworkSeedV1>(std::move(seed)),
          {},
          {},
          false,
          std::nullopt,
          {}});
    }
    auto activated = activate_registered_surrogate_framework(
        plan.provider(), RuntimeFrameworkActivationContextV1{
                             portable_payload,
                             artifact,
                             plan.capability_contract(),
                             plan.problem_view(),
                             plan.resolved_instance(),
                             plan.compiled_arrival_law(),
                             descriptor,
                             access,
                             realized.value(),
                             binding_context,
                             request.build_identity_digest(),
                             request.request_digest().value()});
    return activated;
  }();
  if (!activation_result) {
    return Result<ActivatedFrameworkV1>::failure(
        activation_result.error());
  }
  RuntimeFrameworkActivationV1 activation =
      std::move(activation_result).value();
  if (!activation.causal_program || !activation.framework_seed) {
    return fail<ActivatedFrameworkV1>(
        "c27.framework_activation_incomplete",
        "the exact framework activation omitted its causal program or framework seed");
  }

  const ExactReducedStateSchemaV1 schema_copy =
      activation.exact_state_schema;
  std::vector<ReducedStateV1> finite_domain =
      activation.finite_backend_domain_states;
  const bool exact_closed = activation.exact_closed_boundary_proven;
  std::optional<RuntimeFrameworkActivationV1::
                    SingleConditioningStateBindingV1>
      conditioning_state =
      activation.single_conditioning_state;
  auto reward_decoders = activation.conditional_reward_decoders;
  OptimizerFreeFrameworkCandidateInputsV1 common_inputs{
      request.build_identity_digest(),
      request.request_digest().value(),
      plan.resolved_instance(),
      plan.compiled_arrival_law(),
      plan.capability_contract(),
      std::move(realized).value(),
      std::move(activation.exact_state_schema),
      *activation.causal_program,
      *activation.framework_seed};
  Result<AuditedCompiledFramework> framework = [&]() {
    if (activation.direct_metric_activation) {
      const auto capabilities =
          plan.provider().framework_activation_capabilities();
      if (!capabilities.has_value() ||
          !capabilities->supplies_direct_factor ||
          !capabilities->maximum_direct_factor_optimizer_calls.has_value() ||
          activation.direct_metric_activation.use_count() != 1U) {
        return fail<AuditedCompiledFramework>(
            "c27.direct_composite_activation_incomplete",
            "the direct framework activation lost its unique fresh factor "
            "recipe or callback-free optimizer-call bound");
      }
      RuntimeDirectMetricActivationV1 direct_activation(
          std::move(*activation.direct_metric_activation));
      activation.direct_metric_activation.reset();
      auto composite =
          C17AuditedFrameworkMint::make_direct_composite_candidate(
              std::move(plug), std::move(access),
              std::move(common_inputs), std::move(direct_activation),
              std::move(optimizer),
              *capabilities->maximum_direct_factor_optimizer_calls);
      return audit_v0_direct_composite(std::move(composite));
    }
    CompiledFrameworkCandidateInputsV1 inputs{
        std::move(common_inputs.build_identity),
        std::move(common_inputs.final_request_identity),
        std::move(common_inputs.instance),
        std::move(common_inputs.configured_arrival),
        std::move(common_inputs.accepted_contract),
        std::move(common_inputs.realized_metric_bindings),
        std::move(common_inputs.exact_state_schema),
        std::move(common_inputs.causal_program),
        std::nullopt,
        std::move(optimizer),
        std::move(common_inputs.framework_seed)};
    auto ordinary = C17AuditedFrameworkMint::make_candidate(
        std::move(plug), std::move(inputs));
    return audit_v0_causality(
        std::move(ordinary), descriptor, std::move(access));
  }();
  if (!framework) {
    return Result<ActivatedFrameworkV1>::failure(framework.error());
  }
  return Result<ActivatedFrameworkV1>::success(ActivatedFrameworkV1{
      std::move(framework).value(), schema_copy, std::move(finite_domain),
      exact_closed, std::move(conditioning_state),
      std::move(reward_decoders)});
}

[[nodiscard]] std::vector<std::string> support_clause_assumptions(
    const ResolvedMetricContractV1& contract,
    const MetricSupportClauseV1& clause) {
  std::vector<std::string> assumptions{
      "accepted_support_clause=" + contract.support_clause_digest.hex()};
  for (const ArrivalAssumptionV1& arrival : clause.arrival_assumptions) {
    assumptions.push_back(
        "accepted_arrival_assumption=" +
        std::to_string(static_cast<std::uint8_t>(arrival.kind)) + ":" +
        std::to_string(static_cast<std::uint8_t>(arrival.provision)));
  }
  for (const HypothesisClaimV1& hypothesis : clause.hypotheses) {
    std::string encoded =
        "accepted_hypothesis=" +
        std::to_string(static_cast<std::uint8_t>(hypothesis.kind));
    if (hypothesis.variable) {
      encoded += ":variable=" + std::to_string(
          static_cast<std::uint8_t>(*hypothesis.variable));
    }
    if (hypothesis.order) {
      encoded += ":order=" + hypothesis.order->to_decimal_string();
    }
    if (hypothesis.convention_or_class) {
      encoded += ":convention=" +
                 typed_label_text(*hypothesis.convention_or_class);
    }
    assumptions.push_back(std::move(encoded));
  }
  return assumptions;
}

[[nodiscard]] ResultMetricValueV1 canonical_result_value(
    const CanonicalRuntimeValueV1& value) {
  // Runtime codec bytes are already the backend's complete, versioned
  // mathematical result carrier.  C27 preserves them byte-for-byte and does
  // not decode/re-encode a backend-owned schema merely for presentation.
  return ResultCanonicalValueV1{value.codec, value.canonical_value};
}

[[nodiscard]] ResultMetricHeaderV1 backend_metric_header(
    const PlannedMetricV1& metric, const MetricSupportClauseV1& clause,
    const Digest256& law_identity, std::string convention,
    std::vector<std::string> residual_refs = {},
    std::vector<std::string> error_refs = {},
    std::vector<std::string> additional_assumptions = {}) {
  const MetricRequestHeader& source =
      metric_request_header(metric.request());
  std::vector<std::string> assumptions =
      support_clause_assumptions(metric.contract(), clause);
  assumptions.insert(assumptions.end(),
                     std::make_move_iterator(additional_assumptions.begin()),
                     std::make_move_iterator(additional_assumptions.end()));
  return ResultMetricHeaderV1{
      source.metric_id,
      source.kind,
      result_targets(source),
      std::string(metric_units(source.kind)),
      std::move(convention),
      law_identity,
      clause.result_scope,
      std::move(assumptions),
      std::move(error_refs),
      std::move(residual_refs)};
}

void append_v0_only_certificates(
    const ValidatedCertificates& validated,
    std::vector<ResultCertificateV1>& certificates) {
  const auto append = [&](std::string id, const ValidatedClaimV1& claim) {
    std::vector<std::string> evidence;
    if (claim.evidence.has_value()) {
      evidence.push_back(
          "evidence:id=" + typed_label_text(claim.evidence->object_id) +
          ",digest=" + claim.evidence->object_digest.hex());
    }
    std::vector<std::string> assumptions{
        "c25_evidence_graph=" + validated.graph_digest().hex(),
        "v0_required_and_established",
        "absence_of_stronger_evidence_is_not_refutation"};
    assumptions.insert(assumptions.end(), claim.diagnostics.begin(),
                       claim.diagnostics.end());
    certificates.push_back(ResultCertificateV1{
        std::move(id), claim.kind, claim.state, std::move(assumptions),
        std::move(evidence), {"c27.v0.causal_admissibility"}});
  };
  append("c25.v1_fibre_geometry", validated.v1_geometry());
  append("c25.v2_dynamic_lift", validated.v2_dynamic_lift());
  append("c25.stationary_integrated_fidelity",
         validated.stationary_integrated_fidelity());
  append("c25.physical_fidelity", validated.physical_fidelity());
  append("c25.stability", validated.stability());
}

[[nodiscard]] Result<void> validate_v0_only_certificate_layer(
    const AuditedCompiledFramework& framework,
    std::vector<ResultCertificateV1>& certificates) {
  auto evidence = Evidence::bind(framework, {});
  if (!evidence) return Result<void>::failure(evidence.error());
  CertificateBundle bundle = CertificateBundle::v0_only(evidence.value());
  auto validated =
      validate_certificate_bundle(bundle, framework, evidence.value());
  if (!validated) return Result<void>::failure(validated.error());
  append_v0_only_certificates(validated.value(), certificates);
  return Result<void>::success();
}

[[nodiscard]] Result<SolverPolicy> enumerated_solver_policy(
    const ExecutionPlan& plan) {
  const SolverSpec& authored =
      plan.resolved_instance().analysis_spec().context->solver;
  const auto* enumerated = std::get_if<EnumeratedSolver>(&authored);
  if (enumerated == nullptr) {
    return fail<SolverPolicy>(
        "c27.enumerated_solver_required",
        "the selected exact finite backend requires the frozen enumerated solver");
  }
  ExactRational absolute = ExactRational::zero();
  const auto& configured = plan.resolved_instance()
                               .analysis_spec()
                               .context->resolution.tolerance
                               .linear_residual_abs;
  if (configured.has_value()) absolute = *configured;
  return Result<SolverPolicy>::success(SolverPolicy{
      enumerated->linear_method, enumerated->max_iterations,
      std::move(absolute), ExactRational::zero(),
      plan.resolved_instance().fingerprints().analysis});
}

struct TemporalRepresentationCapsV1 final {
  std::size_t maximum_states;
  std::size_t maximum_row_atoms;
};

[[nodiscard]] Result<std::size_t> temporal_representation_cap(
    const std::optional<BigNat>& authored, const std::string_view name) {
  if (!authored.has_value()) {
    return fail<std::size_t>(
        "c27.temporal_representation_cap_missing",
        "the frozen exact temporal route has no authored " +
            std::string(name) + " allocation limit");
  }
  if (authored->bit_length() >
      std::numeric_limits<std::size_t>::digits) {
    return fail<std::size_t>(
        "c27.temporal_representation_cap_not_addressable",
        "the authored " + std::string(name) +
            " allocation limit has no addressable native representation",
        DiagnosticCategory::resource_limit);
  }
  return Result<std::size_t>::success(
      authored->value().convert_to<std::size_t>());
}

[[nodiscard]] Result<TemporalRepresentationCapsV1>
temporal_representation_caps(const ExecutionPlan& plan) {
  const LevelResolution& level =
      plan.resolved_instance().analysis_spec().context->resolution.level;
  auto states = temporal_representation_cap(level.max_states, "max_states");
  if (!states) {
    return Result<TemporalRepresentationCapsV1>::failure(states.error());
  }
  auto row_atoms = temporal_representation_cap(
      level.max_row_atoms, "max_row_atoms");
  if (!row_atoms) {
    return Result<TemporalRepresentationCapsV1>::failure(
        row_atoms.error());
  }
  return Result<TemporalRepresentationCapsV1>::success(
      TemporalRepresentationCapsV1{states.value(), row_atoms.value()});
}

struct ExactStationaryBackendV1 final {
  TransitionMatrix matrix;
  ClassDecomposition classes;
  InvariantSelection selection;
  InvariantLaw law;
  DiagnosticBundle diagnostics;
};

[[nodiscard]] Result<ExactStationaryBackendV1>
build_exact_stationary_backend(const ExecutionPlan& plan,
                               const ActivatedFrameworkV1& activated) {
  if (activated.finite_backend_domain_states.empty()) {
    return fail<ExactStationaryBackendV1>(
        "c27.finite_backend_domain_unavailable",
        "the registered exact activation did not supply a finite state domain for the requested stationary backend");
  }
  if (!activated.exact_closed_boundary_proven) {
    return fail<ExactStationaryBackendV1>(
        "c27.stationary_boundary_rule_unavailable",
        "the finite backend domain has no registered raw exact-closure or "
        "audited stationary clock-quotient proof, and C27 will not invent a "
        "boundary completion");
  }
  auto provider = audited_row_provider(activated.framework);
  if (!provider) {
    return Result<ExactStationaryBackendV1>::failure(provider.error());
  }
  auto matrix =
      detail::assemble_finite_stationary_time_homogeneous_transition_matrix(
          StateDomain{activated.finite_backend_domain_states},
          provider.value());
  if (!matrix &&
      matrix.error().code ==
          "c18.stationary_time_homogeneous_quotient_unavailable") {
    // Preserve the original raw exact-closure lane for a provider whose
    // finite physical state really is closed.  The quotient path above is
    // selected only by its independently audited C17 clock-erasure seal.
    matrix = assemble_finite_transition_matrix(
        StateDomain{activated.finite_backend_domain_states},
        provider.value(),
        BoundaryRule{BoundaryCompletionKindV1::exact_closed, std::nullopt,
                     true, {}});
  }
  if (!matrix) {
    return Result<ExactStationaryBackendV1>::failure(matrix.error());
  }
  ClassDecomposition classes = analyze_communicating_classes(matrix.value());
  auto selection =
      select_invariant_class(classes, plan.selection_spec());
  if (!selection) {
    return Result<ExactStationaryBackendV1>::failure(selection.error());
  }
  auto policy = enumerated_solver_policy(plan);
  if (!policy) {
    return Result<ExactStationaryBackendV1>::failure(policy.error());
  }
  auto law = solve_invariant_distribution(matrix.value(), selection.value(),
                                          policy.value());
  if (!law) return Result<ExactStationaryBackendV1>::failure(law.error());
  DiagnosticBundle diagnostics = compute_stationary_flux_diagnostics(
      law.value(), plan.resolved_instance());
  if (!diagnostics.publication_allowed) {
    return fail<ExactStationaryBackendV1>(
        diagnostics.fatal ? "c27.stationary_diagnostics_failed"
                          : "c27.stationary_publication_not_established",
        diagnostics.fatal
            ? "the exact stationary backend reported fatal invariant or flux diagnostics"
            : "the exact stationary backend did not establish the diagnostics required for publication",
        diagnostics.fatal ? DiagnosticCategory::internal
                          : DiagnosticCategory::unavailable);
  }
  return Result<ExactStationaryBackendV1>::success(
      ExactStationaryBackendV1{
          std::move(matrix).value(), std::move(classes),
          std::move(selection).value(), std::move(law).value(),
          std::move(diagnostics)});
}

struct StationaryTemporalBackendV1 final {
  AuditedResidenceProvider provider;
  EmbeddedKernel embedded;
  EventInvariantLaw event_law;
  PositiveFiniteMean mean_residence;
  StationaryTemporalProjection projection;
  std::size_t actual_state_count;
  std::size_t actual_maximum_row_atoms;
};

[[nodiscard]] Result<StationaryTemporalBackendV1>
build_stationary_temporal_backend(const ExecutionPlan& plan,
                                  const ActivatedFrameworkV1& activated) {
  auto provider = audited_residence_provider(activated.framework);
  if (!provider) {
    return Result<StationaryTemporalBackendV1>::failure(provider.error());
  }
  auto domain =
      FiniteEventStateDomain::from_audited_provider(provider.value());
  if (!domain) {
    return Result<StationaryTemporalBackendV1>::failure(domain.error());
  }
  auto embedded =
      assemble_embedded_event_kernel(domain.value(), provider.value());
  if (!embedded) {
    return Result<StationaryTemporalBackendV1>::failure(embedded.error());
  }
  auto policy = enumerated_solver_policy(plan);
  if (!policy) {
    return Result<StationaryTemporalBackendV1>::failure(policy.error());
  }
  auto law = select_event_invariant_law(
      embedded.value(), plan.selection_spec(), policy.value());
  if (!law) {
    return Result<StationaryTemporalBackendV1>::failure(law.error());
  }
  auto mean = compute_mean_residence(law.value(), provider.value());
  if (!mean) {
    return Result<StationaryTemporalBackendV1>::failure(mean.error());
  }
  auto caps = temporal_representation_caps(plan);
  if (!caps) {
    return Result<StationaryTemporalBackendV1>::failure(caps.error());
  }
  auto projection =
      stationary::detail::build_stationary_temporal_projection_bounded(
          law.value(), provider.value(), mean.value(),
          caps.value().maximum_states,
          caps.value().maximum_row_atoms);
  if (!projection) {
    return Result<StationaryTemporalBackendV1>::failure(
        projection.error());
  }
  auto bounded_projection = std::move(projection).value();
  return Result<StationaryTemporalBackendV1>::success(
      StationaryTemporalBackendV1{
          std::move(provider).value(), std::move(embedded).value(),
          std::move(law).value(), std::move(mean).value(),
          std::move(bounded_projection.projection),
          bounded_projection.actual_state_count,
          bounded_projection.actual_maximum_row_atoms});
}

[[nodiscard]] ResultMetricHeaderV1 scalar_response_metric_header(
    const MetricRequestHeader& source,
    const ResolvedMetricContractV1& contract,
    const MetricSupportClauseV1& clause,
    const StationaryAnalyticLawIdentityV1& law, std::string units,
    std::string convention, std::string response_assumption,
    std::vector<std::string> residual_refs,
    std::vector<std::string> additional_assumptions) {
  std::vector<std::string> assumptions =
      support_clause_assumptions(contract, clause);
  assumptions.insert(assumptions.begin(),
                     {std::move(response_assumption),
                      "configured_iid_late_arrival",
                      "early_service_late_admission"});
  assumptions.insert(assumptions.end(),
                     std::make_move_iterator(
                         additional_assumptions.begin()),
                     std::make_move_iterator(additional_assumptions.end()));
  return ResultMetricHeaderV1{
      source.metric_id,
      source.kind,
      result_targets(source),
      std::move(units),
      std::move(convention),
      law.execution_seal_digest(),
      law.result_scope(),
      std::move(assumptions),
      {},
      std::move(residual_refs)};
}

[[nodiscard]] ResultMetricHeaderV1 metric_header(
    const MetricRequestHeader& source,
    const ResolvedMetricContractV1& contract,
    const MetricSupportClauseV1& clause,
    const StationaryAnalyticLawIdentityV1& law, std::string units,
    std::string convention, std::vector<std::string> residual_refs = {},
    std::vector<std::string> additional_assumptions = {}) {
  return scalar_response_metric_header(
      source, contract, clause, law, std::move(units),
      std::move(convention), "phase_free_three_bin_response",
      std::move(residual_refs), std::move(additional_assumptions));
}

[[nodiscard]] ResultMetricHeaderV1 finite_prefix_metric_header(
    const MetricRequestHeader& source,
    const ResolvedMetricContractV1& contract,
    const MetricSupportClauseV1& clause,
    const StationaryAnalyticLawIdentityV1& law, std::string units,
    std::string convention, std::vector<std::string> residual_refs = {},
    std::vector<std::string> additional_assumptions = {}) {
  return scalar_response_metric_header(
      source, contract, clause, law, std::move(units),
      std::move(convention),
      "phase_free_finite_prefix_constant_tail_response",
      std::move(residual_refs), std::move(additional_assumptions));
}

[[nodiscard]] ResultMetricHeaderV1 framework_identity_metric_header(
    const MetricRequestHeader& source,
    const ResolvedMetricContractV1& contract,
    const MetricSupportClauseV1& clause, const Digest256& execution_seal,
    std::string units, std::string convention,
    std::vector<std::string> residual_refs,
    std::vector<std::string> additional_assumptions = {}) {
  std::vector<std::string> assumptions =
      support_clause_assumptions(contract, clause);
  assumptions.insert(assumptions.begin(),
                     {"framework_scalar_identity",
                      "stationary_lossless_flow_identity",
                      "configured_arrival_exact_first_moment"});
  assumptions.insert(assumptions.end(),
                     std::make_move_iterator(
                         additional_assumptions.begin()),
                     std::make_move_iterator(additional_assumptions.end()));
  return ResultMetricHeaderV1{
      source.metric_id,
      source.kind,
      result_targets(source),
      std::move(units),
      std::move(convention),
      execution_seal,
      clause.result_scope,
      std::move(assumptions),
      {},
      std::move(residual_refs)};
}

[[nodiscard]] const MetricSupportClauseV1* accepted_support_clause(
    const ExecutionPlan& plan, const PlannedMetricV1& metric) noexcept {
  const auto clauses =
      plan.capability_contract().structural_manifest().clauses();
  const auto found = std::ranges::find_if(
      clauses, [&](const MetricSupportClauseV1& clause) {
        return clause.clause_id == metric.contract().clause_id;
      });
  return found == clauses.end() ? nullptr : &*found;
}

[[nodiscard]] bool declared_off_support_convention(
    const MetricSupportClauseV1& clause) noexcept {
  return std::ranges::any_of(
      clause.hypotheses, [](const HypothesisClaimV1& hypothesis) {
        return hypothesis.kind ==
                   HypothesisKindV1::positive_conditioning_mass &&
               hypothesis.convention_or_class.has_value();
      });
}

[[nodiscard]] bool is_arrival_intensity_identity_requirement(
    const PlannedMetricV1& metric) noexcept {
  const auto* backend =
      std::get_if<FrameworkScalarIdentityBackendPlanV1>(&metric.backend());
  return backend != nullptr &&
         backend->scalar == FrameworkScalarKindV1::arrival_intensity;
}

[[nodiscard]] bool finite_prefix_normalized_law_established(
    const FinitePrefixIidSummary& summary) noexcept {
  return summary.prefix_masses().has_value() &&
         summary.aggregate_tail_mass().has_value() &&
         !summary.prefix_masses()->empty() &&
         summary.prefix_masses()->size() ==
             summary.service_by_level().size();
}

[[nodiscard]] Result<ResultMetricV1> map_framework_scalar_identity(
    const ExecutionPlan& plan, const PlannedMetricV1& metric,
    const MetricSupportClauseV1& clause, const Digest256& execution_seal,
    const ThreeBinIidSummary& stationary_summary,
    const std::vector<std::string>& residual_refs) {
  const MetricRequestHeader& header = metric_request_header(metric.request());
  if (header.kind != MetricKindV1::stationary_throughput) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_kind_unsupported",
        "the selected framework scalar identity does not implement the requested metric kind",
        DiagnosticCategory::internal);
  }
  if (!is_arrival_intensity_identity_requirement(metric)) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_law_mismatch",
        "the frozen identity route is not backed by the arrival-intensity semantic requirement",
        DiagnosticCategory::internal);
  }
  if (header.ordered_targets.size() != 1U) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_target_cardinality",
        "the v1 arrival-intensity identity requires exactly one resolved metric target",
        DiagnosticCategory::internal);
  }
  if (!stationary_summary.pi_zero() || !stationary_summary.pi_one() ||
      !stationary_summary.pi_two() ||
      !stationary_summary.tail_mass_from_three()) {
    return fail<ResultMetricV1>(
        "c27.stationary_throughput_not_established",
        "the selected ThreeBin IID backend did not establish a proper normalized stationary law for the lossless flow identity",
        DiagnosticCategory::unavailable);
  }
  const BuilderArrivalView& arrival =
      plan.problem_view().configured_arrival();
  if (!(arrival_law_binding(plan.compiled_arrival_law()) ==
        plan.problem_view().configured_arrival().binding())) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_arrival_binding_mismatch",
        "the compiled configured arrival does not match the canonical law "
        "and queue-catalog binding frozen in the problem view",
        DiagnosticCategory::internal);
  }
  const auto& moments = arrival.moments();
  if (!moments) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_moment_unavailable",
        "the configured arrival view does not carry the exact first target moment accepted by the route",
        DiagnosticCategory::internal);
  }
  const DenseQueueIndex target = header.ordered_targets.front().dense_index;
  const auto matches = [&](const ExactMomentDatum& datum) {
    return datum.order == BigNat{1U} && datum.coordinates.size() == 1U &&
           datum.coordinates.front() == target;
  };
  const std::size_t match_count =
      static_cast<std::size_t>(std::ranges::count_if(*moments, matches));
  if (match_count != 1U) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_target_moment_missing",
        "the exact first-moment table must have exactly one row for the resolved throughput target",
        DiagnosticCategory::internal);
  }
  const auto found = std::ranges::find_if(*moments, matches);
  if (!(found->value == stationary_summary.arrival_mean())) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_arrival_mean_mismatch",
        "the C19 arrival mean differs from the frozen exact target-moment identity",
        DiagnosticCategory::internal);
  }
  return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
      framework_identity_metric_header(
          header, metric.contract(), clause, execution_seal, "packets/slot",
          "stationary lossless throughput equals configured target arrival intensity",
          residual_refs),
      PortableScientificScalar::rational(found->value)});
}

[[nodiscard]] Result<ResultMetricV1>
map_finite_prefix_framework_scalar_identity(
    const ExecutionPlan& plan, const PlannedMetricV1& metric,
    const MetricSupportClauseV1& clause, const Digest256& execution_seal,
    const FinitePrefixIidSummary& stationary_summary,
    const std::vector<std::string>& residual_refs) {
  const MetricRequestHeader& header = metric_request_header(metric.request());
  if (header.kind != MetricKindV1::stationary_throughput) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_kind_unsupported",
        "the selected framework scalar identity does not implement the requested metric kind",
        DiagnosticCategory::internal);
  }
  if (!is_arrival_intensity_identity_requirement(metric)) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_law_mismatch",
        "the frozen identity route is not backed by the arrival-intensity semantic requirement",
        DiagnosticCategory::internal);
  }
  if (header.ordered_targets.size() != 1U) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_target_cardinality",
        "the v1 arrival-intensity identity requires exactly one resolved metric target",
        DiagnosticCategory::internal);
  }
  if (!finite_prefix_normalized_law_established(stationary_summary)) {
    return fail<ResultMetricV1>(
        "c27.stationary_throughput_not_established",
        "the selected finite-prefix IID backend did not establish a proper normalized stationary law for the lossless flow identity",
        DiagnosticCategory::unavailable);
  }
  const BuilderArrivalView& arrival =
      plan.problem_view().configured_arrival();
  if (!(arrival_law_binding(plan.compiled_arrival_law()) ==
        plan.problem_view().configured_arrival().binding())) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_arrival_binding_mismatch",
        "the compiled configured arrival does not match the canonical law "
        "and queue-catalog binding frozen in the problem view",
        DiagnosticCategory::internal);
  }
  const auto& moments = arrival.moments();
  if (!moments) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_moment_unavailable",
        "the configured arrival view does not carry the exact first target moment accepted by the route",
        DiagnosticCategory::internal);
  }
  const DenseQueueIndex target = header.ordered_targets.front().dense_index;
  const auto matches = [&](const ExactMomentDatum& datum) {
    return datum.order == BigNat{1U} && datum.coordinates.size() == 1U &&
           datum.coordinates.front() == target;
  };
  const std::size_t match_count =
      static_cast<std::size_t>(std::ranges::count_if(*moments, matches));
  if (match_count != 1U) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_target_moment_missing",
        "the exact first-moment table must have exactly one row for the resolved throughput target",
        DiagnosticCategory::internal);
  }
  const auto found = std::ranges::find_if(*moments, matches);
  if (!(found->value == stationary_summary.arrival_mean())) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_arrival_mean_mismatch",
        "the C19 arrival mean differs from the frozen exact target-moment identity",
        DiagnosticCategory::internal);
  }
  return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
      framework_identity_metric_header(
          header, metric.contract(), clause, execution_seal, "packets/slot",
          "stationary lossless throughput equals configured target arrival intensity",
          residual_refs,
          {"phase_free_finite_prefix_constant_tail_response"}),
      PortableScientificScalar::rational(found->value)});
}

[[nodiscard]] Result<std::size_t> retained_target_ordinal(
    const ExecutionPlan& plan, const QueueId& target);

[[nodiscard]] Result<ResultMetricV1> map_framework_scalar_identity_c18(
    const ExecutionPlan& plan, const ActivatedFrameworkV1& activated,
    const PlannedMetricV1& metric,
    const MetricSupportClauseV1& clause,
    const ExactStationaryBackendV1& stationary,
    const std::vector<std::string>& residual_refs,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  const MetricRequestHeader& header = metric_request_header(metric.request());
  if (header.kind != MetricKindV1::stationary_throughput ||
      !is_arrival_intensity_identity_requirement(metric) ||
      header.ordered_targets.size() != 1U) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_law_mismatch",
        "the C18 stationary proof was requested for a non-throughput or non-arrival-intensity scalar identity",
        DiagnosticCategory::internal);
  }
  if (!stationary.diagnostics.publication_allowed ||
      !stationary.diagnostics.arrival_phase_marginal_matches) {
    return fail<ResultMetricV1>(
        "c27.stationary_throughput_not_established",
        "the selected C18 invariant did not establish the configured arrival phase and publication diagnostics required by the stationary flow identity",
        DiagnosticCategory::unavailable);
  }
  auto ordinal = retained_target_ordinal(plan,
                                         header.ordered_targets.front().queue_id);
  if (!ordinal) return Result<ResultMetricV1>::failure(ordinal.error());
  if (ordinal.value() >=
          stationary.diagnostics.expected_target_departures.size() ||
      ordinal.value() >=
          stationary.diagnostics.expected_target_arrivals.size() ||
      ordinal.value() >= stationary.diagnostics.target_flow_differences.size() ||
      !stationary.diagnostics.expected_target_departures[ordinal.value()] ||
      !stationary.diagnostics.expected_target_arrivals[ordinal.value()] ||
      !stationary.diagnostics.target_flow_differences[ordinal.value()]) {
    return fail<ResultMetricV1>(
        "c27.stationary_throughput_flow_diagnostic_missing",
        "the selected C18 invariant lacks the target-specific admitted-flow diagnostics required for throughput publication");
  }
  const long double departure =
      *stationary.diagnostics.expected_target_departures[ordinal.value()];
  const long double admitted_arrival =
      *stationary.diagnostics.expected_target_arrivals[ordinal.value()];
  const long double flow_difference =
      *stationary.diagnostics.target_flow_differences[ordinal.value()];
  const long double reconstructed_flow_difference =
      admitted_arrival - departure;

  BigNat maximum_backlog{0U};
  for (const ReducedStateV1& state : stationary.matrix.states()) {
    auto decoded = activated.state_schema.decode(state);
    if (!decoded) {
      return Result<ResultMetricV1>::failure(decoded.error());
    }
    if (ordinal.value() >= decoded.value().backlog.size()) {
      return fail<ResultMetricV1>(
          "c27.stationary_throughput_state_target_missing",
          "a finite C18 state omits the retained target backlog needed to bound stationary flow drift");
    }
    maximum_backlog = std::max(
        maximum_backlog,
        decoded.value().backlog.value_at_target_ordinal(ordinal.value()));
  }
  const auto natural_upward_image = [](const BigNat& value) noexcept {
    if (value.is_zero()) return 0.0L;
    const std::size_t exponent = value.bit_length();
    if (exponent >= static_cast<std::size_t>(
                        std::numeric_limits<long double>::max_exponent)) {
      return std::numeric_limits<long double>::infinity();
    }
    // Every positive integer with this bit length is strictly below 2^b.
    // ldexp represents that power of two exactly, so this is an explicitly
    // upward (albeit intentionally conservative) image of the BigNat.
    return std::ldexp(1.0L, static_cast<int>(exponent));
  };
  const auto upward_product = [](const long double left,
                                 const long double right) noexcept {
    if (left == 0.0L || right == 0.0L) return 0.0L;
    const long double product = left * right;
    if (!std::isfinite(product)) {
      return std::numeric_limits<long double>::infinity();
    }
    return std::nextafter(
        product, std::numeric_limits<long double>::infinity());
  };
  const auto upward_sum = [](const long double left,
                             const long double right) noexcept {
    if (left == 0.0L && right == 0.0L) return 0.0L;
    const long double sum = left + right;
    if (!std::isfinite(sum)) {
      return std::numeric_limits<long double>::infinity();
    }
    return std::nextafter(
        sum, std::numeric_limits<long double>::infinity());
  };
  const auto upward_quotient = [](const long double numerator,
                                  const long double denominator) noexcept {
    if (numerator == 0.0L) return 0.0L;
    const long double quotient = numerator / denominator;
    if (!std::isfinite(quotient)) {
      return std::numeric_limits<long double>::infinity();
    }
    return std::nextafter(
        quotient, std::numeric_limits<long double>::infinity());
  };
  const auto upward_magnitude = [](const long double value) noexcept {
    const long double magnitude = std::fabs(value);
    if (magnitude == 0.0L || !std::isfinite(magnitude)) return magnitude;
    return std::nextafter(
        magnitude, std::numeric_limits<long double>::infinity());
  };
  const long double maximum_backlog_image =
      natural_upward_image(maximum_backlog);
  const long double invariant_l1_bound =
      stationary.law.solve_diagnostics().l1_invariance_bound;
  const long double invariant_l1_bound_upper =
      invariant_l1_bound > 0.0L && std::isfinite(invariant_l1_bound)
          ? std::nextafter(
                invariant_l1_bound,
                std::numeric_limits<long double>::infinity())
          : invariant_l1_bound;
  BigNat positive_marked_atoms{0U};
  for (const CompletionBoundMarkedRowV1& row :
       stationary.matrix.marked_flux().rows()) {
    for (const CompletionBoundMarkedAtomV1& atom : row.atoms) {
      if (atom.exact_mass.is_positive() && atom.edge.has_value()) {
        ++positive_marked_atoms;
      }
    }
  }
  const BigNat exact_operation_count =
      BigNat{6U} * positive_marked_atoms + BigNat{4U};
  const long double operation_count =
      natural_upward_image(exact_operation_count);
  const long double roundoff_product = upward_product(
      operation_count, std::numeric_limits<long double>::epsilon());
  const long double flow_scale =
      upward_sum(std::fabs(admitted_arrival), std::fabs(departure));
  long double rounding_allowance =
      std::numeric_limits<long double>::infinity();
  long double roundoff_denominator_lower = 0.0L;
  long double roundoff_amplification =
      std::numeric_limits<long double>::infinity();
  if (roundoff_product < 1.0L) {
    long double denominator = 1.0L - roundoff_product;
    if (denominator > 0.0L) {
      denominator = std::nextafter(denominator, 0.0L);
      roundoff_denominator_lower = denominator;
      roundoff_amplification =
          upward_quotient(roundoff_product, denominator);
      rounding_allowance =
          upward_product(roundoff_amplification, flow_scale);
    }
  }
  const long double invariant_drift_bound =
      upward_product(maximum_backlog_image, invariant_l1_bound_upper);
  const long double flow_residual_bound =
      upward_sum(invariant_drift_bound, rounding_allowance);
  const long double reconstruction_discrepancy =
      upward_magnitude(flow_difference - reconstructed_flow_difference);
  const long double flow_difference_magnitude =
      upward_magnitude(flow_difference);
  const std::string flow_diagnostic_id =
      "c27.c18.target_flow." + header.metric_id;
  diagnostics.push_back(ResultDiagnosticV1{
      flow_diagnostic_id, DiagnosticCategory::information,
      "c27.c18.target_flow_residual",
      "C18 target-specific stationary admitted-flow residual bound",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::stationary_residual, std::nullopt,
      std::nullopt,
      {"target_ordinal=" + std::to_string(ordinal.value()),
       "expected_target_departures=" + floating_text(departure),
       "expected_target_arrivals=" + floating_text(admitted_arrival),
       "target_flow_difference=" + floating_text(flow_difference),
       "reconstructed_target_flow_difference=" +
           floating_text(reconstructed_flow_difference),
       "maximum_retained_target_backlog=" +
           maximum_backlog.to_decimal_string(),
       "maximum_backlog_upward_image=" +
           floating_text(maximum_backlog_image),
       "positive_marked_atoms=" +
           positive_marked_atoms.to_decimal_string(),
       "exact_roundoff_operation_count=" +
           exact_operation_count.to_decimal_string(),
       "operation_count_upward_image=" + floating_text(operation_count),
       "roundoff_product_upward=" + floating_text(roundoff_product),
       "roundoff_denominator_lower=" +
           floating_text(roundoff_denominator_lower),
       "roundoff_amplification_upward=" +
           floating_text(roundoff_amplification),
       "flow_scale_upward=" + floating_text(flow_scale),
       "invariant_l1_bound=" + floating_text(invariant_l1_bound),
       "invariant_l1_bound_upward=" +
           floating_text(invariant_l1_bound_upper),
       "invariant_drift_bound_upward=" +
           floating_text(invariant_drift_bound),
       "rounding_allowance=" + floating_text(rounding_allowance),
       "reconstruction_discrepancy_upward=" +
           floating_text(reconstruction_discrepancy),
       "target_flow_difference_magnitude_upward=" +
           floating_text(flow_difference_magnitude),
       "flow_residual_bound=" + floating_text(flow_residual_bound)},
      {}});
  if (!std::isfinite(departure) || !std::isfinite(admitted_arrival) ||
      !std::isfinite(flow_difference) ||
      !std::isfinite(reconstructed_flow_difference) ||
      !std::isfinite(maximum_backlog_image) ||
      !std::isfinite(invariant_l1_bound) || invariant_l1_bound < 0.0L ||
      !std::isfinite(rounding_allowance) ||
      !std::isfinite(flow_residual_bound) ||
      !std::isfinite(reconstruction_discrepancy) ||
      !std::isfinite(flow_difference_magnitude) ||
      reconstruction_discrepancy > rounding_allowance ||
      flow_difference_magnitude > flow_residual_bound) {
    return fail<ResultMetricV1>(
        "c27.stationary_throughput_flow_residual_not_established",
        "the numerical target flow difference is nonfinite or exceeds the finite-domain invariant-residual and explicit rounding bound");
  }
  const BuilderArrivalView arrival =
      builder_arrival_view(plan.compiled_arrival_law());
  if (!(arrival.digest() == plan.problem_view().configured_arrival().digest()) ||
      !arrival.moments()) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_moment_unavailable",
        "the configured arrival view does not carry the exact first target moment accepted by the C18 route",
        DiagnosticCategory::internal);
  }
  const DenseQueueIndex target = header.ordered_targets.front().dense_index;
  const auto matches = [&](const ExactMomentDatum& datum) {
    return datum.order == BigNat{1U} && datum.coordinates.size() == 1U &&
           datum.coordinates.front() == target;
  };
  const auto& moments = *arrival.moments();
  if (std::ranges::count_if(moments, matches) != 1) {
    return fail<ResultMetricV1>(
        "c27.framework_scalar_target_moment_missing",
        "the exact configured-arrival moment table must contain one target first moment",
        DiagnosticCategory::internal);
  }
  const auto found = std::ranges::find_if(moments, matches);
  std::vector<std::string> throughput_residual_refs = residual_refs;
  throughput_residual_refs.push_back(flow_diagnostic_id);
  const bool raw_exact_closed =
      stationary.matrix.marked_flux().completion_kind() ==
      BoundaryCompletionKindV1::exact_closed;
  return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
      framework_identity_metric_header(
          header, metric.contract(), clause,
          stationary.matrix.matrix_identity(), "packets/slot",
          "stationary lossless throughput equals configured target arrival intensity after C18 invariant and flow diagnostics",
          std::move(throughput_residual_refs),
          {raw_exact_closed
               ? "exact_closed_finite_domain"
               : "mark_preserving_stationary_clock_quotient_finite_domain"}),
      PortableScientificScalar::rational(found->value)});
}

[[nodiscard]] Result<ResultMetricV1> map_three_bin_metric(
    const PlannedMetricV1& metric, const MetricSupportClauseV1& clause,
    const ThreeBinIidSummary& summary,
    const std::vector<std::string>& residual_refs) {
  const MetricRequest& request = metric.request();
  const MetricRequestHeader& header = metric_request_header(request);
  const auto scalar = [](const ExactRational& value) -> ResultMetricValueV1 {
    return PortableScientificScalar::rational(value);
  };
  switch (header.kind) {
    case MetricKindV1::stationary_throughput:
      if (!summary.pi_zero() || !summary.pi_one() || !summary.pi_two() ||
          !summary.tail_mass_from_three()) {
        break;
      }
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          metric_header(header, metric.contract(), clause,
                        summary.law_identity(), "packets/slot",
                        "stationary admitted departure rate",
                        residual_refs),
          scalar(summary.arrival_mean())});
    case MetricKindV1::stationary_empty_probability:
      if (summary.pi_zero()) {
        return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
            metric_header(header, metric.contract(), clause,
                          summary.law_identity(), "probability",
                          "Pr{N=0} at the predecision boundary",
                          residual_refs),
            scalar(*summary.pi_zero())});
      }
      break;
    case MetricKindV1::mean_sojourn:
      if (summary.exact_mean_sojourn()) {
        return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
            metric_header(header, metric.contract(), clause,
                          summary.law_identity(), "slots",
                          "Little-law mean including the departure slot",
                          residual_refs),
            scalar(*summary.exact_mean_sojourn())});
      }
      break;
    case MetricKindV1::stationary_backlog_moment: {
      const auto* typed =
          std::get_if<StationaryBacklogMomentRequestV1>(&request);
      if (typed != nullptr && typed->parameters().order == BigNat{1U}) {
        if (summary.exact_mean_backlog()) {
          return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
              metric_header(header, metric.contract(), clause,
                            summary.law_identity(), "packets",
                            "first stationary backlog moment",
                            residual_refs),
              scalar(*summary.exact_mean_backlog())});
        }
        if (summary.status() == AnalyticStationaryStatusV1::infinite) {
          return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
              metric_header(header, metric.contract(), clause,
                            summary.law_identity(), "packets",
                            "first stationary backlog moment",
                            residual_refs),
              PositiveInfinityV1{}});
        }
      }
      break;
    }
    case MetricKindV1::stationary_backlog_tail: {
      const auto* typed =
          std::get_if<StationaryBacklogTailRequestV1>(&request);
      if (typed == nullptr || !summary.pi_zero() || !summary.pi_one() ||
          !summary.pi_two() || !summary.tail_mass_from_three()) {
        break;
      }
      const BigNat& threshold = typed->parameters().threshold;
      ExactRational tail = ExactRational::one();
      if (threshold == BigNat{1U}) {
        tail = *summary.pi_one() + *summary.pi_two() +
               *summary.tail_mass_from_three();
      } else if (threshold == BigNat{2U}) {
        tail = *summary.pi_two() + *summary.tail_mass_from_three();
      } else if (threshold == BigNat{3U}) {
        tail = *summary.tail_mass_from_three();
      } else if (!threshold.is_zero()) {
        break;
      }
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          metric_header(header, metric.contract(), clause,
                        summary.law_identity(), "probability",
                        "Pr{N >= threshold} at the predecision boundary",
                        residual_refs),
          scalar(tail)});
    }
    case MetricKindV1::stationary_backlog_pmf: {
      const auto* typed =
          std::get_if<StationaryBacklogPmfRequestV1>(&request);
      if (typed == nullptr || !summary.pi_zero() || !summary.pi_one() ||
          !summary.pi_two() || !summary.tail_mass_from_three()) {
        break;
      }
      const auto* through =
          std::get_if<PmfThroughLevelV1>(&typed->parameters().domain);
      if (through == nullptr) break;
      std::size_t maximum_level = 0U;
      if (through->max_level == BigNat{1U}) {
        maximum_level = 1U;
      } else if (through->max_level == BigNat{2U}) {
        maximum_level = 2U;
      } else if (!through->max_level.is_zero()) {
        break;
      }
      const std::array<ExactRational, 4U> partition{
          *summary.pi_zero(), *summary.pi_one(), *summary.pi_two(),
          *summary.tail_mass_from_three()};
      ResultProbabilityLawV1 law{
          {"predecision_backlog_partition"}, {},
          PortableScientificScalar::rational(ExactRational::zero()), true};
      law.atoms.reserve(maximum_level + 2U);
      for (std::size_t level = 0U; level <= maximum_level; ++level) {
        law.atoms.push_back(ResultProbabilityAtomV1{
            {TypedLabel::numeric(BigNat{static_cast<std::uint64_t>(level)})},
            PortableScientificScalar::rational(partition[level])});
      }
      ExactRational aggregate_tail = ExactRational::zero();
      for (std::size_t level = maximum_level + 1U;
           level < partition.size(); ++level) {
        aggregate_tail = aggregate_tail + partition[level];
      }
      auto aggregate_label = TypedLabel::text(
          "N>=" + std::to_string(maximum_level + 1U));
      if (!aggregate_label) {
        return Result<ResultMetricV1>::failure(aggregate_label.error());
      }
      law.atoms.push_back(ResultProbabilityAtomV1{
          {std::move(aggregate_label).value()},
          PortableScientificScalar::rational(aggregate_tail)});
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          metric_header(
              header, metric.contract(), clause, summary.law_identity(),
              "probability",
              "complete coarsened stationary backlog partition through the requested level with one explicit aggregate tail atom",
              residual_refs,
              {"aggregate_tail_atom_is_not_an_individual_backlog_level"}),
          std::move(law)});
    }
    case MetricKindV1::backlog_conditioned_service: {
      const auto* typed =
          std::get_if<BacklogConditionedServiceRequestV1>(&request);
      if (typed == nullptr) break;
      ResultScalarVectorV1 values;
      values.values.reserve(typed->parameters().levels.size());
      const auto bins = summary.bins();
      bool used_off_support = false;
      const bool permits_off_support =
          declared_off_support_convention(clause);
      for (const BigNat& level : typed->parameters().levels) {
        std::size_t bin = 3U;
        if (level.is_zero()) bin = 0U;
        else if (level == BigNat{1U}) bin = 1U;
        else if (level == BigNat{2U}) bin = 2U;
        const StationaryConditioningMassKindV1 mass =
            bins[bin].conditioning_mass.kind();
        if (mass != StationaryConditioningMassKindV1::established_positive &&
            !permits_off_support) {
          return fail<ResultMetricV1>(
              "c27.conditioning_mass_not_positive",
              "the deployed stationary law does not establish positive mass for every requested backlog-conditioned service level",
              DiagnosticCategory::unavailable);
        }
        used_off_support = used_off_support ||
                           mass != StationaryConditioningMassKindV1::
                                       established_positive;
        values.values.push_back(
            PortableScientificScalar::rational(bins[bin].response));
      }
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          metric_header(
              header, metric.contract(), clause, summary.law_identity(),
              "probability",
                        "service probability conditional on deployed stationary backlog",
              residual_refs,
              used_off_support
                  ? std::vector<std::string>{
                        "declared_off_support_conditioning_convention"}
                  : std::vector<std::string>{}),
          std::move(values)});
    }
    default:
      break;
  }
  return fail<ResultMetricV1>(
      "c27.three_bin_metric_not_established",
      "the C19 ThreeBin summary does not establish the exact requested metric and parameter domain",
      DiagnosticCategory::unavailable);
}

[[nodiscard]] Result<ResultMetricV1> map_finite_prefix_metric(
    const PlannedMetricV1& metric, const MetricSupportClauseV1& clause,
    const FinitePrefixIidSummary& summary,
    const std::vector<std::string>& residual_refs) {
  const MetricRequest& request = metric.request();
  const MetricRequestHeader& header = metric_request_header(request);
  const auto scalar = [](const ExactRational& value) -> ResultMetricValueV1 {
    return PortableScientificScalar::rational(value);
  };
  const auto& prefix = summary.prefix_masses();
  const std::span<const ExactRational> service = summary.service_by_level();
  const bool normalized = finite_prefix_normalized_law_established(summary);
  switch (header.kind) {
    case MetricKindV1::stationary_throughput:
      if (!normalized) break;
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          finite_prefix_metric_header(
              header, metric.contract(), clause, summary.law_identity(),
              "packets/slot", "stationary admitted departure rate",
              residual_refs),
          scalar(summary.arrival_mean())});
    case MetricKindV1::stationary_empty_probability:
      if (normalized && !prefix->empty()) {
        return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
            finite_prefix_metric_header(
                header, metric.contract(), clause, summary.law_identity(),
                "probability", "Pr{N=0} at the predecision boundary",
                residual_refs),
            scalar(prefix->front())});
      }
      break;
    case MetricKindV1::mean_sojourn:
      if (summary.exact_mean_sojourn()) {
        return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
            finite_prefix_metric_header(
                header, metric.contract(), clause, summary.law_identity(),
                "slots", "Little-law mean including the departure slot",
                residual_refs),
            scalar(*summary.exact_mean_sojourn())});
      }
      break;
    case MetricKindV1::stationary_backlog_moment: {
      const auto* typed =
          std::get_if<StationaryBacklogMomentRequestV1>(&request);
      if (typed != nullptr && typed->parameters().order == BigNat{1U}) {
        if (summary.exact_mean_backlog()) {
          return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
              finite_prefix_metric_header(
                  header, metric.contract(), clause, summary.law_identity(),
                  "packets", "first stationary backlog moment",
                  residual_refs),
              scalar(*summary.exact_mean_backlog())});
        }
        if (summary.status() == AnalyticStationaryStatusV1::infinite) {
          return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
              finite_prefix_metric_header(
                  header, metric.contract(), clause, summary.law_identity(),
                  "packets", "first stationary backlog moment",
                  residual_refs),
              PositiveInfinityV1{}});
        }
      }
      break;
    }
    case MetricKindV1::stationary_backlog_tail: {
      const auto* typed =
          std::get_if<StationaryBacklogTailRequestV1>(&request);
      if (typed == nullptr || typed->parameters().threshold != BigNat{3U} ||
          !normalized || prefix->size() < 3U) {
        break;
      }
      // The summary tail atom starts at K+1.  Levels 3..K remain native
      // prefix probability masses; the response's tail coefficient is not a
      // probability and never enters this aggregation.
      ExactRational tail = *summary.aggregate_tail_mass();
      for (std::size_t level = 3U; level < prefix->size(); ++level) {
        tail = tail + (*prefix)[level];
      }
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          finite_prefix_metric_header(
              header, metric.contract(), clause, summary.law_identity(),
              "probability",
              "Pr{N >= threshold} at the predecision boundary",
              residual_refs),
          scalar(tail)});
    }
    case MetricKindV1::stationary_backlog_pmf: {
      const auto* typed =
          std::get_if<StationaryBacklogPmfRequestV1>(&request);
      if (typed == nullptr || !normalized || prefix->size() < 3U) {
        break;
      }
      const auto* through =
          std::get_if<PmfThroughLevelV1>(&typed->parameters().domain);
      if (through == nullptr) break;
      std::size_t maximum_level = 0U;
      if (through->max_level == BigNat{1U}) {
        maximum_level = 1U;
      } else if (through->max_level == BigNat{2U}) {
        maximum_level = 2U;
      } else if (!through->max_level.is_zero()) {
        break;
      }
      ResultProbabilityLawV1 law{
          {"predecision_backlog_partition"}, {},
          PortableScientificScalar::rational(ExactRational::zero()), true};
      law.atoms.reserve(maximum_level + 2U);
      for (std::size_t level = 0U; level <= maximum_level; ++level) {
        law.atoms.push_back(ResultProbabilityAtomV1{
            {TypedLabel::numeric(BigNat{static_cast<std::uint64_t>(level)})},
            PortableScientificScalar::rational((*prefix)[level])});
      }
      ExactRational aggregate_tail = *summary.aggregate_tail_mass();
      for (std::size_t level = maximum_level + 1U;
           level < prefix->size(); ++level) {
        aggregate_tail = aggregate_tail + (*prefix)[level];
      }
      auto aggregate_label = TypedLabel::text(
          "N>=" + std::to_string(maximum_level + 1U));
      if (!aggregate_label) {
        return Result<ResultMetricV1>::failure(aggregate_label.error());
      }
      law.atoms.push_back(ResultProbabilityAtomV1{
          {std::move(aggregate_label).value()},
          PortableScientificScalar::rational(aggregate_tail)});
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          finite_prefix_metric_header(
              header, metric.contract(), clause, summary.law_identity(),
              "probability",
              "complete coarsened stationary backlog partition through the requested level with one explicit aggregate tail atom",
              residual_refs,
              {"aggregate_tail_atom_is_not_an_individual_backlog_level"}),
          std::move(law)});
    }
    case MetricKindV1::backlog_conditioned_service: {
      const auto* typed =
          std::get_if<BacklogConditionedServiceRequestV1>(&request);
      if (typed == nullptr || service.size() < 3U || !normalized) break;
      ResultScalarVectorV1 values;
      values.values.reserve(typed->parameters().levels.size());
      bool used_off_support = false;
      const bool permits_off_support =
          declared_off_support_convention(clause);
      for (const BigNat& level : typed->parameters().levels) {
        std::size_t index = 0U;
        if (level == BigNat{1U}) {
          index = 1U;
        } else if (level == BigNat{2U}) {
          index = 2U;
        } else if (!level.is_zero()) {
          return fail<ResultMetricV1>(
              "c27.k_bin_metric_not_established",
              "the C19 finite-prefix summary accepts backlog-conditioned service only on the provider's levels {0,1,2}",
              DiagnosticCategory::unavailable);
        }
        const bool positive_mass =
            prefix.has_value() && index < prefix->size() &&
            (*prefix)[index].is_positive();
        if (!positive_mass && !permits_off_support) {
          return fail<ResultMetricV1>(
              "c27.conditioning_mass_not_positive",
              "the deployed stationary law does not establish positive mass for every requested backlog-conditioned service level",
              DiagnosticCategory::unavailable);
        }
        used_off_support = used_off_support || !positive_mass;
        values.values.push_back(
            PortableScientificScalar::rational(service[index]));
      }
      return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
          finite_prefix_metric_header(
              header, metric.contract(), clause, summary.law_identity(),
              "probability",
              "service probability conditional on deployed stationary backlog",
              residual_refs,
              used_off_support
                  ? std::vector<std::string>{
                        "declared_off_support_conditioning_convention"}
                  : std::vector<std::string>{}),
          std::move(values)});
    }
    default:
      break;
  }
  return fail<ResultMetricV1>(
      "c27.k_bin_metric_not_established",
      "the C19 finite-prefix summary does not establish the exact requested metric and parameter domain",
      DiagnosticCategory::unavailable);
}

[[nodiscard]] Result<ResultMetricV1> map_canonical_backend_metric(
    const PlannedMetricV1& metric, const MetricSupportClauseV1& clause,
    const Digest256& law_identity, CanonicalRuntimeValueV1 value,
    std::string convention,
    std::vector<std::string> residual_refs = {},
    std::vector<std::string> error_refs = {},
    std::vector<std::string> additional_assumptions = {}) {
  return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
      backend_metric_header(metric, clause, law_identity,
                            std::move(convention),
                            std::move(residual_refs), std::move(error_refs),
                            std::move(additional_assumptions)),
      canonical_result_value(value)});
}

[[nodiscard]] Result<LagSpec> temporal_lag_spec(
    const MetricRequest& request) {
  switch (metric_request_kind(request)) {
    case MetricKindV1::service_persistence:
      return Result<LagSpec>::success(
          LagSpec{TemporalStatisticKindV1::service_persistence, {},
                  std::nullopt, std::nullopt, {}});
    case MetricKindV1::service_autocovariance: {
      const auto& parameters =
          std::get<ServiceAutocovarianceRequestV1>(request).parameters();
      return Result<LagSpec>::success(
          LagSpec{TemporalStatisticKindV1::autocovariance, parameters.lags,
                  std::nullopt, std::nullopt, {}});
    }
    case MetricKindV1::service_window_count: {
      const auto& parameters =
          std::get<ServiceWindowCountRequestV1>(request).parameters();
      return Result<LagSpec>::success(
          LagSpec{TemporalStatisticKindV1::service_window_count, {},
                  parameters.width, std::nullopt, {}});
    }
    case MetricKindV1::service_spectrum: {
      const auto& parameters =
          std::get<ServiceSpectrumRequestV1>(request).parameters();
      return Result<LagSpec>::success(
          LagSpec{TemporalStatisticKindV1::service_spectrum, {},
                  std::nullopt, parameters.truncation_lag,
                  parameters.frequencies});
    }
    case MetricKindV1::mean_event_gap:
      return Result<LagSpec>::success(
          LagSpec{TemporalStatisticKindV1::mean_event_gap, {}, std::nullopt,
                  std::nullopt, {}});
    case MetricKindV1::mean_binary_run:
      return Result<LagSpec>::success(
          LagSpec{TemporalStatisticKindV1::mean_binary_run, {}, std::nullopt,
                  std::nullopt, {}});
    default:
      return fail<LagSpec>(
          "c27.stationary_temporal_metric_not_adapted",
          "the accepted temporal route has no mathematically equivalent C22 statistic adapter");
  }
}

[[nodiscard]] Result<BinaryMark> temporal_binary_mark(
    const MetricRequest& request, const std::size_t target_ordinal) {
  switch (metric_request_kind(request)) {
    case MetricKindV1::service_persistence:
    case MetricKindV1::service_autocovariance:
    case MetricKindV1::service_window_count:
    case MetricKindV1::service_spectrum:
      return Result<BinaryMark>::success(BinaryMark{
          BinaryMarkKindV1::target_departure, target_ordinal, std::nullopt});
    case MetricKindV1::mean_event_gap: {
      const auto event =
          std::get<MeanEventGapRequestV1>(request).parameters().event;
      BinaryMarkKindV1 kind = BinaryMarkKindV1::target_departure;
      if (event == GapEventKind::admission) {
        kind = BinaryMarkKindV1::positive_target_arrival;
      } else if (event == GapEventKind::busy_denial) {
        kind = BinaryMarkKindV1::busy_denial;
      }
      return Result<BinaryMark>::success(
          BinaryMark{kind, target_ordinal, std::nullopt});
    }
    case MetricKindV1::mean_binary_run: {
      const BinaryPredicateV1& predicate =
          std::get<MeanBinaryRunRequestV1>(request).parameters().predicate;
      if (const auto* basic =
              std::get_if<BasicBinaryPredicateV1>(&predicate);
          basic != nullptr &&
          *basic == BasicBinaryPredicateV1::busy_denial) {
        return Result<BinaryMark>::success(
            BinaryMark{BinaryMarkKindV1::busy_denial, target_ordinal,
                       std::nullopt});
      }
      return Result<BinaryMark>::success(BinaryMark{
          BinaryMarkKindV1::state_predicate, target_ordinal,
          TemporalStatePredicateV1{
              BinaryStatePredicateV1{target_ordinal, predicate}}});
    }
    default:
      return fail<BinaryMark>(
          "c27.stationary_temporal_mark_not_adapted",
          "the accepted temporal metric has no exact C22 binary-mark adapter");
  }
}

[[nodiscard]] Result<ResultMetricV1> execute_stationary_temporal_metric(
    const ExecutionPlan& plan, const PlannedMetricV1& metric,
    const MetricSupportClauseV1& clause,
    const StationaryTemporalBackendV1& backend,
    const std::vector<std::string>& residual_refs,
    const std::vector<std::string>& error_refs) {
  const MetricKindV1 kind = metric_request_kind(metric.request());
  if (kind == MetricKindV1::stationary_empty_probability ||
      kind == MetricKindV1::stationary_backlog_pmf ||
      kind == MetricKindV1::stationary_backlog_pgf ||
      kind == MetricKindV1::stationary_backlog_moment ||
      kind == MetricKindV1::stationary_backlog_quantile ||
      kind == MetricKindV1::stationary_backlog_tail ||
      kind == MetricKindV1::stationary_edge_reward) {
    auto value = evaluate_stationary_temporal_metric(
        backend.projection.temporal_law(), metric.request());
    if (!value) return Result<ResultMetricV1>::failure(value.error());
    return map_canonical_backend_metric(
        metric, clause, backend.projection.fingerprint(),
        std::move(value).value(),
        "C21 exact stationary event-to-slot suspension", residual_refs,
        error_refs,
        {"finite_exact_residence_word_law",
         "positive_finite_mean_residence"});
  }

  const MetricRequestHeader& header = metric_request_header(metric.request());
  if (header.ordered_targets.size() != 1U) {
    return fail<ResultMetricV1>(
        "c27.temporal_scalar_target_required",
        "the installed C22 statistic adapter requires one retained target");
  }
  auto target = retained_target_ordinal(
      plan, header.ordered_targets.front().queue_id);
  if (!target) return Result<ResultMetricV1>::failure(target.error());
  auto mark = temporal_binary_mark(metric.request(), target.value());
  if (!mark) return Result<ResultMetricV1>::failure(mark.error());
  auto lags = temporal_lag_spec(metric.request());
  if (!lags) return Result<ResultMetricV1>::failure(lags.error());
  auto value = [&]() -> Result<MetricValue> {
    if (metric.route_kind() ==
        BackendRouteKindV1::finite_temporal_cylinder) {
      const auto* cylinder = std::get_if<AuditedCylinderLaw>(
          &backend.projection.cylinder_law());
      if (cylinder == nullptr) {
        const auto* reason = std::get_if<StationaryProjectionUnavailableV1>(
            &backend.projection.cylinder_law());
        return fail<MetricValue>(
            reason == nullptr ? "c27.cylinder_projection_unavailable"
                              : reason->code,
            reason == nullptr
                ? "the stationary projection did not expose the accepted "
                  "finite-cylinder law"
                : reason->message,
            DiagnosticCategory::unavailable);
      }
      return detail::evaluate_finite_cylinder_statistic(
          *cylinder, mark.value(), lags.value());
    }

    const auto* temporal_law = std::get_if<AuditedTemporalLaw>(
        &backend.projection.audited_temporal_law());
    if (temporal_law == nullptr) {
      const auto* reason = std::get_if<StationaryProjectionUnavailableV1>(
          &backend.projection.audited_temporal_law());
      return fail<MetricValue>(
          reason == nullptr ? "c27.temporal_projection_unavailable"
                            : reason->code,
          reason == nullptr
              ? "the stationary projection did not expose a C22 temporal law"
              : reason->message,
          DiagnosticCategory::unavailable);
    }
    return evaluate_runs_gaps_autocorrelation(
        *temporal_law, mark.value(), lags.value());
  }();
  if (!value) return Result<ResultMetricV1>::failure(value.error());
  return map_canonical_backend_metric(
      metric, clause, backend.projection.fingerprint(),
      std::move(value).value(),
      "C22 exact stationary temporal statistic", residual_refs, error_refs,
      {"stationary_slot_projection", "exact_finite_temporal_source"});
}

[[nodiscard]] Result<std::size_t> retained_target_ordinal(
    const ExecutionPlan& plan, const QueueId& target) {
  const auto retained =
      plan.problem_view().target_selection().ordered_targets;
  const auto found = std::find(retained.begin(), retained.end(), target);
  if (found == retained.end()) {
    return fail<std::size_t>(
        "c27.metric_target_not_retained",
        "the accepted metric target is absent from the exact reduced-state target order",
        DiagnosticCategory::internal);
  }
  return Result<std::size_t>::success(
      static_cast<std::size_t>(std::distance(retained.begin(), found)));
}

[[nodiscard]] Result<long double> finite_natural_power(
    const BigNat& base, const BigNat& exponent) {
  if (exponent.bit_length() > 63U) {
    if (base.is_zero()) return Result<long double>::success(0.0L);
    if (base == BigNat{1U}) return Result<long double>::success(1.0L);
    return fail<long double>(
        "c27.reward_power_not_representable",
        "the requested natural reward power exceeds the finite numerical image supported by C18");
  }
  const auto power = exponent.value().convert_to<std::uint64_t>();
  long double value = 1.0L;
  long double factor = base.value().convert_to<long double>();
  std::uint64_t remaining = power;
  while (remaining != 0U) {
    if ((remaining & 1U) != 0U) value *= factor;
    remaining >>= 1U;
    if (remaining != 0U) factor *= factor;
    if (!std::isfinite(value) || !std::isfinite(factor)) {
      return fail<long double>(
          "c27.reward_power_overflow",
          "the requested exact backlog reward has no finite long-double image for the selected C18 solver");
    }
  }
  return Result<long double>::success(value);
}

[[nodiscard]] Result<RewardDecoder> c18_reward_decoder(
    const ExecutionPlan& plan, const ActivatedFrameworkV1& activated,
    const PlannedMetricV1& metric) {
  const MetricRequest& request = metric.request();
  const MetricRequestHeader& header = metric_request_header(request);
  if (header.ordered_targets.empty()) {
    return fail<RewardDecoder>(
        "c27.stationary_reward_target_missing",
        "the exact stationary reward requires at least one retained target",
        DiagnosticCategory::internal);
  }
  std::vector<std::size_t> ordinals;
  ordinals.reserve(header.ordered_targets.size());
  for (const auto& target : header.ordered_targets) {
    auto ordinal = retained_target_ordinal(plan, target.queue_id);
    if (!ordinal) return Result<RewardDecoder>::failure(ordinal.error());
    ordinals.push_back(ordinal.value());
  }
  const MetricKindV1 kind = metric_request_kind(request);
  StationaryRewardDomainV1 domain = StationaryRewardDomainV1::state;
  if (kind == MetricKindV1::stationary_edge_reward) {
    domain = StationaryRewardDomainV1::one_edge;
  }
  auto decode = [schema = activated.state_schema, request, ordinals,
                 kind](const StationaryRewardArgumentV1& argument)
      -> Result<long double> {
    auto coordinates = schema.decode(argument.state);
    if (!coordinates) return Result<long double>::failure(coordinates.error());
    const auto backlog = [&](const std::size_t ordinal) -> const BigNat& {
      return coordinates.value().backlog.value_at_target_ordinal(ordinal);
    };
    if (kind == MetricKindV1::stationary_empty_probability) {
      return Result<long double>::success(
          backlog(ordinals.front()).is_zero() ? 1.0L : 0.0L);
    }
    if (kind == MetricKindV1::stationary_backlog_moment) {
      const BigNat& order =
          std::get<StationaryBacklogMomentRequestV1>(request)
              .parameters()
              .order;
      return finite_natural_power(backlog(ordinals.front()), order);
    }
    if (kind == MetricKindV1::stationary_backlog_tail) {
      const BigNat& threshold =
          std::get<StationaryBacklogTailRequestV1>(request)
              .parameters()
              .threshold;
      return Result<long double>::success(
          backlog(ordinals.front()) >= threshold ? 1.0L : 0.0L);
    }
    if (kind == MetricKindV1::joint_backlog_event) {
      const auto& parameters =
          std::get<JointBacklogEventRequestV1>(request).parameters();
      if (parameters.thresholds.size() != ordinals.size()) {
        return fail<long double>(
            "c27.joint_backlog_threshold_cardinality",
            "the joint backlog event threshold vector does not match the retained target vector",
            DiagnosticCategory::internal);
      }
      bool event =
          parameters.relation == JointBacklogRelation::all_at_or_above;
      for (std::size_t index = 0U; index < ordinals.size(); ++index) {
        const bool hit = backlog(ordinals[index]) >=
                         parameters.thresholds[index];
        if (parameters.relation ==
            JointBacklogRelation::all_at_or_above) {
          event = event && hit;
        } else {
          event = event || hit;
        }
      }
      return Result<long double>::success(event ? 1.0L : 0.0L);
    }
    if (kind == MetricKindV1::stationary_edge_reward) {
      if (argument.edge == nullptr) {
        return fail<long double>(
            "c27.stationary_edge_argument_missing",
            "the C18 edge reward decoder received a state-only argument");
      }
      const auto& parameters =
          std::get<StationaryEdgeRewardRequestV1>(request).parameters();
      const std::size_t target = ordinals.front();
      if (target >= argument.edge->target_arrivals.size() ||
          target >= argument.edge->target_departures.size()) {
        return fail<long double>(
            "c27.stationary_edge_target_not_retained",
            "the completion-bound edge omits the requested target coordinate");
      }
      BigInt signed_base{0};
      if (parameters.reward == EdgeRewardKind::arrival) {
        signed_base = argument.edge->target_arrivals[target].value();
      } else if (parameters.reward == EdgeRewardKind::departure) {
        signed_base = argument.edge->target_departures[target];
      } else {
        signed_base = argument.edge->target_arrivals[target].value() -
                      argument.edge->target_departures[target];
      }
      if (parameters.moment_order.bit_length() > 63U) {
        return fail<long double>(
            "c27.edge_reward_power_not_representable",
            "the requested edge-reward moment order exceeds the finite C18 numerical image");
      }
      const auto order =
          parameters.moment_order.value().convert_to<std::uint64_t>();
      BigInt powered{1};
      BigInt factor = signed_base;
      std::uint64_t remaining = order;
      while (remaining != 0U) {
        if ((remaining & 1U) != 0U) powered *= factor;
        remaining >>= 1U;
        if (remaining != 0U) factor *= factor;
      }
      const long double value = powered.convert_to<long double>();
      if (!std::isfinite(value)) {
        return fail<long double>(
            "c27.edge_reward_power_overflow",
            "the requested edge reward has no finite long-double image");
      }
      return Result<long double>::success(value);
    }
    return fail<long double>(
        "c27.c18_metric_not_adapted",
        "the finite stationary matrix was established but the requested metric has no exact C18 reward adapter");
  };
  return Result<RewardDecoder>::success(RewardDecoder{
      domain, StationaryRewardIntegrabilityV1::finite_absolute, false, {},
      std::move(decode), CodecIdentityV1{"mwperf.c27.c18.scalar", 1U}, {}});
}

[[nodiscard]] Result<ResultMetricV1> execute_c18_stationary_metric(
    const ExecutionPlan& plan, const ActivatedFrameworkV1& activated,
    const PlannedMetricV1& metric, const MetricSupportClauseV1& clause,
    const ExactStationaryBackendV1& backend,
    const std::vector<std::string>& residual_refs) {
  auto decoder = c18_reward_decoder(plan, activated, metric);
  if (!decoder) return Result<ResultMetricV1>::failure(decoder.error());
  auto value = evaluate_stationary_edge_reward(backend.law, decoder.value());
  if (!value) return Result<ResultMetricV1>::failure(value.error());
  const bool raw_exact_closed =
      backend.matrix.marked_flux().completion_kind() ==
      BoundaryCompletionKindV1::exact_closed;
  return map_canonical_backend_metric(
      metric, clause, backend.matrix.matrix_identity(),
      std::move(value).value(),
      "C18 selected finite invariant-law reward", residual_refs,
      {},
      {raw_exact_closed
           ? "exact_closed_finite_domain"
           : "mark_preserving_stationary_clock_quotient_finite_domain",
       "selected_invariant_class",
       "numerical_image_with_reported_residuals"});
}

[[nodiscard]] Result<Digest256> sample_identity_digest(
    const Sample& sample) {
  std::vector<std::byte> bytes;
  const auto append_value = [&](const CanonicalRuntimeValueV1& value) {
    const auto id_bytes = std::as_bytes(
        std::span(value.codec.id.data(), value.codec.id.size()));
    append_u64(bytes, static_cast<std::uint64_t>(id_bytes.size()));
    append_bytes(bytes, id_bytes);
    append_u64(bytes, value.codec.version);
    append_u64(bytes,
               static_cast<std::uint64_t>(value.canonical_value.size()));
    append_bytes(bytes, value.canonical_value);
  };
  append_value(sample.successor_state);
  append_u64(bytes,
             static_cast<std::uint64_t>(sample.ordered_marks.size()));
  for (const auto& mark : sample.ordered_marks) append_value(mark);
  return sha256_domain_separated("mwperf.c27.c24.sample.v1", bytes);
}

[[nodiscard]] Result<Digest256> c24_row_law_identity(
    const SamplingPlan& plan, const EmpiricalRow& row) {
  std::vector<std::byte> canonical;
  append_bytes(canonical, plan.plan_digest().bytes());
  append_bytes(canonical, row.seal_digest().bytes());
  append_bytes(canonical, row.conditioning_row_digest().bytes());
  append_bytes(canonical, row.metric_target_digest().bytes());
  append_u64(canonical, static_cast<std::uint64_t>(plan.stage()));
  append_u64(canonical,
             static_cast<std::uint64_t>(plan.accepted_backend_route()));
  return sha256_domain_separated("mwperf.c27.c24.row-law.v1", canonical);
}

[[nodiscard]] Result<Digest256> c24_estimate_law_identity(
    const SamplingPlan& plan, const Estimate& estimate,
    const Digest256& decoder_digest) {
  std::vector<std::byte> canonical;
  append_bytes(canonical, plan.plan_digest().bytes());
  append_bytes(canonical, estimate.seal_digest().bytes());
  append_bytes(canonical, estimate.conditioning_row_digest().bytes());
  append_bytes(canonical, decoder_digest.bytes());
  append_bytes(canonical, estimate.metric_target_digest().bytes());
  append_u64(canonical, static_cast<std::uint64_t>(plan.stage()));
  append_u64(canonical,
             static_cast<std::uint64_t>(plan.accepted_backend_route()));
  const auto append_optional_digest =
      [&](const std::optional<Digest256>& value) {
        canonical.push_back(value ? std::byte{1} : std::byte{0});
        if (value) append_bytes(canonical, value->bytes());
      };
  append_optional_digest(estimate.proposal_law_identity());
  append_optional_digest(estimate.target_law_identity());
  return sha256_domain_separated("mwperf.c27.c24.estimate-law.v1",
                                 canonical);
}

[[nodiscard]] Result<PortableScientificScalar> outward_binary64(
    const long double value, const bool lower) {
  if (!std::isfinite(value)) {
    return fail<PortableScientificScalar>(
        "c27.c24.interval_endpoint_nonfinite",
        "a C24 interval endpoint is not finite in the estimator image");
  }
  double image = static_cast<double>(value);
  if (!std::isfinite(image)) {
    return fail<PortableScientificScalar>(
        "c27.c24.interval_endpoint_not_binary64",
        "a finite C24 interval endpoint has no finite binary64 enclosure");
  }
  const long double restored = static_cast<long double>(image);
  if ((lower && restored > value) || (!lower && restored < value)) {
    image = std::nextafter(
        image, lower ? -std::numeric_limits<double>::infinity()
                     : std::numeric_limits<double>::infinity());
  }
  if (!std::isfinite(image)) {
    return fail<PortableScientificScalar>(
        "c27.c24.interval_endpoint_not_binary64",
        "the outward-rounded C24 interval endpoint is not finite binary64");
  }
  return PortableScientificScalar::from_binary64(image);
}

[[nodiscard]] std::vector<std::string> c24_sampling_evidence_notes(
    const SamplingEvidenceSnapshotV1& evidence) {
  std::vector<std::string> notes{
      "runtime_provenance=" +
          std::to_string(static_cast<std::uint8_t>(
              evidence.runtime_provenance)),
      "normalization_evidence=" +
          std::to_string(static_cast<std::uint8_t>(
              evidence.normalization_evidence)),
      "termination_evidence=" +
          std::to_string(static_cast<std::uint8_t>(
              evidence.termination_evidence)),
      "v1_evidence_scope=" +
          std::to_string(static_cast<std::uint8_t>(
              evidence.v1_evidence_scope)),
      "v2_evidence_scope=" +
          std::to_string(static_cast<std::uint8_t>(
              evidence.v2_evidence_scope))};
  if (evidence.v1_evidence_reference) {
    notes.push_back("v1_evidence_reference=" +
                    evidence.v1_evidence_reference->hex());
  }
  if (evidence.v2_evidence_reference) {
    notes.push_back("v2_evidence_reference=" +
                    evidence.v2_evidence_reference->hex());
  }
  if (evidence.foreign_construction_evidence) {
    notes.push_back("foreign_construction_evidence=" +
                    evidence.foreign_construction_evidence->hex());
  }
  return notes;
}

[[nodiscard]] StageTag c24_sampler_stage(
    const ConditionalSamplerContractV1& contract) noexcept {
  if (contract.dependence == ConditionalSampleDependenceV1::iid_proposal) {
    return StageTag::importance_proposal;
  }
  switch (contract.reveal_stage) {
    case ConditionalSamplerRevealStageV1::prearrival_residual:
      return StageTag::prearrival_closure;
    case ConditionalSamplerRevealStageV1::postarrival_residual:
      return StageTag::postarrival_closure;
    case ConditionalSamplerRevealStageV1::generic_row_residual:
      return StageTag::generic_sampling;
  }
  return StageTag::solver_sampling;
}

[[nodiscard]] Result<void> append_c24_runtime_sampling_accounting(
    const SamplingPlan& plan, const std::string_view metric_id,
    const SamplingExecutionObserverV1& observer,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& backend_budgets,
    std::vector<ResultReplayStreamV1>& replay_streams) {
  if (observer.plan_digest() != plan.plan_digest() ||
      observer.stage() != plan.stage() ||
      observer.draw_cap() != plan.draw_cap()) {
    return fail<void>(
        "c27.sampling_observer_plan_mismatch",
        "the C24 execution observer no longer matches the exact fixed sampling plan, stage, and draw cap");
  }
  if (observer.generator_draws() > observer.draw_cap() ||
      observer.failed_draws() > observer.generator_draws()) {
    return fail<void>(
        "c27.sampling_observer_count_invalid",
        "the C24 execution observer reported draws outside its fixed cap or more failed draws than consumed draws");
  }
  const BigInt maximum = std::numeric_limits<std::size_t>::max();
  if (observer.generator_draws().value() > maximum) {
    return fail<void>(
        "c27.sampling_replay_count_not_addressable",
        "the consumed C24 generator-call count has no addressable replay-stream image");
  }
  const std::size_t count =
      observer.generator_draws().value().convert_to<std::size_t>();
  const std::span<const SamplingReplicationReplayV1> captured_streams =
      observer.replay_streams();
  if (captured_streams.size() != count) {
    return fail<void>(
        "c27.sampling_replay_count_mismatch",
        "the C24 execution observer did not retain exactly one replay-provenance record per consumed generator call");
  }
  std::vector<ResultReplayStreamV1> staged;
  staged.reserve(count);
  for (const SamplingReplicationReplayV1& captured : captured_streams) {
    staged.push_back(ResultRuntimeReplayStreamV1{
        plan.stage(), captured.stream_identity, captured.consumed_words});
  }
  replay_streams.insert(replay_streams.end(),
                        std::make_move_iterator(staged.begin()),
                        std::make_move_iterator(staged.end()));
  backend_budgets.push_back(ResultBudgetUsageV1{
      "backend." + std::string(metric_id) +
          ".conditional_generator_draws",
      ResultBudgetApplicabilityV1::applicable, observer.draw_cap(),
      observer.generator_draws(), "draws"});
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c24.sampling_accounting." + std::string(metric_id),
      DiagnosticCategory::information,
      "c27.c24.sampling_execution_accounting",
      "Final consumed draw and replay accounting for one fixed C24 estimator invocation",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::budget_termination,
      std::nullopt,
      std::nullopt,
      {"plan_digest=" + observer.plan_digest().hex(),
       "stage=" + std::to_string(
                      static_cast<std::uint8_t>(observer.stage())),
       "draw_cap=" + observer.draw_cap().to_decimal_string(),
       "generator_draws=" +
           observer.generator_draws().to_decimal_string(),
       "failed_draws=" + observer.failed_draws().to_decimal_string(),
       "replay_stream_count=" + std::to_string(captured_streams.size())},
      {}});
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_c24_success_accounting(
    const SamplingExecutionObserverV1& observer,
    const SamplingCostCountersV1& costs,
    const std::span<const SamplingReplicationReplayV1> replay_streams) {
  if (observer.generator_draws() != costs.draws ||
      observer.failed_draws() != costs.failed_draws ||
      !std::ranges::equal(observer.replay_streams(), replay_streams)) {
    return fail<void>(
        "c27.sampling_success_accounting_mismatch",
        "the successful C24 publication does not match its execution observer's consumed draws, failed draws, and replay streams");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<SamplingPlan> c24_sampling_plan(
    const ExecutionPlan& plan, const PlannedMetricV1& metric,
    const NormalizedSamplerAccess& access) {
  const auto* row =
      std::get_if<ConditionalRowMonteCarloBackendPlanV1>(&metric.backend());
  const auto* reward =
      std::get_if<ConditionalRewardMonteCarloBackendPlanV1>(
          &metric.backend());
  if (row == nullptr && reward == nullptr) {
    return fail<SamplingPlan>(
        "c27.sampling_backend_plan_mismatch",
        "the C24 dispatcher received a non-sampling backend plan");
  }
  const MonteCarloAccuracyV1& accuracy =
      row != nullptr ? row->accuracy : reward->accuracy;
  const BigNat& draw_cap = row != nullptr
                               ? row->worst_case_generator_draws
                               : reward->worst_case_generator_draws;
  const MetricRequestHeader& header = metric_request_header(metric.request());
  const StageTag required_stage = c24_sampler_stage(access.contract());
  const ConditionalEstimatorProcedureV1 required_procedure =
      row != nullptr
          ? ConditionalEstimatorProcedureV1::conditional_empirical_row
          : (access.contract().dependence ==
                     ConditionalSampleDependenceV1::iid_proposal
                 ? ConditionalEstimatorProcedureV1::
                       self_normalized_importance
                 : ConditionalEstimatorProcedureV1::conditional_reward_mean);
  const AcceptedSamplingClauseV1* accepted = nullptr;
  for (const AcceptedSamplingClauseV1& candidate :
       access.accepted_sampling_clauses()) {
    if (candidate.metric_target_digest !=
        metric.contract().support_clause_digest) {
      continue;
    }
    if (accepted != nullptr) {
      return fail<SamplingPlan>(
          "c27.sampling_access_target_ambiguous",
          "the sealed C24 access contains more than one accepted clause for the planned metric-target digest");
    }
    accepted = &candidate;
  }
  if (accepted == nullptr ||
      accepted->clause_id != metric.contract().clause_id ||
      accepted->backend_route != metric.route_kind() ||
      !(accepted->accepted_accuracy == accuracy)) {
    return fail<SamplingPlan>(
        "c27.sampling_access_clause_mismatch",
        "the sealed C24 access has no unique clause matching the frozen clause, backend route, metric target, and accuracy");
  }
  const RngAddressTemplateV1* address = nullptr;
  for (const RngAddressTemplateV1& candidate :
       plan.rng_address_templates()) {
    if (candidate.authored_metric_index != header.authored_index) continue;
    if (address != nullptr) {
      return fail<SamplingPlan>(
          "c27.sampling_rng_address_ambiguous",
          "the frozen execution plan contains more than one RNG address template for one authored sampling metric");
    }
    address = &candidate;
  }
  if (address == nullptr || address->schema_version != 1U ||
      address->clause_id != metric.contract().clause_id ||
      address->backend_route != metric.route_kind() ||
      address->instance_key_route !=
          RngInstanceKeyRouteV1::conditional_estimator ||
      address->stage != required_stage ||
      address->sampler_dependence != access.contract().dependence ||
      address->estimator_procedure != required_procedure ||
      (row != nullptr && address->reward_premises.has_value()) ||
      (reward != nullptr && !address->reward_premises.has_value()) ||
      address->metric_target_digest !=
          metric.contract().support_clause_digest ||
      !(address->replications == accuracy.replications)) {
    return fail<SamplingPlan>(
        "c27.sampling_rng_address_mismatch",
        "the C24 execution inputs do not match the immutable RNG address template frozen during planning");
  }
  return SamplingPlan::from_accepted_clause(
      access,
      SamplingPlanSpecV1{
          accuracy,
          plan.master_seed(),
          address->estimator_id,
          address->metric_target_digest,
          draw_cap,
          address->stage,
          true,
          false,
          std::nullopt});
}

[[nodiscard]] Result<ResultMetricV1> execute_c24_sampling_metric(
    const ExecutionPlan& plan, const ActivatedFrameworkV1& activated,
    const PlannedMetricV1& metric, const MetricSupportClauseV1& clause,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& backend_budgets,
    std::vector<ResultReplayStreamV1>& replay_streams) {
  if (!activated.single_conditioning_state.has_value()) {
    return fail<ResultMetricV1>(
        "c27.sampling_conditioning_state_unavailable",
        "the registered C24 activation did not bind the one exact conditioning row required by this metric");
  }
  auto one_metric_requirements = requirements_for_metric(metric.request());
  auto one_metric_digest =
      canonical_metric_requirements_digest(one_metric_requirements);
  if (!one_metric_digest) {
    return Result<ResultMetricV1>::failure(one_metric_digest.error());
  }
  const auto& conditioning = *activated.single_conditioning_state;
  if (conditioning.accepted_clause_id != metric.contract().clause_id ||
      conditioning.support_clause_digest !=
          metric.contract().support_clause_digest ||
      conditioning.normalized_metric_request_digest !=
          one_metric_digest.value()) {
    return fail<ResultMetricV1>(
        "c27.sampling_conditioning_state_binding_mismatch",
        "the registered conditioning state is not bound to this exact accepted clause, support digest, and normalized metric request");
  }
  const MetricRequestHeader& metric_header =
      metric_request_header(metric.request());
  const BacklogConditionedServiceRequestV1* point_request = nullptr;
  if (metric.route_kind() ==
      BackendRouteKindV1::conditional_reward_monte_carlo) {
    if (metric_header.kind == MetricKindV1::stationary_edge_reward) {
      return fail<ResultMetricV1>(
          "c27.row_conditional_stationary_transfer_unavailable",
          "a C24 estimate at one sealed conditioning row has row-conditional surrogate scope and does not establish a stationary edge-reward expectation without separate stationary-transfer evidence");
    }
    point_request =
        std::get_if<BacklogConditionedServiceRequestV1>(&metric.request());
    if (plan.metric_plans().size() != 1U || point_request == nullptr ||
        metric_header.ordered_targets.size() != 1U ||
        point_request->parameters().levels.size() != 1U ||
        metric.contract().semantic !=
            SemanticTagV1::staged_opportunity_flux_law ||
        clause.semantic != SemanticTagV1::staged_opportunity_flux_law ||
        metric.contract().runtime_access !=
            RuntimeAccessTagV1::normalized_conditional_sampler ||
        metric.contract().target_coupling !=
            TargetCouplingV1::scalar_target) {
      return fail<ResultMetricV1>(
          "c27.conditional_reward_exact_point_route_required",
          "C27 admits a conditional-reward sampler only for one singleton-target backlog-conditioned-service metric at one requested backlog level under the accepted staged-opportunity-flux exact-point contract");
    }

    const auto requirement_clauses = one_metric_requirements.clauses();
    const bool exact_point_route =
        requirement_clauses.size() == 1U &&
        std::ranges::any_of(
            requirement_clauses.front().route_alternatives,
            [&](const MetricRouteAlternativeV1& route) {
              const auto* point =
                  std::get_if<ExactPointResponseRequirementV1>(
                      &route.semantic.law);
              return route.access.backend_route == metric.route_kind() &&
                     route.access.runtime_access ==
                         metric.contract().runtime_access &&
                     route.access.c24_row_or_reward_only &&
                     !route.access.exact_request_only && point != nullptr &&
                     route.semantic.coupling ==
                         TargetCouplingV1::scalar_target &&
                     route.semantic.entrance ==
                         EntranceLawRequirementV1::none &&
                     std::ranges::all_of(
                         route.arrival.all_of,
                         [&](const ArrivalAssumptionV1& required) {
                           return std::ranges::find(
                                      clause.arrival_assumptions,
                                      required) !=
                                  clause.arrival_assumptions.end();
                         }) &&
                     point->represented_levels ==
                         point_request->parameters().levels &&
                     point->require_positive_stationary_conditioning_mass &&
                     point->permit_declared_off_support_convention;
            });
    if (!exact_point_route) {
      return fail<ResultMetricV1>(
          "c27.conditional_reward_exact_point_contract_mismatch",
          "the frozen C24 reward route is not the accepted ExactPointResponse alternative for the requested singleton backlog level");
    }

    auto target_ordinal = retained_target_ordinal(
        plan, metric_header.ordered_targets.front().queue_id);
    if (!target_ordinal) {
      return Result<ResultMetricV1>::failure(target_ordinal.error());
    }
    auto decoded_conditioning =
        activated.state_schema.decode(conditioning.state);
    if (!decoded_conditioning) {
      return Result<ResultMetricV1>::failure(
          decoded_conditioning.error());
    }
    const TargetBacklogV1& backlog = decoded_conditioning.value().backlog;
    const std::size_t ordinal = target_ordinal.value();
    if (!backlog.matches(plan.resolved_instance()) ||
        ordinal >= backlog.size() ||
        !backlog.target_at_target_ordinal(ordinal).matches(
            plan.resolved_instance()) ||
        backlog.target_at_target_ordinal(ordinal).ordinal() !=
            metric_header.ordered_targets.front().dense_index.ordinal() ||
        backlog.value_at_target_ordinal(ordinal) !=
            point_request->parameters().levels.front()) {
      return fail<ResultMetricV1>(
          "c27.conditional_reward_conditioning_backlog_mismatch",
          "the exact registered C24 conditioning state does not retain the requested target at the requested backlog level");
    }
  }
  auto descriptor = audited_sampler_descriptor(activated.framework);
  if (!descriptor) return Result<ResultMetricV1>::failure(descriptor.error());
  auto access = validate_conditional_generator(descriptor.value());
  if (!access) return Result<ResultMetricV1>::failure(access.error());
  auto sampling_plan = c24_sampling_plan(plan, metric, access.value());
  if (!sampling_plan) {
    return Result<ResultMetricV1>::failure(sampling_plan.error());
  }
  const std::string metric_id =
      metric_request_header(metric.request()).metric_id;
  if (metric.route_kind() ==
      BackendRouteKindV1::conditional_row_monte_carlo) {
    if (access.value().contract().dependence ==
        ConditionalSampleDependenceV1::iid_proposal) {
      return fail<ResultMetricV1>(
          "c27.proposal_row_estimator_unavailable",
          "a proposal-law sampler cannot publish an unweighted target kernel row, and the public C24 importance route is scalar-reward only");
    }
    auto observer = SamplingExecutionObserverV1::for_plan(
        sampling_plan.value());
    if (!observer) {
      return Result<ResultMetricV1>::failure(observer.error());
    }
    auto row = estimate_discrete_kernel_row_observed(
        access.value(), conditioning.state, sampling_plan.value(),
        observer.value());
    auto accounting = append_c24_runtime_sampling_accounting(
        sampling_plan.value(), metric_id, observer.value(), diagnostics,
        backend_budgets, replay_streams);
    if (!accounting) {
      return Result<ResultMetricV1>::failure(accounting.error());
    }
    if (!row) return Result<ResultMetricV1>::failure(row.error());
    auto success_accounting = validate_c24_success_accounting(
        observer.value(), row.value().costs(), row.value().replay_streams());
    if (!success_accounting) {
      return Result<ResultMetricV1>::failure(success_accounting.error());
    }
    const std::string sampling_diagnostic_id =
        "c27.c24.sampling." + metric_id;
    std::vector<std::string> sampling_notes =
        c24_sampling_evidence_notes(row.value().sampling_evidence());
    sampling_notes.insert(
        sampling_notes.begin(),
        {"plan_digest=" + row.value().plan_digest().hex(),
         "seal_digest=" + row.value().seal_digest().hex(),
         "conditioning_row_digest=" +
             row.value().conditioning_row_digest().hex(),
         "metric_target_digest=" +
             row.value().metric_target_digest().hex(),
         "replications=" + row.value().total().to_decimal_string(),
         row.value().iid_replications() ? "iid_replications=true"
                                        : "iid_replications=false",
         "generator_draws=" +
             row.value().costs().draws.to_decimal_string(),
         "failed_draws=" +
             row.value().costs().failed_draws.to_decimal_string(),
         "canonical_bytes=" +
             row.value().costs().canonical_bytes.to_decimal_string()});
    if (row.value().advertised_tv_failure_bound()) {
      sampling_notes.push_back(
          "advertised_tv_failure_bound=" +
          floating_text(*row.value().advertised_tv_failure_bound()));
    }
    diagnostics.push_back(ResultDiagnosticV1{
        sampling_diagnostic_id, DiagnosticCategory::information,
        "c27.c24.sampling_metadata",
        "C24 sealed fixed-bank sampling identity and evidence metadata",
        component_scope_from_ordinal(7U),
        ResultDiagnosticKindV1::execution, std::nullopt, std::nullopt,
        std::move(sampling_notes), {}});
    ResultProbabilityLawV1 law{
        {"completed_sample_identity"}, {},
        PortableScientificScalar::rational(ExactRational::zero()), true};
    law.atoms.reserve(row.value().atoms().size());
    for (const EmpiricalRowAtomV1& atom : row.value().atoms()) {
      auto digest = sample_identity_digest(atom.sample);
      if (!digest) return Result<ResultMetricV1>::failure(digest.error());
      auto label = TypedLabel::text(digest.value().hex());
      if (!label) return Result<ResultMetricV1>::failure(label.error());
      law.atoms.push_back(ResultProbabilityAtomV1{
          {std::move(label).value()},
          PortableScientificScalar::rational(atom.probability)});
    }
    auto law_identity =
        c24_row_law_identity(sampling_plan.value(), row.value());
    if (!law_identity) {
      return Result<ResultMetricV1>::failure(law_identity.error());
    }
    return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
        backend_metric_header(
            metric, clause, law_identity.value(),
            "C24 fixed-budget empirical conditional kernel row",
            {}, {sampling_diagnostic_id},
            {"row_conditional_surrogate_scope",
             row.value().iid_replications() ? "iid_replications"
                                            : "dependent_replications"}),
        std::move(law)});
  }

  const RuntimeFrameworkActivationV1::ConditionalRewardDecoderBindingV1*
      decoder_binding = nullptr;
  for (const auto& candidate : activated.conditional_reward_decoders) {
    if (candidate.accepted_clause_id != metric.contract().clause_id ||
        candidate.support_clause_digest !=
            metric.contract().support_clause_digest ||
        candidate.normalized_metric_request_digest !=
            one_metric_digest.value()) {
      continue;
    }
    if (decoder_binding != nullptr) {
      return fail<ResultMetricV1>(
          "c27.conditional_reward_decoder_ambiguous",
          "the registered activation contains duplicate reward decoders for one accepted clause and normalized metric request");
    }
    decoder_binding = &candidate;
  }
  if (decoder_binding == nullptr || !decoder_binding->decoder) {
    return fail<ResultMetricV1>(
        "c27.conditional_reward_decoder_unavailable",
        "the registered activation has no decoder bound to the exact accepted clause and metric request");
  }
  if (point_request == nullptr ||
      !decoder_binding->decoder->binary_indicator ||
      !decoder_binding->decoder->almost_sure_lower.has_value() ||
      !decoder_binding->decoder->almost_sure_upper.has_value() ||
      *decoder_binding->decoder->almost_sure_lower != ExactRational::zero() ||
      *decoder_binding->decoder->almost_sure_upper != ExactRational::one()) {
    return fail<ResultMetricV1>(
        "c27.conditional_service_reward_decoder_not_binary",
        "the exact-point backlog-conditioned-service route requires a request-bound binary service indicator with the exact almost-sure range [0,1]");
  }
  RewardDecoder reward_decoder{
      StationaryRewardDomainV1::state,
      decoder_binding->decoder->integrability,
      false,
      {},
      [](const StationaryRewardArgumentV1&) -> Result<long double> {
        return fail<long double>(
            "c27.stationary_reward_branch_not_applicable",
            "the C24-only residual reward has no C18 stationary branch");
      },
      CodecIdentityV1{"mwperf.c27.c24.estimate", 1U},
      decoder_binding->decoder};
  const bool importance =
      access.value().contract().dependence ==
      ConditionalSampleDependenceV1::iid_proposal;
  auto observer = SamplingExecutionObserverV1::for_plan(
      sampling_plan.value());
  if (!observer) {
    return Result<ResultMetricV1>::failure(observer.error());
  }
  auto estimate = [&]() -> Result<Estimate> {
    if (!importance) {
      return estimate_reward_expectation_observed(
          access.value(), conditioning.state,
          reward_decoder, sampling_plan.value(), observer.value());
    }
    auto ratio = access.value().bind_target_density_ratio(
        conditioning.state, sampling_plan.value());
    if (!ratio) return Result<Estimate>::failure(ratio.error());
    return estimate_importance_weighted_observed(
        access.value(), conditioning.state,
        ratio.value(), reward_decoder, sampling_plan.value(),
        observer.value());
  }();
  auto accounting = append_c24_runtime_sampling_accounting(
      sampling_plan.value(), metric_id, observer.value(), diagnostics,
      backend_budgets, replay_streams);
  if (!accounting) {
    return Result<ResultMetricV1>::failure(accounting.error());
  }
  if (!estimate) return Result<ResultMetricV1>::failure(estimate.error());
  auto success_accounting = validate_c24_success_accounting(
      observer.value(), estimate.value().costs(),
      estimate.value().replay_streams());
  if (!success_accounting) {
    return Result<ResultMetricV1>::failure(success_accounting.error());
  }
  const std::string sampling_diagnostic_id =
      "c27.c24.sampling." + metric_id;
  std::vector<std::string> sampling_notes =
      c24_sampling_evidence_notes(estimate.value().sampling_evidence());
  sampling_notes.insert(
      sampling_notes.begin(),
      {"plan_digest=" + estimate.value().plan_digest().hex(),
       "seal_digest=" + estimate.value().seal_digest().hex(),
       "conditioning_row_digest=" +
           estimate.value().conditioning_row_digest().hex(),
       "decoder_digest=" + decoder_binding->decoder->decoder_digest.hex(),
       "metric_target_digest=" +
           estimate.value().metric_target_digest().hex(),
       "claim_scope=" +
           std::to_string(static_cast<std::uint8_t>(
               estimate.value().claim_scope())),
       "replications=" +
           estimate.value().replications().to_decimal_string(),
       "generator_draws=" +
           estimate.value().costs().draws.to_decimal_string(),
       "failed_draws=" +
           estimate.value().costs().failed_draws.to_decimal_string(),
       "exact_innovation_atoms=" +
           estimate.value().costs().exact_innovation_atoms
               .to_decimal_string(),
       "optimizer_probes=" +
           estimate.value().costs().optimizer_probes.to_decimal_string(),
       "canonical_bytes=" +
           estimate.value().costs().canonical_bytes.to_decimal_string()});
  if (estimate.value().sample_variance()) {
    sampling_notes.push_back(
        "sample_variance=" +
        floating_text(*estimate.value().sample_variance()));
  }
  if (estimate.value().exact_integration_absolute_error()) {
    sampling_notes.push_back(
        "exact_integration_absolute_error=" +
        floating_text(
            *estimate.value().exact_integration_absolute_error()));
  }
  if (estimate.value().proposal_law_identity()) {
    sampling_notes.push_back(
        "proposal_law_identity=" +
        estimate.value().proposal_law_identity()->hex());
  }
  if (estimate.value().target_law_identity()) {
    sampling_notes.push_back(
        "target_law_identity=" +
        estimate.value().target_law_identity()->hex());
  }
  if (estimate.value().importance_diagnostics()) {
    const ImportanceDiagnosticsV1& source =
        *estimate.value().importance_diagnostics();
    sampling_notes.push_back(
        "effective_sample_size=" +
        floating_text(source.effective_sample_size));
    sampling_notes.push_back(
        "maximum_normalized_weight=" +
        floating_text(source.maximum_normalized_weight));
    sampling_notes.push_back(
        "zero_weight_count=" + std::to_string(source.zero_weight_count));
    sampling_notes.push_back(
        "positive_log_weight_dynamic_range=" +
        floating_text(source.positive_log_weight_dynamic_range));
    sampling_notes.push_back(
        source.zero_weights_present ? "zero_weights_present=true"
                                    : "zero_weights_present=false");
    sampling_notes.push_back(
        source.full_log_weight_dynamic_range_infinite
            ? "full_log_weight_dynamic_range_infinite=true"
            : "full_log_weight_dynamic_range_infinite=false");
    sampling_notes.push_back(
        source.finite_sample_biased ? "finite_sample_biased=true"
                                    : "finite_sample_biased=false");
    sampling_notes.push_back(
        source.consistency_claim ? "consistency_claim=true"
                                 : "consistency_claim=false");
    sampling_notes.push_back(
        source.weighted_second_moment_claim
            ? "weighted_second_moment_claim=true"
            : "weighted_second_moment_claim=false");
  }
  diagnostics.push_back(ResultDiagnosticV1{
      sampling_diagnostic_id, DiagnosticCategory::information,
      "c27.c24.sampling_metadata",
      "C24 sealed estimator identity, cost, and evidence metadata",
      component_scope_from_ordinal(7U), ResultDiagnosticKindV1::execution,
      std::nullopt, std::nullopt, std::move(sampling_notes), {}});
  const long double estimate_value = estimate.value().value();
  if (!std::isfinite(estimate_value) || estimate_value < 0.0L ||
      estimate_value > 1.0L) {
    return fail<ResultMetricV1>(
        "c27.conditional_service_estimate_out_of_range",
        "the C24 conditional-service estimate is outside its audited probability range [0,1]");
  }
  auto scalar = PortableScientificScalar::from_binary64(
      static_cast<double>(estimate_value));
  if (!scalar) return Result<ResultMetricV1>::failure(scalar.error());
  auto law_identity = c24_estimate_law_identity(
      sampling_plan.value(), estimate.value(),
      decoder_binding->decoder->decoder_digest);
  if (!law_identity) {
    return Result<ResultMetricV1>::failure(law_identity.error());
  }
  if (estimate.value().interval().has_value()) {
    auto lower = outward_binary64(
        estimate.value().interval()->lower, true);
    auto upper = outward_binary64(
        estimate.value().interval()->upper, false);
    if (!lower) return Result<ResultMetricV1>::failure(lower.error());
    if (!upper) return Result<ResultMetricV1>::failure(upper.error());
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.c24.interval." + metric_id,
        DiagnosticCategory::information,
        "c27.conditional_reward_interval",
        "C24 fixed-sample row-conditional service-probability interval at the exact requested backlog level",
        component_scope_from_ordinal(7U),
        ResultDiagnosticKindV1::component,
        std::nullopt,
        ResultDiagnosticIntervalV1{CertificateClaimStateV1::established,
                                   BoundValueStatusV1::finite,
                                   std::move(lower).value(),
                                   std::move(upper).value()},
        {"coverage=" + estimate.value().interval()->coverage_statement,
         "exact_point_backlog_conditioning",
         "no_stationary_transfer_from_c24_sampling",
         "not_physical_fidelity"},
        {}});
  }
  std::vector<std::string> assumptions{
      importance ? "self_normalized_importance_target_scope"
                 : "row_conditional_surrogate_scope",
      "runtime_sampling_only", "not_provider_construction_sampling",
      "exact_point_backlog_conditioning",
      "conditioning_state_backlog_matches_requested_level",
      "binary_service_indicator", "not_stationary_edge_average",
      "no_stationary_transfer_from_c24_sampling"};
  if (importance) {
    assumptions.push_back("audited_target_density_ratio");
    assumptions.push_back("finite_sample_self_normalized_bias");
  }
  ResultScalarVectorV1 values;
  values.values.push_back(std::move(scalar).value());
  return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
      backend_metric_header(
          metric, clause, law_identity.value(),
          importance
              ? "C24 fixed-budget self-normalized importance estimate of row-conditional service probability at the exact requested backlog level"
              : "C24 fixed-budget estimate of row-conditional service probability at the exact requested backlog level",
          {},
          estimate.value().interval().has_value()
              ? std::vector<std::string>{sampling_diagnostic_id,
                                         "c27.c24.interval." + metric_id}
              : std::vector<std::string>{sampling_diagnostic_id},
          std::move(assumptions)),
      std::move(values)});
}

[[nodiscard]] ResultDiagnosticV1 exact_residual_diagnostic(
    std::string id, std::string code, std::string message,
    const ExactRational& value) {
  const PortableScientificScalar scalar =
      PortableScientificScalar::rational(value);
  return ResultDiagnosticV1{
      std::move(id),
      DiagnosticCategory::information,
      std::move(code),
      std::move(message),
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::stationary_residual,
      std::nullopt,
      std::nullopt,
      {"exact_rational_residual", scalar.canonical_tagged_encoding()},
      {}};
}

template <typename Summary>
void append_c19_solver_diagnostics(
    const Summary& summary,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  const AnalyticStationaryDiagnosticsV1& source = summary.diagnostics();
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c19.stationary_status", DiagnosticCategory::information,
      "c27.c19.stationary_status",
      "C19 constant-tail stationary-law status",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::numerical_conditioning, std::nullopt,
      std::nullopt,
      {"status=" +
       std::to_string(static_cast<std::uint8_t>(summary.status()))},
      {}});
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c19.tail_slack_applicability", DiagnosticCategory::information,
      "c27.c19.tail_slack_applicability",
      "C19 constant-tail slack branch applicability",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::numerical_conditioning, std::nullopt,
      std::nullopt,
      {"applicability=" + std::to_string(static_cast<std::uint8_t>(
                              summary.tail_slack_applicability()))},
      {}});
  if (summary.tail_slack()) {
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.c19.tail_slack", DiagnosticCategory::information,
        "c27.c19.tail_slack", "exact C19 constant-tail service slack",
        component_scope_from_ordinal(7U),
        ResultDiagnosticKindV1::numerical_conditioning, std::nullopt,
        std::nullopt,
        {"tail_slack=" + exact_text(*summary.tail_slack())}, {}});
  }
  if (source.tail_remainder_bound) {
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.c19.tail_remainder_bound", DiagnosticCategory::information,
        "c27.c19.tail_remainder_bound",
        "C19 certified stationary tail remainder bound",
        component_scope_from_ordinal(7U),
        ResultDiagnosticKindV1::truncation_tail, std::nullopt, std::nullopt,
        {"tail_remainder_bound=" +
         exact_text(*source.tail_remainder_bound)},
        {}});
  }
  if (source.terms_evaluated) {
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.c19.terms_evaluated", DiagnosticCategory::information,
        "c27.c19.terms_evaluated",
        "C19 exact or numerical series terms evaluated",
        component_scope_from_ordinal(7U),
        ResultDiagnosticKindV1::numerical_conditioning, std::nullopt,
        std::nullopt,
        {"terms_evaluated=" +
         source.terms_evaluated->to_decimal_string()},
        {}});
  }
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c19.condition_estimate", DiagnosticCategory::information,
      "c27.c19.condition_estimate",
      "C19 reported numerical condition estimate",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::numerical_conditioning, std::nullopt,
      std::nullopt,
      {"condition_estimate=" +
       floating_text(source.numerical_condition_estimate)},
      {}});
}

void append_stationary_temporal_backend_diagnostics(
    const StationaryTemporalBackendV1& backend,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  const EventInvariantDiagnosticsV1& invariant =
      backend.event_law.diagnostics();
  diagnostics.push_back(exact_residual_diagnostic(
      "c27.c20.normalization_residual",
      "c27.c20.normalization_residual",
      "exact C20 event-invariant normalization residual",
      invariant.exact_normalization_residual));

  std::vector<std::string> exact_invariance_notes{
      "class_count=" + std::to_string(invariant.classes.size()),
      "closed_class_count=" +
          std::to_string(invariant.closed_class_indices.size()),
      "transient_state_count=" +
          std::to_string(invariant.transient_state_indices.size()),
      "residual_count=" +
      std::to_string(invariant.exact_invariance_residuals.size()),
      invariant.exact_nonnegative ? "exact_nonnegative=true"
                                  : "exact_nonnegative=false",
      invariant.exact_normalized ? "exact_normalized=true"
                                 : "exact_normalized=false",
      invariant.exact_invariant ? "exact_invariant=true"
                                : "exact_invariant=false"};
  for (std::size_t index = 0U; index < invariant.classes.size(); ++index) {
    const CommunicatingClassV1& item = invariant.classes[index];
    const std::string prefix = "class[" + std::to_string(index) + "].";
    exact_invariance_notes.push_back(prefix + "id=" +
                                     typed_label_text(item.class_id));
    exact_invariance_notes.push_back(
        prefix + "member_count=" +
        std::to_string(item.member_indices.size()));
    for (std::size_t member = 0U; member < item.member_indices.size();
         ++member) {
      exact_invariance_notes.push_back(
          prefix + "member[" + std::to_string(member) + "]=" +
          std::to_string(item.member_indices[member]));
    }
    exact_invariance_notes.push_back(
        prefix + "outgoing_class_count=" +
        std::to_string(item.outgoing_class_ids.size()));
    for (std::size_t outgoing = 0U;
         outgoing < item.outgoing_class_ids.size(); ++outgoing) {
      exact_invariance_notes.push_back(
          prefix + "outgoing_class[" + std::to_string(outgoing) + "]=" +
          typed_label_text(item.outgoing_class_ids[outgoing]));
    }
    exact_invariance_notes.push_back(
        prefix + (item.closed ? "closed=true" : "closed=false"));
  }
  for (std::size_t index = 0U;
       index < invariant.closed_class_indices.size(); ++index) {
    exact_invariance_notes.push_back(
        "closed_class_index[" + std::to_string(index) + "]=" +
        std::to_string(invariant.closed_class_indices[index]));
  }
  for (std::size_t index = 0U;
       index < invariant.transient_state_indices.size(); ++index) {
    exact_invariance_notes.push_back(
        "transient_state_index[" + std::to_string(index) + "]=" +
        std::to_string(invariant.transient_state_indices[index]));
  }
  for (std::size_t index = 0U;
       index < invariant.exact_invariance_residuals.size(); ++index) {
    exact_invariance_notes.push_back(
        "state[" + std::to_string(index) + "]=" +
        exact_text(invariant.exact_invariance_residuals[index]));
  }
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c20.invariance_residuals", DiagnosticCategory::information,
      "c27.c20.invariance_residuals",
      "exact C20 event-invariant coordinate residuals",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::stationary_residual, std::nullopt,
      std::nullopt, std::move(exact_invariance_notes), {}});

  const InvariantSolveDiagnosticsV1& solve = invariant.solve;
  std::vector<std::string> solve_notes{
      "linear_method=" +
          std::to_string(static_cast<std::uint8_t>(solve.method)),
      "absolute_residual_tolerance=" +
          exact_text(solve.absolute_residual_tolerance),
      "relative_residual_tolerance=" +
          exact_text(solve.relative_residual_tolerance),
      "normalization_residual=" +
          floating_text(solve.normalization_residual),
      "normalization_bound=" + floating_text(solve.normalization_bound),
      "l1_invariance_residual=" +
          floating_text(solve.l1_invariance_residual),
      "l1_invariance_bound=" + floating_text(solve.l1_invariance_bound),
      "maximum_invariance_residual=" +
          floating_text(solve.maximum_invariance_residual),
      "maximum_invariance_bound=" +
          floating_text(solve.maximum_invariance_bound),
      "selected_class_count=" +
          std::to_string(solve.selected_classes.size()),
      "class_solve_count=" + std::to_string(solve.class_solves.size())};
  for (std::size_t index = 0U; index < solve.selected_classes.size();
       ++index) {
    const SelectedInvariantClassV1& selected =
        solve.selected_classes[index];
    const std::string prefix =
        "selected_class[" + std::to_string(index) + "].";
    solve_notes.push_back(prefix + "id=" +
                          typed_label_text(selected.class_id));
    solve_notes.push_back(prefix + "index=" +
                          std::to_string(selected.class_index));
    solve_notes.push_back(prefix + "exact_weight=" +
                          exact_text(selected.exact_weight));
    solve_notes.push_back(prefix + "numerical_weight=" +
                          floating_text(selected.numerical_weight));
  }
  for (std::size_t index = 0U; index < solve.class_solves.size(); ++index) {
    const ClassSolveDiagnosticV1& item = solve.class_solves[index];
    const std::string prefix =
        "class_solve[" + std::to_string(index) + "].";
    solve_notes.push_back(prefix + "id=" + typed_label_text(item.class_id));
    solve_notes.push_back(prefix + "dimension=" +
                          std::to_string(item.dimension));
    solve_notes.push_back(prefix + "rank=" + std::to_string(item.rank));
    solve_notes.push_back(prefix + "rank_threshold_eta=" +
                          floating_text(item.rank_threshold_eta));
    solve_notes.push_back(prefix + "reciprocal_condition_estimate=" +
                          floating_text(item.reciprocal_condition_estimate));
    solve_notes.push_back(prefix + "condition_warning_threshold=" +
                          floating_text(item.condition_warning_threshold));
    solve_notes.push_back(prefix +
                          (item.condition_warning
                               ? "condition_warning=true"
                               : "condition_warning=false"));
    solve_notes.push_back(prefix + "normalization_residual=" +
                          floating_text(item.normalization_residual));
    solve_notes.push_back(prefix + "normalization_bound=" +
                          floating_text(item.normalization_bound));
    solve_notes.push_back(prefix + "l1_invariance_residual=" +
                          floating_text(item.l1_invariance_residual));
    solve_notes.push_back(prefix + "l1_invariance_bound=" +
                          floating_text(item.l1_invariance_bound));
    solve_notes.push_back(prefix + "maximum_invariance_residual=" +
                          floating_text(item.maximum_invariance_residual));
    solve_notes.push_back(prefix + "maximum_invariance_bound=" +
                          floating_text(item.maximum_invariance_bound));
    solve_notes.push_back(prefix +
                          (item.finite_nonnegative
                               ? "finite_nonnegative=true"
                               : "finite_nonnegative=false"));
    solve_notes.push_back(
        prefix + "status=" +
        std::to_string(static_cast<std::uint8_t>(item.status)));
  }
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c20.solve_residuals", DiagnosticCategory::information,
      "c27.c20.solve_residuals",
      "C20 selected event-invariant numerical solve diagnostics",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::stationary_residual, std::nullopt,
      std::nullopt, std::move(solve_notes), {}});

  const PositiveFiniteMeanDiagnosticsV1& mean =
      backend.mean_residence.diagnostics();
  std::vector<std::string> mean_notes{
      "event_law_fingerprint=" +
          backend.mean_residence.event_law_fingerprint().hex(),
      "provider_fingerprint=" +
          backend.mean_residence.provider_fingerprint().hex(),
      "denominator_fingerprint=" + backend.mean_residence.fingerprint().hex(),
      "method=" + std::to_string(static_cast<std::uint8_t>(mean.method)),
      "exact_value=" +
          (mean.exact_value ? exact_text(*mean.exact_value)
                            : std::string("unavailable")),
      "exact_evaluated_sum=" + exact_text(mean.exact_evaluated_sum),
      "exact_lower_bound=" + exact_text(mean.exact_lower_bound),
      "exact_upper_bound=" + exact_text(mean.exact_upper_bound),
      "exact_tail_lower_bound=" + exact_text(mean.exact_tail_lower_bound),
      "exact_tail_upper_bound=" + exact_text(mean.exact_tail_upper_bound),
      "numerical_value=" + floating_text(mean.numerical_value),
      "numerical_correction=" + floating_text(mean.numerical_correction),
      "numerical_lower_bound=" + floating_text(mean.numerical_lower_bound),
      "numerical_upper_bound=" + floating_text(mean.numerical_upper_bound),
      "numerical_condition_estimate=" +
          floating_text(mean.numerical_condition_estimate),
      "range_status=" +
          std::to_string(static_cast<std::uint8_t>(mean.range_status)),
      "event_states_visited=" + std::to_string(mean.event_states_visited),
      "words_visited=" + std::to_string(mean.words_visited),
      "offsets_certified=" + std::to_string(mean.offsets_certified),
      mean.support_complete ? "support_complete=true"
                            : "support_complete=false",
      mean.tail_certified ? "tail_certified=true" : "tail_certified=false"};
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c21.mean_residence_enclosure", DiagnosticCategory::information,
      "c27.c21.mean_residence_enclosure",
      "C21 positive finite mean-residence denominator and tail enclosure",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::truncation_tail, std::nullopt, std::nullopt,
      std::move(mean_notes), {}});

  const StationaryProjectionDiagnosticsV1& projection =
      backend.projection.diagnostics();
  const StationaryTemporalDiagnosticsV1& temporal =
      backend.projection.temporal_law().diagnostics();
  const StationaryMarkedEdgeDiagnosticsV1& edge =
      backend.projection.marked_edge().diagnostics();
  std::vector<std::string> projection_notes{
      "event_law_fingerprint=" + projection.event_law_fingerprint.hex(),
      "residence_provider_fingerprint=" +
          projection.residence_provider_fingerprint.hex(),
      "denominator_fingerprint=" + projection.denominator_fingerprint.hex(),
      "exact_length_biased_mass=" +
          exact_text(projection.exact_length_biased_mass),
      "numerical_length_biased_mass=" +
          floating_text(projection.numerical_length_biased_mass),
      projection.three_way_identity_matches
          ? "three_way_identity_matches=true"
          : "three_way_identity_matches=false",
      projection.phase_occupation_matches
          ? "phase_occupation_matches=true"
          : "phase_occupation_matches=false",
      projection.edge_mass_is_one ? "edge_mass_is_one=true"
                                  : "edge_mass_is_one=false",
      projection.edge_marginals_match ? "edge_marginals_match=true"
                                      : "edge_marginals_match=false",
      projection.endpoint_is_invariant ? "endpoint_is_invariant=true"
                                       : "endpoint_is_invariant=false",
      projection.constructed_in_one_residence_pass
          ? "constructed_in_one_residence_pass=true"
          : "constructed_in_one_residence_pass=false",
      "temporal_exact_total_mass=" + exact_text(temporal.exact_total_mass),
      "temporal_numerical_total_mass=" +
          floating_text(temporal.numerical_total_mass),
      "temporal_numerical_mass_correction=" +
          floating_text(temporal.numerical_mass_correction),
      "temporal_numerical_mass_residual=" +
          floating_text(temporal.numerical_mass_residual),
      temporal.configured_phase_identity_available
          ? "configured_phase_identity_available=true"
          : "configured_phase_identity_available=false",
      temporal.configured_phase_identity_matches
          ? "configured_phase_identity_matches=true"
          : "configured_phase_identity_matches=false",
      temporal.cross_residence_continuation_retained
          ? "cross_residence_continuation_retained=true"
          : "cross_residence_continuation_retained=false",
      temporal.signed_absolute_integrability_available
          ? "signed_absolute_integrability_available=true"
          : "signed_absolute_integrability_available=false",
      "edge_exact_total_mass=" + exact_text(edge.exact_total_mass),
      "edge_numerical_total_mass=" +
          floating_text(edge.numerical_total_mass),
      "edge_numerical_mass_correction=" +
          floating_text(edge.numerical_mass_correction),
      "edge_numerical_mass_residual=" +
          floating_text(edge.numerical_mass_residual),
      "edge_maximum_left_right_residual=" +
          floating_text(edge.maximum_left_right_residual),
      "edge_maximum_endpoint_invariance_residual=" +
          floating_text(edge.maximum_endpoint_invariance_residual),
      edge.exact_left_right_marginals_equal
          ? "exact_left_right_marginals_equal=true"
          : "exact_left_right_marginals_equal=false",
      edge.exact_queue_updates_hold ? "exact_queue_updates_hold=true"
                                    : "exact_queue_updates_hold=false",
      edge.exact_endpoint_invariance_holds
          ? "exact_endpoint_invariance_holds=true"
          : "exact_endpoint_invariance_holds=false",
      edge.zero_mass_rows_left_undefined
          ? "zero_mass_rows_left_undefined=true"
          : "zero_mass_rows_left_undefined=false",
      "edge_explicit_completion_identity=" +
          (edge.explicit_completion_identity
               ? edge.explicit_completion_identity->hex()
               : std::string("unavailable")),
      "phase_occupation_count=" +
          std::to_string(temporal.phase_occupation.size())};
  for (std::size_t index = 0U; index < temporal.phase_occupation.size();
       ++index) {
    const StationaryPhaseOccupationAtomV1& phase =
        temporal.phase_occupation[index];
    const std::string prefix =
        "phase_occupation[" + std::to_string(index) + "].";
    projection_notes.push_back(
        prefix + "arrival_family=" +
        std::to_string(static_cast<std::uint8_t>(phase.phase.family)));
    projection_notes.push_back(
        prefix + "canonical_state_size=" +
        std::to_string(phase.phase.canonical_state.size()));
    for (std::size_t byte = 0U;
         byte < phase.phase.canonical_state.size(); ++byte) {
      projection_notes.push_back(
          prefix + "canonical_state[" + std::to_string(byte) + "]=" +
          std::to_string(std::to_integer<std::uint8_t>(
              phase.phase.canonical_state[byte])));
    }
    projection_notes.push_back(prefix + "exact_slot_mass=" +
                               exact_text(phase.exact_slot_mass));
    projection_notes.push_back(prefix + "numerical_slot_mass=" +
                               floating_text(phase.numerical_slot_mass));
    projection_notes.push_back(
        prefix + "configured_exact_mass=" +
        (phase.configured_exact_mass
             ? exact_text(*phase.configured_exact_mass)
             : std::string("unavailable")));
    projection_notes.push_back(
        prefix + "configured_numerical_mass=" +
        (phase.configured_numerical_mass
             ? floating_text(*phase.configured_numerical_mass)
             : std::string("unavailable")));
    projection_notes.push_back(prefix + "numerical_residual=" +
                               floating_text(phase.numerical_residual));
    projection_notes.push_back(prefix + "residual_bound=" +
                               floating_text(phase.residual_bound));
  }
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c21.projection_residuals", DiagnosticCategory::information,
      "c27.c21.projection_residuals",
      "C21 stationary suspension and marked-edge projection residuals",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::stationary_residual, std::nullopt,
      std::nullopt, std::move(projection_notes), {}});
}

template <typename T>
[[nodiscard]] Result<const T*> require_stationary_projection_slot(
    const StationaryProjectionSlotV1<T>& slot,
    const std::string_view description) {
  if (const auto* value = std::get_if<T>(&slot)) {
    return Result<const T*>::success(value);
  }
  const auto* unavailable =
      std::get_if<StationaryProjectionUnavailableV1>(&slot);
  return fail<const T*>(
      unavailable == nullptr ? "c27.stationary_projection_slot_unavailable"
                             : unavailable->code,
      unavailable == nullptr
          ? "the stationary temporal projection omitted its " +
                std::string(description)
          : unavailable->message,
      DiagnosticCategory::unavailable);
}

[[nodiscard]] Result<Digest256> route_bound_law_identity(
    const Digest256& source, const PlannedMetricV1& metric) {
  auto requirements =
      canonical_metric_requirements_digest(
          requirements_for_metric(metric.request()));
  if (!requirements) {
    return Result<Digest256>::failure(requirements.error());
  }
  std::vector<std::byte> canonical;
  append_bytes(canonical, source.bytes());
  append_bytes(canonical, metric.contract().support_clause_digest.bytes());
  append_u64(canonical,
             static_cast<std::uint64_t>(metric.route_kind()));
  append_bytes(canonical, requirements.value().bytes());
  return sha256_domain_separated("mwperf.c27.route-bound-law.v1",
                                 canonical);
}

[[nodiscard]] Result<PortableScientificScalar> natural_scalar(
    const BigNat& value) {
  auto rational = ExactRational::make(value.value(), BigInt{1});
  if (!rational) {
    return Result<PortableScientificScalar>::failure(rational.error());
  }
  return Result<PortableScientificScalar>::success(
      PortableScientificScalar::rational(std::move(rational).value()));
}

void append_text(std::vector<std::byte>& output,
                 const std::string_view value) {
  append_bytes(output, std::as_bytes(std::span(value.data(), value.size())));
}

void append_rational(std::vector<std::byte>& output,
                     const ExactRational& value) {
  const std::vector<std::uint8_t> canonical =
      PortableScientificScalar::rational(value).canonical_bytes();
  append_u64(output, static_cast<std::uint64_t>(canonical.size()));
  for (const std::uint8_t byte : canonical) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

void append_optional_size(
    std::vector<std::byte>& output,
    const std::optional<std::size_t>& value) {
  output.push_back(value ? std::byte{1} : std::byte{0});
  if (value) {
    append_u64(output, static_cast<std::uint64_t>(*value));
  }
}

void append_optional_natural(
    std::vector<std::byte>& output,
    const std::optional<BigNat>& value) {
  output.push_back(value ? std::byte{1} : std::byte{0});
  if (value) append_natural(output, *value);
}

void append_optional_rational(
    std::vector<std::byte>& output,
    const std::optional<ExactRational>& value) {
  output.push_back(value ? std::byte{1} : std::byte{0});
  if (value) append_rational(output, *value);
}

void append_optional_floating(
    std::vector<std::byte>& output,
    const std::optional<long double>& value) {
  output.push_back(value ? std::byte{1} : std::byte{0});
  if (value) {
    std::ostringstream canonical;
    canonical.imbue(std::locale::classic());
    canonical << std::hexfloat
              << std::setprecision(
                     std::numeric_limits<long double>::max_digits10)
              << (*value == 0.0L ? 0.0L : *value);
    append_text(output, canonical.str());
  }
}

void append_stopped_solve_diagnostics(
    std::vector<std::byte>& output,
    const std::optional<StoppedSolveDiagnosticsV1>& diagnostics) {
  output.push_back(diagnostics ? std::byte{1} : std::byte{0});
  if (!diagnostics) return;
  output.push_back(static_cast<std::byte>(
      static_cast<std::uint8_t>(diagnostics->status)));
  append_u64(output,
             static_cast<std::uint64_t>(diagnostics->iterations));
  append_optional_size(output, diagnostics->system_dimension);
  append_optional_size(output, diagnostics->exact_rank);
  append_u64(
      output,
      static_cast<std::uint64_t>(
          diagnostics->exact_equation_residuals.size()));
  for (const std::optional<ExactRational>& residual :
       diagnostics->exact_equation_residuals) {
    append_optional_rational(output, residual);
  }
  append_u64(
      output,
      static_cast<std::uint64_t>(
          diagnostics->exact_auxiliary_residuals.size()));
  for (const std::optional<ExactRational>& residual :
       diagnostics->exact_auxiliary_residuals) {
    append_optional_rational(output, residual);
  }
  append_optional_floating(output,
                           diagnostics->reciprocal_condition_estimate);
  append_optional_floating(output,
                           diagnostics->condition_warning_threshold);
  output.push_back(diagnostics->condition_warning ? std::byte{1}
                                                   : std::byte{0});
  append_text(output, diagnostics->method);
}

void append_temporal_budget(std::vector<std::byte>& output,
                            const TemporalBudgetReportV1& budget) {
  append_u64(output, static_cast<std::uint64_t>(budget.requested_horizon));
  append_u64(output, static_cast<std::uint64_t>(budget.state_count));
  append_u64(output, static_cast<std::uint64_t>(budget.row_atom_count));
  append_u64(output, static_cast<std::uint64_t>(budget.iterations));
  append_optional_size(output, budget.maximum_states);
  append_optional_size(output, budget.maximum_row_atoms);
  append_optional_size(output, budget.maximum_iterations);
  append_optional_natural(output, budget.authored_maximum_iterations);
  append_rational(output, budget.absolute_residual_tolerance);
  append_rational(output, budget.relative_residual_tolerance);
  output.push_back(budget.budget_stop ? std::byte{1} : std::byte{0});
}

// ResultProbabilityLawV1 cannot distinguish a finite-horizon survivor tail
// from proved physical defect. Retain the complete exact public C22 result in
// one versioned canonical carrier rather than relabeling unresolved survival.
[[nodiscard]] ResultCanonicalValueV1 canonical_stopped_bundle(
    const StoppedMetricBundle& stopped) {
  std::vector<std::byte> canonical;
  append_bytes(canonical, stopped.source_fingerprint.bytes());
  canonical.push_back(static_cast<std::byte>(
      static_cast<std::uint8_t>(stopped.initial_law_kind)));
  append_u64(canonical,
             static_cast<std::uint64_t>(stopped.survival_tails.size()));
  for (const SurvivalTailV1& tail : stopped.survival_tails) {
    append_natural(canonical, tail.index);
    append_rational(canonical, tail.exact_probability);
  }
  append_u64(canonical,
             static_cast<std::uint64_t>(stopped.absorption_masses.size()));
  for (const TypedAbsorptionMassV1& mass : stopped.absorption_masses) {
    append_natural(canonical, mass.hitting_time);
    append_text(canonical, mass.type_id);
    append_rational(canonical, mass.exact_probability);
  }
  append_u64(canonical, static_cast<std::uint64_t>(
                            stopped.eventual_typed_exit_probabilities.size()));
  for (const EventualTypedExitProbabilityV1& exit :
       stopped.eventual_typed_exit_probabilities) {
    append_text(canonical, exit.type_id);
    append_rational(canonical, exit.exact_probability);
  }
  append_rational(canonical, stopped.exact_defect_probability);
  canonical.push_back(static_cast<std::byte>(
      static_cast<std::uint8_t>(stopped.absorption_status)));
  canonical.push_back(static_cast<std::byte>(
      static_cast<std::uint8_t>(stopped.mean_stopping_time.status)));
  canonical.push_back(stopped.mean_stopping_time.exact_value.has_value()
                          ? std::byte{1}
                          : std::byte{0});
  if (stopped.mean_stopping_time.exact_value) {
    append_rational(canonical, *stopped.mean_stopping_time.exact_value);
  }
  append_temporal_budget(canonical, stopped.budget);
  canonical.push_back(stopped.finite_results_preserved_when_mean_unavailable
                          ? std::byte{1}
                          : std::byte{0});
  append_stopped_solve_diagnostics(
      canonical, stopped.typed_exit_defect_solve_diagnostics);
  append_stopped_solve_diagnostics(
      canonical, stopped.potential_solve_diagnostics);
  return ResultCanonicalValueV1{
      CodecIdentityV1{"mwperf.c27.stopped-metric-bundle", 1U},
      std::move(canonical)};
}

struct StoppedDiagnosticRefsV1 final {
  std::vector<std::string> residual_refs;
  std::vector<std::string> error_refs;
};

[[nodiscard]] std::string optional_size_text(
    const std::optional<std::size_t>& value) {
  return value ? std::to_string(*value) : std::string("unbounded");
}

[[nodiscard]] std::vector<std::string> stopped_solve_notes(
    const StoppedSolveDiagnosticsV1& solve) {
  std::vector<std::string> notes{
      "status=" +
          std::to_string(static_cast<std::uint8_t>(solve.status)),
      "iterations=" + std::to_string(solve.iterations),
      "system_dimension=" +
          (solve.system_dimension ? std::to_string(*solve.system_dimension)
                                  : std::string("not_applicable")),
      "exact_rank=" +
          (solve.exact_rank ? std::to_string(*solve.exact_rank)
                            : std::string("not_applicable")),
      "reciprocal_condition_estimate=" +
          (solve.reciprocal_condition_estimate
               ? floating_text(*solve.reciprocal_condition_estimate)
               : std::string("unavailable")),
      "condition_warning_threshold=" +
          (solve.condition_warning_threshold
               ? floating_text(*solve.condition_warning_threshold)
               : std::string("unavailable")),
      solve.condition_warning ? "condition_warning=true"
                              : "condition_warning=false",
      "method=" + solve.method,
      "equation_residual_count=" +
          std::to_string(solve.exact_equation_residuals.size()),
      "auxiliary_residual_count=" +
          std::to_string(solve.exact_auxiliary_residuals.size())};
  for (std::size_t index = 0U;
       index < solve.exact_equation_residuals.size(); ++index) {
    const std::optional<ExactRational>& residual =
        solve.exact_equation_residuals[index];
    notes.push_back(
        "equation_residual[" + std::to_string(index) + "]=" +
        (residual ? exact_text(*residual)
                  : std::string("not_applicable")));
  }
  for (std::size_t index = 0U;
       index < solve.exact_auxiliary_residuals.size(); ++index) {
    const std::optional<ExactRational>& residual =
        solve.exact_auxiliary_residuals[index];
    notes.push_back(
        "auxiliary_residual[" + std::to_string(index) + "]=" +
        (residual ? exact_text(*residual)
                  : std::string("not_applicable")));
  }
  return notes;
}

[[nodiscard]] StoppedDiagnosticRefsV1 append_stopped_backend_diagnostics(
    std::string prefix, const StoppedMetricBundle& stopped,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  StoppedDiagnosticRefsV1 refs;
  refs.error_refs.push_back(prefix);
  diagnostics.push_back(ResultDiagnosticV1{
      prefix,
      DiagnosticCategory::information,
      "c27.c22.stopped_metric_status",
      "C22 exact stopped-law status, retained mass classification, and temporal budget",
      component_scope_from_ordinal(7U),
      stopped.budget.budget_stop
          ? ResultDiagnosticKindV1::budget_termination
          : ResultDiagnosticKindV1::truncation_tail,
      std::nullopt, std::nullopt,
      {"absorption_status=" +
           std::to_string(static_cast<std::uint8_t>(
               stopped.absorption_status)),
       "mean_status=" +
           std::to_string(static_cast<std::uint8_t>(
               stopped.mean_stopping_time.status)),
       "mean_exact_value=" +
           (stopped.mean_stopping_time.exact_value
                ? exact_text(*stopped.mean_stopping_time.exact_value)
                : std::string("absent")),
       "exact_defect_probability=" +
           exact_text(stopped.exact_defect_probability),
       "survival_tail_count=" +
           std::to_string(stopped.survival_tails.size()),
       "absorption_mass_count=" +
           std::to_string(stopped.absorption_masses.size()),
       "eventual_typed_exit_count=" +
           std::to_string(
               stopped.eventual_typed_exit_probabilities.size()),
       "requested_horizon=" +
           std::to_string(stopped.budget.requested_horizon),
       "state_count=" + std::to_string(stopped.budget.state_count),
       "row_atom_count=" +
           std::to_string(stopped.budget.row_atom_count),
       "iterations=" + std::to_string(stopped.budget.iterations),
       "maximum_states=" +
           optional_size_text(stopped.budget.maximum_states),
       "maximum_row_atoms=" +
           optional_size_text(stopped.budget.maximum_row_atoms),
       "maximum_iterations=" +
           optional_size_text(stopped.budget.maximum_iterations),
       "authored_maximum_iterations=" +
           (stopped.budget.authored_maximum_iterations
                ? stopped.budget.authored_maximum_iterations
                      ->to_decimal_string()
                : std::string("unbounded")),
       "absolute_residual_tolerance=" +
           exact_text(stopped.budget.absolute_residual_tolerance),
       "relative_residual_tolerance=" +
           exact_text(stopped.budget.relative_residual_tolerance),
       stopped.budget.budget_stop ? "budget_stop=true"
                                  : "budget_stop=false",
       stopped.finite_results_preserved_when_mean_unavailable
           ? "finite_results_preserved_when_mean_unavailable=true"
           : "finite_results_preserved_when_mean_unavailable=false",
       stopped.typed_exit_defect_solve_diagnostics
           ? "typed_exit_defect_solve_present=true"
           : "typed_exit_defect_solve_present=false",
       stopped.potential_solve_diagnostics
           ? "potential_solve_present=true"
           : "potential_solve_present=false"},
      {}});

  const auto append_solve = [&](const std::string_view suffix,
                                const std::string_view code,
                                const std::string_view message,
                                const std::optional<StoppedSolveDiagnosticsV1>&
                                    solve) {
    if (!solve) return;
    const std::string id = prefix + "." + std::string(suffix);
    if (solve->status == StoppedSolveStatusV1::established) {
      refs.residual_refs.push_back(id);
    } else {
      refs.error_refs.push_back(id);
    }
    diagnostics.push_back(ResultDiagnosticV1{
        id, DiagnosticCategory::information, std::string(code),
        std::string(message), component_scope_from_ordinal(7U),
        solve->status == StoppedSolveStatusV1::budget_stopped
            ? ResultDiagnosticKindV1::budget_termination
            : ResultDiagnosticKindV1::stationary_residual,
        std::nullopt,
        std::nullopt, stopped_solve_notes(*solve), {}});
  };
  append_solve("typed_exit_defect_solve",
               "c27.c22.typed_exit_defect_solve",
               "C22 typed-exit and defect solve diagnostics",
               stopped.typed_exit_defect_solve_diagnostics);
  append_solve("potential_solve", "c27.c22.potential_solve",
               "C22 stopped-potential solve diagnostics",
               stopped.potential_solve_diagnostics);
  return refs;
}

[[nodiscard]] StoppedDiagnosticRefsV1 append_stopped_backend_diagnostics(
    const PlannedMetricV1& metric, const StoppedMetricBundle& stopped,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  return append_stopped_backend_diagnostics(
      "c27.c22.stopped." +
          metric_request_header(metric.request()).metric_id,
      stopped, diagnostics);
}

struct TemporalRepresentationUsageV1 final {
  std::size_t actual_state_count;
  std::size_t actual_maximum_row_atoms;
};

void append_stopped_iteration_budget(
    std::string prefix, const TemporalBudgetReportV1& budget,
    const TemporalRepresentationUsageV1 usage,
    std::vector<ResultBudgetUsageV1>& backend_budgets) {
  // Result-v1 requires every applicable usage row to carry a finite authored
  // grant. Omitted caps are genuinely unbounded and remain represented in the
  // stopped diagnostic and canonical carrier rather than by invented grants.
  if (budget.maximum_states) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        prefix + ".stopped_states",
        ResultBudgetApplicabilityV1::applicable,
        BigNat{*budget.maximum_states}, BigNat{usage.actual_state_count},
        "states"});
  }
  if (budget.maximum_row_atoms) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        prefix + ".stopped_row_atoms",
        ResultBudgetApplicabilityV1::applicable,
        BigNat{*budget.maximum_row_atoms},
        BigNat{usage.actual_maximum_row_atoms},
        "row_atoms"});
  }
  if (budget.authored_maximum_iterations) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        prefix + ".stopped_iterations",
        ResultBudgetApplicabilityV1::applicable,
        budget.authored_maximum_iterations,
        BigNat{budget.iterations},
        "iterations"});
  }
}

void append_stopped_iteration_budget(
    const PlannedMetricV1& metric, const TemporalBudgetReportV1& budget,
    const TemporalRepresentationUsageV1 usage,
    std::vector<ResultBudgetUsageV1>& backend_budgets) {
  append_stopped_iteration_budget(
      "backend." + metric_request_header(metric.request()).metric_id,
      budget, usage, backend_budgets);
}

void append_transient_metric_budget(
    const PlannedMetricV1& metric,
    const TemporalMetricBudgetReportV1& budget,
    const std::size_t actual_maximum_row_atoms,
    std::vector<ResultBudgetUsageV1>& backend_budgets) {
  const std::string prefix =
      "backend." + metric_request_header(metric.request()).metric_id;
  if (budget.maximum_states.has_value()) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        prefix + ".stopped_states",
        ResultBudgetApplicabilityV1::applicable,
        BigNat{*budget.maximum_states},
        BigNat{budget.actual_state_count}, "states"});
  }
  if (budget.maximum_row_atoms.has_value()) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        prefix + ".stopped_row_atoms",
        ResultBudgetApplicabilityV1::applicable,
        BigNat{*budget.maximum_row_atoms},
        BigNat{actual_maximum_row_atoms}, "row_atoms"});
  }
  if (budget.authored_maximum_solver_iterations.has_value()) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        prefix + ".stopped_iterations",
        ResultBudgetApplicabilityV1::applicable,
        budget.authored_maximum_solver_iterations,
        BigNat{budget.solver_iterations}, "iterations"});
  }
}

[[nodiscard]] BacklogRelationV1 backlog_relation(
    const HitSetKind kind) noexcept {
  switch (kind) {
    case HitSetKind::at_or_above:
      return BacklogRelationV1::at_or_above;
    case HitSetKind::at_or_below:
      return BacklogRelationV1::at_or_below;
    case HitSetKind::equal:
      return BacklogRelationV1::equal;
  }
  return BacklogRelationV1::equal;
}

[[nodiscard]] Result<TemporalEdgePredicateV1> gap_event_predicate(
    const GapEventKind event, const std::size_t target_ordinal) {
  switch (event) {
    case GapEventKind::departure:
      return Result<TemporalEdgePredicateV1>::success(
          TemporalEdgePredicateV1{
              TargetDeparturePredicateV1{target_ordinal, true}});
    case GapEventKind::admission:
      return Result<TemporalEdgePredicateV1>::success(
          TemporalEdgePredicateV1{
              PositiveTargetArrivalPredicateV1{target_ordinal}});
    case GapEventKind::busy_denial:
      return Result<TemporalEdgePredicateV1>::success(
          TemporalEdgePredicateV1{
              BusyDenialEdgePredicateV1{target_ordinal}});
  }
  return fail<TemporalEdgePredicateV1>(
      "c27.event_gap_predicate_invalid",
      "the accepted event-gap request has no closed event predicate");
}

[[nodiscard]] Result<ResultMetricV1> execute_stationary_stopped_metric(
    const ExecutionPlan& plan, const PlannedMetricV1& metric,
    const MetricSupportClauseV1& clause,
    const StationaryTemporalBackendV1& backend,
    const std::vector<std::string>& common_residual_refs,
    const std::vector<std::string>& common_error_refs,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& backend_budgets) {
  const MetricRequestHeader& header = metric_request_header(metric.request());
  if (header.ordered_targets.size() != 1U) {
    return fail<ResultMetricV1>(
        "c27.stopped_scalar_target_required",
        "the public C22 stopped adapter requires exactly one retained target");
  }
  auto target = retained_target_ordinal(plan,
                                        header.ordered_targets.front().queue_id);
  if (!target) return Result<ResultMetricV1>::failure(target.error());
  auto kernel = require_stationary_projection_slot(
      backend.projection.temporal_kernel(), "audited temporal kernel");
  if (!kernel) return Result<ResultMetricV1>::failure(kernel.error());
  auto policy = enumerated_solver_policy(plan);
  if (!policy) return Result<ResultMetricV1>::failure(policy.error());

  const MetricKindV1 kind = metric_request_kind(metric.request());
  if (kind == MetricKindV1::event_gap_distribution) {
    const auto& parameters =
        std::get<EventGapDistributionRequestV1>(metric.request())
            .parameters();
    auto predicate = gap_event_predicate(parameters.event, target.value());
    if (!predicate) {
      return Result<ResultMetricV1>::failure(predicate.error());
    }
    auto palm = construct_event_palm_law(
        backend.projection.temporal_law(),
        EventIndicator{"target-event-gap", "binary-event",
                       BinaryEventCountV1{predicate.value()}});
    if (!palm) return Result<ResultMetricV1>::failure(palm.error());
    auto killed = construct_killed_kernel(
        *kernel.value(), SafeSet{AnyStatePredicateV1{}},
        AbsorptionMarks{{TypedAbsorptionMarkV1{
            "next_event", AnyStatePredicateV1{}, predicate.value()}}});
    if (!killed) return Result<ResultMetricV1>::failure(killed.error());
    auto stopped = evaluate_hit_survival_absorption(
        killed.value(), palm.value().initial_law(),
        HorizonSpec{parameters.horizon, false, true}, policy.value());
    if (!stopped) return Result<ResultMetricV1>::failure(stopped.error());
    StoppedDiagnosticRefsV1 stopped_refs =
        append_stopped_backend_diagnostics(metric, stopped.value(),
                                           diagnostics);
    append_stopped_iteration_budget(
        metric, stopped.value().budget,
        TemporalRepresentationUsageV1{
            backend.actual_state_count,
            backend.actual_maximum_row_atoms},
        backend_budgets);
    auto identity = route_bound_law_identity(
        stopped.value().source_fingerprint, metric);
    if (!identity) return Result<ResultMetricV1>::failure(identity.error());
    std::vector<std::string> residual_refs = common_residual_refs;
    residual_refs.insert(residual_refs.end(),
                         stopped_refs.residual_refs.begin(),
                         stopped_refs.residual_refs.end());
    std::vector<std::string> error_refs = common_error_refs;
    error_refs.insert(error_refs.end(), stopped_refs.error_refs.begin(),
                      stopped_refs.error_refs.end());
    return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
        backend_metric_header(
            metric, clause, identity.value(),
            "C23 event-Palm entrance with C22 next-event stopping",
            std::move(residual_refs), std::move(error_refs),
            {"event_palm_entrance", "exact_future_event_predicate",
             "finite_horizon_survival_retained_explicitly"}),
        canonical_stopped_bundle(stopped.value())});
  }

  if (kind == MetricKindV1::first_hit) {
    const auto& parameters =
        std::get<FirstHitRequestV1>(metric.request()).parameters();
    auto initial = require_stationary_projection_slot(
        backend.projection.initial_law(), "stationary slot initial law");
    if (!initial) return Result<ResultMetricV1>::failure(initial.error());
    const TargetBacklogPredicateV1 hit{
        target.value(), backlog_relation(parameters.set.kind),
        parameters.set.level};
    auto killed = construct_killed_kernel(
        *kernel.value(),
        SafeSet{TargetBacklogOutsideHitSetPredicateV1{target.value(),
                                                      parameters.set}},
        AbsorptionMarks{{TypedAbsorptionMarkV1{
            "hit", hit, AnyEdgePredicateV1{}}}});
    if (!killed) return Result<ResultMetricV1>::failure(killed.error());
    auto stopped = evaluate_hit_survival_absorption(
        killed.value(), *initial.value(),
        HorizonSpec{parameters.horizon, parameters.include_mean, true},
        policy.value());
    if (!stopped) {
      if (stopped.error().code ==
          "c22.initial_law_not_supported_on_safe_set") {
        return fail<ResultMetricV1>(
            "c27.stationary_first_hit_entrance_not_outside_set",
            "the stationary slot entrance has positive mass in the requested hit set, while the public C22 stopped evaluator requires its initial law to be supported on the safe set",
            DiagnosticCategory::unavailable);
      }
      return Result<ResultMetricV1>::failure(stopped.error());
    }
    StoppedDiagnosticRefsV1 stopped_refs =
        append_stopped_backend_diagnostics(metric, stopped.value(),
                                           diagnostics);
    append_stopped_iteration_budget(
        metric, stopped.value().budget,
        TemporalRepresentationUsageV1{
            backend.actual_state_count,
            backend.actual_maximum_row_atoms},
        backend_budgets);
    if (parameters.include_mean &&
        (stopped.value().mean_stopping_time.status ==
             ExtendedNonnegativeStatusV1::not_established ||
         stopped.value().mean_stopping_time.status ==
             ExtendedNonnegativeStatusV1::numerically_unresolved)) {
      return fail<ResultMetricV1>(
          "c27.stationary_first_hit_mean_not_established",
          "C22 preserved the finite-horizon first-hit law but did not establish the separately requested infinite-horizon mean",
          DiagnosticCategory::unavailable);
    }
    auto identity = route_bound_law_identity(
        stopped.value().source_fingerprint, metric);
    if (!identity) return Result<ResultMetricV1>::failure(identity.error());
    std::vector<std::string> residual_refs = common_residual_refs;
    residual_refs.insert(residual_refs.end(),
                         stopped_refs.residual_refs.begin(),
                         stopped_refs.residual_refs.end());
    std::vector<std::string> error_refs = common_error_refs;
    error_refs.insert(error_refs.end(), stopped_refs.error_refs.begin(),
                      stopped_refs.error_refs.end());
    return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
        backend_metric_header(
            metric, clause, identity.value(),
            parameters.include_mean
                ? "C22 stationary-slot first-hit law with requested extended mean"
                : "C22 stationary-slot exact first-hit law",
            std::move(residual_refs), std::move(error_refs),
            {"stationary_slot_entrance", "exact_killed_kernel",
             parameters.include_mean
                 ? "finite_law_and_extended_mean_retained_together"
                 : "finite_horizon_survival_retained_explicitly"}),
        canonical_stopped_bundle(stopped.value())});
  }

  if (kind == MetricKindV1::binary_run_distribution) {
    return fail<ResultMetricV1>(
        "c27.run_start_palm_adapter_unavailable",
        "C23 exposes no production constructor for the required run-start Palm entrance; C27 will not substitute a typical stationary slot");
  }
  if (kind == MetricKindV1::threshold_excursion) {
    return fail<ResultMetricV1>(
        "c27.threshold_crossing_palm_adapter_unavailable",
        "C23 exposes no production constructor for the required threshold-crossing Palm entrance; C27 will not substitute a typical stationary slot");
  }
  if (kind == MetricKindV1::counterfactual_opportunity_gap) {
    return fail<ResultMetricV1>(
        "c27.counterfactual_mark_binding_unavailable",
        "the public C23 counterfactual Palm route requires the exact retained runtime mark identity, which C27 cannot infer from an equal-looking request");
  }
  return fail<ResultMetricV1>(
      "c27.stopped_metric_adapter_unavailable",
      "the accepted stopped/residence route has no mathematically equivalent public C22/C23 adapter");
}

[[nodiscard]] const FifoDelayOutputV1* fifo_delay_output(
    const MetricRequest& request) noexcept {
  if (const auto* plain = std::get_if<FifoDelayRequestV1>(&request)) {
    return &plain->parameters().output;
  }
  if (const auto* conditioned =
          std::get_if<FifoDelayConditionedRequestV1>(&request)) {
    return &conditioned->parameters().output;
  }
  return nullptr;
}

[[nodiscard]] std::optional<FifoConditionV1> fifo_delay_condition(
    const MetricRequest& request) {
  if (const auto* conditioned =
          std::get_if<FifoDelayConditionedRequestV1>(&request)) {
    return conditioned->parameters().condition;
  }
  return std::nullopt;
}

[[nodiscard]] Result<HorizonSpec> fifo_group_horizon(
    const ExecutionPlan& plan, const PlannedMetricV1& metric) {
  const MetricRequestHeader& requested =
      metric_request_header(metric.request());
  if (requested.ordered_targets.size() != 1U ||
      fifo_delay_output(metric.request()) == nullptr) {
    return fail<HorizonSpec>(
        "c27.fifo_scalar_request_required",
        "the public C23 FIFO evaluator requires one scalar FIFO-delay request");
  }
  const std::optional<FifoConditionV1> condition =
      fifo_delay_condition(metric.request());
  std::optional<BigNat> finite_horizon;
  bool include_mean = false;
  bool matched = false;
  for (const PlannedMetricV1& candidate : plan.metric_plans()) {
    if (candidate.route_kind() != BackendRouteKindV1::palm_or_fifo_law) {
      continue;
    }
    const MetricRequestHeader& header =
        metric_request_header(candidate.request());
    const FifoDelayOutputV1* output = fifo_delay_output(candidate.request());
    if (output == nullptr || header.ordered_targets.size() != 1U ||
        !(header.ordered_targets.front().queue_id ==
          requested.ordered_targets.front().queue_id) ||
        fifo_delay_condition(candidate.request()) != condition) {
      continue;
    }
    matched = true;
    std::visit(
        [&](const auto& typed) {
          using Output = std::remove_cvref_t<decltype(typed)>;
          if constexpr (std::same_as<Output, FifoDelayPmfOutputV1> ||
                        std::same_as<Output, FifoDelayTailOutputV1>) {
            if (!finite_horizon || *finite_horizon < typed.horizon) {
              finite_horizon = typed.horizon;
            }
          } else if constexpr (std::same_as<Output,
                                            FifoDelayMomentOutputV1>) {
            include_mean = true;
          }
        },
        *output);
  }
  if (!matched) {
    return fail<HorizonSpec>(
        "c27.fifo_authorization_group_missing",
        "the execution plan contains no accepted FIFO output in this entrance group");
  }
  return Result<HorizonSpec>::success(
      HorizonSpec{finite_horizon.value_or(BigNat{0U}), include_mean, true});
}

struct FifoDelayCacheEntryV1 final {
  ResolvedMetricTargetV1 target;
  std::optional<FifoConditionV1> condition;
  HorizonSpec horizon;
  MetricSelectionRegimeV1 selection_regime;
  MetricSolverRegimeV1 solver_regime;
  Digest256 sealed_temporal_source;
  DelayLaw distribution;
  StoppedDiagnosticRefsV1 stopped_diagnostic_refs;
  std::string shared_diagnostic_id;
};

[[nodiscard]] bool same_fifo_horizon(const HorizonSpec& left,
                                     const HorizonSpec& right) noexcept {
  return left.maximum_tail_index == right.maximum_tail_index &&
         left.include_infinite_horizon_mean ==
             right.include_infinite_horizon_mean &&
         left.include_eventual_typed_exit_probabilities ==
             right.include_eventual_typed_exit_probabilities;
}

[[nodiscard]] std::string fifo_condition_text(
    const std::optional<FifoConditionV1>& condition) {
  if (!condition) return "unconditioned";
  return std::visit(
      [](const auto& typed) {
        using Condition = std::remove_cvref_t<decltype(typed)>;
        if constexpr (std::same_as<Condition, FifoRankConditionV1>) {
          return std::string("rank=") +
                 typed.one_based_rank.to_decimal_string();
        } else if constexpr (std::same_as<Condition,
                                          FifoBatchConditionV1>) {
          return std::string("batch_size=") +
                 typed.batch_size.to_decimal_string();
        } else if constexpr (std::same_as<Condition,
                                          FifoClassConditionV1>) {
          return std::string("class=") + typed_label_text(typed.class_id);
        } else {
          return std::string("phase=") + typed_label_text(typed.phase_id);
        }
      },
      *condition);
}

[[nodiscard]] Result<std::size_t> load_fifo_delay_distribution(
    const ExecutionPlan& plan, const StationaryTemporalBackendV1& backend,
    const ResolvedMetricTargetV1& target,
    const std::optional<FifoConditionV1>& condition,
    const HorizonSpec& horizon,
    std::vector<FifoDelayCacheEntryV1>& cache,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& backend_budgets) {
  const MetricSelectionRegimeV1 selection = plan.selection_regime();
  const MetricSolverRegimeV1 solver = plan.solver_regime();
  const Digest256& temporal_source = backend.projection.fingerprint();
  for (std::size_t index = 0U; index < cache.size(); ++index) {
    const FifoDelayCacheEntryV1& entry = cache[index];
    if (entry.target == target && entry.condition == condition &&
        same_fifo_horizon(entry.horizon, horizon) &&
        entry.selection_regime == selection &&
        entry.solver_regime == solver &&
        entry.sealed_temporal_source == temporal_source) {
      return Result<std::size_t>::success(index);
    }
  }

  auto target_ordinal = retained_target_ordinal(plan, target.queue_id);
  if (!target_ordinal) {
    return Result<std::size_t>::failure(target_ordinal.error());
  }
  auto split = require_stationary_projection_slot(
      backend.projection.predictive_service_split(),
      "predictive service split");
  if (!split) return Result<std::size_t>::failure(split.error());
  auto service = require_stationary_projection_slot(
      backend.projection.temporal_service_kernel(),
      "temporal service kernel");
  if (!service) return Result<std::size_t>::failure(service.error());
  auto caps = temporal_representation_caps(plan);
  if (!caps) return Result<std::size_t>::failure(caps.error());
  auto admission = metrics::detail::construct_admission_palm_law_bounded(
      backend.projection.marked_edge(),
      ArrivalCountMark{
          target_ordinal.value(),
          AdmissionCountingSemanticsV1::retained_edge_packet_labels},
      caps.value().maximum_states);
  if (!admission) return Result<std::size_t>::failure(admission.error());
  auto lifted =
      lift_fifo_tag_state(admission.value().law, *split.value());
  if (!lifted) return Result<std::size_t>::failure(lifted.error());
  TagInitialLaw initial = lifted.value();
  if (condition && !initial.conditioning()) {
    auto conditioned = condition_tag_initial_law(initial, *condition);
    if (!conditioned) {
      return Result<std::size_t>::failure(conditioned.error());
    }
    initial = std::move(conditioned).value();
  }
  if (!condition && !initial.is_unconditioned_all_admissions()) {
    return fail<std::size_t>(
        "c27.fifo_unconditioned_entrance_unavailable",
        "the accepted FIFO group does not retain the all-admission Palm entrance");
  }
  auto policy = enumerated_solver_policy(plan);
  if (!policy) return Result<std::size_t>::failure(policy.error());
  auto evaluated = metrics::detail::evaluate_fifo_delay_distribution_bounded(
      initial, *service.value(), horizon, policy.value(),
      caps.value().maximum_states,
      caps.value().maximum_row_atoms);
  if (!evaluated) {
    return Result<std::size_t>::failure(evaluated.error());
  }
  auto bounded_distribution = std::move(evaluated).value();
  DelayLaw distribution = std::move(bounded_distribution.law);
  const TemporalRepresentationUsageV1 representation_usage{
      std::max({backend.actual_state_count,
                admission.value().actual_entrance_atoms,
                bounded_distribution.actual_state_count}),
      std::max(backend.actual_maximum_row_atoms,
               bounded_distribution.actual_maximum_row_atoms)};

  const std::size_t group_ordinal = cache.size();
  const std::string group = std::to_string(group_ordinal);
  const std::string stopped_prefix =
      "c27.c23.fifo_group." + group + ".stopped";
  StoppedDiagnosticRefsV1 stopped_refs =
      append_stopped_backend_diagnostics(
          stopped_prefix, distribution.stopped_backend_result(),
          diagnostics);
  append_stopped_iteration_budget(
      "backend.fifo_group." + group,
      distribution.stopped_backend_result().budget,
      representation_usage, backend_budgets);
  const std::string shared_diagnostic_id =
      "c27.c23.fifo_group." + group + ".shared_distribution";
  diagnostics.push_back(ResultDiagnosticV1{
      shared_diagnostic_id,
      DiagnosticCategory::information,
      "c27.c23.shared_fifo_distribution",
      "One immutable C23 FIFO delay distribution shared by its exact target, entrance, horizon, selection, solver, and sealed temporal source group",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::execution,
      std::nullopt,
      std::nullopt,
      {"target=" + typed_label_text(target.queue_id.label()),
       "target_dense_ordinal=" +
           std::to_string(target.dense_index.ordinal()),
       "condition=" + fifo_condition_text(condition),
       "maximum_tail_index=" + horizon.maximum_tail_index.to_decimal_string(),
       horizon.include_infinite_horizon_mean
           ? "include_infinite_horizon_mean=true"
           : "include_infinite_horizon_mean=false",
       horizon.include_eventual_typed_exit_probabilities
           ? "include_eventual_typed_exit_probabilities=true"
           : "include_eventual_typed_exit_probabilities=false",
       "selection_regime=" +
           std::to_string(static_cast<std::uint8_t>(selection)),
       "solver_regime=" +
           std::to_string(static_cast<std::uint8_t>(solver)),
       "sealed_temporal_source=" + temporal_source.hex(),
       "fifo_source=" + distribution.source_fingerprint().hex()},
      {}});
  cache.push_back(FifoDelayCacheEntryV1{
      target, condition, horizon, selection, solver, temporal_source,
      std::move(distribution), std::move(stopped_refs),
      shared_diagnostic_id});
  return Result<std::size_t>::success(group_ordinal);
}

[[nodiscard]] Result<ResultMetricValueV1> map_fifo_delay_value(
    const FifoDelayOutputV1& output, const DelayLaw& delay) {
  return std::visit(
      [&](const auto& typed) -> Result<ResultMetricValueV1> {
        using Output = std::remove_cvref_t<decltype(typed)>;
        if constexpr (std::same_as<Output, FifoDelayPmfOutputV1>) {
          ResultTableV1 table{{"sojourn_slots"}, {}};
          table.entries.reserve(delay.finite_pmf().size());
          for (const DelayMassV1& mass : delay.finite_pmf()) {
            if (mass.sojourn_slots > typed.horizon) continue;
            table.entries.push_back(ResultTableEntryV1{
                {TypedLabel::numeric(mass.sojourn_slots)},
                PortableScientificScalar::rational(mass.exact_probability)});
          }
          return Result<ResultMetricValueV1>::success(
              ResultMetricValueV1{std::move(table)});
        } else if constexpr (std::same_as<Output,
                                          FifoDelayTailOutputV1>) {
          ResultTableV1 table{{"completed_eligible_slots"}, {}};
          table.entries.reserve(delay.tails().size());
          for (const DelayTailV1& tail : delay.tails()) {
            if (tail.completed_eligible_slots > typed.horizon) continue;
            table.entries.push_back(ResultTableEntryV1{
                {TypedLabel::numeric(tail.completed_eligible_slots)},
                PortableScientificScalar::rational(
                    tail.exact_probability)});
          }
          return Result<ResultMetricValueV1>::success(
              ResultMetricValueV1{std::move(table)});
        } else if constexpr (std::same_as<Output,
                                          FifoDelayQuantileOutputV1>) {
          auto quantile = delay.quantile(typed.probability);
          if (!quantile) {
            return Result<ResultMetricValueV1>::failure(quantile.error());
          }
          if (quantile.value().status ==
              DelayQuantileStatusV1::beyond_defective_mass) {
            return Result<ResultMetricValueV1>::success(
                ResultMetricValueV1{PositiveInfinityV1{}});
          }
          if (quantile.value().status ==
                  DelayQuantileStatusV1::unresolved_horizon ||
              !quantile.value().sojourn_slots) {
            return fail<ResultMetricValueV1>(
                "c27.fifo_quantile_unresolved_horizon",
                "the accepted finite FIFO horizon does not establish the requested lower-inverse quantile",
                DiagnosticCategory::unavailable);
          }
          auto scalar = natural_scalar(*quantile.value().sojourn_slots);
          if (!scalar) {
            return Result<ResultMetricValueV1>::failure(scalar.error());
          }
          return Result<ResultMetricValueV1>::success(
              ResultMetricValueV1{std::move(scalar).value()});
        } else {
          auto moment = delay.moment(typed.order);
          if (!moment) {
            return Result<ResultMetricValueV1>::failure(moment.error());
          }
          if (moment.value().status ==
              DelayMomentStatusV1::positive_infinity) {
            return Result<ResultMetricValueV1>::success(
                ResultMetricValueV1{PositiveInfinityV1{}});
          }
          if (moment.value().status == DelayMomentStatusV1::unresolved ||
              !moment.value().exact_value) {
            return fail<ResultMetricValueV1>(
                "c27.fifo_moment_unresolved",
                "C23 did not establish the requested FIFO delay moment",
                DiagnosticCategory::unavailable);
          }
          return Result<ResultMetricValueV1>::success(ResultMetricValueV1{
              PortableScientificScalar::rational(
                  *moment.value().exact_value)});
        }
      },
      output);
}

void append_fifo_tail_status_diagnostic(
    const PlannedMetricV1& metric, const FifoDelayOutputV1& output,
    const DelayLaw& delay, std::vector<ResultDiagnosticV1>& diagnostics) {
  std::optional<BigNat> requested_horizon;
  std::visit(
      [&](const auto& typed) {
        using Output = std::remove_cvref_t<decltype(typed)>;
        if constexpr (std::same_as<Output, FifoDelayPmfOutputV1> ||
                      std::same_as<Output, FifoDelayTailOutputV1>) {
          requested_horizon = typed.horizon;
        }
      },
      output);

  ExactRational finite_tail =
      delay.tails().empty() ? ExactRational::one()
                            : delay.tails().back().exact_probability;
  if (requested_horizon) {
    const auto found = std::ranges::find_if(
        delay.tails(), [&](const DelayTailV1& tail) {
          return tail.completed_eligible_slots == *requested_horizon;
        });
    if (found != delay.tails().end()) {
      finite_tail = found->exact_probability;
    }
  }
  ExactRational unresolved = finite_tail;
  if (delay.absorption_status() != AbsorptionStatusV1::not_established) {
    unresolved = finite_tail - delay.proven_defective_mass();
  }
  diagnostics.push_back(ResultDiagnosticV1{
      "c27.c23." + metric_request_header(metric.request()).metric_id +
          ".tail_status",
      DiagnosticCategory::information,
      "c27.c23.fifo_tail_status",
      "C23 FIFO finite-horizon survivor, unresolved tail, and proved defect classification",
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::truncation_tail, std::nullopt, std::nullopt,
      {"finite_horizon_survivor_mass=" + exact_text(finite_tail),
       "unresolved_tail_mass=" + exact_text(unresolved),
       "proven_defective_mass=" +
           exact_text(delay.proven_defective_mass()),
       "absorption_status=" +
           std::to_string(
               static_cast<std::uint8_t>(delay.absorption_status()))},
      {}});
}

[[nodiscard]] std::string append_fifo_coefficient_diagnostic(
    const PlannedMetricV1& metric, const DelayLaw& delay,
    std::vector<ResultDiagnosticV1>& diagnostics) {
  const std::string id =
      "c27.c23." + metric_request_header(metric.request()).metric_id +
      ".coefficient_crosscheck";
  const DelayLawDiagnosticsV1& source = delay.diagnostics();
  std::vector<std::string> notes{
      source.coefficient_crosscheck_performed
          ? "coefficient_crosscheck_performed=true"
          : "coefficient_crosscheck_performed=false",
      source.coefficient_crosscheck_exact
          ? "coefficient_crosscheck_exact=true"
          : "coefficient_crosscheck_exact=false",
      "lifted_state_count=" + std::to_string(source.lifted_state_count),
      "lifted_row_atom_count=" +
          std::to_string(source.lifted_row_atom_count),
      "maximum_initial_rank=" +
          std::to_string(source.maximum_initial_rank),
      "requested_horizon=" + std::to_string(source.requested_horizon),
      source.conditioned_entrance ? "conditioned_entrance=true"
                                  : "conditioned_entrance=false",
      "timing_convention=" + source.timing_convention};
  DiagnosticCategory category = DiagnosticCategory::information;
  std::string code = "c27.c23.fifo_coefficient_crosscheck";
  std::string message =
      "C23 optional FIFO coefficient propagation cross-check";
  if (source.coefficient_crosscheck_diagnostic) {
    const Diagnostic& diagnostic =
        *source.coefficient_crosscheck_diagnostic;
    category = diagnostic.category;
    code = diagnostic.code;
    message = diagnostic.message;
    if (diagnostic.authored_path) {
      notes.push_back("authored_path=" + *diagnostic.authored_path);
    }
    if (diagnostic.json_pointer) {
      notes.push_back("json_pointer=" + *diagnostic.json_pointer);
    }
    notes.insert(notes.end(), diagnostic.notes.begin(),
                 diagnostic.notes.end());
  }
  diagnostics.push_back(ResultDiagnosticV1{
      id, category, std::move(code), std::move(message),
      component_scope_from_ordinal(7U),
      ResultDiagnosticKindV1::numerical_conditioning, std::nullopt,
      std::nullopt, std::move(notes), {}});
  return id;
}

[[nodiscard]] Result<ResultMetricV1> execute_fifo_delay_metric(
    const ExecutionPlan& plan, const PlannedMetricV1& metric,
    const MetricSupportClauseV1& clause,
    const StationaryTemporalBackendV1& backend,
    const std::vector<std::string>& common_residual_refs,
    const std::vector<std::string>& common_error_refs,
    std::vector<ResultDiagnosticV1>& diagnostics,
    std::vector<ResultBudgetUsageV1>& backend_budgets,
    std::vector<FifoDelayCacheEntryV1>& fifo_cache) {
  const MetricRequestHeader& header = metric_request_header(metric.request());
  const FifoDelayOutputV1* output = fifo_delay_output(metric.request());
  if (header.ordered_targets.size() != 1U || output == nullptr) {
    return fail<ResultMetricV1>(
        "c27.fifo_scalar_request_required",
        "the public C23 FIFO evaluator cannot establish a coupled joint-delay request");
  }
  const std::optional<FifoConditionV1> condition =
      fifo_delay_condition(metric.request());
  auto horizon = fifo_group_horizon(plan, metric);
  if (!horizon) return Result<ResultMetricV1>::failure(horizon.error());
  auto cached = load_fifo_delay_distribution(
      plan, backend, header.ordered_targets.front(), condition,
      horizon.value(), fifo_cache, diagnostics, backend_budgets);
  if (!cached) return Result<ResultMetricV1>::failure(cached.error());
  const FifoDelayCacheEntryV1& cache_entry = fifo_cache[cached.value()];
  const DelayLaw& delay = cache_entry.distribution;

  const std::string diagnostic_prefix =
      "c27.c23." + header.metric_id;
  diagnostics.push_back(exact_residual_diagnostic(
      diagnostic_prefix + ".entrance_residual",
      "c27.c23.fifo_entrance_residual",
      "C23 exact FIFO Palm entrance normalization residual",
      delay.diagnostics().exact_entrance_mass_residual));
  diagnostics.push_back(exact_residual_diagnostic(
      diagnostic_prefix + ".killed_row_residual",
      "c27.c23.fifo_killed_row_residual",
      "C23 maximum exact passive-tag killed-row residual",
      delay.diagnostics().exact_maximum_killed_row_residual));
  const std::string coefficient_diagnostic_id =
      append_fifo_coefficient_diagnostic(metric, delay, diagnostics);
  append_fifo_tail_status_diagnostic(metric, *output, delay,
                                     diagnostics);
  std::optional<std::string> little_diagnostic_id;
  bool little_is_residual = false;
  if (delay.is_unconditioned_all_admissions()) {
    little_diagnostic_id = diagnostic_prefix + ".little_identity";
    Diagnostic little =
        verify_little_identity(delay.stationary_queue_law(),
                               delay.admission_rate(), delay);
    little_is_residual =
        little.category == DiagnosticCategory::information;
    diagnostics.push_back(
        execution_diagnostic(*little_diagnostic_id, little));
    if (little.category != DiagnosticCategory::information &&
        little.category != DiagnosticCategory::unavailable) {
      return Result<ResultMetricV1>::failure(std::move(little));
    }
  }

  auto value = map_fifo_delay_value(*output, delay);
  if (!value) return Result<ResultMetricV1>::failure(value.error());
  auto identity = route_bound_law_identity(
      delay.projection_fingerprint(), metric);
  if (!identity) return Result<ResultMetricV1>::failure(identity.error());
  std::vector<std::string> assumptions{
      "admission_palm_packet_size_biasing",
      "retained_within_batch_rank",
      "passive_global_fifo_tag",
      "early_service_late_admission"};
  if (condition) assumptions.push_back("exact_conditioned_palm_entrance");
  std::vector<std::string> residual_refs = common_residual_refs;
  residual_refs.push_back(diagnostic_prefix + ".entrance_residual");
  residual_refs.push_back(diagnostic_prefix + ".killed_row_residual");
  residual_refs.insert(residual_refs.end(),
                       cache_entry.stopped_diagnostic_refs.residual_refs.begin(),
                       cache_entry.stopped_diagnostic_refs.residual_refs.end());
  std::vector<std::string> error_refs = common_error_refs;
  error_refs.insert(error_refs.end(),
                    cache_entry.stopped_diagnostic_refs.error_refs.begin(),
                    cache_entry.stopped_diagnostic_refs.error_refs.end());
  error_refs.push_back(cache_entry.shared_diagnostic_id);
  error_refs.push_back(diagnostic_prefix + ".tail_status");
  error_refs.push_back(coefficient_diagnostic_id);
  if (little_diagnostic_id) {
    if (little_is_residual) {
      residual_refs.push_back(*little_diagnostic_id);
    } else {
      error_refs.push_back(*little_diagnostic_id);
    }
  }
  return Result<ResultMetricV1>::success(EstablishedResultMetricV1{
      backend_metric_header(
          metric, clause, identity.value(),
          "C23 exact admission-Palm passive FIFO delay",
          std::move(residual_refs), std::move(error_refs),
          std::move(assumptions)),
      std::move(value).value()});
}

}  // namespace

#if defined(MWPERF_C27_TEST_SEAMS)
namespace testing {

bool is_permitted_backend_scientific_unavailability(
    const Diagnostic& diagnostic) noexcept {
  return is_permitted_scientific_unavailability(diagnostic);
}

}  // namespace testing
#endif

AnalysisBundle execute_analysis(const ExecutionPlan& plan) {
  return detail::execute_analysis_from(plan, std::chrono::steady_clock::now());
}

namespace detail {

AnalysisBundle execute_analysis_from(
    const ExecutionPlan& plan,
    const std::chrono::steady_clock::time_point invocation_started_at) {
  using WallClock = std::chrono::steady_clock;
  std::chrono::nanoseconds sampler_wall_time{0};
  const auto wall_clock_times = [&]() -> AnalysisWallClockTimesV1 {
    const auto end_to_end = std::chrono::duration_cast<std::chrono::nanoseconds>(
        WallClock::now() - invocation_started_at);
    return AnalysisWallClockTimesV1{
        end_to_end, sampler_wall_time,
        end_to_end >= sampler_wall_time ? end_to_end - sampler_wall_time
                                        : std::chrono::nanoseconds{0}};
  };
  AnalysisExecutionIdentityV1 identity = plan_identity(plan);
  std::optional<CommonBuildReportV1> build_report;
  std::optional<AnalysisResponseCurveV1> response_curve;
  std::optional<ResultUnavailableDiagnosticsV1>
      k_wide_unavailable_diagnostics;
  std::vector<ResultMetricV1> metrics;
  std::vector<ResultCertificateV1> certificates;
  std::vector<ResultDiagnosticV1> diagnostics;
  std::vector<ResultBudgetUsageV1> execution_budgets;
  std::vector<ResultBudgetUsageV1> backend_budgets;
  std::vector<ResultReplayStreamV1> replay_streams;
  std::shared_ptr<const ValidatedConstructionObservationBundleV1>
      diagnostic_observation;
  std::shared_ptr<const CompressionAnalysisResultV1> diagnostic_analysis;
  std::optional<Diagnostic> diagnostic_analysis_failure;
  CompressionAnalysisOptionsV1 diagnostic_analysis_options;
  AnalysisProviderSuppliedProfileV2 diagnostic_provider_profile{
      AnalysisProviderSuppliedProfileStatusV2::not_reached, std::nullopt,
      std::nullopt};
  AnalysisDecoderProfileV2 diagnostic_decoder{
      AnalysisDecoderProfileStatusV2::not_reached, std::nullopt,
      std::nullopt};
  std::optional<Digest256> provider_result_digest;
  std::optional<OptimizerCallLedgerObserver> optimizer_accounting_observer;
  bool optimizer_accounting_finalized = false;
  bool inactive_optimizer_owner_permitted = false;
  BigNat optimizer_calls_observed{0U};
  BigNat optimizer_search_states_observed{0U};
  append_input_normalization_diagnostics(plan.resolved_request(),
                                         diagnostics);

  const auto finalize_optimizer_accounting = [&]() -> Result<void> {
    if (!optimizer_accounting_observer.has_value() ||
        optimizer_accounting_finalized) {
      return Result<void>::success();
    }
    auto accounting = append_shared_optimizer_accounting(
        plan, *optimizer_accounting_observer, build_report,
        inactive_optimizer_owner_permitted, diagnostics,
        execution_budgets, optimizer_calls_observed,
        optimizer_search_states_observed);
    optimizer_accounting_finalized = true;
    return accounting;
  };

  const auto freeze_diagnostic_supplement =
      [&](const ResultStatusV1 status,
          std::optional<ResultFailureStageV1> failure_stage,
          std::optional<std::string> code)
      -> std::shared_ptr<const AnalysisDiagnosticSupplementV2> {
    if (!diagnostic_observation) {
      return {};
    }
    return std::make_shared<const AnalysisDiagnosticSupplementV2>(
        diagnostic_observation, diagnostic_analysis,
        diagnostic_analysis_failure, diagnostic_provider_profile,
        diagnostic_decoder,
        AnalysisDiagnosticTerminalV2{status, std::move(failure_stage),
                                     std::move(code)},
        diagnostic_analysis_options, provider_result_digest);
  };

  const auto failed = [&](const ResultFailureStageV1 stage,
                          const Diagnostic& diagnostic) -> AnalysisBundle {
    std::vector<std::string> failure_refs;
    auto accounting = finalize_optimizer_accounting();
    if (!accounting) {
      const std::string accounting_id =
          "c27.execution." + std::to_string(diagnostics.size());
      diagnostics.push_back(
          execution_diagnostic(accounting_id, accounting.error()));
      failure_refs.push_back(accounting_id);
    }
    const std::string id =
        "c27.execution." + std::to_string(diagnostics.size());
    diagnostics.push_back(execution_diagnostic(id, diagnostic));
    failure_refs.push_back(id);
    metrics.clear();
    return AnalysisBundle(
        ResultStatusV1::failed,
        ResultFailureV1{stage, diagnostic.code, std::move(failure_refs)}, identity,
        build_report, std::nullopt, std::nullopt, {}, certificates, diagnostics,
        execution_budgets, backend_budgets, replay_streams,
        wall_clock_times(), optimizer_calls_observed,
        optimizer_search_states_observed,
        freeze_diagnostic_supplement(ResultStatusV1::failed, stage,
                                     diagnostic.code));
  };
  const auto append_unavailable_metric = [&]
      (const PlannedMetricV1& planned, std::string reason_code,
       std::vector<std::string> diagnostic_refs) -> Result<void> {
    const MetricRequestHeader& source =
        metric_request_header(planned.request());
    const MetricSupportClauseV1* clause =
        accepted_support_clause(plan, planned);
    if (clause == nullptr) {
      return Result<void>::failure(
          Diagnostic{DiagnosticCategory::internal,
                     "c27.accepted_support_clause_missing",
                     "the frozen metric route has no matching accepted support clause",
                     std::nullopt, std::nullopt, {}});
    }
    metrics.push_back(UnavailableResultMetricV1{
        ResultMetricHeaderV1{
            source.metric_id, source.kind, result_targets(source),
            std::string(metric_units(source.kind)),
            "requested law was not established",
            planned.contract().support_clause_digest,
            clause->result_scope,
            {"accepted_support_clause=" +
                 planned.contract().support_clause_digest.hex(),
             "no numeric placeholder was emitted"},
            {}, {}},
        std::move(reason_code), std::move(diagnostic_refs)});
    return Result<void>::success();
  };
  const auto wire_unavailable = [&]
      (const std::vector<UnavailableReasonV1>& reasons) -> AnalysisBundle {
    auto accounting = finalize_optimizer_accounting();
    if (!accounting) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    accounting.error());
    }
    if (reasons.empty()) {
      return failed(
          ResultFailureStageV1::build_contract_validation,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.surrogate_unavailable_without_reason",
                     "the validated provider Unavailable result retained no typed reasons",
                     std::nullopt, std::nullopt, {}});
    }

    std::vector<std::string> reason_ids;
    reason_ids.reserve(reasons.size());
    for (const UnavailableReasonV1& reason : reasons) {
      const std::string id =
          "c27.execution." + std::to_string(diagnostics.size());
      std::vector<std::string> notes{
          "provider_unavailable_reason_kind=" +
          std::string(unavailable_reason_kind_name(reason.kind))};
      if (reason.metric_clause_id) {
        notes.push_back("metric_clause_id.metric_id=" +
                        reason.metric_clause_id->metric_id);
        notes.push_back(
            "metric_clause_id.authored_index=" +
            std::to_string(reason.metric_clause_id->authored_index));
      }
      if (reason.subject) {
        notes.push_back("subject.object_id=" +
                        typed_label_text(reason.subject->object_id));
        notes.push_back("subject.object_digest=" +
                        reason.subject->object_digest.hex());
      }
      diagnostics.push_back(execution_diagnostic(
          id, DiagnosticCategory::unavailable, reason.code,
          reason.message, std::move(notes)));
      reason_ids.push_back(id);
      if (k_wide_unavailable_diagnostics) {
        k_wide_unavailable_diagnostics->causes.push_back(
            ResultUnavailableCauseV1{
                reason.code, reason.message,
                reason.metric_clause_id
                    ? std::optional<std::string>{
                          reason.metric_clause_id->metric_id}
                    : std::nullopt});
      }
    }

    metrics.clear();
    for (const PlannedMetricV1& planned : plan.metric_plans()) {
      const UnavailableReasonV1* primary = nullptr;
      std::vector<std::string> diagnostic_refs;
      for (std::size_t index = 0U; index < reasons.size(); ++index) {
        const UnavailableReasonV1& reason = reasons[index];
        if (!reason.metric_clause_id ||
            *reason.metric_clause_id == planned.contract().clause_id) {
          if (primary == nullptr) primary = &reason;
          diagnostic_refs.push_back(reason_ids[index]);
        }
      }
      if (primary == nullptr) {
        return failed(
            ResultFailureStageV1::build_contract_validation,
            Diagnostic{DiagnosticCategory::internal,
                       "c27.surrogate_unavailable_clause_uncovered",
                       "the validated provider Unavailable reasons do not cover a frozen metric clause",
                       std::nullopt, std::nullopt, {}});
      }
      auto appended = append_unavailable_metric(
          planned, primary->code, std::move(diagnostic_refs));
      if (!appended) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      appended.error());
      }
    }
    return AnalysisBundle(ResultStatusV1::unavailable, std::nullopt, identity,
                          build_report, std::nullopt,
                          k_wide_unavailable_diagnostics, metrics, certificates,
                          diagnostics, execution_budgets, backend_budgets,
                          replay_streams, wall_clock_times(),
                          optimizer_calls_observed,
                          optimizer_search_states_observed,
                          freeze_diagnostic_supplement(
                              ResultStatusV1::unavailable, std::nullopt,
                              reasons.front().code));
  };
  const auto backend_unavailable = [&]
      (const std::size_t cause_index, std::string code,
       std::string message) -> AnalysisBundle {
    auto accounting = finalize_optimizer_accounting();
    if (!accounting) {
      return failed(ResultFailureStageV1::backend,
                    accounting.error());
    }
    if (cause_index >= plan.metric_plans().size()) {
      return failed(
          ResultFailureStageV1::backend,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.backend_unavailable_index_invalid",
                     "backend unavailability named a metric outside the frozen plan",
                     std::nullopt, std::nullopt, {}});
    }

    const PlannedMetricV1& cause = plan.metric_plans()[cause_index];
    const std::string cause_id =
        "c27.execution." + std::to_string(diagnostics.size());
    diagnostics.push_back(execution_diagnostic(
        cause_id, DiagnosticCategory::unavailable, code, message,
        {"metric_clause_id.metric_id=" + cause.contract().clause_id.metric_id,
         "metric_clause_id.authored_index=" +
             std::to_string(cause.contract().clause_id.authored_index)}));
    if (k_wide_unavailable_diagnostics) {
      k_wide_unavailable_diagnostics->causes.clear();
      k_wide_unavailable_diagnostics->causes.push_back(
          ResultUnavailableCauseV1{
              code, message, cause.contract().clause_id.metric_id});
    }

    constexpr std::string_view suppression_code =
        "c27.atomic_result_suppressed";
    std::optional<std::string> suppression_id;
    if (plan.metric_plans().size() > 1U) {
      suppression_id =
          "c27.execution." + std::to_string(diagnostics.size());
      diagnostics.push_back(execution_diagnostic(
          *suppression_id, DiagnosticCategory::unavailable,
          std::string(suppression_code),
          "the atomic analysis result suppressed this metric because another requested metric was unavailable",
          {"trigger_metric_id=" + cause.contract().clause_id.metric_id,
           "trigger_reason_code=" + code}));
    }

    metrics.clear();
    for (std::size_t index = 0U; index < plan.metric_plans().size();
         ++index) {
      const PlannedMetricV1& planned = plan.metric_plans()[index];
      const bool is_cause = index == cause_index;
      std::vector<std::string> diagnostic_refs;
      if (is_cause) {
        diagnostic_refs.push_back(cause_id);
      } else {
        diagnostic_refs.push_back(*suppression_id);
        diagnostic_refs.push_back(cause_id);
      }
      auto appended = append_unavailable_metric(
          planned,
          is_cause ? code : std::string(suppression_code),
          std::move(diagnostic_refs));
      if (!appended) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      appended.error());
      }
    }
    return AnalysisBundle(ResultStatusV1::unavailable, std::nullopt, identity,
                          build_report, std::nullopt,
                          k_wide_unavailable_diagnostics, metrics, certificates,
                          diagnostics, execution_budgets, backend_budgets,
                          replay_streams, wall_clock_times(),
                          optimizer_calls_observed,
                          optimizer_search_states_observed,
                          freeze_diagnostic_supplement(
                              ResultStatusV1::unavailable, std::nullopt,
                              code));
  };

  auto plan_valid = validate_execution_plan(plan);
  if (!plan_valid) {
    return failed(ResultFailureStageV1::request_construction,
                  plan_valid.error());
  }
  if (plan.preview().core.payload_class.tag ==
      PayloadClassTagV1::finite_prefix_constant_tail_response_v1) {
    if (!plan.preview().core.tail.boundary) {
      return failed(
          ResultFailureStageV1::request_construction,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.k_bin_tail_boundary_missing",
                     "the validated K-wide route has no constant-tail boundary",
                     std::nullopt, std::nullopt, {}});
    }
    auto cutoff = checked_subtract(*plan.preview().core.tail.boundary,
                                   BigNat{1U});
    if (!cutoff) {
      return failed(ResultFailureStageV1::request_construction,
                    cutoff.error());
    }
    k_wide_unavailable_diagnostics.emplace(
        ResultUnavailableDiagnosticsV1{std::move(cutoff).value(), {}, {},
                                       std::nullopt});
  }
  // C27 owns exactly one optimizer context for the complete post-plan
  // execution.  Create it before F-C15-03 and retain a read-only observer so
  // every later terminal path can report the same ledger even after mutable
  // ownership has moved into (or been destroyed with) the V0 candidate.
  auto optimizer = OptimizerExecutionContext::from_resolved_instance(
      plan.resolved_instance(), plan.work_bounds().optimizer_calls);
  if (!optimizer) {
    append_uncreated_optimizer_accounting(
        plan, diagnostics, execution_budgets);
    return failed(ResultFailureStageV1::request_construction,
                  optimizer.error());
  }
  optimizer_accounting_observer.emplace(
      optimizer.value().ledger_observer());
  auto request = make_surrogate_build_request(
      plan.provider_manifest(), plan.problem_view(),
      plan.capability_contract(), plan.validated_parameters(),
      plan.construction_budget(), plan.master_seed());
  if (!request) {
    return failed(ResultFailureStageV1::request_construction,
                  request.error());
  }
  identity.request_identity = AnalysisBuildRequestIdentityV1{
      request.value().build_identity_digest(), request.value().build_seed(),
      request.value().request_digest()};
  auto request_binding = artifact::detail::verify_request_bindings_v1(
      request.value(), plan.provider_manifest());
  if (!request_binding) {
    return failed(ResultFailureStageV1::build_contract_validation,
                  request_binding.error());
  }
  std::optional<BuilderArrivalServices> arrival_services;
  if (needs_process_local_arrival_service(request.value())) {
    auto services = make_builder_arrival_services(
        plan.compiled_arrival_law(),
        plan.problem_view().configured_arrival());
    if (!services) {
      return failed(ResultFailureStageV1::producer_execution,
                    services.error());
    }
    arrival_services = std::move(services).value();
  }
  std::optional<ConstructionExactQueryServices> exact_services;
  const auto& construction = request.value()
                                 .accepted_capability_contract()
                                 .construction_prerequisites;
  if (request.value().classifications().producer_mode ==
          ProducerModeV1::in_process_builder &&
      construction.required_optimizer_calls.has_value()) {
    const auto& grant = request.value().construction_budget()
                            .exact_optimizer_calls;
    if (grant.applicability != BudgetApplicabilityV1::applicable ||
        !grant.amount.has_value()) {
      return failed(
          ResultFailureStageV1::producer_execution,
          Diagnostic{DiagnosticCategory::input_validation,
                     "c27.construction_optimizer_grant_missing",
                     "the in-process exact-query prerequisite has no matching construction grant",
                     std::nullopt, std::nullopt, {}});
    }
    auto exact = detail::ConstructionExactQueryBindingAccess::bind(
        plan.resolved_instance(), request.value().build_identity_digest(),
        optimizer.value(), grant.amount);
    if (!exact) {
      return failed(ResultFailureStageV1::producer_execution, exact.error());
    }
    exact_services = std::move(exact).value();
  }
  auto workspace = ExecutionWorkspace::create(request.value().request_digest());
  if (!workspace) {
    return failed(ResultFailureStageV1::producer_execution,
                  workspace.error());
  }
  auto context = BuildExecutionContext::create(
      request.value(), plan.provider_manifest(), workspace.value()->path(),
      std::move(arrival_services), std::move(exact_services));
  if (!context) {
    return failed(ResultFailureStageV1::producer_execution,
                  context.error());
  }
  ProviderExecutionControlsV1 execution_controls;
  if (plan.registered_executable().has_value() &&
      plan.registered_executable()->maximum_worker_count().has_value()) {
    execution_controls.worker_count = static_cast<std::size_t>(
        plan.resolved_request().analyze().worker_count);
  }
  if (plan.registered_executable().has_value() &&
      plan.registered_executable()->maximum_wall_time_limit().has_value()) {
    execution_controls.wall_time_limit =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::seconds(
                plan.resolved_request().analyze().timeout_seconds));
  }
  const auto sampler_started_at = WallClock::now();
  ProviderExecutionOutcome outcome = execute_surrogate_provider(
      plan.provider(), request.value(), context.value(), execution_controls);
  sampler_wall_time += std::chrono::duration_cast<std::chrono::nanoseconds>(
      WallClock::now() - sampler_started_at);
  if (const auto* provider_failure =
          std::get_if<FailedProviderExecution>(&outcome)) {
    return failed(ResultFailureStageV1::producer_execution,
                  provider_failure->diagnostic);
  }
  const auto& completed = std::get<CompletedProviderExecution>(outcome);
  const std::uint32_t result_protocol_version =
      plan.provider().result_protocol_version();
  std::optional<SurrogateBuildResult> parsed_v1;
  std::optional<ParsedSurrogateResultFrameV2> parsed_v2;
  std::optional<ParsedSurrogateResultFrameV3> parsed_v3;
  std::optional<ValidatedSurrogateBuildReport> report;
  if (result_protocol_version == 1U) {
    auto parsed = parse_surrogate_build_result(
        completed.bytes, parse_limits(plan.provider_manifest()));
    if (!parsed) {
      return failed(ResultFailureStageV1::wire_parse, parsed.error());
    }
    parsed_v1.emplace(std::move(parsed).value());
    auto validated_report = validate_surrogate_build_report(
        *parsed_v1, request.value(), plan.construction_budget());
    if (!validated_report) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    validated_report.error());
    }
    report.emplace(std::move(validated_report).value());
  } else if (result_protocol_version == 2U) {
    const ObservationParseLimitsV1 observation_limits =
        default_observation_parse_limits_v1();
    auto parsed = parse_surrogate_build_result_v2(
        completed.bytes, parse_limits(plan.provider_manifest()),
        observation_limits);
    if (!parsed) {
      return failed(ResultFailureStageV1::wire_parse, parsed.error());
    }
    parsed_v2.emplace(std::move(parsed).value());
    auto digest = sha256_domain_separated(
        "mwperf.provider_result.v2",
        ByteSpan{completed.bytes.data(), completed.bytes.size()});
    if (!digest) {
      return failed(ResultFailureStageV1::wire_parse, digest.error());
    }
    provider_result_digest = std::move(digest).value();

    const bool observation_was_present =
        parsed_v2->envelope.observation.has_value();
    std::optional<ValidatedConstructionObservationBundleV1>
        validated_observation;
    if (observation_was_present) {
      auto observation = validate_construction_observation_envelope_v1(
          std::move(*parsed_v2->envelope.observation), observation_limits);
      if (!observation) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      observation.error());
      }
      validated_observation.emplace(std::move(observation).value());
    }
    const ObservationEnvelopeValidationContextV1 observation_context{
        parsed_v2->envelope,
        observation_was_present,
        parsed_v2->declared_kind,
        request.value(),
        plan.validated_parameters(),
        plan.resolved_instance(),
        plan.compiled_arrival_law()};
    auto provider_observation = validate_registered_observation_envelope(
        plan.provider(), observation_context,
        validated_observation ? &*validated_observation : nullptr);
    if (!provider_observation) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    provider_observation.error());
    }
    auto validated_report = validate_surrogate_build_report_v2(
        parsed_v2->envelope, parsed_v2->declared_kind, request.value(),
        plan.construction_budget());
    if (!validated_report) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    validated_report.error());
    }
    report.emplace(std::move(validated_report).value());

    // The diagnostic sidecar is trusted only after both pieces of the v2
    // common envelope have independently passed validation.  In particular,
    // an invalid common build report is a pre-envelope failure and must not
    // retain an otherwise well-formed observation on the terminal path.
    if (validated_observation) {
      diagnostic_observation =
          std::make_shared<const ValidatedConstructionObservationBundleV1>(
              std::move(*validated_observation));
      auto analysis = analyze_compression_observations_v1(
          *diagnostic_observation, CompressionAnalysisOptionsV1{});
      if (analysis) {
        diagnostic_analysis =
            std::make_shared<const CompressionAnalysisResultV1>(
                std::move(analysis).value());
      } else {
        diagnostic_analysis_failure = analysis.error();
      }
    }
  } else if (result_protocol_version == 3U) {
    const ObservationParseLimitsV1 observation_limits =
        default_observation_parse_limits_v1();
    auto parsed = parse_surrogate_build_result_v3(
        completed.bytes, parse_limits(plan.provider_manifest()),
        observation_limits);
    if (!parsed) {
      return failed(ResultFailureStageV1::wire_parse, parsed.error());
    }
    parsed_v3.emplace(std::move(parsed).value());
    auto digest = sha256_domain_separated(
        "mwperf.provider_result.v3",
        ByteSpan{completed.bytes.data(), completed.bytes.size()});
    if (!digest) {
      return failed(ResultFailureStageV1::wire_parse, digest.error());
    }
    provider_result_digest = std::move(digest).value();

    const bool observation_was_present =
        parsed_v3->envelope.observation.has_value();
    std::optional<ValidatedConstructionObservationBundleV1>
        validated_observation;
    if (observation_was_present) {
      auto observation = validate_construction_observation_envelope_v1(
          std::move(*parsed_v3->envelope.observation), observation_limits);
      if (!observation) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      observation.error());
      }
      validated_observation.emplace(std::move(observation).value());
    }
    const ObservationEnvelopeValidationContextV1 observation_context{
        parsed_v3->envelope,
        observation_was_present,
        parsed_v3->declared_kind,
        request.value(),
        plan.validated_parameters(),
        plan.resolved_instance(),
        plan.compiled_arrival_law()};
    auto provider_observation = validate_registered_observation_envelope(
        plan.provider(), observation_context,
        validated_observation ? &*validated_observation : nullptr);
    if (!provider_observation) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    provider_observation.error());
    }
    auto validated_report = validate_surrogate_build_report_v3(
        parsed_v3->envelope, parsed_v3->declared_kind, request.value(),
        plan.construction_budget());
    if (!validated_report) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    validated_report.error());
    }
    report.emplace(std::move(validated_report).value());

    // CP09 performs every cutoff projection after collection.  The retained
    // observation is one sparse physical record; changing a numerical cutoff
    // can therefore neither change nor duplicate the sampled profile.
    if (validated_observation) {
      diagnostic_observation =
          std::make_shared<const ValidatedConstructionObservationBundleV1>(
              std::move(*validated_observation));
      auto parameters = detail::full_orbit_cp09_analysis_parameters(
          plan.validated_parameters());
      if (!parameters) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      parameters.error());
      }
      FullOrbitCp09AnalysisParametersV1 analysis_parameters =
          std::move(parameters).value();
      diagnostic_analysis_options.cutoffs =
          std::move(analysis_parameters.projection_cutoffs);
      diagnostic_analysis_options.run_diagnostic_fits = false;
      diagnostic_analysis_options.projection_mode =
          CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response;
      diagnostic_analysis_options.ensemble_population_size =
          std::move(analysis_parameters.population_size);
      const std::uint64_t target_ordinal =
          diagnostic_observation->value().bindings.target.target_index;
      if (!std::in_range<std::size_t>(target_ordinal)) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      Diagnostic{DiagnosticCategory::input_validation,
                                 "c32.poisson_analysis_target_range",
                                 "the observed target ordinal exceeds the framework queue-catalog domain",
                                 std::nullopt, std::nullopt, {}});
      }
      auto dense_target = plan.resolved_instance().queues().index_at(
          static_cast<std::size_t>(target_ordinal));
      if (!dense_target) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      dense_target.error());
      }
      auto poisson_law = detail::full_orbit_cp09_poisson_target_law(
          plan.compiled_arrival_law(), dense_target.value());
      if (!poisson_law) {
        return failed(ResultFailureStageV1::build_contract_validation,
                      poisson_law.error());
      }
      if (poisson_law.value()) {
        std::vector<CompressionAnalysisOptionsV1::
                        PoissonOvershootComponentV1>
            components;
        components.reserve(poisson_law.value()->components.size());
        for (const auto& component : poisson_law.value()->components) {
          components.push_back({component.weight, component.component_rate,
                                component.operational_rate_bits});
        }
        BigInt tolerance_denominator = 1;
        for (std::size_t digit = 0U; digit < 45U; ++digit) {
          tolerance_denominator *= 10;
        }
        auto tolerance =
            ExactRational::make(BigInt{1}, tolerance_denominator);
        if (!tolerance) {
          return failed(ResultFailureStageV1::build_contract_validation,
                        tolerance.error());
        }
        // The certified recurrence stops when its exact enclosure meets the
        // tolerance.  Leave only the u64 work-counter carrier boundary; a
        // checkpoint-specific step quota must not change metric availability.
        diagnostic_analysis_options.poisson_overshoot =
            CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1{
                poisson_law.value()->descriptor_id,
                poisson_law.value()->descriptor_version,
                std::move(components),
                poisson_law.value()->operational_parameter_digest,
                poisson_law.value()->descriptor_digest,
                std::move(tolerance).value(),
                std::numeric_limits<std::uint64_t>::max()};
      }
      auto analysis = analyze_compression_observations_v1(
          *diagnostic_observation, diagnostic_analysis_options);
      if (analysis) {
        diagnostic_analysis =
            std::make_shared<const CompressionAnalysisResultV1>(
                std::move(analysis).value());
      } else {
        diagnostic_analysis_failure = analysis.error();
      }
    }
  } else {
    return failed(
        ResultFailureStageV1::build_contract_validation,
        Diagnostic{DiagnosticCategory::internal,
                   "c30.provider_result_protocol_unsupported",
                   "the selected provider registration has no supported "
                   "result protocol",
                   std::nullopt, std::nullopt,
                   {"result_protocol_version=" +
                    std::to_string(result_protocol_version)}});
  }

  build_report = report->value();
  execution_budgets =
      construction_budget_usage(plan.construction_budget(), build_report);
  auto local_optimizer_accounting = charge_local_reported_optimizer_calls(
      request.value().classifications().producer_mode, *build_report,
      optimizer.value());
  if (!local_optimizer_accounting) {
    return failed(ResultFailureStageV1::build_contract_validation,
                  local_optimizer_accounting.error());
  }
  auto in_process_optimizer_accounting =
      reconcile_in_process_optimizer_calls(
          request.value().classifications().producer_mode, *build_report,
          optimizer.value());
  if (!in_process_optimizer_accounting) {
    return failed(ResultFailureStageV1::build_contract_validation,
                  in_process_optimizer_accounting.error());
  }

  if (parsed_v2) {
    if (const auto* branch_failure =
            std::get_if<SurrogateResultBranchDecodeFailureV2>(
                &parsed_v2->branch_decode_outcome)) {
      diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
          AnalysisProviderSuppliedProfileStatusV2::rejected, std::nullopt,
          branch_failure->diagnostic.code};
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::rejected, std::nullopt,
          branch_failure->diagnostic.code};
      return failed(ResultFailureStageV1::wire_parse,
                    branch_failure->diagnostic);
    }
  }
  if (parsed_v3) {
    // Provider-result v3 never carries a deployable provider or decoder
    // profile.  This remains true when its authenticated terminal branch is
    // malformed: the branch itself failed to decode; no profile was rejected.
    diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
        AnalysisProviderSuppliedProfileStatusV2::not_applicable,
        std::nullopt, std::nullopt};
    diagnostic_decoder = AnalysisDecoderProfileV2{
        AnalysisDecoderProfileStatusV2::not_applicable, std::nullopt,
        std::nullopt};
    if (const auto* branch_failure =
            std::get_if<SurrogateResultBranchDecodeFailureV3>(
                &parsed_v3->branch_decode_outcome)) {
      return failed(ResultFailureStageV1::wire_parse,
                    branch_failure->diagnostic);
    }

    const auto& branch = std::get<SurrogateBuildResultBranchV3>(
        parsed_v3->branch_decode_outcome);
    auto terminal_shape = validate_surrogate_build_terminal_v3(
        branch, plan.capability_contract());
    if (!terminal_shape) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    terminal_shape.error());
    }
    if (const auto* unavailable =
            std::get_if<UnavailableSurrogateResultBodyV2>(&branch)) {
      return wire_unavailable(unavailable->reasons);
    }
    if (const auto* provider_failed =
            std::get_if<FailedSurrogateResultBodyV2>(&branch)) {
      const ProviderFailureV1& failure = provider_failed->failure;
      return failed(
          ResultFailureStageV1::producer_execution,
          Diagnostic{provider_failure_category(failure.kind), failure.code,
                     failure.message, std::nullopt, std::nullopt,
                     {"provider_failure_kind=" +
                      std::string(provider_failure_kind_name(failure.kind))}});
    }
    if (!diagnostic_observation || !diagnostic_analysis ||
        diagnostic_analysis_failure.has_value()) {
      const Diagnostic analysis_failure =
          diagnostic_analysis_failure.value_or(Diagnostic{
              DiagnosticCategory::internal,
              "c32.observed_analysis_missing",
              "provider-result-v3 Observed did not establish its authenticated empirical finite-window analysis",
              std::nullopt, std::nullopt, {}});
      return failed(ResultFailureStageV1::build_contract_validation,
                    analysis_failure);
    }
    auto accounting = finalize_optimizer_accounting();
    if (!accounting) {
      return failed(ResultFailureStageV1::build_contract_validation,
                    accounting.error());
    }
    return AnalysisBundle(
        ResultStatusV1::success, std::nullopt, std::move(identity),
        std::move(build_report), std::nullopt, std::nullopt, {},
        std::move(certificates), std::move(diagnostics),
        std::move(execution_budgets), std::move(backend_budgets),
        std::move(replay_streams), wall_clock_times(),
        std::move(optimizer_calls_observed),
        std::move(optimizer_search_states_observed),
        freeze_diagnostic_supplement(ResultStatusV1::success, std::nullopt,
                                     std::nullopt));
  }

  auto validated = [&]() -> Result<ValidatedSurrogateBuildResult> {
    if (parsed_v1) {
      return validate_surrogate_build_result(
          *parsed_v1, request.value(), plan.provider_manifest(),
          plan.capability_contract(), *report);
    }
    return validate_surrogate_build_result_v2(
        parsed_v2->envelope,
        std::get<SurrogateBuildResultBranchV2>(
            parsed_v2->branch_decode_outcome),
        request.value(), plan.provider_manifest(),
        plan.capability_contract(), *report);
  }();
  if (!validated) {
    if (diagnostic_observation) {
      diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
          AnalysisProviderSuppliedProfileStatusV2::rejected, std::nullopt,
          validated.error().code};
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::rejected, std::nullopt,
          validated.error().code};
    }
    return failed(ResultFailureStageV1::build_contract_validation,
                  validated.error());
  }
  // Preserve the validated wire alternative as the typed origin of any
  // realized failure.  A provider-authored Failed code is free text and must
  // not be able to impersonate the framework-generated Built-contract
  // mismatch below merely by choosing the same spelling.
  const bool validated_built_result =
      std::holds_alternative<ValidatedBuiltResultV1>(
          validated.value().value());
  if (diagnostic_observation && !validated_built_result) {
    diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
        AnalysisProviderSuppliedProfileStatusV2::not_applicable,
        std::nullopt, std::nullopt};
    diagnostic_decoder = AnalysisDecoderProfileV2{
        AnalysisDecoderProfileStatusV2::not_applicable, std::nullopt,
        std::nullopt};
  }
  RealizedCapabilityReport realized = resolve_realized_metric_capabilities(
      validated.value(), plan.requirements());
  // Non-Built alternatives publish no surrogate artifact or derived metric
  // claim, so their already validated build report is the complete truthful
  // construction accounting.  Per-stream replay provenance remains mandatory
  // for Built artifacts and is checked against configured-generator usage
  // below.
  if (const auto* unavailable_result =
          std::get_if<RealizedUnavailableCapabilitiesV1>(&realized)) {
    return wire_unavailable(unavailable_result->reasons);
  }
  if (const auto* provider_failed =
          std::get_if<RealizedFailedCapabilitiesV1>(&realized)) {
    const ProviderFailureV1& failure = provider_failed->failure;
    const ResultFailureStageV1 stage =
        validated_built_result
            ? ResultFailureStageV1::build_contract_validation
            : ResultFailureStageV1::producer_execution;
    if (diagnostic_observation && validated_built_result) {
      diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
          AnalysisProviderSuppliedProfileStatusV2::rejected, std::nullopt,
          failure.code};
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::rejected, std::nullopt,
          failure.code};
    }
    return failed(
        stage,
        Diagnostic{provider_failure_category(failure.kind), failure.code,
                   failure.message, std::nullopt, std::nullopt,
                   {"provider_failure_kind=" +
                    std::string(provider_failure_kind_name(failure.kind))}});
  }
  auto built =
      std::get<RealizedBuiltCapabilitiesV1>(std::move(realized));
  const SurrogateArtifactV1& built_artifact = built.artifact.value();
  std::vector<SeedStreamCountV1> construction_replay_streams =
      built_artifact.provenance.seed_stream_counts;
  const bool full_orbit_aggregate_replay =
      construction_replay_streams.empty() &&
      build_report->configured_generator_draws.used != BigNat{0U} &&
      detail::is_full_orbit_1_1(built_artifact.provider) &&
      built_artifact.provider_scientific_contract_digest.hex() ==
          "4920a71e97a757cfcd998ab6ad012a23f31d69da917daa6ecfb715001f0bef7a" &&
      built_artifact.construction_method ==
          ConstructionMethodV1::sampled_offline &&
      built_artifact.producer_mode ==
          ProducerModeV1::local_executable_builder &&
      built_artifact.payload_class ==
          PayloadClassV1{PayloadClassTagV1::three_bin_scalar_response_v1,
                         1U} &&
      built_artifact.provenance.method_decisions ==
          std::vector<std::string>{"full_orbit_sampling_v1"} &&
      built_artifact.provenance.frozen_input_bank_id.has_value();
  if (full_orbit_aggregate_replay) {
    // CP06 seals its per-replication replay coordinates inside the registered
    // family-evidence body and reports their aggregate configured-generator
    // use in the validated C15 build report.  Project that already-validated
    // aggregate into result-v1's generic construction replay ledger.  This
    // neither mutates the C15 artifact nor changes any scientific value.
    construction_replay_streams.push_back(SeedStreamCountV1{
        StageTag::surrogate_build_final,
        *built_artifact.provenance.frozen_input_bank_id,
        build_report->configured_generator_draws.used});
    diagnostics.push_back(ResultDiagnosticV1{
        "c27.full_orbit.aggregate_replay_projection",
        DiagnosticCategory::information,
        "c27.full_orbit_aggregate_replay_projection",
        "CP06 aggregate construction draw accounting was projected into "
        "the generic result replay ledger",
        component_scope_from_ordinal(1U),
        ResultDiagnosticKindV1::execution,
        std::nullopt,
        std::nullopt,
        {"basis=validated_build_report+frozen_input_bank_id",
         "granularity=aggregate",
         "scientific_payload_unchanged=true"},
        {}});
  }
  BigNat construction_replay_draws{0U};
  for (const SeedStreamCountV1& stream : construction_replay_streams) {
    construction_replay_draws += stream.draw_count;
  }
  if (construction_replay_draws !=
      build_report->configured_generator_draws.used) {
    return failed(
        ResultFailureStageV1::build_contract_validation,
        Diagnostic{
            DiagnosticCategory::input_validation,
            "c27.construction_replay_draw_count_mismatch",
            "the Built artifact's construction replay streams do not sum "
            "to the validated configured-generator draw usage",
            std::nullopt,
            std::nullopt,
            {"replay_draw_sum=" +
                 construction_replay_draws.to_decimal_string(),
             "configured_generator_draws_used=" +
                 build_report->configured_generator_draws.used
                     .to_decimal_string()}});
  }
  const bool built_in_three_bin =
      built.artifact.value().payload_class.tag ==
      PayloadClassTagV1::three_bin_scalar_response_v1;
  const bool built_in_finite_prefix =
      built.artifact.value().payload_class.tag ==
      PayloadClassTagV1::finite_prefix_constant_tail_response_v1;
  identity.payload_digest = built.artifact.value().payload_digest;
  append_artifact_diagnostics(built.artifact.value(),
                              request.value().build_identity_digest(),
                              diagnostics);
  for (const SeedStreamCountV1& stream : construction_replay_streams) {
    replay_streams.push_back(ResultConstructionReplayStreamV1{
        stream.stage, stream.stream_instance_id, stream.draw_count});
  }

  identity.plug_kind = [&]() -> std::string {
    switch (built.artifact.value().payload_class.tag) {
      case PayloadClassTagV1::three_bin_scalar_response_v1:
        return "three_bin_scalar_response_v1";
      case PayloadClassTagV1::finite_prefix_constant_tail_response_v1:
        return "finite_prefix_constant_tail_response_v1";
      case PayloadClassTagV1::empirical_finite_window_response_v1:
        return "empirical_finite_window_response_v1";
      case PayloadClassTagV1::finite_parameter_analytic_data_v1:
        return "finite_parameter_analytic_data_v1";
      case PayloadClassTagV1::finite_law_tables_v1:
        return "finite_law_tables_v1";
      case PayloadClassTagV1::registered_runtime_recipe_v1:
        return "registered_runtime_recipe_v1";
      case PayloadClassTagV1::response_envelope_evidence_v1:
        return "response_envelope_evidence_v1";
      case PayloadClassTagV1::direct_metric_payload_v1:
        return "direct_metric_payload_v1";
    }
    return "unknown_portable_payload";
  }();
  if (diagnostic_observation) {
    const auto* finite_prefix =
        std::get_if<FinitePrefixConstantTailResponseV1>(
            &built_artifact.payload);
    if (finite_prefix == nullptr) {
      diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
          AnalysisProviderSuppliedProfileStatusV2::not_applicable,
          std::nullopt, std::nullopt};
    } else if (!provider_result_digest) {
      diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
          AnalysisProviderSuppliedProfileStatusV2::rejected, std::nullopt,
          "c30.provider_profile_provider_result_digest_missing"};
    } else {
      auto profile =
          provider_supplied_finite_prefix_profile(*finite_prefix);
      if (!profile) {
        diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
            AnalysisProviderSuppliedProfileStatusV2::rejected,
            std::nullopt, profile.error().code};
      } else {
        diagnostic_provider_profile = AnalysisProviderSuppliedProfileV2{
            AnalysisProviderSuppliedProfileStatusV2::available,
            std::move(profile).value(),
            std::nullopt,
            diagnostic_observation->digest(),
            *provider_result_digest,
            built_artifact.payload_digest};
      }
    }
  }
  auto payload = adapt_portable_payload(built.artifact);
  if (!payload) {
    if (diagnostic_observation) {
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::rejected, std::nullopt,
          payload.error().code};
    }
    return failed(ResultFailureStageV1::payload_adaptation,
                  payload.error());
  }
  if (diagnostic_observation) {
    const auto* finite_prefix =
        std::get_if<PortableFinitePrefixConstantTailResponseV1>(
            &payload.value().value());
    if (finite_prefix == nullptr) {
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::not_applicable, std::nullopt,
          std::nullopt};
    } else if (!provider_result_digest) {
      constexpr std::string_view code =
          "c30.decoder_profile_provider_result_digest_missing";
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::rejected, std::nullopt,
          std::string(code)};
      return failed(
          ResultFailureStageV1::payload_adaptation,
          Diagnostic{DiagnosticCategory::internal, std::string(code),
                     "an observation-bearing decoder profile has no exact "
                     "provider-result-v2 binding",
                     std::nullopt, std::nullopt, {}});
    } else {
      auto profile = decoder_consumed_finite_prefix_profile(*finite_prefix);
      if (!profile) {
        diagnostic_decoder = AnalysisDecoderProfileV2{
            AnalysisDecoderProfileStatusV2::rejected, std::nullopt,
            profile.error().code};
        return failed(ResultFailureStageV1::payload_adaptation,
                      profile.error());
      }
      diagnostic_decoder = AnalysisDecoderProfileV2{
          AnalysisDecoderProfileStatusV2::available,
          std::move(profile).value(),
          std::nullopt,
          *provider_result_digest,
          built.artifact.value().provider_scientific_contract_digest};
    }
  }
  if (k_wide_unavailable_diagnostics) {
    const auto* finite_prefix =
        std::get_if<PortableFinitePrefixConstantTailResponseV1>(
            &payload.value().value());
    if (finite_prefix == nullptr ||
        finite_prefix->response_cutoff !=
            k_wide_unavailable_diagnostics->response_cutoff) {
      return failed(
          ResultFailureStageV1::payload_adaptation,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.k_bin_diagnostic_payload_mismatch",
                     "the native K-wide diagnostic carrier does not match the adapted payload cutoff",
                     std::nullopt, std::nullopt, {}});
    }
    const FinitePrefixConstantTailResponseV1& normalized =
        finite_prefix->normalized_record;
    k_wide_unavailable_diagnostics->coefficient_diagnostics.clear();
    k_wide_unavailable_diagnostics->coefficient_diagnostics.reserve(
        normalized.raw_response.identifications.size());
    const FinitePrefixRawResponseEnvelopeV1* envelope =
        normalized.raw_envelopes.empty() ? nullptr
                                         : &normalized.raw_envelopes.front();
    for (const FinitePrefixCoefficientIdentificationV1& identification :
         normalized.raw_response.identifications) {
      ResultKBinCoordinateKindV1 kind =
          ResultKBinCoordinateKindV1::structural_level_zero;
      switch (identification.coordinate.kind) {
        case FinitePrefixResponseCoordinateKindV1::structural_level_zero:
          kind = ResultKBinCoordinateKindV1::structural_level_zero;
          break;
        case FinitePrefixResponseCoordinateKindV1::exact_level:
          kind = ResultKBinCoordinateKindV1::exact_level;
          break;
        case FinitePrefixResponseCoordinateKindV1::constant_tail:
          kind = ResultKBinCoordinateKindV1::constant_tail;
          break;
      }
      std::optional<PortableScientificScalar> lower;
      std::optional<PortableScientificScalar> upper;
      if (envelope != nullptr) {
        const auto coordinate = std::ranges::find(
            envelope->covered_coordinates, identification.coordinate);
        if (coordinate != envelope->covered_coordinates.end()) {
          const std::size_t index = static_cast<std::size_t>(
              std::distance(envelope->covered_coordinates.begin(),
                            coordinate));
          if (index < envelope->lower.size() &&
              index < envelope->upper.size()) {
            lower = envelope->lower[index];
            upper = envelope->upper[index];
          }
        }
      }
      k_wide_unavailable_diagnostics->coefficient_diagnostics.push_back(
          ResultKBinCoefficientDiagnosticV1{
              kind, identification.coordinate.level_or_tail_from,
              identification.pooled_unserved_mass,
              identification.pooled_served_mass,
              identification.raw_point, std::move(lower),
              std::move(upper)});
    }
  }
  auto plug = materialize_and_validate_surrogate_plug(
      payload.value(), built.artifact, plan.capability_contract());
  if (!plug) {
    return failed(ResultFailureStageV1::plug_binding, plug.error());
  }
  auto access = validate_kernel_access(plug.value());
  if (!access) {
    return failed(ResultFailureStageV1::plug_binding, access.error());
  }
  auto activated = audit_built_framework(
      plan, request.value(), built.artifact, payload.value(),
      std::move(plug).value(), std::move(access).value(),
      std::move(optimizer).value());
  if (!activated) {
    // The consumed candidate owns the sole mutable context.  A failed audit
    // destroys that owner before returning, while the observer deliberately
    // retains its final committed ledger for terminal accounting.
    inactive_optimizer_owner_permitted = true;
    return failed(ResultFailureStageV1::v0_audit, activated.error());
  }
  auto execution_seal =
      detail::audited_framework_execution_seal_digest(
          activated.value().framework);
  if (!execution_seal) {
    return failed(ResultFailureStageV1::v0_audit,
                  execution_seal.error());
  }
  identity.execution_seal_digest = execution_seal.value();
  const V0WitnessReport& v0 =
      v0_witness_report(activated.value().framework);
  const V0WitnessBindingsV1& v0_bindings = v0.bindings();
  const std::string v0_diagnostic_id = "c27.v0.causal_admissibility";
  diagnostics.push_back(ResultDiagnosticV1{
      v0_diagnostic_id, DiagnosticCategory::information,
      "c27.v0_causality_established",
      "C17 established every applicable V0 causal-admissibility obligation",
      std::nullopt, ResultDiagnosticKindV1::execution, std::nullopt,
      std::nullopt,
      {"resolved_instance=" + v0_bindings.resolved_instance.hex(),
       "descriptor=" + v0_bindings.descriptor.hex(),
       "access=" + v0_bindings.access.hex(),
       "ownership_schema=" + v0_bindings.ownership_schema.hex(),
      "exact_update_schema=" + v0_bindings.exact_update_schema.hex()},
      {}});

  auto certificate_status = validate_v0_only_certificate_layer(
      activated.value().framework, certificates);
  if (!certificate_status) {
    return failed(ResultFailureStageV1::certificate,
                  certificate_status.error());
  }

  if (built_in_three_bin) {
    if (identity.ordered_targets.size() != 1U) {
      return failed(
          ResultFailureStageV1::backend,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.response_curve_target_invalid",
                     "the scalar response requires exactly one deployed target",
                     std::nullopt, std::nullopt, {}});
    }
    auto response = audited_three_bin_response(activated.value().framework);
    if (!response) {
      return failed(ResultFailureStageV1::backend, response.error());
    }
    std::array<ExactRational, 4U> service_probabilities{
        ExactRational::zero(), ExactRational::zero(),
        ExactRational::zero(), ExactRational::zero()};
    for (std::size_t backlog = 0U; backlog < service_probabilities.size();
         ++backlog) {
      auto probability =
          response.value().service_probability(BigNat{backlog});
      if (!probability) {
        return failed(ResultFailureStageV1::backend,
                      probability.error());
      }
      service_probabilities[backlog] = std::move(probability).value();
    }
    response_curve.emplace(AnalysisResponseCurveV1{
        identity.ordered_targets.front(), service_probabilities[0],
        service_probabilities[1], service_probabilities[2],
        service_probabilities[3]});
  }

  std::vector<std::optional<ResultMetricV1>> staged(
      plan.metric_plans().size());
  for (const PlannedMetricV1& metric : plan.metric_plans()) {
    const MetricSupportClauseV1* clause =
        accepted_support_clause(plan, metric);
    if (clause == nullptr) {
      return failed(
          ResultFailureStageV1::backend,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.accepted_support_clause_missing",
                     "the backend cannot recover its exact accepted support clause",
                     std::nullopt, std::nullopt, {}});
    }
  }

  std::optional<ThreeBinIidSummary> c19_summary;
  std::optional<FinitePrefixIidSummary> finite_prefix_c19_summary;
  std::optional<ExactStationaryBackendV1> c18_stationary;
  std::optional<StationaryTemporalBackendV1> stationary_temporal;
  std::optional<ReducedInitialLaw> transient_initial;
  std::vector<FifoDelayCacheEntryV1> fifo_delay_cache;

  const auto ensure_three_bin_c19 = [&]()
      -> Result<const ThreeBinIidSummary*> {
    if (c19_summary.has_value()) {
      return Result<const ThreeBinIidSummary*>::success(&*c19_summary);
    }
    auto response = audited_three_bin_response(activated.value().framework);
    if (!response) {
      return Result<const ThreeBinIidSummary*>::failure(response.error());
    }
    const bool solver_proves_stationary_unique =
        plan.selection_regime() == MetricSelectionRegimeV1::stationary_unique;
    auto summary = [&]() -> Result<ThreeBinIidSummary> {
      if (solver_proves_stationary_unique) {
        // C19 itself proves the proper invariant probability; alpha0 and a
        // fabricated uniqueness token are deliberately not consulted.
        return summarize_three_bin_iid_stationary_unique(response.value());
      }
      auto arrival = ArrivalLaw::from_audited(response.value());
      if (!arrival) {
        return Result<ThreeBinIidSummary>::failure(arrival.error());
      }
      return summarize_three_bin_iid_response(response.value(),
                                              arrival.value());
    }();
    if (!summary) {
      return Result<const ThreeBinIidSummary*>::failure(summary.error());
    }
    if (summary.value().law_identity().execution_seal_digest() !=
        execution_seal.value()) {
      return fail<const ThreeBinIidSummary*>(
          "c27.analytic_execution_seal_mismatch",
          "the C19 analytic law identity is not bound to the V0 execution seal");
    }
    diagnostics.push_back(exact_residual_diagnostic(
        "c27.c19.normalization_residual",
        "c27.c19.normalization_residual",
        "exact C19 stationary normalization residual",
        summary.value().diagnostics().normalization_residual));
    diagnostics.push_back(exact_residual_diagnostic(
        "c27.c19.invariance_residual", "c27.c19.invariance_residual",
        "exact C19 stationary invariance residual",
        summary.value().diagnostics().invariance_residual));
    if (solver_proves_stationary_unique) {
      diagnostics.push_back(ResultDiagnosticV1{
          "c27.c19.stationary_uniqueness",
          DiagnosticCategory::information,
          "c27.c19.strict_tail_stationary_unique",
          "C19 established the unique invariant probability by its exact strict-tail descent theorem",
          component_scope_from_ordinal(7U),
          ResultDiagnosticKindV1::execution,
          std::nullopt,
          std::nullopt,
          {"basis=strict_tail_descent_to_zero",
           "initial_mapper_invoked=false",
           "uniqueness_digest_synthesized=false"},
          {}});
    }
    append_c19_solver_diagnostics(summary.value(), diagnostics);
    c19_summary.emplace(std::move(summary).value());
    return Result<const ThreeBinIidSummary*>::success(&*c19_summary);
  };

  const auto ensure_finite_prefix_c19 = [&]()
      -> Result<const FinitePrefixIidSummary*> {
    if (finite_prefix_c19_summary.has_value()) {
      return Result<const FinitePrefixIidSummary*>::success(
          &*finite_prefix_c19_summary);
    }
    auto response = audited_response_law(activated.value().framework);
    if (!response) {
      return Result<const FinitePrefixIidSummary*>::failure(
          response.error());
    }
    const bool solver_proves_stationary_unique =
        plan.selection_regime() == MetricSelectionRegimeV1::stationary_unique;
    auto summary = [&]() -> Result<FinitePrefixIidSummary> {
      if (solver_proves_stationary_unique) {
        return summarize_finite_prefix_iid_stationary_unique(
            response.value());
      }
      auto arrival = ArrivalLaw::from_audited(response.value());
      if (!arrival) {
        return Result<FinitePrefixIidSummary>::failure(arrival.error());
      }
      return summarize_finite_prefix_iid_response(response.value(),
                                                  arrival.value());
    }();
    if (!summary) {
      return Result<const FinitePrefixIidSummary*>::failure(summary.error());
    }
    if (summary.value().law_identity().execution_seal_digest() !=
        execution_seal.value()) {
      return fail<const FinitePrefixIidSummary*>(
          "c27.analytic_execution_seal_mismatch",
          "the C19 analytic law identity is not bound to the V0 execution seal");
    }
    diagnostics.push_back(exact_residual_diagnostic(
        "c27.c19.normalization_residual",
        "c27.c19.normalization_residual",
        "exact C19 stationary normalization residual",
        summary.value().diagnostics().normalization_residual));
    diagnostics.push_back(exact_residual_diagnostic(
        "c27.c19.invariance_residual", "c27.c19.invariance_residual",
        "exact C19 stationary invariance residual",
        summary.value().diagnostics().invariance_residual));
    const AnalyticStationaryStatusV1 status = summary.value().status();
    const bool strict_tail_unique =
        status == AnalyticStationaryStatusV1::strict_tail_stable ||
        status == AnalyticStationaryStatusV1::required_moment_unavailable;
    if (solver_proves_stationary_unique && strict_tail_unique &&
        finite_prefix_normalized_law_established(summary.value())) {
      diagnostics.push_back(ResultDiagnosticV1{
          "c27.c19.stationary_uniqueness",
          DiagnosticCategory::information,
          "c27.c19.strict_tail_stationary_unique",
          "C19 established the unique invariant probability by its exact strict-tail descent theorem",
          component_scope_from_ordinal(7U),
          ResultDiagnosticKindV1::execution,
          std::nullopt,
          std::nullopt,
          {"basis=strict_tail_descent_to_zero",
           "initial_mapper_invoked=false",
           "uniqueness_digest_synthesized=false"},
          {}});
    }
    append_c19_solver_diagnostics(summary.value(), diagnostics);
    if (k_wide_unavailable_diagnostics) {
      std::vector<PortableScientificScalar> service_by_level;
      service_by_level.reserve(summary.value().service_by_level().size());
      for (const ExactRational& coefficient :
           summary.value().service_by_level()) {
        service_by_level.push_back(
            PortableScientificScalar::rational(coefficient));
      }
      const AnalyticStationaryDiagnosticsV1& c19_diagnostics =
          summary.value().diagnostics();
      const ExactRational tail_service =
          summary.value().tail_coefficient().service_probability;
      const ExactRational algebraic_tail_slack =
          tail_service - summary.value().arrival_mean();
      k_wide_unavailable_diagnostics->c19.emplace(
          ResultC19UnavailableDiagnosticsV1{
              std::string(analytic_stationary_status_text(
                  summary.value().status())),
              PortableScientificScalar::rational(
                  summary.value().arrival_mean()),
              std::move(service_by_level),
              summary.value().tail_coefficient().tail_from,
              PortableScientificScalar::rational(tail_service),
              PortableScientificScalar::rational(algebraic_tail_slack),
              std::string(tail_slack_applicability_text(
                  summary.value().tail_slack_applicability())),
              PortableScientificScalar::rational(
                  c19_diagnostics.normalization_residual),
              PortableScientificScalar::rational(
                  c19_diagnostics.invariance_residual),
              c19_diagnostics.tail_remainder_bound
                  ? std::optional<PortableScientificScalar>{
                        PortableScientificScalar::rational(
                            *c19_diagnostics.tail_remainder_bound)}
                  : std::nullopt,
              c19_diagnostics.terms_evaluated});
    }
    finite_prefix_c19_summary.emplace(std::move(summary).value());
    return Result<const FinitePrefixIidSummary*>::success(
        &*finite_prefix_c19_summary);
  };

  const auto ensure_c18 = [&]() -> Result<const ExactStationaryBackendV1*> {
    if (!c18_stationary.has_value()) {
      auto stationary = build_exact_stationary_backend(plan,
                                                       activated.value());
      if (!stationary) {
        return Result<const ExactStationaryBackendV1*>::failure(
            stationary.error());
      }
      c18_stationary.emplace(std::move(stationary).value());
      const auto& solve = c18_stationary->law.solve_diagnostics();
      diagnostics.push_back(ResultDiagnosticV1{
          "c27.c18.normalization_residual",
          DiagnosticCategory::information,
          "c27.c18.normalization_residual",
          "C18 selected invariant-law normalization residual",
          component_scope_from_ordinal(7U),
          ResultDiagnosticKindV1::stationary_residual,
          std::nullopt,
          std::nullopt,
          {"normalization_residual=" +
           floating_text(solve.normalization_residual),
           "normalization_bound=" +
           floating_text(solve.normalization_bound)},
          {}});
      diagnostics.push_back(ResultDiagnosticV1{
          "c27.c18.invariance_residual",
          DiagnosticCategory::information,
          "c27.c18.invariance_residual",
          "C18 selected invariant-law L1 invariance residual",
          component_scope_from_ordinal(7U),
          ResultDiagnosticKindV1::stationary_residual,
          std::nullopt,
          std::nullopt,
          {"l1_invariance_residual=" +
           floating_text(solve.l1_invariance_residual),
           "l1_invariance_bound=" +
           floating_text(solve.l1_invariance_bound)},
          {}});
      const CompletionBoundMarkedFlux& completion =
          c18_stationary->matrix.marked_flux();
      const std::string completion_kind =
          completion.completion_kind() ==
                  BoundaryCompletionKindV1::exact_closed
              ? "exact_closed"
          : completion.completion_kind() ==
                  BoundaryCompletionKindV1::marked_completion
              ? "marked_completion"
              : "state_only_completion";
      diagnostics.push_back(ResultDiagnosticV1{
          "c27.c18.boundary_completion",
          DiagnosticCategory::information,
          "c27.c18.boundary_completion",
          "C18 finite-domain boundary completion provenance",
          component_scope_from_ordinal(7U),
          ResultDiagnosticKindV1::execution,
          std::nullopt,
          std::nullopt,
          {"completion_kind=" + completion_kind,
           "completion_identity=" +
               (completion.completion_identity()
                    ? completion.completion_identity()->hex()
                    : std::string("none")),
           "exact_completed_mass=" +
               exact_text(completion.exact_completed_mass()),
           completion.physical_mark_preserving()
               ? "physical_mark_preserving=true"
               : "physical_mark_preserving=false"},
          {}});
    }
    return Result<const ExactStationaryBackendV1*>::success(
        &*c18_stationary);
  };

  const auto ensure_stationary_temporal = [&]()
      -> Result<const StationaryTemporalBackendV1*> {
    if (!stationary_temporal.has_value()) {
      auto temporal = build_stationary_temporal_backend(plan,
                                                        activated.value());
      if (!temporal) {
        return Result<const StationaryTemporalBackendV1*>::failure(
            temporal.error());
      }
      append_stationary_temporal_backend_diagnostics(temporal.value(),
                                                     diagnostics);
      stationary_temporal.emplace(std::move(temporal).value());
    }
    return Result<const StationaryTemporalBackendV1*>::success(
        &*stationary_temporal);
  };

  const auto requires_transient_initial = [&](const PlannedMetricV1& metric) {
    if (plan.selection_regime() != MetricSelectionRegimeV1::transient) {
      return false;
    }
    if (metric.route_kind() ==
        BackendRouteKindV1::finite_temporal_cylinder) {
      return true;
    }
    if (metric.route_kind() !=
        BackendRouteKindV1::residence_or_stopped_law) {
      return false;
    }
    const MetricKindV1 kind = metric_request_kind(metric.request());
    return kind == MetricKindV1::first_hit ||
           kind == MetricKindV1::threshold_excursion ||
           kind == MetricKindV1::transient_backlog_law;
  };
  if (std::ranges::any_of(plan.metric_plans(),
                          requires_transient_initial)) {
    auto initial = construct_reduced_initial_law(
        plan.resolved_instance(), activated.value().framework,
        plan.selection_spec(), plan.initial_physical_law());
    if (!initial) {
      return failed(ResultFailureStageV1::initial_law,
                    initial.error());
    }
    transient_initial.emplace(std::move(initial).value());
  }

  const std::vector<std::string> c19_residual_refs{
      "c27.c19.normalization_residual", "c27.c19.invariance_residual"};
  const std::vector<std::string> c18_residual_refs{
      "c27.c18.normalization_residual", "c27.c18.invariance_residual"};
  const std::vector<std::string> c20_c21_residual_refs{
      "c27.c20.normalization_residual",
      "c27.c20.invariance_residuals",
      "c27.c20.solve_residuals",
      "c27.c21.projection_residuals"};
  const std::vector<std::string> c20_c21_error_refs{
      "c27.c21.mean_residence_enclosure"};

  for (std::size_t index = 0U; index < plan.metric_plans().size(); ++index) {
    const PlannedMetricV1& metric = plan.metric_plans()[index];
    const MetricSupportClauseV1* clause =
        accepted_support_clause(plan, metric);
    auto mapped = [&]() -> Result<ResultMetricV1> {
      switch (metric.route_kind()) {
        case BackendRouteKindV1::framework_scalar_identity: {
          const auto* scalar = std::get_if<FrameworkScalarIdentityBackendPlanV1>(
              &metric.backend());
          if (scalar == nullptr) {
            return fail<ResultMetricV1>(
                "c27.framework_scalar_backend_plan_mismatch",
                "the frozen scalar-identity route has no scalar backend plan");
          }
          if (scalar->stationary_proof.backend ==
              StationaryProofBackendV1::c19_scalar_iid_summary) {
            if (built_in_finite_prefix) {
              auto summary = ensure_finite_prefix_c19();
              if (!summary) {
                return Result<ResultMetricV1>::failure(summary.error());
              }
              return map_finite_prefix_framework_scalar_identity(
                  plan, metric, *clause, execution_seal.value(),
                  *summary.value(), c19_residual_refs);
            }
            if (!built_in_three_bin) {
              return fail<ResultMetricV1>(
                  "c27.framework_scalar_c19_payload_mismatch",
                  "the frozen C19 scalar identity is not backed by a recognized phase-free scalar response payload");
            }
            auto summary = ensure_three_bin_c19();
            if (!summary) {
              if (summary.error().code ==
                  "c19.stationary_unique_not_established") {
                return fail<ResultMetricV1>(
                    "c27.stationary_throughput_not_established",
                    "C19 did not establish the proper unique stationary law required by the lossless throughput identity",
                    DiagnosticCategory::unavailable);
              }
              return Result<ResultMetricV1>::failure(summary.error());
            }
            return map_framework_scalar_identity(
                plan, metric, *clause, execution_seal.value(),
                *summary.value(), c19_residual_refs);
          }
          if (built_in_finite_prefix) {
            return fail<ResultMetricV1>(
                "c27.finite_prefix_c19_route_mismatch",
                "the finite-prefix scalar response reached a non-C19 stationary proof route");
          }
          auto stationary = ensure_c18();
          if (!stationary) {
            return Result<ResultMetricV1>::failure(stationary.error());
          }
          return map_framework_scalar_identity_c18(
              plan, activated.value(), metric, *clause,
              *stationary.value(), c18_residual_refs, diagnostics);
        }

        case BackendRouteKindV1::analytic_metric_family: {
          const MetricKindV1 kind = metric_request_kind(metric.request());
          if (kind == MetricKindV1::mean_event_gap ||
              kind == MetricKindV1::mean_binary_run ||
              kind == MetricKindV1::service_window_count) {
            auto temporal = ensure_stationary_temporal();
            if (!temporal) {
              return Result<ResultMetricV1>::failure(temporal.error());
            }
            return execute_stationary_temporal_metric(
                plan, metric, *clause, *temporal.value(),
                c20_c21_residual_refs, c20_c21_error_refs);
          }
          if (built_in_finite_prefix) {
            auto summary = ensure_finite_prefix_c19();
            if (!summary) {
              return Result<ResultMetricV1>::failure(summary.error());
            }
            return map_finite_prefix_metric(metric, *clause,
                                            *summary.value(),
                                            c19_residual_refs);
          }
          auto summary = ensure_three_bin_c19();
          if (!summary) {
            return Result<ResultMetricV1>::failure(summary.error());
          }
          return map_three_bin_metric(metric, *clause, *summary.value(),
                                      c19_residual_refs);
        }

        case BackendRouteKindV1::stationary_invariant:
        case BackendRouteKindV1::stationary_edge_reward: {
          if (built_in_three_bin) {
            auto summary = ensure_three_bin_c19();
            if (!summary) {
              return Result<ResultMetricV1>::failure(summary.error());
            }
            return map_three_bin_metric(metric, *clause, *summary.value(),
                                        c19_residual_refs);
          }
          if (built_in_finite_prefix) {
            auto summary = ensure_finite_prefix_c19();
            if (!summary) {
              return Result<ResultMetricV1>::failure(summary.error());
            }
            return map_finite_prefix_metric(metric, *clause,
                                            *summary.value(),
                                            c19_residual_refs);
          }
          if (plan.capability_contract().runtime_access() ==
              RuntimeAccessTagV1::procedural_residence_generator) {
            auto temporal = ensure_stationary_temporal();
            if (!temporal) {
              return Result<ResultMetricV1>::failure(temporal.error());
            }
            return execute_stationary_temporal_metric(
                plan, metric, *clause, *temporal.value(),
                c20_c21_residual_refs, c20_c21_error_refs);
          }
          auto stationary = ensure_c18();
          if (!stationary) {
            return Result<ResultMetricV1>::failure(stationary.error());
          }
          return execute_c18_stationary_metric(
              plan, activated.value(), metric, *clause,
              *stationary.value(), c18_residual_refs);
        }

        case BackendRouteKindV1::finite_temporal_cylinder: {
          if (plan.selection_regime() == MetricSelectionRegimeV1::transient) {
            if (!transient_initial) {
              return fail<ResultMetricV1>(
                  "c27.transient_initial_dependency_missing",
                  "the frozen transient route reached backend dispatch without its preconstructed sealed initial law");
            }
            auto evaluation =
                detail::evaluate_transient_metric_with_budget(
                activated.value().framework, *transient_initial,
                metric.request());
            if (!evaluation) {
              return Result<ResultMetricV1>::failure(evaluation.error());
            }
            append_transient_metric_budget(
                metric, evaluation.value().budget,
                evaluation.value().actual_maximum_row_atoms,
                backend_budgets);
            return map_canonical_backend_metric(
                metric, *clause, execution_seal.value(),
                std::move(evaluation).value().value,
                "C22 exact finite-horizon transient reduced law", {},
                {},
                {"sealed_joint_reduced_initial_law",
                 "early_service_late_admission"});
          }
          auto temporal = ensure_stationary_temporal();
          if (!temporal) {
            return Result<ResultMetricV1>::failure(temporal.error());
          }
          return execute_stationary_temporal_metric(
              plan, metric, *clause, *temporal.value(),
              c20_c21_residual_refs, c20_c21_error_refs);
        }

        case BackendRouteKindV1::residence_or_stopped_law: {
          const MetricKindV1 kind = metric_request_kind(metric.request());
          if (plan.selection_regime() == MetricSelectionRegimeV1::transient &&
              (kind == MetricKindV1::first_hit ||
               kind == MetricKindV1::threshold_excursion ||
               kind == MetricKindV1::transient_backlog_law)) {
            if (!transient_initial) {
              return fail<ResultMetricV1>(
                  "c27.transient_initial_dependency_missing",
                  "the frozen transient stopped route reached backend dispatch without its preconstructed sealed initial law");
            }
            auto evaluation =
                detail::evaluate_transient_metric_with_budget(
                activated.value().framework, *transient_initial,
                metric.request());
            if (!evaluation) {
              return Result<ResultMetricV1>::failure(evaluation.error());
            }
            append_transient_metric_budget(
                metric, evaluation.value().budget,
                evaluation.value().actual_maximum_row_atoms,
                backend_budgets);
            return map_canonical_backend_metric(
                metric, *clause, execution_seal.value(),
                std::move(evaluation).value().value,
                "C22 exact transient stopped-law evaluation", {},
                {},
                {"sealed_joint_reduced_initial_law",
                 "survival_and_defective_mass_retained"});
          }
          auto temporal = ensure_stationary_temporal();
          if (!temporal) {
            return Result<ResultMetricV1>::failure(temporal.error());
          }
          return execute_stationary_stopped_metric(
              plan, metric, *clause, *temporal.value(),
              c20_c21_residual_refs, c20_c21_error_refs, diagnostics,
              backend_budgets);
        }

        case BackendRouteKindV1::palm_or_fifo_law: {
          const MetricKindV1 kind = metric_request_kind(metric.request());
          if (kind == MetricKindV1::joint_delay) {
            return fail<ResultMetricV1>(
                "c27.joint_delay_backend_unavailable",
                "C23 exposes only a scalar admission-Palm FIFO tag law; C27 will not manufacture the common-schedule coupling required by joint_delay");
          }
          if (kind != MetricKindV1::fifo_delay &&
              kind != MetricKindV1::fifo_delay_conditioned) {
            return fail<ResultMetricV1>(
                "c27.palm_fifo_metric_adapter_unavailable",
                "the accepted Palm/FIFO route has no mathematically equivalent public C23 evaluator");
          }
          auto temporal = ensure_stationary_temporal();
          if (!temporal) {
            return Result<ResultMetricV1>::failure(temporal.error());
          }
          return execute_fifo_delay_metric(
              plan, metric, *clause, *temporal.value(),
              c20_c21_residual_refs, c20_c21_error_refs, diagnostics,
              backend_budgets, fifo_delay_cache);
        }

        case BackendRouteKindV1::conditional_row_monte_carlo:
        case BackendRouteKindV1::conditional_reward_monte_carlo:
          return execute_c24_sampling_metric(
              plan, activated.value(), metric, *clause, diagnostics,
              backend_budgets, replay_streams);

        case BackendRouteKindV1::exact_direct: {
          const auto* direct_payload = std::get_if<DirectMetricPayloadV1>(
              &built.artifact.value().payload);
          if (direct_payload == nullptr ||
              direct_payload->values.size() != 1U) {
            return fail<ResultMetricV1>(
                "c27.direct_metric_value_metadata_missing",
                "the validated direct-metric artifact does not retain exactly one request-bound value metadata record");
          }
          const DirectMetricValueV1& direct_value =
              direct_payload->values.front();
          auto normalized_request = canonical_metric_requirements_digest(
              requirements_for_metric(metric.request()));
          if (!normalized_request) {
            return Result<ResultMetricV1>::failure(
                normalized_request.error());
          }
          if (direct_value.metric_clause_id !=
                  metric.contract().clause_id ||
              direct_value.ordered_targets != clause->ordered_targets ||
              direct_value.request_digest !=
                  request.value().request_digest().value() ||
              direct_value.normalized_metric_request_digest !=
                  normalized_request.value() ||
              direct_value.accepted_contract_digest !=
                  plan.capability_contract().contract_digest() ||
              direct_value.result_scope != clause->result_scope) {
            return fail<ResultMetricV1>(
                "c27.direct_metric_value_metadata_binding_mismatch",
                "the validated direct-metric value metadata no longer matches the frozen clause, request, accepted contract, targets, or result scope");
          }

          std::string validity_basis;
          std::string convention;
          switch (direct_value.validity_basis) {
            case DirectMetricValidityBasisV1::exact_closed_form:
              validity_basis = "exact_closed_form";
              convention =
                  "C16 sealed exact-request direct metric value established by exact closed form";
              break;
            case DirectMetricValidityBasisV1::exact_finite_enumeration:
              validity_basis = "exact_finite_enumeration";
              convention =
                  "C16 sealed exact-request direct metric value established by exact finite enumeration";
              break;
            case DirectMetricValidityBasisV1::certified_bound:
              validity_basis = "certified_bound";
              convention =
                  "C16 sealed exact-request direct metric value with a certified-bound validity basis";
              break;
            default:
              return fail<ResultMetricV1>(
                  "c27.direct_metric_validity_basis_invalid",
                  "the validated direct-metric value carries an unknown validity basis");
          }

          std::vector<std::string> direct_assumptions{
              "exact_request_domain_match", "canonical_value_preserved",
              "direct_result_not_a_reusable_law",
              "direct_metric_value_id=" +
                  typed_label_text(direct_value.value_id.object_id),
              "direct_metric_value_digest=" +
                  direct_value.value_id.object_digest.hex(),
              "direct_validity_basis=" + validity_basis};
          direct_assumptions.reserve(direct_assumptions.size() +
                                     direct_value.evidence_ids.size());
          for (const ArtifactObjectReferenceV1& evidence :
               direct_value.evidence_ids) {
            direct_assumptions.push_back(
                "direct_validity_evidence_id=" +
                typed_label_text(evidence.object_id) + ",digest=" +
                evidence.object_digest.hex());
          }

          auto direct =
              audited_direct_metric_access(activated.value().framework);
          if (!direct) {
            return Result<ResultMetricV1>::failure(direct.error());
          }
          auto value = execute_direct_metric_decoder(
              activated.value().framework, direct.value(),
              metric.request());
          if (!value) {
            return Result<ResultMetricV1>::failure(value.error());
          }
          return map_canonical_backend_metric(
              metric, *clause, direct_value.value_id.object_digest,
              std::move(value).value(), std::move(convention), {}, {},
              std::move(direct_assumptions));
        }
      }
      return fail<ResultMetricV1>(
          "c27.backend_route_not_implemented",
          "the frozen backend route has no closed C27 dispatcher");
    }();
    if (!mapped) {
      if (is_permitted_scientific_unavailability(mapped.error())) {
        return backend_unavailable(index, mapped.error().code,
                                   mapped.error().message);
      }
      return failed(ResultFailureStageV1::backend, mapped.error());
    }
    staged[index] = std::move(mapped).value();
  }

  metrics.reserve(staged.size());
  for (std::optional<ResultMetricV1>& mapped : staged) {
    if (!mapped) {
      return failed(
          ResultFailureStageV1::backend,
          Diagnostic{DiagnosticCategory::internal,
                     "c27.backend_result_missing",
                     "one frozen metric route did not produce a terminal metric value",
                     std::nullopt, std::nullopt, {}});
    }
    metrics.push_back(std::move(*mapped));
  }
  const bool sampling_metric_ran = std::ranges::any_of(
      plan.metric_plans(), [](const PlannedMetricV1& metric) {
        return metric.route_kind() ==
                   BackendRouteKindV1::conditional_row_monte_carlo ||
               metric.route_kind() ==
                   BackendRouteKindV1::conditional_reward_monte_carlo;
      });
  if (!sampling_metric_ran) {
    backend_budgets.push_back(ResultBudgetUsageV1{
        "backend.conditional_generator_draws",
        ResultBudgetApplicabilityV1::not_applicable, std::nullopt,
        BigNat{0U}, "draws"});
  }
  auto optimizer_accounting = finalize_optimizer_accounting();
  if (!optimizer_accounting) {
    return failed(ResultFailureStageV1::backend,
                  optimizer_accounting.error());
  }
  return AnalysisBundle(ResultStatusV1::success, std::nullopt,
                        std::move(identity), std::move(build_report),
                        std::move(response_curve), std::nullopt,
                        std::move(metrics),
                        std::move(certificates), std::move(diagnostics),
                        std::move(execution_budgets),
                        std::move(backend_budgets),
                        std::move(replay_streams), wall_clock_times(),
                        std::move(optimizer_calls_observed),
                        std::move(optimizer_search_states_observed),
                        freeze_diagnostic_supplement(
                            ResultStatusV1::success, std::nullopt,
                            std::nullopt));
}

}  // namespace detail

}  // namespace mwperf
