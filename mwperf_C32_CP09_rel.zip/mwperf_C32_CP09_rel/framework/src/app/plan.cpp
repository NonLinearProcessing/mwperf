#include "mwperf/app/execution_plan.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <exception>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/schema_versions.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/metrics/metric_capabilities.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/surrogate_id.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"
#include "surrogate/providers/full_orbit_sampler_provider.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> fail(Diagnostic diagnostic) {
  return Result<T>::failure(std::move(diagnostic));
}

[[nodiscard]] Diagnostic plan_error(
    const DiagnosticCategory category, std::string code,
    std::string message, std::optional<std::string> json_pointer = std::nullopt,
    std::vector<std::string> notes = {}) {
  return Diagnostic{category,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    std::move(json_pointer),
                    std::move(notes)};
}

[[nodiscard]] CountConstructionGrantV1 count_grant(
    const std::optional<BigNat>& amount) {
  return amount.has_value()
             ? CountConstructionGrantV1{BudgetApplicabilityV1::applicable,
                                        amount}
             : CountConstructionGrantV1{
                   BudgetApplicabilityV1::not_applicable, std::nullopt};
}

[[nodiscard]] ToleranceConstructionGrantV1 tolerance_grant(
    const std::optional<ExactRational>& amount) {
  return amount.has_value()
             ? ToleranceConstructionGrantV1{
                   BudgetApplicabilityV1::applicable, amount}
             : ToleranceConstructionGrantV1{
                   BudgetApplicabilityV1::not_applicable, std::nullopt};
}

[[nodiscard]] bool grant_is_well_formed(
    const CountConstructionGrantV1& grant) noexcept {
  return (grant.applicability == BudgetApplicabilityV1::applicable) ==
         grant.amount.has_value();
}

[[nodiscard]] bool grant_is_well_formed(
    const ToleranceConstructionGrantV1& grant) noexcept {
  return (grant.applicability == BudgetApplicabilityV1::applicable) ==
         grant.amount.has_value();
}

[[nodiscard]] bool grant_covers(
    const CountConstructionGrantV1& grant,
    const std::optional<BigNat>& required) noexcept {
  return !required.has_value() ||
         (grant.applicability == BudgetApplicabilityV1::applicable &&
          grant.amount.has_value() && *grant.amount >= *required);
}

[[nodiscard]] bool is_three_bin_payload(
    const PayloadClassV1& payload) noexcept {
  return payload.tag == PayloadClassTagV1::three_bin_scalar_response_v1 &&
         payload.version == 1U;
}

[[nodiscard]] bool is_finite_prefix_constant_tail_payload(
    const PayloadClassV1& payload) noexcept {
  return payload.tag ==
             PayloadClassTagV1::finite_prefix_constant_tail_response_v1 &&
         payload.version == 1U;
}

[[nodiscard]] bool is_builtin_c19_scalar_response(
    const PlugDescriptorCore& core) noexcept {
  const bool three_bin = is_three_bin_payload(core.payload_class);
  const bool finite_prefix =
      is_finite_prefix_constant_tail_payload(core.payload_class);
  if ((!three_bin && !finite_prefix) ||
      core.semantic != SemanticTagV1::scalar_backlog_response ||
      core.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      core.target_coupling != TargetCouplingV1::scalar_target ||
      core.deployed_targets.size() != 1U ||
      core.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
      core.tail.kind != TailRepresentationKindV1::constant_response ||
      !core.tail.boundary.has_value()) {
    return false;
  }
  return three_bin ? *core.tail.boundary == BigNat{3U}
                   : *core.tail.boundary >= BigNat{3U};
}

[[nodiscard]] bool uses_compact_factorized_iid_problem_view(
    const ProviderIdentityV1& provider,
    const BuilderArrivalView& arrival) noexcept {
  // This is deliberately provider-scoped.  Explicit joint IID tables remain
  // part of the generic framework view for every legacy/current consumer that
  // has not opted into the compact canonical generator contract.
  return provider.provider_id == "full_orbit_framework_sampler" &&
         arrival.capabilities()
             .exact_factorized_iid_generator.has_value();
}

[[nodiscard]] std::vector<QueueId> resolved_targets(
    const ResolvedInstance& instance) {
  std::vector<QueueId> targets;
  targets.reserve(instance.targets().size());
  for (const ResolvedTarget& target : instance.targets().values()) {
    targets.push_back(instance.queues().queue_id(target.queue));
  }
  return targets;
}

[[nodiscard]] Result<TargetSelection> make_target_selection(
    const ResolvedRequest& request) {
  auto group_label = TypedLabel::text(
      "c27.analysis." + request.fingerprints().combined.hex());
  if (!group_label) {
    return fail<TargetSelection>(group_label.error());
  }
  return Result<TargetSelection>::success(TargetSelection{
      1U, resolved_targets(request.instance()),
      ConstructionGroupIdV1(std::move(group_label).value())});
}

[[nodiscard]] Result<BigNat> authored_metric_draw_bound(
    std::span<const MetricRequest> requests,
    const MetricSolverRegimeV1 solver_regime) {
  BigNat total{0U};
  if (solver_regime != MetricSolverRegimeV1::monte_carlo) {
    return Result<BigNat>::success(std::move(total));
  }
  for (const MetricRequest& request : requests) {
    const MetricRequestHeader& header = metric_request_header(request);
    if (!header.context) {
      return fail<BigNat>(plan_error(
          DiagnosticCategory::internal, "c27.metric_context_missing",
          "a parsed metric request lost its immutable analysis context"));
    }
    const auto* solver =
        std::get_if<MonteCarloSolver>(&header.context->solver);
    if (solver == nullptr) {
      return fail<BigNat>(plan_error(
          DiagnosticCategory::internal, "c27.metric_solver_mismatch",
          "the homogeneous Monte Carlo regime is not backed by an authored "
          "Monte Carlo solver"));
    }
    total += solver->replications;
  }
  return Result<BigNat>::success(std::move(total));
}

struct BudgetPlan final {
  ConstructionBudget construction;
  PlannedWorkBoundsV1 work;
};

[[nodiscard]] Result<std::optional<BigNat>>
cp09_minimum_construction_optimizer_calls(
    const ProviderIdentityV1& provider,
    const ValidatedSurrogateParameters& parameters) {
  if (!detail::is_full_orbit_cp09_provider(provider)) {
    return Result<std::optional<BigNat>>::success(std::nullopt);
  }
  auto cp09 = detail::full_orbit_cp09_analysis_parameters(parameters);
  if (!cp09) {
    return Result<std::optional<BigNat>>::failure(cp09.error());
  }
  auto measured_slots =
      checked_subtract(cp09.value().horizon_slots,
                       cp09.value().warmup_slots);
  if (!measured_slots) {
    return Result<std::optional<BigNat>>::failure(measured_slots.error());
  }
  const BigNat physical_calls = cp09.value().replications *
                                cp09.value().population_size *
                                cp09.value().horizon_slots;
  const BigNat diagnostic_gap_calls =
      cp09.value().gap_telemetry_requested
          ? cp09.value().replications * cp09.value().population_size *
                measured_slots.value()
          : BigNat{0U};
  return Result<std::optional<BigNat>>::success(
      physical_calls + diagnostic_gap_calls);
}

[[nodiscard]] Result<BudgetPlan> make_budget_plan(
    const ResolvedInstance& instance,
    const std::optional<BigNat>& maximum_downstream_optimizer_calls,
    const BigNat& metric_generator_draws,
    const bool full_orbit_addressed_work = false,
    const std::optional<BigNat>& minimum_construction_optimizer_calls =
        std::nullopt) {
  if (!instance.analysis_spec().context) {
    return fail<BudgetPlan>(plan_error(
        DiagnosticCategory::internal, "c27.analysis_context_missing",
        "the resolved request has no immutable analysis context"));
  }
  const AnalysisContext& context = *instance.analysis_spec().context;
  const OptimizerBudgetPolicy& optimizer = instance.optimizer_budget();

  // Every currently selectable non-direct downstream route has a proved
  // zero F-C05-03 entry bound: C17 resolves the mandatory emitted face
  // without the physical optimizer, C18--C24 consume only sealed rows/laws,
  // and analysis-v1 has no production selector for the optional C12
  // reference path. A direct decoder instead uses its callback-free
  // registered composite-factor bound. Keep the unknown-bound rejection for
  // any future route that actually introduces downstream optimizer work.
  if (optimizer.max_calls.has_value() &&
      !maximum_downstream_optimizer_calls.has_value()) {
    return fail<BudgetPlan>(plan_error(
        DiagnosticCategory::resource_limit,
        "c27.optimizer_upper_bound_unavailable",
        "the selected generic payload has no finite pre-execution optimizer "
        "call bound under the authored global cap",
        "/resolution/optimizer/max_calls",
        {"no provider was executed and no alternate route was selected"}));
  }

  std::optional<BigNat> construction_optimizer_calls;
  if (optimizer.max_calls.has_value() &&
      maximum_downstream_optimizer_calls.has_value()) {
    auto remaining = checked_subtract(
        *optimizer.max_calls, *maximum_downstream_optimizer_calls);
    if (!remaining) {
      return fail<BudgetPlan>(plan_error(
          DiagnosticCategory::resource_limit,
          "c27.downstream_optimizer_budget_insufficient",
          "the callback-free downstream optimizer-call bound exceeds the "
          "authored global call cap",
          "/resolution/optimizer/max_calls",
          {"no provider was executed and no alternate route was selected"}));
    }
    construction_optimizer_calls = std::move(remaining).value();
  } else {
    construction_optimizer_calls = optimizer.max_calls;
  }
  // With no authored global cap, CP09 still needs a finite process-local
  // grant for its physical sampler and exact counterfactual gap probes.  The
  // immutable R,P,T,W request supplies that conservative bound.  A finite
  // authored max_calls is instead a hard global grant and is never enlarged;
  // planning rejects it if it is insufficient.
  if (minimum_construction_optimizer_calls.has_value() &&
      !construction_optimizer_calls.has_value()) {
    construction_optimizer_calls = minimum_construction_optimizer_calls;
  }
  std::optional<BigNat> construction_search_states;
  if (!full_orbit_addressed_work &&
      construction_optimizer_calls.has_value() &&
      optimizer.effective_per_call.has_value()) {
    construction_search_states =
        *construction_optimizer_calls * *optimizer.effective_per_call;
  }

  std::optional<BigNat> construction_generator_draws;
  std::optional<BigNat> total_generator_draws;
  const std::optional<BigNat>& global_draw_cap =
      context.resolution.sampling.max_generator_draws;
  if (full_orbit_addressed_work) {
    // CP07.1 uses addressed randomness and exposes neither configured draw
    // use nor exact-search attempts through EnsembleWork.  NotApplicable is
    // therefore a scientific statement for this provider, not a zero
    // observation.  Metric-side draws remain independently accounted below.
    if (!metric_generator_draws.is_zero()) {
      return fail<BudgetPlan>(plan_error(
          DiagnosticCategory::internal,
          "c27.full_orbit_k_wide_metric_draws",
          "the analytic K-wide Full Orbit route cannot carry metric-side "
          "conditional-generator draws"));
    }
    total_generator_draws = BigNat{0U};
  } else if (global_draw_cap.has_value()) {
    auto remaining =
        checked_subtract(*global_draw_cap, metric_generator_draws);
    if (!remaining) {
      return fail<BudgetPlan>(plan_error(
          DiagnosticCategory::resource_limit,
          "c27.generator_draw_budget_insufficient",
          "the exact authored Monte Carlo replication count exceeds the "
          "global conditional-generator draw cap",
          "/resolution/sampling/max_generator_draws"));
    }
    construction_generator_draws = std::move(remaining).value();
    total_generator_draws = *construction_generator_draws +
                            metric_generator_draws;
  } else {
    if (!metric_generator_draws.is_zero()) {
      return fail<BudgetPlan>(plan_error(
          DiagnosticCategory::input_validation,
          "c27.generator_draw_cap_required",
          "a Monte Carlo backend requires an explicit global "
          "max_generator_draws cap",
          "/resolution/sampling/max_generator_draws"));
    }
    // A not-applicable construction grant permits no charged construction
    // draws.  Therefore zero is a proved total, not an inferred provider cost.
    total_generator_draws = BigNat{0U};
  }

  ConstructionBudget budget{
      1U,
      count_grant(construction_optimizer_calls),
      count_grant(construction_search_states),
      count_grant(construction_generator_draws),
      tolerance_grant(context.resolution.tolerance.linear_residual_abs),
      tolerance_grant(context.resolution.tolerance.integration_abs),
      tolerance_grant(context.resolution.tolerance.tail_abs),
      tolerance_grant(context.resolution.tolerance.fixed_point_abs)};

  std::optional<BigNat> total_optimizer_calls;
  if (maximum_downstream_optimizer_calls.has_value()) {
    total_optimizer_calls =
        construction_optimizer_calls.value_or(BigNat{0U}) +
        *maximum_downstream_optimizer_calls;
  }
  std::optional<BigNat> total_optimizer_search_states;
  if (!full_orbit_addressed_work && total_optimizer_calls.has_value() &&
      optimizer.effective_per_call.has_value()) {
    total_optimizer_search_states =
        *total_optimizer_calls * *optimizer.effective_per_call;
  } else if (!full_orbit_addressed_work &&
             total_optimizer_calls.has_value() &&
             total_optimizer_calls->is_zero()) {
    total_optimizer_search_states = BigNat{0U};
  }

  PlannedWorkBoundsV1 work{
      std::move(total_optimizer_calls),
      std::move(total_optimizer_search_states),
      construction_generator_draws.has_value()
          ? construction_generator_draws
          : std::optional<BigNat>(BigNat{0U}),
      metric_generator_draws,
      total_generator_draws};
  return Result<BudgetPlan>::success(
      BudgetPlan{std::move(budget), std::move(work)});
}

[[nodiscard]] const MetricSupportClauseV1* find_support_clause(
    const MetricSupportManifest& manifest,
    const MetricClauseIdV1& clause_id) noexcept {
  const auto clauses = manifest.clauses();
  const auto found = std::find_if(
      clauses.begin(), clauses.end(),
      [&](const MetricSupportClauseV1& clause) {
        return clause.clause_id == clause_id;
      });
  return found == clauses.end() ? nullptr : &*found;
}

[[nodiscard]] const MetricRequirementClause* find_requirement_clause(
    const MetricRequirements& requirements,
    const MetricClauseIdV1& clause_id) noexcept {
  const auto clauses = requirements.clauses();
  const auto found = std::find_if(
      clauses.begin(), clauses.end(),
      [&](const MetricRequirementClause& clause) {
        return clause.origin.clause_id == clause_id;
      });
  return found == clauses.end() ? nullptr : &*found;
}

[[nodiscard]] Result<FrameworkScalarKindV1> framework_scalar_law(
    const MetricRequirementClause& requirement,
    const ResolvedMetricContractV1& contract) {
  std::optional<FrameworkScalarKindV1> selected;
  for (const MetricRouteAlternativeV1& route :
       requirement.route_alternatives) {
    if (route.access.backend_route != contract.backend_route ||
        route.access.runtime_access != contract.runtime_access) {
      continue;
    }
    const auto* scalar =
        std::get_if<FrameworkDerivedScalarRequirementV1>(
            &route.semantic.law);
    if (scalar == nullptr) {
      return fail<FrameworkScalarKindV1>(plan_error(
          DiagnosticCategory::internal,
          "c27.framework_scalar_route_law_mismatch",
          "the accepted framework-scalar backend route does not carry a "
          "framework-derived scalar semantic law"));
    }
    if (selected.has_value() && *selected != scalar->scalar) {
      return fail<FrameworkScalarKindV1>(plan_error(
          DiagnosticCategory::internal,
          "c27.framework_scalar_route_ambiguous",
          "the accepted framework-scalar backend route does not identify one "
          "unique scalar semantic law"));
    }
    selected = scalar->scalar;
  }
  if (!selected.has_value()) {
    return fail<FrameworkScalarKindV1>(plan_error(
        DiagnosticCategory::internal,
        "c27.framework_scalar_route_missing",
        "the accepted framework-scalar backend route is absent from its "
        "frozen metric requirements"));
  }
  return Result<FrameworkScalarKindV1>::success(*selected);
}

[[nodiscard]] bool selection_supports(
    const SelectionSupportV1& support,
    const MetricSelectionRegimeV1 selected) noexcept {
  SelectionKindV1 kind = SelectionKindV1::transient_initial;
  switch (selected) {
    case MetricSelectionRegimeV1::transient:
      kind = SelectionKindV1::transient_initial;
      break;
    case MetricSelectionRegimeV1::stationary_unique:
      kind = SelectionKindV1::stationary_unique;
      break;
    case MetricSelectionRegimeV1::stationary_class:
      kind = SelectionKindV1::stationary_class;
      break;
    case MetricSelectionRegimeV1::stationary_mixture:
      kind = SelectionKindV1::stationary_mixture;
      break;
    case MetricSelectionRegimeV1::fixed_point_unique:
      kind = SelectionKindV1::fixed_point_unique;
      break;
    case MetricSelectionRegimeV1::fixed_point_id:
      kind = SelectionKindV1::fixed_point_id;
      break;
  }
  return std::find(support.kinds.begin(), support.kinds.end(), kind) !=
         support.kinds.end();
}

[[nodiscard]] Result<StationaryProofDependencyV1>
make_framework_stationary_proof(
    const MetricRequest& request, const FrameworkScalarKindV1 scalar,
    const MetricRequirementClause& requirement,
    const MetricSupportClauseV1& support, const PlugDescriptorCore& core,
    const ArrivalCapabilities& arrival) {
  const MetricRequestHeader& header = metric_request_header(request);
  if (header.kind != MetricKindV1::stationary_throughput ||
      scalar != FrameworkScalarKindV1::arrival_intensity) {
    return fail<StationaryProofDependencyV1>(plan_error(
        DiagnosticCategory::internal,
        "c27.framework_scalar_stationary_proof_mismatch",
        "the framework-scalar identity route is not the stationary "
        "throughput arrival-intensity theorem"));
  }
  const bool portable_exact_iid =
      (arrival.exact_iid_joint_vector.has_value() &&
       arrival.exact_iid_joint_vector->finite_support &&
       arrival.exact_iid_joint_vector->provision !=
           AccessProvision::process_local_only) ||
      (arrival.exact_factorized_iid_generator.has_value() &&
       arrival.exact_factorized_iid_generator->provision !=
           AccessProvision::process_local_only) ||
      (arrival.exact_portable_iid_recipe.has_value() &&
       arrival.exact_portable_iid_recipe->provision !=
           AccessProvision::process_local_only);
  const bool common_stationary_route =
      support.payload_class == core.payload_class &&
      header.selection_regime != MetricSelectionRegimeV1::transient &&
      selection_supports(support.selection_domain,
                         header.selection_regime);
  const bool c19_scalar_route =
      common_stationary_route && is_builtin_c19_scalar_response(core) &&
      support.phase_domain.payload_phase ==
          PayloadPhaseKindV1::phase_free &&
      header.solver_regime == MetricSolverRegimeV1::analytic &&
      std::holds_alternative<AnalyticAccuracyV1>(
          requirement.accuracy.contract) &&
      portable_exact_iid;
  if (c19_scalar_route) {
    return Result<StationaryProofDependencyV1>::success(
        StationaryProofDependencyV1{
            StationaryProofBackendV1::c19_scalar_iid_summary,
            support.payload_class,
            support.selection_domain,
            header.selection_regime,
            support.phase_domain,
            core.tail,
            support.arrival_assumptions,
            support.hypotheses,
            requirement.accuracy.contract,
            true,
            true});
  }

  const bool c18_finite_route =
      common_stationary_route &&
      (support.runtime_access ==
           RuntimeAccessTagV1::finite_enumerated_row ||
       support.runtime_access == RuntimeAccessTagV1::sparse_row) &&
      header.solver_regime == MetricSolverRegimeV1::enumerated &&
      std::holds_alternative<EnumeratedAccuracyV1>(
          requirement.accuracy.contract);
  if (!c18_finite_route) {
    return fail<StationaryProofDependencyV1>(plan_error(
        DiagnosticCategory::unavailable,
        "c27.framework_scalar_stationary_proof_unavailable",
        "stationary throughput requires either a phase-free finite-prefix "
        "constant-tail IID C19 invariant summary or an exact finite/sparse "
        "C18 row with a selected stationary regime; no flow identity was "
        "treated as an existence proof"));
  }
  return Result<StationaryProofDependencyV1>::success(
      StationaryProofDependencyV1{
          StationaryProofBackendV1::c18_selected_finite_invariant,
          support.payload_class,
          support.selection_domain,
          header.selection_regime,
          support.phase_domain,
          core.tail,
          support.arrival_assumptions,
          support.hypotheses,
          requirement.accuracy.contract,
          false,
          true});
}

[[nodiscard]] Result<void> validate_frozen_route_binding(
    const ResolvedMetricContractV1& contract,
    const MetricRequirementClause& requirement,
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core) {
  if (contract.clause_id != requirement.origin.clause_id ||
      contract.clause_id != support.clause_id ||
      contract.semantic != support.semantic ||
      contract.runtime_access != support.runtime_access ||
      contract.solver_regime != support.solver_route ||
      support.semantic != core.semantic ||
      support.runtime_access != core.runtime_access ||
      support.payload_class != core.payload_class ||
      requirement.accuracy.solver_regime != support.solver_route) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::internal,
        "c27.accepted_route_binding_mismatch",
        "the accepted metric route no longer binds one exact requirement, "
        "support clause, descriptor semantic/access pair, and solver"));
  }

  const auto route = std::ranges::find_if(
      requirement.route_alternatives,
      [&](const MetricRouteAlternativeV1& alternative) {
        return alternative.access.backend_route == contract.backend_route &&
               alternative.access.runtime_access == contract.runtime_access;
      });
  if (route == requirement.route_alternatives.end()) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::internal,
        "c27.accepted_route_alternative_missing",
        "the accepted backend/access pair is absent from the frozen complete "
        "metric-route alternatives"));
  }

  switch (contract.backend_route) {
    case BackendRouteKindV1::conditional_row_monte_carlo:
    case BackendRouteKindV1::conditional_reward_monte_carlo:
      if (contract.runtime_access !=
              RuntimeAccessTagV1::normalized_conditional_sampler ||
          contract.solver_regime != SolverRegimeV1::monte_carlo ||
          !route->access.c24_row_or_reward_only ||
          route->access.exact_request_only) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.sampler_route_binding_mismatch",
            "a C24 route must be the exact normalized conditional-sampler "
            "row/reward alternative selected by C14"));
      }
      break;
    case BackendRouteKindV1::exact_direct:
      if (contract.runtime_access !=
              RuntimeAccessTagV1::direct_metric_decoder ||
          contract.solver_regime != SolverRegimeV1::direct ||
          !route->access.exact_request_only ||
          route->access.c24_row_or_reward_only ||
          contract.semantic != SemanticTagV1::direct_metric_decoder) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.direct_route_binding_mismatch",
            "a direct route must retain the exact-request decoder semantic, "
            "access, and solver selected by C14"));
      }
      break;
    default:
      if (route->access.exact_request_only ||
          route->access.c24_row_or_reward_only ||
          contract.runtime_access ==
              RuntimeAccessTagV1::direct_metric_decoder ||
          contract.runtime_access ==
              RuntimeAccessTagV1::normalized_conditional_sampler) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.reusable_route_binding_mismatch",
            "a reusable exact/analytic route cannot acquire direct-decoder "
            "or C24 conditional-sampler authority"));
      }
      break;
  }
  return Result<void>::success();
}

[[nodiscard]] Result<MetricBackendPlanV1> make_backend_plan(
    const MetricRequest& request,
    const ResolvedMetricContractV1& contract,
    const MetricRequirementClause& requirement,
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core,
    const ArrivalCapabilities& arrival) {
  auto frozen_route =
      validate_frozen_route_binding(contract, requirement, support, core);
  if (!frozen_route) {
    return fail<MetricBackendPlanV1>(frozen_route.error());
  }
  switch (contract.backend_route) {
    case BackendRouteKindV1::framework_scalar_identity: {
      auto scalar = framework_scalar_law(requirement, contract);
      if (!scalar) {
        return fail<MetricBackendPlanV1>(scalar.error());
      }
      auto proof = make_framework_stationary_proof(
          request, scalar.value(), requirement, support, core, arrival);
      if (!proof) {
        return fail<MetricBackendPlanV1>(proof.error());
      }
      return Result<MetricBackendPlanV1>::success(
          FrameworkScalarIdentityBackendPlanV1{
              scalar.value(), std::move(proof).value()});
    }
    case BackendRouteKindV1::stationary_invariant:
      return Result<MetricBackendPlanV1>::success(
          StationaryInvariantBackendPlanV1{support.selection_domain,
                                           core.tail});
    case BackendRouteKindV1::stationary_edge_reward:
      return Result<MetricBackendPlanV1>::success(
          StationaryEdgeRewardBackendPlanV1{support.selection_domain,
                                            support.marks});
    case BackendRouteKindV1::finite_temporal_cylinder:
      return Result<MetricBackendPlanV1>::success(
          FiniteTemporalCylinderBackendPlanV1{support.phase_domain,
                                              support.marks});
    case BackendRouteKindV1::analytic_metric_family:
      return Result<MetricBackendPlanV1>::success(
          AnalyticMetricFamilyBackendPlanV1{
              requirement.accuracy.contract});
    case BackendRouteKindV1::residence_or_stopped_law:
      return Result<MetricBackendPlanV1>::success(
          ResidenceOrStoppedLawBackendPlanV1{
              support.selection_domain, support.phase_domain,
              core.tail, support.marks});
    case BackendRouteKindV1::palm_or_fifo_law:
      return Result<MetricBackendPlanV1>::success(
          PalmOrFifoLawBackendPlanV1{support.selection_domain,
                                     support.marks});
    case BackendRouteKindV1::conditional_row_monte_carlo: {
      const auto* accuracy = std::get_if<MonteCarloAccuracyV1>(
          &requirement.accuracy.contract);
      if (accuracy == nullptr) {
        return fail<MetricBackendPlanV1>(plan_error(
            DiagnosticCategory::internal,
            "c27.monte_carlo_accuracy_missing",
            "a conditional-row Monte Carlo route lacks its exact accepted "
            "Monte Carlo accuracy contract"));
      }
      return Result<MetricBackendPlanV1>::success(
          ConditionalRowMonteCarloBackendPlanV1{*accuracy,
                                                accuracy->replications});
    }
    case BackendRouteKindV1::conditional_reward_monte_carlo: {
      const auto* accuracy = std::get_if<MonteCarloAccuracyV1>(
          &requirement.accuracy.contract);
      if (accuracy == nullptr) {
        return fail<MetricBackendPlanV1>(plan_error(
            DiagnosticCategory::internal,
            "c27.monte_carlo_accuracy_missing",
            "a conditional-reward Monte Carlo route lacks its exact accepted "
            "Monte Carlo accuracy contract"));
      }
      return Result<MetricBackendPlanV1>::success(
          ConditionalRewardMonteCarloBackendPlanV1{
              *accuracy, accuracy->replications});
    }
    case BackendRouteKindV1::exact_direct: {
      const auto* domain =
          std::get_if<ExactMetricDecoderDomainV1>(&support.parameter_domain);
      if (domain == nullptr ||
          domain->exact_parameters != metric_request_parameters(request)) {
        return fail<MetricBackendPlanV1>(plan_error(
            DiagnosticCategory::input_validation,
            "c27.direct_decoder_key_missing",
            "the direct route lacks a decoder key for the exact requested "
            "metric parameters"));
      }
      return Result<MetricBackendPlanV1>::success(ExactDirectBackendPlanV1{
          domain->decoder_key, domain->exact_parameters});
    }
  }
  return fail<MetricBackendPlanV1>(plan_error(
      DiagnosticCategory::internal, "c27.unknown_backend_route",
      "the accepted capability contract contains an unknown backend route"));
}

[[nodiscard]] bool c19_metric_adapter_is_implemented(
    const MetricRequest& request) noexcept;

[[nodiscard]] SharedDependencyKindV1 dependency_kind(
    const PlannedMetricV1& metric,
    const bool built_in_c19_scalar) noexcept {
  if (built_in_c19_scalar &&
      c19_metric_adapter_is_implemented(metric.request())) {
    switch (metric.route_kind()) {
      case BackendRouteKindV1::framework_scalar_identity:
      case BackendRouteKindV1::stationary_invariant:
      case BackendRouteKindV1::stationary_edge_reward:
      case BackendRouteKindV1::analytic_metric_family:
        return SharedDependencyKindV1::
            c19_scalar_iid_stationary_summary;
      default:
        break;
    }
  }
  switch (metric.route_kind()) {
    case BackendRouteKindV1::framework_scalar_identity: {
      const auto* scalar =
          std::get_if<FrameworkScalarIdentityBackendPlanV1>(
              &metric.backend());
      return scalar != nullptr &&
                     scalar->stationary_proof.backend ==
                         StationaryProofBackendV1::c19_scalar_iid_summary
                 ? SharedDependencyKindV1::
                       c19_scalar_iid_stationary_summary
                 : SharedDependencyKindV1::stationary_invariant;
    }
    case BackendRouteKindV1::stationary_invariant:
      return SharedDependencyKindV1::stationary_invariant;
    case BackendRouteKindV1::stationary_edge_reward:
      return SharedDependencyKindV1::stationary_edge_law;
    case BackendRouteKindV1::finite_temporal_cylinder:
      return SharedDependencyKindV1::finite_temporal_kernel;
    case BackendRouteKindV1::analytic_metric_family:
      return SharedDependencyKindV1::analytic_metric_family;
    case BackendRouteKindV1::residence_or_stopped_law:
      return SharedDependencyKindV1::residence_or_stopped_law;
    case BackendRouteKindV1::palm_or_fifo_law:
      return SharedDependencyKindV1::palm_or_fifo_law;
    case BackendRouteKindV1::conditional_row_monte_carlo:
      return SharedDependencyKindV1::conditional_row_sampler;
    case BackendRouteKindV1::conditional_reward_monte_carlo:
      return SharedDependencyKindV1::conditional_reward_sampler;
    case BackendRouteKindV1::exact_direct:
      return SharedDependencyKindV1::exact_direct_decoder;
  }
  return SharedDependencyKindV1::exact_direct_decoder;
}

[[nodiscard]] std::vector<DependencySharingGroupV1>
make_dependency_schedule(std::span<const PlannedMetricV1> metrics,
                         const Digest256& descriptor_core_digest,
                         const ArrivalBinding& configured_arrival,
                         const bool built_in_c19_scalar) {
  std::vector<DependencySharingGroupV1> schedule;
  schedule.reserve(metrics.size());
  for (const PlannedMetricV1& metric : metrics) {
    const MetricRequestHeader& header =
        metric_request_header(metric.request());
    const SharedDependencyKindV1 kind =
        dependency_kind(metric, built_in_c19_scalar);
    SharedDependencyIdentityV1 identity{
        descriptor_core_digest,
        configured_arrival,
        header.ordered_targets,
        header.selection_regime,
        header.solver_regime,
        header.kind,
        metric_request_parameters(metric.request()),
        metric.backend()};
    const auto found = std::find_if(
        schedule.begin(), schedule.end(),
        [&](const DependencySharingGroupV1& group) {
          return group.kind == kind && group.identity == identity;
        });
    if (found == schedule.end()) {
      schedule.push_back(DependencySharingGroupV1{
          kind, std::move(identity), {header.authored_index}});
    } else {
      found->authored_metric_indices.push_back(header.authored_index);
    }
  }
  return schedule;
}

[[nodiscard]] Result<std::vector<RngAddressTemplateV1>>
make_rng_address_templates(
    std::span<const PlannedMetricV1> metrics,
    const std::optional<FrameworkActivationCapabilitiesV1>& capabilities) {
  std::vector<RngAddressTemplateV1> templates;
  templates.reserve(metrics.size());
  for (const PlannedMetricV1& metric : metrics) {
    const MonteCarloAccuracyV1* accuracy = nullptr;
    if (const auto* row =
            std::get_if<ConditionalRowMonteCarloBackendPlanV1>(
                &metric.backend())) {
      accuracy = &row->accuracy;
    } else if (const auto* reward =
                   std::get_if<ConditionalRewardMonteCarloBackendPlanV1>(
                       &metric.backend())) {
      accuracy = &reward->accuracy;
    }
    if (accuracy == nullptr) {
      continue;
    }
    if (!capabilities.has_value() ||
        !capabilities->conditional_sampler_rng_stage.has_value() ||
        !capabilities->conditional_sampler_dependence.has_value() ||
        !capabilities->conditional_estimator_procedure.has_value()) {
      return Result<std::vector<RngAddressTemplateV1>>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.sampler_procedure_not_registered",
          "the accepted conditional sampler has no complete callback-free "
          "stage, dependence, and estimator procedure, so C27 cannot freeze "
          "its reproducible statistical plan"));
    }

    const MetricRequestHeader& header =
        metric_request_header(metric.request());
    templates.push_back(RngAddressTemplateV1{
        1U,
        header.authored_index,
        metric.contract().clause_id,
        metric.route_kind(),
        RngInstanceKeyRouteV1::conditional_estimator,
        *capabilities->conditional_sampler_rng_stage,
        "c27." + header.metric_id,
        metric.contract().support_clause_digest,
        accuracy->replications,
        *capabilities->conditional_sampler_dependence,
        *capabilities->conditional_estimator_procedure,
        capabilities->conditional_reward_premises,
    });
  }
  return Result<std::vector<RngAddressTemplateV1>>::success(
      std::move(templates));
}

[[nodiscard]] bool is_c24_rng_stage(const StageTag stage) noexcept {
  switch (stage) {
    case StageTag::prearrival_closure:
    case StageTag::postarrival_closure:
    case StageTag::generic_sampling:
    case StageTag::importance_proposal:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] bool exact_binary_reward_premises(
    const ConditionalRewardPremisesV1& premises) noexcept {
  return premises.binary_indicator &&
         premises.almost_sure_lower == ExactRational::zero() &&
         premises.almost_sure_upper == ExactRational::one();
}

[[nodiscard]] Result<void> validate_conditional_sampling_premises(
    const PlannedMetricV1& metric,
    const std::optional<FrameworkActivationCapabilitiesV1>& capabilities) {
  const auto* row =
      std::get_if<ConditionalRowMonteCarloBackendPlanV1>(&metric.backend());
  const auto* reward =
      std::get_if<ConditionalRewardMonteCarloBackendPlanV1>(&metric.backend());
  if (row == nullptr && reward == nullptr) {
    return Result<void>::success();
  }
  const MetricRequestHeader& header = metric_request_header(metric.request());
  const auto reject = [&](std::string message) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        "c27.sampling_procedure_premise_mismatch", std::move(message),
        std::nullopt, {"metric: " + header.metric_id,
                       "no provider was executed"}));
  };
  if (!capabilities.has_value() ||
      !capabilities->conditional_sampler_rng_stage.has_value() ||
      !capabilities->conditional_sampler_dependence.has_value() ||
      !capabilities->conditional_estimator_procedure.has_value()) {
    return reject("the conditional Monte Carlo route lacks a complete typed "
                  "sampler stage, dependence, and estimator procedure");
  }
  const StageTag stage = *capabilities->conditional_sampler_rng_stage;
  const ConditionalSampleDependenceV1 dependence =
      *capabilities->conditional_sampler_dependence;
  const ConditionalEstimatorProcedureV1 procedure =
      *capabilities->conditional_estimator_procedure;
  const bool proposal =
      dependence == ConditionalSampleDependenceV1::iid_proposal;
  const bool direct =
      dependence == ConditionalSampleDependenceV1::iid_cold_replications ||
      dependence == ConditionalSampleDependenceV1::correlated_trace;
  const bool importance = procedure ==
                          ConditionalEstimatorProcedureV1::
                              self_normalized_importance;
  const bool empirical = procedure ==
                         ConditionalEstimatorProcedureV1::
                             conditional_empirical_row;
  const bool reward_mean = procedure ==
                           ConditionalEstimatorProcedureV1::
                               conditional_reward_mean;
  const bool direct_stage = stage == StageTag::prearrival_closure ||
                            stage == StageTag::postarrival_closure ||
                            stage == StageTag::generic_sampling;
  if ((!proposal && !direct) || (proposal != importance) ||
      (proposal ? stage != StageTag::importance_proposal : !direct_stage) ||
      (row != nullptr ? !empirical : empirical) ||
      (reward != nullptr && !reward_mean && !importance)) {
    return reject("the registered dependence, RNG stage, estimator procedure, "
                  "and accepted row/reward route are inconsistent");
  }

  const MonteCarloAccuracyV1& accuracy =
      row != nullptr ? row->accuracy : reward->accuracy;
  if (empirical) {
    if (accuracy.interval != StatisticalIntervalKindV1::none ||
        accuracy.estimand != StatisticalEstimandKindV1::
                                 point_with_variance_diagnostics ||
        capabilities->conditional_reward_premises.has_value()) {
      return reject("the empirical-row procedure cannot advertise a scalar "
                    "reward interval or reward-decoder premises");
    }
    return Result<void>::success();
  }
  if (!capabilities->conditional_reward_premises.has_value() ||
      !exact_binary_reward_premises(
          *capabilities->conditional_reward_premises)) {
    return reject("the singleton backlog-conditioned-service route requires "
                  "a registered binary reward with exact support [0,1]");
  }

  switch (accuracy.interval) {
    case StatisticalIntervalKindV1::exact_binomial:
      if (!reward_mean || dependence !=
                              ConditionalSampleDependenceV1::
                                  iid_cold_replications ||
          accuracy.estimand !=
              StatisticalEstimandKindV1::binary_proportion ||
          accuracy.almost_sure_lower != ExactRational::zero() ||
          accuracy.almost_sure_upper != ExactRational::one()) {
        return reject("exact_binomial requires the IID direct binary-reward "
                      "mean procedure and exact authored support [0,1]");
      }
      break;
    case StatisticalIntervalKindV1::hoeffding: {
      const ConditionalRewardPremisesV1& premises =
          *capabilities->conditional_reward_premises;
      if (!reward_mean || dependence !=
                              ConditionalSampleDependenceV1::
                                  iid_cold_replications ||
          (accuracy.estimand != StatisticalEstimandKindV1::bounded_iid &&
           accuracy.estimand !=
               StatisticalEstimandKindV1::binary_proportion) ||
          !accuracy.almost_sure_lower.has_value() ||
          !accuracy.almost_sure_upper.has_value() ||
          *accuracy.almost_sure_lower > *accuracy.almost_sure_upper ||
          !std::isfinite(accuracy.almost_sure_lower->to_long_double()) ||
          !std::isfinite(accuracy.almost_sure_upper->to_long_double()) ||
          premises.almost_sure_lower != accuracy.almost_sure_lower ||
          premises.almost_sure_upper != accuracy.almost_sure_upper) {
        return reject("Hoeffding requires the IID direct reward-mean "
                      "procedure and one identical finite exact authored and "
                      "decoder range");
      }
      break;
    }
    case StatisticalIntervalKindV1::none:
      if (accuracy.estimand != StatisticalEstimandKindV1::
                                   point_with_variance_diagnostics) {
        return reject("the no-interval procedure requires the "
                      "point-with-variance-diagnostics estimand");
      }
      break;
    default:
      return reject("the interval method is outside the closed C24 policy");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_scalar_response_contract(
    const FrameworkProblemView& problem,
    const PlugDescriptorPreview& preview) {
  const bool three_bin = preview.core.payload_class.tag ==
                         PayloadClassTagV1::three_bin_scalar_response_v1;
  const bool finite_prefix =
      preview.core.payload_class.tag ==
      PayloadClassTagV1::finite_prefix_constant_tail_response_v1;
  if (!three_bin && !finite_prefix) {
    return Result<void>::success();
  }
  if (preview.core.payload_class.version != 1U) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        finite_prefix ? "c29.unsupported_scalar_response_payload_version"
                      : "c27.unsupported_three_bin_payload_version",
        "the scalar-response route supports only version 1 of its selected "
        "payload class"));
  }
  const auto runtime_targets = problem.target_selection().ordered_targets;
  if (runtime_targets.size() != 1U ||
      preview.core.deployed_targets.size() != 1U ||
      preview.core.deployed_targets.front() != runtime_targets.front()) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        three_bin ? "c27.three_bin_singleton_target_required"
                  : "c29.scalar_response_singleton_target_required",
        "the scalar-response payload must bind exactly the one authored "
        "runtime target; submit separate analysis documents for additional "
        "targets",
        "/targets"));
  }
  if (preview.core.semantic != SemanticTagV1::scalar_backlog_response ||
      preview.core.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      preview.core.target_coupling != TargetCouplingV1::scalar_target) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        three_bin ? "c27.three_bin_contract_mismatch"
                  : "c29.scalar_response_contract_mismatch",
        "the scalar-response payload requires the scalar backlog-response "
        "semantic, finite-parameter analytic access, and scalar coupling"));
  }
  if (preview.core.phase.payload_phase !=
      PayloadPhaseKindV1::phase_free) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        three_bin ? "c27.three_bin_payload_must_be_phase_free"
                  : "c29.scalar_response_payload_must_be_phase_free",
        "the scalar-response payload cannot contain phase-indexed response "
        "coefficients"));
  }
  if (preview.core.tail.kind !=
          TailRepresentationKindV1::constant_response ||
      !preview.core.tail.boundary.has_value() ||
      (three_bin ? *preview.core.tail.boundary != BigNat{3U}
                 : (*preview.core.tail.boundary < BigNat{3U} ||
                    *preview.core.tail.boundary > BigNat{6U}))) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        three_bin ? "c27.three_bin_tail_contract_mismatch"
                  : "c29.scalar_response_tail_contract_mismatch",
        three_bin
            ? "three_bin_scalar_response_v1 requires bins {1}, {2}, and "
              "the constant-response tail beginning at backlog 3"
            : "finite_prefix_constant_tail_response_v1 requires exact "
              "positive levels 1 through K and the constant-response tail "
              "beginning at K+1 for 2 <= K <= 5"));
  }
  const bool construction_contains_runtime = std::find(
      preview.construction_target_scope.begin(),
      preview.construction_target_scope.end(), runtime_targets.front()) !=
      preview.construction_target_scope.end();
  if (!construction_contains_runtime) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        three_bin ? "c27.three_bin_construction_scope_missing_target"
                  : "c29.scalar_response_construction_scope_missing_target",
        "the construction target scope does not contain the singleton "
        "runtime target"));
  }
  return Result<void>::success();
}

[[nodiscard]] bool same_targets(
    const std::vector<ResolvedMetricTargetV1>& left,
    const std::vector<ResolvedMetricTargetV1>& right) noexcept {
  return left == right;
}

[[nodiscard]] bool same_metric_request(const MetricRequest& left,
                                       const MetricRequest& right) {
  const MetricRequestHeader& left_header = metric_request_header(left);
  const MetricRequestHeader& right_header = metric_request_header(right);
  return metric_request_kind(left) == metric_request_kind(right) &&
         left_header.metric_id == right_header.metric_id &&
         left_header.authored_index == right_header.authored_index &&
         left_header.kind == right_header.kind &&
         left_header.coupling == right_header.coupling &&
         left_header.ordered_targets == right_header.ordered_targets &&
         left_header.selection_regime == right_header.selection_regime &&
         left_header.solver_regime == right_header.solver_regime &&
         metric_request_parameters(left) == metric_request_parameters(right);
}

[[nodiscard]] bool same_metric_requests(
    std::span<const MetricRequest> left,
    std::span<const MetricRequest> right) {
  return left.size() == right.size() &&
         std::equal(left.begin(), left.end(), right.begin(), right.end(),
                    same_metric_request);
}

[[nodiscard]] SolverRegimeV1 solver_regime(
    const MetricSolverRegimeV1 value) noexcept {
  switch (value) {
    case MetricSolverRegimeV1::enumerated:
      return SolverRegimeV1::enumerated;
    case MetricSolverRegimeV1::analytic:
      return SolverRegimeV1::analytic;
    case MetricSolverRegimeV1::monte_carlo:
      return SolverRegimeV1::monte_carlo;
    case MetricSolverRegimeV1::direct:
      return SolverRegimeV1::direct;
  }
  return SolverRegimeV1::direct;
}

[[nodiscard]] bool c19_metric_adapter_is_implemented(
    const MetricRequest& request) noexcept {
  switch (metric_request_kind(request)) {
    case MetricKindV1::stationary_throughput:
    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::mean_sojourn:
    case MetricKindV1::backlog_conditioned_service:
      return true;
    case MetricKindV1::stationary_backlog_moment: {
      const auto* moment =
          std::get_if<StationaryBacklogMomentRequestV1>(&request);
      return moment != nullptr && moment->parameters().order == BigNat{1U};
    }
    case MetricKindV1::stationary_backlog_tail: {
      const auto* tail =
          std::get_if<StationaryBacklogTailRequestV1>(&request);
      return tail != nullptr &&
             tail->parameters().threshold <= BigNat{3U};
    }
    case MetricKindV1::stationary_backlog_pmf: {
      const auto* pmf =
          std::get_if<StationaryBacklogPmfRequestV1>(&request);
      if (pmf == nullptr) {
        return false;
      }
      const auto* through = std::get_if<PmfThroughLevelV1>(
          &pmf->parameters().domain);
      return through != nullptr && through->max_level <= BigNat{2U};
    }
    default:
      return false;
  }
}

[[nodiscard]] bool c18_scalar_adapter_is_implemented(
    const MetricKindV1 kind) noexcept {
  switch (kind) {
    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::stationary_backlog_moment:
    case MetricKindV1::stationary_backlog_tail:
    case MetricKindV1::stationary_edge_reward:
    case MetricKindV1::joint_backlog_event:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] bool stationary_suspension_adapter_is_implemented(
    const MetricKindV1 kind) noexcept {
  switch (kind) {
    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::stationary_backlog_pmf:
    case MetricKindV1::stationary_backlog_pgf:
    case MetricKindV1::stationary_backlog_moment:
    case MetricKindV1::stationary_backlog_quantile:
    case MetricKindV1::stationary_backlog_tail:
    case MetricKindV1::stationary_edge_reward:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] bool stationary_temporal_statistic_adapter_is_implemented(
    const MetricKindV1 kind) noexcept {
  switch (kind) {
    case MetricKindV1::service_persistence:
    case MetricKindV1::service_autocovariance:
    case MetricKindV1::service_window_count:
    case MetricKindV1::service_spectrum:
    case MetricKindV1::mean_event_gap:
    case MetricKindV1::mean_binary_run:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] bool transient_temporal_adapter_is_implemented(
    const MetricKindV1 kind) noexcept {
  return kind == MetricKindV1::transient_backlog_law ||
         kind == MetricKindV1::first_hit ||
         kind == MetricKindV1::threshold_excursion;
}

[[nodiscard]] bool native_size_bound(const BigNat& value,
                                     const bool needs_successor = false) {
  if (value.bit_length() > std::numeric_limits<std::size_t>::digits) {
    return false;
  }
  const std::size_t native = value.value().convert_to<std::size_t>();
  return !needs_successor ||
         native != std::numeric_limits<std::size_t>::max();
}

// The dense exact backends flatten an n-by-n table through size_t and pass n
// to Eigen's project-default DenseIndex (std::ptrdiff_t).  Validate both
// representations from callback-free bounds before provider execution.
[[nodiscard]] bool native_dense_square_bound(const BigNat& value) {
  if (!native_size_bound(value)) {
    return false;
  }
  const std::size_t dimension = value.value().convert_to<std::size_t>();
  if (dimension == 0U ||
      dimension >
          std::numeric_limits<std::size_t>::max() / dimension) {
    return false;
  }
  if constexpr (std::numeric_limits<std::ptrdiff_t>::digits <
                std::numeric_limits<std::size_t>::digits) {
    if (dimension > static_cast<std::size_t>(
                        std::numeric_limits<std::ptrdiff_t>::max())) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool finite_nonnegative_image(
    const ExactRational& value) {
  const long double image = value.to_long_double();
  return std::isfinite(image) && image >= 0.0L;
}

[[nodiscard]] Result<void> validate_metric_native_bounds(
    const MetricRequest& request) {
  const MetricRequestHeader& header = metric_request_header(request);
  const auto reject = [&](const std::string& role) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::resource_limit,
        "c27.metric_native_bound_exceeded",
        "the authored " + role +
            " cannot be represented by the selected finite backend before "
            "provider execution",
        std::nullopt, {"metric: " + header.metric_id}));
  };
  const auto check = [&](const BigNat& value, const std::string& role,
                         const bool needs_successor = false) {
    return native_size_bound(value, needs_successor)
               ? Result<void>::success()
               : reject(role);
  };
  if (header.context != nullptr) {
    const auto* monte_carlo =
        std::get_if<MonteCarloSolver>(&header.context->solver);
    if (monte_carlo != nullptr &&
        !native_size_bound(monte_carlo->replications)) {
      return reject("Monte Carlo replication count");
    }
  }
  return std::visit(
      [&](const auto& typed) -> Result<void> {
        using Request = std::decay_t<decltype(typed)>;
        const auto& parameters = typed.parameters();
        if constexpr (std::is_same_v<Request,
                                     ServiceAutocovarianceRequestV1> ||
                      std::is_same_v<
                          Request, LaggedCrossQueueCovarianceRequestV1>) {
          for (const BigNat& lag : parameters.lags) {
            auto valid = check(lag, "lag", true);
            if (!valid) return valid;
          }
        } else if constexpr (std::is_same_v<Request,
                                            ServiceSpectrumRequestV1>) {
          return check(parameters.truncation_lag, "truncation lag", true);
        } else if constexpr (std::is_same_v<Request,
                                            ServiceWindowCountRequestV1>) {
          return check(parameters.width, "service-window width", true);
        } else if constexpr (std::is_same_v<
                                 Request, EventGapDistributionRequestV1> ||
                             std::is_same_v<
                                 Request,
                                 BinaryRunDistributionRequestV1> ||
                             std::is_same_v<Request, FirstHitRequestV1> ||
                             std::is_same_v<
                                 Request, ThresholdExcursionRequestV1> ||
                             std::is_same_v<
                                 Request,
                                 CounterfactualOpportunityGapRequestV1> ||
                             std::is_same_v<Request, JointDelayRequestV1> ||
                             std::is_same_v<
                                 Request, OrderedScheduleSequenceRequestV1>) {
          return check(parameters.horizon, "horizon", true);
        } else if constexpr (std::is_same_v<
                                 Request, TransientBacklogLawRequestV1>) {
          for (const BigNat& horizon : parameters.horizons) {
            auto valid = check(horizon, "horizon", true);
            if (!valid) return valid;
          }
        } else if constexpr (std::is_same_v<Request, FifoDelayRequestV1> ||
                             std::is_same_v<
                                 Request, FifoDelayConditionedRequestV1>) {
          if (const auto* pmf =
                  std::get_if<FifoDelayPmfOutputV1>(&parameters.output)) {
            auto valid = check(pmf->horizon, "FIFO PMF horizon", true);
            if (!valid) return valid;
          }
          if (const auto* tail =
                  std::get_if<FifoDelayTailOutputV1>(&parameters.output)) {
            auto valid = check(tail->horizon, "FIFO tail horizon", true);
            if (!valid) return valid;
          }
          if (const auto* moment =
                  std::get_if<FifoDelayMomentOutputV1>(&parameters.output)) {
            if (!native_size_bound(moment->order) ||
                moment->order > BigNat{4096U}) {
              return Result<void>::failure(plan_error(
                  DiagnosticCategory::resource_limit,
                  "c27.fifo_moment_order_exceeded",
                  "the exact C23 FIFO moment adapter supports authored "
                  "orders through 4096 before provider execution",
                  std::nullopt, {"metric: " + header.metric_id}));
            }
          }
          if constexpr (std::is_same_v<
                            Request, FifoDelayConditionedRequestV1>) {
            if (const auto* rank =
                    std::get_if<FifoRankConditionV1>(
                        &parameters.condition)) {
              return check(rank->one_based_rank, "FIFO rank");
            }
            if (const auto* batch =
                    std::get_if<FifoBatchConditionV1>(
                        &parameters.condition)) {
              return check(batch->batch_size, "FIFO batch size");
            }
          }
        }
        return Result<void>::success();
      },
      request);
}

[[nodiscard]] const FifoDelayOutputV1* fifo_output(
    const MetricRequest& request) noexcept {
  if (const auto* fifo = std::get_if<FifoDelayRequestV1>(&request)) {
    return &fifo->parameters().output;
  }
  if (const auto* fifo =
          std::get_if<FifoDelayConditionedRequestV1>(&request)) {
    return &fifo->parameters().output;
  }
  return nullptr;
}

[[nodiscard]] const FifoConditionV1* fifo_condition(
    const MetricRequest& request) noexcept {
  const auto* fifo =
      std::get_if<FifoDelayConditionedRequestV1>(&request);
  return fifo == nullptr ? nullptr : &fifo->parameters().condition;
}

[[nodiscard]] bool same_fifo_group(const MetricRequest& left,
                                   const MetricRequest& right) noexcept {
  const MetricRequestHeader& left_header = metric_request_header(left);
  const MetricRequestHeader& right_header = metric_request_header(right);
  if (left_header.ordered_targets != right_header.ordered_targets) {
    return false;
  }
  const FifoConditionV1* left_condition = fifo_condition(left);
  const FifoConditionV1* right_condition = fifo_condition(right);
  return (left_condition == nullptr && right_condition == nullptr) ||
         (left_condition != nullptr && right_condition != nullptr &&
          *left_condition == *right_condition);
}

[[nodiscard]] bool exact_backlog_only_sampler_shape(
    const PlugDescriptorCore& core) noexcept {
  return core.payload_class.tag ==
             PayloadClassTagV1::registered_runtime_recipe_v1 &&
         core.payload_class.version == 1U &&
         core.semantic == SemanticTagV1::staged_opportunity_flux_law &&
         core.runtime_access ==
             RuntimeAccessTagV1::normalized_conditional_sampler &&
         core.target_coupling == TargetCouplingV1::scalar_target &&
         core.deployed_targets.size() == 1U &&
         core.phase.payload_phase == PayloadPhaseKindV1::phase_free &&
         core.phase.arrival_composition ==
             ConfiguredArrivalCompositionV1::iid_late_arrival &&
         !core.phase.retains_configured_predictive_phase &&
         !core.phase.predictive_phase_codec.has_value() &&
         core.state_fields.size() == 1U &&
         core.state_fields.front().kind ==
             StateFieldKindV1::target_backlog &&
         core.state_fields.front().ownership ==
             FieldOwnershipV1::framework_exact;
}

[[nodiscard]] bool hit_set_contains(const MetricHitSetV1& set,
                                    const BigNat& backlog) noexcept {
  switch (set.kind) {
    case HitSetKind::at_or_above:
      return backlog >= set.level;
    case HitSetKind::at_or_below:
      return backlog <= set.level;
    case HitSetKind::equal:
      return backlog == set.level;
  }
  return false;
}

[[nodiscard]] Result<void> validate_transient_entrance_predicate(
    const std::optional<InitialPhysicalLaw>& initial_law,
    const MetricRequest& request) {
  const MetricRequestHeader& header = metric_request_header(request);
  const MetricHitSetV1* set = nullptr;
  bool require_inside = false;
  if (const auto* first = std::get_if<FirstHitRequestV1>(&request)) {
    set = &first->parameters().set;
  } else if (const auto* excursion =
                 std::get_if<ThresholdExcursionRequestV1>(&request)) {
    set = &excursion->parameters().set;
    require_inside = true;
  } else {
    return Result<void>::success();
  }
  if (!initial_law.has_value() || header.ordered_targets.size() != 1U) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::internal,
        "c27.transient_entrance_law_missing",
        "the transient stopped-law route lost its compiled physical entrance "
        "law or singleton target"));
  }
  const std::size_t coordinate =
      header.ordered_targets.front().dense_index.ordinal();
  bool found_positive_mass = false;
  for (const InitialPhysicalAtom& atom : initial_law->atoms()) {
    if (atom.probability.is_zero()) continue;
    found_positive_mass = true;
    if (coordinate >= atom.backlog.size()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.transient_entrance_coordinate_missing",
          "the compiled physical entrance law lacks the planned target "
          "backlog coordinate"));
    }
    const bool inside = hit_set_contains(*set, atom.backlog[coordinate]);
    if (inside != require_inside) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          require_inside
              ? "c27.threshold_excursion_entrance_outside_predicate"
              : "c27.first_hit_entrance_already_absorbed",
          require_inside
              ? "every positive-mass authored entrance atom for a transient "
                "threshold-excursion law must lie inside the requested "
                "excursion set"
              : "every positive-mass authored entrance atom for a transient "
                "first-hit law must lie outside the requested hit set",
          std::nullopt, {"metric: " + header.metric_id}));
    }
  }
  if (!found_positive_mass) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::internal,
        "c27.transient_entrance_law_empty",
        "the compiled transient physical entrance law has no positive-mass "
        "atom",
        std::nullopt, {"metric: " + header.metric_id}));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_execution_availability(
    const SurrogateProvider& provider, const PlugDescriptorPreview& preview,
    const AcceptedCapabilityContract& accepted,
    std::span<const PlannedMetricV1> metrics,
    const std::optional<InitialPhysicalLaw>& initial_law) {
  const bool built_in_c19_scalar =
      is_builtin_c19_scalar_response(preview.core);
  const std::optional<FrameworkActivationCapabilitiesV1>
      activation_capabilities =
          provider.framework_activation_capabilities();
  if (activation_capabilities.has_value() &&
      activation_capabilities->conditional_sampler_rng_stage.has_value() &&
      !is_c24_rng_stage(
          *activation_capabilities->conditional_sampler_rng_stage)) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        "c27.sampler_rng_stage_invalid",
        "the registered conditional sampler names an RNG stage outside the "
        "closed C24 prearrival, postarrival, generic-sampling, and "
        "importance-proposal stage set; no provider was executed"));
  }
  const std::size_t direct_metrics = static_cast<std::size_t>(
      std::count_if(metrics.begin(), metrics.end(),
                    [](const PlannedMetricV1& metric) {
                      return metric.route_kind() ==
                             BackendRouteKindV1::exact_direct;
                    }));
  if (direct_metrics != 0U &&
      (direct_metrics != 1U || metrics.size() != 1U ||
       accepted.structural_manifest().clauses().size() != 1U)) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::input_validation,
        "c27.direct_decoder_single_metric_required",
        "C16's raw direct-decoder seam exposes exactly one accepted metric "
        "value and structural clause; submit each direct metric in a "
        "separate analysis document so no provider is executed"));
  }
  if (built_in_c19_scalar) {
    for (const PlannedMetricV1& metric : metrics) {
      const MetricRequestHeader& header =
          metric_request_header(metric.request());
      if (header.selection_regime !=
          MetricSelectionRegimeV1::stationary_unique) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.three_bin_stationary_unique_required",
            "the C19 ThreeBin adapter proves only its unique stationary IID "
            "law; stationary class or mixture labels cannot be mapped to "
            "that law before provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
    }
  }
  for (const PlannedMetricV1& metric : metrics) {
    const BackendRouteKindV1 route = metric.route_kind();
    const MetricRequestHeader& header =
        metric_request_header(metric.request());
    auto sampling_premises = validate_conditional_sampling_premises(
        metric, activation_capabilities);
    if (!sampling_premises) return sampling_premises;
    if (route != BackendRouteKindV1::exact_direct) {
      auto native_bounds = validate_metric_native_bounds(metric.request());
      if (!native_bounds) return native_bounds;
    }
    if (header.context != nullptr) {
      const ResolutionEnvelope& resolution = header.context->resolution;
      if ((resolution.level.max_states.has_value() &&
           !native_size_bound(*resolution.level.max_states)) ||
          (resolution.level.max_row_atoms.has_value() &&
           !native_size_bound(*resolution.level.max_row_atoms))) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.resolution_native_bound_exceeded",
            "an authored finite-state or row-atom resolution grant exceeds "
            "the host-addressable exact backend range before provider "
            "execution",
            "/resolution/level", {"metric: " + header.metric_id}));
      }
      if (const auto* enumerated =
              std::get_if<EnumeratedSolver>(&header.context->solver);
          enumerated != nullptr && enumerated->max_iterations.has_value() &&
          !native_size_bound(*enumerated->max_iterations)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.max_iterations_native_bound_exceeded",
            "the authored enumerated max_iterations value exceeds the "
            "host-addressable solver range before provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
    }
    if (route == BackendRouteKindV1::conditional_row_monte_carlo) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.conditional_row_binding_unavailable",
          "C27 has no request-bound mapping from an accepted metric clause "
          "to a complete conditional kernel row; no provider was executed",
          std::nullopt, {"metric: " + header.metric_id}));
    }
    if (route == BackendRouteKindV1::conditional_reward_monte_carlo) {
      const auto* conditioned =
          std::get_if<BacklogConditionedServiceRequestV1>(
              &metric.request());
      const MetricRequirementClause* requirement =
          find_requirement_clause(accepted.requirements(),
                                  metric.contract().clause_id);
      const bool exact_point_route =
          requirement != nullptr && conditioned != nullptr &&
          std::any_of(
              requirement->route_alternatives.begin(),
              requirement->route_alternatives.end(),
              [&](const MetricRouteAlternativeV1& alternative) {
                const auto* point =
                    std::get_if<ExactPointResponseRequirementV1>(
                        &alternative.semantic.law);
                return alternative.access.backend_route ==
                           BackendRouteKindV1::
                               conditional_reward_monte_carlo &&
                       alternative.access.runtime_access ==
                           RuntimeAccessTagV1::
                               normalized_conditional_sampler &&
                       alternative.access.c24_row_or_reward_only &&
                       !alternative.access.exact_request_only &&
                       alternative.semantic.coupling ==
                           TargetCouplingV1::scalar_target &&
                       point != nullptr &&
                       point->represented_levels ==
                           conditioned->parameters().levels &&
                       point->require_positive_stationary_conditioning_mass &&
                       point->permit_declared_off_support_convention;
              });
      const bool c24_backlog_singleton =
          metrics.size() == 1U &&
          accepted.structural_manifest().clauses().size() == 1U &&
          header.kind == MetricKindV1::backlog_conditioned_service &&
          conditioned != nullptr &&
          conditioned->parameters().levels.size() == 1U &&
          header.ordered_targets.size() == 1U &&
          metric.contract().semantic ==
              SemanticTagV1::staged_opportunity_flux_law &&
          metric.contract().runtime_access ==
              RuntimeAccessTagV1::normalized_conditional_sampler &&
          metric.contract().target_coupling ==
              TargetCouplingV1::scalar_target &&
          metric.contract().ordered_targets.size() == 1U &&
          exact_point_route &&
          exact_backlog_only_sampler_shape(preview.core) &&
          activation_capabilities.has_value() &&
          activation_capabilities->supplies_single_conditioning_state &&
          activation_capabilities->supplies_conditional_reward_decoder &&
          activation_capabilities->conditional_sampler_rng_stage.has_value();
      if (!c24_backlog_singleton) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.conditional_reward_conditioning_law_unavailable",
            "C27 admits C24 conditional rewards only for one exact "
            "backlog-conditioned-service level carried by a registered "
            "staged-flux normalized sampler; no provider was executed",
            std::nullopt, {"metric: " + header.metric_id}));
      }
    }
  }

  const PayloadClassV1 cp09_observation_payload{
      PayloadClassTagV1::empirical_finite_window_response_v1, 1U};
  const bool cp09_observation_only =
      detail::is_full_orbit_cp09_provider(provider.identity()) &&
      provider.result_protocol_version() == 3U &&
      provider.manifest().value().payload_class ==
          cp09_observation_payload &&
      preview.core.provider == provider.identity() &&
      preview.core.payload_class == cp09_observation_payload;
  if (cp09_observation_only) {
    // CP09 result-v3 publishes the authenticated empirical observation, its
    // compression analysis, and a framework-owned plug-in prediction over
    // the observed response.  It still has no deployed provider surrogate.
    // Its C14 metric plans bind compatibility coordinates only and are never
    // dispatched to the C18--C24 result backends.  The common request,
    // native-bound, and conditional-premise checks above still apply;
    // executable-backend availability below does not.
    return Result<void>::success();
  }

  // C14 proves that a mathematical route is admissible, but C27 must also
  // know how to turn the exact authored request into the safe-set, entrance,
  // tag, or coupled-path input expected by that backend.  Reject known gaps
  // before provider execution; an exact request-bound direct decoder remains
  // valid because it requires no C27 reconstruction.
  for (const PlannedMetricV1& metric : metrics) {
    const MetricRequestHeader& header =
        metric_request_header(metric.request());
    const BackendRouteKindV1 route = metric.route_kind();
    if (route == BackendRouteKindV1::exact_direct) {
      if (!activation_capabilities.has_value() ||
          !activation_capabilities->supplies_direct_factor ||
          !activation_capabilities
               ->maximum_direct_factor_optimizer_calls.has_value()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.direct_causal_factor_not_registered",
            "the exact direct decoder has no code-registered causal factor "
            "and callback-free optimizer-call bound for its mandatory "
            "composite V0 seal",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      continue;
    }
    const bool stationary_selection =
        header.selection_regime ==
            MetricSelectionRegimeV1::stationary_unique ||
        header.selection_regime ==
            MetricSelectionRegimeV1::stationary_class ||
        header.selection_regime ==
            MetricSelectionRegimeV1::stationary_mixture;
    const bool transient_c22_dispatch =
        header.selection_regime == MetricSelectionRegimeV1::transient &&
        (route == BackendRouteKindV1::finite_temporal_cylinder ||
         (route == BackendRouteKindV1::residence_or_stopped_law &&
          (header.kind == MetricKindV1::first_hit ||
           header.kind == MetricKindV1::threshold_excursion ||
           header.kind == MetricKindV1::transient_backlog_law)));
    const bool constructs_stationary_law =
        route == BackendRouteKindV1::framework_scalar_identity ||
        route == BackendRouteKindV1::stationary_invariant ||
        route == BackendRouteKindV1::stationary_edge_reward ||
        route == BackendRouteKindV1::analytic_metric_family ||
        route == BackendRouteKindV1::palm_or_fifo_law ||
        ((route == BackendRouteKindV1::finite_temporal_cylinder ||
          route == BackendRouteKindV1::residence_or_stopped_law) &&
         !transient_c22_dispatch);
    if (constructs_stationary_law && !stationary_selection) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_backend_selection_required",
          "the accepted route is dispatched through a C18, C19, C20/C21, "
          "stationary C22, or C23 stationary-law constructor, which requires "
          "stationary_unique, stationary_class, or stationary_mixture; a "
          "transient or fixed-point selection cannot be reinterpreted",
          std::nullopt, {"metric: " + header.metric_id}));
    }
    if (constructs_stationary_law && header.context != nullptr) {
      if (const auto* mixture =
              std::get_if<StationaryMixtureSelection>(
                  &header.context->selection)) {
        ExactRational total = ExactRational::zero();
        for (std::size_t component_index = 0U;
             component_index < mixture->components.size();
             ++component_index) {
          const StationaryMixtureComponent& component =
              mixture->components[component_index];
          for (std::size_t earlier = 0U; earlier < component_index;
               ++earlier) {
            if (mixture->components[earlier].class_id ==
                component.class_id) {
              return Result<void>::failure(plan_error(
                  DiagnosticCategory::input_validation,
                  "c27.stationary_mixture_duplicate_class",
                  "a stationary mixture may name each invariant class at "
                  "most once before provider execution",
                  std::nullopt, {"metric: " + header.metric_id}));
            }
          }
          total = total + component.probability.exact_value();
        }
        bool finite_positive_images = total.is_positive();
        if (finite_positive_images) {
          for (const StationaryMixtureComponent& component :
               mixture->components) {
            const ExactRational& exact =
                component.probability.exact_value();
            if (!exact.is_positive()) continue;
            auto normalized = checked_divide(exact, total);
            if (!normalized) {
              finite_positive_images = false;
              break;
            }
            const long double image = normalized.value().to_long_double();
            if (!std::isfinite(image) || image <= 0.0L) {
              finite_positive_images = false;
              break;
            }
          }
        }
        if (!finite_positive_images) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::input_validation,
              "c27.stationary_mixture_numerical_image_invalid",
              "every positive exact stationary-mixture component must have "
              "a finite positive normalized long-double image for the "
              "selected matrix backend before provider execution",
              std::nullopt, {"metric: " + header.metric_id}));
        }
      }
    }
    const bool stationary_temporal_execution_route =
        stationary_selection &&
        ((route == BackendRouteKindV1::analytic_metric_family &&
          (header.kind == MetricKindV1::mean_event_gap ||
           header.kind == MetricKindV1::mean_binary_run ||
           header.kind == MetricKindV1::service_window_count)) ||
         ((route == BackendRouteKindV1::stationary_invariant ||
           route == BackendRouteKindV1::stationary_edge_reward) &&
          preview.core.runtime_access ==
              RuntimeAccessTagV1::procedural_residence_generator) ||
         route == BackendRouteKindV1::finite_temporal_cylinder ||
         route == BackendRouteKindV1::residence_or_stopped_law ||
         route == BackendRouteKindV1::palm_or_fifo_law);
    if (stationary_temporal_execution_route &&
        header.solver_regime != MetricSolverRegimeV1::enumerated) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_temporal_enumerated_solver_required",
          "the installed C20/C21 stationary event-law adapter requires the "
          "authored enumerated linear-solver policy; C27 will not derive one "
          "from an analytic or Monte Carlo solver request",
          std::nullopt, {"metric: " + header.metric_id}));
    }
    if (!built_in_c19_scalar && stationary_temporal_execution_route) {
      if (const auto* pgf =
              std::get_if<StationaryBacklogPgfRequestV1>(
                  &metric.request())) {
        for (const ExactRational& point : pgf->parameters().points) {
          if (!std::isfinite(point.to_long_double())) {
            return Result<void>::failure(plan_error(
                DiagnosticCategory::unavailable,
                "c27.stationary_temporal_pgf_point_not_representable",
                "the generic C21 stationary PGF adapter requires every "
                "authored exact point to have a finite long-double image "
                "before provider execution",
                std::nullopt, {"metric: " + header.metric_id}));
          }
        }
      }
      const BigNat* c21_moment_order = nullptr;
      if (const auto* moment =
              std::get_if<StationaryBacklogMomentRequestV1>(
                  &metric.request())) {
        c21_moment_order = &moment->parameters().order;
      } else if (const auto* edge =
                     std::get_if<StationaryEdgeRewardRequestV1>(
                         &metric.request())) {
        c21_moment_order = &edge->parameters().moment_order;
      }
      if (c21_moment_order != nullptr &&
          (c21_moment_order->bit_length() > 20U ||
           *c21_moment_order > BigNat{1000000U})) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_temporal_moment_order_exceeded",
            "the generic C21 stationary state/edge moment adapter supports "
            "authored orders through 1000000 before provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      if (preview.core.semantic !=
              SemanticTagV1::romr_residence_word_law ||
          preview.core.phase.arrival_composition !=
              ConfiguredArrivalCompositionV1::
                  finite_enumerated_predictive_phase ||
          !preview.core.phase.retains_configured_predictive_phase) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.stationary_temporal_quotient_descriptor_required",
            "the installed generic C20/C21 stationary event-law backend "
            "requires an exact ROMR residence-word descriptor that explicitly "
            "retains the configured finite enumerated predictive phase; no "
            "provider was executed",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      const auto* enumerated =
          header.context == nullptr
              ? nullptr
              : std::get_if<EnumeratedSolver>(&header.context->solver);
      if (enumerated == nullptr ||
          enumerated->linear_method != LinearMethod::dense_pivoted) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.stationary_temporal_dense_solver_required",
            "the installed stationary C20/C21 backend implements only the "
            "authored dense_pivoted enumerated method; sparse_iterative "
            "cannot be deferred until provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      const auto& tolerance =
          header.context->resolution.tolerance.linear_residual_abs;
      if (!tolerance.has_value() ||
          !finite_nonnegative_image(*tolerance)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::input_validation,
            "c27.stationary_temporal_linear_residual_invalid",
            "the installed C20/C21/C22/C23 matrix route requires an "
            "authored finite nonnegative linear_residual_abs image before "
            "provider execution",
            "/resolution/tolerance/linear_residual_abs",
            {"metric: " + header.metric_id}));
      }
      const LevelResolution& level = header.context->resolution.level;
      if (!level.max_states.has_value() ||
          !level.max_row_atoms.has_value()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_temporal_resolution_bounds_required",
            "a stationary C20/C21/C22/C23 route requires authored "
            "max_states and max_row_atoms grants before provider execution",
            "/resolution/level", {"metric: " + header.metric_id}));
      }
      // C17's finite event-clock quotient requires a positive finite
      // residence support even when its exact row access is finite or sparse;
      // this is not limited to a procedural residence carrier.
      constexpr bool needs_residence_bound = true;
      const bool registered_bounds_available =
          activation_capabilities.has_value() &&
          activation_capabilities->maximum_finite_event_states.has_value() &&
          activation_capabilities->maximum_row_atoms.has_value() &&
          (!needs_residence_bound ||
           activation_capabilities->maximum_residence_slots.has_value());
      if (!registered_bounds_available) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.stationary_temporal_registered_bounds_missing",
            "the selected stationary temporal route lacks callback-free "
            "event-state, row-atom, or residence-slot bounds; no provider "
            "was executed",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      if (*activation_capabilities->maximum_finite_event_states >
              *level.max_states ||
          *activation_capabilities->maximum_row_atoms >
              *level.max_row_atoms ||
          !native_size_bound(
              *activation_capabilities->maximum_finite_event_states) ||
          !native_size_bound(*activation_capabilities->maximum_row_atoms) ||
          (needs_residence_bound &&
           !native_size_bound(
               *activation_capabilities->maximum_residence_slots))) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_temporal_registered_bounds_exceed_grant",
            "the callback-free stationary temporal representation bound "
            "exceeds the authored finite-state or row-atom grant or the "
            "host-addressable residence range",
            "/resolution/level", {"metric: " + header.metric_id}));
      }
      if (!native_dense_square_bound(
              *activation_capabilities->maximum_finite_event_states)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_temporal_dense_dimension_exceeded",
            "the callback-free finite event-state bound cannot index and "
            "flatten the dense C20/C21 invariant system before provider "
            "execution",
            "/resolution/level/max_states",
            {"metric: " + header.metric_id}));
      }
    }

    // The current C18 dispatcher publishes only its closed scalar reward
    // projections.  C14 acceptance of a finite invariant/edge law does not by
    // itself provide the missing request-to-result adapter.  A procedural
    // residence route and a metric-specific analytic/direct route are distinct
    // backends and remain eligible.
    const bool c18_stationary_route =
        !built_in_c19_scalar &&
        preview.core.runtime_access !=
            RuntimeAccessTagV1::procedural_residence_generator &&
        (route == BackendRouteKindV1::stationary_invariant ||
         route == BackendRouteKindV1::stationary_edge_reward);
    const auto* framework_scalar =
        std::get_if<FrameworkScalarIdentityBackendPlanV1>(&metric.backend());
    const bool c18_framework_scalar_route =
        !built_in_c19_scalar &&
        route == BackendRouteKindV1::framework_scalar_identity &&
        framework_scalar != nullptr &&
        framework_scalar->stationary_proof.backend ==
            StationaryProofBackendV1::c18_selected_finite_invariant;
    const bool c18_execution_route =
        c18_stationary_route || c18_framework_scalar_route;
    if (c18_stationary_route) {
      if (const auto* edge =
              std::get_if<StationaryEdgeRewardRequestV1>(&metric.request());
          edge != nullptr &&
          edge->parameters().moment_order.bit_length() > 63U) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.edge_reward_power_not_representable",
            "the selected finite C18 numerical adapter requires the authored "
            "edge-reward moment order to fit its 63-bit exponent before "
            "provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      switch (header.kind) {
        case MetricKindV1::stationary_backlog_pmf:
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.c18_stationary_backlog_pmf_adapter_unavailable",
              "the accepted C18 stationary route has no public exact "
              "stationary-backlog PMF projection adapter; no provider was "
              "executed and no alternate route was selected",
              std::nullopt, {"metric: " + header.metric_id}));
        case MetricKindV1::stationary_backlog_pgf:
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.c18_stationary_backlog_pgf_adapter_unavailable",
              "the accepted C18 stationary route has no public exact "
              "stationary-backlog PGF projection adapter; no provider was "
              "executed and no alternate route was selected",
              std::nullopt, {"metric: " + header.metric_id}));
        case MetricKindV1::stationary_backlog_quantile:
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.c18_stationary_backlog_quantile_adapter_unavailable",
              "the accepted C18 stationary route has no public exact "
              "stationary-backlog quantile projection adapter; no provider "
              "was executed and no alternate route was selected",
              std::nullopt, {"metric: " + header.metric_id}));
        case MetricKindV1::joint_backlog_covariance:
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.c18_joint_backlog_covariance_adapter_unavailable",
              "the accepted C18 stationary route has no public exact joint-"
              "backlog covariance projection adapter; no provider was "
              "executed and no alternate route was selected",
              std::nullopt, {"metric: " + header.metric_id}));
        case MetricKindV1::backlog_conditioned_service:
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.c18_backlog_conditioned_service_adapter_unavailable",
              "the accepted C18 stationary edge route has no public exact "
              "backlog-conditioned service projection adapter; no provider "
              "was executed and no alternate route was selected",
              std::nullopt, {"metric: " + header.metric_id}));
        default:
          break;
      }
      if (!c18_scalar_adapter_is_implemented(header.kind)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.c18_metric_adapter_unavailable",
            "the accepted C18 finite invariant/edge route has no exact "
            "request-to-scalar adapter for this metric; no provider was "
            "executed and no alternate route was selected",
            std::nullopt, {"metric: " + header.metric_id}));
      }
    }
    if (c18_execution_route &&
        header.solver_regime != MetricSolverRegimeV1::enumerated) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_finite_enumerated_solver_required",
          "the installed C18 finite-stationary adapter requires the "
          "authored enumerated linear-solver policy; C27 will not reinterpret "
          "an analytic or Monte Carlo request as an enumerated solve",
          std::nullopt, {"metric: " + header.metric_id}));
    }
    if (c18_execution_route) {
      const auto* enumerated =
          header.context == nullptr
              ? nullptr
              : std::get_if<EnumeratedSolver>(&header.context->solver);
      if (enumerated == nullptr ||
          enumerated->linear_method != LinearMethod::dense_pivoted) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.stationary_finite_dense_solver_required",
            "the installed C18 finite-stationary backend implements only "
            "the authored dense_pivoted enumerated method; sparse_iterative "
            "cannot be deferred until provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      if (header.context == nullptr ||
          !header.context->resolution.tolerance.linear_residual_abs
               .has_value()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::input_validation,
            "c27.stationary_finite_linear_residual_required",
            "the installed C18 finite-stationary backend requires an "
            "authored resolution.tolerance.linear_residual_abs before "
            "provider execution",
            "/resolution/tolerance/linear_residual_abs",
            {"metric: " + header.metric_id}));
      }
      if (!finite_nonnegative_image(
              *header.context->resolution.tolerance.linear_residual_abs)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::input_validation,
            "c27.stationary_finite_linear_residual_invalid",
            "the installed C18 finite-stationary backend requires a finite "
            "nonnegative long-double image of the authored linear residual "
            "tolerance before provider execution",
            "/resolution/tolerance/linear_residual_abs",
            {"metric: " + header.metric_id}));
      }
      const LevelResolution& level = header.context->resolution.level;
      if (!level.max_states.has_value() ||
          !level.max_row_atoms.has_value()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_finite_resolution_bounds_required",
            "a C18 finite-stationary route requires authored max_states and "
            "max_row_atoms grants before provider execution",
            "/resolution/level", {"metric: " + header.metric_id}));
      }
      if (!activation_capabilities.has_value() ||
          !activation_capabilities->maximum_finite_backend_states
               .has_value() ||
          !activation_capabilities->maximum_row_atoms.has_value()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.stationary_finite_registered_bounds_missing",
            "the selected C18 route lacks callback-free backend-state or "
            "row-atom bounds; no provider was executed",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      if (*activation_capabilities->maximum_finite_backend_states >
              *level.max_states ||
          *activation_capabilities->maximum_row_atoms >
              *level.max_row_atoms ||
          !native_size_bound(
              *activation_capabilities->maximum_finite_backend_states) ||
          !native_size_bound(*activation_capabilities->maximum_row_atoms)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_finite_registered_bounds_exceed_grant",
            "the callback-free C18 backend-state or row-atom bound exceeds "
            "the authored finite representation grant",
            "/resolution/level", {"metric: " + header.metric_id}));
      }
      if (!native_dense_square_bound(
              *activation_capabilities->maximum_finite_backend_states)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.stationary_finite_dense_dimension_exceeded",
            "the callback-free C18 backend-state bound cannot index and "
            "flatten the selected dense invariant system before provider "
            "execution",
            "/resolution/level/max_states",
            {"metric: " + header.metric_id}));
      }
    }

    if ((route == BackendRouteKindV1::stationary_invariant ||
         route == BackendRouteKindV1::stationary_edge_reward) &&
        preview.core.runtime_access ==
            RuntimeAccessTagV1::procedural_residence_generator &&
        !stationary_suspension_adapter_is_implemented(header.kind)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_suspension_metric_adapter_unavailable",
          "the accepted procedural residence route has no exact C21 "
          "stationary-suspension adapter for this metric; no provider was "
          "executed and no alternate route was selected",
          std::nullopt, {"metric: " + header.metric_id}));
    }

    if (route == BackendRouteKindV1::finite_temporal_cylinder &&
        header.selection_regime != MetricSelectionRegimeV1::transient &&
        !stationary_temporal_statistic_adapter_is_implemented(header.kind)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_temporal_metric_adapter_unavailable",
          "the accepted finite-cylinder route has no exact C22 stationary "
          "statistic adapter for this request; no provider was executed and "
          "no alternate route was selected",
          std::nullopt, {"metric: " + header.metric_id}));
    }

    if ((route == BackendRouteKindV1::finite_temporal_cylinder ||
         route == BackendRouteKindV1::residence_or_stopped_law) &&
        header.selection_regime == MetricSelectionRegimeV1::transient &&
        header.solver_regime != MetricSolverRegimeV1::enumerated) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.transient_temporal_enumerated_solver_required",
          "the installed transient finite-cylinder/stopped-law adapter "
          "requires the authored enumerated linear-solver policy; C27 will "
          "not reinterpret an analytic or Monte Carlo request as an "
          "enumerated solve",
          std::nullopt, {"metric: " + header.metric_id}));
    }

    const bool transient_temporal_route =
        (route == BackendRouteKindV1::finite_temporal_cylinder ||
         route == BackendRouteKindV1::residence_or_stopped_law) &&
        header.selection_regime == MetricSelectionRegimeV1::transient;
    if (transient_temporal_route) {
      if (route == BackendRouteKindV1::residence_or_stopped_law &&
          (header.kind == MetricKindV1::first_hit ||
           header.kind == MetricKindV1::threshold_excursion) &&
          (header.context == nullptr ||
           !header.context->resolution.level.max_states.has_value())) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.transient_stopped_state_budget_required",
            "an exact transient first-hit or threshold-excursion route "
            "requires an authored resolution.level.max_states cap to "
            "certify reachable finite closure before provider execution",
            "/resolution/level/max_states",
            {"metric: " + header.metric_id}));
      }
      if (header.context == nullptr ||
          !header.context->resolution.level.max_states.has_value() ||
          !header.context->resolution.level.max_row_atoms.has_value()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.transient_temporal_resolution_bounds_required",
            "an exact transient finite-cylinder or stopped-law route "
            "requires authored max_states and max_row_atoms grants before "
            "provider execution",
            "/resolution/level", {"metric: " + header.metric_id}));
      }
      const bool transient_stopped_dense_route =
          route == BackendRouteKindV1::residence_or_stopped_law &&
          (header.kind == MetricKindV1::first_hit ||
           header.kind == MetricKindV1::threshold_excursion);
      if (transient_stopped_dense_route &&
          !native_dense_square_bound(
              *header.context->resolution.level.max_states)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.transient_stopped_dense_dimension_exceeded",
            "the authored transient stopped-state cap cannot index and "
            "flatten the exact C22 killed system before provider execution",
            "/resolution/level/max_states",
            {"metric: " + header.metric_id}));
      }
      const bool needs_residence_bound =
          route == BackendRouteKindV1::residence_or_stopped_law;
      if (!activation_capabilities.has_value() ||
          !activation_capabilities->maximum_row_atoms.has_value() ||
          (needs_residence_bound &&
           !activation_capabilities->maximum_residence_slots.has_value())) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.transient_temporal_registered_bounds_missing",
            "the selected transient route lacks callback-free row-atom or "
            "residence-slot bounds; no provider was executed",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      if (*activation_capabilities->maximum_row_atoms >
              *header.context->resolution.level.max_row_atoms ||
          !native_size_bound(*activation_capabilities->maximum_row_atoms) ||
          (needs_residence_bound &&
           !native_size_bound(
               *activation_capabilities->maximum_residence_slots))) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.transient_temporal_registered_bounds_exceed_grant",
            "the callback-free transient row-atom bound exceeds the "
            "authored grant or its residence-slot bound exceeds the host "
            "range",
            "/resolution/level/max_row_atoms",
            {"metric: " + header.metric_id}));
      }

      bool include_mean = false;
      if (const auto* first =
              std::get_if<FirstHitRequestV1>(&metric.request())) {
        include_mean = first->parameters().include_mean;
      } else if (const auto* excursion =
                     std::get_if<ThresholdExcursionRequestV1>(
                         &metric.request())) {
        include_mean = excursion->parameters().include_mean;
      }
      if (include_mean) {
        const auto* enumerated =
            std::get_if<EnumeratedSolver>(&header.context->solver);
        const auto& tolerance =
            header.context->resolution.tolerance.linear_residual_abs;
        if (enumerated == nullptr ||
            enumerated->linear_method != LinearMethod::dense_pivoted ||
            !tolerance.has_value() ||
            !finite_nonnegative_image(*tolerance)) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.transient_mean_dense_policy_required",
              "a transient first-hit or threshold-excursion mean requires "
              "the authored dense_pivoted method and a finite nonnegative "
              "linear_residual_abs image before provider execution",
              "/resolution/tolerance/linear_residual_abs",
              {"metric: " + header.metric_id}));
        }
      }
      auto entrance = validate_transient_entrance_predicate(
          initial_law, metric.request());
      if (!entrance) return entrance;
    }

    if ((route == BackendRouteKindV1::finite_temporal_cylinder ||
         route == BackendRouteKindV1::residence_or_stopped_law) &&
        header.selection_regime == MetricSelectionRegimeV1::transient &&
        !transient_temporal_adapter_is_implemented(header.kind)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.transient_temporal_metric_adapter_unavailable",
          "the accepted transient temporal route has no exact C22 request "
          "adapter for this metric; no provider was executed and no alternate "
          "route was selected",
          std::nullopt, {"metric: " + header.metric_id}));
    }

    if (route == BackendRouteKindV1::residence_or_stopped_law &&
        header.selection_regime != MetricSelectionRegimeV1::transient &&
        header.kind != MetricKindV1::event_gap_distribution &&
        header.kind != MetricKindV1::first_hit) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_stopped_metric_adapter_unavailable",
          "the accepted stopped-law route has no request-bound stationary "
          "entrance adapter for this metric; no provider was executed and no "
          "alternate route was selected",
          std::nullopt, {"metric: " + header.metric_id}));
    }

    if (route == BackendRouteKindV1::palm_or_fifo_law &&
        header.kind != MetricKindV1::fifo_delay &&
        header.kind != MetricKindV1::fifo_delay_conditioned) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.palm_fifo_metric_adapter_unavailable",
          "the accepted Palm route has no exact scalar FIFO adapter for this "
          "request; no provider was executed and no alternate route was "
          "selected",
          std::nullopt, {"metric: " + header.metric_id}));
    }
    if (route == BackendRouteKindV1::palm_or_fifo_law) {
      const FifoDelayOutputV1* output = fifo_output(metric.request());
      if (output == nullptr || header.ordered_targets.size() != 1U) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.fifo_scalar_request_required",
            "the C23 FIFO adapter requires one scalar typed FIFO output "
            "before provider execution",
            std::nullopt, {"metric: " + header.metric_id}));
      }
      if (std::holds_alternative<FifoDelayQuantileOutputV1>(*output)) {
        const bool has_finite_distribution_horizon = std::any_of(
            metrics.begin(), metrics.end(),
            [&](const PlannedMetricV1& candidate) {
              if (candidate.route_kind() !=
                      BackendRouteKindV1::palm_or_fifo_law ||
                  !same_fifo_group(metric.request(), candidate.request())) {
                return false;
              }
              const FifoDelayOutputV1* candidate_output =
                  fifo_output(candidate.request());
              return candidate_output != nullptr &&
                     (std::holds_alternative<FifoDelayPmfOutputV1>(
                          *candidate_output) ||
                      std::holds_alternative<FifoDelayTailOutputV1>(
                          *candidate_output));
            });
        if (!has_finite_distribution_horizon) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::resource_limit,
              "c27.fifo_quantile_horizon_required",
              "a C23 FIFO quantile requires a PMF or tail request in the "
              "same target-and-condition group to author its finite "
              "distribution horizon before provider execution",
              std::nullopt, {"metric: " + header.metric_id}));
        }
      }

      const FifoConditionV1* condition = fifo_condition(metric.request());
      std::optional<MetricMarkKindV1> required_label;
      if (condition != nullptr &&
          std::holds_alternative<FifoClassConditionV1>(*condition)) {
        required_label = MetricMarkKindV1::class_label;
      } else if (condition != nullptr &&
                 std::holds_alternative<FifoPhaseConditionV1>(*condition)) {
        required_label = MetricMarkKindV1::phase_label;
      }
      if (required_label.has_value()) {
        std::size_t label_mark_count = 0U;
        bool exact_label_mark = false;
        for (const MarkDescriptorV1& mark : preview.core.marks) {
          if (mark.kind != *required_label) continue;
          ++label_mark_count;
          exact_label_mark =
              exact_label_mark ||
              (mark.reveal_stage == MetricRevealStageV1::entrance_label &&
               mark.codec.id == "mwperf.c23.typed_label" &&
               mark.codec.version == 1U);
        }
        if (label_mark_count != 1U || !exact_label_mark) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.fifo_entrance_label_mark_required",
              "a class- or phase-conditioned C23 FIFO route requires "
              "exactly one matching entrance-label mark with the "
              "mwperf.c23.typed_label v1 codec before provider execution",
              std::nullopt, {"metric: " + header.metric_id}));
        }
      }
    }

    switch (header.kind) {
      case MetricKindV1::joint_delay:
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.joint_delay_adapter_unavailable",
            "the accepted joint-delay route has no public request-bound "
            "coupled Palm/FIFO tag adapter; no provider was executed and no "
            "alternate route was selected",
            std::nullopt, {"metric: " + header.metric_id}));
      case MetricKindV1::binary_run_distribution:
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.stationary_binary_run_adapter_unavailable",
            "the accepted stationary binary-run distribution route has no "
            "public run-start entrance and residence-word adapter; no "
            "provider was executed and no alternate route was selected",
            std::nullopt, {"metric: " + header.metric_id}));
      case MetricKindV1::threshold_excursion:
        if (header.selection_regime != MetricSelectionRegimeV1::transient) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::unavailable,
              "c27.stationary_threshold_excursion_adapter_unavailable",
              "the accepted stationary threshold-excursion route has no "
              "public threshold-crossing Palm entrance adapter; no provider "
              "was executed and no alternate route was selected",
              std::nullopt, {"metric: " + header.metric_id}));
        }
        break;
      case MetricKindV1::counterfactual_opportunity_gap:
        return Result<void>::failure(plan_error(
            DiagnosticCategory::unavailable,
            "c27.counterfactual_gap_adapter_unavailable",
            "the accepted counterfactual opportunity-gap route has no public "
            "request-bound counterfactual event-law adapter; no provider was "
            "executed and no alternate route was selected",
            std::nullopt, {"metric: " + header.metric_id}));
      default:
        break;
    }
  }

  for (const PlannedMetricV1& metric : metrics) {
    if (metric.route_kind() != BackendRouteKindV1::analytic_metric_family ||
        built_in_c19_scalar) {
      continue;
    }
    const MetricKindV1 kind = metric_request_kind(metric.request());
    const bool procedural_temporal =
        preview.core.runtime_access ==
            RuntimeAccessTagV1::procedural_residence_generator &&
        (kind == MetricKindV1::mean_event_gap ||
         kind == MetricKindV1::mean_binary_run ||
         kind == MetricKindV1::service_window_count);
    if (!procedural_temporal) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.analytic_family_metric_adapter_unavailable",
          "the accepted non-ThreeBin analytic-family route has no installed "
          "request-to-C19 adapter; no provider was executed and no alternate "
          "route was selected",
          std::nullopt,
          {"metric: " +
           metric_request_header(metric.request()).metric_id}));
    }
  }
  if (!built_in_c19_scalar &&
      !provider.has_framework_activation_factory()) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::unavailable,
        "c27.framework_activation_factory_missing",
        "the frozen non-ThreeBin provider route has no code-registered C27 "
        "framework activation factory; no provider was executed and no "
        "alternate route was selected"));
  }
  for (const PlannedMetricV1& metric : metrics) {
    const BackendRouteKindV1 route = metric.route_kind();
    const bool c18_framework_proof = [&]() {
      if (route != BackendRouteKindV1::framework_scalar_identity) {
        return false;
      }
      const auto* scalar =
          std::get_if<FrameworkScalarIdentityBackendPlanV1>(
              &metric.backend());
      return scalar != nullptr &&
             scalar->stationary_proof.backend ==
                 StationaryProofBackendV1::c18_selected_finite_invariant;
    }();
    const MetricSelectionRegimeV1 selected_regime =
        metric_request_header(metric.request()).selection_regime;
    const bool stationary_selection =
        selected_regime == MetricSelectionRegimeV1::stationary_unique ||
        selected_regime == MetricSelectionRegimeV1::stationary_class ||
        selected_regime == MetricSelectionRegimeV1::stationary_mixture;
    const bool stationary_finite_route =
        c18_framework_proof ||
        ((route == BackendRouteKindV1::stationary_invariant ||
          route == BackendRouteKindV1::stationary_edge_reward) &&
         preview.core.runtime_access !=
             RuntimeAccessTagV1::procedural_residence_generator);
    if (!built_in_c19_scalar && stationary_finite_route &&
        (!activation_capabilities.has_value() ||
         !activation_capabilities->supplies_finite_backend_domain ||
         !activation_capabilities->proves_exact_closed_boundary)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_activation_domain_missing",
          "the accepted stationary route has no code-registered finite "
          "backend domain with a registered raw exact-closure or audited "
          "stationary clock-quotient declaration; C27 will not invent a "
          "cutoff or treat sampled rows as closed",
          std::nullopt,
          {"metric: " + metric_request_header(metric.request()).metric_id}));
    }

    const MetricKindV1 metric_kind = metric_request_kind(metric.request());
    const bool stationary_temporal_route =
        stationary_selection &&
        ((route == BackendRouteKindV1::analytic_metric_family &&
          (metric_kind == MetricKindV1::mean_event_gap ||
           metric_kind == MetricKindV1::mean_binary_run ||
           metric_kind == MetricKindV1::service_window_count)) ||
         ((route == BackendRouteKindV1::stationary_invariant ||
           route == BackendRouteKindV1::stationary_edge_reward) &&
          preview.core.runtime_access ==
              RuntimeAccessTagV1::procedural_residence_generator) ||
         route == BackendRouteKindV1::finite_temporal_cylinder ||
         route == BackendRouteKindV1::residence_or_stopped_law ||
         route == BackendRouteKindV1::palm_or_fifo_law);
    if (!built_in_c19_scalar && stationary_temporal_route &&
        (!activation_capabilities.has_value() ||
         !activation_capabilities->supplies_finite_event_domain)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.stationary_finite_event_domain_missing",
          "the accepted stationary temporal, stopped, or Palm route has no "
          "code-registered finite event-entry domain; C27 will not reinterpret "
          "an exact countable event predicate or a C18 invariant domain as a "
          "finite C20 event quotient",
          std::nullopt,
          {"metric: " + metric_request_header(metric.request()).metric_id}));
    }
    if (built_in_c19_scalar &&
        ((metric.route_kind() !=
              BackendRouteKindV1::analytic_metric_family &&
          metric.route_kind() !=
              BackendRouteKindV1::framework_scalar_identity &&
          metric.route_kind() !=
              BackendRouteKindV1::stationary_invariant &&
          metric.route_kind() !=
              BackendRouteKindV1::stationary_edge_reward) ||
         !c19_metric_adapter_is_implemented(metric.request()))) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::unavailable,
          "c27.three_bin_metric_adapter_unavailable",
          "the built-in ThreeBin adapter has no C19 result mapping for the "
          "exact requested metric and parameters; no provider was executed",
          std::nullopt,
          {"metric: " + metric_request_header(metric.request()).metric_id}));
    }
  }
  return Result<void>::success();
}

}  // namespace

BackendRouteKindV1 backend_route_kind(
    const MetricBackendPlanV1& backend) noexcept {
  return std::visit(
      []<typename Backend>(const Backend&) noexcept {
        using T = std::remove_cvref_t<Backend>;
        if constexpr (std::is_same_v<
                          T, FrameworkScalarIdentityBackendPlanV1>) {
          return BackendRouteKindV1::framework_scalar_identity;
        } else if constexpr (std::is_same_v<
                                 T, StationaryInvariantBackendPlanV1>) {
          return BackendRouteKindV1::stationary_invariant;
        } else if constexpr (std::is_same_v<
                                 T, StationaryEdgeRewardBackendPlanV1>) {
          return BackendRouteKindV1::stationary_edge_reward;
        } else if constexpr (std::is_same_v<
                                 T, FiniteTemporalCylinderBackendPlanV1>) {
          return BackendRouteKindV1::finite_temporal_cylinder;
        } else if constexpr (std::is_same_v<
                                 T, AnalyticMetricFamilyBackendPlanV1>) {
          return BackendRouteKindV1::analytic_metric_family;
        } else if constexpr (std::is_same_v<
                                 T, ResidenceOrStoppedLawBackendPlanV1>) {
          return BackendRouteKindV1::residence_or_stopped_law;
        } else if constexpr (std::is_same_v<T,
                                            PalmOrFifoLawBackendPlanV1>) {
          return BackendRouteKindV1::palm_or_fifo_law;
        } else if constexpr (std::is_same_v<
                                 T,
                                 ConditionalRowMonteCarloBackendPlanV1>) {
          return BackendRouteKindV1::conditional_row_monte_carlo;
        } else if constexpr (std::is_same_v<
                                 T,
                                 ConditionalRewardMonteCarloBackendPlanV1>) {
          return BackendRouteKindV1::conditional_reward_monte_carlo;
        } else {
          static_assert(std::is_same_v<T, ExactDirectBackendPlanV1>);
          return BackendRouteKindV1::exact_direct;
        }
      },
      backend);
}

Result<ExecutionPlan> build_execution_plan(const ResolvedRequest& request) {
  try {
    const ResolvedInstance& instance = request.instance();
    const AnalysisSpec& analysis = instance.analysis_spec();
    if (!analysis.context || analysis.metrics.empty()) {
      return fail<ExecutionPlan>(plan_error(
          DiagnosticCategory::internal, "c27.analysis_context_missing",
          "planning requires a nonempty resolved analysis context"));
    }

    std::vector<MetricRequest> metric_requests;
    metric_requests.reserve(analysis.metrics.size());
    for (const MetricNode& metric : analysis.metrics) {
      auto parsed = parse_metric_request(metric, instance.queues());
      if (!parsed) {
        return fail<ExecutionPlan>(parsed.error());
      }
      metric_requests.push_back(std::move(parsed).value());
    }
    MetricRequirements requirements =
        aggregate_metric_requirements(metric_requests);
    const RegimeCompatibilityV1& regime =
        requirements.regime_compatibility();
    if (regime.kind != RegimeCompatibilityKindV1::compatible ||
        !regime.common_selection.has_value() ||
        !regime.common_solver.has_value()) {
      return fail<ExecutionPlan>(plan_error(
          DiagnosticCategory::input_validation,
          "c27.incompatible_metric_regime",
          "analysis-v1 requires one homogeneous selection and solver regime "
          "for every requested metric",
          "/metrics"));
    }

    auto surrogate_id = SurrogateId::parse(analysis.surrogate.id);
    if (!surrogate_id) {
      return fail<ExecutionPlan>(surrogate_id.error());
    }
    std::optional<SurrogateVersion> surrogate_version;
    if (analysis.surrogate.version.has_value()) {
      auto parsed_version =
          SurrogateVersion::parse(*analysis.surrogate.version);
      if (!parsed_version) {
        return fail<ExecutionPlan>(parsed_version.error());
      }
      surrogate_version.emplace(std::move(parsed_version).value());
    } else if (analysis.surrogate.id ==
                   "full_orbit_framework_sampler" &&
               instance.authored_model().schema_version.value ==
                   kPhysicalSchemaVersionV4) {
      // Schema 4's native IID families and observation-only success belong to
      // CP09.  Preserve the released registry default for schema 3, while an
      // omitted version in a schema-4 analysis resolves deterministically to
      // the additive 1.4 route.
      auto cp09_version = SurrogateVersion::parse("1.4.0");
      if (!cp09_version) {
        return fail<ExecutionPlan>(cp09_version.error());
      }
      surrogate_version.emplace(std::move(cp09_version).value());
    }
    auto selected_provider = lookup_surrogate_provider(
        surrogate_id.value(), surrogate_version);
    if (!selected_provider) {
      return fail<ExecutionPlan>(selected_provider.error());
    }
    SurrogateProvider provider = std::move(selected_provider).value();
    const SurrogateProviderManifestV1& manifest = provider.manifest().value();
    if (*regime.common_solver == MetricSolverRegimeV1::direct &&
        metric_requests.size() != 1U) {
      return fail<ExecutionPlan>(plan_error(
          DiagnosticCategory::input_validation,
          "c27.direct_decoder_single_metric_required",
          "C16's raw direct-decoder seam exposes exactly one accepted metric "
          "value and structural clause; submit each direct metric in a "
          "separate analysis document so no provider is executed",
          "/metrics"));
    }
    const bool three_bin = is_three_bin_payload(manifest.payload_class);
    if (manifest.payload_class.tag ==
            PayloadClassTagV1::three_bin_scalar_response_v1 &&
        !three_bin) {
      return fail<ExecutionPlan>(plan_error(
          DiagnosticCategory::input_validation,
          "c27.unsupported_three_bin_payload_version",
          "C27 supports only version 1 of three_bin_scalar_response_v1"));
    }
    if (three_bin && instance.targets().size() != 1U) {
      return fail<ExecutionPlan>(plan_error(
          DiagnosticCategory::input_validation,
          "c27.three_bin_singleton_target_required",
          "three_bin_scalar_response_v1 requires one runtime target; submit "
          "one analysis document per scalar target",
          "/targets"));
    }

    auto parameters =
        validate_surrogate_parameters(provider, analysis.surrogate.parameters);
    if (!parameters) {
      return fail<ExecutionPlan>(parameters.error());
    }
    auto k_wide_resolution_binding =
        detail::validate_full_orbit_k_wide_resolution_binding(
            manifest.provider, parameters.value(),
            analysis.context->resolution.tail);
    if (!k_wide_resolution_binding) {
      return fail<ExecutionPlan>(k_wide_resolution_binding.error());
    }
    auto observation_resolution_binding =
        detail::validate_full_orbit_observation_resolution_binding(
            manifest.provider, parameters.value(),
            analysis.context->resolution.tail);
    if (!observation_resolution_binding) {
      return fail<ExecutionPlan>(observation_resolution_binding.error());
    }
    const bool full_orbit_addressed_work =
        detail::is_full_orbit_k_wide_provider(manifest.provider) ||
        detail::is_full_orbit_observation_provider(manifest.provider) ||
        detail::is_full_orbit_cp09_provider(manifest.provider);

    auto metric_draws = authored_metric_draw_bound(
        metric_requests, *regime.common_solver);
    if (!metric_draws) {
      return fail<ExecutionPlan>(metric_draws.error());
    }
    const std::optional<FrameworkActivationCapabilitiesV1>
        activation_capabilities =
            provider.framework_activation_capabilities();
    const bool exact_direct =
        *regime.common_solver == MetricSolverRegimeV1::direct &&
        manifest.payload_class.tag ==
            PayloadClassTagV1::direct_metric_payload_v1 &&
        manifest.payload_class.version == 1U &&
        manifest.deployed_semantic_tag ==
            SemanticTagV1::direct_metric_decoder &&
        manifest.runtime_access_tag ==
            RuntimeAccessTagV1::direct_metric_decoder &&
        activation_capabilities.has_value() &&
        activation_capabilities->supplies_direct_factor;
    std::optional<BigNat> maximum_downstream_optimizer_calls{BigNat{0U}};
    if (exact_direct &&
        activation_capabilities
            ->maximum_direct_factor_optimizer_calls.has_value()) {
      maximum_downstream_optimizer_calls =
          *activation_capabilities
               ->maximum_direct_factor_optimizer_calls;
    }
    auto minimum_construction_optimizer_calls =
        cp09_minimum_construction_optimizer_calls(
            manifest.provider, parameters.value());
    if (!minimum_construction_optimizer_calls) {
      return fail<ExecutionPlan>(
          minimum_construction_optimizer_calls.error());
    }
    auto budget_plan = make_budget_plan(
        instance, maximum_downstream_optimizer_calls,
        metric_draws.value(), full_orbit_addressed_work,
        minimum_construction_optimizer_calls.value());
    if (!budget_plan) {
      return fail<ExecutionPlan>(budget_plan.error());
    }

    auto targets = make_target_selection(request);
    if (!targets) {
      return fail<ExecutionPlan>(targets.error());
    }
    auto problem = build_framework_problem_view(
        instance, request.compiled_arrival(), targets.value());
    if (!problem) {
      return fail<ExecutionPlan>(problem.error());
    }
    if (uses_compact_factorized_iid_problem_view(
            manifest.provider, problem.value().configured_arrival())) {
      auto compact = project_factorized_iid_framework_problem_view(
          problem.value());
      if (!compact) {
        return fail<ExecutionPlan>(compact.error());
      }
      problem = std::move(compact);
    }

    auto preview = preview_surrogate_descriptor(
        provider, problem.value(), requirements,
        budget_plan.value().construction, parameters.value());
    if (!preview) {
      return fail<ExecutionPlan>(preview.error());
    }
    auto scalar_response_valid =
        validate_scalar_response_contract(problem.value(), preview.value());
    if (!scalar_response_valid) {
      return fail<ExecutionPlan>(scalar_response_valid.error());
    }

    const ArrivalCapabilities configured_arrival_capabilities =
        problem.value().configured_arrival().capabilities();
    CapabilityDecision decision = negotiate_capabilities(
        requirements, preview.value(), configured_arrival_capabilities);
    const AcceptedCapabilityContract* accepted =
        accepted_capability_contract(decision);
    if (accepted == nullptr) {
      return fail<ExecutionPlan>(explain_capability_failure(decision));
    }

    if (accepted->metric_contracts().size() != metric_requests.size()) {
      return fail<ExecutionPlan>(plan_error(
          DiagnosticCategory::internal,
          "c27.accepted_metric_cardinality_mismatch",
          "the accepted capability contract does not contain exactly one "
          "route for every authored metric"));
    }
    std::vector<PlannedMetricV1> metric_plans;
    metric_plans.reserve(metric_requests.size());
    for (std::size_t index = 0U; index < metric_requests.size(); ++index) {
      const ResolvedMetricContractV1& contract =
          accepted->metric_contracts()[index];
      const MetricRequest& metric = metric_requests[index];
      const MetricRequestHeader& header = metric_request_header(metric);
      if (contract.authored_metric_index != header.authored_index ||
          contract.metric_id != header.metric_id) {
        return fail<ExecutionPlan>(plan_error(
            DiagnosticCategory::internal,
            "c27.accepted_metric_order_mismatch",
            "the accepted capability contract changed authored metric order"));
      }
      const MetricSupportClauseV1* support = find_support_clause(
          accepted->structural_manifest(), contract.clause_id);
      if (support == nullptr) {
        return fail<ExecutionPlan>(plan_error(
            DiagnosticCategory::internal,
            "c27.accepted_support_clause_missing",
            "an accepted metric route has no structural support clause"));
      }
      const MetricRequirementClause* requirement =
          find_requirement_clause(requirements, contract.clause_id);
      if (requirement == nullptr) {
        return fail<ExecutionPlan>(plan_error(
            DiagnosticCategory::internal,
            "c27.accepted_requirement_clause_missing",
            "an accepted metric route has no frozen requirement clause"));
      }
      auto backend = make_backend_plan(metric, contract, *requirement, *support,
                                       preview.value().core,
                                       configured_arrival_capabilities);
      if (!backend) {
        return fail<ExecutionPlan>(backend.error());
      }
      metric_plans.push_back(PlannedMetricV1(
          metric, contract, std::move(backend).value()));
    }

    auto execution_available = validate_execution_availability(
        provider, preview.value(), *accepted, metric_plans,
        request.initial_physical_law());
    if (!execution_available) {
      return fail<ExecutionPlan>(execution_available.error());
    }

    std::optional<RegisteredExecutableSpec> executable;
    if (preview.value().producer_mode ==
        ProducerModeV1::local_executable_builder) {
      const RegisteredExecutableSpec* registered =
          provider.registered_executable();
      if (registered == nullptr) {
        return fail<ExecutionPlan>(plan_error(
            DiagnosticCategory::input_validation,
            "c27.local_executable_not_registered",
            "the selected local producer has no registry-owned executable "
            "specification"));
      }
      executable.emplace(*registered);
    }

    auto dependencies = make_dependency_schedule(
        metric_plans, preview.value().core.core_digest,
        arrival_law_binding(request.compiled_arrival()),
        is_builtin_c19_scalar_response(preview.value().core));
    auto rng_addresses = make_rng_address_templates(
        metric_plans, provider.framework_activation_capabilities());
    if (!rng_addresses) {
      return fail<ExecutionPlan>(rng_addresses.error());
    }
    ExecutionPlan plan(
        request, std::move(problem).value(), metric_requests,
        std::move(requirements), provider, std::move(parameters).value(),
        std::move(preview).value(), *accepted,
        std::move(budget_plan.value().construction),
        *regime.common_selection, *regime.common_solver,
        std::move(executable), std::move(metric_plans),
        std::move(budget_plan.value().work),
        std::move(rng_addresses).value(),
        std::move(dependencies));
    auto valid = validate_execution_plan(plan);
    if (!valid) {
      return fail<ExecutionPlan>(valid.error());
    }
    return Result<ExecutionPlan>::success(std::move(plan));
  } catch (const std::bad_alloc&) {
    return fail<ExecutionPlan>(plan_error(
        DiagnosticCategory::resource_limit,
        "c27.plan_allocation_failure",
        "execution-plan construction exhausted memory"));
  } catch (const std::exception&) {
    return fail<ExecutionPlan>(plan_error(
        DiagnosticCategory::internal, "c27.plan_exception",
        "execution-plan construction raised an unexpected exception"));
  } catch (...) {
    return fail<ExecutionPlan>(plan_error(
        DiagnosticCategory::internal, "c27.plan_unknown_exception",
        "execution-plan construction raised an unknown exception"));
  }
}

Result<void> validate_execution_plan(const ExecutionPlan& plan) {
  try {
    const ResolvedInstance& instance = plan.resolved_instance();
    const AnalysisSpec& analysis = instance.analysis_spec();
    if (!analysis.context || analysis.metrics.empty()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal, "c27.plan_missing_analysis_context",
          "the execution plan lost its resolved analysis context"));
    }
    if (plan.metric_requests_.size() != analysis.metrics.size() ||
        plan.metric_plans_.size() != analysis.metrics.size()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_metric_cardinality_mismatch",
          "the execution plan does not contain exactly one route for every "
          "authored metric"));
    }

    std::vector<MetricRequest> reparsed;
    reparsed.reserve(analysis.metrics.size());
    for (const MetricNode& node : analysis.metrics) {
      auto metric = parse_metric_request(node, instance.queues());
      if (!metric) {
        return Result<void>::failure(metric.error());
      }
      reparsed.push_back(std::move(metric).value());
    }
    if (!same_metric_requests(reparsed, plan.metric_requests_)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_metric_request_binding_mismatch",
          "the planned metric requests differ from the resolved authored "
          "requests"));
    }
    MetricRequirements recomputed_requirements =
        aggregate_metric_requirements(reparsed);
    if (!equivalent_metric_requirements(recomputed_requirements,
                                        plan.requirements_)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_requirements_binding_mismatch",
          "the planned aggregate requirements differ from the authored "
          "metric conjunction"));
    }
    const RegimeCompatibilityV1& regime =
        recomputed_requirements.regime_compatibility();
    if (regime.kind != RegimeCompatibilityKindV1::compatible ||
        !regime.common_selection.has_value() ||
        !regime.common_solver.has_value() ||
        *regime.common_selection != plan.selection_regime_ ||
        *regime.common_solver != plan.solver_regime_) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::input_validation,
          "c27.plan_regime_mismatch",
          "the execution plan does not preserve the one homogeneous "
          "selection and solver regime"));
    }

    auto expected_targets = make_target_selection(plan.resolved_request_);
    if (!expected_targets) {
      return Result<void>::failure(expected_targets.error());
    }
    if (!(plan.problem_view_.target_selection() == expected_targets.value())) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_target_selection_mismatch",
          "the frozen problem view has a foreign target/group binding"));
    }
    const SurrogateProviderManifestV1& manifest =
        plan.provider_.manifest().value();
    auto rebuilt_problem = build_framework_problem_view(
        instance, plan.compiled_arrival_law(), expected_targets.value());
    if (!rebuilt_problem) {
      return Result<void>::failure(rebuilt_problem.error());
    }
    if (uses_compact_factorized_iid_problem_view(
            manifest.provider,
            rebuilt_problem.value().configured_arrival())) {
      auto compact = project_factorized_iid_framework_problem_view(
          rebuilt_problem.value());
      if (!compact) {
        return Result<void>::failure(compact.error());
      }
      rebuilt_problem = std::move(compact);
    }
    if (!(rebuilt_problem.value() == plan.problem_view_)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_problem_view_binding_mismatch",
          "the frozen problem view differs from its canonical callback-free "
          "projection"));
    }

    const bool authored_provider_matches =
        manifest.provider.provider_id == analysis.surrogate.id &&
        (analysis.surrogate.version.has_value()
             ? manifest.provider.provider_version ==
                   *analysis.surrogate.version
             : plan.provider_.is_default() ||
                   (instance.authored_model().schema_version.value ==
                        kPhysicalSchemaVersionV4 &&
                    detail::is_full_orbit_cp09_provider(
                        manifest.provider)));
    if (!authored_provider_matches ||
        manifest.provider != plan.provider_.identity() ||
        plan.parameters_.provider() != manifest.provider ||
        plan.parameters_.parameter_schema_version() !=
            manifest.parameter_schema_version ||
        plan.parameters_.parameter_schema_digest() !=
            manifest.parameter_schema_digest) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_provider_parameter_binding_mismatch",
          "the provider, manifest, and validated parameter carrier do not "
          "share one identity and schema"));
    }
    auto parameter_digest = digest_surrogate_parameter_values_v1(
        plan.parameters_.canonical_value_bytes());
    if (!parameter_digest ||
        parameter_digest.value() !=
            plan.parameters_.canonical_value_digest()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_parameter_digest_mismatch",
          "the validated parameter bytes do not match their frozen digest"));
    }
    auto k_wide_resolution_binding =
        detail::validate_full_orbit_k_wide_resolution_binding(
            manifest.provider, plan.parameters_,
            analysis.context->resolution.tail);
    if (!k_wide_resolution_binding) {
      return k_wide_resolution_binding;
    }
    auto observation_resolution_binding =
        detail::validate_full_orbit_observation_resolution_binding(
            manifest.provider, plan.parameters_,
            analysis.context->resolution.tail);
    if (!observation_resolution_binding) {
      return observation_resolution_binding;
    }
    const bool full_orbit_addressed_work =
        detail::is_full_orbit_k_wide_provider(manifest.provider) ||
        detail::is_full_orbit_observation_provider(manifest.provider) ||
        detail::is_full_orbit_cp09_provider(manifest.provider);
    auto budget_digest =
        digest_construction_budget_v1(plan.construction_budget_);
    if (!budget_digest) {
      return Result<void>::failure(budget_digest.error());
    }

    const PlugDescriptorPreview& preview = plan.preview_;
    if (!preview.metric_support_manifest ||
        preview.schema_version != 1U ||
        preview.problem_view_digest !=
            plan.problem_view_.canonical_digest().value() ||
        preview.parameter_digest !=
            plan.parameters_.canonical_value_digest() ||
        preview.budget_digest != budget_digest.value() ||
        preview.construction_method != manifest.construction_method ||
        preview.producer_mode != manifest.producer_mode ||
        preview.core.provider != manifest.provider ||
        preview.core.payload_class != manifest.payload_class ||
        preview.core.semantic != manifest.deployed_semantic_tag ||
        preview.core.runtime_access != manifest.runtime_access_tag ||
        *preview.metric_support_manifest !=
            plan.capability_contract_.structural_manifest()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_preview_binding_mismatch",
          "the execution plan does not retain the exact provider preview "
          "and its problem/parameter/budget bindings"));
    }
    auto core_digest =
        canonical_plug_descriptor_core_digest_v1(preview.core);
    auto preview_digest =
        canonical_plug_descriptor_preview_digest_v1(preview);
    if (!core_digest || !preview_digest ||
        core_digest.value() != preview.core.core_digest ||
        preview_digest.value() != preview.preview_digest) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_preview_digest_mismatch",
          "the frozen provider preview is not canonical"));
    }

    const AcceptedCapabilityContract& accepted =
        plan.capability_contract_;
    const ArrivalCapabilities configured_arrival_capabilities =
        plan.problem_view_.configured_arrival().capabilities();
    auto requirements_digest =
        canonical_metric_requirements_digest(plan.requirements_);
    auto arrival_digest = canonical_arrival_capabilities_digest_v1(
        configured_arrival_capabilities);
    if (!requirements_digest || !arrival_digest) {
      return Result<void>::failure(
          !requirements_digest ? requirements_digest.error()
                               : arrival_digest.error());
    }
    if (accepted.provider() != manifest.provider ||
        accepted.construction_method() != preview.construction_method ||
        accepted.producer_mode() != preview.producer_mode ||
        accepted.payload_class() != preview.core.payload_class ||
        accepted.semantic() != preview.core.semantic ||
        accepted.runtime_access() != preview.core.runtime_access ||
        accepted.descriptor_core() != preview.core ||
        accepted.structural_manifest() != *preview.metric_support_manifest ||
        !equivalent_metric_requirements(accepted.requirements(),
                                        plan.requirements_) ||
        accepted.arrival_capabilities() !=
            configured_arrival_capabilities ||
        !std::equal(accepted.construction_target_scope().begin(),
                    accepted.construction_target_scope().end(),
                    preview.construction_target_scope.begin(),
                    preview.construction_target_scope.end()) ||
        accepted.policies() != preview.policies ||
        accepted.construction_prerequisites() !=
            preview.construction_prerequisites ||
        accepted.requirements_digest() != requirements_digest.value() ||
        accepted.arrival_capabilities_digest() != arrival_digest.value() ||
        accepted.preview_digest() != preview.preview_digest ||
        accepted.parameter_digest() != preview.parameter_digest ||
        accepted.budget_digest() != preview.budget_digest) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_capability_binding_mismatch",
          "the accepted capability contract is not the exact immutable "
          "snapshot of this plan's preview and requirements"));
    }
    if (!plan.requirements_.mandatory_v0() ||
        preview.core.mandatory_v0.kind !=
            V0DeclarationKindV1::structural_witness_required) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::input_validation,
          "c27.plan_v0_not_required",
          "every executable analysis plan must require the C17 V0 audit"));
    }

    auto scalar_response_valid =
        validate_scalar_response_contract(plan.problem_view_, preview);
    if (!scalar_response_valid) {
      return scalar_response_valid;
    }
    if (preview.construction_method == ConstructionMethodV1::precomputed &&
        preview.producer_mode != ProducerModeV1::inline_immediate) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::input_validation,
          "c27.precomputed_requires_inline_producer",
          "precomputed is a construction method and must use the "
          "inline_immediate producer mode"));
    }
    if (preview.producer_mode ==
        ProducerModeV1::local_executable_builder) {
      const RegisteredExecutableSpec* registered =
          plan.provider_.registered_executable();
      if (registered == nullptr || !plan.registered_executable_.has_value() ||
          *registered != *plan.registered_executable_ ||
          !manifest.local_executable.has_value() ||
          !manifest.local_executable->externally_reconstructible_arrival) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::input_validation,
            "c27.local_executable_binding_mismatch",
            "the local producer is not bound to one registry-owned executable "
            "and a reconstructible external arrival contract"));
      }
    } else if (plan.registered_executable_.has_value()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.unexpected_local_executable",
          "a non-local producer plan retained a local executable"));
    }

    if (accepted.metric_contracts().size() != plan.metric_plans_.size()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_metric_contract_cardinality_mismatch",
          "the accepted contract and typed backend plan have different "
          "metric cardinalities"));
    }
    BigNat metric_draws{0U};
    for (std::size_t index = 0U; index < plan.metric_plans_.size(); ++index) {
      const PlannedMetricV1& metric = plan.metric_plans_[index];
      const MetricRequestHeader& header = metric_request_header(metric.request());
      const ResolvedMetricContractV1& frozen =
          accepted.metric_contracts()[index];
      if (!same_metric_request(metric.request(),
                               plan.metric_requests_[index]) ||
          metric.contract() != frozen ||
          frozen.authored_metric_index != header.authored_index ||
          frozen.metric_id != header.metric_id ||
          !same_targets(frozen.ordered_targets, header.ordered_targets) ||
          metric.route_kind() != frozen.backend_route ||
          frozen.semantic != preview.core.semantic ||
          frozen.runtime_access != preview.core.runtime_access ||
          frozen.solver_regime != solver_regime(plan.solver_regime_)) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.plan_metric_route_binding_mismatch",
            "a typed backend route differs from its authored request or "
            "accepted C14 metric contract"));
      }
      if (header.coupling ==
              MetricTargetCouplingV1::common_schedule_coupled &&
          frozen.target_coupling == TargetCouplingV1::scalar_target) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::input_validation,
            "c27.joint_metric_requires_coupled_law",
            "a joint metric cannot use a scalar/uncoupled target law"));
      }
      if (header.coupling == MetricTargetCouplingV1::scalar_singleton &&
          header.ordered_targets.size() != 1U) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.scalar_metric_target_cardinality",
            "a scalar metric request must retain one target"));
      }
      const MetricSupportClauseV1* support =
          find_support_clause(accepted.structural_manifest(),
                              frozen.clause_id);
      if (support == nullptr) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.plan_support_clause_missing",
            "a planned metric route lost its accepted support clause"));
      }
      const MetricRequirementClause* requirement =
          find_requirement_clause(plan.requirements_, frozen.clause_id);
      if (requirement == nullptr) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.plan_requirement_clause_missing",
            "a planned metric route lost its frozen requirement clause"));
      }
      auto expected_backend = make_backend_plan(
          metric.request(), frozen, *requirement, *support, preview.core,
          configured_arrival_capabilities);
      if (!expected_backend || expected_backend.value() != metric.backend()) {
        return Result<void>::failure(
            expected_backend
                ? plan_error(DiagnosticCategory::internal,
                             "c27.plan_backend_payload_mismatch",
                             "the typed backend payload differs from its "
                             "accepted structural support clause")
                : expected_backend.error());
      }
      if (const auto* row =
              std::get_if<ConditionalRowMonteCarloBackendPlanV1>(
                  &metric.backend())) {
        metric_draws += row->worst_case_generator_draws;
      } else if (const auto* reward =
                     std::get_if<ConditionalRewardMonteCarloBackendPlanV1>(
                         &metric.backend())) {
        metric_draws += reward->worst_case_generator_draws;
      }
    }
    if (metric_draws != plan.work_bounds_.metric_generator_draws) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_metric_draw_bound_mismatch",
          "the metric draw bound is not the sum of exact authored "
          "replications"));
    }

    auto authored_metric_draws =
        authored_metric_draw_bound(plan.metric_requests_, plan.solver_regime_);
    if (!authored_metric_draws) {
      return Result<void>::failure(authored_metric_draws.error());
    }
    if (authored_metric_draws.value() != metric_draws) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_authored_metric_draw_bound_mismatch",
          "the typed backend draw bound differs from the exact authored "
          "Monte Carlo replication total"));
    }
    const std::optional<FrameworkActivationCapabilitiesV1>
        activation_capabilities =
            plan.provider_.framework_activation_capabilities();
    const bool exact_direct =
        plan.metric_plans_.size() == 1U &&
        plan.metric_plans_.front().route_kind() ==
            BackendRouteKindV1::exact_direct &&
        manifest.payload_class.tag ==
            PayloadClassTagV1::direct_metric_payload_v1 &&
        manifest.payload_class.version == 1U &&
        manifest.deployed_semantic_tag ==
            SemanticTagV1::direct_metric_decoder &&
        manifest.runtime_access_tag ==
            RuntimeAccessTagV1::direct_metric_decoder &&
        activation_capabilities.has_value() &&
        activation_capabilities->supplies_direct_factor;
    std::optional<BigNat> maximum_downstream_optimizer_calls{BigNat{0U}};
    if (exact_direct &&
        activation_capabilities
            ->maximum_direct_factor_optimizer_calls.has_value()) {
      maximum_downstream_optimizer_calls =
          *activation_capabilities
               ->maximum_direct_factor_optimizer_calls;
    }
    auto minimum_construction_optimizer_calls =
        cp09_minimum_construction_optimizer_calls(
            manifest.provider, plan.parameters_);
    if (!minimum_construction_optimizer_calls) {
      return Result<void>::failure(
          minimum_construction_optimizer_calls.error());
    }
    auto expected_budget_plan = make_budget_plan(
        instance, maximum_downstream_optimizer_calls,
        authored_metric_draws.value(), full_orbit_addressed_work,
        minimum_construction_optimizer_calls.value());
    if (!expected_budget_plan) {
      return Result<void>::failure(expected_budget_plan.error());
    }
    if (expected_budget_plan.value().construction !=
            plan.construction_budget_ ||
        expected_budget_plan.value().work != plan.work_bounds_) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_budget_derivation_mismatch",
          "the frozen construction grants or work bounds differ from the "
          "canonical budget plan derived from the resolved request"));
    }

    auto expected_rng_addresses = make_rng_address_templates(
        plan.metric_plans_,
        plan.provider_.framework_activation_capabilities());
    if (!expected_rng_addresses) {
      return Result<void>::failure(expected_rng_addresses.error());
    }
    if (expected_rng_addresses.value() != plan.rng_address_templates_) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_rng_address_templates_mismatch",
          "the frozen RNG route/stage address templates differ from the "
          "accepted stochastic backend plans"));
    }

    auto execution_available = validate_execution_availability(
        plan.provider_, preview, accepted, plan.metric_plans_,
        plan.initial_physical_law());
    if (!execution_available) {
      return execution_available;
    }

    const ConstructionBudget& budget = plan.construction_budget_;
    if (budget.schema_version != 1U ||
        !grant_is_well_formed(budget.exact_optimizer_calls) ||
        !grant_is_well_formed(budget.optimizer_search_states) ||
        !grant_is_well_formed(budget.configured_generator_draws) ||
        !grant_is_well_formed(budget.linear_residual_abs) ||
        !grant_is_well_formed(budget.integration_abs) ||
        !grant_is_well_formed(budget.tail_abs) ||
        !grant_is_well_formed(budget.fixed_point_abs) ||
        !grant_covers(budget.exact_optimizer_calls,
                      preview.construction_prerequisites
                          .required_optimizer_calls) ||
        !grant_covers(budget.configured_generator_draws,
                      preview.construction_prerequisites
                          .required_generator_draws)) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::resource_limit,
          "c27.plan_construction_budget_invalid",
          "the frozen construction budget is malformed or does not cover "
          "the accepted preview prerequisites"));
    }
    if (preview.construction_prerequisites.required_optimizer_calls
            .has_value() &&
        preview.construction_prerequisites.required_search_states_per_call
            .has_value()) {
      const BigNat required_search =
          *preview.construction_prerequisites.required_optimizer_calls *
          *preview.construction_prerequisites
               .required_search_states_per_call;
      if (!budget.optimizer_search_states.amount.has_value() ||
          *budget.optimizer_search_states.amount < required_search) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.plan_search_budget_insufficient",
            "the total optimizer-search grant does not cover the accepted "
            "call-by-per-call prerequisite"));
      }
    }

    const OptimizerBudgetPolicy& optimizer = instance.optimizer_budget();
    if (optimizer.max_calls.has_value()) {
      if (!plan.work_bounds_.optimizer_calls.has_value() ||
          *plan.work_bounds_.optimizer_calls > *optimizer.max_calls ||
          budget.exact_optimizer_calls.applicability !=
              BudgetApplicabilityV1::applicable ||
          !budget.exact_optimizer_calls.amount.has_value() ||
          *budget.exact_optimizer_calls.amount > *optimizer.max_calls) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.plan_optimizer_bound_invalid",
            "the finite optimizer cap lacks a conservative finite planned "
            "upper bound"));
      }
      if (full_orbit_addressed_work) {
        if (budget.optimizer_search_states.applicability !=
                BudgetApplicabilityV1::not_applicable ||
            budget.optimizer_search_states.amount.has_value() ||
            plan.work_bounds_.optimizer_search_states.has_value()) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::resource_limit,
              "c27.plan_k_wide_search_not_applicable",
              "the K-wide Full Orbit route must retain search-state work as "
              "NotApplicable without an observed counter"));
        }
      } else if (optimizer.effective_per_call.has_value()) {
        const BigNat maximum_search =
            *optimizer.max_calls * *optimizer.effective_per_call;
        const BigNat construction_search =
            *budget.exact_optimizer_calls.amount *
            *optimizer.effective_per_call;
        const BigNat planned_search =
            *plan.work_bounds_.optimizer_calls *
            *optimizer.effective_per_call;
        if (budget.optimizer_search_states.applicability !=
                BudgetApplicabilityV1::applicable ||
            !budget.optimizer_search_states.amount.has_value() ||
            *budget.optimizer_search_states.amount != construction_search ||
            !plan.work_bounds_.optimizer_search_states.has_value() ||
            *plan.work_bounds_.optimizer_search_states != planned_search ||
            planned_search > maximum_search) {
          return Result<void>::failure(plan_error(
              DiagnosticCategory::resource_limit,
              "c27.plan_optimizer_search_bound_invalid",
              "the total search-state grant does not equal the finite "
              "call-by-per-call optimizer bound"));
        }
      } else if (!budget.exact_optimizer_calls.amount->is_zero() &&
                 (budget.optimizer_search_states.applicability !=
                      BudgetApplicabilityV1::not_applicable ||
                  plan.work_bounds_.optimizer_search_states.has_value())) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::internal,
            "c27.plan_unbounded_optimizer_search_misreported",
            "an absent per-call search cap cannot be presented as a finite "
            "total search-state bound"));
      }
    }

    const std::optional<BigNat>& generator_cap =
        analysis.context->resolution.sampling.max_generator_draws;
    if (full_orbit_addressed_work) {
      if (budget.configured_generator_draws.applicability !=
              BudgetApplicabilityV1::not_applicable ||
          budget.configured_generator_draws.amount.has_value() ||
          !plan.work_bounds_.construction_generator_draws.has_value() ||
          !plan.work_bounds_.construction_generator_draws->is_zero() ||
          !plan.work_bounds_.metric_generator_draws.is_zero() ||
          !plan.work_bounds_.total_generator_draws.has_value() ||
          !plan.work_bounds_.total_generator_draws->is_zero()) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.plan_k_wide_draws_not_applicable",
            "the K-wide Full Orbit route must retain configured-generator "
            "draw work as NotApplicable without an observed counter"));
      }
    } else if (generator_cap.has_value()) {
      if (budget.configured_generator_draws.applicability !=
              BudgetApplicabilityV1::applicable ||
          !budget.configured_generator_draws.amount.has_value() ||
          !plan.work_bounds_.construction_generator_draws.has_value() ||
          *plan.work_bounds_.construction_generator_draws !=
              *budget.configured_generator_draws.amount ||
          !plan.work_bounds_.total_generator_draws.has_value() ||
          *plan.work_bounds_.total_generator_draws !=
              *plan.work_bounds_.construction_generator_draws +
                  plan.work_bounds_.metric_generator_draws ||
          *plan.work_bounds_.total_generator_draws > *generator_cap) {
        return Result<void>::failure(plan_error(
            DiagnosticCategory::resource_limit,
            "c27.plan_generator_bound_invalid",
            "construction and metric generator draws do not fit the one "
            "authored global cap"));
      }
    } else if (!metric_draws.is_zero() ||
               budget.configured_generator_draws.applicability !=
                   BudgetApplicabilityV1::not_applicable ||
               !plan.work_bounds_.construction_generator_draws.has_value() ||
               !plan.work_bounds_.construction_generator_draws->is_zero() ||
               !plan.work_bounds_.total_generator_draws.has_value() ||
               !plan.work_bounds_.total_generator_draws->is_zero()) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::input_validation,
          "c27.plan_generator_cap_missing",
          "a plan cannot dispatch Monte Carlo draws without an authored "
          "global draw cap"));
    }

    const auto expected_dependencies = make_dependency_schedule(
        plan.metric_plans_, preview.core.core_digest,
        arrival_law_binding(plan.compiled_arrival_law()),
        is_builtin_c19_scalar_response(preview.core));
    if (expected_dependencies != plan.dependency_schedule_) {
      return Result<void>::failure(plan_error(
          DiagnosticCategory::internal,
          "c27.plan_dependency_schedule_mismatch",
          "the dependency-sharing schedule is not the canonical grouping of "
          "the frozen typed routes"));
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::resource_limit,
        "c27.plan_validation_allocation_failure",
        "execution-plan validation exhausted memory"));
  } catch (const std::exception&) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::internal, "c27.plan_validation_exception",
        "execution-plan validation raised an unexpected exception"));
  } catch (...) {
    return Result<void>::failure(plan_error(
        DiagnosticCategory::internal,
        "c27.plan_validation_unknown_exception",
        "execution-plan validation raised an unknown exception"));
  }
}

}  // namespace mwperf
