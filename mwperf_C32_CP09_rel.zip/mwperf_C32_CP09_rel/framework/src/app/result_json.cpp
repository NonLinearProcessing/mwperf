#include "mwperf/app/result_artifact.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <charconv>
#include <cmath>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <exception>
#include <fstream>
#include <initializer_list>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <ranges>
#include <regex>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <type_traits>
#include <unordered_set>
#include <utility>
#include <variant>

#include <nlohmann/json.hpp>

#include "mwperf/app/execution_plan.hpp"
#include "mwperf/app/resolved_request.hpp"
#include "mwperf/app/surrogate_build_flow.hpp"
#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "mwperf/diagnostics/compression_comparison.hpp"
#include "mwperf/diagnostics/observation_record.hpp"
#include "mwperf/diagnostics/error_budget.hpp"

#include "mwperf/app/result_v1_schema_embedded.hpp"
#include "mwperf/app/result_v2_schema_embedded.hpp"
#include "mwperf/app/result_v3_schema_embedded.hpp"
#include "mwperf/app/compression_comparison_v1_schema_embedded.hpp"

#if defined(__unix__) || defined(__APPLE__)
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#endif

namespace mwperf {
namespace {

using Json = nlohmann::ordered_json;

struct SchemaValidationFailure final {
  std::string path;
  std::string message;
};

[[nodiscard]] bool schema_type_matches(
    const Json& instance, const std::string_view expected) noexcept {
  if (expected == "object") {
    return instance.is_object();
  }
  if (expected == "array") {
    return instance.is_array();
  }
  if (expected == "string") {
    return instance.is_string();
  }
  if (expected == "integer") {
    return instance.is_number_integer() || instance.is_number_unsigned();
  }
  if (expected == "number") {
    return instance.is_number();
  }
  if (expected == "boolean") {
    return instance.is_boolean();
  }
  if (expected == "null") {
    return instance.is_null();
  }
  return false;
}

class ResultSchemaValidator final {
 public:
  explicit ResultSchemaValidator(const Json& root) : root_(root) {}

  [[nodiscard]] std::optional<SchemaValidationFailure> validate(
      const Json& instance) const {
    return validate_node(instance, root_, "$");
  }

  // JSON objects are mathematically unordered, but published mwperf
  // artifacts use one byte-canonical member order.  Schema validation alone
  // therefore cannot distinguish a compact key permutation from the writer's
  // canonical bytes.  Walk the already selected schema branches and require
  // every object to follow the order of its closed `properties` declaration.
  [[nodiscard]] std::optional<SchemaValidationFailure>
  validate_canonical_member_order(const Json& instance) const {
    return validate_member_order_node(instance, root_, "$");
  }

 private:
  [[nodiscard]] const Json* resolve_reference(
      const std::string& reference) const noexcept {
    if (!reference.starts_with("#/")) {
      return nullptr;
    }
    try {
      return &root_.at(Json::json_pointer(reference.substr(1U)));
    } catch (const Json::exception&) {
      return nullptr;
    }
  }

  [[nodiscard]] static SchemaValidationFailure failure(
      const std::string& path, std::string message) {
    return {.path = path, .message = std::move(message)};
  }

  [[nodiscard]] static std::string child_path(
      const std::string& parent, const std::string_view child) {
    return parent + "/" + std::string(child);
  }

  [[nodiscard]] std::optional<SchemaValidationFailure>
  validate_member_order_node(const Json& instance, const Json& schema,
                             const std::string& path) const {
    if (!schema.is_object()) {
      return std::nullopt;
    }
    if (const auto reference = schema.find("$ref");
        reference != schema.end() && reference->is_string()) {
      const Json* target =
          resolve_reference(reference->get_ref<const std::string&>());
      if (target == nullptr) {
        return failure(path, "$ref is not a resolvable local reference");
      }
      if (auto error = validate_member_order_node(instance, *target, path)) {
        return error;
      }
    }
    if (const auto alternatives = schema.find("oneOf");
        alternatives != schema.end() && alternatives->is_array()) {
      const Json* selected = nullptr;
      for (const Json& alternative : *alternatives) {
        if (!validate_node(instance, alternative, path).has_value()) {
          selected = &alternative;
          // Full schema validation has already proved oneOf uniqueness.
          break;
        }
      }
      if (selected == nullptr) {
        return failure(path,
                       "canonical ordering has no matching oneOf branch");
      }
      if (auto error = validate_member_order_node(instance, *selected, path)) {
        return error;
      }
    }
    if (const auto conjunction = schema.find("allOf");
        conjunction != schema.end() && conjunction->is_array()) {
      for (const Json& conjunct : *conjunction) {
        if (auto error =
                validate_member_order_node(instance, conjunct, path)) {
          return error;
        }
      }
    }
    if (const auto condition = schema.find("if"); condition != schema.end()) {
      const bool matches = !validate_node(instance, *condition, path);
      const auto branch = schema.find(matches ? "then" : "else");
      if (branch != schema.end()) {
        if (auto error = validate_member_order_node(instance, *branch, path)) {
          return error;
        }
      }
    }

    if (instance.is_object()) {
      if (const auto properties = schema.find("properties");
          properties != schema.end() && properties->is_object()) {
        bool complete_property_order = true;
        for (auto member = instance.begin(); member != instance.end();
             ++member) {
          if (!properties->contains(member.key())) {
            complete_property_order = false;
            break;
          }
        }
        if (complete_property_order) {
          auto expected = properties->begin();
          for (auto member = instance.begin(); member != instance.end();
               ++member) {
            while (expected != properties->end() &&
                   expected.key() != member.key()) {
              ++expected;
            }
            if (expected == properties->end()) {
              return failure(child_path(path, member.key()),
                             "object members are not in canonical order");
            }
            if (auto error = validate_member_order_node(
                    member.value(), expected.value(),
                    child_path(path, member.key()))) {
              return error;
            }
            ++expected;
          }
        } else {
          // Conditional and oneOf branches commonly refine only a subset of
          // a closed object's members.  The enclosing complete schema owns
          // their order; this branch still recursively checks any nested
          // value it declares.
          for (auto property = properties->begin();
               property != properties->end(); ++property) {
            const auto member = instance.find(property.key());
            if (member != instance.end()) {
              if (auto error = validate_member_order_node(
                      *member, property.value(),
                      child_path(path, property.key()))) {
                return error;
              }
            }
          }
        }
      }
    } else if (instance.is_array()) {
      std::size_t prefix_count = 0U;
      if (const auto prefix = schema.find("prefixItems");
          prefix != schema.end() && prefix->is_array()) {
        prefix_count = std::min(prefix->size(), instance.size());
        for (std::size_t index = 0U; index < prefix_count; ++index) {
          if (auto error = validate_member_order_node(
                  instance[index], (*prefix)[index],
                  child_path(path, std::to_string(index)))) {
            return error;
          }
        }
      }
      if (const auto items = schema.find("items"); items != schema.end()) {
        for (std::size_t index = prefix_count; index < instance.size();
             ++index) {
          if (auto error = validate_member_order_node(
                  instance[index], *items,
                  child_path(path, std::to_string(index)))) {
            return error;
          }
        }
      }
    }
    return std::nullopt;
  }

  void collect_declared_properties(const Json& schema,
                                   std::set<std::string>& names) const {
    if (!schema.is_object()) {
      return;
    }
    if (const auto reference = schema.find("$ref");
        reference != schema.end() && reference->is_string()) {
      if (const Json* target =
              resolve_reference(reference->get_ref<const std::string&>());
          target != nullptr) {
        collect_declared_properties(*target, names);
      }
    }
    if (const auto properties = schema.find("properties");
        properties != schema.end() && properties->is_object()) {
      for (auto property = properties->begin();
           property != properties->end(); ++property) {
        names.insert(property.key());
      }
    }
    for (const std::string_view keyword : {"allOf", "oneOf"}) {
      const auto alternatives = schema.find(std::string(keyword));
      if (alternatives != schema.end() && alternatives->is_array()) {
        for (const Json& alternative : *alternatives) {
          collect_declared_properties(alternative, names);
        }
      }
    }
    for (const std::string_view keyword : {"then", "else"}) {
      const auto branch = schema.find(std::string(keyword));
      if (branch != schema.end()) {
        collect_declared_properties(*branch, names);
      }
    }
  }

  [[nodiscard]] std::optional<SchemaValidationFailure> validate_node(
      const Json& instance, const Json& schema,
      const std::string& path) const {
    if (schema.is_boolean()) {
      return schema.get<bool>()
                 ? std::nullopt
                 : std::optional<SchemaValidationFailure>(
                       failure(path, "boolean schema is false"));
    }
    if (!schema.is_object()) {
      return failure(path, "schema node is not an object or boolean");
    }

    if (const auto reference = schema.find("$ref");
        reference != schema.end()) {
      if (!reference->is_string()) {
        return failure(path, "$ref is not a string");
      }
      const Json* target =
          resolve_reference(reference->get_ref<const std::string&>());
      if (target == nullptr) {
        return failure(path, "$ref is not a resolvable local reference");
      }
      if (auto error = validate_node(instance, *target, path)) {
        return error;
      }
    }

    if (const auto type = schema.find("type"); type != schema.end() &&
        (!type->is_string() ||
         !schema_type_matches(instance,
                              type->get_ref<const std::string&>()))) {
      return failure(path, "instance has the wrong JSON type");
    }
    if (const auto constant = schema.find("const");
        constant != schema.end() && instance != *constant) {
      return failure(path, "instance differs from const");
    }
    if (const auto enumeration = schema.find("enum");
        enumeration != schema.end() &&
        (!enumeration->is_array() ||
         std::find(enumeration->begin(), enumeration->end(), instance) ==
             enumeration->end())) {
      return failure(path, "instance is not in enum");
    }

    if (const auto alternatives = schema.find("oneOf");
        alternatives != schema.end()) {
      if (!alternatives->is_array()) {
        return failure(path, "oneOf is not an array");
      }
      std::size_t matches = 0U;
      for (const Json& alternative : *alternatives) {
        if (!validate_node(instance, alternative, path).has_value()) {
          ++matches;
        }
      }
      if (matches != 1U) {
        return failure(path, "oneOf did not match exactly one branch");
      }
    }
    if (const auto conjunction = schema.find("allOf");
        conjunction != schema.end()) {
      if (!conjunction->is_array()) {
        return failure(path, "allOf is not an array");
      }
      for (const Json& conjunct : *conjunction) {
        if (auto error = validate_node(instance, conjunct, path)) {
          return error;
        }
      }
    }
    if (const auto condition = schema.find("if");
        condition != schema.end()) {
      const bool matches =
          !validate_node(instance, *condition, path).has_value();
      const auto branch = schema.find(matches ? "then" : "else");
      if (branch != schema.end()) {
        if (auto error = validate_node(instance, *branch, path)) {
          return error;
        }
      }
    }

    if (instance.is_string()) {
      const std::string& text = instance.get_ref<const std::string&>();
      if (const auto minimum = schema.find("minLength");
          minimum != schema.end() && minimum->is_number_unsigned() &&
          text.size() < minimum->get<std::size_t>()) {
        return failure(path, "string is shorter than minLength");
      }
      if (const auto pattern = schema.find("pattern");
          pattern != schema.end()) {
        if (!pattern->is_string()) {
          return failure(path, "pattern is not a string");
        }
        try {
          if (!std::regex_search(
                  text, std::regex(pattern->get_ref<const std::string&>()))) {
            return failure(path, "string does not match pattern");
          }
        } catch (const std::regex_error&) {
          return failure(path,
                         "published schema contains an invalid pattern");
        }
      }
    }

    if (instance.is_number()) {
      if (const auto minimum = schema.find("minimum");
          minimum != schema.end() &&
          instance.get<long double>() < minimum->get<long double>()) {
        return failure(path, "number is smaller than minimum");
      }
      if (const auto maximum = schema.find("maximum");
          maximum != schema.end() &&
          instance.get<long double>() > maximum->get<long double>()) {
        return failure(path, "number is larger than maximum");
      }
    }

    if (instance.is_array()) {
      if (const auto minimum = schema.find("minItems");
          minimum != schema.end() && minimum->is_number_unsigned() &&
          instance.size() < minimum->get<std::size_t>()) {
        return failure(path, "array is shorter than minItems");
      }
      if (const auto maximum = schema.find("maxItems");
          maximum != schema.end() && maximum->is_number_unsigned() &&
          instance.size() > maximum->get<std::size_t>()) {
        return failure(path, "array is longer than maxItems");
      }
      if (const auto unique = schema.find("uniqueItems");
          unique != schema.end() && unique->is_boolean() &&
          unique->get<bool>()) {
        for (std::size_t left = 0U; left < instance.size(); ++left) {
          for (std::size_t right = left + 1U; right < instance.size();
               ++right) {
            if (instance[left] == instance[right]) {
              return failure(path, "array violates uniqueItems");
            }
          }
        }
      }
      std::size_t prefix_count = 0U;
      if (const auto prefix_items = schema.find("prefixItems");
          prefix_items != schema.end()) {
        if (!prefix_items->is_array()) {
          return failure(path, "prefixItems is not an array");
        }
        prefix_count = prefix_items->size();
        const std::size_t validated = std::min(instance.size(), prefix_count);
        for (std::size_t index = 0U; index < validated; ++index) {
          if (auto error = validate_node(
                  instance[index], (*prefix_items)[index],
                  child_path(path, std::to_string(index)))) {
            return error;
          }
        }
      }
      if (const auto items = schema.find("items"); items != schema.end()) {
        for (std::size_t index = prefix_count; index < instance.size();
             ++index) {
          if (auto error = validate_node(
                  instance[index], *items,
                  child_path(path, std::to_string(index)))) {
            return error;
          }
        }
      }
      if (const auto contains = schema.find("contains");
          contains != schema.end()) {
        const bool matched = std::any_of(
            instance.begin(), instance.end(), [&](const Json& item) {
              return !validate_node(item, *contains, path).has_value();
            });
        if (!matched) {
          return failure(path, "array has no item matching contains");
        }
      }
    }

    if (instance.is_object()) {
      if (const auto minimum = schema.find("minProperties");
          minimum != schema.end() && minimum->is_number_unsigned() &&
          instance.size() < minimum->get<std::size_t>()) {
        return failure(path, "object has fewer members than minProperties");
      }
      if (const auto maximum = schema.find("maxProperties");
          maximum != schema.end() && maximum->is_number_unsigned() &&
          instance.size() > maximum->get<std::size_t>()) {
        return failure(path, "object has more members than maxProperties");
      }
      if (const auto required = schema.find("required");
          required != schema.end()) {
        if (!required->is_array()) {
          return failure(path, "required is not an array");
        }
        for (const Json& name : *required) {
          if (!name.is_string() ||
              !instance.contains(name.get_ref<const std::string&>())) {
            return failure(path, "required property is absent");
          }
        }
      }

      std::set<std::string> declared;
      if (const auto properties = schema.find("properties");
          properties != schema.end()) {
        if (!properties->is_object()) {
          return failure(path, "properties is not an object");
        }
        for (auto property = properties->begin();
             property != properties->end(); ++property) {
          declared.insert(property.key());
          const auto member = instance.find(property.key());
          if (member != instance.end()) {
            if (auto error = validate_node(
                    *member, property.value(),
                    child_path(path, property.key()))) {
              return error;
            }
          }
        }
      }

      if (const auto property_names = schema.find("propertyNames");
          property_names != schema.end()) {
        for (auto member = instance.begin(); member != instance.end();
             ++member) {
          if (auto error = validate_node(Json(member.key()), *property_names,
                                         child_path(path, member.key()))) {
            return error;
          }
        }
      }

      if (const auto additional = schema.find("additionalProperties");
          additional != schema.end()) {
        for (auto member = instance.begin(); member != instance.end();
             ++member) {
          if (declared.contains(member.key())) {
            continue;
          }
          if (additional->is_boolean()) {
            if (!additional->get<bool>()) {
              return failure(child_path(path, member.key()),
                             "additional property is forbidden");
            }
          } else if (auto error = validate_node(
                         member.value(), *additional,
                         child_path(path, member.key()))) {
            return error;
          }
        }
      }

      if (const auto unevaluated = schema.find("unevaluatedProperties");
          unevaluated != schema.end() && unevaluated->is_boolean() &&
          !unevaluated->get<bool>()) {
        std::set<std::string> evaluated;
        collect_declared_properties(schema, evaluated);
        for (auto member = instance.begin(); member != instance.end();
             ++member) {
          if (!evaluated.contains(member.key())) {
            return failure(child_path(path, member.key()),
                           "unevaluated property is forbidden");
          }
        }
      }
    }

    return std::nullopt;
  }

  const Json& root_;
};

#if !defined(NDEBUG) || defined(MWPERF_C27_TEST_SEAMS)
[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_json_against_published_schema(const std::string& document) {
  try {
    const Json schema = Json::parse(detail::kPublishedResultV1SchemaJson);
    const Json instance = Json::parse(document);
    return ResultSchemaValidator(schema).validate(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON parse failure: ") + exception.what(),
    };
  }
}
#endif

[[nodiscard]] const Json& published_result_v2_schema() {
  static const Json schema =
      Json::parse(detail::kPublishedResultV2SchemaJson);
  return schema;
}

[[nodiscard]] const Json& published_result_v3_schema() {
  static const Json schema =
      Json::parse(detail::kPublishedResultV3SchemaJson);
  return schema;
}

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_v3_json_against_published_schema(const Json& instance) {
  try {
    return ResultSchemaValidator(published_result_v3_schema())
        .validate(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON parse failure: ") + exception.what(),
      };
  }
}

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_v2_json_against_published_schema(const Json& instance) {
  try {
    return ResultSchemaValidator(published_result_v2_schema())
        .validate(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON parse failure: ") + exception.what(),
    };
  }
}

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_v2_canonical_member_order(const Json& instance) {
  try {
    return ResultSchemaValidator(published_result_v2_schema())
        .validate_canonical_member_order(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON schema traversal failure: ") +
                   exception.what(),
    };
  }
}

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_v3_canonical_member_order(const Json& instance) {
  try {
    return ResultSchemaValidator(published_result_v3_schema())
        .validate_canonical_member_order(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON schema traversal failure: ") +
                   exception.what(),
    };
  }
}

[[nodiscard]] const Json& published_compression_comparison_v1_schema() {
  static const Json schema = Json::parse(
      detail::kPublishedCompressionComparisonV1SchemaJson);
  return schema;
}

#if !defined(NDEBUG) || defined(MWPERF_C27_TEST_SEAMS)
[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_v2_json_against_published_schema(
    const std::string& document) {
  try {
    return validate_result_v2_json_against_published_schema(
        Json::parse(document));
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON parse failure: ") + exception.what(),
    };
  }
}

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_result_v3_json_against_published_schema(
    const std::string& document) {
  try {
    return validate_result_v3_json_against_published_schema(
        Json::parse(document));
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON parse failure: ") + exception.what(),
    };
  }
}
#endif

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_compression_comparison_v1_against_published_schema(
    const Json& instance) {
  try {
    return ResultSchemaValidator(published_compression_comparison_v1_schema())
        .validate(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON parse failure: ") + exception.what(),
    };
  }
}

[[nodiscard]] std::optional<SchemaValidationFailure>
validate_compression_comparison_v1_canonical_member_order(
    const Json& instance) {
  try {
    return ResultSchemaValidator(published_compression_comparison_v1_schema())
        .validate_canonical_member_order(instance);
  } catch (const Json::exception& exception) {
    return SchemaValidationFailure{
        .path = "$",
        .message = std::string("JSON schema traversal failure: ") +
                   exception.what(),
    };
  }
}

[[nodiscard]] Diagnostic result_error(std::string code,
                                      std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic publication_error(
    const std::filesystem::path& path, const std::string_view stage) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = "output_publication_failed",
      .message = "the result artifact could not be published atomically",
      .authored_path = path.string(),
      .json_pointer = std::nullopt,
      .notes = {"publication stage: " + std::string(stage)},
  };
}

template <typename Value>
[[nodiscard]] Result<Value> fail_result(std::string code,
                                        std::string message) {
  return Result<Value>::failure(
      result_error(std::move(code), std::move(message)));
}

class ResultV2SaxPreflight final : public nlohmann::json_sax<Json> {
 public:
  explicit ResultV2SaxPreflight(const ResultArtifactParseLimitsV2& limits)
      : limits_(limits), observation_limits_(
                              default_observation_parse_limits_v1()) {
    observation_limits_.maximum_bytes =
        std::min(observation_limits_.maximum_bytes, limits_.maximum_bytes);
    observation_limits_.maximum_nesting_depth = std::min(
        observation_limits_.maximum_nesting_depth,
        limits_.maximum_nesting_depth);
    observation_limits_.maximum_object_entries = std::min(
        observation_limits_.maximum_object_entries,
        limits_.maximum_object_entries);
    observation_limits_.maximum_array_entries = std::min(
        observation_limits_.maximum_array_entries,
        limits_.maximum_array_entries);
    observation_limits_.maximum_string_bytes = std::min(
        observation_limits_.maximum_string_bytes,
        limits_.maximum_string_bytes);
    observation_limits_.maximum_total_decoded_allocation_bytes = std::min(
        observation_limits_.maximum_total_decoded_allocation_bytes,
        limits_.maximum_total_decoded_allocation_bytes);
  }

  [[nodiscard]] bool null() override { return scalar(32U, 64U, 4U); }
  [[nodiscard]] bool boolean(const bool value) override {
    return scalar(32U, 64U, value ? 4U : 5U);
  }
  [[nodiscard]] bool number_integer(const number_integer_t value) override {
    return scalar(32U, 64U, integer_text_size(value));
  }
  [[nodiscard]] bool number_unsigned(const number_unsigned_t value) override {
    return scalar(32U, 64U, integer_text_size(value));
  }
  [[nodiscard]] bool number_float(number_float_t,
                                  const string_t& token) override {
    if (next_value_context() == Context::observation) {
      return reject("observation_parse_decimal_number_forbidden",
                    "decimal JSON numbers are not part of the embedded observation grammar");
    }
    return check_string(token) &&
           scalar_string(token.size(), token.size());
  }
  [[nodiscard]] bool string(string_t& value) override {
    return check_string(value) &&
           scalar_string(value.size(), canonical_json_string_size(value));
  }
  [[nodiscard]] bool binary(binary_t&) override {
    return reject("c30.result_v2_binary_value_forbidden",
                  "binary values are not valid result-v2 JSON");
  }
  [[nodiscard]] bool start_object(std::size_t) override {
    return begin_container(FrameKind::object);
  }
  [[nodiscard]] bool key(string_t& value) override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject("c30.result_v2_invalid_json",
                    "an object key appeared outside an object");
    }
    if (!check_string(value)) {
      return false;
    }
    if (object_entries_ >= limits_.maximum_object_entries) {
      return reject("c30.result_v2_object_entries_limit",
                    "result-v2 exceeds the cumulative object-entry cap");
    }
    Frame& frame = frames_.back();
    if (frame.keys.contains(value)) {
      return reject("c30.result_v2_duplicate_key",
                    "result-v2 contains a duplicate decoded object key");
    }
    if (frame.context == Context::observation &&
        observation_object_entries_ >=
            observation_limits_.maximum_object_entries) {
      return reject("observation_parse_object_entries_limit",
                    "the embedded observation exceeds its object-entry cap");
    }
    ++object_entries_;
    if (frame.context == Context::observation) {
      ++observation_object_entries_;
    }
    if (frame.context == Context::observation &&
        ((!frame.keys.empty() && !charge_observation_bytes(1U)) ||
         !charge_observation_bytes(canonical_json_string_size(value)) ||
         !charge_observation_bytes(1U))) {
      return false;
    }
    if (!charge(96U) || !charge(value.size()) || !charge(value.size()) ||
        (frame.context == Context::observation &&
         (!charge_observation(96U) ||
          !charge_observation(value.size()) ||
          !charge_observation(value.size())))) {
      return false;
    }
    frame.keys.insert(value);
    frame.pending_key = value;
    return true;
  }
  [[nodiscard]] bool end_object() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject("c30.result_v2_invalid_json",
                    "result-v2 has an unmatched object end");
    }
    return end_container();
  }
  [[nodiscard]] bool start_array(std::size_t) override {
    return begin_container(FrameKind::array);
  }
  [[nodiscard]] bool end_array() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::array) {
      return reject("c30.result_v2_invalid_json",
                    "result-v2 has an unmatched array end");
    }
    return end_container();
  }
  [[nodiscard]] bool parse_error(
      std::size_t, const std::string&,
      const nlohmann::detail::exception& error) override {
    return reject("c30.result_v2_invalid_json",
                  std::string("invalid result-v2 JSON: ") + error.what());
  }

  [[nodiscard]] const std::optional<Diagnostic>& diagnostic() const noexcept {
    return diagnostic_;
  }
  [[nodiscard]] std::size_t estimated_decoded_allocation() const noexcept {
    return allocation_;
  }

 private:
  enum class FrameKind : std::uint8_t { object, array };
  enum class Context : std::uint8_t {
    generic,
    root,
    diagnostic_supplement,
    observation,
  };
  enum class ObservationArrayRole : std::uint8_t {
    generic,
    replications,
    blocks,
    levels,
    boundary_rows,
    arrival_atoms,
    reporting_boundaries,
  };
  struct Frame final {
    FrameKind kind;
    Context context;
    ObservationArrayRole observation_array_role;
    std::unordered_set<std::string> keys;
    std::string pending_key;
    std::size_t array_values{0U};
  };

  template <typename Integer>
  [[nodiscard]] static std::size_t integer_text_size(
      const Integer value) noexcept {
    std::array<char, std::numeric_limits<Integer>::digits10 + 4U> buffer{};
    const auto result = std::to_chars(buffer.data(),
                                      buffer.data() + buffer.size(), value);
    return result.ec == std::errc{}
               ? static_cast<std::size_t>(result.ptr - buffer.data())
               : buffer.size();
  }
  [[nodiscard]] static std::size_t canonical_json_string_size(
      const std::string_view value) noexcept {
    std::size_t size = 2U;
    for (const unsigned char byte : value) {
      switch (byte) {
        case '"':
        case '\\':
        case '\b':
        case '\f':
        case '\n':
        case '\r':
        case '\t':
          size += 2U;
          break;
        default:
          size += byte < 0x20U ? 6U : 1U;
          break;
      }
    }
    return size;
  }

  [[nodiscard]] bool reject(std::string code, std::string message) {
    if (!diagnostic_) {
      diagnostic_ = Diagnostic{.category = DiagnosticCategory::input_validation,
                               .code = std::move(code),
                               .message = std::move(message),
                               .authored_path = std::nullopt,
                               .json_pointer = std::nullopt,
                               .notes = {}};
    }
    return false;
  }
  [[nodiscard]] bool check_string(const std::string_view value) {
    if (value.size() > limits_.maximum_string_bytes) {
      return reject("c30.result_v2_string_limit",
                    "a result-v2 JSON string exceeds the configured cap");
    }
    if (next_value_context() == Context::observation &&
        value.size() > observation_limits_.maximum_string_bytes) {
      return reject("observation_parse_string_limit",
                    "an embedded observation string exceeds its length cap");
    }
    return true;
  }
  [[nodiscard]] bool charge(const std::size_t amount) {
    if (amount > limits_.maximum_total_decoded_allocation_bytes ||
        allocation_ >
            limits_.maximum_total_decoded_allocation_bytes - amount) {
      return reject("c30.result_v2_allocation_limit",
                    "result-v2 exceeds the decoded-allocation cap");
    }
    allocation_ += amount;
    return true;
  }
  [[nodiscard]] bool charge_observation(const std::size_t amount) {
    if (amount >
            observation_limits_.maximum_total_decoded_allocation_bytes ||
        observation_allocation_ >
            observation_limits_.maximum_total_decoded_allocation_bytes -
                amount) {
      return reject(
          "observation_parse_allocation_limit",
          "the embedded observation exceeds its decoded-allocation cap");
    }
    observation_allocation_ += amount;
    return true;
  }
  [[nodiscard]] bool charge_observation_bytes(const std::size_t amount) {
    if (amount > observation_limits_.maximum_bytes ||
        observation_canonical_bytes_ >
            observation_limits_.maximum_bytes - amount) {
      return reject(
          "observation_parse_input_bytes_limit",
          "the embedded canonical observation envelope exceeds its byte cap");
    }
    observation_canonical_bytes_ += amount;
    return true;
  }
  [[nodiscard]] Context next_value_context() const noexcept {
    if (frames_.empty()) {
      return Context::root;
    }
    const Frame& parent = frames_.back();
    if (parent.context == Context::observation) {
      return Context::observation;
    }
    if (parent.kind != FrameKind::object) {
      return Context::generic;
    }
    if (parent.context == Context::root &&
        parent.pending_key == "diagnostic_supplement") {
      return Context::diagnostic_supplement;
    }
    if (parent.context == Context::diagnostic_supplement &&
        parent.pending_key == "observation_bundle") {
      return Context::observation;
    }
    return Context::generic;
  }
  [[nodiscard]] ObservationArrayRole next_observation_array_role(
      const Context context) const noexcept {
    if (context != Context::observation || frames_.empty() ||
        frames_.back().kind != FrameKind::object) {
      return ObservationArrayRole::generic;
    }
    const std::string_view key = frames_.back().pending_key;
    if (key == "replications") return ObservationArrayRole::replications;
    if (key == "blocks") return ObservationArrayRole::blocks;
    if (key == "levels") return ObservationArrayRole::levels;
    if (key == "rows") return ObservationArrayRole::boundary_rows;
    if (key == "atoms") return ObservationArrayRole::arrival_atoms;
    if (key == "reporting_block_boundaries") {
      return ObservationArrayRole::reporting_boundaries;
    }
    return ObservationArrayRole::generic;
  }
  [[nodiscard]] bool increment_observation_role(
      const ObservationArrayRole role) {
    std::size_t* counter = nullptr;
    std::size_t limit = 0U;
    std::string_view code;
    std::string_view name;
    switch (role) {
      case ObservationArrayRole::generic:
        return true;
      case ObservationArrayRole::replications:
        counter = &observation_replications_;
        limit = observation_limits_.maximum_replications;
        code = "observation_parse_replication_limit";
        name = "replication";
        break;
      case ObservationArrayRole::blocks:
        counter = &observation_blocks_;
        limit = observation_limits_.maximum_total_blocks;
        code = "observation_parse_block_limit";
        name = "block";
        break;
      case ObservationArrayRole::levels:
        counter = &observation_level_rows_;
        limit = observation_limits_.maximum_total_level_rows;
        code = "observation_parse_level_row_limit";
        name = "exact-level row";
        break;
      case ObservationArrayRole::boundary_rows:
        counter = &observation_boundary_rows_;
        limit = observation_limits_.maximum_total_boundary_rows;
        code = "observation_parse_boundary_row_limit";
        name = "boundary row";
        break;
      case ObservationArrayRole::arrival_atoms:
        counter = &observation_arrival_atoms_;
        limit = observation_limits_.maximum_arrival_atoms;
        code = "observation_parse_arrival_atom_limit";
        name = "arrival atom";
        break;
      case ObservationArrayRole::reporting_boundaries:
        counter = &observation_reporting_boundaries_;
        limit = observation_limits_.maximum_reporting_boundaries;
        code = "observation_parse_reporting_boundary_limit";
        name = "reporting boundary";
        break;
    }
    if (*counter >= limit) {
      return reject(std::string(code),
                    "the embedded observation exceeds its configured " +
                        std::string(name) + " cap");
    }
    ++*counter;
    return true;
  }
  [[nodiscard]] bool begin_value() {
    if (!frames_.empty() && frames_.back().kind == FrameKind::array) {
      if (array_entries_ >= limits_.maximum_array_entries) {
        return reject("c30.result_v2_array_entries_limit",
                      "result-v2 exceeds the cumulative array-entry cap");
      }
      ++array_entries_;
      if (frames_.back().context == Context::observation) {
        if (observation_array_entries_ >=
            observation_limits_.maximum_array_entries) {
          return reject(
              "observation_parse_array_entries_limit",
              "the embedded observation exceeds its cumulative array-entry cap");
        }
        ++observation_array_entries_;
        if (!increment_observation_role(
                frames_.back().observation_array_role)) {
          return false;
        }
      }
    }
    return true;
  }
  [[nodiscard]] bool begin_container(const FrameKind kind) {
    const Context context = next_value_context();
    const ObservationArrayRole observation_role =
        kind == FrameKind::array
            ? next_observation_array_role(context)
            : ObservationArrayRole::generic;
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= limits_.maximum_nesting_depth) {
      return reject("c30.result_v2_nesting_limit",
                    "result-v2 exceeds the nesting-depth cap");
    }
    if (context == Context::observation &&
        !begin_observation_encoded_value()) {
      return false;
    }
    // The standalone observation reader counts its envelope root as one
    // frame.  observation_depth_ counts only the embedded bundle subtree, so
    // reserving that one frame makes this test equivalent to its SAX check.
    if (context == Context::observation &&
        observation_depth_ + 1U >=
            observation_limits_.maximum_nesting_depth) {
      return reject(
          "observation_parse_nesting_limit",
          "the embedded observation exceeds its nesting-depth cap");
    }
    if (!charge(96U) ||
        (context == Context::observation &&
         (!charge_observation(96U) ||
          !charge_observation_bytes(1U)))) {
      return false;
    }
    frames_.push_back(
        Frame{kind, context, observation_role, {}, {}, 0U});
    if (context == Context::observation) {
      ++observation_depth_;
    }
    return true;
  }
  [[nodiscard]] bool end_container() {
    if (frames_.back().context == Context::observation) {
      if (!charge_observation_bytes(1U)) {
        return false;
      }
      --observation_depth_;
    }
    frames_.pop_back();
    return true;
  }
  [[nodiscard]] bool begin_observation_encoded_value() {
    if (!observation_bytes_initialized_) {
      constexpr std::size_t kEnvelopeFramingBytes =
          std::string_view{"{\"observation_bundle\":"}.size() +
          std::string_view{",\"observation_bundle_digest\":\""}.size() +
          64U + std::string_view{"\"}"}.size();
      if (!charge_observation_bytes(kEnvelopeFramingBytes)) {
        return false;
      }
      observation_bytes_initialized_ = true;
    }
    if (!frames_.empty() &&
        frames_.back().context == Context::observation &&
        frames_.back().kind == FrameKind::array) {
      Frame& array = frames_.back();
      if (array.array_values != 0U && !charge_observation_bytes(1U)) {
        return false;
      }
      ++array.array_values;
    }
    return true;
  }
  [[nodiscard]] bool scalar(const std::size_t amount,
                            const std::size_t observation_amount,
                            const std::size_t encoded_size) {
    const bool in_observation =
        next_value_context() == Context::observation;
    if (!begin_value() || !charge(amount)) {
      return false;
    }
    if (!in_observation) {
      return true;
    }
    if (!begin_observation_encoded_value() ||
        !charge_observation_bytes(encoded_size)) {
      return false;
    }
    if (observation_scalar_count_ >=
        observation_limits_.maximum_scalar_count) {
      return reject("observation_parse_scalar_limit",
                    "the embedded observation exceeds its scalar-count cap");
    }
    ++observation_scalar_count_;
    return charge_observation(observation_amount);
  }
  [[nodiscard]] bool scalar_string(const std::size_t size,
                                   const std::size_t encoded_size) {
    const bool in_observation =
        next_value_context() == Context::observation;
    if (!begin_value() || !charge(32U) || !charge(size)) {
      return false;
    }
    if (!in_observation) {
      return true;
    }
    if (!begin_observation_encoded_value() ||
        !charge_observation_bytes(encoded_size)) {
      return false;
    }
    if (observation_scalar_count_ >=
        observation_limits_.maximum_scalar_count) {
      return reject("observation_parse_scalar_limit",
                    "the embedded observation exceeds its scalar-count cap");
    }
    ++observation_scalar_count_;
    return charge_observation(96U) && charge_observation(size) &&
           charge_observation(size) && charge_observation(size);
  }

  const ResultArtifactParseLimitsV2& limits_;
  ObservationParseLimitsV1 observation_limits_;
  std::vector<Frame> frames_;
  std::size_t object_entries_{0U};
  std::size_t array_entries_{0U};
  std::size_t allocation_{0U};
  std::size_t observation_depth_{0U};
  std::size_t observation_object_entries_{0U};
  std::size_t observation_array_entries_{0U};
  std::size_t observation_scalar_count_{0U};
  std::size_t observation_allocation_{0U};
  std::size_t observation_canonical_bytes_{0U};
  bool observation_bytes_initialized_{false};
  std::size_t observation_replications_{0U};
  std::size_t observation_blocks_{0U};
  std::size_t observation_level_rows_{0U};
  std::size_t observation_boundary_rows_{0U};
  std::size_t observation_arrival_atoms_{0U};
  std::size_t observation_reporting_boundaries_{0U};
  std::optional<Diagnostic> diagnostic_;
};

template <typename Value, typename Key>
[[nodiscard]] bool unique_by(const std::vector<Value>& values, Key key) {
  std::set<std::string> seen;
  for (const Value& value : values) {
    if (!seen.insert(key(value)).second) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] ExactRational exact_scalar(
    const PortableScientificScalar& value) {
  if (value.kind() == PortableScientificScalarKind::rational) {
    return value.rational_value();
  }
  return binary64_as_exact_rational(value);
}

[[nodiscard]] bool scalar_in_closed_unit_interval(
    const PortableScientificScalar& value) {
  const ExactRational exact = exact_scalar(value);
  return exact >= ExactRational::zero() && exact <= ExactRational::one();
}

[[nodiscard]] bool scalar_is_nonnegative(
    const PortableScientificScalar& value) {
  return exact_scalar(value) >= ExactRational::zero();
}

[[nodiscard]] bool valid_c19_status_text(
    const std::string_view status) noexcept {
  static constexpr std::array<std::string_view, 13U> values{
      "finite",
      "infinite",
      "not_established",
      "strict_tail_stable",
      "finite_closed_tail_unreachable",
      "outside_strict_tail_profile",
      "degenerate_or_selected_closed_class",
      "required_moment_unavailable",
      "not_summable",
      "incomplete_tail",
      "multiple_classes_or_roots",
      "unsupported_assumptions",
      "numerically_unresolved",
  };
  return std::ranges::find(values, status) != values.end();
}

[[nodiscard]] bool valid_tail_slack_applicability_text(
    const std::string_view applicability) noexcept {
  static constexpr std::array<std::string_view, 3U> values{
      "applicable", "not_applicable_off_class",
      "stationary_law_not_established"};
  return std::ranges::find(values, applicability) != values.end();
}

[[nodiscard]] bool valid_unavailable_diagnostics(
    const ResultUnavailableDiagnosticsV1& diagnostics) {
  if (diagnostics.response_cutoff < BigNat{2U} ||
      diagnostics.response_cutoff > BigNat{5U} ||
      diagnostics.causes.empty() ||
      std::ranges::any_of(diagnostics.causes, [](const auto& cause) {
        return cause.code.empty() || cause.message.empty() ||
               (cause.metric_id && cause.metric_id->empty());
      })) {
    return false;
  }
  const std::size_t cutoff =
      diagnostics.response_cutoff.value().convert_to<std::size_t>();
  if (!diagnostics.coefficient_diagnostics.empty()) {
    if (diagnostics.coefficient_diagnostics.size() != cutoff + 2U) {
      return false;
    }
    for (std::size_t index = 0U;
         index < diagnostics.coefficient_diagnostics.size(); ++index) {
      const ResultKBinCoefficientDiagnosticV1& coefficient =
          diagnostics.coefficient_diagnostics[index];
      const ResultKBinCoordinateKindV1 expected_kind =
          index == 0U
              ? ResultKBinCoordinateKindV1::structural_level_zero
              : (index <= cutoff
                     ? ResultKBinCoordinateKindV1::exact_level
                     : ResultKBinCoordinateKindV1::constant_tail);
      if (coefficient.coordinate_kind != expected_kind ||
          coefficient.level_or_tail_from !=
              BigNat{static_cast<std::uint64_t>(index)} ||
          !scalar_is_nonnegative(coefficient.pooled_unserved_mass) ||
          !scalar_is_nonnegative(coefficient.pooled_served_mass) ||
          !scalar_in_closed_unit_interval(
              coefficient.nominal_service_probability) ||
          coefficient.construction_interval_lower.has_value() !=
              coefficient.construction_interval_upper.has_value()) {
        return false;
      }
      if (coefficient.construction_interval_lower &&
          (!scalar_in_closed_unit_interval(
               *coefficient.construction_interval_lower) ||
           !scalar_in_closed_unit_interval(
               *coefficient.construction_interval_upper) ||
           exact_scalar(*coefficient.construction_interval_lower) >
               exact_scalar(*coefficient.construction_interval_upper))) {
        return false;
      }
    }
  }
  if (!diagnostics.c19) return true;
  const ResultC19UnavailableDiagnosticsV1& c19 = *diagnostics.c19;
  if (diagnostics.coefficient_diagnostics.empty() ||
      !valid_c19_status_text(c19.analytic_status) ||
      !valid_tail_slack_applicability_text(
          c19.tail_slack_applicability) ||
      c19.service_by_level.size() != cutoff + 1U ||
      c19.tail_from != BigNat{static_cast<std::uint64_t>(cutoff + 1U)} ||
      !scalar_is_nonnegative(c19.arrival_mean) ||
      !scalar_in_closed_unit_interval(c19.tail_service) ||
      std::ranges::any_of(c19.service_by_level, [](const auto& value) {
        return !scalar_in_closed_unit_interval(value);
      }) ||
      exact_scalar(c19.tail_slack) !=
          exact_scalar(c19.tail_service) - exact_scalar(c19.arrival_mean)) {
    return false;
  }
  for (std::size_t level = 0U; level <= cutoff; ++level) {
    if (exact_scalar(c19.service_by_level[level]) !=
        exact_scalar(diagnostics.coefficient_diagnostics[level]
                         .nominal_service_probability)) {
      return false;
    }
  }
  return exact_scalar(c19.tail_service) ==
         exact_scalar(diagnostics.coefficient_diagnostics.back()
                          .nominal_service_probability);
}

[[nodiscard]] bool valid_metric_kind(const MetricKindV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(
             MetricKindV1::ordered_schedule_sequence);
}

[[nodiscard]] bool valid_metric_scope(
    const MetricResultScopeV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(MetricResultScopeV1::physical_bound);
}

[[nodiscard]] bool valid_component_scope(
    const ComponentScopeV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <= 8U;
}

[[nodiscard]] bool valid_product_kind(const ProductKindV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <= 4U;
}

[[nodiscard]] bool valid_raw_value_form(
    const ResponseProductValueFormV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(
             ResponseProductValueFormV1::interval_only);
}

[[nodiscard]] bool valid_response_bin(
    const ThreeBinCoefficientV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(
             ThreeBinCoefficientV1::tail_from_three);
}

[[nodiscard]] constexpr bool valid_stage_tag(const StageTag value) noexcept {
  switch (value) {
    case StageTag::initial_joint_atom:
    case StageTag::prearrival_closure:
    case StageTag::tie_resolution:
    case StageTag::configured_arrival:
    case StageTag::postarrival_closure:
    case StageTag::controller_post:
    case StageTag::generic_sampling:
    case StageTag::importance_proposal:
    case StageTag::training:
    case StageTag::solver_sampling:
    case StageTag::surrogate_build_input:
    case StageTag::surrogate_build_context:
    case StageTag::surrogate_build_probe:
    case StageTag::surrogate_build_final:
      return true;
  }
  return false;
}

[[nodiscard]] constexpr bool construction_stage_tag(
    const StageTag value) noexcept {
  return value == StageTag::surrogate_build_input ||
         value == StageTag::surrogate_build_context ||
         value == StageTag::surrogate_build_probe ||
         value == StageTag::surrogate_build_final;
}

[[nodiscard]] bool valid_replay_stream(
    const ResultReplayStreamV1& value) {
  return std::visit(
      []<typename Stream>(const Stream& stream) {
        if constexpr (std::same_as<Stream,
                                   ResultConstructionReplayStreamV1>) {
          return construction_stage_tag(stream.stage_tag);
        } else {
          return valid_stage_tag(stream.stage_tag) &&
                 !construction_stage_tag(stream.stage_tag);
        }
      },
      value);
}

[[nodiscard]] bool same_replay_identity(
    const ResultReplayStreamV1& left,
    const ResultReplayStreamV1& right) {
  if (left.index() != right.index()) {
    return false;
  }
  return std::visit(
      []<typename Left, typename Right>(const Left& lhs, const Right& rhs) {
        if constexpr (!std::same_as<Left, Right>) {
          return false;
        } else if constexpr (std::same_as<
                                 Left, ResultConstructionReplayStreamV1>) {
          return lhs.stage_tag == rhs.stage_tag &&
                 lhs.stream_instance_id == rhs.stream_instance_id;
        } else {
          return lhs.stage_tag == rhs.stage_tag &&
                 lhs.stream_identity == rhs.stream_identity;
        }
      },
      left, right);
}

[[nodiscard]] StageTag replay_stage_tag(
    const ResultReplayStreamV1& value) {
  return std::visit([](const auto& stream) { return stream.stage_tag; }, value);
}

[[maybe_unused, nodiscard]] bool replay_identity_less(
    const ResultReplayStreamV1& left,
    const ResultReplayStreamV1& right) {
  const auto left_stage = stage_tag_value(replay_stage_tag(left));
  const auto right_stage = stage_tag_value(replay_stage_tag(right));
  if (left_stage != right_stage) {
    return left_stage < right_stage;
  }
  if (left.index() != right.index()) {
    return left.index() < right.index();
  }
  return std::visit(
      []<typename Left, typename Right>(const Left& lhs, const Right& rhs) {
        if constexpr (!std::same_as<Left, Right>) {
          return false;
        } else if constexpr (std::same_as<
                                 Left, ResultConstructionReplayStreamV1>) {
          return lhs.stream_instance_id < rhs.stream_instance_id;
        } else {
          return lhs.stream_identity < rhs.stream_identity;
        }
      },
      left, right);
}

[[nodiscard]] const ResultBudgetUsageV1* find_budget_row(
    const std::span<const ResultBudgetUsageV1> rows,
    const std::string_view name) noexcept {
  const auto found = std::find_if(
      rows.begin(), rows.end(), [&name](const ResultBudgetUsageV1& row) {
        return row.name == name;
      });
  return found == rows.end() ? nullptr : &*found;
}

[[nodiscard]] bool failure_references_diagnostic_code(
    const AnalysisBundle& bundle, const std::string_view code) {
  if (!bundle.failure().has_value()) return false;
  return std::ranges::any_of(
      bundle.diagnostics(), [&](const ResultDiagnosticV1& diagnostic) {
        return diagnostic.code == code &&
               std::ranges::find(bundle.failure()->diagnostic_refs,
                                 diagnostic.diagnostic_id) !=
                   bundle.failure()->diagnostic_refs.end();
      });
}

[[nodiscard]] bool unique_budget_names(
    const std::span<const ResultBudgetUsageV1> rows) {
  std::set<std::string_view> names;
  return std::all_of(rows.begin(), rows.end(), [&](const auto& row) {
    return names.insert(row.name).second;
  });
}

[[nodiscard]] bool well_formed_budget_row(
    const ResultBudgetUsageV1& row) noexcept {
  if (row.name.empty() || row.unit.empty()) return false;
  if (row.applicability == ResultBudgetApplicabilityV1::not_applicable) {
    return !row.granted.has_value() && row.used.is_zero();
  }
  return row.applicability == ResultBudgetApplicabilityV1::applicable &&
         row.granted.has_value() && row.used <= *row.granted;
}

[[nodiscard]] ResultBudgetApplicabilityV1 result_applicability(
    const BudgetApplicabilityV1 applicability) noexcept {
  return applicability == BudgetApplicabilityV1::applicable
             ? ResultBudgetApplicabilityV1::applicable
             : ResultBudgetApplicabilityV1::not_applicable;
}

[[nodiscard]] bool matches_construction_budget_row(
    const ResultBudgetUsageV1& row, const std::string_view name,
    const CountConstructionGrantV1& grant,
    const CommonWorkCounterV1& counter) noexcept {
  return row.name == name && row.unit == "count" &&
         row.applicability == result_applicability(grant.applicability) &&
         ((counter.applicability == WorkCounterApplicabilityV1::applicable &&
           row.applicability == ResultBudgetApplicabilityV1::applicable) ||
          (counter.applicability ==
               WorkCounterApplicabilityV1::not_applicable &&
           row.applicability ==
               ResultBudgetApplicabilityV1::not_applicable)) &&
         row.granted == grant.amount && row.used == counter.used;
}

[[nodiscard]] const BigNat* sampling_draw_cap(
    const PlannedMetricV1& metric) noexcept {
  if (const auto* row =
          std::get_if<ConditionalRowMonteCarloBackendPlanV1>(
              &metric.backend())) {
    return &row->worst_case_generator_draws;
  }
  if (const auto* reward =
          std::get_if<ConditionalRewardMonteCarloBackendPlanV1>(
              &metric.backend())) {
    return &reward->worst_case_generator_draws;
  }
  return nullptr;
}

[[nodiscard]] const RngAddressTemplateV1* rng_template_for_metric(
    const ExecutionPlan& plan, const PlannedMetricV1& metric) noexcept {
  const std::size_t authored_index =
      metric_request_header(metric.request()).authored_index;
  const RngAddressTemplateV1* match = nullptr;
  for (const RngAddressTemplateV1& candidate :
       plan.rng_address_templates()) {
    if (candidate.authored_metric_index != authored_index) continue;
    if (match != nullptr) return nullptr;
    match = &candidate;
  }
  return match;
}

struct ReplayStageCountV1 final {
  StageTag stage;
  BigNat count;
};

void add_stage_count(std::vector<ReplayStageCountV1>& counts,
                     const StageTag stage, const BigNat& amount) {
  const auto found = std::find_if(
      counts.begin(), counts.end(), [stage](const ReplayStageCountV1& row) {
        return row.stage == stage;
      });
  if (found == counts.end()) {
    counts.push_back(ReplayStageCountV1{stage, amount});
  } else {
    found->count += amount;
  }
}

[[nodiscard]] BigNat stage_count(
    const std::vector<ReplayStageCountV1>& counts,
    const StageTag stage) {
  const auto found = std::find_if(
      counts.begin(), counts.end(), [stage](const ReplayStageCountV1& row) {
        return row.stage == stage;
      });
  return found == counts.end() ? BigNat{0U} : found->count;
}

struct StoppedBudgetExpectationV1 final {
  std::string prefix;
  std::string name;
  std::string_view suffix;
};

[[nodiscard]] bool matches_stopped_budget_grant(
    const ExecutionPlan& plan, const ResultBudgetUsageV1& row,
    const std::string_view suffix) noexcept {
  if (row.applicability != ResultBudgetApplicabilityV1::applicable ||
      !row.granted.has_value()) {
    return false;
  }
  const ResolutionEnvelope& resolution =
      plan.resolved_instance().analysis_spec().context->resolution;
  if (suffix == ".stopped_states") {
    return row.unit == "states" && resolution.level.max_states.has_value() &&
           row.granted == resolution.level.max_states;
  }
  if (suffix == ".stopped_row_atoms") {
    return row.unit == "row_atoms" &&
           resolution.level.max_row_atoms.has_value() &&
           row.granted == resolution.level.max_row_atoms;
  }
  if (suffix != ".stopped_iterations" || row.unit != "iterations") {
    return false;
  }
  const auto* solver = std::get_if<EnumeratedSolver>(
      &plan.resolved_instance().analysis_spec().context->solver);
  return solver != nullptr && solver->max_iterations.has_value() &&
         row.granted == solver->max_iterations;
}

void append_stopped_budget_expectations(
    const ExecutionPlan& plan, const std::string_view prefix,
    const bool uses_stopped_solver,
    std::vector<StoppedBudgetExpectationV1>& expected) {
  const ResolutionEnvelope& resolution =
      plan.resolved_instance().analysis_spec().context->resolution;
  if (resolution.level.max_states.has_value()) {
    expected.push_back(StoppedBudgetExpectationV1{
        std::string(prefix), std::string(prefix) + ".stopped_states",
        ".stopped_states"});
  }
  if (resolution.level.max_row_atoms.has_value()) {
    expected.push_back(StoppedBudgetExpectationV1{
        std::string(prefix),
        std::string(prefix) + ".stopped_row_atoms",
        ".stopped_row_atoms"});
  }
  if (!uses_stopped_solver) return;
  const auto* solver = std::get_if<EnumeratedSolver>(
      &plan.resolved_instance().analysis_spec().context->solver);
  if (solver != nullptr && solver->max_iterations.has_value()) {
    expected.push_back(StoppedBudgetExpectationV1{
        std::string(prefix),
        std::string(prefix) + ".stopped_iterations",
        ".stopped_iterations"});
  }
}

[[nodiscard]] const FifoConditionV1* result_fifo_condition(
    const MetricRequest& request) noexcept {
  const auto* conditioned =
      std::get_if<FifoDelayConditionedRequestV1>(&request);
  return conditioned == nullptr ? nullptr
                                : &conditioned->parameters().condition;
}

// FIFO execution constructs one shared distribution on first encounter for
// each exact target-and-entrance group. Its horizon is aggregated over that
// same group, while selection, solver, and sealed temporal source are shared
// by the one frozen plan/execution. Reproduce that cache key here so result
// validation neither authorizes one row set per metric nor invents groups.
[[nodiscard]] bool same_result_fifo_group(
    const MetricRequest& left, const MetricRequest& right) {
  if (metric_request_header(left).ordered_targets !=
      metric_request_header(right).ordered_targets) {
    return false;
  }
  const FifoConditionV1* left_condition = result_fifo_condition(left);
  const FifoConditionV1* right_condition = result_fifo_condition(right);
  return (left_condition == nullptr && right_condition == nullptr) ||
         (left_condition != nullptr && right_condition != nullptr &&
          *left_condition == *right_condition);
}

[[nodiscard]] std::vector<StoppedBudgetExpectationV1>
expected_stopped_budget_rows(const ExecutionPlan& plan) {
  std::vector<StoppedBudgetExpectationV1> expected;
  std::vector<const MetricRequest*> fifo_groups;
  for (const PlannedMetricV1& metric : plan.metric_plans()) {
    const MetricRequest& request = metric.request();
    const MetricRequestHeader& header = metric_request_header(request);
    const BackendRouteKindV1 route = metric.route_kind();
    const bool transient_temporal =
        plan.selection_regime() == MetricSelectionRegimeV1::transient &&
        (route == BackendRouteKindV1::finite_temporal_cylinder ||
         route == BackendRouteKindV1::residence_or_stopped_law);
    if (transient_temporal) {
      const MetricKindV1 kind = metric_request_kind(request);
      if (kind == MetricKindV1::transient_backlog_law ||
          kind == MetricKindV1::first_hit ||
          kind == MetricKindV1::threshold_excursion) {
        append_stopped_budget_expectations(
            plan, "backend." + header.metric_id,
            kind == MetricKindV1::first_hit ||
                kind == MetricKindV1::threshold_excursion,
            expected);
      }
      continue;
    }
    if (route == BackendRouteKindV1::residence_or_stopped_law) {
      // Plan validation admits only stationary event-gap and first-hit
      // requests here; both execute the iterative C22 stopped evaluator.
      if (header.kind == MetricKindV1::event_gap_distribution ||
          header.kind == MetricKindV1::first_hit) {
        append_stopped_budget_expectations(
            plan, "backend." + header.metric_id, true, expected);
      }
      continue;
    }
    if (route != BackendRouteKindV1::palm_or_fifo_law) continue;
    const auto group = std::ranges::find_if(
        fifo_groups, [&](const MetricRequest* candidate) {
          return same_result_fifo_group(*candidate, request);
        });
    if (group != fifo_groups.end()) continue;
    const std::size_t ordinal = fifo_groups.size();
    fifo_groups.push_back(&request);
    append_stopped_budget_expectations(
        plan, "backend.fifo_group." + std::to_string(ordinal), true,
        expected);
  }
  return expected;
}

// F-C27-05 is a binding boundary, not merely a JSON conversion.  Validate
// every result-side accounting carrier that can be recomputed from the
// frozen plan or from C15's already-validated build report before copying it
// into result-v1.  Construction stream IDs themselves remain C15 provenance:
// C27 checks their closed shape but never manufactures a replacement digest.
[[nodiscard]] Result<void> validate_analysis_accounting_bindings(
    const ExecutionPlan& plan, const AnalysisBundle& bundle) {
  const auto execution_rows = bundle.execution_budget_usage();
  const auto backend_rows = bundle.backend_budget_usage();
  if (!unique_budget_names(execution_rows) ||
      !unique_budget_names(backend_rows) ||
      !std::all_of(execution_rows.begin(), execution_rows.end(),
                   well_formed_budget_row) ||
      !std::all_of(backend_rows.begin(), backend_rows.end(),
                   well_formed_budget_row)) {
    return Result<void>::failure(result_error(
        "c27.result_accounting_row_invalid",
        "analysis accounting rows must be unique, internally valid, and bounded by their reported grants"));
  }

  const ConstructionBudget& construction = plan.construction_budget();
  const CommonBuildReportV1* report =
      bundle.build_report().has_value() ? &*bundle.build_report() : nullptr;
  const bool payload_present =
      bundle.execution_identity().payload_digest.has_value();
  const bool seal_present =
      bundle.execution_identity().execution_seal_digest.has_value();
  struct ConstructionExpectationV1 final {
    std::string_view name;
    const CountConstructionGrantV1* grant;
    const CommonWorkCounterV1* counter;
  };
  const std::array<ConstructionExpectationV1, 3U> construction_rows{{
      {"construction.exact_optimizer_calls",
       &construction.exact_optimizer_calls,
       report == nullptr ? nullptr : &report->optimizer_calls},
      {"construction.optimizer_search_states",
       &construction.optimizer_search_states,
       report == nullptr ? nullptr : &report->optimizer_search_states},
      {"construction.configured_generator_draws",
       &construction.configured_generator_draws,
       report == nullptr ? nullptr : &report->configured_generator_draws},
  }};
  for (const ConstructionExpectationV1& expected : construction_rows) {
    const ResultBudgetUsageV1* row =
        find_budget_row(execution_rows, expected.name);
    if (report == nullptr) {
      if (row != nullptr) {
        return Result<void>::failure(result_error(
            "c27.result_construction_budget_without_report",
            "analysis output contains construction usage without C15's validated common build report"));
      }
    } else if (row == nullptr ||
               !matches_construction_budget_row(
                   *row, expected.name, *expected.grant,
                   *expected.counter)) {
      return Result<void>::failure(result_error(
          "c27.result_construction_budget_binding_mismatch",
          "construction budget usage does not exactly match the frozen grant and C15 build-report counter"));
    }
  }

  auto construction_digest =
      digest_construction_budget_v1(plan.construction_budget());
  if (!construction_digest) {
    return Result<void>::failure(construction_digest.error());
  }
  if (report != nullptr &&
      report->construction_budget_digest != construction_digest.value()) {
    return Result<void>::failure(result_error(
        "c27.result_construction_budget_digest_mismatch",
        "the retained C15 build report is bound to a different construction budget"));
  }

  const ResultBudgetUsageV1* optimizer =
      find_budget_row(execution_rows, "execution.shared_optimizer_calls");
  const ResultBudgetUsageV1* optimizer_search_states = find_budget_row(
      execution_rows, "execution.shared_optimizer_search_states");
  const std::optional<BigNat>& optimizer_cap =
      plan.work_bounds().optimizer_calls;
  const std::optional<BigNat>& optimizer_search_state_cap =
      plan.work_bounds().optimizer_search_states;
  const bool pre_optimizer_terminal =
      bundle.failure().has_value() &&
      bundle.failure()->stage == ResultFailureStageV1::request_construction;
  const bool optimizer_cap_exceeded_terminal =
      failure_references_diagnostic_code(
          bundle, "c27.shared_optimizer_ledger_cap_exceeded");
  const bool optimizer_search_state_cap_exceeded_terminal =
      failure_references_diagnostic_code(
          bundle, "c27.shared_optimizer_search_state_cap_exceeded");
  const auto activation_capabilities =
      plan.provider().framework_activation_capabilities();
  const bool registered_direct_optimizer_route =
      plan.metric_plans().size() == 1U &&
      plan.metric_plans().front().route_kind() ==
          BackendRouteKindV1::exact_direct &&
      activation_capabilities.has_value() &&
      activation_capabilities->supplies_direct_factor &&
      activation_capabilities
          ->maximum_direct_factor_optimizer_calls.has_value();
  const bool direct_factor_bound_terminal =
      bundle.failure().has_value() &&
      bundle.failure()->stage == ResultFailureStageV1::v0_audit &&
      bundle.failure()->code ==
          "c17.direct_factor_optimizer_bound_exceeded" &&
      failure_references_diagnostic_code(
          bundle, "c17.direct_factor_optimizer_bound_exceeded");
  const bool optimizer_report_mismatch_terminal = [&]() {
    if (!bundle.failure().has_value() ||
        bundle.failure()->stage !=
            ResultFailureStageV1::build_contract_validation ||
        (bundle.failure()->code !=
             "c27.inline_optimizer_usage_forbidden" &&
         bundle.failure()->code !=
             "c27.in_process_optimizer_calls_underreported" &&
         bundle.failure()->code !=
             "c27.in_process_optimizer_calls_overreported")) {
      return false;
    }
    return failure_references_diagnostic_code(bundle,
                                               bundle.failure()->code);
  }();
  const bool optimizer_search_state_report_mismatch_terminal = [&]() {
    if (!bundle.failure().has_value() ||
        bundle.failure()->stage !=
            ResultFailureStageV1::build_contract_validation ||
        (bundle.failure()->code !=
             "c27.inline_optimizer_usage_forbidden" &&
         bundle.failure()->code !=
             "c27.in_process_optimizer_calls_underreported" &&
         bundle.failure()->code !=
             "c27.in_process_optimizer_calls_overreported" &&
         bundle.failure()->code !=
             "c27.in_process_optimizer_search_states_underreported" &&
         bundle.failure()->code !=
             "c27.in_process_optimizer_search_states_overreported")) {
      return false;
    }
    return failure_references_diagnostic_code(bundle,
                                               bundle.failure()->code);
  }();
  std::optional<BigNat> direct_optimizer_calls_used;
  if (!optimizer_cap.has_value()) {
    if (optimizer != nullptr) {
      return Result<void>::failure(result_error(
          "c27.result_optimizer_budget_unbounded_row",
          "an unbounded execution-wide optimizer ledger cannot be encoded as a finite result budget row"));
    }
  } else if (optimizer == nullptr) {
    if (!pre_optimizer_terminal && !optimizer_cap_exceeded_terminal) {
      return Result<void>::failure(result_error(
          "c27.result_optimizer_budget_missing",
          "a finite frozen optimizer cap requires the execution-wide ledger row on every post-construction terminal path"));
    }
  } else if (optimizer->applicability !=
                 ResultBudgetApplicabilityV1::applicable ||
             optimizer->granted != optimizer_cap ||
             optimizer->unit != "calls") {
    return Result<void>::failure(result_error(
        "c27.result_optimizer_budget_binding_mismatch",
        "the execution-wide optimizer row does not match the frozen call cap"));
  } else if (report != nullptr && !optimizer_report_mismatch_terminal) {
    const bool mismatch = registered_direct_optimizer_route
                              ? optimizer->used <
                                    report->optimizer_calls.used
                              : optimizer->used !=
                                    report->optimizer_calls.used;
    if (mismatch) {
      return Result<void>::failure(result_error(
          registered_direct_optimizer_route
              ? "c27.result_optimizer_budget_underreported"
              : "c27.result_optimizer_budget_mismatch",
          registered_direct_optimizer_route
              ? "the execution-wide optimizer ledger reports fewer committed calls than C15's validated construction counter"
              : "a plan with no registered downstream optimizer route must report exactly C15's validated construction call count"));
    }
    if (registered_direct_optimizer_route) {
      auto downstream_calls = checked_subtract(
          optimizer->used, report->optimizer_calls.used);
      if (!downstream_calls) {
        return Result<void>::failure(result_error(
            "c27.result_direct_optimizer_call_accounting_invalid",
            "the execution-wide optimizer total cannot be partitioned into construction and registered direct-factor calls"));
      }
      const BigNat& registered_maximum =
          *activation_capabilities
               ->maximum_direct_factor_optimizer_calls;
      if (downstream_calls.value() > registered_maximum &&
          !direct_factor_bound_terminal) {
        return Result<void>::failure(result_error(
            "c27.result_direct_optimizer_call_bound_exceeded",
            "reported downstream optimizer calls exceed the frozen registered direct-factor bound"));
      }
      direct_optimizer_calls_used =
          std::move(downstream_calls).value();
    }
  }
  if (!optimizer_search_state_cap.has_value()) {
    if (optimizer_search_states != nullptr) {
      return Result<void>::failure(result_error(
          "c27.result_optimizer_search_state_budget_unbounded_row",
          "an unbounded execution-wide recursive search-state ledger cannot be encoded as a finite result budget row"));
    }
  } else if (optimizer_search_states == nullptr) {
    if (!pre_optimizer_terminal &&
        !optimizer_cap_exceeded_terminal &&
        !optimizer_search_state_cap_exceeded_terminal) {
      return Result<void>::failure(result_error(
          "c27.result_optimizer_search_state_budget_missing",
          "a finite frozen recursive search-state cap requires the execution-wide ledger row on every post-construction terminal path"));
    }
  } else if (optimizer_search_states->applicability !=
                 ResultBudgetApplicabilityV1::applicable ||
             optimizer_search_states->granted !=
                 optimizer_search_state_cap ||
             optimizer_search_states->unit != "states") {
    return Result<void>::failure(result_error(
        "c27.result_optimizer_search_state_budget_binding_mismatch",
        "the execution-wide recursive search-state row does not match the frozen cap"));
  } else if (report != nullptr &&
             !optimizer_search_state_report_mismatch_terminal) {
    const bool mismatch =
        registered_direct_optimizer_route
            ? optimizer_search_states->used <
                  report->optimizer_search_states.used
            : optimizer_search_states->used !=
                  report->optimizer_search_states.used;
    if (mismatch) {
      return Result<void>::failure(result_error(
          registered_direct_optimizer_route
              ? "c27.result_optimizer_search_state_budget_underreported"
              : "c27.result_optimizer_search_state_budget_mismatch",
          registered_direct_optimizer_route
              ? "the execution-wide recursive search-state ledger reports fewer expansions than C15's validated construction counter"
              : "a plan with no registered downstream optimizer route must report exactly C15's validated construction recursive-state count"));
    }
    if (registered_direct_optimizer_route &&
        direct_optimizer_calls_used.has_value() &&
        plan.resolved_instance()
            .optimizer_budget()
            .effective_per_call.has_value()) {
      auto downstream_states = checked_subtract(
          optimizer_search_states->used,
          report->optimizer_search_states.used);
      if (!downstream_states) {
        return Result<void>::failure(result_error(
            "c27.result_direct_optimizer_search_state_accounting_invalid",
            "the execution-wide recursive-state total cannot be partitioned into construction and registered direct-factor work"));
      }
      try {
        const BigNat maximum_downstream_states =
            *direct_optimizer_calls_used *
            *plan.resolved_instance()
                 .optimizer_budget()
                 .effective_per_call;
        if (downstream_states.value() > maximum_downstream_states) {
          return Result<void>::failure(result_error(
              "c27.result_direct_optimizer_search_state_bound_exceeded",
              "reported downstream recursive search states exceed the exact per-call bound for the reported direct-factor calls"));
        }
      } catch (const std::exception&) {
        return Result<void>::failure(result_error(
            "c27.result_direct_optimizer_search_state_bound_failure",
            "computing the exact direct-factor recursive search-state bound failed"));
      } catch (...) {
        return Result<void>::failure(result_error(
            "c27.result_direct_optimizer_search_state_bound_failure",
            "computing the exact direct-factor recursive search-state bound raised an unknown exception"));
      }
    }
  }

  for (const ResultBudgetUsageV1& row : execution_rows) {
    const bool construction_row = std::ranges::any_of(
        construction_rows, [&](const ConstructionExpectationV1& expected) {
          return row.name == expected.name;
        });
    if (!construction_row &&
        row.name != "execution.shared_optimizer_calls" &&
        row.name != "execution.shared_optimizer_search_states") {
      return Result<void>::failure(result_error(
          "c27.result_execution_budget_unknown",
          "analysis output contains an execution budget row outside the closed C27 accounting plan"));
    }
  }

  if (payload_present && report == nullptr) {
    return Result<void>::failure(result_error(
        "c27.result_built_report_missing",
        "a Built payload cannot be retained without its validated C15 common build report"));
  }
  if ((!backend_rows.empty() ||
       std::ranges::any_of(bundle.replay_streams(), [](const auto& stream) {
         return std::holds_alternative<ResultRuntimeReplayStreamV1>(stream);
       })) &&
      !seal_present) {
    return Result<void>::failure(result_error(
        "c27.result_backend_accounting_without_seal",
        "backend budget or runtime replay accounting cannot precede the audited execution seal"));
  }

  std::vector<ReplayStageCountV1> expected_runtime_streams;
  std::size_t sampling_metric_count = 0U;
  BigNat metric_draws_used{0U};
  for (const PlannedMetricV1& metric : plan.metric_plans()) {
    const BigNat* cap = sampling_draw_cap(metric);
    if (cap == nullptr) continue;
    ++sampling_metric_count;
    const std::string name =
        "backend." + metric_request_header(metric.request()).metric_id +
        ".conditional_generator_draws";
    const ResultBudgetUsageV1* row = find_budget_row(backend_rows, name);
    if (bundle.status() == ResultStatusV1::success && row == nullptr) {
      return Result<void>::failure(result_error(
          "c27.result_sampling_budget_missing",
          "a successful sampling route lacks its exact metric draw-budget row"));
    }
    if (row == nullptr) continue;
    if (row->applicability != ResultBudgetApplicabilityV1::applicable ||
        row->granted != *cap || row->unit != "draws" ||
        (bundle.status() == ResultStatusV1::success &&
         row->used != *cap)) {
      return Result<void>::failure(result_error(
          "c27.result_sampling_budget_binding_mismatch",
          "a sampling budget row does not match the frozen metric draw cap or successful fixed-replication use"));
    }
    const RngAddressTemplateV1* address =
        rng_template_for_metric(plan, metric);
    if (address == nullptr) {
      return Result<void>::failure(result_error(
          "c27.result_sampling_rng_template_missing",
          "a reported sampling budget has no unique frozen RNG address template"));
    }
    add_stage_count(expected_runtime_streams, address->stage, row->used);
    metric_draws_used += row->used;
  }
  if (metric_draws_used > plan.work_bounds().metric_generator_draws) {
    return Result<void>::failure(result_error(
        "c27.result_sampling_budget_total_exceeded",
        "reported metric generator calls exceed the frozen aggregate metric draw bound"));
  }
  if (plan.work_bounds().total_generator_draws.has_value()) {
    BigNat total_used = metric_draws_used;
    if (report != nullptr) {
      total_used += report->configured_generator_draws.used;
    }
    if (total_used > *plan.work_bounds().total_generator_draws) {
      return Result<void>::failure(result_error(
          "c27.result_generator_budget_total_exceeded",
          "reported construction and metric generator calls exceed the frozen total draw bound"));
    }
  }

  const ResultBudgetUsageV1* nonsampling =
      find_budget_row(backend_rows, "backend.conditional_generator_draws");
  if (sampling_metric_count != 0U && nonsampling != nullptr) {
    return Result<void>::failure(result_error(
        "c27.result_nonsampling_budget_mismatch",
        "the not-applicable generator-draw row is invalid for a plan containing a sampling route"));
  }
  if (nonsampling != nullptr &&
      (nonsampling->applicability !=
           ResultBudgetApplicabilityV1::not_applicable ||
       nonsampling->granted.has_value() || !nonsampling->used.is_zero() ||
       nonsampling->unit != "draws")) {
    return Result<void>::failure(result_error(
        "c27.result_nonsampling_budget_mismatch",
        "the non-sampling generator-draw row must be explicitly not applicable with zero use"));
  }
  if (sampling_metric_count == 0U &&
      bundle.status() == ResultStatusV1::success && nonsampling == nullptr) {
    return Result<void>::failure(result_error(
        "c27.result_nonsampling_budget_missing",
        "a successful non-sampling plan requires its explicit not-applicable generator-draw row"));
  }

  const std::vector<StoppedBudgetExpectationV1> expected_stopped_rows =
      expected_stopped_budget_rows(plan);
  for (std::size_t left = 0U; left < expected_stopped_rows.size(); ++left) {
    for (std::size_t right = left + 1U;
         right < expected_stopped_rows.size(); ++right) {
      if (expected_stopped_rows[left].name ==
          expected_stopped_rows[right].name) {
        return Result<void>::failure(result_error(
            "c27.result_stopped_budget_plan_collision",
            "the frozen plan maps distinct stopped-backend work to one result budget name"));
      }
    }
  }
  for (std::size_t index = 0U; index < expected_stopped_rows.size();
       ++index) {
    const StoppedBudgetExpectationV1& representative =
        expected_stopped_rows[index];
    const bool prefix_already_checked = std::any_of(
        expected_stopped_rows.begin(),
        expected_stopped_rows.begin() + static_cast<std::ptrdiff_t>(index),
        [&](const StoppedBudgetExpectationV1& prior) {
          return prior.prefix == representative.prefix;
        });
    if (prefix_already_checked) continue;
    const bool any_group_row = std::any_of(
        expected_stopped_rows.begin(), expected_stopped_rows.end(),
        [&](const StoppedBudgetExpectationV1& expected) {
          return expected.prefix == representative.prefix &&
                 find_budget_row(backend_rows, expected.name) != nullptr;
        });
    if (bundle.status() != ResultStatusV1::success && !any_group_row) {
      continue;
    }
    for (const StoppedBudgetExpectationV1& expected :
         expected_stopped_rows) {
      if (expected.prefix != representative.prefix) continue;
      if (find_budget_row(backend_rows, expected.name) == nullptr) {
        return Result<void>::failure(result_error(
            bundle.status() == ResultStatusV1::success
                ? "c27.result_stopped_budget_missing"
                : "c27.result_stopped_budget_group_incomplete",
            bundle.status() == ResultStatusV1::success
                ? "a successful stopped-backend route lacks an authored finite budget row required by its frozen execution group"
                : "a terminal stopped-backend budget group is only partially present; its authored rows must be retained atomically"));
      }
    }
  }

  for (const ResultBudgetUsageV1& row : backend_rows) {
    if (row.name == "backend.conditional_generator_draws") continue;
    bool sampling_row = false;
    for (const PlannedMetricV1& metric : plan.metric_plans()) {
      if (sampling_draw_cap(metric) == nullptr) continue;
      const std::string expected =
          "backend." + metric_request_header(metric.request()).metric_id +
          ".conditional_generator_draws";
      if (row.name == expected) {
        sampling_row = true;
        break;
      }
    }
    if (sampling_row) continue;
    const auto stopped = std::ranges::find_if(
        expected_stopped_rows,
        [&](const StoppedBudgetExpectationV1& expected) {
          return expected.name == row.name;
        });
    if (stopped != expected_stopped_rows.end()) {
      if (!matches_stopped_budget_grant(plan, row, stopped->suffix)) {
        return Result<void>::failure(result_error(
            "c27.result_stopped_budget_binding_mismatch",
            "a stopped-backend budget row does not match its exact frozen route, authored grant, or unit"));
      }
      continue;
    }
    return Result<void>::failure(result_error(
        "c27.result_backend_budget_unknown",
        "analysis output contains a backend budget row not authorized by a frozen metric route and authored grant"));
  }

  std::vector<ReplayStageCountV1> actual_runtime_streams;
  BigNat actual_construction_draws{0U};
  bool replay_unique = true;
  for (std::size_t left = 0U;
       replay_unique && left < bundle.replay_streams().size(); ++left) {
    const ResultReplayStreamV1& stream = bundle.replay_streams()[left];
    if (!valid_replay_stream(stream)) {
      return Result<void>::failure(result_error(
          "c27.result_replay_plan_mismatch",
          "analysis replay provenance uses a stage outside its construction or runtime domain"));
    }
    for (std::size_t right = left + 1U;
         right < bundle.replay_streams().size(); ++right) {
      if (same_replay_identity(stream, bundle.replay_streams()[right])) {
        replay_unique = false;
        break;
      }
    }
    if (const auto* construction_stream =
            std::get_if<ResultConstructionReplayStreamV1>(&stream)) {
      if (!payload_present || report == nullptr ||
          !construction_stage_tag(construction_stream->stage_tag)) {
        return Result<void>::failure(result_error(
            "c27.result_construction_replay_binding_mismatch",
            "construction replay provenance is valid only for a C15-validated Built artifact"));
      }
      actual_construction_draws += construction_stream->draws;
      continue;
    }
    const auto& runtime_stream =
        std::get<ResultRuntimeReplayStreamV1>(stream);
    const bool planned_stage = std::ranges::any_of(
        plan.rng_address_templates(), [&](const RngAddressTemplateV1& item) {
          return item.stage == runtime_stream.stage_tag;
        });
    if (!planned_stage) {
      return Result<void>::failure(result_error(
          "c27.result_runtime_replay_stage_mismatch",
          "a runtime replay stream does not match any frozen sampling RNG stage"));
    }
    add_stage_count(actual_runtime_streams, runtime_stream.stage_tag,
                    BigNat{1U});
  }
  if (!replay_unique) {
    return Result<void>::failure(result_error(
        "c27.result_replay_identity_duplicate",
        "analysis replay provenance contains a duplicate typed stream identity"));
  }
  if (payload_present && report != nullptr &&
      actual_construction_draws != report->configured_generator_draws.used) {
    return Result<void>::failure(result_error(
        "c27.result_construction_replay_count_mismatch",
        "construction replay draw counts do not equal C15's validated configured-generator counter"));
  }
  for (const RngAddressTemplateV1& address :
       plan.rng_address_templates()) {
    if (stage_count(actual_runtime_streams, address.stage) !=
        stage_count(expected_runtime_streams, address.stage)) {
      return Result<void>::failure(result_error(
          "c27.result_runtime_replay_count_mismatch",
          "runtime replay stream cardinality does not equal consumed generator calls for the matching frozen RNG stage"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool valid_claim_state(
    const CertificateClaimStateV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(
             CertificateClaimStateV1::not_established);
}

[[nodiscard]] bool valid_bound_status(
    const BoundValueStatusV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(BoundValueStatusV1::unresolved);
}

[[nodiscard]] bool valid_claim_kind(
    const CertificateClaimKindV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(CertificateClaimKindV1::premise);
}

[[nodiscard]] bool valid_status(const ResultStatusV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(ResultStatusV1::failed);
}

[[nodiscard]] bool valid_failure_stage(
    const ResultFailureStageV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(ResultFailureStageV1::result_assembly);
}

[[nodiscard]] Result<void> validate_failure_stage_provenance(
    const std::optional<ResultFailureV1>& failure,
    const bool payload_present, const bool seal_present,
    const std::span<const ResultCertificateV1> certificates) {
  if (!failure.has_value()) {
    return Result<void>::success();
  }

  const bool certificates_present = !certificates.empty();
  const auto invalid = [] {
    return Result<void>::failure(result_error(
        "c27.result_failure_stage_provenance_invalid",
        "failure provenance must contain exactly the payload, execution seal, and certificates minted before its recorded stage"));
  };
  switch (failure->stage) {
    case ResultFailureStageV1::request_construction:
    case ResultFailureStageV1::producer_execution:
    case ResultFailureStageV1::wire_parse:
    case ResultFailureStageV1::build_contract_validation:
      return !payload_present && !seal_present && !certificates_present
                 ? Result<void>::success()
                 : invalid();
    case ResultFailureStageV1::payload_adaptation:
    case ResultFailureStageV1::plug_binding:
    case ResultFailureStageV1::v0_audit:
      return payload_present && !seal_present && !certificates_present
                 ? Result<void>::success()
                 : invalid();
    case ResultFailureStageV1::initial_law:
    case ResultFailureStageV1::backend:
      return payload_present && seal_present ? Result<void>::success()
                                             : invalid();
    case ResultFailureStageV1::certificate:
      return payload_present && seal_present && !certificates_present
                 ? Result<void>::success()
                 : invalid();
    case ResultFailureStageV1::result_assembly:
      return Result<void>::failure(result_error(
          "c27.result_assembly_stage_not_publishable",
          "result assembly failures are outer Result errors and cannot be published inside an AnalysisBundle"));
  }
  return invalid();
}

[[nodiscard]] bool valid_diagnostic_kind(
    const ResultDiagnosticKindV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(ResultDiagnosticKindV1::execution);
}

[[nodiscard]] bool valid_diagnostic_category(
    const DiagnosticCategory value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(DiagnosticCategory::information);
}

[[nodiscard]] bool valid_solver_regime(
    const MetricSolverRegimeV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(MetricSolverRegimeV1::direct);
}

[[nodiscard]] bool valid_construction_method(
    const ConstructionMethodV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(ConstructionMethodV1::precomputed);
}

[[nodiscard]] bool valid_producer_mode(const ProducerModeV1 value) noexcept {
  return static_cast<std::uint8_t>(value) <=
         static_cast<std::uint8_t>(
             ProducerModeV1::local_executable_builder);
}

[[nodiscard]] bool valid_metric_value(const ResultMetricValueV1& value) {
  return std::visit(
      [](const auto& alternative) {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::same_as<Alternative,
                                   PortableScientificScalar> ||
                      std::same_as<Alternative, PositiveInfinityV1>) {
          return true;
        } else if constexpr (std::same_as<Alternative,
                                          ResultScalarVectorV1>) {
          return !alternative.values.empty();
        } else if constexpr (std::same_as<Alternative, ResultTableV1>) {
          if (alternative.coordinate_names.empty()) {
            return false;
          }
          for (const ResultTableEntryV1& entry : alternative.entries) {
            if (entry.coordinates.size() !=
                alternative.coordinate_names.size()) {
              return false;
            }
          }
          return true;
        } else if constexpr (std::same_as<Alternative,
                                          ResultProbabilityLawV1>) {
          if (alternative.coordinate_names.empty() ||
              !scalar_in_closed_unit_interval(alternative.defective_mass)) {
            return false;
          }
          ExactRational total = exact_scalar(alternative.defective_mass);
          for (const ResultProbabilityAtomV1& atom : alternative.atoms) {
            if (atom.outcome.size() != alternative.coordinate_names.size() ||
                !scalar_in_closed_unit_interval(atom.mass)) {
              return false;
            }
            total = total + exact_scalar(atom.mass);
          }
          return alternative.defective_mass_proven &&
                 total == ExactRational::one();
        } else {
          return !alternative.codec.id.empty();
        }
      },
      value);
}

[[nodiscard]] const ResultMetricHeaderV1& result_metric_header(
    const ResultMetricV1& metric) noexcept {
  if (const auto* established =
          std::get_if<EstablishedResultMetricV1>(&metric)) {
    return established->header;
  }
  return std::get<UnavailableResultMetricV1>(metric).header;
}

[[nodiscard]] Result<void> validate_result_data(
    const ResultArtifactDataV1& value) {
  if (!valid_status(value.status)) {
    return Result<void>::failure(result_error(
        "c27.result_status_invalid", "result status is outside result-v1"));
  }
  if (value.unavailable_diagnostics.has_value() &&
      (value.status != ResultStatusV1::unavailable ||
       !valid_unavailable_diagnostics(*value.unavailable_diagnostics))) {
    return Result<void>::failure(result_error(
        "c27.result_unavailable_diagnostics_invalid",
        "K-wide unavailable diagnostics must be closed, ordered, and bound to an Unavailable result"));
  }
  if (value.config_name.empty() || value.worker_count == 0U) {
    return Result<void>::failure(result_error(
        "c27.result_publication_context_invalid",
        "result publication requires a configuration name and at least one worker"));
  }
  if (value.wall_clock_times.end_to_end < std::chrono::nanoseconds::zero() ||
      value.wall_clock_times.sampler < std::chrono::nanoseconds::zero() ||
      value.wall_clock_times.framework < std::chrono::nanoseconds::zero() ||
      value.wall_clock_times.sampler + value.wall_clock_times.framework !=
          value.wall_clock_times.end_to_end) {
    return Result<void>::failure(result_error(
        "c27.result_wall_clock_invalid",
        "wall-clock durations must be nonnegative and partition end-to-end time"));
  }
  if (value.response_curve.has_value()) {
    const ResultResponseCurveV1& curve = *value.response_curve;
    if (value.status != ResultStatusV1::success ||
        std::ranges::find(value.analysis.ordered_targets, curve.target) ==
            value.analysis.ordered_targets.end()) {
      return Result<void>::failure(result_error(
          "c27.result_response_curve_binding_invalid",
          "the response curve must be bound to a selected target of a successful analysis"));
    }
    const std::array<const PortableScientificScalar*, 4U> probabilities{
        &curve.backlog_zero, &curve.backlog_one, &curve.backlog_two,
        &curve.backlog_at_least_three};
    for (const PortableScientificScalar* probability : probabilities) {
      auto bounded = validate_in_closed_interval(
          *probability, ExactRational::zero(), ExactRational::one());
      if (!bounded) {
        return Result<void>::failure(result_error(
            "c27.result_response_curve_invalid",
            "response-curve service probabilities must lie in [0,1]"));
      }
    }
  }
  if (value.status == ResultStatusV1::success &&
      value.surrogate.plug_kind ==
          std::optional<std::string>{"three_bin_scalar_response_v1"} &&
      !value.response_curve.has_value()) {
    return Result<void>::failure(result_error(
        "c27.result_response_curve_missing",
        "a successful scalar-response analysis must publish its four response regions"));
  }
  if (value.model.schema_version != "3.0.0" ||
      value.analysis.schema_version != "1.0.0" ||
      value.model.fingerprint != value.input_fingerprints.model ||
      value.analysis.fingerprint != value.input_fingerprints.analysis) {
    return Result<void>::failure(result_error(
        "c27.result_input_binding_mismatch",
        "result model and analysis provenance must copy the resolved input fingerprints"));
  }
  if (value.build.core.empty() || value.build.rng.empty() ||
      value.build.interfaces.empty()) {
    return Result<void>::failure(result_error(
        "c27.result_build_identity_missing",
        "result build provenance must contain core, RNG, and interface identities"));
  }
  if (value.execution.build_request_identity.has_value()) {
    const ResultBuildRequestIdentityV1& identity =
        *value.execution.build_request_identity;
    if (identity.build_seed.master_seed() != value.execution.actual_seed ||
        !identity.build_seed.is_bound_to(identity.build_identity_digest)) {
      return Result<void>::failure(result_error(
          "c27.result_seed_binding_mismatch",
          "the recorded build seed is not bound to the recorded master seed and build identity"));
    }
  }
  if (value.surrogate.provider.provider_id.empty() ||
      value.surrogate.provider.provider_version.empty() ||
      !valid_construction_method(value.surrogate.construction_method) ||
      !valid_producer_mode(value.surrogate.producer_mode) ||
      !valid_solver_regime(value.analysis.solver_regime) ||
      value.surrogate.payload_digest.has_value() !=
          value.surrogate.plug_kind.has_value() ||
      (value.surrogate.plug_kind.has_value() &&
       value.surrogate.plug_kind->empty())) {
    return Result<void>::failure(result_error(
        "c27.result_surrogate_provenance_invalid",
        "surrogate provenance is incomplete or internally inconsistent"));
  }
  if ((value.execution.execution_seal_digest.has_value() &&
       !value.surrogate.payload_digest.has_value()) ||
      (value.status == ResultStatusV1::success &&
       !value.execution.execution_seal_digest.has_value())) {
    return Result<void>::failure(result_error(
        "c27.result_execution_seal_invalid",
        "an execution seal requires a bound payload and every successful result requires the validated seal"));
  }
  if (value.analysis.metric_ids.empty() ||
      value.analysis.ordered_targets.empty() ||
      !unique_by(value.analysis.metric_ids,
                 [](const std::string& id) { return id; })) {
    return Result<void>::failure(result_error(
        "c27.result_analysis_identity_invalid",
        "analysis provenance requires nonempty unique metric and target identities"));
  }

  if ((value.status == ResultStatusV1::failed) !=
      value.failure.has_value()) {
    return Result<void>::failure(result_error(
        "c27.result_failure_shape_invalid",
        "failure is present exactly for a failed result"));
  }
  if (value.failure.has_value() &&
      (!valid_failure_stage(value.failure->stage) ||
       value.failure->code.empty() ||
       value.failure->diagnostic_refs.empty())) {
    return Result<void>::failure(result_error(
        "c27.result_failure_shape_invalid",
        "a failed result requires a closed stage, code, and diagnostic references"));
  }
  const bool request_construction_failure =
      value.failure.has_value() &&
      value.failure->stage == ResultFailureStageV1::request_construction;
  if (value.execution.build_request_identity.has_value() ==
      request_construction_failure) {
    return Result<void>::failure(result_error(
        "c27.result_build_request_identity_invalid",
        "build request identities are absent exactly when request construction failed"));
  }

  if (!unique_by(value.diagnostics, [](const ResultDiagnosticV1& item) {
        return item.diagnostic_id;
      })) {
    return Result<void>::failure(result_error(
        "c27.result_duplicate_diagnostic",
        "diagnostic identifiers must be unique"));
  }
  std::set<std::string> diagnostic_ids;
  for (const ResultDiagnosticV1& diagnostic : value.diagnostics) {
    bool product_shape_valid = true;
    if (diagnostic.product.has_value()) {
      const ResultProductBindingV1& product = *diagnostic.product;
      const auto product_kind =
          static_cast<std::uint8_t>(product.product_kind);
      const bool response_product = product_kind <= 1U || product_kind == 4U;
      const bool raw_product = product_kind == 0U;
      if (response_product) {
        product_shape_valid = product.response_target.has_value() &&
                              product.ordered_construction_targets.empty() &&
                              product.response_bin.has_value() &&
                              valid_response_bin(*product.response_bin) &&
                              (product.raw_value_form.has_value() ==
                               raw_product) &&
                              (!product.raw_value_form.has_value() ||
                               valid_raw_value_form(
                                   *product.raw_value_form));
      } else {
        product_shape_valid = !product.response_target.has_value() &&
                              !product.ordered_construction_targets.empty() &&
                              !product.response_bin.has_value() &&
                              !product.raw_value_form.has_value() &&
                              !product.law_identity.has_value();
      }
      if (product.provider.provider_id.empty() ||
          product.provider.provider_version.empty() ||
          (product.law_identity.has_value() && !response_product) ||
          (product.law_identity.has_value() && raw_product &&
           product.raw_value_form !=
               ResponseProductValueFormV1::exact_point)) {
        product_shape_valid = false;
      }
    }
    if (diagnostic.diagnostic_id.empty() || diagnostic.code.empty() ||
        diagnostic.message.empty() ||
        !valid_diagnostic_category(diagnostic.category) ||
        !valid_diagnostic_kind(diagnostic.kind) ||
        (diagnostic.kind == ResultDiagnosticKindV1::component &&
         !diagnostic.component_scope.has_value()) ||
        (diagnostic.component_scope.has_value() &&
         !valid_component_scope(*diagnostic.component_scope)) ||
        (diagnostic.product.has_value() &&
         (!valid_product_kind(diagnostic.product->product_kind) ||
          !product_shape_valid)) ||
        (diagnostic.value.has_value() &&
         (!valid_claim_state(diagnostic.value->claim_state) ||
          !valid_bound_status(diagnostic.value->value_status)))) {
      return Result<void>::failure(result_error(
          "c27.result_diagnostic_invalid",
          "a diagnostic has an invalid identity, scope, kind, or value status"));
    }
    diagnostic_ids.insert(diagnostic.diagnostic_id);
  }
  const auto refs_exist = [&diagnostic_ids](
                              const std::vector<std::string>& refs) {
    return std::all_of(refs.begin(), refs.end(),
                       [&diagnostic_ids](const std::string& ref) {
                         return diagnostic_ids.contains(ref);
                       });
  };
  const auto refs_include_code = [&value](
                                     const std::vector<std::string>& refs,
                                     const std::string& code) {
    return std::any_of(
        refs.begin(), refs.end(), [&value, &code](const std::string& ref) {
          const auto diagnostic = std::find_if(
              value.diagnostics.begin(), value.diagnostics.end(),
              [&ref](const ResultDiagnosticV1& item) {
                return item.diagnostic_id == ref;
              });
          return diagnostic != value.diagnostics.end() &&
                 diagnostic->code == code;
        });
  };
  if (value.failure.has_value() &&
      !refs_exist(value.failure->diagnostic_refs)) {
    return Result<void>::failure(result_error(
        "c27.result_diagnostic_reference_missing",
        "the failure object contains a dangling diagnostic reference"));
  }
  if (value.failure.has_value() &&
      !refs_include_code(value.failure->diagnostic_refs,
                         value.failure->code)) {
    return Result<void>::failure(result_error(
        "c27.result_failure_diagnostic_mismatch",
        "the failure object does not reference diagnostic evidence carrying its failure code"));
  }

  if (value.status == ResultStatusV1::failed) {
    if (!value.metrics.empty()) {
      return Result<void>::failure(result_error(
          "c27.result_partial_failure",
          "a failed result may not retain partially computed metrics"));
    }
  } else if (value.metrics.size() != value.analysis.metric_ids.size()) {
    return Result<void>::failure(result_error(
        "c27.result_metric_set_mismatch",
        "success and unavailable results require every requested metric exactly once"));
  }

  for (std::size_t index = 0U; index < value.metrics.size(); ++index) {
    const ResultMetricHeaderV1& header =
        result_metric_header(value.metrics[index]);
    if (header.metric_id != value.analysis.metric_ids[index] ||
        header.metric_id.empty() || !valid_metric_kind(header.kind) ||
        !valid_metric_scope(header.scientific_scope) ||
        header.ordered_targets.empty() || header.units.empty() ||
        header.convention.empty() || !refs_exist(header.error_refs) ||
        !refs_exist(header.residual_refs)) {
      return Result<void>::failure(result_error(
          "c27.result_metric_binding_mismatch",
          "a result metric does not match the ordered analysis identity or diagnostic ledger"));
    }
    const bool established =
        std::holds_alternative<EstablishedResultMetricV1>(
            value.metrics[index]);
    if (value.status == ResultStatusV1::success && !established) {
      return Result<void>::failure(result_error(
          "c27.result_success_not_established",
          "every metric in a successful result must be established"));
    }
    if (value.status == ResultStatusV1::unavailable && established) {
      return Result<void>::failure(result_error(
          "c27.result_unavailable_has_value",
          "an unavailable result may not contain a numeric metric value"));
    }
    if (established) {
      const auto& metric =
          std::get<EstablishedResultMetricV1>(value.metrics[index]);
      if (!valid_metric_value(metric.value)) {
        return Result<void>::failure(result_error(
            "c27.result_metric_value_invalid",
            "an established metric value violates its closed result-v1 representation"));
      }
    } else {
      const auto& metric =
          std::get<UnavailableResultMetricV1>(value.metrics[index]);
      if (metric.reason_code.empty() || metric.diagnostic_refs.empty() ||
          !refs_exist(metric.diagnostic_refs) ||
          !refs_include_code(metric.diagnostic_refs, metric.reason_code)) {
        return Result<void>::failure(result_error(
            "c27.result_metric_unavailability_invalid",
            "an unavailable metric requires a reason and matching diagnostic evidence"));
      }
    }
  }

  if (!unique_by(value.certificates, [](const ResultCertificateV1& item) {
        return item.certificate_id;
      })) {
    return Result<void>::failure(result_error(
        "c27.result_duplicate_certificate",
        "certificate identifiers must be unique"));
  }
  for (const ResultCertificateV1& certificate : value.certificates) {
    if (certificate.certificate_id.empty() ||
        !valid_claim_kind(certificate.kind) ||
        !valid_claim_state(certificate.claim_state) ||
        !refs_exist(certificate.diagnostic_refs)) {
      return Result<void>::failure(result_error(
          "c27.result_certificate_invalid",
          "a result certificate has an invalid identity, claim, or diagnostic reference"));
    }
  }

  const auto valid_budgets = [](const std::vector<ResultBudgetUsageV1>& rows) {
    if (!unique_by(rows, [](const ResultBudgetUsageV1& row) {
          return row.name;
        })) {
      return false;
    }
    return std::all_of(rows.begin(), rows.end(),
                       [](const ResultBudgetUsageV1& row) {
                         if (row.name.empty() || row.unit.empty()) {
                           return false;
                         }
                         if (row.applicability ==
                             ResultBudgetApplicabilityV1::not_applicable) {
                           return !row.granted.has_value() &&
                                  row.used.is_zero();
                         }
                         return row.applicability ==
                                    ResultBudgetApplicabilityV1::applicable &&
                                row.granted.has_value() &&
                                row.used <= *row.granted;
                       });
  };
  if (!valid_budgets(value.execution.budget_usage) ||
      !valid_budgets(value.budgets_used)) {
    return Result<void>::failure(result_error(
        "c27.result_budget_invalid",
        "budget usage records must be unique, scoped, and internally consistent"));
  }
  const auto shared_optimizer_calls = std::find_if(
      value.execution.budget_usage.begin(),
      value.execution.budget_usage.end(), [](const auto& row) {
        return row.name == "execution.shared_optimizer_calls";
      });
  const auto shared_optimizer_search_states = std::find_if(
      value.execution.budget_usage.begin(),
      value.execution.budget_usage.end(), [](const auto& row) {
        return row.name ==
               "execution.shared_optimizer_search_states";
      });
  if ((shared_optimizer_calls != value.execution.budget_usage.end() &&
       (shared_optimizer_calls->applicability !=
            ResultBudgetApplicabilityV1::applicable ||
        shared_optimizer_calls->unit != "calls")) ||
      (shared_optimizer_search_states !=
           value.execution.budget_usage.end() &&
       (shared_optimizer_search_states->applicability !=
            ResultBudgetApplicabilityV1::applicable ||
        shared_optimizer_search_states->unit != "states" ||
        shared_optimizer_calls == value.execution.budget_usage.end()))) {
    return Result<void>::failure(result_error(
        "c27.result_optimizer_accounting_invalid",
        "finite shared optimizer rows require their closed units, and recursive search-state accounting requires the matching call ledger"));
  }
  bool replay_identities_unique = true;
  for (std::size_t left = 0U;
       replay_identities_unique &&
       left < value.execution.replay_streams.size();
       ++left) {
    for (std::size_t right = left + 1U;
         right < value.execution.replay_streams.size(); ++right) {
      if (same_replay_identity(value.execution.replay_streams[left],
                               value.execution.replay_streams[right])) {
        replay_identities_unique = false;
        break;
      }
    }
  }
  if (!replay_identities_unique ||
      !std::all_of(value.execution.replay_streams.begin(),
                   value.execution.replay_streams.end(),
                   valid_replay_stream)) {
    return Result<void>::failure(result_error(
        "c27.result_replay_invalid",
        "replay streams require a closed construction-or-runtime shape, the matching stage domain, and a unique typed identity"));
  }

  const bool payload_present = value.surrogate.payload_digest.has_value();
  const bool seal_present =
      value.execution.execution_seal_digest.has_value();
  bool construction_replay_present = false;
  bool runtime_replay_present = false;
  BigNat construction_replay_draws{0U};
  for (const ResultReplayStreamV1& stream :
       value.execution.replay_streams) {
    if (const auto* construction =
            std::get_if<ResultConstructionReplayStreamV1>(&stream)) {
      construction_replay_present = true;
      construction_replay_draws += construction->draws;
    } else {
      runtime_replay_present = true;
    }
  }
  if ((!payload_present && construction_replay_present) ||
      (!seal_present &&
       (runtime_replay_present || !value.budgets_used.empty()))) {
    return Result<void>::failure(result_error(
        "c27.result_replay_provenance_invalid",
        "construction replay requires a Built payload, while runtime replay and backend budgets require an audited execution seal"));
  }
  const auto construction_budget = std::find_if(
      value.execution.budget_usage.begin(),
      value.execution.budget_usage.end(), [](const auto& row) {
        return row.name == "construction.configured_generator_draws";
      });
  if (construction_budget != value.execution.budget_usage.end()) {
    if ((payload_present &&
         construction_replay_draws != construction_budget->used) ||
        (construction_replay_present &&
         construction_budget->applicability !=
             ResultBudgetApplicabilityV1::applicable)) {
      return Result<void>::failure(result_error(
          "c27.result_construction_replay_count_mismatch",
          "construction replay draw counts must exactly match the validated configured-generator usage row"));
    }
  } else if (construction_replay_present) {
    return Result<void>::failure(result_error(
        "c27.result_construction_replay_budget_missing",
        "construction replay provenance requires its configured-generator usage row"));
  }
  if (request_construction_failure) {
    const bool construction_budget_present = std::any_of(
        value.execution.budget_usage.begin(),
        value.execution.budget_usage.end(), [](const auto& row) {
          return row.name.starts_with("construction.");
        });
    if (payload_present || seal_present ||
        !value.execution.replay_streams.empty() ||
        !value.budgets_used.empty() || construction_budget_present) {
      return Result<void>::failure(result_error(
          "c27.result_request_construction_provenance_invalid",
          "request-construction failure cannot retain payload, seal, replay, construction, or backend provenance minted later in execution"));
    }
  }

  auto failure_provenance = validate_failure_stage_provenance(
      value.failure, payload_present, seal_present, value.certificates);
  if (!failure_provenance) {
    return failure_provenance;
  }

  return Result<void>::success();
}

[[nodiscard]] constexpr std::string_view metric_kind_name(
    const MetricKindV1 value) noexcept {
  switch (value) {
    case MetricKindV1::stationary_throughput:
      return "stationary_throughput";
    case MetricKindV1::stationary_empty_probability:
      return "stationary_empty_probability";
    case MetricKindV1::mean_sojourn:
      return "mean_sojourn";
    case MetricKindV1::service_persistence:
      return "service_persistence";
    case MetricKindV1::joint_backlog_covariance:
      return "joint_backlog_covariance";
    case MetricKindV1::stationary_backlog_pmf:
      return "stationary_backlog_pmf";
    case MetricKindV1::stationary_backlog_pgf:
      return "stationary_backlog_pgf";
    case MetricKindV1::stationary_backlog_moment:
      return "stationary_backlog_moment";
    case MetricKindV1::stationary_backlog_quantile:
      return "stationary_backlog_quantile";
    case MetricKindV1::stationary_backlog_tail:
      return "stationary_backlog_tail";
    case MetricKindV1::backlog_conditioned_service:
      return "backlog_conditioned_service";
    case MetricKindV1::stationary_edge_reward:
      return "stationary_edge_reward";
    case MetricKindV1::service_autocovariance:
      return "service_autocovariance";
    case MetricKindV1::lagged_cross_queue_covariance:
      return "lagged_cross_queue_covariance";
    case MetricKindV1::service_spectrum:
      return "service_spectrum";
    case MetricKindV1::service_window_count:
      return "service_window_count";
    case MetricKindV1::mean_event_gap:
      return "mean_event_gap";
    case MetricKindV1::event_gap_distribution:
      return "event_gap_distribution";
    case MetricKindV1::mean_binary_run:
      return "mean_binary_run";
    case MetricKindV1::binary_run_distribution:
      return "binary_run_distribution";
    case MetricKindV1::first_hit:
      return "first_hit";
    case MetricKindV1::threshold_excursion:
      return "threshold_excursion";
    case MetricKindV1::transient_backlog_law:
      return "transient_backlog_law";
    case MetricKindV1::fifo_delay:
      return "fifo_delay";
    case MetricKindV1::fifo_delay_conditioned:
      return "fifo_delay_conditioned";
    case MetricKindV1::counterfactual_opportunity_gap:
      return "counterfactual_opportunity_gap";
    case MetricKindV1::joint_backlog_event:
      return "joint_backlog_event";
    case MetricKindV1::joint_delay:
      return "joint_delay";
    case MetricKindV1::ordered_schedule_sequence:
      return "ordered_schedule_sequence";
  }
  return "invalid";
}

[[nodiscard]] Json encode_compact_rational(const ExactRational& value) {
  Json encoded = Json{{"exact", value.to_canonical_string()}};
  const double decimal = static_cast<double>(value.to_long_double());
  if (std::isfinite(decimal)) {
    encoded["decimal"] = decimal;
  }
  return encoded;
}

[[nodiscard]] Json encode_compact_scalar(
    const PortableScientificScalar& value) {
  if (value.kind() == PortableScientificScalarKind::rational) {
    return encode_compact_rational(value.rational_value());
  }
  return encode_compact_rational(binary64_as_exact_rational(value));
}

[[nodiscard]] Json encode_compact_label(const TypedLabel& label) {
  if (label.is_text()) {
    return *label.text_value();
  }
  return Json{{"integer", label.numeric_value()->to_decimal_string()}};
}

[[nodiscard]] Json encode_compact_coordinates(
    const std::vector<TypedLabel>& coordinates) {
  if (coordinates.size() == 1U) {
    return encode_compact_label(coordinates.front());
  }
  Json encoded = Json::array();
  for (const TypedLabel& coordinate : coordinates) {
    encoded.push_back(encode_compact_label(coordinate));
  }
  return encoded;
}

[[nodiscard]] Json encode_compact_targets(
    const std::vector<QueueId>& targets) {
  if (targets.size() == 1U) {
    return encode_compact_label(targets.front().label());
  }
  Json encoded = Json::array();
  for (const QueueId& target : targets) {
    encoded.push_back(encode_compact_label(target.label()));
  }
  return encoded;
}

[[nodiscard]] Json encode_compact_metric_value(
    const ResultMetricValueV1& value) {
  return std::visit(
      [](const auto& alternative) -> Json {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::same_as<Alternative,
                                   PortableScientificScalar>) {
          return encode_compact_scalar(alternative);
        } else if constexpr (std::same_as<Alternative,
                                          PositiveInfinityV1>) {
          return "positive_infinity";
        } else if constexpr (std::same_as<Alternative,
                                          ResultScalarVectorV1>) {
          Json encoded = Json::array();
          for (const PortableScientificScalar& scalar : alternative.values) {
            encoded.push_back(encode_compact_scalar(scalar));
          }
          return encoded;
        } else if constexpr (std::same_as<Alternative, ResultTableV1>) {
          Json encoded = Json::object();
          encoded["coordinates"] = alternative.coordinate_names;
          encoded["entries"] = Json::array();
          for (const ResultTableEntryV1& entry : alternative.entries) {
            encoded["entries"].push_back(
                Json{{"at", encode_compact_coordinates(entry.coordinates)},
                     {"value", encode_compact_scalar(entry.value)}});
          }
          return encoded;
        } else if constexpr (std::same_as<Alternative,
                                          ResultProbabilityLawV1>) {
          Json encoded = Json::object();
          encoded["coordinates"] = alternative.coordinate_names;
          encoded["probabilities"] = Json::array();
          for (const ResultProbabilityAtomV1& atom : alternative.atoms) {
            encoded["probabilities"].push_back(
                Json{{"outcome", encode_compact_coordinates(atom.outcome)},
                     {"probability", encode_compact_scalar(atom.mass)}});
          }
          const ExactRational defect =
              alternative.defective_mass.kind() ==
                      PortableScientificScalarKind::rational
                  ? alternative.defective_mass.rational_value()
                  : binary64_as_exact_rational(alternative.defective_mass);
          if (!defect.is_zero()) {
            encoded["defective_mass"] = encode_compact_rational(defect);
          }
          return encoded;
        } else {
          return nullptr;
        }
      },
      value);
}

[[nodiscard]] Json encode_compact_metric(const ResultMetricV1& value) {
  const auto& established = std::get<EstablishedResultMetricV1>(value);
  const ResultMetricHeaderV1& header = established.header;
  Json encoded = Json::object();
  encoded["id"] = header.metric_id;
  encoded["kind"] = metric_kind_name(header.kind);
  encoded["target"] = encode_compact_targets(header.ordered_targets);
  encoded["units"] = header.units;
  encoded["value"] = encode_compact_metric_value(established.value);
  return encoded;
}

[[nodiscard]] Json encode_wall_clock(const ResultWallClockTimesV1& times) {
  const auto seconds = [](const std::chrono::nanoseconds duration) {
    return std::chrono::duration<double>(duration).count();
  };
  Json encoded = Json::object();
  encoded["end_to_end"] = seconds(times.end_to_end);
  encoded["sampler"] = seconds(times.sampler);
  encoded["framework"] = seconds(times.framework);
  return encoded;
}

[[nodiscard]] const ResultBudgetUsageV1* find_usage(
    const ResultArtifactDataV1& value, const std::string_view name) {
  const auto found = std::find_if(
      value.execution.budget_usage.begin(),
      value.execution.budget_usage.end(),
      [name](const ResultBudgetUsageV1& row) { return row.name == name; });
  return found == value.execution.budget_usage.end() ? nullptr : &*found;
}

[[nodiscard]] Json encode_resources(const ResultArtifactDataV1& value) {
  const ResultBudgetUsageV1* generator_draws =
      find_usage(value, "construction.configured_generator_draws");
  Json encoded = Json::object();
  encoded["workers"] = value.worker_count;
  encoded["optimizer_calls"] =
      value.optimizer_calls_observed.to_decimal_string();
  encoded["configured_generator_draws"] =
      generator_draws == nullptr ? "0"
                                 : generator_draws->used.to_decimal_string();
  encoded["optimizer_search_states"] =
      value.optimizer_search_states_observed.to_decimal_string();
  return encoded;
}

[[nodiscard]] std::string_view k_bin_coordinate_kind_text(
    const ResultKBinCoordinateKindV1 kind) noexcept {
  switch (kind) {
    case ResultKBinCoordinateKindV1::structural_level_zero:
      return "structural_level_zero";
    case ResultKBinCoordinateKindV1::exact_level:
      return "exact_level";
    case ResultKBinCoordinateKindV1::constant_tail:
      return "constant_tail";
  }
  return "invalid";
}

[[nodiscard]] Json encode_unavailable_diagnostics(
    const ResultUnavailableDiagnosticsV1& diagnostics) {
  Json encoded = Json::object();
  encoded["reasons"] = Json::array();
  for (const ResultUnavailableCauseV1& cause : diagnostics.causes) {
    Json reason{{"code", cause.code}, {"message", cause.message}};
    if (cause.metric_id) reason["metric_id"] = *cause.metric_id;
    encoded["reasons"].push_back(std::move(reason));
  }
  if (!diagnostics.coefficient_diagnostics.empty()) {
    encoded["coefficient_diagnostics"] = Json::array();
    for (const ResultKBinCoefficientDiagnosticV1& coefficient :
         diagnostics.coefficient_diagnostics) {
      Json row = Json::object();
      row["coordinate"] =
          Json{{"kind", std::string(k_bin_coordinate_kind_text(
                            coefficient.coordinate_kind))},
               {"level_or_tail_from",
                coefficient.level_or_tail_from.to_decimal_string()}};
      row["pooled_unserved_mass"] =
          encode_compact_scalar(coefficient.pooled_unserved_mass);
      row["pooled_served_mass"] =
          encode_compact_scalar(coefficient.pooled_served_mass);
      row["nominal_service_probability"] =
          encode_compact_scalar(coefficient.nominal_service_probability);
      if (coefficient.construction_interval_lower) {
        row["construction_interval"] =
            Json{{"lower", encode_compact_scalar(
                                *coefficient.construction_interval_lower)},
                 {"upper", encode_compact_scalar(
                                *coefficient.construction_interval_upper)},
                 {"use", "construction_evidence_only"}};
      }
      encoded["coefficient_diagnostics"].push_back(std::move(row));
    }
  }
  if (diagnostics.c19) {
    const ResultC19UnavailableDiagnosticsV1& source = *diagnostics.c19;
    Json service_by_level = Json::array();
    for (const PortableScientificScalar& coefficient :
         source.service_by_level) {
      service_by_level.push_back(encode_compact_scalar(coefficient));
    }
    Json c19 =
        Json{{"analytic_status", source.analytic_status},
             {"arrival_mean", encode_compact_scalar(source.arrival_mean)},
             {"service_by_level", std::move(service_by_level)},
             {"constant_tail",
              Json{{"tail_from", source.tail_from.to_decimal_string()},
                   {"service_probability",
                    encode_compact_scalar(source.tail_service)}}},
             {"tail_slack", encode_compact_scalar(source.tail_slack)},
             {"tail_slack_applicability",
              source.tail_slack_applicability},
             {"normalization_residual",
              encode_compact_scalar(source.normalization_residual)},
             {"invariance_residual",
              encode_compact_scalar(source.invariance_residual)}};
    if (source.tail_remainder_bound) {
      c19["tail_remainder_bound"] =
          encode_compact_scalar(*source.tail_remainder_bound);
    }
    if (source.terms_evaluated) {
      c19["terms_evaluated"] =
          source.terms_evaluated->to_decimal_string();
    }
    encoded["c19"] = std::move(c19);
  }
  return encoded;
}

[[nodiscard]] std::string_view result_status_text(
    const ResultStatusV1 value) noexcept {
  switch (value) {
    case ResultStatusV1::success: return "success";
    case ResultStatusV1::unavailable: return "unavailable";
    case ResultStatusV1::failed: return "failed";
  }
  return "invalid";
}

[[nodiscard]] std::string_view result_failure_stage_text(
    const ResultFailureStageV1 value) noexcept {
  switch (value) {
    case ResultFailureStageV1::request_construction:
      return "request_construction";
    case ResultFailureStageV1::producer_execution:
      return "producer_execution";
    case ResultFailureStageV1::wire_parse: return "wire_parse";
    case ResultFailureStageV1::build_contract_validation:
      return "build_contract_validation";
    case ResultFailureStageV1::payload_adaptation:
      return "payload_adaptation";
    case ResultFailureStageV1::plug_binding: return "plug_binding";
    case ResultFailureStageV1::v0_audit: return "v0_audit";
    case ResultFailureStageV1::initial_law: return "initial_law";
    case ResultFailureStageV1::backend: return "backend";
    case ResultFailureStageV1::certificate: return "certificate";
    case ResultFailureStageV1::result_assembly: return "result_assembly";
  }
  return "invalid";
}

[[nodiscard]] Json encode_result_failure(
    const std::optional<ResultFailureV1>& failure) {
  if (!failure.has_value()) {
    return nullptr;
  }
  return Json{{"stage", result_failure_stage_text(failure->stage)},
              {"code", failure->code},
              {"diagnostic_refs", failure->diagnostic_refs}};
}

[[nodiscard]] std::string_view observation_source_role_text(
    const ObservationSourceRoleV1 value) noexcept {
  switch (value) {
    case ObservationSourceRoleV1::weighted_ensemble:
      return "weighted_ensemble";
    case ObservationSourceRoleV1::short_restart_reference:
      return "short_restart_reference";
    case ObservationSourceRoleV1::long_stationary_reference:
      return "long_stationary_reference";
  }
  return "invalid";
}

[[nodiscard]] std::string_view compression_unavailable_reason_text(
    const CompressionUnavailableReasonV1 value) noexcept {
  switch (value) {
    case CompressionUnavailableReasonV1::no_complete_replication:
      return "no_complete_replication";
    case CompressionUnavailableReasonV1::no_exposure: return "no_exposure";
    case CompressionUnavailableReasonV1::no_tail_exposure:
      return "no_tail_exposure";
    case CompressionUnavailableReasonV1::zero_observed_mean:
      return "zero_observed_mean";
    case CompressionUnavailableReasonV1::zero_tail_slack:
      return "zero_tail_slack";
    case CompressionUnavailableReasonV1::nonpositive_tail_slack:
      return "nonpositive_tail_slack";
    case CompressionUnavailableReasonV1::stationary_hypotheses_unavailable:
      return "stationary_hypotheses_unavailable";
    case CompressionUnavailableReasonV1::prefix_preservation_unavailable:
      return "prefix_preservation_unavailable";
    case CompressionUnavailableReasonV1::unsupported_arrival_identity:
      return "unsupported_arrival_identity";
    case CompressionUnavailableReasonV1::unsupported_slot_convention:
      return "unsupported_slot_convention";
    case CompressionUnavailableReasonV1::target_drop_possible:
      return "target_drop_possible";
    case CompressionUnavailableReasonV1::missing_second_moment:
      return "missing_second_moment";
    case CompressionUnavailableReasonV1::missing_arrival_overshoot:
      return "missing_arrival_overshoot";
    case CompressionUnavailableReasonV1::incomplete_or_missing_boundary:
      return "incomplete_or_missing_boundary";
    case CompressionUnavailableReasonV1::gap_telemetry_unavailable:
      return "gap_telemetry_unavailable";
    case CompressionUnavailableReasonV1::inexact_primary_optimizer:
      return "inexact_primary_optimizer";
    case CompressionUnavailableReasonV1::unsupported_gap_topology:
      return "unsupported_gap_topology";
    case CompressionUnavailableReasonV1::unsupported_target_multiplier:
      return "unsupported_target_multiplier";
    case CompressionUnavailableReasonV1::zero_competition_scale:
      return "zero_competition_scale";
    case CompressionUnavailableReasonV1::nonpositive_competition_scale:
      return "nonpositive_competition_scale";
    case CompressionUnavailableReasonV1::fitted_law_unavailable:
      return "fitted_law_unavailable";
    case CompressionUnavailableReasonV1::outside_decoder_profile:
      return "outside_decoder_profile";
    case CompressionUnavailableReasonV1::decoder_rejected:
      return "decoder_rejected";
    case CompressionUnavailableReasonV1::invalid_fit_shape:
      return "invalid_fit_shape";
    case CompressionUnavailableReasonV1::denominator_enclosure_contains_zero:
      return "denominator_enclosure_contains_zero";
    case CompressionUnavailableReasonV1::insufficient_independent_replications:
      return "insufficient_independent_replications";
    case CompressionUnavailableReasonV1::invalid_jackknife_resample:
      return "invalid_jackknife_resample";
    case CompressionUnavailableReasonV1::context_mismatch:
      return "context_mismatch";
    case CompressionUnavailableReasonV1::source_role_mismatch:
      return "source_role_mismatch";
    case CompressionUnavailableReasonV1::intermediate_fit_unavailable:
      return "intermediate_fit_unavailable";
    case CompressionUnavailableReasonV1::transformed_profile_unavailable:
      return "transformed_profile_unavailable";
    case CompressionUnavailableReasonV1::
        arrival_overshoot_numerically_unresolved:
      return "arrival_overshoot_numerically_unresolved";
    case CompressionUnavailableReasonV1::arrival_overshoot_work_limit:
      return "arrival_overshoot_work_limit";
  }
  return "invalid";
}

[[nodiscard]] std::string_view compression_warning_text(
    const CompressionWarningCodeV1 value) noexcept {
  switch (value) {
    case CompressionWarningCodeV1::structural_zero_response:
      return "structural_zero_response";
    case CompressionWarningCodeV1::exposure_without_observed_service:
      return "exposure_without_observed_service";
    case CompressionWarningCodeV1::nonunit_recorded_mass:
      return "nonunit_recorded_mass";
    case CompressionWarningCodeV1::numerical_enclosure_required:
      return "numerical_enclosure_required";
    case CompressionWarningCodeV1::ill_conditioned_tail_slack:
      return "ill_conditioned_tail_slack";
    case CompressionWarningCodeV1::finite_closure_with_nonpositive_slack:
      return "finite_closure_with_nonpositive_slack";
    case CompressionWarningCodeV1::stationary_interpretation_is_estimated:
      return "stationary_interpretation_is_estimated";
    case CompressionWarningCodeV1::partial_replications_excluded:
      return "partial_replications_excluded";
    case CompressionWarningCodeV1::invalid_jackknife_resamples_present:
      return "invalid_jackknife_resamples_present";
  }
  return "invalid";
}

[[nodiscard]] Json encode_compression_status(
    const CompressionMetricStatusV1& status) {
  Json unavailable = Json::array();
  for (const CompressionUnavailableReasonV1 reason :
       status.unavailable_reasons) {
    unavailable.push_back(compression_unavailable_reason_text(reason));
  }
  Json warnings = Json::array();
  for (const CompressionWarningCodeV1 warning : status.warnings) {
    warnings.push_back(compression_warning_text(warning));
  }
  return Json{{"unavailable_reasons", std::move(unavailable)},
              {"warnings", std::move(warnings)}};
}

[[nodiscard]] Json encode_compression_numerical_value(
    const CompressionNumericalValueV1& value) {
  return Json{{"value", encode_compact_rational(value.value)},
              {"absolute_error_bound",
               encode_compact_rational(value.absolute_error_bound)}};
}

[[nodiscard]] Json encode_compression_quantity(
    const CompressionQuantityV1& value) {
  return Json{{"estimate",
               value.estimate.has_value()
                   ? encode_compression_numerical_value(*value.estimate)
                   : Json(nullptr)},
              {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_pooled_gap(const PooledGapCellV1& value) {
  return Json{{"negative_mass",
               encode_compression_numerical_value(value.negative_mass)},
              {"tie_mass", encode_compression_numerical_value(value.tie_mass)},
              {"positive_mass",
               encode_compression_numerical_value(value.positive_mass)},
              {"tied_and_served_mass",
               encode_compression_numerical_value(value.tied_and_served_mass)},
              {"positive_magnitude_mass",
               encode_compression_numerical_value(
                   value.positive_magnitude_mass)},
              {"negative_magnitude_mass",
               encode_compression_numerical_value(
                   value.negative_magnitude_mass)}};
}

[[nodiscard]] Json encode_pooled_moments(
    const PooledObservationMomentsV1& value) {
  Json levels = Json::array();
  for (const PooledObservationLevelV1& level : value.levels) {
    levels.push_back(
        Json{{"backlog_level", level.backlog_level.to_decimal_string()},
             {"exposure_mass",
              encode_compression_numerical_value(level.exposure_mass)},
             {"served_mass",
              encode_compression_numerical_value(level.served_mass)},
             {"gap", level.gap.has_value() ? encode_pooled_gap(*level.gap)
                                             : Json(nullptr)}});
  }
  return Json{{"measured_slot_count",
               value.measured_slot_count.to_decimal_string()},
              {"included_complete_replications",
               value.included_complete_replications},
              {"excluded_partial_replications",
               value.excluded_partial_replications},
              {"levels", std::move(levels)},
              {"recorded_exposure_mass",
               encode_compression_numerical_value(
                   value.recorded_exposure_mass)},
              {"mass_per_slot", encode_compression_quantity(value.mass_per_slot)},
              {"signed_mass_defect",
               encode_compression_quantity(value.signed_mass_defect)},
              {"departure_rate",
               encode_compression_quantity(value.departure_rate)},
              {"observed_mean",
               encode_compression_quantity(value.observed_mean)},
              {"service_moment",
               encode_compression_quantity(value.service_moment)},
              {"departure_rate_per_slot",
               encode_compression_quantity(value.departure_rate_per_slot)},
              {"observed_mean_per_slot",
               encode_compression_quantity(value.observed_mean_per_slot)},
              {"service_moment_per_slot",
               encode_compression_quantity(value.service_moment_per_slot)},
              {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] std::string_view empirical_point_status_text(
    const EmpiricalFiniteWindowPointStatusV1 value) noexcept {
  switch (value) {
    case EmpiricalFiniteWindowPointStatusV1::structural_zero:
      return "structural_zero";
    case EmpiricalFiniteWindowPointStatusV1::available:
      return "available";
    case EmpiricalFiniteWindowPointStatusV1::no_exposure:
      return "no_exposure";
    case EmpiricalFiniteWindowPointStatusV1::
        denominator_enclosure_contains_zero:
      return "denominator_enclosure_contains_zero";
  }
  return "invalid";
}

[[nodiscard]] Json encode_empirical_finite_window_response(
    const EmpiricalFiniteWindowResponseV1& value) {
  Json levels = Json::array();
  for (const EmpiricalFiniteWindowResponsePointV1& point :
       value.observed_levels) {
    levels.push_back(Json{
        {"level", point.backlog_level.to_decimal_string()},
        {"exposure_mass",
         encode_compression_numerical_value(point.exposure_mass)},
        {"served_mass", encode_compression_numerical_value(point.served_mass)},
        {"response_status", empirical_point_status_text(point.response_status)},
        {"response", encode_compression_quantity(point.response)}});
  }
  Json boundaries = Json::array();
  for (const std::uint64_t boundary : value.reporting_block_boundaries) {
    boundaries.push_back(boundary);
  }
  return Json{
      {"source_observation_digest", value.source_observation_digest.hex()},
      {"source_role", observation_source_role_text(value.source_role)},
      {"request_digest", value.bindings.request_digest.hex()},
      {"problem_digest", value.bindings.problem_digest.hex()},
      {"experiment_digest", value.bindings.experiment_digest.hex()},
      {"topology_digest", value.bindings.topology_digest.hex()},
      {"arrival_law_digest",
       value.bindings.arrival.configured_law_digest.hex()},
      {"target_id", encode_compact_label(value.bindings.target.target_id.label())},
      {"warmup_boundary", value.warmup_boundary},
      {"end_boundary", value.end_boundary},
      {"reporting_block_boundaries", std::move(boundaries)},
      {"ensemble_population_size",
       value.ensemble_population_size
           ? Json(value.ensemble_population_size->to_decimal_string())
           : Json(nullptr)},
      {"configured_replications", value.configured_replications},
      {"included_complete_replications",
       value.included_complete_replications},
      {"excluded_partial_replications", value.excluded_partial_replications},
      {"observed_levels", std::move(levels)},
      {"observed_point_count", value.observed_point_count.to_decimal_string()},
      {"highest_observed_level",
       value.highest_observed_level
           ? Json(value.highest_observed_level->to_decimal_string())
           : Json(nullptr)},
      {"coordinate_extent",
       value.coordinate_extent
           ? Json(value.coordinate_extent->to_decimal_string())
           : Json(nullptr)},
      {"complete_through",
       value.complete_through
           ? Json(value.complete_through->to_decimal_string())
           : Json(nullptr)},
      {"recorded_exposure_mass",
       encode_compression_numerical_value(value.recorded_exposure_mass)},
      {"mass_per_slot", encode_compression_quantity(value.mass_per_slot)},
      {"signed_mass_defect",
       encode_compression_quantity(value.signed_mass_defect)},
      {"interpretation", "finite_window"},
      {"tail_completion", "none"},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] std::string_view compression_replication_inclusion_text(
    const CompressionReplicationInclusionV1 value) noexcept {
  switch (value) {
    case CompressionReplicationInclusionV1::included_complete:
      return "included_complete";
    case CompressionReplicationInclusionV1::excluded_incomplete:
      return "excluded_incomplete";
    case CompressionReplicationInclusionV1::excluded_boundary_mismatch:
      return "excluded_boundary_mismatch";
  }
  return "invalid";
}

[[nodiscard]] std::string_view observation_completeness_text(
    const ObservationCompletenessV1 value) noexcept {
  switch (value) {
    case ObservationCompletenessV1::complete:
      return "complete";
    case ObservationCompletenessV1::partial:
      return "partial";
  }
  return "invalid";
}

[[nodiscard]] Json encode_optional_compression_numerical_value(
    const std::optional<CompressionNumericalValueV1>& value) {
  return value.has_value() ? encode_compression_numerical_value(*value)
                           : Json(nullptr);
}

[[nodiscard]] Json encode_replication_cutoff_summary(
    const CompressionReplicationCutoffSummaryV1& value) {
  return Json{
      {"cutoff", value.cutoff.to_decimal_string()},
      {"tail_exposure_mass",
       encode_compression_numerical_value(value.tail_exposure_mass)},
      {"tail_service_mass",
       encode_compression_numerical_value(value.tail_service_mass)},
      {"backlog_tail_exposure_mass",
       encode_compression_numerical_value(
           value.backlog_tail_exposure_mass)},
      {"backlog_tail_service_mass",
       encode_compression_numerical_value(
           value.backlog_tail_service_mass)},
      {"positive_gap_tail_magnitude_mass",
       encode_optional_compression_numerical_value(
           value.positive_gap_tail_magnitude_mass)},
      {"negative_gap_tail_magnitude_mass",
       encode_optional_compression_numerical_value(
           value.negative_gap_tail_magnitude_mass)}};
}

[[nodiscard]] Json encode_replication_summary(
    const CompressionReplicationSummaryV1& value) {
  Json cutoffs = Json::array();
  for (const CompressionReplicationCutoffSummaryV1& cutoff : value.cutoffs) {
    cutoffs.push_back(encode_replication_cutoff_summary(cutoff));
  }
  return Json{
      {"replication_id", encode_compact_label(value.replication_id)},
      {"completeness", observation_completeness_text(value.completeness)},
      {"inclusion", compression_replication_inclusion_text(value.inclusion)},
      {"measured_slot_count", value.measured_slot_count.to_decimal_string()},
      {"exposure_mass",
       encode_compression_numerical_value(value.exposure_mass)},
      {"service_mass",
       encode_compression_numerical_value(value.service_mass)},
      {"backlog_exposure_mass",
       encode_compression_numerical_value(value.backlog_exposure_mass)},
      {"backlog_service_mass",
       encode_compression_numerical_value(value.backlog_service_mass)},
      {"initial_first_moment",
       encode_optional_compression_numerical_value(value.initial_first_moment)},
      {"committed_first_moment",
       encode_optional_compression_numerical_value(
           value.committed_first_moment)},
      {"initial_second_moment",
       encode_optional_compression_numerical_value(
           value.initial_second_moment)},
      {"committed_second_moment",
       encode_optional_compression_numerical_value(
           value.committed_second_moment)},
      {"cutoffs", std::move(cutoffs)}};
}

[[nodiscard]] Json encode_empirical_profile(
    const EmpiricalResponseProfileV1& value) {
  Json prefix = Json::array();
  for (const EmpiricalResponsePointV1& point : value.prefix) {
    prefix.push_back(
        Json{{"backlog_level", point.backlog_level.to_decimal_string()},
             {"occupation_probability",
              encode_compression_quantity(point.occupation_probability)},
             {"service_probability_mass",
              encode_compression_quantity(point.service_probability_mass)},
             {"response", encode_compression_quantity(point.response)},
             {"observed_exposure", point.observed_exposure},
             {"decoder_structural_zero", point.decoder_structural_zero}});
  }
  Json encoded{{"cutoff", value.cutoff.to_decimal_string()},
               {"prefix", std::move(prefix)},
               {"constant_tail_response",
                encode_compression_quantity(value.constant_tail_response)},
               {"status", encode_compression_status(value.status)}};
  if (value.representation ==
      EmpiricalResponseProfileRepresentationV1::sparse_profile_reference) {
    encoded["representation"] = "sparse_profile_reference";
  }
  return encoded;
}

[[nodiscard]] Json encode_rational_vector(
    const std::vector<ExactRational>& values) {
  Json encoded = Json::array();
  for (const ExactRational& value : values) {
    encoded.push_back(encode_compact_rational(value));
  }
  return encoded;
}

[[nodiscard]] Json encode_supplied_profile(
    const SuppliedResponseProfileV1& value) {
  return Json{{"cutoff", value.cutoff.to_decimal_string()},
              {"service_by_level",
               encode_rational_vector(value.service_by_level)},
              {"constant_tail_service",
               encode_compact_rational(value.constant_tail_service)},
              {"prefix_exposure_mass",
               encode_rational_vector(value.prefix_exposure_mass)},
              {"prefix_served_mass",
               encode_rational_vector(value.prefix_served_mass)},
              {"tail_exposure_mass",
               encode_compact_rational(value.tail_exposure_mass)},
              {"tail_served_mass",
               encode_compact_rational(value.tail_served_mass)}};
}

// This is the complete, typed preimage consumed by
// compression_analysis_digest (apart from the separately authenticated
// observation digest).  Array order is deliberately retained: although the
// identity encoder canonicalizes the set-like portions, admission checks can
// depend on the authored cardinality, so the reader must rerun with exactly
// the effective options used by the writer.
[[nodiscard]] Json encode_compression_analysis_options(
    const CompressionAnalysisOptionsV1& value) {
  Json cutoffs = Json::array();
  for (const BigNat& cutoff : value.cutoffs) {
    cutoffs.push_back(cutoff.to_decimal_string());
  }
  Json seed = Json::array();
  for (const FinitePrefixFitSelectionSeedAtomV1& atom :
       value.selection_seed) {
    seed.push_back(
        Json{{"backlog", atom.backlog.to_decimal_string()},
             {"selection_mass", encode_compact_rational(atom.selection_mass)}});
  }
  Json supplied = Json::array();
  for (const SuppliedResponseProfileV1& profile :
       value.provider_supplied_profiles) {
    supplied.push_back(encode_supplied_profile(profile));
  }
  Json encoded{
      {"cutoffs", std::move(cutoffs)},
      {"fit_limits",
       Json{{"maximum_cutoff", value.fit_limits.maximum_cutoff},
            {"maximum_arrival_atoms",
             value.fit_limits.maximum_arrival_atoms},
            {"maximum_selection_seed_atoms",
             value.fit_limits.maximum_selection_seed_atoms},
            {"maximum_closure_states",
             value.fit_limits.maximum_closure_states}}},
      {"effective_selection_seed", std::move(seed)},
      {"provider_supplied_profiles", std::move(supplied)},
      {"ill_conditioned_slack_threshold",
       value.ill_conditioned_slack_threshold.has_value()
           ? encode_compact_rational(
                 *value.ill_conditioned_slack_threshold)
           : Json(nullptr)},
      {"run_diagnostic_fits", value.run_diagnostic_fits},
      {"compute_delete_one_replication_jackknife",
       value.compute_delete_one_replication_jackknife},
      {"stationary_coefficients_established",
       value.stationary_coefficients_established},
      {"prefix_preservation_established",
       value.prefix_preservation_established}};
  if (value.projection_mode ==
      CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response) {
    encoded["projection_mode"] = "empirical_finite_window_response_v1";
    encoded["ensemble_population_size"] =
        value.ensemble_population_size
            ? Json(value.ensemble_population_size->to_decimal_string())
            : Json(nullptr);
    if (value.poisson_overshoot) {
      Json components = Json::array();
      for (const auto& component : value.poisson_overshoot->components) {
        components.push_back(
            Json{{"weight", encode_compact_rational(component.weight)},
                 {"component_rate",
                  encode_compact_rational(component.component_rate)},
                 {"operational_rate_bits",
                  std::to_string(component.operational_rate_bits)}});
      }
      encoded["poisson_mixture_overshoot_v1"] =
          Json{{"descriptor_id", value.poisson_overshoot->descriptor_id},
               {"descriptor_version",
                value.poisson_overshoot->descriptor_version},
               {"components", std::move(components)},
               {"operational_parameter_digest",
                value.poisson_overshoot->operational_parameter_digest.hex()},
               {"descriptor_digest",
                value.poisson_overshoot->descriptor_digest.hex()},
               {"omitted_tail_tolerance",
                encode_compact_rational(
                    value.poisson_overshoot->omitted_tail_tolerance)},
               {"maximum_recurrence_steps",
                value.poisson_overshoot->maximum_recurrence_steps}};
    } else {
      encoded["poisson_mixture_overshoot_v1"] = nullptr;
    }
  }
  return encoded;
}

[[nodiscard]] bool published_analysis_options_within_limits(
    const CompressionAnalysisOptionsV1& value) noexcept {
  const FinitePrefixFitLimitsV1 bounds;
  const std::size_t maximum_cutoff_count = bounds.maximum_cutoff + 1U;
  const bool sparse_empirical =
      value.projection_mode ==
      CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  if (value.fit_limits.maximum_cutoff > bounds.maximum_cutoff ||
      value.fit_limits.maximum_arrival_atoms >
          bounds.maximum_arrival_atoms ||
      value.fit_limits.maximum_selection_seed_atoms >
          bounds.maximum_selection_seed_atoms ||
      value.fit_limits.maximum_closure_states >
          bounds.maximum_closure_states ||
      (!sparse_empirical && value.cutoffs.size() > maximum_cutoff_count) ||
      value.selection_seed.size() > bounds.maximum_selection_seed_atoms ||
      value.provider_supplied_profiles.size() > maximum_cutoff_count ||
      (sparse_empirical && !value.provider_supplied_profiles.empty()) ||
      (!sparse_empirical && value.poisson_overshoot.has_value()) ||
      (value.poisson_overshoot &&
       value.poisson_overshoot->maximum_recurrence_steps == 0U)) {
    return false;
  }
  return std::ranges::all_of(
      value.provider_supplied_profiles,
      [maximum_cutoff_count](const SuppliedResponseProfileV1& profile) {
        return profile.service_by_level.size() <= maximum_cutoff_count &&
               profile.prefix_exposure_mass.size() <=
                   maximum_cutoff_count &&
               profile.prefix_served_mass.size() <= maximum_cutoff_count;
      });
}

[[nodiscard]] bool valid_supplied_profile_semantics(
    const SuppliedResponseProfileV1& value) {
  if (value.service_by_level.empty() ||
      value.service_by_level.size() != value.prefix_exposure_mass.size() ||
      value.service_by_level.size() != value.prefix_served_mass.size() ||
      value.cutoff != BigNat{static_cast<std::uint64_t>(
                          value.service_by_level.size() - 1U)} ||
      value.service_by_level.front() != ExactRational::zero()) {
    return false;
  }
  const auto probability = [](const ExactRational& candidate) {
    return candidate >= ExactRational::zero() &&
           candidate <= ExactRational::one();
  };
  if (!probability(value.constant_tail_service) ||
      value.tail_exposure_mass < ExactRational::zero() ||
      value.tail_served_mass < ExactRational::zero() ||
      value.tail_served_mass > value.tail_exposure_mass) {
    return false;
  }
  // Do not require served == exposure * coefficient.  The provider-authored
  // binary64 coefficient and its supporting masses are independently rounded
  // observables, and F5 requires any mismatch to remain visible beside the
  // empirical mass-ratio profile rather than rejecting or silently rewriting
  // it.  Nonnegativity and served <= exposure still imply served == 0 for a
  // zero-exposure coordinate.
  for (std::size_t index = 0U; index < value.service_by_level.size();
       ++index) {
    if (!probability(value.service_by_level[index]) ||
        value.prefix_exposure_mass[index] < ExactRational::zero() ||
        value.prefix_served_mass[index] < ExactRational::zero() ||
        value.prefix_served_mass[index] >
            value.prefix_exposure_mass[index]) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] Json encode_four_tail_rewards(const FourTailRewardsV1& value) {
  return Json{{"tail_probability",
               encode_compression_quantity(value.tail_probability)},
              {"tail_service_mass",
               encode_compression_quantity(value.tail_service_mass)},
              {"backlog_tail_reward",
               encode_compression_quantity(value.backlog_tail_reward)},
              {"backlog_service_tail_reward",
               encode_compression_quantity(
                   value.backlog_service_tail_reward)},
              {"constant_tail_response",
               encode_compression_quantity(value.constant_tail_response)},
              {"tail_slack", encode_compression_quantity(value.tail_slack)},
              {"discarded_association_reward",
               encode_compression_quantity(
                   value.discarded_association_reward)},
              {"tail_mean_fraction",
               encode_compression_quantity(value.tail_mean_fraction)},
              {"tail_association_ratio",
               encode_compression_quantity(value.tail_association_ratio)},
              {"stationary_compression_defect",
               encode_compression_quantity(
                   value.stationary_compression_defect)},
              {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_decomposition(
    const EmpiricalCompressionDecompositionV1& value) {
  return Json{{"arrival_balance_constant",
               encode_compression_quantity(value.arrival_balance_constant)},
              {"empirical_balance_residual",
               encode_compression_quantity(value.empirical_balance_residual)},
              {"observed_prefix_correction",
               encode_compression_quantity(value.observed_prefix_correction)},
              {"observation_balance_lhs",
               encode_compression_quantity(value.observation_balance_lhs)},
              {"observation_balance_rhs",
               encode_compression_quantity(value.observation_balance_rhs)},
              {"observation_balance_closure",
               encode_compression_quantity(
                   value.observation_balance_closure)},
              {"fitted_prefix_correction",
               encode_compression_quantity(value.fitted_prefix_correction)},
              {"fitted_minus_observed_mean",
               encode_compression_quantity(
                   value.fitted_minus_observed_mean)},
              {"numerator_lhs",
               encode_compression_quantity(value.numerator_lhs)},
              {"numerator_rhs",
               encode_compression_quantity(value.numerator_rhs)},
              {"numerator_closure",
               encode_compression_quantity(value.numerator_closure)},
              {"compression_term",
               encode_compression_quantity(value.compression_term)},
              {"fitted_prefix_term",
               encode_compression_quantity(value.fitted_prefix_term)},
              {"finite_window_balance_term",
               encode_compression_quantity(
                   value.finite_window_balance_term)},
              {"divided_term_sum",
               encode_compression_quantity(value.divided_term_sum)},
              {"divided_closure",
               encode_compression_quantity(value.divided_closure)},
              {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] std::string_view fit_status_text(
    const FinitePrefixFitStatusV1 value) noexcept {
  switch (value) {
    case FinitePrefixFitStatusV1::strict_tail_stable:
      return "strict_tail_stable";
    case FinitePrefixFitStatusV1::finite_closed_tail_unreachable:
      return "finite_closed_tail_unreachable";
    case FinitePrefixFitStatusV1::outside_strict_tail_profile:
      return "outside_strict_tail_profile";
    case FinitePrefixFitStatusV1::degenerate_or_selected_closed_class:
      return "degenerate_or_selected_closed_class";
    case FinitePrefixFitStatusV1::required_moment_unavailable:
      return "required_moment_unavailable";
    case FinitePrefixFitStatusV1::unsupported_assumptions:
      return "unsupported_assumptions";
  }
  return "invalid";
}

[[nodiscard]] std::string_view fit_slack_applicability_text(
    const FinitePrefixFitSlackApplicabilityV1 value) noexcept {
  switch (value) {
    case FinitePrefixFitSlackApplicabilityV1::applicable:
      return "applicable";
    case FinitePrefixFitSlackApplicabilityV1::not_applicable_off_class:
      return "not_applicable_off_class";
    case FinitePrefixFitSlackApplicabilityV1::stationary_law_not_established:
      return "stationary_law_not_established";
  }
  return "invalid";
}

[[nodiscard]] Json encode_optional_rational(
    const std::optional<ExactRational>& value) {
  return value.has_value() ? encode_compact_rational(*value) : Json(nullptr);
}

[[nodiscard]] Json encode_optional_rational_vector(
    const std::optional<std::vector<ExactRational>>& values) {
  return values.has_value() ? encode_rational_vector(*values) : Json(nullptr);
}

[[nodiscard]] Json encode_big_nat_vector(const std::vector<BigNat>& values) {
  Json encoded = Json::array();
  for (const BigNat& value : values) {
    encoded.push_back(value.to_decimal_string());
  }
  return encoded;
}

[[nodiscard]] Json encode_finite_prefix_fit(
    const FinitePrefixFitResultV1& value) {
  return Json{
      {"status", fit_status_text(value.status)},
      {"binding",
       Json{{"coefficient_source_digest",
             value.binding.coefficient_source_digest.hex()},
            {"arrival_law_digest", value.binding.arrival_law_digest.hex()}}},
      {"consumed_service_by_level",
       encode_rational_vector(value.consumed_service_by_level)},
      {"consumed_constant_tail_service",
       encode_compact_rational(value.consumed_constant_tail_service)},
      {"arrival_mean", encode_compact_rational(value.arrival_mean)},
      {"arrival_second_moment",
       encode_optional_rational(value.arrival_second_moment)},
      {"fitted_prefix_probabilities",
       encode_optional_rational_vector(value.fitted_prefix_probabilities)},
      {"fitted_tail_mass", encode_optional_rational(value.fitted_tail_mass)},
      {"fitted_mean_backlog",
       encode_optional_rational(value.fitted_mean_backlog)},
      {"tail_slack_applicability",
       fit_slack_applicability_text(value.tail_slack_applicability)},
      {"tail_slack", encode_optional_rational(value.tail_slack)},
      {"residuals",
       Json{{"normalization",
             encode_optional_rational(value.residuals.normalization)},
            {"invariance",
             encode_optional_rational(value.residuals.invariance)},
            {"mean_identity",
             encode_optional_rational(value.residuals.mean_identity)}}},
      {"terms_evaluated", value.terms_evaluated.to_decimal_string()},
      {"finite_reachable_support",
       encode_big_nat_vector(value.finite_reachable_support)}};
}

[[nodiscard]] std::string_view diagnostic_category_text(
    const DiagnosticCategory value) noexcept {
  switch (value) {
    case DiagnosticCategory::cli_usage: return "cli_usage";
    case DiagnosticCategory::input_validation: return "input_validation";
    case DiagnosticCategory::resource_limit: return "resource_limit";
    case DiagnosticCategory::unavailable: return "unavailable";
    case DiagnosticCategory::internal: return "internal";
    case DiagnosticCategory::information: return "information";
  }
  return "invalid";
}

[[nodiscard]] Json encode_diagnostic(const Diagnostic& value) {
  return Json{{"category", diagnostic_category_text(value.category)},
              {"code", value.code},
              {"message", value.message},
              {"authored_path",
               value.authored_path.has_value() ? Json(*value.authored_path)
                                                : Json(nullptr)},
              {"json_pointer",
               value.json_pointer.has_value() ? Json(*value.json_pointer)
                                               : Json(nullptr)},
              {"notes", value.notes}};
}

[[nodiscard]] Json encode_delete_one_jackknife(
    const DeleteOneReplicationJackknifeV1& value) {
  Json leave_one_out = Json::array();
  for (const JackknifeReplicationEstimateV1& estimate :
       value.leave_one_out_estimates) {
    leave_one_out.push_back(
        Json{{"omitted_replication_id",
              encode_compact_label(estimate.omitted_replication_id)},
             {"estimate", encode_compression_quantity(estimate.estimate)}});
  }
  return Json{{"point_estimate",
               encode_compression_quantity(value.point_estimate)},
              {"leave_one_out_estimates", std::move(leave_one_out)},
              {"leave_one_out_mean",
               encode_compression_quantity(value.leave_one_out_mean)},
              {"estimated_bias",
               encode_compression_quantity(value.estimated_bias)},
              {"bias_corrected_estimate",
               encode_compression_quantity(value.bias_corrected_estimate)},
              {"squared_standard_error",
               encode_compression_quantity(value.squared_standard_error)},
              {"invalid_resample_rate",
               encode_compression_quantity(value.invalid_resample_rate)},
              {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_jackknife(
    const CompressionCutoffJackknifeV1& value) {
  return Json{{"fitted_mean",
               encode_delete_one_jackknife(value.fitted_mean)},
              {"fitted_minus_observed_mean",
               encode_delete_one_jackknife(
                   value.fitted_minus_observed_mean)},
              {"tail_association_ratio",
               encode_delete_one_jackknife(value.tail_association_ratio)},
              {"fit_resamples",
               Json{{"eligible_fit_resamples",
                     value.fit_resamples.eligible_fit_resamples},
                    {"failed_fit_resamples",
                     value.fit_resamples.failed_fit_resamples},
                    {"unavailable_fit_resamples",
                     value.fit_resamples.unavailable_fit_resamples},
                    {"unavailable_estimate_resamples",
                     value.fit_resamples.unavailable_estimate_resamples}}}};
}

[[nodiscard]] Json encode_cutoff_analysis(
    const CompressionCutoffAnalysisV1& value) {
  return Json{
      {"cutoff", value.cutoff.to_decimal_string()},
      {"empirical_profile", encode_empirical_profile(value.empirical_profile)},
      {"provider_supplied_profile",
       value.provider_supplied_profile.has_value()
           ? encode_supplied_profile(*value.provider_supplied_profile)
           : Json(nullptr)},
      {"four_tail_rewards", encode_four_tail_rewards(value.tail)},
      {"diagnostic_fit",
       value.diagnostic_fit.has_value()
           ? encode_finite_prefix_fit(*value.diagnostic_fit)
           : Json(nullptr)},
      {"diagnostic_fit_failure",
       value.diagnostic_fit_failure.has_value()
           ? encode_diagnostic(*value.diagnostic_fit_failure)
           : Json(nullptr)},
      {"diagnostic_fit_status",
       encode_compression_status(value.diagnostic_fit_status)},
      {"diagnostic_fitted_mean",
       encode_compression_quantity(value.diagnostic_fitted_mean)},
      {"empirical_decomposition", encode_decomposition(value.decomposition)},
      {"jackknife", value.jackknife.has_value()
                        ? encode_jackknife(*value.jackknife)
                        : Json(nullptr)},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_finite_window(
    const FiniteWindowAnalysisV1& value) {
  Json cutoffs = Json::array();
  for (const FiniteWindowCutoffAnalysisV1& cutoff : value.cutoffs) {
    cutoffs.push_back(
        Json{{"cutoff", cutoff.cutoff.to_decimal_string()},
             {"hinge_endpoint_drift",
              encode_compression_quantity(cutoff.hinge_endpoint_drift)},
             {"tail_probability_per_slot",
              encode_compression_quantity(cutoff.tail_probability_per_slot)},
             {"overshoot_reward_normalized",
              encode_compression_quantity(
                  cutoff.overshoot_reward_normalized)},
             {"overshoot_reward_per_slot",
              encode_compression_quantity(cutoff.overshoot_reward_per_slot)},
             {"innovation",
              encode_compression_quantity(cutoff.innovation)},
             {"expectation_level_residual",
              encode_compression_quantity(
                  cutoff.expectation_level_residual)},
             {"realized_identity_closure",
              encode_compression_quantity(
                  cutoff.realized_identity_closure)},
             {"status", encode_compression_status(cutoff.status)}});
  }
  return Json{
      {"first_moment_endpoint_drift",
       encode_compression_quantity(value.first_moment_endpoint_drift)},
      {"second_moment_endpoint_drift",
       encode_compression_quantity(value.second_moment_endpoint_drift)},
      {"first_moment_expected_increment",
       encode_compression_quantity(value.first_moment_expected_increment)},
      {"second_moment_expected_increment",
       encode_compression_quantity(value.second_moment_expected_increment)},
      {"first_moment_innovation",
       encode_compression_quantity(value.first_moment_innovation)},
      {"second_moment_innovation",
       encode_compression_quantity(value.second_moment_innovation)},
      {"starred_balance_residual",
       encode_compression_quantity(value.starred_balance_residual)},
      {"mass_defect_corrected_balance_residual",
       encode_compression_quantity(
           value.mass_defect_corrected_balance_residual)},
      {"moment_identity_closure",
       encode_compression_quantity(value.moment_identity_closure)},
      {"cutoffs", std::move(cutoffs)},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_competition(
    const CompetitionAnalysisV1& value) {
  Json cutoffs = Json::array();
  for (const CompetitionCutoffAnalysisV1& cutoff : value.cutoffs) {
    cutoffs.push_back(
        Json{{"cutoff", cutoff.cutoff.to_decimal_string()},
             {"positive_gap_tail_reward",
              encode_compression_quantity(
                  cutoff.positive_gap_tail_reward)},
             {"negative_gap_tail_reward",
              encode_compression_quantity(
                  cutoff.negative_gap_tail_reward)},
             {"gap_association_reward",
              encode_compression_quantity(cutoff.gap_association_reward)},
             {"competition_association_reward",
              encode_compression_quantity(
                  cutoff.competition_association_reward)},
             {"competition_backlog_tail_reward",
              encode_compression_quantity(
                  cutoff.competition_backlog_tail_reward)},
             {"competition_service_tail_reward",
              encode_compression_quantity(
                  cutoff.competition_service_tail_reward)},
             {"direct_competition_association_reward",
              encode_compression_quantity(
                  cutoff.direct_competition_association_reward)},
             {"association_split_closure",
              encode_compression_quantity(
                  cutoff.association_split_closure)},
             {"status", encode_compression_status(cutoff.status)}});
  }
  return Json{
      {"mean_gap", encode_compression_quantity(value.mean_gap)},
      {"mean_absolute_gap",
       encode_compression_quantity(value.mean_absolute_gap)},
      {"mean_competition_scale",
       encode_compression_quantity(value.mean_competition_scale)},
      {"normalized_gap_scale",
       encode_compression_quantity(value.normalized_gap_scale)},
      {"cutoffs", std::move(cutoffs)},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_ties(const TieAnalysisV1& value) {
  Json response = Json::array();
  for (const TieResponsePointV1& point : value.response_by_level) {
    response.push_back(
        Json{{"backlog_level", point.backlog_level.to_decimal_string()},
             {"strict_win_response_component",
              encode_compression_quantity(
                  point.strict_win_response_component)},
             {"tied_service_response_component",
              encode_compression_quantity(
                  point.tied_service_response_component)},
             {"reconstructed_response",
              encode_compression_quantity(point.reconstructed_response)},
             {"observed_response",
              encode_compression_quantity(point.observed_response)},
             {"response_reconstruction_closure",
              encode_compression_quantity(
                  point.response_reconstruction_closure)}});
  }
  return Json{
      {"response_by_level", std::move(response)},
      {"strict_loss_backlog_reward",
       encode_compression_quantity(value.strict_loss_backlog_reward)},
      {"lost_tie_backlog_reward",
       encode_compression_quantity(value.lost_tie_backlog_reward)},
      {"empirical_identity_lhs",
       encode_compression_quantity(value.empirical_identity_lhs)},
      {"empirical_identity_rhs",
       encode_compression_quantity(value.empirical_identity_rhs)},
      {"empirical_identity_closure",
       encode_compression_quantity(value.empirical_identity_closure)},
      {"isolated_server_baseline",
       encode_compression_quantity(value.isolated_server_baseline)},
      {"strict_loss_mean_contribution",
       encode_compression_quantity(value.strict_loss_mean_contribution)},
      {"lost_tie_mean_contribution",
       encode_compression_quantity(value.lost_tie_mean_contribution)},
      {"stationary_mean_reconstruction",
       encode_compression_quantity(value.stationary_mean_reconstruction)},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_compression_analysis(
    const CompressionAnalysisResultV1& value) {
  Json replications = Json::array();
  for (const CompressionReplicationSummaryV1& replication :
       value.replications) {
    replications.push_back(encode_replication_summary(replication));
  }
  Json cutoffs = Json::array();
  for (const CompressionCutoffAnalysisV1& cutoff : value.cutoffs) {
    cutoffs.push_back(encode_cutoff_analysis(cutoff));
  }
  Json encoded{
      {"observation_digest", value.observation_digest.hex()},
      {"analysis_digest", value.analysis_digest.hex()},
      {"source_role", observation_source_role_text(value.source_role)},
      {"warmup_boundary", value.warmup_boundary},
      {"end_boundary", value.end_boundary},
      {"pooled", encode_pooled_moments(value.pooled)},
      {"replications", std::move(replications)},
      {"cutoffs", std::move(cutoffs)},
      {"finite_window", encode_finite_window(value.finite_window)},
      {"competition", encode_competition(value.competition)},
      {"ties", encode_ties(value.ties)},
      {"work",
       Json{{"input_level_rows", value.work.input_level_rows},
            {"input_boundary_rows", value.work.input_boundary_rows},
            {"input_row_bytes", value.work.input_row_bytes},
            {"merged_level_rows", value.work.merged_level_rows},
            {"merged_boundary_rows", value.work.merged_boundary_rows},
            {"merge_key_comparisons", value.work.merge_key_comparisons},
            {"merge_heap_operations", value.work.merge_heap_operations},
            {"point_fit_invocations", value.work.point_fit_invocations},
            {"jackknife_fit_invocations",
             value.work.jackknife_fit_invocations},
            {"top_level_reservation_events",
             value.work.top_level_reservation_events},
            {"analysis_allocation_events",
             value.work.analysis_allocation_events},
            {"peak_retained_top_level_objects",
             value.work.peak_retained_top_level_objects},
            {"estimated_peak_retained_bytes",
             value.work.estimated_peak_retained_bytes}}},
      {"status", encode_compression_status(value.status)}};
  if (value.projection_mode ==
      CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response) {
    encoded["projection_mode"] = "empirical_finite_window_response_v1";
    encoded["empirical_finite_window_response_v1"] =
        value.empirical_finite_window_response
            ? encode_empirical_finite_window_response(
                  *value.empirical_finite_window_response)
            : Json(nullptr);
    encoded["poisson_overshoot_evaluation_v1"] =
        value.poisson_overshoot_evaluation
            ? Json{{"algorithm_id",
                    value.poisson_overshoot_evaluation->algorithm_id},
                   {"algorithm_version",
                    value.poisson_overshoot_evaluation->algorithm_version},
                   {"descriptor_digest",
                    value.poisson_overshoot_evaluation->descriptor_digest
                        .hex()},
                   {"omitted_tail_tolerance",
                    encode_compact_rational(
                        value.poisson_overshoot_evaluation
                            ->omitted_tail_tolerance)},
                   {"maximum_recurrence_steps",
                    value.poisson_overshoot_evaluation
                        ->maximum_recurrence_steps},
                   {"recurrence_steps",
                    value.poisson_overshoot_evaluation->recurrence_steps},
                   {"status",
                    encode_compression_status(
                        value.poisson_overshoot_evaluation->status)}}
            : Json(nullptr);
  }
  return encoded;
}

[[nodiscard]] Json encode_comparison_uncertainty(
    const ErrorSeparationUncertaintyV1& value) {
  return Json{
      {"compression_squared_standard_error",
       encode_compression_quantity(
           value.compression_squared_standard_error)},
      {"finite_window_squared_standard_error",
       encode_compression_quantity(
           value.finite_window_squared_standard_error)},
      {"sampling_squared_standard_error",
       encode_compression_quantity(value.sampling_squared_standard_error)},
      {"transformation_squared_standard_error",
       encode_compression_quantity(
           value.transformation_squared_standard_error)},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_comparison_cutoff(
    const ErrorSeparationCutoffV1& value) {
  return Json{
      {"cutoff", value.cutoff.to_decimal_string()},
      {"compression", encode_compression_quantity(value.compression)},
      {"finite_window_construction",
       encode_compression_quantity(value.finite_window_construction)},
      {"weighted_ensemble_sampling",
       encode_compression_quantity(value.weighted_ensemble_sampling)},
      {"provider_transformation",
       encode_compression_quantity(value.provider_transformation)},
      {"three_term_sum",
       encode_compression_quantity(value.three_term_sum)},
      {"three_term_target",
       encode_compression_quantity(value.three_term_target)},
      {"three_term_closure",
       encode_compression_quantity(value.three_term_closure)},
      {"four_term_sum", encode_compression_quantity(value.four_term_sum)},
      {"four_term_target",
       encode_compression_quantity(value.four_term_target)},
      {"four_term_closure",
       encode_compression_quantity(value.four_term_closure)},
      {"stationary_tail_crosscheck",
       encode_compression_quantity(value.stationary_tail_crosscheck)},
      {"fit_resamples",
       Json{{"eligible_fit_resamples",
             value.fit_resamples.eligible_fit_resamples},
            {"failed_fit_resamples",
             value.fit_resamples.failed_fit_resamples},
            {"unavailable_fit_resamples",
             value.fit_resamples.unavailable_fit_resamples},
            {"unavailable_estimate_resamples",
             value.fit_resamples.unavailable_estimate_resamples}}},
      {"fit_failure_rate",
       encode_compression_quantity(value.fit_failure_rate)},
      {"uncertainty", encode_comparison_uncertainty(value.uncertainty)},
      {"transformation_is_definitionally_zero",
       value.transformation_is_definitionally_zero},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] Json encode_compression_comparison(
    const ThreeRecordErrorSeparationV1& value) {
  Json cutoffs = Json::array();
  for (const ErrorSeparationCutoffV1& cutoff : value.cutoffs) {
    cutoffs.push_back(encode_comparison_cutoff(cutoff));
  }
  return Json{
      {"comparison_version", 1U},
      {"kind", "compression_error_separation"},
      {"experiment_digest", value.experiment_digest.hex()},
      {"decoder_semantics_digest", value.decoder_semantics_digest.hex()},
      {"stationary_observation_digest",
       value.stationary_observation_digest.hex()},
      {"finite_window_observation_digest",
       value.finite_window_observation_digest.hex()},
      {"weighted_ensemble_observation_digest",
       value.weighted_ensemble_observation_digest.hex()},
      {"stationary_analysis_digest",
       value.stationary_analysis_digest.hex()},
      {"finite_window_analysis_digest",
       value.finite_window_analysis_digest.hex()},
      {"weighted_ensemble_analysis_digest",
       value.weighted_ensemble_analysis_digest.hex()},
      {"provider_result_digest",
       value.provider_result_digest.has_value()
           ? Json(value.provider_result_digest->hex())
           : Json(nullptr)},
      {"cutoffs", std::move(cutoffs)},
      {"status", encode_compression_status(value.status)}};
}

[[nodiscard]] std::string_view decoder_profile_status_text(
    const AnalysisDecoderProfileStatusV2 value) noexcept {
  switch (value) {
    case AnalysisDecoderProfileStatusV2::not_applicable:
      return "not_applicable";
    case AnalysisDecoderProfileStatusV2::not_reached: return "not_reached";
    case AnalysisDecoderProfileStatusV2::available: return "available";
    case AnalysisDecoderProfileStatusV2::rejected: return "rejected";
  }
  return "invalid";
}

[[nodiscard]] std::string_view provider_profile_status_text(
    const AnalysisProviderSuppliedProfileStatusV2 value) noexcept {
  switch (value) {
    case AnalysisProviderSuppliedProfileStatusV2::not_applicable:
      return "not_applicable";
    case AnalysisProviderSuppliedProfileStatusV2::not_reached:
      return "not_reached";
    case AnalysisProviderSuppliedProfileStatusV2::available:
      return "available";
    case AnalysisProviderSuppliedProfileStatusV2::rejected:
      return "rejected";
  }
  return "invalid";
}

[[nodiscard]] Json encode_terminal(
    const AnalysisDiagnosticTerminalV2& value) {
  return Json{{"main_status", result_status_text(value.main_status)},
              {"failure_stage",
               value.failure_stage.has_value()
                   ? Json(result_failure_stage_text(*value.failure_stage))
                   : Json(nullptr)},
              {"code", value.code.has_value() ? Json(*value.code)
                                               : Json(nullptr)}};
}

[[nodiscard]] Json encode_decoder_profile(
    const AnalysisDecoderProfileV2& value) {
  return Json{{"status", decoder_profile_status_text(value.status)},
              {"profile", value.profile.has_value()
                              ? encode_supplied_profile(*value.profile)
                              : Json(nullptr)},
              {"reason_code", value.reason_code.has_value()
                                  ? Json(*value.reason_code)
                                  : Json(nullptr)},
              {"provider_result_digest",
               value.provider_result_digest.has_value()
                   ? Json(value.provider_result_digest->hex())
                   : Json(nullptr)},
              {"decoder_semantics_digest",
               value.decoder_semantics_digest.has_value()
                   ? Json(value.decoder_semantics_digest->hex())
                   : Json(nullptr)}};
}

[[nodiscard]] Json encode_provider_supplied_profile(
    const AnalysisProviderSuppliedProfileV2& value) {
  return Json{
      {"status", provider_profile_status_text(value.status)},
      {"profile", value.profile.has_value()
                      ? encode_supplied_profile(*value.profile)
                      : Json(nullptr)},
      {"reason_code", value.reason_code.has_value()
                          ? Json(*value.reason_code)
                          : Json(nullptr)},
      {"observation_digest", value.observation_digest.has_value()
                                 ? Json(value.observation_digest->hex())
                                 : Json(nullptr)},
      {"provider_result_digest", value.provider_result_digest.has_value()
                                     ? Json(value.provider_result_digest->hex())
                                     : Json(nullptr)},
      {"payload_digest", value.payload_digest.has_value()
                             ? Json(value.payload_digest->hex())
                             : Json(nullptr)}};
}

[[nodiscard]] Json encode_artifact(const ResultArtifactDataV1& value) {
  Json root = Json::object();
  root["config"] = value.config_name;
  if (value.status != ResultStatusV1::success) {
    std::string code;
    std::string message;
    if (value.failure.has_value()) {
      code = value.failure->code;
      message = "analysis failed";
    } else if (!value.metrics.empty()) {
      const auto primary = std::ranges::find_if(
          value.metrics, [](const ResultMetricV1& metric) {
            const auto* unavailable =
                std::get_if<UnavailableResultMetricV1>(&metric);
            return unavailable != nullptr &&
                   unavailable->reason_code !=
                       "c27.atomic_result_suppressed";
          });
      const auto& unavailable = std::get<UnavailableResultMetricV1>(
          primary == value.metrics.end() ? value.metrics.front() : *primary);
      code = unavailable.reason_code;
      message = "requested queue metrics unavailable";
    } else {
      code = "metrics_unavailable";
      message = "requested queue metrics unavailable";
    }
    Json error{{"code", std::move(code)}, {"message", std::move(message)}};
    if (value.status == ResultStatusV1::unavailable &&
        value.unavailable_diagnostics) {
      error["response_cutoff"] =
          value.unavailable_diagnostics->response_cutoff.to_decimal_string();
      if (value.report_unavailable_diagnostics) {
        error["unavailable_diagnostics"] =
            encode_unavailable_diagnostics(*value.unavailable_diagnostics);
      }
    }
    root["error"] = std::move(error);
    root["wall_clock_seconds"] = encode_wall_clock(value.wall_clock_times);
    return root;
  }

  if (value.response_curve.has_value()) {
    const ResultResponseCurveV1& curve = *value.response_curve;
    Json response = Json::object();
    response["target"] = encode_compact_label(curve.target.label());
    response["regions"] = Json::array(
        {Json{{"backlog", "0"},
              {"service_probability",
               encode_compact_scalar(curve.backlog_zero)}},
         Json{{"backlog", "1"},
              {"service_probability",
               encode_compact_scalar(curve.backlog_one)}},
         Json{{"backlog", "2"},
              {"service_probability",
               encode_compact_scalar(curve.backlog_two)}},
         Json{{"backlog", ">=3"},
              {"service_probability",
               encode_compact_scalar(curve.backlog_at_least_three)}}});
    root["response_curve"] = std::move(response);
  } else {
    root["response_curve"] = nullptr;
  }
  root["metrics"] = Json::array();
  for (const ResultMetricV1& metric : value.metrics) {
    root["metrics"].push_back(encode_compact_metric(metric));
  }
  root["wall_clock_seconds"] = encode_wall_clock(value.wall_clock_times);
  if (value.output_resources) {
    root["resources"] = encode_resources(value);
  }
  return root;
}

[[nodiscard]] Result<void> validate_diagnostic_supplement_v2(
    const ResultArtifactDataV2& value,
    const bool verify_analysis_projection) {
  auto main_valid = validate_result_data(value.main);
  if (!main_valid) {
    return main_valid;
  }
  if (!value.diagnostic_supplement) {
    return Result<void>::success();
  }

  const AnalysisDiagnosticSupplementV2& supplement =
      *value.diagnostic_supplement;
  if (!supplement.observation() ||
      static_cast<bool>(supplement.analysis()) ==
          supplement.analysis_failure().has_value()) {
    return Result<void>::failure(result_error(
        "c30.result_v2_analysis_outcome_invalid",
        "result-v2 requires an authenticated observation and exactly one compression-analysis outcome"));
  }
  const ValidatedConstructionObservationBundleV1& observation =
      *supplement.observation();
  const ConstructionObservationBundleV1& body = observation.value();
  auto effective_options = effective_compression_analysis_options_v1(
      observation, supplement.analysis_options());
  if (!effective_options) {
    return Result<void>::failure(effective_options.error());
  }
  if (effective_options.value().projection_mode !=
          CompressionAnalysisOptionsV1::ProjectionMode::
              finite_prefix_constant_tail ||
      effective_options.value().ensemble_population_size.has_value()) {
    return Result<void>::failure(result_error(
        "c30.result_v2_analysis_options_invalid",
        "result-v2 is closed to its released finite-prefix analysis options"));
  }
  if (!published_analysis_options_within_limits(effective_options.value())) {
    return Result<void>::failure(result_error(
        "c30.result_v2_analysis_options_limit",
        "compression-analysis options exceed the published bounded defaults"));
  }
  if (supplement.analysis()) {
    const CompressionAnalysisResultV1& analysis = *supplement.analysis();
    auto expected_analysis_digest = compression_analysis_identity_digest_v1(
        observation, effective_options.value());
    if (!expected_analysis_digest) {
      return Result<void>::failure(expected_analysis_digest.error());
    }
    if (analysis.observation_digest != observation.digest() ||
        analysis.analysis_digest != expected_analysis_digest.value() ||
        analysis.source_role != body.source_role ||
        analysis.bindings != body.bindings ||
        analysis.slot_convention != body.slot_convention ||
        analysis.initialization != body.initialization ||
        analysis.warmup_boundary != body.warmup_boundary ||
        analysis.end_boundary != body.end_boundary) {
      return Result<void>::failure(result_error(
          "c30.result_v2_analysis_binding_mismatch",
          "compression analysis metadata or option digest is not bound to its authenticated observation record"));
    }
  } else if (supplement.analysis_failure()->code.empty()) {
    return Result<void>::failure(result_error(
        "c30.result_v2_analysis_outcome_invalid",
        "compression-analysis failure requires a nonempty diagnostic code"));
  }

  if (verify_analysis_projection) {
    // This is the untrusted/arbitrary typed-construction boundary used by the
    // test seam.  Compare the same complete canonical projections that the
    // external reader verifies, including raw replication summaries and work
    // counters.  Production assembly has a separate trusted path: its
    // AnalysisBundle can only be minted by execute_analysis and stores an
    // immutable analyzer result, so it does not pay for a second nonlinear
    // analysis before publication.
    auto recomputed = analyze_compression_observations_v1(
        observation, effective_options.value());
    if (supplement.analysis()) {
      if (!recomputed ||
          encode_compression_analysis(recomputed.value()).dump() !=
              encode_compression_analysis(*supplement.analysis()).dump()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_analysis_verification_failed",
            "the supplied typed compression analysis differs from deterministic recomputation over its authenticated observation and options"));
      }
    } else if (recomputed ||
               encode_diagnostic(recomputed.error()).dump() !=
                   encode_diagnostic(*supplement.analysis_failure()).dump()) {
      return Result<void>::failure(result_error(
          "c30.result_v2_analysis_verification_failed",
          "the supplied typed compression-analysis failure differs from deterministic recomputation over its authenticated observation and options"));
    }
  }

  const AnalysisProviderSuppliedProfileV2& provider_profile =
      supplement.provider_supplied_profile();
  switch (provider_profile.status) {
    case AnalysisProviderSuppliedProfileStatusV2::available:
      if (!provider_profile.profile.has_value() ||
          provider_profile.reason_code.has_value() ||
          !provider_profile.observation_digest.has_value() ||
          !provider_profile.provider_result_digest.has_value() ||
          !provider_profile.payload_digest.has_value() ||
          *provider_profile.observation_digest != observation.digest() ||
          !value.main.surrogate.payload_digest.has_value() ||
          *provider_profile.payload_digest !=
              *value.main.surrogate.payload_digest ||
          !valid_supplied_profile_semantics(*provider_profile.profile)) {
        return Result<void>::failure(result_error(
            "c30.result_v2_provider_profile_shape_invalid",
            "an available provider-supplied profile requires valid coefficients and all authenticated bindings"));
      }
      break;
    case AnalysisProviderSuppliedProfileStatusV2::rejected:
      if (provider_profile.profile.has_value() ||
          !provider_profile.reason_code.has_value() ||
          provider_profile.reason_code->empty() ||
          provider_profile.observation_digest.has_value() ||
          provider_profile.provider_result_digest.has_value() ||
          provider_profile.payload_digest.has_value()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_provider_profile_shape_invalid",
            "a rejected provider-supplied profile requires a nonempty reason only"));
      }
      break;
    case AnalysisProviderSuppliedProfileStatusV2::not_applicable:
      if (provider_profile.profile.has_value() ||
          provider_profile.reason_code.has_value() ||
          provider_profile.observation_digest.has_value() ||
          provider_profile.provider_result_digest.has_value() ||
          provider_profile.payload_digest.has_value()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_provider_profile_shape_invalid",
            "a non-applicable provider-supplied profile carries no values"));
      }
      break;
    case AnalysisProviderSuppliedProfileStatusV2::not_reached:
      if (provider_profile.profile.has_value() ||
          (provider_profile.reason_code.has_value() &&
           provider_profile.reason_code->empty()) ||
          provider_profile.observation_digest.has_value() ||
          provider_profile.provider_result_digest.has_value() ||
          provider_profile.payload_digest.has_value()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_provider_profile_shape_invalid",
            "a provider-supplied profile that was not reached cannot carry profile data or bindings"));
      }
      break;
  }

  const AnalysisDiagnosticTerminalV2& terminal = supplement.terminal();
  if (terminal.main_status != value.main.status ||
      terminal.failure_stage.has_value() != value.main.failure.has_value() ||
      (value.main.failure.has_value() &&
       terminal.failure_stage !=
           std::optional<ResultFailureStageV1>(value.main.failure->stage)) ||
      (value.main.failure.has_value() &&
       terminal.code != std::optional<std::string>(value.main.failure->code)) ||
      (value.main.status == ResultStatusV1::success &&
       terminal.code.has_value()) ||
      (value.main.status == ResultStatusV1::unavailable &&
       (!terminal.code.has_value() || terminal.code->empty()))) {
    return Result<void>::failure(result_error(
        "c30.result_v2_terminal_binding_mismatch",
        "diagnostic terminal context does not match the main result"));
  }

  const AnalysisDecoderProfileV2& decoder = supplement.decoder_profile();
  switch (decoder.status) {
    case AnalysisDecoderProfileStatusV2::available:
      if (!decoder.profile.has_value() || decoder.reason_code.has_value() ||
          !decoder.provider_result_digest.has_value() ||
          !decoder.decoder_semantics_digest.has_value() ||
          !valid_supplied_profile_semantics(*decoder.profile)) {
        return Result<void>::failure(result_error(
            "c30.result_v2_decoder_profile_shape_invalid",
            "an available decoder profile requires its supplied profile and both decoder bindings"));
      }
      break;
    case AnalysisDecoderProfileStatusV2::rejected:
      if (decoder.profile.has_value() || !decoder.reason_code.has_value() ||
          decoder.reason_code->empty() ||
          decoder.provider_result_digest.has_value() ||
          decoder.decoder_semantics_digest.has_value()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_decoder_profile_shape_invalid",
            "a rejected decoder profile requires a nonempty reason and no profile"));
      }
      break;
    case AnalysisDecoderProfileStatusV2::not_applicable:
      if (decoder.profile.has_value() || decoder.reason_code.has_value() ||
          decoder.provider_result_digest.has_value() ||
          decoder.decoder_semantics_digest.has_value()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_decoder_profile_shape_invalid",
            "a non-applicable decoder profile carries no profile or reason"));
      }
      break;
    case AnalysisDecoderProfileStatusV2::not_reached:
      if (decoder.profile.has_value() ||
          (decoder.reason_code.has_value() &&
           decoder.reason_code->empty()) ||
          decoder.provider_result_digest.has_value() ||
          decoder.decoder_semantics_digest.has_value()) {
        return Result<void>::failure(result_error(
            "c30.result_v2_decoder_profile_shape_invalid",
            "a decoder profile that was not reached cannot carry a profile"));
      }
      break;
  }
  if (provider_profile.status ==
          AnalysisProviderSuppliedProfileStatusV2::available &&
      decoder.status == AnalysisDecoderProfileStatusV2::available &&
      provider_profile.provider_result_digest !=
          decoder.provider_result_digest) {
    return Result<void>::failure(result_error(
        "c30.result_v2_profile_provider_binding_mismatch",
        "provider-supplied and decoder-consumed profiles name different provider results"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_observed_result_v3(
    const ResultArtifactDataV3& value,
    const bool verify_analysis_projection) {
  if (value.provider.provider_id != "full_orbit_framework_sampler" ||
      value.provider.provider_version != "1.4.0" ||
      value.config_name.empty() || value.worker_count == 0U ||
      value.model.fingerprint != value.input_fingerprints.model ||
      value.analysis.fingerprint != value.input_fingerprints.analysis) {
    return Result<void>::failure(result_error(
        "c32.result_v3_provenance_invalid",
        "result-v3 requires the CP09 provider and input-bound run provenance"));
  }
  if (!valid_status(value.status) ||
      (value.status == ResultStatusV1::failed) !=
          value.failure.has_value() ||
      (value.failure &&
       (!valid_failure_stage(value.failure->stage) ||
        value.failure->code.empty()))) {
    return Result<void>::failure(result_error(
        "c32.result_v3_terminal_invalid",
        "result-v3 Failed requires one typed failure and other terminal statuses forbid it"));
  }
  const bool request_construction_failure =
      value.failure.has_value() &&
      value.failure->stage == ResultFailureStageV1::request_construction;
  if (value.build_request_identity.has_value() ==
      request_construction_failure) {
    return Result<void>::failure(result_error(
        "c32.result_v3_build_request_identity_invalid",
        "result-v3 build-request provenance is absent exactly when request construction failed"));
  }
  if (request_construction_failure &&
      (value.diagnostic_supplement || value.provider_result_digest ||
       value.framework_prediction)) {
    return Result<void>::failure(result_error(
        "c32.result_v3_pre_observation_shape_invalid",
        "request construction failed before a provider result or diagnostic observation supplement could exist"));
  }
  if (value.build_request_identity) {
    if (value.build_request_identity->build_seed.master_seed() !=
            value.master_seed ||
        !value.build_request_identity->build_seed.is_bound_to(
            value.build_request_identity->build_identity_digest)) {
      return Result<void>::failure(result_error(
          "c32.result_v3_seed_binding_mismatch",
          "result-v3 build seed is not bound to its build identity"));
    }
  }

  // A valid plan can fail before a provider-result-v3 envelope (and hence an
  // observation) exists.  Preserve that typed terminal as result-v3 rather
  // than making publication itself fail.  Once an observation exists, its
  // authenticated provider-result digest and complete diagnostic supplement
  // remain mandatory; unavailable and successful terminals can only arise
  // from that observation-retaining path.
  if (!value.diagnostic_supplement) {
    const bool pre_observation_stage =
        value.failure.has_value() &&
        (value.failure->stage == ResultFailureStageV1::request_construction ||
         value.failure->stage == ResultFailureStageV1::producer_execution ||
         value.failure->stage == ResultFailureStageV1::wire_parse ||
         value.failure->stage ==
             ResultFailureStageV1::build_contract_validation);
    if (value.status != ResultStatusV1::failed || !pre_observation_stage ||
        value.provider_result_digest.has_value() ||
        value.framework_prediction) {
      return Result<void>::failure(result_error(
          "c32.result_v3_pre_observation_shape_invalid",
          "only a typed pre-observation failure may omit the diagnostic supplement and provider-result digest"));
    }
    return Result<void>::success();
  }

  const AnalysisDiagnosticSupplementV2& supplement =
      *value.diagnostic_supplement;
  if (!supplement.observation() ||
      (supplement.analysis().get() == nullptr) ==
          !supplement.analysis_failure().has_value() ||
      static_cast<bool>(value.framework_prediction) !=
          static_cast<bool>(supplement.analysis()) ||
      supplement.terminal().main_status != value.status ||
      supplement.provider_supplied_profile().status !=
          AnalysisProviderSuppliedProfileStatusV2::not_applicable ||
      supplement.decoder_profile().status !=
          AnalysisDecoderProfileStatusV2::not_applicable ||
      !value.provider_result_digest.has_value() ||
      !supplement.source_provider_result_digest().has_value() ||
      *supplement.source_provider_result_digest() !=
          *value.provider_result_digest) {
    return Result<void>::failure(result_error(
        "c32.result_v3_observed_shape_invalid",
        "result-v3 requires one authenticated observation-analysis outcome and no deployed provider or decoder profile"));
  }
  if (value.status == ResultStatusV1::success) {
    if (!supplement.analysis() || supplement.analysis_failure().has_value() ||
        supplement.terminal().failure_stage.has_value() ||
        supplement.terminal().code.has_value()) {
      return Result<void>::failure(result_error(
          "c32.result_v3_terminal_invalid",
          "successful result-v3 requires a successful analysis and an empty failure terminal"));
    }
  } else if (value.status == ResultStatusV1::failed) {
    if (!supplement.terminal().failure_stage.has_value() ||
        !supplement.terminal().code.has_value() ||
        *supplement.terminal().failure_stage != value.failure->stage ||
        *supplement.terminal().code != value.failure->code) {
      return Result<void>::failure(result_error(
          "c32.result_v3_terminal_invalid",
          "failed result-v3 terminal does not match its typed outer failure"));
    }
  } else if (supplement.terminal().failure_stage.has_value() ||
             !supplement.terminal().code.has_value() ||
             supplement.terminal().code->empty()) {
    return Result<void>::failure(result_error(
        "c32.result_v3_terminal_invalid",
        "unavailable result-v3 requires a reason code but no failure stage"));
  }
  const ValidatedConstructionObservationBundleV1& observation =
      *supplement.observation();
  // CP09 intentionally binds the physical observation to the route's
  // cutoff-free trajectory request, not to the full projection-bearing build
  // request.  The registered provider hook validates that trajectory binding
  // before AnalysisBundle is minted; the outer provenance and common report
  // independently retain the complete build-request digest.  Equating the
  // two digests here would make every valid raw observation unpublishable.
  auto effective_options = effective_compression_analysis_options_v1(
      observation, supplement.analysis_options());
  if (!effective_options) {
    return Result<void>::failure(effective_options.error());
  }
  if (effective_options.value().projection_mode !=
          CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response ||
      !effective_options.value().ensemble_population_size.has_value() ||
      effective_options.value().ensemble_population_size->is_zero() ||
      effective_options.value().run_diagnostic_fits ||
      effective_options.value().compute_delete_one_replication_jackknife ||
      effective_options.value().stationary_coefficients_established ||
      effective_options.value().prefix_preservation_established ||
      !effective_options.value().provider_supplied_profiles.empty() ||
      !published_analysis_options_within_limits(effective_options.value())) {
    return Result<void>::failure(result_error(
        "c32.result_v3_analysis_options_invalid",
        "result-v3 requires resource-admitted empirical finite-window projection options"));
  }
  const CompressionAnalysisResultV1* analysis = supplement.analysis().get();
  auto expected_digest = compression_analysis_identity_digest_v1(
      observation, effective_options.value());
  if (!expected_digest) {
    return Result<void>::failure(expected_digest.error());
  }
  if (analysis != nullptr &&
      (analysis->projection_mode !=
          CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response ||
       !analysis->empirical_finite_window_response ||
       analysis->observation_digest != observation.digest() ||
       analysis->analysis_digest != expected_digest.value() ||
       analysis->source_role != observation.value().source_role ||
       analysis->bindings != observation.value().bindings ||
       analysis->slot_convention != observation.value().slot_convention ||
       analysis->initialization != observation.value().initialization ||
       analysis->warmup_boundary != observation.value().warmup_boundary ||
       analysis->end_boundary != observation.value().end_boundary)) {
    return Result<void>::failure(result_error(
        "c32.result_v3_analysis_binding_mismatch",
        "the empirical finite-window analysis is not bound to its authenticated observation"));
  }
  if (analysis != nullptr) {
    const FrameworkEmpiricalPredictionV1& prediction =
        *value.framework_prediction;
    if (prediction.observation_digest != observation.digest() ||
        prediction.analysis_digest != analysis->analysis_digest ||
        prediction.target_id != observation.value().bindings.target.target_id) {
      return Result<void>::failure(result_error(
          "c32.framework_prediction_binding_mismatch",
          "the framework prediction is not bound to its authenticated observation, analysis, and target"));
    }
    if (verify_analysis_projection &&
        prediction != derive_framework_empirical_prediction_v1(
                          observation, *analysis,
                          effective_options.value())) {
      return Result<void>::failure(result_error(
          "c32.framework_prediction_verification_failed",
          "the framework prediction differs from deterministic recomputation over the authenticated raw response"));
    }
  }
  if (analysis != nullptr &&
      effective_options.value().poisson_overshoot.has_value() !=
          analysis->poisson_overshoot_evaluation.has_value()) {
    return Result<void>::failure(result_error(
        "c32.result_v3_poisson_evaluator_binding_mismatch",
        "the Poisson evaluator report does not match the authenticated analysis options"));
  }
  if (analysis != nullptr && effective_options.value().poisson_overshoot) {
    const auto& configured = *effective_options.value().poisson_overshoot;
    const auto& report = *analysis->poisson_overshoot_evaluation;
    if (report.algorithm_id !=
            "certified_rational_poisson_overshoot_v1" ||
        report.algorithm_version != 1U ||
        report.descriptor_digest != configured.descriptor_digest ||
        report.omitted_tail_tolerance !=
            configured.omitted_tail_tolerance ||
        report.maximum_recurrence_steps !=
            configured.maximum_recurrence_steps ||
        report.recurrence_steps > report.maximum_recurrence_steps) {
      return Result<void>::failure(result_error(
          "c32.result_v3_poisson_evaluator_binding_mismatch",
          "the Poisson evaluator report is not bound to its registered descriptor and numerical policy"));
    }
  }
  if (analysis != nullptr) {
    const EmpiricalFiniteWindowResponseV1& profile =
        *analysis->empirical_finite_window_response;
    if (profile.source_observation_digest != observation.digest() ||
        profile.source_role != observation.value().source_role ||
        profile.bindings != observation.value().bindings ||
        profile.warmup_boundary != observation.value().warmup_boundary ||
        profile.end_boundary != observation.value().end_boundary ||
        profile.reporting_block_boundaries !=
            observation.value().reporting_block_boundaries ||
        profile.ensemble_population_size !=
            effective_options.value().ensemble_population_size ||
        profile.configured_replications !=
            observation.value().replications.size() ||
        profile.observed_point_count !=
            BigNat{profile.observed_levels.size()} ||
        profile.interpretation !=
            EmpiricalFiniteWindowInterpretationV1::finite_window ||
        profile.tail_completion !=
            EmpiricalFiniteWindowTailCompletionV1::none) {
      return Result<void>::failure(result_error(
          "c32.result_v3_profile_binding_mismatch",
          "the sparse finite-window profile is incomplete or bound to different observation metadata"));
    }
  }
  if (verify_analysis_projection) {
    auto recomputed = analyze_compression_observations_v1(
        observation, effective_options.value());
    const bool agrees =
        analysis != nullptr
            ? recomputed &&
                  encode_compression_analysis(recomputed.value()).dump() ==
                      encode_compression_analysis(*analysis).dump()
            : !recomputed && supplement.analysis_failure().has_value() &&
                  encode_diagnostic(recomputed.error()).dump() ==
                      encode_diagnostic(*supplement.analysis_failure()).dump();
    if (!agrees) {
      return Result<void>::failure(result_error(
          "c32.result_v3_analysis_verification_failed",
          "the empirical finite-window analysis differs from deterministic recomputation"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::string> canonical_result_v2_json(
    const ResultArtifactV2& artifact) {
  const ResultArtifactDataV2& value = artifact.value();
  auto valid = validate_diagnostic_supplement_v2(
      value, false /* trusted immutable ResultArtifactV2 */);
  if (!valid) {
    return Result<std::string>::failure(valid.error());
  }
  for (const ResultMetricV1& metric : value.main.metrics) {
    const auto* established = std::get_if<EstablishedResultMetricV1>(&metric);
    if (established != nullptr &&
        std::holds_alternative<ResultCanonicalValueV1>(established->value)) {
      return fail_result<std::string>(
          "c27.metric_display_projection_unavailable",
          "the requested metric has no scientific compact-output projection");
    }
  }

  try {
    Json root = Json::object();
    root["result_version"] = 2U;
    root["status"] = result_status_text(value.main.status);
    root["failure"] = encode_result_failure(value.main.failure);
    root["main_result"] = encode_artifact(value.main);

    std::string encoded = root.dump();
    if (encoded.empty() || encoded.back() != '}') {
      return fail_result<std::string>(
          "c30.result_v2_json_encoding_failed",
          "the validated result-v2 wrapper could not be encoded");
    }
    encoded.pop_back();
    encoded += ",\"diagnostic_supplement\":";
    if (!value.diagnostic_supplement) {
      encoded += "null}";
    } else {
      const AnalysisDiagnosticSupplementV2& supplement =
          *value.diagnostic_supplement;
      Json diagnostic = Json::object();
      diagnostic["terminal"] = encode_terminal(supplement.terminal());
      diagnostic["provider_supplied_profile"] =
          encode_provider_supplied_profile(
              supplement.provider_supplied_profile());
      diagnostic["decoder_profile"] =
          encode_decoder_profile(supplement.decoder_profile());
      auto effective_options = effective_compression_analysis_options_v1(
          *supplement.observation(), supplement.analysis_options());
      if (!effective_options) {
        return Result<std::string>::failure(effective_options.error());
      }
      if (!published_analysis_options_within_limits(
              effective_options.value())) {
        return fail_result<std::string>(
            "c30.result_v2_analysis_options_limit",
            "compression-analysis options exceed the published bounded defaults");
      }
      diagnostic["analysis_options"] =
          encode_compression_analysis_options(effective_options.value());
      diagnostic["analysis"] =
          supplement.analysis()
              ? encode_compression_analysis(*supplement.analysis())
              : Json(nullptr);
      diagnostic["analysis_failure"] =
          supplement.analysis_failure().has_value()
              ? encode_diagnostic(*supplement.analysis_failure())
              : Json(nullptr);
      diagnostic["observation_bundle_digest"] =
          supplement.observation()->digest().hex();
      std::string diagnostic_prefix = diagnostic.dump();
      if (diagnostic_prefix.empty() || diagnostic_prefix.back() != '}') {
        return fail_result<std::string>(
            "c30.result_v2_json_encoding_failed",
            "the result-v2 diagnostic wrapper could not be encoded");
      }
      diagnostic_prefix.pop_back();
      encoded += diagnostic_prefix;
      encoded += ",\"observation_bundle\":";
      auto observation_bytes =
          canonical_construction_observation_bundle_body_bytes_v1(
              supplement.observation()->value());
      if (!observation_bytes) {
        return Result<std::string>::failure(observation_bytes.error());
      }
      const auto* data = reinterpret_cast<const char*>(
          observation_bytes.value().data());
      encoded.append(data, observation_bytes.value().size());
      encoded += "}}";
    }
    if (encoded.size() >
        default_result_artifact_parse_limits_v2().maximum_bytes) {
      return fail_result<std::string>(
          "c30.result_v2_output_limit",
          "canonical result-v2 output exceeds the framework's published reader byte limit");
    }
#if !defined(NDEBUG) || defined(MWPERF_C27_TEST_SEAMS)
    if (const auto schema_failure =
            validate_result_v2_json_against_published_schema(encoded)) {
      return fail_result<std::string>(
          "c30.result_v2_schema_self_validation_failed",
          "canonical result-v2 output violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message);
    }
#endif
    return Result<std::string>::success(std::move(encoded));
  } catch (const nlohmann::json::exception&) {
    return fail_result<std::string>(
        "c30.result_v2_json_encoding_failed",
        "the validated result-v2 could not be encoded as strict UTF-8 JSON");
  } catch (const std::bad_alloc&) {
    return fail_result<std::string>(
        "c30.result_v2_output_limit",
        "canonical result-v2 output could not be allocated within process resources");
  }
}

[[nodiscard]] Json encode_result_v3_provenance(
    const ResultArtifactDataV3& value) {
  Json build_request = nullptr;
  if (value.build_request_identity) {
    const ResultBuildRequestIdentityV1& request =
        *value.build_request_identity;
    build_request =
        Json{{"build_identity_digest",
              request.build_identity_digest.digest().hex()},
             {"build_request_digest",
              request.build_request_digest.value().hex()},
             {"rng_version", request.build_seed.rng_version()}};
  }
  return Json{
      {"config", value.config_name},
      {"input_fingerprints",
       Json{{"model", value.input_fingerprints.model.hex()},
            {"analysis", value.input_fingerprints.analysis.hex()},
            {"combined", value.input_fingerprints.combined.hex()}}},
      {"provider",
       Json{{"provider_id", value.provider.provider_id},
            {"provider_version", value.provider.provider_version},
            {"scientific_contract_digest",
             value.provider_digest.value().hex()}}},
      {"provider_result_digest",
       value.provider_result_digest
           ? Json(value.provider_result_digest->hex())
           : Json(nullptr)},
      {"master_seed", std::to_string(value.master_seed.value())},
      {"build_request", std::move(build_request)},
      {"model",
       Json{{"schema_version", value.model.schema_version},
            {"fingerprint", value.model.fingerprint.hex()}}},
      {"analysis",
       Json{{"schema_version", value.analysis.schema_version},
            {"fingerprint", value.analysis.fingerprint.hex()}}},
      {"wall_clock_seconds", encode_wall_clock(value.wall_clock_times)},
      {"worker_count", value.worker_count}};
}

[[nodiscard]] std::string_view framework_prediction_availability_text(
    const FrameworkPredictionAvailabilityV1 value) noexcept {
  return value == FrameworkPredictionAvailabilityV1::available
             ? std::string_view("available")
             : std::string_view("unavailable");
}

[[nodiscard]] Json encode_framework_prediction_quantity(
    const FrameworkPredictionQuantityV1& value) {
  return Json{
      {"status", framework_prediction_availability_text(value.availability)},
      {"value", value.value ? encode_compact_rational(*value.value)
                            : Json(nullptr)},
      {"reason_code", value.reason_code ? Json(*value.reason_code)
                                         : Json(nullptr)}};
}

[[nodiscard]] Json encode_framework_empirical_prediction(
    const FrameworkEmpiricalPredictionV1& value) {
  Json response_points = Json::array();
  for (const FrameworkPredictionResponsePointV1& point :
       value.response_points) {
    response_points.push_back(
        Json{{"level", point.backlog_level.to_decimal_string()},
             {"observed_response",
              encode_compression_numerical_value(point.observed_response)},
             {"observation_status",
              empirical_point_status_text(point.observation_status)},
             {"role", point.constant_tail_anchor
                          ? "finite_prefix_and_constant_tail_anchor"
                          : "finite_prefix"}});
  }
  Json pmf = Json::array();
  for (const FrameworkPredictionPmfPointV1& point : value.stationary_pmf) {
    pmf.push_back(
        Json{{"level", point.backlog_level.to_decimal_string()},
             {"probability",
              encode_framework_prediction_quantity(point.probability)}});
  }
  Json poisson_reconstruction = nullptr;
  if (value.poisson_arrival_reconstruction) {
    const FrameworkPoissonArrivalReconstructionV1& reconstruction =
        *value.poisson_arrival_reconstruction;
    Json prefix = Json::array();
    for (const FrameworkPoissonArrivalPointV1& point :
         reconstruction.probability_prefix) {
      prefix.push_back(
          Json{{"arrival_count", point.arrival_count.to_decimal_string()},
               {"probability",
                encode_compression_numerical_value(point.probability)}});
    }
    poisson_reconstruction = Json{
        {"algorithm_id", reconstruction.algorithm_id},
        {"algorithm_version", reconstruction.algorithm_version},
        {"descriptor_digest", reconstruction.descriptor_digest.hex()},
        {"law_support", reconstruction.support_unbounded
                            ? "infinite_not_truncated"
                            : "point_mass_zero"},
        {"configured_rate_treatment", "exact_declarative_rational"},
        {"operational_rate_treatment",
         "authenticated_sampling_parameter_only"},
        {"projection_role", "finite_cut_recurrence_coefficients"},
        {"represented_through",
         reconstruction.represented_through.to_decimal_string()},
        {"probability_prefix", std::move(prefix)},
        {"omitted_probability",
         encode_compression_numerical_value(
             reconstruction.omitted_probability)},
        {"omitted_first_raw_moment",
         encode_compression_numerical_value(
             reconstruction.omitted_first_raw_moment)},
        {"omitted_second_raw_moment",
         encode_compression_numerical_value(
             reconstruction.omitted_second_raw_moment)},
        {"omitted_third_raw_moment",
         encode_compression_numerical_value(
             reconstruction.omitted_third_raw_moment)},
        {"exact_first_raw_moment",
         encode_compact_rational(reconstruction.exact_first_raw_moment)},
        {"exact_second_raw_moment",
         encode_compact_rational(reconstruction.exact_second_raw_moment)},
        {"exact_third_raw_moment",
         encode_compact_rational(reconstruction.exact_third_raw_moment)},
        {"exponential_absolute_tolerance",
         encode_compact_rational(
             reconstruction.exponential_absolute_tolerance)},
        {"recurrence_steps", reconstruction.recurrence_steps}};
  }
  Json encoded{
      {"method_id", "framework_empirical_constant_last_observed_v1"},
      {"method_version",
       value.poisson_arrival_reconstruction ? 2U : 1U},
      {"calculation_status",
       framework_prediction_availability_text(value.calculation_status)},
      {"calculation_reason_code",
       value.calculation_reason_code ? Json(*value.calculation_reason_code)
                                     : Json(nullptr)},
      {"observation_digest", value.observation_digest.hex()},
      {"analysis_digest", value.analysis_digest.hex()},
      {"target_id", encode_compact_label(value.target_id.label())},
      {"response_treatment",
       Json{{"observed_complete_through",
             value.observed_complete_through
                 ? Json(value.observed_complete_through->to_decimal_string())
                 : Json(nullptr)},
            {"prefix_cutoff",
             value.prefix_cutoff
                 ? Json(value.prefix_cutoff->to_decimal_string())
                 : Json(nullptr)},
            {"constant_tail_from",
             value.constant_tail_from
                 ? Json(value.constant_tail_from->to_decimal_string())
                 : Json(nullptr)},
            {"completion_policy", "constant_last_observed"},
            {"unobserved_levels",
             "constant_equal_to_last_observed_response"},
            {"empirical_zero_or_one",
             "retained_as_observed_coefficient"},
            {"structural_zero", "mu_0_equals_zero"},
            {"coefficient_value_treatment",
             "exact_dyadic_point_estimate_with_absolute_error_retained"},
            {"numerical_enclosures_present",
             value.response_has_numerical_enclosures},
            {"points", std::move(response_points)}}},
      {"stationary",
       Json{{"interpretation",
             value.poisson_arrival_reconstruction
                 ? "empirical_plugin_prediction_conditional_on_exact_dyadic_response_and_certified_poisson_representative"
                 : "empirical_plugin_prediction_conditional_on_exact_dyadic_response_centers"},
            {"physical_metric_claim",
             "not_established_source_absolute_error_bounds_retained"},
            {"pmf", std::move(pmf)},
            {"remaining_tail_probability",
             encode_framework_prediction_quantity(
                 value.remaining_tail_probability)},
            {"empty_probability",
             encode_framework_prediction_quantity(value.empty_probability)},
            {"first_backlog_moment",
             encode_framework_prediction_quantity(
                 value.first_backlog_moment)},
            {"second_backlog_moment",
             encode_framework_prediction_quantity(
                 value.second_backlog_moment)},
            {"mean_sojourn",
             encode_framework_prediction_quantity(value.mean_sojourn)},
            {"arrival_mean",
             encode_framework_prediction_quantity(value.arrival_mean)}}}};
  if (value.poisson_arrival_reconstruction) {
    Json stationary = std::move(encoded["stationary"]);
    encoded.erase("stationary");
    encoded["poisson_arrival_reconstruction_v1"] =
        std::move(poisson_reconstruction);
    encoded["stationary"] = std::move(stationary);
  }
  return encoded;
}

// Result-v3 method version 1 deliberately reported analytic Poisson arrivals
// as unavailable.  Retain a byte-level verifier for those saved artifacts so
// the decoder-only repair does not invalidate authenticated observations that
// can now be interpreted by method version 2.
[[nodiscard]] Json encode_legacy_poisson_framework_prediction_v1(
    const FrameworkEmpiricalPredictionV1& current) {
  Json encoded = encode_framework_empirical_prediction(current);
  encoded["method_version"] = 1U;
  encoded.erase("poisson_arrival_reconstruction_v1");
  encoded["calculation_status"] = "unavailable";
  encoded["calculation_reason_code"] =
      "exact_target_arrival_marginal_unavailable";
  encoded["stationary"]["interpretation"] =
      "empirical_plugin_prediction_conditional_on_exact_dyadic_response_centers";
  encoded["stationary"]["pmf"] = Json::array();
  const Json unavailable{
      {"status", "unavailable"},
      {"value", nullptr},
      {"reason_code", "exact_target_arrival_marginal_unavailable"}};
  for (const std::string_view name : {
           std::string_view("remaining_tail_probability"),
           std::string_view("empty_probability"),
           std::string_view("first_backlog_moment"),
           std::string_view("second_backlog_moment"),
           std::string_view("mean_sojourn")}) {
    encoded["stationary"][std::string(name)] = unavailable;
  }
  return encoded;
}

[[nodiscard]] Result<std::string> canonical_result_v3_json(
    const ResultArtifactV3& artifact) {
  const ResultArtifactDataV3& value = artifact.value();
  auto valid = validate_observed_result_v3(
      value, false /* trusted immutable execute_analysis projection */);
  if (!valid) {
    return Result<std::string>::failure(valid.error());
  }

  try {
    Json root = Json::object();
    root["result_version"] = 3U;
    root["status"] = result_status_text(value.status);
    root["failure"] = encode_result_failure(value.failure);
    root["result_kind"] =
        value.status == ResultStatusV1::success
            ? Json("observed")
            : Json(result_status_text(value.status));
    root["main_result"] =
        value.framework_prediction
            ? encode_framework_empirical_prediction(
                  *value.framework_prediction)
            : Json(nullptr);
    root["provenance"] = encode_result_v3_provenance(value);

    std::string encoded = root.dump();
    if (encoded.empty() || encoded.back() != '}') {
      return fail_result<std::string>(
          "c32.result_v3_json_encoding_failed",
          "the validated result-v3 wrapper could not be encoded");
    }
    encoded.pop_back();
    encoded += ",\"diagnostic_supplement\":";
    if (!value.diagnostic_supplement) {
      encoded += "null}";
    } else {
      const AnalysisDiagnosticSupplementV2& supplement =
          *value.diagnostic_supplement;
      Json diagnostic = Json::object();
      diagnostic["terminal"] = encode_terminal(supplement.terminal());
      diagnostic["provider_supplied_profile"] =
          encode_provider_supplied_profile(
              supplement.provider_supplied_profile());
      diagnostic["decoder_profile"] =
          encode_decoder_profile(supplement.decoder_profile());
      auto effective_options = effective_compression_analysis_options_v1(
          *supplement.observation(), supplement.analysis_options());
      if (!effective_options) {
        return Result<std::string>::failure(effective_options.error());
      }
      if (!published_analysis_options_within_limits(
              effective_options.value())) {
        return fail_result<std::string>(
            "c32.result_v3_analysis_options_limit",
            "empirical finite-window analysis options exceed published resource limits");
      }
      diagnostic["analysis_options"] =
          encode_compression_analysis_options(effective_options.value());
      diagnostic["analysis"] =
          supplement.analysis()
              ? encode_compression_analysis(*supplement.analysis())
              : Json(nullptr);
      diagnostic["analysis_failure"] =
          supplement.analysis_failure()
              ? encode_diagnostic(*supplement.analysis_failure())
              : Json(nullptr);
      diagnostic["observation_bundle_digest"] =
          supplement.observation()->digest().hex();
      std::string diagnostic_prefix = diagnostic.dump();
      if (diagnostic_prefix.empty() || diagnostic_prefix.back() != '}') {
        return fail_result<std::string>(
            "c32.result_v3_json_encoding_failed",
            "the result-v3 diagnostic wrapper could not be encoded");
      }
      diagnostic_prefix.pop_back();
      encoded += diagnostic_prefix;
      encoded += ",\"observation_bundle\":";
      auto observation_bytes =
          canonical_construction_observation_bundle_body_bytes_v1(
              supplement.observation()->value());
      if (!observation_bytes) {
        return Result<std::string>::failure(observation_bytes.error());
      }
      const auto* data = reinterpret_cast<const char*>(
          observation_bytes.value().data());
      encoded.append(data, observation_bytes.value().size());
      encoded += "}}";
    }

    if (encoded.size() >
        default_result_artifact_parse_limits_v2().maximum_bytes) {
      return fail_result<std::string>(
          "c32.result_v3_output_limit",
          "canonical result-v3 output exceeds the published byte limit");
    }
#if !defined(NDEBUG) || defined(MWPERF_C27_TEST_SEAMS)
    if (const auto schema_failure =
            validate_result_v3_json_against_published_schema(encoded)) {
      return fail_result<std::string>(
          "c32.result_v3_schema_self_validation_failed",
          "canonical result-v3 output violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message);
    }
#endif
    return Result<std::string>::success(std::move(encoded));
  } catch (const nlohmann::json::exception&) {
    return fail_result<std::string>(
        "c32.result_v3_json_encoding_failed",
        "the validated result-v3 could not be encoded as strict UTF-8 JSON");
  } catch (const std::bad_alloc&) {
    return fail_result<std::string>(
        "c32.result_v3_output_limit",
        "canonical result-v3 output could not be allocated within process resources");
  }
}

[[nodiscard]] Result<std::string> canonical_result_json(
    const ResultArtifact& artifact) {
  auto valid = validate_result_data(artifact.value());
  if (!valid) {
    return Result<std::string>::failure(valid.error());
  }
  for (const ResultMetricV1& metric : artifact.value().metrics) {
    const auto* established =
        std::get_if<EstablishedResultMetricV1>(&metric);
    if (established != nullptr &&
        std::holds_alternative<ResultCanonicalValueV1>(established->value)) {
      return fail_result<std::string>(
          "c27.metric_display_projection_unavailable",
          "the requested metric has no scientific compact-output projection");
    }
  }
  try {
    std::string encoded =
        encode_artifact(artifact.value())
            .dump(2, ' ', false, nlohmann::json::error_handler_t::strict);
#if !defined(NDEBUG) || defined(MWPERF_C27_TEST_SEAMS)
    if (const auto schema_failure =
            validate_result_json_against_published_schema(encoded)) {
      return fail_result<std::string>(
          "c27.result_schema_self_validation_failed",
          "canonical result-v1 output violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message);
    }
#endif
    return Result<std::string>::success(std::move(encoded));
  } catch (const nlohmann::json::exception&) {
    return fail_result<std::string>(
        "c27.result_json_encoding_failed",
        "the validated result could not be encoded as strict UTF-8 JSON");
  }
}

[[nodiscard]] bool exact_object_shape(
    const Json& value,
    const std::initializer_list<std::string_view> keys) {
  if (!value.is_object() || value.size() != keys.size()) {
    return false;
  }
  return std::ranges::all_of(keys, [&value](const std::string_view key) {
    return value.contains(std::string(key));
  });
}

[[nodiscard]] Result<ResultStatusV1> parse_result_status_v2(
    const Json& value) {
  if (!value.is_string()) {
    return fail_result<ResultStatusV1>(
        "c30.result_v2_status_invalid", "result-v2 status must be a string");
  }
  const std::string& text = value.get_ref<const std::string&>();
  if (text == "success") {
    return Result<ResultStatusV1>::success(ResultStatusV1::success);
  }
  if (text == "unavailable") {
    return Result<ResultStatusV1>::success(ResultStatusV1::unavailable);
  }
  if (text == "failed") {
    return Result<ResultStatusV1>::success(ResultStatusV1::failed);
  }
  return fail_result<ResultStatusV1>(
      "c30.result_v2_status_invalid", "result-v2 status is not recognized");
}

[[nodiscard]] std::optional<ResultFailureStageV1> parse_failure_stage_v2(
    const std::string_view text) noexcept {
  if (text == "request_construction") {
    return ResultFailureStageV1::request_construction;
  }
  if (text == "producer_execution") {
    return ResultFailureStageV1::producer_execution;
  }
  if (text == "wire_parse") return ResultFailureStageV1::wire_parse;
  if (text == "build_contract_validation") {
    return ResultFailureStageV1::build_contract_validation;
  }
  if (text == "payload_adaptation") {
    return ResultFailureStageV1::payload_adaptation;
  }
  if (text == "plug_binding") return ResultFailureStageV1::plug_binding;
  if (text == "v0_audit") return ResultFailureStageV1::v0_audit;
  if (text == "initial_law") return ResultFailureStageV1::initial_law;
  if (text == "backend") return ResultFailureStageV1::backend;
  if (text == "certificate") return ResultFailureStageV1::certificate;
  if (text == "result_assembly") return ResultFailureStageV1::result_assembly;
  return std::nullopt;
}

[[nodiscard]] Result<std::optional<ResultFailureV1>> parse_result_failure_v2(
    const Json& value, const ResultStatusV1 status) {
  if (value.is_null()) {
    if (status == ResultStatusV1::failed) {
      return fail_result<std::optional<ResultFailureV1>>(
          "c30.result_v2_failure_shape_invalid",
          "a failed result-v2 requires failure provenance");
    }
    return Result<std::optional<ResultFailureV1>>::success(std::nullopt);
  }
  if (status != ResultStatusV1::failed ||
      !exact_object_shape(value, {"stage", "code", "diagnostic_refs"}) ||
      !value["stage"].is_string() || !value["code"].is_string() ||
      value["code"].get_ref<const std::string&>().empty() ||
      !value["diagnostic_refs"].is_array() ||
      value["diagnostic_refs"].empty()) {
    return fail_result<std::optional<ResultFailureV1>>(
        "c30.result_v2_failure_shape_invalid",
        "result-v2 failure provenance has an invalid closed shape");
  }
  const auto stage = parse_failure_stage_v2(
      value["stage"].get_ref<const std::string&>());
  if (!stage.has_value()) {
    return fail_result<std::optional<ResultFailureV1>>(
        "c30.result_v2_failure_shape_invalid",
        "result-v2 failure stage is not recognized");
  }
  std::vector<std::string> refs;
  refs.reserve(value["diagnostic_refs"].size());
  std::unordered_set<std::string> seen_refs;
  seen_refs.reserve(value["diagnostic_refs"].size());
  for (const Json& ref : value["diagnostic_refs"]) {
    if (!ref.is_string() || ref.get_ref<const std::string&>().empty() ||
        !seen_refs.insert(ref.get_ref<const std::string&>()).second) {
      return fail_result<std::optional<ResultFailureV1>>(
          "c30.result_v2_failure_shape_invalid",
          "result-v2 diagnostic references must be nonempty and unique");
    }
    refs.push_back(ref.get<std::string>());
  }
  return Result<std::optional<ResultFailureV1>>::success(ResultFailureV1{
      .stage = *stage,
      .code = value["code"].get<std::string>(),
      .diagnostic_refs = std::move(refs),
  });
}

[[nodiscard]] Result<ExactRational> parse_compact_rational_v2(
    const Json& value, const ResultArtifactParseLimitsV2& limits) {
  if (!value.is_object() || !value.contains("exact") ||
      !value["exact"].is_string() || value.size() < 1U || value.size() > 2U ||
      (value.size() == 2U &&
       (!value.contains("decimal") || !value["decimal"].is_number()))) {
    return fail_result<ExactRational>(
        "c30.result_v2_rational_invalid",
        "a compact exact rational has an invalid closed shape");
  }
  const std::string& exact = value["exact"].get_ref<const std::string&>();
  const std::size_t slash = exact.find('/');
  if (slash == std::string::npos || slash == 0U ||
      slash + 1U == exact.size() || exact.find('/', slash + 1U) !=
                                          std::string::npos) {
    return fail_result<ExactRational>(
        "c30.result_v2_rational_invalid",
        "a compact exact rational must use canonical numerator/denominator form");
  }
  auto scalar = PortableScientificScalar::parse_rational(
      std::string_view(exact).substr(0U, slash),
      std::string_view(exact).substr(slash + 1U),
      RationalBoundPolicy{.maximum_bits = std::nullopt,
                          .maximum_decimal_digits =
                              limits.maximum_string_bytes});
  if (!scalar) {
    return fail_result<ExactRational>(
        "c30.result_v2_rational_invalid",
        "a compact exact rational must use a canonical reduced "
        "numerator/denominator encoding");
  }
  ExactRational parsed = scalar.value().rational_value();
  if (encode_compact_rational(parsed).dump() != value.dump()) {
    return fail_result<ExactRational>(
        "c30.result_v2_rational_invalid",
        "a compact exact rational must use the canonical exact and decimal projection");
  }
  return Result<ExactRational>::success(std::move(parsed));
}

[[nodiscard]] Result<void> validate_canonical_compact_rationals_v2(
    const Json& value, const ResultArtifactParseLimitsV2& limits) {
  if (value.is_object()) {
    // Every object with an `exact` member in the closed result-v2 schema is a
    // compact rational (including the legacy main-result scalar projection).
    // Reparse and re-encode all of them so display-only analysis fields cannot
    // smuggle unreduced signs/fractions or an arbitrary decimal projection
    // past the schema's deliberately syntactic rationalText pattern.
    if (value.contains("exact")) {
      auto canonical = parse_compact_rational_v2(value, limits);
      if (!canonical) {
        return Result<void>::failure(canonical.error());
      }
      return Result<void>::success();
    }
    for (auto member = value.begin(); member != value.end(); ++member) {
      auto valid =
          validate_canonical_compact_rationals_v2(member.value(), limits);
      if (!valid) {
        return valid;
      }
    }
  } else if (value.is_array()) {
    for (const Json& item : value) {
      auto valid = validate_canonical_compact_rationals_v2(item, limits);
      if (!valid) {
        return valid;
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<BigNat> parse_big_nat_v2(
    const Json& value, const ResultArtifactParseLimitsV2& limits) {
  if (!value.is_string()) {
    return fail_result<BigNat>("c30.result_v2_big_nat_invalid",
                               "a result-v2 natural number must be a decimal string");
  }
  return parse_exact_nonnegative_integer(
      JsonNumber(value.get<std::string>()),
      BoundPolicy{.mathematical_maximum = std::nullopt,
                  .maximum_bits = std::nullopt,
                  .maximum_decimal_digits = limits.maximum_string_bytes});
}

[[nodiscard]] Result<std::vector<ExactRational>> parse_rational_vector_v2(
    const Json& value, const ResultArtifactParseLimitsV2& limits) {
  if (!value.is_array()) {
    return fail_result<std::vector<ExactRational>>(
        "c30.result_v2_decoder_profile_invalid",
        "a decoder profile coefficient collection must be an array");
  }
  std::vector<ExactRational> parsed;
  parsed.reserve(value.size());
  for (const Json& item : value) {
    auto rational = parse_compact_rational_v2(item, limits);
    if (!rational) {
      return Result<std::vector<ExactRational>>::failure(rational.error());
    }
    parsed.push_back(std::move(rational).value());
  }
  return Result<std::vector<ExactRational>>::success(std::move(parsed));
}

[[nodiscard]] Result<SuppliedResponseProfileV1> parse_supplied_profile_v2(
    const Json& value, const ResultArtifactParseLimitsV2& limits,
    const bool require_valid_semantics = true) {
  if (!exact_object_shape(
          value, {"cutoff", "service_by_level", "constant_tail_service",
                  "prefix_exposure_mass", "prefix_served_mass",
                  "tail_exposure_mass", "tail_served_mass"})) {
    return fail_result<SuppliedResponseProfileV1>(
        "c30.result_v2_decoder_profile_invalid",
        "decoder profile has an invalid closed shape");
  }
  const FinitePrefixFitLimitsV1 bounded_fit_limits;
  const std::size_t maximum_profile_values =
      bounded_fit_limits.maximum_cutoff + 1U;
  if (!value["service_by_level"].is_array() ||
      !value["prefix_exposure_mass"].is_array() ||
      !value["prefix_served_mass"].is_array() ||
      value["service_by_level"].size() > maximum_profile_values ||
      value["prefix_exposure_mass"].size() > maximum_profile_values ||
      value["prefix_served_mass"].size() > maximum_profile_values) {
    return fail_result<SuppliedResponseProfileV1>(
        "c30.result_v2_decoder_profile_invalid",
        "a supplied profile exceeds the bounded finite-prefix extent");
  }
  auto cutoff = parse_big_nat_v2(value["cutoff"], limits);
  auto service = parse_rational_vector_v2(value["service_by_level"], limits);
  auto tail =
      parse_compact_rational_v2(value["constant_tail_service"], limits);
  auto exposure =
      parse_rational_vector_v2(value["prefix_exposure_mass"], limits);
  auto served = parse_rational_vector_v2(value["prefix_served_mass"], limits);
  auto tail_exposure =
      parse_compact_rational_v2(value["tail_exposure_mass"], limits);
  auto tail_served =
      parse_compact_rational_v2(value["tail_served_mass"], limits);
  if (!cutoff) {
    return Result<SuppliedResponseProfileV1>::failure(cutoff.error());
  }
  if (!service) {
    return Result<SuppliedResponseProfileV1>::failure(service.error());
  }
  if (!tail) {
    return Result<SuppliedResponseProfileV1>::failure(tail.error());
  }
  if (!exposure) {
    return Result<SuppliedResponseProfileV1>::failure(exposure.error());
  }
  if (!served) {
    return Result<SuppliedResponseProfileV1>::failure(served.error());
  }
  if (!tail_exposure) {
    return Result<SuppliedResponseProfileV1>::failure(tail_exposure.error());
  }
  if (!tail_served) {
    return Result<SuppliedResponseProfileV1>::failure(tail_served.error());
  }
  SuppliedResponseProfileV1 profile{
      .cutoff = std::move(cutoff).value(),
      .service_by_level = std::move(service).value(),
      .constant_tail_service = std::move(tail).value(),
      .prefix_exposure_mass = std::move(exposure).value(),
      .prefix_served_mass = std::move(served).value(),
      .tail_exposure_mass = std::move(tail_exposure).value(),
      .tail_served_mass = std::move(tail_served).value(),
  };
  if (require_valid_semantics && !valid_supplied_profile_semantics(profile)) {
    return fail_result<SuppliedResponseProfileV1>(
        "c30.result_v2_decoder_profile_invalid",
        "decoder profile violates cutoff, probability, or supporting-mass invariants");
  }
  return Result<SuppliedResponseProfileV1>::success(std::move(profile));
}

[[nodiscard]] Result<std::size_t> parse_native_size_v2(
    const Json& value, const std::string_view member) {
  if (!value.is_number_unsigned()) {
    return fail_result<std::size_t>(
        "c30.result_v2_analysis_options_invalid",
        "analysis option " + std::string(member) +
            " must be a nonnegative native-size integer");
  }
  const std::uint64_t parsed = value.get<std::uint64_t>();
  if constexpr (sizeof(std::size_t) < sizeof(std::uint64_t)) {
    if (parsed > static_cast<std::uint64_t>(
                     std::numeric_limits<std::size_t>::max())) {
      return fail_result<std::size_t>(
          "c30.result_v2_analysis_options_invalid",
          "analysis option " + std::string(member) +
              " exceeds the native-size range");
    }
  }
  return Result<std::size_t>::success(static_cast<std::size_t>(parsed));
}

[[nodiscard]] Result<CompressionAnalysisOptionsV1>
parse_compression_analysis_options(
    const Json& value, const ResultArtifactParseLimitsV2& limits,
    const ResultArtifactVersionV1 result_version) {
  const bool empirical = result_version == ResultArtifactVersionV1::v3;
  const bool valid_shape =
      empirical
          ? exact_object_shape(
                value,
                {"cutoffs", "fit_limits", "effective_selection_seed",
                 "provider_supplied_profiles",
                 "ill_conditioned_slack_threshold", "run_diagnostic_fits",
                 "compute_delete_one_replication_jackknife",
                 "stationary_coefficients_established",
                 "prefix_preservation_established", "projection_mode",
                 "ensemble_population_size",
                 "poisson_mixture_overshoot_v1"})
          : exact_object_shape(
                value,
                {"cutoffs", "fit_limits", "effective_selection_seed",
                 "provider_supplied_profiles",
                 "ill_conditioned_slack_threshold", "run_diagnostic_fits",
                 "compute_delete_one_replication_jackknife",
                 "stationary_coefficients_established",
                 "prefix_preservation_established"});
  if (!valid_shape ||
      !value["cutoffs"].is_array() ||
      !value["fit_limits"].is_object() ||
      !value["effective_selection_seed"].is_array() ||
      !value["provider_supplied_profiles"].is_array() ||
      !value["run_diagnostic_fits"].is_boolean() ||
      !value["compute_delete_one_replication_jackknife"].is_boolean() ||
      !value["stationary_coefficients_established"].is_boolean() ||
      !value["prefix_preservation_established"].is_boolean() ||
      (empirical &&
       (!value["projection_mode"].is_string() ||
        value["projection_mode"].get_ref<const std::string&>() !=
            "empirical_finite_window_response_v1"))) {
    return fail_result<CompressionAnalysisOptionsV1>(
        "c30.result_v2_analysis_options_invalid",
        "compression-analysis options have an invalid closed shape");
  }
  const FinitePrefixFitLimitsV1 bounded_fit_limits;
  const std::size_t maximum_cutoff_count =
      bounded_fit_limits.maximum_cutoff + 1U;
  if ((!empirical && value["cutoffs"].size() > maximum_cutoff_count) ||
      value["effective_selection_seed"].size() >
          bounded_fit_limits.maximum_selection_seed_atoms ||
      value["provider_supplied_profiles"].size() > maximum_cutoff_count) {
    return fail_result<CompressionAnalysisOptionsV1>(
        "c30.result_v2_analysis_options_limit",
        "compression-analysis option collections exceed the bounded finite-prefix limits");
  }

  CompressionAnalysisOptionsV1 options;
  options.cutoffs.clear();
  options.cutoffs.reserve(value["cutoffs"].size());
  for (const Json& item : value["cutoffs"]) {
    auto cutoff = parse_big_nat_v2(item, limits);
    if (!cutoff) {
      return Result<CompressionAnalysisOptionsV1>::failure(cutoff.error());
    }
    options.cutoffs.push_back(std::move(cutoff).value());
  }

  const Json& fit_limits = value["fit_limits"];
  if (!exact_object_shape(
          fit_limits,
          {"maximum_cutoff", "maximum_arrival_atoms",
           "maximum_selection_seed_atoms", "maximum_closure_states"})) {
    return fail_result<CompressionAnalysisOptionsV1>(
        "c30.result_v2_analysis_options_invalid",
        "compression-analysis fit limits have an invalid closed shape");
  }
  auto maximum_cutoff =
      parse_native_size_v2(fit_limits["maximum_cutoff"], "maximum_cutoff");
  auto maximum_arrival_atoms = parse_native_size_v2(
      fit_limits["maximum_arrival_atoms"], "maximum_arrival_atoms");
  auto maximum_selection_seed_atoms = parse_native_size_v2(
      fit_limits["maximum_selection_seed_atoms"],
      "maximum_selection_seed_atoms");
  auto maximum_closure_states = parse_native_size_v2(
      fit_limits["maximum_closure_states"], "maximum_closure_states");
  if (!maximum_cutoff) {
    return Result<CompressionAnalysisOptionsV1>::failure(
        maximum_cutoff.error());
  }
  if (!maximum_arrival_atoms) {
    return Result<CompressionAnalysisOptionsV1>::failure(
        maximum_arrival_atoms.error());
  }
  if (!maximum_selection_seed_atoms) {
    return Result<CompressionAnalysisOptionsV1>::failure(
        maximum_selection_seed_atoms.error());
  }
  if (!maximum_closure_states) {
    return Result<CompressionAnalysisOptionsV1>::failure(
        maximum_closure_states.error());
  }
  if (maximum_cutoff.value() > bounded_fit_limits.maximum_cutoff ||
      maximum_arrival_atoms.value() >
          bounded_fit_limits.maximum_arrival_atoms ||
      maximum_selection_seed_atoms.value() >
          bounded_fit_limits.maximum_selection_seed_atoms ||
      maximum_closure_states.value() >
          bounded_fit_limits.maximum_closure_states) {
    return fail_result<CompressionAnalysisOptionsV1>(
        "c30.result_v2_analysis_options_limit",
        "compression-analysis fit limits may tighten but not exceed the published bounded defaults");
  }
  options.fit_limits = FinitePrefixFitLimitsV1{
      .maximum_cutoff = maximum_cutoff.value(),
      .maximum_arrival_atoms = maximum_arrival_atoms.value(),
      .maximum_selection_seed_atoms =
          maximum_selection_seed_atoms.value(),
      .maximum_closure_states = maximum_closure_states.value(),
  };

  options.selection_seed.clear();
  options.selection_seed.reserve(value["effective_selection_seed"].size());
  for (const Json& item : value["effective_selection_seed"]) {
    if (!exact_object_shape(item, {"backlog", "selection_mass"})) {
      return fail_result<CompressionAnalysisOptionsV1>(
          "c30.result_v2_analysis_options_invalid",
          "an effective selection-seed atom has an invalid closed shape");
    }
    auto backlog = parse_big_nat_v2(item["backlog"], limits);
    auto mass = parse_compact_rational_v2(item["selection_mass"], limits);
    if (!backlog) {
      return Result<CompressionAnalysisOptionsV1>::failure(backlog.error());
    }
    if (!mass) {
      return Result<CompressionAnalysisOptionsV1>::failure(mass.error());
    }
    options.selection_seed.push_back(FinitePrefixFitSelectionSeedAtomV1{
        std::move(backlog).value(), std::move(mass).value()});
  }

  options.provider_supplied_profiles.clear();
  options.provider_supplied_profiles.reserve(
      value["provider_supplied_profiles"].size());
  for (const Json& item : value["provider_supplied_profiles"]) {
    auto profile = parse_supplied_profile_v2(item, limits, false);
    if (!profile) {
      return Result<CompressionAnalysisOptionsV1>::failure(profile.error());
    }
    options.provider_supplied_profiles.push_back(
        std::move(profile).value());
  }

  if (value["ill_conditioned_slack_threshold"].is_null()) {
    options.ill_conditioned_slack_threshold = std::nullopt;
  } else {
    auto threshold = parse_compact_rational_v2(
        value["ill_conditioned_slack_threshold"], limits);
    if (!threshold) {
      return Result<CompressionAnalysisOptionsV1>::failure(
          threshold.error());
    }
    options.ill_conditioned_slack_threshold =
        std::move(threshold).value();
  }
  options.run_diagnostic_fits =
      value["run_diagnostic_fits"].get<bool>();
  options.compute_delete_one_replication_jackknife =
      value["compute_delete_one_replication_jackknife"].get<bool>();
  options.stationary_coefficients_established =
      value["stationary_coefficients_established"].get<bool>();
  options.prefix_preservation_established =
      value["prefix_preservation_established"].get<bool>();

  if (empirical) {
    auto ensemble_population =
        parse_big_nat_v2(value["ensemble_population_size"], limits);
    if (!ensemble_population || ensemble_population.value().is_zero()) {
      return fail_result<CompressionAnalysisOptionsV1>(
          "c32.result_v3_analysis_options_invalid",
          "empirical analysis requires a positive ensemble population size");
    }
    options.projection_mode =
        CompressionAnalysisOptionsV1::ProjectionMode::
            empirical_finite_window_response;
    options.ensemble_population_size =
        std::move(ensemble_population).value();

    const Json& overshoot = value["poisson_mixture_overshoot_v1"];
    if (!overshoot.is_null()) {
      if (!exact_object_shape(
              overshoot,
              {"descriptor_id", "descriptor_version", "components",
               "operational_parameter_digest", "descriptor_digest",
               "omitted_tail_tolerance", "maximum_recurrence_steps"}) ||
          !overshoot["descriptor_id"].is_string() ||
          overshoot["descriptor_id"].get_ref<const std::string&>().empty() ||
          !overshoot["descriptor_version"].is_number_unsigned() ||
          !overshoot["components"].is_array() ||
          overshoot["components"].empty() ||
          !overshoot["operational_parameter_digest"].is_string() ||
          !overshoot["descriptor_digest"].is_string() ||
          !overshoot["maximum_recurrence_steps"].is_number_unsigned()) {
        return fail_result<CompressionAnalysisOptionsV1>(
            "c32.result_v3_poisson_options_invalid",
            "the empirical Poisson-overshoot descriptor has an invalid closed shape");
      }
      const std::uint64_t descriptor_version =
          overshoot["descriptor_version"].get<std::uint64_t>();
      const std::uint64_t maximum_recurrence_steps =
          overshoot["maximum_recurrence_steps"].get<std::uint64_t>();
      if (descriptor_version == 0U ||
          descriptor_version > std::numeric_limits<std::uint32_t>::max() ||
          maximum_recurrence_steps == 0U) {
        return fail_result<CompressionAnalysisOptionsV1>(
            "c32.result_v3_poisson_options_invalid",
            "the empirical Poisson-overshoot descriptor has an invalid numeric field");
      }
      auto operational_digest = Digest256::from_hex(
          overshoot["operational_parameter_digest"]
              .get_ref<const std::string&>());
      auto descriptor_digest = Digest256::from_hex(
          overshoot["descriptor_digest"].get_ref<const std::string&>());
      auto tolerance = parse_compact_rational_v2(
          overshoot["omitted_tail_tolerance"], limits);
      if (!operational_digest || !descriptor_digest || !tolerance) {
        return fail_result<CompressionAnalysisOptionsV1>(
            "c32.result_v3_poisson_options_invalid",
            "the empirical Poisson-overshoot descriptor has invalid digest or tolerance fields");
      }

      std::vector<CompressionAnalysisOptionsV1::PoissonOvershootComponentV1>
          components;
      components.reserve(overshoot["components"].size());
      for (const Json& component : overshoot["components"]) {
        if (!exact_object_shape(
                component,
                {"weight", "component_rate", "operational_rate_bits"})) {
          return fail_result<CompressionAnalysisOptionsV1>(
              "c32.result_v3_poisson_options_invalid",
              "a Poisson-overshoot mixture component has an invalid closed shape");
        }
        auto weight = parse_compact_rational_v2(component["weight"], limits);
        auto rate =
            parse_compact_rational_v2(component["component_rate"], limits);
        auto rate_bits =
            parse_big_nat_v2(component["operational_rate_bits"], limits);
        if (!weight || !rate || !rate_bits || rate_bits.value().bit_length() >
                                                    64U) {
          return fail_result<CompressionAnalysisOptionsV1>(
              "c32.result_v3_poisson_options_invalid",
              "a Poisson-overshoot mixture component is not canonical or exceeds uint64 range");
        }
        components.push_back(
            CompressionAnalysisOptionsV1::PoissonOvershootComponentV1{
                std::move(weight).value(), std::move(rate).value(),
                rate_bits.value().value().convert_to<std::uint64_t>()});
      }
      options.poisson_overshoot =
          CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1{
              overshoot["descriptor_id"].get<std::string>(),
              static_cast<std::uint32_t>(descriptor_version),
              std::move(components), std::move(operational_digest).value(),
              std::move(descriptor_digest).value(),
              std::move(tolerance).value(), maximum_recurrence_steps};
    }
  }
  return Result<CompressionAnalysisOptionsV1>::success(std::move(options));
}

[[nodiscard]] Result<std::string> canonical_compression_comparison_json(
    const ThreeRecordErrorSeparationV1& comparison) {
  if (comparison.cutoffs.empty()) {
    return fail_result<std::string>(
        "c30.comparison_cutoffs_empty",
        "compression comparison must retain at least one cutoff row");
  }
  for (std::size_t index = 1U; index < comparison.cutoffs.size(); ++index) {
    if (!(comparison.cutoffs[index - 1U].cutoff <
          comparison.cutoffs[index].cutoff)) {
      return fail_result<std::string>(
          "c30.comparison_cutoffs_not_canonical",
          "compression comparison cutoff rows must be strictly increasing");
    }
  }
  try {
    Json encoded = encode_compression_comparison(comparison);
    if (const auto schema_failure =
            validate_compression_comparison_v1_against_published_schema(
                encoded)) {
      return fail_result<std::string>(
          "c30.comparison_schema_self_validation_failed",
          "canonical comparison output violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message);
    }
    if (const auto order_failure =
            validate_compression_comparison_v1_canonical_member_order(
                encoded)) {
      return fail_result<std::string>(
          "c30.comparison_schema_self_validation_failed",
          "canonical comparison output violates the published member order "
          "at " +
              order_failure->path + ": " + order_failure->message);
    }
    return Result<std::string>::success(encoded.dump());
  } catch (const nlohmann::json::exception&) {
    return fail_result<std::string>(
        "c30.comparison_json_encoding_failed",
        "compression comparison could not be encoded as strict UTF-8 JSON");
  }
}

enum class PublicationFailurePoint : std::uint8_t {
  none,
  open,
  write,
  flush,
  close,
  rename,
};

#if defined(MWPERF_C27_TEST_SEAMS)
[[nodiscard]] constexpr PublicationFailurePoint internal_failure_point(
    const ResultPublicationFailurePointV1 value) noexcept {
  switch (value) {
    case ResultPublicationFailurePointV1::none:
      return PublicationFailurePoint::none;
    case ResultPublicationFailurePointV1::open:
      return PublicationFailurePoint::open;
    case ResultPublicationFailurePointV1::write:
      return PublicationFailurePoint::write;
    case ResultPublicationFailurePointV1::flush:
      return PublicationFailurePoint::flush;
    case ResultPublicationFailurePointV1::close:
      return PublicationFailurePoint::close;
    case ResultPublicationFailurePointV1::rename:
      return PublicationFailurePoint::rename;
  }
  return PublicationFailurePoint::open;
}
#endif

#if defined(__unix__) || defined(__APPLE__)
class ScopedDescriptor final {
 public:
  explicit ScopedDescriptor(const int descriptor = -1) noexcept
      : descriptor_(descriptor) {}
  ScopedDescriptor(const ScopedDescriptor&) = delete;
  ScopedDescriptor& operator=(const ScopedDescriptor&) = delete;
  ScopedDescriptor(ScopedDescriptor&& other) noexcept
      : descriptor_(other.release()) {}
  ScopedDescriptor& operator=(ScopedDescriptor&& other) noexcept {
    if (this != &other) {
      reset(other.release());
    }
    return *this;
  }
  ~ScopedDescriptor() { reset(); }

  [[nodiscard]] int get() const noexcept { return descriptor_; }
  [[nodiscard]] int release() noexcept {
    const int descriptor = descriptor_;
    descriptor_ = -1;
    return descriptor;
  }
  void reset(const int descriptor = -1) noexcept {
    if (descriptor_ >= 0) {
      (void)::close(descriptor_);
    }
    descriptor_ = descriptor;
  }

 private:
  int descriptor_;
};

class ScopedTemporarySibling final {
 public:
  ScopedTemporarySibling(const int directory, std::string name)
      : directory_(directory), name_(std::move(name)) {}
  ScopedTemporarySibling(const ScopedTemporarySibling&) = delete;
  ScopedTemporarySibling& operator=(const ScopedTemporarySibling&) = delete;
  ~ScopedTemporarySibling() {
    if (!published_ && !name_.empty()) {
      (void)::unlinkat(directory_, name_.c_str(), 0);
    }
  }
  void published() noexcept { published_ = true; }

 private:
  int directory_;
  std::string name_;
  bool published_{false};
};

[[nodiscard]] bool path_contains_nul(
    const std::filesystem::path& path) noexcept {
  const auto& native = path.native();
  return std::find(native.begin(), native.end(),
                   std::filesystem::path::value_type{}) != native.end();
}

[[nodiscard]] bool write_all(const int descriptor,
                             const std::string& bytes) noexcept {
  std::size_t offset = 0U;
  while (offset < bytes.size()) {
    const std::size_t remaining = bytes.size() - offset;
    const std::size_t amount = std::min<std::size_t>(
        remaining, static_cast<std::size_t>(
                       std::numeric_limits<ssize_t>::max()));
    const ssize_t written =
        ::write(descriptor, bytes.data() + offset, amount);
    if (written < 0 && errno == EINTR) {
      continue;
    }
    if (written <= 0) {
      return false;
    }
    offset += static_cast<std::size_t>(written);
  }
  return true;
}

[[nodiscard]] Result<void> publish_json(
    const std::string& bytes, const std::filesystem::path& path,
    const PublicationFailurePoint failure_point) {
  if (path.empty() || path.filename().empty() || path_contains_nul(path)) {
    return Result<void>::failure(publication_error(path, "open"));
  }
  const std::filesystem::path parent =
      path.has_parent_path() ? path.parent_path() : std::filesystem::path(".");
  const std::string destination = path.filename().string();
  if (destination.empty() || destination.find('\0') != std::string::npos ||
      failure_point == PublicationFailurePoint::open) {
    return Result<void>::failure(publication_error(path, "open"));
  }

  ScopedDescriptor directory(::open(
      parent.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC));
  if (directory.get() < 0) {
    return Result<void>::failure(publication_error(path, "open"));
  }

  static std::atomic<std::uint64_t> sequence{0U};
  constexpr std::size_t kMaximumAttempts = 1024U;
  ScopedDescriptor temporary;
  std::string temporary_name;
  for (std::size_t attempt = 0U; attempt < kMaximumAttempts; ++attempt) {
    const std::uint64_t serial =
        sequence.fetch_add(1U, std::memory_order_relaxed);
    temporary_name = "." + destination + ".mwperf-result-v1.tmp." +
                     std::to_string(static_cast<unsigned long long>(
                         ::getpid())) +
                     "." + std::to_string(serial);
    temporary.reset(::openat(directory.get(), temporary_name.c_str(),
                             O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW |
                                 O_CLOEXEC,
                             S_IRUSR | S_IWUSR));
    if (temporary.get() >= 0) {
      break;
    }
    if (errno != EEXIST) {
      return Result<void>::failure(publication_error(path, "open"));
    }
  }
  if (temporary.get() < 0) {
    return Result<void>::failure(publication_error(path, "open"));
  }
  ScopedTemporarySibling cleanup(directory.get(), temporary_name);

  if (failure_point == PublicationFailurePoint::write ||
      !write_all(temporary.get(), bytes)) {
    return Result<void>::failure(publication_error(path, "write"));
  }
  if (failure_point == PublicationFailurePoint::flush ||
      ::fsync(temporary.get()) != 0) {
    return Result<void>::failure(publication_error(path, "flush"));
  }

  const int raw_temporary = temporary.release();
  const bool close_succeeded = ::close(raw_temporary) == 0;
  if (failure_point == PublicationFailurePoint::close || !close_succeeded) {
    return Result<void>::failure(publication_error(path, "close"));
  }
  if (failure_point == PublicationFailurePoint::rename ||
      ::renameat(directory.get(), temporary_name.c_str(), directory.get(),
                 destination.c_str()) != 0) {
    return Result<void>::failure(publication_error(path, "rename"));
  }
  cleanup.published();
  return Result<void>::success();
}
#else
[[nodiscard]] Result<void> publish_json(
    const std::string& bytes, const std::filesystem::path& path,
    const PublicationFailurePoint failure_point) {
  if (path.empty() || path.filename().empty() ||
      failure_point == PublicationFailurePoint::open) {
    return Result<void>::failure(publication_error(path, "open"));
  }
  static std::atomic<std::uint64_t> sequence{0U};
  const std::filesystem::path temporary =
      path.parent_path() /
      ("." + path.filename().string() + ".mwperf-result-v1.tmp." +
       std::to_string(sequence.fetch_add(1U, std::memory_order_relaxed)));
  struct Cleanup final {
    std::filesystem::path path;
    bool published{false};
    ~Cleanup() {
      if (!published) {
        std::error_code ignored;
        (void)std::filesystem::remove(path, ignored);
      }
    }
  } cleanup{temporary};
  std::ofstream stream(temporary,
                       std::ios::binary | std::ios::out | std::ios::trunc);
  if (!stream.is_open()) {
    return Result<void>::failure(publication_error(path, "open"));
  }
  if (failure_point == PublicationFailurePoint::write) {
    return Result<void>::failure(publication_error(path, "write"));
  }
  stream.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
  if (!stream.good()) {
    return Result<void>::failure(publication_error(path, "write"));
  }
  if (failure_point == PublicationFailurePoint::flush) {
    return Result<void>::failure(publication_error(path, "flush"));
  }
  stream.flush();
  if (!stream.good()) {
    return Result<void>::failure(publication_error(path, "flush"));
  }
  stream.close();
  if (failure_point == PublicationFailurePoint::close || stream.fail()) {
    return Result<void>::failure(publication_error(path, "close"));
  }
  if (failure_point == PublicationFailurePoint::rename) {
    return Result<void>::failure(publication_error(path, "rename"));
  }
  std::error_code rename_error;
  std::filesystem::rename(temporary, path, rename_error);
  if (rename_error) {
    return Result<void>::failure(publication_error(path, "rename"));
  }
  cleanup.published = true;
  return Result<void>::success();
}
#endif

[[nodiscard]] Result<void> write_result_artifact_impl(
    const ResultArtifact& artifact, const std::filesystem::path& path,
    const PublicationFailurePoint failure_point) {
  auto encoded = canonical_result_json(artifact);
  if (!encoded) {
    return Result<void>::failure(publication_error(path, "serialize"));
  }
  return publish_json(encoded.value(), path, failure_point);
}

[[nodiscard]] Result<void> write_result_artifact_v2_impl(
    const ResultArtifactV2& artifact, const std::filesystem::path& path,
    const PublicationFailurePoint failure_point) {
  auto encoded = canonical_result_v2_json(artifact);
  if (!encoded) {
    return Result<void>::failure(encoded.error());
  }
  return publish_json(encoded.value(), path, failure_point);
}

[[nodiscard]] Result<void> write_result_artifact_v3_impl(
    const ResultArtifactV3& artifact, const std::filesystem::path& path,
    const PublicationFailurePoint failure_point) {
  auto encoded = canonical_result_v3_json(artifact);
  if (!encoded) {
    return Result<void>::failure(encoded.error());
  }
  return publish_json(encoded.value(), path, failure_point);
}

}  // namespace

#if defined(MWPERF_C27_TEST_SEAMS)
Result<void> validate_result_v1_json_schema_for_test(
    const std::string_view document) {
  const auto schema_failure = validate_result_json_against_published_schema(
      std::string(document));
  if (!schema_failure.has_value()) {
    return Result<void>::success();
  }
  return Result<void>::failure(result_error(
      "c27.result_schema_self_validation_failed",
      "result-v1 test document violates the published schema at " +
          schema_failure->path + ": " + schema_failure->message));
}

Result<void> validate_result_v2_json_schema_for_test(
    const std::string_view document) {
  try {
    const Json parsed = Json::parse(document);
    const auto schema_failure =
        validate_result_v2_json_against_published_schema(parsed);
    if (schema_failure.has_value()) {
      return Result<void>::failure(result_error(
          "c30.result_v2_schema_validation_failed",
          "result-v2 test document violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message));
    }
    const auto order_failure =
        validate_result_v2_canonical_member_order(parsed);
    if (order_failure.has_value()) {
      return Result<void>::failure(result_error(
          "c30.result_v2_schema_validation_failed",
          "result-v2 test document violates canonical schema member order at " +
              order_failure->path + ": " + order_failure->message));
    }
    return Result<void>::success();
  } catch (const Json::exception& exception) {
    return Result<void>::failure(result_error(
        "c30.result_v2_schema_validation_failed",
        std::string("result-v2 test document is not valid JSON: ") +
            exception.what()));
  }
}

Result<void> validate_result_v3_json_schema_for_test(
    const std::string_view document) {
  try {
    const Json instance = Json::parse(document);
    const auto schema_failure =
        validate_result_v3_json_against_published_schema(instance);
    if (schema_failure.has_value()) {
      return Result<void>::failure(result_error(
          "c32.result_v3_schema_validation_failed",
          "result-v3 test document violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message));
    }
    const auto order_failure =
        validate_result_v3_canonical_member_order(instance);
    if (order_failure.has_value()) {
      return Result<void>::failure(result_error(
          "c32.result_v3_schema_validation_failed",
          "result-v3 test document violates canonical schema member order at " +
              order_failure->path + ": " + order_failure->message));
    }
    return Result<void>::success();
  } catch (const Json::exception& exception) {
    return Result<void>::failure(result_error(
        "c32.result_v3_schema_validation_failed",
        std::string("result-v3 test document is not valid JSON: ") +
            exception.what()));
  }
}

Result<std::string> canonical_result_artifact_v2_json_for_test(
    const ResultArtifactV2& artifact) {
  return canonical_result_v2_json(artifact);
}

Result<std::string> canonical_result_artifact_v3_json_for_test(
    const ResultArtifactV3& artifact) {
  return canonical_result_v3_json(artifact);
}

Result<void> validate_compression_comparison_v1_json_schema_for_test(
    const std::string_view document) {
  try {
    const Json instance = Json::parse(document);
    const auto schema_failure =
        validate_compression_comparison_v1_against_published_schema(
            instance);
    if (schema_failure.has_value()) {
      return Result<void>::failure(result_error(
          "c30.comparison_schema_validation_failed",
          "comparison-v1 test document violates the published schema at " +
              schema_failure->path + ": " + schema_failure->message));
    }
    const auto order_failure =
        validate_compression_comparison_v1_canonical_member_order(instance);
    if (order_failure.has_value()) {
      return Result<void>::failure(result_error(
          "c30.comparison_schema_validation_failed",
          "comparison-v1 test document violates the published member order "
          "at " +
              order_failure->path + ": " + order_failure->message));
    }
    return Result<void>::success();
  } catch (const nlohmann::json::exception&) {
    return Result<void>::failure(result_error(
        "c30.comparison_schema_validation_failed",
        "comparison-v1 test document is not valid JSON"));
  }
}
#endif

ResultArtifactParseLimitsV2
default_result_artifact_parse_limits_v2() noexcept {
  return ResultArtifactParseLimitsV2{
      .maximum_bytes = kNonScientificByteCeiling,
      .maximum_nesting_depth = 48U,
      .maximum_object_entries = std::numeric_limits<std::size_t>::max(),
      .maximum_array_entries = std::numeric_limits<std::size_t>::max(),
      .maximum_string_bytes = kNonScientificByteCeiling,
      .maximum_total_decoded_allocation_bytes = kNonScientificByteCeiling,
  };
}

Result<ParsedResultArtifactV2> parse_result_artifact_v2(
    const std::span<const std::byte> bytes,
    const ResultArtifactParseLimitsV2& limits) {
  if (limits.maximum_bytes == 0U || limits.maximum_nesting_depth == 0U ||
      limits.maximum_object_entries == 0U ||
      limits.maximum_array_entries == 0U ||
      limits.maximum_string_bytes == 0U ||
      limits.maximum_total_decoded_allocation_bytes == 0U) {
    return fail_result<ParsedResultArtifactV2>(
        "c30.result_v2_parse_limits_invalid",
        "result-v2 parse limits must all be positive");
  }
  if (bytes.empty() || bytes.size() > limits.maximum_bytes) {
    return fail_result<ParsedResultArtifactV2>(
        "c30.result_v2_byte_limit",
        "result-v2 is empty or exceeds the configured byte cap");
  }

  try {
    const char* const source_begin =
        reinterpret_cast<const char*>(bytes.data());
    const char* const source_end = source_begin + bytes.size();
    ResultV2SaxPreflight preflight(limits);
    if (!Json::sax_parse(source_begin, source_end, &preflight,
                         Json::input_format_t::json, true)) {
      if (preflight.diagnostic()) {
        return Result<ParsedResultArtifactV2>::failure(
            *preflight.diagnostic());
      }
      return fail_result<ParsedResultArtifactV2>(
          "c30.result_v2_invalid_json", "result-v2 is not valid JSON");
    }
    const std::size_t decoded_estimate =
        preflight.estimated_decoded_allocation();
    // The input span remains owned by the caller while the DOM is live.  A
    // canonical dump is live during byte comparison, and observation
    // extraction can momentarily retain both the dumped body and its envelope
    // before the DOM is released.  Reserve three source-sized carriers plus
    // the SAX-derived DOM estimate up front so those transient copies remain
    // inside the advertised simultaneous-allocation budget.
    if (decoded_estimate >
            limits.maximum_total_decoded_allocation_bytes ||
        bytes.size() >
            (limits.maximum_total_decoded_allocation_bytes -
             decoded_estimate) /
                3U) {
      return fail_result<ParsedResultArtifactV2>(
          "c30.result_v2_allocation_limit",
          "result-v2 canonical verification would exceed the simultaneous allocation cap");
    }

    Json document = Json::parse(source_begin, source_end);
    {
      const std::string canonical_encoding = document.dump();
      if (canonical_encoding.size() != bytes.size() ||
          std::memcmp(canonical_encoding.data(), source_begin, bytes.size()) !=
              0) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_noncanonical",
            "result-v2 must use the canonical compact JSON encoding");
      }
    }
    if (const auto schema_failure =
            validate_result_v2_json_against_published_schema(document)) {
      return fail_result<ParsedResultArtifactV2>(
          "c30.result_v2_schema_validation_failed",
          "result-v2 violates the published closed schema at " +
              schema_failure->path + ": " + schema_failure->message);
    }
    auto canonical_rationals =
        validate_canonical_compact_rationals_v2(document, limits);
    if (!canonical_rationals) {
      return Result<ParsedResultArtifactV2>::failure(
          canonical_rationals.error());
    }
    if (const auto order_failure =
            validate_result_v2_canonical_member_order(document)) {
      return fail_result<ParsedResultArtifactV2>(
          "c30.result_v2_noncanonical",
          "result-v2 members are not in canonical order at " +
              order_failure->path + ": " + order_failure->message);
    }
    if (!exact_object_shape(document,
                            {"result_version", "status", "failure",
                             "main_result", "diagnostic_supplement"}) ||
        !document["result_version"].is_number_unsigned() ||
        document["result_version"].get<std::uint64_t>() != 2U ||
        !document["main_result"].is_object()) {
      return fail_result<ParsedResultArtifactV2>(
          "c30.result_v2_root_invalid",
          "result-v2 has an invalid closed root object");
    }

    auto status = parse_result_status_v2(document["status"]);
    if (!status) {
      return Result<ParsedResultArtifactV2>::failure(status.error());
    }
    auto failure =
        parse_result_failure_v2(document["failure"], status.value());
    if (!failure) {
      return Result<ParsedResultArtifactV2>::failure(failure.error());
    }
    const bool main_is_error = document["main_result"].contains("error");
    if ((status.value() == ResultStatusV1::success) == main_is_error ||
        (failure.value().has_value() &&
         (!document["main_result"]["error"].is_object() ||
          !document["main_result"]["error"].contains("code") ||
          !document["main_result"]["error"]["code"].is_string() ||
          document["main_result"]["error"]["code"]
                  .get_ref<const std::string&>() != failure.value()->code))) {
      return fail_result<ParsedResultArtifactV2>(
          "c30.result_v2_main_status_mismatch",
          "result-v2 main projection does not match its typed status or failure");
    }

    std::shared_ptr<const ValidatedConstructionObservationBundleV1>
        observation;
    std::optional<Digest256> analysis_digest;
    std::shared_ptr<const CompressionAnalysisResultV1> verified_analysis;
    std::shared_ptr<const CompressionAnalysisOptionsV1> analysis_options;
    std::shared_ptr<const SuppliedResponseProfileV1>
        provider_supplied_profile;
    std::optional<Digest256> provider_supplied_result_digest;
    std::optional<Digest256> provider_payload_digest;
    std::shared_ptr<const SuppliedResponseProfileV1> decoder_profile;
    std::optional<Digest256> provider_result_digest;
    std::optional<Digest256> decoder_semantics_digest;
    const Json& diagnostic = document["diagnostic_supplement"];
    if (!diagnostic.is_null()) {
      if (!exact_object_shape(
              diagnostic,
              {"terminal", "provider_supplied_profile", "decoder_profile",
               "analysis_options", "analysis", "analysis_failure",
               "observation_bundle_digest", "observation_bundle"}) ||
          !diagnostic["observation_bundle_digest"].is_string() ||
          !diagnostic["observation_bundle"].is_object()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_supplement_invalid",
            "result-v2 diagnostic supplement has an invalid closed shape");
      }
      const bool has_analysis = !diagnostic["analysis"].is_null();
      const bool has_analysis_failure =
          !diagnostic["analysis_failure"].is_null();
      if (has_analysis == has_analysis_failure ||
          (has_analysis && !diagnostic["analysis"].is_object()) ||
          (has_analysis_failure &&
           (!diagnostic["analysis_failure"].is_object() ||
            !diagnostic["analysis_failure"].contains("code") ||
            !diagnostic["analysis_failure"]["code"].is_string()))) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_analysis_outcome_invalid",
            "result-v2 must retain exactly one compression-analysis outcome");
      }
      auto parsed_analysis_options = parse_compression_analysis_options(
          diagnostic["analysis_options"], limits,
          ResultArtifactVersionV1::v2);
      if (!parsed_analysis_options) {
        return Result<ParsedResultArtifactV2>::failure(
            parsed_analysis_options.error());
      }
      analysis_options =
          std::make_shared<const CompressionAnalysisOptionsV1>(
              std::move(parsed_analysis_options).value());
      const std::string serialized_analysis_outcome =
          has_analysis ? diagnostic["analysis"].dump()
                       : diagnostic["analysis_failure"].dump();
      std::optional<std::string> analysis_observation_digest;
      if (has_analysis) {
        if (!diagnostic["analysis"].contains("observation_digest") ||
            !diagnostic["analysis"]["observation_digest"].is_string() ||
            !diagnostic["analysis"].contains("analysis_digest") ||
            !diagnostic["analysis"]["analysis_digest"].is_string()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_analysis_binding_mismatch",
              "serialized compression analysis has no observation/options binding");
        }
        analysis_observation_digest =
            diagnostic["analysis"]["observation_digest"].get<std::string>();
        auto parsed_analysis_digest = Digest256::from_hex(
            diagnostic["analysis"]["analysis_digest"]
                .get_ref<const std::string&>());
        if (!parsed_analysis_digest) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_analysis_binding_mismatch",
              "serialized analysis digest is not canonical SHA-256");
        }
        analysis_digest = std::move(parsed_analysis_digest).value();
      }

      const Json& terminal = diagnostic["terminal"];
      if (!exact_object_shape(terminal,
                              {"main_status", "failure_stage", "code"})) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_terminal_binding_mismatch",
            "result-v2 terminal context has an invalid closed shape");
      }
      auto terminal_status = parse_result_status_v2(terminal["main_status"]);
      if (!terminal_status || terminal_status.value() != status.value()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_terminal_binding_mismatch",
            "result-v2 terminal status differs from the main result");
      }
      if (failure.value().has_value()) {
        if (!terminal["failure_stage"].is_string() ||
            !terminal["code"].is_string() ||
            terminal["failure_stage"].get_ref<const std::string&>() !=
                result_failure_stage_text(failure.value()->stage) ||
            terminal["code"].get_ref<const std::string&>() !=
                failure.value()->code) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_terminal_binding_mismatch",
              "result-v2 terminal failure differs from the main result");
        }
      } else if (!terminal["failure_stage"].is_null() ||
                 (status.value() == ResultStatusV1::success &&
                  !terminal["code"].is_null()) ||
                 (status.value() == ResultStatusV1::unavailable &&
                  (!terminal["code"].is_string() ||
                   terminal["code"].get_ref<const std::string&>().empty()))) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_terminal_binding_mismatch",
            "result-v2 terminal context carries invalid failure state");
      }

      std::optional<Digest256> provider_observation_digest;
      const Json& provider = diagnostic["provider_supplied_profile"];
      if (!exact_object_shape(
              provider,
              {"status", "profile", "reason_code", "observation_digest",
               "provider_result_digest", "payload_digest"}) ||
          !provider["status"].is_string()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_provider_profile_shape_invalid",
            "result-v2 provider-supplied profile has an invalid closed shape");
      }
      const std::string& provider_status =
          provider["status"].get_ref<const std::string&>();
      if (provider_status == "available") {
        if (!provider["reason_code"].is_null() ||
            !provider["observation_digest"].is_string() ||
            !provider["provider_result_digest"].is_string() ||
            !provider["payload_digest"].is_string()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_provider_profile_shape_invalid",
              "available provider-supplied profile requires all authenticated bindings and no rejection reason");
        }
        auto profile = parse_supplied_profile_v2(provider["profile"], limits);
        if (!profile) {
          return Result<ParsedResultArtifactV2>::failure(profile.error());
        }
        auto observation_binding = Digest256::from_hex(
            provider["observation_digest"].get_ref<const std::string&>());
        auto result_binding = Digest256::from_hex(
            provider["provider_result_digest"].get_ref<const std::string&>());
        auto payload_binding = Digest256::from_hex(
            provider["payload_digest"].get_ref<const std::string&>());
        if (!observation_binding || !result_binding || !payload_binding) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_provider_profile_shape_invalid",
              "available provider profile bindings must be canonical SHA-256 digests");
        }
        provider_supplied_profile =
            std::make_shared<const SuppliedResponseProfileV1>(
                std::move(profile).value());
        provider_observation_digest =
            std::move(observation_binding).value();
        provider_supplied_result_digest =
            std::move(result_binding).value();
        provider_payload_digest = std::move(payload_binding).value();
      } else if (provider_status == "rejected") {
        if (!provider["profile"].is_null() ||
            !provider["reason_code"].is_string() ||
            provider["reason_code"].get_ref<const std::string&>().empty() ||
            !provider["observation_digest"].is_null() ||
            !provider["provider_result_digest"].is_null() ||
            !provider["payload_digest"].is_null()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_provider_profile_shape_invalid",
              "rejected provider-supplied profile requires a nonempty reason only");
        }
      } else if (provider_status == "not_reached") {
        if (!provider["profile"].is_null() ||
            (!provider["reason_code"].is_null() &&
             (!provider["reason_code"].is_string() ||
              provider["reason_code"]
                  .get_ref<const std::string&>()
                  .empty())) ||
            !provider["observation_digest"].is_null() ||
            !provider["provider_result_digest"].is_null() ||
            !provider["payload_digest"].is_null()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_provider_profile_shape_invalid",
              "provider-supplied profile not reached has invalid state");
        }
      } else if (provider_status == "not_applicable") {
        if (!provider["profile"].is_null() ||
            !provider["reason_code"].is_null() ||
            !provider["observation_digest"].is_null() ||
            !provider["provider_result_digest"].is_null() ||
            !provider["payload_digest"].is_null()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_provider_profile_shape_invalid",
              "non-applicable provider-supplied profile carries no values");
        }
      } else {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_provider_profile_shape_invalid",
            "result-v2 provider-supplied profile status is not recognized");
      }

      const Json& decoder = diagnostic["decoder_profile"];
      if (!exact_object_shape(decoder,
                              {"status", "profile", "reason_code",
                               "provider_result_digest",
                               "decoder_semantics_digest"}) ||
          !decoder["status"].is_string()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_decoder_profile_shape_invalid",
            "result-v2 decoder profile has an invalid closed shape");
      }
      const std::string& decoder_status =
          decoder["status"].get_ref<const std::string&>();
      if (decoder_status == "available") {
        if (!decoder["reason_code"].is_null() ||
            !decoder["provider_result_digest"].is_string() ||
            !decoder["decoder_semantics_digest"].is_string()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_decoder_profile_shape_invalid",
              "available decoder profile cannot carry a rejection reason");
        }
        auto profile = parse_supplied_profile_v2(decoder["profile"], limits);
        if (!profile) {
          return Result<ParsedResultArtifactV2>::failure(profile.error());
        }
        decoder_profile =
            std::make_shared<const SuppliedResponseProfileV1>(
                std::move(profile).value());
        auto provider_digest = Digest256::from_hex(
            decoder["provider_result_digest"].get_ref<const std::string&>());
        auto semantics_digest = Digest256::from_hex(
            decoder["decoder_semantics_digest"].get_ref<const std::string&>());
        if (!provider_digest || !semantics_digest) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_decoder_profile_shape_invalid",
              "available decoder bindings must be canonical SHA-256 digests");
        }
        provider_result_digest = std::move(provider_digest).value();
        decoder_semantics_digest = std::move(semantics_digest).value();
      } else if (decoder_status == "rejected") {
        if (!decoder["profile"].is_null() ||
            !decoder["reason_code"].is_string() ||
            decoder["reason_code"].get_ref<const std::string&>().empty() ||
            !decoder["provider_result_digest"].is_null() ||
            !decoder["decoder_semantics_digest"].is_null()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_decoder_profile_shape_invalid",
              "rejected decoder profile requires a nonempty reason only");
        }
      } else if (decoder_status == "not_reached") {
        if (!decoder["profile"].is_null() ||
            (!decoder["reason_code"].is_null() &&
             (!decoder["reason_code"].is_string() ||
              decoder["reason_code"]
                  .get_ref<const std::string&>()
                  .empty())) ||
            !decoder["provider_result_digest"].is_null() ||
            !decoder["decoder_semantics_digest"].is_null()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_decoder_profile_shape_invalid",
              "decoder profile not reached has invalid state");
        }
      } else if (decoder_status == "not_applicable") {
        if (!decoder["profile"].is_null() ||
            !decoder["reason_code"].is_null() ||
            !decoder["provider_result_digest"].is_null() ||
            !decoder["decoder_semantics_digest"].is_null()) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_decoder_profile_shape_invalid",
              "non-applicable decoder profile carries no values");
        }
      } else {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_decoder_profile_shape_invalid",
            "result-v2 decoder profile status is not recognized");
      }
      if (provider_supplied_result_digest.has_value() &&
          provider_result_digest.has_value() &&
          provider_supplied_result_digest != provider_result_digest) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_profile_provider_binding_mismatch",
            "provider-supplied and decoder-consumed profiles name different provider results");
      }

      std::string envelope_json = "{\"observation_bundle\":";
      envelope_json += diagnostic["observation_bundle"].dump();
      envelope_json += ",\"observation_bundle_digest\":";
      envelope_json += diagnostic["observation_bundle_digest"].dump();
      envelope_json += "}";
      // Release the potentially very large outer DOM before the observation
      // reader constructs its own typed representation.  The initial SAX
      // pass already applied the cumulative row/key/string/allocation caps to
      // the embedded observation, so this bounded canonical slice is the only
      // overlapping carrier.
      document = Json(nullptr);
      ObservationParseLimitsV1 observation_limits =
          default_observation_parse_limits_v1();
      observation_limits.maximum_bytes =
          std::min(observation_limits.maximum_bytes, limits.maximum_bytes);
      observation_limits.maximum_nesting_depth = std::min(
          observation_limits.maximum_nesting_depth,
          limits.maximum_nesting_depth);
      observation_limits.maximum_object_entries = std::min(
          observation_limits.maximum_object_entries,
          limits.maximum_object_entries);
      observation_limits.maximum_array_entries = std::min(
          observation_limits.maximum_array_entries,
          limits.maximum_array_entries);
      observation_limits.maximum_string_bytes = std::min(
          observation_limits.maximum_string_bytes,
          limits.maximum_string_bytes);
      if (bytes.size() >
              limits.maximum_total_decoded_allocation_bytes ||
          envelope_json.size() >
              limits.maximum_total_decoded_allocation_bytes - bytes.size() ||
          serialized_analysis_outcome.size() >
              limits.maximum_total_decoded_allocation_bytes - bytes.size() -
                  envelope_json.size()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_allocation_limit",
            "the embedded observation carrier exceeds the simultaneous allocation cap");
      }
      const std::size_t nested_allocation_budget =
          (limits.maximum_total_decoded_allocation_bytes - bytes.size() -
           envelope_json.size() - serialized_analysis_outcome.size()) /
          3U;
      observation_limits.maximum_total_decoded_allocation_bytes = std::min(
          observation_limits.maximum_total_decoded_allocation_bytes,
          nested_allocation_budget);
      const auto envelope_bytes = std::span<const std::byte>(
          reinterpret_cast<const std::byte*>(envelope_json.data()),
          envelope_json.size());
      auto parsed_envelope = parse_construction_observation_envelope_v1(
          envelope_bytes, observation_limits);
      if (!parsed_envelope) {
        return Result<ParsedResultArtifactV2>::failure(
            parsed_envelope.error());
      }
      auto validated = validate_construction_observation_envelope_v1(
          std::move(parsed_envelope).value(), observation_limits);
      if (!validated) {
        return Result<ParsedResultArtifactV2>::failure(validated.error());
      }
      observation =
          std::make_shared<const ValidatedConstructionObservationBundleV1>(
              std::move(validated).value());
      if (analysis_observation_digest.has_value() &&
          *analysis_observation_digest != observation->digest().hex()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_analysis_binding_mismatch",
            "serialized compression analysis is not bound to its observation");
      }
      if (provider_observation_digest.has_value() &&
          *provider_observation_digest != observation->digest()) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_provider_profile_binding_mismatch",
            "provider-supplied profile is not bound to its observation");
      }

      // result-v2 publishes the complete *effective* option preimage.  Do not
      // silently repair a noncanonical serialized request (notably an omitted
      // registered empty-backlog selection seed), because that would admit
      // multiple wire encodings for one analysis identity and return options
      // different from those actually verified below.
      auto effective_options = effective_compression_analysis_options_v1(
          *observation, *analysis_options);
      if (!effective_options) {
        return Result<ParsedResultArtifactV2>::failure(
            effective_options.error());
      }
      if (effective_options.value() != *analysis_options) {
        return fail_result<ParsedResultArtifactV2>(
            "c30.result_v2_analysis_options_not_effective",
            "serialized compression-analysis options are not the canonical effective options for the authenticated initialization descriptor");
      }

      // The serialized analysis is never treated as a trusted display
      // projection.  Recompute from the authenticated record and the complete
      // canonical option preimage, then require the full canonical projection
      // (including every derived closure, reward, gap/tie quantity, work
      // counter, and digest) to agree before exposing a typed analysis.
      auto recomputed = analyze_compression_observations_v1(
          *observation, *analysis_options);
      if (has_analysis) {
        if (!recomputed ||
            encode_compression_analysis(recomputed.value()).dump() !=
                serialized_analysis_outcome) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_analysis_verification_failed",
              "serialized compression analysis differs from deterministic recomputation over its authenticated observation and options");
        }
        if (!analysis_digest.has_value() ||
            *analysis_digest != recomputed.value().analysis_digest) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_analysis_verification_failed",
              "serialized compression analysis digest differs from its recomputed option binding");
        }
        verified_analysis =
            std::make_shared<const CompressionAnalysisResultV1>(
                std::move(recomputed).value());
      } else {
        if (recomputed ||
            encode_diagnostic(recomputed.error()).dump() !=
                serialized_analysis_outcome) {
          return fail_result<ParsedResultArtifactV2>(
              "c30.result_v2_analysis_verification_failed",
              "serialized compression-analysis failure differs from deterministic recomputation over its authenticated observation and options");
        }
      }
    }

    std::vector<std::byte> canonical(bytes.begin(), bytes.end());
    return Result<ParsedResultArtifactV2>::success(ParsedResultArtifactV2(
        status.value(), std::move(failure).value(), std::move(observation),
        std::move(analysis_digest),
        std::move(verified_analysis), std::move(analysis_options),
        std::move(provider_supplied_profile),
        std::move(provider_supplied_result_digest),
        std::move(provider_payload_digest),
        std::move(decoder_profile), std::move(provider_result_digest),
        std::move(decoder_semantics_digest), std::move(canonical)));
  } catch (const nlohmann::json::exception&) {
    return fail_result<ParsedResultArtifactV2>(
        "c30.result_v2_invalid_json",
        "result-v2 could not be decoded as canonical JSON");
  } catch (const std::bad_alloc&) {
    return fail_result<ParsedResultArtifactV2>(
        "c30.result_v2_allocation_limit",
        "result-v2 decoding could not allocate within process resources");
  }
}

Result<ParsedResultArtifactV3> parse_result_artifact_v3(
    const std::span<const std::byte> bytes,
    const ResultArtifactParseLimitsV2& limits) {
  if (limits.maximum_bytes == 0U || limits.maximum_nesting_depth == 0U ||
      limits.maximum_object_entries == 0U ||
      limits.maximum_array_entries == 0U ||
      limits.maximum_string_bytes == 0U ||
      limits.maximum_total_decoded_allocation_bytes == 0U) {
    return fail_result<ParsedResultArtifactV3>(
        "c32.result_v3_parse_limits_invalid",
        "result-v3 parse limits must all be positive");
  }
  if (bytes.empty() || bytes.size() > limits.maximum_bytes) {
    return fail_result<ParsedResultArtifactV3>(
        "c32.result_v3_byte_limit",
        "result-v3 is empty or exceeds the configured byte cap");
  }

  try {
    const char* const source_begin =
        reinterpret_cast<const char*>(bytes.data());
    const char* const source_end = source_begin + bytes.size();
    // Result-v2 and result-v3 deliberately share the same bounded JSON and
    // embedded-observation grammar.  Reuse the one cumulative preflight so a
    // version choice cannot change allocation, nesting, or duplicate-key
    // admission semantics.
    ResultV2SaxPreflight preflight(limits);
    if (!Json::sax_parse(source_begin, source_end, &preflight,
                         Json::input_format_t::json, true)) {
      if (preflight.diagnostic()) {
        return Result<ParsedResultArtifactV3>::failure(
            *preflight.diagnostic());
      }
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_invalid_json", "result-v3 is not valid JSON");
    }
    const std::size_t decoded_estimate =
        preflight.estimated_decoded_allocation();
    if (decoded_estimate > limits.maximum_total_decoded_allocation_bytes ||
        bytes.size() >
            (limits.maximum_total_decoded_allocation_bytes -
             decoded_estimate) /
                3U) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_allocation_limit",
          "result-v3 canonical verification would exceed the simultaneous allocation cap");
    }

    Json document = Json::parse(source_begin, source_end);
    {
      const std::string canonical_encoding = document.dump();
      if (canonical_encoding.size() != bytes.size() ||
          std::memcmp(canonical_encoding.data(), source_begin, bytes.size()) !=
              0) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_noncanonical",
            "result-v3 must use the canonical compact JSON encoding");
      }
    }
    if (const auto schema_failure =
            validate_result_v3_json_against_published_schema(document)) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_schema_validation_failed",
          "result-v3 violates the published closed schema at " +
              schema_failure->path + ": " + schema_failure->message);
    }
    auto canonical_rationals =
        validate_canonical_compact_rationals_v2(document, limits);
    if (!canonical_rationals) {
      return Result<ParsedResultArtifactV3>::failure(
          canonical_rationals.error());
    }
    if (const auto order_failure =
            validate_result_v3_canonical_member_order(document)) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_noncanonical",
          "result-v3 members are not in canonical order at " +
              order_failure->path + ": " + order_failure->message);
    }
    if (!exact_object_shape(
            document,
            {"result_version", "status", "failure", "result_kind",
             "main_result", "provenance", "diagnostic_supplement"}) ||
        !document["result_version"].is_number_unsigned() ||
        document["result_version"].get<std::uint64_t>() != 3U ||
        (!document["main_result"].is_null() &&
         !document["main_result"].is_object()) ||
        !document["provenance"].is_object()) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_root_invalid",
          "result-v3 has an invalid closed root object");
    }

    auto status = parse_result_status_v2(document["status"]);
    if (!status) {
      return Result<ParsedResultArtifactV3>::failure(status.error());
    }
    auto failure =
        parse_result_failure_v2(document["failure"], status.value());
    if (!failure) {
      return Result<ParsedResultArtifactV3>::failure(failure.error());
    }
    const std::string_view expected_kind =
        status.value() == ResultStatusV1::success
            ? std::string_view("observed")
            : status.value() == ResultStatusV1::unavailable
                  ? std::string_view("unavailable")
                  : std::string_view("failed");
    if (!document["result_kind"].is_string() ||
        document["result_kind"].get_ref<const std::string&>() !=
            expected_kind) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_terminal_invalid",
          "result-v3 kind does not match its typed terminal status");
    }
    const std::string serialized_framework_prediction =
        document["main_result"].dump();

    const Json& provenance = document["provenance"];
    if (provenance["input_fingerprints"]["model"] !=
            provenance["model"]["fingerprint"] ||
        provenance["input_fingerprints"]["analysis"] !=
            provenance["analysis"]["fingerprint"]) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_provenance_invalid",
          "result-v3 model and analysis provenance are not bound to the input fingerprints");
    }
    const bool request_construction_failure =
        failure.value().has_value() &&
        failure.value()->stage ==
            ResultFailureStageV1::request_construction;
    if (provenance["build_request"].is_null() !=
        request_construction_failure) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_build_request_identity_invalid",
          "result-v3 build-request provenance is absent exactly when request construction failed");
    }
    if (!provenance["build_request"].is_null() &&
        provenance["build_request"]["rng_version"].get<std::uint64_t>() !=
            kRngVersion) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_build_request_identity_invalid",
          "result-v3 build-request provenance names an unsupported RNG version");
    }
    std::optional<Digest256> provider_result_digest;
    if (!provenance["provider_result_digest"].is_null()) {
      auto parsed_digest = Digest256::from_hex(
          provenance["provider_result_digest"].get_ref<const std::string&>());
      if (!parsed_digest) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_provider_result_digest_invalid",
            "result-v3 provider-result binding is not a canonical SHA-256 digest");
      }
      provider_result_digest = std::move(parsed_digest).value();
    }

    const Json& diagnostic = document["diagnostic_supplement"];
    if (diagnostic.is_null()) {
      const bool pre_observation_stage =
          failure.value().has_value() &&
          (failure.value()->stage ==
               ResultFailureStageV1::request_construction ||
           failure.value()->stage == ResultFailureStageV1::producer_execution ||
           failure.value()->stage == ResultFailureStageV1::wire_parse ||
           failure.value()->stage ==
               ResultFailureStageV1::build_contract_validation);
      if (status.value() != ResultStatusV1::failed ||
          !pre_observation_stage || provider_result_digest.has_value() ||
          !document["main_result"].is_null()) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_pre_observation_shape_invalid",
            "only a typed pre-observation failure may omit the diagnostic supplement and provider-result digest");
      }
      std::vector<std::byte> canonical(bytes.begin(), bytes.end());
      return Result<ParsedResultArtifactV3>::success(ParsedResultArtifactV3(
          status.value(), std::move(failure).value(), nullptr, std::nullopt,
          nullptr, nullptr, nullptr, std::nullopt, std::move(canonical)));
    }

    if (!provider_result_digest.has_value() ||
        !exact_object_shape(
            diagnostic,
            {"terminal", "provider_supplied_profile", "decoder_profile",
             "analysis_options", "analysis", "analysis_failure",
             "observation_bundle_digest", "observation_bundle"}) ||
        !diagnostic["observation_bundle_digest"].is_string() ||
        !diagnostic["observation_bundle"].is_object()) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_supplement_invalid",
          "observed result-v3 requires a bound diagnostic supplement with an observation");
    }

    const bool has_analysis = !diagnostic["analysis"].is_null();
    const bool has_analysis_failure =
        !diagnostic["analysis_failure"].is_null();
    if (has_analysis == has_analysis_failure ||
        (status.value() == ResultStatusV1::success && !has_analysis) ||
        has_analysis != document["main_result"].is_object() ||
        (has_analysis && !diagnostic["analysis"].is_object()) ||
        (has_analysis_failure &&
         (!diagnostic["analysis_failure"].is_object() ||
          !diagnostic["analysis_failure"].contains("code") ||
          !diagnostic["analysis_failure"]["code"].is_string()))) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_analysis_outcome_invalid",
          "result-v3 must retain exactly one valid compression-analysis outcome");
    }

    auto parsed_analysis_options = parse_compression_analysis_options(
        diagnostic["analysis_options"], limits,
        ResultArtifactVersionV1::v3);
    if (!parsed_analysis_options) {
      return Result<ParsedResultArtifactV3>::failure(
          parsed_analysis_options.error());
    }
    auto analysis_options =
        std::make_shared<const CompressionAnalysisOptionsV1>(
            std::move(parsed_analysis_options).value());
    const std::string serialized_analysis_outcome =
        has_analysis ? diagnostic["analysis"].dump()
                     : diagnostic["analysis_failure"].dump();
    std::optional<std::string> analysis_observation_digest;
    std::optional<Digest256> analysis_digest;
    if (has_analysis) {
      if (!diagnostic["analysis"].contains("observation_digest") ||
          !diagnostic["analysis"]["observation_digest"].is_string() ||
          !diagnostic["analysis"].contains("analysis_digest") ||
          !diagnostic["analysis"]["analysis_digest"].is_string()) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_analysis_binding_mismatch",
            "serialized empirical analysis has no observation/options binding");
      }
      analysis_observation_digest =
          diagnostic["analysis"]["observation_digest"].get<std::string>();
      auto parsed_digest = Digest256::from_hex(
          diagnostic["analysis"]["analysis_digest"]
              .get_ref<const std::string&>());
      if (!parsed_digest) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_analysis_binding_mismatch",
            "serialized empirical analysis digest is not canonical SHA-256");
      }
      analysis_digest = std::move(parsed_digest).value();
    }

    const Json& terminal = diagnostic["terminal"];
    if (!exact_object_shape(terminal,
                            {"main_status", "failure_stage", "code"})) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_terminal_binding_mismatch",
          "result-v3 terminal context has an invalid closed shape");
    }
    auto terminal_status = parse_result_status_v2(terminal["main_status"]);
    if (!terminal_status || terminal_status.value() != status.value()) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_terminal_binding_mismatch",
          "result-v3 diagnostic terminal differs from its outer status");
    }
    if (failure.value().has_value()) {
      if (!terminal["failure_stage"].is_string() ||
          !terminal["code"].is_string() ||
          terminal["failure_stage"].get_ref<const std::string&>() !=
              result_failure_stage_text(failure.value()->stage) ||
          terminal["code"].get_ref<const std::string&>() !=
              failure.value()->code) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_terminal_binding_mismatch",
            "result-v3 diagnostic failure differs from its outer failure");
      }
    } else if (!terminal["failure_stage"].is_null() ||
               (status.value() == ResultStatusV1::success &&
                !terminal["code"].is_null()) ||
               (status.value() == ResultStatusV1::unavailable &&
                (!terminal["code"].is_string() ||
                 terminal["code"].get_ref<const std::string&>().empty()))) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_terminal_binding_mismatch",
          "result-v3 diagnostic terminal carries invalid failure state");
    }

    const Json& provider = diagnostic["provider_supplied_profile"];
    const Json& decoder = diagnostic["decoder_profile"];
    if (!exact_object_shape(
            provider,
            {"status", "profile", "reason_code", "observation_digest",
             "provider_result_digest", "payload_digest"}) ||
        !provider["status"].is_string() ||
        provider["status"].get_ref<const std::string&>() !=
            "not_applicable" ||
        !provider["profile"].is_null() ||
        !provider["reason_code"].is_null() ||
        !provider["observation_digest"].is_null() ||
        !provider["provider_result_digest"].is_null() ||
        !provider["payload_digest"].is_null() ||
        !exact_object_shape(
            decoder,
            {"status", "profile", "reason_code", "provider_result_digest",
             "decoder_semantics_digest"}) ||
        !decoder["status"].is_string() ||
        decoder["status"].get_ref<const std::string&>() !=
            "not_applicable" ||
        !decoder["profile"].is_null() ||
        !decoder["reason_code"].is_null() ||
        !decoder["provider_result_digest"].is_null() ||
        !decoder["decoder_semantics_digest"].is_null()) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_profile_state_invalid",
          "result-v3 cannot carry deployed provider or decoder profiles");
    }

    std::string envelope_json = "{\"observation_bundle\":";
    envelope_json += diagnostic["observation_bundle"].dump();
    envelope_json += ",\"observation_bundle_digest\":";
    envelope_json += diagnostic["observation_bundle_digest"].dump();
    envelope_json += "}";
    document = Json(nullptr);
    ObservationParseLimitsV1 observation_limits =
        default_observation_parse_limits_v1();
    observation_limits.maximum_bytes =
        std::min(observation_limits.maximum_bytes, limits.maximum_bytes);
    observation_limits.maximum_nesting_depth = std::min(
        observation_limits.maximum_nesting_depth,
        limits.maximum_nesting_depth);
    observation_limits.maximum_object_entries = std::min(
        observation_limits.maximum_object_entries,
        limits.maximum_object_entries);
    observation_limits.maximum_array_entries = std::min(
        observation_limits.maximum_array_entries,
        limits.maximum_array_entries);
    observation_limits.maximum_string_bytes = std::min(
        observation_limits.maximum_string_bytes, limits.maximum_string_bytes);
    if (bytes.size() > limits.maximum_total_decoded_allocation_bytes ||
        envelope_json.size() >
            limits.maximum_total_decoded_allocation_bytes - bytes.size() ||
        serialized_analysis_outcome.size() >
            limits.maximum_total_decoded_allocation_bytes - bytes.size() -
                envelope_json.size() ||
        serialized_framework_prediction.size() >
            limits.maximum_total_decoded_allocation_bytes - bytes.size() -
                envelope_json.size() - serialized_analysis_outcome.size()) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_allocation_limit",
          "the embedded observation carrier exceeds the simultaneous allocation cap");
    }
    const std::size_t nested_allocation_budget =
        (limits.maximum_total_decoded_allocation_bytes - bytes.size() -
         envelope_json.size() - serialized_analysis_outcome.size() -
         serialized_framework_prediction.size()) /
        3U;
    observation_limits.maximum_total_decoded_allocation_bytes = std::min(
        observation_limits.maximum_total_decoded_allocation_bytes,
        nested_allocation_budget);
    const auto envelope_bytes = std::span<const std::byte>(
        reinterpret_cast<const std::byte*>(envelope_json.data()),
        envelope_json.size());
    auto parsed_envelope = parse_construction_observation_envelope_v1(
        envelope_bytes, observation_limits);
    if (!parsed_envelope) {
      return Result<ParsedResultArtifactV3>::failure(
          parsed_envelope.error());
    }
    auto validated = validate_construction_observation_envelope_v1(
        std::move(parsed_envelope).value(), observation_limits);
    if (!validated) {
      return Result<ParsedResultArtifactV3>::failure(validated.error());
    }
    auto observation =
        std::make_shared<const ValidatedConstructionObservationBundleV1>(
            std::move(validated).value());
    if (analysis_observation_digest.has_value() &&
        *analysis_observation_digest != observation->digest().hex()) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_analysis_binding_mismatch",
          "serialized empirical analysis is not bound to its observation");
    }

    auto effective_options = effective_compression_analysis_options_v1(
        *observation, *analysis_options);
    if (!effective_options) {
      return Result<ParsedResultArtifactV3>::failure(
          effective_options.error());
    }
    if (effective_options.value() != *analysis_options) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_analysis_options_not_effective",
          "serialized empirical analysis options are not the canonical effective options for the authenticated observation");
    }
    if (analysis_options->projection_mode !=
            CompressionAnalysisOptionsV1::ProjectionMode::
                empirical_finite_window_response ||
        !analysis_options->ensemble_population_size.has_value() ||
        analysis_options->ensemble_population_size->is_zero() ||
        analysis_options->run_diagnostic_fits ||
        analysis_options->compute_delete_one_replication_jackknife ||
        analysis_options->stationary_coefficients_established ||
        analysis_options->prefix_preservation_established ||
        !analysis_options->provider_supplied_profiles.empty() ||
        !published_analysis_options_within_limits(*analysis_options)) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_analysis_options_invalid",
          "result-v3 requires resource-admitted empirical finite-window projection options");
    }

    auto recomputed = analyze_compression_observations_v1(
        *observation, *analysis_options);
    std::shared_ptr<const CompressionAnalysisResultV1> verified_analysis;
    std::shared_ptr<const FrameworkEmpiricalPredictionV1>
        verified_framework_prediction;
    if (has_analysis) {
      if (!recomputed ||
          encode_compression_analysis(recomputed.value()).dump() !=
              serialized_analysis_outcome ||
          !analysis_digest.has_value() ||
          *analysis_digest != recomputed.value().analysis_digest) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.result_v3_analysis_verification_failed",
            "serialized empirical analysis differs from deterministic recomputation over its authenticated observation and options");
      }
      verified_analysis =
          std::make_shared<const CompressionAnalysisResultV1>(
              std::move(recomputed).value());
      FrameworkEmpiricalPredictionV1 prediction =
          derive_framework_empirical_prediction_v1(
              *observation, *verified_analysis, *analysis_options);
      const bool current_prediction_matches =
          encode_framework_empirical_prediction(prediction).dump() ==
          serialized_framework_prediction;
      const bool legacy_poisson_prediction_matches =
          !current_prediction_matches && analysis_options->poisson_overshoot &&
          encode_legacy_poisson_framework_prediction_v1(prediction).dump() ==
              serialized_framework_prediction;
      if (!current_prediction_matches &&
          !legacy_poisson_prediction_matches) {
        return fail_result<ParsedResultArtifactV3>(
            "c32.framework_prediction_verification_failed",
            "serialized framework prediction differs from deterministic recomputation over the authenticated raw response");
      }
      verified_framework_prediction =
          std::make_shared<const FrameworkEmpiricalPredictionV1>(
              std::move(prediction));
    } else if (recomputed ||
               encode_diagnostic(recomputed.error()).dump() !=
                   serialized_analysis_outcome) {
      return fail_result<ParsedResultArtifactV3>(
          "c32.result_v3_analysis_verification_failed",
          "serialized empirical analysis failure differs from deterministic recomputation over its authenticated observation and options");
    }

    std::vector<std::byte> canonical(bytes.begin(), bytes.end());
    return Result<ParsedResultArtifactV3>::success(ParsedResultArtifactV3(
        status.value(), std::move(failure).value(), std::move(observation),
        std::move(analysis_digest), std::move(verified_analysis),
        std::move(analysis_options),
        std::move(verified_framework_prediction),
        std::move(provider_result_digest), std::move(canonical)));
  } catch (const nlohmann::json::exception&) {
    return fail_result<ParsedResultArtifactV3>(
        "c32.result_v3_invalid_json",
        "result-v3 could not be decoded as canonical JSON");
  } catch (const std::bad_alloc&) {
    return fail_result<ParsedResultArtifactV3>(
        "c32.result_v3_allocation_limit",
        "result-v3 decoding could not allocate within process resources");
  }
}

Result<ResultArtifact> ResultArtifact::make_checked(
    ResultArtifactDataV1 value) {
  auto valid = validate_result_data(value);
  if (!valid) {
    return Result<ResultArtifact>::failure(valid.error());
  }
  return Result<ResultArtifact>::success(
      ResultArtifact(std::move(value)));
}

Result<ResultArtifactV2> ResultArtifactV2::make_checked(
    ResultArtifactDataV2 value) {
  auto valid = validate_diagnostic_supplement_v2(
      value, true /* arbitrary typed input must be scientifically verified */);
  if (!valid) {
    return Result<ResultArtifactV2>::failure(valid.error());
  }
  return Result<ResultArtifactV2>::success(
      ResultArtifactV2(std::move(value)));
}

Result<ResultArtifactV2> ResultArtifactV2::make_from_trusted_execution(
    ResultArtifactDataV2 value) {
  auto valid = validate_diagnostic_supplement_v2(
      value, false /* AnalysisBundle is an immutable execute_analysis mint */);
  if (!valid) {
    return Result<ResultArtifactV2>::failure(valid.error());
  }
  return Result<ResultArtifactV2>::success(
      ResultArtifactV2(std::move(value)));
}

Result<ResultArtifactV3> ResultArtifactV3::make_from_trusted_execution(
    ResultArtifactDataV3 value) {
  auto valid = validate_observed_result_v3(
      value, false /* AnalysisBundle is an immutable execute_analysis mint */);
  if (!valid) {
    return Result<ResultArtifactV3>::failure(valid.error());
  }
  return Result<ResultArtifactV3>::success(
      ResultArtifactV3(std::move(value)));
}

ResultArtifactVersionV1 PublishedResultArtifact::version() const noexcept {
  if (std::holds_alternative<ResultArtifact>(value_)) {
    return ResultArtifactVersionV1::v1;
  }
  if (std::holds_alternative<ResultArtifactV2>(value_)) {
    return ResultArtifactVersionV1::v2;
  }
  return ResultArtifactVersionV1::v3;
}

ResultStatusV1 PublishedResultArtifact::status() const noexcept {
  return std::visit(
      [](const auto& artifact) { return artifact.status(); }, value_);
}

Result<ResultArtifact> assemble_result_artifact(
    const ResolvedRequest& request, const ExecutionPlan& plan,
    const AnalysisBundle& analysis_bundle) {
  if (!request.shares_resolution_owner_with(plan.resolved_request())) {
    return fail_result<ResultArtifact>(
        "c27.result_request_plan_mismatch",
        "result assembly rejected a request from a different resolved plan");
  }
  // Revalidate the complete backend payloads here, rather than treating the
  // route-kind vector below as a substitute for the frozen route identity.
  auto plan_valid = validate_execution_plan(plan);
  if (!plan_valid) {
    return Result<ResultArtifact>::failure(plan_valid.error());
  }

  const AnalysisExecutionIdentityV1& identity =
      analysis_bundle.execution_identity();
  const SurrogateProviderManifestV1& manifest =
      plan.provider_manifest().value();
  std::vector<std::string> planned_metric_ids;
  std::vector<BackendRouteKindV1> planned_backend_routes;
  planned_metric_ids.reserve(plan.metric_requests().size());
  planned_backend_routes.reserve(plan.metric_plans().size());
  for (const MetricRequest& metric : plan.metric_requests()) {
    planned_metric_ids.push_back(metric_request_header(metric).metric_id);
  }
  for (const PlannedMetricV1& metric : plan.metric_plans()) {
    planned_backend_routes.push_back(metric.route_kind());
  }

  if (identity.fingerprints != request.fingerprints() ||
      identity.fingerprints !=
          plan.problem_view().fingerprints().authored_inputs ||
      identity.provider != manifest.provider ||
      identity.provider_digest !=
          plan.provider_manifest().scientific_contract_digest() ||
      identity.accepted_contract_digest !=
          plan.capability_contract().contract_digest() ||
      identity.construction_method != plan.construction_method() ||
      identity.producer_mode != plan.producer_mode() ||
      identity.master_seed != request.master_seed() ||
      identity.ordered_targets !=
          plan.problem_view().target_selection().ordered_targets ||
      identity.selection != plan.problem_view().analysis_selection() ||
      identity.solver_regime != plan.solver_regime() ||
      identity.metric_ids != planned_metric_ids ||
      identity.backend_routes != planned_backend_routes) {
    return fail_result<ResultArtifact>(
        "c27.result_execution_binding_mismatch",
        "analysis output identity does not match the frozen request and execution plan");
  }

  const ResultStatusV1 status = analysis_bundle.status();
  if (!valid_status(status)) {
    return fail_result<ResultArtifact>(
        "c27.result_status_invalid",
        "analysis output status is outside result-v1");
  }
  if ((status == ResultStatusV1::failed) !=
      analysis_bundle.failure().has_value()) {
    return fail_result<ResultArtifact>(
        "c27.result_failure_shape_invalid",
        "analysis output failure is present exactly for a failed result");
  }
  if (status == ResultStatusV1::failed &&
      !analysis_bundle.metrics().empty()) {
    return fail_result<ResultArtifact>(
        "c27.result_partial_failure",
        "a failed analysis output may not retain partially computed metrics");
  }
  if (status != ResultStatusV1::failed &&
      analysis_bundle.metrics().size() != plan.metric_requests().size()) {
    return fail_result<ResultArtifact>(
        "c27.result_metric_set_mismatch",
        "analysis output does not contain the complete ordered metric set");
  }
  for (const ResultMetricV1& metric : analysis_bundle.metrics()) {
    const bool established =
        std::holds_alternative<EstablishedResultMetricV1>(metric);
    if (status == ResultStatusV1::success && !established) {
      return fail_result<ResultArtifact>(
          "c27.result_success_not_established",
          "every metric in a successful analysis output must be established");
    }
    if (status == ResultStatusV1::unavailable && established) {
      return fail_result<ResultArtifact>(
          "c27.result_unavailable_has_value",
          "an unavailable analysis output may not contain a numeric metric value");
    }
  }

  const bool request_construction_failure =
      analysis_bundle.failure().has_value() &&
      analysis_bundle.failure()->stage ==
          ResultFailureStageV1::request_construction;
  if (identity.request_identity.has_value() == request_construction_failure) {
    return fail_result<ResultArtifact>(
        "c27.result_request_identity_mismatch",
        "analysis request identities are absent exactly for request-construction failure");
  }
  if (identity.request_identity.has_value()) {
    const AnalysisBuildRequestIdentityV1& request_identity =
        *identity.request_identity;
    if (request_identity.build_seed.master_seed() != identity.master_seed ||
        !request_identity.build_seed.is_bound_to(
            request_identity.build_identity_digest)) {
      return fail_result<ResultArtifact>(
          "c27.result_seed_binding_mismatch",
          "analysis output carries a foreign or internally inconsistent build seed");
    }
    if (analysis_bundle.build_report().has_value() &&
        analysis_bundle.build_report()->request_digest !=
            request_identity.build_request_digest.value()) {
      return fail_result<ResultArtifact>(
          "c27.result_build_report_binding_mismatch",
          "the build report is bound to a different build request");
    }
  }
  if (identity.payload_digest.has_value() != identity.plug_kind.has_value()) {
    return fail_result<ResultArtifact>(
        "c27.result_payload_binding_mismatch",
        "payload digest and bound plug kind must be present or absent together");
  }
  if ((identity.execution_seal_digest.has_value() &&
       !identity.payload_digest.has_value()) ||
      (analysis_bundle.status() == ResultStatusV1::success &&
       !identity.execution_seal_digest.has_value())) {
    return fail_result<ResultArtifact>(
        "c27.result_execution_seal_mismatch",
        "a validated execution seal is required for success and cannot exist without a bound payload");
  }

  auto failure_provenance = validate_failure_stage_provenance(
      analysis_bundle.failure(), identity.payload_digest.has_value(),
      identity.execution_seal_digest.has_value(),
      analysis_bundle.certificates());
  if (!failure_provenance) {
    return Result<ResultArtifact>::failure(failure_provenance.error());
  }

  auto accounting_bindings =
      validate_analysis_accounting_bindings(plan, analysis_bundle);
  if (!accounting_bindings) {
    return Result<ResultArtifact>::failure(accounting_bindings.error());
  }

  for (const ResultDiagnosticV1& diagnostic :
       analysis_bundle.diagnostics()) {
    if (!diagnostic.product.has_value()) {
      continue;
    }
    const ResultProductBindingV1& product = *diagnostic.product;
    if (!identity.request_identity.has_value() ||
        !identity.payload_digest.has_value() ||
        product.provider != identity.provider ||
        product.payload_identity.object_digest != *identity.payload_digest ||
        product.build_identity !=
            identity.request_identity->build_identity_digest.digest() ||
        product.request_identity !=
            identity.request_identity->build_request_digest.value() ||
        (product.law_identity.has_value() &&
         (!identity.execution_seal_digest.has_value() ||
          product.law_identity->execution_identity !=
              *identity.execution_seal_digest))) {
      return fail_result<ResultArtifact>(
          "c27.result_diagnostic_binding_mismatch",
          "a diagnostic product is bound to a foreign provider, payload, build request, or execution seal");
    }
    if (product.product_kind == ProductKindV1::projection_center ||
        product.product_kind == ProductKindV1::projected_mean) {
      const auto expected_targets =
          plan.capability_contract().construction_target_scope();
      if (product.ordered_construction_targets.size() !=
              expected_targets.size() ||
          !std::equal(product.ordered_construction_targets.begin(),
                      product.ordered_construction_targets.end(),
                      expected_targets.begin(), expected_targets.end())) {
        return fail_result<ResultArtifact>(
            "c27.result_diagnostic_binding_mismatch",
            "a mean-stage diagnostic product has a foreign ordered construction-target scope");
      }
    }
  }

  for (std::size_t index = 0U; index < analysis_bundle.metrics().size();
       ++index) {
    const ResultMetricHeaderV1& produced =
        result_metric_header(analysis_bundle.metrics()[index]);
    const MetricRequestHeader& planned =
        metric_request_header(plan.metric_requests()[index]);
    const PlannedMetricV1& planned_metric = plan.metric_plans()[index];
    const auto support_clauses =
        plan.capability_contract().structural_manifest().clauses();
    const auto support_clause = std::find_if(
        support_clauses.begin(), support_clauses.end(),
        [&planned_metric](const MetricSupportClauseV1& clause) {
          return clause.clause_id == planned_metric.contract().clause_id;
        });
    std::vector<QueueId> planned_targets;
    planned_targets.reserve(planned.ordered_targets.size());
    for (const ResolvedMetricTargetV1& target : planned.ordered_targets) {
      planned_targets.push_back(target.queue_id);
    }
    if (produced.metric_id != planned.metric_id ||
        produced.kind != planned.kind ||
        produced.ordered_targets != planned_targets ||
        support_clause == support_clauses.end() ||
        produced.scientific_scope != support_clause->result_scope) {
      return fail_result<ResultArtifact>(
          "c27.result_metric_binding_mismatch",
          "a metric output is bound to a foreign request, target, route, or scientific scope");
    }

    // backlog_conditioned_service is an ordered level-indexed quantity on
    // every accepted backend, including C24's one-level exact-point lane.
    // Reject a scalar (or a vector with the wrong cardinality) here so a
    // producer cannot silently erase the authored conditioning coordinate at
    // result assembly.
    if (planned.kind == MetricKindV1::backlog_conditioned_service &&
        std::holds_alternative<EstablishedResultMetricV1>(
            analysis_bundle.metrics()[index])) {
      const auto* authored =
          std::get_if<BacklogConditionedServiceRequestV1>(
              &plan.metric_requests()[index]);
      const auto& established = std::get<EstablishedResultMetricV1>(
          analysis_bundle.metrics()[index]);
      const auto* level_values =
          std::get_if<ResultScalarVectorV1>(&established.value);
      if (authored == nullptr || level_values == nullptr ||
          level_values->values.size() !=
              authored->parameters().levels.size()) {
        return fail_result<ResultArtifact>(
            "c27.result_metric_shape_mismatch",
            "backlog_conditioned_service must retain one ordered scalar for every authored backlog level");
      }
    }
  }

  const BuildInformation information = build_information();
  ResultBuildProvenanceV1 build{
      .core = "program=" + information.program_version +
              ";source=" + information.source_tree_version +
              ";compiler=" + information.compiler_id + "-" +
              information.compiler_version + ";features=" +
              information.enabled_features,
      .rng = information.rng_algorithm_version,
      .interfaces = information.function_interface_manifest_version,
  };

  std::optional<ResultBuildRequestIdentityV1> request_identity;
  if (identity.request_identity.has_value()) {
    request_identity = ResultBuildRequestIdentityV1{
        identity.request_identity->build_identity_digest,
        identity.request_identity->build_seed,
        identity.request_identity->build_request_digest};
  }

  ResultArtifactDataV1 value{
      .status = analysis_bundle.status(),
      .failure = analysis_bundle.failure(),
      .input_fingerprints = request.fingerprints(),
      .build = std::move(build),
      .execution =
          ResultExecutionProvenanceV1{
              .actual_seed = identity.master_seed,
              .build_request_identity = std::move(request_identity),
              .replay_streams =
                  std::vector<ResultReplayStreamV1>(
                      analysis_bundle.replay_streams().begin(),
                      analysis_bundle.replay_streams().end()),
              .budget_usage =
                  std::vector<ResultBudgetUsageV1>(
                      analysis_bundle.execution_budget_usage().begin(),
                      analysis_bundle.execution_budget_usage().end()),
              .execution_seal_digest = identity.execution_seal_digest,
          },
      .model =
          ResultModelProvenanceV1{
              .schema_version =
                  request.instance().authored_model().schema_version.value,
              .fingerprint = request.fingerprints().model,
          },
      .analysis =
          ResultAnalysisProvenanceV1{
              .schema_version = request.instance()
                                    .analysis_spec()
                                    .analysis_schema_version,
              .fingerprint = request.fingerprints().analysis,
              .ordered_targets = identity.ordered_targets,
              .metric_ids = identity.metric_ids,
              .selection = identity.selection,
              .solver_regime = identity.solver_regime,
          },
      .surrogate =
          ResultSurrogateProvenanceV1{
              .provider = identity.provider,
              .construction_method = identity.construction_method,
              .producer_mode = identity.producer_mode,
              .provider_digest = identity.provider_digest,
              .payload_digest = identity.payload_digest,
              .plug_kind = identity.plug_kind,
          },
      .metrics = std::vector<ResultMetricV1>(analysis_bundle.metrics().begin(),
                                             analysis_bundle.metrics().end()),
      .certificates =
          std::vector<ResultCertificateV1>(
              analysis_bundle.certificates().begin(),
              analysis_bundle.certificates().end()),
      .diagnostics =
          std::vector<ResultDiagnosticV1>(
              analysis_bundle.diagnostics().begin(),
              analysis_bundle.diagnostics().end()),
      .budgets_used =
          std::vector<ResultBudgetUsageV1>(
              analysis_bundle.backend_budget_usage().begin(),
              analysis_bundle.backend_budget_usage().end()),
      .config_name = request.model_path().path.filename().string(),
      .response_curve =
          analysis_bundle.response_curve().has_value()
              ? std::optional<ResultResponseCurveV1>(ResultResponseCurveV1{
                    .target = analysis_bundle.response_curve()->target,
                    .backlog_zero = PortableScientificScalar::rational(
                        analysis_bundle.response_curve()->backlog_zero),
                    .backlog_one = PortableScientificScalar::rational(
                        analysis_bundle.response_curve()->backlog_one),
                    .backlog_two = PortableScientificScalar::rational(
                        analysis_bundle.response_curve()->backlog_two),
                    .backlog_at_least_three =
                        PortableScientificScalar::rational(
                            analysis_bundle.response_curve()
                                ->backlog_at_least_three),
                })
              : std::nullopt,
      .unavailable_diagnostics =
          analysis_bundle.unavailable_diagnostics(),
      .wall_clock_times =
          ResultWallClockTimesV1{
              .end_to_end = analysis_bundle.wall_clock_times().end_to_end,
              .sampler = analysis_bundle.wall_clock_times().sampler,
              .framework = analysis_bundle.wall_clock_times().framework,
          },
      .output_resources = request.analyze().output_resources,
      .report_unavailable_diagnostics =
          request.analyze().report_unavailable_diagnostics,
      .worker_count = request.analyze().worker_count,
      .optimizer_calls_observed =
          analysis_bundle.optimizer_calls_observed(),
      .optimizer_search_states_observed =
          analysis_bundle.optimizer_search_states_observed(),
  };
  return ResultArtifact::make_checked(std::move(value));
}

Result<PublishedResultArtifact> assemble_selected_result_artifact(
    const ResolvedRequest& request, const ExecutionPlan& plan,
    const AnalysisBundle& analysis_bundle,
    const ResultVersionSelectionV1 selection) {
  const bool route_requires_v3 =
      plan.provider().result_protocol_version() == 3U;
  if (route_requires_v3) {
    if (selection == ResultVersionSelectionV1::v1 ||
        selection == ResultVersionSelectionV1::v2) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_v3_required",
          "provider-result-v3 Observed can only be published as outer result-v3");
    }
    if (!request.shares_resolution_owner_with(plan.resolved_request())) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_request_plan_mismatch",
          "result-v3 assembly rejected a request from a different resolved plan");
    }
    auto plan_valid = validate_execution_plan(plan);
    if (!plan_valid) {
      return Result<PublishedResultArtifact>::failure(plan_valid.error());
    }

    const AnalysisExecutionIdentityV1& identity =
        analysis_bundle.execution_identity();
    const SurrogateProviderManifestV1& manifest =
        plan.provider_manifest().value();
    std::vector<std::string> planned_metric_ids;
    std::vector<BackendRouteKindV1> planned_backend_routes;
    planned_metric_ids.reserve(plan.metric_requests().size());
    planned_backend_routes.reserve(plan.metric_plans().size());
    for (const MetricRequest& metric : plan.metric_requests()) {
      planned_metric_ids.push_back(metric_request_header(metric).metric_id);
    }
    for (const PlannedMetricV1& metric : plan.metric_plans()) {
      planned_backend_routes.push_back(metric.route_kind());
    }
    if (identity.fingerprints != request.fingerprints() ||
        identity.fingerprints !=
            plan.problem_view().fingerprints().authored_inputs ||
        identity.provider != manifest.provider ||
        identity.provider_digest !=
            plan.provider_manifest().scientific_contract_digest() ||
        identity.accepted_contract_digest !=
            plan.capability_contract().contract_digest() ||
        identity.construction_method != plan.construction_method() ||
        identity.producer_mode != plan.producer_mode() ||
        identity.master_seed != request.master_seed() ||
        identity.ordered_targets !=
            plan.problem_view().target_selection().ordered_targets ||
        identity.selection != plan.problem_view().analysis_selection() ||
        identity.solver_regime != plan.solver_regime() ||
        identity.metric_ids != planned_metric_ids ||
        identity.backend_routes != planned_backend_routes) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_execution_binding_mismatch",
          "observed analysis identity does not match the frozen request and execution plan");
    }
    const bool terminal_metrics_compatible =
        analysis_bundle.status() == ResultStatusV1::unavailable
            ? std::ranges::all_of(
                  analysis_bundle.metrics(), [](const ResultMetricV1& metric) {
                    return std::holds_alternative<
                        UnavailableResultMetricV1>(metric);
                  })
            : analysis_bundle.metrics().empty();
    const bool request_construction_failure =
        analysis_bundle.failure().has_value() &&
        analysis_bundle.failure()->stage ==
            ResultFailureStageV1::request_construction;
    if ((analysis_bundle.status() == ResultStatusV1::failed) !=
            analysis_bundle.failure().has_value() ||
        !terminal_metrics_compatible ||
        analysis_bundle.response_curve().has_value() ||
        identity.payload_digest.has_value() || identity.plug_kind.has_value() ||
        identity.execution_seal_digest.has_value()) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_v3_observed_execution_shape_invalid",
          "outer result-v3 requires no deployed payload, response, seal, or established metric values");
    }
    if (identity.request_identity.has_value() ==
        request_construction_failure) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_v3_request_identity_mismatch",
          "result-v3 request provenance is absent exactly for request-construction failure");
    }
    if (identity.request_identity &&
        (identity.request_identity->build_seed.master_seed() !=
             identity.master_seed ||
         !identity.request_identity->build_seed.is_bound_to(
             identity.request_identity->build_identity_digest))) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_v3_seed_binding_mismatch",
          "analysis output carries a foreign or internally inconsistent build seed");
    }
    if (analysis_bundle.build_report().has_value() &&
        (!identity.request_identity.has_value() ||
         analysis_bundle.build_report()->request_digest !=
             identity.request_identity->build_request_digest.value())) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_v3_build_report_binding_mismatch",
          "the result-v3 build report is missing its request or bound to a different build request");
    }
    const auto& supplement = analysis_bundle.diagnostic_supplement();
    if ((supplement &&
         (!analysis_bundle.build_report().has_value() ||
          !supplement->source_provider_result_digest().has_value())) ||
        (!supplement &&
         analysis_bundle.status() != ResultStatusV1::failed)) {
      return fail_result<PublishedResultArtifact>(
          "c32.result_v3_observation_provenance_invalid",
          "successful and unavailable result-v3 terminals require an authenticated observation, while a retained observation requires its build report and provider-result digest");
    }

    std::optional<ResultBuildRequestIdentityV1> result_request_identity;
    if (identity.request_identity) {
      result_request_identity = ResultBuildRequestIdentityV1{
          identity.request_identity->build_identity_digest,
          identity.request_identity->build_seed,
          identity.request_identity->build_request_digest};
    }
    const std::optional<Digest256> result_provider_digest =
        supplement ? supplement->source_provider_result_digest()
                   : std::nullopt;
    std::shared_ptr<const FrameworkEmpiricalPredictionV1>
        framework_prediction;
    if (supplement && supplement->observation() && supplement->analysis()) {
      framework_prediction =
          std::make_shared<const FrameworkEmpiricalPredictionV1>(
              derive_framework_empirical_prediction_v1(
                  *supplement->observation(), *supplement->analysis(),
                  supplement->analysis_options()));
    }

    ResultArtifactDataV3 value{
        .status = analysis_bundle.status(),
        .failure = analysis_bundle.failure(),
        .input_fingerprints = request.fingerprints(),
        .provider = identity.provider,
        .provider_digest = identity.provider_digest,
        .provider_result_digest = result_provider_digest,
        .master_seed = identity.master_seed,
        .build_request_identity = std::move(result_request_identity),
        .model =
            ResultModelProvenanceV1{
                .schema_version =
                    request.instance().authored_model().schema_version.value,
                .fingerprint = request.fingerprints().model,
            },
        .analysis =
            ResultAnalysisProvenanceV1{
                .schema_version = request.instance()
                                      .analysis_spec()
                                      .analysis_schema_version,
                .fingerprint = request.fingerprints().analysis,
                .ordered_targets = identity.ordered_targets,
                .metric_ids = identity.metric_ids,
                .selection = identity.selection,
                .solver_regime = identity.solver_regime,
            },
        .config_name = request.model_path().path.filename().string(),
        .wall_clock_times =
            ResultWallClockTimesV1{
                .end_to_end = analysis_bundle.wall_clock_times().end_to_end,
                .sampler = analysis_bundle.wall_clock_times().sampler,
                .framework = analysis_bundle.wall_clock_times().framework,
            },
        .worker_count = request.analyze().worker_count,
        .diagnostic_supplement = supplement,
        .framework_prediction = std::move(framework_prediction),
    };
    auto artifact =
        ResultArtifactV3::make_from_trusted_execution(std::move(value));
    if (!artifact) {
      return Result<PublishedResultArtifact>::failure(artifact.error());
    }
    return Result<PublishedResultArtifact>::success(
        PublishedResultArtifact(std::move(artifact).value()));
  }
  if (selection == ResultVersionSelectionV1::v3) {
    return fail_result<PublishedResultArtifact>(
        "c32.result_v3_route_required",
        "outer result-v3 is available only for provider-result-v3 observation routes");
  }

  auto legacy = assemble_result_artifact(request, plan, analysis_bundle);
  if (!legacy) {
    return Result<PublishedResultArtifact>::failure(legacy.error());
  }

  const bool supplement_present =
      static_cast<bool>(analysis_bundle.diagnostic_supplement());
  const bool route_requires_v2 =
      plan.provider().result_protocol_version() == 2U;
  if (selection == ResultVersionSelectionV1::v1 &&
      (supplement_present || route_requires_v2)) {
    return fail_result<PublishedResultArtifact>(
        "c30.result_v1_would_discard_diagnostics",
        "result-v1 was requested for a diagnostics-v2 provider execution");
  }
  const bool publish_v2 = selection == ResultVersionSelectionV1::v2 ||
                          (selection == ResultVersionSelectionV1::automatic &&
                           (supplement_present || route_requires_v2));
  if (!publish_v2) {
    return Result<PublishedResultArtifact>::success(
        PublishedResultArtifact(std::move(legacy).value()));
  }

  ResultArtifact legacy_artifact = std::move(legacy).value();
  ResultArtifactDataV2 value{
      .main = std::move(legacy_artifact.value_),
      .diagnostic_supplement = analysis_bundle.diagnostic_supplement(),
  };
  auto artifact =
      ResultArtifactV2::make_from_trusted_execution(std::move(value));
  if (!artifact) {
    return Result<PublishedResultArtifact>::failure(artifact.error());
  }
  return Result<PublishedResultArtifact>::success(
      PublishedResultArtifact(std::move(artifact).value()));
}

Result<void> write_result_artifact(const ResultArtifact& artifact,
                                   const std::filesystem::path& path) {
  return write_result_artifact_impl(artifact, path,
                                    PublicationFailurePoint::none);
}

Result<void> write_published_result_artifact(
    const PublishedResultArtifact& artifact,
    const std::filesystem::path& path) {
  return std::visit(
      [&path](const auto& selected) -> Result<void> {
        using Artifact = std::decay_t<decltype(selected)>;
        if constexpr (std::same_as<Artifact, ResultArtifact>) {
          return write_result_artifact_impl(
              selected, path, PublicationFailurePoint::none);
        } else if constexpr (std::same_as<Artifact, ResultArtifactV2>) {
          return write_result_artifact_v2_impl(
              selected, path, PublicationFailurePoint::none);
        } else {
          static_assert(std::same_as<Artifact, ResultArtifactV3>);
          return write_result_artifact_v3_impl(
              selected, path, PublicationFailurePoint::none);
        }
      },
      artifact.value());
}

Result<void> write_compression_comparison_artifact_v1(
    const ThreeRecordErrorSeparationV1& comparison,
    const std::filesystem::path& path) {
  auto encoded = canonical_compression_comparison_json(comparison);
  if (!encoded) {
    return Result<void>::failure(encoded.error());
  }
  return publish_json(encoded.value(), path, PublicationFailurePoint::none);
}

#if defined(MWPERF_C27_TEST_SEAMS)
Result<ResultArtifact> make_result_artifact_for_test(
    ResultArtifactDataV1 value) {
  return ResultArtifact::make_checked(std::move(value));
}

Result<ResultArtifactV2> make_result_artifact_v2_for_test(
    ResultArtifactDataV2 value) {
  return ResultArtifactV2::make_checked(std::move(value));
}

Result<ResultArtifactV3> make_result_artifact_v3_for_test(
    ResultArtifactDataV3 value) {
  auto valid = validate_observed_result_v3(
      value, true /* arbitrary typed input must be scientifically verified */);
  if (!valid) {
    return Result<ResultArtifactV3>::failure(valid.error());
  }
  return Result<ResultArtifactV3>::success(
      ResultArtifactV3(std::move(value)));
}

Result<void> write_result_artifact_with_failure_for_test(
    const ResultArtifact& artifact, const std::filesystem::path& path,
    const ResultPublicationFailurePointV1 failure_point) {
  return write_result_artifact_impl(
      artifact, path, internal_failure_point(failure_point));
}
#endif

}  // namespace mwperf
