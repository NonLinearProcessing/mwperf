#pragma once

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {

// Constructs the versioned, universal CP06 production profile entirely in
// memory, then routes it through the unchanged Analysis-v1 parser.
[[nodiscard]] Result<AnalysisSpec> make_full_orbit_default_analysis_v1(
    const QueueId& target, const AuthoredSchedulerConfig& scheduler);

// Schema-4 target mode selects the CP09 observation-only route and its raw
// campaign defaults without changing the released schema-3 built-in bytes.
[[nodiscard]] Result<AnalysisSpec> make_full_orbit_cp09_default_analysis_v1(
    const QueueId& target, const AuthoredSchedulerConfig& scheduler,
    const AuthoredTelemetryConfig& telemetry);

}  // namespace mwperf::detail
