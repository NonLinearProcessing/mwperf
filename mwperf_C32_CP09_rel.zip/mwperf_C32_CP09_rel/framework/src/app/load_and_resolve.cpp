#include "mwperf/app/resolved_request.hpp"

#include <algorithm>
#include <cstdint>
#include <exception>
#include <functional>
#include <memory>
#include <new>
#include <optional>
#include <random>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "full_orbit_default_analysis.hpp"
#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/document.hpp"
#include "mwperf/config/schema_versions.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/model/framework_scope.hpp"
#include "mwperf/model/queue_catalog.hpp"
#if defined(MWPERF_C27_TEST_SEAMS)
#include "mwperf/stationary/analytic.hpp"
#endif

namespace mwperf {

struct ResolvedRequest::Storage final {
  Analyze analyze;
  CanonicalInputPair canonical_inputs;
  InputFingerprintBundle fingerprints;
  MasterSeed master_seed;
  ResolvedSeedSource seed_source;
  ResolvedInstance instance;
  CompiledArrivalLaw compiled_arrival;
  std::optional<InitialPhysicalLaw> initial_physical_law;
  std::vector<PmfNormalizationRecord> normalization_diagnostics;
};

namespace detail {

struct ResolvedRequestBuilder final {
  [[nodiscard]] static Result<ResolvedRequest> publish(
      Analyze analyze, CanonicalInputPair canonical_inputs,
      InputFingerprintBundle fingerprints, MasterSeed master_seed,
      ResolvedSeedSource seed_source, ResolvedInstance instance,
      CompiledArrivalLaw compiled_arrival,
      std::optional<InitialPhysicalLaw> initial_physical_law,
      std::vector<PmfNormalizationRecord> normalization_diagnostics);
};

}  // namespace detail

namespace {

template <typename T>
[[nodiscard]] Result<T> fail(Diagnostic diagnostic) {
  return Result<T>::failure(std::move(diagnostic));
}

[[nodiscard]] Diagnostic simple_diagnostic(
    const DiagnosticCategory category, std::string code,
    std::string message, std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

using EntropySource = std::function<Result<std::uint64_t>()>;

[[nodiscard]] std::string queue_label_text(const QueueId& queue) {
  const TypedLabel& label = queue.label();
  return label.is_text() ? *label.text_value()
                         : label.numeric_value()->to_decimal_string();
}

[[nodiscard]] Result<QueueId> resolve_cli_target(
    const AuthoredModelConfig& model, const std::string_view authored) {
  auto catalog = build_queue_catalog(model.switch_config);
  if (!catalog) {
    return Result<QueueId>::failure(catalog.error());
  }

  const QueueCatalogEntry* text_match = nullptr;
  for (const QueueCatalogEntry& entry : catalog.value().entries()) {
    const TypedLabel& label = entry.id.label();
    if (label.is_text() && *label.text_value() == authored) {
      text_match = &entry;
      break;
    }
  }

  const QueueCatalogEntry* numeric_match = nullptr;
  // Canonical decimal syntax can also name a numeric queue.  It is resolved
  // as a typed identity, never by number-to-string coercion.
  if (!authored.empty() &&
      (authored == "0" ||
       (authored.front() >= '1' && authored.front() <= '9' &&
        std::all_of(authored.begin() + 1, authored.end(), [](const char byte) {
          return byte >= '0' && byte <= '9';
        })))) {
    auto numeric = BigNat::from_big_int(BigInt(std::string(authored)));
    if (numeric) {
      const QueueId wanted(TypedLabel::numeric(std::move(numeric).value()));
      for (const QueueCatalogEntry& entry : catalog.value().entries()) {
        if (entry.id == wanted) {
          numeric_match = &entry;
          break;
        }
      }
    }
  }
  if (text_match != nullptr && numeric_match != nullptr) {
    return Result<QueueId>::failure(simple_diagnostic(
        DiagnosticCategory::input_validation, "cli_target_queue_ambiguous",
        "--target matches both a text queue and a numeric queue",
        {"requested target: " + std::string(authored),
         "the input must use unambiguous queue identities for the compact "
         "target CLI"}));
  }
  if (text_match != nullptr) {
    return Result<QueueId>::success(text_match->id);
  }
  if (numeric_match != nullptr) {
    return Result<QueueId>::success(numeric_match->id);
  }

  std::vector<std::string> notes;
  notes.reserve(std::min<std::size_t>(catalog.value().size(), 16U) + 1U);
  notes.push_back("requested target: " + std::string(authored));
  std::size_t count = 0U;
  for (const QueueCatalogEntry& entry : catalog.value().entries()) {
    if (count++ == 16U) {
      notes.push_back("additional queue IDs omitted");
      break;
    }
    notes.push_back("available queue: " + queue_label_text(entry.id));
  }
  return Result<QueueId>::failure(simple_diagnostic(
      DiagnosticCategory::input_validation, "cli_target_queue_unknown",
      "--target does not name a queue declared by the input model",
      std::move(notes)));
}

[[nodiscard]] std::string_view arrival_row_kind_name(
    const ArrivalCategoricalRowKind kind) noexcept {
  switch (kind) {
    case ArrivalCategoricalRowKind::finite_interarrival:
      return "finite_interarrival";
    case ArrivalCategoricalRowKind::geometric_trial:
      return "geometric_trial";
    case ArrivalCategoricalRowKind::destination:
      return "destination";
    case ArrivalCategoricalRowKind::joint_gap_destination:
      return "joint_gap_destination";
    case ArrivalCategoricalRowKind::private_initial_state:
      return "private_initial_state";
    case ArrivalCategoricalRowKind::private_transition:
      return "private_transition";
    case ArrivalCategoricalRowKind::shared_initial_state:
      return "shared_initial_state";
    case ArrivalCategoricalRowKind::shared_outcome:
      return "shared_outcome";
    case ArrivalCategoricalRowKind::iid_count_outcome:
      return "iid_count_outcome";
    case ArrivalCategoricalRowKind::mixed_poisson_state:
      return "mixed_poisson_state";
  }
  return "unknown";
}

struct ConcreteSeed final {
  MasterSeed value;
  ResolvedSeedSource source;
};

[[nodiscard]] Result<std::uint64_t> operating_system_entropy_word() {
  try {
    std::random_device source;
    // The standard permits deterministic random_device implementations.  An
    // implementation that reports no entropy is not accepted as the OS
    // entropy adapter; importantly, there is no clock/PID/address fallback.
    if (!(source.entropy() > 0.0)) {
      return fail<std::uint64_t>(simple_diagnostic(
          DiagnosticCategory::unavailable, "seed_entropy_unavailable",
          "the operating-system entropy source is unavailable",
          {"std::random_device reported no nondeterministic entropy",
           "no clock, process, address, or fixed fallback was used"}));
    }
    std::uniform_int_distribution<std::uint64_t> distribution;
    return Result<std::uint64_t>::success(distribution(source));
  } catch (const std::exception&) {
    return fail<std::uint64_t>(simple_diagnostic(
        DiagnosticCategory::unavailable, "seed_entropy_unavailable",
        "the operating-system entropy source could not produce a seed",
        {"no clock, process, address, or fixed fallback was used"}));
  } catch (...) {
    return fail<std::uint64_t>(simple_diagnostic(
        DiagnosticCategory::unavailable, "seed_entropy_unavailable",
        "the operating-system entropy source could not produce a seed",
        {"no clock, process, address, or fixed fallback was used"}));
  }
}

[[nodiscard]] Result<ConcreteSeed> resolve_seed(
    const AuthoredRunConfig& run, const EntropySource& entropy_source) {
  if (run.actual_seed.value.has_value()) {
    return Result<ConcreteSeed>::success(ConcreteSeed{
        MasterSeed(*run.actual_seed.value), ResolvedSeedSource::replay_actual});
  }

  const SeedSpec& requested = run.requested_seed.value.has_value()
                                  ? *run.requested_seed.value
                                  : run.seed.value;
  if (requested.mode == SeedMode::fixed) {
    return Result<ConcreteSeed>::success(
        ConcreteSeed{MasterSeed(requested.fixed_value),
                     ResolvedSeedSource::authored_fixed});
  }

  if (!entropy_source) {
    return fail<ConcreteSeed>(simple_diagnostic(
        DiagnosticCategory::unavailable, "seed_entropy_unavailable",
        "the automatic seed requested an unavailable entropy adapter",
        {"no clock, process, address, or fixed fallback was used"}));
  }
  try {
    Result<std::uint64_t> entropy = entropy_source();
    if (!entropy) {
      std::vector<std::string> notes{
          "entropy adapter diagnostic: " + entropy.error().code,
          "no clock, process, address, or fixed fallback was used"};
      return fail<ConcreteSeed>(simple_diagnostic(
          DiagnosticCategory::unavailable, "seed_entropy_unavailable",
          "the automatic seed could not be resolved from operating-system "
          "entropy",
          std::move(notes)));
    }
    return Result<ConcreteSeed>::success(ConcreteSeed{
        MasterSeed(entropy.value()),
        ResolvedSeedSource::operating_system_entropy});
  } catch (const std::exception&) {
    return fail<ConcreteSeed>(simple_diagnostic(
        DiagnosticCategory::unavailable, "seed_entropy_unavailable",
        "the automatic seed entropy adapter raised an exception",
        {"no clock, process, address, or fixed fallback was used"}));
  } catch (...) {
    return fail<ConcreteSeed>(simple_diagnostic(
        DiagnosticCategory::unavailable, "seed_entropy_unavailable",
        "the automatic seed entropy adapter raised an unknown exception",
        {"no clock, process, address, or fixed fallback was used"}));
  }
}

[[nodiscard]] Result<ResolvedRequest> resolve_with_entropy(
    const CliRequest& request, const EntropySource& entropy_source) {
  try {
    const auto* analyze = std::get_if<Analyze>(&request.mode);
    if (analyze == nullptr) {
      return fail<ResolvedRequest>(simple_diagnostic(
          DiagnosticCategory::cli_usage, "analysis_mode_required",
          "request resolution requires the CLI analysis mode"));
    }
    const bool has_analysis_path =
        !analyze->analysis_path.authored.empty() ||
        !analyze->analysis_path.path.empty();
    if (analyze->target_queue.has_value() == has_analysis_path) {
      return fail<ResolvedRequest>(simple_diagnostic(
          DiagnosticCategory::cli_usage, "cli_analysis_source_invalid",
          "request resolution requires exactly one of a target queue or an "
          "explicit analysis document"));
    }

    Result<ParsedDocument> physical_document =
        load_document(analyze->model_path.path);
    if (!physical_document) {
      return fail<ResolvedRequest>(physical_document.error());
    }
    std::optional<ParsedDocument> explicit_analysis_document;
    if (!analyze->target_queue.has_value()) {
      Result<ParsedDocument> loaded_analysis =
          load_document(analyze->analysis_path.path);
      if (!loaded_analysis) {
        return fail<ResolvedRequest>(loaded_analysis.error());
      }
      explicit_analysis_document = std::move(loaded_analysis).value();
    }

    // Preserve the legacy two-document diagnostic order: in explicit mode
    // both source-preserving documents are loaded before either typed parser
    // interprets the other's schema.  Target mode has no second document.
    Result<ModelNode> physical_node =
        extract_executable_model(physical_document.value());
    if (!physical_node) {
      return fail<ResolvedRequest>(physical_node.error());
    }
    Result<AuthoredModelConfig> model =
        parse_model_config(physical_node.value());
    if (!model) {
      return fail<ResolvedRequest>(model.error());
    }
    Result<AnalysisSpec> analysis = [&]() -> Result<AnalysisSpec> {
      if (analyze->target_queue.has_value()) {
        auto target = resolve_cli_target(model.value(),
                                         *analyze->target_queue);
        if (!target) {
          return Result<AnalysisSpec>::failure(target.error());
        }
        if (model.value().schema_version.value ==
            kPhysicalSchemaVersionV4) {
          return detail::make_full_orbit_cp09_default_analysis_v1(
              target.value(), model.value().scheduler,
              model.value().telemetry);
        }
        return detail::make_full_orbit_default_analysis_v1(
            target.value(), model.value().scheduler);
      }
      return parse_analysis_spec_v1(*explicit_analysis_document);
    }();
    if (!analysis) {
      return fail<ResolvedRequest>(analysis.error());
    }

    CanonicalInputPair canonical_inputs =
        canonicalize_authored_inputs(model.value(), analysis.value());
    InputFingerprintBundle fingerprints =
        fingerprint_inputs(canonical_inputs);

    Result<ConcreteSeed> seed =
        resolve_seed(model.value().run, entropy_source);
    if (!seed) {
      return fail<ResolvedRequest>(seed.error());
    }

    // F-C04-05 is the sole public physical-resolution boundary.  Its released
    // implementation already compiles and retains the C09 arrival product and
    // (for transient selection) the complete coupled physical initializer.
    Result<ResolvedInstance> instance = resolve_physical_instance(
        model.value(), analysis.value(), fingerprints);
    if (!instance) {
      return fail<ResolvedRequest>(instance.error());
    }

    Result<std::shared_ptr<const CompiledArrivalLaw>> recovered_arrival =
        detail::CompiledArrivalAccess::get(instance.value().arrival());
    if (!recovered_arrival) {
      return fail<ResolvedRequest>(recovered_arrival.error());
    }
    CompiledArrivalLaw compiled_arrival = *recovered_arrival.value();

    std::optional<InitialPhysicalLaw> initial_physical_law;
    if (instance.value().initial_law().has_value()) {
      Result<std::shared_ptr<const InitialPhysicalLaw>> recovered_initial =
          detail::CompiledInitialLawAccess::get(
              *instance.value().initial_law());
      if (!recovered_initial) {
        return fail<ResolvedRequest>(recovered_initial.error());
      }
      if (!(recovered_initial.value()->arrival_binding() ==
            arrival_law_binding(compiled_arrival))) {
        return fail<ResolvedRequest>(simple_diagnostic(
            DiagnosticCategory::internal,
            "resolved_initial_arrival_binding_mismatch",
            "the recovered physical initializer belongs to another compiled "
            "arrival law"));
      }
      initial_physical_law = *recovered_initial.value();
    }

    const bool transient_selection =
        analysis.value().context != nullptr &&
        std::holds_alternative<TransientSelection>(
            analysis.value().context->selection);
    if (transient_selection != initial_physical_law.has_value()) {
      return fail<ResolvedRequest>(simple_diagnostic(
          DiagnosticCategory::internal,
          "resolved_initial_law_presence_mismatch",
          "the resolved selection and retained C09 physical initializer "
          "disagree"));
    }

    std::vector<PmfNormalizationRecord> normalization_diagnostics;
    for (const NormalizedArrivalRow& row :
         normalized_arrival_rows(compiled_arrival)) {
      normalization_diagnostics.push_back(PmfNormalizationRecord{
          .kind = PmfNormalizationKind::configured_arrival_categorical_row,
          .identity =
              "configured_arrival." +
              std::string(arrival_row_kind_name(row.kind)) + ".source." +
              std::to_string(row.source_ordinal) + ".state." +
              std::to_string(row.state_ordinal),
          .authored_sum = row.pmf.authored_sum(),
          .normalization_delta = row.normalization_delta(),
          .arrival_row_kind = row.kind,
          .source_ordinal = row.source_ordinal,
          .state_ordinal = row.state_ordinal,
      });
    }
    const BuilderArrivalView arrival_view =
        builder_arrival_view(compiled_arrival);
    if (arrival_view.stationary_phase_law().has_value()) {
      const StationaryPhaseLawDescriptor& stationary =
          *arrival_view.stationary_phase_law();
      normalization_diagnostics.push_back(PmfNormalizationRecord{
          .kind = PmfNormalizationKind::
              configured_arrival_stationary_phase,
          .identity = stationary.law_id,
          .authored_sum = stationary.probabilities.authored_sum(),
          .normalization_delta =
              stationary.probabilities.normalization_delta(),
      });
    }
    if (initial_physical_law.has_value()) {
      normalization_diagnostics.push_back(PmfNormalizationRecord{
          .kind = PmfNormalizationKind::transient_initial_law,
          .identity = "physical_transient_initial_law",
          .authored_sum =
              initial_physical_law->original_pmf().authored_sum(),
          .normalization_delta =
              initial_physical_law->normalization_delta(),
      });
    }

    return detail::ResolvedRequestBuilder::publish(
        *analyze, std::move(canonical_inputs), std::move(fingerprints),
        seed.value().value, seed.value().source, std::move(instance).value(),
        std::move(compiled_arrival), std::move(initial_physical_law),
        std::move(normalization_diagnostics));
  } catch (const std::bad_alloc&) {
    return fail<ResolvedRequest>(simple_diagnostic(
        DiagnosticCategory::resource_limit,
        "request_resolution_allocation_failure",
        "resolving the analysis request exhausted memory"));
  } catch (const std::length_error&) {
    return fail<ResolvedRequest>(simple_diagnostic(
        DiagnosticCategory::resource_limit,
        "request_resolution_representation_failure",
        "resolving the analysis request exceeded a host representation "
        "limit"));
  } catch (const std::exception&) {
    return fail<ResolvedRequest>(simple_diagnostic(
        DiagnosticCategory::internal, "request_resolution_exception",
        "an unexpected exception interrupted request resolution"));
  } catch (...) {
    return fail<ResolvedRequest>(simple_diagnostic(
        DiagnosticCategory::internal, "request_resolution_unknown_exception",
        "an unknown exception interrupted request resolution"));
  }
}

}  // namespace

namespace detail {

Result<ResolvedRequest> ResolvedRequestBuilder::publish(
    Analyze analyze, CanonicalInputPair canonical_inputs,
    InputFingerprintBundle fingerprints, const MasterSeed master_seed,
    const ResolvedSeedSource seed_source, ResolvedInstance instance,
    CompiledArrivalLaw compiled_arrival,
    std::optional<InitialPhysicalLaw> initial_physical_law,
    std::vector<PmfNormalizationRecord> normalization_diagnostics) {
  try {
    auto storage = std::make_shared<const ResolvedRequest::Storage>(
        ResolvedRequest::Storage{
            .analyze = std::move(analyze),
            .canonical_inputs = std::move(canonical_inputs),
            .fingerprints = std::move(fingerprints),
            .master_seed = master_seed,
            .seed_source = seed_source,
            .instance = std::move(instance),
            .compiled_arrival = std::move(compiled_arrival),
            .initial_physical_law = std::move(initial_physical_law),
            .normalization_diagnostics =
                std::move(normalization_diagnostics),
        });
    return Result<ResolvedRequest>::success(
        ResolvedRequest(std::move(storage)));
  } catch (const std::bad_alloc&) {
    return fail<ResolvedRequest>(simple_diagnostic(
        DiagnosticCategory::resource_limit,
        "resolved_request_allocation_failure",
        "publishing the immutable resolved request exhausted memory"));
  }
}

}  // namespace detail

ResolvedRequest::ResolvedRequest(
    std::shared_ptr<const Storage> storage) noexcept
    : storage_(std::move(storage)) {}

ResolvedRequest::ResolvedRequest(ResolvedRequest&& other) noexcept
    : storage_(other.storage_) {}

ResolvedRequest& ResolvedRequest::operator=(ResolvedRequest&& other) noexcept {
  if (this != &other) {
    storage_ = other.storage_;
  }
  return *this;
}

const Analyze& ResolvedRequest::analyze() const noexcept {
  return storage_->analyze;
}

const CliPath& ResolvedRequest::model_path() const noexcept {
  return storage_->analyze.model_path;
}

const CliPath& ResolvedRequest::analysis_path() const noexcept {
  return storage_->analyze.analysis_path;
}

const CliPath& ResolvedRequest::output_path() const noexcept {
  return storage_->analyze.output_path;
}

const CanonicalInputPair& ResolvedRequest::canonical_inputs() const noexcept {
  return storage_->canonical_inputs;
}

const InputFingerprintBundle& ResolvedRequest::fingerprints() const noexcept {
  return storage_->fingerprints;
}

MasterSeed ResolvedRequest::master_seed() const noexcept {
  return storage_->master_seed;
}

ResolvedSeedSource ResolvedRequest::seed_source() const noexcept {
  return storage_->seed_source;
}

const ResolvedInstance& ResolvedRequest::instance() const noexcept {
  return storage_->instance;
}

const CompiledArrivalLaw& ResolvedRequest::compiled_arrival() const noexcept {
  return storage_->compiled_arrival;
}

const std::optional<InitialPhysicalLaw>&
ResolvedRequest::initial_physical_law() const noexcept {
  return storage_->initial_physical_law;
}

std::span<const PmfNormalizationRecord>
ResolvedRequest::normalization_diagnostics() const noexcept {
  return storage_->normalization_diagnostics;
}

bool ResolvedRequest::shares_resolution_owner_with(
    const ResolvedRequest& other) const noexcept {
  return storage_ == other.storage_;
}

Result<ResolvedRequest> load_and_resolve_request(const CliRequest& request) {
  return resolve_with_entropy(request, operating_system_entropy_word);
}

#if defined(MWPERF_C27_TEST_SEAMS)
namespace testing {

Result<ResolvedRequest> load_and_resolve_request_with_entropy(
    const CliRequest& request,
    const std::function<Result<std::uint64_t>()>& entropy_source) {
  return resolve_with_entropy(request, entropy_source);
}

#if defined(MWPERF_C19_TEST_SEAMS)
Result<ResolvedInstance> C19FixtureAccess::bind_resolved_arrival_for_testing(
    const ResolvedInstance& source,
    std::shared_ptr<const CompiledArrivalLaw> configured_arrival) {
  const auto reject = [](std::string code, std::string message) {
    return Result<ResolvedInstance>::failure(
        {DiagnosticCategory::input_validation, std::move(code),
         std::move(message), std::nullopt, std::nullopt, {}});
  };
  if (!configured_arrival) {
    return reject("c27.fixture_arrival_missing",
                  "the C27 execution fixture requires an exact arrival law");
  }

  const PhysicalBindingIdentity physical = source.arrival().identity();
  const ArrivalBinding& binding = arrival_law_binding(*configured_arrival);
  if (physical.combined_input != source.fingerprints().combined ||
      binding.family != physical.arrival_family ||
      binding.timing != source.timing() ||
      binding.timing != physical.timing ||
      binding.queue_cardinality != source.queues().size() ||
      binding.queue_cardinality != physical.queue_cardinality) {
    return reject(
        "c27.fixture_arrival_physical_binding_mismatch",
        "the exact fixture law does not match the resolved physical arrival family, timing, or queue dimension");
  }
  auto catalog_digest = detail::digest_queue_catalog(source.queues());
  if (!catalog_digest || binding.catalog_digest != catalog_digest.value()) {
    return catalog_digest
               ? reject("c27.fixture_arrival_catalog_mismatch",
                        "the exact fixture law does not match the resolved queue catalog")
               : Result<ResolvedInstance>::failure(catalog_digest.error());
  }
  QueueMask support = positive_arrival_support(*configured_arrival);
  if (support.size() != source.queues().size() ||
      support.bytes() != source.positive_arrival_support().bytes()) {
    return reject(
        "c27.fixture_arrival_support_mismatch",
        "the exact fixture law and authored law have different positive support");
  }

  const ArrivalProductBindingIdentity product_identity{
      binding.family, binding.timing, binding.queue_cardinality,
      binding.law_digest.value(), binding.catalog_digest.value()};
  const auto references = source.arrival().queue_references();
  ConfiguredArrivalBinding rebound_arrival(
      physical,
      std::vector<BoundQueueReference>(references.begin(), references.end()),
      std::shared_ptr<const void>(configured_arrival),
      ArrivalCompiledProductKind::compiled_arrival_law_v1,
      product_identity);

  std::optional<InitialLawBinding> rebound_initial_law;
  if (source.initial_law().has_value()) {
    const InitialLawBinding& authored_initial = *source.initial_law();
    if (authored_initial.identity() != physical) {
      return reject(
          "c27.fixture_initial_physical_binding_mismatch",
          "the retained authored initial law does not match the resolved "
          "physical arrival binding");
    }
    auto compiled_initial = compile_initial_physical_law(
        authored_initial.law(), *configured_arrival);
    if (!compiled_initial) {
      return Result<ResolvedInstance>::failure(compiled_initial.error());
    }
    if (compiled_initial.value().arrival_binding() != binding) {
      return reject(
          "c27.fixture_initial_arrival_binding_mismatch",
          "the recompiled initial law does not match the exact replacement "
          "arrival law");
    }
    try {
      auto initial_owner = std::make_shared<const InitialPhysicalLaw>(
          std::move(compiled_initial).value());
      InitialLawBinding rebound_initial(
          physical, authored_initial.law(),
          std::shared_ptr<const void>(std::move(initial_owner)),
          InitialCompiledProductKind::initial_physical_law_v1,
          product_identity);
      rebound_initial_law = std::move(rebound_initial);
    } catch (const std::bad_alloc&) {
      return Result<ResolvedInstance>::failure(
          {DiagnosticCategory::resource_limit,
           "c27.fixture_initial_product_allocation_failure",
           "retaining the recompiled fixture initial law exhausted memory",
           std::nullopt, std::nullopt, {}});
    }
  }

  return Result<ResolvedInstance>::success(ResolvedInstance(
      source.authored_model(), source.analysis_spec(), source.fingerprints(),
      source.queues(), source.priority(), source.constraint(),
      source.service_identity(), source.serviceable(),
      source.optimizer_budget(), source.targets(), std::move(rebound_arrival),
      std::move(support), std::move(rebound_initial_law), source.timing()));
}
#endif

Result<ResolvedRequest> rebind_resolved_request_arrival_for_testing(
    const ResolvedRequest& source,
    std::shared_ptr<const CompiledArrivalLaw> configured_arrival) {
#if defined(MWPERF_C19_TEST_SEAMS)
  auto rebound = C19FixtureAccess::bind_resolved_arrival_for_testing(
      source.instance(), configured_arrival);
  if (!rebound) {
    return Result<ResolvedRequest>::failure(rebound.error());
  }

  // Recover through C04's checked erased carrier before publishing the new
  // immutable request.  This independently validates kind, family, timing,
  // dimension, law fingerprint, and queue-catalog fingerprint.
  auto recovered =
      detail::CompiledArrivalAccess::get(rebound.value().arrival());
  if (!recovered) {
    return Result<ResolvedRequest>::failure(recovered.error());
  }
  if (!configured_arrival ||
      arrival_law_binding(*recovered.value()) !=
          arrival_law_binding(*configured_arrival) ||
      builder_arrival_view(*recovered.value()).digest() !=
          builder_arrival_view(*configured_arrival).digest()) {
    return Result<ResolvedRequest>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "c27.fixture_arrival_recovery_mismatch",
        "the rebound carrier did not recover the replacement law identity",
        std::nullopt, std::nullopt, {}});
  }
  std::optional<InitialPhysicalLaw> initial_physical_law;
  if (rebound.value().initial_law().has_value()) {
    auto recovered_initial = detail::CompiledInitialLawAccess::get(
        *rebound.value().initial_law());
    if (!recovered_initial) {
      return Result<ResolvedRequest>::failure(recovered_initial.error());
    }
    if (recovered_initial.value()->arrival_binding() !=
        arrival_law_binding(*configured_arrival)) {
      return Result<ResolvedRequest>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "c27.fixture_initial_recovery_mismatch",
          "the rebound initializer did not recover the replacement arrival "
          "law identity",
          std::nullopt, std::nullopt, {}});
    }
    initial_physical_law = *recovered_initial.value();
  }
  const bool transient_selection =
      source.instance().analysis_spec().context != nullptr &&
      std::holds_alternative<TransientSelection>(
          source.instance().analysis_spec().context->selection);
  if (transient_selection != initial_physical_law.has_value()) {
    return Result<ResolvedRequest>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "c27.fixture_initial_presence_mismatch",
        "the rebound fixture selection and recompiled physical initializer "
        "disagree",
        std::nullopt, std::nullopt, {}});
  }
  const auto records = source.normalization_diagnostics();
  if (source.initial_physical_law().has_value() !=
      initial_physical_law.has_value()) {
    return Result<ResolvedRequest>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "c27.fixture_initial_source_presence_mismatch",
        "the source request and rebound fixture disagree about the physical "
        "initializer",
        std::nullopt, std::nullopt, {}});
  }
  if (initial_physical_law.has_value()) {
    std::size_t transient_record_count = 0U;
    for (const PmfNormalizationRecord& record : records) {
      if (record.kind != PmfNormalizationKind::transient_initial_law) {
        continue;
      }
      ++transient_record_count;
      if (record.authored_sum !=
              initial_physical_law->original_pmf().authored_sum() ||
          record.normalization_delta !=
              initial_physical_law->normalization_delta()) {
        return Result<ResolvedRequest>::failure(Diagnostic{
            DiagnosticCategory::internal,
            "c27.fixture_initial_normalization_mismatch",
            "the rebound initializer changed the retained transient PMF "
            "normalization record",
            std::nullopt, std::nullopt, {}});
      }
    }
    if (transient_record_count != 1U) {
      return Result<ResolvedRequest>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "c27.fixture_initial_normalization_record_missing",
          "the transient rebound requires exactly one retained initializer "
          "normalization record",
          std::nullopt, std::nullopt, {}});
    }
  }
  return detail::ResolvedRequestBuilder::publish(
      source.analyze(), source.canonical_inputs(), source.fingerprints(),
      source.master_seed(), source.seed_source(), std::move(rebound).value(),
      *configured_arrival, std::move(initial_physical_law),
      std::vector<PmfNormalizationRecord>(records.begin(), records.end()));
#else
  static_cast<void>(source);
  static_cast<void>(configured_arrival);
  return Result<ResolvedRequest>::failure(Diagnostic{
      DiagnosticCategory::internal, "c27.fixture_arrival_authority_missing",
      "the C27 test arrival seam requires the C19 fixture authority",
      std::nullopt, std::nullopt, {}});
#endif
}

}  // namespace testing
#endif

}  // namespace mwperf
