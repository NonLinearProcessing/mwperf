#include "mwperf/core/sha256.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>

namespace mwperf {
namespace {

constexpr std::array<std::uint32_t, 8U> kInitialState{
    0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
    0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U,
};

constexpr std::array<std::uint32_t, 64U> kRoundConstants{
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
    0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
    0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
    0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
    0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
    0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
    0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
    0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
    0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U,
};

constexpr std::uint64_t kMaximumMessageBytes =
    std::numeric_limits<std::uint64_t>::max() / 8U;

[[nodiscard]] Diagnostic digest_error(const std::string_view code,
                                      const std::string_view message) {
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = std::string(code),
      .message = std::string(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic length_error() {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "sha256_message_too_long",
      .message = "SHA-256 input exceeds the maximum byte-aligned message length",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char digit) noexcept {
  if (digit >= '0' && digit <= '9') {
    return static_cast<std::uint8_t>(digit - '0');
  }
  if (digit >= 'a' && digit <= 'f') {
    return static_cast<std::uint8_t>(10 + (digit - 'a'));
  }
  return 0xffU;
}

[[nodiscard]] constexpr std::uint32_t load_u32be(
    const std::byte* bytes) noexcept {
  return (std::to_integer<std::uint32_t>(bytes[0]) << 24U) |
         (std::to_integer<std::uint32_t>(bytes[1]) << 16U) |
         (std::to_integer<std::uint32_t>(bytes[2]) << 8U) |
         std::to_integer<std::uint32_t>(bytes[3]);
}

void store_u32be(const std::uint32_t value, std::byte* output) noexcept {
  output[0] = static_cast<std::byte>((value >> 24U) & 0xffU);
  output[1] = static_cast<std::byte>((value >> 16U) & 0xffU);
  output[2] = static_cast<std::byte>((value >> 8U) & 0xffU);
  output[3] = static_cast<std::byte>(value & 0xffU);
}

void store_u64be(const std::uint64_t value, std::byte* output) noexcept {
  for (std::size_t index = 0U; index < 8U; ++index) {
    const auto shift = static_cast<unsigned>((7U - index) * 8U);
    output[index] = static_cast<std::byte>((value >> shift) & 0xffU);
  }
}

[[nodiscard]] constexpr std::uint32_t choose(const std::uint32_t x,
                                             const std::uint32_t y,
                                             const std::uint32_t z) noexcept {
  return (x & y) ^ (~x & z);
}

[[nodiscard]] constexpr std::uint32_t majority(const std::uint32_t x,
                                               const std::uint32_t y,
                                               const std::uint32_t z) noexcept {
  return (x & y) ^ (x & z) ^ (y & z);
}

[[nodiscard]] constexpr std::uint32_t big_sigma_zero(
    const std::uint32_t value) noexcept {
  return std::rotr(value, 2) ^ std::rotr(value, 13) ^ std::rotr(value, 22);
}

[[nodiscard]] constexpr std::uint32_t big_sigma_one(
    const std::uint32_t value) noexcept {
  return std::rotr(value, 6) ^ std::rotr(value, 11) ^ std::rotr(value, 25);
}

[[nodiscard]] constexpr std::uint32_t small_sigma_zero(
    const std::uint32_t value) noexcept {
  return std::rotr(value, 7) ^ std::rotr(value, 18) ^ (value >> 3U);
}

[[nodiscard]] constexpr std::uint32_t small_sigma_one(
    const std::uint32_t value) noexcept {
  return std::rotr(value, 17) ^ std::rotr(value, 19) ^ (value >> 10U);
}

[[nodiscard]] bool is_valid_domain(const std::string_view domain) noexcept {
  if (domain.empty()) {
    return false;
  }
  return std::all_of(domain.begin(), domain.end(), [](const char character) {
    const auto byte = static_cast<unsigned char>(character);
    return byte >= 0x21U && byte <= 0x7eU;
  });
}

}  // namespace

Digest256::Digest256(std::array<std::byte, kSize> bytes,
                     ValidatedTag) noexcept
    : bytes_(std::move(bytes)) {}

Result<Digest256> Digest256::from_bytes(
    const std::span<const std::byte> bytes) {
  if (bytes.size() != kSize) {
    return Result<Digest256>::failure(digest_error(
        "invalid_digest_width", "a Digest256 must contain exactly 32 bytes"));
  }

  std::array<std::byte, kSize> stored{};
  std::copy(bytes.begin(), bytes.end(), stored.begin());
  return Result<Digest256>::success(
      Digest256(std::move(stored), ValidatedTag{}));
}

Result<Digest256> Digest256::from_hex(const std::string_view encoded) {
  if (encoded.size() != kSize * 2U) {
    return Result<Digest256>::failure(digest_error(
        "invalid_digest_width",
        "a canonical Digest256 hexadecimal encoding must contain 64 digits"));
  }

  std::array<std::byte, kSize> stored{};
  for (std::size_t index = 0U; index < kSize; ++index) {
    const std::uint8_t high = hex_nibble(encoded[index * 2U]);
    const std::uint8_t low = hex_nibble(encoded[index * 2U + 1U]);
    if (high == 0xffU || low == 0xffU) {
      return Result<Digest256>::failure(digest_error(
          "noncanonical_digest_hex",
          "a Digest256 hexadecimal encoding must use lower-case hexadecimal digits"));
    }
    stored[index] = static_cast<std::byte>(
        static_cast<std::uint8_t>((high << 4U) | low));
  }

  return Result<Digest256>::success(
      Digest256(std::move(stored), ValidatedTag{}));
}

std::span<const std::byte, Digest256::kSize> Digest256::bytes() const noexcept {
  return std::span<const std::byte, kSize>(bytes_);
}

std::string Digest256::hex() const {
  constexpr std::array<char, 16U> digits{
      '0', '1', '2', '3', '4', '5', '6', '7',
      '8', '9', 'a', 'b', 'c', 'd', 'e', 'f',
  };
  std::string encoded(kSize * 2U, '0');
  for (std::size_t index = 0U; index < kSize; ++index) {
    const auto value = std::to_integer<std::uint8_t>(bytes_[index]);
    encoded[index * 2U] = digits[(value >> 4U) & 0x0fU];
    encoded[index * 2U + 1U] = digits[value & 0x0fU];
  }
  return encoded;
}

Sha256::Sha256() noexcept : state_(kInitialState) {}

Result<void> Sha256::update(std::span<const std::byte> bytes) {
  const std::uint64_t remaining_bytes =
      kMaximumMessageBytes - total_bytes_;
  bool exceeds_limit = false;
  if constexpr (sizeof(std::size_t) > sizeof(std::uint64_t)) {
    exceeds_limit = bytes.size() > static_cast<std::size_t>(remaining_bytes);
  } else {
    exceeds_limit =
        static_cast<std::uint64_t>(bytes.size()) > remaining_bytes;
  }
  if (exceeds_limit) {
    return Result<void>::failure(length_error());
  }
  const auto byte_count = static_cast<std::uint64_t>(bytes.size());
  total_bytes_ += byte_count;

  if (buffered_bytes_ != 0U) {
    const std::size_t copied =
        std::min(kBlockSize - buffered_bytes_, bytes.size());
    std::copy_n(bytes.begin(), copied, buffer_.begin() +
                                          static_cast<std::ptrdiff_t>(
                                              buffered_bytes_));
    buffered_bytes_ += copied;
    bytes = bytes.subspan(copied);
    if (buffered_bytes_ == kBlockSize) {
      compress_block(buffer_.data());
      buffered_bytes_ = 0U;
    }
  }

  while (bytes.size() >= kBlockSize) {
    compress_block(bytes.data());
    bytes = bytes.subspan(kBlockSize);
  }

  if (!bytes.empty()) {
    std::copy(bytes.begin(), bytes.end(), buffer_.begin());
    buffered_bytes_ = bytes.size();
  }

  return Result<void>::success();
}

Digest256 Sha256::finalize() const noexcept {
  Sha256 snapshot = *this;
  snapshot.buffer_[snapshot.buffered_bytes_++] = std::byte{0x80U};

  if (snapshot.buffered_bytes_ > 56U) {
    std::fill(snapshot.buffer_.begin() +
                  static_cast<std::ptrdiff_t>(snapshot.buffered_bytes_),
              snapshot.buffer_.end(), std::byte{0U});
    snapshot.compress_block(snapshot.buffer_.data());
    snapshot.buffered_bytes_ = 0U;
  }

  std::fill(snapshot.buffer_.begin() +
                static_cast<std::ptrdiff_t>(snapshot.buffered_bytes_),
            snapshot.buffer_.begin() + 56, std::byte{0U});
  store_u64be(snapshot.total_bytes_ * 8U, snapshot.buffer_.data() + 56U);
  snapshot.compress_block(snapshot.buffer_.data());

  std::array<std::byte, Digest256::kSize> digest_bytes{};
  for (std::size_t index = 0U; index < snapshot.state_.size(); ++index) {
    store_u32be(snapshot.state_[index], digest_bytes.data() + index * 4U);
  }
  return Digest256(std::move(digest_bytes), Digest256::ValidatedTag{});
}

void Sha256::compress_block(const std::byte* const block) noexcept {
  std::array<std::uint32_t, 64U> words{};
  for (std::size_t index = 0U; index < 16U; ++index) {
    words[index] = load_u32be(block + index * 4U);
  }
  for (std::size_t index = 16U; index < words.size(); ++index) {
    words[index] = small_sigma_one(words[index - 2U]) + words[index - 7U] +
                   small_sigma_zero(words[index - 15U]) + words[index - 16U];
  }

  std::uint32_t a = state_[0];
  std::uint32_t b = state_[1];
  std::uint32_t c = state_[2];
  std::uint32_t d = state_[3];
  std::uint32_t e = state_[4];
  std::uint32_t f = state_[5];
  std::uint32_t g = state_[6];
  std::uint32_t h = state_[7];

  for (std::size_t index = 0U; index < words.size(); ++index) {
    const std::uint32_t temporary_one =
        h + big_sigma_one(e) + choose(e, f, g) + kRoundConstants[index] +
        words[index];
    const std::uint32_t temporary_two = big_sigma_zero(a) + majority(a, b, c);
    h = g;
    g = f;
    f = e;
    e = d + temporary_one;
    d = c;
    c = b;
    b = a;
    a = temporary_one + temporary_two;
  }

  state_[0] += a;
  state_[1] += b;
  state_[2] += c;
  state_[3] += d;
  state_[4] += e;
  state_[5] += f;
  state_[6] += g;
  state_[7] += h;
}

Result<Digest256> sha256(const std::span<const std::byte> bytes) {
  Sha256 hasher;
  Result<void> updated = hasher.update(bytes);
  if (!updated) {
    return Result<Digest256>::failure(std::move(updated).error());
  }
  return Result<Digest256>::success(hasher.finalize());
}

Result<Digest256> sha256_domain_separated(
    const std::string_view domain,
    const std::span<const std::byte> canonical_bytes) {
  if (!is_valid_domain(domain)) {
    return Result<Digest256>::failure(digest_error(
        "invalid_digest_domain",
        "a digest domain must be nonempty visible ASCII"));
  }

  Sha256 hasher;
  const std::span<const char> domain_characters(domain.data(), domain.size());
  Result<void> updated = hasher.update(std::as_bytes(domain_characters));
  if (!updated) {
    return Result<Digest256>::failure(std::move(updated).error());
  }
  constexpr std::array<std::byte, 1U> separator{std::byte{0U}};
  updated = hasher.update(separator);
  if (!updated) {
    return Result<Digest256>::failure(std::move(updated).error());
  }
  updated = hasher.update(canonical_bytes);
  if (!updated) {
    return Result<Digest256>::failure(std::move(updated).error());
  }
  return Result<Digest256>::success(hasher.finalize());
}

}  // namespace mwperf
