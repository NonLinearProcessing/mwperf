#include "mwperf/diagnostic.hpp"

#include <string_view>

namespace mwperf {
namespace {

[[nodiscard]] constexpr std::string_view category_name(
    const DiagnosticCategory category) noexcept {
  switch (category) {
    case DiagnosticCategory::information:
      return "information";
    case DiagnosticCategory::cli_usage:
      return "cli_usage";
    case DiagnosticCategory::input_validation:
      return "input_validation";
    case DiagnosticCategory::resource_limit:
      return "resource_limit";
    case DiagnosticCategory::unavailable:
      return "unavailable";
    case DiagnosticCategory::internal:
      return "internal";
  }
  return "internal";
}

[[nodiscard]] std::string escape_field(const std::string_view value,
                                       const bool escape_brackets = false) {
  constexpr char hex_digits[] = "0123456789ABCDEF";
  std::string escaped;
  escaped.reserve(value.size());

  for (const unsigned char byte : value) {
    if (byte == static_cast<unsigned char>('"')) {
      escaped += "\\\"";
    } else if (byte == static_cast<unsigned char>('\\')) {
      escaped += "\\\\";
    } else if (byte >= 0x20U && byte <= 0x7EU &&
               !(escape_brackets &&
                 (byte == static_cast<unsigned char>('[') ||
                  byte == static_cast<unsigned char>(']')))) {
      escaped.push_back(static_cast<char>(byte));
    } else {
      escaped += "\\x";
      escaped.push_back(hex_digits[(byte >> 4U) & 0x0FU]);
      escaped.push_back(hex_digits[byte & 0x0FU]);
    }
  }
  return escaped;
}

void append_quoted_field(std::string& rendered, const std::string_view label,
                         const std::string_view value) {
  rendered += "  ";
  rendered += label;
  rendered += ": \"";
  rendered += escape_field(value);
  rendered += "\"\n";
}

}  // namespace

std::string render_cli_diagnostic(const Diagnostic& diagnostic) {
  std::string rendered;
  rendered.reserve(128U + diagnostic.message.size());
  rendered += "mwperf: ";
  rendered += category_name(diagnostic.category);
  rendered += '[';
  rendered += escape_field(diagnostic.code, true);
  rendered += "]: \"";
  rendered += escape_field(diagnostic.message);
  rendered += "\"\n";

  if (diagnostic.authored_path.has_value()) {
    append_quoted_field(rendered, "path", *diagnostic.authored_path);
  }
  if (diagnostic.json_pointer.has_value()) {
    append_quoted_field(rendered, "pointer", *diagnostic.json_pointer);
  }
  for (const std::string& note : diagnostic.notes) {
    append_quoted_field(rendered, "note", note);
  }

  return rendered;
}

}  // namespace mwperf
