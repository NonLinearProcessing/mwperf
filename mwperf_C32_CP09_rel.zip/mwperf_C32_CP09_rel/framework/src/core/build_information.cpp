#include "mwperf/build_information.hpp"

#include "mwperf_build_config.hpp"

namespace mwperf {

BuildInformation build_information() {
  return BuildInformation{
      .program_version = MWPERF_BUILD_PROGRAM_VERSION,
      .source_tree_version = MWPERF_BUILD_SOURCE_VERSION,
      .compiler_id = MWPERF_BUILD_COMPILER_ID,
      .compiler_version = MWPERF_BUILD_COMPILER_VERSION,
      .enabled_features = MWPERF_BUILD_ENABLED_FEATURES,
      // This field is the CLI's compact supported-schema declaration.  Keep
      // both native dialects explicit; neither is a migration alias for the
      // other.
      .physical_schema_version = "3.0.0,4.0.0",
      .analysis_schema_version = "1.0.0",
      .rng_algorithm_version = "xoshiro256ss-v1",
      .function_interface_manifest_version =
          MWPERF_BUILD_INTERFACE_MANIFEST_VERSION,
  };
}

}  // namespace mwperf
