#include "mwperf/temporal/romr.hpp"

#include "c20_stationary_bridge_internal.hpp"
#include "stationary/c21_projection_source_internal.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

#include "../kernel/c17_core_internal.hpp"

namespace mwperf {

namespace {

template <typename T>
[[nodiscard]] Result<T> c20_failure(DiagnosticCategory category,
                                    std::string code,
                                    std::string message,
                                    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{category, std::move(code),
                                       std::move(message), std::nullopt,
                                       std::nullopt, std::move(notes)});
}

template <typename T>
[[nodiscard]] Result<T> c20_invalid(std::string code, std::string message,
                                    std::vector<std::string> notes = {}) {
  return c20_failure<T>(DiagnosticCategory::input_validation,
                        std::move(code), std::move(message),
                        std::move(notes));
}

template <typename T>
[[nodiscard]] Result<T> c20_unavailable(std::string code,
                                        std::string message) {
  return c20_failure<T>(DiagnosticCategory::unavailable, std::move(code),
                        std::move(message));
}

template <typename T>
[[nodiscard]] Result<T> c20_resource(std::string code,
                                     std::string message) {
  return c20_failure<T>(DiagnosticCategory::resource_limit, std::move(code),
                        std::move(message));
}

class CanonicalEncoder final {
 public:
  void octet(std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }

  void boolean(bool value) { octet(value ? 1U : 0U); }

  void u32(std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) {
      octet(static_cast<std::uint8_t>((value >> shift) & 0xffU));
    }
  }

  void u64(std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8) {
      octet(static_cast<std::uint8_t>((value >> shift) & UINT64_C(0xff)));
    }
  }

  void count(std::size_t value) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    u64(static_cast<std::uint64_t>(value));
  }

  void optional_count(const std::optional<std::size_t>& value) {
    boolean(value.has_value());
    if (value.has_value()) {
      count(*value);
    }
  }

  template <typename Enum>
    requires std::is_enum_v<Enum>
  void enumeration(Enum value) {
    using Underlying = std::underlying_type_t<Enum>;
    using Unsigned = std::make_unsigned_t<Underlying>;
    u64(static_cast<std::uint64_t>(static_cast<Unsigned>(value)));
  }

  void framed(std::span<const std::byte> bytes) {
    u64(static_cast<std::uint64_t>(bytes.size()));
    bytes_.insert(bytes_.end(), bytes.begin(), bytes.end());
  }

  void string(std::string_view value) {
    framed(std::as_bytes(std::span(value.data(), value.size())));
  }

  void digest(const Digest256& value) { framed(value.bytes()); }

  void codec(const CodecIdentityV1& value) {
    string(value.id);
    u32(value.version);
  }

  template <StrongIdDomainName Domain>
  void id(const StrongId<Domain>& value) {
    const auto bytes = value.canonical_bytes();
    framed(std::as_bytes(std::span(bytes)));
  }

  void runtime_value(const CanonicalRuntimeValueV1& value) {
    codec(value.codec);
    framed(value.canonical_value);
  }

  void natural(const BigNat& value) {
    const std::vector<std::uint8_t> magnitude =
        value.canonical_magnitude_bytes();
    framed(std::as_bytes(std::span(magnitude)));
  }

  void integer(const BigInt& value) {
    string(value.convert_to<std::string>());
  }

  void optional_natural(const std::optional<BigNat>& value) {
    boolean(value.has_value());
    if (value.has_value()) {
      natural(*value);
    }
  }

  void optional_runtime_value(
      const std::optional<CanonicalRuntimeValueV1>& value) {
    boolean(value.has_value());
    if (value.has_value()) {
      runtime_value(*value);
    }
  }

  void rational(const ExactRational& value) {
    string(value.numerator_decimal());
    string(value.denominator_decimal());
  }

  [[nodiscard]] std::span<const std::byte> bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] Result<Digest256> finish_digest(std::string_view domain,
                                              const CanonicalEncoder& value) {
  return sha256_domain_separated(domain, value.bytes());
}

[[nodiscard]] bool same_predictive_arrival_phase(
    const ArrivalPhase& left, const ArrivalPhase& right) {
  const auto left_bytes = arrival_phase_canonical_state(left);
  const auto right_bytes = arrival_phase_canonical_state(right);
  return arrival_phase_family(left) == arrival_phase_family(right) &&
         left_bytes.size() == right_bytes.size() &&
         std::equal(left_bytes.begin(), left_bytes.end(), right_bytes.begin());
}

[[nodiscard]] bool same_exact_arrival_phase(const ArrivalPhase& left,
                                            const ArrivalPhase& right) {
  const auto left_core = detail::ArrivalCoreAccess::phase_core(left);
  const auto right_core = detail::ArrivalCoreAccess::phase_core(right);
  return left_core && right_core &&
         same_predictive_arrival_phase(left, right) &&
         left_core->binding == right_core->binding &&
         left_core->next_authored_slot == right_core->next_authored_slot;
}

[[nodiscard]] bool resettable_field(
    const RuntimeFieldIdV1& field,
    const std::span<const RuntimeFieldIdV1> reset_fields) {
  return std::find(reset_fields.begin(), reset_fields.end(), field) !=
         reset_fields.end();
}

[[nodiscard]] bool same_unresolved_across_reset(
    const std::span<const RuntimeFieldPatchV1> left,
    const std::span<const RuntimeFieldPatchV1> right,
    const std::span<const RuntimeFieldIdV1> reset_fields) {
  if (left.size() != right.size()) {
    return false;
  }
  for (const RuntimeFieldPatchV1& source : left) {
    const auto matching = std::find_if(
        right.begin(), right.end(), [&](const RuntimeFieldPatchV1& candidate) {
          return candidate.field == source.field;
        });
    if (matching == right.end() ||
        (!resettable_field(source.field, reset_fields) &&
         !(matching->value == source.value))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool same_coordinates_across_reset(
    const ExactReducedCoordinatesV1& left,
    const ExactReducedCoordinatesV1& right,
    const std::span<const RuntimeFieldIdV1> reset_fields) {
  return left.backlog == right.backlog &&
         same_exact_arrival_phase(left.arrival_phase, right.arrival_phase) &&
         left.boundary_index == right.boundary_index &&
         left.resources == right.resources && left.margins == right.margins &&
         left.controller == right.controller &&
         same_unresolved_across_reset(left.unresolved_fields,
                                      right.unresolved_fields,
                                      reset_fields);
}

[[nodiscard]] bool same_runtime_value(const CanonicalRuntimeValueV1& left,
                                      const CanonicalRuntimeValueV1& right) {
  return left == right;
}

[[nodiscard]] bool same_state_sequence(
    std::span<const CanonicalRuntimeValueV1> left,
    std::span<const CanonicalRuntimeValueV1> right) {
  return left.size() == right.size() &&
         std::equal(left.begin(), left.end(), right.begin(),
                    same_runtime_value);
}

[[nodiscard]] NumericalProbabilityImageStatusV1 numerical_status(
    const ExactRational& value) {
  const long double image = value.to_long_double();
  if (!std::isfinite(image)) {
    return NumericalProbabilityImageStatusV1::overflow;
  }
  if (value.is_positive() && image == 0.0L) {
    return NumericalProbabilityImageStatusV1::positive_underflow;
  }
  return NumericalProbabilityImageStatusV1::finite;
}

template <typename AtomRange>
[[nodiscard]] CompensatedNumericalRowImageV1 compensated_numerical_image(
    const AtomRange& atoms) {
  long double sum = 0.0L;
  long double correction = 0.0L;
  NumericalProbabilityImageStatusV1 status =
      NumericalProbabilityImageStatusV1::finite;
  for (const auto& atom : atoms) {
    const long double value = atom.numerical_image;
    const long double updated = sum + value;
    if (std::fabs(sum) >= std::fabs(value)) {
      correction += (sum - updated) + value;
    } else {
      correction += (value - updated) + sum;
    }
    sum = updated;
    if (atom.numerical_image_status ==
        NumericalProbabilityImageStatusV1::overflow) {
      status = NumericalProbabilityImageStatusV1::overflow;
    } else if (status == NumericalProbabilityImageStatusV1::finite &&
               atom.numerical_image_status ==
                   NumericalProbabilityImageStatusV1::positive_underflow) {
      status = NumericalProbabilityImageStatusV1::positive_underflow;
    }
  }
  const long double total = sum + correction;
  return {total, total - 1.0L, status};
}

[[nodiscard]] BigInt c20_absolute(BigInt value) {
  return value < 0 ? -value : value;
}

[[nodiscard]] BigInt c20_gcd_nonnegative(BigInt left, BigInt right) {
  left = c20_absolute(std::move(left));
  right = c20_absolute(std::move(right));
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  return left;
}

[[nodiscard]] std::size_t c20_nonnegative_bit_length(
    const BigInt& value) noexcept {
  if (value == 0) {
    return 0U;
  }
  return static_cast<std::size_t>(boost::multiprecision::msb(value)) + 1U;
}

[[nodiscard]] Result<void> check_representation_budget(
    const ExactRational& value, const PmfRepresentationBudget& budget) {
  if (!value.is_nonnegative()) {
    return c20_failure<void>(
        DiagnosticCategory::internal, "c20.negative_probability_mass",
        "an exact C20 probability mass became negative");
  }
  if (!budget.maximum_integral_bits.has_value()) {
    return Result<void>::success();
  }
  if (c20_nonnegative_bit_length(value.numerator()) >
          *budget.maximum_integral_bits ||
      c20_nonnegative_bit_length(value.denominator()) >
          *budget.maximum_integral_bits) {
    return c20_resource<void>(
        "c20.representation_budget_exceeded",
        "an exact C20 probability mass exceeds the frozen integral-bit "
        "representation budget");
  }
  return Result<void>::success();
}

// Reject a definitely over-budget positive product before allocating it.
// Its bit length is either a_bits+b_bits-1 or a_bits+b_bits; the post-check
// below resolves the one-bit ambiguous case.
[[nodiscard]] bool c20_product_provably_exceeds_budget(
    const BigInt& left, const BigInt& right,
    const PmfRepresentationBudget& budget) noexcept {
  if (!budget.maximum_integral_bits.has_value()) {
    return false;
  }
  const std::size_t maximum = *budget.maximum_integral_bits;
  const std::size_t left_bits = c20_nonnegative_bit_length(left);
  const std::size_t right_bits = c20_nonnegative_bit_length(right);
  if (left_bits == 0U || right_bits == 0U) {
    return false;
  }
  if (left_bits > maximum || right_bits > maximum) {
    return true;
  }
  return left_bits > maximum - right_bits + 1U;
}

[[nodiscard]] Result<void> check_integral_scratch_budget(
    const BigInt& value, const PmfRepresentationBudget& budget,
    const std::string_view role) {
  if (value < 0) {
    return c20_failure<void>(
        DiagnosticCategory::internal, "c20.negative_probability_scratch",
        "a C20 probability scratch integer became negative");
  }
  if (budget.maximum_integral_bits.has_value() &&
      c20_nonnegative_bit_length(value) >
          *budget.maximum_integral_bits) {
    return c20_resource<void>(
        "c20.representation_budget_exceeded",
        "the exact " + std::string(role) +
            " exceeds the frozen integral-bit representation budget");
  }
  return Result<void>::success();
}

[[nodiscard]] bool c20_sum_exceeds_budget(
    const BigInt& left, const BigInt& right,
    const PmfRepresentationBudget& budget) {
  if (!budget.maximum_integral_bits.has_value()) {
    return false;
  }
  const std::size_t maximum = *budget.maximum_integral_bits;
  const std::size_t left_bits = c20_nonnegative_bit_length(left);
  const std::size_t right_bits = c20_nonnegative_bit_length(right);
  if (left_bits > maximum || right_bits > maximum) {
    return true;
  }
  const std::size_t larger_bits = std::max(left_bits, right_bits);
  if (larger_bits < maximum || larger_bits == 0U) {
    return false;
  }
  BigInt high_bit = 1;
  high_bit <<= maximum - 1U;
  const BigInt& larger = left_bits >= right_bits ? left : right;
  const BigInt& smaller = left_bits >= right_bits ? right : left;
  const BigInt excess = larger - high_bit;
  return smaller >= high_bit - excess;
}

[[nodiscard]] Result<ExactRational> multiply_probability_mass(
    const ExactRational& left, const ExactRational& right,
    const PmfRepresentationBudget& budget) {
  auto left_ok = check_representation_budget(left, budget);
  auto right_ok = check_representation_budget(right, budget);
  if (!left_ok) {
    return Result<ExactRational>::failure(left_ok.error());
  }
  if (!right_ok) {
    return Result<ExactRational>::failure(right_ok.error());
  }
  if (c20_product_provably_exceeds_budget(
          left.numerator(), right.numerator(), budget) ||
      c20_product_provably_exceeds_budget(
          left.denominator(), right.denominator(), budget)) {
    return c20_resource<ExactRational>(
        "c20.representation_budget_exceeded",
        "an exact residence branch-product scratch integer exceeds the "
        "frozen integral-bit representation budget");
  }
  BigInt numerator = left.numerator() * right.numerator();
  BigInt denominator = left.denominator() * right.denominator();
  auto numerator_ok = check_integral_scratch_budget(
      numerator, budget, "residence branch-product numerator");
  auto denominator_ok = check_integral_scratch_budget(
      denominator, budget, "residence branch-product denominator");
  if (!numerator_ok) {
    return Result<ExactRational>::failure(numerator_ok.error());
  }
  if (!denominator_ok) {
    return Result<ExactRational>::failure(denominator_ok.error());
  }
  auto product = ExactRational::make(std::move(numerator),
                                     std::move(denominator));
  if (!product) {
    return Result<ExactRational>::failure(product.error());
  }
  auto product_ok = check_representation_budget(product.value(), budget);
  if (!product_ok) {
    return Result<ExactRational>::failure(product_ok.error());
  }
  return product;
}

[[nodiscard]] Result<ExactRational> add_probability_mass(
    const ExactRational& left, const ExactRational& right,
    const PmfRepresentationBudget& budget, const std::string_view role) {
  auto left_ok = check_representation_budget(left, budget);
  auto right_ok = check_representation_budget(right, budget);
  if (!left_ok) {
    return Result<ExactRational>::failure(left_ok.error());
  }
  if (!right_ok) {
    return Result<ExactRational>::failure(right_ok.error());
  }
  const BigInt divisor =
      c20_gcd_nonnegative(left.denominator(), right.denominator());
  const BigInt reduced_left_denominator = left.denominator() / divisor;
  if (c20_product_provably_exceeds_budget(
          reduced_left_denominator, right.denominator(), budget)) {
    return c20_resource<ExactRational>(
        "c20.representation_budget_exceeded",
        "the exact " + std::string(role) +
            " denominator scratch exceeds the frozen integral-bit "
            "representation budget");
  }
  const BigInt common =
      reduced_left_denominator * right.denominator();
  auto common_ok = check_integral_scratch_budget(
      common, budget, std::string(role) + " denominator");
  if (!common_ok) {
    return Result<ExactRational>::failure(common_ok.error());
  }
  const BigInt left_multiplier = common / left.denominator();
  const BigInt right_multiplier = common / right.denominator();
  if (c20_product_provably_exceeds_budget(
          left.numerator(), left_multiplier, budget) ||
      c20_product_provably_exceeds_budget(
          right.numerator(), right_multiplier, budget)) {
    return c20_resource<ExactRational>(
        "c20.representation_budget_exceeded",
        "the exact " + std::string(role) +
            " numerator scratch exceeds the frozen integral-bit "
            "representation budget");
  }
  const BigInt scaled_left = left.numerator() * left_multiplier;
  const BigInt scaled_right = right.numerator() * right_multiplier;
  auto scaled_left_ok = check_integral_scratch_budget(
      scaled_left, budget, std::string(role) + " left numerator");
  auto scaled_right_ok = check_integral_scratch_budget(
      scaled_right, budget, std::string(role) + " right numerator");
  if (!scaled_left_ok) {
    return Result<ExactRational>::failure(scaled_left_ok.error());
  }
  if (!scaled_right_ok) {
    return Result<ExactRational>::failure(scaled_right_ok.error());
  }
  if (c20_sum_exceeds_budget(scaled_left, scaled_right, budget)) {
    return c20_resource<ExactRational>(
        "c20.representation_budget_exceeded",
        "the exact " + std::string(role) +
            " numerator sum exceeds the frozen integral-bit representation "
            "budget");
  }
  BigInt numerator = scaled_left + scaled_right;
  auto numerator_ok = check_integral_scratch_budget(
      numerator, budget, std::string(role) + " numerator sum");
  if (!numerator_ok) {
    return Result<ExactRational>::failure(numerator_ok.error());
  }
  auto sum = ExactRational::make(std::move(numerator), common);
  if (!sum) {
    return Result<ExactRational>::failure(sum.error());
  }
  auto sum_ok = check_representation_budget(sum.value(), budget);
  if (!sum_ok) {
    return Result<ExactRational>::failure(sum_ok.error());
  }
  return sum;
}

[[nodiscard]] bool stage_trace_is_exact(const CompletedReducedEdge& edge) {
  return edge.stage_trace() == kCausalStageOrderV1;
}

void encode_branch(CanonicalEncoder& encoder,
                   const CausalBranchIdentityV1& branch) {
  encoder.digest(branch.state_identity);
  encoder.count(branch.atom_path.size());
  for (const std::size_t atom : branch.atom_path) {
    encoder.count(atom);
  }
}

void encode_runtime_mark(CanonicalEncoder& encoder,
                         const RuntimeDecodedMarkV1& mark) {
  encoder.id(mark.mark);
  encoder.runtime_value(mark.value);
}

void encode_target_backlog(CanonicalEncoder& encoder,
                           const TargetBacklogV1& backlog) {
  encoder.count(backlog.size());
  for (std::size_t index = 0U; index < backlog.size(); ++index) {
    encoder.count(backlog.target_at_target_ordinal(index).ordinal());
    encoder.natural(backlog.value_at_target_ordinal(index));
  }
}

void encode_schedule(CanonicalEncoder& encoder, const Schedule& schedule) {
  encoder.framed(std::as_bytes(schedule.bytes()));
}

void encode_search_accounting(CanonicalEncoder& encoder,
                              const SearchAccounting& accounting) {
  encoder.natural(accounting.call_ordinal());
  encoder.optional_natural(accounting.effective_per_call_limit());
  encoder.natural(accounting.completed_expansions());
  encoder.enumeration(accounting.query_kind());
  encoder.boolean(accounting.family().has_value());
  if (accounting.family().has_value()) {
    encoder.enumeration(*accounting.family());
  }
  encoder.boolean(accounting.target().has_value());
  if (accounting.target().has_value()) {
    encoder.count(accounting.target()->ordinal());
  }
  encoder.boolean(accounting.exhausted());
}

void encode_primary_optimum(CanonicalEncoder& encoder,
                            const PrimaryOptimum& optimum,
                            const bool include_execution_provenance) {
  encoder.natural(optimum.value);
  encode_schedule(encoder, optimum.witness);
  encoder.natural(optimum.secondary_code);
  encoder.count(optimum.target.ordinal());
  encoder.enumeration(optimum.side);
  encoder.enumeration(optimum.family);
  encoder.enumeration(optimum.backend_id);
  // SearchAccounting is a process-local execution report.  In particular,
  // its call ordinal depends on prior ledger use and is deliberately absent
  // from Opportunity::certificate_digest().  It belongs in an edge token,
  // but never in the canonical mathematical value of a residence word.
  if (include_execution_provenance) {
    encode_search_accounting(encoder, optimum.accounting);
  }
}

void encode_opportunity_evidence(CanonicalEncoder& encoder,
                                 const Opportunity& opportunity,
                                 const bool include_execution_provenance) {
  encoder.count(opportunity.target().ordinal());
  encoder.count(opportunity.evaluation_backlog().size());
  for (const BigNat& value : opportunity.evaluation_backlog().values()) {
    encoder.natural(value);
  }
  encoder.digest(opportunity.certificate_digest());
  encoder.natural(opportunity.psi0());
  encoder.natural(opportunity.psi1());
  encoder.natural(opportunity.theta());
  encoder.integer(opportunity.margin());
  const CrossClassOutcome& cross = opportunity.cross_class_outcome();
  encoder.enumeration(cross.algebraic_class);
  encoder.boolean(cross.target_eligible);
  encoder.enumeration(cross.configured_winning_side);
  encode_schedule(encoder, cross.configured_winning_schedule);
  encoder.natural(cross.forced_out_complete_objective);
  encoder.natural(cross.forced_in_complete_objective);
  encoder.natural(cross.configured_winning_secondary_code);
  const EqualityWinnerEvidence& equality =
      opportunity.equality_winner_if_qe_eq_theta();
  encoder.enumeration(equality.winning_side);
  encode_schedule(encoder, equality.winning_schedule);
  encoder.natural(equality.common_primary_objective);
  encoder.natural(equality.winning_secondary_code);
  encode_primary_optimum(encoder, opportunity.forced_out_certificate(),
                         include_execution_provenance);
  encode_primary_optimum(encoder, opportunity.forced_in_certificate(),
                         include_execution_provenance);
}

void encode_emitted_face(CanonicalEncoder& encoder,
                         const V0EmittedOpportunityFaceV1& face) {
  encoder.count(face.alternatives.size());
  for (const V0ScheduleFaceAtomV1& alternative : face.alternatives) {
    encoder.count(alternative.selected_full_schedule.size());
    for (const QueueId& queue : alternative.selected_full_schedule) {
      encoder.id(queue);
    }
    encoder.count(alternative.non_target_departures.size());
    for (const QueueId& queue : alternative.non_target_departures) {
      encoder.id(queue);
    }
    encoder.rational(alternative.target_free_primary_score);
  }
}

void encode_opportunity(CanonicalEncoder& encoder,
                        const OpportunityMark& opportunity,
                        const bool include_branch_provenance) {
  if (include_branch_provenance) {
    encode_branch(encoder, opportunity.branch);
  }
  encoder.boolean(opportunity.prearrival_backlog.has_value());
  if (opportunity.prearrival_backlog.has_value()) {
    encode_target_backlog(encoder, *opportunity.prearrival_backlog);
  }
  encoder.boolean(opportunity.resolver_face.has_value());
  if (opportunity.resolver_face.has_value()) {
    encode_emitted_face(encoder, *opportunity.resolver_face);
  }
  encoder.boolean(opportunity.exact_opportunity_evidence.has_value());
  if (opportunity.exact_opportunity_evidence.has_value()) {
    encode_opportunity_evidence(
        encoder, *opportunity.exact_opportunity_evidence,
        include_branch_provenance);
  }
  encoder.runtime_value(opportunity.opportunity);
  encoder.count(opportunity.marks.size());
  for (const RuntimeDecodedMarkV1& mark : opportunity.marks) {
    encode_runtime_mark(encoder, mark);
  }
}

void encode_action(CanonicalEncoder& encoder, const ResolvedAction& action,
                   const bool include_branch_provenance) {
  if (include_branch_provenance) {
    encode_branch(encoder, action.branch);
  }
  encode_schedule(encoder, action.schedule);
  encode_schedule(encoder, action.actual_departure);
  encoder.digest(action.schedule_identity);
  encoder.enumeration(action.evidence.resolution_kind);
  encoder.boolean(action.evidence.common_feasible_schedule);
  encoder.boolean(action.evidence.exact_target_class.has_value());
  if (action.evidence.exact_target_class.has_value()) {
    encoder.enumeration(*action.evidence.exact_target_class);
  }
  encoder.boolean(action.evidence.emitted_face.has_value());
  if (action.evidence.emitted_face.has_value()) {
    const EmittedScheduleFaceDecisionV1& face =
        *action.evidence.emitted_face;
    encoder.count(face.ordered_target_faces.size());
    for (const EmittedTargetFaceEvidenceV1& target :
         face.ordered_target_faces) {
      encoder.count(target.target.ordinal());
      encoder.rational(target.forced_out_residual_max);
      encoder.rational(target.forced_in_residual_max);
      encoder.rational(target.algebraic_margin);
      encoder.enumeration(target.exact_class);
      encoder.boolean(target.target_eligible);
    }
    encoder.rational(face.selected_primary_score);
    encoder.natural(face.configured_secondary_code);
  }
  encoder.runtime_value(action.decision);
  encoder.optional_runtime_value(action.interim_controller);
  encoder.optional_runtime_value(action.postupdate_controller_tape);
  encoder.count(action.marks.size());
  for (const RuntimeDecodedMarkV1& mark : action.marks) {
    encode_runtime_mark(encoder, mark);
  }
}

void encode_arrival_binding(CanonicalEncoder& encoder,
                            const ArrivalBinding& binding) {
  encoder.enumeration(binding.family);
  encoder.enumeration(binding.timing);
  encoder.count(binding.queue_cardinality);
  encoder.digest(binding.law_digest.value());
  encoder.digest(binding.catalog_digest.value());
}

void encode_arrival(CanonicalEncoder& encoder,
                    const ArrivalTransition& arrival,
                    const bool include_branch_provenance) {
  if (include_branch_provenance) {
    encode_branch(encoder, arrival.branch);
  }
  encoder.natural(arrival.authored_slot);
  encoder.boolean(arrival.batch.binding().has_value());
  if (arrival.batch.binding().has_value()) {
    encode_arrival_binding(encoder, *arrival.batch.binding());
  }
  encoder.count(arrival.batch.entries().size());
  for (const ArrivalBatchEntry& entry : arrival.batch.entries()) {
    encoder.count(entry.queue.ordinal());
    encoder.natural(entry.count);
  }
  encoder.enumeration(arrival_phase_family(arrival.phase_before));
  encoder.framed(arrival_phase_canonical_state(arrival.phase_before));
  encoder.enumeration(arrival_phase_family(arrival.phase_after));
  encoder.framed(arrival_phase_canonical_state(arrival.phase_after));
  encoder.digest(arrival.law_digest.value());
  if (include_branch_provenance) {
    encoder.digest(arrival.realization_identity);
  }
  encoder.runtime_value(arrival.canonical_source);
  encoder.count(arrival.marks.size());
  for (const RuntimeDecodedMarkV1& mark : arrival.marks) {
    encode_runtime_mark(encoder, mark);
  }
}

void encode_postclosure(CanonicalEncoder& encoder, const PostClosure& post,
                        const bool include_branch_provenance) {
  if (include_branch_provenance) {
    encode_branch(encoder, post.branch);
  }
  encoder.count(post.unresolved_patch.fields().size());
  for (const RuntimeFieldPatchV1& field :
       post.unresolved_patch.fields()) {
    encoder.id(field.field);
    encoder.runtime_value(field.value);
  }
  encoder.count(post.marks.size());
  for (const RuntimeDecodedMarkV1& mark : post.marks) {
    encode_runtime_mark(encoder, mark);
  }
}

}  // namespace

namespace temporal::detail {

struct SealedRomrOpsCore final {
  std::shared_ptr<const surrogate::detail::SealedRomrOpsAuthority> authority;
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity> seal;
  Digest256 identity;
  Digest256 view_fingerprint;
  CodecIdentityV1 state_codec;
  Digest256 exact_state_schema_digest;
  Digest256 reduced_state_schema_digest;
  ExactReducedStateSchemaV1 exact_schema;
  PmfRepresentationBudget representation_budget;
  std::optional<std::size_t> maximum_residence_slots;
  std::optional<std::vector<ReducedStateV1>> finite_event_domain_states;
  bool event_entry_domain_is_exact_state_domain;
  EventClockSemanticsV1 event_clock_semantics;
  bool unit_residence;
  CodecIdentityV1 indicator_codec;
  std::vector<std::byte> stopping_false_value;
  std::vector<std::byte> stopping_true_value;
  CodecIdentityV1 predecision_projection_codec;
  CodecIdentityV1 completed_projection_codec;
  std::vector<RuntimeFieldIdV1> residence_local_reset_fields;
};

struct CursorIdentityToken final {
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity> seal;
  Digest256 residence_identity;
  Digest256 branch_identity;
};

struct StepBinding final {
  std::shared_ptr<const CursorIdentityToken> cursor;
  BigNat input_version;
  BigNat output_version;
  BigNat offset;
  Digest256 edge_digest;
};

struct ResidenceStepCore final {
  CompletedReducedEdge edge;
  CanonicalRuntimeValueV1 predecision_projection;
  CanonicalRuntimeValueV1 completed_projection;
  StepBinding binding;
};

struct StopDecisionCore final {
  StopDispositionV1 disposition;
  StepBinding binding;
};

struct ResidenceCursorCore final {
  SealedRomrOpsHandle ops;
  ResidenceLifecycleV1 lifecycle;
  std::shared_ptr<const CursorIdentityToken> identity;
  ReducedStateV1 event_entry;
  ReducedStateV1 current_state;
  CanonicalRuntimeValueV1 raw_continuation;
  BigNat offset;
  BigNat version;
  BigNat residence_stream_index;
  std::optional<Digest256> temporal_bank_root;
  std::optional<MasterSeed> temporal_bank_seed;
  std::vector<CompletedReducedEdge> edges;
  std::vector<CanonicalRuntimeValueV1> continuations;
  std::vector<CanonicalRuntimeValueV1> predecision_projections;
  std::vector<CanonicalRuntimeValueV1> completed_projections;
  std::optional<StepBinding> pending;
  std::optional<StepBinding> validated_stop;
};

struct ResidenceWordCore final {
  BigNat length;
  ReducedStateV1 entry_state;
  ReducedStateV1 event_endpoint;
  CanonicalRuntimeValueV1 raw_terminal_state;
  std::vector<CanonicalRuntimeValueV1> continuations;
  std::vector<CompletedReducedEdge> edges;
  std::vector<CanonicalRuntimeValueV1> predecision_projections;
  std::vector<CanonicalRuntimeValueV1> completed_projections;
  Digest256 word_digest;
  Digest256 view_fingerprint;
};

struct ResidenceWordRowCore final {
  ReducedStateV1 entry_state;
  std::vector<ResidenceWordRowAtomV1> atoms;
  ExactRational exact_total_mass;
  CompensatedNumericalRowImageV1 numerical_row_image;
  PmfRepresentationBudget representation_budget;
  Digest256 provider_fingerprint;
};

struct FiniteEventStateDomainCore final {
  std::vector<ReducedStateV1> states;
  Digest256 fingerprint;
  Digest256 content_digest;
  Digest256 provider_fingerprint;
  CodecIdentityV1 state_codec;
  Digest256 exact_state_schema_digest;
  Digest256 reduced_state_schema_digest;
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity> seal;
};

struct EmbeddedKernelCore final {
  FiniteEventStateDomain domain;
  std::vector<EmbeddedKernelRowV1> rows;
  Digest256 fingerprint;
  // Retained privately for C21's strict same-run/source checks.  The C20
  // stationary bridge exposes only immutable value identities and the
  // unforgeable seal token, never this core or its raw operations.
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> source_framework;
  std::shared_ptr<const SealedRomrOpsCore> romr_ops;
};

struct TemporalPathCore final {
  BigNat horizon;
  ReducedStateV1 initial_state;
  ReducedStateV1 final_state;
  std::vector<TemporalSlotV1> slots;
  std::vector<ResidenceWord> completed_words;
  std::vector<BigNat> event_epochs;
  std::optional<UnfinishedResidenceV1> unfinished;
  Digest256 framework_fingerprint;
  Digest256 initial_law_digest;
  Digest256 path_stream_identity;
};

}  // namespace temporal::detail

namespace detail {

class C20CoreAccess final {
 public:
  C20CoreAccess() = delete;

  [[nodiscard]] static DeterministicRuntimeMarkDecoderCallbackV1
  fresh_mark_decoder(
      const DeterministicRuntimeMarkDecoderOperationV1& decoder) {
    return decoder.fresh_operation();
  }

  [[nodiscard]] static UnresolvedPatch empty_unresolved_patch() {
    return UnresolvedPatch(std::vector<RuntimeFieldPatchV1>{});
  }

  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedRomrView& view) noexcept {
    return view.core_;
  }
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedResidenceProvider& provider) noexcept {
    return provider.core_;
  }
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedTemporalFramework& framework) noexcept {
    return framework.core_;
  }
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedSlotExecutor& executor) noexcept {
    return executor.core_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      stationary::detail::TemporalServiceKernelCore>&
  temporal_service_core(const TemporalServiceKernel& kernel) noexcept {
    return kernel.core_;
  }

  [[nodiscard]] static AuditedCylinderLaw stationary_cylinder_law(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::StationaryProjectionSourceCore>
          source,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 projection_fingerprint) {
    Digest256 source_fingerprint = projection_fingerprint;
    return AuditedCylinderLaw(
        std::move(core), std::move(source), std::move(temporal_source),
        std::move(source_fingerprint), std::move(projection_fingerprint));
  }
  [[nodiscard]] static AuditedTemporalLaw stationary_temporal_law(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::StationaryProjectionSourceCore>
          source,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 projection_fingerprint) {
    Digest256 source_fingerprint = projection_fingerprint;
    return AuditedTemporalLaw(
        std::move(core), std::move(source), std::move(temporal_source),
        std::move(source_fingerprint), std::move(projection_fingerprint));
  }
  [[nodiscard]] static AuditedTemporalKernel stationary_temporal_kernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::StationaryProjectionSourceCore>
          source,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 projection_fingerprint) {
    Digest256 source_fingerprint = projection_fingerprint;
    return AuditedTemporalKernel(
        std::move(core), std::move(source), std::move(temporal_source),
        std::move(source_fingerprint), std::move(projection_fingerprint));
  }

  [[nodiscard]] static AuditedTemporalKernel passive_fifo_temporal_kernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source) {
    const Digest256 source_fingerprint =
        temporal_source->binding.source_fingerprint;
    const Digest256 projection_fingerprint =
        *temporal_source->binding.projection_fingerprint;
    return AuditedTemporalKernel(
        std::move(core), AuditedTemporalSourceKindV1::passive_fifo_tag,
        std::move(temporal_source), source_fingerprint,
        projection_fingerprint);
  }

  [[nodiscard]] static const std::shared_ptr<const
      stationary::detail::StationaryProjectionSourceCore>&
  stationary_source(const AuditedCylinderLaw& view) noexcept {
    return view.stationary_source_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      stationary::detail::StationaryProjectionSourceCore>&
  stationary_source(const AuditedTemporalLaw& view) noexcept {
    return view.stationary_source_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      stationary::detail::StationaryProjectionSourceCore>&
  stationary_source(const AuditedTemporalKernel& view) noexcept {
    return view.stationary_source_;
  }

  [[nodiscard]] static const std::shared_ptr<const
      metrics::detail::TemporalSourceCore>&
  temporal_source(const AuditedCylinderLaw& view) noexcept {
    return view.temporal_source_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      metrics::detail::TemporalSourceCore>&
  temporal_source(const AuditedTemporalLaw& view) noexcept {
    return view.temporal_source_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      metrics::detail::TemporalSourceCore>&
  temporal_source(const AuditedTemporalKernel& view) noexcept {
    return view.temporal_source_;
  }

  [[nodiscard]] static const std::shared_ptr<
      surrogate::detail::SealedFrameworkCore>&
  stationary_core(const AuditedCylinderLaw& view) noexcept {
    return view.core_;
  }
  [[nodiscard]] static const std::shared_ptr<
      surrogate::detail::SealedFrameworkCore>&
  stationary_core(const AuditedTemporalLaw& view) noexcept {
    return view.core_;
  }
  [[nodiscard]] static const std::shared_ptr<
      surrogate::detail::SealedFrameworkCore>&
  stationary_core(const AuditedTemporalKernel& view) noexcept {
    return view.core_;
  }

  [[nodiscard]] static const std::shared_ptr<const
      surrogate::detail::AuditedConsumerSealIdentity>&
  initial_law_seal(const ReducedInitialLaw& law) noexcept {
    return law.seal_;
  }

  [[nodiscard]] static SealedRomrOpsHandle handle(
      std::shared_ptr<const temporal::detail::SealedRomrOpsCore> core) {
    return SealedRomrOpsHandle(std::move(core));
  }
  [[nodiscard]] static const std::shared_ptr<const
      temporal::detail::SealedRomrOpsCore>&
  handle_core(const SealedRomrOpsHandle& handle) noexcept {
    return handle.core_;
  }

  [[nodiscard]] static FiniteEventStateDomain domain(
      std::shared_ptr<const temporal::detail::FiniteEventStateDomainCore>
          core) {
    return FiniteEventStateDomain(std::move(core));
  }
  [[nodiscard]] static const std::shared_ptr<const
      temporal::detail::FiniteEventStateDomainCore>&
  domain_core(const FiniteEventStateDomain& domain) noexcept {
    return domain.core_;
  }

  [[nodiscard]] static ResidenceStep step(
      std::shared_ptr<const temporal::detail::ResidenceStepCore> core) {
    return ResidenceStep(std::move(core));
  }
  [[nodiscard]] static const std::shared_ptr<const
      temporal::detail::ResidenceStepCore>&
  step_core(const ResidenceStep& step) noexcept {
    return step.core_;
  }
  [[nodiscard]] static StopDecision decision(
      std::shared_ptr<const temporal::detail::StopDecisionCore> core) {
    return StopDecision(std::move(core));
  }
  [[nodiscard]] static const std::shared_ptr<const
      temporal::detail::StopDecisionCore>&
  decision_core(const StopDecision& decision) noexcept {
    return decision.core_;
  }
  [[nodiscard]] static ResidenceWord word(
      std::shared_ptr<const temporal::detail::ResidenceWordCore> core) {
    return ResidenceWord(std::move(core));
  }
  [[nodiscard]] static const std::shared_ptr<const
      temporal::detail::ResidenceWordCore>&
  word_core(const ResidenceWord& word) noexcept {
    return word.core_;
  }
  [[nodiscard]] static ResidenceWordRow word_row(
      std::shared_ptr<const temporal::detail::ResidenceWordRowCore> core) {
    return ResidenceWordRow(std::move(core));
  }
  [[nodiscard]] static EmbeddedKernel embedded_kernel(
      std::shared_ptr<const temporal::detail::EmbeddedKernelCore> core) {
    return EmbeddedKernel(std::move(core));
  }
  [[nodiscard]] static const std::shared_ptr<const
      temporal::detail::EmbeddedKernelCore>&
  embedded_kernel_core(const EmbeddedKernel& kernel) noexcept {
    return kernel.core_;
  }
  [[nodiscard]] static TemporalPath path(
      std::shared_ptr<const temporal::detail::TemporalPathCore> core) {
    return TemporalPath(std::move(core));
  }

  static void set_residence_stream_index(ResidenceCursor& cursor,
                                         BigNat index) {
    cursor.core_->residence_stream_index = std::move(index);
  }
  [[nodiscard]] static temporal::detail::ResidenceCursorCore& cursor_core(
      ResidenceCursor& cursor) noexcept {
    return *cursor.core_;
  }
  [[nodiscard]] static const temporal::detail::ResidenceCursorCore&
  cursor_core(const ResidenceCursor& cursor) noexcept {
    return *cursor.core_;
  }
};

}  // namespace detail

const Digest256& SealedRomrOpsHandle::identity() const noexcept {
  return core_->identity;
}

ResidenceCursor::ResidenceCursor(const ResidenceCursor& other)
    : core_(std::make_unique<temporal::detail::ResidenceCursorCore>(
          *other.core_)) {
  auto token = std::make_shared<const temporal::detail::CursorIdentityToken>(
      *other.core_->identity);
  core_->identity = token;
  if (core_->pending.has_value()) {
    core_->pending->cursor = token;
  }
  if (core_->validated_stop.has_value()) {
    core_->validated_stop->cursor = token;
  }
}

ResidenceCursor::ResidenceCursor(
    std::unique_ptr<temporal::detail::ResidenceCursorCore> core)
    : core_(std::move(core)) {}

ResidenceCursor::ResidenceCursor(ResidenceCursor&&) noexcept = default;

ResidenceCursor& ResidenceCursor::operator=(const ResidenceCursor& other) {
  if (this != &other) {
    ResidenceCursor copy(other);
    core_.swap(copy.core_);
  }
  return *this;
}

ResidenceCursor& ResidenceCursor::operator=(ResidenceCursor&&) noexcept =
    default;
ResidenceCursor::~ResidenceCursor() = default;

ResidenceLifecycleV1 ResidenceCursor::lifecycle() const noexcept {
  return core_->lifecycle;
}
const BigNat& ResidenceCursor::offset() const noexcept { return core_->offset; }
const BigNat& ResidenceCursor::version() const noexcept {
  return core_->version;
}
const ReducedStateV1& ResidenceCursor::event_entry() const noexcept {
  return core_->event_entry;
}
const ReducedStateV1& ResidenceCursor::current_state() const noexcept {
  return core_->current_state;
}
const CanonicalRuntimeValueV1& ResidenceCursor::raw_continuation()
    const noexcept {
  return core_->raw_continuation;
}
const Digest256& ResidenceCursor::audited_view_fingerprint() const noexcept {
  return detail::C20CoreAccess::handle_core(core_->ops)->view_fingerprint;
}
const Digest256& ResidenceCursor::residence_identity() const noexcept {
  return core_->identity->residence_identity;
}
const SealedRomrOpsHandle& ResidenceCursor::ops_handle() const noexcept {
  return core_->ops;
}
std::span<const CompletedReducedEdge> ResidenceCursor::edges() const noexcept {
  return core_->edges;
}

const CompletedReducedEdge& ResidenceStep::edge() const noexcept {
  return core_->edge;
}
const CanonicalRuntimeValueV1& ResidenceStep::predecision_projection()
    const noexcept {
  return core_->predecision_projection;
}
const CanonicalRuntimeValueV1& ResidenceStep::completed_edge_projection()
    const noexcept {
  return core_->completed_projection;
}
const BigNat& ResidenceStep::offset() const noexcept {
  return core_->binding.offset;
}
const BigNat& ResidenceStep::input_version() const noexcept {
  return core_->binding.input_version;
}
const BigNat& ResidenceStep::output_version() const noexcept {
  return core_->binding.output_version;
}
const Digest256& ResidenceStep::completed_edge_digest() const noexcept {
  return core_->binding.edge_digest;
}

StopDispositionV1 StopDecision::disposition() const noexcept {
  return core_->disposition;
}
const BigNat& StopDecision::offset() const noexcept {
  return core_->binding.offset;
}
const BigNat& StopDecision::cursor_version() const noexcept {
  return core_->binding.output_version;
}
const Digest256& StopDecision::completed_edge_digest() const noexcept {
  return core_->binding.edge_digest;
}

const BigNat& ResidenceWord::length() const noexcept { return core_->length; }
const ReducedStateV1& ResidenceWord::entry_state() const noexcept {
  return core_->entry_state;
}
const ReducedStateV1& ResidenceWord::event_endpoint() const noexcept {
  return core_->event_endpoint;
}
const CanonicalRuntimeValueV1& ResidenceWord::raw_terminal_state()
    const noexcept {
  return core_->raw_terminal_state;
}
std::span<const CanonicalRuntimeValueV1> ResidenceWord::continuation_path()
    const noexcept {
  return core_->continuations;
}
std::span<const CompletedReducedEdge> ResidenceWord::edges() const noexcept {
  return core_->edges;
}
std::span<const CanonicalRuntimeValueV1>
ResidenceWord::predecision_projections() const noexcept {
  return core_->predecision_projections;
}
std::span<const CanonicalRuntimeValueV1>
ResidenceWord::completed_edge_projections() const noexcept {
  return core_->completed_projections;
}
const Digest256& ResidenceWord::word_digest() const noexcept {
  return core_->word_digest;
}
const Digest256& ResidenceWord::audited_view_fingerprint() const noexcept {
  return core_->view_fingerprint;
}

const ReducedStateV1& ResidenceWordRow::entry_state() const noexcept {
  return core_->entry_state;
}
std::span<const ResidenceWordRowAtomV1> ResidenceWordRow::atoms()
    const noexcept {
  return core_->atoms;
}
const ExactRational& ResidenceWordRow::exact_total_mass() const noexcept {
  return core_->exact_total_mass;
}
const CompensatedNumericalRowImageV1&
ResidenceWordRow::numerical_row_image() const noexcept {
  return core_->numerical_row_image;
}
const PmfRepresentationBudget& ResidenceWordRow::representation_budget()
    const noexcept {
  return core_->representation_budget;
}
const Digest256& ResidenceWordRow::provider_fingerprint() const noexcept {
  return core_->provider_fingerprint;
}

std::span<const ReducedStateV1> FiniteEventStateDomain::states()
    const noexcept {
  return core_->states;
}
const Digest256& FiniteEventStateDomain::fingerprint() const noexcept {
  return core_->fingerprint;
}
std::optional<std::size_t> FiniteEventStateDomain::index_of(
    const ReducedStateV1& state) const noexcept {
  for (std::size_t index = 0U; index < core_->states.size(); ++index) {
    if (core_->states[index] == state) {
      return index;
    }
  }
  return std::nullopt;
}

const FiniteEventStateDomain& EmbeddedKernel::domain() const noexcept {
  return core_->domain;
}
std::span<const EmbeddedKernelRowV1> EmbeddedKernel::rows() const noexcept {
  return core_->rows;
}
const Digest256& EmbeddedKernel::fingerprint() const noexcept {
  return core_->fingerprint;
}

const BigNat& TemporalPath::horizon() const noexcept { return core_->horizon; }
const ReducedStateV1& TemporalPath::initial_state() const noexcept {
  return core_->initial_state;
}
const ReducedStateV1& TemporalPath::final_state() const noexcept {
  return core_->final_state;
}
std::span<const TemporalSlotV1> TemporalPath::slots() const noexcept {
  return core_->slots;
}
std::span<const ResidenceWord> TemporalPath::completed_words()
    const noexcept {
  return core_->completed_words;
}
std::span<const BigNat> TemporalPath::event_epochs() const noexcept {
  return core_->event_epochs;
}
const std::optional<UnfinishedResidenceV1>& TemporalPath::unfinished()
    const noexcept {
  return core_->unfinished;
}
const Digest256& TemporalPath::framework_fingerprint() const noexcept {
  return core_->framework_fingerprint;
}
const Digest256& TemporalPath::reduced_initial_law_digest() const noexcept {
  return core_->initial_law_digest;
}
const Digest256& TemporalPath::path_stream_identity() const noexcept {
  return core_->path_stream_identity;
}

}  // namespace mwperf

namespace mwperf {
namespace {

using RomrCore = temporal::detail::SealedRomrOpsCore;
using CursorCore = temporal::detail::ResidenceCursorCore;
using StepCore = temporal::detail::ResidenceStepCore;
using Binding = temporal::detail::StepBinding;

[[nodiscard]] Result<CanonicalRuntimeValueV1> invoke_initializer(
    const RomrCore& ops, const CanonicalRuntimeValueV1& value) {
  if (!ops.authority) {
    return c20_unavailable<CanonicalRuntimeValueV1>(
        "c20.missing_sealed_event_operations",
        "the sealed ROMR handle has lost its event initializer authority");
  }
  return ops.authority->initialize(value);
}

[[nodiscard]] Result<CanonicalRuntimeValueV1> invoke_stop(
    const RomrCore& ops, const CanonicalRuntimeValueV1& value) {
  if (!ops.authority) {
    return c20_unavailable<CanonicalRuntimeValueV1>(
        "c20.missing_sealed_event_operations",
        "the sealed ROMR handle has lost its stopping authority");
  }
  return ops.authority->stop(value);
}

[[nodiscard]] Result<CanonicalRuntimeValueV1> invoke_terminal(
    const RomrCore& ops, const EventTerminalReentryInputV1& input) {
  if (!ops.authority) {
    return c20_unavailable<CanonicalRuntimeValueV1>(
        "c20.missing_sealed_event_operations",
        "the sealed ROMR handle has lost its terminal authority");
  }
  return ops.authority->terminal(input);
}

[[nodiscard]] Result<CanonicalRuntimeValueV1> invoke_predecision_projection(
    const RomrCore& ops, const EventPredecisionProjectionInputV1& input) {
  if (!ops.authority) {
    return c20_unavailable<CanonicalRuntimeValueV1>(
        "c20.missing_sealed_event_operations",
        "the sealed ROMR handle has lost its predecision projection authority");
  }
  return ops.authority->predecision(input);
}

[[nodiscard]] Result<CanonicalRuntimeValueV1> invoke_completed_projection(
    const RomrCore& ops, const EventCompletedEdgeProjectionInputV1& input) {
  if (!ops.authority) {
    return c20_unavailable<CanonicalRuntimeValueV1>(
        "c20.missing_sealed_event_operations",
        "the sealed ROMR handle has lost its completed projection authority");
  }
  return ops.authority->completed(input);
}

[[nodiscard]] Result<Digest256> event_domain_content_digest(
    const RomrCore& ops, std::span<const ReducedStateV1> states) {
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.codec(ops.state_codec);
  encoder.digest(ops.exact_state_schema_digest);
  encoder.digest(ops.reduced_state_schema_digest);
  encoder.u64(static_cast<std::uint64_t>(states.size()));
  for (std::size_t index = 0U; index < states.size(); ++index) {
    encoder.u64(static_cast<std::uint64_t>(index));
    encoder.runtime_value(states[index]);
  }
  return finish_digest("mwperf.c20.event-state-domain-content.v1", encoder);
}

[[nodiscard]] Result<Digest256> event_domain_fingerprint(
    const RomrCore& ops, std::span<const ReducedStateV1> states) {
  auto content = event_domain_content_digest(ops, states);
  if (!content) {
    return Result<Digest256>::failure(content.error());
  }
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(ops.view_fingerprint);
  encoder.digest(ops.identity);
  encoder.digest(content.value());
  return finish_digest("mwperf.c20.event-state-domain.v1", encoder);
}

[[nodiscard]] Result<void> validate_entry_state(const RomrCore& ops,
                                                const ReducedStateV1& state) {
  if (!(state.codec == ops.state_codec)) {
    return c20_invalid<void>(
        "c20.event_entry_codec_mismatch",
        "the event-entry state does not use the sealed exact reduced-state "
        "codec");
  }
  auto valid = ops.exact_schema.validate_domain(state);
  if (!valid) {
    return Result<void>::failure(valid.error());
  }
  if (!ops.finite_event_domain_states.has_value() &&
      !ops.event_entry_domain_is_exact_state_domain) {
    return c20_unavailable<void>(
        "c20.event_entry_domain_unavailable",
        "the ROMR view has no sealed event-entry membership descriptor");
  }
  if (ops.finite_event_domain_states.has_value() &&
      std::find(ops.finite_event_domain_states->begin(),
                ops.finite_event_domain_states->end(), state) ==
          ops.finite_event_domain_states->end()) {
    return c20_invalid<void>(
        "c20.event_entry_outside_domain",
        "the event-entry state is outside the sealed ROMR entry domain");
  }
  return Result<void>::success();
}

[[nodiscard]] bool same_event_quotient_coordinates(
    const ExactReducedCoordinatesV1& left,
    const ExactReducedCoordinatesV1& right) {
  const auto left_phase =
      detail::ArrivalCoreAccess::phase_core(left.arrival_phase);
  const auto right_phase =
      detail::ArrivalCoreAccess::phase_core(right.arrival_phase);
  return left_phase && right_phase &&
         left.backlog == right.backlog &&
         same_predictive_arrival_phase(left.arrival_phase,
                                       right.arrival_phase) &&
         left_phase->binding == right_phase->binding &&
         left.resources == right.resources && left.margins == right.margins &&
         left.controller == right.controller &&
         left.unresolved_fields == right.unresolved_fields;
}

[[nodiscard]] Result<ArrivalPhase> quotient_phase_at_slot(
    const ArrivalPhase& phase, BigNat slot) {
  const auto core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!core) {
    return c20_invalid<ArrivalPhase>(
        "c20.quotient_arrival_phase_missing",
        "the finite event-clock quotient requires a complete configured "
        "arrival phase");
  }
  try {
    auto replacement = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{
            core->family, core->binding, core->state_digest,
            core->canonical_state, std::move(slot), core->cursor_state,
            core->cursor_owner});
    return Result<ArrivalPhase>::success(
        detail::ArrivalCoreAccess::make_phase(core->family,
                                              std::move(replacement)));
  } catch (const std::bad_alloc&) {
    return c20_resource<ArrivalPhase>(
        "c20.quotient_phase_allocation_exhausted",
        "constructing a slot-erased callback phase exhausted memory");
  }
}

// Provider event operations are invoked through a clock-erased ABI whenever
// the row-only quotient is active.  This prevents C-minus/C-plus-independent
// stop, terminal, initializer, and projection callbacks from recovering the
// absolute physical slot from opaque continuation bytes.  Raw cursor/edge
// state is never replaced by this value.
[[nodiscard]] Result<ReducedStateV1> quotient_callback_state(
    const RomrCore& ops, const ReducedStateV1& raw_state) {
  if (ops.event_clock_semantics !=
      EventClockSemanticsV1::finite_phase_time_homogeneous_quotient) {
    return Result<ReducedStateV1>::success(raw_state);
  }
  auto decoded = ops.exact_schema.decode(raw_state);
  if (!decoded) {
    return Result<ReducedStateV1>::failure(decoded.error());
  }
  ExactReducedCoordinatesV1 anchored = decoded.value();
  auto phase = quotient_phase_at_slot(anchored.arrival_phase, BigNat{0U});
  if (!phase) {
    return Result<ReducedStateV1>::failure(phase.error());
  }
  anchored.arrival_phase = std::move(phase).value();
  anchored.boundary_index = BigNat{0U};
  auto rebuilt = ops.exact_schema.rebuild(
      anchored, detail::C20CoreAccess::empty_unresolved_patch());
  if (!rebuilt) {
    return Result<ReducedStateV1>::failure(rebuilt.error());
  }
  auto valid = ops.exact_schema.validate_domain(rebuilt.value());
  if (!valid) {
    return Result<ReducedStateV1>::failure(valid.error());
  }
  auto round_trip = ops.exact_schema.decode(rebuilt.value());
  const auto round_phase = round_trip
                               ? detail::ArrivalCoreAccess::phase_core(
                                     round_trip.value().arrival_phase)
                               : nullptr;
  if (!round_trip || !round_phase ||
      !(round_trip.value().boundary_index == BigNat{0U}) ||
      !(round_phase->next_authored_slot == BigNat{0U}) ||
      !same_event_quotient_coordinates(anchored, round_trip.value())) {
    return c20_invalid<ReducedStateV1>(
        "c20.quotient_callback_state_round_trip_mismatch",
        "the exact state schema cannot expose a slot-zero callback value "
        "without changing a retained coordinate");
  }
  return rebuilt;
}

// Lift a callback's clock-erased state result back onto the raw physical
// clock.  Only non-clock coordinates are taken from the callback result; the
// boundary and arrival cursor lineage come exclusively from raw_physical.
[[nodiscard]] Result<ReducedStateV1> lift_quotient_callback_state(
    const RomrCore& ops, const ReducedStateV1& raw_physical,
    const ReducedStateV1& callback_result) {
  if (ops.event_clock_semantics !=
      EventClockSemanticsV1::finite_phase_time_homogeneous_quotient) {
    return Result<ReducedStateV1>::success(callback_result);
  }
  auto raw = ops.exact_schema.decode(raw_physical);
  auto result = ops.exact_schema.decode(callback_result);
  if (!raw) {
    return Result<ReducedStateV1>::failure(raw.error());
  }
  if (!result) {
    return Result<ReducedStateV1>::failure(result.error());
  }
  const auto raw_phase = detail::ArrivalCoreAccess::phase_core(
      raw.value().arrival_phase);
  const auto result_phase = detail::ArrivalCoreAccess::phase_core(
      result.value().arrival_phase);
  if (!raw_phase || !raw_phase->cursor_owner ||
      !(raw_phase->next_authored_slot == raw.value().boundary_index)) {
    return c20_invalid<ReducedStateV1>(
        "c20.raw_physical_cursor_lineage_missing",
        "lifting a quotient callback requires a raw physical arrival phase "
        "whose cursor lineage is anchored at the physical boundary");
  }
  if (!result_phase ||
      !(result.value().boundary_index == BigNat{0U}) ||
      !(result_phase->next_authored_slot == BigNat{0U})) {
    return c20_invalid<ReducedStateV1>(
        "c20.clockful_quotient_callback_result",
        "an event operation in the quotient lane returned a value outside "
        "its slot-zero callback ABI");
  }
  if (!same_predictive_arrival_phase(raw.value().arrival_phase,
                                     result.value().arrival_phase) ||
      !(raw_phase->binding == result_phase->binding)) {
    return c20_invalid<ReducedStateV1>(
        "c20.quotient_callback_predictive_phase_changed",
        "an event operation in the quotient lane changed the configured "
        "predictive arrival phase while its physical clock was erased");
  }
  ExactReducedCoordinatesV1 lifted = result.value();
  // Callback phases belong to the slot-zero representative's private
  // cursor.  They are valid only inside the clock-erased ABI and must never
  // replace the raw path's RNG/cursor provenance.  Restore the complete raw
  // phase object (not merely its authored slot) after checking that the
  // callback retained the same predictive phase and binding.
  lifted.arrival_phase = raw.value().arrival_phase;
  lifted.boundary_index = raw.value().boundary_index;
  auto rebuilt = ops.exact_schema.rebuild(
      lifted, detail::C20CoreAccess::empty_unresolved_patch());
  if (!rebuilt) {
    return Result<ReducedStateV1>::failure(rebuilt.error());
  }
  auto round_trip = ops.exact_schema.decode(rebuilt.value());
  const auto round_phase = round_trip
                               ? detail::ArrivalCoreAccess::phase_core(
                                     round_trip.value().arrival_phase)
                               : nullptr;
  if (!round_trip || !round_phase ||
      !(round_phase->next_authored_slot == raw.value().boundary_index) ||
      !arrival_phases_share_cursor(raw.value().arrival_phase,
                                   round_trip.value().arrival_phase) ||
      raw_phase->cursor_state != round_phase->cursor_state ||
      !same_coordinates_across_reset(
          lifted, round_trip.value(),
          std::span<const RuntimeFieldIdV1>{})) {
    return c20_invalid<ReducedStateV1>(
        "c20.quotient_callback_lift_round_trip_mismatch",
        "lifting a clock-erased event result changed an exact retained "
        "coordinate or replaced the raw physical arrival cursor lineage");
  }
  return rebuilt;
}

// Project only the event-state index.  The caller retains the raw terminal
// and every completed edge unchanged in the word.  This operation is absent
// from the realized/path lane because C17 withholds its slot executor for a
// quotient seal.
[[nodiscard]] Result<ReducedStateV1> project_event_clock_quotient(
    const RomrCore& ops, const ReducedStateV1& raw_terminal) {
  if (ops.event_clock_semantics !=
      EventClockSemanticsV1::finite_phase_time_homogeneous_quotient ||
      !ops.finite_event_domain_states.has_value()) {
    return Result<ReducedStateV1>::success(raw_terminal);
  }
  auto raw = ops.exact_schema.decode(raw_terminal);
  if (!raw) {
    return Result<ReducedStateV1>::failure(raw.error());
  }
  const auto raw_phase =
      detail::ArrivalCoreAccess::phase_core(raw.value().arrival_phase);
  if (!raw_phase ||
      !(raw_phase->next_authored_slot == raw.value().boundary_index)) {
    return c20_invalid<ReducedStateV1>(
        "c20.raw_terminal_clock_mismatch",
        "the raw terminal's physical boundary and configured-arrival cursor "
        "slot disagree");
  }

  const ReducedStateV1* match = nullptr;
  for (const ReducedStateV1& candidate :
       *ops.finite_event_domain_states) {
    auto decoded = ops.exact_schema.decode(candidate);
    if (!decoded) {
      return Result<ReducedStateV1>::failure(decoded.error());
    }
    const auto phase =
        detail::ArrivalCoreAccess::phase_core(decoded.value().arrival_phase);
    if (!phase || !(decoded.value().boundary_index == BigNat{0U}) ||
        !(phase->next_authored_slot == BigNat{0U})) {
      return c20_invalid<ReducedStateV1>(
          "c20.invalid_event_clock_representative",
          "a sealed finite event-clock representative is not anchored at "
          "authored slot zero");
    }
    if (!same_event_quotient_coordinates(raw.value(), decoded.value())) {
      continue;
    }
    if (match != nullptr) {
      return c20_invalid<ReducedStateV1>(
          "c20.ambiguous_event_clock_quotient",
          "the raw terminal maps to more than one finite event-state "
          "representative");
    }
    match = &candidate;
  }
  if (match == nullptr) {
    return c20_invalid<ReducedStateV1>(
        "c20.endpoint_outside_event_domain",
        "the raw terminal has no exact non-clock representative in the "
        "sealed finite event domain");
  }
  return Result<ReducedStateV1>::success(*match);
}

[[nodiscard]] Result<Digest256> romr_ops_identity(
    const surrogate::detail::SealedFrameworkCore& framework,
    const CodecIdentityV1& state_codec, const bool unit_residence) {
  const ExactCausalProgramV1& program = framework.inputs().causal_program;
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(framework.execution_seal_digest());
  encoder.digest(framework.descriptor().descriptor_digest);
  encoder.codec(state_codec);
  encoder.boolean(unit_residence);
  encoder.optional_count(
      program.representation_budget.maximum_integral_bits);
  encoder.optional_count(unit_residence
                             ? std::optional<std::size_t>{1U}
                             : program.maximum_residence_slots);
  encoder.boolean(program.finite_event_domain_states.has_value());
  if (program.finite_event_domain_states.has_value()) {
    encoder.count(program.finite_event_domain_states->size());
    for (const ReducedStateV1& state :
         *program.finite_event_domain_states) {
      encoder.runtime_value(state);
    }
  }
  encoder.boolean(program.event_entry_domain_is_exact_state_domain);
  encoder.enumeration(program.event_clock_semantics);
  if (framework.descriptor().event_contract.has_value()) {
    const TemporalEventContractV1& event =
        *framework.descriptor().event_contract;
    encoder.id(event.event_generator_operation.operation_id);
    encoder.u32(event.event_generator_operation.operation_version);
    encoder.id(event.entry_initializer_operation.operation_id);
    encoder.u32(event.entry_initializer_operation.operation_version);
    encoder.id(event.stopping_indicator_operation.operation_id);
    encoder.u32(event.stopping_indicator_operation.operation_version);
    encoder.id(event.terminal_reentry_operation.operation_id);
    encoder.u32(event.terminal_reentry_operation.operation_version);
    encoder.id(event.predecision_projection_operation.operation_id);
    encoder.u32(event.predecision_projection_operation.operation_version);
    encoder.id(event.completed_edge_projection_operation.operation_id);
    encoder.u32(event.completed_edge_projection_operation.operation_version);
    encoder.codec(event.continuation_space);
    encoder.codec(event.entrance_space);
    encoder.codec(event.terminal_space);
    encoder.codec(event.reentry_space);
    encoder.codec(event.stopping_indicator);
    encoder.codec(event.predecision_projection);
    encoder.codec(event.completed_edge_projection);
    encoder.framed(event.stopping_false_value);
    encoder.framed(event.stopping_true_value);
    encoder.count(event.residence_local_reset_fields.size());
    for (const RuntimeFieldIdV1& field :
         event.residence_local_reset_fields) {
      encoder.id(field);
    }
  } else {
    encoder.string("mwperf.c20.canonical-unit-romr.v1");
  }
  return finish_digest("mwperf.c20.sealed-romr-ops.v1", encoder);
}

[[nodiscard]] Result<SealedRomrOpsHandle> mint_romr_handle(
    const AuditedRomrView& view) {
  const auto framework = detail::C20CoreAccess::core(view);
  if (!framework || !framework->report().passed()) {
    return c20_unavailable<SealedRomrOpsHandle>(
        "c20.romr_view_requires_v0",
        "a ROMR operations handle requires a live passing C17 V0 seal");
  }

  const auto& inputs = framework->inputs();
  const CodecIdentityV1 state_codec =
      inputs.exact_state_schema.reduced_state_codec;
  const bool unit = framework->is_three_bin();
  const auto authority = framework->romr_ops_authority();
  if (!authority) {
    return c20_unavailable<SealedRomrOpsHandle>(
        "c20.missing_sealed_event_operations",
        "the audited ROMR view carries no C17-minted event authority");
  }
  auto identity = romr_ops_identity(*framework, state_codec, unit);
  if (!identity) {
    return Result<SealedRomrOpsHandle>::failure(identity.error());
  }

  CodecIdentityV1 indicator_codec{"mwperf.c20.unit-stop-indicator", 1U};
  std::vector<std::byte> stopping_false_value{std::byte{0x00}};
  std::vector<std::byte> stopping_true_value{std::byte{0x01}};
  CodecIdentityV1 pre_codec = state_codec;
  CodecIdentityV1 completed_codec = state_codec;
  std::vector<RuntimeFieldIdV1> reset_fields;

  if (unit) {
  } else {
    const TemporalEventContractV1* contract =
        framework->descriptor().event_contract
            ? &*framework->descriptor().event_contract
            : nullptr;
    if (contract == nullptr) {
      return c20_unavailable<SealedRomrOpsHandle>(
          "c20.missing_sealed_event_operations",
          "the audited ROMR view has no complete temporal event operations");
    }

    // C19 had no explicit event/reduced-state conversion operation.  C20
    // therefore accepts only the lossless ABI case in which all four event
    // state spaces are the exact reduced-state codec.  Guessing a byte-level
    // relabeling would violate (12.4d).
    if (!(contract->entrance_space == state_codec) ||
        !(contract->continuation_space == state_codec) ||
        !(contract->terminal_space == state_codec) ||
        !(contract->reentry_space == state_codec)) {
      return c20_unavailable<SealedRomrOpsHandle>(
          "c20.event_state_codec_bridge_unavailable",
          "C20 requires a lossless exact-state event ABI; the sealed contract "
          "declares distinct event codecs without a conversion operation");
    }

    indicator_codec = contract->stopping_indicator;
    stopping_false_value = contract->stopping_false_value;
    stopping_true_value = contract->stopping_true_value;
    pre_codec = contract->predecision_projection;
    completed_codec = contract->completed_edge_projection;
    reset_fields = contract->residence_local_reset_fields;
  }

  auto romr = std::make_shared<const RomrCore>(RomrCore{
      authority,
      framework->consumer_seal_identity(),
      std::move(identity).value(),
      framework->execution_seal_digest(),
      state_codec,
      inputs.exact_state_schema.exact_state_schema_digest,
      inputs.exact_state_schema.reduced_state_schema_digest,
      inputs.exact_state_schema,
      inputs.causal_program.representation_budget,
      unit ? std::optional<std::size_t>(1U)
           : inputs.causal_program.maximum_residence_slots,
      inputs.causal_program.finite_event_domain_states,
      unit ||
          inputs.causal_program
              .event_entry_domain_is_exact_state_domain,
      inputs.causal_program.event_clock_semantics,
      unit,
      std::move(indicator_codec),
      std::move(stopping_false_value),
      std::move(stopping_true_value),
      std::move(pre_codec),
      std::move(completed_codec),
      std::move(reset_fields)});
  return Result<SealedRomrOpsHandle>::success(
      detail::C20CoreAccess::handle(std::move(romr)));
}

[[nodiscard]] Result<Digest256> c20_target_service_schema_identity(
    const surrogate::detail::SealedFrameworkCore& framework) {
  const AuditedFrameworkBindingsV1& bindings =
      framework.inputs().framework_seed.bindings;
  const DerivedServiceIdentity& service =
      framework.inputs().instance.service_identity();
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(bindings.problem_fingerprints.constraint);
  encoder.digest(bindings.problem_fingerprints.target_selection);
  encoder.digest(bindings.ordered_target_digest);
  encoder.enumeration(service.scheduler);
  encoder.enumeration(service.family);
  encoder.enumeration(service.optimizer);
  encoder.enumeration(framework.descriptor().core.target_coupling);
  encoder.count(framework.descriptor().core.deployed_targets.size());
  for (const QueueId& target :
       framework.descriptor().core.deployed_targets) {
    encoder.id(target);
  }
  return finish_digest("mwperf.c20.target-service-schema.v1", encoder);
}

[[nodiscard]] temporal::detail::C20StationaryCapabilityFactsV1
c20_stationary_capability_facts(
    const surrogate::detail::SealedFrameworkCore& framework,
    const RomrCore& ops, const BuilderArrivalView& arrival_view) {
  temporal::detail::C20StationaryCapabilityFactsV1 facts;
  const auto retain_maximum = [](std::optional<BigNat>& retained,
                                 const BigNat& candidate) {
    if (!retained.has_value() || *retained < candidate) {
      retained = candidate;
    }
  };
  const auto cylinder_maximum = [](const FiniteCylinderCoverageV1& coverage) {
    return std::visit(
        [](const auto& typed) -> BigNat {
          using Coverage = std::decay_t<decltype(typed)>;
          if constexpr (std::is_same_v<Coverage,
                                       ExplicitCylinderOffsetsV1>) {
            if (typed.offsets.empty()) {
              return BigNat{0U};
            }
            return *std::max_element(typed.offsets.begin(),
                                     typed.offsets.end());
          } else {
            BigNat maximum = typed.maximum_offset;
            if constexpr (std::is_same_v<
                              Coverage,
                              InclusiveCylinderThroughWithExtraOffsetsV1>) {
              if (!typed.extra_offsets.empty() &&
                  maximum < typed.extra_offsets.back()) {
                maximum = typed.extra_offsets.back();
              }
            }
            return maximum;
          }
        },
        coverage);
  };
  const auto retain_cylinder_budget = [&](
                                          const FiniteCylinderRequirementV1&
                                              cylinder) {
    const BigNat maximum = cylinder_maximum(cylinder.coverage);
    switch (cylinder.family) {
      case FiniteCylinderFamilyV1::target_backlog:
      case FiniteCylinderFamilyV1::coupled_backlog:
        retain_maximum(facts.maximum_stationary_state_offset, maximum);
        break;
      case FiniteCylinderFamilyV1::target_departure:
      case FiniteCylinderFamilyV1::target_predicate:
      case FiniteCylinderFamilyV1::coupled_schedule:
        retain_maximum(facts.maximum_stationary_edge_offset, maximum);
        break;
      case FiniteCylinderFamilyV1::generic_marked_word:
        retain_maximum(facts.maximum_stationary_state_offset, maximum);
        retain_maximum(facts.maximum_stationary_edge_offset, maximum);
        break;
    }
  };
  const bool exact_complete_residence_words =
      framework.row_available() && ops.maximum_residence_slots.has_value() &&
      *ops.maximum_residence_slots != 0U &&
      ops.finite_event_domain_states.has_value();
  const auto is_stationary_selection = [](const MetricSelectionRegimeV1 value) {
    switch (value) {
      case MetricSelectionRegimeV1::stationary_unique:
      case MetricSelectionRegimeV1::stationary_class:
      case MetricSelectionRegimeV1::stationary_mixture:
        return true;
      case MetricSelectionRegimeV1::transient:
      case MetricSelectionRegimeV1::fixed_point_unique:
      case MetricSelectionRegimeV1::fixed_point_id:
        return false;
    }
    return false;
  };
  const auto requires_generic_stationary_temporal_law =
      [](const MetricKindV1 kind) {
        switch (kind) {
          case MetricKindV1::service_persistence:
          case MetricKindV1::service_autocovariance:
          case MetricKindV1::lagged_cross_queue_covariance:
          case MetricKindV1::service_spectrum:
          case MetricKindV1::service_window_count:
          case MetricKindV1::mean_event_gap:
          case MetricKindV1::event_gap_distribution:
          case MetricKindV1::mean_binary_run:
          case MetricKindV1::binary_run_distribution:
          case MetricKindV1::counterfactual_opportunity_gap:
            return true;
          default:
            return false;
        }
      };
  const auto is_f05_request = [](const MetricKindV1 kind) {
    switch (kind) {
      case MetricKindV1::service_persistence:
      case MetricKindV1::service_autocovariance:
      case MetricKindV1::service_spectrum:
      case MetricKindV1::service_window_count:
      case MetricKindV1::mean_event_gap:
      case MetricKindV1::mean_binary_run:
        return true;
      default:
        return false;
    }
  };
  const auto retain_f05_authorization =
      [&](const MetricClauseOriginV1& origin) {
        if (!is_f05_request(origin.kind) ||
            origin.wire_coupling !=
                MetricTargetCouplingV1::scalar_singleton ||
            origin.ordered_targets.size() != 1U) {
          return;
        }
        const auto& deployed = framework.descriptor().core.deployed_targets;
        const QueueId& requested = origin.ordered_targets.front().queue_id;
        std::optional<std::size_t> ordinal;
        for (std::size_t index = 0U; index < deployed.size(); ++index) {
          if (!(deployed[index] == requested)) {
            continue;
          }
          if (ordinal.has_value()) {
            // A duplicated deployed target is not a usable scalar target
            // identity.  C17 normally rejects it; this bridge grants no
            // authorization if an inconsistent record reaches it.
            return;
          }
          ordinal = index;
        }
        if (!ordinal.has_value()) {
          return;
        }
        metrics::detail::F05AuthorizationV1 authorization{
            origin.kind, *ordinal, origin.parameters};
        if (std::find(facts.f05_authorizations.begin(),
                      facts.f05_authorizations.end(), authorization) ==
            facts.f05_authorizations.end()) {
          facts.f05_authorizations.push_back(std::move(authorization));
        }
      };
  const MetricRequirements& requirements =
      framework.inputs().accepted_contract.requirements();
  for (const ResolvedMetricContractV1& contract :
       framework.inputs().accepted_contract.metric_contracts()) {
    if (contract.semantic != framework.descriptor().core.semantic ||
        contract.runtime_access !=
            framework.descriptor().core.runtime_access ||
        contract.target_coupling !=
            framework.descriptor().core.target_coupling) {
      continue;
    }

    const auto clause = std::find_if(
        requirements.clauses().begin(), requirements.clauses().end(),
        [&](const MetricRequirementClause& candidate) {
          return candidate.origin.clause_id == contract.clause_id &&
                 candidate.origin.clause_id.authored_index ==
                     contract.authored_metric_index &&
                 candidate.origin.ordered_targets == contract.ordered_targets;
        });
    if (clause == requirements.clauses().end() ||
        !is_stationary_selection(clause->origin.selection_regime)) {
      // C21 is a stationary suspension.  A transient or fixed-point request
      // cannot authorize any of its views merely because it shares a coarse
      // backend-route enum with a stationary request.
      continue;
    }

    std::vector<const MetricRouteAlternativeV1*> matching_routes;
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.backend_route == contract.backend_route &&
          route.semantic.coupling == contract.target_coupling) {
        matching_routes.push_back(&route);
      }
    }
    if (matching_routes.empty()) {
      // The accepted contract and its immutable requirement clause must stay
      // correlated.  Treat an inconsistent record as granting no C21 view.
      continue;
    }
    const auto every_matching_route =
        [&](const auto& predicate) {
          return std::all_of(
              matching_routes.begin(), matching_routes.end(),
              [&](const MetricRouteAlternativeV1* route) {
                return predicate(route->semantic);
              });
        };
    const bool exact_cylinder = every_matching_route(
        [](const SemanticContractAlternativeV1& semantic) {
          return std::holds_alternative<FiniteCylinderRequirementV1>(
              semantic.law);
        });
    const bool exact_invariant = every_matching_route(
        [](const SemanticContractAlternativeV1& semantic) {
          return std::holds_alternative<
              SelectedInvariantMarginalRequirementV1>(semantic.law);
        });
    const bool exact_marked_edge = every_matching_route(
        [](const SemanticContractAlternativeV1& semantic) {
          return std::holds_alternative<StationaryMarkedEdgeRequirementV1>(
              semantic.law);
        });
    const bool exact_residence_word = every_matching_route(
        [](const SemanticContractAlternativeV1& semantic) {
          return std::holds_alternative<ResidenceWordRequirementV1>(
              semantic.law);
        });
    const bool exact_stopped_path = every_matching_route(
        [](const SemanticContractAlternativeV1& semantic) {
          return std::holds_alternative<StoppedPathRequirementV1>(
              semantic.law);
        });
    const bool exact_stationary_entrance =
        exact_stopped_path && every_matching_route(
            [](const SemanticContractAlternativeV1& semantic) {
              return semantic.entrance == EntranceLawRequirementV1::none;
            });
    const bool exact_admission_palm_stopped =
        exact_stopped_path && every_matching_route(
            [](const SemanticContractAlternativeV1& semantic) {
              return semantic.entrance ==
                     EntranceLawRequirementV1::admission_palm;
            });

    // Retain the observation budget from the exact correlated route, not
    // from the aggregate requirement summaries (which may include an
    // unselected alternative).  A bounded cylinder remains bounded even
    // though C21's latent source happens to contain complete rows.
    if (exact_cylinder) {
      for (const MetricRouteAlternativeV1* route : matching_routes) {
        retain_cylinder_budget(
            std::get<FiniteCylinderRequirementV1>(route->semantic.law));
      }
    }

    bool authorizes_f05 = false;
    switch (contract.backend_route) {
      case BackendRouteKindV1::stationary_invariant:
        facts.stationary_invariant_route |= exact_invariant;
        break;
      case BackendRouteKindV1::stationary_edge_reward:
        facts.stationary_edge_reward_route |= exact_marked_edge;
        break;
      case BackendRouteKindV1::finite_temporal_cylinder:
        facts.finite_temporal_cylinder_route |= exact_cylinder;
        facts.stationary_temporal_law_route |=
            exact_cylinder && requires_generic_stationary_temporal_law(
                                  clause->origin.kind);
        authorizes_f05 = exact_cylinder && is_f05_request(clause->origin.kind);
        break;
      case BackendRouteKindV1::residence_or_stopped_law:
        facts.residence_or_stopped_route |=
            exact_residence_word || exact_stopped_path;
        facts.stationary_temporal_law_route |=
            exact_residence_word && requires_generic_stationary_temporal_law(
                                        clause->origin.kind);
        // The killed continuation is entrance-independent.  Palm and FIFO
        // constructions may later supply a different, fingerprint-matched
        // entrance without changing or renormalizing this kernel.
        facts.stationary_stopped_kernel_route |=
            exact_residence_word || exact_stopped_path;
        facts.stationary_stopped_entrance_route |=
            exact_stationary_entrance;
        facts.unbounded_stationary_temporal_continuation |=
            exact_residence_word || exact_stopped_path;
        authorizes_f05 =
            exact_residence_word && is_f05_request(clause->origin.kind);
        break;
      case BackendRouteKindV1::palm_or_fifo_law:
        facts.palm_or_fifo_route |= exact_admission_palm_stopped;
        // A FIFO stopped-path request owns the same entrance-independent,
        // unbounded chronological continuation as an ordinary stopped-law
        // request.  Its entrance is supplied later by C23's admission-Palm
        // lift, but that does not make the service kernel bounded or
        // nonpredictive.  Retain this authority from the accepted FIFO route
        // itself; requiring an unrelated residence/stopped request here would
        // make an otherwise complete FIFO contract spuriously unavailable.
        facts.stationary_stopped_kernel_route |=
            exact_admission_palm_stopped;
        facts.unbounded_stationary_temporal_continuation |=
            exact_admission_palm_stopped;
        break;
      case BackendRouteKindV1::framework_scalar_identity:
        break;
      case BackendRouteKindV1::analytic_metric_family:
        // C22's source-derived window and mean gap/run readouts are exact
        // chronological functionals when C20 retained enumerable complete
        // words.  The analytic route label does not authorize a fitted or
        // sampler-only temporal law.
        facts.stationary_temporal_law_route |=
            exact_complete_residence_words &&
            requires_generic_stationary_temporal_law(clause->origin.kind);
        if (exact_complete_residence_words &&
            requires_generic_stationary_temporal_law(clause->origin.kind)) {
          for (const MetricRouteAlternativeV1* route : matching_routes) {
            if (const auto* count =
                    std::get_if<PushforwardCountLawRequirementV1>(
                        &route->semantic.law);
                count != nullptr) {
              auto maximum = checked_subtract(count->width, BigNat{1U});
              if (maximum) {
                retain_maximum(facts.maximum_stationary_edge_offset,
                               maximum.value());
              }
            } else if (const auto* scalar =
                           std::get_if<FrameworkDerivedScalarRequirementV1>(
                               &route->semantic.law);
                       scalar != nullptr) {
              switch (scalar->scalar) {
                case FrameworkScalarKindV1::event_intensity_active_fraction:
                  retain_maximum(facts.maximum_stationary_state_offset,
                                 BigNat{0U});
                  retain_maximum(facts.maximum_stationary_edge_offset,
                                 BigNat{0U});
                  break;
                case FrameworkScalarKindV1::binary_occupation_start_ratio:
                  retain_maximum(facts.maximum_stationary_state_offset,
                                 BigNat{1U});
                  retain_maximum(facts.maximum_stationary_edge_offset,
                                 BigNat{1U});
                  break;
                case FrameworkScalarKindV1::arrival_intensity:
                case FrameworkScalarKindV1::stationary_backlog_mean:
                  break;
              }
            }
          }
        }
        authorizes_f05 = exact_complete_residence_words &&
                         is_f05_request(clause->origin.kind);
        break;
      case BackendRouteKindV1::conditional_row_monte_carlo:
      case BackendRouteKindV1::conditional_reward_monte_carlo:
      case BackendRouteKindV1::exact_direct:
        break;
    }
    if (authorizes_f05) {
      retain_f05_authorization(clause->origin);
    }
  }
  facts.retains_predictive_phase =
      framework.descriptor().core.phase.retains_configured_predictive_phase;
  // CompletedReducedEdge always retains the common actual departure and the
  // one configured joint arrival transition.  Publication of a particular
  // metric still remains gated by the accepted C14 requirements above.
  facts.retains_target_departure = true;
  facts.retains_arrival_batch = true;
  facts.exact_complete_residence_words = exact_complete_residence_words;
  facts.finite_phase_time_homogeneous =
      ops.event_clock_semantics ==
          EventClockSemanticsV1::finite_phase_time_homogeneous_quotient &&
      arrival_view.finite_phase().has_value() &&
      arrival_view.finite_phase()->row_clock_semantics ==
          ArrivalRowClockSemanticsV1::finite_phase_time_homogeneous;
  return facts;
}

[[nodiscard]] Result<temporal::detail::C20StationarySourceBindingV1>
c20_make_stationary_source_binding(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& framework,
    const std::shared_ptr<const RomrCore>& ops) {
  if (!framework || !ops || !framework->report().passed() ||
      !framework->consumer_seal_identity() || !ops->seal ||
      framework->consumer_seal_identity() != ops->seal ||
      framework->execution_seal_digest() != ops->view_fingerprint) {
    return c20_invalid<temporal::detail::C20StationarySourceBindingV1>(
        "c20.stationary_source_seal_mismatch",
        "the stationary handoff requires one live matching C17/C20 seal");
  }
  if (!ops->finite_event_domain_states.has_value() ||
      ops->finite_event_domain_states->empty()) {
    return c20_unavailable<
        temporal::detail::C20StationarySourceBindingV1>(
        "c20.stationary_finite_event_domain_unavailable",
        "the C21 exact stationary route requires C20's nonempty sealed "
        "finite event domain");
  }
  const CompiledFrameworkCandidateInputsV1& inputs = framework->inputs();
  if (!inputs.instance.analysis_spec().context) {
    return c20_invalid<temporal::detail::C20StationarySourceBindingV1>(
        "c20.stationary_analysis_context_missing",
        "the sealed stationary source has lost its immutable analysis "
        "selection and solver context");
  }
  const AuditedFrameworkBindingsV1& bindings =
      inputs.framework_seed.bindings;
  const FrameworkProblemFingerprintsV1& problem =
      bindings.problem_fingerprints;
  const BuilderArrivalView arrival_view =
      builder_arrival_view(inputs.configured_arrival);
  if (!(arrival_view.binding() ==
        arrival_law_binding(inputs.configured_arrival))) {
    return c20_invalid<temporal::detail::C20StationarySourceBindingV1>(
        "c20.stationary_arrival_binding_mismatch",
        "the callback-free configured-arrival view does not match the "
        "sealed arrival law");
  }
  auto target_service = c20_target_service_schema_identity(*framework);
  if (!target_service) {
    return Result<temporal::detail::C20StationarySourceBindingV1>::failure(
        target_service.error());
  }

  std::vector<ResolvedMetricContractV1> metric_contracts(
      inputs.accepted_contract.metric_contracts().begin(),
      inputs.accepted_contract.metric_contracts().end());
  const AnalysisContext& analysis = *inputs.instance.analysis_spec().context;
  temporal::detail::C20StationarySourceBindingV1 output{
      framework->consumer_seal_identity(),
      ops->identity,
      framework->execution_seal_digest(),
      framework->descriptor().descriptor_digest,
      framework->validated_contract_digest(),
      bindings.normalized_metric_requirements_digest,
      bindings.selection_digest,
      problem.authored_inputs.analysis,
      problem.resolved_instance,
      problem.compiled_arrival,
      arrival_view.digest().value(),
      arrival_view.binding().law_digest.value(),
      arrival_view.binding().catalog_digest.value(),
      inputs.exact_state_schema.exact_state_schema_digest,
      inputs.exact_state_schema.reduced_state_schema_digest,
      inputs.exact_state_schema.ownership_schema_digest,
      inputs.exact_state_schema.exact_update_schema_digest,
      // The canonical descriptor identity binds the ordered runtime marks,
      // their decoders, dependencies, codecs, and reveal stages.
      framework->descriptor().descriptor_digest,
      problem.tie_and_timing,
      // The ROMR identity binds the complete continuation/event schema and
      // every operation identity without exposing any operation.
      ops->identity,
      problem.target_selection,
      std::move(target_service).value(),
      ops->state_codec,
      inputs.instance.timing(),
      ops->event_clock_semantics,
      ops->representation_budget,
      analysis.selection,
      analysis.solver,
      arrival_view.binding(),
      arrival_view.finite_phase(),
      arrival_view.stationary_phase_law(),
      inputs.accepted_contract.arrival_capabilities(),
      inputs.accepted_contract.requirements(),
      std::move(metric_contracts),
      framework->descriptor().state_fields,
      framework->descriptor().marks,
      framework->descriptor().event_contract,
      inputs.framework_seed.target_selection,
      inputs.instance.service_identity(),
      c20_stationary_capability_facts(*framework, *ops, arrival_view)};
  return Result<temporal::detail::C20StationarySourceBindingV1>::success(
      std::move(output));
}

[[nodiscard]] Result<Digest256> residence_identity(
    const RomrCore& ops, const ReducedStateV1& state) {
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(ops.identity);
  encoder.runtime_value(state);
  return finish_digest("mwperf.c20.residence.v1", encoder);
}

[[nodiscard]] Result<Digest256> branch_identity(
    const Digest256& residence, const Digest256* parent,
    const std::optional<std::size_t> child) {
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(residence);
  if (parent != nullptr) {
    encoder.digest(*parent);
  }
  if (child.has_value()) {
    encoder.u64(static_cast<std::uint64_t>(*child));
  }
  return finish_digest("mwperf.c20.residence-branch.v1", encoder);
}

[[nodiscard]] Result<Digest256> completed_edge_digest(
    const CompletedReducedEdge& edge, const bool include_branch_provenance) {
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.runtime_value(edge.pre_state());
  encoder.runtime_value(edge.successor_state());
  encode_opportunity(encoder, edge.opportunity(),
                     include_branch_provenance);
  encode_action(encoder, edge.action(), include_branch_provenance);
  encode_arrival(encoder, edge.arrival(), include_branch_provenance);
  encode_postclosure(encoder, edge.postclosure(),
                     include_branch_provenance);
  encoder.count(edge.marks().size());
  for (const CausalMarkV1& mark : edge.marks()) {
    encoder.enumeration(mark.reveal_stage);
    encode_runtime_mark(encoder, mark.mark);
  }
  encoder.count(edge.stage_trace().size());
  for (const CausalStageV1 stage : edge.stage_trace()) {
    encoder.enumeration(stage);
  }
  return finish_digest(include_branch_provenance
                           ? "mwperf.c20.completed-edge-token.v1"
                           : "mwperf.c20.completed-edge-value.v1",
                       encoder);
}

[[nodiscard]] KernelTransitionV1 event_transition(
    const CompletedReducedEdge& edge) {
  std::vector<CanonicalRuntimeValueV1> marks;
  marks.reserve(edge.marks().size());
  for (const CausalMarkV1& mark : edge.marks()) {
    marks.push_back(mark.mark.value);
  }
  return KernelTransitionV1{edge.successor_state(), std::move(marks)};
}

[[nodiscard]] std::vector<GeneratedResidenceSlotV1> generated_prefix(
    const CursorCore& cursor) {
  std::vector<GeneratedResidenceSlotV1> prefix;
  prefix.reserve(cursor.edges.size());
  for (std::size_t index = 0U; index < cursor.edges.size(); ++index) {
    prefix.push_back(GeneratedResidenceSlotV1{
        cursor.continuations[index], event_transition(cursor.edges[index])});
  }
  return prefix;
}

[[nodiscard]] bool same_binding(const Binding& left,
                                const Binding& right) {
  return left.cursor == right.cursor &&
         left.input_version == right.input_version &&
         left.output_version == right.output_version &&
         left.offset == right.offset && left.edge_digest == right.edge_digest;
}

[[nodiscard]] Result<CanonicalRuntimeValueV1> prepare_predecision_projection(
    const CursorCore& cursor) {
  const auto ops = detail::C20CoreAccess::handle_core(cursor.ops);
  auto event_entry = quotient_callback_state(*ops, cursor.event_entry);
  auto current = quotient_callback_state(*ops, cursor.raw_continuation);
  if (!event_entry) {
    return Result<CanonicalRuntimeValueV1>::failure(event_entry.error());
  }
  if (!current) {
    return Result<CanonicalRuntimeValueV1>::failure(current.error());
  }
  std::vector<GeneratedResidenceSlotV1> prefix = generated_prefix(cursor);
  for (GeneratedResidenceSlotV1& slot : prefix) {
    auto predecision = quotient_callback_state(*ops,
                                               slot.predecision_state);
    auto successor = quotient_callback_state(
        *ops, slot.completed_edge.successor_state);
    if (!predecision) {
      return Result<CanonicalRuntimeValueV1>::failure(predecision.error());
    }
    if (!successor) {
      return Result<CanonicalRuntimeValueV1>::failure(successor.error());
    }
    slot.predecision_state = std::move(predecision).value();
    slot.completed_edge.successor_state = std::move(successor).value();
  }
  EventPredecisionProjectionInputV1 input{
      std::move(event_entry).value(), std::move(prefix),
      std::move(current).value()};
  auto projection = invoke_predecision_projection(*ops, input);
  if (!projection) {
    return Result<CanonicalRuntimeValueV1>::failure(projection.error());
  }
  if (!(projection.value().codec == ops->predecision_projection_codec)) {
    return c20_invalid<CanonicalRuntimeValueV1>(
        "c20.predecision_projection_codec_mismatch",
        "the sealed predecision projection returned a foreign codec");
  }
  return projection;
}

[[nodiscard]] Result<ResidenceStep> append_completed_edge(
    CursorCore& cursor, CompletedReducedEdge edge,
    CanonicalRuntimeValueV1 predecision_projection) {
  if (cursor.lifecycle != ResidenceLifecycleV1::open) {
    return c20_invalid<ResidenceStep>(
        "c20.cursor_not_open",
        "a residence edge can be appended only to an open cursor with no "
        "pending stop validation");
  }
  if (!(edge.pre_state() == cursor.current_state)) {
    return c20_invalid<ResidenceStep>(
        "c20.edge_prestate_mismatch",
        "the completed C17 edge does not start at the cursor's exact current "
        "state");
  }
  if (!stage_trace_is_exact(edge)) {
    return c20_invalid<ResidenceStep>(
        "c20.invalid_completed_edge_stage_trace",
        "a residence edge must retain C-minus, resolver, arrival, C-plus, Psi "
        "in that exact order");
  }

  const auto ops = detail::C20CoreAccess::handle_core(cursor.ops);
  if (!(predecision_projection.codec ==
        ops->predecision_projection_codec)) {
    return c20_invalid<ResidenceStep>(
        "c20.predecision_projection_codec_mismatch",
        "the sealed predecision projection returned a foreign codec");
  }
  KernelTransitionV1 callback_edge = event_transition(edge);
  auto callback_successor = quotient_callback_state(
      *ops, callback_edge.successor_state);
  if (!callback_successor) {
    return Result<ResidenceStep>::failure(callback_successor.error());
  }
  callback_edge.successor_state = std::move(callback_successor).value();
  EventCompletedEdgeProjectionInputV1 completed_input{
      predecision_projection, std::move(callback_edge)};
  auto completed = invoke_completed_projection(*ops, completed_input);
  if (!completed) {
    return Result<ResidenceStep>::failure(completed.error());
  }
  if (!(completed.value().codec == ops->completed_projection_codec)) {
    return c20_invalid<ResidenceStep>(
        "c20.completed_projection_codec_mismatch",
        "the sealed completed-edge projection returned a foreign codec");
  }
  if (!(edge.successor_state().codec == ops->state_codec)) {
    return c20_invalid<ResidenceStep>(
        "c20.edge_successor_codec_mismatch",
        "the completed C17 edge left the sealed exact state codec");
  }
  auto domain = ops->exact_schema.validate_domain(edge.successor_state());
  if (!domain) {
    return Result<ResidenceStep>::failure(domain.error());
  }
  auto digest = completed_edge_digest(edge, true);
  if (!digest) {
    return Result<ResidenceStep>::failure(digest.error());
  }

  const BigNat input_version = cursor.version;
  BigNat output_version = input_version;
  ++output_version;
  BigNat next_offset = cursor.offset;
  ++next_offset;
  Binding binding{cursor.identity, input_version, output_version, next_offset,
                  digest.value()};
  auto step_core = std::make_shared<const StepCore>(StepCore{
      edge, predecision_projection, completed.value(), binding});

  cursor.current_state = edge.successor_state();
  cursor.raw_continuation = edge.successor_state();
  cursor.edges.push_back(std::move(edge));
  cursor.continuations.push_back(cursor.raw_continuation);
  cursor.predecision_projections.push_back(predecision_projection);
  cursor.completed_projections.push_back(completed.value());
  cursor.offset = std::move(next_offset);
  cursor.version = std::move(output_version);
  cursor.pending = binding;
  cursor.validated_stop.reset();
  cursor.lifecycle = ResidenceLifecycleV1::step_pending_validation;
  return Result<ResidenceStep>::success(
      detail::C20CoreAccess::step(std::move(step_core)));
}

[[nodiscard]] Result<void> rebind_enumerated_branch(
    CursorCore& cursor, const std::size_t child) {
  auto branch = branch_identity(cursor.identity->residence_identity,
                                &cursor.identity->branch_identity, child);
  if (!branch) {
    return Result<void>::failure(branch.error());
  }
  cursor.identity =
      std::make_shared<const temporal::detail::CursorIdentityToken>(
          temporal::detail::CursorIdentityToken{
              cursor.identity->seal, cursor.identity->residence_identity,
              std::move(branch).value()});
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_word_replay(const CursorCore& cursor) {
  const auto ops = detail::C20CoreAccess::handle_core(cursor.ops);
  if (cursor.edges.empty() || cursor.continuations.size() !=
                                  cursor.edges.size() + 1U ||
      cursor.predecision_projections.size() != cursor.edges.size() ||
      cursor.completed_projections.size() != cursor.edges.size()) {
    return c20_invalid<void>(
        "c20.invalid_residence_word_lengths",
        "a completed residence requires ell>=1, ell+1 continuation states, "
        "and ell entries in every slot-mark sequence");
  }
  ReducedStateV1 replay = cursor.continuations.front();
  for (std::size_t index = 0U; index < cursor.edges.size(); ++index) {
    const CompletedReducedEdge& edge = cursor.edges[index];
    if (!(edge.pre_state() == replay) ||
        !(cursor.continuations[index] == edge.pre_state()) ||
        !(cursor.continuations[index + 1U] == edge.successor_state()) ||
        !stage_trace_is_exact(edge)) {
      return c20_invalid<void>(
          "c20.residence_replay_chain_mismatch",
          "the residence continuation phases and C17 edges do not form one "
          "chronological chain");
    }
    auto before = ops->exact_schema.decode(edge.pre_state());
    auto after = ops->exact_schema.decode(edge.successor_state());
    if (!before) {
      return Result<void>::failure(before.error());
    }
    if (!after) {
      return Result<void>::failure(after.error());
    }
    if (before.value().backlog.size() != after.value().backlog.size()) {
      return c20_invalid<void>(
          "c20.residence_replay_backlog_dimension_mismatch",
          "a residence edge changed the target backlog dimension");
    }
    for (std::size_t target = 0U;
         target < before.value().backlog.size(); ++target) {
      const std::size_t physical =
          before.value().backlog.target_at_target_ordinal(target).ordinal();
      const std::uint8_t departure =
          edge.action().actual_departure.bytes()[physical];
      if (departure > 1U) {
        return c20_invalid<void>(
            "c20.nonbinary_departure",
            "a residence word contains a target departure greater than one");
      }
      auto after_service = checked_subtract(
          before.value().backlog.value_at_target_ordinal(target),
          BigNat(departure));
      if (!after_service) {
        return c20_invalid<void>(
            "c20.departure_exceeds_backlog",
            "a residence word attempts a departure from an empty target "
            "queue");
      }
      BigNat expected = std::move(after_service).value();
      for (const ArrivalBatchEntry& arrival : edge.arrival().batch.entries()) {
        if (arrival.queue.ordinal() == physical) {
          expected += arrival.count;
        }
      }
      if (!(expected ==
            after.value().backlog.value_at_target_ordinal(target))) {
        return c20_invalid<void>(
            "c20.residence_replay_endpoint_mismatch",
            "the exact replay n[j+1]=n[j]-d[j]+a_e[j+1] does not equal the "
            "stored C17 successor");
      }
    }
    replay = edge.successor_state();
  }
  if (!(replay == cursor.current_state) ||
      !(cursor.raw_continuation == cursor.current_state) ||
      !(cursor.continuations.back() == cursor.current_state)) {
    return c20_invalid<void>(
        "c20.residence_replay_endpoint_mismatch",
        "the replayed final state differs from the cursor endpoint");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<Digest256> residence_word_digest(
    const Digest256& ops_identity, const Digest256& view_fingerprint,
    const ReducedStateV1& entry, const ReducedStateV1& endpoint,
    const CanonicalRuntimeValueV1& raw_terminal,
    std::span<const CanonicalRuntimeValueV1> continuations,
    std::span<const CompletedReducedEdge> edges,
    std::span<const CanonicalRuntimeValueV1> predecision,
    std::span<const CanonicalRuntimeValueV1> completed) {
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(ops_identity);
  encoder.digest(view_fingerprint);
  encoder.runtime_value(entry);
  encoder.runtime_value(endpoint);
  encoder.runtime_value(raw_terminal);
  encoder.u64(static_cast<std::uint64_t>(edges.size()));
  for (const CanonicalRuntimeValueV1& value : continuations) {
    encoder.runtime_value(value);
  }
  for (const CompletedReducedEdge& edge : edges) {
    auto digest = completed_edge_digest(edge, false);
    if (!digest) {
      return Result<Digest256>::failure(digest.error());
    }
    encoder.digest(digest.value());
  }
  for (const CanonicalRuntimeValueV1& value : predecision) {
    encoder.runtime_value(value);
  }
  for (const CanonicalRuntimeValueV1& value : completed) {
    encoder.runtime_value(value);
  }
  return finish_digest("mwperf.c20.residence-word.v1", encoder);
}

[[nodiscard]] bool same_primary_optimum_word_value(
    const PrimaryOptimum& left, const PrimaryOptimum& right) {
  return left.value == right.value && left.witness == right.witness &&
         left.secondary_code == right.secondary_code &&
         left.target == right.target && left.side == right.side &&
         left.family == right.family && left.backend_id == right.backend_id;
}

[[nodiscard]] bool same_exact_opportunity_word_value(
    const std::optional<Opportunity>& left,
    const std::optional<Opportunity>& right) {
  if (left.has_value() != right.has_value()) {
    return false;
  }
  if (!left.has_value()) {
    return true;
  }
  return left->target() == right->target() &&
         left->evaluation_backlog() == right->evaluation_backlog() &&
         left->certificate_digest() == right->certificate_digest() &&
         left->psi0() == right->psi0() && left->psi1() == right->psi1() &&
         left->theta() == right->theta() && left->margin() == right->margin() &&
         left->cross_class_outcome() == right->cross_class_outcome() &&
         left->equality_winner_if_qe_eq_theta() ==
             right->equality_winner_if_qe_eq_theta() &&
         same_primary_optimum_word_value(left->forced_out_certificate(),
                                         right->forced_out_certificate()) &&
         same_primary_optimum_word_value(left->forced_in_certificate(),
                                         right->forced_in_certificate());
}

// C17's duplicate-row predicate correctly preserves the complete C17
// evidence object, including process-local optimizer accounting.  A C20 word
// is a mathematical/observable residence value instead: atom-path/stream
// provenance and SearchAccounting do not distinguish equation-(12.7) words.
[[nodiscard]] bool same_completed_edge_word_value(
    const CompletedReducedEdge& left, const CompletedReducedEdge& right) {
  const OpportunityMark& left_opportunity = left.opportunity();
  const OpportunityMark& right_opportunity = right.opportunity();
  const ResolvedAction& left_action = left.action();
  const ResolvedAction& right_action = right.action();
  const PostClosure& left_post = left.postclosure();
  const PostClosure& right_post = right.postclosure();
  return left.pre_state() == right.pre_state() &&
         left.successor_state() == right.successor_state() &&
         left_opportunity.prearrival_backlog ==
             right_opportunity.prearrival_backlog &&
         left_opportunity.resolver_face == right_opportunity.resolver_face &&
         same_exact_opportunity_word_value(
             left_opportunity.exact_opportunity_evidence,
             right_opportunity.exact_opportunity_evidence) &&
         left_opportunity.opportunity == right_opportunity.opportunity &&
         left_opportunity.marks == right_opportunity.marks &&
         left_action.schedule == right_action.schedule &&
         left_action.actual_departure == right_action.actual_departure &&
         left_action.schedule_identity == right_action.schedule_identity &&
         left_action.evidence == right_action.evidence &&
         left_action.decision == right_action.decision &&
         left_action.interim_controller == right_action.interim_controller &&
         left_action.postupdate_controller_tape ==
             right_action.postupdate_controller_tape &&
         left_action.marks == right_action.marks &&
         same_arrival_transition_value(left.arrival(), right.arrival()) &&
         left_post.unresolved_patch == right_post.unresolved_patch &&
         left_post.marks == right_post.marks &&
         left.marks().size() == right.marks().size() &&
         std::equal(left.marks().begin(), left.marks().end(),
                    right.marks().begin(), right.marks().end()) &&
         left.stage_trace() == right.stage_trace();
}

[[nodiscard]] bool same_word_value(const ResidenceWord& left,
                                   const ResidenceWord& right) {
  const auto left_core = detail::C20CoreAccess::word_core(left);
  const auto right_core = detail::C20CoreAccess::word_core(right);
  if (left_core->word_digest != right_core->word_digest ||
      left_core->entry_state != right_core->entry_state ||
      left_core->event_endpoint != right_core->event_endpoint ||
      left_core->raw_terminal_state != right_core->raw_terminal_state ||
      !same_state_sequence(left_core->continuations,
                           right_core->continuations) ||
      !same_state_sequence(left_core->predecision_projections,
                           right_core->predecision_projections) ||
      !same_state_sequence(left_core->completed_projections,
                           right_core->completed_projections) ||
      left_core->edges.size() != right_core->edges.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < left_core->edges.size(); ++index) {
    if (!same_completed_edge_word_value(left_core->edges[index],
                                        right_core->edges[index])) {
      return false;
    }
  }
  return true;
}

}  // namespace

Result<ResidenceCursor> begin_residence(const AuditedRomrView& view,
                                        const ReducedStateV1& state) {
  try {
    auto handle = mint_romr_handle(view);
    if (!handle) {
      return Result<ResidenceCursor>::failure(handle.error());
    }
    const auto ops = detail::C20CoreAccess::handle_core(handle.value());
    auto valid = validate_entry_state(*ops, state);
    if (!valid) {
      return Result<ResidenceCursor>::failure(valid.error());
    }
    auto initializer_input = quotient_callback_state(*ops, state);
    if (!initializer_input) {
      return Result<ResidenceCursor>::failure(initializer_input.error());
    }
    auto callback_initialized =
        invoke_initializer(*ops, initializer_input.value());
    if (!callback_initialized) {
      return Result<ResidenceCursor>::failure(callback_initialized.error());
    }
    auto initialized = lift_quotient_callback_state(
        *ops, state, callback_initialized.value());
    if (!initialized) {
      return Result<ResidenceCursor>::failure(initialized.error());
    }
    if (!(initialized.value().codec == ops->state_codec)) {
      return c20_invalid<ResidenceCursor>(
          "c20.initializer_codec_mismatch",
          "the sealed residence initializer returned a value outside the "
          "exact continuation codec");
    }
    auto initialized_domain =
        ops->exact_schema.validate_domain(initialized.value());
    if (!initialized_domain) {
      return Result<ResidenceCursor>::failure(initialized_domain.error());
    }
    auto before = ops->exact_schema.decode(state);
    auto after = ops->exact_schema.decode(initialized.value());
    if (!before) {
      return Result<ResidenceCursor>::failure(before.error());
    }
    if (!after) {
      return Result<ResidenceCursor>::failure(after.error());
    }
    if (!same_coordinates_across_reset(
            before.value(), after.value(),
            ops->residence_local_reset_fields)) {
      return c20_invalid<ResidenceCursor>(
          "c20.initializer_reset_exact_coordinate",
          "the residence initializer changed a queue, predictive arrival "
          "phase, controller, resource, boundary, margin, or unclassified "
          "surrogate-owned coordinate");
    }
    auto residence = residence_identity(*ops, state);
    if (!residence) {
      return Result<ResidenceCursor>::failure(residence.error());
    }
    auto branch = branch_identity(residence.value(), nullptr, std::nullopt);
    if (!branch) {
      return Result<ResidenceCursor>::failure(branch.error());
    }
    auto token =
        std::make_shared<const temporal::detail::CursorIdentityToken>(
            temporal::detail::CursorIdentityToken{
                ops->seal, residence.value(), branch.value()});
    auto core = std::make_unique<CursorCore>(CursorCore{
        std::move(handle).value(),
        ResidenceLifecycleV1::open,
        std::move(token),
        state,
        initialized.value(),
        initialized.value(),
        BigNat(0U),
        BigNat(0U),
        BigNat(0U),
        std::nullopt,
        std::nullopt,
        {},
        {initialized.value()},
        {},
        {},
        std::nullopt,
        std::nullopt});
    return Result<ResidenceCursor>::success(
        ResidenceCursor(std::move(core)));
  } catch (const std::bad_alloc&) {
    return c20_resource<ResidenceCursor>(
        "c20.allocation_failure",
        "allocating a residence cursor exceeded available memory");
  } catch (const std::exception&) {
    return c20_failure<ResidenceCursor>(
        DiagnosticCategory::internal, "c20.begin_residence_exception",
        "the residence initializer raised an unexpected exception");
  }
}

}  // namespace mwperf

namespace mwperf {
namespace {

class AdvanceAddressGuard final {
 public:
  explicit AdvanceAddressGuard(RngBank& bank) : bank_(&bank), bound_(false) {}
  AdvanceAddressGuard(const AdvanceAddressGuard&) = delete;
  AdvanceAddressGuard& operator=(const AdvanceAddressGuard&) = delete;
  ~AdvanceAddressGuard() {
    if (bound_) {
      detail::C20RngAccess::clear_advance_address(*bank_);
    }
  }
  void mark_bound() noexcept { bound_ = true; }

 private:
  RngBank* bank_;
  bool bound_;
};

}  // namespace

Result<ResidenceStep> advance_residence(
    ResidenceCursor& cursor, const AuditedSlotExecutor& executor,
    RngBank& rng_bank) {
  try {
    CursorCore& state = *cursor.core_;
    if (state.lifecycle != ResidenceLifecycleV1::open) {
      return c20_invalid<ResidenceStep>(
          "c20.cursor_not_open",
          "advance_residence requires an open cursor whose prior edge has "
          "already received its stop decision");
    }
    const auto ops = detail::C20CoreAccess::handle_core(state.ops);
    const auto executor_core = detail::C20CoreAccess::core(executor);
    if (!executor_core ||
        executor_core->execution_seal_digest() != ops->view_fingerprint ||
        executor_core->consumer_seal_identity() != state.identity->seal) {
      return c20_invalid<ResidenceStep>(
          "c20.executor_binding_mismatch",
          "the slot executor and residence cursor do not share the same C17 "
          "seal, state schema, arrival law, and timing convention");
    }

    AdvanceAddressGuard guard(rng_bank);
    auto address = detail::C20RngAccess::bind_advance_address(
        rng_bank, state.identity->branch_identity,
        state.residence_stream_index, state.offset);
    if (!address) {
      return Result<ResidenceStep>::failure(address.error());
    }
    guard.mark_bound();

    const Digest256& bank_root =
        detail::C20RngAccess::temporal_root_fingerprint(rng_bank);
    if ((state.temporal_bank_root.has_value() &&
         *state.temporal_bank_root != bank_root) ||
        (state.temporal_bank_seed.has_value() &&
         *state.temporal_bank_seed != rng_bank.seed())) {
      return c20_invalid<ResidenceStep>(
          "c20.cursor_rng_binding_mismatch",
          "an unfinished residence can advance only with the same temporal "
          "path root and master seed that produced its revealed prefix");
    }

    // x^- is frozen before C17 can reveal the current opportunity/arrival.
    auto predecision = prepare_predecision_projection(state);
    if (!predecision) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceStep>::failure(predecision.error());
    }

    // F-C17-08 is the sole owner of the five-stage realized slot.  There is
    // exactly one invocation and no retry/fallback on any error.
    auto edge = execute_reduced_slot(executor, state.current_state, rng_bank);
    if (!edge) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceStep>::failure(edge.error());
    }
    if (!state.temporal_bank_root.has_value()) {
      state.temporal_bank_root = bank_root;
      state.temporal_bank_seed = rng_bank.seed();
    }
    auto appended = append_completed_edge(
        state, std::move(edge).value(), std::move(predecision).value());
    if (!appended) {
      state.lifecycle = ResidenceLifecycleV1::failed;
    }
    return appended;
  } catch (const std::bad_alloc&) {
    cursor.core_->lifecycle = ResidenceLifecycleV1::failed;
    return c20_resource<ResidenceStep>(
        "c20.allocation_failure",
        "recording a realized residence edge exceeded available memory");
  } catch (const std::exception&) {
    cursor.core_->lifecycle = ResidenceLifecycleV1::failed;
    return c20_failure<ResidenceStep>(
        DiagnosticCategory::internal, "c20.advance_residence_exception",
        "the atomic residence advance raised an unexpected exception");
  }
}

Result<StopDecision> validate_residence_stop(ResidenceCursor& cursor,
                                             const ResidenceStep& step) {
  try {
    CursorCore& state = *cursor.core_;
    if (state.lifecycle !=
            ResidenceLifecycleV1::step_pending_validation ||
        !state.pending.has_value()) {
      return c20_invalid<StopDecision>(
          "c20.cursor_not_pending_stop_validation",
          "a stop decision is valid only for the cursor's unvalidated last "
          "completed edge");
    }
    const auto step_core = detail::C20CoreAccess::step_core(step);
    if (!step_core || !same_binding(*state.pending, step_core->binding) ||
        !(state.edges.back() == step_core->edge)) {
      return c20_invalid<StopDecision>(
          "c20.step_binding_mismatch",
          "the ResidenceStep belongs to another seal, cursor, branch, "
          "version, offset, or completed edge");
    }
    if (state.offset.is_zero()) {
      return c20_invalid<StopDecision>(
          "c20.time_zero_stop",
          "a ROMR stopping decision requires at least one completed edge");
    }
    const auto ops = detail::C20CoreAccess::handle_core(state.ops);
    auto stop_input = quotient_callback_state(*ops, state.raw_continuation);
    if (!stop_input) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<StopDecision>::failure(stop_input.error());
    }
    auto raw = invoke_stop(*ops, stop_input.value());
    if (!raw) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<StopDecision>::failure(raw.error());
    }
    if (!(raw.value().codec == ops->indicator_codec)) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<StopDecision>(
          "c20.stop_indicator_codec_mismatch",
          "the adapted stopping operation returned a foreign indicator "
          "codec");
    }
    const bool is_false =
        raw.value().canonical_value == ops->stopping_false_value;
    const bool is_true =
        raw.value().canonical_value == ops->stopping_true_value;
    if (is_false == is_true) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<StopDecision>(
          "c20.noncanonical_stop_indicator",
          "the stopping operation returned neither of its two sealed "
          "canonical Boolean encodings");
    }
    if (ops->unit_residence && (!is_true || state.edges.size() != 1U)) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<StopDecision>(
          "c20.invalid_unit_residence_stop",
          "the canonical unit residence must stop after exactly its first "
          "completed edge");
    }
    if (!is_true && ops->maximum_residence_slots.has_value() &&
        state.edges.size() >= *ops->maximum_residence_slots) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<StopDecision>(
          "c20.declared_max_residence_exceeded",
          "the stopping rule continued at its sealed maximum residence "
          "length");
    }

    const StopDispositionV1 disposition =
        is_true ? StopDispositionV1::stop_residence
                : StopDispositionV1::continue_residence;
    auto decision_core =
        std::make_shared<const temporal::detail::StopDecisionCore>(
            temporal::detail::StopDecisionCore{disposition, *state.pending});
    if (is_true) {
      state.validated_stop = *state.pending;
      state.lifecycle = ResidenceLifecycleV1::stopped;
    } else {
      state.validated_stop.reset();
      state.lifecycle = ResidenceLifecycleV1::open;
    }
    state.pending.reset();
    return Result<StopDecision>::success(
        detail::C20CoreAccess::decision(std::move(decision_core)));
  } catch (const std::bad_alloc&) {
    cursor.core_->lifecycle = ResidenceLifecycleV1::failed;
    return c20_resource<StopDecision>(
        "c20.allocation_failure",
        "recording a residence stop decision exceeded available memory");
  } catch (const std::exception&) {
    cursor.core_->lifecycle = ResidenceLifecycleV1::failed;
    return c20_failure<StopDecision>(
        DiagnosticCategory::internal, "c20.stop_validation_exception",
        "the sealed stopping operation raised an unexpected exception");
  }
}

Result<ResidenceWord> finalize_residence_word(ResidenceCursor& cursor) {
  try {
    CursorCore& state = *cursor.core_;
    if (state.lifecycle == ResidenceLifecycleV1::finalized) {
      return c20_invalid<ResidenceWord>(
          "c20.cursor_already_finalized",
          "a stopped residence cursor can authorize finalization only once");
    }
    if (state.lifecycle != ResidenceLifecycleV1::stopped ||
        !state.validated_stop.has_value()) {
      return c20_invalid<ResidenceWord>(
          "c20.cursor_not_stopped",
          "finalize_residence_word requires a successful first-positive stop "
          "decision bound to the cursor's last edge");
    }
    if (state.edges.empty() ||
        state.validated_stop->cursor != state.identity ||
        state.validated_stop->output_version != state.version ||
        state.validated_stop->offset != state.offset) {
      return c20_invalid<ResidenceWord>(
          "c20.stop_binding_mismatch",
          "the recorded stop decision no longer matches the cursor's final "
          "edge, version, and offset");
    }
    auto final_edge_digest = completed_edge_digest(state.edges.back(), true);
    if (!final_edge_digest) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(final_edge_digest.error());
    }
    BigNat expected_output = state.validated_stop->input_version;
    ++expected_output;
    if (!(expected_output == state.validated_stop->output_version) ||
        state.validated_stop->edge_digest != final_edge_digest.value()) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<ResidenceWord>(
          "c20.stop_binding_mismatch",
          "the recorded stop no longer binds the final completed-edge digest "
          "and adjacent cursor versions");
    }
    auto replay = validate_word_replay(state);
    if (!replay) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(replay.error());
    }

    const auto ops = detail::C20CoreAccess::handle_core(state.ops);
    const CanonicalRuntimeValueV1 raw_terminal = state.raw_continuation;
    auto terminal_successor = quotient_callback_state(*ops,
                                                      state.current_state);
    auto terminal_raw = quotient_callback_state(*ops, raw_terminal);
    if (!terminal_successor) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(terminal_successor.error());
    }
    if (!terminal_raw) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(terminal_raw.error());
    }
    auto callback_terminal = invoke_terminal(
        *ops, EventTerminalReentryInputV1{terminal_successor.value(),
                                          terminal_raw.value()});
    if (!callback_terminal) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(callback_terminal.error());
    }
    auto terminal = lift_quotient_callback_state(
        *ops, raw_terminal, callback_terminal.value());
    if (!terminal) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(terminal.error());
    }
    if (!(terminal.value().codec == ops->state_codec)) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<ResidenceWord>(
          "c20.terminal_reentry_codec_mismatch",
          "the terminal map returned a value outside the sealed event-entry "
          "codec");
    }
    auto terminal_schema =
        ops->exact_schema.validate_domain(terminal.value());
    if (!terminal_schema) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(terminal_schema.error());
    }

    // First audit the provider/framework terminal map against the complete
    // raw physical coordinates.  The finite event quotient, when sealed,
    // happens only after this strict check and therefore cannot disguise a
    // terminal callback that reset physical time or predictive state.
    auto raw_exact = ops->exact_schema.decode(state.current_state);
    auto terminal_exact = ops->exact_schema.decode(terminal.value());
    if (!raw_exact) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(raw_exact.error());
    }
    if (!terminal_exact) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(terminal_exact.error());
    }
    if (!same_coordinates_across_reset(
            raw_exact.value(), terminal_exact.value(),
            ops->residence_local_reset_fields)) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<ResidenceWord>(
          "c20.terminal_reset_exact_coordinate",
          "the terminal map changed a predictive arrival phase, controller, "
          "queue, resource, physical boundary, margin, or unclassified "
          "surrogate-owned coordinate");
    }

    if (ops->event_clock_semantics ==
        EventClockSemanticsV1::finite_phase_time_homogeneous_quotient) {
      // Validate that the clockful endpoint has a unique finite quotient
      // representative, but never substitute that representative into the
      // physical word.  The actual projection is used only by F-C20-05.
      auto representative =
          project_event_clock_quotient(*ops, terminal.value());
      if (!representative) {
        state.lifecycle = ResidenceLifecycleV1::failed;
        return Result<ResidenceWord>::failure(representative.error());
      }
    } else {
      auto endpoint_domain = validate_entry_state(*ops, terminal.value());
      if (!endpoint_domain) {
        state.lifecycle = ResidenceLifecycleV1::failed;
        return c20_invalid<ResidenceWord>(
            "c20.endpoint_outside_event_domain",
            "the positive residence endpoint lies outside the sealed event "
            "entry domain");
      }
    }
    auto reinitializer_input = quotient_callback_state(*ops,
                                                       terminal.value());
    if (!reinitializer_input) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(reinitializer_input.error());
    }
    auto callback_reinitialized =
        invoke_initializer(*ops, reinitializer_input.value());
    if (!callback_reinitialized) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(callback_reinitialized.error());
    }
    auto reinitialized = lift_quotient_callback_state(
        *ops, terminal.value(), callback_reinitialized.value());
    if (!reinitialized) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(reinitialized.error());
    }
    if (!(reinitialized.value().codec == ops->state_codec)) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<ResidenceWord>(
          "c20.reinitializer_codec_mismatch",
          "the next residence initializer returned a foreign continuation "
          "codec");
    }
    auto reinitialized_domain =
        ops->exact_schema.validate_domain(reinitialized.value());
    if (!reinitialized_domain) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(reinitialized_domain.error());
    }
    auto endpoint_exact = ops->exact_schema.decode(terminal.value());
    auto reset_exact = ops->exact_schema.decode(reinitialized.value());
    if (!endpoint_exact) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(endpoint_exact.error());
    }
    if (!reset_exact) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(reset_exact.error());
    }
    if (!same_coordinates_across_reset(
            endpoint_exact.value(), reset_exact.value(),
            ops->residence_local_reset_fields)) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return c20_invalid<ResidenceWord>(
          "c20.terminal_reset_exact_coordinate",
          "residence reinitialization changed a predictive arrival phase, "
          "controller, queue, resource, physical boundary, margin, or "
          "unclassified surrogate-owned coordinate");
    }

    std::vector<CanonicalRuntimeValueV1> continuations =
        state.continuations;
    continuations.back() = reinitialized.value();
    auto digest = residence_word_digest(
        ops->identity, ops->view_fingerprint, state.event_entry,
        terminal.value(), raw_terminal, continuations, state.edges,
        state.predecision_projections,
        state.completed_projections);
    if (!digest) {
      state.lifecycle = ResidenceLifecycleV1::failed;
      return Result<ResidenceWord>::failure(digest.error());
    }
    auto word_core = std::make_shared<const temporal::detail::ResidenceWordCore>(
        temporal::detail::ResidenceWordCore{
            BigNat(static_cast<std::uint64_t>(state.edges.size())),
            state.event_entry,
            terminal.value(),
            raw_terminal,
            std::move(continuations),
            state.edges,
            state.predecision_projections,
            state.completed_projections,
            std::move(digest).value(),
            ops->view_fingerprint});
    state.lifecycle = ResidenceLifecycleV1::finalized;
    return Result<ResidenceWord>::success(
        detail::C20CoreAccess::word(std::move(word_core)));
  } catch (const std::bad_alloc&) {
    cursor.core_->lifecycle = ResidenceLifecycleV1::failed;
    return c20_resource<ResidenceWord>(
        "c20.allocation_failure",
        "sealing a complete residence word exceeded available memory");
  } catch (const std::exception&) {
    cursor.core_->lifecycle = ResidenceLifecycleV1::failed;
    return c20_failure<ResidenceWord>(
        DiagnosticCategory::internal, "c20.finalize_residence_exception",
        "residence word validation raised an unexpected exception");
  }
}

}  // namespace mwperf

namespace mwperf {
namespace {

struct FrontierBranch final {
  ResidenceCursor cursor;
  ExactRational mass;
};

[[nodiscard]] Result<void> add_or_merge_word(
    std::vector<std::pair<ResidenceWord, ExactRational>>& words,
    ResidenceWord word, const ExactRational& mass,
    const PmfRepresentationBudget& budget) {
  for (auto& [existing, existing_mass] : words) {
    if (same_word_value(existing, word)) {
      auto combined = add_probability_mass(
          existing_mass, mass, budget, "duplicate-word mass merge");
      if (!combined) {
        return Result<void>::failure(combined.error());
      }
      existing_mass = std::move(combined).value();
      return Result<void>::success();
    }
  }
  words.emplace_back(std::move(word), mass);
  return Result<void>::success();
}

[[nodiscard]] Result<Digest256> initial_law_digest(
    const ReducedInitialLaw& law, const Digest256& framework_fingerprint) {
  CanonicalEncoder encoder;
  encoder.u32(1U);
  encoder.digest(framework_fingerprint);
  encoder.codec(law.state_codec());
  encoder.digest(law.exact_state_schema_digest());
  encoder.digest(law.reduced_state_schema_digest());
  encoder.digest(law.selection_digest());
  encoder.u64(static_cast<std::uint64_t>(law.atoms().size()));
  for (std::size_t index = 0U; index < law.atoms().size(); ++index) {
    encoder.u64(static_cast<std::uint64_t>(index));
    encoder.runtime_value(law.atoms()[index].state);
    encoder.rational(law.atoms()[index].mass.exact_value());
    encoder.octet(law.atoms()[index].mass.structural_support() ? 1U : 0U);
  }
  return finish_digest("mwperf.c20.reduced-initial-law.v1", encoder);
}

}  // namespace

Result<FiniteEventStateDomain>
FiniteEventStateDomain::from_audited_provider(
    const AuditedResidenceProvider& provider) {
  try {
    auto view = audited_romr_view(provider);
    if (!view) {
      return Result<FiniteEventStateDomain>::failure(view.error());
    }
    auto handle = mint_romr_handle(view.value());
    if (!handle) {
      return Result<FiniteEventStateDomain>::failure(handle.error());
    }
    const auto ops = detail::C20CoreAccess::handle_core(handle.value());
    std::vector<ReducedStateV1> states;
    if (ops->finite_event_domain_states.has_value()) {
      states = *ops->finite_event_domain_states;
    } else {
      return c20_unavailable<FiniteEventStateDomain>(
          "c20.finite_event_domain_unavailable",
          "the provider declares a countable/procedural event-entry domain, "
          "not an indexed finite domain");
    }
    if (states.empty()) {
      return c20_invalid<FiniteEventStateDomain>(
          "c20.empty_event_domain",
          "a finite embedded event kernel requires at least one indexed "
          "event-entry state");
    }
    for (std::size_t index = 0U; index < states.size(); ++index) {
      auto valid = ops->exact_schema.validate_domain(states[index]);
      if (!valid || !(states[index].codec == ops->state_codec)) {
        return c20_invalid<FiniteEventStateDomain>(
            "c20.invalid_event_domain_state",
            "a finite event-domain member fails the sealed exact-state "
            "schema/domain validator");
      }
      if (std::find(states.begin(), states.begin() + index, states[index]) !=
          states.begin() + index) {
        return c20_invalid<FiniteEventStateDomain>(
            "c20.duplicate_event_domain_state",
            "the finite event domain contains a duplicate indexed state");
      }
    }
    auto content = event_domain_content_digest(*ops, states);
    auto fingerprint = event_domain_fingerprint(*ops, states);
    if (!content) {
      return Result<FiniteEventStateDomain>::failure(content.error());
    }
    if (!fingerprint) {
      return Result<FiniteEventStateDomain>::failure(fingerprint.error());
    }
    auto core =
        std::make_shared<const temporal::detail::FiniteEventStateDomainCore>(
            temporal::detail::FiniteEventStateDomainCore{
                std::move(states),
                std::move(fingerprint).value(),
                std::move(content).value(),
                ops->identity,
                ops->state_codec,
                ops->exact_state_schema_digest,
                ops->reduced_state_schema_digest,
                ops->seal});
    return Result<FiniteEventStateDomain>::success(
        detail::C20CoreAccess::domain(std::move(core)));
  } catch (const std::bad_alloc&) {
    return c20_resource<FiniteEventStateDomain>(
        "c20.allocation_failure",
        "materializing the finite event domain exceeded available memory");
  } catch (const std::exception&) {
    return c20_failure<FiniteEventStateDomain>(
        DiagnosticCategory::internal, "c20.event_domain_exception",
        "finite event-domain validation raised an unexpected exception");
  }
}

Result<ResidenceWordRow> enumerate_residence_word_row(
    const AuditedResidenceProvider& provider, const ReducedStateV1& state,
    PmfRepresentationBudget representation_budget) {
  try {
    const auto provider_core = detail::C20CoreAccess::core(provider);
    if (!provider_core || !provider_core->report().passed() ||
        !provider_core->row_available()) {
      return c20_unavailable<ResidenceWordRow>(
          "c20.enumerable_residence_unavailable",
          "exact residence-word enumeration requires the provider's audited "
          "enumerable C17 row capability");
    }
    const PmfRepresentationBudget& frozen =
        provider_core->inputs().causal_program.representation_budget;
    if (!(representation_budget == frozen)) {
      return c20_invalid<ResidenceWordRow>(
          "c20.representation_budget_mismatch",
          "F-C20-07 must receive the exact representation budget frozen in "
          "the audited residence provider");
    }
    auto view = audited_romr_view(provider);
    auto rows = audited_row_provider(provider);
    if (!view) {
      return Result<ResidenceWordRow>::failure(view.error());
    }
    if (!rows) {
      return Result<ResidenceWordRow>::failure(rows.error());
    }
    auto handle = mint_romr_handle(view.value());
    if (!handle) {
      return Result<ResidenceWordRow>::failure(handle.error());
    }
    const auto ops = detail::C20CoreAccess::handle_core(handle.value());
    if (!ops->maximum_residence_slots.has_value() ||
        *ops->maximum_residence_slots == 0U) {
      return c20_unavailable<ResidenceWordRow>(
          "c20.finite_residence_support_uncertified",
          "this v1 enumerator requires a sealed positive finite residence "
          "bound; a runtime budget is not a termination proof");
    }
    auto initial = begin_residence(view.value(), state);
    if (!initial) {
      return Result<ResidenceWordRow>::failure(initial.error());
    }

    std::vector<FrontierBranch> frontier;
    frontier.push_back(
        FrontierBranch{std::move(initial).value(), ExactRational::one()});
    std::vector<std::pair<ResidenceWord, ExactRational>> complete;

    for (std::size_t depth = 0U;
         depth < *ops->maximum_residence_slots && !frontier.empty(); ++depth) {
      std::vector<FrontierBranch> next;
      for (FrontierBranch& source : frontier) {
        auto predecision =
            prepare_predecision_projection(
                detail::C20CoreAccess::cursor_core(source.cursor));
        if (!predecision) {
          return Result<ResidenceWordRow>::failure(predecision.error());
        }
        // F-C17-06 is invoked once for this source prefix.  No RngBank exists
        // in this function, and no sampled route is available as fallback.
        auto row = compile_reduced_kernel_row(
            rows.value(), source.cursor.current_state());
        if (!row) {
          return Result<ResidenceWordRow>::failure(row.error());
        }
        if (!(row.value().exact_total_mass() == ExactRational::one())) {
          return c20_invalid<ResidenceWordRow>(
              "c20.incomplete_slot_row",
              "C17 returned a row whose exact total mass is not one");
        }
        const auto atoms = row.value().atoms();
        for (std::size_t atom_index = 0U; atom_index < atoms.size();
             ++atom_index) {
          const MarkedKernelRowAtomV1& atom = atoms[atom_index];
          if (atom.exact_mass.is_zero()) {
            if (atom.structural_support) {
              return c20_invalid<ResidenceWordRow>(
                  "c20.zero_mass_structural_branch",
                  "an exact-zero row atom cannot claim structural support");
            }
            continue;
          }
          auto branch_mass = multiply_probability_mass(
              source.mass, atom.exact_mass, representation_budget);
          if (!branch_mass) {
            return Result<ResidenceWordRow>::failure(branch_mass.error());
          }
          ResidenceCursor branch(source.cursor);
          auto rebound = rebind_enumerated_branch(
              detail::C20CoreAccess::cursor_core(branch), atom_index);
          if (!rebound) {
            return Result<ResidenceWordRow>::failure(rebound.error());
          }
          auto step = append_completed_edge(
              detail::C20CoreAccess::cursor_core(branch), atom.edge,
              predecision.value());
          if (!step) {
            return Result<ResidenceWordRow>::failure(step.error());
          }
          auto decision = validate_residence_stop(branch, step.value());
          if (!decision) {
            return Result<ResidenceWordRow>::failure(decision.error());
          }
          if (decision.value().stops()) {
            auto word = finalize_residence_word(branch);
            if (!word) {
              return Result<ResidenceWordRow>::failure(word.error());
            }
            auto merged = add_or_merge_word(
                complete, std::move(word).value(), branch_mass.value(),
                representation_budget);
            if (!merged) {
              return Result<ResidenceWordRow>::failure(merged.error());
            }
          } else {
            next.push_back(
                FrontierBranch{std::move(branch),
                               std::move(branch_mass).value()});
          }
        }
      }
      frontier = std::move(next);
    }
    if (!frontier.empty()) {
      return c20_invalid<ResidenceWordRow>(
          "c20.incomplete_residence_support",
          "the enumerable residence frontier remains positive at the sealed "
          "maximum; no partial row was normalized or emitted");
    }

    std::stable_sort(complete.begin(), complete.end(),
                     [](const auto& left, const auto& right) {
                       return left.first.word_digest() <
                              right.first.word_digest();
                     });
    ExactRational total = ExactRational::zero();
    std::vector<ResidenceWordRowAtomV1> atoms;
    atoms.reserve(complete.size());
    for (auto& [word, mass] : complete) {
      auto cumulative = add_probability_mass(
          total, mass, representation_budget, "word-row cumulative mass");
      if (!cumulative) {
        return Result<ResidenceWordRow>::failure(cumulative.error());
      }
      total = std::move(cumulative).value();
      atoms.push_back(ResidenceWordRowAtomV1{
          std::move(word), mass, true, mass.to_long_double(),
          numerical_status(mass), total});
    }
    if (!(total == ExactRational::one())) {
      return c20_invalid<ResidenceWordRow>(
          "c20.incomplete_residence_mass",
          "the complete residence-word row does not have exact unit mass; it "
          "was not normalized");
    }
    const CompensatedNumericalRowImageV1 numerical_row_image =
        compensated_numerical_image(atoms);
    auto core = std::make_shared<const temporal::detail::ResidenceWordRowCore>(
        temporal::detail::ResidenceWordRowCore{
            state, std::move(atoms), total, numerical_row_image,
            representation_budget, ops->identity});
    return Result<ResidenceWordRow>::success(
        detail::C20CoreAccess::word_row(std::move(core)));
  } catch (const std::bad_alloc&) {
    return c20_resource<ResidenceWordRow>(
        "c20.allocation_failure",
        "enumerating a residence word row exceeded available memory");
  } catch (const std::exception&) {
    return c20_failure<ResidenceWordRow>(
        DiagnosticCategory::internal, "c20.enumeration_exception",
        "exact residence frontier enumeration raised an unexpected "
        "exception");
  }
}

}  // namespace mwperf

namespace mwperf {

Result<EmbeddedKernel> assemble_embedded_event_kernel(
    const FiniteEventStateDomain& domain,
    const AuditedResidenceProvider& provider) {
  try {
    const auto provider_core = detail::C20CoreAccess::core(provider);
    const auto domain_core = detail::C20CoreAccess::domain_core(domain);
    if (!provider_core || !domain_core || !provider_core->report().passed() ||
        !provider_core->row_available()) {
      return c20_unavailable<EmbeddedKernel>(
          "c20.embedded_kernel_access_unavailable",
          "exact embedded-kernel assembly requires one live enumerable "
          "residence provider and finite event domain");
    }
    auto view = audited_romr_view(provider);
    if (!view) {
      return Result<EmbeddedKernel>::failure(view.error());
    }
    auto handle = mint_romr_handle(view.value());
    if (!handle) {
      return Result<EmbeddedKernel>::failure(handle.error());
    }
    const auto ops = detail::C20CoreAccess::handle_core(handle.value());
    std::vector<ReducedStateV1> expected_states;
    if (ops->finite_event_domain_states.has_value()) {
      expected_states = *ops->finite_event_domain_states;
    }
    auto expected_content = event_domain_content_digest(*ops, expected_states);
    auto expected_fingerprint =
        event_domain_fingerprint(*ops, expected_states);
    if (!expected_content || !expected_fingerprint) {
      return c20_failure<EmbeddedKernel>(
          DiagnosticCategory::internal,
          "c20.event_domain_digest_failure",
          "the sealed event-domain identity could not be recomputed");
    }
    if (expected_states.empty() || domain_core->seal != ops->seal ||
        domain_core->provider_fingerprint != ops->identity ||
        !(domain_core->state_codec == ops->state_codec) ||
        domain_core->exact_state_schema_digest !=
            ops->exact_state_schema_digest ||
        domain_core->reduced_state_schema_digest !=
            ops->reduced_state_schema_digest ||
        domain_core->states != expected_states ||
        domain_core->content_digest != expected_content.value() ||
        domain_core->fingerprint != expected_fingerprint.value()) {
      return c20_invalid<EmbeddedKernel>(
          "c20.event_domain_mismatch",
          "the finite event domain is a subset, superset, reordered, foreign, "
          "or otherwise not the exact domain sealed by this provider");
    }

    const PmfRepresentationBudget frozen_budget =
        provider_core->inputs().causal_program.representation_budget;
    std::vector<EmbeddedKernelRowV1> kernel_rows;
    kernel_rows.reserve(domain_core->states.size());
    for (const ReducedStateV1& entry : domain_core->states) {
      auto word_row =
          enumerate_residence_word_row(provider, entry, frozen_budget);
      if (!word_row) {
        return Result<EmbeddedKernel>::failure(word_row.error());
      }
      if (!(word_row.value().exact_total_mass() == ExactRational::one())) {
        return c20_invalid<EmbeddedKernel>(
            "c20.incomplete_embedded_row",
            "an embedded row may be pushed forward only from a complete exact "
            "unit-mass residence-word law");
      }
      std::vector<ExactRational> endpoint_mass(
          domain_core->states.size(), ExactRational::zero());
      for (const ResidenceWordRowAtomV1& atom : word_row.value().atoms()) {
        if (atom.exact_mass.is_zero()) {
          continue;
        }
        ReducedStateV1 event_index_state = atom.word.event_endpoint();
        if (ops->event_clock_semantics ==
            EventClockSemanticsV1::
                finite_phase_time_homogeneous_quotient) {
          auto projected = project_event_clock_quotient(
              *ops, atom.word.event_endpoint());
          if (!projected) {
            return Result<EmbeddedKernel>::failure(projected.error());
          }
          event_index_state = std::move(projected).value();
        }
        const auto endpoint = domain.index_of(event_index_state);
        if (!endpoint.has_value()) {
          return c20_invalid<EmbeddedKernel>(
              "c20.endpoint_outside_event_domain",
              "positive residence-word mass exits the finite event domain; "
              "no reflection, cemetery state, or normalization is allowed");
        }
        auto merged = add_probability_mass(
            endpoint_mass[*endpoint], atom.exact_mass, frozen_budget,
            "embedded endpoint mass merge");
        if (!merged) {
          return Result<EmbeddedKernel>::failure(merged.error());
        }
        endpoint_mass[*endpoint] = std::move(merged).value();
      }
      ExactRational total = ExactRational::zero();
      std::vector<EmbeddedKernelAtomV1> endpoint_atoms;
      for (std::size_t endpoint = 0U; endpoint < endpoint_mass.size();
           ++endpoint) {
        if (endpoint_mass[endpoint].is_zero()) {
          continue;
        }
        auto cumulative = add_probability_mass(
            total, endpoint_mass[endpoint], frozen_budget,
            "embedded-row cumulative mass");
        if (!cumulative) {
          return Result<EmbeddedKernel>::failure(cumulative.error());
        }
        total = std::move(cumulative).value();
        endpoint_atoms.push_back(EmbeddedKernelAtomV1{
            endpoint, endpoint_mass[endpoint],
            endpoint_mass[endpoint].to_long_double(),
            numerical_status(endpoint_mass[endpoint])});
      }
      if (!(total == ExactRational::one())) {
        return c20_invalid<EmbeddedKernel>(
            "c20.incomplete_embedded_row",
            "the endpoint pushforward has missing or excess exact mass; it "
            "was not normalized");
      }
      const CompensatedNumericalRowImageV1 numerical_row_image =
          compensated_numerical_image(endpoint_atoms);
      kernel_rows.push_back(EmbeddedKernelRowV1{
          std::move(word_row).value(), std::move(endpoint_atoms), total,
          numerical_row_image});
    }

    CanonicalEncoder encoder;
    encoder.u32(1U);
    encoder.digest(domain_core->fingerprint);
    encoder.u64(static_cast<std::uint64_t>(kernel_rows.size()));
    for (const EmbeddedKernelRowV1& row : kernel_rows) {
      encoder.runtime_value(row.word_row.entry_state());
      encoder.u64(static_cast<std::uint64_t>(row.word_row.atoms().size()));
      for (const ResidenceWordRowAtomV1& atom : row.word_row.atoms()) {
        encoder.digest(atom.word.word_digest());
        encoder.rational(atom.exact_mass);
      }
      encoder.u64(static_cast<std::uint64_t>(row.endpoint_atoms.size()));
      for (const EmbeddedKernelAtomV1& atom : row.endpoint_atoms) {
        encoder.u64(static_cast<std::uint64_t>(atom.endpoint_index));
        encoder.rational(atom.exact_mass);
      }
    }
    auto fingerprint =
        finish_digest("mwperf.c20.embedded-event-kernel.v1", encoder);
    if (!fingerprint) {
      return Result<EmbeddedKernel>::failure(fingerprint.error());
    }
    auto core = std::make_shared<const temporal::detail::EmbeddedKernelCore>(
        temporal::detail::EmbeddedKernelCore{
            domain, std::move(kernel_rows),
            std::move(fingerprint).value(), provider_core, ops});
    return Result<EmbeddedKernel>::success(
        detail::C20CoreAccess::embedded_kernel(std::move(core)));
  } catch (const std::bad_alloc&) {
    return c20_resource<EmbeddedKernel>(
        "c20.allocation_failure",
        "assembling the exact embedded event kernel exceeded available "
        "memory");
  } catch (const std::exception&) {
    return c20_failure<EmbeddedKernel>(
        DiagnosticCategory::internal, "c20.embedded_kernel_exception",
        "embedded event-kernel assembly raised an unexpected exception");
  }
}

}  // namespace mwperf

namespace mwperf::temporal::detail {

Result<C20StationaryKernelBindingV1> c20_stationary_kernel_binding(
    const EmbeddedKernel& kernel) {
  try {
    const auto& kernel_core =
        ::mwperf::detail::C20CoreAccess::embedded_kernel_core(kernel);
    if (!kernel_core || !kernel_core->source_framework ||
        !kernel_core->romr_ops) {
      return c20_invalid<C20StationaryKernelBindingV1>(
          "c20.stationary_kernel_source_missing",
          "the embedded kernel does not retain its originating sealed "
          "framework and ROMR identities");
    }
    const auto& domain_core =
        ::mwperf::detail::C20CoreAccess::domain_core(kernel_core->domain);
    if (!domain_core || domain_core->states.empty() ||
        domain_core->seal != kernel_core->romr_ops->seal ||
        domain_core->provider_fingerprint !=
            kernel_core->romr_ops->identity ||
        domain_core->fingerprint != kernel_core->domain.fingerprint() ||
        !(domain_core->state_codec == kernel_core->romr_ops->state_codec) ||
        domain_core->exact_state_schema_digest !=
            kernel_core->romr_ops->exact_state_schema_digest ||
        domain_core->reduced_state_schema_digest !=
            kernel_core->romr_ops->reduced_state_schema_digest) {
      return c20_invalid<C20StationaryKernelBindingV1>(
          "c20.stationary_kernel_domain_binding_mismatch",
          "the embedded kernel's finite event domain no longer matches its "
          "originating ROMR seal");
    }
    auto source = c20_make_stationary_source_binding(
        kernel_core->source_framework, kernel_core->romr_ops);
    if (!source) {
      return Result<C20StationaryKernelBindingV1>::failure(source.error());
    }
    return Result<C20StationaryKernelBindingV1>::success(
        C20StationaryKernelBindingV1{
            std::move(source).value(), domain_core->fingerprint,
            domain_core->content_digest, kernel_core->fingerprint});
  } catch (const std::bad_alloc&) {
    return c20_resource<C20StationaryKernelBindingV1>(
        "c20.stationary_binding_allocation_failure",
        "copying the immutable stationary kernel binding exhausted memory");
  } catch (const std::exception&) {
    return c20_failure<C20StationaryKernelBindingV1>(
        DiagnosticCategory::internal,
        "c20.stationary_kernel_binding_exception",
        "reading the embedded kernel's stationary binding raised an "
        "unexpected exception");
  }
}

Result<C20StationarySourceBindingV1> c20_stationary_provider_binding(
    const AuditedResidenceProvider& provider) {
  try {
    const auto framework = ::mwperf::detail::C20CoreAccess::core(provider);
    auto view = audited_romr_view(provider);
    if (!view) {
      return Result<C20StationarySourceBindingV1>::failure(view.error());
    }
    auto handle = mint_romr_handle(view.value());
    if (!handle) {
      return Result<C20StationarySourceBindingV1>::failure(handle.error());
    }
    return c20_make_stationary_source_binding(
        framework,
        ::mwperf::detail::C20CoreAccess::handle_core(handle.value()));
  } catch (const std::bad_alloc&) {
    return c20_resource<C20StationarySourceBindingV1>(
        "c20.stationary_binding_allocation_failure",
        "copying the immutable stationary provider binding exhausted "
        "memory");
  } catch (const std::exception&) {
    return c20_failure<C20StationarySourceBindingV1>(
        DiagnosticCategory::internal,
        "c20.stationary_provider_binding_exception",
        "reading the residence provider's stationary binding raised an "
        "unexpected exception");
  }
}

Result<void> c20_require_stationary_kernel_provider_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider) {
  try {
    const auto& kernel_core =
        ::mwperf::detail::C20CoreAccess::embedded_kernel_core(kernel);
    const auto provider_core =
        ::mwperf::detail::C20CoreAccess::core(provider);
    // Shared ownership identity, not digest equality, is the authoritative
    // same-run check.  Independently minted equal-looking frameworks must be
    // rejected before any residence atom is visited.
    if (!kernel_core || !kernel_core->source_framework || !provider_core ||
        kernel_core->source_framework != provider_core) {
      return c20_invalid<void>(
          "c20.stationary_foreign_residence_provider",
          "the residence provider was not the exact sealed source that "
          "assembled this embedded kernel");
    }
    auto kernel_binding = c20_stationary_kernel_binding(kernel);
    if (!kernel_binding) {
      return Result<void>::failure(kernel_binding.error());
    }
    auto provider_binding = c20_stationary_provider_binding(provider);
    if (!provider_binding) {
      return Result<void>::failure(provider_binding.error());
    }
    const C20StationarySourceBindingV1& left =
        kernel_binding.value().source;
    const C20StationarySourceBindingV1& right = provider_binding.value();
    if (left.seal_token != right.seal_token ||
        left.provider_romr_identity != right.provider_romr_identity ||
        left.execution_seal_identity != right.execution_seal_identity ||
        left.descriptor_identity != right.descriptor_identity ||
        left.accepted_contract_identity != right.accepted_contract_identity ||
        left.selection_identity != right.selection_identity ||
        left.configured_arrival_identity !=
            right.configured_arrival_identity ||
        left.configured_arrival_law_identity !=
            right.configured_arrival_law_identity ||
        left.exact_state_schema_identity !=
            right.exact_state_schema_identity ||
        left.reduced_state_schema_identity !=
            right.reduced_state_schema_identity ||
        left.timing_identity != right.timing_identity ||
        left.continuation_schema_identity !=
            right.continuation_schema_identity ||
        left.target_service_schema_identity !=
            right.target_service_schema_identity ||
        !(left.frozen_representation_budget ==
          right.frozen_representation_budget) ||
        left.event_clock_semantics != right.event_clock_semantics) {
      return c20_invalid<void>(
          "c20.stationary_source_binding_mismatch",
          "the kernel and provider disagree on a sealed stationary source "
          "identity, schema, timing, or representation bound");
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return c20_resource<void>(
        "c20.stationary_binding_allocation_failure",
        "validating the stationary kernel/provider binding exhausted "
        "memory");
  } catch (const std::exception&) {
    return c20_failure<void>(
        DiagnosticCategory::internal,
        "c20.stationary_source_match_exception",
        "validating the stationary kernel/provider binding raised an "
        "unexpected exception");
  }
}

Result<ExactReducedCoordinatesV1> c20_decode_stationary_state(
    const EmbeddedKernel& kernel, const ReducedStateV1& raw_state) {
  try {
    const auto& kernel_core =
        ::mwperf::detail::C20CoreAccess::embedded_kernel_core(kernel);
    if (!kernel_core || !kernel_core->romr_ops ||
        !kernel_core->source_framework) {
      return c20_invalid<ExactReducedCoordinatesV1>(
          "c20.stationary_kernel_source_missing",
          "exact stationary-state decoding requires the kernel's retained "
          "sealed C20 source");
    }
    const auto& ops = kernel_core->romr_ops;
    if (!(raw_state.codec == ops->state_codec)) {
      return c20_invalid<ExactReducedCoordinatesV1>(
          "c20.stationary_state_codec_mismatch",
          "the stationary word state uses a codec foreign to its embedded "
          "kernel");
    }
    auto valid = ops->exact_schema.validate_domain(raw_state);
    if (!valid) {
      return Result<ExactReducedCoordinatesV1>::failure(valid.error());
    }
    auto decoded = ops->exact_schema.decode(raw_state);
    if (!decoded) {
      return Result<ExactReducedCoordinatesV1>::failure(decoded.error());
    }
    const auto phase =
        ::mwperf::detail::ArrivalCoreAccess::phase_core(
            decoded.value().arrival_phase);
    if (!phase ||
        !(phase->binding ==
          arrival_law_binding(
              kernel_core->source_framework->inputs().configured_arrival)) ||
        !(phase->next_authored_slot == decoded.value().boundary_index)) {
      return c20_invalid<ExactReducedCoordinatesV1>(
          "c20.stationary_state_arrival_clock_mismatch",
          "the raw stationary word state does not preserve its configured "
          "arrival binding and absolute physical boundary");
    }
    return decoded;
  } catch (const std::bad_alloc&) {
    return c20_resource<ExactReducedCoordinatesV1>(
        "c20.stationary_decode_allocation_failure",
        "decoding an exact stationary word state exhausted memory");
  } catch (const std::exception&) {
    return c20_failure<ExactReducedCoordinatesV1>(
        DiagnosticCategory::internal,
        "c20.stationary_decode_exception",
        "decoding an exact stationary word state raised an unexpected "
        "exception");
  }
}

Result<std::vector<RuntimeDecodedMarkV1>>
c20_decode_stationary_entrance_labels(
    const EmbeddedKernel& kernel,
    const ReducedStateV1& first_eligible_state) {
  try {
    const auto& kernel_core =
        ::mwperf::detail::C20CoreAccess::embedded_kernel_core(kernel);
    if (!kernel_core || !kernel_core->romr_ops ||
        !kernel_core->source_framework) {
      return c20_invalid<std::vector<RuntimeDecodedMarkV1>>(
          "c20.stationary_entrance_decoder_source_missing",
          "stationary entrance-label decoding requires the retained sealed "
          "C20 source");
    }
    const auto& schema = kernel_core->romr_ops->exact_schema;
    if (!(first_eligible_state.codec == schema.reduced_state_codec)) {
      return c20_invalid<std::vector<RuntimeDecodedMarkV1>>(
          "c20.stationary_entrance_decoder_codec_mismatch",
          "the first-eligible FIFO state uses a codec foreign to the sealed "
          "entrance decoders");
    }
    auto valid = schema.validate_domain(first_eligible_state);
    if (!valid) {
      return Result<std::vector<RuntimeDecodedMarkV1>>::failure(
          valid.error());
    }
    std::vector<RuntimeDecodedMarkV1> labels;
    for (const DeterministicRuntimeMarkDecoderOperationV1& decoder :
         schema.framework_mark_decoders) {
      const auto& decoder_schema = decoder.schema();
      if (decoder_schema.source !=
          MarkDecoderSourceV1::entrance_realization) {
        continue;
      }
      if (!(decoder_schema.input_codec == first_eligible_state.codec) ||
          std::any_of(labels.begin(), labels.end(),
                      [&](const RuntimeDecodedMarkV1& existing) {
                        return existing.mark == decoder_schema.mark;
                      })) {
        return c20_failure<std::vector<RuntimeDecodedMarkV1>>(
            DiagnosticCategory::internal,
            "c20.stationary_entrance_decoder_binding_mismatch",
            "a sealed entrance decoder has a foreign input codec or a "
            "duplicate runtime mark identity");
      }
      auto operation =
          ::mwperf::detail::C20CoreAccess::fresh_mark_decoder(decoder);
      if (!operation) {
        return c20_failure<std::vector<RuntimeDecodedMarkV1>>(
            DiagnosticCategory::internal,
            "c20.stationary_entrance_decoder_missing",
            "a V0-sealed entrance decoder lost its immutable operation");
      }
      auto value = operation(first_eligible_state);
      if (!value) {
        return Result<std::vector<RuntimeDecodedMarkV1>>::failure(
            value.error());
      }
      if (!(value.value().codec == decoder_schema.output_codec)) {
        return c20_failure<std::vector<RuntimeDecodedMarkV1>>(
            DiagnosticCategory::internal,
            "c20.stationary_entrance_decoder_output_mismatch",
            "a V0-sealed entrance decoder returned a foreign value codec");
      }
      labels.push_back(RuntimeDecodedMarkV1{
          decoder_schema.mark, std::move(value).value()});
    }
    return Result<std::vector<RuntimeDecodedMarkV1>>::success(
        std::move(labels));
  } catch (const std::bad_alloc&) {
    return c20_resource<std::vector<RuntimeDecodedMarkV1>>(
        "c20.stationary_entrance_decoder_allocation_failure",
        "decoding stationary entrance labels exhausted memory");
  } catch (const std::exception&) {
    return c20_failure<std::vector<RuntimeDecodedMarkV1>>(
        DiagnosticCategory::internal,
        "c20.stationary_entrance_decoder_exception",
        "decoding stationary entrance labels raised an unexpected "
        "exception");
  }
}

Result<ReducedStateV1> c20_project_time_homogeneous_stationary_state(
    const EmbeddedKernel& kernel, const ReducedStateV1& raw_state) {
  try {
    const auto& kernel_core =
        ::mwperf::detail::C20CoreAccess::embedded_kernel_core(kernel);
    if (!kernel_core || !kernel_core->romr_ops ||
        !kernel_core->source_framework) {
      return c20_invalid<ReducedStateV1>(
          "c20.stationary_kernel_source_missing",
          "stationary clock projection requires the kernel's retained "
          "sealed C20 source");
    }
    const auto& ops = kernel_core->romr_ops;
    const BuilderArrivalView arrival_view = builder_arrival_view(
        kernel_core->source_framework->inputs().configured_arrival);
    if (ops->event_clock_semantics !=
            EventClockSemanticsV1::finite_phase_time_homogeneous_quotient ||
        !ops->finite_event_domain_states.has_value() ||
        !arrival_view.finite_phase().has_value() ||
        arrival_view.finite_phase()->row_clock_semantics !=
            ArrivalRowClockSemanticsV1::finite_phase_time_homogeneous) {
      return c20_unavailable<ReducedStateV1>(
          "c20.stationary_clock_quotient_unavailable",
          "C21 may erase physical slot only for C20's audited finite-phase, "
          "time-homogeneous quotient; a conditioned or undeclared clock "
          "semantics is not guessed");
    }
    auto decoded = c20_decode_stationary_state(kernel, raw_state);
    if (!decoded) {
      return Result<ReducedStateV1>::failure(decoded.error());
    }
    auto projected = quotient_callback_state(*ops, raw_state);
    if (!projected) {
      return projected;
    }
    auto round_trip = ops->exact_schema.decode(projected.value());
    const auto projected_phase =
        round_trip
            ? ::mwperf::detail::ArrivalCoreAccess::phase_core(
                  round_trip.value().arrival_phase)
            : nullptr;
    if (!round_trip || !projected_phase ||
        !(round_trip.value().boundary_index == BigNat{0U}) ||
        !(projected_phase->next_authored_slot == BigNat{0U}) ||
        !same_event_quotient_coordinates(decoded.value(),
                                         round_trip.value())) {
      return c20_invalid<ReducedStateV1>(
          "c20.stationary_clock_quotient_round_trip_mismatch",
          "clock erasure changed a backlog, predictive phase, controller, "
          "resource, margin, or unresolved coordinate");
    }
    return projected;
  } catch (const std::bad_alloc&) {
    return c20_resource<ReducedStateV1>(
        "c20.stationary_projection_allocation_failure",
        "projecting an exact stationary word state exhausted memory");
  } catch (const std::exception&) {
    return c20_failure<ReducedStateV1>(
        DiagnosticCategory::internal,
        "c20.stationary_projection_exception",
        "projecting an exact stationary word state raised an unexpected "
        "exception");
  }
}

namespace {

template <typename View>
[[nodiscard]] Result<void> c20_require_stationary_projection_view_match_impl(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint, const View& view,
    const bool contract_supports_view) {
  auto source_match =
      c20_require_stationary_kernel_provider_match(kernel, provider);
  if (!source_match) {
    return source_match;
  }
  if (!projection_source) {
    return c20_invalid<void>(
        "c20.stationary_projection_source_missing",
        "an audited stationary restriction requires one live opaque C21 "
        "projection source");
  }
  if (!contract_supports_view) {
    return c20_unavailable<void>(
        "c20.stationary_projection_view_not_accepted",
        "the retained accepted C14 contract does not authorize this "
        "stationary temporal restriction");
  }

  const auto& kernel_core =
      ::mwperf::detail::C20CoreAccess::embedded_kernel_core(kernel);
  const auto provider_core =
      ::mwperf::detail::C20CoreAccess::core(provider);
  const auto& view_core =
      ::mwperf::detail::C20CoreAccess::stationary_core(view);
  const auto& view_source =
      ::mwperf::detail::C20CoreAccess::stationary_source(view);
  const auto& view_temporal_source =
      ::mwperf::detail::C20CoreAccess::temporal_source(view);
  const bool same_projection_owner =
      view_source && view_source.get() == projection_source.get() &&
      !view_source.owner_before(projection_source) &&
      !projection_source.owner_before(view_source);
  const bool same_temporal_owner =
      temporal_source && view_temporal_source &&
      view_temporal_source.get() == temporal_source.get() &&
      !view_temporal_source.owner_before(temporal_source) &&
      !temporal_source.owner_before(view_temporal_source);
  if (!kernel_core || !provider_core || !view_core ||
      kernel_core->source_framework != provider_core ||
      view_core != provider_core || !same_projection_owner ||
      !same_temporal_owner ||
      view.source_kind() !=
          AuditedTemporalSourceKindV1::stationary_projection ||
      view.source_fingerprint() != projection_fingerprint ||
      view.projection_fingerprint() != projection_fingerprint) {
    return c20_invalid<void>(
        "c20.stationary_projection_view_binding_mismatch",
        "the audited stationary restriction belongs to a foreign C20 "
        "source, C21 projection source, or projection fingerprint");
  }
  return Result<void>::success();
}

}  // namespace

Result<C20StationaryProjectionViewsV1>
c20_mint_stationary_projection_views(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    std::shared_ptr<const
                    stationary::detail::StationaryProjectionSourceCore>
        projection_source,
    std::shared_ptr<const metrics::detail::TemporalSourceCore>
        temporal_source,
    const Digest256& projection_fingerprint) {
  try {
    auto source_match =
        c20_require_stationary_kernel_provider_match(kernel, provider);
    if (!source_match) {
      return Result<C20StationaryProjectionViewsV1>::failure(
          source_match.error());
    }
    if (!projection_source || !temporal_source) {
      return c20_invalid<C20StationaryProjectionViewsV1>(
          "c20.stationary_projection_source_missing",
          "the C20-authorized stationary mint requires one live opaque C21 "
          "projection source");
    }
    auto binding = c20_stationary_kernel_binding(kernel);
    if (!binding) {
      return Result<C20StationaryProjectionViewsV1>::failure(
          binding.error());
    }
    const C20StationaryCapabilityFactsV1& capabilities =
        binding.value().source.capabilities;
    if (!capabilities.exact_complete_residence_words ||
        !capabilities.finite_phase_time_homogeneous) {
      return c20_unavailable<C20StationaryProjectionViewsV1>(
          "c20.stationary_projection_mint_unavailable",
          "audited stationary temporal restrictions require exact complete "
          "residence words and the sealed finite-phase, time-homogeneous "
          "event-state quotient");
    }

    const auto framework =
        ::mwperf::detail::C20CoreAccess::core(provider);
    std::optional<AuditedCylinderLaw> cylinder_law;
    std::optional<AuditedTemporalLaw> temporal_law;
    std::optional<AuditedTemporalKernel> temporal_kernel;

    if (capabilities.finite_temporal_cylinder_route) {
      cylinder_law.emplace(
          ::mwperf::detail::C20CoreAccess::stationary_cylinder_law(
              framework, projection_source, temporal_source,
              projection_fingerprint));
    }
    if (capabilities.stationary_temporal_law_route) {
      temporal_law.emplace(
          ::mwperf::detail::C20CoreAccess::stationary_temporal_law(
              framework, projection_source, temporal_source,
              projection_fingerprint));
    }
    if (capabilities.stationary_stopped_kernel_route) {
      temporal_kernel.emplace(
          ::mwperf::detail::C20CoreAccess::stationary_temporal_kernel(
              framework, projection_source, temporal_source,
              projection_fingerprint));
    }

    return Result<C20StationaryProjectionViewsV1>::success(
        C20StationaryProjectionViewsV1{
            projection_fingerprint, std::move(cylinder_law),
            std::move(temporal_law), std::move(temporal_kernel)});
  } catch (const std::bad_alloc&) {
    return c20_resource<C20StationaryProjectionViewsV1>(
        "c20.stationary_projection_mint_allocation_failure",
        "minting audited stationary restrictions exhausted memory");
  } catch (const std::exception&) {
    return c20_failure<C20StationaryProjectionViewsV1>(
        DiagnosticCategory::internal,
        "c20.stationary_projection_mint_exception",
        "minting audited stationary restrictions raised an unexpected "
        "exception");
  }
}

Result<AuditedTemporalKernel> c20_mint_passive_fifo_temporal_kernel(
    const TemporalServiceKernel& service_kernel,
    std::shared_ptr<const metrics::detail::TemporalSourceCore>
        passive_source) {
  try {
    const auto& service =
        ::mwperf::detail::C20CoreAccess::temporal_service_core(
            service_kernel);
    const auto nonzero = [](const Digest256& digest) noexcept {
      return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                         [](const std::byte value) {
                           return value != std::byte{0};
                         });
    };
    const auto same_seal = [](const auto& left, const auto& right) noexcept {
      return left && right && left.get() == right.get() &&
             !left.owner_before(right) && !right.owner_before(left);
    };
    if (!service || !service->source ||
        !service->source->temporal_source || !passive_source ||
        passive_source->nodes.empty() || !passive_source->exact_rows ||
        !passive_source->complete_rows ||
        !passive_source->projectively_consistent ||
        passive_source->binding.kind !=
            AuditedTemporalSourceKindV1::passive_fifo_tag ||
        !passive_source->binding.projection_fingerprint.has_value() ||
        !nonzero(passive_source->binding.source_fingerprint) ||
        service->projection_fingerprint != service->source->fingerprint ||
        *passive_source->binding.projection_fingerprint !=
            service->projection_fingerprint ||
        service->continuation_schema_identity !=
            service->source->provider_binding.continuation_schema_identity ||
        service->target_selection_identity !=
            service->source->provider_binding.target_selection_identity ||
        service->target_service_schema_identity !=
            service->source->provider_binding.target_service_schema_identity ||
        !same_seal(passive_source->binding.seal_token,
                   service->source->provider_binding.seal_token)) {
      return c20_invalid<AuditedTemporalKernel>(
          "c23.passive_fifo_temporal_mint_binding_mismatch",
          "a passive FIFO temporal kernel must lift one exact C21 service "
          "continuation while preserving its source owner, V0 seal, "
          "projection, target, and service identities");
    }
    const auto& base = service->source->temporal_source->binding;
    const auto& lifted = passive_source->binding;
    if (lifted.accepted_contract_identity !=
            base.accepted_contract_identity ||
        lifted.normalized_requirements_identity !=
            base.normalized_requirements_identity ||
        lifted.authored_analysis_identity != base.authored_analysis_identity ||
        lifted.resolved_instance_identity != base.resolved_instance_identity ||
        lifted.target_selection_identity != base.target_selection_identity ||
        lifted.configured_arrival_identity !=
            base.configured_arrival_identity ||
        lifted.selection_identity != base.selection_identity ||
        lifted.target_service_schema_identity !=
            base.target_service_schema_identity ||
        lifted.timing_identity != base.timing_identity) {
      return c20_invalid<AuditedTemporalKernel>(
          "c23.passive_fifo_temporal_identity_mismatch",
          "passive tag lifting changed a contract, analysis, instance, "
          "arrival, selection, target, service, or timing identity");
    }
    const auto framework =
        ::mwperf::detail::C20CoreAccess::core(service->source->provider);
    if (!framework || !framework->report().passed() ||
        !same_seal(framework->consumer_seal_identity(),
                   passive_source->binding.seal_token)) {
      return c20_unavailable<AuditedTemporalKernel>(
          "c23.passive_fifo_temporal_v0_seal_unavailable",
          "the passive FIFO lift no longer retains its exact live passing "
          "C17 framework seal");
    }
    return Result<AuditedTemporalKernel>::success(
        ::mwperf::detail::C20CoreAccess::passive_fifo_temporal_kernel(
            framework, std::move(passive_source)));
  } catch (const std::bad_alloc&) {
    return c20_resource<AuditedTemporalKernel>(
        "c23.passive_fifo_temporal_mint_allocation_failure",
        "minting the passive FIFO temporal restriction exhausted memory");
  } catch (const std::exception&) {
    return c20_failure<AuditedTemporalKernel>(
        DiagnosticCategory::internal,
        "c23.passive_fifo_temporal_mint_exception",
        "minting the passive FIFO temporal restriction raised an "
        "unexpected exception");
  }
}

Result<void> c20_require_stationary_projection_view_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint,
    const AuditedCylinderLaw& view) {
  auto binding = c20_stationary_kernel_binding(kernel);
  if (!binding) {
    return Result<void>::failure(binding.error());
  }
  return c20_require_stationary_projection_view_match_impl(
      kernel, provider, projection_source, temporal_source,
      projection_fingerprint, view,
      binding.value().source.capabilities.finite_temporal_cylinder_route);
}

Result<void> c20_require_stationary_projection_view_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint,
    const AuditedTemporalLaw& view) {
  auto binding = c20_stationary_kernel_binding(kernel);
  if (!binding) {
    return Result<void>::failure(binding.error());
  }
  const C20StationaryCapabilityFactsV1& capabilities =
      binding.value().source.capabilities;
  return c20_require_stationary_projection_view_match_impl(
      kernel, provider, projection_source, temporal_source,
      projection_fingerprint, view,
      capabilities.stationary_temporal_law_route);
}

Result<void> c20_require_stationary_projection_view_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint,
    const AuditedTemporalKernel& view) {
  auto binding = c20_stationary_kernel_binding(kernel);
  if (!binding) {
    return Result<void>::failure(binding.error());
  }
  const C20StationaryCapabilityFactsV1& capabilities =
      binding.value().source.capabilities;
  return c20_require_stationary_projection_view_match_impl(
      kernel, provider, projection_source, temporal_source,
      projection_fingerprint, view,
      capabilities.stationary_stopped_kernel_route);
}

}  // namespace mwperf::temporal::detail

namespace mwperf {

Result<TemporalPath> execute_temporal_path(
    const AuditedTemporalFramework& framework,
    const ReducedInitialLaw& initial_law, const BigNat& horizon,
    MasterSeed seed) {
  try {
    const auto framework_core = detail::C20CoreAccess::core(framework);
    if (!framework_core || !framework_core->report().passed() ||
        !framework_core->slot_available()) {
      return c20_unavailable<TemporalPath>(
          "c20.temporal_framework_unavailable",
          "temporal path execution requires one live V0-audited C17 slot "
          "capability");
    }
    auto initial_valid = validate_reduced_initial_law_v1(initial_law);
    if (!initial_valid) {
      return Result<TemporalPath>::failure(initial_valid.error());
    }
    const auto& inputs = framework_core->inputs();
    const auto& bindings = inputs.framework_seed.bindings;
    if (detail::C20CoreAccess::initial_law_seal(initial_law) !=
            framework_core->consumer_seal_identity() ||
        !(initial_law.state_codec() ==
          inputs.exact_state_schema.reduced_state_codec) ||
        initial_law.exact_state_schema_digest() !=
            inputs.exact_state_schema.exact_state_schema_digest ||
        initial_law.reduced_state_schema_digest() !=
            inputs.exact_state_schema.reduced_state_schema_digest ||
        initial_law.selection_digest() != bindings.selection_digest) {
      return c20_invalid<TemporalPath>(
          "c20.initial_law_binding_mismatch",
          "the reduced initial law belongs to another C17 seal, configured "
          "arrival, state schema, timing convention, or selection");
    }

    auto view = audited_romr_view(framework);
    auto executor = audited_slot_executor(framework);
    if (!view) {
      return Result<TemporalPath>::failure(view.error());
    }
    if (!executor) {
      return Result<TemporalPath>::failure(executor.error());
    }
    auto handle = mint_romr_handle(view.value());
    if (!handle) {
      return Result<TemporalPath>::failure(handle.error());
    }
    const auto ops = detail::C20CoreAccess::handle_core(handle.value());
    if (initial_law.atoms().empty()) {
      return c20_invalid<TemporalPath>(
          "c20.empty_initial_law",
          "a temporal path requires a nonempty exactly normalized initial "
          "law");
    }
    for (const ReducedInitialAtomV1& atom : initial_law.atoms()) {
      if (atom.mass.exact_value().is_positive()) {
        auto valid = validate_entry_state(*ops, atom.state);
        if (!valid) {
          return c20_invalid<TemporalPath>(
              "c20.initial_atom_outside_event_domain",
              "a positive-mass initial atom lies outside the sealed ROMR "
              "event-entry domain");
        }
      }
    }
    if (horizon.bit_length() > std::numeric_limits<std::size_t>::digits) {
      return c20_resource<TemporalPath>(
          "c20.horizon_storage_overflow",
          "the exact horizon cannot be represented by this process's path "
          "container index type");
    }
    const std::size_t requested_slots =
        horizon.value().convert_to<std::size_t>();

    auto law_digest =
        initial_law_digest(initial_law, framework_core->execution_seal_digest());
    if (!law_digest) {
      return Result<TemporalPath>::failure(law_digest.error());
    }
    auto bank_result = detail::C20RngAccess::make_temporal_bank(
        inputs.instance, framework_core->execution_seal_digest(),
        law_digest.value(), seed);
    if (!bank_result) {
      return Result<TemporalPath>::failure(bank_result.error());
    }
    RngBank bank = std::move(bank_result).value();
    const Digest256 path_stream_identity =
        detail::C20RngAccess::temporal_root_fingerprint(bank);

    std::vector<AuthoredProbability> authored;
    authored.reserve(initial_law.atoms().size());
    for (const ReducedInitialAtomV1& atom : initial_law.atoms()) {
      auto probability =
          AuthoredProbability::from_exact(atom.mass.exact_value());
      if (!probability) {
        return Result<TemporalPath>::failure(probability.error());
      }
      authored.push_back(std::move(probability).value());
    }
    auto initial_pmf = validate_and_normalize_pmf_with_budget(
        authored, physical_pmf_tolerance(),
        inputs.causal_program.representation_budget);
    if (!initial_pmf) {
      return Result<TemporalPath>::failure(initial_pmf.error());
    }
    if (!(initial_pmf.value().authored_sum() == ExactRational::one()) ||
        !initial_pmf.value().normalization_delta().is_zero()) {
      return c20_invalid<TemporalPath>(
          "c20.initial_law_mass_mismatch",
          "the reduced initial law must already have exact unit mass; C20 "
          "does not normalize it");
    }
    DeterministicRng& initial_rng =
        detail::C20RngAccess::initial_joint_atom(bank);
    const std::size_t initial_index =
        sample_categorical(initial_pmf.value(), initial_rng);
    auto initialized = detail::C20RngAccess::mark_initialized(bank);
    if (!initialized) {
      return Result<TemporalPath>::failure(initialized.error());
    }
    const ReducedStateV1 selected_initial =
        initial_law.atoms()[initial_index].state;

    std::vector<TemporalSlotV1> slots;
    slots.reserve(requested_slots);
    std::vector<ResidenceWord> words;
    std::vector<BigNat> event_epochs;
    event_epochs.push_back(BigNat(0U));

    if (requested_slots == 0U) {
      auto core = std::make_shared<const temporal::detail::TemporalPathCore>(
          temporal::detail::TemporalPathCore{
              horizon,
              selected_initial,
              selected_initial,
              {},
              {},
              std::move(event_epochs),
              std::nullopt,
              framework_core->execution_seal_digest(),
              law_digest.value(),
              path_stream_identity});
      return Result<TemporalPath>::success(
          detail::C20CoreAccess::path(std::move(core)));
    }

    auto cursor_result = begin_residence(view.value(), selected_initial);
    if (!cursor_result) {
      return Result<TemporalPath>::failure(cursor_result.error());
    }
    ResidenceCursor cursor = std::move(cursor_result).value();
    BigNat event_index(0U);
    detail::C20CoreAccess::set_residence_stream_index(cursor, event_index);
    BigNat global_offset(0U);
    ReducedStateV1 final_state = selected_initial;

    while (slots.size() < requested_slots) {
      const BigNat local_offset = cursor.offset();
      auto step = advance_residence(cursor, executor.value(), bank);
      if (!step) {
        return Result<TemporalPath>::failure(step.error());
      }
      slots.push_back(TemporalSlotV1{
          global_offset,
          event_index,
          local_offset,
          step.value().edge(),
          step.value().predecision_projection(),
          step.value().completed_edge_projection()});
      ++global_offset;
      final_state = step.value().edge().successor_state();

      auto stop = validate_residence_stop(cursor, step.value());
      if (!stop) {
        return Result<TemporalPath>::failure(stop.error());
      }
      if (stop.value().stops()) {
        auto word = finalize_residence_word(cursor);
        if (!word) {
          return Result<TemporalPath>::failure(word.error());
        }
        final_state = word.value().event_endpoint();
        words.push_back(std::move(word).value());
        event_epochs.push_back(global_offset);
        if (slots.size() < requested_slots) {
          ++event_index;
          auto next = begin_residence(view.value(), final_state);
          if (!next) {
            return Result<TemporalPath>::failure(next.error());
          }
          cursor = std::move(next).value();
          detail::C20CoreAccess::set_residence_stream_index(cursor,
                                                            event_index);
        }
      }
    }

    std::optional<UnfinishedResidenceV1> unfinished;
    if (cursor.lifecycle() == ResidenceLifecycleV1::open) {
      unfinished.emplace(UnfinishedResidenceV1{
          cursor, bank.snapshot(), cursor.audited_view_fingerprint(),
          cursor.ops_handle().identity()});
      final_state = cursor.current_state();
    }
    auto core = std::make_shared<const temporal::detail::TemporalPathCore>(
        temporal::detail::TemporalPathCore{
            horizon,
            selected_initial,
            std::move(final_state),
            std::move(slots),
            std::move(words),
            std::move(event_epochs),
            std::move(unfinished),
            framework_core->execution_seal_digest(),
            law_digest.value(),
            path_stream_identity});
    return Result<TemporalPath>::success(
        detail::C20CoreAccess::path(std::move(core)));
  } catch (const std::bad_alloc&) {
    return c20_resource<TemporalPath>(
        "c20.allocation_failure",
        "executing the finite temporal path exceeded available memory");
  } catch (const std::exception&) {
    return c20_failure<TemporalPath>(
        DiagnosticCategory::internal, "c20.temporal_path_exception",
        "temporal path execution raised an unexpected exception");
  }
}

}  // namespace mwperf

#if defined(MWPERF_C20_TEST_SEAMS)
namespace mwperf::testing {

Result<RngBank> C20FixtureAccess::restore_temporal_bank(
    const RngBankSnapshot& snapshot) {
  return detail::C20RngAccess::restore_temporal_bank(snapshot);
}

Result<RngBank> C20FixtureAccess::initialized_temporal_bank(
    const AuditedRomrView& view, const ResolvedInstance& instance,
    const MasterSeed seed) {
  const auto framework = detail::C20CoreAccess::core(view);
  if (!framework || !framework->report().passed() ||
      framework->inputs().instance.fingerprints().combined !=
          instance.fingerprints().combined) {
    return c20_invalid<RngBank>(
        "c20.test_temporal_bank_binding_mismatch",
        "the test temporal bank requires the exact audited ROMR instance");
  }
  auto law_digest = sha256_domain_separated(
      "mwperf.c20.test-reduced-initial-law.v1",
      framework->execution_seal_digest().bytes());
  if (!law_digest) {
    return Result<RngBank>::failure(law_digest.error());
  }
  auto bank = detail::C20RngAccess::make_temporal_bank(
      instance, framework->execution_seal_digest(), law_digest.value(), seed);
  if (!bank) {
    return bank;
  }
  auto initialized = detail::C20RngAccess::mark_initialized(bank.value());
  if (!initialized) {
    return Result<RngBank>::failure(initialized.error());
  }
  return bank;
}

Result<FiniteEventStateDomain>
C20FixtureAccess::finite_domain_from_states_for_testing(
    const AuditedResidenceProvider& provider,
    std::vector<ReducedStateV1> states) {
  auto view = audited_romr_view(provider);
  if (!view) {
    return Result<FiniteEventStateDomain>::failure(view.error());
  }
  auto handle = mint_romr_handle(view.value());
  if (!handle) {
    return Result<FiniteEventStateDomain>::failure(handle.error());
  }
  const auto ops = detail::C20CoreAccess::handle_core(handle.value());
  for (std::size_t index = 0U; index < states.size(); ++index) {
    if (!(states[index].codec == ops->state_codec)) {
      return c20_invalid<FiniteEventStateDomain>(
          "c20.test_event_domain_codec_mismatch",
          "a test event-domain state has the wrong exact-state codec");
    }
    auto valid = ops->exact_schema.validate_domain(states[index]);
    if (!valid) {
      return Result<FiniteEventStateDomain>::failure(valid.error());
    }
    if (std::find(states.begin(), states.begin() + index, states[index]) !=
        states.begin() + index) {
      return c20_invalid<FiniteEventStateDomain>(
          "c20.duplicate_event_domain_state",
          "the test finite event domain contains duplicate states");
    }
  }
  auto content = event_domain_content_digest(*ops, states);
  auto fingerprint = event_domain_fingerprint(*ops, states);
  if (!content) {
    return Result<FiniteEventStateDomain>::failure(content.error());
  }
  if (!fingerprint) {
    return Result<FiniteEventStateDomain>::failure(fingerprint.error());
  }
  auto core =
      std::make_shared<const temporal::detail::FiniteEventStateDomainCore>(
          temporal::detail::FiniteEventStateDomainCore{
              std::move(states), std::move(fingerprint).value(),
              std::move(content).value(), ops->identity, ops->state_codec,
              ops->exact_state_schema_digest,
              ops->reduced_state_schema_digest, ops->seal});
  return Result<FiniteEventStateDomain>::success(
      detail::C20CoreAccess::domain(std::move(core)));
}

bool C20FixtureAccess::reset_preserves_persistent_coordinates_for_testing(
    const ExactReducedCoordinatesV1& before,
    const ExactReducedCoordinatesV1& after,
    const std::span<const RuntimeFieldIdV1>
        residence_local_reset_fields) {
  return same_coordinates_across_reset(before, after,
                                       residence_local_reset_fields);
}

}  // namespace mwperf::testing
#endif
