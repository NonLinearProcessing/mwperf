#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/temporal_contract.hpp"
#include "mwperf/stationary/flux.hpp"

// Dependency-neutral private representation shared by C21, C22, and the
// later C23 handoff. It is not owned by the removable C22 backend.
namespace mwperf::metrics::detail {

// Immutable proof identity shared by every view and entrance participating in
// one temporal calculation.  It is value-only except for the unforgeable C17
// seal token and contains no executable plug authority.
struct TemporalSourceBindingV1 final {
  AuditedTemporalSourceKindV1 kind;
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
      seal_token;
  Digest256 source_fingerprint;
  std::optional<Digest256> projection_fingerprint;
  Digest256 accepted_contract_identity;
  Digest256 normalized_requirements_identity;
  Digest256 authored_analysis_identity;
  Digest256 resolved_instance_identity;
  Digest256 target_selection_identity;
  Digest256 configured_arrival_identity;
  Digest256 selection_identity;
  Digest256 exact_state_schema_identity;
  Digest256 reduced_state_schema_identity;
  Digest256 mark_schema_identity;
  Digest256 continuation_schema_identity;
  Digest256 target_service_schema_identity;
  Digest256 timing_identity;
  CodecIdentityV1 state_codec;
};

struct TemporalTransitionCore final {
  std::size_t successor_index;
  MarkedFluxEdgeV1 edge;
  ExactRational exact_mass;
};

// Certified enclosure for the difference between the complete stochastic
// source-row mass and the explicitly represented row mass.  In particular,
// a row with represented mass m is accepted only when 1-m lies in this
// interval.  The interval is numerical/source-law error; it is never a
// physical exit atom.
struct TemporalRowErrorEnclosureV1 final {
  ExactRational lower;
  ExactRational upper;
};

// One predictively sufficient latent state.  The optional component identity
// is used only for the source-derived active-component run/gap qualifiers.
struct TemporalNodeCore final {
  ReducedStateV1 decoded_state;
  std::vector<TemporalTransitionCore> transitions;
  std::optional<std::size_t> invariant_component;
  // Predecision target backlog in the accepted target order.  Keeping this
  // decoded state observable on the node lets StateAt(k) stop after exactly
  // k transitions; C22 never evaluates an outgoing row merely to inspect the
  // terminal state.
  std::vector<BigNat> state_target_backlog;
  // Absent for an exact row. Present only for an analytically certified row
  // whose explicitly represented atoms need not sum exactly to one.
  std::optional<TemporalRowErrorEnclosureV1> source_row_error_enclosure =
      std::nullopt;
};

struct TemporalEntranceAtomCore final {
  std::size_t node_index;
  ReducedStateV1 decoded_state;
  ExactRational exact_mass;
};

// Exact C14 authorization for one F-C22-05 statistic.  This is deliberately
// a closed request projection, not a general "temporal law available" bit:
// the statistic kind, target and every authored parameter must all agree
// before the source may be traversed for that readout.
struct F05AuthorizationV1 final {
  MetricKindV1 request_kind;
  std::size_t target_ordinal;
  MetricRequestParametersV1 parameters;

  friend bool operator==(const F05AuthorizationV1&,
                         const F05AuthorizationV1&) = default;
};

struct TemporalSourceCore final {
  TemporalSourceBindingV1 binding;
  std::vector<TemporalNodeCore> nodes;
  std::vector<TemporalEntranceAtomCore> stationary_entrance;
  std::vector<F05AuthorizationV1> f05_authorizations;
  std::size_t maximum_state_offset;
  // nullopt means that this retained finite prefix contains no edge at all.
  // Otherwise edges 0..maximum_edge_offset are available.  This avoids
  // falsely exposing EdgeMarkAt(0) from a zero-step transient prefix.
  std::optional<std::size_t> maximum_edge_offset;
  std::optional<std::size_t> maximum_states_budget;
  std::optional<std::size_t> maximum_row_atoms_budget;
  bool projectively_consistent;
  bool exact_rows;
  // True only when every retained node has a complete exact or certified
  // analytic one-slot row. A horizon-specialized transient cylinder may
  // retain a terminal frontier without rows; that prefix is never minted as
  // a temporal kernel or law.
  bool complete_rows;
};

struct InitialLawCore final {
  InitialLawKindV1 kind;
  std::shared_ptr<const TemporalSourceCore> source;
  std::vector<TemporalEntranceAtomCore> atoms;
  Digest256 source_fingerprint;
  Digest256 projection_fingerprint;
  bool has_projection_binding;
};

}  // namespace mwperf::metrics::detail
