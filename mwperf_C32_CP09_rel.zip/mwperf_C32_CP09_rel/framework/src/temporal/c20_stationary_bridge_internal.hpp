#pragma once

#include <memory>
#include <optional>
#include <vector>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/temporal/romr.hpp"
#include "temporal/temporal_contract_internal.hpp"

namespace mwperf {
class TemporalServiceKernel;
}

namespace mwperf::temporal::detail {

// Private C20 -> C21 handoff.  This is deliberately a value-only projection
// of the C17/C20 seal.  It contains no SealedFrameworkCore, KernelAccess,
// plug, executor, row provider, operation, decoder callback, or RNG handle.
// The in-process seal token is retained only for strict same-run equality.
struct C20StationaryCapabilityFactsV1 final {
  bool stationary_invariant_route{false};
  bool stationary_edge_reward_route{false};
  bool finite_temporal_cylinder_route{false};
  // These three facts are derived from the authoritative accepted clause,
  // not merely from its aggregate backend-route tag.  Keeping them separate
  // prevents a residence-word Palm contract or a transient stopped contract
  // from minting a stronger stationary continuation/entrance view.
  bool stationary_temporal_law_route{false};
  bool stationary_stopped_kernel_route{false};
  bool stationary_stopped_entrance_route{false};
  bool residence_or_stopped_route{false};
  bool palm_or_fifo_route{false};
  bool retains_predictive_phase{false};
  bool retains_target_departure{false};
  bool retains_arrival_batch{false};
  bool exact_complete_residence_words{false};
  bool finite_phase_time_homogeneous{false};
  // Finite-cylinder/finite-word capabilities retain typed observation
  // budgets.  StateAt(k) and EdgeMarkAt(k) are deliberately separate: a
  // backlog cylinder does not authorize inspection of an edge mark merely
  // because its construction advances through that edge.  The unbounded bit
  // is set only by an accepted genuine sequential residence/stopped-law
  // contract, never by a bounded finite-cylinder request.
  std::optional<BigNat> maximum_stationary_state_offset;
  std::optional<BigNat> maximum_stationary_edge_offset;
  bool unbounded_stationary_temporal_continuation{false};
  // Exact accepted C14 requests that may be dispatched by F-C22-05.  Keeping
  // this list separate from the coarse temporal-law route prevents callers
  // from changing a lag, window, predicate, event, frequency or target after
  // negotiation.
  std::vector<metrics::detail::F05AuthorizationV1> f05_authorizations;
};

struct C20StationarySourceBindingV1 final {
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
      seal_token;

  Digest256 provider_romr_identity;
  Digest256 execution_seal_identity;
  Digest256 descriptor_identity;
  Digest256 accepted_contract_identity;
  Digest256 normalized_requirements_identity;
  Digest256 selection_identity;
  Digest256 authored_analysis_identity;
  Digest256 resolved_instance_identity;
  Digest256 configured_arrival_identity;
  Digest256 configured_arrival_view_identity;
  Digest256 configured_arrival_law_identity;
  Digest256 configured_arrival_catalog_identity;
  Digest256 exact_state_schema_identity;
  Digest256 reduced_state_schema_identity;
  Digest256 ownership_schema_identity;
  Digest256 exact_update_schema_identity;
  Digest256 mark_schema_identity;
  Digest256 timing_identity;
  Digest256 continuation_schema_identity;
  Digest256 target_selection_identity;
  Digest256 target_service_schema_identity;

  CodecIdentityV1 state_codec;
  TimingConvention timing;
  EventClockSemanticsV1 event_clock_semantics;
  PmfRepresentationBudget frozen_representation_budget;
  SelectionSpec configured_selection;
  SolverSpec configured_solver;
  ArrivalBinding configured_arrival_binding;
  std::optional<FinitePhaseDescriptor> configured_finite_phase;
  std::optional<StationaryPhaseLawDescriptor>
      configured_stationary_phase_law;
  ArrivalCapabilities accepted_arrival_capabilities;
  MetricRequirements accepted_requirements;
  std::vector<ResolvedMetricContractV1> accepted_metric_contracts;
  std::vector<RuntimeStateFieldV1> retained_state_schema;
  std::vector<RuntimeMarkDescriptorV1> retained_mark_schema;
  std::optional<TemporalEventContractV1> continuation_contract;
  TargetSelection target_selection;
  DerivedServiceIdentity target_service;
  C20StationaryCapabilityFactsV1 capabilities;
};

struct C20StationaryKernelBindingV1 final {
  C20StationarySourceBindingV1 source;
  Digest256 finite_event_domain_identity;
  Digest256 finite_event_domain_content_identity;
  Digest256 embedded_kernel_identity;
};

// C21's common source is deliberately incomplete here.  The bridge retains
// only shared ownership, which permits an exact same-projection check but no
// inspection or execution of the latent stationary construction.
struct C20StationaryProjectionViewsV1 final {
  Digest256 projection_fingerprint;
  std::optional<AuditedCylinderLaw> cylinder_law;
  std::optional<AuditedTemporalLaw> temporal_law;
  std::optional<AuditedTemporalKernel> temporal_kernel;
};

// Read-only identity projections for the exact finite C20 route.
[[nodiscard]] Result<C20StationaryKernelBindingV1>
c20_stationary_kernel_binding(const EmbeddedKernel& kernel);

[[nodiscard]] Result<C20StationarySourceBindingV1>
c20_stationary_provider_binding(const AuditedResidenceProvider& provider);

// Requires the exact originating provider object, not merely equal digests.
// This rejects independently minted, same-shaped seals before word traversal.
[[nodiscard]] Result<void> c20_require_stationary_kernel_provider_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider);

// Exact schema decode retained by the sealed C20 source.  This returns only
// value coordinates; it does not expose the decoder operation itself.
[[nodiscard]] Result<ExactReducedCoordinatesV1>
c20_decode_stationary_state(const EmbeddedKernel& kernel,
                            const ReducedStateV1& raw_state);

// Invokes only the V0-sealed entrance-realization decoders and returns their
// typed values.  No callback, framework core, or mutable operation crosses
// this C20 value boundary.
[[nodiscard]] Result<std::vector<RuntimeDecodedMarkV1>>
c20_decode_stationary_entrance_labels(
    const EmbeddedKernel& kernel, const ReducedStateV1& first_eligible_state);

// Erases only absolute physical slot/boundary coordinates by invoking C20's
// already-audited finite-phase, time-homogeneous quotient round trip.  The
// caller must retain raw_state in the latent word/provenance object.
[[nodiscard]] Result<ReducedStateV1>
c20_project_time_homogeneous_stationary_state(
    const EmbeddedKernel& kernel, const ReducedStateV1& raw_state);

// The only C20-authorized mint for C21 audited temporal restrictions.  A
// restriction is populated only when the retained accepted C14 contract has
// the corresponding temporal route.  The common source remains opaque and
// no callback, row access, executor, or framework carrier is returned.
[[nodiscard]] Result<C20StationaryProjectionViewsV1>
c20_mint_stationary_projection_views(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    std::shared_ptr<const
                    stationary::detail::StationaryProjectionSourceCore>
        projection_source,
    std::shared_ptr<const metrics::detail::TemporalSourceCore>
        temporal_source,
    const Digest256& projection_fingerprint);

// Future C23 may lift the already C21-audited chronological service source
// with a passive FIFO tag.  This C20-owned mint is the only route that can
// attach the original live V0 framework core to that lifted value graph.  It
// accepts no raw callback and requires exact projection/source ownership.
[[nodiscard]] Result<AuditedTemporalKernel>
c20_mint_passive_fifo_temporal_kernel(
    const TemporalServiceKernel& service_kernel,
    std::shared_ptr<const metrics::detail::TemporalSourceCore>
        passive_source);

// Strict identity checks used by C21 before combining a restriction with a
// core projection.  They compare exact C20 source ownership, exact opaque
// projection-source ownership, and the supplied projection fingerprint.
[[nodiscard]] Result<void> c20_require_stationary_projection_view_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint,
    const AuditedCylinderLaw& view);

[[nodiscard]] Result<void> c20_require_stationary_projection_view_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint,
    const AuditedTemporalLaw& view);

[[nodiscard]] Result<void> c20_require_stationary_projection_view_match(
    const EmbeddedKernel& kernel,
    const AuditedResidenceProvider& provider,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        projection_source,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>&
        temporal_source,
    const Digest256& projection_fingerprint,
    const AuditedTemporalKernel& view);

}  // namespace mwperf::temporal::detail
