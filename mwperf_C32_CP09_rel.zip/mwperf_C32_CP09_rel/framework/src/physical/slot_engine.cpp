#include "mwperf/physical/slot_engine.hpp"

#include <algorithm>
#include <atomic>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <ranges>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "arrival/core_internal.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/periodic.hpp"
#include "mwperf/arrival/private_markov_renewal.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/arrival/shared_round_renewal.hpp"
#include "mwperf/arrival/trace.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/physical/physical_edge.hpp"
#include "mwperf/physical/physical_state.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/random/rng_stage.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace detail {

struct PhysicalRunOwner final {};

// RngBankSnapshot keeps this record behind an immutable shared owner so the
// public C12 counters remain source compatible while C20 receives a complete,
// owned, versioned restore point.  No pointer refers back to the live bank.
struct RngBankSnapshotState final {
  std::uint32_t format_version;
  bool temporal_path;
  bool initialized;
  Digest256 combined_input;
  MasterSeed seed;
  Digest256 instance_key_digest;
  Digest256 configured_arrival_stream_identity;
  std::optional<Digest256> temporal_framework_digest;
  std::optional<Digest256> reduced_initial_law_digest;
  RngCheckpoint initial_joint_atom;
  RngCheckpoint tie_resolution;
  std::optional<Digest256> active_cursor_digest;
  std::optional<BigNat> active_residence_index;
  std::optional<BigNat> active_slot_offset;
};

struct PhysicalEngineAccess final {
  [[nodiscard]] static PhysicalState make_state(
      Backlog backlog, BigNat boundary_index, SourceNode controller_memory,
      SourceNode static_context, ArrivalPhase arrival_phase,
      PhysicalRunIdentity run_identity,
      std::shared_ptr<const PhysicalRunOwner> run_owner) {
    return PhysicalState(std::move(backlog), std::move(boundary_index),
                         std::move(controller_memory),
                         std::move(static_context), std::move(arrival_phase),
                         std::move(run_identity), std::move(run_owner));
  }

  [[nodiscard]] static const std::shared_ptr<const PhysicalRunOwner>& owner(
      const PhysicalState& state) noexcept {
    return state.run_owner_;
  }

  [[nodiscard]] static const std::shared_ptr<const PhysicalRunOwner>& owner(
      const RngBank& bank) noexcept {
    return bank.run_owner_;
  }

  [[nodiscard]] static DeterministicRng& initial_rng(RngBank& bank) noexcept {
    return bank.initial_joint_atom_;
  }

  [[nodiscard]] static const DeterministicRng& initial_rng(
      const RngBank& bank) noexcept {
    return bank.initial_joint_atom_;
  }

  [[nodiscard]] static const DeterministicRng& tie_rng(
      const RngBank& bank) noexcept {
    return bank.tie_resolution_;
  }

  [[nodiscard]] static bool initialized(const RngBank& bank) noexcept {
    return bank.initialized_;
  }

  static void mark_initialized(RngBank& bank) noexcept {
    bank.initialized_ = true;
  }

  [[nodiscard]] static InitializedPhysicalRun make_initialized(
      PhysicalState state, ArrivalProcess process) {
    return InitializedPhysicalRun(std::move(state), std::move(process));
  }

  [[nodiscard]] static PhysicalState& state(
      InitializedPhysicalRun& run) noexcept {
    return run.state_;
  }

  [[nodiscard]] static ArrivalProcess& process(
      InitializedPhysicalRun& run) noexcept {
    return run.process_;
  }

  [[nodiscard]] static PhysicalEdge make_edge(
      BigNat slot_index, PhysicalState pre_state, ScheduleDecision decision,
      Schedule departure, std::shared_ptr<const ArrivalStep> arrival_step,
      PhysicalState post_state, std::vector<PhysicalMarkEvidence> marks) {
    return PhysicalEdge(std::move(slot_index), std::move(pre_state),
                        std::move(decision), std::move(departure),
                        std::move(arrival_step), std::move(post_state),
                        std::move(marks));
  }

  [[nodiscard]] static PhysicalPath make_path(
      PhysicalState initial_state, PhysicalState final_state,
      std::vector<PhysicalEdge> edges, std::vector<QueueId> queue_ids) {
    return PhysicalPath(std::move(initial_state), std::move(final_state),
                        std::move(edges), std::move(queue_ids));
  }
};

}  // namespace detail
namespace {

inline constexpr std::uint32_t kRngBankSnapshotFormatVersion = 1U;

[[nodiscard]] Diagnostic physical_error(
    DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{.category = category,
                    .code = std::move(code),
                    .message = std::move(message),
                    .authored_path = std::nullopt,
                    .json_pointer = std::nullopt,
                    .notes = std::move(notes)};
}

template <typename T>
[[nodiscard]] Result<T> fail(std::string code, std::string message,
                             std::vector<std::string> notes = {}) {
  return Result<T>::failure(
      physical_error(DiagnosticCategory::input_validation, std::move(code),
                     std::move(message), std::move(notes)));
}

template <typename T>
[[nodiscard]] Result<T> internal_fail(std::string code, std::string message,
                                      std::vector<std::string> notes = {}) {
  return Result<T>::failure(
      physical_error(DiagnosticCategory::internal, std::move(code),
                     std::move(message), std::move(notes)));
}

template <typename T>
[[nodiscard]] Result<T> allocation_fail(std::string operation) {
  return Result<T>::failure(physical_error(
      DiagnosticCategory::resource_limit, "physical_allocation_failure",
      "the physical reference engine exhausted memory while " + operation));
}

template <typename Left, typename Right>
[[nodiscard]] bool same_owner(const std::shared_ptr<Left>& left,
                              const std::shared_ptr<Right>& right) {
  return left && right && !left.owner_before(right) &&
         !right.owner_before(left);
}

[[nodiscard]] bool source_nodes_equal(const SourceNode& left,
                                      const SourceNode& right) noexcept {
  if (left.kind() != right.kind()) {
    return false;
  }
  switch (left.kind()) {
    case SourceNodeKind::null_value:
      return true;
    case SourceNodeKind::boolean:
      return *left.boolean_value() == *right.boolean_value();
    case SourceNodeKind::number:
      return *left.number_lexeme() == *right.number_lexeme();
    case SourceNodeKind::string:
      return *left.string_value() == *right.string_value();
    case SourceNodeKind::array: {
      const auto left_items = left.array_items();
      const auto right_items = right.array_items();
      if (left_items.size() != right_items.size()) {
        return false;
      }
      for (std::size_t index = 0U; index < left_items.size(); ++index) {
        if (!source_nodes_equal(left_items[index], right_items[index])) {
          return false;
        }
      }
      return true;
    }
    case SourceNodeKind::object: {
      const auto left_members = left.object_members();
      const auto right_members = right.object_members();
      if (left_members.size() != right_members.size()) {
        return false;
      }
      for (const SourceObjectMember& member : left_members) {
        const SourceNode* candidate = right.find(member.key);
        if (candidate == nullptr ||
            !source_nodes_equal(member.value, *candidate)) {
          return false;
        }
      }
      return true;
    }
  }
  return false;
}

[[nodiscard]] bool is_empty_object(const SourceNode& node) noexcept {
  return node.kind() == SourceNodeKind::object &&
         node.object_members().empty();
}

[[nodiscard]] bool same_phase(const ArrivalPhase& left,
                              const ArrivalPhase& right) noexcept {
  if (arrival_phase_family(left) != arrival_phase_family(right) ||
      arrival_phase_digest(left) != arrival_phase_digest(right)) {
    return false;
  }
  return std::ranges::equal(arrival_phase_canonical_state(left),
                            arrival_phase_canonical_state(right));
}

[[nodiscard]] bool same_rng_checkpoint(const RngCheckpoint& left,
                                       const RngCheckpoint& right) noexcept {
  return left.rng_version() == right.rng_version() &&
         left.stream_identity() == right.stream_identity() &&
         left.state_words() == right.state_words() &&
         left.consumed_words() == right.consumed_words();
}

[[nodiscard]] bool same_arrival_step(const ArrivalStep& left,
                                     const ArrivalStep& right) noexcept {
  return left.authored_slot == right.authored_slot &&
         left.batch == right.batch &&
         same_phase(left.phase_before, right.phase_before) &&
         same_phase(left.phase_after, right.phase_after) &&
         left.law_digest == right.law_digest &&
         left.realization_identity == right.realization_identity;
}

[[nodiscard]] bool same_decision(const ScheduleDecision& left,
                                 const ScheduleDecision& right) noexcept {
  return std::ranges::equal(left.schedule.bytes(), right.schedule.bytes()) &&
         left.primary_objective == right.primary_objective &&
         left.composite_objective == right.composite_objective &&
         left.priority_code == right.priority_code &&
         std::ranges::equal(left.eligibility.bytes(),
                            right.eligibility.bytes()) &&
         left.family == right.family && left.backend_id == right.backend_id &&
         left.accounting == right.accounting;
}

// Holds the original deployed core live and prevents concurrent/reentrant
// mutation while C12 stages a successor on a private cloned core.
class ArrivalProcessLease final {
 public:
  explicit ArrivalProcessLease(
      std::shared_ptr<detail::ArrivalProcessCore> core) noexcept
      : core_(std::move(core)),
        acquired_(core_ &&
                  !core_->in_step.test_and_set(std::memory_order_acquire)) {}

  ArrivalProcessLease(const ArrivalProcessLease&) = delete;
  ArrivalProcessLease& operator=(const ArrivalProcessLease&) = delete;

  ~ArrivalProcessLease() noexcept {
    if (acquired_) {
      core_->in_step.clear(std::memory_order_release);
    }
  }

  [[nodiscard]] bool acquired() const noexcept { return acquired_; }

 private:
  std::shared_ptr<detail::ArrivalProcessCore> core_;
  bool acquired_;
};

[[nodiscard]] Result<ArrivalPhase> snapshot_current_phase(
    const std::shared_ptr<detail::ArrivalProcessCore>& core) {
  if (!core || !core->law || !core->owner || !core->state ||
      !core->law->runtime.encode_phase) {
    return internal_fail<ArrivalPhase>(
        "physical_arrival_cursor_incomplete",
        "the deployed arrival cursor cannot produce a complete predictive "
        "phase snapshot");
  }
  try {
    auto encoded = core->law->runtime.encode_phase(core->law->payload,
                                                   core->state);
    if (!encoded) {
      return Result<ArrivalPhase>::failure(encoded.error());
    }
    auto digest = detail::digest_arrival_state(encoded.value());
    if (!digest) {
      return Result<ArrivalPhase>::failure(digest.error());
    }
    auto phase_core = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{core->law->binding.family,
                                 core->law->binding,
                                 ArrivalStateDigest(digest.value()),
                                 std::move(encoded.value()),
                                 core->expected_slot,
                                 core->state,
                                 core->owner});
    return Result<ArrivalPhase>::success(detail::ArrivalCoreAccess::make_phase(
        core->law->binding.family, std::move(phase_core)));
  } catch (const std::bad_alloc&) {
    return allocation_fail<ArrivalPhase>("snapshotting the initial phase");
  } catch (const std::exception&) {
    return internal_fail<ArrivalPhase>(
        "physical_phase_snapshot_failure",
        "the configured arrival codec failed while snapshotting H(0)");
  }
}

[[nodiscard]] Result<ArrivalProcess> stage_arrival_process(
    const std::shared_ptr<detail::ArrivalProcessCore>& source,
    const RngBank& bank) {
  if (!source || !source->law || !source->rng || !source->state ||
      !source->owner) {
    return fail<ArrivalProcess>(
        "physical_arrival_process_moved_from",
        "the physical slot requires one live configured arrival cursor");
  }
  try {
    DeterministicRng staged_rng = derive_rng_stream(
        bank.seed(), StageTag::configured_arrival, bank.instance_key());
    if (staged_rng.stream_identity() !=
            bank.configured_arrival_stream_identity() ||
        staged_rng.stream_identity() != source->rng->stream_identity()) {
      return fail<ArrivalProcess>(
          "physical_arrival_stream_mismatch",
          "the deployed arrival cursor does not belong to this physical RNG "
          "bank");
    }
    const RngCheckpoint checkpoint = source->rng->checkpoint();
    auto restored = staged_rng.restore(checkpoint);
    if (!restored) {
      return Result<ArrivalProcess>::failure(restored.error());
    }
    auto staged_core = std::make_shared<detail::ArrivalProcessCore>(
        source->law, std::make_unique<DeterministicRng>(std::move(staged_rng)),
        source->state, source->expected_slot, source->owner,
        source->realization_identity);
    return Result<ArrivalProcess>::success(
        detail::ArrivalCoreAccess::make_process(source->law->binding.family,
                                                std::move(staged_core)));
  } catch (const std::bad_alloc&) {
    return allocation_fail<ArrivalProcess>("staging an arrival cursor");
  } catch (const std::exception&) {
    return internal_fail<ArrivalProcess>(
        "physical_arrival_staging_failure",
        "the arrival cursor could not be staged transactionally");
  }
}

// One closed family dispatch per slot. Each spelling remains a thin guard over
// C09's sole cursor transition and therefore cannot cause a second kernel
// invocation.
[[nodiscard]] Result<ArrivalStep> dispatch_arrival_family(
    ArrivalProcess& process, const BigNat& authored_slot) {
  switch (process.family()) {
    case ArrivalFamily::deterministic_trace:
      return next_trace_batch(process, authored_slot);
    case ArrivalFamily::periodic_global_phase:
    case ArrivalFamily::periodic_source_delays:
      return next_periodic_batch(process, authored_slot);
    case ArrivalFamily::independent_marked_renewal:
      return next_marked_renewal_batch(process, authored_slot);
    case ArrivalFamily::independent_private_markov_renewal:
      return next_private_markov_batch(process, authored_slot);
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return next_shared_round_batch(process, authored_slot);
    case ArrivalFamily::iid_independent_bernoulli:
    case ArrivalFamily::iid_count_table:
    case ArrivalFamily::iid_independent_poisson:
    case ArrivalFamily::iid_mixed_poisson:
      // The public family-specific names above are compatibility guards.  All
      // schema-4 IID laws use C09's same authenticated cursor transition.
      return next_arrival_step(process, authored_slot);
  }
  return internal_fail<ArrivalStep>(
      "physical_arrival_family_invalid",
      "the configured arrival process has an unknown family tag");
}

[[nodiscard]] Result<void> validate_feasible_schedule(
    const ConstraintDescriptor& descriptor, const Schedule& schedule) {
  if (!schedule.dimension().matches(descriptor)) {
    return fail<void>("physical_schedule_dimension_mismatch",
                      "the schedule is not bound to the configured service "
                      "geometry");
  }
  return std::visit(
      [&schedule]<typename Constraint>(const Constraint& constraint)
          -> Result<void> {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          std::vector<std::uint8_t> inputs(constraint.inputs.size(), 0U);
          std::vector<std::uint8_t> outputs(constraint.outputs.size(), 0U);
          for (const auto& edge : constraint.edges) {
            if (!schedule.at(edge.queue)) {
              continue;
            }
            if (inputs.at(edge.input.ordinal()) != 0U ||
                outputs.at(edge.output.ordinal()) != 0U) {
              return fail<void>("physical_schedule_infeasible",
                                "two selected crossbar edges share a port");
            }
            inputs[edge.input.ordinal()] = 1U;
            outputs[edge.output.ordinal()] = 1U;
          }
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          std::vector<const ResolvedInterval*> selected;
          for (const auto& interval : constraint.intervals) {
            if (schedule.at(interval.queue)) {
              selected.push_back(&interval);
            }
          }
          std::ranges::sort(selected, [](const auto* left, const auto* right) {
            if (left->left != right->left) return left->left < right->left;
            if (left->right != right->right) return left->right < right->right;
            return left->queue < right->queue;
          });
          for (std::size_t index = 1U; index < selected.size(); ++index) {
            if (!(selected[index - 1U]->right <= selected[index]->left)) {
              return fail<void>("physical_schedule_infeasible",
                                "two selected half-open intervals overlap");
            }
          }
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          std::vector<std::uint8_t> vertices(constraint.vertices.size(), 0U);
          for (const auto& link : constraint.links) {
            if (!schedule.at(link.queue)) {
              continue;
            }
            if (vertices.at(link.u.ordinal()) != 0U ||
                vertices.at(link.v.ordinal()) != 0U) {
              return fail<void>("physical_schedule_infeasible",
                                "two selected links share an endpoint");
            }
            vertices[link.u.ordinal()] = 1U;
            vertices[link.v.ordinal()] = 1U;
          }
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          for (const auto& pair : constraint.conflicts) {
            if (schedule.at(pair.first) && schedule.at(pair.second)) {
              return fail<void>("physical_schedule_infeasible",
                                "both endpoints of a conflict are selected");
            }
          }
        } else {
          std::vector<BigInt> used(constraint.resources.size(), BigInt{0});
          for (const auto& demand : constraint.demands) {
            if (!schedule.at(demand.queue)) {
              continue;
            }
            for (std::size_t resource = 0U; resource < used.size();
                 ++resource) {
              used[resource] += demand.demand.at(resource).value();
              if (used[resource] > constraint.capacity.at(resource).value()) {
                return fail<void>("physical_schedule_infeasible",
                                  "selected demands exceed a capacity");
              }
            }
          }
        }
        return Result<void>::success();
      },
      descriptor.value());
}

[[nodiscard]] Result<void> validate_decision(
    const ResolvedInstance& instance, const Backlog& backlog,
    const ScheduleDecision& decision) {
  if (!(decision.schedule.dimension() == backlog.dimension()) ||
      !(decision.eligibility.dimension() == backlog.dimension()) ||
      decision.schedule.size() != backlog.size() ||
      decision.eligibility.size() != backlog.size()) {
    return fail<void>("physical_decision_dimension_mismatch",
                      "the MaxWeight decision is not bound to the prestate "
                      "queue dimension");
  }
  if (decision.family != instance.service_identity().family ||
      decision.family != instance.constraint().family() ||
      decision.backend_id != instance.service_identity().optimizer) {
    return fail<void>("physical_decision_backend_mismatch",
                      "the MaxWeight decision names a different exact family "
                      "or backend");
  }

  BigNat primary(0U);
  std::vector<BigNat> primary_values(backlog.values().begin(),
                                     backlog.values().end());
  for (std::size_t ordinal = 0U; ordinal < backlog.size(); ++ordinal) {
    const bool expected_eligible = !backlog.values()[ordinal].is_zero();
    if (decision.eligibility.bytes()[ordinal] !=
            static_cast<std::uint8_t>(expected_eligible) ||
        (decision.schedule.bytes()[ordinal] != 0U && !expected_eligible)) {
      return fail<void>("physical_decision_eligibility_mismatch",
                        "the returned schedule is not eligibility-pruned at "
                        "the completed boundary state");
    }
    if (decision.schedule.bytes()[ordinal] != 0U) {
      primary += backlog.values()[ordinal];
    }
  }
  if (primary != decision.primary_objective) {
    return fail<void>("physical_decision_primary_objective_mismatch",
                      "the recorded primary objective is not the exact "
                      "selected backlog sum");
  }

  auto primary_vector = PrimaryWeights::from_values(
      backlog.dimension(), std::move(primary_values));
  if (!primary_vector) {
    return Result<void>::failure(primary_vector.error());
  }
  auto weights = compose_lexicographic_weights(
      primary_vector.value(), instance.priority(), decision.eligibility);
  if (!weights) {
    return Result<void>::failure(weights.error());
  }
  BigNat composite(0U);
  BigNat priority(0U);
  for (std::size_t ordinal = 0U; ordinal < backlog.size(); ++ordinal) {
    if (decision.schedule.bytes()[ordinal] != 0U) {
      composite += weights.value().values()[ordinal];
      priority += weights.value().secondary_weights()[ordinal];
    }
  }
  if (composite != decision.composite_objective ||
      priority != decision.priority_code) {
    return fail<void>("physical_decision_lexicographic_objective_mismatch",
                      "the schedule does not reproduce its exact configured "
                      "tie-breaking evidence");
  }
  if (decision.accounting.query_kind() != OptimizerQueryKind::ordinary ||
      decision.accounting.target().has_value() ||
      decision.accounting.exhausted() ||
      decision.accounting.call_ordinal().is_zero() ||
      decision.accounting.family() !=
          std::optional<ServiceFamily>(decision.family)) {
    return fail<void>("physical_decision_accounting_mismatch",
                      "the schedule is not tied to one completed ordinary "
                      "exact-optimizer call");
  }
  return validate_feasible_schedule(instance.constraint(), decision.schedule);
}

[[nodiscard]] Result<void> validate_state_process_bank(
    const ResolvedInstance& instance, const PhysicalState& state,
    ArrivalProcess& process, const RngBank& bank,
    const OptimizerExecutionContext& context) {
  if (!detail::PhysicalEngineAccess::initialized(bank) ||
      bank.combined_input() != instance.fingerprints().combined ||
      state.run_identity().combined_input != instance.fingerprints().combined ||
      state.run_identity().seed != bank.seed() ||
      state.run_identity().instance_key != bank.instance_key().digest() ||
      state.run_identity().path_or_replication_id != BigNat(0U) ||
      !same_owner(detail::PhysicalEngineAccess::owner(state),
                  detail::PhysicalEngineAccess::owner(bank))) {
    return fail<void>("physical_rng_bank_identity_mismatch",
                      "the state and RNG bank do not belong to this cold "
                      "physical-reference run");
  }
  auto expected_key = make_physical_reference_instance_key(
      instance.fingerprints().combined, BigNat(0U));
  if (!expected_key || expected_key.value() != bank.instance_key() ||
      detail::PhysicalEngineAccess::initial_rng(bank).derivation_stage() !=
          StageTag::initial_joint_atom ||
      detail::PhysicalEngineAccess::tie_rng(bank).derivation_stage() !=
          StageTag::tie_resolution ||
      state.run_identity().initial_stream_identity !=
          detail::PhysicalEngineAccess::initial_rng(bank).stream_identity() ||
      state.run_identity().tie_stream_identity !=
          detail::PhysicalEngineAccess::tie_rng(bank).stream_identity()) {
    return fail<void>(
        "physical_stage_stream_identity_mismatch",
        "the physical boundary does not retain this bank's exact staged "
        "stream identities");
  }
  if (!state.backlog().dimension().matches(instance) ||
      !context.active() ||
      !context.matches_dimension(state.backlog().dimension())) {
    return fail<void>("physical_optimizer_context_mismatch",
                      "the state or optimizer context is not bound to the "
                      "resolved instance");
  }
  if (instance.timing() != TimingConvention::early_service_late_admission ||
      !is_empty_object(state.controller_memory()) ||
      !is_empty_object(state.static_context())) {
    return fail<void>("physical_controller_convention_mismatch",
                      "C12 accepts only the configured base controller and "
                      "early-service/late-admission convention");
  }

  auto retained_law = detail::CompiledArrivalAccess::get(instance.arrival());
  if (!retained_law) {
    return Result<void>::failure(retained_law.error());
  }
  const auto core = detail::ArrivalCoreAccess::process_core(process);
  if (!core || !core->law || !core->rng || !core->state || !core->owner) {
    return fail<void>("physical_arrival_process_moved_from",
                      "the physical state has no live aligned arrival cursor");
  }
  const auto& retained_core =
      detail::ArrivalCoreAccess::law_core(*retained_law.value());
  const auto phase_core =
      detail::ArrivalCoreAccess::phase_core(state.arrival_phase());
  if (!same_owner(core->law, retained_core) ||
      core->law->binding != state.run_identity().arrival_binding ||
      process.family() != core->law->binding.family ||
      phase_core->binding != core->law->binding ||
      phase_core->family != core->law->binding.family ||
      !same_owner(phase_core->cursor_owner, core->owner) ||
      !same_owner(phase_core->cursor_state, core->state) ||
      phase_core->next_authored_slot != core->expected_slot ||
      core->expected_slot != state.boundary_index() ||
      core->realization_identity !=
          state.run_identity().arrival_realization_identity ||
      core->rng->derivation_stage() != StageTag::configured_arrival ||
      core->rng->stream_identity() !=
          state.run_identity().configured_arrival_stream_identity ||
      core->rng->stream_identity() !=
          bank.configured_arrival_stream_identity()) {
    return fail<void>("physical_state_cursor_identity_mismatch",
                      "the completed boundary state and arrival cursor are "
                      "not the same aligned process realization");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_arrival_step(
    const PhysicalState& pre_state, const ArrivalStep& step,
    const ArrivalProcess& staged_process) {
  const auto core = detail::ArrivalCoreAccess::process_core(staged_process);
  BigNat successor = pre_state.boundary_index();
  ++successor;
  if (!core || !core->law || !core->rng || !step.batch.binding().has_value() ||
      step.authored_slot != pre_state.boundary_index() ||
      step.physical_arrival_epoch() != successor ||
      *step.batch.binding() != pre_state.run_identity().arrival_binding ||
      step.law_digest !=
          pre_state.run_identity().arrival_binding.law_digest ||
      step.realization_identity !=
          pre_state.run_identity().arrival_realization_identity ||
      !same_phase(step.phase_before, pre_state.arrival_phase()) ||
      !arrival_phases_share_cursor(step.phase_before, step.phase_after) ||
      core->expected_slot != successor ||
      core->realization_identity != step.realization_identity) {
    return fail<void>("physical_arrival_step_malformed",
                      "the configured arrival step is not the unique aligned "
                      "late-admission transition for this slot");
  }
  const auto after = detail::ArrivalCoreAccess::phase_core(step.phase_after);
  if (!same_owner(after->cursor_owner, core->owner) ||
      !same_owner(after->cursor_state, core->state) ||
      after->next_authored_slot != core->expected_slot ||
      after->binding != core->law->binding) {
    return fail<void>("physical_arrival_successor_mismatch",
                      "the arrival step's successor phase does not match its "
                      "staged cursor");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_transition(
    const PhysicalState& pre_state, const ScheduleDecision& decision,
    const Schedule& departure, const ArrivalStep& arrival,
    const PhysicalState& post_state) {
  BigNat successor = pre_state.boundary_index();
  ++successor;
  if (post_state.boundary_index() != successor ||
      post_state.run_identity() != pre_state.run_identity() ||
      !same_owner(detail::PhysicalEngineAccess::owner(pre_state),
                  detail::PhysicalEngineAccess::owner(post_state)) ||
      !source_nodes_equal(pre_state.controller_memory(),
                          post_state.controller_memory()) ||
      !source_nodes_equal(pre_state.static_context(),
                          post_state.static_context()) ||
      !same_phase(arrival.phase_after, post_state.arrival_phase())) {
    return fail<void>("physical_poststate_transition_mismatch",
                      "the staged poststate is not the completed next boundary");
  }
  auto expected_departure =
      compute_actual_departure(pre_state.backlog(), decision.schedule);
  if (!expected_departure || expected_departure.value() != departure) {
    return fail<void>("physical_departure_mismatch",
                      "the recorded actual departure is not s*1{Q>0}");
  }
  auto expected_backlog = apply_queue_recursion(
      pre_state.backlog(), decision.schedule, arrival.batch);
  if (!expected_backlog ||
      expected_backlog.value() != post_state.backlog()) {
    return fail<void>("physical_queue_transition_mismatch",
                      "the poststate backlog does not satisfy Q'=Q-D+A");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_edge_arrival_evidence(
    const PhysicalState& pre_state, const ArrivalStep& arrival,
    const PhysicalState& post_state) {
  BigNat successor = pre_state.boundary_index();
  ++successor;
  if (!arrival.batch.binding().has_value() ||
      arrival.authored_slot != pre_state.boundary_index() ||
      arrival.physical_arrival_epoch() != successor ||
      *arrival.batch.binding() != pre_state.run_identity().arrival_binding ||
      arrival.law_digest != pre_state.run_identity().arrival_binding.law_digest ||
      arrival.realization_identity !=
          pre_state.run_identity().arrival_realization_identity ||
      !same_phase(arrival.phase_before, pre_state.arrival_phase()) ||
      !same_phase(arrival.phase_after, post_state.arrival_phase()) ||
      !arrival_phases_share_cursor(arrival.phase_before,
                                   arrival.phase_after)) {
    return fail<void>(
        "physical_edge_arrival_evidence_mismatch",
        "the arrival evidence does not describe the unique transition "
        "between the supplied physical boundary states");
  }
  return Result<void>::success();
}

[[nodiscard]] std::vector<PhysicalMarkEvidence> base_mark_evidence() {
  return {
      {PhysicalMarkKind::controller_memory_before,
       RevealStage::boundary_observation},
      {PhysicalMarkKind::static_context, RevealStage::boundary_observation},
      {PhysicalMarkKind::predictive_phase_before,
       RevealStage::boundary_observation},
      {PhysicalMarkKind::schedule, RevealStage::decision_completed},
      {PhysicalMarkKind::departure, RevealStage::decision_completed},
      {PhysicalMarkKind::controller_memory_after,
       RevealStage::decision_completed},
      {PhysicalMarkKind::arrival_batch, RevealStage::late_admission},
      {PhysicalMarkKind::predictive_phase_after,
       RevealStage::late_admission},
  };
}

[[nodiscard]] std::string json_escape(std::string_view text) {
  constexpr char hex[] = "0123456789abcdef";
  std::string encoded;
  encoded.push_back('"');
  for (const unsigned char byte : text) {
    switch (byte) {
      case '"': encoded += "\\\""; break;
      case '\\': encoded += "\\\\"; break;
      case '\b': encoded += "\\b"; break;
      case '\f': encoded += "\\f"; break;
      case '\n': encoded += "\\n"; break;
      case '\r': encoded += "\\r"; break;
      case '\t': encoded += "\\t"; break;
      default:
        if (byte < 0x20U) {
          encoded += "\\u00";
          encoded.push_back(hex[(byte >> 4U) & 0x0fU]);
          encoded.push_back(hex[byte & 0x0fU]);
        } else {
          encoded.push_back(static_cast<char>(byte));
        }
    }
  }
  encoded.push_back('"');
  return encoded;
}

[[nodiscard]] std::string serialize_source_node(const SourceNode& node) {
  switch (node.kind()) {
    case SourceNodeKind::null_value:
      return "null";
    case SourceNodeKind::boolean:
      return *node.boolean_value() ? "true" : "false";
    case SourceNodeKind::number:
      return *node.number_lexeme();
    case SourceNodeKind::string:
      return json_escape(*node.string_value());
    case SourceNodeKind::array: {
      std::string result{"["};
      bool first = true;
      for (const SourceNode& item : node.array_items()) {
        if (!first) result.push_back(',');
        first = false;
        result += serialize_source_node(item);
      }
      result.push_back(']');
      return result;
    }
    case SourceNodeKind::object: {
      std::vector<const SourceObjectMember*> members;
      members.reserve(node.object_members().size());
      for (const auto& member : node.object_members()) members.push_back(&member);
      std::ranges::sort(members, [](const auto* left, const auto* right) {
        return left->key < right->key;
      });
      std::string result{"{"};
      bool first = true;
      for (const auto* member : members) {
        if (!first) result.push_back(',');
        first = false;
        result += json_escape(member->key);
        result.push_back(':');
        result += serialize_source_node(member->value);
      }
      result.push_back('}');
      return result;
    }
  }
  return "null";
}

[[nodiscard]] std::string serialize_label(const QueueId& id) {
  const TypedLabel& label = id.label();
  if (const BigNat* numeric = label.numeric_value(); numeric != nullptr) {
    return "{\"type\":\"number\",\"value\":" +
           json_escape(numeric->to_decimal_string()) + "}";
  }
  return "{\"type\":\"string\",\"value\":" +
         json_escape(*label.text_value()) + "}";
}

[[nodiscard]] std::string bytes_hex(std::span<const std::byte> bytes) {
  constexpr char hex[] = "0123456789abcdef";
  std::string result;
  result.reserve(bytes.size() * 2U);
  for (const std::byte value : bytes) {
    const auto byte = std::to_integer<std::uint8_t>(value);
    result.push_back(hex[(byte >> 4U) & 0x0fU]);
    result.push_back(hex[byte & 0x0fU]);
  }
  return result;
}

[[nodiscard]] std::string serialize_state(
    const PhysicalState& state, std::span<const QueueId> queue_ids) {
  std::string result = "{\"boundary\":" +
                       json_escape(state.boundary_index().to_decimal_string()) +
                       ",\"queues\":[";
  for (std::size_t index = 0U; index < state.backlog().size(); ++index) {
    if (index != 0U) result.push_back(',');
    result += "{\"id\":" + serialize_label(queue_ids[index]) +
              ",\"backlog\":" +
              json_escape(state.backlog().values()[index].to_decimal_string()) +
              "}";
  }
  result += "],\"controller\":" +
            serialize_source_node(state.controller_memory());
  result += ",\"static_context\":" +
            serialize_source_node(state.static_context());
  result += ",\"phase\":{\"family\":" +
            json_escape(std::string(to_string(
                arrival_phase_family(state.arrival_phase())))) +
            ",\"digest\":" +
            json_escape(arrival_phase_digest(state.arrival_phase()).value().hex()) +
            ",\"canonical\":" +
            json_escape(bytes_hex(
                arrival_phase_canonical_state(state.arrival_phase()))) +
            "}}";
  return result;
}

[[nodiscard]] std::string serialize_bits(std::span<const std::uint8_t> bits) {
  std::string result{"["};
  for (std::size_t index = 0U; index < bits.size(); ++index) {
    if (index != 0U) result.push_back(',');
    result.push_back(bits[index] == 0U ? '0' : '1');
  }
  result.push_back(']');
  return result;
}

[[nodiscard]] std::string serialize_optional_nat(
    const std::optional<BigNat>& value) {
  return value.has_value() ? json_escape(value->to_decimal_string()) : "null";
}

[[nodiscard]] std::string serialize_accounting(
    const SearchAccounting& accounting) {
  std::string result = "{\"call_ordinal\":" +
                       json_escape(accounting.call_ordinal().to_decimal_string()) +
                       ",\"effective_limit\":" +
                       serialize_optional_nat(
                           accounting.effective_per_call_limit()) +
                       ",\"completed_expansions\":" +
                       json_escape(
                           accounting.completed_expansions().to_decimal_string()) +
                       ",\"query_kind\":" +
                       json_escape(std::string(to_string(
                           accounting.query_kind()))) +
                       ",\"family\":";
  if (accounting.family().has_value()) {
    result += json_escape(std::string(to_string(*accounting.family())));
  } else {
    result += "null";
  }
  result += ",\"target\":";
  if (accounting.target().has_value()) {
    result += json_escape(std::to_string(accounting.target()->ordinal()));
  } else {
    result += "null";
  }
  result += ",\"exhausted\":";
  result += accounting.exhausted() ? "true}" : "false}";
  return result;
}

[[nodiscard]] std::string reveal_stage_name(RevealStage stage) {
  switch (stage) {
    case RevealStage::boundary_observation: return "boundary_observation";
    case RevealStage::decision_completed: return "decision_completed";
    case RevealStage::late_admission: return "late_admission";
  }
  return "unknown";
}

[[nodiscard]] std::string mark_kind_name(PhysicalMarkKind kind) {
  switch (kind) {
    case PhysicalMarkKind::controller_memory_before:
      return "controller_memory_before";
    case PhysicalMarkKind::controller_memory_after:
      return "controller_memory_after";
    case PhysicalMarkKind::static_context: return "static_context";
    case PhysicalMarkKind::predictive_phase_before:
      return "predictive_phase_before";
    case PhysicalMarkKind::predictive_phase_after:
      return "predictive_phase_after";
    case PhysicalMarkKind::schedule: return "schedule";
    case PhysicalMarkKind::departure: return "departure";
    case PhysicalMarkKind::arrival_batch: return "arrival_batch";
  }
  return "unknown";
}

using Resolver = std::function<Result<ScheduleDecision>(
    const ResolvedInstance&, const Backlog&, const TieContext&,
    OptimizerExecutionContext&)>;
using Arrival =
    std::function<Result<ArrivalStep>(ArrivalProcess&, const BigNat&)>;
using PostArrivalValidator =
    std::function<Result<void>(const ArrivalStep&)>;

[[nodiscard]] Result<PhysicalEdge> execute_slot_core(
    const ResolvedInstance& instance, PhysicalState& state,
    ArrivalProcess& process, RngBank& bank,
    OptimizerExecutionContext& optimizer_context, const Resolver& resolver,
    const Arrival& arrival, const PostArrivalValidator& post_validate) {
  if (!resolver || !arrival || !post_validate) {
    return internal_fail<PhysicalEdge>(
        "physical_slot_service_missing",
        "the closed physical slot stage table is incomplete");
  }
  auto boundary = validate_state_process_bank(instance, state, process, bank,
                                               optimizer_context);
  if (!boundary) {
    return Result<PhysicalEdge>::failure(boundary.error());
  }
  const auto original_core = detail::ArrivalCoreAccess::process_core(process);
  ArrivalProcessLease lease(original_core);
  if (!lease.acquired()) {
    return fail<PhysicalEdge>(
        "physical_arrival_cursor_busy",
        "one physical arrival cursor cannot execute concurrently or "
        "reentrantly");
  }

  try {
    // Snapshot and resolve before a staged configured-arrival transition is
    // even constructed. No fresh A(t+1) value can reach this call.
    PhysicalState pre_state = state;
    auto decision = resolver(instance, pre_state.backlog(),
                             TieContext::configured_priority(),
                             optimizer_context);
    if (!decision) {
      return Result<PhysicalEdge>::failure(decision.error());
    }
    auto decision_valid =
        validate_decision(instance, pre_state.backlog(), decision.value());
    if (!decision_valid) {
      return Result<PhysicalEdge>::failure(decision_valid.error());
    }

    auto staged = stage_arrival_process(original_core, bank);
    if (!staged) {
      return Result<PhysicalEdge>::failure(staged.error());
    }
    auto step = arrival(staged.value(), pre_state.boundary_index());
    if (!step) {
      return Result<PhysicalEdge>::failure(step.error());
    }
    auto step_valid =
        validate_arrival_step(pre_state, step.value(), staged.value());
    if (!step_valid) {
      return Result<PhysicalEdge>::failure(step_valid.error());
    }
    auto injected = post_validate(step.value());
    if (!injected) {
      return Result<PhysicalEdge>::failure(injected.error());
    }

    auto next_backlog = apply_queue_recursion(
        pre_state.backlog(), decision.value().schedule, step.value().batch);
    if (!next_backlog) {
      return Result<PhysicalEdge>::failure(next_backlog.error());
    }
    auto departure = compute_actual_departure(pre_state.backlog(),
                                               decision.value().schedule);
    if (!departure) {
      return Result<PhysicalEdge>::failure(departure.error());
    }
    BigNat next_boundary = pre_state.boundary_index();
    ++next_boundary;
    PhysicalState post_state = detail::PhysicalEngineAccess::make_state(
        std::move(next_backlog.value()), std::move(next_boundary),
        pre_state.controller_memory(), pre_state.static_context(),
        step.value().phase_after, pre_state.run_identity(),
        detail::PhysicalEngineAccess::owner(pre_state));
    auto transition = validate_transition(
        pre_state, decision.value(), departure.value(), step.value(),
        post_state);
    if (!transition) {
      return Result<PhysicalEdge>::failure(transition.error());
    }

    PhysicalEdge edge = make_physical_edge(pre_state, decision.value(),
                                           step.value(), post_state);
    Result<PhysicalEdge> result =
        Result<PhysicalEdge>::success(std::move(edge));
    static_assert(std::is_nothrow_move_assignable_v<ArrivalProcess>);
    static_assert(std::is_nothrow_move_assignable_v<PhysicalState>);
    process = std::move(staged.value());
    state = std::move(post_state);
    return result;
  } catch (const std::bad_alloc&) {
    return allocation_fail<PhysicalEdge>("executing one physical slot");
  } catch (const std::exception&) {
    return internal_fail<PhysicalEdge>(
        "physical_slot_invariant_failure",
        "one physical slot raised an unexpected exception before commit");
  } catch (...) {
    return internal_fail<PhysicalEdge>(
        "physical_slot_invariant_failure",
        "one physical slot raised a nonstandard exception before commit");
  }
}

}  // namespace

RngBankSnapshot RngBank::snapshot() const {
  const RngCheckpoint initial = initial_joint_atom_.checkpoint();
  const RngCheckpoint tie = tie_resolution_.checkpoint();
  std::optional<Digest256> active_cursor;
  std::optional<BigNat> active_residence;
  std::optional<BigNat> active_slot;
  if (temporal_advance_address_.has_value()) {
    active_cursor = temporal_advance_address_->cursor_digest;
    active_residence = temporal_advance_address_->residence_index;
    active_slot = temporal_advance_address_->slot_offset;
  }
  auto state = std::make_shared<const detail::RngBankSnapshotState>(
      detail::RngBankSnapshotState{
          kRngBankSnapshotFormatVersion,
          temporal_path_,
          initialized_,
          combined_input_,
          seed_,
          instance_key_.digest(),
          configured_arrival_stream_identity_,
          temporal_framework_digest_,
          reduced_initial_law_digest_,
          initial,
          tie,
          std::move(active_cursor),
          std::move(active_residence),
          std::move(active_slot)});
  return RngBankSnapshot(initial.consumed_words(), tie.consumed_words(),
                         initialized_, std::move(state));
}

bool operator==(const RngBankSnapshot& left,
                const RngBankSnapshot& right) {
  if (left.initial_joint_atom_words != right.initial_joint_atom_words ||
      left.tie_resolution_words != right.tie_resolution_words ||
      left.initialized != right.initialized) {
    return false;
  }
  // Retain C12's diagnostic equality for physical/legacy snapshots.  C20
  // temporal snapshots additionally compare their complete owned restore
  // records so route or stream mismatches cannot look equal in temporal
  // replay tests.
  if (!left.state_ || !right.state_) {
    return true;
  }
  const detail::RngBankSnapshotState& lhs = *left.state_;
  const detail::RngBankSnapshotState& rhs = *right.state_;
  if (!lhs.temporal_path || !rhs.temporal_path) {
    return true;
  }
  return lhs.format_version == rhs.format_version &&
         lhs.temporal_path == rhs.temporal_path &&
         lhs.initialized == rhs.initialized &&
         lhs.combined_input == rhs.combined_input && lhs.seed == rhs.seed &&
         lhs.instance_key_digest == rhs.instance_key_digest &&
         lhs.configured_arrival_stream_identity ==
             rhs.configured_arrival_stream_identity &&
         lhs.temporal_framework_digest == rhs.temporal_framework_digest &&
         lhs.reduced_initial_law_digest == rhs.reduced_initial_law_digest &&
         same_rng_checkpoint(lhs.initial_joint_atom,
                             rhs.initial_joint_atom) &&
         same_rng_checkpoint(lhs.tie_resolution, rhs.tie_resolution) &&
         lhs.active_cursor_digest == rhs.active_cursor_digest &&
         lhs.active_residence_index == rhs.active_residence_index &&
         lhs.active_slot_offset == rhs.active_slot_offset;
}

Result<RngBank> RngBank::for_physical_reference(
    const ResolvedInstance& instance, const MasterSeed seed) {
  try {
    BigNat path_id(0U);
    auto key = make_physical_reference_instance_key(
        instance.fingerprints().combined, path_id);
    if (!key) {
      return Result<RngBank>::failure(key.error());
    }
    DeterministicRng initial = derive_rng_stream(
        seed, StageTag::initial_joint_atom, key.value());
    DeterministicRng tie =
        derive_rng_stream(seed, StageTag::tie_resolution, key.value());
    DeterministicRng arrival =
        derive_rng_stream(seed, StageTag::configured_arrival, key.value());
    Digest256 arrival_identity = arrival.stream_identity();
    auto owner = std::make_shared<const detail::PhysicalRunOwner>();
    return Result<RngBank>::success(RngBank(
        instance.fingerprints().combined, seed, std::move(key.value()),
        std::move(initial), std::move(tie), std::move(arrival_identity),
        std::move(owner), false, std::nullopt, std::nullopt));
  } catch (const std::bad_alloc&) {
    return allocation_fail<RngBank>("constructing the physical RNG bank");
  } catch (const std::exception&) {
    return internal_fail<RngBank>(
        "physical_rng_bank_construction_failure",
        "the physical-reference stage streams could not be derived");
  }
}

Result<RngBank> detail::C20RngAccess::make_temporal_bank(
    const ResolvedInstance& instance,
    const Digest256& audited_framework_digest,
    const Digest256& reduced_initial_law_digest, const MasterSeed seed) {
  try {
    const BigNat path_id(0U);
    auto key = make_temporal_path_instance_key(
        audited_framework_digest, reduced_initial_law_digest, path_id);
    if (!key) {
      return Result<RngBank>::failure(key.error());
    }
    DeterministicRng initial = derive_rng_stream(
        seed, StageTag::initial_joint_atom, key.value());
    DeterministicRng tie =
        derive_rng_stream(seed, StageTag::tie_resolution, key.value());
    DeterministicRng arrival = derive_rng_stream(
        seed, StageTag::configured_arrival, key.value());
    Digest256 arrival_identity = arrival.stream_identity();
    auto owner = std::make_shared<const detail::PhysicalRunOwner>();
    return Result<RngBank>::success(RngBank(
        instance.fingerprints().combined, seed, std::move(key.value()),
        std::move(initial), std::move(tie), std::move(arrival_identity),
        std::move(owner), true, audited_framework_digest,
        reduced_initial_law_digest));
  } catch (const std::bad_alloc&) {
    return allocation_fail<RngBank>("constructing the temporal-path RNG bank");
  } catch (const std::exception&) {
    return internal_fail<RngBank>(
        "temporal_rng_bank_construction_failure",
        "the temporal-path stage streams could not be derived");
  }
}

Result<RngBank> detail::C20RngAccess::restore_temporal_bank(
    const RngBankSnapshot& snapshot_value) {
  const auto& state = snapshot_value.state_;
  if (!state || state->format_version != kRngBankSnapshotFormatVersion) {
    return fail<RngBank>(
        "temporal_rng_snapshot_version_mismatch",
        "the RNG-bank snapshot has no supported owned format");
  }
  if (!state->temporal_path ||
      !state->temporal_framework_digest.has_value() ||
      !state->reduced_initial_law_digest.has_value()) {
    return fail<RngBank>(
        "temporal_rng_snapshot_route_mismatch",
        "the supplied snapshot does not belong to a temporal path");
  }
  if (state->active_cursor_digest.has_value() ||
      state->active_residence_index.has_value() ||
      state->active_slot_offset.has_value()) {
    return fail<RngBank>(
        "temporal_rng_snapshot_active_advance",
        "a temporal RNG snapshot cannot be restored from inside an active "
        "slot advance");
  }
  if (snapshot_value.initial_joint_atom_words !=
          state->initial_joint_atom.consumed_words() ||
      snapshot_value.tie_resolution_words !=
          state->tie_resolution.consumed_words() ||
      snapshot_value.initialized != state->initialized) {
    return fail<RngBank>(
        "temporal_rng_snapshot_counter_mismatch",
        "the public RNG counters do not match the owned stream checkpoints");
  }
  try {
    const BigNat path_id(0U);
    auto key = make_temporal_path_instance_key(
        *state->temporal_framework_digest,
        *state->reduced_initial_law_digest, path_id);
    if (!key) {
      return Result<RngBank>::failure(key.error());
    }
    if (key.value().digest() != state->instance_key_digest) {
      return fail<RngBank>(
          "temporal_rng_snapshot_root_mismatch",
          "the snapshot route does not reproduce its temporal root key");
    }
    DeterministicRng initial = derive_rng_stream(
        state->seed, StageTag::initial_joint_atom, key.value());
    DeterministicRng tie = derive_rng_stream(
        state->seed, StageTag::tie_resolution, key.value());
    DeterministicRng arrival = derive_rng_stream(
        state->seed, StageTag::configured_arrival, key.value());
    if (arrival.stream_identity() !=
        state->configured_arrival_stream_identity) {
      return fail<RngBank>(
          "temporal_rng_snapshot_stream_mismatch",
          "the snapshot route does not reproduce its configured-arrival "
          "stream identity");
    }
    auto initial_restore = initial.restore(state->initial_joint_atom);
    if (!initial_restore) {
      return Result<RngBank>::failure(initial_restore.error());
    }
    auto tie_restore = tie.restore(state->tie_resolution);
    if (!tie_restore) {
      return Result<RngBank>::failure(tie_restore.error());
    }
    auto owner = std::make_shared<const detail::PhysicalRunOwner>();
    RngBank bank(
        state->combined_input, state->seed, std::move(key.value()),
        std::move(initial), std::move(tie),
        state->configured_arrival_stream_identity, std::move(owner), true,
        state->temporal_framework_digest,
        state->reduced_initial_law_digest);
    bank.initialized_ = snapshot_value.initialized;
    return Result<RngBank>::success(std::move(bank));
  } catch (const std::bad_alloc&) {
    return allocation_fail<RngBank>("restoring the temporal-path RNG bank");
  } catch (const std::exception&) {
    return internal_fail<RngBank>(
        "temporal_rng_snapshot_restore_failure",
        "the temporal-path RNG bank could not be restored");
  }
}

DeterministicRng& detail::C20RngAccess::initial_joint_atom(
    RngBank& bank) noexcept {
  return bank.initial_joint_atom_;
}

bool detail::C20RngAccess::initialized(const RngBank& bank) noexcept {
  return bank.initialized_;
}

Result<void> detail::C20RngAccess::mark_initialized(RngBank& bank) {
  if (!bank.temporal_path_ ||
      !bank.temporal_framework_digest_.has_value() ||
      !bank.reduced_initial_law_digest_.has_value()) {
    return fail<void>(
        "temporal_rng_bank_route_mismatch",
        "initial selection requires a temporal-path RNG bank");
  }
  if (bank.initialized_) {
    return fail<void>(
        "temporal_rng_bank_already_initialized",
        "one temporal-path bank cannot select a second initial atom");
  }
  if (bank.temporal_advance_address_.has_value()) {
    return fail<void>(
        "temporal_rng_bank_active_advance",
        "initial selection is invalid during an active slot advance");
  }
  bank.initialized_ = true;
  return Result<void>::success();
}

Result<void> detail::C20RngAccess::bind_advance_address(
    RngBank& bank, const Digest256& cursor_digest,
    const BigNat& residence_index, const BigNat& slot_offset) {
  if (!bank.temporal_path_ ||
      !bank.temporal_framework_digest_.has_value() ||
      !bank.reduced_initial_law_digest_.has_value()) {
    return fail<void>(
        "temporal_rng_bank_route_mismatch",
        "a residence advance requires a temporal-path RNG bank");
  }
  if (!bank.initialized_) {
    return fail<void>(
        "temporal_rng_bank_not_initialized",
        "a residence advance requires completed initial-law selection");
  }
  if (bank.temporal_advance_address_.has_value()) {
    return fail<void>(
        "temporal_rng_bank_active_advance",
        "a temporal RNG bank already has an active slot address");
  }
  try {
    bank.temporal_advance_address_.emplace(
        RngBank::TemporalAdvanceAddress{cursor_digest, residence_index,
                                        slot_offset});
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return allocation_fail<void>("binding a temporal slot address");
  }
}

void detail::C20RngAccess::clear_advance_address(RngBank& bank) noexcept {
  bank.temporal_advance_address_.reset();
}

const Digest256& detail::C20RngAccess::temporal_root_fingerprint(
    const RngBank& bank) noexcept {
  return bank.instance_key_.digest();
}

bool same_physical_state(const PhysicalState& left,
                         const PhysicalState& right) noexcept {
  return left.boundary_index_ == right.boundary_index_ &&
         std::ranges::equal(left.backlog_.values(), right.backlog_.values()) &&
         source_nodes_equal(left.controller_memory_, right.controller_memory_) &&
         source_nodes_equal(left.static_context_, right.static_context_) &&
         same_phase(left.arrival_phase_, right.arrival_phase_) &&
         left.run_identity_ == right.run_identity_;
}

bool same_physical_edge(const PhysicalEdge& left,
                        const PhysicalEdge& right) noexcept {
  return left.slot_index() == right.slot_index() &&
         same_physical_state(left.pre_state(), right.pre_state()) &&
         same_decision(left.decision(), right.decision()) &&
         std::ranges::equal(left.departure().bytes(),
                            right.departure().bytes()) &&
         same_arrival_step(left.arrival_step(), right.arrival_step()) &&
         same_physical_state(left.post_state(), right.post_state()) &&
         std::ranges::equal(left.marks(), right.marks());
}

Result<Schedule> compute_actual_departure(const Backlog& backlog,
                                          const Schedule& schedule) {
  if (!(backlog.dimension() == schedule.dimension()) ||
      backlog.size() != schedule.size()) {
    return fail<Schedule>("queue_recursion_dimension_mismatch",
                          "backlog and schedule dimensions must agree");
  }
  try {
    std::vector<std::uint8_t> departure;
    departure.reserve(backlog.size());
    for (std::size_t index = 0U; index < backlog.size(); ++index) {
      const std::uint8_t bit = schedule.bytes()[index];
      if (bit > 1U) {
        return fail<Schedule>("queue_recursion_schedule_not_binary",
                              "the supplied schedule contains a nonbinary "
                              "entry");
      }
      departure.push_back(
          bit != 0U && !backlog.values()[index].is_zero() ? 1U : 0U);
    }
    return Schedule::from_bytes(backlog.dimension(), std::move(departure));
  } catch (const std::bad_alloc&) {
    return allocation_fail<Schedule>("forming the actual departure mask");
  }
}

Result<Backlog> apply_queue_recursion(const Backlog& backlog,
                                      const Schedule& schedule,
                                      const ArrivalBatch& arrival_batch) {
  auto departure = compute_actual_departure(backlog, schedule);
  if (!departure) {
    return Result<Backlog>::failure(departure.error());
  }
  if (!arrival_batch.binding().has_value() ||
      arrival_batch.binding()->queue_cardinality != backlog.size() ||
      arrival_batch.binding()->timing !=
          TimingConvention::early_service_late_admission) {
    return fail<Backlog>("queue_recursion_arrival_binding_mismatch",
                         "the arrival batch is not bound to this queue "
                         "dimension and timing convention");
  }
  try {
    std::vector<BigNat> next(backlog.values().begin(), backlog.values().end());
    for (std::size_t index = 0U; index < next.size(); ++index) {
      auto after_service = checked_subtract(
          next[index], BigNat(departure.value().bytes()[index]));
      if (!after_service) {
        return Result<Backlog>::failure(after_service.error());
      }
      next[index] = std::move(after_service.value());
    }
    std::optional<std::size_t> previous;
    for (const ArrivalBatchEntry& entry : arrival_batch.entries()) {
      const std::size_t ordinal = entry.queue.ordinal();
      if (ordinal >= next.size() ||
          (previous.has_value() && ordinal <= *previous) ||
          entry.count.is_zero()) {
        return fail<Backlog>("queue_recursion_arrival_batch_malformed",
                             "the sparse arrival batch is not canonical for "
                             "this queue dimension");
      }
      next[ordinal] += entry.count;
      previous = ordinal;
    }
    return Backlog::from_values(backlog.dimension(), std::move(next));
  } catch (const std::bad_alloc&) {
    return allocation_fail<Backlog>("applying exact queue recursion");
  } catch (const std::exception&) {
    return internal_fail<Backlog>(
        "queue_recursion_invariant_failure",
        "the exact queue recursion failed before publishing a successor");
  }
}

Result<InitializedPhysicalRun> initialize_physical_run(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival_law,
    const InitialPhysicalLaw& initial_law, RngBank& bank) {
  if (detail::PhysicalEngineAccess::initialized(bank)) {
    return fail<InitializedPhysicalRun>(
        "physical_rng_bank_already_initialized",
        "one physical RNG bank can initialize exactly one cold run");
  }
  if (bank.combined_input() != instance.fingerprints().combined ||
      instance.timing() != TimingConvention::early_service_late_admission) {
    return fail<InitializedPhysicalRun>(
        "physical_initialization_instance_mismatch",
        "the RNG bank or timing convention belongs to another resolved "
        "physical instance");
  }
  auto expected_key = make_physical_reference_instance_key(
      instance.fingerprints().combined, BigNat(0U));
  if (!expected_key || bank.instance_key() != expected_key.value()) {
    return fail<InitializedPhysicalRun>(
        "physical_rng_instance_key_mismatch",
        "the RNG bank does not carry the required physical-reference path-0 "
        "instance key");
  }

  auto retained_law = detail::CompiledArrivalAccess::get(instance.arrival());
  if (!retained_law) {
    return Result<InitializedPhysicalRun>::failure(retained_law.error());
  }
  if (!instance.initial_law().has_value()) {
    return fail<InitializedPhysicalRun>(
        "physical_initial_law_unavailable",
        "a cold physical reference path requires one transient initial law");
  }
  auto retained_initial =
      detail::CompiledInitialLawAccess::get(*instance.initial_law());
  if (!retained_initial) {
    return Result<InitializedPhysicalRun>::failure(retained_initial.error());
  }
  // C27 carries the C09 initializer through an immutable value-semantic
  // request snapshot.  Such a copy retains C09's opaque origin token, so it
  // is the same compiled product even though its object address differs from
  // the owner erased into ResolvedInstance.  A separately compiled,
  // same-shaped law has another origin and remains inadmissible.
  if (!retained_initial.value()->shares_origin_with(initial_law)) {
    return fail<InitializedPhysicalRun>(
        "physical_initial_law_identity_mismatch",
        "the supplied initializer does not share the exact immutable C09 "
        "joint-law origin retained by the resolved instance");
  }
  const ArrivalBinding& binding = arrival_law_binding(arrival_law);
  const auto& supplied_core = detail::ArrivalCoreAccess::law_core(arrival_law);
  const auto& retained_core =
      detail::ArrivalCoreAccess::law_core(*retained_law.value());
  if (binding != initial_law.arrival_binding() ||
      binding.family != instance.arrival().family() ||
      binding.timing != instance.timing() ||
      binding.queue_cardinality != instance.queues().size() ||
      !same_owner(supplied_core, retained_core)) {
    return fail<InitializedPhysicalRun>(
        "physical_initialization_binding_mismatch",
        "the configured law, joint initializer, and resolved instance do not "
        "share one exact arrival identity");
  }
  if (detail::PhysicalEngineAccess::initial_rng(bank).derivation_stage() !=
          StageTag::initial_joint_atom ||
      detail::PhysicalEngineAccess::tie_rng(bank).derivation_stage() !=
          StageTag::tie_resolution) {
    return fail<InitializedPhysicalRun>(
        "physical_rng_stage_mismatch",
        "the physical RNG bank contains a stream from the wrong causal stage");
  }
  if (initial_law.atoms().empty() ||
      initial_law.original_to_atom().size() !=
          initial_law.original_pmf().size()) {
    return internal_fail<InitializedPhysicalRun>(
        "physical_initial_law_malformed",
        "the compiled joint initializer has inconsistent row mapping");
  }

  try {
    RngTransaction initial_transaction(
        detail::PhysicalEngineAccess::initial_rng(bank));
    const std::size_t original_index = sample_categorical(
        initial_law.original_pmf(),
        detail::PhysicalEngineAccess::initial_rng(bank));
    if (original_index >= initial_law.original_to_atom().size()) {
      return internal_fail<InitializedPhysicalRun>(
          "physical_initial_row_out_of_range",
          "the exact categorical sampler selected no joint initial row");
    }
    const std::size_t atom_index =
        initial_law.original_to_atom()[original_index];
    if (atom_index >= initial_law.atoms().size()) {
      return internal_fail<InitializedPhysicalRun>(
          "physical_initial_atom_out_of_range",
          "the initial-row mapping names no compiled joint atom");
    }
    const InitialPhysicalAtom& atom = initial_law.atoms()[atom_index];
    if (!is_empty_object(atom.controller_state) ||
        !is_empty_object(atom.static_context)) {
      return fail<InitializedPhysicalRun>(
          "physical_controller_initial_state_invalid",
          "C12's configured base controller requires empty controller and "
          "static initial coordinates");
    }
    auto backlog = Backlog::from_values(QueueDimensionToken::from_instance(instance),
                                        atom.backlog);
    if (!backlog) {
      return Result<InitializedPhysicalRun>::failure(backlog.error());
    }

    DeterministicRng configured_rng = derive_rng_stream(
        bank.seed(), StageTag::configured_arrival, bank.instance_key());
    if (configured_rng.stream_identity() !=
        bank.configured_arrival_stream_identity()) {
      return internal_fail<InitializedPhysicalRun>(
          "physical_arrival_stream_derivation_mismatch",
          "re-deriving the configured-arrival stream changed its identity");
    }
    auto stream_key = make_configured_arrival_stream_key(
        arrival_law, std::move(configured_rng));
    if (!stream_key) {
      return Result<InitializedPhysicalRun>::failure(stream_key.error());
    }
    auto process = instantiate_arrival_process(
        arrival_law, atom.arrival_state, std::move(stream_key.value()));
    if (!process) {
      return Result<InitializedPhysicalRun>::failure(process.error());
    }
    const auto process_core =
        detail::ArrivalCoreAccess::process_core(process.value());
    auto phase = snapshot_current_phase(process_core);
    if (!phase) {
      return Result<InitializedPhysicalRun>::failure(phase.error());
    }
    PhysicalRunIdentity identity{
        .combined_input = instance.fingerprints().combined,
        .arrival_binding = binding,
        .seed = bank.seed(),
        .path_or_replication_id = BigNat(0U),
        .instance_key = bank.instance_key().digest(),
        .initial_stream_identity =
            detail::PhysicalEngineAccess::initial_rng(bank).stream_identity(),
        .tie_stream_identity =
            detail::PhysicalEngineAccess::tie_rng(bank).stream_identity(),
        .configured_arrival_stream_identity =
            bank.configured_arrival_stream_identity(),
        .arrival_realization_identity = process_core->realization_identity,
        .initial_original_row_index = original_index,
        .initial_coalesced_atom_index = atom_index,
    };
    PhysicalState state = detail::PhysicalEngineAccess::make_state(
        std::move(backlog.value()), BigNat(0U), atom.controller_state,
        atom.static_context, std::move(phase.value()), std::move(identity),
        detail::PhysicalEngineAccess::owner(bank));
    InitializedPhysicalRun run = detail::PhysicalEngineAccess::make_initialized(
        std::move(state), std::move(process.value()));
    Result<InitializedPhysicalRun> result =
        Result<InitializedPhysicalRun>::success(std::move(run));
    detail::PhysicalEngineAccess::mark_initialized(bank);
    initial_transaction.commit();
    return result;
  } catch (const std::bad_alloc&) {
    return allocation_fail<InitializedPhysicalRun>(
        "sampling the joint physical initializer");
  } catch (const std::exception&) {
    return internal_fail<InitializedPhysicalRun>(
        "physical_initialization_failure",
        "the cold physical initializer failed transactionally");
  } catch (...) {
    return internal_fail<InitializedPhysicalRun>(
        "physical_initialization_failure",
        "the cold physical initializer raised a nonstandard exception");
  }
}

PhysicalEdge make_physical_edge(const PhysicalState& pre_state,
                                const ScheduleDecision& decision,
                                const ArrivalStep& arrival_step,
                                const PhysicalState& post_state) {
  auto departure =
      compute_actual_departure(pre_state.backlog(), decision.schedule);
  if (!departure) {
    throw std::invalid_argument(departure.error().code);
  }
  auto transition = validate_transition(pre_state, decision,
                                        departure.value(), arrival_step,
                                        post_state);
  if (!transition) {
    throw std::invalid_argument(transition.error().code);
  }
  auto arrival_evidence =
      validate_edge_arrival_evidence(pre_state, arrival_step, post_state);
  if (!arrival_evidence) {
    throw std::invalid_argument(arrival_evidence.error().code);
  }
  auto arrival = std::make_shared<const ArrivalStep>(arrival_step);
  return detail::PhysicalEngineAccess::make_edge(
      pre_state.boundary_index(), pre_state, decision,
      std::move(departure.value()), std::move(arrival), post_state,
      base_mark_evidence());
}

Result<PhysicalEdge> execute_physical_slot(
    const ResolvedInstance& instance, PhysicalState& state,
    ArrivalProcess& process, RngBank& bank,
    OptimizerExecutionContext& optimizer_context) {
  return execute_slot_core(
      instance, state, process, bank, optimizer_context,
      [](const ResolvedInstance& supplied_instance,
         const Backlog& backlog, const TieContext& tie,
         OptimizerExecutionContext& context) {
        return resolve_maxweight_schedule(supplied_instance, backlog, tie,
                                          context);
      },
      [](ArrivalProcess& supplied_process, const BigNat& slot) {
        return dispatch_arrival_family(supplied_process, slot);
      },
      [](const ArrivalStep&) { return Result<void>::success(); });
}

#if defined(MWPERF_C12_TEST_SEAMS)
Result<PhysicalEdge> testing::execute_physical_slot_with_services(
    const ResolvedInstance& instance, PhysicalState& state,
    ArrivalProcess& process, RngBank& bank,
    OptimizerExecutionContext& optimizer_context,
    const PhysicalSlotServices& services) {
  return execute_slot_core(instance, state, process, bank, optimizer_context,
                           services.resolve, services.arrival,
                           services.post_arrival_validate);
}
#endif

Result<PhysicalPath> execute_reference_path(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival_law,
    const InitialPhysicalLaw& initial_law, const BigNat& horizon,
    const MasterSeed seed, OptimizerExecutionContext& optimizer_context) {
  if (!optimizer_context.active() ||
      !optimizer_context.matches_dimension(
          QueueDimensionToken::from_instance(instance))) {
    return fail<PhysicalPath>(
        "physical_optimizer_context_mismatch",
        "the execution-wide optimizer context is not bound to this resolved "
        "instance");
  }
  const BigInt maximum = std::numeric_limits<std::size_t>::max();
  if (horizon.value() > maximum) {
    return Result<PhysicalPath>::failure(physical_error(
        DiagnosticCategory::resource_limit, "physical_horizon_too_large",
        "the exact reference horizon exceeds the host path representation"));
  }
  const std::size_t count = horizon.value().convert_to<std::size_t>();
  try {
    std::vector<PhysicalEdge> edges;
    if (count > edges.max_size()) {
      return Result<PhysicalPath>::failure(physical_error(
          DiagnosticCategory::resource_limit, "physical_horizon_too_large",
          "the exact reference horizon exceeds the host path capacity"));
    }
    edges.reserve(count);
    std::vector<QueueId> queue_ids;
    queue_ids.reserve(instance.queues().size());
    for (const QueueCatalogEntry& entry : instance.queues().entries()) {
      queue_ids.push_back(entry.id);
    }
    auto bank = RngBank::for_physical_reference(instance, seed);
    if (!bank) {
      return Result<PhysicalPath>::failure(bank.error());
    }
    auto initialized = initialize_physical_run(
        instance, arrival_law, initial_law, bank.value());
    if (!initialized) {
      return Result<PhysicalPath>::failure(initialized.error());
    }
    PhysicalState initial_state = initialized.value().state();
    for (std::size_t index = 0U; index < count; ++index) {
      auto edge = execute_physical_slot(
          instance, detail::PhysicalEngineAccess::state(initialized.value()),
          detail::PhysicalEngineAccess::process(initialized.value()),
          bank.value(), optimizer_context);
      if (!edge) {
        return Result<PhysicalPath>::failure(edge.error());
      }
#ifndef NDEBUG
      if (!edges.empty()) {
        assert(same_physical_state(edges.back().post_state(),
                                   edge.value().pre_state()));
        BigNat expected = edges.back().slot_index();
        ++expected;
        assert(expected == edge.value().slot_index());
      }
#endif
      edges.push_back(std::move(edge.value()));
    }
    PhysicalState final_state = initialized.value().state();
    return Result<PhysicalPath>::success(detail::PhysicalEngineAccess::make_path(
        std::move(initial_state), std::move(final_state), std::move(edges),
        std::move(queue_ids)));
  } catch (const std::bad_alloc&) {
    return allocation_fail<PhysicalPath>("constructing the finite path");
  } catch (const std::exception&) {
    return internal_fail<PhysicalPath>(
        "physical_path_invariant_failure",
        "the cold finite-path driver failed before publishing a path");
  } catch (...) {
    return internal_fail<PhysicalPath>(
        "physical_path_invariant_failure",
        "the cold finite-path driver raised a nonstandard exception");
  }
}

bool same_physical_path(const PhysicalPath& left,
                        const PhysicalPath& right) noexcept {
  if (!same_physical_state(left.initial_state(), right.initial_state()) ||
      !same_physical_state(left.final_state(), right.final_state()) ||
      !std::ranges::equal(left.queue_ids(), right.queue_ids()) ||
      left.edges().size() != right.edges().size()) {
    return false;
  }
  for (std::size_t index = 0U; index < left.edges().size(); ++index) {
    if (!same_physical_edge(left.edges()[index], right.edges()[index])) {
      return false;
    }
  }
  return true;
}

std::string serialize_physical_path(const PhysicalPath& path) {
  if (path.queue_ids().size() != path.initial_state().backlog().size()) {
    throw std::invalid_argument("physical_path_queue_catalog_mismatch");
  }
  const PhysicalRunIdentity& run = path.initial_state().run_identity();
  std::string result = "{\"version\":1,\"run\":{\"combined_input\":" +
      json_escape(run.combined_input.hex()) +
      ",\"seed\":" + json_escape(std::to_string(run.seed.value())) +
      ",\"path_or_replication_id\":" +
      json_escape(run.path_or_replication_id.to_decimal_string()) +
      ",\"instance_key\":" + json_escape(run.instance_key.hex()) +
      ",\"arrival_binding\":{\"family\":" +
      json_escape(std::string(to_string(run.arrival_binding.family))) +
      ",\"timing\":\"early_service_late_admission\",\"queue_cardinality\":" +
      json_escape(std::to_string(run.arrival_binding.queue_cardinality)) +
      ",\"law_digest\":" +
      json_escape(run.arrival_binding.law_digest.value().hex()) +
      ",\"catalog_digest\":" +
      json_escape(run.arrival_binding.catalog_digest.value().hex()) + "}" +
      ",\"streams\":{\"initial_joint_atom\":" +
      json_escape(run.initial_stream_identity.hex()) +
      ",\"tie_resolution\":" +
      json_escape(run.tie_stream_identity.hex()) +
      ",\"configured_arrival\":" +
      json_escape(run.configured_arrival_stream_identity.hex()) + "}" +
      ",\"arrival_realization\":" +
      json_escape(run.arrival_realization_identity.hex()) +
      ",\"initial_original_row\":" +
      json_escape(std::to_string(
          run.initial_original_row_index)) +
      ",\"initial_coalesced_atom\":" +
      json_escape(std::to_string(run.initial_coalesced_atom_index)) +
      "},\"initial\":" +
      serialize_state(path.initial_state(), path.queue_ids()) +
      ",\"edges\":[";
  for (std::size_t edge_index = 0U; edge_index < path.edges().size();
       ++edge_index) {
    if (edge_index != 0U) result.push_back(',');
    const PhysicalEdge& edge = path.edges()[edge_index];
    result += "{\"slot\":" +
              json_escape(edge.slot_index().to_decimal_string()) +
              ",\"pre\":" +
              serialize_state(edge.pre_state(), path.queue_ids()) +
              ",\"decision\":{\"schedule\":" +
              serialize_bits(edge.decision().schedule.bytes()) +
              ",\"eligibility\":" +
              serialize_bits(edge.decision().eligibility.bytes()) +
              ",\"primary\":" +
              json_escape(edge.decision().primary_objective.to_decimal_string()) +
              ",\"composite\":" +
              json_escape(edge.decision().composite_objective.to_decimal_string()) +
              ",\"priority\":" +
              json_escape(edge.decision().priority_code.to_decimal_string()) +
              ",\"family\":" +
              json_escape(std::string(to_string(edge.decision().family))) +
              ",\"backend\":" +
              json_escape(std::string(to_string(edge.decision().backend_id))) +
              ",\"accounting\":" +
              serialize_accounting(edge.decision().accounting) +
              "},\"departure\":" +
              serialize_bits(edge.departure().bytes()) +
              ",\"arrival\":{\"authored_slot\":" +
              json_escape(edge.arrival_step().authored_slot.to_decimal_string()) +
              ",\"physical_epoch\":" +
              json_escape(edge.arrival_step().physical_arrival_epoch().to_decimal_string()) +
              ",\"law_digest\":" +
              json_escape(edge.arrival_step().law_digest.value().hex()) +
              ",\"realization\":" +
              json_escape(edge.arrival_step().realization_identity.hex()) +
              ",\"phase_before\":" +
              json_escape(arrival_phase_digest(
                              edge.arrival_step().phase_before).value().hex()) +
              ",\"phase_after\":" +
              json_escape(arrival_phase_digest(
                              edge.arrival_step().phase_after).value().hex()) +
              ",\"batch\":[";
    bool first = true;
    for (const ArrivalBatchEntry& entry :
         edge.arrival_step().batch.entries()) {
      if (!first) result.push_back(',');
      first = false;
      result += "{\"id\":" +
                serialize_label(path.queue_ids()[entry.queue.ordinal()]) +
                ",\"count\":" +
                json_escape(entry.count.to_decimal_string()) + "}";
    }
    result += "]},\"marks\":[";
    for (std::size_t index = 0U; index < edge.marks().size(); ++index) {
      if (index != 0U) result.push_back(',');
      result += "{\"kind\":" +
                json_escape(mark_kind_name(edge.marks()[index].kind)) +
                ",\"stage\":" +
                json_escape(reveal_stage_name(edge.marks()[index].stage)) +
                "}";
    }
    result += "],\"post\":" +
              serialize_state(edge.post_state(), path.queue_ids()) + "}";
  }
  result += "],\"final\":" +
            serialize_state(path.final_state(), path.queue_ids()) + "}";
  return result;
}

}  // namespace mwperf
