#include "metrics/c22_exact_solver_internal.hpp"

#include <algorithm>
#include <cstddef>
#include <exception>
#include <limits>
#include <new>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace mwperf::metrics::detail {
namespace {

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    const DiagnosticCategory category = DiagnosticCategory::input_validation,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

[[nodiscard]] Result<void> validate_dense_dimensions(
    const ExactKilledSystem& system) {
  if (system.state_count == 0U) {
    return fail<void>(
        "c22.empty_exact_killed_state_domain",
        "an exact finite killed system requires at least one survivor state");
  }
  if (system.rows.size() != system.state_count) {
    return fail<void>(
        "c22.exact_killed_state_count_mismatch",
        "the exact killed system row count differs from its state count");
  }
  if (system.state_count != 0U &&
      system.state_count >
          std::numeric_limits<std::size_t>::max() / system.state_count) {
    return fail<void>(
        "c22.exact_killed_dense_dimension_overflow",
        "the exact killed survivor matrix dimension overflows size_t",
        DiagnosticCategory::resource_limit);
  }
  if (system.exit_type_count != 0U &&
      system.state_count >
          std::numeric_limits<std::size_t>::max() /
              system.exit_type_count) {
    return fail<void>(
        "c22.exact_killed_exit_dimension_overflow",
        "the exact killed typed-exit matrix dimension overflows size_t",
        DiagnosticCategory::resource_limit);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ExactKilledValidation> validate_impl(
    const ExactKilledSystem& system) {
  auto dimensions = validate_dense_dimensions(system);
  if (!dimensions) {
    return Result<ExactKilledValidation>::failure(dimensions.error());
  }

  std::vector<ExactRational> survivor_matrix(
      system.state_count * system.state_count, ExactRational::zero());
  std::vector<ExactRational> typed_exit_matrix(
      system.state_count * system.exit_type_count, ExactRational::zero());
  std::vector<ExactKilledRowAudit> audits;
  audits.reserve(system.state_count);

  for (std::size_t state = 0U; state < system.state_count; ++state) {
    const ExactKilledRow& row = system.rows[state];
    if (!(row.exact_source_mass == ExactRational::one())) {
      return fail<ExactKilledValidation>(
          "c22.exact_source_row_not_unit",
          "an exact killed source row does not have exact mass one",
          DiagnosticCategory::input_validation,
          {"state index " + std::to_string(state),
           "exact source mass " + row.exact_source_mass.to_canonical_string()});
    }

    ExactRational survivor_total = ExactRational::zero();
    for (const ExactKilledTransition& atom : row.survivors) {
      if (atom.successor_index >= system.state_count) {
        return fail<ExactKilledValidation>(
            "c22.exact_killed_successor_out_of_domain",
            "an exact killed survivor atom points outside the declared state domain",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state),
             "successor index " + std::to_string(atom.successor_index)});
      }
      if (!atom.exact_mass.is_nonnegative()) {
        return fail<ExactKilledValidation>(
            "c22.negative_exact_survivor_mass",
            "an exact killed survivor atom has negative mass",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      const std::size_t offset =
          state * system.state_count + atom.successor_index;
      survivor_matrix[offset] =
          survivor_matrix[offset] + atom.exact_mass;
      survivor_total = survivor_total + atom.exact_mass;
    }

    std::vector<ExactRational> exit_totals(system.exit_type_count,
                                            ExactRational::zero());
    ExactRational exit_total = ExactRational::zero();
    for (const ExactKilledTypedExit& atom : row.typed_exits) {
      if (atom.exit_type_index >= system.exit_type_count) {
        return fail<ExactKilledValidation>(
            "c22.exact_killed_exit_type_out_of_domain",
            "an exact killed exit atom names an undeclared exit type",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state),
             "exit type index " + std::to_string(atom.exit_type_index)});
      }
      if (!atom.exact_mass.is_nonnegative()) {
        return fail<ExactKilledValidation>(
            "c22.negative_exact_exit_mass",
            "an exact killed typed exit has negative mass",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      const std::size_t offset =
          state * system.exit_type_count + atom.exit_type_index;
      typed_exit_matrix[offset] =
          typed_exit_matrix[offset] + atom.exact_mass;
      exit_totals[atom.exit_type_index] =
          exit_totals[atom.exit_type_index] + atom.exact_mass;
      exit_total = exit_total + atom.exact_mass;
    }

    const ExactRational classified_total = survivor_total + exit_total;
    const ExactRational balance =
        classified_total - row.exact_source_mass;
    if (!balance.is_zero()) {
      return fail<ExactKilledValidation>(
          "c22.exact_killed_row_mass_mismatch",
          "exact survivor and typed-exit masses do not reproduce the exact source row; no residual is converted to absorption",
          DiagnosticCategory::input_validation,
          {"state index " + std::to_string(state),
           "exact source mass " + row.exact_source_mass.to_canonical_string(),
           "exact classified mass " + classified_total.to_canonical_string(),
           "exact balance residual " + balance.to_canonical_string()});
    }
    audits.push_back(ExactKilledRowAudit{
        state, row.exact_source_mass, survivor_total, std::move(exit_totals),
        classified_total, balance});
  }

  return Result<ExactKilledValidation>::success(ExactKilledValidation{
      std::move(audits), std::move(survivor_matrix),
      std::move(typed_exit_matrix)});
}

class Tarjan final {
 public:
  Tarjan(const std::size_t count,
         const std::vector<ExactRational>& survivor_matrix)
      : count_(count),
        survivor_matrix_(survivor_matrix),
        discovery_(count, kUnvisited),
        low_(count, 0U),
        on_stack_(count, false) {}

  [[nodiscard]] std::vector<std::vector<std::size_t>> run() {
    for (std::size_t state = 0U; state < count_; ++state) {
      if (discovery_[state] == kUnvisited) {
        visit(state);
      }
    }
    // Tarjan's emission order is an implementation detail.  Canonicalize
    // members and components by their smallest state index.
    for (auto& component : components_) {
      std::sort(component.begin(), component.end());
    }
    std::sort(components_.begin(), components_.end(),
              [](const auto& left, const auto& right) {
                return left.front() < right.front();
              });
    return std::move(components_);
  }

 private:
  static constexpr std::size_t kUnvisited =
      std::numeric_limits<std::size_t>::max();

  void visit(const std::size_t state) {
    discovery_[state] = next_discovery_;
    low_[state] = next_discovery_;
    ++next_discovery_;
    stack_.push_back(state);
    on_stack_[state] = true;

    for (std::size_t successor = 0U; successor < count_; ++successor) {
      if (!survivor_matrix_[state * count_ + successor].is_positive()) {
        continue;
      }
      if (discovery_[successor] == kUnvisited) {
        visit(successor);
        low_[state] = std::min(low_[state], low_[successor]);
      } else if (on_stack_[successor]) {
        low_[state] = std::min(low_[state], discovery_[successor]);
      }
    }

    if (low_[state] != discovery_[state]) {
      return;
    }
    std::vector<std::size_t> component;
    while (true) {
      const std::size_t member = stack_.back();
      stack_.pop_back();
      on_stack_[member] = false;
      component.push_back(member);
      if (member == state) {
        break;
      }
    }
    components_.push_back(std::move(component));
  }

  std::size_t count_;
  const std::vector<ExactRational>& survivor_matrix_;
  std::vector<std::size_t> discovery_;
  std::vector<std::size_t> low_;
  std::vector<bool> on_stack_;
  std::vector<std::size_t> stack_;
  std::vector<std::vector<std::size_t>> components_;
  std::size_t next_discovery_{0U};
};

[[nodiscard]] ExactSurvivorClassification classify_validated(
    const ExactKilledSystem& system,
    const ExactKilledValidation& validation) {
  std::vector<std::vector<std::size_t>> components =
      Tarjan(system.state_count, validation.survivor_matrix).run();
  std::vector<std::size_t> component_by_state(system.state_count, 0U);
  for (std::size_t component = 0U; component < components.size();
       ++component) {
    for (const std::size_t state : components[component]) {
      component_by_state[state] = component;
    }
  }

  std::vector<ExactClosedSurvivorClass> closed;
  for (std::size_t component = 0U; component < components.size();
       ++component) {
    bool is_closed = true;
    for (const std::size_t state : components[component]) {
      if (!(validation.rows[state].exact_survivor_mass ==
            ExactRational::one())) {
        is_closed = false;
        break;
      }
      for (std::size_t successor = 0U; successor < system.state_count;
           ++successor) {
        if (validation.survivor_matrix[state * system.state_count +
                                       successor]
                .is_positive() &&
            component_by_state[successor] != component) {
          is_closed = false;
          break;
        }
      }
      if (!is_closed) {
        break;
      }
    }
    if (is_closed) {
      closed.push_back(
          ExactClosedSurvivorClass{component, components[component]});
    }
  }

  // Work on the reversed positive-support graph from every closed survivor
  // state.  Reachability is exact and never thresholded.
  std::vector<bool> reaches_closed(system.state_count, false);
  std::vector<std::size_t> work;
  for (const ExactClosedSurvivorClass& item : closed) {
    for (const std::size_t state : item.member_indices) {
      reaches_closed[state] = true;
      work.push_back(state);
    }
  }
  while (!work.empty()) {
    const std::size_t destination = work.back();
    work.pop_back();
    for (std::size_t predecessor = 0U; predecessor < system.state_count;
         ++predecessor) {
      if (!reaches_closed[predecessor] &&
          validation
              .survivor_matrix[predecessor * system.state_count + destination]
              .is_positive()) {
        reaches_closed[predecessor] = true;
        work.push_back(predecessor);
      }
    }
  }

  return ExactSurvivorClassification{
      std::move(components), std::move(component_by_state),
      std::move(closed), std::move(reaches_closed)};
}

struct ExactLinearSolution final {
  std::vector<ExactRational> values;
  std::size_t rank;
};

[[nodiscard]] Result<ExactLinearSolution> solve_exact_square(
    std::vector<ExactRational> coefficients,
    std::vector<ExactRational> right_hand_side,
    const std::size_t dimension) {
  if (dimension == 0U) {
    return Result<ExactLinearSolution>::success(
        ExactLinearSolution{{}, 0U});
  }
  if (coefficients.size() != dimension * dimension ||
      right_hand_side.size() != dimension) {
    return fail<ExactLinearSolution>(
        "c22.exact_linear_dimension_mismatch",
        "the private exact square solve received inconsistent dimensions",
        DiagnosticCategory::internal);
  }

  std::size_t rank = 0U;
  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension &&
           coefficients[pivot * dimension + column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return fail<ExactLinearSolution>(
          "c22.exact_linear_system_singular",
          "the structurally transient exact sub-Markov system is singular",
          DiagnosticCategory::internal,
          {"pivot column " + std::to_string(column),
           "rank " + std::to_string(rank),
           "dimension " + std::to_string(dimension)});
    }
    ++rank;
    if (pivot != column) {
      for (std::size_t entry = 0U; entry < dimension; ++entry) {
        std::swap(coefficients[column * dimension + entry],
                  coefficients[pivot * dimension + entry]);
      }
      std::swap(right_hand_side[column], right_hand_side[pivot]);
    }

    const ExactRational pivot_value =
        coefficients[column * dimension + column];
    for (std::size_t entry = column; entry < dimension; ++entry) {
      auto quotient = checked_divide(
          coefficients[column * dimension + entry], pivot_value);
      if (!quotient) {
        return Result<ExactLinearSolution>::failure(quotient.error());
      }
      coefficients[column * dimension + entry] =
          std::move(quotient).value();
    }
    auto rhs_quotient =
        checked_divide(right_hand_side[column], pivot_value);
    if (!rhs_quotient) {
      return Result<ExactLinearSolution>::failure(rhs_quotient.error());
    }
    right_hand_side[column] = std::move(rhs_quotient).value();

    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const ExactRational factor =
          coefficients[row * dimension + column];
      if (factor.is_zero()) {
        continue;
      }
      for (std::size_t entry = column; entry < dimension; ++entry) {
        coefficients[row * dimension + entry] =
            coefficients[row * dimension + entry] -
            factor * coefficients[column * dimension + entry];
      }
      right_hand_side[row] =
          right_hand_side[row] - factor * right_hand_side[column];
    }
  }
  return Result<ExactLinearSolution>::success(
      ExactLinearSolution{std::move(right_hand_side), rank});
}

[[nodiscard]] std::vector<std::size_t> indices_with_flag(
    const std::vector<bool>& flags, const bool wanted) {
  std::vector<std::size_t> result;
  result.reserve(flags.size());
  for (std::size_t index = 0U; index < flags.size(); ++index) {
    if (flags[index] == wanted) {
      result.push_back(index);
    }
  }
  return result;
}

[[nodiscard]] std::vector<bool> closed_member_flags(
    const ExactSurvivorClassification& classification,
    const std::size_t state_count) {
  std::vector<bool> result(state_count, false);
  for (const ExactClosedSurvivorClass& item :
       classification.closed_survivor_classes) {
    for (const std::size_t state : item.member_indices) {
      result[state] = true;
    }
  }
  return result;
}

[[nodiscard]] std::vector<ExactRational> transient_coefficients(
    const ExactKilledValidation& validation, const std::size_t state_count,
    const std::vector<std::size_t>& states) {
  const std::size_t dimension = states.size();
  std::vector<ExactRational> coefficients(
      dimension * dimension, ExactRational::zero());
  for (std::size_t row = 0U; row < dimension; ++row) {
    for (std::size_t column = 0U; column < dimension; ++column) {
      ExactRational value =
          -validation.survivor_matrix[states[row] * state_count +
                                      states[column]];
      if (row == column) {
        value = value + ExactRational::one();
      }
      coefficients[row * dimension + column] = std::move(value);
    }
  }
  return coefficients;
}

[[nodiscard]] Result<ExactMinimalPotential> potential_impl(
    const ExactKilledSystem& system) {
  auto validation = validate_impl(system);
  if (!validation) {
    return Result<ExactMinimalPotential>::failure(validation.error());
  }
  ExactSurvivorClassification classification =
      classify_validated(system, validation.value());
  const std::vector<std::size_t> finite_states =
      indices_with_flag(classification.can_reach_closed_survivor, false);
  const std::size_t dimension = finite_states.size();
  std::vector<ExactRational> coefficients = transient_coefficients(
      validation.value(), system.state_count, finite_states);
  std::vector<ExactRational> rhs(dimension, ExactRational::one());
  auto solution =
      solve_exact_square(std::move(coefficients), std::move(rhs), dimension);
  if (!solution) {
    return Result<ExactMinimalPotential>::failure(solution.error());
  }

  std::vector<std::optional<ExactRational>> finite_values(system.state_count);
  for (std::size_t local = 0U; local < dimension; ++local) {
    const ExactRational& value = solution.value().values[local];
    if (!value.is_nonnegative()) {
      return fail<ExactMinimalPotential>(
          "c22.negative_exact_minimal_potential",
          "the exact transient solve produced a negative potential",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(finite_states[local]),
           "exact value " + value.to_canonical_string()});
    }
    finite_values[finite_states[local]] = value;
  }

  // The first zero-start Neumann iterate is the all-one vector.  The
  // candidate must dominate it coordinatewise.  Positivity of K then makes
  // every subsequent zero-start iterate monotone, while full rank and the
  // exact fixed-point residual below make the pivoted solution the unique
  // finite fixed point on this transient subsystem.
  bool zero_start_monotone = true;
  for (const std::size_t state : finite_states) {
    if (!finite_values[state].has_value() ||
        *finite_values[state] < ExactRational::one()) {
      zero_start_monotone = false;
      break;
    }
  }
  if (!zero_start_monotone) {
    return fail<ExactMinimalPotential>(
        "c22.exact_potential_zero_start_certificate_failed",
        "the exact pivoted potential does not dominate its first "
        "zero-start Neumann iterate",
        DiagnosticCategory::internal);
  }

  std::vector<ExactPotentialCoordinate> coordinates;
  std::vector<std::optional<ExactRational>> residuals;
  coordinates.reserve(system.state_count);
  residuals.reserve(system.state_count);
  for (std::size_t state = 0U; state < system.state_count; ++state) {
    if (classification.can_reach_closed_survivor[state]) {
      coordinates.push_back(ExactPotentialCoordinate{
          ExactPotentialStatus::positive_infinity, std::nullopt});
      residuals.push_back(std::nullopt);
      continue;
    }
    ExactRational image = ExactRational::one();
    for (std::size_t successor = 0U; successor < system.state_count;
         ++successor) {
      const ExactRational& mass =
          validation.value()
              .survivor_matrix[state * system.state_count + successor];
      if (mass.is_zero()) {
        continue;
      }
      if (!finite_values[successor].has_value()) {
        return fail<ExactMinimalPotential>(
            "c22.finite_potential_reaches_infinite_coordinate",
            "a coordinate classified finite has positive survivor mass into the infinite-potential basin",
            DiagnosticCategory::internal);
      }
      image = image + mass * *finite_values[successor];
    }
    const ExactRational residual = *finite_values[state] - image;
    if (!residual.is_zero()) {
      return fail<ExactMinimalPotential>(
          "c22.exact_potential_residual_nonzero",
          "the exact minimal-potential solve failed its defining equation",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state),
           "exact residual " + residual.to_canonical_string()});
    }
    coordinates.push_back(ExactPotentialCoordinate{
        ExactPotentialStatus::finite, finite_values[state]});
    residuals.push_back(residual);
  }

  return Result<ExactMinimalPotential>::success(ExactMinimalPotential{
      std::move(coordinates), std::move(classification),
      std::move(residuals), dimension, solution.value().rank, 1U,
      zero_start_monotone, solution.value().rank == dimension});
}

[[nodiscard]] Result<ExactMinimalTypedExitProbabilities>
typed_exit_probabilities_impl(const ExactKilledSystem& system) {
  auto validation = validate_impl(system);
  if (!validation) {
    return Result<ExactMinimalTypedExitProbabilities>::failure(
        validation.error());
  }
  ExactSurvivorClassification classification =
      classify_validated(system, validation.value());
  const std::vector<bool> closed_members =
      closed_member_flags(classification, system.state_count);
  const std::vector<std::size_t> transient_states =
      indices_with_flag(closed_members, false);
  const std::size_t dimension = transient_states.size();
  const std::vector<ExactRational> coefficients = transient_coefficients(
      validation.value(), system.state_count, transient_states);

  std::vector<ExactRational> probabilities(
      system.state_count * system.exit_type_count, ExactRational::zero());
  std::size_t rank = dimension;
  for (std::size_t exit_type = 0U; exit_type < system.exit_type_count;
       ++exit_type) {
    std::vector<ExactRational> rhs;
    rhs.reserve(dimension);
    for (const std::size_t state : transient_states) {
      rhs.push_back(
          validation.value().typed_exit_matrix[
              state * system.exit_type_count + exit_type]);
    }
    auto solution = solve_exact_square(coefficients, std::move(rhs),
                                       dimension);
    if (!solution) {
      return Result<ExactMinimalTypedExitProbabilities>::failure(
          solution.error());
    }
    rank = solution.value().rank;
    for (std::size_t local = 0U; local < dimension; ++local) {
      const ExactRational& value = solution.value().values[local];
      if (!value.is_nonnegative() || value > ExactRational::one()) {
        return fail<ExactMinimalTypedExitProbabilities>(
            "c22.invalid_exact_eventual_exit_probability",
            "the exact minimal typed-exit solve produced a value outside [0,1]",
            DiagnosticCategory::internal,
            {"state index " + std::to_string(transient_states[local]),
             "exit type index " + std::to_string(exit_type),
             "exact value " + value.to_canonical_string()});
      }
      probabilities[transient_states[local] * system.exit_type_count +
                    exit_type] = value;
    }
  }

  std::vector<ExactRational> residuals(
      system.state_count * system.exit_type_count, ExactRational::zero());
  for (std::size_t state = 0U; state < system.state_count; ++state) {
    for (std::size_t exit_type = 0U; exit_type < system.exit_type_count;
         ++exit_type) {
      ExactRational image =
          validation.value().typed_exit_matrix[
              state * system.exit_type_count + exit_type];
      for (std::size_t successor = 0U; successor < system.state_count;
           ++successor) {
        image = image +
                validation.value().survivor_matrix[
                    state * system.state_count + successor] *
                    probabilities[successor * system.exit_type_count +
                                  exit_type];
      }
      const std::size_t offset =
          state * system.exit_type_count + exit_type;
      const ExactRational& first_zero_start_iterate =
          validation.value().typed_exit_matrix[offset];
      if (probabilities[offset] < first_zero_start_iterate) {
        return fail<ExactMinimalTypedExitProbabilities>(
            "c22.exact_typed_exit_zero_start_certificate_failed",
            "an exact pivoted typed-exit probability is below its first "
            "zero-start iterate",
            DiagnosticCategory::internal,
            {"state index " + std::to_string(state),
             "exit type index " + std::to_string(exit_type)});
      }
      residuals[offset] = probabilities[offset] - image;
      if (!residuals[offset].is_zero()) {
        return fail<ExactMinimalTypedExitProbabilities>(
            "c22.exact_typed_exit_residual_nonzero",
            "the exact minimal typed-exit solve failed its defining equation",
            DiagnosticCategory::internal,
            {"state index " + std::to_string(state),
             "exit type index " + std::to_string(exit_type),
             "exact residual " + residuals[offset].to_canonical_string()});
      }
    }
  }

  std::vector<ExactRational> defect(system.state_count,
                                    ExactRational::one());
  std::vector<ExactRational> defect_residual(system.state_count,
                                             ExactRational::zero());
  for (std::size_t state = 0U; state < system.state_count; ++state) {
    for (std::size_t exit_type = 0U; exit_type < system.exit_type_count;
         ++exit_type) {
      defect[state] =
          defect[state] -
          probabilities[state * system.exit_type_count + exit_type];
    }
    if (!defect[state].is_nonnegative() ||
        defect[state] > ExactRational::one()) {
      return fail<ExactMinimalTypedExitProbabilities>(
          "c22.invalid_exact_defect_probability",
          "eventual typed exits leave a defect probability outside [0,1]",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state),
           "exact defect " + defect[state].to_canonical_string()});
    }
  }

  for (std::size_t state = 0U; state < system.state_count; ++state) {
    ExactRational image = ExactRational::zero();
    for (std::size_t successor = 0U; successor < system.state_count;
         ++successor) {
      image = image +
              validation.value().survivor_matrix[
                  state * system.state_count + successor] *
                  defect[successor];
    }
    defect_residual[state] = defect[state] - image;
    if (!defect_residual[state].is_zero()) {
      return fail<ExactMinimalTypedExitProbabilities>(
          "c22.exact_defect_residual_nonzero",
          "the exact nonabsorption probability failed its harmonic equation",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state),
           "exact residual " +
               defect_residual[state].to_canonical_string()});
    }
    const bool expected_positive =
        classification.can_reach_closed_survivor[state];
    if (defect[state].is_positive() != expected_positive) {
      return fail<ExactMinimalTypedExitProbabilities>(
          "c22.exact_defect_support_mismatch",
          "the exact nonabsorption probability disagrees with positive-support reachability",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state)});
    }
  }

  return Result<ExactMinimalTypedExitProbabilities>::success(
      ExactMinimalTypedExitProbabilities{
          system.state_count, system.exit_type_count,
          std::move(probabilities), std::move(defect),
          std::move(residuals), std::move(defect_residual),
          std::move(classification), dimension, rank,
          system.exit_type_count == 0U ? 0U : 1U, true,
          rank == dimension});
}

}  // namespace

Result<ExactKilledValidation> validate_exact_killed_system(
    const ExactKilledSystem& system) {
  try {
    return validate_impl(system);
  } catch (const std::bad_alloc&) {
    return fail<ExactKilledValidation>(
        "c22.exact_killed_validation_allocation_failure",
        "validating the exact killed system exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ExactKilledValidation>(
        "c22.exact_killed_validation_exception",
        "validating the exact killed system raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<ExactSurvivorClassification> classify_exact_survivor_support(
    const ExactKilledSystem& system) {
  try {
    auto validation = validate_impl(system);
    if (!validation) {
      return Result<ExactSurvivorClassification>::failure(
          validation.error());
    }
    return Result<ExactSurvivorClassification>::success(
        classify_validated(system, validation.value()));
  } catch (const std::bad_alloc&) {
    return fail<ExactSurvivorClassification>(
        "c22.exact_survivor_classification_allocation_failure",
        "classifying exact survivor support exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ExactSurvivorClassification>(
        "c22.exact_survivor_classification_exception",
        "classifying exact survivor support raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<ExactMinimalPotential> compute_exact_minimal_potential(
    const ExactKilledSystem& system) {
  try {
    return potential_impl(system);
  } catch (const std::bad_alloc&) {
    return fail<ExactMinimalPotential>(
        "c22.exact_potential_allocation_failure",
        "computing the exact minimal killed potential exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ExactMinimalPotential>(
        "c22.exact_potential_exception",
        "computing the exact minimal killed potential raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<ExactMinimalTypedExitProbabilities>
compute_exact_minimal_typed_exit_probabilities(
    const ExactKilledSystem& system) {
  try {
    return typed_exit_probabilities_impl(system);
  } catch (const std::bad_alloc&) {
    return fail<ExactMinimalTypedExitProbabilities>(
        "c22.exact_typed_exit_allocation_failure",
        "computing exact minimal typed-exit probabilities exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ExactMinimalTypedExitProbabilities>(
        "c22.exact_typed_exit_exception",
        "computing exact minimal typed-exit probabilities raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace mwperf::metrics::detail
