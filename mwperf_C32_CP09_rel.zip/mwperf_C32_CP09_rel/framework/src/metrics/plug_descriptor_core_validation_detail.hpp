#pragma once

#include "mwperf/contracts/plug_descriptor.hpp"

namespace mwperf::detail {

// Source-internal bridge to C14's authoritative descriptor-shape predicate.
// This header is not part of the installed public include surface.
[[nodiscard]] bool is_valid_plug_descriptor_core_shape_v1(
    const PlugDescriptorCore& core);

}  // namespace mwperf::detail
