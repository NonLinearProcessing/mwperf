#include "mwperf/metrics/metric_capabilities.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_requirements.hpp"

#include "plug_descriptor_core_validation_detail.hpp"

namespace mwperf {

// The aggregate's only construction seam.  Public callers receive an
// immutable value; F-C14-02/03 assemble every acceleration field here from
// the authoritative clauses.
class MetricRequirementsAccess final {
 public:
  [[nodiscard]] static MetricRequirements construct(
      std::uint32_t schema_version,
      std::vector<MetricRequirementClause> clauses,
      std::vector<MetricClauseIdV1> authored_diagnostic_order,
      std::vector<ResolvedMetricTargetV1> target_union,
      std::vector<MarkRequirementV1> mark_union,
      std::vector<ArrivalRequirementSetV1> arrival_conjunction,
      std::vector<std::vector<MetricRouteAlternativeV1>> route_conjunction,
      std::vector<HypothesisRequirementV1> hypothesis_union,
      std::vector<CylinderRequirementSummaryV1> cylinder_summaries,
      std::vector<MomentRequirementSummaryV1> moment_summaries,
      std::vector<AccuracyRequirementV1> accuracy_conjunction,
      RegimeCompatibilityV1 regime_compatibility, bool mandatory_v0) {
    return MetricRequirements(
        schema_version, std::move(clauses),
        std::move(authored_diagnostic_order), std::move(target_union),
        std::move(mark_union), std::move(arrival_conjunction),
        std::move(route_conjunction), std::move(hypothesis_union),
        std::move(cylinder_summaries), std::move(moment_summaries),
        std::move(accuracy_conjunction), std::move(regime_compatibility),
        mandatory_v0);
  }
};

namespace {

constexpr std::uint32_t kMetricRequirementsSchemaVersion = 1U;

[[nodiscard]] SolverRegimeV1 solver_regime(
    const MetricSolverRegimeV1 regime) noexcept {
  switch (regime) {
    case MetricSolverRegimeV1::enumerated:
      return SolverRegimeV1::enumerated;
    case MetricSolverRegimeV1::analytic:
      return SolverRegimeV1::analytic;
    case MetricSolverRegimeV1::monte_carlo:
      return SolverRegimeV1::monte_carlo;
    case MetricSolverRegimeV1::direct:
      return SolverRegimeV1::direct;
  }
  return SolverRegimeV1::direct;
}

[[nodiscard]] SelectionKindV1 selection_kind(
    const MetricSelectionRegimeV1 regime) noexcept {
  switch (regime) {
    case MetricSelectionRegimeV1::transient:
      return SelectionKindV1::transient_initial;
    case MetricSelectionRegimeV1::stationary_unique:
      return SelectionKindV1::stationary_unique;
    case MetricSelectionRegimeV1::stationary_class:
      return SelectionKindV1::stationary_class;
    case MetricSelectionRegimeV1::stationary_mixture:
      return SelectionKindV1::stationary_mixture;
    case MetricSelectionRegimeV1::fixed_point_unique:
      return SelectionKindV1::fixed_point_unique;
    case MetricSelectionRegimeV1::fixed_point_id:
      return SelectionKindV1::fixed_point_id;
  }
  return SelectionKindV1::transient_initial;
}

[[nodiscard]] TargetCouplingV1 target_coupling(
    const MetricTargetCouplingV1 coupling) noexcept {
  switch (coupling) {
    case MetricTargetCouplingV1::scalar_singleton:
      return TargetCouplingV1::scalar_target;
    case MetricTargetCouplingV1::common_schedule_coupled:
      return TargetCouplingV1::common_schedule_projection;
  }
  return TargetCouplingV1::scalar_target;
}

[[nodiscard]] bool is_stationary_selection(
    const MetricSelectionRegimeV1 selection) noexcept {
  return selection != MetricSelectionRegimeV1::transient;
}

[[nodiscard]] bool deterministic_tolerance_applies(
    const MetricClauseOriginV1& origin,
    const DeterministicToleranceKindV1 kind) noexcept {
  const bool stationary = is_stationary_selection(origin.selection_regime);
  switch (kind) {
    case DeterministicToleranceKindV1::linear_residual_abs:
      // Throughput is an exact lossless flow identity once a proper
      // stationary regime has been supplied; it does not ask C14 to solve an
      // invariant linear system.  Every other stationary metric can consume
      // a selected invariant, Palm, or stopped-system solve.
      return stationary &&
             origin.kind != MetricKindV1::stationary_throughput;
    case DeterministicToleranceKindV1::integration_abs:
      switch (origin.kind) {
        case MetricKindV1::mean_sojourn:
        case MetricKindV1::stationary_empty_probability:
        case MetricKindV1::joint_backlog_covariance:
        case MetricKindV1::stationary_backlog_pmf:
        case MetricKindV1::stationary_backlog_pgf:
        case MetricKindV1::stationary_backlog_moment:
        case MetricKindV1::stationary_backlog_quantile:
        case MetricKindV1::stationary_backlog_tail:
        case MetricKindV1::stationary_edge_reward:
        case MetricKindV1::backlog_conditioned_service:
        case MetricKindV1::service_persistence:
        case MetricKindV1::service_autocovariance:
        case MetricKindV1::lagged_cross_queue_covariance:
        case MetricKindV1::service_spectrum:
        case MetricKindV1::service_window_count:
        case MetricKindV1::mean_event_gap:
        case MetricKindV1::event_gap_distribution:
        case MetricKindV1::mean_binary_run:
        case MetricKindV1::binary_run_distribution:
        case MetricKindV1::first_hit:
        case MetricKindV1::threshold_excursion:
        case MetricKindV1::transient_backlog_law:
        case MetricKindV1::fifo_delay:
        case MetricKindV1::fifo_delay_conditioned:
        case MetricKindV1::counterfactual_opportunity_gap:
        case MetricKindV1::joint_delay:
        case MetricKindV1::joint_backlog_event:
        case MetricKindV1::ordered_schedule_sequence:
          return true;
        default:
          return false;
      }
    case DeterministicToleranceKindV1::tail_abs:
      switch (origin.kind) {
        case MetricKindV1::stationary_backlog_pmf:
          // A finite max_level is only the requested output window.  It does
          // not authorize a tail closure and therefore cannot acquire a
          // tail-approximation tolerance by implication.
          return std::holds_alternative<CompletePmfDomainV1>(
              std::get<StationaryBacklogPmfParametersV1>(origin.parameters)
                  .domain);
        case MetricKindV1::stationary_backlog_pgf:
        case MetricKindV1::stationary_backlog_moment:
        case MetricKindV1::stationary_backlog_quantile:
        case MetricKindV1::stationary_backlog_tail:
        case MetricKindV1::mean_event_gap:
        case MetricKindV1::event_gap_distribution:
        case MetricKindV1::mean_binary_run:
        case MetricKindV1::binary_run_distribution:
        case MetricKindV1::first_hit:
        case MetricKindV1::threshold_excursion:
        case MetricKindV1::fifo_delay:
        case MetricKindV1::fifo_delay_conditioned:
        case MetricKindV1::counterfactual_opportunity_gap:
        case MetricKindV1::joint_delay:
          return true;
        default:
          return false;
      }
    case DeterministicToleranceKindV1::fixed_point_abs:
      return origin.selection_regime ==
                 MetricSelectionRegimeV1::fixed_point_unique ||
             origin.selection_regime ==
                 MetricSelectionRegimeV1::fixed_point_id;
  }
  return false;
}

[[nodiscard]] std::vector<DeterministicToleranceV1> configured_tolerances(
    const MetricClauseOriginV1& origin,
    const ResolutionEnvelope& resolution) {
  std::vector<DeterministicToleranceV1> result;
  const auto add = [&result, &origin](
                       const DeterministicToleranceKindV1 kind,
                       const std::optional<ExactRational>& value) {
    if (value.has_value() && deterministic_tolerance_applies(origin, kind)) {
      result.push_back(DeterministicToleranceV1{kind, *value});
    }
  };
  add(DeterministicToleranceKindV1::linear_residual_abs,
      resolution.tolerance.linear_residual_abs);
  add(DeterministicToleranceKindV1::integration_abs,
      resolution.tolerance.integration_abs);
  add(DeterministicToleranceKindV1::tail_abs,
      resolution.tolerance.tail_abs);
  add(DeterministicToleranceKindV1::fixed_point_abs,
      resolution.tolerance.fixed_point_abs);
  return result;
}

[[nodiscard]] bool is_binary_proportion_metric(
    const MetricKindV1 kind,
    const MetricRequestParametersV1& parameters) {
  switch (kind) {
    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::stationary_backlog_tail:
    case MetricKindV1::joint_backlog_event:
      return true;
    case MetricKindV1::backlog_conditioned_service:
      // A single conditional service probability has one Bernoulli
      // estimand.  A vector of represented levels is not silently assigned a
      // simultaneous exact-binomial coverage statement.
      return std::get<BacklogConditionedServiceParametersV1>(parameters)
                 .levels.size() == 1U;
    case MetricKindV1::stationary_edge_reward: {
      const auto& reward =
          std::get<StationaryEdgeRewardParametersV1>(parameters);
      return reward.reward == EdgeRewardKind::departure;
    }
    default:
      return false;
  }
}

[[nodiscard]] AccuracyRequirementV1 make_accuracy(
    const MetricClauseOriginV1& origin) {
  const AnalysisContext& context = *origin.context;
  const SolverRegimeV1 regime = solver_regime(origin.solver_regime);
  return std::visit(
      [&](const auto& solver) -> AccuracyRequirementV1 {
        using Solver = std::decay_t<decltype(solver)>;
        if constexpr (std::is_same_v<Solver, EnumeratedSolver>) {
          return AccuracyRequirementV1{
              regime,
              EnumeratedAccuracyV1{
                  configured_tolerances(origin, context.resolution)},
              true};
        } else if constexpr (std::is_same_v<Solver, AnalyticSolver>) {
          return AccuracyRequirementV1{
              regime,
              AnalyticAccuracyV1{
                  solver.precision_bits,
                  configured_tolerances(origin, context.resolution)},
              true};
        } else if constexpr (std::is_same_v<Solver, MonteCarloSolver>) {
          StatisticalIntervalKindV1 interval =
              StatisticalIntervalKindV1::none;
          switch (solver.interval_method) {
            case MonteCarloIntervalMethod::exact_binomial:
              interval = StatisticalIntervalKindV1::exact_binomial;
              break;
            case MonteCarloIntervalMethod::hoeffding:
              interval = StatisticalIntervalKindV1::hoeffding;
              break;
            case MonteCarloIntervalMethod::none:
              interval = StatisticalIntervalKindV1::none;
              break;
          }
          const bool binary =
              is_binary_proportion_metric(origin.kind, origin.parameters);
          const StatisticalEstimandKindV1 estimand =
              interval == StatisticalIntervalKindV1::none
                  ? StatisticalEstimandKindV1::point_with_variance_diagnostics
                  : (binary ? StatisticalEstimandKindV1::binary_proportion
                            : StatisticalEstimandKindV1::bounded_iid);
          return AccuracyRequirementV1{
              regime,
              MonteCarloAccuracyV1{
                  solver.replications, solver.confidence_level, interval,
                  estimand,
                  binary ? std::optional<ExactRational>{ExactRational::zero()}
                         : std::nullopt,
                  binary ? std::optional<ExactRational>{ExactRational::one()}
                         : std::nullopt},
              interval != StatisticalIntervalKindV1::none};
        } else {
          return AccuracyRequirementV1{regime, DirectExactAccuracyV1{}, true};
        }
      },
      context.solver);
}

[[nodiscard]] MetricClauseOriginV1 make_origin(
    const MetricRequest& request) {
  const MetricRequestHeader& header = metric_request_header(request);
  return MetricClauseOriginV1{
      MetricClauseIdV1{header.metric_id, header.authored_index},
      header.kind,
      metric_request_parameters(request),
      header.coupling,
      header.ordered_targets,
      header.selection_regime,
      header.solver_regime,
      header.context,
      header.provenance};
}

[[nodiscard]] ArrivalRequirementV1 arrival_need(
    const ArrivalNeedKindV1 kind, const bool joint = false,
    std::optional<BigNat> moment_order = std::nullopt,
    const bool phase_conditioned = false) {
  return ArrivalRequirementV1{
      kind,
      ArrivalCapabilityUseV1::runtime,
      CapabilityProvisionNeedV1::any,
      std::move(moment_order),
      joint,
      phase_conditioned,
      std::nullopt,
      std::nullopt,
      std::nullopt};
}

[[nodiscard]] ArrivalRequirementAlternativeV1 arrival_all(
    std::initializer_list<ArrivalRequirementV1> needs) {
  return ArrivalRequirementAlternativeV1{
      std::vector<ArrivalRequirementV1>(needs)};
}

[[nodiscard]] ArrivalRequirementAlternativeV1 temporal_arrival(
    const bool joint, const bool labels = false) {
  std::vector<ArrivalRequirementV1> needs;
  needs.push_back(arrival_need(ArrivalNeedKindV1::full_common_batch, joint));
  needs.push_back(arrival_need(ArrivalNeedKindV1::predictive_phase, joint));
  needs.push_back(arrival_need(ArrivalNeedKindV1::sequential_law, joint));
  if (labels) {
    needs.push_back(arrival_need(ArrivalNeedKindV1::entrance_labels, joint));
  }
  return ArrivalRequirementAlternativeV1{std::move(needs)};
}

[[nodiscard]] ArrivalRequirementAlternativeV1 iid_arrival(
    const bool joint, const bool labels = false) {
  std::vector<ArrivalRequirementV1> needs;
  needs.push_back(arrival_need(ArrivalNeedKindV1::exact_iid_late, joint));
  needs.push_back(arrival_need(ArrivalNeedKindV1::full_common_batch, joint));
  if (labels) {
    needs.push_back(arrival_need(ArrivalNeedKindV1::entrance_labels, joint));
  }
  return ArrivalRequirementAlternativeV1{std::move(needs)};
}

[[nodiscard]] bool arrival_has(const ArrivalRequirementAlternativeV1& arrival,
                               const ArrivalNeedKindV1 kind) noexcept {
  return std::any_of(arrival.all_of.begin(), arrival.all_of.end(),
                     [kind](const ArrivalRequirementV1& need) {
                       return need.kind == kind;
                     });
}

[[nodiscard]] HypothesisRequirementV1 hypothesis(
    const HypothesisKindV1 kind,
    const HypothesisSatisfactionKindV1 satisfaction =
        HypothesisSatisfactionKindV1::required_evidence,
    std::optional<MomentVariableV1> variable = std::nullopt,
    std::optional<BigNat> order = std::nullopt,
    std::optional<TypedLabel> convention = std::nullopt) {
  return HypothesisRequirementV1{
      HypothesisClaimV1{kind, std::move(variable), std::move(order),
                        std::move(convention)},
      satisfaction};
}

[[nodiscard]] MarkRequirementV1 mark(
    const MetricMarkKindV1 kind, const MetricRevealStageV1 stage,
    const MarkRelationRequirementV1 relation,
    const MarkTargetScopeRequirementV1 scope) {
  return MarkRequirementV1{kind, stage, relation, scope};
}

[[nodiscard]] SemanticContractAlternativeV1 semantic(
    ReusableMetricLawRequirementV1 law,
    const EntranceLawRequirementV1 entrance,
    const TargetCouplingV1 coupling,
    const bool temporal_source = false,
    const bool full_history = false) {
  return SemanticContractAlternativeV1{std::move(law), entrance, coupling,
                                       temporal_source, full_history};
}

[[nodiscard]] AccessAlternativeV1 access(
    const RuntimeAccessTagV1 tag, const BackendRouteKindV1 route,
    const bool c24_only = false, const bool exact_only = false) {
  return AccessAlternativeV1{tag, route, c24_only, exact_only};
}

struct ClauseBuilder final {
  explicit ClauseBuilder(const MetricRequest& request)
      : origin(make_origin(request)),
        coupling(target_coupling(origin.wire_coupling)),
        selection(SelectionRequirementV1{
            {selection_kind(origin.selection_regime)},
            EntranceLawRequirementV1::none,
            is_stationary_selection(origin.selection_regime)}),
        accuracy(make_accuracy(origin)) {}

  MetricClauseOriginV1 origin;
  TargetCouplingV1 coupling;
  SelectionRequirementV1 selection;
  std::vector<MetricRouteAlternativeV1> routes;
  std::vector<ArrivalRequirementAlternativeV1> declared_arrivals;
  std::vector<HypothesisRequirementV1> common_hypotheses;
  std::vector<MomentRequirementV1> moments;
  AccuracyRequirementV1 accuracy;

  void add_route(SemanticContractAlternativeV1 semantic_value,
                 AccessAlternativeV1 access_value,
                 ArrivalRequirementAlternativeV1 arrival_value,
                 std::vector<MarkRequirementV1> marks = {},
                 std::vector<HypothesisRequirementV1> hypotheses = {}) {
    routes.push_back(MetricRouteAlternativeV1{
        std::move(semantic_value), std::move(access_value),
        std::move(arrival_value), std::move(marks), std::move(hypotheses)});
  }
};

[[nodiscard]] std::vector<AccessAlternativeV1> reusable_accesses(
    const MetricClauseOriginV1& origin, const BackendRouteKindV1 route,
    const bool residence_capable, const bool c24_reward_capable) {
  switch (origin.solver_regime) {
    case MetricSolverRegimeV1::enumerated: {
      std::vector<AccessAlternativeV1> result{
          access(RuntimeAccessTagV1::finite_enumerated_row, route),
          access(RuntimeAccessTagV1::sparse_row, route)};
      if (residence_capable) {
        // An audited ROMR provider may be procedurally represented while its
        // complete residence-word rows are exactly enumerable.  C21 consumes
        // that exact word law; it does not promote a sampler or change the
        // authored enumerated solver regime.
        result.push_back(access(
            RuntimeAccessTagV1::procedural_residence_generator, route));
      }
      return result;
    }
    case MetricSolverRegimeV1::analytic: {
      std::vector<AccessAlternativeV1> result{
          access(RuntimeAccessTagV1::analytic_transform, route),
          access(RuntimeAccessTagV1::finite_parameter_analytic_family, route)};
      if (residence_capable) {
        result.push_back(access(RuntimeAccessTagV1::procedural_residence_generator,
                                route));
      }
      return result;
    }
    case MetricSolverRegimeV1::monte_carlo:
      if (c24_reward_capable) {
        return {access(RuntimeAccessTagV1::normalized_conditional_sampler,
                       BackendRouteKindV1::conditional_reward_monte_carlo,
                       true)};
      }
      return {};
    case MetricSolverRegimeV1::direct:
      return {};
  }
  return {};
}

void add_reusable_routes(
    ClauseBuilder& builder, const SemanticContractAlternativeV1& contract,
    const BackendRouteKindV1 route,
    const std::vector<ArrivalRequirementAlternativeV1>& arrivals,
    const std::vector<MarkRequirementV1>& marks,
    const std::vector<HypothesisRequirementV1>& route_hypotheses = {},
    const bool residence_capable = false,
    const bool c24_reward_capable = false) {
  builder.declared_arrivals.insert(builder.declared_arrivals.end(),
                                   arrivals.begin(), arrivals.end());
  for (const AccessAlternativeV1& candidate : reusable_accesses(
           builder.origin, route, residence_capable, c24_reward_capable)) {
    for (const ArrivalRequirementAlternativeV1& arrival : arrivals) {
      SemanticContractAlternativeV1 correlated_contract = contract;
      std::vector<MarkRequirementV1> correlated_marks = marks;
      const bool composed_predictive_phase =
          arrival_has(arrival, ArrivalNeedKindV1::predictive_phase);
      if (!composed_predictive_phase) {
        // The IID-late route has no configured predictive arrival phase to
        // retain or decode.  This is a route-local relaxation, never an
        // axis-wise choice: the paired temporal route keeps both obligations.
        correlated_marks.erase(
            std::remove_if(correlated_marks.begin(), correlated_marks.end(),
                           [](const MarkRequirementV1& requirement) {
                             return requirement.kind ==
                                    MetricMarkKindV1::predictive_phase;
                           }),
            correlated_marks.end());
        if (auto* invariant =
                std::get_if<SelectedInvariantMarginalRequirementV1>(
                    &correlated_contract.law);
            invariant != nullptr) {
          invariant->retain_predictive_phase = false;
        }
      }
      // A route is the authoritative conjunctive unit.  Common mathematical
      // premises therefore live in every complete tuple; the flattened
      // hypothesis projection below is diagnostic acceleration only.
      std::vector<HypothesisRequirementV1> hypotheses =
          builder.common_hypotheses;
      hypotheses.insert(hypotheses.end(), route_hypotheses.begin(),
                        route_hypotheses.end());
      if (residence_capable &&
          candidate.runtime_access ==
              RuntimeAccessTagV1::procedural_residence_generator &&
          is_stationary_selection(builder.origin.selection_regime)) {
        // A stationary result derived from complete residence words is
        // available only through C21's audited suspension/inversion. Keep
        // that proof obligation in the same conjunctive route as the
        // procedural ROMR access instead of treating a residence generator
        // as an already-stationary slot law.
        hypotheses.push_back(
            hypothesis(HypothesisKindV1::c21_suspension_inversion));
      }
      if (arrival_has(arrival, ArrivalNeedKindV1::exact_iid_late)) {
        hypotheses.push_back(hypothesis(HypothesisKindV1::iid_late_arrival));
      }
      if (arrival_has(arrival, ArrivalNeedKindV1::predictive_phase)) {
        hypotheses.push_back(hypothesis(HypothesisKindV1::predictive_phase));
      }
      builder.add_route(std::move(correlated_contract), candidate, arrival,
                        std::move(correlated_marks),
                        std::move(hypotheses));
    }
  }
}

void add_direct_route(ClauseBuilder& builder) {
  if (builder.origin.solver_regime != MetricSolverRegimeV1::direct) {
    return;
  }
  if (builder.declared_arrivals.empty()) {
    builder.declared_arrivals.push_back(arrival_all({}));
  }
  for (const ArrivalRequirementAlternativeV1& arrival :
       builder.declared_arrivals) {
    std::vector<HypothesisRequirementV1> hypotheses =
        builder.common_hypotheses;
    if (arrival_has(arrival, ArrivalNeedKindV1::exact_iid_late)) {
      hypotheses.push_back(hypothesis(HypothesisKindV1::iid_late_arrival));
    }
    if (arrival_has(arrival, ArrivalNeedKindV1::predictive_phase)) {
      hypotheses.push_back(hypothesis(HypothesisKindV1::predictive_phase));
    }
    builder.add_route(
        semantic(ExactRequestDecoderRequirementV1{true},
                 builder.selection.entrance, builder.coupling),
        access(RuntimeAccessTagV1::direct_metric_decoder,
               BackendRouteKindV1::exact_direct, false, true),
        arrival, {}, std::move(hypotheses));
  }
}

[[nodiscard]] bool mark_less(const MarkRequirementV1& left,
                             const MarkRequirementV1& right) noexcept {
  return std::tie(left.kind, left.latest_reveal_stage, left.relation,
                  left.target_scope) <
         std::tie(right.kind, right.latest_reveal_stage, right.relation,
                  right.target_scope);
}

template <typename T, typename Less = std::less<T>>
void sort_unique(std::vector<T>& values, Less less = Less{}) {
  std::sort(values.begin(), values.end(), less);
  values.erase(std::unique(values.begin(), values.end()), values.end());
}

[[nodiscard]] MetricRequirementClause finish_clause(ClauseBuilder builder) {
  add_direct_route(builder);

  const SolverRegimeV1 required_solver =
      solver_regime(builder.origin.solver_regime);

  std::vector<SemanticContractAlternativeV1> semantics;
  std::vector<MarkRequirementV1> marks;
  std::vector<ArrivalRequirementAlternativeV1> arrival_alternatives;
  std::vector<AccessAlternativeV1> accesses;
  std::vector<HypothesisRequirementV1> hypotheses = builder.common_hypotheses;
  semantics.reserve(builder.routes.size());
  arrival_alternatives.reserve(builder.routes.size());
  accesses.reserve(builder.routes.size());
  for (const MetricRouteAlternativeV1& route : builder.routes) {
    semantics.push_back(route.semantic);
    arrival_alternatives.push_back(route.arrival);
    accesses.push_back(route.access);
    marks.insert(marks.end(), route.marks.begin(), route.marks.end());
    hypotheses.insert(hypotheses.end(), route.hypotheses.begin(),
                      route.hypotheses.end());
  }
  sort_unique(marks, mark_less);

  return MetricRequirementClause{
      std::move(builder.origin),
      std::move(builder.routes),
      std::move(semantics),
      std::move(marks),
      builder.coupling,
      std::move(builder.selection),
      ArrivalRequirementSetV1{std::move(arrival_alternatives)},
      AccessRequirementV1{required_solver, std::move(accesses)},
      std::move(hypotheses),
      std::move(builder.moments),
      std::move(builder.accuracy),
      ValidityRequirementV1{true}};
}

void require_stationary(ClauseBuilder& builder) {
  builder.common_hypotheses.push_back(
      hypothesis(HypothesisKindV1::proper_stationary));
  builder.common_hypotheses.push_back(
      hypothesis(HypothesisKindV1::invariant_selected));
  builder.selection.require_unique_or_explicit_selection = true;
}

void require_common_schedule(ClauseBuilder& builder,
                             const bool full_identity = false) {
  builder.coupling = full_identity ? TargetCouplingV1::full_schedule_identity
                                   : TargetCouplingV1::common_schedule_projection;
  builder.common_hypotheses.push_back(
      hypothesis(HypothesisKindV1::common_schedule));
}

[[nodiscard]] std::vector<ArrivalRequirementAlternativeV1>
ordinary_arrival_routes(const bool joint = false) {
  return {temporal_arrival(joint), iid_arrival(joint)};
}

[[nodiscard]] std::vector<ArrivalRequirementAlternativeV1>
labelled_arrival_routes(const bool joint = false) {
  return {temporal_arrival(joint, true), iid_arrival(joint, true)};
}

[[nodiscard]] std::vector<ArrivalRequirementAlternativeV1>
labelled_arrival_routes_with_target_intensity(const bool joint = false) {
  std::vector<ArrivalRequirementAlternativeV1> routes =
      labelled_arrival_routes(joint);
  for (auto& route : routes) {
    // Admission-Palm selection is defined only when the target admission
    // intensity is available (and later proved positive).  Entrance labels
    // and replay alone do not provide that normalization constant.
    route.all_of.insert(
        route.all_of.begin(),
        arrival_need(ArrivalNeedKindV1::target_intensity));
  }
  return routes;
}

[[nodiscard]] std::vector<BigNat> zero_and_lags(
    const std::vector<BigNat>& lags) {
  std::vector<BigNat> offsets;
  offsets.reserve(lags.size() + 1U);
  offsets.emplace_back(0U);
  offsets.insert(offsets.end(), lags.begin(), lags.end());
  std::sort(offsets.begin(), offsets.end());
  offsets.erase(std::unique(offsets.begin(), offsets.end()), offsets.end());
  return offsets;
}

[[nodiscard]] BigNat positive_predecessor(const BigNat& value) {
  Result<BigNat> result = checked_subtract(value, BigNat{1U});
  // C03 has already proved positivity for every caller (window widths and
  // positive sequence horizons).  A failure is therefore unreachable at this
  // pure requirement-mapping boundary.
  if (!result) {
    return BigNat{0U};
  }
  return std::move(result).value();
}

[[nodiscard]] std::vector<MarkRequirementV1> queue_path_marks(
    const MarkTargetScopeRequirementV1 target_scope) {
  return {
      mark(MetricMarkKindV1::target_backlog,
           MetricRevealStageV1::predecision,
           MarkRelationRequirementV1::ordered_temporal_word, target_scope),
      mark(MetricMarkKindV1::opportunity,
           MetricRevealStageV1::predecision,
           MarkRelationRequirementV1::ordered_temporal_word, target_scope),
      mark(MetricMarkKindV1::actual_departure,
           MetricRevealStageV1::decision,
           MarkRelationRequirementV1::ordered_temporal_word, target_scope),
      mark(MetricMarkKindV1::arrival_batch, MetricRevealStageV1::arrival,
           MarkRelationRequirementV1::same_arrival_realization, target_scope),
      mark(MetricMarkKindV1::successor_backlog,
           MetricRevealStageV1::postarrival,
           MarkRelationRequirementV1::ordered_temporal_word, target_scope),
      mark(MetricMarkKindV1::predictive_phase,
           MetricRevealStageV1::postarrival,
           MarkRelationRequirementV1::ordered_temporal_word, target_scope),
  };
}

[[nodiscard]] MetricRequirements build_requirements_aggregate(
    std::vector<MetricRequirementClause> clauses,
    std::vector<MetricClauseIdV1> authored_diagnostic_order);

}  // namespace

MetricRequirements requirements_for_metric(const MetricRequest& request) {
  ClauseBuilder builder(request);
  const MarkTargetScopeRequirementV1 scalar_scope =
      MarkTargetScopeRequirementV1::singleton_target;
  const MarkTargetScopeRequirementV1 vector_scope =
      MarkTargetScopeRequirementV1::ordered_metric_target_vector;

  switch (builder.origin.kind) {
    case MetricKindV1::stationary_throughput: {
      require_stationary(builder);
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::lossless));
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::moment_finite,
                     HypothesisSatisfactionKindV1::theorem_or_separate_evidence,
                     MomentVariableV1::arrival, BigNat{1U}));
      builder.moments.push_back(MomentRequirementV1{
          MomentVariableV1::arrival, BigNat{1U},
          MomentConditioningV1::stationary, builder.origin.ordered_targets,
          false});
      const auto law = semantic(
          FrameworkDerivedScalarRequirementV1{
              FrameworkScalarKindV1::arrival_intensity},
          EntranceLawRequirementV1::none, builder.coupling);
      add_reusable_routes(
          builder, law, BackendRouteKindV1::framework_scalar_identity,
          {arrival_all({arrival_need(ArrivalNeedKindV1::target_intensity)})},
          {});
      break;
    }

    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::stationary_backlog_pmf:
    case MetricKindV1::stationary_backlog_pgf:
    case MetricKindV1::stationary_backlog_quantile:
    case MetricKindV1::stationary_backlog_tail: {
      require_stationary(builder);
      const std::vector<MarkRequirementV1> marks{
          mark(MetricMarkKindV1::target_backlog,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge, scalar_scope),
          mark(MetricMarkKindV1::opportunity,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge, scalar_scope),
          mark(MetricMarkKindV1::predictive_phase,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge, scalar_scope),
      };
      const auto law = semantic(SelectedInvariantMarginalRequirementV1{true},
                                EntranceLawRequirementV1::none,
                                builder.coupling);
      std::vector<ArrivalRequirementAlternativeV1> arrivals =
          ordinary_arrival_routes();
      if (builder.origin.kind == MetricKindV1::stationary_backlog_pgf) {
        const auto& points =
            std::get<StationaryBacklogPgfParametersV1>(
                builder.origin.parameters)
                .points;
        const auto bounds = std::minmax_element(points.begin(), points.end());
        const ExactArgumentDomain target_domain{
            *bounds.first, *bounds.second, true, true};
        ArrivalRequirementV1 coordinate_pgf =
            arrival_need(ArrivalNeedKindV1::transform);
        coordinate_pgf.transform_kind = TransformKind::exact_pgf;
        coordinate_pgf.distribution_scope =
            DistributionScope::per_coordinate;
        coordinate_pgf.argument_domain = target_domain;
        arrivals.push_back(arrival_all(
            {arrival_need(ArrivalNeedKindV1::exact_iid_late), coordinate_pgf}));

        ArrivalRequirementV1 joint_pgf = coordinate_pgf;
        joint_pgf.distribution_scope = DistributionScope::joint_vector;
        // Reading a target marginal from a joint PGF holds all other
        // coordinates at one, so one is part of the required exact domain
        // even when every authored query point lies strictly on one side.
        const ExactRational one = ExactRational::one();
        joint_pgf.argument_domain = ExactArgumentDomain{
            std::min(*bounds.first, one), std::max(*bounds.second, one), true,
            true};
        arrivals.push_back(arrival_all(
            {arrival_need(ArrivalNeedKindV1::exact_iid_late), joint_pgf}));
      }
      add_reusable_routes(builder, law,
                          BackendRouteKindV1::stationary_invariant, arrivals,
                          marks, {}, true);
      add_reusable_routes(
          builder,
          semantic(StationaryMarkedEdgeRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_edge_reward, arrivals, marks, {},
          true);
      break;
    }

    case MetricKindV1::stationary_backlog_moment: {
      require_stationary(builder);
      const BigNat order =
          std::get<StationaryBacklogMomentParametersV1>(
              builder.origin.parameters)
              .order;
      builder.common_hypotheses.push_back(hypothesis(
          HypothesisKindV1::moment_finite,
          HypothesisSatisfactionKindV1::required_evidence,
          MomentVariableV1::backlog, order));
      builder.moments.push_back(MomentRequirementV1{
          MomentVariableV1::backlog, order, MomentConditioningV1::stationary,
          builder.origin.ordered_targets, false});
      const auto law = semantic(SelectedInvariantMarginalRequirementV1{true},
                                EntranceLawRequirementV1::none,
                                builder.coupling);
      add_reusable_routes(
          builder, law, BackendRouteKindV1::stationary_invariant,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope),
           mark(MetricMarkKindV1::opportunity,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope)},
          {}, true);
      add_reusable_routes(
          builder,
          semantic(StationaryMarkedEdgeRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_edge_reward,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope),
           mark(MetricMarkKindV1::opportunity,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::backlog_conditioned_service: {
      require_stationary(builder);
      const auto& parameters =
          std::get<BacklogConditionedServiceParametersV1>(
              builder.origin.parameters);
      const HypothesisRequirementV1 conditioning = hypothesis(
          HypothesisKindV1::positive_conditioning_mass,
          HypothesisSatisfactionKindV1::
              required_or_declared_off_support_convention);
      builder.common_hypotheses.push_back(conditioning);

      const std::vector<ArrivalRequirementAlternativeV1> arrivals =
          ordinary_arrival_routes();
      const auto edge = semantic(StationaryMarkedEdgeRequirementV1{true},
                                 EntranceLawRequirementV1::none,
                                 builder.coupling);
      add_reusable_routes(
          builder, edge, BackendRouteKindV1::stationary_edge_reward, arrivals,
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge, scalar_scope),
           mark(MetricMarkKindV1::opportunity,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge, scalar_scope),
           mark(MetricMarkKindV1::actual_departure,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::same_completed_edge, scalar_scope)},
          {conditioning}, false, true);

      const auto point = semantic(
          ExactPointResponseRequirementV1{parameters.levels, true, true},
          EntranceLawRequirementV1::none, builder.coupling);
      add_reusable_routes(
          builder, point, BackendRouteKindV1::analytic_metric_family, arrivals,
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::individual, scalar_scope),
           mark(MetricMarkKindV1::opportunity,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::individual, scalar_scope)},
          {conditioning}, false, true);
      break;
    }

    case MetricKindV1::stationary_edge_reward: {
      require_stationary(builder);
      const auto& parameters =
          std::get<StationaryEdgeRewardParametersV1>(
              builder.origin.parameters);
      builder.common_hypotheses.push_back(hypothesis(
          HypothesisKindV1::reward_integrable,
          HypothesisSatisfactionKindV1::required_evidence,
          MomentVariableV1::edge_reward, parameters.moment_order));
      builder.moments.push_back(MomentRequirementV1{
          MomentVariableV1::edge_reward, parameters.moment_order,
          MomentConditioningV1::stationary, builder.origin.ordered_targets,
          false});

      std::vector<MarkRequirementV1> marks;
      if (parameters.reward == EdgeRewardKind::departure) {
        marks.push_back(mark(MetricMarkKindV1::actual_departure,
                             MetricRevealStageV1::decision,
                             MarkRelationRequirementV1::same_completed_edge,
                             scalar_scope));
      } else if (parameters.reward == EdgeRewardKind::arrival) {
        marks.push_back(mark(MetricMarkKindV1::arrival_batch,
                             MetricRevealStageV1::arrival,
                             MarkRelationRequirementV1::same_arrival_realization,
                             scalar_scope));
      } else {
        marks = {
            mark(MetricMarkKindV1::target_backlog,
                 MetricRevealStageV1::predecision,
                 MarkRelationRequirementV1::same_completed_edge, scalar_scope),
            mark(MetricMarkKindV1::actual_departure,
                 MetricRevealStageV1::decision,
                 MarkRelationRequirementV1::same_completed_edge, scalar_scope),
            mark(MetricMarkKindV1::arrival_batch,
                 MetricRevealStageV1::arrival,
                 MarkRelationRequirementV1::same_completed_edge, scalar_scope),
            mark(MetricMarkKindV1::successor_backlog,
                 MetricRevealStageV1::postarrival,
                 MarkRelationRequirementV1::same_completed_edge, scalar_scope),
            mark(MetricMarkKindV1::edge_increment,
                 MetricRevealStageV1::completed_edge,
                 MarkRelationRequirementV1::same_completed_edge, scalar_scope),
        };
      }
      add_reusable_routes(
          builder,
          semantic(StationaryMarkedEdgeRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_edge_reward,
          ordinary_arrival_routes(), marks, {}, false, true);
      break;
    }

    case MetricKindV1::mean_sojourn: {
      require_stationary(builder);
      builder.common_hypotheses.insert(
          builder.common_hypotheses.end(),
          {hypothesis(HypothesisKindV1::lossless),
           hypothesis(HypothesisKindV1::unit_packets),
           hypothesis(HypothesisKindV1::little_law),
           hypothesis(HypothesisKindV1::positive_finite_intensity),
           hypothesis(HypothesisKindV1::eventual_departure_or_accessible_class),
           hypothesis(HypothesisKindV1::moment_finite,
                      HypothesisSatisfactionKindV1::required_evidence,
                      MomentVariableV1::backlog, BigNat{1U})});
      builder.moments.push_back(MomentRequirementV1{
          MomentVariableV1::backlog, BigNat{1U},
          MomentConditioningV1::stationary, builder.origin.ordered_targets,
          false});
      const auto arrivals = ordinary_arrival_routes();
      const auto add_intensity = [](ArrivalRequirementAlternativeV1 route) {
        route.all_of.push_back(
            arrival_need(ArrivalNeedKindV1::target_intensity));
        return route;
      };
      std::vector<ArrivalRequirementAlternativeV1> with_intensity;
      for (const auto& route : arrivals) {
        with_intensity.push_back(add_intensity(route));
      }
      add_reusable_routes(
          builder,
          semantic(FrameworkDerivedScalarRequirementV1{
                       FrameworkScalarKindV1::stationary_backlog_mean},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::analytic_metric_family, with_intensity,
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::individual, scalar_scope)});
      break;
    }

    case MetricKindV1::service_persistence: {
      require_stationary(builder);
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::positive_event_intensity));
      const FiniteCylinderRequirementV1 cylinder{
          FiniteCylinderFamilyV1::target_departure,
          ExplicitCylinderOffsetsV1{{BigNat{0U}, BigNat{1U}}}, true};
      add_reusable_routes(
          builder,
          semantic(cylinder, EntranceLawRequirementV1::none, builder.coupling,
                   true, true),
          BackendRouteKindV1::finite_temporal_cylinder,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::actual_departure,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::service_autocovariance: {
      require_stationary(builder);
      const auto& parameters =
          std::get<ServiceAutocovarianceParametersV1>(
              builder.origin.parameters);
      const FiniteCylinderRequirementV1 cylinder{
          FiniteCylinderFamilyV1::target_departure,
          ExplicitCylinderOffsetsV1{zero_and_lags(parameters.lags)}, true};
      add_reusable_routes(
          builder,
          semantic(cylinder, EntranceLawRequirementV1::none, builder.coupling,
                   true, true),
          BackendRouteKindV1::finite_temporal_cylinder,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::actual_departure,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::service_spectrum: {
      require_stationary(builder);
      const auto& parameters = std::get<ServiceSpectrumParametersV1>(
          builder.origin.parameters);
      const FiniteCylinderRequirementV1 cylinder{
          FiniteCylinderFamilyV1::target_departure,
          InclusiveCylinderThroughV1{parameters.truncation_lag}, true};
      add_reusable_routes(
          builder,
          semantic(cylinder, EntranceLawRequirementV1::none, builder.coupling,
                   true, true),
          BackendRouteKindV1::finite_temporal_cylinder,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::actual_departure,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::service_window_count: {
      require_stationary(builder);
      const BigNat width =
          std::get<ServiceWindowCountParametersV1>(builder.origin.parameters)
              .width;
      const auto arrivals = ordinary_arrival_routes();
      add_reusable_routes(
          builder,
          semantic(PushforwardCountLawRequirementV1{width},
                   EntranceLawRequirementV1::none, builder.coupling, true,
                   true),
          BackendRouteKindV1::analytic_metric_family, arrivals,
          {mark(MetricMarkKindV1::actual_departure,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope)},
          {}, true);
      add_reusable_routes(
          builder,
          semantic(FiniteCylinderRequirementV1{
                       FiniteCylinderFamilyV1::target_departure,
                       InclusiveCylinderThroughV1{
                           positive_predecessor(width)},
                       true},
                   EntranceLawRequirementV1::none, builder.coupling, true,
                   true),
          BackendRouteKindV1::finite_temporal_cylinder, arrivals,
          {mark(MetricMarkKindV1::actual_departure,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::joint_backlog_covariance: {
      require_stationary(builder);
      require_common_schedule(builder);
      builder.common_hypotheses.push_back(hypothesis(
          HypothesisKindV1::moment_finite,
          HypothesisSatisfactionKindV1::required_evidence,
          MomentVariableV1::backlog, BigNat{2U}));
      builder.moments.push_back(MomentRequirementV1{
          MomentVariableV1::backlog, BigNat{2U},
          MomentConditioningV1::stationary, builder.origin.ordered_targets,
          true});
      const std::vector<MarkRequirementV1> marks{
          mark(MetricMarkKindV1::target_backlog,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge,
               vector_scope),
          mark(MetricMarkKindV1::schedule_projection,
               MetricRevealStageV1::decision,
               MarkRelationRequirementV1::common_feasible_schedule,
               vector_scope),
          mark(MetricMarkKindV1::predictive_phase,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge,
               vector_scope),
      };
      add_reusable_routes(
          builder,
          semantic(SelectedInvariantMarginalRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_invariant,
          ordinary_arrival_routes(true), marks);
      add_reusable_routes(
          builder,
          semantic(StationaryMarkedEdgeRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_edge_reward,
          ordinary_arrival_routes(true), marks);
      break;
    }

    case MetricKindV1::lagged_cross_queue_covariance: {
      require_stationary(builder);
      require_common_schedule(builder);
      builder.common_hypotheses.push_back(hypothesis(
          HypothesisKindV1::moment_finite,
          HypothesisSatisfactionKindV1::required_evidence,
          MomentVariableV1::backlog, BigNat{2U}));
      builder.moments.push_back(MomentRequirementV1{
          MomentVariableV1::backlog, BigNat{2U},
          MomentConditioningV1::stationary, builder.origin.ordered_targets,
          true});
      const auto& parameters =
          std::get<LaggedCrossQueueCovarianceParametersV1>(
              builder.origin.parameters);
      add_reusable_routes(
          builder,
          semantic(FiniteCylinderRequirementV1{
                       FiniteCylinderFamilyV1::coupled_backlog,
                       ExplicitCylinderOffsetsV1{
                           zero_and_lags(parameters.lags)},
                       true},
                   EntranceLawRequirementV1::none, builder.coupling, true,
                   true),
          BackendRouteKindV1::finite_temporal_cylinder,
          ordinary_arrival_routes(true),
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::ordered_temporal_word,
                vector_scope),
           mark(MetricMarkKindV1::schedule_projection,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::common_feasible_schedule,
                vector_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                vector_scope)});
      break;
    }

    case MetricKindV1::mean_event_gap: {
      require_stationary(builder);
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::positive_event_intensity));
      const auto& parameters =
          std::get<MeanEventGapParametersV1>(builder.origin.parameters);
      std::vector<MarkRequirementV1> marks{
          mark(MetricMarkKindV1::event_indicator,
               MetricRevealStageV1::completed_edge,
               MarkRelationRequirementV1::same_completed_edge,
               scalar_scope),
          mark(MetricMarkKindV1::active_component,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge,
               scalar_scope),
      };
      if (parameters.event == GapEventKind::departure) {
        marks.push_back(mark(MetricMarkKindV1::actual_departure,
                             MetricRevealStageV1::decision,
                             MarkRelationRequirementV1::same_completed_edge,
                             scalar_scope));
      } else if (parameters.event == GapEventKind::admission) {
        marks.push_back(mark(MetricMarkKindV1::arrival_batch,
                             MetricRevealStageV1::arrival,
                             MarkRelationRequirementV1::same_arrival_realization,
                             scalar_scope));
      } else {
        marks.push_back(mark(MetricMarkKindV1::opportunity,
                             MetricRevealStageV1::predecision,
                             MarkRelationRequirementV1::same_completed_edge,
                             scalar_scope));
        marks.push_back(mark(MetricMarkKindV1::actual_departure,
                             MetricRevealStageV1::decision,
                             MarkRelationRequirementV1::same_completed_edge,
                             scalar_scope));
      }
      add_reusable_routes(
          builder,
          semantic(FrameworkDerivedScalarRequirementV1{
                       FrameworkScalarKindV1::event_intensity_active_fraction},
                   EntranceLawRequirementV1::none, builder.coupling, true,
                   true),
          BackendRouteKindV1::analytic_metric_family,
          ordinary_arrival_routes(), marks, {}, true);
      break;
    }

    case MetricKindV1::event_gap_distribution: {
      require_stationary(builder);
      builder.selection.entrance = EntranceLawRequirementV1::event_palm;
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::positive_event_intensity));
      const auto& parameters =
          std::get<EventGapDistributionParametersV1>(
              builder.origin.parameters);
      std::vector<MarkRequirementV1> marks = queue_path_marks(scalar_scope);
      marks.push_back(mark(MetricMarkKindV1::event_indicator,
                           MetricRevealStageV1::completed_edge,
                           MarkRelationRequirementV1::ordered_temporal_word,
                           scalar_scope));
      if (parameters.event == GapEventKind::departure) {
        marks.push_back(mark(MetricMarkKindV1::actual_departure,
                             MetricRevealStageV1::decision,
                             MarkRelationRequirementV1::ordered_temporal_word,
                             scalar_scope));
      } else if (parameters.event == GapEventKind::admission) {
        marks.push_back(mark(MetricMarkKindV1::arrival_batch,
                             MetricRevealStageV1::arrival,
                             MarkRelationRequirementV1::ordered_temporal_word,
                             scalar_scope));
      } else {
        marks.push_back(mark(MetricMarkKindV1::opportunity,
                             MetricRevealStageV1::predecision,
                             MarkRelationRequirementV1::ordered_temporal_word,
                             scalar_scope));
      }
      add_reusable_routes(
          builder,
          semantic(ResidenceWordRequirementV1{
                       StoppingObservableKindV1::next_event,
                       parameters.horizon, true},
                   EntranceLawRequirementV1::event_palm, builder.coupling,
                   true, true),
          BackendRouteKindV1::residence_or_stopped_law,
          ordinary_arrival_routes(), marks, {}, true);
      break;
    }

    case MetricKindV1::mean_binary_run: {
      require_stationary(builder);
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::positive_start_intensity));
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::finite_start_component));
      add_reusable_routes(
          builder,
          semantic(FrameworkDerivedScalarRequirementV1{
                       FrameworkScalarKindV1::binary_occupation_start_ratio},
                   EntranceLawRequirementV1::none, builder.coupling, true,
                   true),
          BackendRouteKindV1::analytic_metric_family,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::predicate,
                MetricRevealStageV1::completed_edge,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope),
           mark(MetricMarkKindV1::predicate_start,
                MetricRevealStageV1::completed_edge,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope),
           mark(MetricMarkKindV1::active_component,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::same_completed_edge,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::binary_run_distribution: {
      require_stationary(builder);
      builder.selection.entrance = EntranceLawRequirementV1::run_start_palm;
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::positive_start_intensity));
      const auto& parameters =
          std::get<BinaryRunDistributionParametersV1>(
              builder.origin.parameters);
      std::vector<MarkRequirementV1> marks = queue_path_marks(scalar_scope);
      marks.push_back(mark(MetricMarkKindV1::predicate,
                           MetricRevealStageV1::completed_edge,
                           MarkRelationRequirementV1::ordered_temporal_word,
                           scalar_scope));
      marks.push_back(mark(MetricMarkKindV1::predicate_start,
                           MetricRevealStageV1::entrance_label,
                           MarkRelationRequirementV1::entrance_bound,
                           scalar_scope));
      add_reusable_routes(
          builder,
          semantic(ResidenceWordRequirementV1{
                       StoppingObservableKindV1::predicate_exit,
                       parameters.horizon, true},
                   EntranceLawRequirementV1::run_start_palm,
                   builder.coupling, true, true),
          BackendRouteKindV1::residence_or_stopped_law,
          ordinary_arrival_routes(), marks, {}, true);
      break;
    }

    case MetricKindV1::first_hit:
    case MetricKindV1::threshold_excursion: {
      const bool threshold_excursion =
          builder.origin.kind == MetricKindV1::threshold_excursion;
      const bool transient =
          builder.origin.selection_regime == MetricSelectionRegimeV1::transient;
      const EntranceLawRequirementV1 entrance =
          transient
              ? EntranceLawRequirementV1::prescribed_entrance
              : (threshold_excursion
                     ? EntranceLawRequirementV1::threshold_crossing_palm
                     : EntranceLawRequirementV1::none);
      if (!transient) {
        require_stationary(builder);
        if (threshold_excursion) {
          builder.common_hypotheses.push_back(
              hypothesis(HypothesisKindV1::positive_start_intensity));
        }
      }
      builder.selection.entrance = entrance;
      const BigNat horizon = threshold_excursion
                                 ? std::get<ThresholdExcursionParametersV1>(
                                       builder.origin.parameters)
                                       .horizon
                                 : std::get<FirstHitParametersV1>(
                                       builder.origin.parameters)
                                       .horizon;
      const bool include_mean =
          threshold_excursion
              ? std::get<ThresholdExcursionParametersV1>(
                    builder.origin.parameters)
                    .include_mean
              : std::get<FirstHitParametersV1>(builder.origin.parameters)
                    .include_mean;
      if (include_mean) {
        builder.common_hypotheses.push_back(
            hypothesis(HypothesisKindV1::nondefective));
        builder.common_hypotheses.push_back(hypothesis(
            HypothesisKindV1::moment_finite,
            HypothesisSatisfactionKindV1::required_evidence,
            MomentVariableV1::stopped_time, BigNat{1U}));
        builder.moments.push_back(MomentRequirementV1{
            MomentVariableV1::stopped_time, BigNat{1U},
            MomentConditioningV1::stopped_entrance,
            builder.origin.ordered_targets, false});
      }
      std::vector<MarkRequirementV1> marks = queue_path_marks(scalar_scope);
      if (threshold_excursion && !transient) {
        marks.push_back(mark(MetricMarkKindV1::predicate_start,
                             MetricRevealStageV1::entrance_label,
                             MarkRelationRequirementV1::entrance_bound,
                             scalar_scope));
      }
      add_reusable_routes(
          builder,
          semantic(StoppedPathRequirementV1{
                       threshold_excursion
                           ? StoppingObservableKindV1::threshold_return
                           : StoppingObservableKindV1::backlog_set_hit,
                       horizon, true, include_mean},
                   entrance, builder.coupling, true, true),
          BackendRouteKindV1::residence_or_stopped_law,
          ordinary_arrival_routes(),
          marks, {}, true);
      break;
    }

    case MetricKindV1::transient_backlog_law: {
      // This is the sole analysis-v1 metric whose reusable route is
      // intrinsically transient-only.  Parser validation rejects any other
      // selection; retaining the exact selection here makes defensive direct
      // calls negotiate as incompatible rather than quietly stationarizing.
      builder.selection.entrance =
          EntranceLawRequirementV1::configured_transient_initial;
      builder.selection.accepted_analysis_selections =
          {SelectionKindV1::transient_initial};
      const auto& parameters =
          std::get<TransientBacklogLawParametersV1>(
              builder.origin.parameters);
      add_reusable_routes(
          builder,
          semantic(FiniteCylinderRequirementV1{
                       FiniteCylinderFamilyV1::target_backlog,
                       ExplicitCylinderOffsetsV1{parameters.horizons}, true},
                   EntranceLawRequirementV1::configured_transient_initial,
                   builder.coupling, true, true),
          BackendRouteKindV1::finite_temporal_cylinder,
          ordinary_arrival_routes(), queue_path_marks(scalar_scope), {},
          true);
      break;
    }

    case MetricKindV1::fifo_delay:
    case MetricKindV1::fifo_delay_conditioned: {
      require_stationary(builder);
      builder.selection.entrance = EntranceLawRequirementV1::admission_palm;
      builder.common_hypotheses.insert(
          builder.common_hypotheses.end(),
          {hypothesis(HypothesisKindV1::lossless),
           hypothesis(HypothesisKindV1::unit_packets),
           hypothesis(HypothesisKindV1::fifo),
           hypothesis(HypothesisKindV1::little_law),
           hypothesis(HypothesisKindV1::positive_finite_intensity),
           hypothesis(HypothesisKindV1::eventual_departure_or_accessible_class)});
      const FifoDelayOutputV1& output =
          builder.origin.kind == MetricKindV1::fifo_delay
              ? std::get<FifoDelayParametersV1>(builder.origin.parameters)
                    .output
              : std::get<FifoDelayConditionedParametersV1>(
                    builder.origin.parameters)
                    .output;
      std::optional<BigNat> output_horizon;
      bool finite_mean_requested = false;
      std::visit(
          [&](const auto& typed_output) {
            using Output = std::decay_t<decltype(typed_output)>;
            if constexpr (std::is_same_v<Output, FifoDelayPmfOutputV1> ||
                          std::is_same_v<Output, FifoDelayTailOutputV1>) {
              output_horizon = typed_output.horizon;
            } else if constexpr (std::is_same_v<Output,
                                                FifoDelayMomentOutputV1>) {
              finite_mean_requested = true;
              builder.common_hypotheses.push_back(hypothesis(
                  HypothesisKindV1::moment_finite,
                  HypothesisSatisfactionKindV1::required_evidence,
                  MomentVariableV1::fifo_delay, typed_output.order));
              builder.moments.push_back(MomentRequirementV1{
                  MomentVariableV1::fifo_delay, typed_output.order,
                  MomentConditioningV1::admission_palm,
                  builder.origin.ordered_targets, false});
            }
          },
          output);
      std::vector<MarkRequirementV1> marks = queue_path_marks(scalar_scope);
      marks.push_back(mark(MetricMarkKindV1::within_batch_rank,
                           MetricRevealStageV1::entrance_label,
                           MarkRelationRequirementV1::entrance_bound,
                           scalar_scope));
      marks.push_back(mark(MetricMarkKindV1::batch_size,
                           MetricRevealStageV1::entrance_label,
                           MarkRelationRequirementV1::entrance_bound,
                           scalar_scope));
      if (builder.origin.kind == MetricKindV1::fifo_delay_conditioned) {
        const FifoConditionV1& condition =
            std::get<FifoDelayConditionedParametersV1>(
                builder.origin.parameters)
                .condition;
        const MetricMarkKindV1 conditional_mark = std::visit(
            [](const auto& typed_condition) {
              using Condition = std::decay_t<decltype(typed_condition)>;
              if constexpr (std::is_same_v<Condition,
                                           FifoRankConditionV1>) {
                return MetricMarkKindV1::within_batch_rank;
              } else if constexpr (std::is_same_v<Condition,
                                                  FifoBatchConditionV1>) {
                return MetricMarkKindV1::batch_size;
              } else if constexpr (std::is_same_v<Condition,
                                                  FifoClassConditionV1>) {
                return MetricMarkKindV1::class_label;
              } else {
                return MetricMarkKindV1::phase_label;
              }
            },
            condition);
        marks.push_back(mark(conditional_mark,
                             MetricRevealStageV1::entrance_label,
                             MarkRelationRequirementV1::entrance_bound,
                             scalar_scope));
      }
      add_reusable_routes(
          builder,
          semantic(StoppedPathRequirementV1{
                       StoppingObservableKindV1::tagged_packet_departure,
                       output_horizon, true, finite_mean_requested},
                   EntranceLawRequirementV1::admission_palm,
                   builder.coupling, true, true),
          BackendRouteKindV1::palm_or_fifo_law,
          labelled_arrival_routes_with_target_intensity(), marks, {}, true);
      break;
    }

    case MetricKindV1::counterfactual_opportunity_gap: {
      require_stationary(builder);
      builder.selection.entrance = EntranceLawRequirementV1::event_palm;
      const auto& parameters =
          std::get<CounterfactualOpportunityGapParametersV1>(
              builder.origin.parameters);
      builder.common_hypotheses.push_back(hypothesis(
          HypothesisKindV1::counterfactual_empty_convention,
          HypothesisSatisfactionKindV1::required_evidence, std::nullopt,
          std::nullopt, parameters.convention_id));
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::positive_event_intensity));
      builder.common_hypotheses.push_back(
          hypothesis(HypothesisKindV1::counterfactual_no_controller_mutation));
      add_reusable_routes(
          builder,
          semantic(ResidenceWordRequirementV1{
                       StoppingObservableKindV1::counterfactual_mark,
                       parameters.horizon, true},
                   EntranceLawRequirementV1::event_palm,
                   builder.coupling, true, true),
          BackendRouteKindV1::residence_or_stopped_law,
          ordinary_arrival_routes(),
          {mark(MetricMarkKindV1::target_backlog,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::opportunity,
                MetricRevealStageV1::predecision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::counterfactual_permission,
                MetricRevealStageV1::decision,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                scalar_scope)},
          {}, true);
      break;
    }

    case MetricKindV1::joint_backlog_event: {
      require_stationary(builder);
      require_common_schedule(builder);
      const std::vector<MarkRequirementV1> marks{
          mark(MetricMarkKindV1::target_backlog,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge,
               vector_scope),
          mark(MetricMarkKindV1::schedule_projection,
               MetricRevealStageV1::decision,
               MarkRelationRequirementV1::common_feasible_schedule,
               vector_scope),
          mark(MetricMarkKindV1::predictive_phase,
               MetricRevealStageV1::predecision,
               MarkRelationRequirementV1::same_completed_edge,
               vector_scope),
      };
      add_reusable_routes(
          builder,
          semantic(SelectedInvariantMarginalRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_invariant,
          ordinary_arrival_routes(true), marks);
      add_reusable_routes(
          builder,
          semantic(StationaryMarkedEdgeRequirementV1{true},
                   EntranceLawRequirementV1::none, builder.coupling),
          BackendRouteKindV1::stationary_edge_reward,
          ordinary_arrival_routes(true), marks);
      break;
    }

    case MetricKindV1::joint_delay: {
      require_stationary(builder);
      require_common_schedule(builder);
      builder.selection.entrance = EntranceLawRequirementV1::admission_palm;
      builder.common_hypotheses.insert(
          builder.common_hypotheses.end(),
          {hypothesis(HypothesisKindV1::lossless),
           hypothesis(HypothesisKindV1::unit_packets),
           hypothesis(HypothesisKindV1::fifo),
           hypothesis(HypothesisKindV1::positive_finite_intensity),
           hypothesis(HypothesisKindV1::eventual_departure_or_accessible_class)});
      const auto& parameters =
          std::get<JointDelayParametersV1>(builder.origin.parameters);
      BigNat joint_path_horizon = parameters.horizon;
      if (const auto* lagged =
              std::get_if<LaggedPalmSamplingV1>(&parameters.sampling);
          lagged != nullptr) {
        joint_path_horizon += lagged->lag;
      }
      std::vector<MarkRequirementV1> marks = queue_path_marks(vector_scope);
      marks.push_back(mark(MetricMarkKindV1::schedule_projection,
                           MetricRevealStageV1::decision,
                           MarkRelationRequirementV1::common_feasible_schedule,
                           vector_scope));
      marks.push_back(mark(MetricMarkKindV1::within_batch_rank,
                           MetricRevealStageV1::entrance_label,
                           MarkRelationRequirementV1::entrance_bound,
                           vector_scope));
      marks.push_back(mark(MetricMarkKindV1::batch_size,
                           MetricRevealStageV1::entrance_label,
                           MarkRelationRequirementV1::entrance_bound,
                           vector_scope));
      add_reusable_routes(
          builder,
          semantic(StoppedPathRequirementV1{
                       StoppingObservableKindV1::tagged_packet_departure,
                       joint_path_horizon, true, false},
                   EntranceLawRequirementV1::admission_palm,
                   builder.coupling, true, true),
          BackendRouteKindV1::palm_or_fifo_law,
          labelled_arrival_routes_with_target_intensity(true), marks, {},
          true);
      break;
    }

    case MetricKindV1::ordered_schedule_sequence: {
      const auto& parameters =
          std::get<OrderedScheduleSequenceParametersV1>(
              builder.origin.parameters);
      const bool transient =
          builder.origin.selection_regime == MetricSelectionRegimeV1::transient;
      if (transient) {
        builder.selection.entrance =
            EntranceLawRequirementV1::configured_transient_initial;
      } else {
        require_stationary(builder);
      }
      require_common_schedule(builder, parameters.retain_full_schedule);
      const MetricMarkKindV1 schedule_mark =
          parameters.retain_full_schedule ? MetricMarkKindV1::full_schedule
                                          : MetricMarkKindV1::schedule_projection;
      const MarkTargetScopeRequirementV1 schedule_scope =
          parameters.retain_full_schedule
              ? MarkTargetScopeRequirementV1::full_schedule_catalog
              : vector_scope;
      add_reusable_routes(
          builder,
          semantic(FiniteCylinderRequirementV1{
                       FiniteCylinderFamilyV1::coupled_schedule,
                       InclusiveCylinderThroughV1{
                           positive_predecessor(parameters.horizon)},
                       true},
                   transient
                       ? EntranceLawRequirementV1::configured_transient_initial
                       : EntranceLawRequirementV1::none,
                   builder.coupling, true, true),
          BackendRouteKindV1::finite_temporal_cylinder,
          ordinary_arrival_routes(true),
          {mark(schedule_mark, MetricRevealStageV1::decision,
                MarkRelationRequirementV1::common_feasible_schedule,
                schedule_scope),
           mark(MetricMarkKindV1::predictive_phase,
                MetricRevealStageV1::postarrival,
                MarkRelationRequirementV1::ordered_temporal_word,
                vector_scope)});
      break;
    }
  }

  const MetricClauseIdV1 clause_id = builder.origin.clause_id;
  std::vector<MetricRequirementClause> clauses;
  clauses.push_back(finish_clause(std::move(builder)));
  return build_requirements_aggregate(std::move(clauses), {clause_id});
}

namespace {

class RequirementCanonicalWriter final {
 public:
  void boolean(const bool value) { bytes_.push_back(value ? std::byte{1} : std::byte{0}); }

  void unsigned_integer(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(
          static_cast<std::byte>(value >> static_cast<unsigned int>(shift - 8U)));
    }
  }

  template <typename Enum>
    requires std::is_enum_v<Enum>
  void enumeration(const Enum value) {
    unsigned_integer(static_cast<std::uint64_t>(value));
  }

  void raw(std::span<const std::uint8_t> value) {
    unsigned_integer(static_cast<std::uint64_t>(value.size()));
    for (const std::uint8_t byte : value) {
      bytes_.push_back(static_cast<std::byte>(byte));
    }
  }

  void raw(std::span<const std::byte> value) {
    unsigned_integer(static_cast<std::uint64_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }

  void string(const std::string_view value) {
    unsigned_integer(static_cast<std::uint64_t>(value.size()));
    for (const char character : value) {
      bytes_.push_back(static_cast<std::byte>(
          static_cast<unsigned char>(character)));
    }
  }

  void natural(const BigNat& value) {
    const std::vector<std::uint8_t> magnitude =
        value.canonical_magnitude_bytes();
    raw(magnitude);
  }

  void rational(const ExactRational& value) {
    string(value.numerator_decimal());
    string(value.denominator_decimal());
  }

  void label(const TypedLabel& value) { raw(value.canonical_bytes()); }

  void queue(const QueueId& value) { raw(value.canonical_bytes()); }

  void target(const ResolvedMetricTargetV1& value) {
    queue(value.queue_id);
    unsigned_integer(static_cast<std::uint64_t>(value.dense_index.ordinal()));
  }

  template <typename T, typename Encoder>
  void optional(const std::optional<T>& value, Encoder encoder) {
    boolean(value.has_value());
    if (value.has_value()) {
      encoder(*this, *value);
    }
  }

  template <typename T, typename Encoder>
  void vector(const std::vector<T>& values, Encoder encoder) {
    unsigned_integer(static_cast<std::uint64_t>(values.size()));
    for (const T& value : values) {
      encoder(*this, value);
    }
  }

  template <typename T, typename Encoder>
  void vector(const std::span<const T> values, Encoder encoder) {
    unsigned_integer(static_cast<std::uint64_t>(values.size()));
    for (const T& value : values) {
      encoder(*this, value);
    }
  }

  [[nodiscard]] const std::vector<std::byte>& bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

void encode_source_node(RequirementCanonicalWriter& writer,
                        const SourceNode& node) {
  writer.enumeration(node.kind());
  switch (node.kind()) {
    case SourceNodeKind::null_value:
      break;
    case SourceNodeKind::boolean:
      writer.boolean(*node.boolean_value());
      break;
    case SourceNodeKind::number: {
      Result<ExactRational> parsed =
          parse_decimal_rational(NumericLexeme(*node.number_lexeme()));
      if (parsed) {
        writer.boolean(true);
        writer.rational(parsed.value());
      } else {
        // SourceNode can also be constructed directly by unit fixtures.  An
        // invalid lexeme is retained injectively rather than terminating the
        // deterministic diagnostic boundary.
        writer.boolean(false);
        writer.string(*node.number_lexeme());
      }
      break;
    }
    case SourceNodeKind::string:
      writer.string(*node.string_value());
      break;
    case SourceNodeKind::array: {
      const std::span<const SourceNode> items = node.array_items();
      writer.unsigned_integer(static_cast<std::uint64_t>(items.size()));
      for (const SourceNode& item : items) {
        encode_source_node(writer, item);
      }
      break;
    }
    case SourceNodeKind::object: {
      std::vector<const SourceObjectMember*> members;
      members.reserve(node.object_members().size());
      for (const SourceObjectMember& member : node.object_members()) {
        members.push_back(&member);
      }
      std::sort(members.begin(), members.end(),
                [](const SourceObjectMember* left,
                   const SourceObjectMember* right) {
                  return left->key < right->key;
                });
      writer.unsigned_integer(static_cast<std::uint64_t>(members.size()));
      for (const SourceObjectMember* member : members) {
        writer.string(member->key);
        encode_source_node(writer, member->value);
      }
      break;
    }
  }
}

void encode_arrival_initial_state(RequirementCanonicalWriter& writer,
                                  const ArrivalInitialState& state) {
  writer.unsigned_integer(static_cast<std::uint64_t>(state.index()));
  std::visit(
      [&](const auto& value) {
        using State = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<State, PrivateMarkovStates>) {
          writer.vector(value.states,
                        [](RequirementCanonicalWriter& output,
                           const PrivateMarkovState& item) {
                          output.string(item.source_id);
                          output.string(item.state);
                        });
        } else if constexpr (std::is_same_v<State, SharedRoundState>) {
          writer.string(value.state);
        }
      },
      state);
}

void encode_selection_spec(RequirementCanonicalWriter& writer,
                           const SelectionSpec& selection) {
  writer.unsigned_integer(static_cast<std::uint64_t>(selection.index()));
  std::visit(
      [&](const auto& value) {
        using Selection = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Selection, TransientSelection>) {
          writer.vector(
              value.atoms,
              [](RequirementCanonicalWriter& output,
                 const TransientInitialAtom& atom) {
                output.rational(atom.probability.exact_value());
                output.vector(
                    atom.backlog,
                    [](RequirementCanonicalWriter& backlog_output,
                       const InitialBacklogEntry& entry) {
                      backlog_output.label(entry.queue_id);
                      backlog_output.natural(entry.value);
                    });
                encode_arrival_initial_state(output, atom.arrival_state);
                encode_source_node(output, atom.controller_state);
                encode_source_node(output, atom.static_context);
                encode_source_node(output, atom.surrogate_initial);
              });
        } else if constexpr (std::is_same_v<Selection,
                                            StationaryClassSelection>) {
          writer.label(value.class_id);
        } else if constexpr (std::is_same_v<Selection,
                                            StationaryMixtureSelection>) {
          writer.vector(
              value.components,
              [](RequirementCanonicalWriter& output,
                 const StationaryMixtureComponent& component) {
                output.label(component.class_id);
                output.rational(component.probability.exact_value());
              });
        } else if constexpr (std::is_same_v<Selection,
                                            FixedPointSelection>) {
          writer.unsigned_integer(static_cast<std::uint64_t>(value.index()));
          std::visit(
              [&](const auto& fixed) {
                using Fixed = std::decay_t<decltype(fixed)>;
                if constexpr (std::is_same_v<Fixed,
                                             FixedPointIdSelection>) {
                  writer.label(fixed.solution_id);
                }
              },
              value);
        }
      },
      selection);
}

void encode_resolution(RequirementCanonicalWriter& writer,
                       const ResolutionEnvelope& resolution) {
  const auto encode_optional_nat = [](RequirementCanonicalWriter& output,
                                      const BigNat& value) {
    output.natural(value);
  };
  const auto encode_optional_rational = [](
                                           RequirementCanonicalWriter& output,
                                           const ExactRational& value) {
    output.rational(value);
  };
  writer.optional(resolution.level.max_states, encode_optional_nat);
  writer.optional(resolution.level.max_row_atoms, encode_optional_nat);
  writer.unsigned_integer(static_cast<std::uint64_t>(resolution.tail.index()));
  std::visit(
      [&](const auto& tail) {
        using Tail = std::decay_t<decltype(tail)>;
        if constexpr (std::is_same_v<Tail, FiniteClosedTailResolution>) {
          writer.natural(tail.max_level);
        } else if constexpr (std::is_same_v<
                                 Tail, ConstantResponseTailResolution>) {
          writer.natural(tail.cutoff);
        } else if constexpr (std::is_same_v<
                                 Tail, CertifiedTruncationTailResolution>) {
          writer.natural(tail.max_level);
          writer.rational(tail.max_tail_mass);
        }
      },
      resolution.tail);
  writer.optional(resolution.phase.max_phase_states, encode_optional_nat);
  writer.optional(resolution.optimizer.max_calls, encode_optional_nat);
  writer.optional(resolution.optimizer.max_search_states_per_call,
                  encode_optional_nat);
  writer.optional(resolution.sampling.max_generator_draws,
                  encode_optional_nat);
  writer.optional(resolution.tolerance.linear_residual_abs,
                  encode_optional_rational);
  writer.optional(resolution.tolerance.integration_abs,
                  encode_optional_rational);
  writer.optional(resolution.tolerance.tail_abs, encode_optional_rational);
  writer.optional(resolution.tolerance.fixed_point_abs,
                  encode_optional_rational);
}

void encode_solver_spec(RequirementCanonicalWriter& writer,
                        const SolverSpec& solver) {
  writer.unsigned_integer(static_cast<std::uint64_t>(solver.index()));
  std::visit(
      [&](const auto& value) {
        using Solver = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Solver, EnumeratedSolver>) {
          writer.enumeration(value.linear_method);
          writer.optional(value.max_iterations,
                          [](RequirementCanonicalWriter& output,
                             const BigNat& natural) {
                            output.natural(natural);
                          });
        } else if constexpr (std::is_same_v<Solver, AnalyticSolver>) {
          writer.natural(value.precision_bits);
          writer.optional(value.max_iterations,
                          [](RequirementCanonicalWriter& output,
                             const BigNat& natural) {
                            output.natural(natural);
                          });
        } else if constexpr (std::is_same_v<Solver, MonteCarloSolver>) {
          writer.natural(value.replications);
          writer.rational(value.confidence_level);
          writer.enumeration(value.interval_method);
        }
      },
      solver);
}

void encode_analysis_context(RequirementCanonicalWriter& writer,
                             const AnalysisContext& context) {
  writer.vector(context.targets.queue_ids,
                [](RequirementCanonicalWriter& output,
                   const TypedLabel& label) { output.label(label); });
  encode_resolution(writer, context.resolution);
  encode_selection_spec(writer, context.selection);
  encode_solver_spec(writer, context.solver);
}

void encode_fifo_output(RequirementCanonicalWriter& writer,
                        const FifoDelayOutputV1& output) {
  writer.unsigned_integer(static_cast<std::uint64_t>(output.index()));
  std::visit(
      [&](const auto& value) {
        using Output = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Output, FifoDelayPmfOutputV1> ||
                      std::is_same_v<Output, FifoDelayTailOutputV1>) {
          writer.natural(value.horizon);
        } else if constexpr (std::is_same_v<
                                 Output, FifoDelayQuantileOutputV1>) {
          writer.rational(value.probability);
          writer.enumeration(value.convention);
        } else {
          writer.natural(value.order);
        }
      },
      output);
}

void encode_fifo_condition(RequirementCanonicalWriter& writer,
                           const FifoConditionV1& condition) {
  writer.unsigned_integer(static_cast<std::uint64_t>(condition.index()));
  std::visit(
      [&](const auto& value) {
        using Condition = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Condition, FifoRankConditionV1>) {
          writer.natural(value.one_based_rank);
        } else if constexpr (std::is_same_v<Condition,
                                            FifoBatchConditionV1>) {
          writer.natural(value.batch_size);
        } else if constexpr (std::is_same_v<Condition,
                                            FifoClassConditionV1>) {
          writer.label(value.class_id);
        } else {
          writer.label(value.phase_id);
        }
      },
      condition);
}

void encode_metric_parameters(RequirementCanonicalWriter& writer,
                              const MetricRequestParametersV1& parameters) {
  writer.unsigned_integer(static_cast<std::uint64_t>(parameters.index()));
  std::visit(
      [&](const auto& value) {
        using Parameters = std::decay_t<decltype(value)>;
        const auto encode_naturals = [&](const std::vector<BigNat>& values) {
          writer.vector(values,
                        [](RequirementCanonicalWriter& output,
                           const BigNat& natural) {
                          output.natural(natural);
                        });
        };
        const auto encode_rationals = [&writer](
                                          const std::vector<ExactRational>& values) {
          writer.vector(values,
                        [](RequirementCanonicalWriter& output,
                           const ExactRational& rational) {
                          output.rational(rational);
                        });
        };
        if constexpr (std::is_same_v<Parameters,
                                     StationaryBacklogPmfParametersV1>) {
          writer.unsigned_integer(static_cast<std::uint64_t>(value.domain.index()));
          std::visit(
              [&](const auto& domain) {
                using Domain = std::decay_t<decltype(domain)>;
                if constexpr (std::is_same_v<Domain, PmfThroughLevelV1>) {
                  writer.natural(domain.max_level);
                }
              },
              value.domain);
        } else if constexpr (std::is_same_v<
                                 Parameters, StationaryBacklogPgfParametersV1>) {
          encode_rationals(value.points);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 StationaryBacklogMomentParametersV1>) {
          writer.natural(value.order);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 StationaryBacklogQuantileParametersV1>) {
          writer.rational(value.probability);
          writer.enumeration(value.convention);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 StationaryBacklogTailParametersV1>) {
          writer.natural(value.threshold);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 BacklogConditionedServiceParametersV1>) {
          encode_naturals(value.levels);
        } else if constexpr (std::is_same_v<
                                 Parameters, StationaryEdgeRewardParametersV1>) {
          writer.enumeration(value.reward);
          writer.natural(value.moment_order);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 ServiceAutocovarianceParametersV1> ||
                             std::is_same_v<
                                 Parameters,
                                 LaggedCrossQueueCovarianceParametersV1>) {
          encode_naturals(value.lags);
        } else if constexpr (std::is_same_v<Parameters,
                                            ServiceSpectrumParametersV1>) {
          encode_rationals(value.frequencies);
          writer.natural(value.truncation_lag);
          writer.enumeration(value.window);
        } else if constexpr (std::is_same_v<
                                 Parameters, ServiceWindowCountParametersV1>) {
          writer.natural(value.width);
        } else if constexpr (std::is_same_v<Parameters,
                                            MeanEventGapParametersV1>) {
          writer.enumeration(value.event);
        } else if constexpr (std::is_same_v<
                                 Parameters, EventGapDistributionParametersV1>) {
          writer.enumeration(value.event);
          writer.natural(value.horizon);
        } else if constexpr (std::is_same_v<Parameters,
                                            MeanBinaryRunParametersV1>) {
          writer.unsigned_integer(
              static_cast<std::uint64_t>(value.predicate.index()));
          std::visit(
              [&](const auto& predicate) {
                using Predicate = std::decay_t<decltype(predicate)>;
                if constexpr (std::is_same_v<Predicate,
                                             BasicBinaryPredicateV1>) {
                  writer.enumeration(predicate);
                } else {
                  writer.natural(predicate.threshold);
                }
              },
              value.predicate);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 BinaryRunDistributionParametersV1>) {
          writer.unsigned_integer(
              static_cast<std::uint64_t>(value.predicate.index()));
          std::visit(
              [&](const auto& predicate) {
                using Predicate = std::decay_t<decltype(predicate)>;
                if constexpr (std::is_same_v<Predicate,
                                             BasicBinaryPredicateV1>) {
                  writer.enumeration(predicate);
                } else {
                  writer.natural(predicate.threshold);
                }
              },
              value.predicate);
          writer.natural(value.horizon);
        } else if constexpr (std::is_same_v<Parameters,
                                            FirstHitParametersV1> ||
                             std::is_same_v<Parameters,
                                            ThresholdExcursionParametersV1>) {
          writer.enumeration(value.set.kind);
          writer.natural(value.set.level);
          writer.natural(value.horizon);
          writer.boolean(value.include_mean);
        } else if constexpr (std::is_same_v<
                                 Parameters, TransientBacklogLawParametersV1>) {
          encode_naturals(value.horizons);
        } else if constexpr (std::is_same_v<Parameters,
                                            FifoDelayParametersV1>) {
          encode_fifo_output(writer, value.output);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 FifoDelayConditionedParametersV1>) {
          encode_fifo_output(writer, value.output);
          encode_fifo_condition(writer, value.condition);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 CounterfactualOpportunityGapParametersV1>) {
          writer.label(value.convention_id);
          writer.natural(value.horizon);
        } else if constexpr (std::is_same_v<
                                 Parameters, JointBacklogEventParametersV1>) {
          writer.enumeration(value.relation);
          encode_naturals(value.thresholds);
        } else if constexpr (std::is_same_v<Parameters,
                                            JointDelayParametersV1>) {
          writer.unsigned_integer(
              static_cast<std::uint64_t>(value.sampling.index()));
          std::visit(
              [&](const auto& sampling) {
                using Sampling = std::decay_t<decltype(sampling)>;
                if constexpr (std::is_same_v<Sampling,
                                             LaggedPalmSamplingV1>) {
                  writer.natural(sampling.lag);
                }
              },
              value.sampling);
          writer.natural(value.horizon);
        } else if constexpr (std::is_same_v<
                                 Parameters,
                                 OrderedScheduleSequenceParametersV1>) {
          writer.natural(value.horizon);
          writer.boolean(value.retain_full_schedule);
        }
      },
      parameters);
}

void encode_origin(RequirementCanonicalWriter& writer,
                   const MetricClauseOriginV1& origin) {
  writer.string(origin.clause_id.metric_id);
  writer.unsigned_integer(
      static_cast<std::uint64_t>(origin.clause_id.authored_index));
  writer.enumeration(origin.kind);
  encode_metric_parameters(writer, origin.parameters);
  writer.enumeration(origin.wire_coupling);
  writer.vector(origin.ordered_targets,
                [](RequirementCanonicalWriter& output,
                   const ResolvedMetricTargetV1& target) {
                  output.target(target);
                });
  writer.enumeration(origin.selection_regime);
  writer.enumeration(origin.solver_regime);
  writer.boolean(origin.context != nullptr);
  if (origin.context != nullptr) {
    encode_analysis_context(writer, *origin.context);
  }
}

void encode_cylinder_coverage(RequirementCanonicalWriter& writer,
                              const FiniteCylinderCoverageV1& coverage) {
  writer.unsigned_integer(static_cast<std::uint64_t>(coverage.index()));
  std::visit(
      [&](const auto& value) {
        using Coverage = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Coverage,
                                     ExplicitCylinderOffsetsV1>) {
          writer.vector(value.offsets,
                        [](RequirementCanonicalWriter& output,
                           const BigNat& offset) {
                          output.natural(offset);
                        });
        } else if constexpr (std::is_same_v<Coverage,
                                            InclusiveCylinderThroughV1>) {
          writer.natural(value.maximum_offset);
        } else {
          writer.natural(value.maximum_offset);
          writer.vector(value.extra_offsets,
                        [](RequirementCanonicalWriter& output,
                           const BigNat& offset) {
                          output.natural(offset);
                        });
        }
      },
      coverage);
}

void encode_law(RequirementCanonicalWriter& writer,
                const ReusableMetricLawRequirementV1& law) {
  writer.unsigned_integer(static_cast<std::uint64_t>(law.index()));
  std::visit(
      [&](const auto& value) {
        using Law = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Law,
                                     FrameworkDerivedScalarRequirementV1>) {
          writer.enumeration(value.scalar);
        } else if constexpr (std::is_same_v<
                                 Law, SelectedInvariantMarginalRequirementV1>) {
          writer.boolean(value.retain_predictive_phase);
        } else if constexpr (std::is_same_v<
                                 Law, StationaryMarkedEdgeRequirementV1>) {
          writer.boolean(value.completion_bound);
        } else if constexpr (std::is_same_v<Law,
                                            FiniteCylinderRequirementV1>) {
          writer.enumeration(value.family);
          encode_cylinder_coverage(writer, value.coverage);
          writer.boolean(value.ordered_word_sufficient);
        } else if constexpr (std::is_same_v<
                                 Law, ExactPointResponseRequirementV1>) {
          writer.vector(value.represented_levels,
                        [](RequirementCanonicalWriter& output,
                           const BigNat& level) { output.natural(level); });
          writer.boolean(value.require_positive_stationary_conditioning_mass);
          writer.boolean(value.permit_declared_off_support_convention);
        } else if constexpr (std::is_same_v<Law,
                                            PushforwardCountLawRequirementV1>) {
          writer.natural(value.width);
        } else if constexpr (std::is_same_v<Law,
                                            ResidenceWordRequirementV1>) {
          writer.enumeration(value.stop);
          writer.optional(value.output_horizon,
                          [](RequirementCanonicalWriter& output,
                             const BigNat& horizon) {
                            output.natural(horizon);
                          });
          writer.boolean(value.retain_terminal_and_reentry);
        } else if constexpr (std::is_same_v<Law,
                                            StoppedPathRequirementV1>) {
          writer.enumeration(value.stop);
          writer.optional(value.output_horizon,
                          [](RequirementCanonicalWriter& output,
                             const BigNat& horizon) {
                            output.natural(horizon);
                          });
          writer.boolean(value.may_be_defective);
          writer.boolean(value.finite_mean_requested);
        } else {
          writer.boolean(value.exact_match_only);
        }
      },
      law);
}

void encode_semantic(RequirementCanonicalWriter& writer,
                     const SemanticContractAlternativeV1& semantic_value) {
  encode_law(writer, semantic_value.law);
  writer.enumeration(semantic_value.entrance);
  writer.enumeration(semantic_value.coupling);
  writer.boolean(semantic_value.require_temporal_one_slot_source);
  writer.boolean(semantic_value.require_full_history_predictive_sufficiency);
}

void encode_mark(RequirementCanonicalWriter& writer,
                 const MarkRequirementV1& requirement) {
  writer.enumeration(requirement.kind);
  writer.enumeration(requirement.latest_reveal_stage);
  writer.enumeration(requirement.relation);
  writer.enumeration(requirement.target_scope);
}

void encode_arrival_requirement(RequirementCanonicalWriter& writer,
                                const ArrivalRequirementV1& requirement) {
  writer.enumeration(requirement.kind);
  writer.enumeration(requirement.use);
  writer.enumeration(requirement.provision);
  writer.optional(requirement.moment_order,
                  [](RequirementCanonicalWriter& output,
                     const BigNat& order) { output.natural(order); });
  writer.boolean(requirement.joint);
  writer.boolean(requirement.phase_conditioned);
  writer.optional(requirement.transform_kind,
                  [](RequirementCanonicalWriter& output,
                     const TransformKind kind) { output.enumeration(kind); });
  writer.optional(requirement.distribution_scope,
                  [](RequirementCanonicalWriter& output,
                     const DistributionScope scope) {
                    output.enumeration(scope);
                  });
  writer.optional(requirement.argument_domain,
                  [](RequirementCanonicalWriter& output,
                     const ExactArgumentDomain& domain) {
                    output.rational(domain.lower);
                    output.rational(domain.upper);
                    output.boolean(domain.lower_inclusive);
                    output.boolean(domain.upper_inclusive);
                  });
}

void encode_arrival_alternative(
    RequirementCanonicalWriter& writer,
    const ArrivalRequirementAlternativeV1& alternative) {
  writer.vector(alternative.all_of,
                [](RequirementCanonicalWriter& output,
                   const ArrivalRequirementV1& requirement) {
                  encode_arrival_requirement(output, requirement);
                });
}

void encode_hypothesis(RequirementCanonicalWriter& writer,
                       const HypothesisRequirementV1& requirement) {
  writer.enumeration(requirement.claim.kind);
  writer.optional(requirement.claim.variable,
                  [](RequirementCanonicalWriter& output,
                     const MomentVariableV1 variable) {
                    output.enumeration(variable);
                  });
  writer.optional(requirement.claim.order,
                  [](RequirementCanonicalWriter& output,
                     const BigNat& order) { output.natural(order); });
  writer.optional(requirement.claim.convention_or_class,
                  [](RequirementCanonicalWriter& output,
                     const TypedLabel& label) { output.label(label); });
  writer.enumeration(requirement.satisfaction);
}

void encode_moment(RequirementCanonicalWriter& writer,
                   const MomentRequirementV1& requirement) {
  writer.enumeration(requirement.variable);
  writer.natural(requirement.order);
  writer.enumeration(requirement.conditioning);
  writer.vector(requirement.ordered_targets,
                [](RequirementCanonicalWriter& output,
                   const ResolvedMetricTargetV1& target) {
                  output.target(target);
                });
  writer.boolean(requirement.joint);
}

void encode_access(RequirementCanonicalWriter& writer,
                   const AccessAlternativeV1& alternative) {
  writer.enumeration(alternative.runtime_access);
  writer.enumeration(alternative.backend_route);
  writer.boolean(alternative.c24_row_or_reward_only);
  writer.boolean(alternative.exact_request_only);
}

void encode_accuracy_contract(RequirementCanonicalWriter& writer,
                              const AccuracyContractV1& contract) {
  writer.unsigned_integer(static_cast<std::uint64_t>(contract.index()));
  std::visit(
      [&](const auto& value) {
        using Accuracy = std::decay_t<decltype(value)>;
        const auto encode_tolerances =
            [&](const std::vector<DeterministicToleranceV1>& tolerances) {
              writer.vector(
                  tolerances,
                  [](RequirementCanonicalWriter& output,
                     const DeterministicToleranceV1& tolerance) {
                    output.enumeration(tolerance.kind);
                    output.rational(tolerance.maximum_absolute_error);
                  });
            };
        if constexpr (std::is_same_v<Accuracy, EnumeratedAccuracyV1>) {
          encode_tolerances(value.tolerances);
        } else if constexpr (std::is_same_v<Accuracy,
                                            AnalyticAccuracyV1>) {
          writer.natural(value.precision_bits);
          encode_tolerances(value.tolerances);
        } else if constexpr (std::is_same_v<Accuracy,
                                            MonteCarloAccuracyV1>) {
          writer.natural(value.replications);
          writer.rational(value.confidence_level);
          writer.enumeration(value.interval);
          writer.enumeration(value.estimand);
          writer.optional(value.almost_sure_lower,
                          [](RequirementCanonicalWriter& output,
                             const ExactRational& bound) {
                            output.rational(bound);
                          });
          writer.optional(value.almost_sure_upper,
                          [](RequirementCanonicalWriter& output,
                             const ExactRational& bound) {
                            output.rational(bound);
                          });
        }
      },
      contract);
}

void encode_accuracy(RequirementCanonicalWriter& writer,
                     const AccuracyRequirementV1& accuracy) {
  writer.enumeration(accuracy.solver_regime);
  encode_accuracy_contract(writer, accuracy.contract);
  writer.boolean(accuracy.require_declared_error_or_certificate);
}

void encode_route(RequirementCanonicalWriter& writer,
                  const MetricRouteAlternativeV1& route) {
  encode_semantic(writer, route.semantic);
  encode_access(writer, route.access);
  encode_arrival_alternative(writer, route.arrival);
  writer.vector(route.marks,
                [](RequirementCanonicalWriter& output,
                   const MarkRequirementV1& requirement) {
                  encode_mark(output, requirement);
                });
  writer.vector(route.hypotheses,
                [](RequirementCanonicalWriter& output,
                   const HypothesisRequirementV1& requirement) {
                  encode_hypothesis(output, requirement);
                });
}

void encode_clause(RequirementCanonicalWriter& writer,
                   const MetricRequirementClause& clause) {
  encode_origin(writer, clause.origin);
  writer.vector(clause.route_alternatives,
                [](RequirementCanonicalWriter& output,
                   const MetricRouteAlternativeV1& route) {
                  encode_route(output, route);
                });
  writer.vector(clause.semantic_alternatives,
                [](RequirementCanonicalWriter& output,
                   const SemanticContractAlternativeV1& semantic_value) {
                  encode_semantic(output, semantic_value);
                });
  writer.vector(clause.marks,
                [](RequirementCanonicalWriter& output,
                   const MarkRequirementV1& requirement) {
                  encode_mark(output, requirement);
                });
  writer.enumeration(clause.coupling);
  writer.vector(clause.selection.accepted_analysis_selections,
                [](RequirementCanonicalWriter& output,
                   const SelectionKindV1 selection) {
                  output.enumeration(selection);
                });
  writer.enumeration(clause.selection.entrance);
  writer.boolean(clause.selection.require_unique_or_explicit_selection);
  writer.vector(clause.arrival.alternatives,
                [](RequirementCanonicalWriter& output,
                   const ArrivalRequirementAlternativeV1& alternative) {
                  encode_arrival_alternative(output, alternative);
                });
  writer.enumeration(clause.access.solver_regime);
  writer.vector(clause.access.alternatives,
                [](RequirementCanonicalWriter& output,
                   const AccessAlternativeV1& alternative) {
                  encode_access(output, alternative);
                });
  writer.vector(clause.hypotheses,
                [](RequirementCanonicalWriter& output,
                   const HypothesisRequirementV1& requirement) {
                  encode_hypothesis(output, requirement);
                });
  writer.vector(clause.moments,
                [](RequirementCanonicalWriter& output,
                   const MomentRequirementV1& requirement) {
                  encode_moment(output, requirement);
                });
  encode_accuracy(writer, clause.accuracy);
  writer.boolean(clause.validity.mandatory_v0);
}

template <typename T, typename Encoder>
[[nodiscard]] std::vector<std::byte> encoded_value(const T& value,
                                                   Encoder encoder) {
  RequirementCanonicalWriter writer;
  encoder(writer, value);
  return writer.bytes();
}

template <typename T, typename Encoder>
void sort_unique_encoded(std::vector<T>& values, Encoder encoder) {
  std::sort(values.begin(), values.end(), [&](const T& left, const T& right) {
    return encoded_value(left, encoder) < encoded_value(right, encoder);
  });
  values.erase(
      std::unique(values.begin(), values.end(),
                  [&](const T& left, const T& right) {
                    return encoded_value(left, encoder) ==
                           encoded_value(right, encoder);
                  }),
      values.end());
}

[[nodiscard]] std::vector<std::byte> clause_bytes(
    const MetricRequirementClause& clause) {
  return encoded_value(
      clause, [](RequirementCanonicalWriter& writer,
                 const MetricRequirementClause& value) {
        encode_clause(writer, value);
      });
}

void normalize_semantic(SemanticContractAlternativeV1& semantic_value) {
  if (auto* cylinder =
          std::get_if<FiniteCylinderRequirementV1>(&semantic_value.law);
      cylinder != nullptr) {
    std::visit(
        [](auto& coverage) {
          using Coverage = std::decay_t<decltype(coverage)>;
          if constexpr (std::is_same_v<Coverage,
                                       ExplicitCylinderOffsetsV1>) {
            std::sort(coverage.offsets.begin(), coverage.offsets.end());
            coverage.offsets.erase(
                std::unique(coverage.offsets.begin(), coverage.offsets.end()),
                coverage.offsets.end());
          } else if constexpr (std::is_same_v<
                                   Coverage,
                                   InclusiveCylinderThroughWithExtraOffsetsV1>) {
            std::sort(coverage.extra_offsets.begin(),
                      coverage.extra_offsets.end());
            coverage.extra_offsets.erase(
                std::unique(coverage.extra_offsets.begin(),
                            coverage.extra_offsets.end()),
                coverage.extra_offsets.end());
            coverage.extra_offsets.erase(
                std::remove_if(
                    coverage.extra_offsets.begin(),
                    coverage.extra_offsets.end(),
                    [&](const BigNat& offset) {
                      return offset <= coverage.maximum_offset;
                    }),
                coverage.extra_offsets.end());
          }
        },
        cylinder->coverage);
  }
  if (auto* point =
          std::get_if<ExactPointResponseRequirementV1>(&semantic_value.law);
      point != nullptr) {
    std::sort(point->represented_levels.begin(),
              point->represented_levels.end());
    point->represented_levels.erase(
        std::unique(point->represented_levels.begin(),
                    point->represented_levels.end()),
        point->represented_levels.end());
  }
}

void normalize_clause(MetricRequirementClause& clause) {
  const auto encode_arrival = [](RequirementCanonicalWriter& writer,
                                 const ArrivalRequirementAlternativeV1& value) {
    encode_arrival_alternative(writer, value);
  };
  const auto encode_hypothesis_value = [](
                                           RequirementCanonicalWriter& writer,
                                           const HypothesisRequirementV1& value) {
    encode_hypothesis(writer, value);
  };
  const auto encode_mark_value = [](RequirementCanonicalWriter& writer,
                                    const MarkRequirementV1& value) {
    encode_mark(writer, value);
  };

  for (MetricRouteAlternativeV1& route : clause.route_alternatives) {
    normalize_semantic(route.semantic);
    sort_unique_encoded(route.arrival.all_of,
                        [](RequirementCanonicalWriter& writer,
                           const ArrivalRequirementV1& value) {
                          encode_arrival_requirement(writer, value);
                        });
    sort_unique_encoded(route.marks, encode_mark_value);
    sort_unique_encoded(route.hypotheses, encode_hypothesis_value);
  }
  for (SemanticContractAlternativeV1& semantic_value :
       clause.semantic_alternatives) {
    normalize_semantic(semantic_value);
  }
  sort_unique_encoded(
      clause.route_alternatives,
      [](RequirementCanonicalWriter& writer,
         const MetricRouteAlternativeV1& route) { encode_route(writer, route); });
  sort_unique_encoded(
      clause.semantic_alternatives,
      [](RequirementCanonicalWriter& writer,
         const SemanticContractAlternativeV1& value) {
        encode_semantic(writer, value);
      });
  sort_unique_encoded(clause.marks, encode_mark_value);
  for (ArrivalRequirementAlternativeV1& alternative :
       clause.arrival.alternatives) {
    sort_unique_encoded(alternative.all_of,
                        [](RequirementCanonicalWriter& writer,
                           const ArrivalRequirementV1& value) {
                          encode_arrival_requirement(writer, value);
                        });
  }
  sort_unique_encoded(clause.arrival.alternatives, encode_arrival);
  sort_unique_encoded(
      clause.access.alternatives,
      [](RequirementCanonicalWriter& writer,
         const AccessAlternativeV1& value) { encode_access(writer, value); });
  sort_unique_encoded(clause.hypotheses, encode_hypothesis_value);
  sort_unique_encoded(
      clause.moments,
      [](RequirementCanonicalWriter& writer,
         const MomentRequirementV1& value) { encode_moment(writer, value); });
}

[[nodiscard]] BigNat coverage_maximum(
    const FiniteCylinderCoverageV1& coverage) {
  return std::visit(
      [](const auto& value) -> BigNat {
        using Coverage = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Coverage,
                                     ExplicitCylinderOffsetsV1>) {
          if (value.offsets.empty()) {
            return BigNat{0U};
          }
          return *std::max_element(value.offsets.begin(),
                                   value.offsets.end());
        } else {
          BigNat maximum = value.maximum_offset;
          if constexpr (std::is_same_v<
                            Coverage,
                            InclusiveCylinderThroughWithExtraOffsetsV1>) {
            if (!value.extra_offsets.empty()) {
              maximum = std::max(maximum, value.extra_offsets.back());
            }
          }
          return maximum;
        }
      },
      coverage);
}

void collect_coverage(const FiniteCylinderCoverageV1& coverage,
                      std::optional<BigNat>& inclusive_maximum,
                      std::vector<BigNat>& explicit_offsets) {
  std::visit(
      [&](const auto& value) {
        using Coverage = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Coverage,
                                     ExplicitCylinderOffsetsV1>) {
          explicit_offsets.insert(explicit_offsets.end(),
                                  value.offsets.begin(), value.offsets.end());
        } else {
          if (!inclusive_maximum.has_value() ||
              *inclusive_maximum < value.maximum_offset) {
            inclusive_maximum = value.maximum_offset;
          }
          if constexpr (std::is_same_v<
                            Coverage,
                            InclusiveCylinderThroughWithExtraOffsetsV1>) {
            explicit_offsets.insert(explicit_offsets.end(),
                                    value.extra_offsets.begin(),
                                    value.extra_offsets.end());
          }
        }
      },
      coverage);
}

[[nodiscard]] FiniteCylinderCoverageV1 join_coverage(
    const FiniteCylinderCoverageV1& left,
    const FiniteCylinderCoverageV1& right) {
  std::optional<BigNat> inclusive_maximum;
  std::vector<BigNat> offsets;
  collect_coverage(left, inclusive_maximum, offsets);
  collect_coverage(right, inclusive_maximum, offsets);
  std::sort(offsets.begin(), offsets.end());
  offsets.erase(std::unique(offsets.begin(), offsets.end()), offsets.end());
  if (!inclusive_maximum.has_value()) {
    return ExplicitCylinderOffsetsV1{std::move(offsets)};
  }
  offsets.erase(
      std::remove_if(offsets.begin(), offsets.end(),
                     [&](const BigNat& offset) {
                       return offset <= *inclusive_maximum;
                     }),
      offsets.end());
  if (offsets.empty()) {
    return InclusiveCylinderThroughV1{*inclusive_maximum};
  }
  return InclusiveCylinderThroughWithExtraOffsetsV1{
      *inclusive_maximum, std::move(offsets)};
}

[[nodiscard]] bool same_cylinder_key(
    const CylinderRequirementSummaryV1& left,
    const CylinderRequirementSummaryV1& right) {
  return left.family == right.family &&
         left.ordered_targets == right.ordered_targets &&
         left.coupling == right.coupling && left.entrance == right.entrance;
}

[[nodiscard]] bool same_moment_key(const MomentRequirementSummaryV1& left,
                                   const MomentRequirementV1& right) {
  return left.variable == right.variable &&
         left.conditioning == right.conditioning &&
         left.ordered_targets == right.ordered_targets &&
         left.joint == right.joint;
}

void encode_cylinder_summary(RequirementCanonicalWriter& writer,
                             const CylinderRequirementSummaryV1& summary) {
  writer.enumeration(summary.family);
  writer.vector(summary.ordered_targets,
                [](RequirementCanonicalWriter& output,
                   const ResolvedMetricTargetV1& target) {
                  output.target(target);
                });
  writer.enumeration(summary.coupling);
  writer.enumeration(summary.entrance);
  encode_cylinder_coverage(writer, summary.coverage);
  writer.natural(summary.maximum_offset);
}

void encode_moment_summary(RequirementCanonicalWriter& writer,
                           const MomentRequirementSummaryV1& summary) {
  writer.enumeration(summary.variable);
  writer.enumeration(summary.conditioning);
  writer.vector(summary.ordered_targets,
                [](RequirementCanonicalWriter& output,
                   const ResolvedMetricTargetV1& target) {
                  output.target(target);
                });
  writer.boolean(summary.joint);
  writer.natural(summary.maximum_order);
}

[[nodiscard]] MetricRequirements build_requirements_aggregate(
    std::vector<MetricRequirementClause> clauses,
    std::vector<MetricClauseIdV1> authored_diagnostic_order) {
  for (MetricRequirementClause& clause : clauses) {
    normalize_clause(clause);
  }
  std::sort(clauses.begin(), clauses.end(),
            [](const MetricRequirementClause& left,
               const MetricRequirementClause& right) {
              return clause_bytes(left) < clause_bytes(right);
            });
  clauses.erase(
      std::unique(clauses.begin(), clauses.end(),
                  [](const MetricRequirementClause& left,
                     const MetricRequirementClause& right) {
                    return clause_bytes(left) == clause_bytes(right);
                  }),
      clauses.end());

  // Diagnostic order is a permutation of the retained semantic clauses.
  // Preserve the caller's first occurrence, discard duplicate request
  // entries, and deterministically append any defensively missing IDs.
  std::vector<MetricClauseIdV1> normalized_diagnostic_order;
  normalized_diagnostic_order.reserve(clauses.size());
  const auto has_clause_id = [&](const MetricClauseIdV1& id) {
    return std::any_of(
        clauses.begin(), clauses.end(), [&](const MetricRequirementClause& c) {
          return c.origin.clause_id == id;
        });
  };
  for (const MetricClauseIdV1& id : authored_diagnostic_order) {
    if (has_clause_id(id) &&
        std::find(normalized_diagnostic_order.begin(),
                  normalized_diagnostic_order.end(), id) ==
            normalized_diagnostic_order.end()) {
      normalized_diagnostic_order.push_back(id);
    }
  }
  std::vector<MetricClauseIdV1> missing_ids;
  for (const MetricRequirementClause& clause : clauses) {
    if (std::find(normalized_diagnostic_order.begin(),
                  normalized_diagnostic_order.end(),
                  clause.origin.clause_id) ==
        normalized_diagnostic_order.end()) {
      missing_ids.push_back(clause.origin.clause_id);
    }
  }
  std::sort(missing_ids.begin(), missing_ids.end(),
            [](const MetricClauseIdV1& left,
               const MetricClauseIdV1& right) {
              return std::tie(left.authored_index, left.metric_id) <
                     std::tie(right.authored_index, right.metric_id);
            });
  normalized_diagnostic_order.insert(normalized_diagnostic_order.end(),
                                     missing_ids.begin(), missing_ids.end());

  std::vector<ResolvedMetricTargetV1> targets;
  std::vector<MarkRequirementV1> marks;
  std::vector<ArrivalRequirementSetV1> arrivals;
  std::vector<std::vector<MetricRouteAlternativeV1>> routes;
  std::vector<HypothesisRequirementV1> hypotheses;
  std::vector<CylinderRequirementSummaryV1> cylinders;
  std::vector<MomentRequirementSummaryV1> moments;
  std::vector<AccuracyRequirementV1> accuracies;

  for (const MetricRequirementClause& clause : clauses) {
    targets.insert(targets.end(), clause.origin.ordered_targets.begin(),
                   clause.origin.ordered_targets.end());
    marks.insert(marks.end(), clause.marks.begin(), clause.marks.end());
    arrivals.push_back(clause.arrival);
    routes.push_back(clause.route_alternatives);
    hypotheses.insert(hypotheses.end(), clause.hypotheses.begin(),
                      clause.hypotheses.end());
    accuracies.push_back(clause.accuracy);

    for (const SemanticContractAlternativeV1& semantic_value :
         clause.semantic_alternatives) {
      const auto* cylinder =
          std::get_if<FiniteCylinderRequirementV1>(&semantic_value.law);
      if (cylinder == nullptr) {
        continue;
      }
      CylinderRequirementSummaryV1 incoming{
          cylinder->family, clause.origin.ordered_targets,
          semantic_value.coupling, semantic_value.entrance,
          cylinder->coverage, coverage_maximum(cylinder->coverage)};
      const auto found = std::find_if(
          cylinders.begin(), cylinders.end(),
          [&](const CylinderRequirementSummaryV1& existing) {
            return same_cylinder_key(existing, incoming);
          });
      if (found == cylinders.end()) {
        cylinders.push_back(std::move(incoming));
      } else {
        found->coverage = join_coverage(found->coverage, incoming.coverage);
        found->maximum_offset = coverage_maximum(found->coverage);
      }
    }

    for (const MomentRequirementV1& moment_requirement : clause.moments) {
      const auto found = std::find_if(
          moments.begin(), moments.end(),
          [&](const MomentRequirementSummaryV1& existing) {
            return same_moment_key(existing, moment_requirement);
          });
      if (found == moments.end()) {
        moments.push_back(MomentRequirementSummaryV1{
            moment_requirement.variable, moment_requirement.conditioning,
            moment_requirement.ordered_targets, moment_requirement.joint,
            moment_requirement.order});
      } else if (found->maximum_order < moment_requirement.order) {
        found->maximum_order = moment_requirement.order;
      }
    }
  }

  std::sort(targets.begin(), targets.end(),
            [](const ResolvedMetricTargetV1& left,
               const ResolvedMetricTargetV1& right) {
              return std::tie(left.dense_index, left.queue_id) <
                     std::tie(right.dense_index, right.queue_id);
            });
  targets.erase(std::unique(targets.begin(), targets.end()), targets.end());
  sort_unique(marks, mark_less);
  sort_unique_encoded(
      hypotheses,
      [](RequirementCanonicalWriter& writer,
         const HypothesisRequirementV1& value) {
        encode_hypothesis(writer, value);
      });
  sort_unique_encoded(
      cylinders,
      [](RequirementCanonicalWriter& writer,
         const CylinderRequirementSummaryV1& value) {
        encode_cylinder_summary(writer, value);
      });
  sort_unique_encoded(
      moments,
      [](RequirementCanonicalWriter& writer,
         const MomentRequirementSummaryV1& value) {
        encode_moment_summary(writer, value);
      });

  RegimeCompatibilityKindV1 compatibility_kind =
      RegimeCompatibilityKindV1::invalid_empty_request_set;
  std::optional<MetricSelectionRegimeV1> common_selection;
  std::optional<MetricSolverRegimeV1> common_solver;
  std::vector<MetricClauseIdV1> conflicts;
  if (!clauses.empty()) {
    common_selection = clauses.front().origin.selection_regime;
    common_solver = clauses.front().origin.solver_regime;
    bool selection_compatible = true;
    bool solver_compatible = true;
    for (const MetricRequirementClause& clause : clauses) {
      selection_compatible =
          selection_compatible &&
          clause.origin.selection_regime == *common_selection;
      solver_compatible = solver_compatible &&
                          clause.origin.solver_regime == *common_solver;
    }
    if (!selection_compatible) {
      common_selection.reset();
    }
    if (!solver_compatible) {
      common_solver.reset();
    }
    if (selection_compatible && solver_compatible) {
      compatibility_kind = RegimeCompatibilityKindV1::compatible;
    } else if (!selection_compatible && !solver_compatible) {
      compatibility_kind =
          RegimeCompatibilityKindV1::incompatible_selection_and_solver;
    } else if (!selection_compatible) {
      compatibility_kind =
          RegimeCompatibilityKindV1::incompatible_selection;
    } else {
      compatibility_kind = RegimeCompatibilityKindV1::incompatible_solver;
    }
    if (!selection_compatible || !solver_compatible) {
      conflicts.reserve(clauses.size());
      for (const MetricRequirementClause& clause : clauses) {
        conflicts.push_back(clause.origin.clause_id);
      }
      std::sort(conflicts.begin(), conflicts.end());
      conflicts.erase(std::unique(conflicts.begin(), conflicts.end()),
                      conflicts.end());
    }
  }

  return MetricRequirementsAccess::construct(
      kMetricRequirementsSchemaVersion,
      std::move(clauses),
      std::move(normalized_diagnostic_order),
      std::move(targets),
      std::move(marks),
      std::move(arrivals),
      std::move(routes),
      std::move(hypotheses),
      std::move(cylinders),
      std::move(moments),
      std::move(accuracies),
      RegimeCompatibilityV1{compatibility_kind, common_selection,
                            common_solver, std::move(conflicts)},
      true);
}

void encode_requirements(RequirementCanonicalWriter& writer,
                         const MetricRequirements& requirements) {
  writer.unsigned_integer(requirements.schema_version());
  writer.vector(requirements.clauses(),
                [](RequirementCanonicalWriter& output,
                   const MetricRequirementClause& clause) {
                  encode_clause(output, clause);
                });
  // authored_diagnostic_order is intentionally omitted.
  writer.vector(requirements.target_union(),
                [](RequirementCanonicalWriter& output,
                   const ResolvedMetricTargetV1& target) {
                  output.target(target);
                });
  writer.vector(requirements.mark_union(),
                [](RequirementCanonicalWriter& output,
                   const MarkRequirementV1& requirement) {
                  encode_mark(output, requirement);
                });
  writer.vector(requirements.arrival_conjunction(),
                [](RequirementCanonicalWriter& output,
                   const ArrivalRequirementSetV1& set) {
                  output.vector(
                      set.alternatives,
                      [](RequirementCanonicalWriter& nested,
                         const ArrivalRequirementAlternativeV1& alternative) {
                        encode_arrival_alternative(nested, alternative);
                      });
                });
  writer.vector(
      requirements.route_conjunction(),
      [](RequirementCanonicalWriter& output,
         const std::vector<MetricRouteAlternativeV1>& alternatives) {
        output.vector(alternatives,
                      [](RequirementCanonicalWriter& nested,
                         const MetricRouteAlternativeV1& route) {
                        encode_route(nested, route);
                      });
      });
  writer.vector(requirements.hypothesis_union(),
                [](RequirementCanonicalWriter& output,
                   const HypothesisRequirementV1& requirement) {
                  encode_hypothesis(output, requirement);
                });
  writer.vector(requirements.cylinder_summaries(),
                [](RequirementCanonicalWriter& output,
                   const CylinderRequirementSummaryV1& summary) {
                  encode_cylinder_summary(output, summary);
                });
  writer.vector(requirements.moment_summaries(),
                [](RequirementCanonicalWriter& output,
                   const MomentRequirementSummaryV1& summary) {
                  encode_moment_summary(output, summary);
                });
  writer.vector(requirements.accuracy_conjunction(),
                [](RequirementCanonicalWriter& output,
                   const AccuracyRequirementV1& accuracy) {
                  encode_accuracy(output, accuracy);
                });
  writer.enumeration(requirements.regime_compatibility().kind);
  writer.optional(
      requirements.regime_compatibility().common_selection,
      [](RequirementCanonicalWriter& output,
         const MetricSelectionRegimeV1 selection) {
        output.enumeration(selection);
      });
  writer.optional(requirements.regime_compatibility().common_solver,
                  [](RequirementCanonicalWriter& output,
                     const MetricSolverRegimeV1 solver) {
                    output.enumeration(solver);
                  });
  writer.vector(requirements.regime_compatibility().conflicting_clauses,
                [](RequirementCanonicalWriter& output,
                   const MetricClauseIdV1& clause_id) {
                  output.string(clause_id.metric_id);
                  output.unsigned_integer(static_cast<std::uint64_t>(
                      clause_id.authored_index));
                });
  writer.boolean(requirements.mandatory_v0());
}

}  // namespace

MetricRequirements aggregate_metric_requirements(
    const std::span<const MetricRequest> requests) {
  std::vector<MetricRequirementClause> clauses;
  clauses.reserve(requests.size());
  std::vector<MetricClauseIdV1> diagnostic_order;
  diagnostic_order.reserve(requests.size());
  for (const MetricRequest& request : requests) {
    MetricRequirements one = requirements_for_metric(request);
    if (!one.clauses().empty()) {
      diagnostic_order.push_back(one.clauses().front().origin.clause_id);
      clauses.push_back(one.clauses().front());
    }
  }
  return build_requirements_aggregate(std::move(clauses),
                                      std::move(diagnostic_order));
}

bool equivalent_metric_requirements(const MetricRequirements& left,
                                    const MetricRequirements& right) {
  RequirementCanonicalWriter left_writer;
  RequirementCanonicalWriter right_writer;
  encode_requirements(left_writer, left);
  encode_requirements(right_writer, right);
  return left_writer.bytes() == right_writer.bytes();
}

Result<Digest256> canonical_metric_requirements_digest(
    const MetricRequirements& requirements) {
  RequirementCanonicalWriter writer;
  encode_requirements(writer, requirements);
  return sha256_domain_separated("mwperf.metric_requirements.v1",
                                 writer.bytes());
}

}  // namespace mwperf

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> c14_manifest_failure(std::string code,
                                             std::string message) {
  return Result<T>::failure(Diagnostic{DiagnosticCategory::internal,
                                       std::move(code), std::move(message),
                                       std::nullopt, std::nullopt, {}});
}

[[nodiscard]] bool valid_arrival_assumption_shape(
    const ArrivalAssumptionV1& assumption);

[[nodiscard]] bool valid_hypothesis_shape(
    const HypothesisClaimV1& claim);

[[nodiscard]] constexpr std::uint32_t c14_role_mask() noexcept { return 0U; }

template <typename... Roles>
[[nodiscard]] constexpr std::uint32_t c14_role_mask(
    const MetricSupportRoleV1 first, const Roles... rest) noexcept {
  return metric_support_role_bit_v1(first) | c14_role_mask(rest...);
}

[[nodiscard]] constexpr std::uint64_t c14_internal_mask() noexcept {
  return 0U;
}

template <typename... Purposes>
[[nodiscard]] constexpr std::uint64_t c14_internal_mask(
    const InternalReferencePurposeV1 first,
    const Purposes... rest) noexcept {
  return internal_reference_purpose_bit_v1(first) |
         c14_internal_mask(rest...);
}

[[nodiscard]] constexpr std::uint32_t c14_target_mask_all() noexcept {
  return metric_target_scope_bit_v1(MetricTargetScopeV1::payload_targets) |
         metric_target_scope_bit_v1(
             MetricTargetScopeV1::deployed_singleton_target) |
         metric_target_scope_bit_v1(
             MetricTargetScopeV1::ordered_metric_targets) |
         metric_target_scope_bit_v1(
             MetricTargetScopeV1::ordered_construction_targets) |
         metric_target_scope_bit_v1(
             MetricTargetScopeV1::exact_request_targets);
}

[[nodiscard]] constexpr std::uint32_t c14_result_mask_all() noexcept {
  return metric_result_scope_bit_v1(
             MetricResultScopeV1::not_a_metric_result) |
         metric_result_scope_bit_v1(MetricResultScopeV1::surrogate_law) |
         metric_result_scope_bit_v1(MetricResultScopeV1::proposal_raw) |
         metric_result_scope_bit_v1(MetricResultScopeV1::response_envelope) |
         metric_result_scope_bit_v1(MetricResultScopeV1::physical_bound);
}

[[nodiscard]] constexpr std::uint32_t c14_evidence_mask_all() noexcept {
  return metric_evidence_scope_bit_v1(MetricEvidenceScopeV1::none) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::raw_static_proposal) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::nominal_static_proposal) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::projection_center) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::projected_surrogate_mean) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::recoded_static_proposal) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::optimizer_interval_raw) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::deployed_surrogate_law) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::numerical_result) |
         metric_evidence_scope_bit_v1(
             MetricEvidenceScopeV1::validity_or_lift) |
         metric_evidence_scope_bit_v1(MetricEvidenceScopeV1::physical_system);
}

[[nodiscard]] constexpr MetricSupportRoleSchemaV1 c14_schema_base(
    const MetricSupportRoleV1 role,
    const RealizedReferenceAlternativeV1 alternative,
    const std::uint32_t target_scopes, const std::uint32_t result_scopes,
    const std::uint32_t evidence_scopes) noexcept {
  MetricSupportRoleSchemaV1 result{};
  result.role = role;
  result.reference_alternative = alternative;
  result.allowed_target_scopes = target_scopes;
  result.allowed_result_scopes = result_scopes;
  result.allowed_evidence_scopes = evidence_scopes;
  return result;
}

[[nodiscard]] constexpr std::array<MetricSupportRoleSchemaV1, 25U>
c14_make_role_schemas() noexcept {
  using R = MetricSupportRoleV1;
  using A = RealizedReferenceAlternativeV1;
  using T = MetricTargetScopeV1;
  using O = MetricResultScopeV1;
  using E = MetricEvidenceScopeV1;
  using I = InternalReferencePurposeV1;
  using C = MetricRoleConditionalRuleV1;

  std::array<MetricSupportRoleSchemaV1, 25U> rows{};
  const auto put = [&rows](MetricSupportRoleSchemaV1 row) constexpr {
    rows[metric_support_role_rank_v1(row.role)] = row;
  };

  put(c14_schema_base(R::deployed_payload,
                      A::deployed_payload_reference,
                      metric_target_scope_bit_v1(T::payload_targets),
                      c14_result_mask_all(),
                      metric_evidence_scope_bit_v1(E::none)));

  auto row = c14_schema_base(
      R::deployed_response, A::deployed_response_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::surrogate_law),
      metric_evidence_scope_bit_v1(E::deployed_surrogate_law));
  row.allowed_binding_roles = row.required_binding_roles =
      c14_role_mask(R::deployed_payload);
  row.allowed_subject_roles =
      c14_role_mask(R::raw_response, R::nominal_response,
                    R::recoded_response);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::selected_response_product_must_match_deployment_policy);
  put(row);

  row = c14_schema_base(
      R::raw_response, A::raw_response_product_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::proposal_raw),
      metric_evidence_scope_bit_v1(E::raw_static_proposal));
  row.allowed_binding_roles = row.required_binding_roles =
      c14_role_mask(R::deployed_payload);
  row.allowed_evidence_roles = c14_role_mask(R::raw_response_bound_evidence);
  row.allowed_internal_lineage_parents =
      row.required_internal_lineage_parents =
          c14_internal_mask(I::coefficient_origin);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::interval_raw_requires_bound_evidence);
  put(row);

  row = c14_schema_base(
      R::nominal_response, A::nominal_response_product_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::nominal_static_proposal));
  row.allowed_lineage_parent_roles = c14_role_mask(R::raw_response);
  row.allowed_evidence_roles =
      c14_role_mask(R::raw_response_bound_evidence, R::optimizer_evidence,
                    R::statistical_evidence, R::numerical_evidence,
                    R::calibration_evidence);
  row.allowed_internal_lineage_parents =
      c14_internal_mask(I::completion_source);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::completion_policy);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::policy_selected_derivation_parents);
  put(row);

  row = c14_schema_base(
      R::projection_center, A::projection_center_product_reference,
      metric_target_scope_bit_v1(T::ordered_construction_targets),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::projection_center));
  row.allowed_internal_lineage_parents =
      row.required_internal_lineage_parents =
          c14_internal_mask(I::projection_source);
  put(row);

  row = c14_schema_base(
      R::projected_mean, A::projected_mean_product_reference,
      metric_target_scope_bit_v1(T::ordered_construction_targets),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::projected_surrogate_mean));
  row.allowed_lineage_parent_roles = row.required_lineage_parent_roles =
      c14_role_mask(R::projection_center);
  row.allowed_evidence_roles =
      c14_role_mask(R::optimizer_evidence, R::numerical_evidence);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::projection_policy);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::policy_selected_derivation_parents);
  put(row);

  row = c14_schema_base(
      R::recoded_response, A::recoded_response_product_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::recoded_static_proposal));
  row.allowed_lineage_parent_roles =
      c14_role_mask(R::raw_response, R::nominal_response, R::projected_mean);
  row.allowed_evidence_roles =
      c14_role_mask(R::raw_response_bound_evidence, R::optimizer_evidence,
                    R::statistical_evidence, R::numerical_evidence,
                    R::calibration_evidence, R::compression_evidence);
  row.allowed_internal_lineage_parents =
      c14_internal_mask(I::completion_source);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::recoding_policy);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::policy_selected_derivation_parents);
  put(row);

  const std::uint32_t law_targets =
      metric_target_scope_bit_v1(T::ordered_metric_targets);
  const std::uint32_t law_result =
      metric_result_scope_bit_v1(O::surrogate_law);
  const std::uint32_t law_evidence =
      metric_evidence_scope_bit_v1(E::deployed_surrogate_law);
  const auto set_law_roles = [](MetricSupportRoleSchemaV1& value) constexpr {
    value.allowed_binding_roles = value.required_binding_roles =
        c14_role_mask(R::deployed_payload);
    value.allowed_evidence_roles = value.required_evidence_roles =
        c14_role_mask(R::reported_validity_or_lift_evidence);
  };

  row = c14_schema_base(R::stationary_marked_edge_law,
                        A::stationary_marked_edge_law_reference, law_targets,
                        law_result, law_evidence);
  set_law_roles(row);
  row.allowed_evidence_roles |= c14_role_mask(R::stability_certificate);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::state_codec, I::mark_codec,
                        I::configured_arrival_binding, I::selection_binding);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::stationary_hypothesis_requires_stability);
  put(row);

  row = c14_schema_base(R::staged_opportunity_flux_law,
                        A::staged_opportunity_flux_law_reference, law_targets,
                        law_result, law_evidence);
  set_law_roles(row);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::stage_law, I::mark_codec, I::reveal_order);
  put(row);

  row = c14_schema_base(R::temporal_continuation_law,
                        A::temporal_continuation_law_reference, law_targets,
                        law_result, law_evidence);
  set_law_roles(row);
  row.allowed_internal_bindings =
      c14_internal_mask(I::one_slot_continuation, I::state_codec,
                        I::mark_codec, I::configured_arrival_binding,
                        I::initial_binding, I::selection_binding);
  row.required_internal_bindings =
      c14_internal_mask(I::one_slot_continuation, I::state_codec,
                        I::mark_codec, I::configured_arrival_binding);
  put(row);

  row = c14_schema_base(R::residence_word_law,
                        A::residence_word_law_reference, law_targets,
                        law_result, law_evidence);
  set_law_roles(row);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::entrance, I::one_slot_continuation,
                        I::adapted_positive_stop, I::word, I::terminal,
                        I::reentry);
  put(row);

  row = c14_schema_base(R::stopped_path_law,
                        A::stopped_path_law_reference, law_targets, law_result,
                        law_evidence);
  set_law_roles(row);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::entrance, I::one_slot_continuation,
                        I::adapted_positive_stop, I::terminal,
                        I::killed_projection, I::mark_codec);
  put(row);

  row = c14_schema_base(R::coupled_schedule_law,
                        A::coupled_schedule_law_reference, law_targets,
                        law_result, law_evidence);
  set_law_roles(row);
  row.allowed_internal_bindings =
      c14_internal_mask(I::projected_schedule, I::feasibility_domain_codec,
                        I::full_schedule);
  row.required_internal_bindings =
      c14_internal_mask(I::projected_schedule, I::feasibility_domain_codec);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::full_schedule_when_projection_is_not_sufficient);
  put(row);

  row = c14_schema_base(
      R::direct_metric_value, A::direct_metric_value_reference,
      metric_target_scope_bit_v1(T::exact_request_targets),
      c14_result_mask_all(),
      metric_evidence_scope_bit_v1(E::deployed_surrogate_law));
  row.allowed_binding_roles = row.required_binding_roles =
      c14_role_mask(R::deployed_payload);
  row.allowed_evidence_roles = row.required_evidence_roles =
      c14_role_mask(R::reported_validity_or_lift_evidence);
  row.allowed_evidence_roles |=
      c14_role_mask(R::physical_transfer_evidence);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::normalized_request, I::selection_binding,
                        I::configured_arrival_binding, I::validity_basis);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::physical_scope_requires_transfer);
  put(row);

  row = c14_schema_base(
      R::response_envelope, A::response_envelope_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::response_envelope) |
          metric_result_scope_bit_v1(O::physical_bound),
      c14_evidence_mask_all());
  row.allowed_binding_roles = row.required_binding_roles =
      c14_role_mask(R::deployed_payload);
  row.allowed_evidence_roles =
      c14_role_mask(R::raw_response_bound_evidence,
                    R::response_order_evidence,
                    R::physical_transfer_evidence);
  row.required_evidence_roles =
      c14_role_mask(R::raw_response_bound_evidence,
                    R::response_order_evidence);
  row.allowed_internal_lineage_parents =
      row.required_internal_lineage_parents =
          c14_internal_mask(I::lower_response_product,
                            I::upper_response_product);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::physical_scope_requires_transfer);
  put(row);

  row = c14_schema_base(
      R::raw_response_bound_evidence,
      A::raw_response_bound_evidence_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::raw_static_proposal) |
          metric_evidence_scope_bit_v1(E::optimizer_interval_raw));
  row.allowed_subject_roles = row.required_subject_roles =
      c14_role_mask(R::raw_response);
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::evaluation_identity, I::proposal_identity);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::coefficient_origin);
  put(row);

  row = c14_schema_base(
      R::response_order_evidence, A::response_order_evidence_reference,
      metric_target_scope_bit_v1(T::deployed_singleton_target),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::deployed_surrogate_law));
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::comparison_domain, I::transfer_direction,
                        I::validity_basis);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::lower_response_product,
                        I::upper_response_product);
  put(row);

  row = c14_schema_base(
      R::optimizer_evidence, A::optimizer_evidence_reference,
      metric_target_scope_bit_v1(T::ordered_construction_targets),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::optimizer_interval_raw));
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::solver_identity, I::constraint_identity,
                        I::call_report_identity, I::evaluation_identity);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::certified_product_or_envelope);
  put(row);

  row = c14_schema_base(R::statistical_evidence,
                        A::statistical_evidence_reference,
                        c14_target_mask_all(),
                        metric_result_scope_bit_v1(O::not_a_metric_result),
                        c14_evidence_mask_all());
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::sampling_bank, I::sampling_probe,
                        I::evaluation_identity, I::coverage_family);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::estimand);
  put(row);

  row = c14_schema_base(
      R::numerical_evidence, A::numerical_evidence_reference,
      c14_target_mask_all(),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::numerical_result));
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::algorithm_tolerance_policy,
                        I::residual_or_enclosure, I::representation_domain);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::law_or_result);
  put(row);

  row = c14_schema_base(R::calibration_evidence,
                        A::calibration_evidence_reference,
                        metric_target_scope_bit_v1(
                            T::ordered_construction_targets),
                        metric_result_scope_bit_v1(O::not_a_metric_result),
                        c14_evidence_mask_all());
  row.allowed_internal_bindings =
      c14_internal_mask(I::sampling_bank, I::exact_population,
                        I::calibration_rule);
  row.required_internal_bindings = c14_internal_mask(I::calibration_rule);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::calibration_source);
  row.conditional_rules = metric_role_conditional_bit_v1(
      C::calibration_input_must_be_sampling_or_population);
  put(row);

  row = c14_schema_base(R::compression_evidence,
                        A::compression_evidence_reference,
                        c14_target_mask_all(),
                        metric_result_scope_bit_v1(O::not_a_metric_result),
                        c14_evidence_mask_all());
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::compression_rule);
  row.allowed_internal_evidence = row.required_internal_evidence =
      c14_internal_mask(I::error_object);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::compression_source, I::compression_destination);
  put(row);

  row = c14_schema_base(
      R::stability_certificate, A::stability_certificate_reference,
      metric_target_scope_bit_v1(T::ordered_metric_targets),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::deployed_surrogate_law));
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::configured_arrival_binding, I::state_domain,
                        I::class_domain, I::selection_binding,
                        I::stability_statement);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::deployed_law);
  put(row);

  row = c14_schema_base(
      R::reported_validity_or_lift_evidence,
      A::reported_validity_or_lift_evidence_reference,
      c14_target_mask_all(),
      metric_result_scope_bit_v1(O::not_a_metric_result),
      metric_evidence_scope_bit_v1(E::validity_or_lift));
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::coordinate_codec, I::mark_codec,
                        I::configured_arrival_binding, I::selection_binding,
                        I::timing_binding, I::validity_basis);
  row.allowed_internal_evidence = row.required_internal_evidence =
      c14_internal_mask(I::validity_witness);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::artifact_payload, I::law_or_result);
  put(row);

  row = c14_schema_base(
      R::physical_transfer_evidence,
      A::physical_transfer_evidence_reference,
      metric_target_scope_bit_v1(T::ordered_metric_targets),
      metric_result_scope_bit_v1(O::physical_bound),
      metric_evidence_scope_bit_v1(E::physical_system));
  row.allowed_internal_bindings = row.required_internal_bindings =
      c14_internal_mask(I::transfer_theorem, I::transfer_assumption,
                        I::transfer_direction);
  row.allowed_internal_evidence = row.required_internal_evidence =
      c14_internal_mask(I::error_object);
  row.allowed_internal_subjects = row.required_internal_subjects =
      c14_internal_mask(I::surrogate_source, I::physical_model,
                        I::physical_metric);
  put(row);

  return rows;
}

inline constexpr auto kC14MetricSupportRoleSchemas = c14_make_role_schemas();

class C14CanonicalEncoder final {
 public:
  void u8(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void boolean(const bool value) { u8(value ? 1U : 0U); }
  void u32(const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      u8(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      u8(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  template <typename Enum>
  void enumeration(const Enum value) {
    u32(static_cast<std::uint32_t>(value));
  }
  void raw(const std::span<const std::byte> value) {
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void raw_u8(const std::span<const std::uint8_t> value) {
    for (const std::uint8_t byte : value) {
      u8(byte);
    }
  }
  void string(const std::string_view value) {
    u64(static_cast<std::uint64_t>(value.size()));
    for (const char byte : value) {
      u8(static_cast<std::uint8_t>(static_cast<unsigned char>(byte)));
    }
  }
  void digest(const Digest256& value) { raw(value.bytes()); }
  void big_nat(const BigNat& value) {
    const auto bytes = value.canonical_magnitude_bytes();
    u64(static_cast<std::uint64_t>(bytes.size()));
    raw_u8(bytes);
  }
  void rational(const ExactRational& value) {
    string(value.numerator_decimal());
    string(value.denominator_decimal());
  }
  void label(const TypedLabel& value) {
    const auto bytes = value.canonical_bytes();
    u64(static_cast<std::uint64_t>(bytes.size()));
    raw_u8(bytes);
  }
  template <StrongIdDomainName Domain>
  void strong_id(const StrongId<Domain>& value) {
    const auto bytes = value.canonical_bytes();
    u64(static_cast<std::uint64_t>(bytes.size()));
    raw_u8(bytes);
  }
  template <typename T, typename Encode>
  void sequence(const std::vector<T>& values, Encode encode) {
    u64(static_cast<std::uint64_t>(values.size()));
    for (const auto& value : values) {
      encode(*this, value);
    }
  }
  template <typename T, typename Encode>
  void optional(const std::optional<T>& value, Encode encode) {
    boolean(value.has_value());
    if (value.has_value()) {
      encode(*this, *value);
    }
  }
  [[nodiscard]] const std::vector<std::byte>& bytes() const noexcept {
    return bytes_;
  }
  [[nodiscard]] std::vector<std::byte> release() && {
    return std::move(bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] bool c14_byte_less(const std::vector<std::byte>& left,
                                  const std::vector<std::byte>& right) {
  return std::lexicographical_compare(
      left.begin(), left.end(), right.begin(), right.end(),
      [](const std::byte lhs, const std::byte rhs) {
        return std::to_integer<std::uint8_t>(lhs) <
               std::to_integer<std::uint8_t>(rhs);
      });
}

template <typename T, typename Encode>
[[nodiscard]] bool c14_sort_encoded_and_has_duplicate(std::vector<T>& values,
                                                       Encode encode) {
  std::sort(values.begin(), values.end(), [&](const T& left, const T& right) {
    return c14_byte_less(encode(left), encode(right));
  });
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (encode(values[index - 1U]) == encode(values[index])) {
      return true;
    }
  }
  return false;
}

template <typename Enum>
[[nodiscard]] constexpr bool c14_enum_rank_below(const Enum value,
                                                  const std::uint32_t limit) {
  using Underlying = std::underlying_type_t<Enum>;
  using Unsigned = std::make_unsigned_t<Underlying>;
  return static_cast<std::uint64_t>(static_cast<Unsigned>(value)) < limit;
}

}  // namespace

const MetricSupportRoleSchemaV1* metric_support_role_schema_v1(
    const MetricSupportRoleV1 role) noexcept {
  const auto rank = metric_support_role_rank_v1(role);
  if (rank >= kC14MetricSupportRoleSchemas.size()) {
    return nullptr;
  }
  const auto& row = kC14MetricSupportRoleSchemas[rank];
  return row.role == role ? &row : nullptr;
}

MetricSupportRoleV1 realized_reference_role_v1(
    const RealizedReferenceV1& reference) noexcept {
  return static_cast<MetricSupportRoleV1>(reference.index());
}

RealizedReferenceAlternativeV1 realized_reference_alternative_v1(
    const RealizedReferenceV1& reference) noexcept {
  return static_cast<RealizedReferenceAlternativeV1>(reference.index());
}

const RealizedReferenceCoreV1& realized_reference_core_v1(
    const RealizedReferenceV1& reference) noexcept {
  return std::visit(
      [](const auto& typed) -> const RealizedReferenceCoreV1& {
        return typed.core;
      },
      reference);
}

const ArtifactObjectReferenceV1& deployed_response_product_subject_v1(
    const DeployedResponseProductReferenceV1& product) noexcept {
  return std::visit(
      [](const auto& typed) -> const ArtifactObjectReferenceV1& {
        return typed.identity;
      },
      product);
}

bool is_point_valued_deployed_response_product_v1(
    const DeployedResponseProductReferenceV1& product) noexcept {
  return std::visit(
      [](const auto& typed) {
        using Product = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Product, RawResponseProductRef>) {
          return typed.value_form == ResponseProductValueFormV1::exact_point;
        }
        return true;
      },
      product);
}

const ArtifactObjectReferenceV1& realized_reference_subject_v1(
    const RealizedReferenceV1& reference) noexcept {
  return std::visit(
      [](const auto& typed) -> const ArtifactObjectReferenceV1& {
        using Reference = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Reference,
                                     DeployedResponseReferenceV1>) {
          return deployed_response_product_subject_v1(typed.selected_product);
        } else if constexpr (std::is_same_v<Reference,
                                            DeployedPayloadReferenceV1>) {
          return typed.payload.identity;
        } else if constexpr (
            std::is_same_v<Reference, RawResponseProductReferenceV1> ||
            std::is_same_v<Reference, NominalResponseProductReferenceV1> ||
            std::is_same_v<Reference, ProjectionCenterProductReferenceV1> ||
            std::is_same_v<Reference, ProjectedMeanProductReferenceV1> ||
            std::is_same_v<Reference, RecodedResponseProductReferenceV1>) {
          return typed.product.identity;
        } else if constexpr (
            std::is_same_v<Reference, StationaryMarkedEdgeLawReferenceV1> ||
            std::is_same_v<Reference, StagedOpportunityFluxLawReferenceV1> ||
            std::is_same_v<Reference, TemporalContinuationLawReferenceV1> ||
            std::is_same_v<Reference, ResidenceWordLawReferenceV1> ||
            std::is_same_v<Reference, StoppedPathLawReferenceV1> ||
            std::is_same_v<Reference, CoupledScheduleLawReferenceV1>) {
          return typed.law.identity;
        } else if constexpr (std::is_same_v<Reference,
                                            DirectMetricValueReferenceV1>) {
          return typed.value.identity;
        } else if constexpr (std::is_same_v<Reference,
                                            ResponseEnvelopeReferenceV1>) {
          return typed.envelope.identity;
        } else if constexpr (std::is_same_v<Reference,
                                            StabilityCertificateReferenceV1>) {
          return typed.certificate.identity;
        } else {
          return typed.evidence.identity;
        }
      },
      reference);
}

namespace {

void c14_encode_binary_predicate(C14CanonicalEncoder& encoder,
                                 const BinaryPredicateV1& predicate) {
  encoder.u32(static_cast<std::uint32_t>(predicate.index()));
  std::visit(
      [&encoder](const auto& typed) {
        using Predicate = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Predicate, BasicBinaryPredicateV1>) {
          encoder.enumeration(typed);
        } else {
          encoder.big_nat(typed.threshold);
        }
      },
      predicate);
}

void c14_encode_fifo_output(C14CanonicalEncoder& encoder,
                            const FifoDelayOutputV1& output) {
  encoder.u32(static_cast<std::uint32_t>(output.index()));
  std::visit(
      [&encoder](const auto& typed) {
        using Output = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Output, FifoDelayPmfOutputV1> ||
                      std::is_same_v<Output, FifoDelayTailOutputV1>) {
          encoder.big_nat(typed.horizon);
        } else if constexpr (std::is_same_v<Output,
                                            FifoDelayQuantileOutputV1>) {
          encoder.rational(typed.probability);
          encoder.enumeration(typed.convention);
        } else {
          encoder.big_nat(typed.order);
        }
      },
      output);
}

void c14_encode_fifo_condition(C14CanonicalEncoder& encoder,
                               const FifoConditionV1& condition) {
  encoder.u32(static_cast<std::uint32_t>(condition.index()));
  std::visit(
      [&encoder](const auto& typed) {
        using Condition = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Condition, FifoRankConditionV1>) {
          encoder.big_nat(typed.one_based_rank);
        } else if constexpr (std::is_same_v<Condition,
                                            FifoBatchConditionV1>) {
          encoder.big_nat(typed.batch_size);
        } else if constexpr (std::is_same_v<Condition,
                                            FifoClassConditionV1>) {
          encoder.label(typed.class_id);
        } else {
          encoder.label(typed.phase_id);
        }
      },
      condition);
}

void c14_encode_parameters(C14CanonicalEncoder& encoder,
                           const MetricRequestParametersV1& parameters) {
  encoder.u32(static_cast<std::uint32_t>(parameters.index()));
  std::visit(
      [&encoder](const auto& typed) {
        using P = std::decay_t<decltype(typed)>;
        if constexpr (
            std::is_same_v<P, StationaryBacklogPmfParametersV1>) {
          encoder.u32(static_cast<std::uint32_t>(typed.domain.index()));
          if (const auto* through = std::get_if<PmfThroughLevelV1>(
                  &typed.domain)) {
            encoder.big_nat(through->max_level);
          }
        } else if constexpr (
            std::is_same_v<P, StationaryBacklogPgfParametersV1>) {
          encoder.sequence(typed.points,
                           [](C14CanonicalEncoder& out,
                              const ExactRational& point) {
                             out.rational(point);
                           });
        } else if constexpr (
            std::is_same_v<P, StationaryBacklogMomentParametersV1>) {
          encoder.big_nat(typed.order);
        } else if constexpr (
            std::is_same_v<P, StationaryBacklogQuantileParametersV1>) {
          encoder.rational(typed.probability);
          encoder.enumeration(typed.convention);
        } else if constexpr (
            std::is_same_v<P, StationaryBacklogTailParametersV1>) {
          encoder.big_nat(typed.threshold);
        } else if constexpr (
            std::is_same_v<P, BacklogConditionedServiceParametersV1>) {
          encoder.sequence(typed.levels,
                           [](C14CanonicalEncoder& out,
                              const BigNat& level) { out.big_nat(level); });
        } else if constexpr (
            std::is_same_v<P, StationaryEdgeRewardParametersV1>) {
          encoder.enumeration(typed.reward);
          encoder.big_nat(typed.moment_order);
        } else if constexpr (
            std::is_same_v<P, ServiceAutocovarianceParametersV1> ||
            std::is_same_v<P, LaggedCrossQueueCovarianceParametersV1>) {
          encoder.sequence(typed.lags,
                           [](C14CanonicalEncoder& out, const BigNat& lag) {
                             out.big_nat(lag);
                           });
        } else if constexpr (
            std::is_same_v<P, ServiceSpectrumParametersV1>) {
          encoder.sequence(typed.frequencies,
                           [](C14CanonicalEncoder& out,
                              const ExactRational& frequency) {
                             out.rational(frequency);
                           });
          encoder.big_nat(typed.truncation_lag);
          encoder.enumeration(typed.window);
        } else if constexpr (
            std::is_same_v<P, ServiceWindowCountParametersV1>) {
          encoder.big_nat(typed.width);
        } else if constexpr (std::is_same_v<P, MeanEventGapParametersV1>) {
          encoder.enumeration(typed.event);
        } else if constexpr (
            std::is_same_v<P, EventGapDistributionParametersV1>) {
          encoder.enumeration(typed.event);
          encoder.big_nat(typed.horizon);
        } else if constexpr (std::is_same_v<P,
                                           MeanBinaryRunParametersV1>) {
          c14_encode_binary_predicate(encoder, typed.predicate);
        } else if constexpr (
            std::is_same_v<P, BinaryRunDistributionParametersV1>) {
          c14_encode_binary_predicate(encoder, typed.predicate);
          encoder.big_nat(typed.horizon);
        } else if constexpr (std::is_same_v<P, FirstHitParametersV1> ||
                             std::is_same_v<P,
                                            ThresholdExcursionParametersV1>) {
          encoder.enumeration(typed.set.kind);
          encoder.big_nat(typed.set.level);
          encoder.big_nat(typed.horizon);
          encoder.boolean(typed.include_mean);
        } else if constexpr (
            std::is_same_v<P, TransientBacklogLawParametersV1>) {
          encoder.sequence(typed.horizons,
                           [](C14CanonicalEncoder& out,
                              const BigNat& horizon) {
                             out.big_nat(horizon);
                           });
        } else if constexpr (std::is_same_v<P, FifoDelayParametersV1>) {
          c14_encode_fifo_output(encoder, typed.output);
        } else if constexpr (
            std::is_same_v<P, FifoDelayConditionedParametersV1>) {
          c14_encode_fifo_output(encoder, typed.output);
          c14_encode_fifo_condition(encoder, typed.condition);
        } else if constexpr (
            std::is_same_v<P, CounterfactualOpportunityGapParametersV1>) {
          encoder.label(typed.convention_id);
          encoder.big_nat(typed.horizon);
        } else if constexpr (
            std::is_same_v<P, JointBacklogEventParametersV1>) {
          encoder.enumeration(typed.relation);
          encoder.sequence(typed.thresholds,
                           [](C14CanonicalEncoder& out,
                              const BigNat& threshold) {
                             out.big_nat(threshold);
                           });
        } else if constexpr (std::is_same_v<P, JointDelayParametersV1>) {
          encoder.u32(static_cast<std::uint32_t>(typed.sampling.index()));
          if (const auto* lagged =
                  std::get_if<LaggedPalmSamplingV1>(&typed.sampling)) {
            encoder.big_nat(lagged->lag);
          }
          encoder.big_nat(typed.horizon);
        } else if constexpr (
            std::is_same_v<P, OrderedScheduleSequenceParametersV1>) {
          encoder.big_nat(typed.horizon);
          encoder.boolean(typed.retain_full_schedule);
        } else {
          // The first five parameter alternatives are unit records.
        }
      },
      parameters);
}

[[nodiscard]] std::vector<std::byte> c14_parameter_bytes(
    const MetricRequestParametersV1& parameters) {
  C14CanonicalEncoder encoder;
  c14_encode_parameters(encoder, parameters);
  return std::move(encoder).release();
}

void c14_encode_codec(C14CanonicalEncoder& encoder,
                      const CodecIdentityV1& codec) {
  encoder.string(codec.id);
  encoder.u32(codec.version);
}

void c14_encode_state_field(C14CanonicalEncoder& encoder,
                            const StateFieldDescriptorV1& field) {
  encoder.enumeration(field.kind);
  encoder.enumeration(field.ownership);
  c14_encode_codec(encoder, field.codec);
}

void c14_encode_mark(C14CanonicalEncoder& encoder,
                     const MarkDescriptorV1& mark) {
  encoder.enumeration(mark.kind);
  encoder.enumeration(mark.reveal_stage);
  c14_encode_codec(encoder, mark.codec);
  encoder.string(mark.common_realization_group);
}

void c14_encode_selection(C14CanonicalEncoder& encoder,
                          const SelectionSupportV1& selection) {
  encoder.sequence(selection.kinds,
                   [](C14CanonicalEncoder& out, const SelectionKindV1 value) {
                     out.enumeration(value);
                   });
  encoder.sequence(selection.named_classes,
                   [](C14CanonicalEncoder& out, const TypedLabel& value) {
                     out.label(value);
                   });
  encoder.sequence(selection.named_fixed_points,
                   [](C14CanonicalEncoder& out, const TypedLabel& value) {
                     out.label(value);
                   });
}

void c14_encode_phase(C14CanonicalEncoder& encoder,
                      const PhaseSupportV1& phase) {
  encoder.enumeration(phase.payload_phase);
  encoder.enumeration(phase.arrival_composition);
  encoder.boolean(phase.retains_configured_predictive_phase);
  encoder.optional(phase.predictive_phase_codec,
                   [](C14CanonicalEncoder& out,
                      const CodecIdentityV1& codec) {
                     c14_encode_codec(out, codec);
                   });
  encoder.enumeration(phase.finite_horizon_coverage);
  encoder.optional(phase.maximum_finite_horizon,
                   [](C14CanonicalEncoder& out, const BigNat& value) {
                     out.big_nat(value);
                   });
}

void c14_encode_exact_domain(C14CanonicalEncoder& encoder,
                             const ExactArgumentDomain& domain) {
  encoder.rational(domain.lower);
  encoder.rational(domain.upper);
  encoder.boolean(domain.lower_inclusive);
  encoder.boolean(domain.upper_inclusive);
}

void c14_encode_arrival_assumption(C14CanonicalEncoder& encoder,
                                   const ArrivalAssumptionV1& assumption) {
  encoder.enumeration(assumption.kind);
  encoder.enumeration(assumption.use);
  encoder.enumeration(assumption.provision);
  encoder.optional(assumption.moment_order,
                   [](C14CanonicalEncoder& out, const BigNat& value) {
                     out.big_nat(value);
                   });
  encoder.boolean(assumption.joint);
  encoder.boolean(assumption.phase_conditioned);
  encoder.optional(assumption.transform_kind,
                   [](C14CanonicalEncoder& out, const TransformKind value) {
                     out.enumeration(value);
                   });
  encoder.optional(assumption.distribution_scope,
                   [](C14CanonicalEncoder& out,
                      const DistributionScope value) {
                     out.enumeration(value);
                   });
  encoder.optional(assumption.argument_domain,
                   [](C14CanonicalEncoder& out,
                      const ExactArgumentDomain& value) {
                     c14_encode_exact_domain(out, value);
                   });
}

void c14_encode_hypothesis(C14CanonicalEncoder& encoder,
                           const HypothesisClaimV1& hypothesis) {
  encoder.enumeration(hypothesis.kind);
  encoder.optional(hypothesis.variable,
                   [](C14CanonicalEncoder& out, const MomentVariableV1 value) {
                     out.enumeration(value);
                   });
  encoder.optional(hypothesis.order,
                   [](C14CanonicalEncoder& out, const BigNat& value) {
                     out.big_nat(value);
                   });
  encoder.optional(hypothesis.convention_or_class,
                   [](C14CanonicalEncoder& out, const TypedLabel& value) {
                     out.label(value);
                   });
}

void c14_encode_accuracy(C14CanonicalEncoder& encoder,
                         const AccuracyContractV1& accuracy) {
  encoder.u32(static_cast<std::uint32_t>(accuracy.index()));
  std::visit(
      [&encoder](const auto& typed) {
        using Accuracy = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Accuracy, EnumeratedAccuracyV1>) {
          encoder.sequence(
              typed.tolerances,
              [](C14CanonicalEncoder& out,
                 const DeterministicToleranceV1& tolerance) {
                out.enumeration(tolerance.kind);
                out.rational(tolerance.maximum_absolute_error);
              });
        } else if constexpr (std::is_same_v<Accuracy,
                                            AnalyticAccuracyV1>) {
          encoder.big_nat(typed.precision_bits);
          encoder.sequence(
              typed.tolerances,
              [](C14CanonicalEncoder& out,
                 const DeterministicToleranceV1& tolerance) {
                out.enumeration(tolerance.kind);
                out.rational(tolerance.maximum_absolute_error);
              });
        } else if constexpr (std::is_same_v<Accuracy,
                                            MonteCarloAccuracyV1>) {
          encoder.big_nat(typed.replications);
          encoder.rational(typed.confidence_level);
          encoder.enumeration(typed.interval);
          encoder.enumeration(typed.estimand);
          encoder.optional(typed.almost_sure_lower,
                           [](C14CanonicalEncoder& out,
                              const ExactRational& value) {
                             out.rational(value);
                           });
          encoder.optional(typed.almost_sure_upper,
                           [](C14CanonicalEncoder& out,
                              const ExactRational& value) {
                             out.rational(value);
                           });
        }
      },
      accuracy);
}

void c14_encode_role_requirement(
    C14CanonicalEncoder& encoder,
    const MetricSupportRoleRequirementV1& requirement) {
  encoder.enumeration(requirement.role);
  encoder.enumeration(requirement.target_scope);
  encoder.enumeration(requirement.result_scope);
  encoder.enumeration(requirement.evidence_scope);
  encoder.sequence(
      requirement.role_relations,
      [](C14CanonicalEncoder& out,
         const MetricRoleRelationRequirementV1& relation) {
        out.enumeration(relation.relation);
        out.enumeration(relation.other_role);
      });
  encoder.sequence(
      requirement.internal_relations,
      [](C14CanonicalEncoder& out,
         const InternalRelationRequirementV1& relation) {
        out.enumeration(relation.relation);
        out.enumeration(relation.purpose);
      });
}

void c14_encode_manifest_clause(C14CanonicalEncoder& encoder,
                                const MetricSupportClauseV1& clause) {
  encoder.string(clause.clause_id.metric_id);
  encoder.u64(static_cast<std::uint64_t>(clause.clause_id.authored_index));
  encoder.enumeration(clause.metric_kind);
  encoder.u32(static_cast<std::uint32_t>(clause.parameter_domain.index()));
  std::visit(
      [&encoder](const auto& domain) {
        using Domain = std::decay_t<decltype(domain)>;
        if constexpr (std::is_same_v<Domain, ExactMetricParameterSetV1>) {
          encoder.sequence(
              domain.values,
              [](C14CanonicalEncoder& out,
                 const MetricRequestParametersV1& parameters) {
                c14_encode_parameters(out, parameters);
              });
        } else {
          encoder.strong_id(domain.decoder_key);
          c14_encode_parameters(encoder, domain.exact_parameters);
        }
      },
      clause.parameter_domain);
  encoder.sequence(clause.ordered_targets,
                   [](C14CanonicalEncoder& out, const QueueId& target) {
                     out.strong_id(target);
                   });
  encoder.enumeration(clause.target_coupling);
  encoder.sequence(clause.state_fields,
                   [](C14CanonicalEncoder& out,
                      const StateFieldDescriptorV1& field) {
                     c14_encode_state_field(out, field);
                   });
  encoder.sequence(clause.marks,
                   [](C14CanonicalEncoder& out,
                      const MarkDescriptorV1& mark) {
                     c14_encode_mark(out, mark);
                   });
  c14_encode_selection(encoder, clause.selection_domain);
  c14_encode_phase(encoder, clause.phase_domain);
  encoder.enumeration(clause.payload_class.tag);
  encoder.u32(clause.payload_class.version);
  encoder.enumeration(clause.semantic);
  encoder.enumeration(clause.runtime_access);
  encoder.sequence(clause.arrival_assumptions,
                   [](C14CanonicalEncoder& out,
                      const ArrivalAssumptionV1& assumption) {
                     c14_encode_arrival_assumption(out, assumption);
                   });
  encoder.sequence(clause.hypotheses,
                   [](C14CanonicalEncoder& out,
                      const HypothesisClaimV1& hypothesis) {
                     c14_encode_hypothesis(out, hypothesis);
                   });
  encoder.enumeration(clause.solver_route);
  c14_encode_accuracy(encoder, clause.requested_accuracy);
  encoder.enumeration(clause.error_promise.form);
  encoder.enumeration(clause.error_promise.scope);
  encoder.optional(clause.error_promise.maximum_error,
                   [](C14CanonicalEncoder& out,
                      const ExactRational& maximum) {
                     out.rational(maximum);
                   });
  encoder.enumeration(clause.result_scope);
  encoder.enumeration(clause.mandatory_v0.kind);
  encoder.string(clause.mandatory_v0.factor_schema_id);
  encoder.u32(clause.mandatory_v0.factor_schema_version);
  encoder.sequence(clause.required_roles,
                   [](C14CanonicalEncoder& out,
                      const MetricSupportRoleRequirementV1& requirement) {
                     c14_encode_role_requirement(out, requirement);
                   });
}

[[nodiscard]] std::vector<std::byte> c14_state_field_bytes(
    const StateFieldDescriptorV1& value) {
  C14CanonicalEncoder encoder;
  c14_encode_state_field(encoder, value);
  return std::move(encoder).release();
}

[[nodiscard]] std::vector<std::byte> c14_mark_bytes(
    const MarkDescriptorV1& value) {
  C14CanonicalEncoder encoder;
  c14_encode_mark(encoder, value);
  return std::move(encoder).release();
}

[[nodiscard]] std::vector<std::byte> c14_arrival_assumption_bytes(
    const ArrivalAssumptionV1& value) {
  C14CanonicalEncoder encoder;
  c14_encode_arrival_assumption(encoder, value);
  return std::move(encoder).release();
}

[[nodiscard]] std::vector<std::byte> c14_hypothesis_bytes(
    const HypothesisClaimV1& value) {
  C14CanonicalEncoder encoder;
  c14_encode_hypothesis(encoder, value);
  return std::move(encoder).release();
}

[[nodiscard]] bool c14_has_duplicates(const std::vector<QueueId>& values) {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    for (std::size_t right = left + 1U; right < values.size(); ++right) {
      if (values[left] == values[right]) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] bool c14_requires_stability(
    const std::vector<HypothesisClaimV1>& hypotheses) {
  return std::any_of(hypotheses.begin(), hypotheses.end(),
                     [](const HypothesisClaimV1& hypothesis) {
                       return hypothesis.kind ==
                                  HypothesisKindV1::proper_stationary ||
                              hypothesis.kind == HypothesisKindV1::stable ||
                              hypothesis.kind ==
                                  HypothesisKindV1::recurrent ||
                              hypothesis.kind ==
                                  HypothesisKindV1::moment_finite ||
                              hypothesis.kind ==
                                  HypothesisKindV1::reward_integrable;
                     });
}

[[nodiscard]] bool c14_has_role_relation(
    const MetricSupportRoleRequirementV1& requirement,
    const MetricRoleRelationKindV1 relation,
    const MetricSupportRoleV1 role) {
  return std::find(requirement.role_relations.begin(),
                   requirement.role_relations.end(),
                   MetricRoleRelationRequirementV1{relation, role}) !=
         requirement.role_relations.end();
}

[[nodiscard]] bool c14_has_internal_relation(
    const MetricSupportRoleRequirementV1& requirement,
    const MetricRoleRelationKindV1 relation,
    const InternalReferencePurposeV1 purpose) {
  return std::find(requirement.internal_relations.begin(),
                   requirement.internal_relations.end(),
                   InternalRelationRequirementV1{relation, purpose}) !=
         requirement.internal_relations.end();
}

}  // namespace

Result<std::vector<std::byte>> canonical_metric_support_manifest_bytes_v1(
    const MetricSupportManifest& manifest) {
  C14CanonicalEncoder encoder;
  encoder.string("mwperf.metric_support_manifest");
  encoder.u32(1U);
  encoder.u64(static_cast<std::uint64_t>(manifest.clauses().size()));
  for (const auto& clause : manifest.clauses()) {
    c14_encode_manifest_clause(encoder, clause);
  }
  return Result<std::vector<std::byte>>::success(std::move(encoder).release());
}

namespace {

[[nodiscard]] bool c14_valid_codec(const CodecIdentityV1& codec) {
  return !codec.id.empty() && codec.version != 0U;
}

template <typename T>
[[nodiscard]] bool c14_canonicalize_value_set(std::vector<T>& values) {
  std::sort(values.begin(), values.end());
  return std::adjacent_find(values.begin(), values.end()) == values.end();
}

[[nodiscard]] bool c14_canonicalize_exact_parameter(
    MetricRequestParametersV1& parameters) {
  return std::visit(
      [](auto& typed) {
        using P = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<P,
                                     StationaryBacklogPgfParametersV1>) {
          return c14_canonicalize_value_set(typed.points);
        } else if constexpr (
            std::is_same_v<P, BacklogConditionedServiceParametersV1>) {
          return c14_canonicalize_value_set(typed.levels);
        } else if constexpr (
            std::is_same_v<P, ServiceAutocovarianceParametersV1> ||
            std::is_same_v<P, LaggedCrossQueueCovarianceParametersV1>) {
          return c14_canonicalize_value_set(typed.lags);
        } else if constexpr (
            std::is_same_v<P, ServiceSpectrumParametersV1>) {
          return c14_canonicalize_value_set(typed.frequencies);
        } else if constexpr (
            std::is_same_v<P, TransientBacklogLawParametersV1>) {
          return c14_canonicalize_value_set(typed.horizons);
        } else {
          return true;
        }
      },
      parameters);
}

[[nodiscard]] bool c14_canonicalize_accuracy_contract(
    AccuracyContractV1& accuracy) {
  return std::visit(
      [](auto& typed) {
        using Accuracy = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Accuracy, EnumeratedAccuracyV1> ||
                      std::is_same_v<Accuracy, AnalyticAccuracyV1>) {
          std::sort(typed.tolerances.begin(), typed.tolerances.end(),
                    [](const auto& left, const auto& right) {
                      return left.kind < right.kind;
                    });
          const bool tolerances_valid = std::all_of(
              typed.tolerances.begin(), typed.tolerances.end(),
              [](const DeterministicToleranceV1& tolerance) {
                return c14_enum_rank_below(tolerance.kind, 4U) &&
                       tolerance.maximum_absolute_error.is_nonnegative();
              });
          const bool duplicate = std::adjacent_find(
                                     typed.tolerances.begin(),
                                     typed.tolerances.end(),
                                     [](const auto& left, const auto& right) {
                                       return left.kind == right.kind;
                                     }) != typed.tolerances.end();
          if constexpr (std::is_same_v<Accuracy, AnalyticAccuracyV1>) {
            return tolerances_valid && !duplicate &&
                   !typed.precision_bits.is_zero();
          }
          return tolerances_valid && !duplicate;
        } else if constexpr (std::is_same_v<Accuracy,
                                            MonteCarloAccuracyV1>) {
          if (typed.replications.is_zero() ||
              !typed.confidence_level.is_positive() ||
              typed.confidence_level >= ExactRational::one() ||
              !c14_enum_rank_below(typed.interval, 3U) ||
              !c14_enum_rank_below(typed.estimand, 3U) ||
              typed.almost_sure_lower.has_value() !=
                  typed.almost_sure_upper.has_value()) {
            return false;
          }
          return !typed.almost_sure_lower.has_value() ||
                 *typed.almost_sure_lower <= *typed.almost_sure_upper;
        } else {
          return true;
        }
      },
      accuracy);
}

[[nodiscard]] bool c14_valid_exact_parameter(
    const MetricKindV1 kind, const MetricRequestParametersV1& parameters) {
  const auto kind_rank = static_cast<std::uint32_t>(kind);
  if (kind_rank >= std::variant_size_v<MetricRequestParametersV1> ||
      parameters.index() != kind_rank) {
    return false;
  }
  return std::visit(
      [](const auto& typed) {
        using P = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<P,
                                     StationaryBacklogPgfParametersV1>) {
          // ExactRational is already finite and reduced.  PGF query-domain
          // admissibility is negotiated against the provider's declared
          // analytic domain; C14 must not impose a universal [0,1] domain.
          return !typed.points.empty();
        } else if constexpr (
            std::is_same_v<P, StationaryBacklogQuantileParametersV1>) {
          return typed.probability.is_positive() &&
                 typed.probability < ExactRational::one() &&
                 typed.convention ==
                     DiscreteQuantileConventionV1::lower_inverse_cdf;
        } else if constexpr (
            std::is_same_v<P, StationaryBacklogMomentParametersV1>) {
          return !typed.order.is_zero();
        } else if constexpr (
            std::is_same_v<P, BacklogConditionedServiceParametersV1>) {
          return !typed.levels.empty();
        } else if constexpr (
            std::is_same_v<P, StationaryEdgeRewardParametersV1>) {
          return static_cast<std::uint32_t>(typed.reward) < 3U &&
                 !typed.moment_order.is_zero();
        } else if constexpr (
            std::is_same_v<P, ServiceAutocovarianceParametersV1> ||
            std::is_same_v<P, LaggedCrossQueueCovarianceParametersV1>) {
          return !typed.lags.empty() &&
                 std::none_of(typed.lags.begin(), typed.lags.end(),
                              [](const BigNat& lag) { return lag.is_zero(); });
        } else if constexpr (
            std::is_same_v<P, ServiceSpectrumParametersV1>) {
          return !typed.frequencies.empty() &&
                 !typed.truncation_lag.is_zero() &&
                 typed.window == SpectrumWindowV1::rectangular_truncation;
        } else if constexpr (
            std::is_same_v<P, ServiceWindowCountParametersV1>) {
          return !typed.width.is_zero();
        } else if constexpr (std::is_same_v<P, MeanEventGapParametersV1> ||
                             std::is_same_v<P,
                                            EventGapDistributionParametersV1>) {
          return static_cast<std::uint32_t>(typed.event) < 3U;
        } else if constexpr (std::is_same_v<P,
                                           MeanBinaryRunParametersV1> ||
                             std::is_same_v<P,
                                            BinaryRunDistributionParametersV1>) {
          return std::visit(
              [](const auto& predicate) {
                using Predicate = std::decay_t<decltype(predicate)>;
                if constexpr (std::is_same_v<Predicate,
                                             BasicBinaryPredicateV1>) {
                  return static_cast<std::uint32_t>(predicate) < 3U;
                }
                return true;
              },
              typed.predicate);
        } else if constexpr (std::is_same_v<P, FirstHitParametersV1> ||
                             std::is_same_v<P,
                                            ThresholdExcursionParametersV1>) {
          return static_cast<std::uint32_t>(typed.set.kind) < 3U;
        } else if constexpr (
            std::is_same_v<P, TransientBacklogLawParametersV1>) {
          return !typed.horizons.empty();
        } else if constexpr (std::is_same_v<P, FifoDelayParametersV1>) {
          return std::visit(
              [](const auto& output) {
                using Output = std::decay_t<decltype(output)>;
                if constexpr (std::is_same_v<Output,
                                             FifoDelayQuantileOutputV1>) {
                  return output.probability.is_positive() &&
                         output.probability < ExactRational::one() &&
                         output.convention ==
                             DiscreteQuantileConventionV1::lower_inverse_cdf;
                } else if constexpr (std::is_same_v<Output,
                                                  FifoDelayMomentOutputV1>) {
                  return !output.order.is_zero();
                }
                return true;
              },
              typed.output);
        } else if constexpr (
            std::is_same_v<P, FifoDelayConditionedParametersV1>) {
          const bool output_valid = std::visit(
              [](const auto& output) {
                using Output = std::decay_t<decltype(output)>;
                if constexpr (std::is_same_v<Output,
                                             FifoDelayQuantileOutputV1>) {
                  return output.probability.is_positive() &&
                         output.probability < ExactRational::one() &&
                         output.convention ==
                             DiscreteQuantileConventionV1::lower_inverse_cdf;
                } else if constexpr (std::is_same_v<Output,
                                                  FifoDelayMomentOutputV1>) {
                  return !output.order.is_zero();
                }
                return true;
              },
              typed.output);
          const bool condition_valid = std::visit(
              [](const auto& condition) {
                using Condition = std::decay_t<decltype(condition)>;
                if constexpr (std::is_same_v<Condition,
                                             FifoRankConditionV1>) {
                  return !condition.one_based_rank.is_zero();
                } else if constexpr (std::is_same_v<
                                         Condition,
                                         FifoBatchConditionV1>) {
                  return !condition.batch_size.is_zero();
                }
                return true;
              },
              typed.condition);
          return output_valid && condition_valid;
        } else if constexpr (
            std::is_same_v<P, JointBacklogEventParametersV1>) {
          return static_cast<std::uint32_t>(typed.relation) < 2U &&
                 !typed.thresholds.empty();
        } else if constexpr (
            std::is_same_v<P, OrderedScheduleSequenceParametersV1>) {
          return !typed.horizon.is_zero();
        } else {
          return true;
        }
      },
      parameters);
}

[[nodiscard]] bool c14_role_is_present(
    const MetricSupportClauseV1& clause, const MetricSupportRoleV1 role) {
  return std::any_of(
      clause.required_roles.begin(), clause.required_roles.end(),
      [role](const MetricSupportRoleRequirementV1& requirement) {
        return requirement.role == role;
      });
}

[[nodiscard]] MetricSupportRoleV1 c14_primary_role_for_semantic(
    const SemanticTagV1 semantic) {
  switch (semantic) {
    case SemanticTagV1::scalar_backlog_response:
      return MetricSupportRoleV1::deployed_response;
    case SemanticTagV1::stationary_marked_edge:
      return MetricSupportRoleV1::stationary_marked_edge_law;
    case SemanticTagV1::staged_opportunity_flux_law:
      return MetricSupportRoleV1::staged_opportunity_flux_law;
    case SemanticTagV1::temporal_one_slot_continuation:
      return MetricSupportRoleV1::temporal_continuation_law;
    case SemanticTagV1::romr_residence_word_law:
      return MetricSupportRoleV1::residence_word_law;
    case SemanticTagV1::stopped_path_law:
      return MetricSupportRoleV1::stopped_path_law;
    case SemanticTagV1::coupled_target_schedule_law:
      return MetricSupportRoleV1::coupled_schedule_law;
    case SemanticTagV1::direct_metric_decoder:
      return MetricSupportRoleV1::direct_metric_value;
    case SemanticTagV1::response_envelope_law:
      return MetricSupportRoleV1::response_envelope;
  }
  return MetricSupportRoleV1::deployed_payload;
}

[[nodiscard]] bool c14_metric_kind_is_coupled(const MetricKindV1 kind) {
  return kind == MetricKindV1::joint_backlog_covariance ||
         kind == MetricKindV1::lagged_cross_queue_covariance ||
         kind == MetricKindV1::joint_backlog_event ||
         kind == MetricKindV1::joint_delay ||
         kind == MetricKindV1::ordered_schedule_sequence;
}

[[nodiscard]] bool c14_parameter_target_arity_valid(
    const MetricKindV1 kind, const MetricRequestParametersV1& parameters,
    const std::size_t target_count, const TargetCouplingV1 coupling) {
  if (kind == MetricKindV1::joint_backlog_event) {
    return std::get<JointBacklogEventParametersV1>(parameters)
               .thresholds.size() == target_count;
  }
  if (kind == MetricKindV1::ordered_schedule_sequence) {
    const bool full = std::get<OrderedScheduleSequenceParametersV1>(parameters)
                          .retain_full_schedule;
    return full == (coupling == TargetCouplingV1::full_schedule_identity);
  }
  return true;
}

[[nodiscard]] Result<void> c14_validate_role_requirement(
    const MetricSupportClauseV1& clause,
    MetricSupportRoleRequirementV1& requirement) {
  const auto* schema = metric_support_role_schema_v1(requirement.role);
  if (schema == nullptr) {
    return c14_manifest_failure<void>("metric_manifest_role_unknown",
                                      "manifest role is not a v1 role");
  }
  const std::uint32_t target_bit =
      metric_target_scope_bit_v1(requirement.target_scope);
  const std::uint32_t result_bit =
      metric_result_scope_bit_v1(requirement.result_scope);
  const std::uint32_t evidence_bit =
      metric_evidence_scope_bit_v1(requirement.evidence_scope);
  if (target_bit == 0U ||
      (schema->allowed_target_scopes & target_bit) == 0U ||
      result_bit == 0U ||
      (schema->allowed_result_scopes & result_bit) == 0U ||
      evidence_bit == 0U ||
      (schema->allowed_evidence_scopes & evidence_bit) == 0U) {
    return c14_manifest_failure<void>(
        "metric_manifest_role_scope_invalid",
        "manifest role uses a target, result, or evidence scope forbidden by "
        "the fixed v1 role schema");
  }

  std::sort(requirement.role_relations.begin(),
            requirement.role_relations.end());
  if (std::adjacent_find(requirement.role_relations.begin(),
                         requirement.role_relations.end()) !=
      requirement.role_relations.end()) {
    return c14_manifest_failure<void>(
        "metric_manifest_role_relation_duplicate",
        "manifest role relation list contains a duplicate");
  }
  std::sort(requirement.internal_relations.begin(),
            requirement.internal_relations.end());
  if (std::adjacent_find(requirement.internal_relations.begin(),
                         requirement.internal_relations.end()) !=
      requirement.internal_relations.end()) {
    return c14_manifest_failure<void>(
        "metric_manifest_internal_relation_duplicate",
        "manifest internal relation list contains a duplicate");
  }

  std::array<std::uint32_t, 4U> role_masks{};
  for (const auto& relation : requirement.role_relations) {
    const auto relation_rank = static_cast<std::uint32_t>(relation.relation);
    const std::uint32_t role_bit = metric_support_role_bit_v1(
        relation.other_role);
    if (relation_rank >= role_masks.size() || role_bit == 0U ||
        !metric_role_relation_mask_contains_v1(
            allowed_role_relation_mask_v1(*schema, relation.relation),
            relation.other_role)) {
      return c14_manifest_failure<void>(
          "metric_manifest_role_relation_invalid",
          "manifest role relation is outside the fixed v1 allowed mask");
    }
    role_masks[relation_rank] |= role_bit;
  }
  std::array<std::uint64_t, 4U> internal_masks{};
  for (const auto& relation : requirement.internal_relations) {
    const auto relation_rank = static_cast<std::uint32_t>(relation.relation);
    const std::uint64_t purpose_bit =
        internal_reference_purpose_bit_v1(relation.purpose);
    if (relation_rank >= internal_masks.size() || purpose_bit == 0U ||
        !internal_relation_mask_contains_v1(
            allowed_internal_relation_mask_v1(*schema, relation.relation),
            relation.purpose)) {
      return c14_manifest_failure<void>(
          "metric_manifest_internal_relation_invalid",
          "manifest internal relation is outside the fixed v1 allowed mask");
    }
    internal_masks[relation_rank] |= purpose_bit;
  }
  for (std::uint32_t rank = 0U; rank < 4U; ++rank) {
    const auto relation = static_cast<MetricRoleRelationKindV1>(rank);
    const std::uint32_t required_roles =
        required_role_relation_mask_v1(*schema, relation);
    const std::uint64_t required_internal =
        required_internal_relation_mask_v1(*schema, relation);
    if ((role_masks[rank] & required_roles) != required_roles ||
        (internal_masks[rank] & required_internal) != required_internal) {
      return c14_manifest_failure<void>(
          "metric_manifest_role_relation_missing",
          "manifest role omits a fixed v1 parent, binding, evidence, or "
          "subject relation");
    }
  }

  if (requirement.role == MetricSupportRoleV1::deployed_payload &&
      requirement.result_scope != clause.result_scope) {
    return c14_manifest_failure<void>(
        "metric_manifest_selected_scope_mismatch",
        "deployed_payload result scope differs from the clause-selected "
        "scope");
  }
  if (requirement.role == MetricSupportRoleV1::direct_metric_value &&
      requirement.result_scope != clause.result_scope) {
    return c14_manifest_failure<void>(
        "metric_manifest_selected_scope_mismatch",
        "direct metric result scope differs from the clause-selected scope");
  }
  if (requirement.role == MetricSupportRoleV1::response_envelope &&
      (requirement.result_scope != clause.result_scope ||
       requirement.evidence_scope != clause.error_promise.scope)) {
    return c14_manifest_failure<void>(
        "metric_manifest_selected_scope_mismatch",
        "response envelope scopes differ from the values frozen by its "
        "clause");
  }

  if (requirement.role == MetricSupportRoleV1::deployed_response) {
    const auto count = static_cast<std::size_t>(std::count_if(
        requirement.role_relations.begin(),
        requirement.role_relations.end(), [](const auto& relation) {
          return relation.relation == MetricRoleRelationKindV1::subject;
        }));
    if (count != 1U) {
      return c14_manifest_failure<void>(
          "metric_manifest_deployed_response_source_invalid",
          "deployed_response must select exactly one raw, nominal, or recoded "
          "point-product role");
    }
  }
  if (requirement.role == MetricSupportRoleV1::nominal_response ||
      requirement.role == MetricSupportRoleV1::recoded_response) {
    const bool has_parent = std::any_of(
        requirement.role_relations.begin(), requirement.role_relations.end(),
        [](const auto& relation) {
          return relation.relation ==
                 MetricRoleRelationKindV1::lineage_parent;
        });
    const bool has_internal_parent = std::any_of(
        requirement.internal_relations.begin(),
        requirement.internal_relations.end(), [](const auto& relation) {
          return relation.relation ==
                 MetricRoleRelationKindV1::lineage_parent;
        });
    if (!has_parent && !has_internal_parent) {
      return c14_manifest_failure<void>(
          "metric_manifest_derivation_parent_missing",
          "nominal or recoded response omits its policy-selected derivation "
          "parent");
    }
  }
  if (requirement.role == MetricSupportRoleV1::stationary_marked_edge_law &&
      c14_requires_stability(clause.hypotheses) &&
      !c14_has_role_relation(requirement,
                             MetricRoleRelationKindV1::evidence,
                             MetricSupportRoleV1::stability_certificate)) {
    return c14_manifest_failure<void>(
        "metric_manifest_stability_evidence_missing",
        "stationary clause requiring recurrence, stability, or moments omits "
        "its stability certificate role");
  }
  if (requirement.role == MetricSupportRoleV1::response_envelope) {
    const bool physical =
        requirement.result_scope == MetricResultScopeV1::physical_bound ||
        requirement.evidence_scope == MetricEvidenceScopeV1::physical_system;
    const bool has_transfer = c14_has_role_relation(
        requirement, MetricRoleRelationKindV1::evidence,
        MetricSupportRoleV1::physical_transfer_evidence);
    if (physical != has_transfer) {
      return c14_manifest_failure<void>(
          "metric_manifest_physical_transfer_invalid",
          "physical-bound envelope requires exactly the separately typed "
          "physical-transfer role");
    }
  }
  if (requirement.role == MetricSupportRoleV1::direct_metric_value) {
    const bool physical =
        requirement.result_scope == MetricResultScopeV1::physical_bound ||
        requirement.evidence_scope == MetricEvidenceScopeV1::physical_system;
    const bool has_transfer = c14_has_role_relation(
        requirement, MetricRoleRelationKindV1::evidence,
        MetricSupportRoleV1::physical_transfer_evidence);
    if (physical != has_transfer) {
      return c14_manifest_failure<void>(
          "metric_manifest_physical_transfer_invalid",
          "a physical-scope direct result requires exactly the separately "
          "typed physical-transfer role");
    }
  }
  if (requirement.role == MetricSupportRoleV1::coupled_schedule_law &&
      clause.target_coupling == TargetCouplingV1::full_schedule_identity &&
      !c14_has_internal_relation(requirement,
                                 MetricRoleRelationKindV1::binding,
                                 InternalReferencePurposeV1::full_schedule)) {
    return c14_manifest_failure<void>(
        "metric_manifest_full_schedule_parent_missing",
        "full-schedule coupling omits the full schedule identity");
  }
  if (requirement.role == MetricSupportRoleV1::temporal_continuation_law) {
    const bool needs_initial = std::any_of(
        clause.selection_domain.kinds.begin(),
        clause.selection_domain.kinds.end(), [](const SelectionKindV1 kind) {
          return kind == SelectionKindV1::transient_initial ||
                 kind == SelectionKindV1::prescribed_entrance ||
                 kind == SelectionKindV1::event_palm ||
                 kind == SelectionKindV1::start_palm ||
                 kind == SelectionKindV1::admission_palm ||
                 kind == SelectionKindV1::threshold_crossing_palm;
        });
    const bool needs_selection = std::any_of(
        clause.selection_domain.kinds.begin(),
        clause.selection_domain.kinds.end(), [](const SelectionKindV1 kind) {
          return kind == SelectionKindV1::stationary_unique ||
                 kind == SelectionKindV1::stationary_class ||
                 kind == SelectionKindV1::stationary_mixture ||
                 kind == SelectionKindV1::fixed_point_unique ||
                 kind == SelectionKindV1::fixed_point_id;
        });
    if ((needs_initial && !c14_has_internal_relation(
                              requirement,
                              MetricRoleRelationKindV1::binding,
                              InternalReferencePurposeV1::initial_binding)) ||
        (needs_selection && !c14_has_internal_relation(
                                requirement,
                                MetricRoleRelationKindV1::binding,
                                InternalReferencePurposeV1::selection_binding))) {
      return c14_manifest_failure<void>(
          "metric_manifest_temporal_selection_binding_missing",
          "temporal continuation omits an initial or selection binding "
          "required by its declared selection domain");
    }
  }
  if (requirement.role == MetricSupportRoleV1::calibration_evidence) {
    const bool has_bank = c14_has_internal_relation(
        requirement, MetricRoleRelationKindV1::binding,
        InternalReferencePurposeV1::sampling_bank);
    const bool has_population = c14_has_internal_relation(
        requirement, MetricRoleRelationKindV1::binding,
        InternalReferencePurposeV1::exact_population);
    if (has_bank == has_population) {
      return c14_manifest_failure<void>(
          "metric_manifest_calibration_input_invalid",
          "calibration evidence must name exactly one frozen sampling bank or "
          "exact population object");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> c14_canonicalize_clause(
    MetricSupportClauseV1& clause) {
  const bool coupled_kind = c14_metric_kind_is_coupled(clause.metric_kind);
  if (clause.clause_id.metric_id.empty() ||
      !c14_enum_rank_below(clause.metric_kind, 29U) ||
      clause.ordered_targets.empty() || c14_has_duplicates(clause.ordered_targets) ||
      !c14_enum_rank_below(clause.target_coupling, 3U) ||
      (!coupled_kind &&
       (clause.target_coupling != TargetCouplingV1::scalar_target ||
        clause.ordered_targets.size() != 1U)) ||
      (coupled_kind &&
       (clause.target_coupling == TargetCouplingV1::scalar_target ||
        clause.ordered_targets.size() < 2U))) {
    return c14_manifest_failure<void>(
        "metric_manifest_clause_identity_invalid",
        "manifest clause has an invalid identity, metric tag, or target "
        "coupling");
  }
  if (auto* parameters =
          std::get_if<ExactMetricParameterSetV1>(&clause.parameter_domain)) {
    if (parameters->values.empty()) {
      return c14_manifest_failure<void>(
          "metric_manifest_parameter_domain_empty",
          "exact metric parameter domain is empty");
    }
    for (auto& value : parameters->values) {
      if (!c14_canonicalize_exact_parameter(value)) {
        return c14_manifest_failure<void>(
            "metric_manifest_parameter_collection_duplicate",
            "metric parameter point repeats a set-like point, level, lag, "
            "frequency, or horizon");
      }
      if (!c14_valid_exact_parameter(clause.metric_kind, value)) {
        return c14_manifest_failure<void>(
            "metric_manifest_parameter_domain_invalid",
            "metric parameter domain contains a wrong-kind or malformed exact "
            "parameter point");
      }
      if (!c14_parameter_target_arity_valid(
              clause.metric_kind, value, clause.ordered_targets.size(),
              clause.target_coupling)) {
        return c14_manifest_failure<void>(
            "metric_manifest_parameter_target_arity_mismatch",
            "metric parameter point does not match ordered target arity or "
            "coupling");
      }
    }
    if (c14_sort_encoded_and_has_duplicate(parameters->values,
                                            c14_parameter_bytes)) {
      return c14_manifest_failure<void>(
          "metric_manifest_parameter_domain_duplicate",
          "metric parameter domain repeats an exact point");
    }
  } else {
    auto& decoder = std::get<ExactMetricDecoderDomainV1>(
        clause.parameter_domain);
    if (!c14_canonicalize_exact_parameter(decoder.exact_parameters) ||
        !c14_valid_exact_parameter(clause.metric_kind,
                                   decoder.exact_parameters) ||
        !c14_parameter_target_arity_valid(
            clause.metric_kind, decoder.exact_parameters,
            clause.ordered_targets.size(), clause.target_coupling) ||
        clause.semantic != SemanticTagV1::direct_metric_decoder ||
        clause.runtime_access != RuntimeAccessTagV1::direct_metric_decoder ||
        clause.solver_route != SolverRegimeV1::direct) {
      return c14_manifest_failure<void>(
          "metric_manifest_decoder_domain_invalid",
          "exact-request decoder domain is not bound to one exact direct "
          "metric route");
    }
  }

  for (const auto& field : clause.state_fields) {
    if (!c14_enum_rank_below(field.kind, 8U) ||
        !c14_enum_rank_below(field.ownership, 2U) ||
        !c14_valid_codec(field.codec)) {
      return c14_manifest_failure<void>(
          "metric_manifest_state_field_invalid",
          "manifest state-field descriptor is malformed");
    }
  }
  if (c14_sort_encoded_and_has_duplicate(clause.state_fields,
                                          c14_state_field_bytes)) {
    return c14_manifest_failure<void>(
        "metric_manifest_state_field_duplicate",
        "manifest state-field descriptor is repeated");
  }
  for (std::size_t index = 1U; index < clause.state_fields.size(); ++index) {
    if (clause.state_fields[index - 1U].kind ==
        clause.state_fields[index].kind) {
      return c14_manifest_failure<void>(
          "metric_manifest_state_field_contradiction",
          "one state-field kind has more than one ownership or codec "
          "declaration");
    }
  }
  for (const auto& mark : clause.marks) {
    if (!c14_enum_rank_below(mark.kind, 18U) ||
        !c14_enum_rank_below(mark.reveal_stage, 6U) ||
        !c14_valid_codec(mark.codec)) {
      return c14_manifest_failure<void>(
          "metric_manifest_mark_invalid",
          "manifest mark descriptor is malformed");
    }
  }
  if (c14_sort_encoded_and_has_duplicate(clause.marks, c14_mark_bytes)) {
    return c14_manifest_failure<void>("metric_manifest_mark_duplicate",
                                      "manifest mark descriptor is repeated");
  }
  for (std::size_t index = 1U; index < clause.marks.size(); ++index) {
    if (clause.marks[index - 1U].kind == clause.marks[index].kind) {
      return c14_manifest_failure<void>(
          "metric_manifest_mark_contradiction",
          "one mark kind has more than one reveal, codec, or realization "
          "declaration");
    }
  }

  std::sort(clause.selection_domain.kinds.begin(),
            clause.selection_domain.kinds.end());
  if (clause.selection_domain.kinds.empty() ||
      std::any_of(clause.selection_domain.kinds.begin(),
                  clause.selection_domain.kinds.end(),
                  [](const SelectionKindV1 value) {
                    return !c14_enum_rank_below(value, 11U);
                  }) ||
      std::adjacent_find(clause.selection_domain.kinds.begin(),
                         clause.selection_domain.kinds.end()) !=
          clause.selection_domain.kinds.end()) {
    return c14_manifest_failure<void>(
        "metric_manifest_selection_domain_invalid",
        "selection domain is empty, duplicated, or contains an invalid tag");
  }
  std::sort(clause.selection_domain.named_classes.begin(),
            clause.selection_domain.named_classes.end());
  std::sort(clause.selection_domain.named_fixed_points.begin(),
            clause.selection_domain.named_fixed_points.end());
  if (std::adjacent_find(clause.selection_domain.named_classes.begin(),
                         clause.selection_domain.named_classes.end()) !=
          clause.selection_domain.named_classes.end() ||
      std::adjacent_find(
          clause.selection_domain.named_fixed_points.begin(),
          clause.selection_domain.named_fixed_points.end()) !=
          clause.selection_domain.named_fixed_points.end()) {
    return c14_manifest_failure<void>(
        "metric_manifest_selection_label_duplicate",
        "selection domain repeats a named class or fixed point");
  }

  const auto& phase = clause.phase_domain;
  const bool codec_present = phase.predictive_phase_codec.has_value();
  const bool horizon_present = phase.maximum_finite_horizon.has_value();
  if (!c14_enum_rank_below(phase.payload_phase, 2U) ||
      !c14_enum_rank_below(phase.arrival_composition, 4U) ||
      !c14_enum_rank_below(phase.finite_horizon_coverage, 3U) ||
      codec_present != phase.retains_configured_predictive_phase ||
      (codec_present && !c14_valid_codec(*phase.predictive_phase_codec)) ||
      (phase.finite_horizon_coverage ==
           FiniteHorizonCoverageKindV1::bounded) != horizon_present) {
    return c14_manifest_failure<void>(
        "metric_manifest_phase_domain_invalid",
        "phase or finite-horizon support declaration is contradictory");
  }
  if (!c14_enum_rank_below(clause.payload_class.tag, 8U) ||
      clause.payload_class.version == 0U ||
      !c14_enum_rank_below(clause.semantic, 9U) ||
      !c14_enum_rank_below(clause.runtime_access, 7U) ||
      !c14_enum_rank_below(clause.solver_route, 4U) ||
      !c14_canonicalize_accuracy_contract(clause.requested_accuracy) ||
      clause.requested_accuracy.index() !=
          static_cast<std::size_t>(clause.solver_route)) {
    return c14_manifest_failure<void>(
        "metric_manifest_route_invalid",
        "payload, semantic, access, solver, or accuracy route is invalid");
  }

  for (const auto& assumption : clause.arrival_assumptions) {
    if (!valid_arrival_assumption_shape(assumption)) {
      return c14_manifest_failure<void>(
          "metric_manifest_arrival_assumption_invalid",
          "arrival assumption contains an invalid closed tag or fields that "
          "do not belong to its selected capability kind");
    }
  }
  if (c14_sort_encoded_and_has_duplicate(clause.arrival_assumptions,
                                          c14_arrival_assumption_bytes)) {
    return c14_manifest_failure<void>(
        "metric_manifest_arrival_assumption_duplicate",
        "arrival assumption is repeated");
  }
  for (const auto& hypothesis : clause.hypotheses) {
    if (!valid_hypothesis_shape(hypothesis)) {
      return c14_manifest_failure<void>(
          "metric_manifest_hypothesis_invalid",
          "hypothesis contains an invalid closed tag or fields that do not "
          "belong to its selected hypothesis kind");
    }
  }
  if (c14_sort_encoded_and_has_duplicate(clause.hypotheses,
                                          c14_hypothesis_bytes)) {
    return c14_manifest_failure<void>(
        "metric_manifest_hypothesis_duplicate",
        "hypothesis is repeated");
  }

  if (!c14_enum_rank_below(clause.error_promise.form, 7U) ||
      metric_evidence_scope_bit_v1(clause.error_promise.scope) == 0U ||
      (clause.error_promise.maximum_error.has_value() &&
       !clause.error_promise.maximum_error->is_nonnegative()) ||
      metric_result_scope_bit_v1(clause.result_scope) == 0U ||
      clause.mandatory_v0.kind !=
          V0DeclarationKindV1::structural_witness_required ||
      clause.mandatory_v0.factor_schema_id.empty() ||
      clause.mandatory_v0.factor_schema_version == 0U) {
    return c14_manifest_failure<void>(
        "metric_manifest_contract_invalid",
        "error, result, or mandatory-V0 contract is malformed");
  }
  if ((clause.error_promise.form == StructuralErrorFormV1::exact &&
       clause.error_promise.maximum_error.has_value() &&
       !clause.error_promise.maximum_error->is_zero()) ||
      ((clause.error_promise.form ==
            StructuralErrorFormV1::deterministic_enclosure ||
        clause.error_promise.form ==
            StructuralErrorFormV1::numerical_residual) &&
       !clause.error_promise.maximum_error.has_value())) {
    return c14_manifest_failure<void>(
        "metric_manifest_error_promise_invalid",
        "an exact promise must omit or declare zero error, and a bounded "
        "deterministic promise must declare a maximum error");
  }
  if (clause.required_roles.empty()) {
    return c14_manifest_failure<void>(
        "metric_manifest_roles_empty",
        "metric support clause has no symbolic roles");
  }
  for (auto& role : clause.required_roles) {
    auto validated = c14_validate_role_requirement(clause, role);
    if (!validated) {
      return validated;
    }
  }
  std::sort(clause.required_roles.begin(), clause.required_roles.end(),
            [](const auto& left, const auto& right) {
              return metric_support_role_rank_v1(left.role) <
                     metric_support_role_rank_v1(right.role);
            });
  for (std::size_t index = 1U; index < clause.required_roles.size(); ++index) {
    if (clause.required_roles[index - 1U].role ==
        clause.required_roles[index].role) {
      return c14_manifest_failure<void>(
          "metric_manifest_role_duplicate",
          "metric support clause repeats a symbolic role");
    }
  }
  if (!c14_role_is_present(clause, MetricSupportRoleV1::deployed_payload) ||
      !c14_role_is_present(clause,
                           c14_primary_role_for_semantic(clause.semantic))) {
    return c14_manifest_failure<void>(
        "metric_manifest_primary_role_missing",
        "metric support clause omits deployed_payload or the primary role for "
        "its semantic tag");
  }
  const MetricSupportRoleV1 primary_role =
      c14_primary_role_for_semantic(clause.semantic);
  const auto primary = std::find_if(
      clause.required_roles.begin(), clause.required_roles.end(),
      [primary_role](const MetricSupportRoleRequirementV1& requirement) {
        return requirement.role == primary_role;
      });
  if (primary == clause.required_roles.end() ||
      primary->result_scope != clause.result_scope) {
    return c14_manifest_failure<void>(
        "metric_manifest_primary_scope_mismatch",
        "the semantic primary role does not use the clause-selected result "
        "scope");
  }
  const bool has_physical_transfer_role = c14_role_is_present(
      clause, MetricSupportRoleV1::physical_transfer_evidence);
  const bool primary_names_physical_transfer =
      primary != clause.required_roles.end() &&
      c14_has_role_relation(
          *primary, MetricRoleRelationKindV1::evidence,
          MetricSupportRoleV1::physical_transfer_evidence);
  const bool clause_claims_physical =
      clause.result_scope == MetricResultScopeV1::physical_bound ||
      clause.error_promise.scope == MetricEvidenceScopeV1::physical_system;
  if (has_physical_transfer_role != primary_names_physical_transfer ||
      primary_names_physical_transfer != clause_claims_physical) {
    return c14_manifest_failure<void>(
        "metric_manifest_physical_transfer_invalid",
        "every physical result or physical-system error claim, and only such "
        "a claim, must attach physical-transfer evidence to the exact "
        "primary metric result");
  }
  for (const auto& role : clause.required_roles) {
    for (const auto& relation : role.role_relations) {
      if (!c14_role_is_present(clause, relation.other_role)) {
        return c14_manifest_failure<void>(
            "metric_manifest_related_role_missing",
            "a symbolic role relation names a role absent from its clause");
      }
      if (relation.relation != MetricRoleRelationKindV1::evidence ||
          (relation.other_role !=
               MetricSupportRoleV1::statistical_evidence &&
           relation.other_role !=
               MetricSupportRoleV1::calibration_evidence &&
           relation.other_role !=
               MetricSupportRoleV1::compression_evidence)) {
        continue;
      }
      const auto evidence = std::find_if(
          clause.required_roles.begin(), clause.required_roles.end(),
          [&](const MetricSupportRoleRequirementV1& candidate) {
            return candidate.role == relation.other_role;
          });
      if (evidence == clause.required_roles.end() ||
          evidence->evidence_scope != role.evidence_scope) {
        return c14_manifest_failure<void>(
            "metric_manifest_evidence_source_scope_mismatch",
            "statistical, calibration, or compression evidence must retain "
            "the exact source/destination product scope of the role that "
            "requires it");
      }
    }
  }
  return Result<void>::success();
}

}  // namespace

Result<MetricSupportManifest> MetricSupportManifest::from_clauses(
    std::vector<MetricSupportClauseV1> clauses) {
  if (clauses.empty()) {
    return c14_manifest_failure<MetricSupportManifest>(
        "metric_support_manifest_empty",
        "a version-1 metric support manifest must be nonempty");
  }
  for (auto& clause : clauses) {
    auto validated = c14_canonicalize_clause(clause);
    if (!validated) {
      return Result<MetricSupportManifest>::failure(validated.error());
    }
  }
  std::sort(clauses.begin(), clauses.end(),
            [](const MetricSupportClauseV1& left,
               const MetricSupportClauseV1& right) {
              return left.clause_id < right.clause_id;
            });
  for (std::size_t index = 1U; index < clauses.size(); ++index) {
    if (clauses[index - 1U].clause_id == clauses[index].clause_id) {
      return c14_manifest_failure<MetricSupportManifest>(
          "metric_support_manifest_clause_duplicate",
          "metric support manifest repeats a clause identity");
    }
  }

  C14CanonicalEncoder encoder;
  encoder.string("mwperf.metric_support_manifest");
  encoder.u32(1U);
  encoder.u64(static_cast<std::uint64_t>(clauses.size()));
  for (const auto& clause : clauses) {
    c14_encode_manifest_clause(encoder, clause);
  }
  auto digest = sha256_domain_separated(
      "mwperf.metric_support_manifest.v1", encoder.bytes());
  if (!digest) {
    return Result<MetricSupportManifest>::failure(digest.error());
  }
  return Result<MetricSupportManifest>::success(MetricSupportManifest(
      std::move(clauses), std::move(digest).value()));
}

namespace {

[[nodiscard]] RealizedReferenceCoreV1& c14_mutable_reference_core(
    RealizedReferenceV1& reference) noexcept {
  return std::visit(
      [](auto& typed) -> RealizedReferenceCoreV1& { return typed.core; },
      reference);
}

void c14_encode_artifact_object(C14CanonicalEncoder& encoder,
                                const ArtifactObjectReferenceV1& object) {
  encoder.label(object.object_id);
  encoder.digest(object.object_digest);
}

void c14_encode_role_key(C14CanonicalEncoder& encoder,
                         const MetricRoleKeyV1& key) {
  encoder.string(key.clause_id.metric_id);
  encoder.u64(static_cast<std::uint64_t>(key.clause_id.authored_index));
  encoder.enumeration(key.role);
}

void c14_encode_reference_core(C14CanonicalEncoder& encoder,
                               const RealizedReferenceCoreV1& core) {
  encoder.sequence(core.ordered_targets,
                   [](C14CanonicalEncoder& out, const QueueId& target) {
                     out.strong_id(target);
                   });
  encoder.enumeration(core.target_scope);
  encoder.enumeration(core.result_scope);
  encoder.enumeration(core.evidence_scope);
  encoder.sequence(
      core.role_relations,
      [](C14CanonicalEncoder& out, const RealizedRoleRelationV1& relation) {
        out.enumeration(relation.relation);
        c14_encode_role_key(out, relation.key);
        c14_encode_artifact_object(out, relation.referenced_object);
      });
  encoder.sequence(
      core.internal_relations,
      [](C14CanonicalEncoder& out,
         const RealizedInternalReferenceV1& relation) {
        out.enumeration(relation.relation);
        out.enumeration(relation.purpose);
        c14_encode_artifact_object(out, relation.referenced_object);
      });
}

void c14_encode_realized_reference(C14CanonicalEncoder& encoder,
                                   const RealizedReferenceV1& reference) {
  encoder.u32(static_cast<std::uint32_t>(reference.index()));
  c14_encode_reference_core(encoder, realized_reference_core_v1(reference));
  std::visit(
      [&encoder, &reference](const auto& typed) {
        using Reference = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Reference,
                                     DeployedResponseReferenceV1>) {
          encoder.u32(
              static_cast<std::uint32_t>(typed.selected_product.index()));
          std::visit(
              [&encoder](const auto& product) {
                c14_encode_artifact_object(encoder, product.identity);
                using Product = std::decay_t<decltype(product)>;
                if constexpr (std::is_same_v<Product,
                                             RawResponseProductRef>) {
                  encoder.enumeration(product.value_form);
                }
              },
              typed.selected_product);
        } else if constexpr (std::is_same_v<Reference,
                                            DeployedPayloadReferenceV1>) {
          c14_encode_artifact_object(encoder, typed.payload.identity);
        } else if constexpr (
            std::is_same_v<Reference, RawResponseProductReferenceV1>) {
          c14_encode_artifact_object(encoder, typed.product.identity);
          encoder.enumeration(typed.product.value_form);
        } else {
          c14_encode_artifact_object(encoder,
                                     realized_reference_subject_v1(reference));
        }
      },
      reference);
}

[[nodiscard]] const MetricSupportClauseV1* c14_find_clause(
    const MetricSupportManifest& manifest, const MetricClauseIdV1& id) {
  const auto clauses = manifest.clauses();
  const auto found = std::lower_bound(
      clauses.begin(), clauses.end(), id,
      [](const MetricSupportClauseV1& clause, const MetricClauseIdV1& key) {
        return clause.clause_id < key;
      });
  return found != clauses.end() && found->clause_id == id ? &*found : nullptr;
}

[[nodiscard]] const MetricSupportRoleRequirementV1* c14_find_role_requirement(
    const MetricSupportClauseV1& clause, const MetricSupportRoleV1 role) {
  const auto found = std::lower_bound(
      clause.required_roles.begin(), clause.required_roles.end(), role,
      [](const MetricSupportRoleRequirementV1& requirement,
         const MetricSupportRoleV1 key) {
        return metric_support_role_rank_v1(requirement.role) <
               metric_support_role_rank_v1(key);
      });
  return found != clause.required_roles.end() && found->role == role ? &*found
                                                                    : nullptr;
}

[[nodiscard]] const RealizedMetricBindingV1* c14_find_binding(
    const std::vector<RealizedMetricBindingV1>& bindings,
    const MetricRoleKeyV1& key) {
  const auto found = std::lower_bound(
      bindings.begin(), bindings.end(), key,
      [](const RealizedMetricBindingV1& binding, const MetricRoleKeyV1& value) {
        return binding.key < value;
      });
  return found != bindings.end() && found->key == key ? &*found : nullptr;
}

[[nodiscard]] Result<std::vector<QueueId>> c14_targets_for_scope(
    const MetricSupportClauseV1& clause,
    const RealizedBindingTargetContextV1& targets,
    const MetricTargetScopeV1 scope) {
  switch (scope) {
    case MetricTargetScopeV1::payload_targets:
      return Result<std::vector<QueueId>>::success(targets.payload_targets);
    case MetricTargetScopeV1::deployed_singleton_target:
      if (!targets.deployed_singleton_target.has_value()) {
        return c14_manifest_failure<std::vector<QueueId>>(
            "metric_binding_deployed_target_missing",
            "binding validation has no frozen deployed singleton target");
      }
      if (clause.ordered_targets.size() != 1U ||
          clause.ordered_targets.front() !=
              *targets.deployed_singleton_target) {
        return c14_manifest_failure<std::vector<QueueId>>(
            "metric_binding_deployed_target_clause_mismatch",
            "frozen deployed singleton differs from the clause's exact "
            "ordered target");
      }
      return Result<std::vector<QueueId>>::success(
          {*targets.deployed_singleton_target});
    case MetricTargetScopeV1::ordered_metric_targets:
    case MetricTargetScopeV1::exact_request_targets:
      return Result<std::vector<QueueId>>::success(clause.ordered_targets);
    case MetricTargetScopeV1::ordered_construction_targets:
      return Result<std::vector<QueueId>>::success(
          targets.construction_targets);
  }
  return c14_manifest_failure<std::vector<QueueId>>(
      "metric_binding_target_scope_invalid",
      "binding contains an invalid target-scope discriminant");
}

[[nodiscard]] bool c14_raw_reference_form_valid(
    const RealizedReferenceV1& reference) {
  if (const auto* raw =
          std::get_if<RawResponseProductReferenceV1>(&reference)) {
    return c14_enum_rank_below(raw->product.value_form, 2U);
  }
  if (const auto* deployed =
          std::get_if<DeployedResponseReferenceV1>(&reference)) {
    if (const auto* raw =
            std::get_if<RawResponseProductRef>(&deployed->selected_product)) {
      return c14_enum_rank_below(raw->value_form, 2U);
    }
  }
  return true;
}

[[nodiscard]] Result<void> c14_validate_deployed_response(
    const RealizedMetricBindingV1& binding,
    const MetricSupportRoleRequirementV1& requirement,
    const RealizedBindingValidationContextV1& context,
    const std::vector<RealizedMetricBindingV1>& bindings) {
  const auto* deployed =
      std::get_if<DeployedResponseReferenceV1>(&binding.reference);
  if (deployed == nullptr ||
      !is_point_valued_deployed_response_product_v1(
          deployed->selected_product)) {
    return c14_manifest_failure<void>(
        "metric_binding_interval_raw_not_deployable",
        "deployed response is not a point-valued raw, nominal, or recoded "
        "product");
  }

  MetricSupportRoleV1 selected_role = MetricSupportRoleV1::raw_response;
  PointDeploymentPolicyV1 expected_policy =
      PointDeploymentPolicyV1::deploy_raw_point;
  switch (deployed->selected_product.index()) {
    case 0U:
      selected_role = MetricSupportRoleV1::raw_response;
      expected_policy = PointDeploymentPolicyV1::deploy_raw_point;
      break;
    case 1U:
      selected_role = MetricSupportRoleV1::nominal_response;
      expected_policy = PointDeploymentPolicyV1::deploy_nominal_point;
      break;
    case 2U:
      selected_role = MetricSupportRoleV1::recoded_response;
      expected_policy = PointDeploymentPolicyV1::deploy_recoded_point;
      break;
    default:
      return c14_manifest_failure<void>(
          "metric_binding_reference_type_mismatch",
          "deployed response has an invalid product alternative");
  }
  if (context.policies.point_deployment != expected_policy ||
      !c14_has_role_relation(requirement,
                             MetricRoleRelationKindV1::subject,
                             selected_role)) {
    return c14_manifest_failure<void>(
        "metric_binding_deployment_policy_mismatch",
        "deployed product differs from the frozen point-deployment policy or "
        "structural source role");
  }
  const MetricRoleKeyV1 source_key{binding.key.clause_id, selected_role};
  const auto* source = c14_find_binding(bindings, source_key);
  if (source == nullptr ||
      realized_reference_subject_v1(source->reference) !=
          deployed_response_product_subject_v1(deployed->selected_product)) {
    return c14_manifest_failure<void>(
        "metric_binding_deployed_product_identity_mismatch",
        "deployed response does not reuse the selected ledger product "
        "identity");
  }
  if (const auto* selected_raw =
          std::get_if<RawResponseProductRef>(&deployed->selected_product)) {
    const auto* source_raw =
        std::get_if<RawResponseProductReferenceV1>(&source->reference);
    if (source_raw == nullptr || source_raw->product != *selected_raw) {
      return c14_manifest_failure<void>(
          "metric_binding_deployed_product_identity_mismatch",
          "deployed raw response must reuse the complete raw product record, "
          "including its exact point/interval status");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> c14_validate_binding_relations(
    const RealizedMetricBindingV1& binding,
    const MetricSupportRoleRequirementV1& requirement,
    const std::vector<RealizedMetricBindingV1>& bindings) {
  const auto& core = realized_reference_core_v1(binding.reference);
  if (core.role_relations.size() != requirement.role_relations.size() ||
      core.internal_relations.size() != requirement.internal_relations.size()) {
    return c14_manifest_failure<void>(
        "metric_binding_relation_set_mismatch",
        "realized role does not contain exactly its frozen structural "
        "relation set");
  }
  for (std::size_t index = 0U; index < core.role_relations.size(); ++index) {
    const auto& actual = core.role_relations[index];
    const auto& expected = requirement.role_relations[index];
    const MetricRoleKeyV1 expected_key{binding.key.clause_id,
                                       expected.other_role};
    if (actual.relation != expected.relation || actual.key != expected_key) {
      return c14_manifest_failure<void>(
          "metric_binding_role_relation_mismatch",
          "realized role relation differs from its frozen same-clause role "
          "edge");
    }
    const auto* parent = c14_find_binding(bindings, expected_key);
    if (parent == nullptr ||
        actual.referenced_object !=
            realized_reference_subject_v1(parent->reference)) {
      return c14_manifest_failure<void>(
          "metric_binding_related_object_identity_mismatch",
          "realized role edge does not name the subject identity of its role "
          "binding");
    }
  }
  for (std::size_t index = 0U; index < core.internal_relations.size();
       ++index) {
    const auto& actual = core.internal_relations[index];
    const auto& expected = requirement.internal_relations[index];
    if (actual.relation != expected.relation ||
        actual.purpose != expected.purpose) {
      return c14_manifest_failure<void>(
          "metric_binding_internal_relation_mismatch",
          "realized internal relation differs from its frozen typed purpose");
    }
  }
  const auto find_internal = [](const RealizedReferenceCoreV1& value,
                                const InternalReferencePurposeV1 purpose)
      -> const ArtifactObjectReferenceV1* {
    const auto found = std::find_if(
        value.internal_relations.begin(), value.internal_relations.end(),
        [purpose](const RealizedInternalReferenceV1& relation) {
          return relation.purpose == purpose;
        });
    return found == value.internal_relations.end() ? nullptr
                                                   : &found->referenced_object;
  };
  const auto require_same_internal = [&](const RealizedReferenceCoreV1& other,
                                         const InternalReferencePurposeV1 first,
                                         const InternalReferencePurposeV1 second)
      -> Result<void> {
    const auto* left = find_internal(core, first);
    const auto* right = find_internal(other, second);
    if (left == nullptr || right == nullptr || *left != *right) {
      return c14_manifest_failure<void>(
          "metric_binding_cross_role_identity_mismatch",
          "related realized roles do not name the same exact internal "
          "artifact object required by the v1 role table");
    }
    return Result<void>::success();
  };
  const auto require_same_if_source_names = [&]
      (const RealizedReferenceCoreV1& other,
       const InternalReferencePurposeV1 source_purpose,
       const InternalReferencePurposeV1 evidence_purpose) -> Result<void> {
    if (find_internal(core, source_purpose) == nullptr) {
      return Result<void>::success();
    }
    return require_same_internal(other, source_purpose, evidence_purpose);
  };

  for (const auto& relation : core.role_relations) {
    if (relation.relation != MetricRoleRelationKindV1::evidence) {
      continue;
    }
    const auto* evidence_binding = c14_find_binding(bindings, relation.key);
    if (evidence_binding == nullptr) {
      continue;
    }
    const auto& evidence_core =
        realized_reference_core_v1(evidence_binding->reference);
    Result<void> cross_check = Result<void>::success();
    switch (relation.key.role) {
      case MetricSupportRoleV1::raw_response_bound_evidence:
        if (binding.key.role == MetricSupportRoleV1::raw_response) {
          cross_check = require_same_internal(
              evidence_core, InternalReferencePurposeV1::coefficient_origin,
              InternalReferencePurposeV1::coefficient_origin);
        }
        break;
      case MetricSupportRoleV1::response_order_evidence:
        if (binding.key.role == MetricSupportRoleV1::response_envelope) {
          cross_check = require_same_internal(
              evidence_core,
              InternalReferencePurposeV1::lower_response_product,
              InternalReferencePurposeV1::lower_response_product);
          if (cross_check) {
            cross_check = require_same_internal(
                evidence_core,
                InternalReferencePurposeV1::upper_response_product,
                InternalReferencePurposeV1::upper_response_product);
          }
        }
        break;
      case MetricSupportRoleV1::stability_certificate: {
        const auto* named = find_internal(
            evidence_core, InternalReferencePurposeV1::deployed_law);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "stability certificate does not name the exact deployed law");
        } else {
          cross_check = require_same_if_source_names(
              evidence_core,
              InternalReferencePurposeV1::configured_arrival_binding,
              InternalReferencePurposeV1::configured_arrival_binding);
          if (cross_check) {
            cross_check = require_same_if_source_names(
                evidence_core, InternalReferencePurposeV1::selection_binding,
                InternalReferencePurposeV1::selection_binding);
          }
        }
        break;
      }
      case MetricSupportRoleV1::reported_validity_or_lift_evidence: {
        const auto* named = find_internal(
            evidence_core, InternalReferencePurposeV1::law_or_result);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "validity/lift evidence does not name the exact law or decoder");
        } else {
          cross_check = require_same_if_source_names(
              evidence_core,
              InternalReferencePurposeV1::configured_arrival_binding,
              InternalReferencePurposeV1::configured_arrival_binding);
          if (cross_check) {
            cross_check = require_same_if_source_names(
                evidence_core, InternalReferencePurposeV1::selection_binding,
                InternalReferencePurposeV1::selection_binding);
          }
          if (cross_check) {
            cross_check = require_same_if_source_names(
                evidence_core, InternalReferencePurposeV1::mark_codec,
                InternalReferencePurposeV1::mark_codec);
          }
          if (cross_check) {
            cross_check = require_same_if_source_names(
                evidence_core, InternalReferencePurposeV1::validity_basis,
                InternalReferencePurposeV1::validity_basis);
          }
        }
        break;
      }
      case MetricSupportRoleV1::physical_transfer_evidence: {
        const auto* named = find_internal(
            evidence_core, InternalReferencePurposeV1::surrogate_source);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "physical-transfer evidence does not name the exact "
              "surrogate-side source");
        }
        break;
      }
      case MetricSupportRoleV1::optimizer_evidence: {
        const auto* named = find_internal(
            evidence_core,
            InternalReferencePurposeV1::certified_product_or_envelope);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "optimizer evidence does not name the exact certified product");
        }
        break;
      }
      case MetricSupportRoleV1::statistical_evidence: {
        const auto* named =
            find_internal(evidence_core, InternalReferencePurposeV1::estimand);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "statistical evidence does not name the exact estimand/product");
        } else if (evidence_core.evidence_scope != core.evidence_scope) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_evidence_scope_mismatch",
              "statistical evidence scope differs from its exact source "
              "product scope");
        }
        break;
      }
      case MetricSupportRoleV1::numerical_evidence: {
        const auto* named = find_internal(
            evidence_core, InternalReferencePurposeV1::law_or_result);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "numerical evidence does not name the exact law or result");
        }
        break;
      }
      case MetricSupportRoleV1::calibration_evidence: {
        const auto* named = find_internal(
            evidence_core, InternalReferencePurposeV1::calibration_source);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "calibration evidence does not name the exact source product");
        } else if (evidence_core.evidence_scope != core.evidence_scope) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_evidence_scope_mismatch",
              "calibration evidence scope differs from its exact source "
              "product scope");
        }
        break;
      }
      case MetricSupportRoleV1::compression_evidence: {
        const auto* named = find_internal(
            evidence_core,
            InternalReferencePurposeV1::compression_destination);
        if (named == nullptr ||
            *named != realized_reference_subject_v1(binding.reference)) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_cross_role_identity_mismatch",
              "compression evidence does not name the exact destination "
              "product");
        } else if (evidence_core.evidence_scope != core.evidence_scope) {
          cross_check = c14_manifest_failure<void>(
              "metric_binding_evidence_scope_mismatch",
              "compression evidence scope differs from its exact "
              "destination product scope");
        }
        break;
      }
      default:
        break;
    }
    if (!cross_check) {
      return cross_check;
    }
  }

  if (binding.key.role ==
      MetricSupportRoleV1::raw_response_bound_evidence) {
    const auto subject = std::find_if(
        core.role_relations.begin(), core.role_relations.end(),
        [](const RealizedRoleRelationV1& relation) {
          return relation.relation == MetricRoleRelationKindV1::subject &&
                 relation.key.role == MetricSupportRoleV1::raw_response;
        });
    const auto* raw_binding =
        subject == core.role_relations.end()
            ? nullptr
            : c14_find_binding(bindings, subject->key);
    const auto* raw_origin =
        raw_binding == nullptr
            ? nullptr
            : find_internal(realized_reference_core_v1(raw_binding->reference),
                            InternalReferencePurposeV1::coefficient_origin);
    const auto* bound_origin = find_internal(
        core, InternalReferencePurposeV1::coefficient_origin);
    if (raw_origin == nullptr || bound_origin == nullptr ||
        *raw_origin != *bound_origin) {
      return c14_manifest_failure<void>(
          "metric_binding_cross_role_identity_mismatch",
          "raw-bound evidence does not name the exact coefficient origin of "
          "its subject raw response");
    }
  }

  if (binding.key.role ==
      MetricSupportRoleV1::reported_validity_or_lift_evidence) {
    const MetricRoleKeyV1 payload_key{
        binding.key.clause_id, MetricSupportRoleV1::deployed_payload};
    const auto* payload_binding = c14_find_binding(bindings, payload_key);
    const auto* named_payload = find_internal(
        core, InternalReferencePurposeV1::artifact_payload);
    if (payload_binding == nullptr || named_payload == nullptr ||
        *named_payload !=
            realized_reference_subject_v1(payload_binding->reference)) {
      return c14_manifest_failure<void>(
          "metric_binding_cross_role_identity_mismatch",
          "validity/lift evidence does not name the exact clause payload");
    }
  }

  if (binding.key.role == MetricSupportRoleV1::compression_evidence) {
    const ArtifactObjectReferenceV1* source = nullptr;
    const ArtifactObjectReferenceV1* destination = nullptr;
    for (const auto& relation : core.internal_relations) {
      if (relation.purpose ==
          InternalReferencePurposeV1::compression_source) {
        source = &relation.referenced_object;
      } else if (relation.purpose ==
                 InternalReferencePurposeV1::compression_destination) {
        destination = &relation.referenced_object;
      }
    }
    if (source != nullptr && destination != nullptr && *source == *destination) {
      return c14_manifest_failure<void>(
          "metric_binding_compression_endpoints_identical",
          "compression evidence must name distinct typed source and "
          "destination objects");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> c14_validate_lineage_acyclic(
    const std::vector<RealizedMetricBindingV1>& bindings) {
  std::vector<std::vector<std::size_t>> adjacency(bindings.size());
  for (std::size_t index = 0U; index < bindings.size(); ++index) {
    const auto& core =
        realized_reference_core_v1(bindings[index].reference);
    for (const auto& relation : core.role_relations) {
      if (relation.relation != MetricRoleRelationKindV1::lineage_parent) {
        continue;
      }
      const auto* parent = c14_find_binding(bindings, relation.key);
      if (parent == nullptr) {
        return c14_manifest_failure<void>(
            "metric_binding_lineage_parent_missing",
            "lineage relation names a missing role binding");
      }
      adjacency[index].push_back(
          static_cast<std::size_t>(parent - bindings.data()));
    }
    const auto& subject =
        realized_reference_subject_v1(bindings[index].reference);
    for (const auto& relation : core.internal_relations) {
      if (relation.relation != MetricRoleRelationKindV1::lineage_parent) {
        continue;
      }
      if (relation.referenced_object == subject) {
        return c14_manifest_failure<void>(
            "metric_binding_lineage_cycle",
            "an internal lineage parent points to its own realized subject");
      }
      for (std::size_t candidate = 0U; candidate < bindings.size();
           ++candidate) {
        if (relation.referenced_object ==
            realized_reference_subject_v1(bindings[candidate].reference)) {
          adjacency[index].push_back(candidate);
        }
      }
    }
  }
  std::vector<std::uint8_t> color(bindings.size(), 0U);
  const auto visit = [&](const auto& self, const std::size_t node) -> bool {
    if (color[node] == 1U) {
      return false;
    }
    if (color[node] == 2U) {
      return true;
    }
    color[node] = 1U;
    for (const std::size_t parent : adjacency[node]) {
      if (!self(self, parent)) {
        return false;
      }
    }
    color[node] = 2U;
    return true;
  };
  for (std::size_t node = 0U; node < bindings.size(); ++node) {
    if (!visit(visit, node)) {
      return c14_manifest_failure<void>(
          "metric_binding_lineage_cycle",
          "realized role lineage-parent graph contains a cycle");
    }
  }
  return Result<void>::success();
}

}  // namespace

Result<RealizedMetricBindingsV1> validate_realized_metric_bindings_v1(
    const MetricSupportManifest& manifest,
    const RealizedBindingValidationContextV1& context,
    std::vector<RealizedMetricBindingV1> bindings) {
  if (bindings.empty()) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        "metric_bindings_empty",
        "realized metric bindings must be nonempty");
  }
  if (!c14_enum_rank_below(context.policies.point_deployment, 4U) ||
      !c14_enum_rank_below(context.policies.coefficient_completion, 4U) ||
      !c14_enum_rank_below(context.policies.projection, 3U) ||
      !c14_enum_rank_below(context.policies.recoding, 3U) ||
      !c14_enum_rank_below(context.policies.evidence_roles, 2U) ||
      context.targets.payload_targets.empty() ||
      c14_has_duplicates(context.targets.payload_targets) ||
      c14_has_duplicates(context.targets.construction_targets)) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        "metric_binding_validation_context_invalid",
        "realized binding target or policy context is malformed");
  }
  if (context.targets.deployed_singleton_target.has_value() &&
      std::find(context.targets.payload_targets.begin(),
                context.targets.payload_targets.end(),
                *context.targets.deployed_singleton_target) ==
          context.targets.payload_targets.end()) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        "metric_binding_deployed_target_payload_mismatch",
        "frozen deployed singleton is absent from the payload target vector");
  }

  for (auto& binding : bindings) {
    auto& core = c14_mutable_reference_core(binding.reference);
    std::sort(core.role_relations.begin(), core.role_relations.end());
    if (std::adjacent_find(core.role_relations.begin(),
                           core.role_relations.end()) !=
        core.role_relations.end()) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_role_relation_duplicate",
          "realized role contains a duplicate role edge");
    }
    std::sort(core.internal_relations.begin(), core.internal_relations.end());
    if (std::adjacent_find(core.internal_relations.begin(),
                           core.internal_relations.end()) !=
        core.internal_relations.end()) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_internal_relation_duplicate",
          "realized role contains a duplicate internal edge");
    }
  }
  std::sort(bindings.begin(), bindings.end(),
            [](const RealizedMetricBindingV1& left,
               const RealizedMetricBindingV1& right) {
              return left.key < right.key;
            });
  if (std::adjacent_find(bindings.begin(), bindings.end(),
                         [](const auto& left, const auto& right) {
                           return left.key == right.key;
                         }) != bindings.end()) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        "metric_binding_key_duplicate",
        "realized bindings repeat a clause-role key");
  }

  std::vector<MetricRoleKeyV1> expected_keys;
  for (const auto& clause : manifest.clauses()) {
    for (const auto& role : clause.required_roles) {
      expected_keys.push_back(MetricRoleKeyV1{clause.clause_id, role.role});
    }
  }
  if (bindings.size() != expected_keys.size()) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        bindings.size() < expected_keys.size() ? "metric_binding_key_missing"
                                               : "metric_binding_key_extra",
        "realized binding key set does not equal the manifest role key set");
  }
  for (std::size_t index = 0U; index < bindings.size(); ++index) {
    if (bindings[index].key != expected_keys[index]) {
      const bool key_expected = std::binary_search(
          expected_keys.begin(), expected_keys.end(), bindings[index].key);
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          key_expected ? "metric_binding_key_missing"
                       : "metric_binding_key_extra",
          "realized binding key set differs from the manifest role key set");
    }
  }

  const auto manifest_has_role = [&](const MetricSupportRoleV1 role) {
    return std::any_of(expected_keys.begin(), expected_keys.end(),
                       [role](const MetricRoleKeyV1& key) {
                         return key.role == role;
                       });
  };
  const bool has_deployed_response =
      manifest_has_role(MetricSupportRoleV1::deployed_response);
  const bool has_raw_response =
      manifest_has_role(MetricSupportRoleV1::raw_response);
  const bool has_nominal_response =
      manifest_has_role(MetricSupportRoleV1::nominal_response);
  const bool has_projection_role =
      manifest_has_role(MetricSupportRoleV1::projection_center) ||
      manifest_has_role(MetricSupportRoleV1::projected_mean);
  const bool has_recoded_response =
      manifest_has_role(MetricSupportRoleV1::recoded_response);
  if (has_deployed_response !=
          (context.policies.point_deployment !=
           PointDeploymentPolicyV1::not_applicable) ||
      has_projection_role !=
          (context.policies.projection != ProjectionPolicyV1::not_applicable) ||
      has_recoded_response !=
          (context.policies.recoding != RecodingPolicyV1::not_applicable)) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        "metric_binding_policy_applicability_mismatch",
        "point-deployment, projection, or recoding policy applicability "
        "does not exactly match the manifest roles");
  }
  switch (context.policies.coefficient_completion) {
    case CoefficientCompletionPolicyV1::not_applicable:
      if (has_nominal_response) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_policy_applicability_mismatch",
            "nominal_response cannot use a not-applicable completion policy");
      }
      break;
    case CoefficientCompletionPolicyV1::require_complete_raw_points:
      if (!has_raw_response || has_nominal_response) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_policy_applicability_mismatch",
            "complete-raw policy requires raw_response and forbids a nominal "
            "completion role");
      }
      break;
    case CoefficientCompletionPolicyV1::declared_nominal_completion:
    case CoefficientCompletionPolicyV1::authorized_endpoint_completion:
      if (!has_nominal_response) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_policy_applicability_mismatch",
            "an applicable nominal-completion policy requires a nominal "
            "response role");
      }
      break;
  }

  const bool any_evidence_role = std::any_of(
      expected_keys.begin(), expected_keys.end(), [](const auto& key) {
        return metric_support_role_rank_v1(key.role) >=
               metric_support_role_rank_v1(
                   MetricSupportRoleV1::raw_response_bound_evidence);
      });
  const bool exact_evidence_policy =
      context.policies.evidence_roles ==
      EvidenceRolePolicyV1::exact_manifest_roles;
  if (any_evidence_role != exact_evidence_policy) {
    return c14_manifest_failure<RealizedMetricBindingsV1>(
        "metric_binding_evidence_policy_mismatch",
        "the frozen evidence policy must be exact_manifest_roles exactly "
        "when the manifest contains evidence-role tags");
  }

  const ArtifactObjectReferenceV1* sole_payload = nullptr;
  for (const auto& binding : bindings) {
    if (binding.key.role != MetricSupportRoleV1::deployed_payload) {
      continue;
    }
    const auto& subject = realized_reference_subject_v1(binding.reference);
    if (sole_payload == nullptr) {
      sole_payload = &subject;
    } else if (*sole_payload != subject) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_deployed_payload_identity_mismatch",
          "all clause-local deployed_payload roles must name the artifact's "
          "one validated payload identity and digest");
    }
  }

  for (const auto& binding : bindings) {
    const auto* clause = c14_find_clause(manifest, binding.key.clause_id);
    const auto* requirement =
        clause == nullptr
            ? nullptr
            : c14_find_role_requirement(*clause, binding.key.role);
    const auto* schema = metric_support_role_schema_v1(binding.key.role);
    if (clause == nullptr || requirement == nullptr || schema == nullptr) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_key_extra",
          "realized binding key is absent from the manifest");
    }
    if (realized_reference_role_v1(binding.reference) != binding.key.role ||
        realized_reference_alternative_v1(binding.reference) !=
            schema->reference_alternative ||
        !c14_raw_reference_form_valid(binding.reference)) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_reference_type_mismatch",
          "realized reference alternative does not match its closed role");
    }
    const auto& core = realized_reference_core_v1(binding.reference);
    auto expected_targets =
        c14_targets_for_scope(*clause, context.targets,
                              requirement->target_scope);
    if (!expected_targets) {
      return Result<RealizedMetricBindingsV1>::failure(
          expected_targets.error());
    }
    if (core.ordered_targets != expected_targets.value()) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_target_scope_mismatch",
          "realized reference target order or cardinality differs from its "
          "frozen target scope");
    }
    if (core.target_scope != requirement->target_scope ||
        core.result_scope != requirement->result_scope ||
        core.evidence_scope != requirement->evidence_scope) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_scope_mismatch",
          "realized reference target, result, or evidence scope differs from "
          "the structural manifest");
    }
    auto relations = c14_validate_binding_relations(
        binding, *requirement, bindings);
    if (!relations) {
      return Result<RealizedMetricBindingsV1>::failure(relations.error());
    }
    if (binding.key.role == MetricSupportRoleV1::deployed_response) {
      auto deployed = c14_validate_deployed_response(
          binding, *requirement, context, bindings);
      if (!deployed) {
        return Result<RealizedMetricBindingsV1>::failure(deployed.error());
      }
    }
    if (binding.key.role == MetricSupportRoleV1::nominal_response) {
      const bool raw_parent = c14_has_role_relation(
          *requirement, MetricRoleRelationKindV1::lineage_parent,
          MetricSupportRoleV1::raw_response);
      const bool completion_parent = c14_has_internal_relation(
          *requirement, MetricRoleRelationKindV1::lineage_parent,
          InternalReferencePurposeV1::completion_source);
      const bool valid_completion =
          (context.policies.coefficient_completion ==
               CoefficientCompletionPolicyV1::declared_nominal_completion &&
           raw_parent && !completion_parent) ||
          (context.policies.coefficient_completion ==
               CoefficientCompletionPolicyV1::authorized_endpoint_completion &&
           completion_parent && !raw_parent);
      if (!valid_completion) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_completion_policy_mismatch",
            "nominal response derivation does not match the frozen "
            "coefficient-completion policy");
      }
    }
    if (binding.key.role == MetricSupportRoleV1::projected_mean &&
        context.policies.projection == ProjectionPolicyV1::not_applicable) {
      return c14_manifest_failure<RealizedMetricBindingsV1>(
          "metric_binding_projection_policy_mismatch",
          "projected mean requires an applicable frozen projection policy");
    }
    if (binding.key.role == MetricSupportRoleV1::recoded_response) {
      if (context.policies.recoding == RecodingPolicyV1::not_applicable) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_recoding_policy_mismatch",
            "recoded response requires an applicable frozen recoding policy");
      }
      if (context.policies.recoding == RecodingPolicyV1::mean_inversion) {
        const bool projected_parent = c14_has_role_relation(
            *requirement, MetricRoleRelationKindV1::lineage_parent,
            MetricSupportRoleV1::projected_mean);
        const bool raw_parent = c14_has_role_relation(
            *requirement, MetricRoleRelationKindV1::lineage_parent,
            MetricSupportRoleV1::raw_response);
        const bool nominal_parent = c14_has_role_relation(
            *requirement, MetricRoleRelationKindV1::lineage_parent,
            MetricSupportRoleV1::nominal_response);
        const bool completion_parent = c14_has_internal_relation(
            *requirement, MetricRoleRelationKindV1::lineage_parent,
            InternalReferencePurposeV1::completion_source);
        const std::size_t interior_count =
            static_cast<std::size_t>(raw_parent) +
            static_cast<std::size_t>(nominal_parent);
        const bool interior_form = projected_parent && interior_count == 1U &&
                                   !completion_parent;
        const bool endpoint_form = !projected_parent && interior_count == 0U &&
                                   completion_parent;
        if (!interior_form && !endpoint_form) {
          return c14_manifest_failure<RealizedMetricBindingsV1>(
              "metric_binding_recoding_parent_mismatch",
              "mean-inversion recoding requires exactly projected mean plus "
              "one interior response, or exactly one authorized endpoint "
              "completion parent");
        }
      } else {
        const std::size_t parent_count = static_cast<std::size_t>(
            std::count_if(requirement->role_relations.begin(),
                          requirement->role_relations.end(),
                          [](const auto& relation) {
                            return relation.relation ==
                                   MetricRoleRelationKindV1::lineage_parent;
                          })) +
            static_cast<std::size_t>(std::count_if(
                requirement->internal_relations.begin(),
                requirement->internal_relations.end(),
                [](const auto& relation) {
                  return relation.relation ==
                         MetricRoleRelationKindV1::lineage_parent;
                }));
        if (parent_count != 1U) {
          return c14_manifest_failure<RealizedMetricBindingsV1>(
              "metric_binding_recoding_parent_mismatch",
              "identity recoding must name exactly one frozen source parent");
        }
      }
    }
    if (binding.key.role == MetricSupportRoleV1::raw_response) {
      const auto& raw =
          std::get<RawResponseProductReferenceV1>(binding.reference);
      if (context.policies.coefficient_completion ==
              CoefficientCompletionPolicyV1::require_complete_raw_points &&
          raw.product.value_form != ResponseProductValueFormV1::exact_point) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_complete_raw_point_missing",
            "require_complete_raw_points cannot be realized by an "
            "interval-only raw response product");
      }
      if (raw.product.value_form == ResponseProductValueFormV1::interval_only &&
          !c14_has_role_relation(
              *requirement, MetricRoleRelationKindV1::evidence,
              MetricSupportRoleV1::raw_response_bound_evidence)) {
        return c14_manifest_failure<RealizedMetricBindingsV1>(
            "metric_binding_interval_raw_bound_missing",
            "interval-only raw response lacks its exact raw-bound evidence "
            "role");
      }
    }
  }
  auto acyclic = c14_validate_lineage_acyclic(bindings);
  if (!acyclic) {
    return Result<RealizedMetricBindingsV1>::failure(acyclic.error());
  }
  return Result<RealizedMetricBindingsV1>::success(
      RealizedMetricBindingsV1(std::move(bindings)));
}

Result<std::vector<std::byte>> canonical_realized_metric_bindings_bytes_v1(
    const RealizedMetricBindingsV1& bindings) {
  C14CanonicalEncoder encoder;
  encoder.string("mwperf.realized_metric_bindings");
  encoder.u32(1U);
  encoder.u64(static_cast<std::uint64_t>(bindings.bindings().size()));
  for (const auto& binding : bindings.bindings()) {
    c14_encode_role_key(encoder, binding.key);
    c14_encode_realized_reference(encoder, binding.reference);
  }
  return Result<std::vector<std::byte>>::success(std::move(encoder).release());
}

Result<Digest256> digest_realized_metric_bindings_v1(
    const RealizedMetricBindingsV1& bindings) {
  auto bytes = canonical_realized_metric_bindings_bytes_v1(bindings);
  if (!bytes) {
    return Result<Digest256>::failure(bytes.error());
  }
  return sha256_domain_separated("mwperf.realized_metric_bindings.v1",
                                 bytes.value());
}

}  // namespace mwperf


namespace mwperf {

class MetricRequestAccess final {
 public:
  template <typename Request, typename Parameters>
  [[nodiscard]] static MetricRequest construct(
      MetricRequestHeader header, Parameters parameters) {
    return MetricRequest(
        Request(std::move(header), std::move(parameters)));
  }
};

namespace {

struct C14MetricWireInfo final {
  MetricKindV1 kind;
  std::string_view spelling;
  MetricTargetCouplingV1 coupling;
};

struct C14MetricSourceView final {
  const SourceNode* parameters;
  std::size_t authored_index;
};

[[nodiscard]] Diagnostic c14_metric_error(const SourceNode& source,
                                          std::string code,
                                          std::string message) {
  Diagnostic diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = source.location().authored_path,
      .json_pointer = std::string(source.json_pointer()),
      .notes = {},
  };
  diagnostic.notes.push_back("line " +
                             std::to_string(source.location().line) +
                             ", column " +
                             std::to_string(source.location().column));
  return diagnostic;
}

template <typename Value>
[[nodiscard]] Result<Value> c14_metric_failure(const SourceNode& source,
                                               std::string code,
                                               std::string message) {
  return Result<Value>::failure(c14_metric_error(
      source, std::move(code), std::move(message)));
}

[[nodiscard]] bool c14_contains(
    const std::initializer_list<std::string_view> values,
    const std::string_view candidate) noexcept {
  return std::find(values.begin(), values.end(), candidate) != values.end();
}

[[nodiscard]] Result<void> c14_exact_source_keys(
    const SourceNode& object,
    const std::initializer_list<std::string_view> allowed,
    const std::initializer_list<std::string_view> required) {
  if (object.kind() != SourceNodeKind::object) {
    return c14_metric_failure<void>(
        object, "metric_request_invalid_source_shape",
        "the retained metric source value must be an object");
  }

  const auto members = object.object_members();
  for (std::size_t index = 0U; index < members.size(); ++index) {
    if (!c14_contains(allowed, members[index].key)) {
      return c14_metric_failure<void>(
          members[index].value, "metric_request_unexpected_source_key",
          "unexpected retained metric key '" + members[index].key + "'");
    }
    for (std::size_t previous = 0U; previous < index; ++previous) {
      if (members[previous].key == members[index].key) {
        return c14_metric_failure<void>(
            members[index].value, "metric_request_duplicate_source_key",
            "duplicate retained metric key '" + members[index].key + "'");
      }
    }
  }
  for (const std::string_view key : required) {
    if (object.find(key) == nullptr) {
      return c14_metric_failure<void>(
          object, "metric_request_missing_source_key",
          "missing retained metric key '" + std::string(key) + "'");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::size_t> c14_authored_metric_index(
    const SourceNode& source) {
  constexpr std::string_view prefix{"/metrics/"};
  const std::string_view pointer = source.json_pointer();
  if (!pointer.starts_with(prefix)) {
    return c14_metric_failure<std::size_t>(
        source, "metric_request_invalid_authored_index",
        "the retained metric source pointer must have the form "
        "'/metrics/<canonical decimal index>'");
  }
  const std::string_view digits = pointer.substr(prefix.size());
  if (digits.empty() || (digits.size() > 1U && digits.front() == '0')) {
    return c14_metric_failure<std::size_t>(
        source, "metric_request_invalid_authored_index",
        "the retained metric source pointer has no canonical authored index");
  }

  std::size_t result = 0U;
  for (const char character : digits) {
    if (character < '0' || character > '9') {
      return c14_metric_failure<std::size_t>(
          source, "metric_request_invalid_authored_index",
          "the retained metric source pointer has no canonical authored "
          "index");
    }
    const std::size_t digit =
        static_cast<std::size_t>(character - '0');
    if (result > (std::numeric_limits<std::size_t>::max() - digit) / 10U) {
      return c14_metric_failure<std::size_t>(
          source, "metric_request_invalid_authored_index",
          "the authored metric index does not fit the platform index type");
    }
    result = result * 10U + digit;
  }
  return Result<std::size_t>::success(result);
}

[[nodiscard]] Result<C14MetricSourceView> c14_metric_source_view(
    const MetricNode& node, const C14MetricWireInfo& info) {
  const std::initializer_list<std::string_view> outer_keys{
      "id", "kind", "parameters"};
  Result<void> outer =
      c14_exact_source_keys(node.source, outer_keys, outer_keys);
  if (!outer) {
    return Result<C14MetricSourceView>::failure(outer.error());
  }

  const SourceNode& source_id = *node.source.find("id");
  const SourceNode& source_kind = *node.source.find("kind");
  const SourceNode& parameters = *node.source.find("parameters");
  if (source_id.kind() != SourceNodeKind::string ||
      source_kind.kind() != SourceNodeKind::string ||
      parameters.kind() != SourceNodeKind::object) {
    return c14_metric_failure<C14MetricSourceView>(
        node.source, "metric_request_invalid_source_shape",
        "the retained metric source must contain string id/kind fields and "
        "an object parameters field");
  }
  if (*source_id.string_value() != node.id ||
      *source_kind.string_value() != info.spelling) {
    return c14_metric_failure<C14MetricSourceView>(
        node.source, "metric_request_source_identity_mismatch",
        "the typed metric identity does not match its retained source node");
  }
  Result<std::size_t> authored_index = c14_authored_metric_index(node.source);
  if (!authored_index) {
    return Result<C14MetricSourceView>::failure(authored_index.error());
  }
  return Result<C14MetricSourceView>::success(
      C14MetricSourceView{&parameters, authored_index.value()});
}

template <typename Value>
[[nodiscard]] bool c14_duplicate_free(const std::vector<Value>& values) {
  for (std::size_t index = 0U; index < values.size(); ++index) {
    if (std::find(values.begin(), values.begin() +
                                      static_cast<std::ptrdiff_t>(index),
                  values[index]) !=
        values.begin() + static_cast<std::ptrdiff_t>(index)) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] BigInt c14_abs_int(BigInt value) {
  return value < 0 ? -value : value;
}

[[nodiscard]] BigInt c14_gcd(BigInt left, BigInt right) {
  left = c14_abs_int(std::move(left));
  right = c14_abs_int(std::move(right));
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  return left;
}

[[nodiscard]] bool c14_canonical_rational(
    const ExactRational& value) {
  return value.denominator() > 0 &&
         c14_gcd(value.numerator(), value.denominator()) == 1 &&
         (value.numerator() != 0 || value.denominator() == 1);
}

[[nodiscard]] bool c14_open_probability(const ExactRational& value) {
  return c14_canonical_rational(value) && value > ExactRational::zero() &&
         value < ExactRational::one();
}

[[nodiscard]] Result<TypedLabel> c14_label_from_source(
    const SourceNode& source) {
  if (source.kind() == SourceNodeKind::number) {
    return parse_typed_label(JsonValue::number(*source.number_lexeme()));
  }
  if (source.kind() == SourceNodeKind::string) {
    return parse_typed_label(JsonValue::string(*source.string_value()));
  }
  return c14_metric_failure<TypedLabel>(
      source, "metric_request_target_source_mismatch",
      "an analysis target source value must be a typed label");
}

[[nodiscard]] Result<std::vector<ResolvedMetricTargetV1>>
c14_resolve_metric_targets(const MetricNode& node,
                           const QueueCatalog& queue_catalog,
                           const MetricTargetCouplingV1 coupling) {
  const TargetSet& target_set = node.context->targets;
  if (target_set.source.kind() != SourceNodeKind::array ||
      target_set.source.array_items().size() != target_set.queue_ids.size()) {
    return c14_metric_failure<std::vector<ResolvedMetricTargetV1>>(
        target_set.source, "metric_request_target_source_mismatch",
        "the contextual target values do not match their retained source "
        "array");
  }
  if (target_set.queue_ids.empty()) {
    return c14_metric_failure<std::vector<ResolvedMetricTargetV1>>(
        target_set.source, "metric_request_target_cardinality",
        "a metric request must retain at least one target");
  }
  if (coupling == MetricTargetCouplingV1::scalar_singleton &&
      target_set.queue_ids.size() != 1U) {
    return c14_metric_failure<std::vector<ResolvedMetricTargetV1>>(
        target_set.source, "metric_request_target_cardinality",
        "a scalar metric requires exactly one analysis target");
  }
  if (coupling == MetricTargetCouplingV1::common_schedule_coupled &&
      target_set.queue_ids.size() < 2U) {
    return c14_metric_failure<std::vector<ResolvedMetricTargetV1>>(
        target_set.source, "metric_request_target_cardinality",
        "a coupled metric requires at least two analysis targets");
  }

  std::vector<ResolvedMetricTargetV1> resolved;
  resolved.reserve(target_set.queue_ids.size());
  const auto target_sources = target_set.source.array_items();
  for (std::size_t index = 0U; index < target_set.queue_ids.size(); ++index) {
    for (std::size_t previous = 0U; previous < index; ++previous) {
      if (target_set.queue_ids[index] == target_set.queue_ids[previous]) {
        return c14_metric_failure<std::vector<ResolvedMetricTargetV1>>(
            target_sources[index], "metric_request_duplicate_target",
            "analysis targets must be duplicate-free under typed identity");
      }
    }

    Result<TypedLabel> source_label =
        c14_label_from_source(target_sources[index]);
    if (!source_label ||
        source_label.value() != target_set.queue_ids[index]) {
      return c14_metric_failure<std::vector<ResolvedMetricTargetV1>>(
          target_sources[index], "metric_request_target_source_mismatch",
          "the contextual target identity does not match its retained source "
          "item");
    }

    QueueId queue_id(target_set.queue_ids[index]);
    Result<DenseQueueIndex> dense = queue_catalog.resolve(
        queue_id, authored_provenance(target_sources[index]));
    if (!dense) {
      return Result<std::vector<ResolvedMetricTargetV1>>::failure(
          dense.error());
    }
    resolved.push_back(ResolvedMetricTargetV1{
        queue_catalog.queue_id(dense.value()), dense.value()});
  }
  return Result<std::vector<ResolvedMetricTargetV1>>::success(
      std::move(resolved));
}

[[nodiscard]] Result<MetricSelectionRegimeV1> c14_selection_regime(
    const MetricNode& node) {
  return std::visit(
      [&node](const auto& selection) -> Result<MetricSelectionRegimeV1> {
        using Selection = std::decay_t<decltype(selection)>;
        if constexpr (std::is_same_v<Selection, TransientSelection>) {
          if (selection.atoms.empty()) {
            return c14_metric_failure<MetricSelectionRegimeV1>(
                selection.source, "metric_request_invalid_selection",
                "a transient selection must contain at least one joint "
                "initial atom");
          }
          return Result<MetricSelectionRegimeV1>::success(
              MetricSelectionRegimeV1::transient);
        } else if constexpr (
            std::is_same_v<Selection, StationaryUniqueSelection>) {
          return Result<MetricSelectionRegimeV1>::success(
              MetricSelectionRegimeV1::stationary_unique);
        } else if constexpr (
            std::is_same_v<Selection, StationaryClassSelection>) {
          return Result<MetricSelectionRegimeV1>::success(
              MetricSelectionRegimeV1::stationary_class);
        } else if constexpr (
            std::is_same_v<Selection, StationaryMixtureSelection>) {
          if (selection.components.empty()) {
            return c14_metric_failure<MetricSelectionRegimeV1>(
                selection.source, "metric_request_invalid_selection",
                "a stationary mixture selection must contain at least one "
                "component");
          }
          return Result<MetricSelectionRegimeV1>::success(
              MetricSelectionRegimeV1::stationary_mixture);
        } else if constexpr (std::is_same_v<Selection,
                                            FixedPointSelection>) {
          return std::visit(
              [](const auto& fixed) -> Result<MetricSelectionRegimeV1> {
                using Fixed = std::decay_t<decltype(fixed)>;
                if constexpr (std::is_same_v<Fixed,
                                             FixedPointUniqueSelection>) {
                  return Result<MetricSelectionRegimeV1>::success(
                      MetricSelectionRegimeV1::fixed_point_unique);
                } else {
                  return Result<MetricSelectionRegimeV1>::success(
                      MetricSelectionRegimeV1::fixed_point_id);
                }
              },
              selection);
        } else {
          return c14_metric_failure<MetricSelectionRegimeV1>(
              node.source, "metric_request_invalid_selection",
              "the contextual selection alternative is not part of "
              "analysis-v1");
        }
      },
      node.context->selection);
}

[[nodiscard]] Result<MetricSolverRegimeV1> c14_solver_regime(
    const MetricNode& node) {
  return std::visit(
      [&node](const auto& solver) -> Result<MetricSolverRegimeV1> {
        using Solver = std::decay_t<decltype(solver)>;
        if constexpr (std::is_same_v<Solver, EnumeratedSolver>) {
          switch (solver.linear_method) {
            case LinearMethod::dense_pivoted:
            case LinearMethod::sparse_iterative:
              break;
            default:
              return c14_metric_failure<MetricSolverRegimeV1>(
                  solver.source, "metric_request_invalid_solver",
                  "the enumerated linear method is not part of analysis-v1");
          }
          if (solver.max_iterations.has_value() &&
              solver.max_iterations->is_zero()) {
            return c14_metric_failure<MetricSolverRegimeV1>(
                solver.source, "metric_request_invalid_solver",
                "an authored maximum iteration count must be positive");
          }
          return Result<MetricSolverRegimeV1>::success(
              MetricSolverRegimeV1::enumerated);
        } else if constexpr (std::is_same_v<Solver, AnalyticSolver>) {
          if (solver.precision_bits.is_zero() ||
              (solver.max_iterations.has_value() &&
               solver.max_iterations->is_zero())) {
            return c14_metric_failure<MetricSolverRegimeV1>(
                solver.source, "metric_request_invalid_solver",
                "analytic precision and every authored iteration grant must "
                "be positive");
          }
          return Result<MetricSolverRegimeV1>::success(
              MetricSolverRegimeV1::analytic);
        } else if constexpr (std::is_same_v<Solver, MonteCarloSolver>) {
          switch (solver.interval_method) {
            case MonteCarloIntervalMethod::exact_binomial:
            case MonteCarloIntervalMethod::hoeffding:
            case MonteCarloIntervalMethod::none:
              break;
            default:
              return c14_metric_failure<MetricSolverRegimeV1>(
                  solver.source, "metric_request_invalid_solver",
                  "the Monte Carlo interval method is not part of "
                  "analysis-v1");
          }
          if (solver.replications.is_zero() ||
              !c14_open_probability(solver.confidence_level) ||
              !node.context->resolution.sampling.max_generator_draws
                   .has_value() ||
              node.context->resolution.sampling.max_generator_draws
                  ->is_zero()) {
            return c14_metric_failure<MetricSolverRegimeV1>(
                solver.source, "metric_request_invalid_solver",
                "Monte Carlo requires positive replications, confidence in "
                "(0,1), and a positive generator-draw grant");
          }
          return Result<MetricSolverRegimeV1>::success(
              MetricSolverRegimeV1::monte_carlo);
        } else if constexpr (std::is_same_v<Solver, DirectSolver>) {
          return Result<MetricSolverRegimeV1>::success(
              MetricSolverRegimeV1::direct);
        } else {
          return c14_metric_failure<MetricSolverRegimeV1>(
              node.source, "metric_request_invalid_solver",
              "the contextual solver alternative is not part of "
              "analysis-v1");
        }
      },
      node.context->solver);
}

[[nodiscard]] bool c14_requires_transient_selection(
    const MetricKindV1 kind) noexcept {
  return kind == MetricKindV1::transient_backlog_law;
}

[[nodiscard]] bool c14_accepts_either_selection(
    const MetricKindV1 kind) noexcept {
  return kind == MetricKindV1::first_hit ||
         kind == MetricKindV1::threshold_excursion ||
         kind == MetricKindV1::ordered_schedule_sequence;
}

[[nodiscard]] Result<void> c14_validate_selection_for_metric(
    const MetricNode& node, const MetricKindV1 kind,
    const MetricSelectionRegimeV1 selection) {
  if (c14_accepts_either_selection(kind)) {
    return Result<void>::success();
  }
  const bool transient = selection == MetricSelectionRegimeV1::transient;
  if (c14_requires_transient_selection(kind) != transient) {
    return c14_metric_failure<void>(
        node.source, "metric_request_incompatible_selection",
        c14_requires_transient_selection(kind)
            ? "transient_backlog_law requires the analysis transient "
              "selection"
            : "this stationary, Palm, or steady-state metric requires a "
              "non-transient analysis selection");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> c14_validate_resolution_context(
    const MetricNode& node) {
  const ResolutionEnvelope& resolution = node.context->resolution;
  const auto positive_optional = [](const std::optional<BigNat>& value) {
    return !value.has_value() || !value->is_zero();
  };
  if (!positive_optional(resolution.level.max_states) ||
      !positive_optional(resolution.level.max_row_atoms) ||
      !positive_optional(resolution.phase.max_phase_states) ||
      !positive_optional(resolution.optimizer.max_calls) ||
      !positive_optional(
          resolution.optimizer.max_search_states_per_call) ||
      !positive_optional(resolution.sampling.max_generator_draws)) {
    return c14_metric_failure<void>(
        resolution.source, "metric_request_invalid_resolution",
        "every nonnull analysis resolution grant must be positive");
  }

  const auto nonnegative_tolerance = [](const auto& value) {
    return !value.has_value() ||
           (c14_canonical_rational(*value) && value->is_nonnegative());
  };
  if (!nonnegative_tolerance(resolution.tolerance.linear_residual_abs) ||
      !nonnegative_tolerance(resolution.tolerance.integration_abs) ||
      !nonnegative_tolerance(resolution.tolerance.tail_abs) ||
      !nonnegative_tolerance(resolution.tolerance.fixed_point_abs)) {
    return c14_metric_failure<void>(
        resolution.tolerance.source, "metric_request_invalid_resolution",
        "analysis tolerances must be canonical exact nonnegative values");
  }

  if (const auto* certified =
          std::get_if<CertifiedTruncationTailResolution>(&resolution.tail);
      certified != nullptr &&
      !c14_open_probability(certified->max_tail_mass)) {
    return c14_metric_failure<void>(
        certified->source, "metric_request_invalid_resolution",
        "a certified truncation tail mass must be in (0,1)");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> c14_metric_parameter_error(
    const SourceNode& parameters, std::string message) {
  return c14_metric_failure<void>(
      parameters, "metric_request_invalid_parameter", std::move(message));
}

[[nodiscard]] bool c14_valid_edge_reward(const EdgeRewardKind reward) {
  switch (reward) {
    case EdgeRewardKind::increment:
    case EdgeRewardKind::departure:
    case EdgeRewardKind::arrival:
      return true;
  }
  return false;
}

[[nodiscard]] bool c14_valid_gap_event(const GapEventKind event) {
  switch (event) {
    case GapEventKind::departure:
    case GapEventKind::admission:
    case GapEventKind::busy_denial:
      return true;
  }
  return false;
}

[[nodiscard]] bool c14_valid_hit_set(const HitSetKind kind) {
  switch (kind) {
    case HitSetKind::at_or_above:
    case HitSetKind::at_or_below:
    case HitSetKind::equal:
      return true;
  }
  return false;
}

[[nodiscard]] bool c14_valid_joint_relation(
    const JointBacklogRelation relation) {
  switch (relation) {
    case JointBacklogRelation::all_at_or_above:
    case JointBacklogRelation::any_at_or_above:
      return true;
  }
  return false;
}

[[nodiscard]] Result<BinaryPredicateV1> c14_project_predicate(
    const BinaryPredicateKind kind, const std::optional<BigNat>& threshold,
    const SourceNode& parameters) {
  switch (kind) {
    case BinaryPredicateKind::busy:
      if (threshold.has_value()) {
        break;
      }
      return Result<BinaryPredicateV1>::success(
          BasicBinaryPredicateV1::busy);
    case BinaryPredicateKind::idle:
      if (threshold.has_value()) {
        break;
      }
      return Result<BinaryPredicateV1>::success(
          BasicBinaryPredicateV1::idle);
    case BinaryPredicateKind::busy_denial:
      if (threshold.has_value()) {
        break;
      }
      return Result<BinaryPredicateV1>::success(
          BasicBinaryPredicateV1::busy_denial);
    case BinaryPredicateKind::threshold_above:
      if (!threshold.has_value()) {
        break;
      }
      return Result<BinaryPredicateV1>::success(
          ThresholdAbovePredicateV1{*threshold});
  }
  return c14_metric_failure<BinaryPredicateV1>(
      parameters, "metric_request_invalid_parameter",
      "threshold is required exactly for predicate='threshold_above'");
}

[[nodiscard]] Result<FifoDelayOutputV1> c14_project_fifo_output(
    const FifoDelayWire& request, const SourceNode& parameters) {
  return std::visit(
      [&parameters](const auto& output) -> Result<FifoDelayOutputV1> {
        using Output = std::decay_t<decltype(output)>;
        if constexpr (std::is_same_v<Output, FifoDelayPmfMetric>) {
          return Result<FifoDelayOutputV1>::success(
              FifoDelayPmfOutputV1{output.horizon});
        } else if constexpr (std::is_same_v<Output,
                                            FifoDelayTailMetric>) {
          return Result<FifoDelayOutputV1>::success(
              FifoDelayTailOutputV1{output.horizon});
        } else if constexpr (std::is_same_v<Output,
                                            FifoDelayQuantileMetric>) {
          if (!c14_open_probability(output.probability)) {
            return c14_metric_failure<FifoDelayOutputV1>(
                parameters, "metric_request_invalid_parameter",
                "a FIFO quantile probability must be a canonical exact "
                "value in (0,1)");
          }
          return Result<FifoDelayOutputV1>::success(
              FifoDelayQuantileOutputV1{
                  output.probability,
                  DiscreteQuantileConventionV1::lower_inverse_cdf});
        } else if constexpr (std::is_same_v<Output,
                                            FifoDelayMomentMetric>) {
          if (output.order.is_zero()) {
            return c14_metric_failure<FifoDelayOutputV1>(
                parameters, "metric_request_invalid_parameter",
                "a FIFO moment order must be positive");
          }
          return Result<FifoDelayOutputV1>::success(
              FifoDelayMomentOutputV1{output.order});
        } else {
          return c14_metric_failure<FifoDelayOutputV1>(
              parameters, "metric_request_invalid_parameter",
              "the FIFO output alternative is not part of analysis-v1");
        }
      },
      request);
}

[[nodiscard]] Result<FifoConditionV1> c14_project_fifo_condition(
    const FifoCondition& condition, const SourceNode& parameters) {
  return std::visit(
      [&parameters](const auto& value) -> Result<FifoConditionV1> {
        using Condition = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Condition, RankCondition>) {
          if (value.value.is_zero()) {
            return c14_metric_failure<FifoConditionV1>(
                parameters, "metric_request_invalid_parameter",
                "a FIFO within-batch rank is one-based and must be positive");
          }
          return Result<FifoConditionV1>::success(
              FifoRankConditionV1{value.value});
        } else if constexpr (std::is_same_v<Condition, BatchCondition>) {
          if (value.value.is_zero()) {
            return c14_metric_failure<FifoConditionV1>(
                parameters, "metric_request_invalid_parameter",
                "a FIFO conditioning batch size must be positive");
          }
          return Result<FifoConditionV1>::success(
              FifoBatchConditionV1{value.value});
        } else if constexpr (std::is_same_v<Condition, ClassCondition>) {
          return Result<FifoConditionV1>::success(
              FifoClassConditionV1{value.value});
        } else if constexpr (std::is_same_v<Condition, PhaseCondition>) {
          return Result<FifoConditionV1>::success(
              FifoPhaseConditionV1{value.value});
        } else {
          return c14_metric_failure<FifoConditionV1>(
              parameters, "metric_request_invalid_parameter",
              "the FIFO condition alternative is not part of analysis-v1");
        }
      },
      condition);
}

[[nodiscard]] Result<void> c14_validate_fifo_source_shape(
    const FifoDelayWire& request, const SourceNode& parameters,
    const bool conditioned) {
  return std::visit(
      [&parameters, conditioned](const auto& output) -> Result<void> {
        using Output = std::decay_t<decltype(output)>;
        static_cast<void>(output);
        if constexpr (std::is_same_v<Output, FifoDelayPmfMetric> ||
                      std::is_same_v<Output, FifoDelayTailMetric>) {
          return conditioned
                     ? c14_exact_source_keys(
                           parameters, {"output", "horizon", "condition"},
                           {"output", "horizon", "condition"})
                     : c14_exact_source_keys(parameters,
                                             {"output", "horizon"},
                                             {"output", "horizon"});
        } else if constexpr (std::is_same_v<Output,
                                            FifoDelayQuantileMetric>) {
          return conditioned
                     ? c14_exact_source_keys(
                           parameters,
                           {"output", "probability", "condition"},
                           {"output", "probability", "condition"})
                     : c14_exact_source_keys(parameters,
                                             {"output", "probability"},
                                             {"output", "probability"});
        } else {
          return conditioned
                     ? c14_exact_source_keys(
                           parameters, {"output", "order", "condition"},
                           {"output", "order", "condition"})
                     : c14_exact_source_keys(parameters, {"output", "order"},
                                             {"output", "order"});
        }
      },
      request);
}

template <typename Request, typename Parameters>
[[nodiscard]] Result<MetricRequest> c14_typed_metric_request(
    MetricRequestHeader header, Parameters parameters) {
  return Result<MetricRequest>::success(
      MetricRequestAccess::construct<Request>(
          std::move(header), std::move(parameters)));
}

[[nodiscard]] C14MetricWireInfo c14_metric_wire_info(
    const MetricWire& wire) {
  return std::visit(
      [](const auto& metric) -> C14MetricWireInfo {
        using Metric = std::decay_t<decltype(metric)>;
        static_cast<void>(metric);
        constexpr MetricTargetCouplingV1 scalar =
            MetricTargetCouplingV1::scalar_singleton;
        constexpr MetricTargetCouplingV1 coupled =
            MetricTargetCouplingV1::common_schedule_coupled;
        if constexpr (std::is_same_v<Metric, StationaryThroughputMetric>) {
          return {MetricKindV1::stationary_throughput,
                  "stationary_throughput", scalar};
        } else if constexpr (std::is_same_v<
                                 Metric, StationaryEmptyProbabilityMetric>) {
          return {MetricKindV1::stationary_empty_probability,
                  "stationary_empty_probability", scalar};
        } else if constexpr (std::is_same_v<Metric, MeanSojournMetric>) {
          return {MetricKindV1::mean_sojourn, "mean_sojourn", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            ServicePersistenceMetric>) {
          return {MetricKindV1::service_persistence,
                  "service_persistence", scalar};
        } else if constexpr (std::is_same_v<
                                 Metric, JointBacklogCovarianceMetric>) {
          return {MetricKindV1::joint_backlog_covariance,
                  "joint_backlog_covariance", coupled};
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogPmfMetric>) {
          return {MetricKindV1::stationary_backlog_pmf,
                  "stationary_backlog_pmf", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogPgfMetric>) {
          return {MetricKindV1::stationary_backlog_pgf,
                  "stationary_backlog_pgf", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogMomentMetric>) {
          return {MetricKindV1::stationary_backlog_moment,
                  "stationary_backlog_moment", scalar};
        } else if constexpr (std::is_same_v<
                                 Metric, StationaryBacklogQuantileMetric>) {
          return {MetricKindV1::stationary_backlog_quantile,
                  "stationary_backlog_quantile", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogTailMetric>) {
          return {MetricKindV1::stationary_backlog_tail,
                  "stationary_backlog_tail", scalar};
        } else if constexpr (std::is_same_v<
                                 Metric, BacklogConditionedServiceMetric>) {
          return {MetricKindV1::backlog_conditioned_service,
                  "backlog_conditioned_service", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryEdgeRewardMetric>) {
          return {MetricKindV1::stationary_edge_reward,
                  "stationary_edge_reward", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            ServiceAutocovarianceMetric>) {
          return {MetricKindV1::service_autocovariance,
                  "service_autocovariance", scalar};
        } else if constexpr (std::is_same_v<
                                 Metric, LaggedCrossQueueCovarianceMetric>) {
          return {MetricKindV1::lagged_cross_queue_covariance,
                  "lagged_cross_queue_covariance", coupled};
        } else if constexpr (std::is_same_v<Metric,
                                            ServiceSpectrumMetric>) {
          return {MetricKindV1::service_spectrum, "service_spectrum",
                  scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            ServiceWindowCountMetric>) {
          return {MetricKindV1::service_window_count,
                  "service_window_count", scalar};
        } else if constexpr (std::is_same_v<Metric, MeanEventGapMetric>) {
          return {MetricKindV1::mean_event_gap, "mean_event_gap", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            EventGapDistributionMetric>) {
          return {MetricKindV1::event_gap_distribution,
                  "event_gap_distribution", scalar};
        } else if constexpr (std::is_same_v<Metric, MeanBinaryRunMetric>) {
          return {MetricKindV1::mean_binary_run, "mean_binary_run", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            BinaryRunDistributionMetric>) {
          return {MetricKindV1::binary_run_distribution,
                  "binary_run_distribution", scalar};
        } else if constexpr (std::is_same_v<Metric, FirstHitMetric>) {
          return {MetricKindV1::first_hit, "first_hit", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            ThresholdExcursionMetric>) {
          return {MetricKindV1::threshold_excursion,
                  "threshold_excursion", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            TransientBacklogLawMetric>) {
          return {MetricKindV1::transient_backlog_law,
                  "transient_backlog_law", scalar};
        } else if constexpr (std::is_same_v<Metric, FifoDelayMetric>) {
          return {MetricKindV1::fifo_delay, "fifo_delay", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            FifoDelayConditionedMetric>) {
          return {MetricKindV1::fifo_delay_conditioned,
                  "fifo_delay_conditioned", scalar};
        } else if constexpr (std::is_same_v<
                                 Metric, CounterfactualOpportunityGapMetric>) {
          return {MetricKindV1::counterfactual_opportunity_gap,
                  "counterfactual_opportunity_gap", scalar};
        } else if constexpr (std::is_same_v<Metric,
                                            JointBacklogEventMetric>) {
          return {MetricKindV1::joint_backlog_event,
                  "joint_backlog_event", coupled};
        } else if constexpr (std::is_same_v<Metric, JointDelayMetric>) {
          return {MetricKindV1::joint_delay, "joint_delay", coupled};
        } else {
          static_assert(std::is_same_v<Metric,
                                       OrderedScheduleSequenceMetric>);
          return {MetricKindV1::ordered_schedule_sequence,
                  "ordered_schedule_sequence", coupled};
        }
      },
      wire);
}

}  // namespace

Result<MetricRequest> parse_metric_request(const MetricNode& node,
                                           const QueueCatalog& queue_catalog) {
  if (!node.context) {
    return c14_metric_failure<MetricRequest>(
        node.source, "metric_request_null_context",
        "a metric node must carry its immutable analysis context");
  }
  Result<TypedLabel> checked_id = TypedLabel::text(node.id);
  if (!checked_id) {
    return c14_metric_failure<MetricRequest>(
        node.source, "metric_request_invalid_metric_id",
        "the metric id must be nonempty, valid UTF-8, and already trimmed");
  }

  const C14MetricWireInfo info = c14_metric_wire_info(node.metric);
  Result<C14MetricSourceView> source = c14_metric_source_view(node, info);
  if (!source) {
    return Result<MetricRequest>::failure(source.error());
  }
  Result<void> resolution = c14_validate_resolution_context(node);
  if (!resolution) {
    return Result<MetricRequest>::failure(resolution.error());
  }
  Result<MetricSelectionRegimeV1> selection = c14_selection_regime(node);
  if (!selection) {
    return Result<MetricRequest>::failure(selection.error());
  }
  Result<void> selection_match =
      c14_validate_selection_for_metric(node, info.kind, selection.value());
  if (!selection_match) {
    return Result<MetricRequest>::failure(selection_match.error());
  }
  Result<MetricSolverRegimeV1> solver = c14_solver_regime(node);
  if (!solver) {
    return Result<MetricRequest>::failure(solver.error());
  }
  Result<std::vector<ResolvedMetricTargetV1>> targets =
      c14_resolve_metric_targets(node, queue_catalog, info.coupling);
  if (!targets) {
    return Result<MetricRequest>::failure(targets.error());
  }

  MetricRequestHeader header{
      node.id,
      source.value().authored_index,
      info.kind,
      info.coupling,
      std::move(targets).value(),
      selection.value(),
      solver.value(),
      node.context,
      authored_provenance(node.source),
  };
  const SourceNode& parameters = *source.value().parameters;

  return std::visit(
      [&](const auto& metric) -> Result<MetricRequest> {
        using Metric = std::decay_t<decltype(metric)>;
        Result<void> shape = Result<void>::success();

        if constexpr (std::is_same_v<Metric, StationaryThroughputMetric>) {
          shape = c14_exact_source_keys(parameters, {}, {});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<StationaryThroughputRequestV1>(
              std::move(header), StationaryThroughputParametersV1{});
        } else if constexpr (std::is_same_v<
                                 Metric, StationaryEmptyProbabilityMetric>) {
          shape = c14_exact_source_keys(parameters, {}, {});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<
              StationaryEmptyProbabilityRequestV1>(
              std::move(header),
              StationaryEmptyProbabilityParametersV1{});
        } else if constexpr (std::is_same_v<Metric, MeanSojournMetric>) {
          shape = c14_exact_source_keys(parameters, {}, {});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<MeanSojournRequestV1>(
              std::move(header), MeanSojournParametersV1{});
        } else if constexpr (std::is_same_v<Metric,
                                            ServicePersistenceMetric>) {
          shape = c14_exact_source_keys(parameters, {}, {});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<ServicePersistenceRequestV1>(
              std::move(header), ServicePersistenceParametersV1{});
        } else if constexpr (std::is_same_v<
                                 Metric, JointBacklogCovarianceMetric>) {
          shape = c14_exact_source_keys(parameters, {}, {});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<
              JointBacklogCovarianceRequestV1>(
              std::move(header), JointBacklogCovarianceParametersV1{});
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogPmfMetric>) {
          shape = metric.max_level.has_value()
                      ? c14_exact_source_keys(parameters, {"max_level"},
                                              {"max_level"})
                      : c14_exact_source_keys(parameters, {}, {});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          StationaryBacklogPmfDomainV1 domain =
              metric.max_level.has_value()
                  ? StationaryBacklogPmfDomainV1(
                        PmfThroughLevelV1{*metric.max_level})
                  : StationaryBacklogPmfDomainV1(CompletePmfDomainV1{});
          return c14_typed_metric_request<StationaryBacklogPmfRequestV1>(
              std::move(header),
              StationaryBacklogPmfParametersV1{std::move(domain)});
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogPgfMetric>) {
          shape = c14_exact_source_keys(parameters, {"points"}, {"points"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.points.empty() || !c14_duplicate_free(metric.points) ||
              !std::all_of(metric.points.begin(), metric.points.end(),
                           c14_canonical_rational)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "PGF points must be a nonempty, duplicate-free array of "
                    "canonical exact finite rationals")
                    .error());
          }
          std::vector<ExactRational> canonical_points = metric.points;
          std::sort(canonical_points.begin(), canonical_points.end());
          return c14_typed_metric_request<StationaryBacklogPgfRequestV1>(
              std::move(header),
              StationaryBacklogPgfParametersV1{
                  std::move(canonical_points)});
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogMomentMetric>) {
          shape = c14_exact_source_keys(parameters, {"order"}, {"order"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.order.is_zero()) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters, "a backlog moment order must be positive")
                    .error());
          }
          return c14_typed_metric_request<
              StationaryBacklogMomentRequestV1>(
              std::move(header),
              StationaryBacklogMomentParametersV1{metric.order});
        } else if constexpr (std::is_same_v<
                                 Metric, StationaryBacklogQuantileMetric>) {
          shape = c14_exact_source_keys(parameters, {"probability"},
                                        {"probability"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_open_probability(metric.probability)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "a backlog quantile probability must be a canonical "
                    "exact value in (0,1)")
                    .error());
          }
          return c14_typed_metric_request<
              StationaryBacklogQuantileRequestV1>(
              std::move(header),
              StationaryBacklogQuantileParametersV1{
                  metric.probability,
                  DiscreteQuantileConventionV1::lower_inverse_cdf});
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryBacklogTailMetric>) {
          shape = c14_exact_source_keys(parameters, {"threshold"},
                                        {"threshold"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<StationaryBacklogTailRequestV1>(
              std::move(header),
              StationaryBacklogTailParametersV1{metric.threshold});
        } else if constexpr (std::is_same_v<
                                 Metric, BacklogConditionedServiceMetric>) {
          shape = c14_exact_source_keys(parameters, {"levels"}, {"levels"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.levels.empty() || !c14_duplicate_free(metric.levels)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "conditioned backlog levels must be nonempty and "
                    "duplicate-free")
                    .error());
          }
          std::vector<BigNat> canonical_levels = metric.levels;
          std::sort(canonical_levels.begin(), canonical_levels.end());
          return c14_typed_metric_request<
              BacklogConditionedServiceRequestV1>(
              std::move(header),
              BacklogConditionedServiceParametersV1{
                  std::move(canonical_levels)});
        } else if constexpr (std::is_same_v<Metric,
                                            StationaryEdgeRewardMetric>) {
          shape = c14_exact_source_keys(
              parameters, {"reward", "moment_order"},
              {"reward", "moment_order"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_valid_edge_reward(metric.reward) ||
              metric.moment_order.is_zero()) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "edge reward must be a closed analysis-v1 value and its "
                    "moment order must be positive")
                    .error());
          }
          return c14_typed_metric_request<StationaryEdgeRewardRequestV1>(
              std::move(header), StationaryEdgeRewardParametersV1{
                                     metric.reward, metric.moment_order});
        } else if constexpr (std::is_same_v<Metric,
                                            ServiceAutocovarianceMetric>) {
          shape = c14_exact_source_keys(parameters, {"lags"}, {"lags"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.lags.empty() || !c14_duplicate_free(metric.lags) ||
              std::any_of(metric.lags.begin(), metric.lags.end(),
                          [](const BigNat& lag) { return lag.is_zero(); })) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "service autocovariance lags must be positive, nonempty, "
                    "and duplicate-free")
                    .error());
          }
          std::vector<BigNat> canonical_lags = metric.lags;
          std::sort(canonical_lags.begin(), canonical_lags.end());
          return c14_typed_metric_request<ServiceAutocovarianceRequestV1>(
              std::move(header),
              ServiceAutocovarianceParametersV1{
                  std::move(canonical_lags)});
        } else if constexpr (std::is_same_v<
                                 Metric, LaggedCrossQueueCovarianceMetric>) {
          shape = c14_exact_source_keys(parameters, {"lags"}, {"lags"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.lags.empty() || !c14_duplicate_free(metric.lags) ||
              std::any_of(metric.lags.begin(), metric.lags.end(),
                          [](const BigNat& lag) { return lag.is_zero(); })) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "cross-queue covariance lags must be positive, nonempty, "
                    "and duplicate-free")
                    .error());
          }
          std::vector<BigNat> canonical_lags = metric.lags;
          std::sort(canonical_lags.begin(), canonical_lags.end());
          return c14_typed_metric_request<
              LaggedCrossQueueCovarianceRequestV1>(
              std::move(header),
              LaggedCrossQueueCovarianceParametersV1{
                  std::move(canonical_lags)});
        } else if constexpr (std::is_same_v<Metric,
                                            ServiceSpectrumMetric>) {
          shape = c14_exact_source_keys(
              parameters, {"frequencies", "truncation_lag"},
              {"frequencies", "truncation_lag"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.frequencies.empty() ||
              !c14_duplicate_free(metric.frequencies) ||
              metric.truncation_lag.is_zero() ||
              !std::all_of(metric.frequencies.begin(),
                           metric.frequencies.end(),
                           c14_canonical_rational)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "spectrum frequencies must be nonempty, duplicate-free, "
                    "canonical exact finite rationals and truncation_lag must "
                    "be positive")
                    .error());
          }
          std::vector<ExactRational> canonical_frequencies =
              metric.frequencies;
          std::sort(canonical_frequencies.begin(),
                    canonical_frequencies.end());
          return c14_typed_metric_request<ServiceSpectrumRequestV1>(
              std::move(header),
              ServiceSpectrumParametersV1{
                  std::move(canonical_frequencies), metric.truncation_lag,
                  SpectrumWindowV1::rectangular_truncation});
        } else if constexpr (std::is_same_v<Metric,
                                            ServiceWindowCountMetric>) {
          shape = c14_exact_source_keys(parameters, {"width"}, {"width"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.width.is_zero()) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters, "a service window width must be positive")
                    .error());
          }
          return c14_typed_metric_request<ServiceWindowCountRequestV1>(
              std::move(header),
              ServiceWindowCountParametersV1{metric.width});
        } else if constexpr (std::is_same_v<Metric, MeanEventGapMetric>) {
          shape = c14_exact_source_keys(parameters, {"event"}, {"event"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_valid_gap_event(metric.event)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "the event kind is not part of analysis-v1")
                    .error());
          }
          return c14_typed_metric_request<MeanEventGapRequestV1>(
              std::move(header), MeanEventGapParametersV1{metric.event});
        } else if constexpr (std::is_same_v<Metric,
                                            EventGapDistributionMetric>) {
          shape = c14_exact_source_keys(parameters, {"event", "horizon"},
                                        {"event", "horizon"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_valid_gap_event(metric.event)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "the event kind is not part of analysis-v1")
                    .error());
          }
          return c14_typed_metric_request<EventGapDistributionRequestV1>(
              std::move(header), EventGapDistributionParametersV1{
                                     metric.event, metric.horizon});
        } else if constexpr (std::is_same_v<Metric, MeanBinaryRunMetric>) {
          shape = metric.threshold.has_value()
                      ? c14_exact_source_keys(
                            parameters, {"predicate", "threshold"},
                            {"predicate", "threshold"})
                      : c14_exact_source_keys(parameters, {"predicate"},
                                              {"predicate"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          Result<BinaryPredicateV1> predicate = c14_project_predicate(
              metric.predicate, metric.threshold, parameters);
          if (!predicate) {
            return Result<MetricRequest>::failure(predicate.error());
          }
          return c14_typed_metric_request<MeanBinaryRunRequestV1>(
              std::move(header),
              MeanBinaryRunParametersV1{std::move(predicate).value()});
        } else if constexpr (std::is_same_v<Metric,
                                            BinaryRunDistributionMetric>) {
          shape = metric.threshold.has_value()
                      ? c14_exact_source_keys(
                            parameters,
                            {"predicate", "threshold", "horizon"},
                            {"predicate", "threshold", "horizon"})
                      : c14_exact_source_keys(
                            parameters, {"predicate", "horizon"},
                            {"predicate", "horizon"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          Result<BinaryPredicateV1> predicate = c14_project_predicate(
              metric.predicate, metric.threshold, parameters);
          if (!predicate) {
            return Result<MetricRequest>::failure(predicate.error());
          }
          return c14_typed_metric_request<BinaryRunDistributionRequestV1>(
              std::move(header), BinaryRunDistributionParametersV1{
                                     std::move(predicate).value(),
                                     metric.horizon});
        } else if constexpr (std::is_same_v<Metric, FirstHitMetric>) {
          shape = c14_exact_source_keys(
              parameters, {"set", "horizon", "include_mean"},
              {"set", "horizon", "include_mean"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_valid_hit_set(metric.set.kind)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "the hit-set kind is not part of analysis-v1")
                    .error());
          }
          return c14_typed_metric_request<FirstHitRequestV1>(
              std::move(header),
              FirstHitParametersV1{
                  MetricHitSetV1{metric.set.kind, metric.set.level},
                  metric.horizon, metric.include_mean});
        } else if constexpr (std::is_same_v<Metric,
                                            ThresholdExcursionMetric>) {
          shape = c14_exact_source_keys(
              parameters, {"set", "horizon", "include_mean"},
              {"set", "horizon", "include_mean"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_valid_hit_set(metric.set.kind)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "the hit-set kind is not part of analysis-v1")
                    .error());
          }
          return c14_typed_metric_request<ThresholdExcursionRequestV1>(
              std::move(header),
              ThresholdExcursionParametersV1{
                  MetricHitSetV1{metric.set.kind, metric.set.level},
                  metric.horizon, metric.include_mean});
        } else if constexpr (std::is_same_v<Metric,
                                            TransientBacklogLawMetric>) {
          shape = c14_exact_source_keys(parameters, {"horizons"},
                                        {"horizons"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.horizons.empty() ||
              !c14_duplicate_free(metric.horizons)) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "transient horizons must be nonempty and "
                    "duplicate-free")
                    .error());
          }
          std::vector<BigNat> canonical_horizons = metric.horizons;
          std::sort(canonical_horizons.begin(), canonical_horizons.end());
          return c14_typed_metric_request<TransientBacklogLawRequestV1>(
              std::move(header),
              TransientBacklogLawParametersV1{
                  std::move(canonical_horizons)});
        } else if constexpr (std::is_same_v<Metric, FifoDelayMetric>) {
          shape = c14_validate_fifo_source_shape(metric.request, parameters,
                                                 false);
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          Result<FifoDelayOutputV1> output =
              c14_project_fifo_output(metric.request, parameters);
          if (!output) return Result<MetricRequest>::failure(output.error());
          return c14_typed_metric_request<FifoDelayRequestV1>(
              std::move(header),
              FifoDelayParametersV1{std::move(output).value()});
        } else if constexpr (std::is_same_v<Metric,
                                            FifoDelayConditionedMetric>) {
          shape = c14_validate_fifo_source_shape(metric.request, parameters,
                                                 true);
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          Result<FifoDelayOutputV1> output =
              c14_project_fifo_output(metric.request, parameters);
          Result<FifoConditionV1> condition =
              c14_project_fifo_condition(metric.condition, parameters);
          if (!output) return Result<MetricRequest>::failure(output.error());
          if (!condition) {
            return Result<MetricRequest>::failure(condition.error());
          }
          return c14_typed_metric_request<FifoDelayConditionedRequestV1>(
              std::move(header), FifoDelayConditionedParametersV1{
                                     std::move(output).value(),
                                     std::move(condition).value()});
        } else if constexpr (std::is_same_v<
                                 Metric, CounterfactualOpportunityGapMetric>) {
          shape = c14_exact_source_keys(
              parameters, {"convention_id", "horizon"},
              {"convention_id", "horizon"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          return c14_typed_metric_request<
              CounterfactualOpportunityGapRequestV1>(
              std::move(header),
              CounterfactualOpportunityGapParametersV1{
                  metric.convention_id, metric.horizon});
        } else if constexpr (std::is_same_v<Metric,
                                            JointBacklogEventMetric>) {
          shape = c14_exact_source_keys(
              parameters, {"relation", "thresholds"},
              {"relation", "thresholds"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (!c14_valid_joint_relation(metric.relation) ||
              metric.thresholds.empty() ||
              metric.thresholds.size() != header.ordered_targets.size()) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "joint backlog thresholds must contain exactly one "
                    "positional value per ordered target")
                    .error());
          }
          return c14_typed_metric_request<JointBacklogEventRequestV1>(
              std::move(header), JointBacklogEventParametersV1{
                                     metric.relation, metric.thresholds});
        } else if constexpr (std::is_same_v<Metric, JointDelayMetric>) {
          switch (metric.sampling) {
            case JointDelaySampling::coincident:
            case JointDelaySampling::independent_palm:
              shape = c14_exact_source_keys(
                  parameters, {"sampling", "horizon"},
                  {"sampling", "horizon"});
              if (metric.lag.has_value()) {
                return Result<MetricRequest>::failure(
                    c14_metric_parameter_error(
                        parameters,
                        "lag is forbidden for coincident and independent "
                        "Palm sampling")
                        .error());
              }
              break;
            case JointDelaySampling::lagged:
              shape = c14_exact_source_keys(
                  parameters, {"sampling", "lag", "horizon"},
                  {"sampling", "lag", "horizon"});
              if (!metric.lag.has_value()) {
                return Result<MetricRequest>::failure(
                    c14_metric_parameter_error(
                        parameters, "lagged joint delay requires lag")
                        .error());
              }
              break;
            default:
              return Result<MetricRequest>::failure(
                  c14_metric_parameter_error(
                      parameters,
                      "the joint-delay sampling convention is not part of "
                      "analysis-v1")
                      .error());
          }
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          JointDelaySamplingV1 sampling =
              metric.sampling == JointDelaySampling::coincident
                  ? JointDelaySamplingV1(CoincidentPalmSamplingV1{})
                  : (metric.sampling == JointDelaySampling::independent_palm
                         ? JointDelaySamplingV1(IndependentPalmSamplingV1{})
                         : JointDelaySamplingV1(
                               LaggedPalmSamplingV1{*metric.lag}));
          return c14_typed_metric_request<JointDelayRequestV1>(
              std::move(header), JointDelayParametersV1{
                                     std::move(sampling), metric.horizon});
        } else {
          static_assert(std::is_same_v<Metric,
                                       OrderedScheduleSequenceMetric>);
          shape = c14_exact_source_keys(
              parameters, {"horizon", "retain_full_schedule"},
              {"horizon", "retain_full_schedule"});
          if (!shape) return Result<MetricRequest>::failure(shape.error());
          if (metric.horizon.is_zero()) {
            return Result<MetricRequest>::failure(
                c14_metric_parameter_error(
                    parameters,
                    "an ordered schedule sequence horizon must be positive")
                    .error());
          }
          return c14_typed_metric_request<OrderedScheduleSequenceRequestV1>(
              std::move(header), OrderedScheduleSequenceParametersV1{
                                     metric.horizon,
                                     metric.retain_full_schedule});
        }
      },
      node.metric);
}

}  // namespace mwperf

namespace mwperf {
namespace {

constexpr std::uint32_t kCapabilitySchemaVersionV1 = 1U;

// A small length-framed encoder is used only for C14 identity guards.  It is
// deliberately independent of locale, native integer width, and object
// addresses.  Every collection is either semantically ordered or validated as
// canonical before its bytes are accepted as a preview identity.
class CapabilityCanonicalEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }

  void boolean(const bool value) { byte(value ? 1U : 0U); }

  void u32(const std::uint32_t value) {
    for (unsigned shift = 32U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }

  void u64(const std::uint64_t value) {
    for (unsigned shift = 64U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }

  void count(const std::size_t value) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    u64(static_cast<std::uint64_t>(value));
  }

  template <typename Enum>
    requires std::is_enum_v<Enum>
  void enumeration(const Enum value) {
    using Underlying = std::underlying_type_t<Enum>;
    using Unsigned = std::make_unsigned_t<Underlying>;
    u64(static_cast<std::uint64_t>(static_cast<Unsigned>(value)));
  }

  void string(const std::string_view value) {
    count(value.size());
    for (const char character : value) {
      byte(static_cast<std::uint8_t>(
          static_cast<unsigned char>(character)));
    }
  }

  void raw(const std::span<const std::byte> value) {
    count(value.size());
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }

  void raw_u8(const std::span<const std::uint8_t> value) {
    count(value.size());
    for (const std::uint8_t item : value) {
      byte(item);
    }
  }

  void digest(const Digest256& value) { raw(value.bytes()); }

  void natural(const BigNat& value) {
    const std::vector<std::uint8_t> magnitude =
        value.canonical_magnitude_bytes();
    raw_u8(magnitude);
  }

  void rational(const ExactRational& value) {
    string(value.numerator_decimal());
    string(value.denominator_decimal());
  }

  void label(const TypedLabel& value) {
    const std::vector<std::uint8_t> bytes = value.canonical_bytes();
    raw_u8(bytes);
  }

  template <StrongIdDomainName Domain>
  void strong_id(const StrongId<Domain>& value) {
    const std::vector<std::uint8_t> bytes = value.canonical_bytes();
    raw_u8(bytes);
  }

  template <typename T, typename Emit>
  void optional(const std::optional<T>& value, Emit emit) {
    boolean(value.has_value());
    if (value.has_value()) {
      emit(*value);
    }
  }

  [[nodiscard]] std::span<const std::byte> bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

template <typename Range, typename Emit>
void encode_vector(CapabilityCanonicalEncoder& encoder, const Range& values,
                   Emit emit) {
  encoder.count(values.size());
  for (const auto& value : values) {
    emit(value);
  }
}

void encode_codec(CapabilityCanonicalEncoder& encoder,
                  const CodecIdentityV1& codec) {
  encoder.string(codec.id);
  encoder.u32(codec.version);
}

void encode_state_field(CapabilityCanonicalEncoder& encoder,
                        const StateFieldDescriptorV1& field) {
  encoder.enumeration(field.kind);
  encoder.enumeration(field.ownership);
  encode_codec(encoder, field.codec);
}

void encode_mark(CapabilityCanonicalEncoder& encoder,
                 const MarkDescriptorV1& mark) {
  encoder.enumeration(mark.kind);
  encoder.enumeration(mark.reveal_stage);
  encode_codec(encoder, mark.codec);
  encoder.string(mark.common_realization_group);
}

void encode_selection(CapabilityCanonicalEncoder& encoder,
                      const SelectionSupportV1& selection) {
  encode_vector(encoder, selection.kinds, [&](const SelectionKindV1 value) {
    encoder.enumeration(value);
  });
  encode_vector(encoder, selection.named_classes,
                [&](const TypedLabel& value) { encoder.label(value); });
  encode_vector(encoder, selection.named_fixed_points,
                [&](const TypedLabel& value) { encoder.label(value); });
}

void encode_phase(CapabilityCanonicalEncoder& encoder,
                  const PhaseSupportV1& phase) {
  encoder.enumeration(phase.payload_phase);
  encoder.enumeration(phase.arrival_composition);
  encoder.boolean(phase.retains_configured_predictive_phase);
  encoder.optional(phase.predictive_phase_codec,
                   [&](const CodecIdentityV1& codec) {
                     encode_codec(encoder, codec);
                   });
  encoder.enumeration(phase.finite_horizon_coverage);
  encoder.optional(phase.maximum_finite_horizon,
                   [&](const BigNat& value) { encoder.natural(value); });
}

void encode_tail(CapabilityCanonicalEncoder& encoder,
                 const TailSupportV1& tail) {
  encoder.enumeration(tail.kind);
  encoder.optional(tail.boundary,
                   [&](const BigNat& value) { encoder.natural(value); });
  encoder.optional(tail.certified_tail_mass,
                   [&](const ExactRational& value) {
                     encoder.rational(value);
                   });
}

void encode_domain(CapabilityCanonicalEncoder& encoder,
                   const ExactArgumentDomain& domain) {
  encoder.rational(domain.lower);
  encoder.rational(domain.upper);
  encoder.boolean(domain.lower_inclusive);
  encoder.boolean(domain.upper_inclusive);
}

void encode_arrival_assumption(CapabilityCanonicalEncoder& encoder,
                               const ArrivalAssumptionV1& assumption) {
  encoder.enumeration(assumption.kind);
  encoder.enumeration(assumption.use);
  encoder.enumeration(assumption.provision);
  encoder.optional(assumption.moment_order,
                   [&](const BigNat& value) { encoder.natural(value); });
  encoder.boolean(assumption.joint);
  encoder.boolean(assumption.phase_conditioned);
  encoder.optional(assumption.transform_kind, [&](const TransformKind value) {
    encoder.enumeration(value);
  });
  encoder.optional(assumption.distribution_scope,
                   [&](const DistributionScope value) {
                     encoder.enumeration(value);
                   });
  encoder.optional(assumption.argument_domain,
                   [&](const ExactArgumentDomain& value) {
                     encode_domain(encoder, value);
                   });
}

void encode_hypothesis(CapabilityCanonicalEncoder& encoder,
                       const HypothesisClaimV1& hypothesis) {
  encoder.enumeration(hypothesis.kind);
  encoder.optional(hypothesis.variable, [&](const MomentVariableV1 value) {
    encoder.enumeration(value);
  });
  encoder.optional(hypothesis.order,
                   [&](const BigNat& value) { encoder.natural(value); });
  encoder.optional(hypothesis.convention_or_class,
                   [&](const TypedLabel& value) { encoder.label(value); });
}

void encode_tolerance(CapabilityCanonicalEncoder& encoder,
                      const DeterministicToleranceV1& tolerance) {
  encoder.enumeration(tolerance.kind);
  encoder.rational(tolerance.maximum_absolute_error);
}

void encode_accuracy(CapabilityCanonicalEncoder& encoder,
                     const AccuracyContractV1& accuracy) {
  encoder.count(accuracy.index());
  std::visit(
      [&](const auto& value) {
        using Value = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Value, EnumeratedAccuracyV1>) {
          encode_vector(encoder, value.tolerances,
                        [&](const DeterministicToleranceV1& tolerance) {
                          encode_tolerance(encoder, tolerance);
                        });
        } else if constexpr (std::is_same_v<Value, AnalyticAccuracyV1>) {
          encoder.natural(value.precision_bits);
          encode_vector(encoder, value.tolerances,
                        [&](const DeterministicToleranceV1& tolerance) {
                          encode_tolerance(encoder, tolerance);
                        });
        } else if constexpr (std::is_same_v<Value, MonteCarloAccuracyV1>) {
          encoder.natural(value.replications);
          encoder.rational(value.confidence_level);
          encoder.enumeration(value.interval);
          encoder.enumeration(value.estimand);
          encoder.optional(value.almost_sure_lower,
                           [&](const ExactRational& bound) {
                             encoder.rational(bound);
                           });
          encoder.optional(value.almost_sure_upper,
                           [&](const ExactRational& bound) {
                             encoder.rational(bound);
                           });
        } else {
          static_assert(std::is_same_v<Value, DirectExactAccuracyV1>);
        }
      },
      accuracy);
}

void encode_v0(CapabilityCanonicalEncoder& encoder,
               const V0DeclarationV1& declaration) {
  encoder.enumeration(declaration.kind);
  encoder.string(declaration.factor_schema_id);
  encoder.u32(declaration.factor_schema_version);
}

void encode_optional_evidence(CapabilityCanonicalEncoder& encoder,
                              const OptionalReportedEvidenceV1& evidence) {
  encoder.enumeration(evidence.kind);
  encoder.string(evidence.witness_schema_id);
  encoder.u32(evidence.witness_schema_version);
}

void encode_policies(CapabilityCanonicalEncoder& encoder,
                     const PreviewPoliciesV1& policies) {
  encoder.enumeration(policies.point_deployment);
  encoder.enumeration(policies.coefficient_completion);
  encoder.enumeration(policies.projection);
  encoder.enumeration(policies.recoding);
  encoder.enumeration(policies.evidence_roles);
}

void encode_prerequisites(CapabilityCanonicalEncoder& encoder,
                          const ConstructionPrerequisitesV1& prerequisites) {
  encode_vector(encoder, prerequisites.arrival,
                [&](const ArrivalAssumptionV1& value) {
                  encode_arrival_assumption(encoder, value);
                });
  encoder.optional(prerequisites.required_optimizer_calls,
                   [&](const BigNat& value) { encoder.natural(value); });
  encoder.optional(prerequisites.required_generator_draws,
                   [&](const BigNat& value) { encoder.natural(value); });
  encoder.optional(prerequisites.required_search_states_per_call,
                   [&](const BigNat& value) { encoder.natural(value); });
}

template <typename Value, typename Emit>
[[nodiscard]] bool strictly_canonical_by(
    const std::vector<Value>& values, Emit emit) {
  const auto byte_less = [](const std::byte left, const std::byte right) {
    return std::to_integer<std::uint8_t>(left) <
           std::to_integer<std::uint8_t>(right);
  };

  std::vector<std::byte> previous;
  bool first = true;
  for (const Value& value : values) {
    CapabilityCanonicalEncoder encoder;
    emit(encoder, value);
    const std::span<const std::byte> bytes = encoder.bytes();
    std::vector<std::byte> current(bytes.begin(), bytes.end());
    if (!first &&
        !std::lexicographical_compare(previous.begin(), previous.end(),
                                      current.begin(), current.end(),
                                      byte_less)) {
      return false;
    }
    previous = std::move(current);
    first = false;
  }
  return true;
}

[[nodiscard]] bool strictly_canonical_tolerances(
    const std::vector<DeterministicToleranceV1>& tolerances) noexcept {
  return std::adjacent_find(
             tolerances.begin(), tolerances.end(),
             [](const DeterministicToleranceV1& left,
                const DeterministicToleranceV1& right) {
               return !(left.kind < right.kind);
             }) == tolerances.end();
}

void encode_core_without_digest(CapabilityCanonicalEncoder& encoder,
                                const PlugDescriptorCore& core) {
  encoder.u32(core.schema_version);
  encoder.string(core.provider.provider_id);
  encoder.string(core.provider.provider_version);
  encode_vector(
      encoder, core.applicability.scheduler_optimizer_pairs,
      [&](const SchedulerConstraintPairV1& pair) {
        encoder.enumeration(pair.service_family);
        encoder.enumeration(pair.optimizer);
      });
  encode_vector(encoder, core.applicability.timing_conventions,
                [&](const TimingConvention timing) {
                  encoder.enumeration(timing);
                });
  encoder.enumeration(core.payload_class.tag);
  encoder.u32(core.payload_class.version);
  encoder.enumeration(core.semantic);
  encoder.enumeration(core.runtime_access);
  encode_vector(encoder, core.deployed_targets,
                [&](const QueueId& target) { encoder.strong_id(target); });
  encoder.enumeration(core.target_coupling);
  encode_vector(encoder, core.state_fields,
                [&](const StateFieldDescriptorV1& field) {
                  encode_state_field(encoder, field);
                });
  encode_vector(encoder, core.marks, [&](const MarkDescriptorV1& mark) {
    encode_mark(encoder, mark);
  });
  encode_selection(encoder, core.selection);
  encode_phase(encoder, core.phase);
  encode_tail(encoder, core.tail);
  encode_vector(encoder, core.arrival_assumptions,
                [&](const ArrivalAssumptionV1& value) {
                  encode_arrival_assumption(encoder, value);
                });
  encode_vector(encoder, core.hypothesis_claims,
                [&](const HypothesisClaimV1& value) {
                  encode_hypothesis(encoder, value);
                });
  encode_v0(encoder, core.mandatory_v0);
  encode_vector(encoder, core.optional_reported_evidence,
                [&](const OptionalReportedEvidenceV1& value) {
                  encode_optional_evidence(encoder, value);
                });
  encode_vector(encoder, core.accuracy_support,
                [&](const AccuracyContractV1& value) {
                  encode_accuracy(encoder, value);
                });
  encoder.enumeration(core.construction_scope.result_scope);
  encoder.enumeration(core.construction_scope.error_scope);
  encoder.digest(core.metric_support_manifest_digest);
}

void encode_preview_without_digest(CapabilityCanonicalEncoder& encoder,
                                   const PlugDescriptorPreview& preview) {
  encoder.u32(preview.schema_version);
  encode_core_without_digest(encoder, preview.core);
  encoder.digest(preview.core.core_digest);
  encoder.enumeration(preview.construction_method);
  encoder.enumeration(preview.producer_mode);
  encode_vector(encoder, preview.construction_target_scope,
                [&](const QueueId& target) { encoder.strong_id(target); });
  encode_policies(encoder, preview.policies);
  encode_prerequisites(encoder, preview.construction_prerequisites);
  encoder.boolean(static_cast<bool>(preview.metric_support_manifest));
  if (preview.metric_support_manifest) {
    encoder.digest(preview.metric_support_manifest->canonical_digest());
  }
  encoder.digest(preview.problem_view_digest);
  encoder.digest(preview.parameter_digest);
  encoder.digest(preview.budget_digest);
}

void encode_transform_capability(CapabilityCanonicalEncoder& encoder,
                                 const TransformCapability& capability) {
  encoder.enumeration(capability.kind);
  encoder.enumeration(capability.scope);
  encode_domain(encoder, capability.domain);
  encoder.enumeration(capability.phase_requirement);
  encoder.enumeration(capability.provision);
}

void encode_moment_capability(CapabilityCanonicalEncoder& encoder,
                              const MomentCapability& capability) {
  encoder.optional(capability.maximum_order,
                   [&](const BigNat& value) { encoder.natural(value); });
  encoder.boolean(capability.joint);
  encoder.boolean(capability.conditioned_on_phase);
  encoder.enumeration(capability.provision);
}

void encode_arrival_capabilities(CapabilityCanonicalEncoder& encoder,
                                 const ArrivalCapabilities& capabilities) {
  encoder.u32(capabilities.version);
  encoder.enumeration(capabilities.exact_positive_support);
  encoder.enumeration(capabilities.sequential_normalized_sampler);
  encoder.enumeration(capabilities.finite_enumerated_predictive_phase);
  encoder.enumeration(capabilities.finite_enumerated_transition_row);
  encoder.optional(capabilities.analytic_transform,
                   [&](const TransformCapability& value) {
                     encode_transform_capability(encoder, value);
                   });
  encoder.optional(capabilities.analytic_moments,
                   [&](const MomentCapability& value) {
                     encode_moment_capability(encoder, value);
                   });
  encoder.enumeration(capabilities.stationary_phase_law);
  encoder.optional(capabilities.exact_iid_joint_vector,
                   [&](const ExactIidJointVectorCapability& value) {
                     encoder.boolean(value.finite_support);
                     encoder.enumeration(value.provision);
                   });
  encoder.optional(capabilities.exact_joint_moments,
                   [&](const MomentCapability& value) {
                     encode_moment_capability(encoder, value);
                   });
  encoder.optional(capabilities.exact_coordinate_moments,
                   [&](const MomentCapability& value) {
                     encode_moment_capability(encoder, value);
                   });
  encoder.enumeration(capabilities.exact_covariance);
  encoder.enumeration(capabilities.exact_cross_moments);
  encoder.optional(capabilities.exact_joint_distribution,
                   [&](const TransformCapability& value) {
                     encode_transform_capability(encoder, value);
                   });
  encoder.optional(capabilities.exact_coordinate_distributions,
                   [&](const TransformCapability& value) {
                     encode_transform_capability(encoder, value);
                   });
  encoder.optional(capabilities.adjacent_batch_replay,
                   [&](const ReplayCapability& value) {
                     encoder.boolean(value.explicit_initial_state);
                     encoder.boolean(value.explicit_phase);
                     encoder.boolean(value.normalized_initial_law);
                     encoder.boolean(value.named_stationary_initialization);
                     encoder.enumeration(value.provision);
                   });
  encoder.optional(capabilities.unit_cube_transform,
                   [&](const UnitCubeCapability& value) {
                     encoder.natural(value.dimension);
                     encoder.enumeration(value.boundary);
                     encoder.enumeration(value.inverse_cdf);
                     encoder.enumeration(value.phase_requirement);
                     encoder.enumeration(value.provision);
                   });
  // Preserve the frozen v1 bytes when this in-place extension is absent.
  // The domain tag makes the conditional suffix unambiguous and binds the
  // compact generator fact independently of the legacy joint-table fact.
  if (capabilities.exact_factorized_iid_generator.has_value()) {
    encoder.string(
        "mwperf.arrival.exact_factorized_iid_generator.capability.v1");
    encoder.enumeration(
        capabilities.exact_factorized_iid_generator->provision);
  }
  if (capabilities.exact_portable_iid_recipe.has_value()) {
    encoder.string(
        "mwperf.arrival.exact_portable_iid_recipe.capability.v1");
    encoder.enumeration(capabilities.exact_portable_iid_recipe->provision);
  }
}

[[nodiscard]] Result<Digest256> hash_capability_bytes(
    const std::string_view domain,
    const CapabilityCanonicalEncoder& encoder) {
  return sha256_domain_separated(domain, encoder.bytes());
}

[[nodiscard]] Digest256 zero_digest() {
  static constexpr std::string_view kZeroHex =
      "0000000000000000000000000000000000000000000000000000000000000000";
  Result<Digest256> result = Digest256::from_hex(kZeroHex);
  return std::move(result).value();
}

template <typename Enum, std::size_t Size>
[[nodiscard]] bool is_closed_enum(
    const Enum value, const std::array<Enum, Size>& values) noexcept {
  return std::find(values.begin(), values.end(), value) != values.end();
}

template <typename Enum>
[[nodiscard]] bool enum_through(const Enum value,
                                const Enum last) noexcept {
  static_assert(std::is_enum_v<Enum>);
  using Underlying = std::underlying_type_t<Enum>;
  using Unsigned = std::make_unsigned_t<Underlying>;
  return static_cast<std::uint64_t>(static_cast<Unsigned>(value)) <=
         static_cast<std::uint64_t>(static_cast<Unsigned>(last));
}

template <typename T>
[[nodiscard]] bool has_duplicates(const std::vector<T>& values) {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    for (std::size_t right = left + 1U; right < values.size(); ++right) {
      if (values[left] == values[right]) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] bool is_valid_codec(const CodecIdentityV1& codec) noexcept {
  return !codec.id.empty() && codec.version != 0U;
}

[[nodiscard]] bool valid_arrival_assumption_shape(
    const ArrivalAssumptionV1& assumption) {
  if (!enum_through(assumption.kind,
                    ArrivalNeedKindV1::exact_iid_late) ||
      !enum_through(assumption.use,
                    ArrivalCapabilityUseV1::construction) ||
      !enum_through(assumption.provision,
                    CapabilityProvisionNeedV1::process_local)) {
    return false;
  }
  const bool has_any_transform_field =
      assumption.transform_kind.has_value() ||
      assumption.distribution_scope.has_value() ||
      assumption.argument_domain.has_value();
  const bool has_complete_transform =
      assumption.transform_kind.has_value() &&
      assumption.distribution_scope.has_value() &&
      assumption.argument_domain.has_value();
  const bool valid_domain =
      !assumption.argument_domain.has_value() ||
      assumption.argument_domain->lower < assumption.argument_domain->upper ||
      (assumption.argument_domain->lower ==
           assumption.argument_domain->upper &&
       assumption.argument_domain->lower_inclusive &&
       assumption.argument_domain->upper_inclusive);
  if (assumption.moment_order.has_value() &&
      assumption.moment_order->is_zero()) {
    return false;
  }
  switch (assumption.kind) {
    case ArrivalNeedKindV1::target_intensity:
      return !assumption.moment_order.has_value() &&
             !has_any_transform_field && !assumption.joint &&
             !assumption.phase_conditioned;
    case ArrivalNeedKindV1::arrival_moment:
      return assumption.moment_order.has_value() &&
             !has_any_transform_field;
    case ArrivalNeedKindV1::transform:
      return !assumption.moment_order.has_value() &&
             has_complete_transform && valid_domain &&
             enum_through(*assumption.transform_kind,
                          TransformKind::closed_transform) &&
             enum_through(*assumption.distribution_scope,
                          DistributionScope::per_coordinate);
    case ArrivalNeedKindV1::full_common_batch:
    case ArrivalNeedKindV1::predictive_phase:
    case ArrivalNeedKindV1::sequential_law:
    case ArrivalNeedKindV1::entrance_labels:
    case ArrivalNeedKindV1::finite_support:
    case ArrivalNeedKindV1::exact_iid_late:
      return !assumption.moment_order.has_value() &&
             !has_any_transform_field && !assumption.phase_conditioned;
  }
  return false;
}

[[nodiscard]] bool valid_hypothesis_shape(
    const HypothesisClaimV1& claim) {
  if (!enum_through(claim.kind,
                    HypothesisKindV1::c21_suspension_inversion) ||
      (claim.variable.has_value() &&
       !enum_through(*claim.variable, MomentVariableV1::stopped_time)) ||
      (claim.order.has_value() && claim.order->is_zero())) {
    return false;
  }
  if (claim.kind == HypothesisKindV1::moment_finite ||
      claim.kind == HypothesisKindV1::reward_integrable) {
    return claim.variable.has_value() && claim.order.has_value() &&
           !claim.convention_or_class.has_value();
  }
  if (claim.variable.has_value() || claim.order.has_value()) {
    return false;
  }
  if (claim.kind ==
      HypothesisKindV1::counterfactual_empty_convention) {
    return claim.convention_or_class.has_value();
  }
  switch (claim.kind) {
    case HypothesisKindV1::proper_stationary:
    case HypothesisKindV1::invariant_selected:
    case HypothesisKindV1::stable:
    case HypothesisKindV1::recurrent:
    case HypothesisKindV1::eventual_departure_or_accessible_class:
    case HypothesisKindV1::positive_conditioning_mass:
    case HypothesisKindV1::finite_start_component:
    case HypothesisKindV1::absorption:
    case HypothesisKindV1::nondefective:
      return true;
    case HypothesisKindV1::lossless:
    case HypothesisKindV1::unit_packets:
    case HypothesisKindV1::fifo:
    case HypothesisKindV1::positive_finite_intensity:
    case HypothesisKindV1::positive_event_intensity:
    case HypothesisKindV1::positive_start_intensity:
    case HypothesisKindV1::little_law:
    case HypothesisKindV1::common_schedule:
    case HypothesisKindV1::predictive_phase:
    case HypothesisKindV1::iid_late_arrival:
    case HypothesisKindV1::counterfactual_no_controller_mutation:
    case HypothesisKindV1::c21_suspension_inversion:
      return !claim.convention_or_class.has_value();
    case HypothesisKindV1::moment_finite:
    case HypothesisKindV1::reward_integrable:
    case HypothesisKindV1::counterfactual_empty_convention:
      break;
  }
  return false;
}

[[nodiscard]] bool valid_monte_carlo_contract(
    const MonteCarloAccuracyV1& contract);

[[nodiscard]] bool valid_accuracy_shape(
    const AccuracyContractV1& accuracy) {
  return std::visit(
      [](const auto& value) {
        using Value = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Value, EnumeratedAccuracyV1>) {
          return strictly_canonical_tolerances(value.tolerances) &&
                 std::all_of(
                     value.tolerances.begin(), value.tolerances.end(),
                     [](const DeterministicToleranceV1& tolerance) {
                       return enum_through(
                                  tolerance.kind,
                                  DeterministicToleranceKindV1::
                                      fixed_point_abs) &&
                              tolerance.maximum_absolute_error.
                                  is_nonnegative();
                     });
        } else if constexpr (std::is_same_v<Value, AnalyticAccuracyV1>) {
          return !value.precision_bits.is_zero() &&
                 strictly_canonical_tolerances(value.tolerances) &&
                 std::all_of(
                     value.tolerances.begin(), value.tolerances.end(),
                     [](const DeterministicToleranceV1& tolerance) {
                       return enum_through(
                                  tolerance.kind,
                                  DeterministicToleranceKindV1::
                                      fixed_point_abs) &&
                              tolerance.maximum_absolute_error.
                                  is_nonnegative();
                     });
        } else if constexpr (std::is_same_v<Value, MonteCarloAccuracyV1>) {
          return !value.replications.is_zero() &&
                 value.confidence_level > ExactRational::zero() &&
                 value.confidence_level < ExactRational::one() &&
                 enum_through(value.interval,
                              StatisticalIntervalKindV1::none) &&
                 enum_through(
                     value.estimand,
                     StatisticalEstimandKindV1::
                         point_with_variance_diagnostics) &&
                 (!value.almost_sure_lower.has_value() ||
                  !value.almost_sure_upper.has_value() ||
                  *value.almost_sure_lower <= *value.almost_sure_upper) &&
                 valid_monte_carlo_contract(value);
        } else {
          static_assert(std::is_same_v<Value, DirectExactAccuracyV1>);
          return true;
        }
      },
      accuracy);
}

[[nodiscard]] bool valid_scheduler_optimizer_pair(
    const SchedulerConstraintPairV1& pair) noexcept {
  switch (pair.service_family) {
    case ServiceFamily::crossbar_matching:
      return pair.optimizer == OptimizerId::hungarian_exact;
    case ServiceFamily::nonoverlapping_intervals:
      return pair.optimizer == OptimizerId::weighted_interval_dp_exact;
    case ServiceFamily::node_exclusive_matching:
      return pair.optimizer == OptimizerId::edmonds_blossom_exact;
    case ServiceFamily::pairwise_conflicts:
      return pair.optimizer == OptimizerId::mwis_branch_memo_exact;
    case ServiceFamily::resource_packing:
      return pair.optimizer == OptimizerId::binary_packing_memo_exact;
  }
  return false;
}

[[nodiscard]] bool valid_mark_reveal_source(
    const MarkDescriptorV1& mark) noexcept {
  const auto ordinary_at_or_after = [&](const MetricRevealStageV1 earliest) {
    return mark.reveal_stage != MetricRevealStageV1::entrance_label &&
           static_cast<std::uint8_t>(mark.reveal_stage) >=
               static_cast<std::uint8_t>(earliest) &&
           static_cast<std::uint8_t>(mark.reveal_stage) <=
               static_cast<std::uint8_t>(
                   MetricRevealStageV1::completed_edge);
  };
  switch (mark.kind) {
    case MetricMarkKindV1::target_backlog:
    case MetricMarkKindV1::predictive_phase:
    case MetricMarkKindV1::opportunity:
      return ordinary_at_or_after(MetricRevealStageV1::predecision);
    case MetricMarkKindV1::actual_departure:
    case MetricMarkKindV1::schedule_projection:
    case MetricMarkKindV1::full_schedule:
    case MetricMarkKindV1::counterfactual_permission:
      return ordinary_at_or_after(MetricRevealStageV1::decision);
    case MetricMarkKindV1::arrival_batch:
      return ordinary_at_or_after(MetricRevealStageV1::arrival);
    case MetricMarkKindV1::successor_backlog:
      return ordinary_at_or_after(MetricRevealStageV1::postarrival);
    case MetricMarkKindV1::edge_increment:
    case MetricMarkKindV1::event_indicator:
    case MetricMarkKindV1::predicate:
      return mark.reveal_stage == MetricRevealStageV1::completed_edge;
    case MetricMarkKindV1::predicate_start:
      return mark.reveal_stage == MetricRevealStageV1::completed_edge ||
             mark.reveal_stage == MetricRevealStageV1::entrance_label;
    case MetricMarkKindV1::active_component:
      return ordinary_at_or_after(MetricRevealStageV1::predecision) ||
             mark.reveal_stage == MetricRevealStageV1::entrance_label;
    case MetricMarkKindV1::within_batch_rank:
    case MetricMarkKindV1::batch_size:
    case MetricMarkKindV1::class_label:
    case MetricMarkKindV1::phase_label:
      return mark.reveal_stage == MetricRevealStageV1::entrance_label;
  }
  return false;
}

[[nodiscard]] bool has_duplicate_optional_evidence_kind(
    const std::vector<OptionalReportedEvidenceV1>& values) noexcept {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    for (std::size_t right = left + 1U; right < values.size(); ++right) {
      if (values[left].kind == values[right].kind) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] bool has_canonical_core_set_order(
    const PlugDescriptorCore& core) {
  return strictly_canonical_by(
             core.applicability.scheduler_optimizer_pairs,
             [](CapabilityCanonicalEncoder& encoder,
                const SchedulerConstraintPairV1& pair) {
               encoder.enumeration(pair.service_family);
               encoder.enumeration(pair.optimizer);
             }) &&
         strictly_canonical_by(
             core.applicability.timing_conventions,
             [](CapabilityCanonicalEncoder& encoder,
                const TimingConvention timing) {
               encoder.enumeration(timing);
             }) &&
         strictly_canonical_by(
             core.state_fields,
             [](CapabilityCanonicalEncoder& encoder,
                const StateFieldDescriptorV1& field) {
               encode_state_field(encoder, field);
             }) &&
         strictly_canonical_by(
             core.marks,
             [](CapabilityCanonicalEncoder& encoder,
                const MarkDescriptorV1& mark) { encode_mark(encoder, mark); }) &&
         strictly_canonical_by(
             core.selection.kinds,
             [](CapabilityCanonicalEncoder& encoder,
                const SelectionKindV1 selection) {
               encoder.enumeration(selection);
             }) &&
         strictly_canonical_by(
             core.selection.named_classes,
             [](CapabilityCanonicalEncoder& encoder,
                const TypedLabel& label) { encoder.label(label); }) &&
         strictly_canonical_by(
             core.selection.named_fixed_points,
             [](CapabilityCanonicalEncoder& encoder,
                const TypedLabel& label) { encoder.label(label); }) &&
         strictly_canonical_by(
             core.arrival_assumptions,
             [](CapabilityCanonicalEncoder& encoder,
                const ArrivalAssumptionV1& assumption) {
               encode_arrival_assumption(encoder, assumption);
             }) &&
         strictly_canonical_by(
             core.hypothesis_claims,
             [](CapabilityCanonicalEncoder& encoder,
                const HypothesisClaimV1& hypothesis) {
               encode_hypothesis(encoder, hypothesis);
             }) &&
         strictly_canonical_by(
             core.optional_reported_evidence,
             [](CapabilityCanonicalEncoder& encoder,
                const OptionalReportedEvidenceV1& evidence) {
               encode_optional_evidence(encoder, evidence);
             }) &&
         strictly_canonical_by(
             core.accuracy_support,
             [](CapabilityCanonicalEncoder& encoder,
                const AccuracyContractV1& accuracy) {
               encode_accuracy(encoder, accuracy);
             });
}

[[nodiscard]] bool is_valid_core_shape(const PlugDescriptorCore& core) {
  if (core.schema_version != kCapabilitySchemaVersionV1 ||
      core.provider.provider_id.empty() || core.provider.provider_version.empty() ||
      core.payload_class.version == 0U ||
      !enum_through(core.payload_class.tag,
                    PayloadClassTagV1::empirical_finite_window_response_v1) ||
      !is_closed_enum(core.semantic, kSemanticTagsV1) ||
      !is_closed_enum(core.runtime_access, kRuntimeAccessTagsV1) ||
      !enum_through(core.target_coupling,
                    TargetCouplingV1::full_schedule_identity) ||
      core.applicability.scheduler_optimizer_pairs.empty() ||
      core.applicability.timing_conventions.empty() ||
      has_duplicates(core.applicability.scheduler_optimizer_pairs) ||
      has_duplicates(core.applicability.timing_conventions) ||
      core.deployed_targets.empty() || has_duplicates(core.deployed_targets) ||
      has_duplicates(core.state_fields) || has_duplicates(core.marks) ||
      has_duplicates(core.arrival_assumptions) ||
      has_duplicates(core.hypothesis_claims) ||
      has_duplicates(core.optional_reported_evidence) ||
      has_duplicates(core.accuracy_support) ||
      has_duplicates(core.selection.kinds) ||
      has_duplicates(core.selection.named_classes) ||
      has_duplicates(core.selection.named_fixed_points) ||
      has_duplicate_optional_evidence_kind(
          core.optional_reported_evidence) ||
      !has_canonical_core_set_order(core)) {
    return false;
  }
  // These are mathematical classification constraints, not a strength
  // ordering.  A scalar response (and especially the frozen three-bin scalar
  // payload) cannot be relabelled as a common projected or complete schedule
  // law by changing only descriptor metadata.
  if ((core.semantic == SemanticTagV1::scalar_backlog_response &&
       core.target_coupling != TargetCouplingV1::scalar_target) ||
      ((core.payload_class.tag ==
            PayloadClassTagV1::three_bin_scalar_response_v1 ||
        core.payload_class.tag ==
            PayloadClassTagV1::finite_prefix_constant_tail_response_v1 ||
        core.payload_class.tag ==
            PayloadClassTagV1::empirical_finite_window_response_v1) &&
       (core.semantic != SemanticTagV1::scalar_backlog_response ||
        core.target_coupling != TargetCouplingV1::scalar_target)) ||
      (core.semantic == SemanticTagV1::coupled_target_schedule_law &&
       core.target_coupling == TargetCouplingV1::scalar_target)) {
    return false;
  }
  if (!std::all_of(
          core.applicability.scheduler_optimizer_pairs.begin(),
          core.applicability.scheduler_optimizer_pairs.end(),
          valid_scheduler_optimizer_pair) ||
      !std::all_of(
          core.applicability.timing_conventions.begin(),
          core.applicability.timing_conventions.end(),
          [](const TimingConvention timing) {
            return timing ==
                   TimingConvention::early_service_late_admission;
          })) {
    return false;
  }
  if (!std::all_of(core.state_fields.begin(), core.state_fields.end(),
                   [](const StateFieldDescriptorV1& field) {
                     return enum_through(
                                field.kind,
                                StateFieldKindV1::entrance_label_state) &&
                            enum_through(field.ownership,
                                         FieldOwnershipV1::surrogate_owned) &&
                            is_valid_codec(field.codec);
                   }) ||
      !std::all_of(core.marks.begin(), core.marks.end(),
                   [](const MarkDescriptorV1& mark) {
                     return enum_through(
                                mark.kind,
                                MetricMarkKindV1::
                                    counterfactual_permission) &&
                            enum_through(
                                mark.reveal_stage,
                                MetricRevealStageV1::entrance_label) &&
                            is_valid_codec(mark.codec) &&
                            valid_mark_reveal_source(mark);
                   })) {
    return false;
  }
  for (std::size_t left = 0U; left < core.state_fields.size(); ++left) {
    for (std::size_t right = left + 1U; right < core.state_fields.size();
         ++right) {
      if (core.state_fields[left].kind == core.state_fields[right].kind) {
        return false;
      }
    }
  }
  for (std::size_t left = 0U; left < core.marks.size(); ++left) {
    for (std::size_t right = left + 1U; right < core.marks.size(); ++right) {
      if (core.marks[left].kind == core.marks[right].kind) {
        return false;
      }
    }
  }
  if (!std::all_of(core.selection.kinds.begin(),
                   core.selection.kinds.end(),
                   [](const SelectionKindV1 selection) {
                     return enum_through(
                         selection,
                         SelectionKindV1::threshold_crossing_palm);
                   }) ||
      !enum_through(core.phase.payload_phase,
                    PayloadPhaseKindV1::predictive_phase_indexed) ||
      !enum_through(core.phase.arrival_composition,
                    ConfiguredArrivalCompositionV1::
                        sequential_predictive_phase) ||
      !enum_through(core.phase.finite_horizon_coverage,
                    FiniteHorizonCoverageKindV1::every_finite_horizon) ||
      !enum_through(core.tail.kind,
                    TailRepresentationKindV1::exact_unbounded) ||
      !std::all_of(core.arrival_assumptions.begin(),
                   core.arrival_assumptions.end(),
                   valid_arrival_assumption_shape) ||
      !std::all_of(core.hypothesis_claims.begin(),
                   core.hypothesis_claims.end(), valid_hypothesis_shape) ||
      !std::all_of(core.accuracy_support.begin(),
                   core.accuracy_support.end(), valid_accuracy_shape)) {
    return false;
  }
  switch (core.tail.kind) {
    case TailRepresentationKindV1::none:
    case TailRepresentationKindV1::exact_unbounded:
      if (core.tail.boundary.has_value() ||
          core.tail.certified_tail_mass.has_value()) {
        return false;
      }
      break;
    case TailRepresentationKindV1::finite_closed:
    case TailRepresentationKindV1::constant_response:
      if (!core.tail.boundary.has_value() ||
          core.tail.certified_tail_mass.has_value()) {
        return false;
      }
      break;
    case TailRepresentationKindV1::certified_truncation:
      if (!core.tail.boundary.has_value() ||
          !core.tail.certified_tail_mass.has_value() ||
          !core.tail.certified_tail_mass->is_nonnegative() ||
          *core.tail.certified_tail_mass > ExactRational::one()) {
        return false;
      }
      break;
  }
  if (core.phase.retains_configured_predictive_phase !=
      core.phase.predictive_phase_codec.has_value()) {
    return false;
  }
  if (core.phase.predictive_phase_codec.has_value() &&
      !is_valid_codec(*core.phase.predictive_phase_codec)) {
    return false;
  }
  if (core.phase.finite_horizon_coverage ==
          FiniteHorizonCoverageKindV1::bounded &&
      !core.phase.maximum_finite_horizon.has_value()) {
    return false;
  }
  if (core.phase.finite_horizon_coverage !=
          FiniteHorizonCoverageKindV1::bounded &&
      core.phase.maximum_finite_horizon.has_value()) {
    return false;
  }
  if (core.mandatory_v0.kind ==
          V0DeclarationKindV1::structural_witness_required &&
      (core.mandatory_v0.factor_schema_id.empty() ||
       core.mandatory_v0.factor_schema_version == 0U)) {
    return false;
  }
  if (!enum_through(core.mandatory_v0.kind,
                    V0DeclarationKindV1::structural_witness_required) ||
      !std::all_of(
          core.optional_reported_evidence.begin(),
          core.optional_reported_evidence.end(),
          [](const OptionalReportedEvidenceV1& evidence) {
            return enum_through(
                       evidence.kind,
                       OptionalReportedEvidenceKindV1::empirical_validation) &&
                   !evidence.witness_schema_id.empty() &&
                   evidence.witness_schema_version != 0U;
          }) ||
      !enum_through(core.construction_scope.result_scope,
                    ConstructionResultScopeV1::physical_bound) ||
      !enum_through(core.construction_scope.error_scope,
                    ConstructionErrorScopeV1::physical_system)) {
    return false;
  }
  return true;
}

[[nodiscard]] MetricResultScopeV1 manifest_result_scope(
    const ConstructionResultScopeV1 scope) noexcept {
  switch (scope) {
    case ConstructionResultScopeV1::not_applicable:
    case ConstructionResultScopeV1::not_a_metric_result:
      return MetricResultScopeV1::not_a_metric_result;
    case ConstructionResultScopeV1::surrogate_law:
      return MetricResultScopeV1::surrogate_law;
    case ConstructionResultScopeV1::proposal_raw:
      return MetricResultScopeV1::proposal_raw;
    case ConstructionResultScopeV1::response_envelope:
      return MetricResultScopeV1::response_envelope;
    case ConstructionResultScopeV1::physical_bound:
      return MetricResultScopeV1::physical_bound;
  }
  return MetricResultScopeV1::not_a_metric_result;
}

[[nodiscard]] MetricEvidenceScopeV1 manifest_evidence_scope(
    const ConstructionErrorScopeV1 scope) noexcept {
  switch (scope) {
    case ConstructionErrorScopeV1::none:
      return MetricEvidenceScopeV1::none;
    case ConstructionErrorScopeV1::raw_static_proposal:
      return MetricEvidenceScopeV1::raw_static_proposal;
    case ConstructionErrorScopeV1::nominal_static_proposal:
      return MetricEvidenceScopeV1::nominal_static_proposal;
    case ConstructionErrorScopeV1::projection_center:
      return MetricEvidenceScopeV1::projection_center;
    case ConstructionErrorScopeV1::projected_surrogate_mean:
      return MetricEvidenceScopeV1::projected_surrogate_mean;
    case ConstructionErrorScopeV1::recoded_static_proposal:
      return MetricEvidenceScopeV1::recoded_static_proposal;
    case ConstructionErrorScopeV1::optimizer_interval_raw:
      return MetricEvidenceScopeV1::optimizer_interval_raw;
    case ConstructionErrorScopeV1::deployed_surrogate_law:
      return MetricEvidenceScopeV1::deployed_surrogate_law;
    case ConstructionErrorScopeV1::numerical_result:
      return MetricEvidenceScopeV1::numerical_result;
    case ConstructionErrorScopeV1::validity_or_lift:
      return MetricEvidenceScopeV1::validity_or_lift;
    case ConstructionErrorScopeV1::physical_system:
      return MetricEvidenceScopeV1::physical_system;
  }
  return MetricEvidenceScopeV1::none;
}

[[nodiscard]] bool manifest_realizes_construction_scope(
    const MetricSupportManifest& manifest,
    const ConstructionScopeClaimV1& construction_scope) {
  const MetricResultScopeV1 expected_result =
      manifest_result_scope(construction_scope.result_scope);
  const MetricEvidenceScopeV1 expected_evidence =
      manifest_evidence_scope(construction_scope.error_scope);
  return std::all_of(
      manifest.clauses().begin(), manifest.clauses().end(),
      [&](const MetricSupportClauseV1& clause) {
        return std::any_of(
            clause.required_roles.begin(), clause.required_roles.end(),
            [&](const MetricSupportRoleRequirementV1& role) {
              return role.result_scope == expected_result &&
                     role.evidence_scope == expected_evidence;
            });
      });
}

[[nodiscard]] std::optional<std::string> preview_integrity_problem(
    const PlugDescriptorPreview& preview) {
  if (preview.schema_version != kCapabilitySchemaVersionV1) {
    return "preview schema_version is not analysis-v1";
  }
  if (!is_valid_core_shape(preview.core)) {
    return "descriptor core is malformed or contains a non-v1 closed value";
  }
  if (!enum_through(preview.construction_method,
                    ConstructionMethodV1::precomputed) ||
      !enum_through(preview.producer_mode,
                    ProducerModeV1::local_executable_builder) ||
      !enum_through(preview.policies.point_deployment,
                    PointDeploymentPolicyV1::deploy_recoded_point) ||
      !enum_through(
          preview.policies.coefficient_completion,
          CoefficientCompletionPolicyV1::authorized_endpoint_completion) ||
      !enum_through(preview.policies.projection,
                    ProjectionPolicyV1::convex_feasible_mean) ||
      !enum_through(preview.policies.recoding,
                    RecodingPolicyV1::mean_inversion) ||
      !enum_through(preview.policies.evidence_roles,
                    EvidenceRolePolicyV1::exact_manifest_roles) ||
      !std::all_of(preview.construction_prerequisites.arrival.begin(),
                   preview.construction_prerequisites.arrival.end(),
                   [](const ArrivalAssumptionV1& assumption) {
                     return valid_arrival_assumption_shape(assumption) &&
                            assumption.use ==
                                ArrivalCapabilityUseV1::construction;
                   }) ||
      !strictly_canonical_by(
          preview.construction_prerequisites.arrival,
          [](CapabilityCanonicalEncoder& encoder,
             const ArrivalAssumptionV1& assumption) {
            encode_arrival_assumption(encoder, assumption);
          })) {
    return "preview contains an invalid closed construction or policy value";
  }
  if (!preview.metric_support_manifest) {
    return "preview has no structural metric-support manifest";
  }

  std::vector<MetricSupportClauseV1> clauses(
      preview.metric_support_manifest->clauses().begin(),
      preview.metric_support_manifest->clauses().end());
  Result<MetricSupportManifest> rebuilt =
      MetricSupportManifest::from_clauses(std::move(clauses));
  if (!rebuilt || !(rebuilt.value() == *preview.metric_support_manifest) ||
      rebuilt.value().canonical_digest() !=
          preview.metric_support_manifest->canonical_digest()) {
    return "structural metric-support manifest is not canonical";
  }
  if (preview.core.metric_support_manifest_digest !=
      preview.metric_support_manifest->canonical_digest()) {
    return "descriptor core does not bind the supplied manifest digest";
  }
  if (!manifest_realizes_construction_scope(
          *preview.metric_support_manifest,
          preview.core.construction_scope)) {
    return "descriptor construction scope is absent from a manifest clause";
  }

  CapabilityCanonicalEncoder core_bytes;
  encode_core_without_digest(core_bytes, preview.core);
  Result<Digest256> expected_core = hash_capability_bytes(
      "mwperf.c14.plug_descriptor_core.v1", core_bytes);
  if (!expected_core || expected_core.value() != preview.core.core_digest) {
    return "descriptor core digest does not match its canonical value";
  }

  CapabilityCanonicalEncoder preview_bytes;
  encode_preview_without_digest(preview_bytes, preview);
  Result<Digest256> expected_preview = hash_capability_bytes(
      "mwperf.c14.plug_descriptor_preview.v1", preview_bytes);
  if (!expected_preview || expected_preview.value() != preview.preview_digest) {
    return "preview digest does not match its canonical value";
  }
  return std::nullopt;
}

[[nodiscard]] std::string enum_text(const std::uint64_t value) {
  return std::to_string(value);
}

template <typename Enum>
[[nodiscard]] std::string enum_text(const Enum value)
  requires std::is_enum_v<Enum>
{
  using Underlying = std::underlying_type_t<Enum>;
  return enum_text(static_cast<std::uint64_t>(
      static_cast<std::make_unsigned_t<Underlying>>(value)));
}

[[nodiscard]] std::optional<std::string> authored_path(
    const MetricRequirementClause& clause) {
  if (clause.origin.provenance.location.has_value()) {
    return clause.origin.provenance.location->authored_path;
  }
  return std::nullopt;
}

[[nodiscard]] CapabilityFailureV1 make_failure(
    const MetricRequirementClause& clause, const CapabilityAxisV1 axis,
    const CapabilityFailureKindV1 kind, std::string provided,
    std::string required) {
  return CapabilityFailureV1{
      clause.origin.clause_id.authored_index,
      clause.origin.clause_id,
      clause.origin.clause_id.metric_id,
      axis,
      kind,
      std::move(provided),
      std::move(required),
      authored_path(clause),
      clause.origin.provenance.json_pointer.empty()
          ? std::nullopt
          : std::optional<std::string>{clause.origin.provenance.json_pointer}};
}

[[nodiscard]] std::vector<const MetricRequirementClause*>
clauses_in_authored_order(const MetricRequirements& requirements) {
  const std::span<const MetricRequirementClause> requirement_clauses =
      requirements.clauses();
  std::vector<const MetricRequirementClause*> ordered;
  ordered.reserve(requirement_clauses.size());
  for (const MetricClauseIdV1& id :
       requirements.authored_diagnostic_order()) {
    const auto iterator = std::find_if(
        requirement_clauses.begin(), requirement_clauses.end(),
        [&](const MetricRequirementClause& clause) {
          return clause.origin.clause_id == id;
        });
    if (iterator != requirement_clauses.end() &&
        std::find(ordered.begin(), ordered.end(), &*iterator) == ordered.end()) {
      ordered.push_back(&*iterator);
    }
  }
  std::vector<const MetricRequirementClause*> remainder;
  for (const MetricRequirementClause& clause : requirement_clauses) {
    if (std::find(ordered.begin(), ordered.end(), &clause) == ordered.end()) {
      remainder.push_back(&clause);
    }
  }
  std::sort(remainder.begin(), remainder.end(),
            [](const MetricRequirementClause* left,
               const MetricRequirementClause* right) {
              return left->origin.clause_id < right->origin.clause_id;
            });
  ordered.insert(ordered.end(), remainder.begin(), remainder.end());
  return ordered;
}

[[nodiscard]] const MetricSupportClauseV1* find_manifest_clause(
    const MetricSupportManifest& manifest, const MetricClauseIdV1& id) {
  const auto clauses = manifest.clauses();
  const auto iterator = std::find_if(
      clauses.begin(), clauses.end(), [&](const MetricSupportClauseV1& clause) {
        return clause.clause_id == id;
      });
  return iterator == clauses.end() ? nullptr : &*iterator;
}

[[nodiscard]] bool contains_queue(const std::vector<QueueId>& values,
                                  const QueueId& sought) {
  return std::find(values.begin(), values.end(), sought) != values.end();
}

[[nodiscard]] std::vector<QueueId> request_target_ids(
    const MetricRequirementClause& clause) {
  std::vector<QueueId> result;
  result.reserve(clause.origin.ordered_targets.size());
  for (const ResolvedMetricTargetV1& target : clause.origin.ordered_targets) {
    result.push_back(target.queue_id);
  }
  return result;
}

[[nodiscard]] int coupling_rank(const TargetCouplingV1 coupling) noexcept {
  switch (coupling) {
    case TargetCouplingV1::scalar_target:
      return 0;
    case TargetCouplingV1::common_schedule_projection:
      return 1;
    case TargetCouplingV1::full_schedule_identity:
      return 2;
  }
  return -1;
}

[[nodiscard]] bool coupling_satisfies(const TargetCouplingV1 offered,
                                      const TargetCouplingV1 required) noexcept {
  return coupling_rank(offered) >= coupling_rank(required);
}

[[nodiscard]] bool parameter_domain_contains(
    const MetricParameterDomainV1& domain,
    const MetricRequestParametersV1& parameters,
    const bool direct_exact) {
  MetricRequestParametersV1 canonical_request = parameters;
  if (!c14_canonicalize_exact_parameter(canonical_request)) {
    return false;
  }
  const auto matches_canonical_request =
      [&](const MetricRequestParametersV1& offered) {
        MetricRequestParametersV1 canonical_offered = offered;
        return c14_canonicalize_exact_parameter(canonical_offered) &&
               canonical_offered == canonical_request;
      };
  if (direct_exact) {
    const auto* exact = std::get_if<ExactMetricDecoderDomainV1>(&domain);
    return exact != nullptr &&
           matches_canonical_request(exact->exact_parameters);
  }
  const auto* set = std::get_if<ExactMetricParameterSetV1>(&domain);
  return set != nullptr &&
         std::any_of(set->values.begin(), set->values.end(),
                     matches_canonical_request);
}

[[nodiscard]] bool ordinary_reveal_stage_satisfies(
    const MetricRevealStageV1 offered,
    const MetricRevealStageV1 latest) noexcept {
  if (offered == MetricRevealStageV1::entrance_label ||
      latest == MetricRevealStageV1::entrance_label) {
    return offered == latest;
  }
  return static_cast<std::uint8_t>(offered) <=
         static_cast<std::uint8_t>(latest);
}

[[nodiscard]] const MarkDescriptorV1* find_mark(
    const std::vector<MarkDescriptorV1>& marks,
    const MarkRequirementV1& requirement) {
  const auto iterator = std::find_if(
      marks.begin(), marks.end(), [&](const MarkDescriptorV1& mark) {
        const bool canonical_fifo_label =
            (requirement.kind != MetricMarkKindV1::class_label &&
             requirement.kind != MetricMarkKindV1::phase_label) ||
            mark.codec ==
                CodecIdentityV1{"mwperf.c23.typed_label", 1U};
        return mark.kind == requirement.kind &&
               ordinary_reveal_stage_satisfies(mark.reveal_stage,
                                                requirement.latest_reveal_stage) &&
               is_valid_codec(mark.codec) && canonical_fifo_label;
      });
  return iterator == marks.end() ? nullptr : &*iterator;
}

[[nodiscard]] bool marks_satisfy(
    const std::vector<MarkDescriptorV1>& marks,
    const std::vector<MarkRequirementV1>& requirements,
    CapabilityFailureKindV1* failed_kind = nullptr) {
  std::optional<std::string> common_group;
  for (const MarkRequirementV1& requirement : requirements) {
    const MarkDescriptorV1* offered = find_mark(marks, requirement);
    if (offered == nullptr) {
      if (failed_kind != nullptr) {
        const bool kind_exists = std::any_of(
            marks.begin(), marks.end(), [&](const MarkDescriptorV1& mark) {
              return mark.kind == requirement.kind;
            });
        *failed_kind = kind_exists
                           ? CapabilityFailureKindV1::reveal_stage_too_late
                           : CapabilityFailureKindV1::missing_mark;
      }
      return false;
    }
    if (requirement.relation == MarkRelationRequirementV1::individual) {
      continue;
    }
    if (offered->common_realization_group.empty()) {
      if (failed_kind != nullptr) {
        *failed_kind =
            CapabilityFailureKindV1::marks_not_from_common_realization;
      }
      return false;
    }
    if (!common_group.has_value()) {
      common_group = offered->common_realization_group;
    } else if (*common_group != offered->common_realization_group) {
      if (failed_kind != nullptr) {
        *failed_kind =
            CapabilityFailureKindV1::marks_not_from_common_realization;
      }
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool state_fields_cover_phase(
    const PhaseSupportV1& phase,
    const std::vector<StateFieldDescriptorV1>& state_fields) {
  if (!phase.retains_configured_predictive_phase) {
    return false;
  }
  return std::any_of(
      state_fields.begin(), state_fields.end(),
      [&](const StateFieldDescriptorV1& field) {
        return field.kind ==
                   StateFieldKindV1::configured_arrival_predictive_phase &&
               field.ownership == FieldOwnershipV1::framework_exact &&
               is_valid_codec(field.codec) &&
               phase.predictive_phase_codec.has_value() &&
               field.codec == *phase.predictive_phase_codec;
      });
}

[[nodiscard]] bool selection_contains(
    const SelectionSupportV1& support, const SelectionKindV1 kind) {
  return std::find(support.kinds.begin(), support.kinds.end(), kind) !=
         support.kinds.end();
}

[[nodiscard]] SelectionKindV1 analysis_selection_kind(
    const MetricSelectionRegimeV1 selection) noexcept {
  switch (selection) {
    case MetricSelectionRegimeV1::transient:
      return SelectionKindV1::transient_initial;
    case MetricSelectionRegimeV1::stationary_unique:
      return SelectionKindV1::stationary_unique;
    case MetricSelectionRegimeV1::stationary_class:
      return SelectionKindV1::stationary_class;
    case MetricSelectionRegimeV1::stationary_mixture:
      return SelectionKindV1::stationary_mixture;
    case MetricSelectionRegimeV1::fixed_point_unique:
      return SelectionKindV1::fixed_point_unique;
    case MetricSelectionRegimeV1::fixed_point_id:
      return SelectionKindV1::fixed_point_id;
  }
  return SelectionKindV1::transient_initial;
}

[[nodiscard]] std::optional<SelectionKindV1> entrance_selection_kind(
    const EntranceLawRequirementV1 entrance) noexcept {
  switch (entrance) {
    case EntranceLawRequirementV1::none:
      return std::nullopt;
    case EntranceLawRequirementV1::configured_transient_initial:
      return SelectionKindV1::transient_initial;
    case EntranceLawRequirementV1::prescribed_entrance:
      return SelectionKindV1::prescribed_entrance;
    case EntranceLawRequirementV1::event_palm:
      return SelectionKindV1::event_palm;
    case EntranceLawRequirementV1::run_start_palm:
      return SelectionKindV1::start_palm;
    case EntranceLawRequirementV1::admission_palm:
      return SelectionKindV1::admission_palm;
    case EntranceLawRequirementV1::threshold_crossing_palm:
      return SelectionKindV1::threshold_crossing_palm;
  }
  return std::nullopt;
}

[[nodiscard]] bool selection_names_satisfy(
    const MetricRequirementClause& clause,
    const SelectionSupportV1& support) {
  if (!clause.origin.context) {
    return false;
  }
  return std::visit(
      [&](const auto& selection) {
        using Selection = std::decay_t<decltype(selection)>;
        if constexpr (std::is_same_v<Selection, StationaryClassSelection>) {
          return std::find(support.named_classes.begin(),
                           support.named_classes.end(), selection.class_id) !=
                 support.named_classes.end();
        } else if constexpr (
            std::is_same_v<Selection, StationaryMixtureSelection>) {
          return std::all_of(
              selection.components.begin(), selection.components.end(),
              [&](const StationaryMixtureComponent& component) {
                return std::find(support.named_classes.begin(),
                                 support.named_classes.end(),
                                 component.class_id) !=
                       support.named_classes.end();
              });
        } else if constexpr (std::is_same_v<Selection, FixedPointSelection>) {
          return std::visit(
              [&](const auto& fixed) {
                using Fixed = std::decay_t<decltype(fixed)>;
                if constexpr (std::is_same_v<Fixed,
                                             FixedPointIdSelection>) {
                  return std::find(support.named_fixed_points.begin(),
                                   support.named_fixed_points.end(),
                                   fixed.solution_id) !=
                         support.named_fixed_points.end();
                }
                return true;
              },
              selection);
        }
        return true;
      },
      clause.origin.context->selection);
}

[[nodiscard]] bool selection_satisfies(
    const MetricRequirementClause& clause,
    const SemanticContractAlternativeV1& semantic,
    const SelectionSupportV1& support) {
  if (!selection_contains(support,
                          analysis_selection_kind(
                              clause.origin.selection_regime)) ||
      !selection_names_satisfy(clause, support)) {
    return false;
  }
  const std::optional<SelectionKindV1> entrance =
      entrance_selection_kind(semantic.entrance);
  return !entrance.has_value() || selection_contains(support, *entrance);
}

[[nodiscard]] bool domain_contains(const ExactArgumentDomain& offered,
                                   const ExactArgumentDomain& required) {
  if (offered.lower > required.lower || offered.upper < required.upper) {
    return false;
  }
  if (offered.lower == required.lower && required.lower_inclusive &&
      !offered.lower_inclusive) {
    return false;
  }
  if (offered.upper == required.upper && required.upper_inclusive &&
      !offered.upper_inclusive) {
    return false;
  }
  return true;
}

[[nodiscard]] bool provision_satisfies(
    const AccessProvision offered,
    const CapabilityProvisionNeedV1 required) noexcept {
  switch (required) {
    case CapabilityProvisionNeedV1::any:
      return true;
    case CapabilityProvisionNeedV1::portable:
      return offered == AccessProvision::portable_only ||
             offered == AccessProvision::portable_and_process_local;
    case CapabilityProvisionNeedV1::process_local:
      return offered == AccessProvision::process_local_only ||
             offered == AccessProvision::portable_and_process_local;
  }
  return false;
}

[[nodiscard]] bool moment_capability_satisfies(
    const MomentCapability& capability,
    const ArrivalAssumptionV1& requirement) {
  if (!provision_satisfies(capability.provision, requirement.provision) ||
      (requirement.joint && !capability.joint) ||
      (requirement.phase_conditioned &&
       !capability.conditioned_on_phase)) {
    return false;
  }
  if (requirement.moment_order.has_value() &&
      capability.maximum_order.has_value() &&
      *capability.maximum_order < *requirement.moment_order) {
    return false;
  }
  return true;
}

[[nodiscard]] bool transform_capability_satisfies(
    const TransformCapability& capability,
    const ArrivalAssumptionV1& requirement) {
  if (!provision_satisfies(capability.provision, requirement.provision)) {
    return false;
  }
  if (requirement.transform_kind.has_value() &&
      capability.kind != *requirement.transform_kind) {
    return false;
  }
  if (requirement.distribution_scope.has_value() &&
      capability.scope != *requirement.distribution_scope) {
    return false;
  }
  if (requirement.phase_conditioned &&
      capability.phase_requirement !=
          PhaseArgumentRequirement::explicit_phase_required) {
    return false;
  }
  return !requirement.argument_domain.has_value() ||
         domain_contains(capability.domain, *requirement.argument_domain);
}

[[nodiscard]] bool valid_exact_domain(const ExactArgumentDomain& domain) {
  return domain.lower < domain.upper ||
         (domain.lower == domain.upper && domain.lower_inclusive &&
          domain.upper_inclusive);
}

[[nodiscard]] bool valid_transform_capability(
    const TransformCapability& capability) {
  return enum_through(capability.kind, TransformKind::closed_transform) &&
         enum_through(capability.scope, DistributionScope::per_coordinate) &&
         valid_exact_domain(capability.domain) &&
         enum_through(capability.phase_requirement,
                      PhaseArgumentRequirement::explicit_phase_required) &&
         capability.provision == AccessProvision::portable_only;
}

[[nodiscard]] bool valid_moment_capability(
    const MomentCapability& capability) {
  // Mirror C09's frozen portable moment carrier.  C14 consumes the exact C09
  // record; it must not reinterpret an impossible infinite-order,
  // phase-conditioned, zero-order, or beyond-second-order table as a valid
  // capability merely because the malformed field is unused by one route.
  return capability.provision == AccessProvision::portable_only &&
         capability.maximum_order.has_value() &&
         !capability.maximum_order->is_zero() &&
         capability.maximum_order->value() <= 2 &&
         !capability.conditioned_on_phase;
}

[[nodiscard]] bool valid_arrival_capabilities(
    const ArrivalCapabilities& capabilities) {
  const auto valid_availability = [](const CapabilityAvailability value) {
    return enum_through(value, CapabilityAvailability::available);
  };
  if (capabilities.version != kCapabilitySchemaVersionV1 ||
      capabilities.exact_positive_support !=
          CapabilityAvailability::available ||
      !valid_availability(capabilities.sequential_normalized_sampler) ||
      !valid_availability(
          capabilities.finite_enumerated_predictive_phase) ||
      !valid_availability(
          capabilities.finite_enumerated_transition_row) ||
      !enum_through(capabilities.stationary_phase_law,
                    StationaryPhaseLawStatus::proved_unique) ||
      !valid_availability(capabilities.exact_covariance) ||
      !valid_availability(capabilities.exact_cross_moments)) {
    return false;
  }
  if (capabilities.finite_enumerated_transition_row ==
          CapabilityAvailability::available &&
      capabilities.finite_enumerated_predictive_phase !=
          CapabilityAvailability::available) {
    return false;
  }
  if ((capabilities.analytic_transform.has_value() &&
       !valid_transform_capability(*capabilities.analytic_transform)) ||
      (capabilities.exact_joint_distribution.has_value() &&
       (!valid_transform_capability(
            *capabilities.exact_joint_distribution) ||
        capabilities.exact_joint_distribution->scope !=
            DistributionScope::joint_vector)) ||
      (capabilities.exact_coordinate_distributions.has_value() &&
       (!valid_transform_capability(
            *capabilities.exact_coordinate_distributions) ||
        capabilities.exact_coordinate_distributions->scope !=
            DistributionScope::per_coordinate)) ||
      (capabilities.analytic_moments.has_value() &&
       !valid_moment_capability(*capabilities.analytic_moments)) ||
      (capabilities.exact_joint_moments.has_value() &&
       (!valid_moment_capability(*capabilities.exact_joint_moments) ||
        !capabilities.exact_joint_moments->joint)) ||
      (capabilities.exact_coordinate_moments.has_value() &&
       (!valid_moment_capability(
            *capabilities.exact_coordinate_moments) ||
        capabilities.exact_coordinate_moments->joint))) {
    return false;
  }
  if (capabilities.exact_iid_joint_vector.has_value() &&
      (!capabilities.exact_iid_joint_vector->finite_support ||
       capabilities.exact_iid_joint_vector->provision !=
           AccessProvision::portable_only)) {
    return false;
  }
  if (capabilities.exact_factorized_iid_generator.has_value() &&
      capabilities.exact_factorized_iid_generator->provision !=
          AccessProvision::portable_only) {
    return false;
  }
  if (capabilities.exact_portable_iid_recipe.has_value() &&
      capabilities.exact_portable_iid_recipe->provision !=
          AccessProvision::portable_only) {
    return false;
  }
  if (capabilities.adjacent_batch_replay.has_value()) {
    const ReplayCapability& replay = *capabilities.adjacent_batch_replay;
    const bool valid_provision = enum_through(
        replay.provision, AccessProvision::portable_and_process_local);
    const bool any_initialization =
        replay.explicit_initial_state || replay.explicit_phase ||
        replay.normalized_initial_law ||
        replay.named_stationary_initialization;
    const bool process_local =
        replay.provision == AccessProvision::process_local_only ||
        replay.provision == AccessProvision::portable_and_process_local;
    if (!valid_provision || !any_initialization ||
        (process_local &&
         capabilities.sequential_normalized_sampler !=
             CapabilityAvailability::available) ||
        (replay.named_stationary_initialization &&
         capabilities.stationary_phase_law ==
             StationaryPhaseLawStatus::unavailable)) {
      return false;
    }
  }
  if (capabilities.unit_cube_transform.has_value() &&
      (capabilities.unit_cube_transform->dimension.is_zero() ||
       !enum_through(capabilities.unit_cube_transform->boundary,
                     UnitCubeBoundary::left_closed_right_open) ||
       !enum_through(capabilities.unit_cube_transform->inverse_cdf,
                     InverseCdfConvention::
                         first_cumulative_mass_strictly_greater) ||
       !enum_through(capabilities.unit_cube_transform->phase_requirement,
                     PhaseArgumentRequirement::explicit_phase_required) ||
       !enum_through(capabilities.unit_cube_transform->provision,
                     AccessProvision::portable_and_process_local))) {
    return false;
  }
  return true;
}

[[nodiscard]] bool bare_capability_satisfies(
    const CapabilityAvailability availability,
    const AccessProvision provision,
    const ArrivalAssumptionV1& requirement) noexcept {
  return availability == CapabilityAvailability::available &&
         provision_satisfies(provision, requirement.provision);
}

[[nodiscard]] bool has_finite_enumerated_arrival(
    const ArrivalCapabilities& capabilities) noexcept {
  return capabilities.finite_enumerated_predictive_phase ==
             CapabilityAvailability::available &&
         capabilities.finite_enumerated_transition_row ==
             CapabilityAvailability::available;
}

[[nodiscard]] bool configured_arrival_composition_satisfies(
    const ArrivalCapabilities& capabilities,
    const ConfiguredArrivalCompositionV1 composition) noexcept {
  switch (composition) {
    case ConfiguredArrivalCompositionV1::no_arrival_composition:
      return true;
    case ConfiguredArrivalCompositionV1::iid_late_arrival:
      return capabilities.exact_iid_joint_vector.has_value() ||
             capabilities.exact_factorized_iid_generator.has_value() ||
             capabilities.exact_portable_iid_recipe.has_value();
    case ConfiguredArrivalCompositionV1::finite_enumerated_predictive_phase:
      return has_finite_enumerated_arrival(capabilities);
    case ConfiguredArrivalCompositionV1::sequential_predictive_phase:
      return capabilities.sequential_normalized_sampler ==
             CapabilityAvailability::available;
  }
  return false;
}

[[nodiscard]] bool arrival_capability_satisfies(
    const ArrivalCapabilities& capabilities,
    const ArrivalAssumptionV1& requirement) {
  // C09's four closed availability flags predate AccessProvision.  Their
  // provision is fixed here rather than inferred from another flag:
  // structural support/finite phase/finite rows are portable, while the
  // sequential cursor is process-local.  Capabilities with authored
  // provision fields are always checked through that explicit field.
  constexpr AccessProvision kPortable = AccessProvision::portable_only;
  constexpr AccessProvision kProcessLocal =
      AccessProvision::process_local_only;
  constexpr AccessProvision kBoth =
      AccessProvision::portable_and_process_local;

  switch (requirement.kind) {
    case ArrivalNeedKindV1::target_intensity: {
      ArrivalAssumptionV1 order_one = requirement;
      order_one.moment_order = BigNat{1U};
      if (capabilities.exact_coordinate_moments.has_value() &&
          moment_capability_satisfies(
              *capabilities.exact_coordinate_moments, order_one)) {
        return true;
      }
      return capabilities.analytic_moments.has_value() &&
             moment_capability_satisfies(*capabilities.analytic_moments,
                                         order_one);
    }
    case ArrivalNeedKindV1::arrival_moment: {
      const std::optional<MomentCapability>& exact =
          requirement.joint ? capabilities.exact_joint_moments
                            : capabilities.exact_coordinate_moments;
      if (exact.has_value() &&
          moment_capability_satisfies(*exact, requirement)) {
        return true;
      }
      return capabilities.analytic_moments.has_value() &&
             moment_capability_satisfies(*capabilities.analytic_moments,
                                         requirement);
    }
    case ArrivalNeedKindV1::full_common_batch:
      if (capabilities.exact_iid_joint_vector.has_value() &&
          provision_satisfies(
              capabilities.exact_iid_joint_vector->provision,
              requirement.provision)) {
        return true;
      }
      if (capabilities.exact_portable_iid_recipe.has_value() &&
          provision_satisfies(
              capabilities.exact_portable_iid_recipe->provision,
              requirement.provision)) {
        return true;
      }
      if (has_finite_enumerated_arrival(capabilities) &&
          provision_satisfies(kPortable, requirement.provision)) {
        return true;
      }
      return bare_capability_satisfies(
          capabilities.sequential_normalized_sampler, kProcessLocal,
          requirement);
    case ArrivalNeedKindV1::predictive_phase:
      return bare_capability_satisfies(
                 capabilities.finite_enumerated_predictive_phase, kPortable,
                 requirement) ||
             bare_capability_satisfies(
                 capabilities.sequential_normalized_sampler, kProcessLocal,
                 requirement);
    case ArrivalNeedKindV1::sequential_law:
      return (has_finite_enumerated_arrival(capabilities) &&
              provision_satisfies(kPortable, requirement.provision)) ||
             bare_capability_satisfies(
                 capabilities.sequential_normalized_sampler, kProcessLocal,
                 requirement);
    case ArrivalNeedKindV1::entrance_labels:
      // Batch size/rank and the true entrance phase are deterministic views
      // of a complete joint arrival realization.  C09's adjacent-replay
      // record describes how construction may reproduce neighboring batches;
      // it is not the sole source of admission labels.  Accept any exact
      // common-batch representation, while retaining replay as an additional
      // construction-capable route.
      if (capabilities.exact_iid_joint_vector.has_value() &&
          provision_satisfies(
              capabilities.exact_iid_joint_vector->provision,
              requirement.provision)) {
        return true;
      }
      if (has_finite_enumerated_arrival(capabilities) &&
          provision_satisfies(kPortable, requirement.provision)) {
        return true;
      }
      if (bare_capability_satisfies(
              capabilities.sequential_normalized_sampler, kProcessLocal,
              requirement)) {
        return true;
      }
      return capabilities.adjacent_batch_replay.has_value() &&
             capabilities.adjacent_batch_replay->explicit_initial_state &&
             provision_satisfies(
                 capabilities.adjacent_batch_replay->provision,
                 requirement.provision);
    case ArrivalNeedKindV1::finite_support:
      // C09's exact_positive_support is only the finite queue-coordinate
      // mask; it is not a claim that the batch/outcome law has finite
      // support.  A finite-support construction request therefore needs an
      // actual finite joint table or finite enumerated phase/row
      // representation.
      return ((capabilities.exact_iid_joint_vector.has_value() &&
               capabilities.exact_iid_joint_vector->finite_support) ||
              has_finite_enumerated_arrival(capabilities)) &&
             provision_satisfies(kPortable, requirement.provision);
    case ArrivalNeedKindV1::transform: {
      const std::array<const std::optional<TransformCapability>*, 3U>
          candidates{&capabilities.analytic_transform,
                     &capabilities.exact_joint_distribution,
                     &capabilities.exact_coordinate_distributions};
      return std::any_of(
          candidates.begin(), candidates.end(),
          [&](const std::optional<TransformCapability>* candidate) {
            return candidate->has_value() &&
                   transform_capability_satisfies(**candidate, requirement);
          });
    }
    case ArrivalNeedKindV1::exact_iid_late:
      // All three witnesses describe the complete joint IID late-arrival law.
      // A factorized generator and a portable recipe avoid materializing the
      // Cartesian table.  The portable-recipe witness makes no within-slot
      // factorization claim, so shared mixed-Poisson dependence remains exact.
      return (capabilities.exact_iid_joint_vector.has_value() &&
              provision_satisfies(
                  capabilities.exact_iid_joint_vector->provision,
                  requirement.provision)) ||
             (capabilities.exact_factorized_iid_generator.has_value() &&
              provision_satisfies(
                  capabilities.exact_factorized_iid_generator->provision,
                  requirement.provision)) ||
             (capabilities.exact_portable_iid_recipe.has_value() &&
              provision_satisfies(
                  capabilities.exact_portable_iid_recipe->provision,
                  requirement.provision));
  }
  static_cast<void>(kBoth);
  return false;
}

[[nodiscard]] bool assumption_satisfies(
    const ArrivalAssumptionV1& offered,
    const ArrivalAssumptionV1& required) {
  if (offered.kind != required.kind || offered.use != required.use ||
      (required.joint && !offered.joint) ||
      (required.phase_conditioned && !offered.phase_conditioned)) {
    return false;
  }
  if (required.provision != CapabilityProvisionNeedV1::any &&
      offered.provision != required.provision) {
    return false;
  }
  if (required.moment_order.has_value() &&
      (!offered.moment_order.has_value() ||
       *offered.moment_order < *required.moment_order)) {
    return false;
  }
  if (required.transform_kind.has_value() &&
      offered.transform_kind != required.transform_kind) {
    return false;
  }
  if (required.distribution_scope.has_value() &&
      offered.distribution_scope != required.distribution_scope) {
    return false;
  }
  if (required.argument_domain.has_value() &&
      (!offered.argument_domain.has_value() ||
       !domain_contains(*offered.argument_domain,
                        *required.argument_domain))) {
    return false;
  }
  return true;
}

[[nodiscard]] bool assumptions_cover(
    const std::vector<ArrivalAssumptionV1>& offered,
    const std::vector<ArrivalAssumptionV1>& required) {
  return std::all_of(
      required.begin(), required.end(),
      [&](const ArrivalAssumptionV1& item) {
        return std::any_of(
            offered.begin(), offered.end(),
            [&](const ArrivalAssumptionV1& candidate) {
              return assumption_satisfies(candidate, item);
            });
      });
}

[[nodiscard]] bool configured_arrival_covers(
    const ArrivalCapabilities& capabilities,
    const std::vector<ArrivalAssumptionV1>& requirements) {
  return std::all_of(
      requirements.begin(), requirements.end(),
      [&](const ArrivalAssumptionV1& requirement) {
        return arrival_capability_satisfies(capabilities, requirement);
      });
}

[[nodiscard]] bool hypothesis_satisfies(
    const HypothesisClaimV1& offered,
    const HypothesisClaimV1& required) {
  if (offered.kind != required.kind || offered.variable != required.variable ||
      offered.convention_or_class != required.convention_or_class) {
    return false;
  }
  if (!required.order.has_value()) {
    return true;
  }
  return offered.order.has_value() && *offered.order >= *required.order;
}

[[nodiscard]] bool hypotheses_cover(
    const std::vector<HypothesisClaimV1>& offered,
    const std::vector<HypothesisRequirementV1>& required,
    const std::vector<ArrivalAssumptionV1>& arrival_assumptions,
    const ArrivalCapabilities& arrival_capabilities) {
  return std::all_of(
      required.begin(), required.end(),
      [&](const HypothesisRequirementV1& item) {
        const bool separately_evidenced = std::any_of(
            offered.begin(), offered.end(),
            [&](const HypothesisClaimV1& candidate) {
              if (hypothesis_satisfies(candidate, item.claim)) {
                return true;
              }
              if (item.satisfaction !=
                      HypothesisSatisfactionKindV1::
                          required_or_declared_off_support_convention ||
                  item.claim.kind !=
                      HypothesisKindV1::positive_conditioning_mass ||
                  candidate.kind != item.claim.kind ||
                  candidate.variable != item.claim.variable ||
                  !candidate.convention_or_class.has_value()) {
                return false;
              }
              return !item.claim.order.has_value() ||
                     (candidate.order.has_value() &&
                      *candidate.order >= *item.claim.order);
            });
        if (separately_evidenced) {
          return true;
        }
        if (item.satisfaction !=
                HypothesisSatisfactionKindV1::theorem_or_separate_evidence ||
            item.claim.kind != HypothesisKindV1::moment_finite ||
            item.claim.variable !=
                std::optional<MomentVariableV1>{MomentVariableV1::arrival} ||
            item.claim.order != std::optional<BigNat>{BigNat{1U}}) {
          return false;
        }
        const auto target_intensity = std::find_if(
            arrival_assumptions.begin(), arrival_assumptions.end(),
            [](const ArrivalAssumptionV1& assumption) {
              return assumption.kind ==
                     ArrivalNeedKindV1::target_intensity;
            });
        return target_intensity != arrival_assumptions.end() &&
               arrival_capability_satisfies(arrival_capabilities,
                                            *target_intensity);
      });
}

[[nodiscard]] bool same_resolved_targets(
    const std::vector<ResolvedMetricTargetV1>& resolved,
    const std::vector<QueueId>& ids) {
  if (resolved.size() != ids.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < resolved.size(); ++index) {
    if (resolved[index].queue_id != ids[index]) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool has_finite_moment_claim(
    const MetricSupportClauseV1& support,
    const MomentRequirementV1& requirement) {
  return std::any_of(
      support.hypotheses.begin(), support.hypotheses.end(),
      [&](const HypothesisClaimV1& claim) {
        const bool matching_claim_kind =
            claim.kind == HypothesisKindV1::moment_finite ||
            (requirement.variable == MomentVariableV1::edge_reward &&
             claim.kind == HypothesisKindV1::reward_integrable);
        return matching_claim_kind &&
               claim.variable == requirement.variable &&
               claim.order.has_value() &&
               *claim.order >= requirement.order;
      });
}

[[nodiscard]] bool moment_conditioning_satisfies(
    const MomentConditioningV1 conditioning,
    const MetricRequirementClause& clause,
    const MetricRouteAlternativeV1& route,
    const MetricSupportClauseV1& support) {
  switch (conditioning) {
    case MomentConditioningV1::unconditioned:
      return true;
    case MomentConditioningV1::stationary:
      return clause.origin.selection_regime !=
                 MetricSelectionRegimeV1::transient &&
             selection_contains(
                 support.selection_domain,
                 analysis_selection_kind(clause.origin.selection_regime));
    case MomentConditioningV1::queried_backlog_level:
      return std::holds_alternative<ExactPointResponseRequirementV1>(
                 route.semantic.law) &&
             std::any_of(
                 support.hypotheses.begin(), support.hypotheses.end(),
                 [](const HypothesisClaimV1& claim) {
                   return claim.kind ==
                          HypothesisKindV1::positive_conditioning_mass;
                 });
    case MomentConditioningV1::event_palm:
      return route.semantic.entrance == EntranceLawRequirementV1::event_palm;
    case MomentConditioningV1::admission_palm:
      return route.semantic.entrance ==
             EntranceLawRequirementV1::admission_palm;
    case MomentConditioningV1::stopped_entrance:
      return std::holds_alternative<StoppedPathRequirementV1>(
                 route.semantic.law) ||
             std::holds_alternative<ResidenceWordRequirementV1>(
                 route.semantic.law);
  }
  return false;
}

[[nodiscard]] bool moments_satisfy(
    const MetricRequirementClause& clause,
    const MetricRouteAlternativeV1& route,
    const MetricSupportClauseV1& support) {
  return std::all_of(
      clause.moments.begin(), clause.moments.end(),
      [&](const MomentRequirementV1& requirement) {
        const bool arrival_theorem_applies =
            requirement.variable == MomentVariableV1::arrival &&
            std::any_of(
                clause.hypotheses.begin(), clause.hypotheses.end(),
                [&](const HypothesisRequirementV1& hypothesis) {
                  return hypothesis.satisfaction ==
                             HypothesisSatisfactionKindV1::
                                 theorem_or_separate_evidence &&
                         hypothesis.claim.kind ==
                             HypothesisKindV1::moment_finite &&
                         hypothesis.claim.variable ==
                             std::optional<MomentVariableV1>{
                                 MomentVariableV1::arrival} &&
                         hypothesis.claim.order.has_value() &&
                         *hypothesis.claim.order >= requirement.order;
                });
        if (!same_resolved_targets(requirement.ordered_targets,
                                   support.ordered_targets) ||
            (!has_finite_moment_claim(support, requirement) &&
             !arrival_theorem_applies) ||
            !moment_conditioning_satisfies(requirement.conditioning, clause,
                                            route, support)) {
          return false;
        }
        if (requirement.joint &&
            !coupling_satisfies(
                support.target_coupling,
                TargetCouplingV1::common_schedule_projection)) {
          return false;
        }
        if (requirement.variable == MomentVariableV1::arrival) {
          const ArrivalAssumptionV1 needed{
              ArrivalNeedKindV1::arrival_moment,
              ArrivalCapabilityUseV1::runtime,
              CapabilityProvisionNeedV1::any,
              requirement.order,
              requirement.joint,
              false,
              std::nullopt,
              std::nullopt,
              std::nullopt};
          const bool explicit_moment = std::any_of(
              support.arrival_assumptions.begin(),
              support.arrival_assumptions.end(),
              [&](const ArrivalAssumptionV1& offered) {
                return assumption_satisfies(offered, needed);
              });
          if (explicit_moment) {
            return true;
          }
          return requirement.order == BigNat{1U} && !requirement.joint &&
                 std::any_of(
                     support.arrival_assumptions.begin(),
                     support.arrival_assumptions.end(),
                     [](const ArrivalAssumptionV1& offered) {
                       return offered.kind ==
                              ArrivalNeedKindV1::target_intensity;
                     });
        }
        return true;
      });
}

[[nodiscard]] bool tolerances_cover(
    const std::vector<DeterministicToleranceV1>& offered,
    const std::vector<DeterministicToleranceV1>& required) {
  return std::all_of(
      required.begin(), required.end(),
      [&](const DeterministicToleranceV1& item) {
        return std::any_of(
            offered.begin(), offered.end(),
            [&](const DeterministicToleranceV1& candidate) {
              return candidate.kind == item.kind &&
                     candidate.maximum_absolute_error <=
                         item.maximum_absolute_error;
            });
      });
}

[[nodiscard]] bool valid_monte_carlo_contract(
    const MonteCarloAccuracyV1& contract) {
  switch (contract.interval) {
    case StatisticalIntervalKindV1::exact_binomial:
      return contract.estimand ==
                 StatisticalEstimandKindV1::binary_proportion &&
             contract.almost_sure_lower.has_value() &&
             contract.almost_sure_upper.has_value() &&
             *contract.almost_sure_lower == ExactRational::zero() &&
             *contract.almost_sure_upper == ExactRational::one();
    case StatisticalIntervalKindV1::hoeffding:
      return (contract.estimand ==
                  StatisticalEstimandKindV1::bounded_iid ||
              contract.estimand ==
                  StatisticalEstimandKindV1::binary_proportion) &&
             contract.almost_sure_lower.has_value() &&
             contract.almost_sure_upper.has_value() &&
             *contract.almost_sure_lower <= *contract.almost_sure_upper;
    case StatisticalIntervalKindV1::none:
      return contract.estimand == StatisticalEstimandKindV1::
                                      point_with_variance_diagnostics;
  }
  return false;
}

[[nodiscard]] bool accuracy_satisfies(const AccuracyContractV1& offered,
                                      const AccuracyContractV1& required) {
  if (offered.index() != required.index()) {
    return false;
  }
  return std::visit(
      [&](const auto& expected) {
        using Expected = std::decay_t<decltype(expected)>;
        const Expected* actual = std::get_if<Expected>(&offered);
        if (actual == nullptr) {
          return false;
        }
        if constexpr (std::is_same_v<Expected, EnumeratedAccuracyV1>) {
          return tolerances_cover(actual->tolerances, expected.tolerances);
        } else if constexpr (std::is_same_v<Expected,
                                            AnalyticAccuracyV1>) {
          return actual->precision_bits >= expected.precision_bits &&
                 tolerances_cover(actual->tolerances, expected.tolerances);
        } else if constexpr (std::is_same_v<Expected,
                                            MonteCarloAccuracyV1>) {
          if (!valid_monte_carlo_contract(*actual) ||
              !valid_monte_carlo_contract(expected) ||
              actual->replications < expected.replications ||
              actual->confidence_level < expected.confidence_level ||
              actual->interval != expected.interval ||
              actual->estimand != expected.estimand) {
            return false;
          }
          if (expected.almost_sure_lower.has_value() &&
              (!actual->almost_sure_lower.has_value() ||
               *actual->almost_sure_lower >
                   *expected.almost_sure_lower)) {
            return false;
          }
          if (expected.almost_sure_upper.has_value() &&
              (!actual->almost_sure_upper.has_value() ||
               *actual->almost_sure_upper <
                   *expected.almost_sure_upper)) {
            return false;
          }
          return true;
        } else {
          static_assert(std::is_same_v<Expected, DirectExactAccuracyV1>);
          return true;
        }
      },
      required);
}

[[nodiscard]] bool accuracy_supports(
    const std::vector<AccuracyContractV1>& offered,
    const AccuracyContractV1& required) {
  return std::any_of(
      offered.begin(), offered.end(), [&](const AccuracyContractV1& candidate) {
        return accuracy_satisfies(candidate, required);
      });
}

[[nodiscard]] bool exact_procedural_romr_source(
    const MetricSupportClauseV1& offered,
    const MetricRouteAlternativeV1& required) {
  if (offered.semantic != SemanticTagV1::romr_residence_word_law ||
      offered.runtime_access !=
          RuntimeAccessTagV1::procedural_residence_generator ||
      required.access.runtime_access !=
          RuntimeAccessTagV1::procedural_residence_generator ||
      required.access.c24_row_or_reward_only ||
      required.access.exact_request_only ||
      (offered.solver_route != SolverRegimeV1::enumerated &&
       offered.solver_route != SolverRegimeV1::analytic) ||
      offered.error_promise.form != StructuralErrorFormV1::exact ||
      (offered.error_promise.maximum_error.has_value() &&
       !offered.error_promise.maximum_error->is_zero())) {
    return false;
  }

  return true;
}

[[nodiscard]] bool exact_procedural_romr_route(
    const MetricSupportClauseV1& offered,
    const MetricRouteAlternativeV1& required) {
  if (!exact_procedural_romr_source(offered, required)) {
    return false;
  }

  // C20/C21 can turn a V0-audited exact complete-word provider into these
  // views without promoting a sampler or iterating a stationary edge. A
  // ResidenceWordRequirement is already the provider's native semantic and
  // is handled separately below; the cases here are derived audited views.
  return std::visit(
      [&](const auto& law) {
        using Law = std::decay_t<decltype(law)>;
        if constexpr (std::is_same_v<Law,
                                     FrameworkDerivedScalarRequirementV1>) {
          return required.semantic.require_temporal_one_slot_source &&
                 required.semantic.require_full_history_predictive_sufficiency &&
                 (law.scalar == FrameworkScalarKindV1::
                                    event_intensity_active_fraction ||
                  law.scalar == FrameworkScalarKindV1::
                                    binary_occupation_start_ratio);
        } else if constexpr (
            std::is_same_v<Law, SelectedInvariantMarginalRequirementV1> ||
            std::is_same_v<Law, StationaryMarkedEdgeRequirementV1>) {
          return true;
        } else if constexpr (
            std::is_same_v<Law, FiniteCylinderRequirementV1> ||
            std::is_same_v<Law, PushforwardCountLawRequirementV1> ||
            std::is_same_v<Law, StoppedPathRequirementV1>) {
          return required.semantic.require_temporal_one_slot_source &&
                 required.semantic.require_full_history_predictive_sufficiency;
        }
        return false;
      },
      required.semantic.law);
}

[[nodiscard]] bool romr_framework_derived_mark(
    const MetricMarkKindV1 kind) noexcept {
  // These values are deterministic readouts of the V0 causal slot retained
  // by every complete C20 word or of its configured arrival transition. They
  // do not require an extra provider mark decoder. Authored class/phase
  // labels and counterfactual permission are intentionally absent: only an
  // explicitly declared provider mark may authorize those readouts.
  switch (kind) {
    case MetricMarkKindV1::target_backlog:
    case MetricMarkKindV1::predictive_phase:
    case MetricMarkKindV1::opportunity:
    case MetricMarkKindV1::actual_departure:
    case MetricMarkKindV1::schedule_projection:
    case MetricMarkKindV1::full_schedule:
    case MetricMarkKindV1::arrival_batch:
    case MetricMarkKindV1::successor_backlog:
    case MetricMarkKindV1::within_batch_rank:
    case MetricMarkKindV1::batch_size:
    case MetricMarkKindV1::edge_increment:
    case MetricMarkKindV1::event_indicator:
    case MetricMarkKindV1::predicate:
    case MetricMarkKindV1::predicate_start:
    case MetricMarkKindV1::active_component:
      return true;
    // A packet class or named phase is an authored entrance label, not a
    // consequence of the generic queue/count arrival batch or the raw
    // predictive-phase bytes. It must be retained explicitly by the provider
    // when a conditioned metric requests it.
    case MetricMarkKindV1::class_label:
    case MetricMarkKindV1::phase_label:
    case MetricMarkKindV1::counterfactual_permission:
      return false;
  }
  return false;
}

[[nodiscard]] bool marks_satisfy_route(
    const MetricSupportClauseV1& offered,
    const MetricRouteAlternativeV1& required,
    CapabilityFailureKindV1* failed_kind) {
  const bool carries_opportunity = std::any_of(
      offered.marks.begin(), offered.marks.end(), [](const auto& mark) {
        return mark.kind == MetricMarkKindV1::opportunity;
      });
  if (offered.semantic == SemanticTagV1::scalar_backlog_response &&
      !carries_opportunity) {
    // A scalar response is already the conditional service law as a function
    // of backlog.  Its sampled opportunity has been marginalized during
    // construction and is not a runtime causal input.
    std::vector<MarkRequirementV1> runtime_marks;
    runtime_marks.reserve(required.marks.size());
    for (const MarkRequirementV1& mark : required.marks) {
      if (mark.kind != MetricMarkKindV1::opportunity) {
        runtime_marks.push_back(mark);
      }
    }
    return marks_satisfy(offered.marks, runtime_marks, failed_kind);
  }
  if (!exact_procedural_romr_source(offered, required)) {
    return marks_satisfy(offered.marks, required.marks, failed_kind);
  }
  std::vector<MarkRequirementV1> provider_marks;
  provider_marks.reserve(required.marks.size());
  for (const MarkRequirementV1& mark : required.marks) {
    if (!romr_framework_derived_mark(mark.kind)) {
      provider_marks.push_back(mark);
    }
  }
  return marks_satisfy(offered.marks, provider_marks, failed_kind);
}

[[nodiscard]] bool semantic_satisfies(
    const MetricSupportClauseV1& offered,
    const MetricRouteAlternativeV1& required) {
  const SemanticTagV1 semantic = offered.semantic;
  const bool exact_romr = exact_procedural_romr_route(offered, required);
  return std::visit(
      [&](const auto& law) {
        using Law = std::decay_t<decltype(law)>;
        if constexpr (std::is_same_v<Law,
                                     FrameworkDerivedScalarRequirementV1>) {
          if (required.semantic.require_temporal_one_slot_source) {
            return semantic ==
                       SemanticTagV1::temporal_one_slot_continuation ||
                   exact_romr;
          }
          return semantic == SemanticTagV1::scalar_backlog_response ||
                 semantic == SemanticTagV1::stationary_marked_edge ||
                 semantic == SemanticTagV1::staged_opportunity_flux_law ||
                 semantic == SemanticTagV1::temporal_one_slot_continuation ||
                 semantic == SemanticTagV1::coupled_target_schedule_law;
        } else if constexpr (
            std::is_same_v<Law, SelectedInvariantMarginalRequirementV1>) {
          return semantic == SemanticTagV1::scalar_backlog_response ||
                 semantic == SemanticTagV1::stationary_marked_edge ||
                 semantic == SemanticTagV1::temporal_one_slot_continuation ||
                 semantic == SemanticTagV1::coupled_target_schedule_law ||
                 exact_romr;
        } else if constexpr (
            std::is_same_v<Law, StationaryMarkedEdgeRequirementV1>) {
          return semantic == SemanticTagV1::stationary_marked_edge ||
                 semantic == SemanticTagV1::temporal_one_slot_continuation ||
                 semantic == SemanticTagV1::coupled_target_schedule_law ||
                 exact_romr;
        } else if constexpr (
            std::is_same_v<Law, FiniteCylinderRequirementV1>) {
          // A finite cylinder is only a derived view of an actual temporal
          // continuation.  It is never powered from an edge law or accepted
          // as a tenth semantic tag.
          return semantic == SemanticTagV1::temporal_one_slot_continuation ||
                 exact_romr;
        } else if constexpr (
            std::is_same_v<Law, ExactPointResponseRequirementV1>) {
          return semantic == SemanticTagV1::scalar_backlog_response ||
                 semantic == SemanticTagV1::staged_opportunity_flux_law;
        } else if constexpr (
            std::is_same_v<Law, PushforwardCountLawRequirementV1>) {
          return semantic == SemanticTagV1::temporal_one_slot_continuation ||
                 exact_romr;
        } else if constexpr (
            std::is_same_v<Law, ResidenceWordRequirementV1>) {
          return semantic == SemanticTagV1::romr_residence_word_law;
        } else if constexpr (
            std::is_same_v<Law, StoppedPathRequirementV1>) {
          return semantic == SemanticTagV1::stopped_path_law || exact_romr;
        } else {
          static_assert(std::is_same_v<Law,
                                       ExactRequestDecoderRequirementV1>);
          return law.exact_match_only &&
                 semantic == SemanticTagV1::direct_metric_decoder;
        }
      },
      required.semantic.law);
}

[[nodiscard]] std::optional<BigNat> maximum_required_horizon(
    const ReusableMetricLawRequirementV1& law) {
  return std::visit(
      [&](const auto& value) -> std::optional<BigNat> {
        using Value = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<Value, FiniteCylinderRequirementV1>) {
          return std::visit(
              [](const auto& coverage) -> BigNat {
                using Coverage = std::decay_t<decltype(coverage)>;
                if constexpr (std::is_same_v<Coverage,
                                             ExplicitCylinderOffsetsV1>) {
                  return *std::max_element(coverage.offsets.begin(),
                                           coverage.offsets.end());
                } else {
                  return coverage.maximum_offset;
                }
              },
              value.coverage);
        } else if constexpr (std::is_same_v<Value,
                                            ResidenceWordRequirementV1> ||
                             std::is_same_v<Value,
                                            StoppedPathRequirementV1>) {
          return value.output_horizon;
        } else if constexpr (std::is_same_v<Value,
                                            PushforwardCountLawRequirementV1>) {
          Result<BigNat> predecessor =
              checked_subtract(value.width, BigNat{1U});
          return predecessor ? std::optional<BigNat>{predecessor.value()}
                             : std::optional<BigNat>{BigNat{0U}};
        }
        return std::nullopt;
      },
      law);
}

[[nodiscard]] bool phase_satisfies(
    const PhaseSupportV1& phase,
    const std::vector<StateFieldDescriptorV1>& state_fields,
    const SemanticContractAlternativeV1& semantic,
    const ArrivalRequirementAlternativeV1& arrival) {
  // A temporal/stopped law's own continuation state is not the same thing as
  // the configured arrival law's predictive phase.  Only the selected
  // dependent-arrival route imposes the latter.  In particular, an IID-late
  // temporal route must not be forced to declare two contradictory arrival
  // compositions merely because its surrogate law retains path history.
  const bool needs_predictive =
      std::any_of(arrival.all_of.begin(), arrival.all_of.end(),
                  [](const ArrivalAssumptionV1& requirement) {
                    return requirement.kind == ArrivalNeedKindV1::predictive_phase ||
                           requirement.kind == ArrivalNeedKindV1::sequential_law;
                  });
  const bool needs_iid_late = std::any_of(
      arrival.all_of.begin(), arrival.all_of.end(),
      [](const ArrivalAssumptionV1& requirement) {
        return requirement.kind == ArrivalNeedKindV1::exact_iid_late;
      });
  if (needs_iid_late &&
      phase.arrival_composition !=
          ConfiguredArrivalCompositionV1::iid_late_arrival) {
    return false;
  }
  if (needs_predictive &&
      phase.arrival_composition !=
          ConfiguredArrivalCompositionV1::finite_enumerated_predictive_phase &&
      phase.arrival_composition !=
          ConfiguredArrivalCompositionV1::sequential_predictive_phase) {
    return false;
  }
  if (needs_predictive && !state_fields_cover_phase(phase, state_fields)) {
    return false;
  }
  const std::optional<BigNat> horizon = maximum_required_horizon(semantic.law);
  if (!horizon.has_value()) {
    return true;
  }
  switch (phase.finite_horizon_coverage) {
    case FiniteHorizonCoverageKindV1::every_finite_horizon:
      return true;
    case FiniteHorizonCoverageKindV1::bounded:
      return phase.maximum_finite_horizon.has_value() &&
             *phase.maximum_finite_horizon >= *horizon;
    case FiniteHorizonCoverageKindV1::none:
      return horizon->is_zero();
  }
  return false;
}

[[nodiscard]] bool access_satisfies(const RuntimeAccessTagV1 offered,
                                    const MetricRouteAlternativeV1& route,
                                    const SolverRegimeV1 solver) {
  if (offered != route.access.runtime_access) {
    return false;
  }
  switch (offered) {
    case RuntimeAccessTagV1::finite_enumerated_row:
    case RuntimeAccessTagV1::sparse_row:
      return solver == SolverRegimeV1::enumerated;
    case RuntimeAccessTagV1::analytic_transform:
    case RuntimeAccessTagV1::finite_parameter_analytic_family:
      return solver == SolverRegimeV1::analytic;
    case RuntimeAccessTagV1::procedural_residence_generator:
      // A procedural ROMR carrier can expose either an analytic residence
      // expectation or C20-audited exact enumerable complete-word rows.  The
      // latter remains an enumerated solve; reusable_accesses emits this
      // pairing only for routes explicitly marked residence-capable.
      return solver == SolverRegimeV1::analytic ||
             solver == SolverRegimeV1::enumerated;
    case RuntimeAccessTagV1::normalized_conditional_sampler:
      return solver == SolverRegimeV1::monte_carlo &&
             route.access.c24_row_or_reward_only &&
             (route.access.backend_route ==
                  BackendRouteKindV1::conditional_row_monte_carlo ||
              route.access.backend_route ==
                  BackendRouteKindV1::conditional_reward_monte_carlo);
    case RuntimeAccessTagV1::direct_metric_decoder:
      return solver == SolverRegimeV1::direct &&
             route.access.exact_request_only &&
             route.access.backend_route == BackendRouteKindV1::exact_direct;
  }
  return false;
}

[[nodiscard]] bool role_present(const MetricSupportClauseV1& clause,
                                const MetricSupportRoleV1 role) {
  return std::any_of(
      clause.required_roles.begin(), clause.required_roles.end(),
      [role](const MetricSupportRoleRequirementV1& requirement) {
        return requirement.role == role;
      });
}

[[nodiscard]] bool policies_satisfy(
    const PlugDescriptorPreview& preview, std::string* reason) {
  bool has_any_evidence_role = false;
  bool needs_deployed_response = false;
  bool needs_raw = false;
  bool needs_nominal = false;
  bool needs_projection = false;
  bool needs_recoded = false;
  bool uses_construction_targets = false;
  for (const MetricSupportClauseV1& clause :
       preview.metric_support_manifest->clauses()) {
    const auto find_requirement =
        [&](const MetricSupportRoleV1 role)
        -> const MetricSupportRoleRequirementV1* {
      const auto found = std::find_if(
          clause.required_roles.begin(), clause.required_roles.end(),
          [role](const MetricSupportRoleRequirementV1& requirement) {
            return requirement.role == role;
          });
      return found == clause.required_roles.end() ? nullptr : &*found;
    };
    has_any_evidence_role = has_any_evidence_role || std::any_of(
        clause.required_roles.begin(), clause.required_roles.end(),
        [](const MetricSupportRoleRequirementV1& requirement) {
          return metric_support_role_rank_v1(requirement.role) >=
                 metric_support_role_rank_v1(
                     MetricSupportRoleV1::raw_response_bound_evidence);
        });
    needs_deployed_response = needs_deployed_response ||
        role_present(clause, MetricSupportRoleV1::deployed_response);
    needs_raw = needs_raw ||
        role_present(clause, MetricSupportRoleV1::raw_response);
    needs_nominal = needs_nominal ||
        role_present(clause, MetricSupportRoleV1::nominal_response);
    needs_projection = needs_projection ||
        role_present(clause, MetricSupportRoleV1::projection_center) ||
        role_present(clause, MetricSupportRoleV1::projected_mean);
    needs_recoded = needs_recoded ||
        role_present(clause, MetricSupportRoleV1::recoded_response);
    uses_construction_targets = uses_construction_targets || std::any_of(
        clause.required_roles.begin(), clause.required_roles.end(),
        [](const MetricSupportRoleRequirementV1& role) {
          return role.target_scope ==
                 MetricTargetScopeV1::ordered_construction_targets;
        });

    if (const auto* deployed =
            find_requirement(MetricSupportRoleV1::deployed_response)) {
      MetricSupportRoleV1 selected_role = MetricSupportRoleV1::raw_response;
      switch (preview.policies.point_deployment) {
        case PointDeploymentPolicyV1::not_applicable:
          *reason =
              "deployed_response requires an explicit point-deployment "
              "policy";
          return false;
        case PointDeploymentPolicyV1::deploy_raw_point:
          selected_role = MetricSupportRoleV1::raw_response;
          break;
        case PointDeploymentPolicyV1::deploy_nominal_point:
          selected_role = MetricSupportRoleV1::nominal_response;
          break;
        case PointDeploymentPolicyV1::deploy_recoded_point:
          selected_role = MetricSupportRoleV1::recoded_response;
          break;
      }
      const std::size_t subject_count = static_cast<std::size_t>(std::count_if(
          deployed->role_relations.begin(), deployed->role_relations.end(),
          [](const MetricRoleRelationRequirementV1& relation) {
            return relation.relation == MetricRoleRelationKindV1::subject;
          }));
      if (subject_count != 1U ||
          !c14_has_role_relation(*deployed,
                                 MetricRoleRelationKindV1::subject,
                                 selected_role)) {
        *reason =
            "deployed_response source does not match the frozen "
            "point-deployment policy in its own clause";
        return false;
      }
    }

    if (const auto* nominal =
            find_requirement(MetricSupportRoleV1::nominal_response)) {
      const bool raw_parent = c14_has_role_relation(
          *nominal, MetricRoleRelationKindV1::lineage_parent,
          MetricSupportRoleV1::raw_response);
      const bool completion_parent = c14_has_internal_relation(
          *nominal, MetricRoleRelationKindV1::lineage_parent,
          InternalReferencePurposeV1::completion_source);
      const bool compatible =
          (preview.policies.coefficient_completion ==
               CoefficientCompletionPolicyV1::declared_nominal_completion &&
           raw_parent && !completion_parent) ||
          (preview.policies.coefficient_completion ==
               CoefficientCompletionPolicyV1::
                   authorized_endpoint_completion &&
           completion_parent && !raw_parent);
      if (!compatible) {
        *reason =
            "nominal_response parents do not match the frozen completion "
            "policy in their own clause";
        return false;
      }
    }

    const bool clause_projects =
        find_requirement(MetricSupportRoleV1::projection_center) != nullptr ||
        find_requirement(MetricSupportRoleV1::projected_mean) != nullptr;
    if (clause_projects &&
        preview.policies.projection == ProjectionPolicyV1::not_applicable) {
      *reason =
          "projection roles require an applicable frozen projection policy "
          "in their own clause";
      return false;
    }

    if (const auto* recoded =
            find_requirement(MetricSupportRoleV1::recoded_response)) {
      if (preview.policies.recoding == RecodingPolicyV1::not_applicable) {
        *reason =
            "recoded_response requires an applicable frozen recoding policy";
        return false;
      }
      const bool projected_parent = c14_has_role_relation(
          *recoded, MetricRoleRelationKindV1::lineage_parent,
          MetricSupportRoleV1::projected_mean);
      const bool raw_parent = c14_has_role_relation(
          *recoded, MetricRoleRelationKindV1::lineage_parent,
          MetricSupportRoleV1::raw_response);
      const bool nominal_parent = c14_has_role_relation(
          *recoded, MetricRoleRelationKindV1::lineage_parent,
          MetricSupportRoleV1::nominal_response);
      const bool completion_parent = c14_has_internal_relation(
          *recoded, MetricRoleRelationKindV1::lineage_parent,
          InternalReferencePurposeV1::completion_source);
      if (preview.policies.recoding == RecodingPolicyV1::mean_inversion) {
        const std::size_t interior_count =
            static_cast<std::size_t>(raw_parent) +
            static_cast<std::size_t>(nominal_parent);
        const bool interior_form = projected_parent && interior_count == 1U &&
                                   !completion_parent;
        const bool endpoint_form = !projected_parent &&
                                   interior_count == 0U && completion_parent;
        if (!interior_form && !endpoint_form) {
          *reason =
              "mean-inversion recoding parents do not match the frozen "
              "interior or endpoint form in their own clause";
          return false;
        }
      } else {
        const std::size_t parent_count = static_cast<std::size_t>(
            std::count_if(recoded->role_relations.begin(),
                          recoded->role_relations.end(),
                          [](const MetricRoleRelationRequirementV1& relation) {
                            return relation.relation ==
                                   MetricRoleRelationKindV1::lineage_parent;
                          })) +
            static_cast<std::size_t>(std::count_if(
                recoded->internal_relations.begin(),
                recoded->internal_relations.end(),
                [](const InternalRelationRequirementV1& relation) {
                  return relation.relation ==
                         MetricRoleRelationKindV1::lineage_parent;
                }));
        if (parent_count != 1U) {
          *reason =
              "identity recoding does not name exactly one source parent in "
              "its own clause";
          return false;
        }
      }
    }
  }

  if (needs_deployed_response &&
      preview.policies.point_deployment ==
          PointDeploymentPolicyV1::not_applicable) {
    *reason = "deployed_response requires an explicit point-deployment policy";
    return false;
  }
  if (!needs_deployed_response &&
      preview.policies.point_deployment !=
          PointDeploymentPolicyV1::not_applicable) {
    *reason =
        "an applicable point-deployment policy requires deployed_response";
    return false;
  }
  switch (preview.policies.point_deployment) {
    case PointDeploymentPolicyV1::not_applicable:
      break;
    case PointDeploymentPolicyV1::deploy_raw_point:
      if (!needs_raw) {
        *reason = "raw point deployment has no raw_response role";
        return false;
      }
      break;
    case PointDeploymentPolicyV1::deploy_nominal_point:
      if (!needs_nominal) {
        *reason = "nominal point deployment has no nominal_response role";
        return false;
      }
      break;
    case PointDeploymentPolicyV1::deploy_recoded_point:
      if (!needs_recoded) {
        *reason = "recoded point deployment has no recoded_response role";
        return false;
      }
      break;
  }
  switch (preview.policies.coefficient_completion) {
    case CoefficientCompletionPolicyV1::not_applicable:
      if (needs_nominal) {
        *reason = "nominal_response requires an explicit completion policy";
        return false;
      }
      break;
    case CoefficientCompletionPolicyV1::require_complete_raw_points:
      if (!needs_raw || needs_nominal) {
        *reason =
            "require_complete_raw_points requires raw_response and forbids "
            "nominal_response";
        return false;
      }
      break;
    case CoefficientCompletionPolicyV1::declared_nominal_completion:
    case CoefficientCompletionPolicyV1::authorized_endpoint_completion:
      if (!needs_nominal) {
        *reason =
            "an applicable nominal-completion policy requires "
            "nominal_response";
        return false;
      }
      break;
  }
  if (needs_projection !=
      (preview.policies.projection != ProjectionPolicyV1::not_applicable)) {
    *reason =
        "projection policy applicability must exactly match projection roles";
    return false;
  }
  if (needs_recoded !=
      (preview.policies.recoding != RecodingPolicyV1::not_applicable)) {
    *reason =
        "recoding policy applicability must exactly match recoded_response";
    return false;
  }
  const bool exact_evidence_policy =
      preview.policies.evidence_roles ==
      EvidenceRolePolicyV1::exact_manifest_roles;
  if (has_any_evidence_role != exact_evidence_policy) {
    *reason =
        "exact_manifest_roles is required exactly when the manifest contains "
        "evidence-role tags";
    return false;
  }
  if (uses_construction_targets &&
      preview.construction_target_scope.empty()) {
    *reason = "ordered construction-target roles require a nonempty scope";
    return false;
  }
  if (has_duplicates(preview.construction_target_scope)) {
    *reason = "construction target scope contains duplicate queue IDs";
    return false;
  }
  return true;
}

[[nodiscard]] bool budget_satisfies(
    const MetricRequirementClause& clause,
    const ConstructionPrerequisitesV1& prerequisites) {
  if (!clause.origin.context) {
    return false;
  }
  const ResolutionEnvelope& resolution = clause.origin.context->resolution;
  const auto within = [](const std::optional<BigNat>& needed,
                         const std::optional<BigNat>& available) {
    return !needed.has_value() || !available.has_value() ||
           *needed <= *available;
  };
  return within(prerequisites.required_optimizer_calls,
                resolution.optimizer.max_calls) &&
         within(prerequisites.required_search_states_per_call,
                resolution.optimizer.max_search_states_per_call) &&
         within(prerequisites.required_generator_draws,
                resolution.sampling.max_generator_draws);
}

[[nodiscard]] bool support_marks_are_in_core(
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core) {
  return std::all_of(
      support.marks.begin(), support.marks.end(),
      [&](const MarkDescriptorV1& mark) {
        return std::find(core.marks.begin(), core.marks.end(), mark) !=
               core.marks.end();
      });
}

[[nodiscard]] bool support_fields_are_in_core(
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core) {
  return std::all_of(
      support.state_fields.begin(), support.state_fields.end(),
      [&](const StateFieldDescriptorV1& field) {
        return std::find(core.state_fields.begin(), core.state_fields.end(),
                         field) != core.state_fields.end();
      });
}

[[nodiscard]] bool support_targets_are_in_core(
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core) {
  if (support.target_coupling != TargetCouplingV1::scalar_target) {
    return support.ordered_targets == core.deployed_targets;
  }
  return std::all_of(
      support.ordered_targets.begin(), support.ordered_targets.end(),
      [&](const QueueId& target) {
        return contains_queue(core.deployed_targets, target);
      });
}

[[nodiscard]] bool manifest_clause_enveloped_by_core(
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core) {
  return support.payload_class == core.payload_class &&
         support.semantic == core.semantic &&
         support.runtime_access == core.runtime_access &&
         coupling_satisfies(core.target_coupling,
                            support.target_coupling) &&
         support_targets_are_in_core(support, core) &&
         support_fields_are_in_core(support, core) &&
         support_marks_are_in_core(support, core) &&
         assumptions_cover(core.arrival_assumptions,
                           support.arrival_assumptions) &&
         std::all_of(
             support.hypotheses.begin(), support.hypotheses.end(),
             [&](const HypothesisClaimV1& required) {
               return std::any_of(
                   core.hypothesis_claims.begin(),
                   core.hypothesis_claims.end(),
                   [&](const HypothesisClaimV1& offered) {
                     return hypothesis_satisfies(offered, required);
                   });
             }) &&
         accuracy_supports(core.accuracy_support,
                           support.requested_accuracy) &&
         support.mandatory_v0 == core.mandatory_v0;
}

[[nodiscard]] bool manifest_selection_envelops(
    const MetricSupportClauseV1& support,
    const PlugDescriptorCore& core) {
  return std::all_of(
             support.selection_domain.kinds.begin(),
             support.selection_domain.kinds.end(),
             [&](const SelectionKindV1 kind) {
               return selection_contains(core.selection, kind);
             }) &&
         std::all_of(
             support.selection_domain.named_classes.begin(),
             support.selection_domain.named_classes.end(),
             [&](const TypedLabel& value) {
               return std::find(core.selection.named_classes.begin(),
                                core.selection.named_classes.end(), value) !=
                      core.selection.named_classes.end();
             }) &&
         std::all_of(
             support.selection_domain.named_fixed_points.begin(),
             support.selection_domain.named_fixed_points.end(),
             [&](const TypedLabel& value) {
               return std::find(core.selection.named_fixed_points.begin(),
                                core.selection.named_fixed_points.end(), value) !=
                      core.selection.named_fixed_points.end();
             });
}

[[nodiscard]] bool phase_support_envelops(const PhaseSupportV1& offered,
                                          const PhaseSupportV1& required) {
  if (offered.payload_phase != required.payload_phase ||
      offered.arrival_composition != required.arrival_composition ||
      (required.retains_configured_predictive_phase &&
       !offered.retains_configured_predictive_phase)) {
    return false;
  }
  if (required.predictive_phase_codec.has_value() &&
      offered.predictive_phase_codec != required.predictive_phase_codec) {
    return false;
  }
  if (required.finite_horizon_coverage ==
      FiniteHorizonCoverageKindV1::none) {
    return true;
  }
  if (offered.finite_horizon_coverage ==
      FiniteHorizonCoverageKindV1::every_finite_horizon) {
    return true;
  }
  if (offered.finite_horizon_coverage !=
          FiniteHorizonCoverageKindV1::bounded ||
      required.finite_horizon_coverage !=
          FiniteHorizonCoverageKindV1::bounded ||
      !offered.maximum_finite_horizon.has_value() ||
      !required.maximum_finite_horizon.has_value()) {
    return false;
  }
  return *offered.maximum_finite_horizon >=
         *required.maximum_finite_horizon;
}

[[nodiscard]] bool error_promise_satisfies(
    const StructuralErrorPromiseV1& promise,
    const AccuracyRequirementV1& accuracy) {
  if (!accuracy.require_declared_error_or_certificate) {
    return true;
  }
  if (promise.form == StructuralErrorFormV1::none) {
    return false;
  }
  if ((promise.form == StructuralErrorFormV1::deterministic_enclosure ||
       promise.form == StructuralErrorFormV1::numerical_residual) &&
      !promise.maximum_error.has_value()) {
    return false;
  }
  if (promise.maximum_error.has_value()) {
    if (!promise.maximum_error->is_nonnegative()) {
      return false;
    }
    const auto promised_error_is_within = [&](const auto& contract) {
      using Contract = std::decay_t<decltype(contract)>;
      if constexpr (std::is_same_v<Contract, EnumeratedAccuracyV1> ||
                    std::is_same_v<Contract, AnalyticAccuracyV1>) {
        return std::all_of(
            contract.tolerances.begin(), contract.tolerances.end(),
            [&](const DeterministicToleranceV1& tolerance) {
              return *promise.maximum_error <=
                     tolerance.maximum_absolute_error;
            });
      }
      return true;
    };
    if (!std::visit(promised_error_is_within, accuracy.contract)) {
      return false;
    }
  }
  if (promise.form == StructuralErrorFormV1::exact &&
      promise.maximum_error.has_value() &&
      !promise.maximum_error->is_zero()) {
    return false;
  }
  if (std::holds_alternative<MonteCarloAccuracyV1>(accuracy.contract)) {
    return promise.form == StructuralErrorFormV1::statistical_interval ||
           promise.form == StructuralErrorFormV1::exact;
  }
  if (std::holds_alternative<DirectExactAccuracyV1>(accuracy.contract)) {
    return promise.form == StructuralErrorFormV1::exact;
  }
  return promise.form == StructuralErrorFormV1::exact ||
         promise.form == StructuralErrorFormV1::deterministic_enclosure ||
         promise.form == StructuralErrorFormV1::numerical_residual;
}

struct RouteEvaluation final {
  const MetricRouteAlternativeV1* route;
  std::vector<CapabilityFailureV1> failures;
};

[[nodiscard]] RouteEvaluation evaluate_route(
    const MetricRequirementClause& clause,
    const MetricRouteAlternativeV1& route,
    const MetricSupportClauseV1& support,
    const PlugDescriptorPreview& preview,
    const ArrivalCapabilities& arrival_capabilities) {
  RouteEvaluation result{&route, {}};
  const bool direct = route.access.exact_request_only;
  if (!semantic_satisfies(support, route)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::semantic,
        CapabilityFailureKindV1::missing_semantic_contract,
        enum_text(support.semantic), "one complete declared semantic route"));
  }
  if (!access_satisfies(support.runtime_access, route,
                        support.solver_route)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::runtime_access,
        CapabilityFailureKindV1::incompatible_runtime_access,
        enum_text(support.runtime_access), enum_text(route.access.runtime_access)));
  }
  if (support.metric_kind != clause.origin.kind ||
      !parameter_domain_contains(support.parameter_domain,
                                 clause.origin.parameters, direct)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::manifest,
        CapabilityFailureKindV1::unsupported_manifest_clause,
        "different metric kind or parameter domain",
        "exact requested metric parameter point"));
  }
  const std::vector<QueueId> targets = request_target_ids(clause);
  if (support.ordered_targets != targets) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::target_scope,
        CapabilityFailureKindV1::target_order_mismatch,
        "different ordered target IDs", "exact ordered metric targets"));
  }
  if (!coupling_satisfies(support.target_coupling,
                          route.semantic.coupling)) {
    const CapabilityFailureKindV1 kind =
        route.semantic.coupling == TargetCouplingV1::full_schedule_identity
            ? CapabilityFailureKindV1::schedule_identity_not_retained
            : CapabilityFailureKindV1::scalar_coupling_only;
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::target_coupling, kind,
        enum_text(support.target_coupling),
        enum_text(route.semantic.coupling)));
  }
  if (!phase_satisfies(support.phase_domain, support.state_fields,
                       route.semantic, route.arrival)) {
    const std::optional<BigNat> horizon =
        maximum_required_horizon(route.semantic.law);
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::phase,
        horizon.has_value()
            ? CapabilityFailureKindV1::finite_horizon_too_short
            : CapabilityFailureKindV1::predictive_phase_not_retained,
        "insufficient composed predictive state or horizon",
        horizon.has_value() ? "temporal continuation through " +
                                  horizon->to_decimal_string()
                            : "configured predictive phase retained"));
  }
  CapabilityFailureKindV1 mark_failure =
      CapabilityFailureKindV1::missing_mark;
  if (!marks_satisfy_route(support, route, &mark_failure)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::mark, mark_failure,
        "manifest mark/reveal schema", "all marks in one complete route"));
  }
  if (!selection_satisfies(clause, route.semantic,
                           support.selection_domain)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::selection,
        CapabilityFailureKindV1::selection_not_supported,
        "different or unnamed selection/entrance",
        "exact analysis selection and entrance law"));
  }
  if (!assumptions_cover(support.arrival_assumptions,
                         route.arrival.all_of)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::arrival,
        CapabilityFailureKindV1::arrival_provision_incompatible,
        "manifest omits a route-correlated arrival assumption",
        "complete route arrival conjunction"));
  } else if (!configured_arrival_covers(
                 arrival_capabilities, support.arrival_assumptions)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::arrival,
        CapabilityFailureKindV1::arrival_capability_missing,
        "configured arrival capability set",
        "every arrival assumption frozen in the selected support clause"));
  }
  if (!configured_arrival_composition_satisfies(
          arrival_capabilities,
          support.phase_domain.arrival_composition)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::arrival,
        CapabilityFailureKindV1::arrival_capability_missing,
        "configured arrival lacks the access named by the phase composition",
        "exact IID table, finite phase plus transition rows, or sequential "
        "sampler matching the selected composition"));
  }
  if (!hypotheses_cover(support.hypotheses, route.hypotheses,
                        support.arrival_assumptions,
                        arrival_capabilities)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::hypothesis,
        CapabilityFailureKindV1::hypothesis_evidence_missing,
        "manifest hypothesis claims", "all route and metric hypotheses"));
  }
  if (!moments_satisfy(clause, route, support)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::moment,
        CapabilityFailureKindV1::moment_evidence_missing,
        "manifest moment evidence lacks the requested target/conditioning/joint scope",
        "exact variable/order/conditioning/ordered-target moment obligation"));
  }
  if (support.semantic ==
          SemanticTagV1::temporal_one_slot_continuation &&
      clause.origin.selection_regime != MetricSelectionRegimeV1::transient &&
      !std::any_of(
          support.hypotheses.begin(), support.hypotheses.end(),
          [](const HypothesisClaimV1& claim) {
            return claim.kind ==
                   HypothesisKindV1::c21_suspension_inversion;
          })) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::hypothesis,
        CapabilityFailureKindV1::hypothesis_evidence_missing,
        "temporal continuation without suspension/inversion evidence",
        "C21-compatible stationary suspension/inversion"));
  }
  if (support.mandatory_v0.kind !=
          V0DeclarationKindV1::structural_witness_required ||
      preview.core.mandatory_v0.kind !=
          V0DeclarationKindV1::structural_witness_required) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::mandatory_v0,
        CapabilityFailureKindV1::v0_not_declared,
        "absent V0 declaration", "structural V0 witness"));
  }
  if (support.solver_route != clause.accuracy.solver_regime ||
      !accuracy_satisfies(support.requested_accuracy,
                          clause.accuracy.contract)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::accuracy,
        CapabilityFailureKindV1::solver_regime_mismatch,
        enum_text(support.solver_route),
        enum_text(clause.accuracy.solver_regime)));
  } else if (!error_promise_satisfies(support.error_promise,
                                      clause.accuracy)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::accuracy,
        std::holds_alternative<MonteCarloAccuracyV1>(
            clause.accuracy.contract)
            ? CapabilityFailureKindV1::statistical_accuracy_mismatch
            : CapabilityFailureKindV1::deterministic_accuracy_missing,
        "insufficient structural error promise",
        "requested exact/numerical/statistical certificate"));
  }
  if (!budget_satisfies(clause, preview.construction_prerequisites)) {
    result.failures.push_back(make_failure(
        clause, CapabilityAxisV1::budget,
        CapabilityFailureKindV1::construction_budget_insufficient,
        "preview construction prerequisites",
        "within authored resolution budget"));
  }
  return result;
}

[[nodiscard]] bool failure_less(const CapabilityFailureV1& left,
                                const CapabilityFailureV1& right) {
  return std::tie(left.authored_metric_index, left.axis, left.kind,
                  left.provided, left.required) <
         std::tie(right.authored_metric_index, right.axis, right.kind,
                  right.provided, right.required);
}

[[nodiscard]] const RouteEvaluation& best_route_evaluation(
    const std::vector<RouteEvaluation>& evaluations) {
  return *std::min_element(
      evaluations.begin(), evaluations.end(),
      [](const RouteEvaluation& left, const RouteEvaluation& right) {
        if (left.failures.size() != right.failures.size()) {
          return left.failures.size() < right.failures.size();
        }
        return std::lexicographical_compare(
            left.failures.begin(), left.failures.end(), right.failures.begin(),
            right.failures.end(), failure_less);
      });
}

[[nodiscard]] Digest256 support_clause_digest(
    const MetricSupportManifest& manifest,
    const MetricSupportClauseV1& clause) {
  CapabilityCanonicalEncoder encoder;
  encoder.digest(manifest.canonical_digest());
  encoder.string(clause.clause_id.metric_id);
  encoder.count(clause.clause_id.authored_index);
  Result<Digest256> result = hash_capability_bytes(
      "mwperf.c14.metric_support_clause.v1", encoder);
  return result ? result.value() : zero_digest();
}

[[nodiscard]] std::optional<CapabilityAlternativeV1> make_alternative(
    const MetricRequirementClause& clause,
    const MetricSupportClauseV1& support,
    const std::vector<CapabilityFailureV1>& failures) {
  if (failures.empty()) {
    return std::nullopt;
  }
  AlternativeRelationshipV1 relationship =
      AlternativeRelationshipV1::different_supported_metric;
  if (std::any_of(failures.begin(), failures.end(),
                  [](const CapabilityFailureV1& failure) {
                    return failure.kind ==
                               CapabilityFailureKindV1::scalar_coupling_only ||
                           failure.kind == CapabilityFailureKindV1::
                                               schedule_identity_not_retained;
                  })) {
    relationship = AlternativeRelationshipV1::scalar_instead_of_coupled;
  } else if (std::any_of(failures.begin(), failures.end(),
                         [](const CapabilityFailureV1& failure) {
                           return failure.axis == CapabilityAxisV1::phase ||
                                  failure.axis == CapabilityAxisV1::semantic;
                         })) {
    relationship = AlternativeRelationshipV1::weaker_temporal_contract;
  } else if (std::any_of(failures.begin(), failures.end(),
                         [](const CapabilityFailureV1& failure) {
                           return failure.axis == CapabilityAxisV1::manifest;
                         })) {
    relationship = AlternativeRelationshipV1::weaker_parameter_domain;
  }
  std::vector<ResolvedMetricTargetV1> resolved;
  if (support.ordered_targets == request_target_ids(clause)) {
    resolved = clause.origin.ordered_targets;
  }
  return CapabilityAlternativeV1{
      clause.origin.clause_id.authored_index,
      clause.origin.clause_id.metric_id,
      relationship,
      support.clause_id,
      "the selected preview exposes only the displayed weaker structural clause",
      support.semantic,
      support.runtime_access,
      std::move(resolved)};
}

[[nodiscard]] Digest256 contract_digest(
    const Digest256& requirements_digest,
    const Digest256& arrival_digest,
    const PlugDescriptorPreview& preview,
    const std::vector<ResolvedMetricContractV1>& contracts) {
  CapabilityCanonicalEncoder encoder;
  encoder.digest(requirements_digest);
  encoder.digest(arrival_digest);
  encoder.digest(preview.preview_digest);
  encoder.digest(preview.parameter_digest);
  encoder.digest(preview.budget_digest);
  encoder.digest(preview.core.core_digest);
  encoder.digest(preview.core.metric_support_manifest_digest);
  encode_vector(encoder, contracts,
                [&](const ResolvedMetricContractV1& contract) {
                  encoder.count(contract.authored_metric_index);
                  encoder.string(contract.clause_id.metric_id);
                  encoder.count(contract.clause_id.authored_index);
                  encoder.string(contract.metric_id);
                  encode_vector(
                      encoder, contract.ordered_targets,
                      [&](const ResolvedMetricTargetV1& target) {
                        encoder.strong_id(target.queue_id);
                        encoder.count(target.dense_index.ordinal());
                      });
                  encoder.enumeration(contract.semantic);
                  encoder.enumeration(contract.runtime_access);
                  encoder.enumeration(contract.target_coupling);
                  encoder.enumeration(contract.solver_regime);
                  encoder.enumeration(contract.backend_route);
                  encoder.digest(contract.support_clause_digest);
                });
  encode_vector(encoder, preview.construction_target_scope,
                [&](const QueueId& target) { encoder.strong_id(target); });
  encode_policies(encoder, preview.policies);
  encoder.enumeration(preview.construction_method);
  encoder.enumeration(preview.producer_mode);
  Result<Digest256> result =
      hash_capability_bytes("mwperf.c14.accepted_capability_contract.v1",
                            encoder);
  return result ? result.value() : zero_digest();
}

[[nodiscard]] std::string_view failure_code(
    const CapabilityFailureKindV1 kind) noexcept {
  switch (kind) {
    case CapabilityFailureKindV1::incompatible_regime:
      return "c14_capability_incompatible_regime";
    case CapabilityFailureKindV1::malformed_preview:
      return "c14_capability_malformed_preview";
    case CapabilityFailureKindV1::unsupported_manifest_clause:
      return "c14_capability_unsupported_manifest_clause";
    case CapabilityFailureKindV1::missing_semantic_contract:
      return "c14_capability_missing_semantic_contract";
    case CapabilityFailureKindV1::incompatible_runtime_access:
      return "c14_capability_incompatible_runtime_access";
    case CapabilityFailureKindV1::target_not_supported:
      return "c14_capability_target_not_supported";
    case CapabilityFailureKindV1::target_order_mismatch:
      return "c14_capability_target_order_mismatch";
    case CapabilityFailureKindV1::scalar_coupling_only:
      return "c14_capability_scalar_coupling_only";
    case CapabilityFailureKindV1::schedule_identity_not_retained:
      return "c14_capability_schedule_identity_not_retained";
    case CapabilityFailureKindV1::predictive_phase_not_retained:
      return "c14_capability_predictive_phase_not_retained";
    case CapabilityFailureKindV1::finite_horizon_too_short:
      return "c14_capability_finite_horizon_too_short";
    case CapabilityFailureKindV1::missing_mark:
      return "c14_capability_missing_mark";
    case CapabilityFailureKindV1::reveal_stage_too_late:
      return "c14_capability_reveal_stage_too_late";
    case CapabilityFailureKindV1::marks_not_from_common_realization:
      return "c14_capability_marks_not_from_common_realization";
    case CapabilityFailureKindV1::selection_not_supported:
      return "c14_capability_selection_not_supported";
    case CapabilityFailureKindV1::stationary_selection_missing:
      return "c14_capability_stationary_selection_missing";
    case CapabilityFailureKindV1::arrival_capability_missing:
      return "c14_capability_arrival_capability_missing";
    case CapabilityFailureKindV1::arrival_provision_incompatible:
      return "c14_capability_arrival_provision_incompatible";
    case CapabilityFailureKindV1::arrival_transform_domain_mismatch:
      return "c14_capability_arrival_transform_domain_mismatch";
    case CapabilityFailureKindV1::arrival_moment_order_insufficient:
      return "c14_capability_arrival_moment_order_insufficient";
    case CapabilityFailureKindV1::hypothesis_evidence_missing:
      return "c14_capability_hypothesis_evidence_missing";
    case CapabilityFailureKindV1::moment_evidence_missing:
      return "c14_capability_moment_evidence_missing";
    case CapabilityFailureKindV1::v0_not_declared:
      return "c14_capability_v0_not_declared";
    case CapabilityFailureKindV1::solver_regime_mismatch:
      return "c14_capability_solver_regime_mismatch";
    case CapabilityFailureKindV1::deterministic_accuracy_missing:
      return "c14_capability_deterministic_accuracy_missing";
    case CapabilityFailureKindV1::statistical_accuracy_mismatch:
      return "c14_capability_statistical_accuracy_mismatch";
    case CapabilityFailureKindV1::construction_prerequisite_missing:
      return "c14_capability_construction_prerequisite_missing";
    case CapabilityFailureKindV1::construction_budget_insufficient:
      return "c14_capability_construction_budget_insufficient";
    case CapabilityFailureKindV1::policy_incomplete:
      return "c14_capability_policy_incomplete";
  }
  return "c14_capability_unknown_failure";
}

[[nodiscard]] std::string axis_name(const CapabilityAxisV1 axis) {
  switch (axis) {
    case CapabilityAxisV1::regime:
      return "regime";
    case CapabilityAxisV1::preview_integrity:
      return "preview_integrity";
    case CapabilityAxisV1::manifest:
      return "manifest";
    case CapabilityAxisV1::semantic:
      return "semantic";
    case CapabilityAxisV1::runtime_access:
      return "runtime_access";
    case CapabilityAxisV1::target_scope:
      return "target_scope";
    case CapabilityAxisV1::target_coupling:
      return "target_coupling";
    case CapabilityAxisV1::phase:
      return "phase";
    case CapabilityAxisV1::mark:
      return "mark";
    case CapabilityAxisV1::selection:
      return "selection";
    case CapabilityAxisV1::arrival:
      return "arrival";
    case CapabilityAxisV1::hypothesis:
      return "hypothesis";
    case CapabilityAxisV1::moment:
      return "moment";
    case CapabilityAxisV1::mandatory_v0:
      return "mandatory_v0";
    case CapabilityAxisV1::accuracy:
      return "accuracy";
    case CapabilityAxisV1::construction_prerequisite:
      return "construction_prerequisite";
    case CapabilityAxisV1::budget:
      return "budget";
    case CapabilityAxisV1::policy:
      return "policy";
  }
  return "unknown";
}

}  // namespace

bool detail::is_valid_plug_descriptor_core_shape_v1(
    const PlugDescriptorCore& core) {
  return is_valid_core_shape(core);
}

// Narrow construction authority for the immutable accepted snapshot.  The
// public contract header befriends this class; no other C14 helper can create
// or mutate an AcceptedCapabilityContract.
class CapabilityContractAccess final {
 public:
  [[nodiscard]] static AcceptedCapabilityContract make(
      const PlugDescriptorPreview& preview,
      const MetricSupportManifest& manifest,
      const MetricRequirements& requirements,
      const ArrivalCapabilities& arrival_capabilities,
      std::vector<ResolvedMetricContractV1> metric_contracts,
      Digest256 requirements_digest, Digest256 arrival_capabilities_digest,
      Digest256 contract_digest) {
    return AcceptedCapabilityContract(
        kCapabilitySchemaVersionV1, preview.core.provider,
        preview.construction_method, preview.producer_mode,
        preview.core.payload_class, preview.core.semantic,
        preview.core.runtime_access, preview.core, manifest, requirements,
        arrival_capabilities, std::move(metric_contracts),
        preview.construction_target_scope, preview.policies,
        preview.construction_prerequisites, std::move(requirements_digest),
        std::move(arrival_capabilities_digest), preview.preview_digest,
        preview.parameter_digest, preview.budget_digest,
        std::move(contract_digest));
  }
};

// These helpers should be declared next to the preview schema when this
// fragment is integrated.  They let C14 tests and the future C16 preview
// factory create integrity-valid values without duplicating canonicalization.
Result<Digest256> canonical_plug_descriptor_core_digest_v1(
    const PlugDescriptorCore& core) {
  CapabilityCanonicalEncoder encoder;
  encode_core_without_digest(encoder, core);
  return hash_capability_bytes("mwperf.c14.plug_descriptor_core.v1", encoder);
}

Result<Digest256> canonical_plug_descriptor_preview_digest_v1(
    const PlugDescriptorPreview& preview) {
  CapabilityCanonicalEncoder encoder;
  encode_preview_without_digest(encoder, preview);
  return hash_capability_bytes("mwperf.c14.plug_descriptor_preview.v1",
                               encoder);
}

Result<Digest256> canonical_arrival_capabilities_digest_v1(
    const ArrivalCapabilities& capabilities) {
  CapabilityCanonicalEncoder encoder;
  encode_arrival_capabilities(encoder, capabilities);
  return hash_capability_bytes("mwperf.c14.arrival_capabilities.v1", encoder);
}

CapabilityDecision negotiate_capabilities(
    const MetricRequirements& requirements,
    const PlugDescriptorPreview& preview,
    const ArrivalCapabilities& arrival_capabilities) {
  Result<Digest256> requirements_digest_result =
      canonical_metric_requirements_digest(requirements);
  Result<Digest256> arrival_digest_result =
      canonical_arrival_capabilities_digest_v1(arrival_capabilities);
  const Digest256 requirements_digest = requirements_digest_result
                                            ? requirements_digest_result.value()
                                            : zero_digest();
  const Digest256 arrival_digest = arrival_digest_result
                                       ? arrival_digest_result.value()
                                       : zero_digest();

  std::vector<CapabilityFailureV1> failures;
  std::vector<CapabilityAlternativeV1> alternatives;
  std::vector<ResolvedMetricContractV1> resolved_contracts;
  const std::vector<const MetricRequirementClause*> clauses =
      clauses_in_authored_order(requirements);

  if (clauses.empty()) {
    // The public parser never produces this case.  A defensive direct caller
    // gets a closed rejection; an empty aggregate is never vacuously accepted.
    return RejectedCapabilityDecision{
        {CapabilityFailureV1{
            0U,
            MetricClauseIdV1{"<aggregate>", 0U},
            "<aggregate>",
            CapabilityAxisV1::regime,
            CapabilityFailureKindV1::incompatible_regime,
            "empty requirement aggregate",
            "one or more analysis-v1 metric clauses",
            std::nullopt,
            std::nullopt}},
        {}, requirements_digest, arrival_digest, preview.preview_digest};
  }

  const MetricRequirementClause& first_clause = *clauses.front();
  if (!requirements_digest_result) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::regime,
        CapabilityFailureKindV1::incompatible_regime,
        "noncanonical requirement aggregate",
        "canonical nonempty analysis-v1 requirements"));
  }
  if (requirements.regime_compatibility().kind !=
      RegimeCompatibilityKindV1::compatible) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::regime,
        CapabilityFailureKindV1::incompatible_regime,
        enum_text(requirements.regime_compatibility().kind),
        "one common selection and solver regime"));
  }
  if (!valid_arrival_capabilities(arrival_capabilities) ||
      !arrival_digest_result) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::arrival,
        CapabilityFailureKindV1::arrival_capability_missing,
        "non-v1 or noncanonical ArrivalCapabilities",
        "analysis-v1 configured-arrival capability record"));
  }

  const std::optional<std::string> integrity =
      preview_integrity_problem(preview);
  if (integrity.has_value()) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::preview_integrity,
        CapabilityFailureKindV1::malformed_preview, *integrity,
        "canonical callback-free parameter-resolved preview"));
  }

  if (!failures.empty()) {
    std::sort(failures.begin(), failures.end(), failure_less);
    return RejectedCapabilityDecision{
        std::move(failures), {}, requirements_digest, arrival_digest,
        preview.preview_digest};
  }

  const MetricSupportManifest& manifest = *preview.metric_support_manifest;
  if (manifest.clauses().size() != requirements.clauses().size()) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::manifest,
        CapabilityFailureKindV1::unsupported_manifest_clause,
        std::to_string(manifest.clauses().size()) + " manifest clauses",
        std::to_string(requirements.clauses().size()) +
            " exact request clauses"));
  }

  std::string policy_reason;
  if (!policies_satisfy(preview, &policy_reason)) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::policy,
        CapabilityFailureKindV1::policy_incomplete, policy_reason,
        "explicit policy values covering every structural role"));
  }
  if (!configured_arrival_covers(
          arrival_capabilities,
          preview.construction_prerequisites.arrival)) {
    failures.push_back(make_failure(
        first_clause, CapabilityAxisV1::construction_prerequisite,
        CapabilityFailureKindV1::construction_prerequisite_missing,
        "configured arrival capabilities",
        "all construction-only arrival prerequisites"));
  }

  for (const MetricRequirementClause* clause_pointer : clauses) {
    const MetricRequirementClause& clause = *clause_pointer;
    const MetricSupportClauseV1* support =
        find_manifest_clause(manifest, clause.origin.clause_id);
    if (support == nullptr) {
      failures.push_back(make_failure(
          clause, CapabilityAxisV1::manifest,
          CapabilityFailureKindV1::unsupported_manifest_clause,
          "missing structural support clause", "exact clause ID"));
      continue;
    }
    if (!manifest_clause_enveloped_by_core(*support, preview.core) ||
        !manifest_selection_envelops(*support, preview.core) ||
        !phase_support_envelops(preview.core.phase,
                                support->phase_domain)) {
      failures.push_back(make_failure(
          clause, CapabilityAxisV1::preview_integrity,
          CapabilityFailureKindV1::malformed_preview,
          "manifest clause exceeds the single descriptor tuple",
          "clause beneath the frozen core payload/semantic/access envelope"));
      continue;
    }

    std::vector<RouteEvaluation> evaluations;
    evaluations.reserve(clause.route_alternatives.size());
    for (const MetricRouteAlternativeV1& route :
         clause.route_alternatives) {
      evaluations.push_back(evaluate_route(
          clause, route, *support, preview, arrival_capabilities));
    }
    if (evaluations.empty()) {
      failures.push_back(make_failure(
          clause, CapabilityAxisV1::semantic,
          CapabilityFailureKindV1::missing_semantic_contract,
          "no route alternatives", "one complete metric route"));
      continue;
    }
    const RouteEvaluation& best = best_route_evaluation(evaluations);
    if (!best.failures.empty()) {
      failures.insert(failures.end(), best.failures.begin(),
                      best.failures.end());
      const std::optional<CapabilityAlternativeV1> alternative =
          make_alternative(clause, *support, best.failures);
      if (alternative.has_value()) {
        alternatives.push_back(*alternative);
      }
      continue;
    }

    resolved_contracts.push_back(ResolvedMetricContractV1{
        clause.origin.clause_id.authored_index,
        clause.origin.clause_id,
        clause.origin.clause_id.metric_id,
        clause.origin.ordered_targets,
        support->semantic,
        support->runtime_access,
        support->target_coupling,
        support->solver_route,
        best.route->access.backend_route,
        support_clause_digest(manifest, *support)});
  }

  // Extra manifest keys are a prebuild broadening attempt, not a capability
  // bonus.  The cardinality check above makes it sufficient to test set
  // containment here without manufacturing an authored identity for extras.
  for (const MetricSupportClauseV1& support : manifest.clauses()) {
    const bool requested = std::any_of(
        requirements.clauses().begin(), requirements.clauses().end(),
        [&](const MetricRequirementClause& clause) {
          return clause.origin.clause_id == support.clause_id;
        });
    if (!requested) {
      failures.push_back(make_failure(
          first_clause, CapabilityAxisV1::manifest,
          CapabilityFailureKindV1::unsupported_manifest_clause,
          "extra structural support clause " + support.clause_id.metric_id,
          "no clauses beyond the exact request"));
    }
  }

  if (!failures.empty()) {
    std::sort(failures.begin(), failures.end(), failure_less);
    failures.erase(std::unique(failures.begin(), failures.end()),
                   failures.end());
    std::sort(alternatives.begin(), alternatives.end(),
              [](const CapabilityAlternativeV1& left,
                 const CapabilityAlternativeV1& right) {
                return std::tie(left.source_authored_metric_index,
                                left.relationship, left.supported_clause_id) <
                       std::tie(right.source_authored_metric_index,
                                right.relationship, right.supported_clause_id);
              });
    alternatives.erase(std::unique(alternatives.begin(), alternatives.end()),
                       alternatives.end());
    return RejectedCapabilityDecision{
        std::move(failures), std::move(alternatives), requirements_digest,
        arrival_digest, preview.preview_digest};
  }

  std::sort(resolved_contracts.begin(), resolved_contracts.end(),
            [](const ResolvedMetricContractV1& left,
               const ResolvedMetricContractV1& right) {
              return std::tie(left.authored_metric_index, left.clause_id) <
                     std::tie(right.authored_metric_index, right.clause_id);
            });
  const Digest256 accepted_digest = contract_digest(
      requirements_digest, arrival_digest, preview, resolved_contracts);

  // Every member is copied by value into the accepted handoff.  Shared
  // AnalysisContext backing inside MetricRequirements is immutable, and the
  // manifest itself is copied rather than retaining the preview pointer.
  return AcceptedCapabilityDecision{CapabilityContractAccess::make(
      preview, manifest, requirements, arrival_capabilities,
      std::move(resolved_contracts), requirements_digest, arrival_digest,
      accepted_digest)};
}

Diagnostic explain_capability_failure(const CapabilityDecision& decision) {
  const auto* rejected =
      std::get_if<RejectedCapabilityDecision>(&decision);
  if (rejected == nullptr) {
    return Diagnostic{
        DiagnosticCategory::internal,
        "c14_capability_decision_is_accepted",
        "an accepted capability decision has no failure to explain",
        std::nullopt,
        std::nullopt,
        {}};
  }
  if (rejected->ordered_failures.empty()) {
    return Diagnostic{
        DiagnosticCategory::internal,
        "c14_capability_rejection_has_no_failure",
        "a rejected capability decision contains no field-level failure",
        std::nullopt,
        std::nullopt,
        {}};
  }

  const CapabilityFailureV1& first = rejected->ordered_failures.front();
  std::vector<std::string> notes;
  notes.reserve(rejected->ordered_failures.size() +
                rejected->alternatives.size());
  notes.push_back("provided: " + first.provided);
  notes.push_back("required: " + first.required);
  for (std::size_t index = 1U;
       index < rejected->ordered_failures.size(); ++index) {
    const CapabilityFailureV1& failure =
        rejected->ordered_failures[index];
    notes.push_back(
        "also metric " + failure.metric_id + " axis " +
        axis_name(failure.axis) + ": " + failure.provided +
        "; requires " + failure.required);
  }
  for (const CapabilityAlternativeV1& alternative :
       rejected->alternatives) {
    notes.push_back("informational alternative for metric " +
                    alternative.source_metric_id + ": " +
                    alternative.description);
  }
  return Diagnostic{
      DiagnosticCategory::unavailable,
      std::string(failure_code(first.kind)),
      "metric " + first.metric_id + " failed capability axis " +
          axis_name(first.axis),
      first.authored_path,
      first.json_pointer,
      std::move(notes)};
}

}  // namespace mwperf
