#include "mwperf/metrics/temporal.hpp"

#include <Eigen/Dense>

#include <boost/multiprecision/cpp_dec_float.hpp>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <limits>
#include <locale>
#include <memory>
#include <new>
#include <numbers>
#include <optional>
#include <set>
#include <sstream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "kernel/c17_temporal_bridge_internal.hpp"
#include "metrics/c22_exact_solver_internal.hpp"
#include "temporal/temporal_contract_internal.hpp"
#include "mwperf/arrival/build_view.hpp"
#include "mwperf/core/sha256.hpp"

namespace mwperf {

static_assert(std::is_signed_v<Eigen::Index> &&
                  std::numeric_limits<Eigen::Index>::digits >=
                      std::numeric_limits<std::ptrdiff_t>::digits,
              "the C27 pre-provider ptrdiff_t bound must fit Eigen::Index");

namespace metrics::detail {

struct KilledKernelCore final {
  std::shared_ptr<const TemporalSourceCore> source;
  // False means that the represented rows are accompanied by certified
  // source-law error enclosures.  F-C22-02 may expose those rows and their
  // physical exit classification, but the exact finite stopped solvers must
  // not consume them as stochastic rows.
  bool exact_source_rows;
  SafeSet safe_set;
  AbsorptionMarks absorption_marks;
  ExactKilledSystem exact_system;
  ExactKilledValidation validation;
  // KilledKernel is defined only on the nonabsorbed (safe) domain.  These
  // maps retain the relationship to the larger audited continuation source
  // without adding rows for already absorbed states.
  std::vector<std::size_t> killed_to_source;
  std::vector<std::optional<std::size_t>> source_to_killed;
  std::vector<bool> safe_nodes;
  std::vector<std::string> exit_type_ids;
  std::vector<KilledRowDiagnosticsV1> row_diagnostics;
  std::size_t source_row_atom_count;
  Digest256 source_fingerprint;
};

struct KilledPotentialCore final {
  std::shared_ptr<const KilledKernelCore> kernel;
  std::vector<PotentialCoordinateV1> coordinates;
  PotentialSolveDiagnosticsV1 diagnostics;
  Digest256 source_fingerprint;
  std::size_t zero_start_iterations;
  bool budget_stop;
};

}  // namespace metrics::detail

namespace detail {

class TemporalContractCoreAccess final {
 public:
  TemporalContractCoreAccess() = delete;
  [[nodiscard]] static const metrics::detail::InitialLawCore& core(
      const InitialLaw& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::KilledKernelCore& core(
      const KilledKernel& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      metrics::detail::KilledKernelCore>& core_ptr(
      const KilledKernel& value) noexcept {
    return value.core_;
  }
  [[nodiscard]] static const metrics::detail::KilledPotentialCore& core(
      const KilledPotential& value) noexcept {
    return *value.core_;
  }

  [[nodiscard]] static KilledKernel killed_kernel(
      std::shared_ptr<const metrics::detail::KilledKernelCore> core) {
    return KilledKernel(std::move(core));
  }
  [[nodiscard]] static KilledPotential killed_potential(
      std::shared_ptr<const metrics::detail::KilledPotentialCore> core) {
    return KilledPotential(std::move(core));
  }
  [[nodiscard]] static InitialLaw initial_law(
      std::shared_ptr<const metrics::detail::InitialLawCore> core) {
    return InitialLaw(std::move(core));
  }

};

}  // namespace detail

namespace {

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    DiagnosticCategory category = DiagnosticCategory::input_validation,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

[[nodiscard]] Result<std::size_t> bounded_size(const BigNat& value,
                                               const std::string_view role) {
  const BigInt& exact = value.value();
  if (exact < 0 || exact > BigInt(std::numeric_limits<std::size_t>::max())) {
    return fail<std::size_t>(
        "c22.temporal_index_out_of_range",
        std::string(role) + " exceeds the addressable C22 finite range",
        DiagnosticCategory::resource_limit);
  }
  return Result<std::size_t>::success(exact.convert_to<std::size_t>());
}

[[nodiscard]] bool same_owner(
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>& left,
    const std::shared_ptr<const metrics::detail::TemporalSourceCore>& right) {
  return left && right && left.get() == right.get() &&
         !left.owner_before(right) && !right.owner_before(left);
}

[[nodiscard]] bool source_kind_requires_projection_binding(
    const AuditedTemporalSourceKindV1 kind) noexcept {
  switch (kind) {
    case AuditedTemporalSourceKindV1::framework_v0:
    case AuditedTemporalSourceKindV1::transient_dispatch:
      return false;
    case AuditedTemporalSourceKindV1::stationary_projection:
    case AuditedTemporalSourceKindV1::passive_fifo_tag:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_cylinder_source_kind(
    const AuditedTemporalSourceKindV1 kind) noexcept {
  switch (kind) {
    case AuditedTemporalSourceKindV1::framework_v0:
    case AuditedTemporalSourceKindV1::stationary_projection:
    case AuditedTemporalSourceKindV1::transient_dispatch:
      return true;
    case AuditedTemporalSourceKindV1::passive_fifo_tag:
      return false;
  }
  return false;
}

[[nodiscard]] bool valid_kernel_source_kind(
    const AuditedTemporalSourceKindV1 kind) noexcept {
  switch (kind) {
    case AuditedTemporalSourceKindV1::framework_v0:
    case AuditedTemporalSourceKindV1::stationary_projection:
    case AuditedTemporalSourceKindV1::transient_dispatch:
    case AuditedTemporalSourceKindV1::passive_fifo_tag:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_temporal_law_source_kind(
    const AuditedTemporalSourceKindV1 kind) noexcept {
  switch (kind) {
    case AuditedTemporalSourceKindV1::framework_v0:
    case AuditedTemporalSourceKindV1::stationary_projection:
      return true;
    case AuditedTemporalSourceKindV1::transient_dispatch:
    case AuditedTemporalSourceKindV1::passive_fifo_tag:
      return false;
  }
  return false;
}

template <typename View>
[[nodiscard]] Result<void> require_temporal_view_seal(
    const View& view,
    const metrics::detail::TemporalSourceBindingV1& binding) {
#if defined(MWPERF_C22_TEST_SEAMS)
  // C22's nonproduction synthetic mints intentionally carry no C17 framework
  // core.  Their fresh typed seal is still compared across every synthetic
  // source/entrance pairing.  Production carriers may never take this path.
  if (!kernel::detail::c17_temporal_view_has_framework_core(view)) {
    return Result<void>::success();
  }
#endif
  return kernel::detail::c17_require_temporal_view_seal(view,
                                                        binding.seal_token);
}

template <typename View>
[[nodiscard]] bool temporal_view_binding_matches(
    const View& view,
    const metrics::detail::TemporalSourceCore& source) noexcept {
  if (source.binding.kind != view.source_kind() ||
      source.binding.source_fingerprint != view.source_fingerprint()) {
    return false;
  }
  const bool requires_projection =
      source_kind_requires_projection_binding(source.binding.kind);
  if (source.binding.projection_fingerprint.has_value() !=
      requires_projection) {
    return false;
  }
  const Digest256& expected_projection =
      source.binding.projection_fingerprint.has_value()
          ? *source.binding.projection_fingerprint
          : source.binding.source_fingerprint;
  return nonzero_digest(expected_projection) &&
         view.projection_fingerprint() == expected_projection;
}

[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> require_source(
    const AuditedCylinderLaw& law) {
  if (!valid_cylinder_source_kind(law.source_kind())) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c22.invalid_cylinder_source_alternative",
        "AuditedCylinderLaw accepts only framework_v0, "
        "stationary_projection, or transient_dispatch sources");
  }
  auto source_result = kernel::detail::c17_temporal_source(law);
  if (!source_result) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(
            source_result.error());
  }
  const auto source = std::move(source_result).value();
  if (!source || !temporal_view_binding_matches(law, *source) ||
      !source->exact_rows || !source->projectively_consistent) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c22.cylinder_source_binding_mismatch",
        "the audited cylinder law has no matching exact projectively "
        "consistent source",
        DiagnosticCategory::unavailable);
  }
  auto seal = require_temporal_view_seal(law, source->binding);
  if (!seal) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(seal.error());
  }
  return Result<std::shared_ptr<const
      metrics::detail::TemporalSourceCore>>::success(source);
}

[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> require_source(
    const AuditedTemporalKernel& kernel) {
  if (!valid_kernel_source_kind(kernel.source_kind())) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c22.invalid_temporal_kernel_source_alternative",
        "AuditedTemporalKernel received an unknown closed source tag");
  }
  auto source_result =
      ::mwperf::kernel::detail::c17_temporal_source(kernel);
  if (!source_result) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(
            source_result.error());
  }
  const auto source = std::move(source_result).value();
  const bool rows_available_for_kernel =
      source &&
      (source->complete_rows ||
       source->binding.kind ==
           AuditedTemporalSourceKindV1::transient_dispatch);
  if (!source || !temporal_view_binding_matches(kernel, *source) ||
      !rows_available_for_kernel) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c22.temporal_kernel_source_binding_mismatch",
        "the audited temporal kernel has no matching certified source or "
        "safe-domain stopped restriction",
        DiagnosticCategory::unavailable);
  }
  auto seal = require_temporal_view_seal(kernel, source->binding);
  if (!seal) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(seal.error());
  }
  return Result<std::shared_ptr<const
      metrics::detail::TemporalSourceCore>>::success(source);
}

[[nodiscard]] Result<std::shared_ptr<const
    metrics::detail::TemporalSourceCore>> require_source(
    const AuditedTemporalLaw& law) {
  if (!valid_temporal_law_source_kind(law.source_kind())) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c22.invalid_temporal_law_source_alternative",
        "AuditedTemporalLaw accepts only framework_v0 or "
        "stationary_projection sources");
  }
  auto source_result = kernel::detail::c17_temporal_source(law);
  if (!source_result) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(
            source_result.error());
  }
  const auto source = std::move(source_result).value();
  if (!source || !temporal_view_binding_matches(law, *source) ||
      !source->exact_rows || !source->complete_rows ||
      source->stationary_entrance.empty()) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c22.temporal_law_source_binding_mismatch",
        "the audited temporal law has no matching stationary exact source",
        DiagnosticCategory::unavailable);
  }
  auto seal = require_temporal_view_seal(law, source->binding);
  if (!seal) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(seal.error());
  }
  return Result<std::shared_ptr<const
      metrics::detail::TemporalSourceCore>>::success(source);
}

[[nodiscard]] Result<void> validate_temporal_source(
    const metrics::detail::TemporalSourceCore& source) {
  const metrics::detail::TemporalSourceBindingV1& binding = source.binding;
  const bool requires_projection =
      source_kind_requires_projection_binding(binding.kind);
  const bool projection_binding_valid =
      binding.projection_fingerprint.has_value() == requires_projection &&
      (!binding.projection_fingerprint.has_value() ||
       nonzero_digest(*binding.projection_fingerprint));
  if (source.nodes.empty() || !binding.seal_token ||
      !valid_kernel_source_kind(binding.kind) ||
      !nonzero_digest(binding.source_fingerprint) ||
      !nonzero_digest(binding.accepted_contract_identity) ||
      !nonzero_digest(binding.normalized_requirements_identity) ||
      !nonzero_digest(binding.authored_analysis_identity) ||
      !nonzero_digest(binding.resolved_instance_identity) ||
      !nonzero_digest(binding.target_selection_identity) ||
      !nonzero_digest(binding.configured_arrival_identity) ||
      !nonzero_digest(binding.selection_identity) ||
      !nonzero_digest(binding.exact_state_schema_identity) ||
      !nonzero_digest(binding.reduced_state_schema_identity) ||
      !nonzero_digest(binding.mark_schema_identity) ||
      !nonzero_digest(binding.continuation_schema_identity) ||
      !nonzero_digest(binding.target_service_schema_identity) ||
      !nonzero_digest(binding.timing_identity) ||
      !projection_binding_valid || binding.state_codec.id.empty() ||
      binding.state_codec.version == 0U) {
    return fail<void>(
        "c22.invalid_temporal_source_identity",
        "an audited temporal source has an empty domain, incomplete proof "
        "identity, or invalid projection-binding rule");
  }
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    const auto& node = source.nodes[state];
    if (!(node.decoded_state.codec == source.binding.state_codec) ||
        (source.complete_rows && node.transitions.empty())) {
      return fail<void>(
          "c22.invalid_temporal_source_state",
          "an audited temporal node has a foreign codec or an unavailable "
          "required exact row",
          DiagnosticCategory::input_validation,
          {"state index " + std::to_string(state)});
    }
    ExactRational total = ExactRational::zero();
    for (const auto& transition : node.transitions) {
      if (transition.successor_index >= source.nodes.size() ||
          !transition.exact_mass.is_positive() ||
          !(transition.edge.pre_state == node.decoded_state) ||
          transition.edge.prearrival_target_backlog !=
              node.state_target_backlog ||
          !(transition.edge.successor_state ==
            source.nodes[transition.successor_index].decoded_state)) {
        return fail<void>(
            "c22.invalid_temporal_source_transition",
            "an audited temporal transition is off-domain, nonpositive, or "
            "not adjacent to its decoded states",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      total = total + transition.exact_mass;
    }
    if (source.exact_rows) {
      if (node.source_row_error_enclosure.has_value()) {
        return fail<void>(
            "c22.exact_temporal_source_has_error_enclosure",
            "an exact audited temporal row must not carry an analytic "
            "source-law error enclosure",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      if (!node.transitions.empty() &&
          !(total == ExactRational::one())) {
        return fail<void>(
            "c22.exact_temporal_source_row_not_unit",
            "an exact audited temporal row does not have mass one; it is "
            "not repaired or normalized",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state),
             "mass " + total.to_canonical_string()});
      }
    } else if (!node.transitions.empty()) {
      if (!node.source_row_error_enclosure.has_value()) {
        return fail<void>(
            "c22.analytic_temporal_source_enclosure_missing",
            "an analytic audited temporal row requires a certified "
            "full-row source-law error enclosure",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      const auto& enclosure = *node.source_row_error_enclosure;
      const ExactRational required_error = ExactRational::one() - total;
      if (enclosure.upper < enclosure.lower ||
          required_error < enclosure.lower ||
          required_error > enclosure.upper) {
        return fail<void>(
            "c22.analytic_temporal_source_enclosure_not_covering_unity",
            "the represented analytic row plus its certified source-law "
            "error enclosure does not cover unit mass",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state),
             "represented mass " + total.to_canonical_string(),
             "required error " + required_error.to_canonical_string(),
             "error lower " + enclosure.lower.to_canonical_string(),
             "error upper " + enclosure.upper.to_canonical_string()});
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool backlog_relation(const BigNat& value,
                                    const BacklogRelationV1 relation,
                                    const BigNat& level) {
  switch (relation) {
    case BacklogRelationV1::equal:
      return value == level;
    case BacklogRelationV1::at_or_above:
      return value >= level;
    case BacklogRelationV1::at_or_below:
      return value <= level;
  }
  return false;
}

[[nodiscard]] Result<bool> matches_state(
    const TemporalStatePredicateV1& predicate,
    const metrics::detail::TemporalNodeCore& node) {
  return std::visit(
      [&](const auto& typed) -> Result<bool> {
        using T = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<T, AnyStatePredicateV1>) {
          return Result<bool>::success(true);
        } else if constexpr (std::is_same_v<T, ExactStatePredicateV1>) {
          return Result<bool>::success(node.decoded_state == typed.state);
        } else {
          if (typed.target_ordinal >=
              node.state_target_backlog.size()) {
            return fail<bool>(
                "c22.state_predicate_target_not_retained",
                "a state predicate requests an absent target backlog mark",
                DiagnosticCategory::unavailable);
          }
          const BigNat& backlog =
              node.state_target_backlog[typed.target_ordinal];
          if constexpr (std::is_same_v<T, TargetBacklogPredicateV1>) {
            return Result<bool>::success(
                backlog_relation(backlog, typed.relation, typed.level));
          } else if constexpr (std::is_same_v<
                                   T,
                                   TargetBacklogOutsideHitSetPredicateV1>) {
            BacklogRelationV1 relation = BacklogRelationV1::equal;
            switch (typed.hit_set.kind) {
              case HitSetKind::at_or_above:
                relation = BacklogRelationV1::at_or_above;
                break;
              case HitSetKind::at_or_below:
                relation = BacklogRelationV1::at_or_below;
                break;
              case HitSetKind::equal:
                relation = BacklogRelationV1::equal;
                break;
            }
            return Result<bool>::success(
                !backlog_relation(backlog, relation, typed.hit_set.level));
          } else {
            return std::visit(
                [&](const auto& binary) -> Result<bool> {
                  using B = std::decay_t<decltype(binary)>;
                  if constexpr (std::is_same_v<B,
                                               BasicBinaryPredicateV1>) {
                    switch (binary) {
                      case BasicBinaryPredicateV1::busy:
                        return Result<bool>::success(!backlog.is_zero());
                      case BasicBinaryPredicateV1::idle:
                        return Result<bool>::success(backlog.is_zero());
                      case BasicBinaryPredicateV1::busy_denial:
                        return fail<bool>(
                            "c22.busy_denial_requires_edge_mark",
                            "busy denial depends on actual departure and "
                            "cannot be decoded from state alone",
                            DiagnosticCategory::unavailable);
                    }
                  } else {
                    return Result<bool>::success(backlog > binary.threshold);
                  }
                  return Result<bool>::success(false);
                },
                typed.predicate);
          }
        }
      },
      predicate);
}

[[nodiscard]] Result<bool> matches_edge(
    const TemporalEdgePredicateV1& predicate,
    const MarkedFluxEdgeV1& edge) {
  return std::visit(
      [&](const auto& typed) -> Result<bool> {
        using T = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<T, AnyEdgePredicateV1>) {
          return Result<bool>::success(true);
        } else if constexpr (std::is_same_v<T,
                                             TargetDeparturePredicateV1>) {
          if (typed.target_ordinal >= edge.target_departures.size()) {
            return fail<bool>(
                "c22.edge_predicate_departure_mark_missing",
                "a departure predicate requests an absent retained target",
                DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              (edge.target_departures[typed.target_ordinal] != 0U) ==
              typed.value);
        } else if constexpr (std::is_same_v<
                                 T, PositiveTargetArrivalPredicateV1>) {
          if (typed.target_ordinal >= edge.target_arrivals.size()) {
            return fail<bool>(
                "c22.edge_predicate_arrival_mark_missing",
                "an arrival predicate requests an absent retained target",
                DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              !edge.target_arrivals[typed.target_ordinal].is_zero());
        } else if constexpr (std::is_same_v<T,
                                             BusyDenialEdgePredicateV1>) {
          if (typed.target_ordinal >= edge.target_departures.size() ||
              typed.target_ordinal >=
                  edge.prearrival_target_backlog.size()) {
            return fail<bool>(
                "c22.busy_denial_marks_missing",
                "busy denial requires retained backlog and actual departure",
                DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              !edge.prearrival_target_backlog[typed.target_ordinal].is_zero() &&
              edge.target_departures[typed.target_ordinal] == 0U);
        } else {
          const CausalMarkV1* retained = nullptr;
          std::size_t id_matches = 0U;
          for (const CausalMarkV1& mark : edge.marks) {
            if (mark.mark.mark == typed.mark_id) {
              ++id_matches;
              retained = &mark;
            }
          }
          if (id_matches == 0U) {
            return fail<bool>(
                "c22.runtime_mark_not_retained",
                "a temporal predicate requests a mark ID absent from the "
                "audited retained-mark alphabet",
                DiagnosticCategory::unavailable);
          }
          if (id_matches > 1U) {
            return fail<bool>(
                "c22.duplicate_runtime_mark",
                "a retained temporal edge contains more than one value for "
                "the requested mark ID",
                DiagnosticCategory::internal);
          }
          if (!(retained->mark.value.codec == typed.codec)) {
            return fail<bool>(
                "c22.runtime_mark_codec_mismatch",
                "the requested temporal mark ID is retained under a "
                "different canonical value codec",
                DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              retained->mark.value.canonical_value == typed.canonical_value);
        }
      },
      predicate);
}

class EnvelopeEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void u32(const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void frame(const std::span<const std::byte> value) {
    if (value.size() > std::numeric_limits<std::uint32_t>::max()) {
      throw std::length_error("C22 envelope frame exceeds u32");
    }
    u32(static_cast<std::uint32_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void text(const std::string_view value) {
    frame(std::as_bytes(std::span(value.data(), value.size())));
  }
  void rational(const ExactRational& value) {
    text(value.numerator_decimal());
    text(value.denominator_decimal());
  }
  void natural(const BigNat& value) { text(value.to_decimal_string()); }
  void floating(const long double value) {
    if (!std::isfinite(value)) {
      throw std::domain_error("C22 envelope requires finite image");
    }
    std::ostringstream stream;
    stream.imbue(std::locale::classic());
    stream << std::hexfloat
           << std::setprecision(std::numeric_limits<long double>::max_digits10)
           << (value == 0.0L ? 0.0L : value);
    text(stream.str());
  }
  [[nodiscard]] std::vector<std::byte> finish() && {
    return std::move(bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

struct MetricEnvelope final {
  MetricEnvelope(
      std::string kind_value, Digest256 source_fingerprint_value,
      std::vector<ExactRational> exact_values_value,
      std::vector<long double> numerical_values_value,
      std::vector<BigNat> indices_value, const bool rectangular,
      const bool radians, const long double error_bound,
      const std::size_t steps,
      TemporalMetricBudgetReportV1 temporal_budget_value,
      std::vector<ExactRational> authored_frequencies = {},
      const bool error_certified = false,
      std::optional<ExactRational> authored_tolerance = std::nullopt,
      ExactRational probability_kernel_error = ExactRational::zero(),
      const bool enclosure_is_whole_range = false,
      std::optional<StoppedMetricBundle> stopped = std::nullopt,
      std::vector<ExactRational> killed_row_residuals = {})
      : kind(std::move(kind_value)),
        source_fingerprint(std::move(source_fingerprint_value)),
        exact_values(std::move(exact_values_value)),
        numerical_values(std::move(numerical_values_value)),
        indices(std::move(indices_value)),
        rectangular_truncation(rectangular),
        angular_radians(radians),
        transcendental_error_bound(error_bound),
        completed_steps(steps),
        authored_angular_frequencies_radians(
            std::move(authored_frequencies)),
        transcendental_error_certified(error_certified),
        authored_absolute_tolerance(std::move(authored_tolerance)),
        exact_probability_kernel_error(std::move(probability_kernel_error)),
        conservative_transcendental_enclosure_radius(error_bound),
        transcendental_enclosure_is_whole_range(enclosure_is_whole_range),
        stopped_metric(std::move(stopped)),
        exact_killed_row_balance_residuals(std::move(killed_row_residuals)),
        temporal_budget(std::move(temporal_budget_value)) {}

  std::string kind;
  Digest256 source_fingerprint;
  std::vector<ExactRational> exact_values;
  std::vector<long double> numerical_values;
  std::vector<BigNat> indices;
  bool rectangular_truncation{false};
  bool angular_radians{false};
  long double transcendental_error_bound{0.0L};
  std::size_t completed_steps{0U};
  std::vector<ExactRational> authored_angular_frequencies_radians;
  bool transcendental_error_certified{false};
  std::optional<ExactRational> authored_absolute_tolerance;
  ExactRational exact_probability_kernel_error{ExactRational::zero()};
  long double conservative_transcendental_enclosure_radius{0.0L};
  bool transcendental_enclosure_is_whole_range{false};
  std::optional<StoppedMetricBundle> stopped_metric;
  std::vector<ExactRational> exact_killed_row_balance_residuals;
  TemporalMetricBudgetReportV1 temporal_budget;
};

[[nodiscard]] Result<MetricValue> encode_metric(MetricEnvelope envelope) {
  try {
    const auto exceeds_u32 = [](const std::size_t size) noexcept {
      return size > std::numeric_limits<std::uint32_t>::max();
    };
    if (exceeds_u32(envelope.exact_values.size()) ||
        exceeds_u32(envelope.numerical_values.size()) ||
        exceeds_u32(envelope.indices.size()) ||
        exceeds_u32(
            envelope.authored_angular_frequencies_radians.size()) ||
        exceeds_u32(envelope.exact_killed_row_balance_residuals.size())) {
      return fail<MetricValue>(
          "c22.metric_output_too_large",
          "a C22 temporal result exceeds the version-1 output envelope",
          DiagnosticCategory::resource_limit);
    }
    EnvelopeEncoder encoder;
    encoder.u32(1U);
    encoder.text(envelope.kind);
    encoder.frame(envelope.source_fingerprint.bytes());
    encoder.u32(static_cast<std::uint32_t>(envelope.exact_values.size()));
    for (const auto& value : envelope.exact_values) {
      encoder.rational(value);
    }
    encoder.u32(
        static_cast<std::uint32_t>(envelope.numerical_values.size()));
    for (const long double value : envelope.numerical_values) {
      encoder.floating(value);
    }
    encoder.u32(static_cast<std::uint32_t>(envelope.indices.size()));
    for (const BigNat& value : envelope.indices) {
      encoder.natural(value);
    }
    encoder.byte(envelope.rectangular_truncation ? 1U : 0U);
    encoder.byte(envelope.angular_radians ? 1U : 0U);
    encoder.floating(envelope.transcendental_error_bound);
    encoder.u64(static_cast<std::uint64_t>(envelope.completed_steps));
    encoder.u32(static_cast<std::uint32_t>(
        envelope.authored_angular_frequencies_radians.size()));
    for (const auto& frequency :
         envelope.authored_angular_frequencies_radians) {
      encoder.rational(frequency);
    }
    encoder.byte(envelope.transcendental_error_certified ? 1U : 0U);
    encoder.byte(envelope.authored_absolute_tolerance.has_value() ? 1U : 0U);
    if (envelope.authored_absolute_tolerance.has_value()) {
      encoder.rational(*envelope.authored_absolute_tolerance);
    }
    encoder.rational(envelope.exact_probability_kernel_error);
    encoder.floating(
        envelope.conservative_transcendental_enclosure_radius);
    encoder.byte(envelope.transcendental_enclosure_is_whole_range ? 1U : 0U);

    const auto encode_optional_size = [&](const std::optional<std::size_t>& value) {
      encoder.byte(value.has_value() ? 1U : 0U);
      if (value.has_value()) {
        encoder.u64(static_cast<std::uint64_t>(*value));
      }
    };
    const auto encode_optional_floating =
        [&](const std::optional<long double>& value) {
          encoder.byte(value.has_value() ? 1U : 0U);
          if (value.has_value()) {
            encoder.floating(*value);
          }
        };
    const auto encode_optional_rational =
        [&](const std::optional<ExactRational>& value) {
          encoder.byte(value.has_value() ? 1U : 0U);
          if (value.has_value()) {
            encoder.rational(*value);
          }
        };
    const auto encode_optional_natural =
        [&](const std::optional<BigNat>& value) {
          encoder.byte(value.has_value() ? 1U : 0U);
          if (value.has_value()) {
            encoder.natural(*value);
          }
        };
    const auto encode_optional_rationals =
        [&](const std::vector<std::optional<ExactRational>>& values) {
          if (exceeds_u32(values.size())) {
            throw std::length_error(
                "C22 stopped residual vector exceeds u32");
          }
          encoder.u32(static_cast<std::uint32_t>(values.size()));
          for (const auto& value : values) {
            encoder.byte(value.has_value() ? 1U : 0U);
            if (value.has_value()) {
              encoder.rational(*value);
            }
          }
        };
    const auto encode_solve_diagnostics =
        [&](const StoppedSolveDiagnosticsV1& diagnostics) {
          encoder.byte(static_cast<std::uint8_t>(diagnostics.status));
          encoder.u64(static_cast<std::uint64_t>(diagnostics.iterations));
          encode_optional_size(diagnostics.system_dimension);
          encode_optional_size(diagnostics.exact_rank);
          encode_optional_rationals(diagnostics.exact_equation_residuals);
          encode_optional_rationals(diagnostics.exact_auxiliary_residuals);
          encode_optional_floating(
              diagnostics.reciprocal_condition_estimate);
          encode_optional_floating(diagnostics.condition_warning_threshold);
          encoder.byte(diagnostics.condition_warning ? 1U : 0U);
          encoder.text(diagnostics.method);
        };

    encoder.u64(static_cast<std::uint64_t>(
        envelope.temporal_budget.actual_state_count));
    encoder.u64(static_cast<std::uint64_t>(
        envelope.temporal_budget.actual_row_atom_count));
    encoder.u64(static_cast<std::uint64_t>(
        envelope.temporal_budget.requested_horizon));
    encode_optional_size(envelope.temporal_budget.permitted_horizon);
    encoder.u64(static_cast<std::uint64_t>(
        envelope.temporal_budget.authorized_maximum_state_offset));
    encode_optional_size(
        envelope.temporal_budget.authorized_maximum_edge_offset);
    encode_optional_size(envelope.temporal_budget.maximum_states);
    encode_optional_size(envelope.temporal_budget.maximum_row_atoms);
    encoder.u64(static_cast<std::uint64_t>(
        envelope.temporal_budget.solver_iterations));
    encode_optional_natural(
        envelope.temporal_budget.authored_maximum_solver_iterations);
    encode_optional_size(
        envelope.temporal_budget.maximum_solver_iterations);
    encode_optional_rational(
        envelope.temporal_budget.absolute_residual_tolerance);
    encode_optional_rational(
        envelope.temporal_budget.relative_residual_tolerance);
    encoder.byte(envelope.temporal_budget.budget_stop ? 1U : 0U);

    encoder.byte(envelope.stopped_metric.has_value() ? 1U : 0U);
    if (envelope.stopped_metric.has_value()) {
      const StoppedMetricBundle& stopped = *envelope.stopped_metric;
      if (stopped.source_fingerprint != envelope.source_fingerprint ||
          exceeds_u32(stopped.survival_tails.size()) ||
          exceeds_u32(stopped.absorption_masses.size()) ||
          exceeds_u32(stopped.eventual_typed_exit_probabilities.size())) {
        return fail<MetricValue>(
            "c22.stopped_metric_envelope_identity_or_size_mismatch",
            "a stopped temporal envelope has a foreign source identity or "
            "an unencodable result vector",
            DiagnosticCategory::internal);
      }
      encoder.byte(static_cast<std::uint8_t>(stopped.initial_law_kind));
      encoder.u32(static_cast<std::uint32_t>(stopped.survival_tails.size()));
      for (const auto& tail : stopped.survival_tails) {
        encoder.natural(tail.index);
        encoder.rational(tail.exact_probability);
      }
      encoder.u32(
          static_cast<std::uint32_t>(stopped.absorption_masses.size()));
      for (const auto& mass : stopped.absorption_masses) {
        encoder.natural(mass.hitting_time);
        encoder.text(mass.type_id);
        encoder.rational(mass.exact_probability);
      }
      encoder.u32(static_cast<std::uint32_t>(
          stopped.eventual_typed_exit_probabilities.size()));
      for (const auto& probability :
           stopped.eventual_typed_exit_probabilities) {
        encoder.text(probability.type_id);
        encoder.rational(probability.exact_probability);
      }
      encoder.rational(stopped.exact_defect_probability);
      encoder.byte(static_cast<std::uint8_t>(stopped.absorption_status));
      encoder.byte(
          static_cast<std::uint8_t>(stopped.mean_stopping_time.status));
      encoder.byte(stopped.mean_stopping_time.exact_value.has_value() ? 1U
                                                                     : 0U);
      if (stopped.mean_stopping_time.exact_value.has_value()) {
        encoder.rational(*stopped.mean_stopping_time.exact_value);
      }
      encoder.u64(static_cast<std::uint64_t>(
          stopped.budget.requested_horizon));
      encoder.u64(static_cast<std::uint64_t>(stopped.budget.state_count));
      encoder.u64(
          static_cast<std::uint64_t>(stopped.budget.row_atom_count));
      encoder.u64(static_cast<std::uint64_t>(stopped.budget.iterations));
      encode_optional_size(stopped.budget.maximum_states);
      encode_optional_size(stopped.budget.maximum_row_atoms);
      encode_optional_size(stopped.budget.maximum_iterations);
      encode_optional_natural(stopped.budget.authored_maximum_iterations);
      encoder.rational(stopped.budget.absolute_residual_tolerance);
      encoder.rational(stopped.budget.relative_residual_tolerance);
      encoder.byte(stopped.budget.budget_stop ? 1U : 0U);
      encoder.byte(
          stopped.finite_results_preserved_when_mean_unavailable ? 1U : 0U);
      encoder.byte(
          stopped.typed_exit_defect_solve_diagnostics.has_value() ? 1U : 0U);
      if (stopped.typed_exit_defect_solve_diagnostics.has_value()) {
        encode_solve_diagnostics(
            *stopped.typed_exit_defect_solve_diagnostics);
      }
      encoder.byte(stopped.potential_solve_diagnostics.has_value() ? 1U :
                                                                    0U);
      if (stopped.potential_solve_diagnostics.has_value()) {
        encode_solve_diagnostics(*stopped.potential_solve_diagnostics);
      }
      encoder.u32(static_cast<std::uint32_t>(
          envelope.exact_killed_row_balance_residuals.size()));
      for (const auto& residual :
           envelope.exact_killed_row_balance_residuals) {
        encoder.rational(residual);
      }
    } else if (!envelope.exact_killed_row_balance_residuals.empty()) {
      return fail<MetricValue>(
          "c22.orphan_killed_row_residuals",
          "killed-row residuals cannot be reported without stopped result "
          "metadata",
          DiagnosticCategory::internal);
    }
    return Result<MetricValue>::success(MetricValue{
        CodecIdentityV1{"mwperf.c22.temporal_metric", 1U},
        std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c22.metric_encoding_allocation_failure",
        "encoding a C22 temporal result exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c22.metric_encoding_failure",
        "a C22 temporal result could not be encoded",
        DiagnosticCategory::internal);
  }
}

using ExactVector = std::vector<ExactRational>;

[[nodiscard]] ExactRational vector_sum(const ExactVector& values) {
  ExactRational result = ExactRational::zero();
  for (const ExactRational& value : values) {
    result = result + value;
  }
  return result;
}

[[nodiscard]] Result<TemporalMetricBudgetReportV1> temporal_metric_budget(
    const metrics::detail::TemporalSourceCore& source,
    const std::size_t requested_horizon,
    std::optional<std::size_t> permitted_horizon = std::nullopt,
    const std::size_t solver_iterations = 0U,
    std::optional<BigNat> authored_maximum_solver_iterations = std::nullopt,
    std::optional<std::size_t> maximum_solver_iterations = std::nullopt,
    std::optional<ExactRational> absolute_residual_tolerance = std::nullopt,
    std::optional<ExactRational> relative_residual_tolerance = std::nullopt,
    const bool budget_stop = false) {
  std::size_t row_atom_count = 0U;
  for (const auto& node : source.nodes) {
    if (node.transitions.size() >
        std::numeric_limits<std::size_t>::max() - row_atom_count) {
      return fail<TemporalMetricBudgetReportV1>(
          "c22.metric_budget_row_atom_count_overflow",
          "the retained temporal row-atom count exceeds size_t",
          DiagnosticCategory::resource_limit);
    }
    row_atom_count += node.transitions.size();
  }
  return Result<TemporalMetricBudgetReportV1>::success(
      TemporalMetricBudgetReportV1{
          source.nodes.size(), row_atom_count, requested_horizon,
          std::move(permitted_horizon), source.maximum_state_offset,
          source.maximum_edge_offset, source.maximum_states_budget,
          source.maximum_row_atoms_budget, solver_iterations,
          std::move(authored_maximum_solver_iterations),
          std::move(maximum_solver_iterations),
          std::move(absolute_residual_tolerance),
          std::move(relative_residual_tolerance), budget_stop});
}

[[nodiscard]] std::size_t temporal_maximum_row_width(
    const metrics::detail::TemporalSourceCore& source) noexcept {
  std::size_t result = 0U;
  for (const auto& node : source.nodes) {
    result = std::max(result, node.transitions.size());
  }
  return result;
}

[[nodiscard]] Result<ExactVector> entrance_vector(
    const metrics::detail::TemporalSourceCore& source,
    const std::span<const metrics::detail::TemporalEntranceAtomCore> atoms) {
  ExactVector result(source.nodes.size(), ExactRational::zero());
  for (const auto& atom : atoms) {
    if (atom.node_index >= source.nodes.size() ||
        !(atom.decoded_state == source.nodes[atom.node_index].decoded_state) ||
        !atom.exact_mass.is_nonnegative()) {
      return fail<ExactVector>(
          "c22.invalid_temporal_entrance_atom",
          "a temporal entrance atom is off-domain, negative, or state-"
          "inconsistent");
    }
    result[atom.node_index] =
        result[atom.node_index] + atom.exact_mass;
  }
  if (!(vector_sum(result) == ExactRational::one())) {
    return fail<ExactVector>(
        "c22.temporal_entrance_mass_not_one",
        "a temporal entrance must have exact unit mass and is never "
        "renormalized");
  }
  return Result<ExactVector>::success(std::move(result));
}

[[nodiscard]] ExactVector advance_vector(
    const metrics::detail::TemporalSourceCore& source,
    const ExactVector& current) {
  ExactVector next(source.nodes.size(), ExactRational::zero());
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    if (current[state].is_zero()) {
      continue;
    }
    for (const auto& transition : source.nodes[state].transitions) {
      next[transition.successor_index] =
          next[transition.successor_index] +
          current[state] * transition.exact_mass;
    }
  }
  return next;
}

// Coalesce the explicitly represented part of an analytically certified
// killed row.  Unlike validate_exact_killed_system, this deliberately does
// not require the represented source mass to be one.  The difference from
// unity is certified separately on TemporalNodeCore and is not inserted into
// either the survivor matrix or a typed physical-exit column.
[[nodiscard]] Result<metrics::detail::ExactKilledValidation>
validate_analytic_killed_representation(
    const metrics::detail::ExactKilledSystem& system) {
  if (system.state_count == 0U ||
      system.rows.size() != system.state_count) {
    return fail<metrics::detail::ExactKilledValidation>(
        "c22.invalid_analytic_killed_dimensions",
        "an analytic killed representation requires one row per safe "
        "state");
  }
  if (system.state_count >
      std::numeric_limits<std::size_t>::max() / system.state_count ||
      (system.exit_type_count != 0U &&
       system.state_count >
           std::numeric_limits<std::size_t>::max() /
               system.exit_type_count)) {
    return fail<metrics::detail::ExactKilledValidation>(
        "c22.analytic_killed_dense_dimension_overflow",
        "the analytic killed representation exceeds addressable dense "
        "dimensions",
        DiagnosticCategory::resource_limit);
  }

  std::vector<ExactRational> survivor_matrix(
      system.state_count * system.state_count, ExactRational::zero());
  std::vector<ExactRational> typed_exit_matrix(
      system.state_count * system.exit_type_count, ExactRational::zero());
  std::vector<metrics::detail::ExactKilledRowAudit> audits;
  audits.reserve(system.state_count);
  for (std::size_t state = 0U; state < system.state_count; ++state) {
    const auto& row = system.rows[state];
    if (!row.exact_source_mass.is_nonnegative()) {
      return fail<metrics::detail::ExactKilledValidation>(
          "c22.negative_analytic_source_image",
          "an analytic killed row has a negative represented source mass",
          DiagnosticCategory::input_validation,
          {"state index " + std::to_string(state)});
    }
    ExactRational survivor_total = ExactRational::zero();
    for (const auto& atom : row.survivors) {
      if (atom.successor_index >= system.state_count ||
          !atom.exact_mass.is_nonnegative()) {
        return fail<metrics::detail::ExactKilledValidation>(
            "c22.invalid_analytic_survivor_atom",
            "an analytic survivor atom is negative or off-domain",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      const std::size_t offset =
          state * system.state_count + atom.successor_index;
      survivor_matrix[offset] =
          survivor_matrix[offset] + atom.exact_mass;
      survivor_total = survivor_total + atom.exact_mass;
    }
    std::vector<ExactRational> exit_totals(
        system.exit_type_count, ExactRational::zero());
    ExactRational exit_total = ExactRational::zero();
    for (const auto& atom : row.typed_exits) {
      if (atom.exit_type_index >= system.exit_type_count ||
          !atom.exact_mass.is_nonnegative()) {
        return fail<metrics::detail::ExactKilledValidation>(
            "c22.invalid_analytic_exit_atom",
            "an analytic typed-exit atom is negative or names an unknown "
            "exit type",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
      const std::size_t offset =
          state * system.exit_type_count + atom.exit_type_index;
      typed_exit_matrix[offset] =
          typed_exit_matrix[offset] + atom.exact_mass;
      exit_totals[atom.exit_type_index] =
          exit_totals[atom.exit_type_index] + atom.exact_mass;
      exit_total = exit_total + atom.exact_mass;
    }
    const ExactRational classified = survivor_total + exit_total;
    const ExactRational balance = classified - row.exact_source_mass;
    if (!balance.is_zero()) {
      return fail<metrics::detail::ExactKilledValidation>(
          "c22.analytic_killed_classification_mismatch",
          "the represented analytic survivor and typed-exit atoms do not "
          "reproduce the represented source row",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state)});
    }
    audits.push_back(metrics::detail::ExactKilledRowAudit{
        state, row.exact_source_mass, survivor_total,
        std::move(exit_totals), classified, balance});
  }
  return Result<metrics::detail::ExactKilledValidation>::success(
      metrics::detail::ExactKilledValidation{
          std::move(audits), std::move(survivor_matrix),
          std::move(typed_exit_matrix)});
}

}  // namespace

AuditedTemporalSourceKindV1 KilledKernel::source_kind() const noexcept {
  return core_->source->binding.kind;
}
const Digest256& KilledKernel::source_fingerprint() const noexcept {
  return core_->source_fingerprint;
}
std::span<const std::string> KilledKernel::exit_type_ids() const noexcept {
  return core_->exit_type_ids;
}
std::span<const KilledRowDiagnosticsV1>
KilledKernel::row_diagnostics() const noexcept {
  return core_->row_diagnostics;
}
std::size_t KilledKernel::state_count() const noexcept {
  return core_->exact_system.state_count;
}

std::span<const PotentialCoordinateV1> KilledPotential::coordinates()
    const noexcept {
  return core_->coordinates;
}
const PotentialSolveDiagnosticsV1& KilledPotential::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const Digest256& KilledPotential::source_fingerprint() const noexcept {
  return core_->source_fingerprint;
}

namespace {

[[nodiscard]] Result<bool> state_observations_match(
    const CylinderEvent& event, const std::size_t offset,
    const metrics::detail::TemporalNodeCore& node) {
  for (const auto& observation : event.observations) {
    const auto* state = std::get_if<StateAtV1>(&observation);
    if (state == nullptr) {
      continue;
    }
    auto authored = bounded_size(state->offset, "a StateAt offset");
    if (!authored) {
      return Result<bool>::failure(authored.error());
    }
    if (authored.value() == offset) {
      auto matches = matches_state(state->predicate, node);
      if (!matches) {
        return matches;
      }
      if (!matches.value()) {
        return Result<bool>::success(false);
      }
    }
  }
  return Result<bool>::success(true);
}

[[nodiscard]] Result<bool> edge_observations_match(
    const CylinderEvent& event, const std::size_t offset,
    const MarkedFluxEdgeV1& edge) {
  for (const auto& observation : event.observations) {
    const auto* mark = std::get_if<EdgeMarkAtV1>(&observation);
    if (mark == nullptr) {
      continue;
    }
    auto authored = bounded_size(mark->offset, "an EdgeMarkAt offset");
    if (!authored) {
      return Result<bool>::failure(authored.error());
    }
    if (authored.value() == offset) {
      auto matches = matches_edge(mark->predicate, edge);
      if (!matches) {
        return matches;
      }
      if (!matches.value()) {
        return Result<bool>::success(false);
      }
    }
  }
  return Result<bool>::success(true);
}

}  // namespace

Result<MetricValue> evaluate_finite_cylinder(
    const AuditedCylinderLaw& law, const CylinderEvent& event,
    const Horizon& horizon) {
  try {
    auto source_result = require_source(law);
    if (!source_result) {
      return Result<MetricValue>::failure(source_result.error());
    }
    const auto& source = *source_result.value();
    auto valid = validate_temporal_source(source);
    if (!valid) {
      return Result<MetricValue>::failure(valid.error());
    }
    auto permitted = bounded_size(horizon, "the cylinder horizon");
    if (!permitted) {
      return Result<MetricValue>::failure(permitted.error());
    }

    std::size_t steps = 0U;
    std::vector<BigNat> authored_offsets;
    authored_offsets.reserve(event.observations.size());
    for (const auto& observation : event.observations) {
      if (const auto* state = std::get_if<StateAtV1>(&observation)) {
        auto offset = bounded_size(state->offset, "a StateAt offset");
        if (!offset) {
          return Result<MetricValue>::failure(offset.error());
        }
        if (offset.value() > source.maximum_state_offset) {
          return fail<MetricValue>(
              "c22.state_offset_beyond_temporal_budget",
              "a requested state offset exceeds the audited cylinder "
              "budget",
              DiagnosticCategory::resource_limit);
        }
        steps = std::max(steps, offset.value());
        authored_offsets.push_back(state->offset);
      } else {
        const auto& mark = std::get<EdgeMarkAtV1>(observation);
        auto offset = bounded_size(mark.offset, "an EdgeMarkAt offset");
        if (!offset) {
          return Result<MetricValue>::failure(offset.error());
        }
        if (!source.maximum_edge_offset.has_value() ||
            offset.value() > *source.maximum_edge_offset ||
            offset.value() == std::numeric_limits<std::size_t>::max()) {
          return fail<MetricValue>(
              "c22.edge_offset_beyond_temporal_budget",
              "a requested edge offset exceeds the audited cylinder budget",
              DiagnosticCategory::resource_limit);
        }
        steps = std::max(steps, offset.value() + 1U);
        authored_offsets.push_back(mark.offset);
      }
    }
    if (steps > permitted.value()) {
      return fail<MetricValue>(
          "c22.cylinder_horizon_too_short",
          "the supplied horizon does not cover the typed cylinder offsets",
          DiagnosticCategory::input_validation,
          {"required completed steps " + std::to_string(steps),
           "supplied horizon " + std::to_string(permitted.value())});
    }

    auto initial = entrance_vector(source, source.stationary_entrance);
    if (!initial) {
      return Result<MetricValue>::failure(initial.error());
    }
    ExactVector current(source.nodes.size(), ExactRational::zero());
    for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
      if (initial.value()[state].is_zero()) {
        continue;
      }
      auto matches = state_observations_match(event, 0U,
                                              source.nodes[state]);
      if (!matches) {
        return Result<MetricValue>::failure(matches.error());
      }
      if (matches.value()) {
        current[state] = initial.value()[state];
      }
    }

    for (std::size_t step = 0U; step < steps; ++step) {
      ExactVector next(source.nodes.size(), ExactRational::zero());
      for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
        if (current[state].is_zero()) {
          continue;
        }
        for (const auto& transition : source.nodes[state].transitions) {
          auto edge_matches =
              edge_observations_match(event, step, transition.edge);
          if (!edge_matches) {
            return Result<MetricValue>::failure(edge_matches.error());
          }
          if (!edge_matches.value()) {
            continue;
          }
          auto state_matches = state_observations_match(
              event, step + 1U,
              source.nodes[transition.successor_index]);
          if (!state_matches) {
            return Result<MetricValue>::failure(state_matches.error());
          }
          if (!state_matches.value()) {
            continue;
          }
          next[transition.successor_index] =
              next[transition.successor_index] +
              current[state] * transition.exact_mass;
        }
      }
      current = std::move(next);
    }
    const ExactRational probability = vector_sum(current);
    if (!probability.is_nonnegative() ||
        probability > ExactRational::one()) {
      return fail<MetricValue>(
          "c22.cylinder_probability_out_of_range",
          "exact finite-cylinder propagation produced a value outside "
          "[0,1]",
          DiagnosticCategory::internal);
    }
    auto budget = temporal_metric_budget(source, steps, permitted.value());
    if (!budget) {
      return Result<MetricValue>::failure(budget.error());
    }
    return encode_metric(MetricEnvelope{
        "finite_cylinder_probability", source.binding.source_fingerprint,
        {probability}, {}, std::move(authored_offsets), false, false, 0.0L,
        steps, std::move(budget).value()});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c22.cylinder_allocation_failure",
        "finite-cylinder evaluation exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c22.cylinder_exception",
        "finite-cylinder evaluation raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<KilledKernel> construct_killed_kernel(
    const AuditedTemporalKernel& kernel, const SafeSet& safe_set,
    const AbsorptionMarks& absorption_marks) {
  try {
    auto source_result = require_source(kernel);
    if (!source_result) {
      return Result<KilledKernel>::failure(source_result.error());
    }
    const auto source = source_result.value();
    auto valid = validate_temporal_source(*source);
    if (!valid) {
      return Result<KilledKernel>::failure(valid.error());
    }
    std::set<std::string> type_ids;
    for (const auto& type : absorption_marks.types) {
      if (type.type_id.empty() || !type_ids.insert(type.type_id).second) {
        return fail<KilledKernel>(
            "c22.invalid_absorption_type_domain",
            "typed absorption identifiers must be nonempty and unique");
      }
    }

    std::vector<bool> safe_nodes(source->nodes.size(), false);
    for (std::size_t state = 0U; state < source->nodes.size(); ++state) {
      auto safe = matches_state(safe_set.predicate, source->nodes[state]);
      if (!safe) {
        return Result<KilledKernel>::failure(safe.error());
      }
      safe_nodes[state] = safe.value();
    }

    std::vector<std::size_t> killed_to_source;
    std::vector<std::optional<std::size_t>> source_to_killed(
        source->nodes.size());
    killed_to_source.reserve(source->nodes.size());
    for (std::size_t source_state = 0U;
         source_state < source->nodes.size(); ++source_state) {
      if (!safe_nodes[source_state]) {
        continue;
      }
      source_to_killed[source_state] = killed_to_source.size();
      killed_to_source.push_back(source_state);
    }
    if (killed_to_source.empty()) {
      return fail<KilledKernel>(
          "c22.empty_safe_state_domain",
          "a killed continuation requires at least one nonabsorbed safe "
          "state; already absorbed states are not completed with rows");
    }

    metrics::detail::ExactKilledSystem exact_system{
        killed_to_source.size(), absorption_marks.types.size(), {}};
    exact_system.rows.reserve(killed_to_source.size());
    std::size_t row_atom_count = 0U;
    for (std::size_t state = 0U; state < killed_to_source.size(); ++state) {
      const std::size_t source_state = killed_to_source[state];
      if (source->nodes[source_state].transitions.empty()) {
        return fail<KilledKernel>(
            "c22.safe_temporal_row_unavailable",
            "an audited stopped restriction omits the exact row of a safe "
            "state; only typed absorbed terminal states may omit rows",
            DiagnosticCategory::unavailable,
            {"source state index " + std::to_string(source_state)});
      }
      metrics::detail::ExactKilledRow row{{}, {}, ExactRational::zero()};
      if (row_atom_count >
          std::numeric_limits<std::size_t>::max() -
              source->nodes[source_state].transitions.size()) {
        return fail<KilledKernel>(
            "c22.killed_row_atom_count_overflow",
            "the exact killed-domain row-atom count overflows size_t",
            DiagnosticCategory::resource_limit);
      }
      row_atom_count += source->nodes[source_state].transitions.size();
      for (const auto& transition :
           source->nodes[source_state].transitions) {
        row.exact_source_mass =
            row.exact_source_mass + transition.exact_mass;
        std::optional<std::size_t> exit_type;
        for (std::size_t type = 0U; type < absorption_marks.types.size();
             ++type) {
          const auto& declared = absorption_marks.types[type];
          auto state_match = matches_state(
              declared.successor_predicate,
              source->nodes[transition.successor_index]);
          if (!state_match) {
            return Result<KilledKernel>::failure(state_match.error());
          }
          auto edge_match = matches_edge(declared.edge_predicate,
                                         transition.edge);
          if (!edge_match) {
            return Result<KilledKernel>::failure(edge_match.error());
          }
          if (state_match.value() && edge_match.value()) {
            if (exit_type.has_value()) {
              return fail<KilledKernel>(
                  "c22.overlapping_absorption_sets",
                  "one positive source atom satisfies more than one typed "
                  "absorption predicate",
                  DiagnosticCategory::input_validation,
                  {"source state index " + std::to_string(source_state),
                   "first type " +
                       absorption_marks.types[*exit_type].type_id,
                   "second type " + declared.type_id});
            }
            exit_type = type;
          }
        }
        const bool successor_is_safe =
            safe_nodes[transition.successor_index];
        if (exit_type.has_value()) {
          row.typed_exits.push_back(
              metrics::detail::ExactKilledTypedExit{
                  *exit_type, transition.exact_mass});
        } else if (successor_is_safe) {
          if (!source_to_killed[transition.successor_index].has_value()) {
            return fail<KilledKernel>(
                "c22.safe_successor_index_missing",
                "a safe temporal successor has no killed-domain index",
                DiagnosticCategory::internal);
          }
          row.survivors.push_back(
              metrics::detail::ExactKilledTransition{
                  *source_to_killed[transition.successor_index],
                  transition.exact_mass});
        } else {
          return fail<KilledKernel>(
              "c22.unclassified_killed_exit",
              "a positive transition leaves the safe set without matching "
              "one declared physical absorption type; missing mass is not "
              "invented",
              DiagnosticCategory::input_validation,
              {"source state index " + std::to_string(source_state),
               "successor source index " +
                   std::to_string(transition.successor_index)});
        }
      }
      exact_system.rows.push_back(std::move(row));
    }

    auto row_validation = source->exact_rows
                              ? metrics::detail::validate_exact_killed_system(
                                    exact_system)
                              : validate_analytic_killed_representation(
                                    exact_system);
    if (!row_validation) {
      return Result<KilledKernel>::failure(row_validation.error());
    }
    std::vector<KilledRowDiagnosticsV1> diagnostics;
    diagnostics.reserve(row_validation.value().rows.size());
    for (const auto& row : row_validation.value().rows) {
      long double typed = 0.0L;
      long double typed_correction = 0.0L;
      for (const auto& mass : row.exact_typed_exit_masses) {
        const long double value = mass.to_long_double();
        const long double next = typed + value;
        typed_correction +=
            std::fabs(typed) >= std::fabs(value)
                ? (typed - next) + value
                : (value - next) + typed;
        typed = next;
      }
      typed += typed_correction;
      const long double source_image = row.exact_source_mass.to_long_double();
      const long double survivor_image =
          row.exact_survivor_mass.to_long_double();
      const long double balance = survivor_image + typed - source_image;
      if (!std::isfinite(source_image) || !std::isfinite(survivor_image) ||
          !std::isfinite(typed) || !std::isfinite(balance)) {
        return fail<KilledKernel>(
            "c22.killed_row_numerically_unresolved",
            "an exact killed row has no finite promoted numerical image",
            DiagnosticCategory::unavailable);
      }
      ExactRational source_error_lower = ExactRational::zero();
      ExactRational source_error_upper = ExactRational::zero();
      if (!source->exact_rows) {
        if (row.state_index >= killed_to_source.size()) {
          return fail<KilledKernel>(
              "c22.analytic_killed_source_index_missing",
              "an analytic killed-row audit has no source-domain index",
              DiagnosticCategory::internal);
        }
        const auto& enclosure =
            source->nodes[killed_to_source[row.state_index]]
                .source_row_error_enclosure;
        if (!enclosure.has_value()) {
          return fail<KilledKernel>(
              "c22.analytic_killed_source_enclosure_missing",
              "an analytic killed row lost its certified source-law error "
              "enclosure",
              DiagnosticCategory::internal);
        }
        source_error_lower = enclosure->lower;
        source_error_upper = enclosure->upper;
      }
      diagnostics.push_back(KilledRowDiagnosticsV1{
          row.state_index,
          row.exact_source_mass,
          row.exact_survivor_mass,
          row.exact_typed_exit_masses,
          row.exact_balance_residual,
          source_image,
          survivor_image,
          typed,
          balance,
          std::move(source_error_lower),
          std::move(source_error_upper)});
    }
    std::vector<std::string> exit_ids;
    exit_ids.reserve(absorption_marks.types.size());
    for (const auto& type : absorption_marks.types) {
      exit_ids.push_back(type.type_id);
    }
    auto core =
        std::make_shared<const metrics::detail::KilledKernelCore>(
            metrics::detail::KilledKernelCore{
                source,
                source->exact_rows,
                safe_set,
                absorption_marks,
                std::move(exact_system),
                std::move(row_validation).value(),
                std::move(killed_to_source),
                std::move(source_to_killed),
                std::move(safe_nodes),
                std::move(exit_ids),
                std::move(diagnostics),
                row_atom_count,
                source->binding.source_fingerprint});
    return Result<KilledKernel>::success(
        detail::TemporalContractCoreAccess::killed_kernel(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<KilledKernel>(
        "c22.killed_kernel_allocation_failure",
        "constructing a certified killed kernel exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<KilledKernel>(
        "c22.killed_kernel_exception",
        "constructing a certified killed kernel raised an unexpected "
        "exception",
        DiagnosticCategory::internal);
  }
}

Result<KilledPotential> compute_minimal_killed_potential(
    const KilledKernel& kernel, const SolverPolicy& policy) {
  try {
    if (policy.linear_method != LinearMethod::dense_pivoted) {
      return fail<KilledPotential>(
          "c22.killed_solver_method_unavailable",
          "the exact finite C22 minimal-potential route implements only "
          "the declared dense_pivoted solver",
          DiagnosticCategory::unavailable);
    }
    if (!policy.absolute_residual_tolerance.is_nonnegative() ||
        !policy.relative_residual_tolerance.is_zero() ||
        !nonzero_digest(policy.analysis_fingerprint)) {
      return fail<KilledPotential>(
          "c22.invalid_killed_solver_policy",
          "the C22 minimal-potential solver requires the bound analysis-v1 "
          "policy, nonnegative absolute tolerance, and zero relative "
          "tolerance");
    }
    const long double tolerance_image =
        policy.absolute_residual_tolerance.to_long_double();
    if (!std::isfinite(tolerance_image) || tolerance_image < 0.0L) {
      return fail<KilledPotential>(
          "c22.killed_solver_tolerance_unusable",
          "the exact residual tolerance has no finite nonnegative "
          "long-double image",
          DiagnosticCategory::unavailable);
    }
    const auto& core = detail::TemporalContractCoreAccess::core(kernel);
    if (policy.analysis_fingerprint !=
        core.source->binding.authored_analysis_identity) {
      return fail<KilledPotential>(
          "c22.killed_solver_policy_binding_mismatch",
          "the solver policy belongs to a foreign authored analysis");
    }
    if (!core.exact_source_rows) {
      return fail<KilledPotential>(
          "c22.analytic_killed_potential_numerically_unresolved",
          "the audited analytic rows retain a certified source-law error "
          "enclosure, but analysis-v1 has no certified interval Neumann "
          "potential solver",
          DiagnosticCategory::unavailable);
    }
    std::optional<std::size_t> maximum_iterations;
    if (policy.max_iterations.has_value()) {
      auto converted = bounded_size(*policy.max_iterations,
                                    "a solver iteration budget");
      if (converted) {
        maximum_iterations = converted.value();
      }
    }

    // A zero authored iteration budget is a deliberate incomplete solve.  It
    // must not be bypassed by the direct factorization: return the classified
    // domain with unresolved coordinates and let F-C22-04 preserve any finite
    // tails it already computed.
    if (policy.max_iterations.has_value() &&
        policy.max_iterations->is_zero()) {
      auto classification =
          metrics::detail::classify_exact_survivor_support(core.exact_system);
      if (!classification) {
        return Result<KilledPotential>::failure(classification.error());
      }
      std::vector<PotentialCoordinateV1> coordinates;
      coordinates.reserve(core.exact_system.state_count);
      std::size_t finite_dimension = 0U;
      for (std::size_t state = 0U; state < core.exact_system.state_count;
           ++state) {
        if (!classification.value().can_reach_closed_survivor[state]) {
          ++finite_dimension;
        }
        coordinates.push_back(PotentialCoordinateV1{
            state,
            ExtendedNonnegativeV1{
                ExtendedNonnegativeStatusV1::not_established,
                std::nullopt},
            std::nullopt});
      }
      std::vector<std::vector<std::size_t>> closed;
      closed.reserve(
          classification.value().closed_survivor_classes.size());
      for (const auto& component :
           classification.value().closed_survivor_classes) {
        closed.push_back(component.member_indices);
      }
      const long double eta =
          std::max<std::size_t>(1U, finite_dimension) *
          std::numeric_limits<long double>::epsilon();
      PotentialSolveDiagnosticsV1 diagnostics{
          std::move(closed),
          finite_dimension,
          0U,
          0.0L,
          std::sqrt(eta),
          true,
          "zero_start_iteration_budget_stop_before_direct_acceleration",
          0U,
          policy.max_iterations,
          maximum_iterations,
          policy.absolute_residual_tolerance,
          policy.relative_residual_tolerance,
          true};
      auto result_core =
          std::make_shared<const metrics::detail::KilledPotentialCore>(
              metrics::detail::KilledPotentialCore{
                  detail::TemporalContractCoreAccess::core_ptr(kernel),
                  std::move(coordinates), std::move(diagnostics),
                  core.source_fingerprint, 0U, true});
      return Result<KilledPotential>::success(
          detail::TemporalContractCoreAccess::killed_potential(
              std::move(result_core)));
    }
    auto exact = metrics::detail::compute_exact_minimal_potential(
        core.exact_system);
    if (!exact) {
      return Result<KilledPotential>::failure(exact.error());
    }
    if (!exact.value().zero_start_monotone ||
        !exact.value().direct_acceleration_certified ||
        exact.value().zero_start_certificate_iterations == 0U) {
      return fail<KilledPotential>(
          "c22.killed_potential_minimality_certificate_failed",
          "the exact direct potential solve lacks its zero-start monotonicity "
          "and full-rank minimal-branch certificate",
          DiagnosticCategory::internal);
    }
    std::vector<PotentialCoordinateV1> coordinates;
    coordinates.reserve(exact.value().coordinates.size());
    std::vector<std::size_t> finite_indices;
    for (std::size_t state = 0U;
         state < exact.value().coordinates.size(); ++state) {
      const auto& value = exact.value().coordinates[state];
      if (value.status == metrics::detail::ExactPotentialStatus::finite) {
        finite_indices.push_back(state);
        coordinates.push_back(PotentialCoordinateV1{
            state,
            ExtendedNonnegativeV1{
                ExtendedNonnegativeStatusV1::finite, value.exact_value},
            exact.value().exact_equation_residuals[state]});
      } else {
        coordinates.push_back(PotentialCoordinateV1{
            state,
            ExtendedNonnegativeV1{
                ExtendedNonnegativeStatusV1::positive_infinity,
                std::nullopt},
            std::nullopt});
      }
    }

    long double reciprocal_condition = 1.0L;
    if (!finite_indices.empty()) {
      const Eigen::Index dimension =
          static_cast<Eigen::Index>(finite_indices.size());
      Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> matrix(
          dimension, dimension);
      for (Eigen::Index row = 0; row < dimension; ++row) {
        for (Eigen::Index column = 0; column < dimension; ++column) {
          const std::size_t source =
              finite_indices[static_cast<std::size_t>(row)];
          const std::size_t destination =
              finite_indices[static_cast<std::size_t>(column)];
          long double value =
              -core.validation
                   .survivor_matrix[source * core.exact_system.state_count +
                                    destination]
                   .to_long_double();
          if (row == column) {
            value += 1.0L;
          }
          matrix(row, column) = value;
        }
      }
      Eigen::FullPivLU<decltype(matrix)> decomposition;
      decomposition.compute(matrix);
      reciprocal_condition = decomposition.rcond();
      if (!std::isfinite(reciprocal_condition) ||
          reciprocal_condition < 0.0L) {
        reciprocal_condition = 0.0L;
      }
    }
    const long double eta =
        std::max<std::size_t>(1U, finite_indices.size()) *
        std::numeric_limits<long double>::epsilon();
    const long double warning_threshold = std::sqrt(eta);
    std::vector<std::vector<std::size_t>> closed;
    for (const auto& component :
         exact.value().classification.closed_survivor_classes) {
      closed.push_back(component.member_indices);
    }
    PotentialSolveDiagnosticsV1 diagnostics{
        std::move(closed),
        exact.value().finite_system_dimension,
        exact.value().finite_system_rank,
        reciprocal_condition,
        warning_threshold,
        reciprocal_condition < warning_threshold,
        "zero_start_minimality_certificate_with_exact_pivoted_acceleration",
        exact.value().zero_start_certificate_iterations,
        policy.max_iterations,
        maximum_iterations,
        policy.absolute_residual_tolerance,
        policy.relative_residual_tolerance,
        false};
    auto result_core =
        std::make_shared<const metrics::detail::KilledPotentialCore>(
            metrics::detail::KilledPotentialCore{
                detail::TemporalContractCoreAccess::core_ptr(kernel),
                std::move(coordinates), std::move(diagnostics),
                core.source_fingerprint,
                exact.value().zero_start_certificate_iterations, false});
    return Result<KilledPotential>::success(
        detail::TemporalContractCoreAccess::killed_potential(
            std::move(result_core)));
  } catch (const std::bad_alloc&) {
    return fail<KilledPotential>(
        "c22.killed_potential_allocation_failure",
        "computing the exact minimal potential exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<KilledPotential>(
        "c22.killed_potential_exception",
        "computing the exact minimal potential raised an unexpected "
        "exception",
        DiagnosticCategory::internal);
  }
}

namespace {

[[nodiscard]] bool entrance_kind_matches_source(
    const InitialLawKindV1 entrance,
    const AuditedTemporalSourceKindV1 source) {
  switch (entrance) {
    case InitialLawKindV1::stationary:
      return source == AuditedTemporalSourceKindV1::stationary_projection;
    case InitialLawKindV1::transient:
      return source == AuditedTemporalSourceKindV1::transient_dispatch;
    case InitialLawKindV1::event_palm:
      return source == AuditedTemporalSourceKindV1::stationary_projection;
    case InitialLawKindV1::fifo_tag:
      return source == AuditedTemporalSourceKindV1::passive_fifo_tag;
  }
  return false;
}

[[nodiscard]] bool initial_kind_requires_projection_binding(
    const InitialLawKindV1 kind) noexcept {
  switch (kind) {
    case InitialLawKindV1::transient:
      return false;
    case InitialLawKindV1::stationary:
    case InitialLawKindV1::event_palm:
    case InitialLawKindV1::fifo_tag:
      return true;
  }
  return false;
}

[[nodiscard]] bool initial_law_binding_matches_source(
    const metrics::detail::InitialLawCore& entrance) noexcept {
  if (!entrance.source ||
      entrance.source_fingerprint !=
          entrance.source->binding.source_fingerprint ||
      !entrance_kind_matches_source(entrance.kind,
                                    entrance.source->binding.kind)) {
    return false;
  }
  const bool requires_projection =
      initial_kind_requires_projection_binding(entrance.kind);
  if (entrance.has_projection_binding != requires_projection ||
      entrance.source->binding.projection_fingerprint.has_value() !=
          requires_projection) {
    return false;
  }
  const Digest256& expected_projection =
      entrance.source->binding.projection_fingerprint.has_value()
          ? *entrance.source->binding.projection_fingerprint
          : entrance.source->binding.source_fingerprint;
  return nonzero_digest(expected_projection) &&
         entrance.projection_fingerprint == expected_projection;
}

[[nodiscard]] Result<std::optional<std::size_t>> optional_size(
    const std::optional<BigNat>& value) {
  if (!value.has_value()) {
    return Result<std::optional<std::size_t>>::success(std::nullopt);
  }
  auto converted = bounded_size(*value, "a solver iteration budget");
  if (!converted) {
    return Result<std::optional<std::size_t>>::failure(converted.error());
  }
  return Result<std::optional<std::size_t>>::success(
      std::optional<std::size_t>{converted.value()});
}

struct StoppedConditionReport final {
  std::optional<long double> reciprocal_condition;
  std::optional<long double> warning_threshold;
  bool warning;
};

[[nodiscard]] StoppedConditionReport stopped_condition_report(
    const metrics::detail::ExactKilledValidation& validation,
    const std::size_t state_count,
    const std::span<const std::size_t> retained_states) {
  if (retained_states.empty()) {
    return {1.0L,
            std::sqrt(std::numeric_limits<long double>::epsilon()), false};
  }
  if (retained_states.size() >
      static_cast<std::size_t>(std::numeric_limits<Eigen::Index>::max())) {
    return {std::nullopt, std::nullopt, true};
  }
  const Eigen::Index dimension =
      static_cast<Eigen::Index>(retained_states.size());
  Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> matrix(
      dimension, dimension);
  for (Eigen::Index row = 0; row < dimension; ++row) {
    for (Eigen::Index column = 0; column < dimension; ++column) {
      const std::size_t source =
          retained_states[static_cast<std::size_t>(row)];
      const std::size_t destination =
          retained_states[static_cast<std::size_t>(column)];
      long double value =
          -validation
               .survivor_matrix[source * state_count + destination]
               .to_long_double();
      if (row == column) {
        value += 1.0L;
      }
      matrix(row, column) = value;
    }
  }
  Eigen::FullPivLU<decltype(matrix)> decomposition;
  decomposition.compute(matrix);
  long double reciprocal = decomposition.rcond();
  if (!std::isfinite(reciprocal) || reciprocal < 0.0L) {
    reciprocal = 0.0L;
  }
  const long double eta =
      std::max<std::size_t>(1U, retained_states.size()) *
      std::numeric_limits<long double>::epsilon();
  const long double threshold = std::sqrt(eta);
  return {reciprocal, threshold, reciprocal < threshold};
}

[[nodiscard]] StoppedSolveDiagnosticsV1 unavailable_stopped_solve(
    const StoppedSolveStatusV1 status, const std::string& method) {
  return StoppedSolveDiagnosticsV1{
      status, 0U, std::nullopt, std::nullopt, {}, {}, std::nullopt,
      std::nullopt, false, method};
}

[[nodiscard]] StoppedSolveDiagnosticsV1 typed_exit_solve_diagnostics(
    const metrics::detail::KilledKernelCore& killed,
    const metrics::detail::ExactMinimalTypedExitProbabilities& exact) {
  std::vector<bool> closed_member(killed.exact_system.state_count, false);
  for (const auto& component :
       exact.classification.closed_survivor_classes) {
    for (const std::size_t state : component.member_indices) {
      closed_member[state] = true;
    }
  }
  std::vector<std::size_t> transient_states;
  transient_states.reserve(killed.exact_system.state_count);
  for (std::size_t state = 0U; state < closed_member.size(); ++state) {
    if (!closed_member[state]) {
      transient_states.push_back(state);
    }
  }
  const StoppedConditionReport condition = stopped_condition_report(
      killed.validation, killed.exact_system.state_count, transient_states);
  std::vector<std::optional<ExactRational>> residuals;
  residuals.reserve(exact.exact_equation_residuals.size());
  for (const ExactRational& residual : exact.exact_equation_residuals) {
    residuals.emplace_back(residual);
  }
  std::vector<std::optional<ExactRational>> defect_residuals;
  defect_residuals.reserve(exact.exact_defect_residuals.size());
  for (const ExactRational& residual : exact.exact_defect_residuals) {
    defect_residuals.emplace_back(residual);
  }
  return StoppedSolveDiagnosticsV1{
      StoppedSolveStatusV1::established,
      exact.zero_start_certificate_iterations,
      exact.transient_system_dimension,
      exact.transient_system_rank,
      std::move(residuals),
      std::move(defect_residuals),
      condition.reciprocal_condition,
      condition.warning_threshold,
      condition.warning,
      "zero_start_minimality_certificate_with_exact_pivoted_typed_exit_"
      "acceleration"};
}

[[nodiscard]] StoppedSolveDiagnosticsV1 potential_solve_diagnostics(
    const KilledPotential& potential) {
  const auto& core = detail::TemporalContractCoreAccess::core(potential);
  std::vector<std::optional<ExactRational>> residuals;
  residuals.reserve(core.coordinates.size());
  for (const PotentialCoordinateV1& coordinate : core.coordinates) {
    residuals.push_back(coordinate.exact_equation_residual);
  }
  return StoppedSolveDiagnosticsV1{
      core.budget_stop ? StoppedSolveStatusV1::budget_stopped
                       : StoppedSolveStatusV1::established,
      core.zero_start_iterations,
      core.diagnostics.finite_dimension,
      core.diagnostics.exact_rank,
      std::move(residuals),
      {},
      core.diagnostics.reciprocal_condition_estimate,
      core.diagnostics.condition_warning_threshold,
      core.diagnostics.condition_warning,
      core.diagnostics.method};
}

}  // namespace

Result<StoppedMetricBundle> evaluate_hit_survival_absorption(
    const KilledKernel& kernel, const InitialLaw& initial_law,
    const HorizonSpec& horizon, const SolverPolicy& policy) {
  try {
    const auto& killed = detail::TemporalContractCoreAccess::core(kernel);
    const auto& entrance =
        detail::TemporalContractCoreAccess::core(initial_law);
    if (!same_owner(killed.source, entrance.source) ||
        entrance.source_fingerprint != killed.source_fingerprint ||
        entrance.source->binding.source_fingerprint !=
            killed.source_fingerprint ||
        !initial_law_binding_matches_source(entrance)) {
      return fail<StoppedMetricBundle>(
          "c22.killed_kernel_initial_law_binding_mismatch",
          "the killed kernel and closed entrance alternative do not share "
          "one source owner, fingerprint, schema, and timing identity");
    }
    if (policy.analysis_fingerprint !=
            killed.source->binding.authored_analysis_identity ||
        !policy.absolute_residual_tolerance.is_nonnegative() ||
        !policy.relative_residual_tolerance.is_zero()) {
      return fail<StoppedMetricBundle>(
          "c22.stopped_solver_policy_binding_mismatch",
          "the stopped evaluator requires the solver policy of the same "
          "authored analysis, a nonnegative absolute tolerance, and the "
          "analysis-v1 zero relative tolerance");
    }
    if (!killed.exact_source_rows) {
      return fail<StoppedMetricBundle>(
          "c22.analytic_stopped_recursion_numerically_unresolved",
          "the killed kernel retains its analytic source-law error "
          "enclosures, but analysis-v1 has no certified interval stopped "
          "recursion; no source residual is relabelled as absorption",
          DiagnosticCategory::unavailable);
    }
    auto maximum = bounded_size(horizon.maximum_tail_index,
                                "the stopped tail horizon");
    if (!maximum) {
      return Result<StoppedMetricBundle>::failure(maximum.error());
    }
    if (maximum.value() == std::numeric_limits<std::size_t>::max()) {
      return fail<StoppedMetricBundle>(
          "c22.stopped_horizon_dimension_overflow",
          "the stopped tail horizon leaves no addressable slot for tail "
          "index zero",
          DiagnosticCategory::resource_limit);
    }
    auto initial = entrance_vector(*killed.source, entrance.atoms);
    if (!initial) {
      return Result<StoppedMetricBundle>::failure(initial.error());
    }
    for (std::size_t state = 0U; state < initial.value().size(); ++state) {
      if (initial.value()[state].is_positive() &&
          !killed.safe_nodes[state]) {
        return fail<StoppedMetricBundle>(
            "c22.initial_law_not_supported_on_safe_set",
            "a stopped entrance assigns positive mass to an already "
            "absorbed state",
            DiagnosticCategory::input_validation,
            {"state index " + std::to_string(state)});
      }
    }
    ExactVector safe_initial(killed.exact_system.state_count,
                             ExactRational::zero());
    for (std::size_t state = 0U;
         state < killed.killed_to_source.size(); ++state) {
      safe_initial[state] =
          initial.value()[killed.killed_to_source[state]];
    }
    if (!(vector_sum(safe_initial) == ExactRational::one())) {
      return fail<StoppedMetricBundle>(
          "c22.safe_entrance_projection_mass_mismatch",
          "projecting the matched entrance to the safe killed domain did "
          "not preserve exact unit mass",
          DiagnosticCategory::internal);
    }

    std::vector<SurvivalTailV1> tails;
    std::vector<TypedAbsorptionMassV1> masses;
    if (maximum.value() >= tails.max_size()) {
      return fail<StoppedMetricBundle>(
          "c22.stopped_tail_output_budget_exceeded",
          "the requested stopped tail vector exceeds its addressable "
          "container budget",
          DiagnosticCategory::resource_limit);
    }
    tails.reserve(maximum.value() + 1U);
    if (killed.exact_system.exit_type_count != 0U &&
        maximum.value() >
            std::numeric_limits<std::size_t>::max() /
                killed.exact_system.exit_type_count) {
      return fail<StoppedMetricBundle>(
          "c22.stopped_output_dimension_overflow",
          "the stopped horizon and typed-exit count overflow size_t",
          DiagnosticCategory::resource_limit);
    }
    const std::size_t absorption_output_count =
        maximum.value() * killed.exact_system.exit_type_count;
    if (absorption_output_count > masses.max_size()) {
      return fail<StoppedMetricBundle>(
          "c22.stopped_absorption_output_budget_exceeded",
          "the requested typed absorption vector exceeds its addressable "
          "container budget",
          DiagnosticCategory::resource_limit);
    }
    masses.reserve(absorption_output_count);
    ExactVector current = safe_initial;
    tails.push_back(
        SurvivalTailV1{BigNat{0U}, vector_sum(current)});
    ExactRational cumulative_exit = ExactRational::zero();
    for (std::size_t step = 0U; step < maximum.value(); ++step) {
      std::vector<ExactRational> step_exits(
          killed.exact_system.exit_type_count, ExactRational::zero());
      ExactVector next(killed.exact_system.state_count,
                       ExactRational::zero());
      for (std::size_t state = 0U;
           state < killed.exact_system.state_count; ++state) {
        if (current[state].is_zero()) {
          continue;
        }
        for (std::size_t successor = 0U;
             successor < killed.exact_system.state_count; ++successor) {
          const ExactRational& probability =
              killed.validation.survivor_matrix[
                  state * killed.exact_system.state_count + successor];
          if (!probability.is_zero()) {
            next[successor] =
                next[successor] + current[state] * probability;
          }
        }
        for (std::size_t type = 0U;
             type < killed.exact_system.exit_type_count; ++type) {
          step_exits[type] =
              step_exits[type] +
              current[state] *
                  killed.validation.typed_exit_matrix[
                      state * killed.exact_system.exit_type_count + type];
        }
      }
      const ExactRational previous_tail = vector_sum(current);
      const ExactRational next_tail = vector_sum(next);
      const ExactRational step_total = vector_sum(step_exits);
      if (!(previous_tail - next_tail == step_total) ||
          !next_tail.is_nonnegative()) {
        return fail<StoppedMetricBundle>(
            "c22.stopped_finite_mass_identity_failure",
            "finite stopped recursion violates exact tail-minus-tail equals "
            "absorption mass",
            DiagnosticCategory::internal,
            {"completed step " + std::to_string(step + 1U)});
      }
      cumulative_exit = cumulative_exit + step_total;
      if (!(cumulative_exit + next_tail == ExactRational::one())) {
        return fail<StoppedMetricBundle>(
            "c22.stopped_cumulative_mass_identity_failure",
            "finite cumulative absorption plus survival is not exactly one",
            DiagnosticCategory::internal);
      }
      for (std::size_t type = 0U; type < step_exits.size(); ++type) {
        masses.push_back(TypedAbsorptionMassV1{
            BigNat{step + 1U}, killed.exit_type_ids[type],
            step_exits[type]});
      }
      tails.push_back(SurvivalTailV1{BigNat{step + 1U}, next_tail});
      current = std::move(next);
    }

    // Infinite-output work begins only after every requested finite tail and
    // typed finite-time absorption mass has been computed.  Consequently an
    // unsupported method, an authored zero iteration budget, or a later
    // resource failure can leave a successful finite result with explicitly
    // unresolved infinite components.
    std::optional<std::size_t> maximum_iterations;
    auto converted_iterations = optional_size(policy.max_iterations);
    if (converted_iterations) {
      maximum_iterations = std::move(converted_iterations).value();
    }
    const bool zero_iteration_budget =
        policy.max_iterations.has_value() &&
        policy.max_iterations->is_zero();
    const bool dense_solver_available =
        policy.linear_method == LinearMethod::dense_pivoted;

    std::vector<EventualTypedExitProbabilityV1> eventual_output;
    ExactRational defect = ExactRational::zero();
    AbsorptionStatusV1 absorption_status =
        AbsorptionStatusV1::not_established;
    bool preserved = false;
    bool budget_stop = zero_iteration_budget;
    std::size_t actual_solver_iterations = 0U;
    std::optional<StoppedSolveDiagnosticsV1> typed_exit_diagnostics;
    std::optional<StoppedSolveDiagnosticsV1> potential_diagnostics;

    // Exact defect classification is part of every successful F-C22-04
    // result, independently of whether the caller asks us to publish the
    // per-exit-type eventual vector.  The selector flag controls only that
    // vector's materialization, never whether defectiveness is established.
    if (zero_iteration_budget) {
      preserved = true;
      typed_exit_diagnostics = unavailable_stopped_solve(
          StoppedSolveStatusV1::budget_stopped,
          "typed_exit_defect_zero_start_iteration_budget_stop");
    } else if (!dense_solver_available) {
      preserved = true;
      typed_exit_diagnostics = unavailable_stopped_solve(
          StoppedSolveStatusV1::unavailable,
          "dense_pivoted_typed_exit_defect_solver_unavailable");
    } else {
      auto eventual =
          metrics::detail::compute_exact_minimal_typed_exit_probabilities(
              killed.exact_system);
      if (!eventual) {
        if (eventual.error().category == DiagnosticCategory::internal ||
            eventual.error().category ==
                DiagnosticCategory::input_validation) {
          return Result<StoppedMetricBundle>::failure(eventual.error());
        }
        preserved = true;
        const bool resource_stop =
            eventual.error().category == DiagnosticCategory::resource_limit;
        budget_stop = budget_stop || resource_stop;
        typed_exit_diagnostics = unavailable_stopped_solve(
            resource_stop ? StoppedSolveStatusV1::budget_stopped
                          : StoppedSolveStatusV1::unavailable,
            "typed_exit_defect_solve_unavailable:" +
                eventual.error().code);
      } else {
        if (!eventual.value().zero_start_monotone ||
            !eventual.value().direct_acceleration_certified) {
          return fail<StoppedMetricBundle>(
              "c22.typed_exit_minimality_certificate_failed",
              "the exact direct typed-exit solve lacks its zero-start "
              "monotonicity and full-rank minimal-branch certificate",
              DiagnosticCategory::internal);
        }
        actual_solver_iterations = std::max(
            actual_solver_iterations,
            eventual.value().zero_start_certificate_iterations);
        typed_exit_diagnostics =
            typed_exit_solve_diagnostics(killed, eventual.value());
        if (horizon.include_eventual_typed_exit_probabilities) {
          eventual_output.reserve(killed.exact_system.exit_type_count);
        }
        for (std::size_t state = 0U;
             state < killed.exact_system.state_count; ++state) {
          defect =
              defect + safe_initial[state] *
                           eventual.value().defect_probabilities[state];
        }
        absorption_status =
            defect.is_zero() ? AbsorptionStatusV1::nondefective
                             : AbsorptionStatusV1::defective;
        for (std::size_t type = 0U;
             type < killed.exact_system.exit_type_count; ++type) {
          ExactRational probability = ExactRational::zero();
          for (std::size_t state = 0U;
               state < killed.exact_system.state_count; ++state) {
            probability =
                probability +
                safe_initial[state] *
                    eventual.value().state_major_probabilities[
                        state * killed.exact_system.exit_type_count + type];
          }
          if (horizon.include_eventual_typed_exit_probabilities) {
            eventual_output.push_back(EventualTypedExitProbabilityV1{
                killed.exit_type_ids[type], probability});
          }
        }
      }
    }

    ExtendedNonnegativeV1 mean{
        ExtendedNonnegativeStatusV1::not_established, std::nullopt};
    // F-C22-03 is an immediate child only for an actually requested
    // infinite-horizon mean/potential.  Finite-tail and defect-only requests
    // never invoke it.
    if (horizon.include_infinite_horizon_mean) {
      auto potential = compute_minimal_killed_potential(kernel, policy);
        if (!potential) {
          if (potential.error().category == DiagnosticCategory::internal ||
              potential.error().category ==
                  DiagnosticCategory::input_validation) {
            return Result<StoppedMetricBundle>::failure(potential.error());
          }
          preserved = true;
          const bool resource_stop =
              potential.error().category ==
              DiagnosticCategory::resource_limit;
          budget_stop = budget_stop || resource_stop;
          potential_diagnostics = unavailable_stopped_solve(
              resource_stop ? StoppedSolveStatusV1::budget_stopped
                            : StoppedSolveStatusV1::unavailable,
              "minimal_potential_solve_unavailable:" +
                  potential.error().code);
        } else {
          const auto& potential_core =
              detail::TemporalContractCoreAccess::core(potential.value());
          actual_solver_iterations =
              std::max(actual_solver_iterations,
                       potential_core.zero_start_iterations);
          budget_stop = budget_stop || potential_core.budget_stop;
          potential_diagnostics =
              potential_solve_diagnostics(potential.value());
          ExactRational exact_mean = ExactRational::zero();
          bool infinite = false;
          bool unresolved = false;
          for (const auto& coordinate : potential.value().coordinates()) {
            if (safe_initial[coordinate.state_index].is_zero()) {
              continue;
            }
            if (coordinate.value.status ==
                ExtendedNonnegativeStatusV1::positive_infinity) {
              infinite = true;
              break;
            }
            if (coordinate.value.status !=
                    ExtendedNonnegativeStatusV1::finite ||
                !coordinate.value.exact_value.has_value()) {
              unresolved = true;
              continue;
            }
            exact_mean =
                exact_mean +
                safe_initial[coordinate.state_index] *
                    *coordinate.value.exact_value;
          }
          if (infinite) {
            mean = ExtendedNonnegativeV1{
                ExtendedNonnegativeStatusV1::positive_infinity,
                std::nullopt};
            preserved = true;
          } else if (unresolved) {
            preserved = true;
          } else {
            mean = ExtendedNonnegativeV1{
                ExtendedNonnegativeStatusV1::finite, exact_mean};
          }
        }
    }
    TemporalBudgetReportV1 budget{
        maximum.value(),
        killed.exact_system.state_count,
        killed.source_row_atom_count,
        actual_solver_iterations,
        killed.source->maximum_states_budget,
        killed.source->maximum_row_atoms_budget,
        maximum_iterations,
        policy.max_iterations,
        policy.absolute_residual_tolerance,
        policy.relative_residual_tolerance,
        budget_stop};
    return Result<StoppedMetricBundle>::success(StoppedMetricBundle{
        killed.source_fingerprint,
        entrance.kind,
        std::move(tails),
        std::move(masses),
        std::move(eventual_output),
        defect,
        absorption_status,
        std::move(mean),
        std::move(budget),
        preserved,
        std::move(typed_exit_diagnostics),
        std::move(potential_diagnostics)});
  } catch (const std::bad_alloc&) {
    return fail<StoppedMetricBundle>(
        "c22.stopped_evaluation_allocation_failure",
        "finite stopped evaluation exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<StoppedMetricBundle>(
        "c22.stopped_evaluation_exception",
        "finite stopped evaluation raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

namespace {

[[nodiscard]] Result<bool> binary_value(
    const BinaryMark& mark,
    const metrics::detail::TemporalNodeCore& node,
    const MarkedFluxEdgeV1& edge) {
  switch (mark.kind) {
    case BinaryMarkKindV1::target_departure:
      return matches_edge(
          TargetDeparturePredicateV1{mark.target_ordinal, true}, edge);
    case BinaryMarkKindV1::positive_target_arrival:
      return matches_edge(
          PositiveTargetArrivalPredicateV1{mark.target_ordinal}, edge);
    case BinaryMarkKindV1::busy_denial:
      return matches_edge(BusyDenialEdgePredicateV1{mark.target_ordinal},
                          edge);
    case BinaryMarkKindV1::state_predicate:
      if (!mark.state_predicate.has_value()) {
        return fail<bool>(
            "c22.binary_state_predicate_missing",
            "a state-predicate binary mark has no predicate");
      }
      return matches_state(*mark.state_predicate, node);
  }
  return fail<bool>("c22.invalid_binary_mark", "invalid binary mark tag");
}

[[nodiscard]] Result<ExactRational> binary_mean(
    const metrics::detail::TemporalSourceCore& source,
    const ExactVector& entrance, const BinaryMark& mark) {
  ExactRational result = ExactRational::zero();
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    for (const auto& transition : source.nodes[state].transitions) {
      auto value = binary_value(mark, source.nodes[state], transition.edge);
      if (!value) {
        return Result<ExactRational>::failure(value.error());
      }
      if (value.value()) {
        result = result +
                 entrance[state] * transition.exact_mass;
      }
    }
  }
  return Result<ExactRational>::success(std::move(result));
}

[[nodiscard]] Result<ExactRational> binary_joint_lag(
    const metrics::detail::TemporalSourceCore& source,
    const ExactVector& entrance, const BinaryMark& mark,
    const std::size_t lag) {
  if (lag == 0U) {
    return binary_mean(source, entrance, mark);
  }
  ExactVector weighted(source.nodes.size(), ExactRational::zero());
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    for (const auto& transition : source.nodes[state].transitions) {
      auto first = binary_value(mark, source.nodes[state], transition.edge);
      if (!first) {
        return Result<ExactRational>::failure(first.error());
      }
      if (first.value()) {
        weighted[transition.successor_index] =
            weighted[transition.successor_index] +
            entrance[state] * transition.exact_mass;
      }
    }
  }
  for (std::size_t step = 1U; step < lag; ++step) {
    weighted = advance_vector(source, weighted);
  }
  ExactRational result = ExactRational::zero();
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    for (const auto& transition : source.nodes[state].transitions) {
      auto last = binary_value(mark, source.nodes[state], transition.edge);
      if (!last) {
        return Result<ExactRational>::failure(last.error());
      }
      if (last.value()) {
        result = result + weighted[state] * transition.exact_mass;
      }
    }
  }
  return Result<ExactRational>::success(std::move(result));
}

[[nodiscard]] Result<std::vector<ExactRational>> service_count_pmf(
    const metrics::detail::TemporalSourceCore& source,
    const ExactVector& entrance, const BinaryMark& mark,
    const std::size_t width) {
  if (width == std::numeric_limits<std::size_t>::max()) {
    return fail<std::vector<ExactRational>>(
        "c22.service_window_width_overflow",
        "the service-window width cannot be represented",
        DiagnosticCategory::resource_limit);
  }
  const std::size_t counts = width + 1U;
  if (!source.nodes.empty() &&
      counts > std::numeric_limits<std::size_t>::max() /
                   source.nodes.size()) {
    return fail<std::vector<ExactRational>>(
        "c22.service_window_dimension_overflow",
        "the service-window coefficient table overflows size_t",
        DiagnosticCategory::resource_limit);
  }
  std::vector<ExactRational> coefficients(
      source.nodes.size() * counts, ExactRational::zero());
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    coefficients[state * counts] = entrance[state];
  }
  for (std::size_t step = 0U; step < width; ++step) {
    std::vector<ExactRational> next(source.nodes.size() * counts,
                                    ExactRational::zero());
    for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
      for (std::size_t count = 0U; count <= step; ++count) {
        const ExactRational& base = coefficients[state * counts + count];
        if (base.is_zero()) {
          continue;
        }
        for (const auto& transition : source.nodes[state].transitions) {
          auto value = binary_value(mark, source.nodes[state],
                                    transition.edge);
          if (!value) {
            return Result<std::vector<ExactRational>>::failure(
                value.error());
          }
          const std::size_t next_count = count + (value.value() ? 1U : 0U);
          next[transition.successor_index * counts + next_count] =
              next[transition.successor_index * counts + next_count] +
              base * transition.exact_mass;
        }
      }
    }
    coefficients = std::move(next);
  }
  std::vector<ExactRational> result(counts, ExactRational::zero());
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    for (std::size_t count = 0U; count < counts; ++count) {
      result[count] = result[count] + coefficients[state * counts + count];
    }
  }
  if (!(vector_sum(result) == ExactRational::one())) {
    return fail<std::vector<ExactRational>>(
        "c22.service_window_mass_not_one",
        "ordered service-count coefficient propagation lost exact mass",
        DiagnosticCategory::internal);
  }
  return Result<std::vector<ExactRational>>::success(std::move(result));
}

[[nodiscard]] bool requires_departure_mark(
    const TemporalStatisticKindV1 statistic) noexcept {
  switch (statistic) {
    case TemporalStatisticKindV1::service_persistence:
    case TemporalStatisticKindV1::autocovariance:
    case TemporalStatisticKindV1::service_window_count:
    case TemporalStatisticKindV1::service_spectrum:
      return true;
    case TemporalStatisticKindV1::mean_event_gap:
    case TemporalStatisticKindV1::mean_binary_run:
      return false;
  }
  return false;
}

[[nodiscard]] bool observes_state(const BinaryMark& mark) noexcept {
  return mark.kind == BinaryMarkKindV1::state_predicate;
}

[[nodiscard]] bool empty_f05_extras(const LagSpec& request) noexcept {
  return request.lags.empty() && !request.window_width.has_value() &&
         !request.truncation_lag.has_value() &&
         request.angular_frequencies_radians.empty();
}

[[nodiscard]] std::optional<metrics::detail::F05AuthorizationV1>
requested_f05_authorization(const BinaryMark& mark,
                            const LagSpec& request) {
  const auto make = [&](const MetricKindV1 kind,
                        MetricRequestParametersV1 parameters) {
    return std::optional<metrics::detail::F05AuthorizationV1>{
        metrics::detail::F05AuthorizationV1{
            kind, mark.target_ordinal, std::move(parameters)}};
  };
  switch (request.statistic) {
    case TemporalStatisticKindV1::service_persistence:
      if (mark.kind != BinaryMarkKindV1::target_departure ||
          mark.state_predicate.has_value() || !empty_f05_extras(request)) {
        return std::nullopt;
      }
      return make(MetricKindV1::service_persistence,
                  ServicePersistenceParametersV1{});
    case TemporalStatisticKindV1::autocovariance:
      if (mark.kind != BinaryMarkKindV1::target_departure ||
          mark.state_predicate.has_value() ||
          request.window_width.has_value() ||
          request.truncation_lag.has_value() ||
          !request.angular_frequencies_radians.empty()) {
        return std::nullopt;
      }
      return make(MetricKindV1::service_autocovariance,
                  ServiceAutocovarianceParametersV1{request.lags});
    case TemporalStatisticKindV1::service_window_count:
      if (mark.kind != BinaryMarkKindV1::target_departure ||
          mark.state_predicate.has_value() || !request.lags.empty() ||
          !request.window_width.has_value() ||
          request.truncation_lag.has_value() ||
          !request.angular_frequencies_radians.empty()) {
        return std::nullopt;
      }
      return make(MetricKindV1::service_window_count,
                  ServiceWindowCountParametersV1{*request.window_width});
    case TemporalStatisticKindV1::service_spectrum:
      if (mark.kind != BinaryMarkKindV1::target_departure ||
          mark.state_predicate.has_value() || !request.lags.empty() ||
          request.window_width.has_value() ||
          !request.truncation_lag.has_value() ||
          request.angular_frequencies_radians.empty()) {
        return std::nullopt;
      }
      return make(
          MetricKindV1::service_spectrum,
          ServiceSpectrumParametersV1{
              request.angular_frequencies_radians, *request.truncation_lag,
              SpectrumWindowV1::rectangular_truncation});
    case TemporalStatisticKindV1::mean_event_gap: {
      if (mark.state_predicate.has_value() || !empty_f05_extras(request)) {
        return std::nullopt;
      }
      std::optional<GapEventKind> event;
      switch (mark.kind) {
        case BinaryMarkKindV1::target_departure:
          event = GapEventKind::departure;
          break;
        case BinaryMarkKindV1::positive_target_arrival:
          event = GapEventKind::admission;
          break;
        case BinaryMarkKindV1::busy_denial:
          event = GapEventKind::busy_denial;
          break;
        case BinaryMarkKindV1::state_predicate:
          return std::nullopt;
      }
      return make(MetricKindV1::mean_event_gap,
                  MeanEventGapParametersV1{*event});
    }
    case TemporalStatisticKindV1::mean_binary_run: {
      if (!empty_f05_extras(request)) {
        return std::nullopt;
      }
      BinaryPredicateV1 predicate;
      if (mark.kind == BinaryMarkKindV1::busy_denial &&
          !mark.state_predicate.has_value()) {
        predicate = BasicBinaryPredicateV1::busy_denial;
      } else if (mark.kind == BinaryMarkKindV1::state_predicate &&
                 mark.state_predicate.has_value()) {
        const auto* state_predicate =
            std::get_if<BinaryStatePredicateV1>(
                &*mark.state_predicate);
        if (state_predicate == nullptr ||
            state_predicate->target_ordinal != mark.target_ordinal ||
            (std::holds_alternative<BasicBinaryPredicateV1>(
                 state_predicate->predicate) &&
             std::get<BasicBinaryPredicateV1>(state_predicate->predicate) ==
                 BasicBinaryPredicateV1::busy_denial)) {
          return std::nullopt;
        }
        predicate = state_predicate->predicate;
      } else {
        return std::nullopt;
      }
      return make(MetricKindV1::mean_binary_run,
                  MeanBinaryRunParametersV1{std::move(predicate)});
    }
  }
  return std::nullopt;
}

[[nodiscard]] Result<void> require_f05_authorization(
    const metrics::detail::TemporalSourceCore& source,
    const BinaryMark& mark, const LagSpec& request) {
  const auto requested = requested_f05_authorization(mark, request);
  if (!requested.has_value() ||
      std::find(source.f05_authorizations.begin(),
                source.f05_authorizations.end(), *requested) ==
          source.f05_authorizations.end()) {
    return fail<void>(
        "c22.temporal_statistic_not_authorized_by_accepted_contract",
        "the requested temporal statistic, target, predicate/event, and "
        "exact lag/window/frequency parameters do not match an accepted "
        "C14 request bound to this audited source",
        DiagnosticCategory::unavailable);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> require_binary_offset(
    const metrics::detail::TemporalSourceCore& source,
    const BinaryMark& mark, const std::size_t maximum_offset,
    const std::string_view diagnostic_code,
    const std::string_view diagnostic_message) {
  if (observes_state(mark)) {
    if (maximum_offset <= source.maximum_state_offset) {
      return Result<void>::success();
    }
  } else if (source.maximum_edge_offset.has_value() &&
             maximum_offset <= *source.maximum_edge_offset) {
    return Result<void>::success();
  }
  std::vector<std::string> notes;
  notes.push_back(observes_state(mark)
                      ? "required state offset " +
                            std::to_string(maximum_offset)
                      : "required edge offset " +
                            std::to_string(maximum_offset));
  if (observes_state(mark)) {
    notes.push_back("retained maximum state offset " +
                    std::to_string(source.maximum_state_offset));
  } else if (source.maximum_edge_offset.has_value()) {
    notes.push_back("retained maximum edge offset " +
                    std::to_string(*source.maximum_edge_offset));
  } else {
    notes.push_back("the retained source contains no edge offset");
  }
  return fail<void>(std::string(diagnostic_code),
                    std::string(diagnostic_message),
                    DiagnosticCategory::resource_limit, std::move(notes));
}

using SpectrumFloat = boost::multiprecision::cpp_dec_float_100;

[[nodiscard]] SpectrumFloat spectrum_float(const ExactRational& value) {
  return SpectrumFloat{value.numerator_decimal()} /
         SpectrumFloat{value.denominator_decimal()};
}

struct CertifiedSpectrumImage final {
  long double value;
  long double enclosing_radius;
};

// cpp_dec_float supplies a stable high-precision centre, but it is not a
// directed-rounding interval package.  Certification therefore does not rely
// on its last bit.  For a binary mark, |Cov(D(0),D(k))| <= 1, so for positive
// L and pi > 3 the exact rectangular sum has magnitude
//
//   (1 + 2L)/(2 pi) < L.
//
// The returned radius deliberately encloses both that whole exact range and
// the reported centre.  It is conservative, deterministic, and remains an
// actual enclosure even if the multiprecision transcendental is not correctly
// rounded.  A future directed interval backend may tighten it without changing
// the result contract.
[[nodiscard]] Result<CertifiedSpectrumImage> certified_spectrum_image(
    const std::span<const ExactRational> covariance,
    const ExactRational& frequency, const std::size_t truncation) {
  try {
    SpectrumFloat sum = spectrum_float(covariance.front());
    const SpectrumFloat omega = spectrum_float(frequency);
    for (std::size_t lag = 1U; lag <= truncation; ++lag) {
      using boost::multiprecision::cos;
      const SpectrumFloat cosine =
          frequency.is_zero()
              ? SpectrumFloat{1}
              : cos(SpectrumFloat{lag} * omega);
      sum += SpectrumFloat{2} * spectrum_float(covariance[lag]) * cosine;
    }
    using boost::multiprecision::acos;
    const SpectrumFloat pi = acos(SpectrumFloat{-1});
    const SpectrumFloat image = sum / (SpectrumFloat{2} * pi);
    const long double centre = image.convert_to<long double>();
    const long double lag_image = static_cast<long double>(truncation);
    if (!std::isfinite(centre) || !std::isfinite(lag_image)) {
      return fail<CertifiedSpectrumImage>(
          "c22.service_spectrum_numerically_unresolved",
          "the finite rectangular covariance Fourier sum has no finite "
          "promoted image or enclosure",
          DiagnosticCategory::unavailable);
    }
    // `2*L+2` is intentionally much larger than the exact < L bound.  The
    // slack makes the enclosure independent of final long-double rounding.
    const long double radius = std::nextafter(
        std::fabs(centre) + 2.0L * lag_image + 2.0L,
        std::numeric_limits<long double>::infinity());
    if (!std::isfinite(radius) || radius < 0.0L) {
      return fail<CertifiedSpectrumImage>(
          "c22.service_spectrum_numerically_unresolved",
          "the finite rectangular covariance Fourier enclosure is not "
          "representable",
          DiagnosticCategory::unavailable);
    }
    return Result<CertifiedSpectrumImage>::success({centre, radius});
  } catch (const std::exception&) {
    return fail<CertifiedSpectrumImage>(
        "c22.service_spectrum_numerically_unresolved",
        "high-precision transcendental evaluation did not produce a "
        "certifiable finite enclosure",
        DiagnosticCategory::unavailable);
  }
}

[[nodiscard]] Result<ExactRational> component_ratio(
    const metrics::detail::TemporalSourceCore& source,
    const ExactVector& entrance, const BinaryMark& mark,
    const bool run_ratio) {
  // Derive invariant components from exact positive support.  A retained
  // label is useful provenance, but it is not a mathematical witness: one
  // label could accidentally merge an active and an inactive closed class
  // and thereby overcount Pr(A_E) or the finite-start run occupation.
  if (advance_vector(source, entrance) != entrance) {
    return fail<ExactRational>(
        "c22.stationary_entrance_not_invariant",
        "a source-derived stationary gap or run ratio requires an exactly "
        "invariant entrance",
        DiagnosticCategory::input_validation);
  }

  metrics::detail::ExactKilledSystem support_system{
      source.nodes.size(), 0U, {}};
  support_system.rows.reserve(source.nodes.size());
  for (const auto& node : source.nodes) {
    metrics::detail::ExactKilledRow row{{}, {}, ExactRational::zero()};
    row.survivors.reserve(node.transitions.size());
    for (const auto& transition : node.transitions) {
      row.survivors.push_back(metrics::detail::ExactKilledTransition{
          transition.successor_index, transition.exact_mass});
      row.exact_source_mass =
          row.exact_source_mass + transition.exact_mass;
    }
    support_system.rows.push_back(std::move(row));
  }

  auto classification =
      metrics::detail::classify_exact_survivor_support(support_system);
  if (!classification) {
    return Result<ExactRational>::failure(classification.error());
  }
  const std::size_t component_count =
      classification.value().closed_survivor_classes.size();
  if (component_count == 0U) {
    return fail<ExactRational>(
        "c22.stationary_closed_component_missing",
        "an exact finite stationary temporal law has no closed positive-"
        "support component",
        DiagnosticCategory::internal);
  }
  std::vector<std::optional<std::size_t>> closed_component_by_state(
      source.nodes.size());
  for (std::size_t component = 0U; component < component_count;
       ++component) {
    for (const std::size_t state :
         classification.value()
             .closed_survivor_classes[component]
             .member_indices) {
      closed_component_by_state[state] = component;
    }
  }
  std::vector<ExactRational> component_mass(component_count,
                                             ExactRational::zero());
  std::vector<ExactRational> occupation(component_count,
                                         ExactRational::zero());
  std::vector<ExactRational> starts(component_count,
                                     ExactRational::zero());
  for (std::size_t state = 0U; state < source.nodes.size(); ++state) {
    if (entrance[state].is_zero()) {
      continue;
    }
    if (!closed_component_by_state[state].has_value()) {
      return fail<ExactRational>(
          "c22.stationary_entrance_charges_transient_component",
          "an exactly invariant finite entrance assigns positive mass outside "
          "the derived closed support classes",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state)});
    }
    const std::size_t component = *closed_component_by_state[state];
    component_mass[component] =
        component_mass[component] + entrance[state];
    for (const auto& first_transition : source.nodes[state].transitions) {
      if (!closed_component_by_state[first_transition.successor_index]
               .has_value() ||
          *closed_component_by_state[first_transition.successor_index] !=
              component) {
        return fail<ExactRational>(
            "c22.stationary_component_not_invariant",
            "a derived closed gap/run component has a positive transition "
            "outside itself",
            DiagnosticCategory::internal);
      }
      auto first = binary_value(mark, source.nodes[state],
                                first_transition.edge);
      if (!first) {
        return Result<ExactRational>::failure(first.error());
      }
      const ExactRational first_weight =
          entrance[state] * first_transition.exact_mass;
      if (first.value()) {
        occupation[component] = occupation[component] + first_weight;
      }
      if (!first.value()) {
        const std::size_t successor = first_transition.successor_index;
        for (const auto& second_transition :
             source.nodes[successor].transitions) {
          auto second = binary_value(mark, source.nodes[successor],
                                     second_transition.edge);
          if (!second) {
            return Result<ExactRational>::failure(second.error());
          }
          if (second.value()) {
            starts[component] =
                starts[component] +
                first_weight * second_transition.exact_mass;
          }
        }
      }
    }
  }
  ExactRational intensity = ExactRational::zero();
  ExactRational numerator = ExactRational::zero();
  if (!run_ratio) {
    for (std::size_t component = 0U; component < component_count;
         ++component) {
      intensity = intensity + occupation[component];
      if (occupation[component].is_positive()) {
        numerator = numerator + component_mass[component];
      }
    }
  } else {
    for (std::size_t component = 0U; component < component_count;
         ++component) {
      intensity = intensity + starts[component];
      if (starts[component].is_positive()) {
        numerator = numerator + occupation[component];
      }
    }
  }
  if (!intensity.is_positive()) {
    return fail<ExactRational>(
        run_ratio ? "c22.zero_run_start_intensity"
                  : "c22.zero_event_intensity",
        run_ratio
            ? "a start-Palm mean run requires positive start intensity"
            : "an event-Palm mean gap requires positive event intensity",
        DiagnosticCategory::unavailable);
  }
  return checked_divide(numerator, intensity);
}

template <typename TemporalLaw>
[[nodiscard]] Result<MetricValue>
evaluate_runs_gaps_autocorrelation_impl(
    const TemporalLaw& law, const BinaryMark& mark,
    const LagSpec& lags) {
  try {
    auto source_result = require_source(law);
    if (!source_result) {
      return Result<MetricValue>::failure(source_result.error());
    }
    const auto& source = *source_result.value();
    auto valid = validate_temporal_source(source);
    if (!valid) {
      return Result<MetricValue>::failure(valid.error());
    }
    auto authorized = require_f05_authorization(source, mark, lags);
    if (!authorized) {
      return Result<MetricValue>::failure(authorized.error());
    }
    if (requires_departure_mark(lags.statistic) &&
        mark.kind != BinaryMarkKindV1::target_departure) {
      return fail<MetricValue>(
          "c22.service_statistic_requires_departure_mark",
          "service persistence, autocovariance, window counts, and spectrum "
          "require the retained actual-departure mark",
          DiagnosticCategory::unavailable);
    }
    auto initial = entrance_vector(source, source.stationary_entrance);
    if (!initial) {
      return Result<MetricValue>::failure(initial.error());
    }
    if (advance_vector(source, initial.value()) != initial.value()) {
      return fail<MetricValue>(
          "c22.stationary_temporal_entrance_not_invariant",
          "a stationary temporal statistic requires an exactly invariant "
          "predictive entrance",
          DiagnosticCategory::input_validation);
    }
    Result<void> initial_budget = Result<void>::success();
    switch (lags.statistic) {
      case TemporalStatisticKindV1::service_persistence:
        initial_budget = require_binary_offset(
            source, mark, 1U,
            "c22.service_persistence_beyond_temporal_budget",
            "service persistence requires departure edges at offsets zero "
            "and one");
        break;
      case TemporalStatisticKindV1::mean_event_gap:
        initial_budget = require_binary_offset(
            source, mark, 0U, "c22.mean_event_gap_beyond_temporal_budget",
            observes_state(mark)
                ? "a state-event gap requires the state at offset zero"
                : "an edge-event gap requires the edge at offset zero");
        break;
      case TemporalStatisticKindV1::mean_binary_run:
        initial_budget = require_binary_offset(
            source, mark, 1U, "c22.mean_binary_run_beyond_temporal_budget",
            observes_state(mark)
                ? "a state run start requires states at offsets zero and one"
                : "an edge run start requires edges at offsets zero and one");
        break;
      case TemporalStatisticKindV1::autocovariance:
      case TemporalStatisticKindV1::service_window_count:
      case TemporalStatisticKindV1::service_spectrum:
        initial_budget = require_binary_offset(
            source, mark, 0U, "c22.temporal_mark_beyond_temporal_budget",
            "the requested temporal statistic requires its binary mark at "
            "offset zero");
        break;
    }
    if (!initial_budget) {
      return Result<MetricValue>::failure(initial_budget.error());
    }
    auto lambda = binary_mean(source, initial.value(), mark);
    if (!lambda) {
      return Result<MetricValue>::failure(lambda.error());
    }

    switch (lags.statistic) {
      case TemporalStatisticKindV1::service_persistence: {
        if (!lambda.value().is_positive()) {
          return fail<MetricValue>(
              "c22.zero_departure_intensity_for_persistence",
              "service persistence requires positive departure intensity",
              DiagnosticCategory::unavailable);
        }
        auto joint = binary_joint_lag(source, initial.value(), mark, 1U);
        if (!joint) {
          return Result<MetricValue>::failure(joint.error());
        }
        auto p11 = checked_divide(joint.value(), lambda.value());
        if (!p11) {
          return Result<MetricValue>::failure(p11.error());
        }
        auto budget = temporal_metric_budget(source, 2U);
        if (!budget) {
          return Result<MetricValue>::failure(budget.error());
        }
        return encode_metric(MetricEnvelope{
            "service_persistence", source.binding.source_fingerprint,
            {lambda.value(), joint.value(), p11.value()}, {}, {BigNat{1U}},
            false, false, 0.0L, 2U, std::move(budget).value()});
      }
      case TemporalStatisticKindV1::autocovariance: {
        std::vector<ExactRational> covariance;
        covariance.reserve(lags.lags.size());
        std::size_t completed = 0U;
        for (const BigNat& authored : lags.lags) {
          auto lag = bounded_size(authored, "an autocovariance lag");
          if (!lag) {
            return Result<MetricValue>::failure(lag.error());
          }
          if (!source.maximum_edge_offset.has_value() ||
              lag.value() > *source.maximum_edge_offset ||
              lag.value() == std::numeric_limits<std::size_t>::max()) {
            return fail<MetricValue>(
                "c22.autocovariance_lag_beyond_temporal_budget",
                "an authored lag exceeds the audited temporal law budget",
                DiagnosticCategory::resource_limit);
          }
          auto joint = binary_joint_lag(source, initial.value(), mark,
                                        lag.value());
          if (!joint) {
            return Result<MetricValue>::failure(joint.error());
          }
          covariance.push_back(joint.value() -
                               lambda.value() * lambda.value());
          completed = std::max(completed, lag.value() + 1U);
        }
        auto budget = temporal_metric_budget(source, completed);
        if (!budget) {
          return Result<MetricValue>::failure(budget.error());
        }
        return encode_metric(MetricEnvelope{
            "service_autocovariance", source.binding.source_fingerprint,
            std::move(covariance), {}, lags.lags, false, false, 0.0L,
            completed, std::move(budget).value()});
      }
      case TemporalStatisticKindV1::service_window_count: {
        if (!lags.window_width.has_value()) {
          return fail<MetricValue>(
              "c22.service_window_width_missing",
              "a service-window count request has no width");
        }
        auto width = bounded_size(*lags.window_width,
                                  "the service-window width");
        if (!width) {
          return Result<MetricValue>::failure(width.error());
        }
        if (width.value() == 0U) {
          return fail<MetricValue>(
              "c22.service_window_zero_width",
              "analysis-v1 service-window counts require a positive width");
        }
        if (!source.maximum_edge_offset.has_value() ||
            width.value() - 1U > *source.maximum_edge_offset) {
          return fail<MetricValue>(
              "c22.service_window_beyond_temporal_budget",
              "the service-window width exceeds the audited temporal law "
              "budget",
              DiagnosticCategory::resource_limit);
        }
        auto pmf = service_count_pmf(source, initial.value(), mark,
                                     width.value());
        if (!pmf) {
          return Result<MetricValue>::failure(pmf.error());
        }
        std::vector<BigNat> counts;
        counts.reserve(pmf.value().size());
        for (std::size_t count = 0U; count < pmf.value().size(); ++count) {
          counts.emplace_back(count);
        }
        auto budget = temporal_metric_budget(source, width.value());
        if (!budget) {
          return Result<MetricValue>::failure(budget.error());
        }
        return encode_metric(MetricEnvelope{
            "service_window_count", source.binding.source_fingerprint,
            std::move(pmf).value(), {}, std::move(counts), false, false,
            0.0L, width.value(), std::move(budget).value()});
      }
      case TemporalStatisticKindV1::service_spectrum: {
        if (!lags.truncation_lag.has_value() ||
            lags.angular_frequencies_radians.empty()) {
          return fail<MetricValue>(
              "c22.service_spectrum_parameters_missing",
              "a finite service spectrum requires a positive truncation lag "
              "and authored angular frequencies");
        }
        auto truncation = bounded_size(*lags.truncation_lag,
                                       "the spectrum truncation lag");
        if (!truncation) {
          return Result<MetricValue>::failure(truncation.error());
        }
        if (truncation.value() == 0U) {
          return fail<MetricValue>(
              "c22.service_spectrum_zero_truncation",
              "analysis-v1 service_spectrum requires positive L");
        }
        if (!source.maximum_edge_offset.has_value() ||
            truncation.value() > *source.maximum_edge_offset ||
            truncation.value() ==
                std::numeric_limits<std::size_t>::max()) {
          return fail<MetricValue>(
              "c22.service_spectrum_beyond_temporal_budget",
              "the rectangular spectrum requests an edge offset beyond the "
              "audited source budget",
              DiagnosticCategory::resource_limit);
        }
        std::vector<ExactRational> covariance;
        covariance.reserve(truncation.value() + 1U);
        for (std::size_t lag = 0U; lag <= truncation.value(); ++lag) {
          auto joint = binary_joint_lag(source, initial.value(), mark, lag);
          if (!joint) {
            return Result<MetricValue>::failure(joint.error());
          }
          covariance.push_back(joint.value() -
                               lambda.value() * lambda.value());
        }
        std::vector<long double> values;
        values.reserve(lags.angular_frequencies_radians.size());
        long double maximum_error = 0.0L;
        for (const ExactRational& frequency :
             lags.angular_frequencies_radians) {
          auto image = certified_spectrum_image(
              covariance, frequency, truncation.value());
          if (!image) {
            return Result<MetricValue>::failure(image.error());
          }
          maximum_error =
              std::max(maximum_error, image.value().enclosing_radius);
          values.push_back(image.value().value);
        }
        auto budget =
            temporal_metric_budget(source, truncation.value() + 1U);
        if (!budget) {
          return Result<MetricValue>::failure(budget.error());
        }
        return encode_metric(MetricEnvelope{
            "rectangularly_truncated_covariance_fourier_sum",
            source.binding.source_fingerprint, std::move(covariance),
            std::move(values), {*lags.truncation_lag}, true, true,
            maximum_error, truncation.value() + 1U,
            std::move(budget).value(),
            lags.angular_frequencies_radians, true, std::nullopt,
            ExactRational::zero(), true});
      }
      case TemporalStatisticKindV1::mean_event_gap: {
        auto ratio = component_ratio(source, initial.value(), mark, false);
        if (!ratio) {
          return Result<MetricValue>::failure(ratio.error());
        }
        const std::size_t completed = observes_state(mark) ? 0U : 1U;
        auto budget = temporal_metric_budget(source, completed);
        if (!budget) {
          return Result<MetricValue>::failure(budget.error());
        }
        return encode_metric(MetricEnvelope{
            "mean_event_palm_gap", source.binding.source_fingerprint,
            {ratio.value()}, {}, {}, false, false, 0.0L,
            completed, std::move(budget).value()});
      }
      case TemporalStatisticKindV1::mean_binary_run: {
        auto ratio = component_ratio(source, initial.value(), mark, true);
        if (!ratio) {
          return Result<MetricValue>::failure(ratio.error());
        }
        const std::size_t completed = observes_state(mark) ? 1U : 2U;
        auto budget = temporal_metric_budget(source, completed);
        if (!budget) {
          return Result<MetricValue>::failure(budget.error());
        }
        return encode_metric(MetricEnvelope{
            "mean_start_palm_binary_run",
            source.binding.source_fingerprint, {ratio.value()}, {}, {},
            false, false, 0.0L, completed,
            std::move(budget).value()});
      }
    }
    return fail<MetricValue>("c22.invalid_temporal_statistic",
                             "invalid temporal statistic tag");
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c22.temporal_statistic_allocation_failure",
        "temporal statistic evaluation exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c22.temporal_statistic_exception",
        "temporal statistic evaluation raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<MetricValue> evaluate_runs_gaps_autocorrelation(
    const AuditedTemporalLaw& law, const BinaryMark& mark,
    const LagSpec& lags) {
  return evaluate_runs_gaps_autocorrelation_impl(law, mark, lags);
}

Result<MetricValue> detail::evaluate_finite_cylinder_statistic(
    const AuditedCylinderLaw& law, const BinaryMark& mark,
    const LagSpec& lags) {
  if (!requires_departure_mark(lags.statistic)) {
    return fail<MetricValue>(
        "c22.finite_cylinder_statistic_not_authorized",
        "a finite-cylinder view authorizes only its bounded service "
        "persistence, autocovariance, window-count, or spectrum statistic",
        DiagnosticCategory::unavailable);
  }
  return evaluate_runs_gaps_autocorrelation_impl(law, mark, lags);
}

namespace {

[[nodiscard]] ArrivalPhaseIdentityV1 phase_identity(
    const ArrivalPhase& phase) {
  const auto bytes = arrival_phase_canonical_state(phase);
  return ArrivalPhaseIdentityV1{
      arrival_phase_family(phase),
      std::vector<std::byte>(bytes.begin(), bytes.end())};
}

[[nodiscard]] Result<MarkedFluxEdgeV1> project_transient_edge(
    const CompletedReducedEdge& edge) {
  if (!edge.opportunity().prearrival_backlog.has_value()) {
    return fail<MarkedFluxEdgeV1>(
        "c22.transient_prearrival_backlog_missing",
        "a transient temporal edge lacks its exact prearrival target "
        "backlog",
        DiagnosticCategory::unavailable);
  }
  const TargetBacklogV1& backlog =
      *edge.opportunity().prearrival_backlog;
  std::vector<BigNat> values(backlog.values().begin(),
                             backlog.values().end());
  std::vector<std::uint8_t> departures;
  std::vector<BigNat> arrivals;
  departures.reserve(backlog.size());
  arrivals.reserve(backlog.size());
  for (std::size_t target = 0U; target < backlog.size(); ++target) {
    const std::size_t physical =
        backlog.target_at_target_ordinal(target).ordinal();
    if (physical >= edge.action().actual_departure.bytes().size()) {
      return fail<MarkedFluxEdgeV1>(
          "c22.transient_departure_mark_missing",
          "a transient temporal edge omits a selected actual-departure "
          "coordinate",
          DiagnosticCategory::unavailable);
    }
    const std::uint8_t departure =
        edge.action().actual_departure.bytes()[physical];
    if (departure > 1U) {
      return fail<MarkedFluxEdgeV1>(
          "c22.transient_nonbinary_departure",
          "a unit-service actual departure is not binary");
    }
    departures.push_back(departure);
    BigNat arrival{0U};
    for (const ArrivalBatchEntry& entry : edge.arrival().batch.entries()) {
      if (entry.queue.ordinal() == physical) {
        arrival = entry.count;
        break;
      }
    }
    arrivals.push_back(std::move(arrival));
  }
  return Result<MarkedFluxEdgeV1>::success(MarkedFluxEdgeV1{
      edge.pre_state(), edge.successor_state(), std::move(values),
      std::move(departures), std::move(arrivals),
      phase_identity(edge.arrival().phase_before),
      phase_identity(edge.arrival().phase_after),
      std::vector<CausalMarkV1>(edge.marks().begin(), edge.marks().end())});
}

void append_u64(std::vector<std::byte>& bytes, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    bytes.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_frame(std::vector<std::byte>& bytes,
                  const std::span<const std::byte> value) {
  append_u64(bytes, static_cast<std::uint64_t>(value.size()));
  bytes.insert(bytes.end(), value.begin(), value.end());
}

void append_text(std::vector<std::byte>& bytes, const std::string_view value) {
  append_frame(bytes, std::as_bytes(std::span(value.data(), value.size())));
}

[[nodiscard]] Result<Digest256> transient_source_fingerprint(
    const kernel::detail::C17TemporalBindingV1& binding,
    const ReducedInitialLaw& entrance, const MetricRequest& request) {
  std::vector<std::byte> bytes;
  append_frame(bytes, binding.source_fingerprint.bytes());
  append_frame(bytes, binding.accepted_contract_identity.bytes());
  append_frame(bytes, binding.normalized_requirements_identity.bytes());
  append_frame(bytes, binding.authored_analysis_identity.bytes());
  append_frame(bytes, binding.resolved_instance_identity.bytes());
  append_frame(bytes, binding.target_selection_identity.bytes());
  append_frame(bytes, binding.configured_arrival_identity.bytes());
  append_frame(bytes, binding.selection_identity.bytes());
  append_frame(bytes, binding.exact_state_schema_identity.bytes());
  append_frame(bytes, binding.reduced_state_schema_identity.bytes());
  append_frame(bytes, binding.mark_schema_identity.bytes());
  append_frame(bytes, binding.continuation_schema_identity.bytes());
  append_frame(bytes, binding.target_service_schema_identity.bytes());
  append_frame(bytes, binding.timing_identity.bytes());
  append_text(bytes, binding.state_codec.id);
  append_u64(bytes, binding.state_codec.version);
  append_text(bytes, metric_request_header(request).metric_id);
  append_u64(bytes,
             static_cast<std::uint64_t>(
                 metric_request_header(request).authored_index));
  append_u64(bytes,
             static_cast<std::uint64_t>(metric_request_kind(request)));
  append_u64(bytes, static_cast<std::uint64_t>(entrance.atoms().size()));
  for (const auto& atom : entrance.atoms()) {
    append_text(bytes, atom.state.codec.id);
    append_u64(bytes, atom.state.codec.version);
    append_frame(bytes, atom.state.canonical_value);
    append_text(bytes, atom.mass.exact_value().numerator_decimal());
    append_text(bytes, atom.mass.exact_value().denominator_decimal());
  }
  return sha256_domain_separated("mwperf.c22.transient-source.v1", bytes);
}

[[nodiscard]] std::optional<std::size_t> find_state(
    const std::span<const metrics::detail::TemporalNodeCore> nodes,
    const ReducedStateV1& state) {
  for (std::size_t index = 0U; index < nodes.size(); ++index) {
    if (nodes[index].decoded_state == state) {
      return index;
    }
  }
  return std::nullopt;
}

struct TransientSourceBundle final {
  std::shared_ptr<const metrics::detail::TemporalSourceCore> source;
  InitialLaw entrance;
  std::optional<AuditedCylinderLaw> cylinder;
  std::optional<AuditedTemporalKernel> kernel;
  std::size_t target_ordinal;
  std::vector<BigNat> authored_horizons;
  struct StoppedPlan final {
    SafeSet safe_set;
    AbsorptionMarks absorption_marks;
    BigNat horizon;
    bool include_mean;
  };
  std::optional<StoppedPlan> stopped_plan;
};

[[nodiscard]] BacklogRelationV1 relation_for_hit(const HitSetKind kind) {
  switch (kind) {
    case HitSetKind::at_or_above:
      return BacklogRelationV1::at_or_above;
    case HitSetKind::at_or_below:
      return BacklogRelationV1::at_or_below;
    case HitSetKind::equal:
      return BacklogRelationV1::equal;
  }
  return BacklogRelationV1::equal;
}

[[nodiscard]] Result<TransientSourceBundle> build_transient_source(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law, const MetricRequest& request) {
  auto request_match =
      kernel::detail::c17_require_temporal_request_match(framework, request);
  if (!request_match) {
    return Result<TransientSourceBundle>::failure(request_match.error());
  }
  auto target_ordinal =
      kernel::detail::c17_scalar_request_target_ordinal(framework, request);
  if (!target_ordinal) {
    return Result<TransientSourceBundle>::failure(target_ordinal.error());
  }
  auto binding = kernel::detail::c17_temporal_binding(framework);
  if (!binding) {
    return Result<TransientSourceBundle>::failure(binding.error());
  }
  if (!binding.value().exact_row_available) {
    return fail<TransientSourceBundle>(
        "c22.sampler_only_temporal_request_deferred",
        "generic C22 temporal execution requires exact enumerable rows; a "
        "sampler is not promoted and C24 is not invoked",
        DiagnosticCategory::unavailable);
  }
  auto initial_seal =
      kernel::detail::c17_require_transient_initial_seal(framework,
                                                         initial_law);
  if (!initial_seal) {
    return Result<TransientSourceBundle>::failure(initial_seal.error());
  }
  if (initial_law.state_codec() != binding.value().state_codec ||
      initial_law.exact_state_schema_digest() !=
          binding.value().exact_state_schema_identity ||
      initial_law.reduced_state_schema_digest() !=
          binding.value().reduced_state_schema_identity ||
      initial_law.selection_digest() != binding.value().selection_identity ||
      metric_request_header(request).selection_regime !=
          MetricSelectionRegimeV1::transient) {
    return fail<TransientSourceBundle>(
        "c22.transient_initial_law_binding_mismatch",
        "the reduced initial law, request, and audited framework do not "
        "share one seal, selection, state schema, and timing identity");
  }
  auto fingerprint =
      transient_source_fingerprint(binding.value(), initial_law, request);
  if (!fingerprint) {
    return Result<TransientSourceBundle>::failure(fingerprint.error());
  }

  std::optional<std::size_t> maximum_states;
  std::optional<std::size_t> maximum_row_atoms;
  const auto& resolution =
      metric_request_header(request).context->resolution.level;
  if (resolution.max_states.has_value()) {
    auto converted = bounded_size(*resolution.max_states,
                                  "the transient maximum state count");
    if (!converted) {
      return Result<TransientSourceBundle>::failure(converted.error());
    }
    maximum_states = converted.value();
  }
  if (resolution.max_row_atoms.has_value()) {
    auto converted = bounded_size(*resolution.max_row_atoms,
                                  "the transient maximum row-atom count");
    if (!converted) {
      return Result<TransientSourceBundle>::failure(converted.error());
    }
    maximum_row_atoms = converted.value();
  }

  const MetricKindV1 request_kind = metric_request_kind(request);
  const bool finite_cylinder_prefix =
      request_kind == MetricKindV1::transient_backlog_law;
  if (!finite_cylinder_prefix && request_kind != MetricKindV1::first_hit &&
      request_kind != MetricKindV1::threshold_excursion) {
    return fail<TransientSourceBundle>(
        "c22.transient_metric_variant_unsupported",
        "the accepted transient request is not a C22 finite-cylinder or "
        "stopped variant implemented by analysis-v1",
        DiagnosticCategory::unavailable);
  }
  if (!finite_cylinder_prefix && !maximum_states.has_value()) {
    return fail<TransientSourceBundle>(
        "c22.transient_stopped_state_budget_required",
        "an exact reusable transient killed kernel requires the authored "
        "max_states budget to certify reachable finite closure before any "
        "unbounded traversal",
        DiagnosticCategory::resource_limit);
  }

  // Compile the stopped predicates before reachable-state discovery.  The
  // safe predicate controls discovery itself: an already-hit successor is
  // retained only as a typed terminal atom and its outgoing row is never
  // requested from the audited source.
  std::optional<TransientSourceBundle::StoppedPlan> stopped_plan;
  if (!finite_cylinder_prefix) {
    MetricHitSetV1 hit_set{HitSetKind::equal, BigNat{0U}};
    BigNat horizon{0U};
    bool include_mean = false;
    if (request_kind == MetricKindV1::first_hit) {
      const auto parameters = std::get<FirstHitParametersV1>(
          metric_request_parameters(request));
      hit_set = parameters.set;
      horizon = parameters.horizon;
      include_mean = parameters.include_mean;
    } else {
      const auto parameters = std::get<ThresholdExcursionParametersV1>(
          metric_request_parameters(request));
      hit_set = parameters.set;
      horizon = parameters.horizon;
      include_mean = parameters.include_mean;
    }
    const std::size_t target = target_ordinal.value();
    const TargetBacklogPredicateV1 inside{
        target, relation_for_hit(hit_set.kind), hit_set.level};
    if (request_kind == MetricKindV1::first_hit) {
      stopped_plan.emplace(TransientSourceBundle::StoppedPlan{
          SafeSet{TargetBacklogOutsideHitSetPredicateV1{target, hit_set}},
          AbsorptionMarks{{TypedAbsorptionMarkV1{
              "hit", inside, AnyEdgePredicateV1{}}}},
          std::move(horizon), include_mean});
    } else {
      // A threshold excursion is entered inside the authored threshold set
      // and ends on the first return outside it.  It is not a first-hit query
      // with a different display label.
      stopped_plan.emplace(TransientSourceBundle::StoppedPlan{
          SafeSet{inside},
          AbsorptionMarks{{TypedAbsorptionMarkV1{
              "return",
              TargetBacklogOutsideHitSetPredicateV1{target, hit_set},
              AnyEdgePredicateV1{}}}},
          std::move(horizon), include_mean});
    }
  }

  std::size_t prefix_horizon = 0U;
  std::vector<BigNat> authored_horizons;
  if (finite_cylinder_prefix) {
    auto authored = kernel::detail::c17_authored_transient_horizons(
        framework, request);
    if (!authored) {
      return Result<TransientSourceBundle>::failure(authored.error());
    }
    authored_horizons = std::move(authored).value();
    for (const BigNat& exact_horizon : authored_horizons) {
      auto converted = bounded_size(exact_horizon,
                                    "a transient backlog horizon");
      if (!converted) {
        return Result<TransientSourceBundle>::failure(converted.error());
      }
      prefix_horizon = std::max(prefix_horizon, converted.value());
    }
    if (prefix_horizon == std::numeric_limits<std::size_t>::max()) {
      return fail<TransientSourceBundle>(
          "c22.transient_horizon_dimension_overflow",
          "the transient cylinder horizon leaves no addressable terminal "
          "frontier",
          DiagnosticCategory::resource_limit);
    }
  }

  std::vector<metrics::detail::TemporalNodeCore> nodes;
  std::vector<metrics::detail::TemporalEntranceAtomCore> entrance;
  std::vector<std::size_t> initial_layer;
  for (const auto& atom : initial_law.atoms()) {
    std::optional<std::size_t> index;
    for (const std::size_t candidate : initial_layer) {
      if (nodes[candidate].decoded_state == atom.state) {
        index = candidate;
        break;
      }
    }
    if (!index.has_value()) {
      if (maximum_states.has_value() && nodes.size() >= *maximum_states) {
        return fail<TransientSourceBundle>(
            "c22.transient_state_budget_exhausted",
            "the exact transient state closure exceeds analysis-v1 "
            "max_states",
            DiagnosticCategory::resource_limit);
      }
      auto decoded_backlog =
          kernel::detail::c17_decode_audited_temporal_backlog(
              framework, atom.state);
      if (!decoded_backlog) {
        return Result<TransientSourceBundle>::failure(
            decoded_backlog.error());
      }
      nodes.push_back(metrics::detail::TemporalNodeCore{
          atom.state, {}, std::nullopt,
          std::move(decoded_backlog).value()});
      index = nodes.size() - 1U;
      initial_layer.push_back(*index);
    }
    const auto existing = std::find_if(
        entrance.begin(), entrance.end(),
        [&](const metrics::detail::TemporalEntranceAtomCore& item) {
          return item.node_index == *index;
        });
    if (existing == entrance.end()) {
      entrance.push_back(metrics::detail::TemporalEntranceAtomCore{
          *index, atom.state, atom.mass.exact_value()});
    } else {
      existing->exact_mass =
          existing->exact_mass + atom.mass.exact_value();
    }
  }

  if (request_kind == MetricKindV1::threshold_excursion) {
    for (const auto& atom : entrance) {
      if (atom.exact_mass.is_zero()) {
        continue;
      }
      auto inside = matches_state(stopped_plan->safe_set.predicate,
                                  nodes[atom.node_index]);
      if (!inside) {
        return Result<TransientSourceBundle>::failure(inside.error());
      }
      if (!inside.value()) {
        return fail<TransientSourceBundle>(
            "c22.threshold_excursion_entrance_outside_set",
            "a transient threshold excursion requires every positive-mass "
            "entrance atom to begin inside the authored threshold set",
            DiagnosticCategory::input_validation,
            {"source state index " + std::to_string(atom.node_index)});
      }
    }
  }

  const auto validate_row = [&](const MarkedKernelRow& row)
      -> Result<void> {
    if (!(row.exact_total_mass() == ExactRational::one())) {
      return fail<void>(
          "c22.transient_exact_row_not_unit",
          "an audited exact transient row does not have unit mass");
    }
    if (maximum_row_atoms.has_value() &&
        row.atoms().size() > *maximum_row_atoms) {
      return fail<void>(
          "c22.transient_row_atom_budget_exhausted",
          "an exact transient row exceeds analysis-v1 max_row_atoms",
          DiagnosticCategory::resource_limit);
    }
    return Result<void>::success();
  };

  if (finite_cylinder_prefix) {
    // A finite cylinder over a potentially infinite queue needs only a
    // projectively consistent layered prefix.  States are deliberately not
    // merged across depths: doing so could pull an unrequested future row
    // into the finite computation.  Rows are enumerated through the largest
    // requested state horizon. State observables are decoded directly from
    // the V0-sealed reduced state, so StateAt(h) never evaluates row h.
    std::vector<std::size_t> layer = initial_layer;
    for (std::size_t depth = 0U; depth < prefix_horizon; ++depth) {
      std::vector<std::size_t> next_layer;
      for (const std::size_t state : layer) {
        auto row = kernel::detail::c17_enumerate_audited_temporal_row(
            framework, nodes[state].decoded_state);
        if (!row) {
          return Result<TransientSourceBundle>::failure(row.error());
        }
        auto row_valid = validate_row(row.value());
        if (!row_valid) {
          return Result<TransientSourceBundle>::failure(row_valid.error());
        }
        std::vector<metrics::detail::TemporalTransitionCore> transitions;
        for (const auto& atom : row.value().atoms()) {
          if (atom.exact_mass.is_zero()) {
            continue;
          }
          std::optional<std::size_t> successor;
          for (const std::size_t candidate : next_layer) {
            if (nodes[candidate].decoded_state ==
                atom.edge.successor_state()) {
              successor = candidate;
              break;
            }
          }
          if (!successor.has_value()) {
            if (maximum_states.has_value() &&
                nodes.size() >= *maximum_states) {
              return fail<TransientSourceBundle>(
                  "c22.transient_state_budget_exhausted",
                  "the exact finite transient prefix exceeds analysis-v1 "
                  "max_states",
                  DiagnosticCategory::resource_limit);
            }
            auto decoded_backlog =
                kernel::detail::c17_decode_audited_temporal_backlog(
                    framework, atom.edge.successor_state());
            if (!decoded_backlog) {
              return Result<TransientSourceBundle>::failure(
                  decoded_backlog.error());
            }
            nodes.push_back(metrics::detail::TemporalNodeCore{
                atom.edge.successor_state(), {}, std::nullopt,
                std::move(decoded_backlog).value()});
            successor = nodes.size() - 1U;
            next_layer.push_back(*successor);
          }
          auto edge = project_transient_edge(atom.edge);
          if (!edge) {
            return Result<TransientSourceBundle>::failure(edge.error());
          }
          transitions.push_back(metrics::detail::TemporalTransitionCore{
              *successor, std::move(edge).value(), atom.exact_mass});
        }
        nodes[state].transitions = std::move(transitions);
      }
      layer = std::move(next_layer);
    }
  } else {
    // Discover only the safe reachable domain.  Hit states remain terminal
    // decoded nodes so F-C22-02 can audit every omitted atom against the
    // authored typed-exit predicate, but no post-hit row is ever traversed.
    // The max_states budget bounds both safe states and finite typed terminal
    // atoms; exhaustion is an incomplete result, never a boundary rule.
    for (std::size_t state = 0U; state < nodes.size(); ++state) {
      auto safe = matches_state(stopped_plan->safe_set.predicate,
                                nodes[state]);
      if (!safe) {
        return Result<TransientSourceBundle>::failure(safe.error());
      }
      if (!safe.value()) {
        continue;
      }
      auto row = kernel::detail::c17_enumerate_audited_temporal_row(
          framework, nodes[state].decoded_state);
      if (!row) {
        return Result<TransientSourceBundle>::failure(row.error());
      }
      auto row_valid = validate_row(row.value());
      if (!row_valid) {
        return Result<TransientSourceBundle>::failure(row_valid.error());
      }
      std::vector<metrics::detail::TemporalTransitionCore> transitions;
      for (const auto& atom : row.value().atoms()) {
        if (atom.exact_mass.is_zero()) {
          continue;
        }
        auto successor = find_state(nodes, atom.edge.successor_state());
        if (!successor.has_value()) {
          if (nodes.size() >= *maximum_states) {
            return fail<TransientSourceBundle>(
                "c22.transient_state_budget_exhausted",
                "the exact transient reachable domain did not close before "
                "analysis-v1 max_states",
                DiagnosticCategory::resource_limit);
          }
          auto decoded_backlog =
              kernel::detail::c17_decode_audited_temporal_backlog(
                  framework, atom.edge.successor_state());
          if (!decoded_backlog) {
            return Result<TransientSourceBundle>::failure(
                decoded_backlog.error());
          }
          nodes.push_back(metrics::detail::TemporalNodeCore{
              atom.edge.successor_state(), {}, std::nullopt,
              std::move(decoded_backlog).value()});
          successor = nodes.size() - 1U;
        }
        auto edge = project_transient_edge(atom.edge);
        if (!edge) {
          return Result<TransientSourceBundle>::failure(edge.error());
        }
        transitions.push_back(metrics::detail::TemporalTransitionCore{
            *successor, std::move(edge).value(), atom.exact_mass});
      }
      nodes[state].transitions = std::move(transitions);
    }
  }

  metrics::detail::TemporalSourceBindingV1 source_binding{
      AuditedTemporalSourceKindV1::transient_dispatch,
      binding.value().seal_token,
      fingerprint.value(),
      std::nullopt,
      binding.value().accepted_contract_identity,
      binding.value().normalized_requirements_identity,
      binding.value().authored_analysis_identity,
      binding.value().resolved_instance_identity,
      binding.value().target_selection_identity,
      binding.value().configured_arrival_identity,
      binding.value().selection_identity,
      binding.value().exact_state_schema_identity,
      binding.value().reduced_state_schema_identity,
      binding.value().mark_schema_identity,
      binding.value().continuation_schema_identity,
      binding.value().target_service_schema_identity,
      binding.value().timing_identity,
      binding.value().state_codec};
  const bool complete_rows =
      std::all_of(nodes.begin(), nodes.end(), [](const auto& node) {
        return !node.transitions.empty();
      });
  auto source =
      std::make_shared<const metrics::detail::TemporalSourceCore>(
          metrics::detail::TemporalSourceCore{
              std::move(source_binding), std::move(nodes), entrance, {},
              finite_cylinder_prefix
                  ? prefix_horizon
                  : std::numeric_limits<std::size_t>::max(),
              finite_cylinder_prefix
                  ? (prefix_horizon == 0U
                         ? std::optional<std::size_t>{}
                         : std::optional<std::size_t>{prefix_horizon - 1U})
                  : std::optional<std::size_t>{
                        std::numeric_limits<std::size_t>::max()},
              maximum_states, maximum_row_atoms, true, true,
              complete_rows});
  auto source_valid = validate_temporal_source(*source);
  if (!source_valid) {
    return Result<TransientSourceBundle>::failure(source_valid.error());
  }
  auto initial_core =
      std::make_shared<const metrics::detail::InitialLawCore>(
          metrics::detail::InitialLawCore{
              InitialLawKindV1::transient, source, std::move(entrance),
              fingerprint.value(), fingerprint.value(), false});
  InitialLaw entrance_law =
      detail::TemporalContractCoreAccess::initial_law(initial_core);
  std::optional<AuditedCylinderLaw> cylinder;
  std::optional<AuditedTemporalKernel> temporal_kernel;
  if (finite_cylinder_prefix) {
    auto minted = kernel::detail::c17_mint_transient_cylinder_law(
        framework, source, fingerprint.value());
    if (!minted) {
      return Result<TransientSourceBundle>::failure(minted.error());
    }
    cylinder.emplace(std::move(minted).value());
  } else {
    auto minted = kernel::detail::c17_mint_transient_temporal_kernel(
        framework, source, fingerprint.value());
    if (!minted) {
      return Result<TransientSourceBundle>::failure(minted.error());
    }
    temporal_kernel.emplace(std::move(minted).value());
  }
  return Result<TransientSourceBundle>::success(TransientSourceBundle{
      std::move(source), std::move(entrance_law), std::move(cylinder),
      std::move(temporal_kernel), target_ordinal.value(),
      std::move(authored_horizons),
      std::move(stopped_plan)});
}

[[nodiscard]] Result<SolverPolicy> transient_solver_policy(
    const MetricRequest& request,
    const Digest256& authored_analysis_identity) {
  const SolverSpec& solver = metric_request_header(request).context->solver;
  const auto* enumerated = std::get_if<EnumeratedSolver>(&solver);
  if (enumerated == nullptr) {
    return fail<SolverPolicy>(
        "c22.transient_enumerated_solver_required",
        "the exact C22 transient route requires the enumerated solver "
        "alternative",
        DiagnosticCategory::unavailable);
  }
  ExactRational tolerance = ExactRational::zero();
  if (metric_request_header(request)
          .context->resolution.tolerance.linear_residual_abs.has_value()) {
    tolerance = *metric_request_header(request)
                     .context->resolution.tolerance.linear_residual_abs;
  }
  return Result<SolverPolicy>::success(SolverPolicy{
      enumerated->linear_method, enumerated->max_iterations, tolerance,
      ExactRational::zero(), authored_analysis_identity});
}

}  // namespace

namespace {

Result<MetricValue> evaluate_transient_metric_impl(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law, const MetricRequest& request,
    std::optional<TemporalMetricBudgetReportV1>& budget_report,
    std::optional<std::size_t>& actual_maximum_row_atoms) {
  try {
    auto bundle = build_transient_source(framework, initial_law, request);
    if (!bundle) {
      return Result<MetricValue>::failure(bundle.error());
    }
    const MetricKindV1 kind = metric_request_kind(request);
    const std::size_t target = bundle.value().target_ordinal;
    if (kind == MetricKindV1::transient_backlog_law) {
      std::vector<ExactRational> masses;
      std::vector<BigNat> coordinates;
      std::size_t completed = 0U;
      const auto& authored_horizons = bundle.value().authored_horizons;
      if (!bundle.value().cylinder.has_value()) {
        return fail<MetricValue>(
            "c22.transient_cylinder_handoff_missing",
            "transient backlog dispatch did not mint its audited finite "
            "cylinder",
            DiagnosticCategory::internal);
      }
      for (const BigNat& authored_horizon : authored_horizons) {
        auto horizon = bounded_size(authored_horizon,
                                    "a transient backlog horizon");
        if (!horizon) {
          return Result<MetricValue>::failure(horizon.error());
        }
        // Exercise the required F-C22-06 -> F-C22-01 handoff on the same
        // audited transient source. StateAt(h) requires exactly h completed
        // transitions and proves total mass/projective consistency without
        // evaluating row h.
        CylinderEvent total_event{{StateAtV1{
            authored_horizon, AnyStatePredicateV1{}}}};
        auto total = evaluate_finite_cylinder(
            *bundle.value().cylinder, total_event, authored_horizon);
        if (!total) {
          return Result<MetricValue>::failure(total.error());
        }
        auto entrance = entrance_vector(
            *bundle.value().source,
            bundle.value().source->stationary_entrance);
        if (!entrance) {
          return Result<MetricValue>::failure(entrance.error());
        }
        ExactVector distribution = std::move(entrance).value();
        for (std::size_t step = 0U; step < horizon.value(); ++step) {
          distribution = advance_vector(*bundle.value().source,
                                        distribution);
        }
        struct BacklogMass final {
          BigNat level;
          ExactRational mass;
        };
        std::vector<BacklogMass> pmf;
        for (std::size_t state = 0U;
             state < bundle.value().source->nodes.size(); ++state) {
          if (distribution[state].is_zero()) {
            continue;
          }
          const auto& decoded_backlog =
              bundle.value().source->nodes[state].state_target_backlog;
          if (target >= decoded_backlog.size()) {
            return fail<MetricValue>(
                "c22.transient_backlog_target_not_retained",
                "the transient state decoder omits the requested target "
                "backlog",
                DiagnosticCategory::unavailable);
          }
          const BigNat& level = decoded_backlog[target];
          const auto found = std::find_if(
              pmf.begin(), pmf.end(), [&](const BacklogMass& atom) {
                return atom.level == level;
              });
          if (found == pmf.end()) {
            pmf.push_back(BacklogMass{level, distribution[state]});
          } else {
            found->mass = found->mass + distribution[state];
          }
        }
        std::stable_sort(pmf.begin(), pmf.end(),
                         [](const BacklogMass& left,
                            const BacklogMass& right) {
                           return left.level < right.level;
                         });
        for (const auto& atom : pmf) {
          coordinates.push_back(authored_horizon);
          coordinates.push_back(atom.level);
          masses.push_back(atom.mass);
        }
        completed = std::max(completed, horizon.value());
      }
      std::size_t maximum_row_width = 0U;
      auto budget = temporal_metric_budget(*bundle.value().source,
                                           completed);
      if (!budget) {
        return Result<MetricValue>::failure(budget.error());
      }
      budget_report = budget.value();
      maximum_row_width =
          temporal_maximum_row_width(*bundle.value().source);
      actual_maximum_row_atoms = maximum_row_width;
      return encode_metric(MetricEnvelope{
          "transient_backlog_law",
          bundle.value().source->binding.source_fingerprint,
          std::move(masses), {}, std::move(coordinates), false, false, 0.0L,
          completed, std::move(budget).value()});
    }

    if (kind == MetricKindV1::first_hit ||
        kind == MetricKindV1::threshold_excursion) {
      if (!bundle.value().kernel.has_value() ||
          !bundle.value().stopped_plan.has_value()) {
        return fail<MetricValue>(
            "c22.transient_kernel_handoff_missing",
            "transient stopped dispatch did not mint its audited temporal "
            "kernel and compiled stopped plan",
            DiagnosticCategory::internal);
      }
      const auto& stopped_plan = *bundle.value().stopped_plan;
      auto killed = construct_killed_kernel(
          *bundle.value().kernel, stopped_plan.safe_set,
          stopped_plan.absorption_marks);
      if (!killed) {
        return Result<MetricValue>::failure(killed.error());
      }
      auto policy = transient_solver_policy(
          request,
          bundle.value().source->binding.authored_analysis_identity);
      if (!policy) {
        return Result<MetricValue>::failure(policy.error());
      }
      auto stopped = evaluate_hit_survival_absorption(
          killed.value(), bundle.value().entrance,
          HorizonSpec{stopped_plan.horizon, stopped_plan.include_mean,
                      false},
          policy.value());
      if (!stopped) {
        return Result<MetricValue>::failure(stopped.error());
      }
      std::vector<ExactRational> values;
      std::vector<BigNat> indices;
      for (const auto& tail : stopped.value().survival_tails) {
        indices.push_back(tail.index);
        values.push_back(tail.exact_probability);
      }
      for (const auto& mass : stopped.value().absorption_masses) {
        indices.push_back(mass.hitting_time);
        values.push_back(mass.exact_probability);
      }
      if (stopped.value().absorption_status !=
          AbsorptionStatusV1::not_established) {
        values.push_back(stopped.value().exact_defect_probability);
      }
      if (stopped.value().mean_stopping_time.exact_value.has_value()) {
        values.push_back(*stopped.value().mean_stopping_time.exact_value);
      }
      std::vector<ExactRational> killed_row_residuals;
      killed_row_residuals.reserve(killed.value().row_diagnostics().size());
      for (const auto& row : killed.value().row_diagnostics()) {
        killed_row_residuals.push_back(row.exact_balance_residual);
      }
      std::size_t maximum_row_width = 0U;
      auto budget = temporal_metric_budget(
          *bundle.value().source,
          stopped.value().budget.requested_horizon, std::nullopt,
          stopped.value().budget.iterations,
          stopped.value().budget.authored_maximum_iterations,
          stopped.value().budget.maximum_iterations,
          stopped.value().budget.absolute_residual_tolerance,
          stopped.value().budget.relative_residual_tolerance,
          stopped.value().budget.budget_stop);
      if (!budget) {
        return Result<MetricValue>::failure(budget.error());
      }
      budget_report = budget.value();
      maximum_row_width =
          temporal_maximum_row_width(*bundle.value().source);
      actual_maximum_row_atoms = maximum_row_width;
      return encode_metric(MetricEnvelope{
          kind == MetricKindV1::first_hit ? "transient_first_hit"
                                          : "transient_threshold_excursion",
          bundle.value().source->binding.source_fingerprint,
          std::move(values), {}, std::move(indices), false, false, 0.0L,
          stopped.value().budget.requested_horizon,
          std::move(budget).value(), {}, false, std::nullopt,
          ExactRational::zero(), false, stopped.value(),
          std::move(killed_row_residuals)});
    }

    return fail<MetricValue>(
        "c22.transient_metric_variant_unsupported",
        "the accepted transient request is not a C22 finite-cylinder or "
        "stopped variant implemented by analysis-v1",
        DiagnosticCategory::unavailable);
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c22.transient_metric_allocation_failure",
        "transient metric dispatch exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c22.transient_metric_exception",
        "transient metric dispatch raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<detail::TransientMetricEvaluationV1>
detail::evaluate_transient_metric_with_budget(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law, const MetricRequest& request) {
  std::optional<TemporalMetricBudgetReportV1> budget;
  std::optional<std::size_t> maximum_row_width;
  auto value = evaluate_transient_metric_impl(
      framework, initial_law, request, budget, maximum_row_width);
  if (!value) {
    return Result<TransientMetricEvaluationV1>::failure(value.error());
  }
  if (!budget.has_value() || !maximum_row_width.has_value()) {
    return fail<TransientMetricEvaluationV1>(
        "c22.transient_metric_budget_report_missing",
        "a successful transient metric evaluation did not retain its "
        "canonical temporal budget report",
        DiagnosticCategory::internal);
  }
  return Result<TransientMetricEvaluationV1>::success(
      TransientMetricEvaluationV1{
          std::move(value).value(), std::move(*budget),
          *maximum_row_width});
}

Result<MetricValue> evaluate_transient_metric(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law, const MetricRequest& request) {
  std::optional<TemporalMetricBudgetReportV1> budget;
  std::optional<std::size_t> maximum_row_width;
  return evaluate_transient_metric_impl(
      framework, initial_law, request, budget, maximum_row_width);
}

#if defined(MWPERF_C22_TEST_SEAMS)
namespace testing {
namespace {

class EnvelopeReader final {
 public:
  explicit EnvelopeReader(const std::span<const std::byte> bytes)
      : bytes_(bytes) {}

  [[nodiscard]] std::optional<std::uint8_t> byte() {
    if (cursor_ == bytes_.size()) {
      return std::nullopt;
    }
    return std::to_integer<std::uint8_t>(bytes_[cursor_++]);
  }
  [[nodiscard]] std::optional<std::uint32_t> u32() {
    if (bytes_.size() - cursor_ < 4U) {
      return std::nullopt;
    }
    std::uint32_t result = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
      result = (result << 8U) |
               std::to_integer<std::uint8_t>(bytes_[cursor_++]);
    }
    return result;
  }
  [[nodiscard]] std::optional<std::uint64_t> u64() {
    if (bytes_.size() - cursor_ < 8U) {
      return std::nullopt;
    }
    std::uint64_t result = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
      result = (result << 8U) |
               std::to_integer<std::uint8_t>(bytes_[cursor_++]);
    }
    return result;
  }
  [[nodiscard]] std::optional<std::span<const std::byte>> frame() {
    const auto size = u32();
    if (!size.has_value() || *size > bytes_.size() - cursor_) {
      return std::nullopt;
    }
    const auto result = bytes_.subspan(cursor_, *size);
    cursor_ += *size;
    return result;
  }
  [[nodiscard]] bool exhausted() const noexcept {
    return cursor_ == bytes_.size();
  }

 private:
  std::span<const std::byte> bytes_;
  std::size_t cursor_{0U};
};

[[nodiscard]] std::optional<std::string> read_text(EnvelopeReader& reader) {
  const auto frame = reader.frame();
  if (!frame.has_value()) {
    return std::nullopt;
  }
  std::string result;
  result.reserve(frame->size());
  for (const std::byte value : *frame) {
    result.push_back(static_cast<char>(
        std::to_integer<unsigned char>(value)));
  }
  return result;
}

[[nodiscard]] std::optional<ExactRational> read_rational(
    EnvelopeReader& reader) {
  const auto numerator = read_text(reader);
  const auto denominator = read_text(reader);
  if (!numerator.has_value() || !denominator.has_value()) {
    return std::nullopt;
  }
  try {
    BigInt n(*numerator);
    BigInt d(*denominator);
    auto value = ExactRational::make(std::move(n), std::move(d));
    if (!value || value.value().numerator_decimal() != *numerator ||
        value.value().denominator_decimal() != *denominator) {
      return std::nullopt;
    }
    return std::move(value).value();
  } catch (const std::exception&) {
    return std::nullopt;
  }
}

[[nodiscard]] std::optional<BigNat> read_natural(EnvelopeReader& reader) {
  const auto text = read_text(reader);
  if (!text.has_value()) {
    return std::nullopt;
  }
  try {
    BigInt value(*text);
    auto result = BigNat::from_big_int(std::move(value));
    if (!result || result.value().to_decimal_string() != *text) {
      return std::nullopt;
    }
    return std::move(result).value();
  } catch (const std::exception&) {
    return std::nullopt;
  }
}

[[nodiscard]] std::optional<long double> read_floating(
    EnvelopeReader& reader) {
  const auto text = read_text(reader);
  if (!text.has_value() || text->empty()) {
    return std::nullopt;
  }
  char* end = nullptr;
  const long double value = std::strtold(text->c_str(), &end);
  if (end == nullptr || end != text->c_str() + text->size() ||
      !std::isfinite(value)) {
    return std::nullopt;
  }
  return value;
}

[[nodiscard]] Result<std::optional<std::size_t>> read_optional_size(
    EnvelopeReader& reader) {
  const auto present = reader.byte();
  if (!present.has_value() || *present > 1U) {
    return fail<std::optional<std::size_t>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional-size tag");
  }
  if (*present == 0U) {
    return Result<std::optional<std::size_t>>::success(std::nullopt);
  }
  const auto value = reader.u64();
  if (!value.has_value() ||
      *value > std::numeric_limits<std::size_t>::max()) {
    return fail<std::optional<std::size_t>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional size");
  }
  return Result<std::optional<std::size_t>>::success(
      std::optional<std::size_t>{static_cast<std::size_t>(*value)});
}

[[nodiscard]] Result<std::optional<long double>> read_optional_floating(
    EnvelopeReader& reader) {
  const auto present = reader.byte();
  if (!present.has_value() || *present > 1U) {
    return fail<std::optional<long double>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional-floating tag");
  }
  if (*present == 0U) {
    return Result<std::optional<long double>>::success(std::nullopt);
  }
  const auto value = read_floating(reader);
  if (!value.has_value()) {
    return fail<std::optional<long double>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional floating value");
  }
  return Result<std::optional<long double>>::success(
      std::optional<long double>{*value});
}

[[nodiscard]] Result<std::optional<ExactRational>> read_optional_rational(
    EnvelopeReader& reader) {
  const auto present = reader.byte();
  if (!present.has_value() || *present > 1U) {
    return fail<std::optional<ExactRational>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional-rational tag");
  }
  if (*present == 0U) {
    return Result<std::optional<ExactRational>>::success(std::nullopt);
  }
  auto value = read_rational(reader);
  if (!value.has_value()) {
    return fail<std::optional<ExactRational>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional rational value");
  }
  return Result<std::optional<ExactRational>>::success(
      std::optional<ExactRational>{std::move(*value)});
}

[[nodiscard]] Result<std::optional<BigNat>> read_optional_natural(
    EnvelopeReader& reader) {
  const auto present = reader.byte();
  if (!present.has_value() || *present > 1U) {
    return fail<std::optional<BigNat>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional-natural tag");
  }
  if (*present == 0U) {
    return Result<std::optional<BigNat>>::success(std::nullopt);
  }
  auto value = read_natural(reader);
  if (!value.has_value()) {
    return fail<std::optional<BigNat>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid optional natural value");
  }
  return Result<std::optional<BigNat>>::success(
      std::optional<BigNat>{std::move(*value)});
}

[[nodiscard]] Result<std::vector<std::optional<ExactRational>>>
read_optional_rationals(EnvelopeReader& reader) {
  const auto count = reader.u32();
  if (!count.has_value()) {
    return fail<std::vector<std::optional<ExactRational>>>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has no stopped residual count");
  }
  std::vector<std::optional<ExactRational>> result;
  result.reserve(*count);
  for (std::uint32_t index = 0U; index < *count; ++index) {
    const auto present = reader.byte();
    if (!present.has_value() || *present > 1U) {
      return fail<std::vector<std::optional<ExactRational>>>(
          "c22.test_metric_envelope_malformed",
          "a C22 metric envelope has an invalid stopped residual tag");
    }
    if (*present == 0U) {
      result.emplace_back(std::nullopt);
      continue;
    }
    auto residual = read_rational(reader);
    if (!residual.has_value()) {
      return fail<std::vector<std::optional<ExactRational>>>(
          "c22.test_metric_envelope_malformed",
          "a C22 metric envelope has a noncanonical stopped residual");
    }
    result.emplace_back(std::move(*residual));
  }
  return Result<std::vector<std::optional<ExactRational>>>::success(
      std::move(result));
}

[[nodiscard]] Result<StoppedSolveDiagnosticsV1> read_solve_diagnostics(
    EnvelopeReader& reader) {
  const auto status = reader.byte();
  const auto iterations = reader.u64();
  if (!status.has_value() ||
      *status > static_cast<std::uint8_t>(
                    StoppedSolveStatusV1::budget_stopped) ||
      !iterations.has_value() ||
      *iterations > std::numeric_limits<std::size_t>::max()) {
    return fail<StoppedSolveDiagnosticsV1>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has an invalid stopped solve header");
  }
  auto dimension = read_optional_size(reader);
  auto rank = read_optional_size(reader);
  auto equation = read_optional_rationals(reader);
  auto auxiliary = read_optional_rationals(reader);
  auto reciprocal_condition = read_optional_floating(reader);
  auto condition_threshold = read_optional_floating(reader);
  const auto warning = reader.byte();
  auto method = read_text(reader);
  if (!dimension || !rank || !equation || !auxiliary ||
      !reciprocal_condition || !condition_threshold ||
      !warning.has_value() || *warning > 1U || !method.has_value()) {
    return fail<StoppedSolveDiagnosticsV1>(
        "c22.test_metric_envelope_malformed",
        "a C22 metric envelope has malformed stopped solve diagnostics");
  }
  return Result<StoppedSolveDiagnosticsV1>::success(
      StoppedSolveDiagnosticsV1{
          static_cast<StoppedSolveStatusV1>(*status),
          static_cast<std::size_t>(*iterations), std::move(dimension).value(),
          std::move(rank).value(), std::move(equation).value(),
          std::move(auxiliary).value(),
          std::move(reciprocal_condition).value(),
          std::move(condition_threshold).value(), *warning == 1U,
          std::move(*method)});
}

[[nodiscard]] bool valid_synthetic_kind_pair(
    const AuditedTemporalSourceKindV1 source,
    const std::optional<InitialLawKindV1> entrance) {
  if (source == AuditedTemporalSourceKindV1::framework_v0) {
    return !entrance.has_value();
  }
  return entrance.has_value() &&
         entrance_kind_matches_source(*entrance, source);
}

[[nodiscard]] bool valid_synthetic_f05_authorization(
    const C22SyntheticF05AuthorizationV1& authorization) {
  switch (authorization.request_kind) {
    case MetricKindV1::service_persistence:
      return std::holds_alternative<ServicePersistenceParametersV1>(
          authorization.parameters);
    case MetricKindV1::service_autocovariance:
      return std::holds_alternative<ServiceAutocovarianceParametersV1>(
          authorization.parameters);
    case MetricKindV1::service_spectrum:
      return std::holds_alternative<ServiceSpectrumParametersV1>(
          authorization.parameters);
    case MetricKindV1::service_window_count:
      return std::holds_alternative<ServiceWindowCountParametersV1>(
          authorization.parameters);
    case MetricKindV1::mean_event_gap:
      return std::holds_alternative<MeanEventGapParametersV1>(
          authorization.parameters);
    case MetricKindV1::mean_binary_run:
      return std::holds_alternative<MeanBinaryRunParametersV1>(
          authorization.parameters);
    default:
      return false;
  }
}

}  // namespace

Result<C22SyntheticViewsV1> C22FixtureAccess::mint_exact_source(
    const AuditedTemporalSourceKindV1 source_kind,
    const std::optional<InitialLawKindV1> entrance_kind,
    C22SyntheticSourceIdentityV1 identity,
    std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance,
    const std::size_t maximum_state_offset,
    std::optional<std::size_t> maximum_edge_offset,
    std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations,
    const bool projectively_consistent) {
  return mint_source(source_kind, entrance_kind, std::move(identity),
                     std::move(nodes), std::move(entrance), {},
                     maximum_state_offset, std::move(maximum_edge_offset),
                     true, std::move(f05_authorizations),
                     projectively_consistent);
}

Result<C22SyntheticViewsV1> C22FixtureAccess::mint_analytic_source(
    const AuditedTemporalSourceKindV1 source_kind,
    const std::optional<InitialLawKindV1> entrance_kind,
    C22SyntheticSourceIdentityV1 identity,
    std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance,
    std::vector<C22SyntheticRowErrorEnclosureV1> row_error_enclosures,
    const std::size_t maximum_state_offset,
    std::optional<std::size_t> maximum_edge_offset,
    std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations,
    const bool projectively_consistent) {
  return mint_source(
      source_kind, entrance_kind, std::move(identity), std::move(nodes),
      std::move(entrance), std::move(row_error_enclosures),
      maximum_state_offset, std::move(maximum_edge_offset), false,
      std::move(f05_authorizations), projectively_consistent);
}

Result<C22SyntheticViewsV1> C22FixtureAccess::mint_source(
    const AuditedTemporalSourceKindV1 source_kind,
    const std::optional<InitialLawKindV1> entrance_kind,
    C22SyntheticSourceIdentityV1 identity,
    std::vector<C22SyntheticNodeV1> synthetic_nodes,
    std::vector<C22SyntheticEntranceV1> synthetic_entrance,
    std::vector<C22SyntheticRowErrorEnclosureV1> row_error_enclosures,
    const std::size_t maximum_state_offset,
    std::optional<std::size_t> maximum_edge_offset,
    const bool exact_rows,
    std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations,
    const bool projectively_consistent) {
  try {
    if (!valid_synthetic_kind_pair(source_kind, entrance_kind) ||
        !nonzero_digest(identity.source_fingerprint) ||
        identity.state_codec.id.empty() ||
        identity.state_codec.version == 0U || synthetic_nodes.empty()) {
      return fail<C22SyntheticViewsV1>(
          "c22.invalid_synthetic_source_identity",
          "a C22 synthetic source has an invalid closed tag pairing or "
          "incomplete identity");
    }
    if ((exact_rows && !row_error_enclosures.empty()) ||
        (!exact_rows &&
         row_error_enclosures.size() != synthetic_nodes.size())) {
      return fail<C22SyntheticViewsV1>(
          "c22.invalid_synthetic_row_certification",
          exact_rows
              ? "an exact synthetic source must not carry analytic row "
                "error enclosures"
              : "an analytic synthetic source requires one certified "
                "row-error enclosure per node");
    }
    std::vector<metrics::detail::F05AuthorizationV1> authorizations;
    authorizations.reserve(f05_authorizations.size());
    for (auto& authorization : f05_authorizations) {
      if (!valid_synthetic_f05_authorization(authorization)) {
        return fail<C22SyntheticViewsV1>(
            "c22.invalid_synthetic_f05_authorization",
            "a synthetic F-C22-05 authorization is not one exact member of "
            "the closed temporal-statistic vocabulary");
      }
      metrics::detail::F05AuthorizationV1 internal{
          authorization.request_kind, authorization.target_ordinal,
          std::move(authorization.parameters)};
      if (std::find(authorizations.begin(), authorizations.end(), internal) !=
          authorizations.end()) {
        return fail<C22SyntheticViewsV1>(
            "c22.duplicate_synthetic_f05_authorization",
            "a synthetic source repeats an exact F-C22-05 authorization");
      }
      authorizations.push_back(std::move(internal));
    }
    const bool requires_projection =
        source_kind_requires_projection_binding(source_kind);
    if (identity.projection_fingerprint.has_value() !=
        requires_projection) {
      return fail<C22SyntheticViewsV1>(
          "c22.synthetic_projection_fingerprint_rule_mismatch",
          requires_projection
              ? "a stationary/Palm/FIFO synthetic handoff requires its "
                "complete projection fingerprint"
              : "a framework/transient synthetic handoff must not claim a "
                "C21 projection fingerprint");
    }
    const auto seal = std::make_shared<const
        surrogate::detail::AuditedConsumerSealIdentity>();
    metrics::detail::TemporalSourceBindingV1 binding{
        source_kind,
        seal,
        identity.source_fingerprint,
        identity.projection_fingerprint,
        identity.accepted_contract_identity,
        identity.normalized_requirements_identity,
        identity.authored_analysis_identity,
        identity.resolved_instance_identity,
        identity.target_selection_identity,
        identity.configured_arrival_identity,
        identity.selection_identity,
        identity.exact_state_schema_identity,
        identity.reduced_state_schema_identity,
        identity.mark_schema_identity,
        identity.continuation_schema_identity,
        identity.target_service_schema_identity,
        identity.timing_identity,
        identity.state_codec};
    std::vector<metrics::detail::TemporalNodeCore> nodes;
    nodes.reserve(synthetic_nodes.size());
    for (std::size_t node_index = 0U;
         node_index < synthetic_nodes.size(); ++node_index) {
      auto& node = synthetic_nodes[node_index];
      std::vector<metrics::detail::TemporalTransitionCore> transitions;
      transitions.reserve(node.transitions.size());
      for (auto& transition : node.transitions) {
        transitions.push_back(metrics::detail::TemporalTransitionCore{
            transition.successor_index, std::move(transition.edge),
            transition.exact_mass});
      }
      std::vector<BigNat> state_backlog;
      if (!transitions.empty()) {
        state_backlog =
            transitions.front().edge.prearrival_target_backlog;
      }
      std::optional<metrics::detail::TemporalRowErrorEnclosureV1>
          row_error;
      if (!exact_rows) {
        row_error.emplace(metrics::detail::TemporalRowErrorEnclosureV1{
            row_error_enclosures[node_index].lower,
            row_error_enclosures[node_index].upper});
      }
      nodes.push_back(metrics::detail::TemporalNodeCore{
          std::move(node.state), std::move(transitions),
          node.invariant_component, std::move(state_backlog),
          std::move(row_error)});
    }
    std::vector<metrics::detail::TemporalEntranceAtomCore> entrance;
    entrance.reserve(synthetic_entrance.size());
    for (const auto& atom : synthetic_entrance) {
      if (atom.node_index >= nodes.size()) {
        return fail<C22SyntheticViewsV1>(
            "c22.synthetic_entrance_out_of_domain",
            "a synthetic entrance atom points outside its source domain");
      }
      entrance.push_back(metrics::detail::TemporalEntranceAtomCore{
          atom.node_index, nodes[atom.node_index].decoded_state,
          atom.exact_mass});
    }
    auto source =
        std::make_shared<const metrics::detail::TemporalSourceCore>(
            metrics::detail::TemporalSourceCore{
                std::move(binding), std::move(nodes), entrance,
                std::move(authorizations),
                maximum_state_offset, maximum_edge_offset, std::nullopt,
                std::nullopt, projectively_consistent, exact_rows, true});
    auto valid = validate_temporal_source(*source);
    if (!valid) {
      return Result<C22SyntheticViewsV1>::failure(valid.error());
    }
    auto normalized = entrance_vector(*source, entrance);
    if (!normalized) {
      return Result<C22SyntheticViewsV1>::failure(normalized.error());
    }
    if (exact_rows &&
        (source_kind == AuditedTemporalSourceKindV1::framework_v0 ||
         entrance_kind == InitialLawKindV1::stationary) &&
        advance_vector(*source, normalized.value()) != normalized.value()) {
      return fail<C22SyntheticViewsV1>(
          "c22.synthetic_stationary_entrance_not_invariant",
          "a stationary synthetic entrance is not invariant for its exact "
          "temporal rows");
    }
    const Digest256 projection =
        identity.projection_fingerprint.value_or(
            identity.source_fingerprint);
    std::optional<InitialLaw> initial;
    if (entrance_kind.has_value()) {
      auto initial_core =
          std::make_shared<const metrics::detail::InitialLawCore>(
              metrics::detail::InitialLawCore{
                  *entrance_kind, source, entrance,
                  identity.source_fingerprint, projection,
                  identity.projection_fingerprint.has_value()});
      initial.emplace(
          detail::TemporalContractCoreAccess::initial_law(initial_core));
    }

    std::optional<AuditedCylinderLaw> cylinder;
    std::optional<AuditedTemporalKernel> kernel;
    std::optional<AuditedTemporalLaw> law;
    if (exact_rows &&
        ((source_kind == AuditedTemporalSourceKindV1::framework_v0) ||
        (entrance_kind == InitialLawKindV1::stationary &&
         source_kind == AuditedTemporalSourceKindV1::stationary_projection) ||
        (entrance_kind == InitialLawKindV1::transient &&
         source_kind == AuditedTemporalSourceKindV1::transient_dispatch))) {
      cylinder.emplace(AuditedCylinderLaw(
          nullptr, source_kind, source, identity.source_fingerprint,
          projection));
    }
    kernel.emplace(AuditedTemporalKernel(
        nullptr, source_kind, source, identity.source_fingerprint,
        projection));
    if (exact_rows &&
        (source_kind == AuditedTemporalSourceKindV1::framework_v0 ||
         source_kind ==
             AuditedTemporalSourceKindV1::stationary_projection) &&
        (source_kind == AuditedTemporalSourceKindV1::framework_v0 ||
         entrance_kind == InitialLawKindV1::stationary)) {
      law.emplace(AuditedTemporalLaw(
          nullptr, source_kind, source, identity.source_fingerprint,
          projection));
    }
    return Result<C22SyntheticViewsV1>::success(C22SyntheticViewsV1{
        std::move(cylinder), std::move(kernel), std::move(law),
        std::move(initial)});
  } catch (const std::bad_alloc&) {
    return fail<C22SyntheticViewsV1>(
        "c22.synthetic_source_allocation_failure",
        "minting a C22 synthetic source exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<C22SyntheticViewsV1>(
        "c22.synthetic_source_exception",
        "minting a C22 synthetic source raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<C22MetricEnvelopeInspectionV1>
C22FixtureAccess::decode_metric_value(const MetricValue& value) {
  if (value.codec.id != "mwperf.c22.temporal_metric" ||
      value.codec.version != 1U) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_codec_mismatch",
        "the value is not a version-1 C22 temporal metric envelope");
  }
  EnvelopeReader reader(value.canonical_value);
  const auto version = reader.u32();
  auto kind = read_text(reader);
  const auto digest_bytes = reader.frame();
  if (!version.has_value() || *version != 1U || !kind.has_value() ||
      !digest_bytes.has_value()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has an invalid header");
  }
  auto digest = Digest256::from_bytes(*digest_bytes);
  const auto exact_count = reader.u32();
  if (!digest || !exact_count.has_value()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has an invalid source or exact count");
  }
  std::vector<ExactRational> exact_values;
  exact_values.reserve(*exact_count);
  for (std::uint32_t index = 0U; index < *exact_count; ++index) {
    auto parsed = read_rational(reader);
    if (!parsed.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 metric envelope contains a noncanonical rational");
    }
    exact_values.push_back(std::move(*parsed));
  }
  const auto numerical_count = reader.u32();
  if (!numerical_count.has_value()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has no numerical count");
  }
  std::vector<long double> numerical_values;
  numerical_values.reserve(*numerical_count);
  for (std::uint32_t index = 0U; index < *numerical_count; ++index) {
    auto parsed = read_floating(reader);
    if (!parsed.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 metric envelope contains a noncanonical numerical image");
    }
    numerical_values.push_back(*parsed);
  }
  const auto index_count = reader.u32();
  if (!index_count.has_value()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has no index count");
  }
  std::vector<BigNat> indices;
  indices.reserve(*index_count);
  for (std::uint32_t index = 0U; index < *index_count; ++index) {
    auto parsed = read_natural(reader);
    if (!parsed.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 metric envelope contains a noncanonical natural index");
    }
    indices.push_back(std::move(*parsed));
  }
  const auto rectangular = reader.byte();
  const auto radians = reader.byte();
  auto error = read_floating(reader);
  const auto completed = reader.u64();
  if (!rectangular.has_value() || *rectangular > 1U ||
      !radians.has_value() || *radians > 1U || !error.has_value() ||
      *error < 0.0L || !completed.has_value() ||
      *completed > std::numeric_limits<std::size_t>::max()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope trailer is invalid");
  }
  const auto frequency_count = reader.u32();
  if (!frequency_count.has_value()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has no authored-frequency count");
  }
  std::vector<ExactRational> authored_frequencies;
  authored_frequencies.reserve(*frequency_count);
  for (std::uint32_t index = 0U; index < *frequency_count; ++index) {
    auto parsed = read_rational(reader);
    if (!parsed.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 metric envelope contains a noncanonical authored "
          "frequency");
    }
    authored_frequencies.push_back(std::move(*parsed));
  }
  const auto certified = reader.byte();
  const auto tolerance_present = reader.byte();
  if (!certified.has_value() || *certified > 1U ||
      !tolerance_present.has_value() || *tolerance_present > 1U) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has an invalid numerical metadata tag");
  }
  std::optional<ExactRational> authored_tolerance;
  if (*tolerance_present == 1U) {
    auto parsed = read_rational(reader);
    if (!parsed.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 metric envelope has a noncanonical authored tolerance");
    }
    authored_tolerance.emplace(std::move(*parsed));
  }
  auto probability_kernel_error = read_rational(reader);
  auto conservative_radius = read_floating(reader);
  const auto whole_range = reader.byte();
  if (!probability_kernel_error.has_value() ||
      !probability_kernel_error->is_nonnegative() ||
      !conservative_radius.has_value() || *conservative_radius < 0.0L ||
      !whole_range.has_value() || *whole_range > 1U) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has invalid separated numerical error "
        "metadata");
  }

  const auto state_count = reader.u64();
  const auto row_atom_count = reader.u64();
  const auto requested_horizon = reader.u64();
  auto permitted_horizon = read_optional_size(reader);
  const auto maximum_state_offset = reader.u64();
  auto maximum_edge_offset = read_optional_size(reader);
  auto maximum_states = read_optional_size(reader);
  auto maximum_row_atoms = read_optional_size(reader);
  const auto solver_iterations = reader.u64();
  auto authored_maximum_solver_iterations = read_optional_natural(reader);
  auto maximum_solver_iterations = read_optional_size(reader);
  auto absolute_residual_tolerance = read_optional_rational(reader);
  auto relative_residual_tolerance = read_optional_rational(reader);
  const auto generic_budget_stop = reader.byte();
  if (!state_count.has_value() || !row_atom_count.has_value() ||
      !requested_horizon.has_value() || !permitted_horizon ||
      !maximum_state_offset.has_value() || !maximum_edge_offset ||
      !maximum_states || !maximum_row_atoms ||
      !solver_iterations.has_value() ||
      !authored_maximum_solver_iterations || !maximum_solver_iterations ||
      !absolute_residual_tolerance || !relative_residual_tolerance ||
      !generic_budget_stop.has_value() || *generic_budget_stop > 1U ||
      *state_count > std::numeric_limits<std::size_t>::max() ||
      *row_atom_count > std::numeric_limits<std::size_t>::max() ||
      *requested_horizon > std::numeric_limits<std::size_t>::max() ||
      *maximum_state_offset > std::numeric_limits<std::size_t>::max() ||
      *solver_iterations > std::numeric_limits<std::size_t>::max() ||
      (permitted_horizon.value().has_value() &&
       *requested_horizon > *permitted_horizon.value()) ||
      (maximum_states.value().has_value() &&
       *state_count > *maximum_states.value()) ||
      (absolute_residual_tolerance.value().has_value() &&
       !absolute_residual_tolerance.value()->is_nonnegative()) ||
      (relative_residual_tolerance.value().has_value() &&
       !relative_residual_tolerance.value()->is_nonnegative()) ||
      (absolute_residual_tolerance.value().has_value() !=
       relative_residual_tolerance.value().has_value())) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has invalid temporal budget metadata");
  }
  TemporalMetricBudgetReportV1 temporal_budget{
      static_cast<std::size_t>(*state_count),
      static_cast<std::size_t>(*row_atom_count),
      static_cast<std::size_t>(*requested_horizon),
      std::move(permitted_horizon).value(),
      static_cast<std::size_t>(*maximum_state_offset),
      std::move(maximum_edge_offset).value(),
      std::move(maximum_states).value(),
      std::move(maximum_row_atoms).value(),
      static_cast<std::size_t>(*solver_iterations),
      std::move(authored_maximum_solver_iterations).value(),
      std::move(maximum_solver_iterations).value(),
      std::move(absolute_residual_tolerance).value(),
      std::move(relative_residual_tolerance).value(),
      *generic_budget_stop == 1U};

  const auto stopped_present = reader.byte();
  if (!stopped_present.has_value() || *stopped_present > 1U) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has an invalid stopped-result tag");
  }

  std::optional<StoppedMetricBundle> stopped_metric;
  std::vector<ExactRational> killed_row_residuals;
  if (*stopped_present == 1U) {
    const auto initial_kind = reader.byte();
    const auto tail_count = reader.u32();
    if (!initial_kind.has_value() ||
        *initial_kind > static_cast<std::uint8_t>(InitialLawKindV1::fifo_tag) ||
        !tail_count.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has an invalid entrance or tail "
          "header");
    }
    std::vector<SurvivalTailV1> tails;
    tails.reserve(*tail_count);
    for (std::uint32_t index = 0U; index < *tail_count; ++index) {
      auto tail_index = read_natural(reader);
      auto probability = read_rational(reader);
      if (!tail_index.has_value() || !probability.has_value() ||
          !probability->is_nonnegative() ||
          *probability > ExactRational::one()) {
        return fail<C22MetricEnvelopeInspectionV1>(
            "c22.test_metric_envelope_malformed",
            "the C22 stopped metric metadata has an invalid survival tail");
      }
      tails.push_back(SurvivalTailV1{std::move(*tail_index),
                                     std::move(*probability)});
    }

    const auto mass_count = reader.u32();
    if (!mass_count.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has no absorption-mass count");
    }
    std::vector<TypedAbsorptionMassV1> masses;
    masses.reserve(*mass_count);
    for (std::uint32_t index = 0U; index < *mass_count; ++index) {
      auto hitting_time = read_natural(reader);
      auto type_id = read_text(reader);
      auto probability = read_rational(reader);
      if (!hitting_time.has_value() || !type_id.has_value() ||
          type_id->empty() || !probability.has_value() ||
          !probability->is_nonnegative() ||
          *probability > ExactRational::one()) {
        return fail<C22MetricEnvelopeInspectionV1>(
            "c22.test_metric_envelope_malformed",
            "the C22 stopped metric metadata has an invalid typed absorption "
            "mass");
      }
      masses.push_back(TypedAbsorptionMassV1{
          std::move(*hitting_time), std::move(*type_id),
          std::move(*probability)});
    }

    const auto eventual_count = reader.u32();
    if (!eventual_count.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has no eventual-exit count");
    }
    std::vector<EventualTypedExitProbabilityV1> eventual;
    eventual.reserve(*eventual_count);
    for (std::uint32_t index = 0U; index < *eventual_count; ++index) {
      auto type_id = read_text(reader);
      auto probability = read_rational(reader);
      if (!type_id.has_value() || type_id->empty() ||
          !probability.has_value() || !probability->is_nonnegative() ||
          *probability > ExactRational::one()) {
        return fail<C22MetricEnvelopeInspectionV1>(
            "c22.test_metric_envelope_malformed",
            "the C22 stopped metric metadata has an invalid eventual typed "
            "exit probability");
      }
      eventual.push_back(EventualTypedExitProbabilityV1{
          std::move(*type_id), std::move(*probability)});
    }

    auto defect = read_rational(reader);
    const auto absorption_status = reader.byte();
    const auto mean_status = reader.byte();
    const auto mean_present = reader.byte();
    if (!defect.has_value() || !defect->is_nonnegative() ||
        *defect > ExactRational::one() || !absorption_status.has_value() ||
        *absorption_status >
            static_cast<std::uint8_t>(AbsorptionStatusV1::not_established) ||
        !mean_status.has_value() ||
        *mean_status > static_cast<std::uint8_t>(
                           ExtendedNonnegativeStatusV1::numerically_unresolved) ||
        !mean_present.has_value() || *mean_present > 1U) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has invalid extended statuses");
    }
    std::optional<ExactRational> exact_mean;
    if (*mean_present == 1U) {
      auto parsed = read_rational(reader);
      if (!parsed.has_value() || !parsed->is_nonnegative()) {
        return fail<C22MetricEnvelopeInspectionV1>(
            "c22.test_metric_envelope_malformed",
            "the C22 stopped metric metadata has an invalid finite mean");
      }
      exact_mean.emplace(std::move(*parsed));
    }
    const auto decoded_mean_status =
        static_cast<ExtendedNonnegativeStatusV1>(*mean_status);
    if ((decoded_mean_status == ExtendedNonnegativeStatusV1::finite) !=
        exact_mean.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric mean status and exact payload disagree");
    }

    const auto requested_horizon = reader.u64();
    const auto state_count = reader.u64();
    const auto row_atom_count = reader.u64();
    const auto iterations = reader.u64();
    if (!requested_horizon.has_value() || !state_count.has_value() ||
        !row_atom_count.has_value() || !iterations.has_value() ||
        *requested_horizon > std::numeric_limits<std::size_t>::max() ||
        *state_count > std::numeric_limits<std::size_t>::max() ||
        *row_atom_count > std::numeric_limits<std::size_t>::max() ||
        *iterations > std::numeric_limits<std::size_t>::max()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has invalid finite budgets");
    }
    auto maximum_states = read_optional_size(reader);
    auto maximum_row_atoms = read_optional_size(reader);
    auto maximum_iterations = read_optional_size(reader);
    auto authored_maximum_iterations = read_optional_natural(reader);
    auto absolute_tolerance = read_rational(reader);
    auto relative_tolerance = read_rational(reader);
    const auto budget_stop = reader.byte();
    const auto finite_preserved = reader.byte();
    if (!maximum_states || !maximum_row_atoms || !maximum_iterations ||
        !authored_maximum_iterations ||
        !absolute_tolerance.has_value() ||
        !absolute_tolerance->is_nonnegative() ||
        !relative_tolerance.has_value() ||
        !relative_tolerance->is_nonnegative() ||
        !budget_stop.has_value() || *budget_stop > 1U ||
        !finite_preserved.has_value() || *finite_preserved > 1U) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has invalid solver budgets or "
          "tolerances");
    }

    const auto typed_diagnostics_present = reader.byte();
    if (!typed_diagnostics_present.has_value() ||
        *typed_diagnostics_present > 1U) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has an invalid typed-solve tag");
    }
    std::optional<StoppedSolveDiagnosticsV1> typed_diagnostics;
    if (*typed_diagnostics_present == 1U) {
      auto decoded = read_solve_diagnostics(reader);
      if (!decoded) {
        return Result<C22MetricEnvelopeInspectionV1>::failure(decoded.error());
      }
      typed_diagnostics.emplace(std::move(decoded).value());
    }
    const auto potential_diagnostics_present = reader.byte();
    if (!potential_diagnostics_present.has_value() ||
        *potential_diagnostics_present > 1U) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has an invalid potential-solve "
          "tag");
    }
    std::optional<StoppedSolveDiagnosticsV1> potential_diagnostics;
    if (*potential_diagnostics_present == 1U) {
      auto decoded = read_solve_diagnostics(reader);
      if (!decoded) {
        return Result<C22MetricEnvelopeInspectionV1>::failure(decoded.error());
      }
      potential_diagnostics.emplace(std::move(decoded).value());
    }

    const auto residual_count = reader.u32();
    if (!residual_count.has_value()) {
      return fail<C22MetricEnvelopeInspectionV1>(
          "c22.test_metric_envelope_malformed",
          "the C22 stopped metric metadata has no killed-row residual count");
    }
    killed_row_residuals.reserve(*residual_count);
    for (std::uint32_t index = 0U; index < *residual_count; ++index) {
      auto residual = read_rational(reader);
      if (!residual.has_value()) {
        return fail<C22MetricEnvelopeInspectionV1>(
            "c22.test_metric_envelope_malformed",
            "the C22 stopped metric metadata has a noncanonical killed-row "
            "residual");
      }
      killed_row_residuals.push_back(std::move(*residual));
    }

    stopped_metric.emplace(StoppedMetricBundle{
        digest.value(), static_cast<InitialLawKindV1>(*initial_kind),
        std::move(tails), std::move(masses), std::move(eventual),
        std::move(*defect),
        static_cast<AbsorptionStatusV1>(*absorption_status),
        ExtendedNonnegativeV1{decoded_mean_status, std::move(exact_mean)},
        TemporalBudgetReportV1{
            static_cast<std::size_t>(*requested_horizon),
            static_cast<std::size_t>(*state_count),
            static_cast<std::size_t>(*row_atom_count),
            static_cast<std::size_t>(*iterations),
            std::move(maximum_states).value(),
            std::move(maximum_row_atoms).value(),
            std::move(maximum_iterations).value(),
            std::move(authored_maximum_iterations).value(),
            std::move(*absolute_tolerance), std::move(*relative_tolerance),
            *budget_stop == 1U},
        *finite_preserved == 1U, std::move(typed_diagnostics),
        std::move(potential_diagnostics)});
  }
  if (!reader.exhausted()) {
    return fail<C22MetricEnvelopeInspectionV1>(
        "c22.test_metric_envelope_malformed",
        "the C22 metric envelope has trailing bytes");
  }
  return Result<C22MetricEnvelopeInspectionV1>::success(
      C22MetricEnvelopeInspectionV1{
          std::move(*kind), std::move(digest).value(),
          std::move(exact_values), std::move(numerical_values),
          std::move(indices), *rectangular == 1U, *radians == 1U, *error,
          static_cast<std::size_t>(*completed),
          std::move(authored_frequencies), *certified == 1U,
          std::move(authored_tolerance),
          std::move(*probability_kernel_error), *conservative_radius,
          *whole_range == 1U, std::move(stopped_metric),
          std::move(killed_row_residuals), std::move(temporal_budget)});
}

Result<KilledKernel> C22FixtureAccess::construct_exact_killed_fixture(
    C22SyntheticSourceIdentityV1 identity,
    std::vector<C22SyntheticNodeV1> nodes,
    std::vector<C22SyntheticEntranceV1> entrance, SafeSet safe_set,
    AbsorptionMarks absorption_marks) {
  auto views = mint_exact_source(
      AuditedTemporalSourceKindV1::stationary_projection,
      InitialLawKindV1::stationary, std::move(identity), std::move(nodes),
      std::move(entrance), std::numeric_limits<std::size_t>::max(),
      std::numeric_limits<std::size_t>::max());
  if (!views) {
    return Result<KilledKernel>::failure(views.error());
  }
  if (!views.value().kernel.has_value()) {
    return fail<KilledKernel>(
        "c22.synthetic_killed_kernel_unavailable",
        "the synthetic exact source did not mint its kernel",
        DiagnosticCategory::internal);
  }
  return construct_killed_kernel(*views.value().kernel, safe_set,
                                 absorption_marks);
}

}  // namespace testing
#endif

}  // namespace mwperf
