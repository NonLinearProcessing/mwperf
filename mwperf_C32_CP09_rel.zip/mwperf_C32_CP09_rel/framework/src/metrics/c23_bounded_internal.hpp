#pragma once

#include <cstddef>

#include "mwperf/metrics/palm_fifo.hpp"

namespace mwperf::metrics::detail {

struct BoundedAdmissionPalmLawV1 final {
  AdmissionPalmLaw law;
  std::size_t actual_entrance_atoms;
};

struct BoundedFifoDelayLawV1 final {
  DelayLaw law;
  std::size_t actual_state_count;
  std::size_t actual_maximum_row_atoms;
};

// C27-only bounded carriers. Public F-C23-02/F-C23-05 remain unchanged for
// their catalog callers; analysis-v1 uses these paths so authored C03 grants
// are enforced before entrance and lifted-graph materialization.
[[nodiscard]] Result<BoundedAdmissionPalmLawV1>
construct_admission_palm_law_bounded(
    const StationaryMarkedEdge& edge, const ArrivalCountMark& mark,
    std::size_t maximum_entrance_atoms);

[[nodiscard]] Result<BoundedFifoDelayLawV1>
evaluate_fifo_delay_distribution_bounded(
    const TagInitialLaw& initial_law,
    const TemporalServiceKernel& service_kernel,
    const HorizonSpec& horizon, const SolverPolicy& policy,
    std::size_t maximum_states, std::size_t maximum_row_atoms);

}  // namespace mwperf::metrics::detail
