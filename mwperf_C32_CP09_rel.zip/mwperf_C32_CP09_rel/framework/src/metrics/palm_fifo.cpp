#include "mwperf/metrics/palm_fifo.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <iterator>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

#include "metrics/c23_bounded_internal.hpp"
#include "stationary/c21_projection_source_internal.hpp"
#include "temporal/c20_stationary_bridge_internal.hpp"
#include "temporal/temporal_contract_internal.hpp"

namespace mwperf::metrics::detail {

struct PalmLawCore final {
  ExactRational exact_event_intensity;
  PalmNumericalDiagnosticsV1 diagnostics;
  std::vector<PalmAtomV1> atoms;
  std::string event_type_id;
  std::string label_schema_id;
  Digest256 projection_fingerprint;
  Digest256 source_law_identity;
  Digest256 timing_identity;
  InitialLaw initial_law;
};

struct AdmissionRateCore final {
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      source;
  ExactRational exact_value;
  long double numerical_value;
  Digest256 projection_fingerprint;
  Digest256 fingerprint;
  std::size_t target_ordinal;
};

struct StationaryQueueLawCore final {
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      source;
  std::vector<StationaryQueueMassV1> atoms;
  ExtendedNonnegativeV1 mean_backlog;
  LabelledOccupancyEvidenceV1 labelled_evidence;
  Digest256 projection_fingerprint;
  Digest256 fingerprint;
  std::size_t target_ordinal;
};

struct AdmissionPalmLawCore final {
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      source;
  std::vector<AdmissionPalmAtomV1> atoms;
  AdmissionRate admission_rate;
  StationaryQueueLaw stationary_queue_law;
  PalmNumericalDiagnosticsV1 diagnostics;
  Digest256 projection_fingerprint;
  Digest256 marked_edge_identity;
  Digest256 timing_identity;
  std::size_t target_ordinal;
};

struct FifoAuthorizationGroupCore final {
  std::optional<PalmConditionV1> condition;
  std::vector<FifoDelayOutputV1> outputs;
};

struct TagInitialLawCore final {
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      source;
  std::shared_ptr<const stationary::detail::PredictiveServiceSplitCore> split;
  std::vector<TagInitialAtomV1> atoms;
  AdmissionRate admission_rate;
  StationaryQueueLaw stationary_queue_law;
  FifoTagAssumptionsV1 assumptions;
  std::vector<FifoAuthorizationGroupCore> authorization_groups;
  std::vector<FifoDelayOutputV1> authorized_outputs;
  std::optional<PalmConditionV1> conditioning;
  Digest256 projection_fingerprint;
  Digest256 entrance_identity;
  std::size_t target_ordinal;
};

struct DelayLawCore final {
  std::vector<DelayTailV1> tails;
  std::vector<DelayMassV1> finite_pmf;
  ExactRational unresolved_tail_mass;
  ExactRational proven_defective_mass;
  AbsorptionStatusV1 absorption_status;
  ExtendedNonnegativeV1 mean_sojourn;
  HorizonSpec horizon;
  DelayLawDiagnosticsV1 diagnostics;
  StoppedMetricBundle stopped_backend_result;
  AdmissionRate admission_rate;
  StationaryQueueLaw stationary_queue_law;
  std::vector<FifoDelayOutputV1> authorized_outputs;
  std::vector<DelayMomentV1> requested_moments;
  std::optional<PalmConditionV1> conditioning;
  bool unconditioned_all_admissions;
  Digest256 projection_fingerprint;
  Digest256 source_fingerprint;
  std::size_t target_ordinal;
};

}  // namespace mwperf::metrics::detail

namespace mwperf::detail {

class C23CoreAccess final {
 public:
  C23CoreAccess() = delete;

  [[nodiscard]] static const stationary::detail::StationaryTemporalLawCore&
  core(const StationaryTemporalLaw& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const stationary::detail::StationaryMarkedEdgeCore&
  core(const StationaryMarkedEdge& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const stationary::detail::PredictiveServiceSplitCore&
  core(const PredictiveServiceSplit& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const std::shared_ptr<const
      stationary::detail::PredictiveServiceSplitCore>&
  core_ptr(const PredictiveServiceSplit& value) noexcept {
    return value.core_;
  }
  [[nodiscard]] static const stationary::detail::TemporalServiceKernelCore&
  core(const TemporalServiceKernel& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::PalmLawCore& core(
      const PalmLaw& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::AdmissionRateCore& core(
      const AdmissionRate& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::StationaryQueueLawCore& core(
      const StationaryQueueLaw& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::AdmissionPalmLawCore& core(
      const AdmissionPalmLaw& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::TagInitialLawCore& core(
      const TagInitialLaw& value) noexcept {
    return *value.core_;
  }
  [[nodiscard]] static const metrics::detail::DelayLawCore& core(
      const DelayLaw& value) noexcept {
    return *value.core_;
  }

  [[nodiscard]] static PalmLaw palm_law(
      std::shared_ptr<const metrics::detail::PalmLawCore> core) {
    return PalmLaw(std::move(core));
  }
  [[nodiscard]] static AdmissionRate admission_rate(
      std::shared_ptr<const metrics::detail::AdmissionRateCore> core) {
    return AdmissionRate(std::move(core));
  }
  [[nodiscard]] static StationaryQueueLaw stationary_queue_law(
      std::shared_ptr<const metrics::detail::StationaryQueueLawCore> core) {
    return StationaryQueueLaw(std::move(core));
  }
  [[nodiscard]] static AdmissionPalmLaw admission_palm_law(
      std::shared_ptr<const metrics::detail::AdmissionPalmLawCore> core) {
    return AdmissionPalmLaw(std::move(core));
  }
  [[nodiscard]] static TagInitialLaw tag_initial_law(
      std::shared_ptr<const metrics::detail::TagInitialLawCore> core) {
    return TagInitialLaw(std::move(core));
  }
  [[nodiscard]] static DelayLaw delay_law(
      std::shared_ptr<const metrics::detail::DelayLawCore> core) {
    return DelayLaw(std::move(core));
  }
#if defined(MWPERF_C23_TEST_SEAMS)
  [[nodiscard]] static StationaryMarkedEdge stationary_marked_edge(
      std::shared_ptr<const
          stationary::detail::StationaryMarkedEdgeCore> core) {
    return StationaryMarkedEdge(std::move(core));
  }
  [[nodiscard]] static PredictiveServiceSplit predictive_service_split(
      std::shared_ptr<const
          stationary::detail::PredictiveServiceSplitCore> core) {
    return PredictiveServiceSplit(std::move(core));
  }
  [[nodiscard]] static TemporalServiceKernel temporal_service_kernel(
      std::shared_ptr<const
          stationary::detail::TemporalServiceKernelCore> core) {
    return TemporalServiceKernel(std::move(core));
  }
#endif
  [[nodiscard]] static InitialLaw initial_law(
      std::shared_ptr<const metrics::detail::InitialLawCore> core) {
    return InitialLaw(std::move(core));
  }
};

}  // namespace mwperf::detail

namespace mwperf {
namespace {

constexpr std::size_t kMaximumEnumeratedPalmLabels = 1U << 20U;
constexpr std::size_t kMaximumExactMomentOrder = 4096U;
constexpr std::size_t kMaximumExactMomentMatrixCells = 1U << 20U;
constexpr std::size_t kMaximumExactMomentArithmeticWork = 1U << 26U;
constexpr std::size_t kMaximumCoefficientFrontierStates = 1U << 18U;
constexpr std::size_t kMaximumCoefficientTransitionWork = 1U << 22U;
constexpr std::string_view kTagStateCodec =
    "mwperf.c23.passive_fifo_tag_state";
constexpr std::string_view kTagDepartureMark =
    "mwperf.c23.tagged_packet_departure";
constexpr std::string_view kTagDepartureCodec =
    "mwperf.c23.boolean_tag_departure";
constexpr std::string_view kTagDepartureType = "tagged_packet_departure";
constexpr std::string_view kTypedEntranceLabelCodec =
    "mwperf.c23.typed_label";
constexpr std::string_view kCounterfactualPermissionCodec =
    "mwperf.c23.counterfactual_permission";

struct CoefficientWorkBudgetV1 final {
  std::size_t maximum_frontier_states;
  std::size_t maximum_transition_work;
};

#if defined(MWPERF_C23_TEST_SEAMS)
thread_local std::optional<CoefficientWorkBudgetV1>
    g_next_coefficient_work_budget;
thread_local bool g_mismatch_next_coefficient_crosscheck{false};
thread_local std::vector<testing::C23ExecutionStageV1>
    g_fifo_execution_trace;
#endif

void begin_fifo_execution_trace() {
#if defined(MWPERF_C23_TEST_SEAMS)
  g_fifo_execution_trace.clear();
#endif
}

void trace_passive_tag_adapter_advance() {
#if defined(MWPERF_C23_TEST_SEAMS)
  g_fifo_execution_trace.push_back(
      testing::C23ExecutionStageV1::passive_tag_adapter_advance);
#endif
}

void trace_construct_killed_kernel() {
#if defined(MWPERF_C23_TEST_SEAMS)
  g_fifo_execution_trace.push_back(
      testing::C23ExecutionStageV1::construct_killed_kernel);
#endif
}

void trace_evaluate_hit_survival_absorption() {
#if defined(MWPERF_C23_TEST_SEAMS)
  g_fifo_execution_trace.push_back(
      testing::C23ExecutionStageV1::evaluate_hit_survival_absorption);
#endif
}

void trace_coefficient_backend() {
#if defined(MWPERF_C23_TEST_SEAMS)
  g_fifo_execution_trace.push_back(
      testing::C23ExecutionStageV1::coefficient_backend);
#endif
}

[[nodiscard]] CoefficientWorkBudgetV1 coefficient_work_budget() noexcept {
#if defined(MWPERF_C23_TEST_SEAMS)
  if (g_next_coefficient_work_budget.has_value()) {
    const CoefficientWorkBudgetV1 budget =
        *g_next_coefficient_work_budget;
    g_next_coefficient_work_budget.reset();
    return budget;
  }
#endif
  return CoefficientWorkBudgetV1{kMaximumCoefficientFrontierStates,
                                 kMaximumCoefficientTransitionWork};
}

[[nodiscard]] bool consume_coefficient_mismatch_override() noexcept {
#if defined(MWPERF_C23_TEST_SEAMS)
  const bool mismatch = g_mismatch_next_coefficient_crosscheck;
  g_mismatch_next_coefficient_crosscheck = false;
  return mismatch;
#else
  return false;
#endif
}

[[nodiscard]] bool consume_bounded_work(
    std::size_t& remaining,
    const std::initializer_list<std::size_t> factors) noexcept {
  std::size_t product = 1U;
  for (const std::size_t factor : factors) {
    if (factor == 0U) {
      return true;
    }
    if (product > remaining / factor) {
      return false;
    }
    product *= factor;
  }
  remaining -= product;
  return true;
}

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    const DiagnosticCategory category = DiagnosticCategory::input_validation,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

[[nodiscard]] Diagnostic diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::nullopt, std::move(notes)};
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

[[nodiscard]] bool same_source_owner(
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        left,
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        right) noexcept {
  return left && right && left.get() == right.get() &&
         !left.owner_before(right) && !right.owner_before(left);
}

[[nodiscard]] Result<std::size_t> bounded_size(
    const BigNat& value, const std::string_view role,
    const std::size_t implementation_limit =
        std::numeric_limits<std::size_t>::max()) {
  if (value.value() > BigInt(std::numeric_limits<std::size_t>::max())) {
    return fail<std::size_t>(
        "c23.finite_index_out_of_range",
        std::string(role) + " exceeds the host address space",
        DiagnosticCategory::resource_limit);
  }
  const std::size_t converted = value.value().convert_to<std::size_t>();
  if (converted > implementation_limit) {
    return fail<std::size_t>(
        "c23.enumeration_budget_exceeded",
        std::string(role) + " exceeds the C23 materialization budget",
        DiagnosticCategory::resource_limit,
        {"requested " + std::to_string(converted),
         "limit " + std::to_string(implementation_limit)});
  }
  return Result<std::size_t>::success(converted);
}

class CompensatedSum final {
 public:
  void add(const long double value) noexcept {
    const long double next = sum_ + value;
    correction_ += std::fabs(sum_) >= std::fabs(value)
                       ? (sum_ - next) + value
                       : (value - next) + sum_;
    sum_ = next;
  }
  [[nodiscard]] long double value() const noexcept {
    return sum_ + correction_;
  }
  [[nodiscard]] long double correction() const noexcept {
    return correction_;
  }

 private:
  long double sum_{0.0L};
  long double correction_{0.0L};
};

class CanonicalEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void frame(const std::span<const std::byte> value) {
    u64(static_cast<std::uint64_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void frame(const std::span<const std::uint8_t> value) {
    u64(static_cast<std::uint64_t>(value.size()));
    for (const std::uint8_t byte_value : value) {
      bytes_.push_back(static_cast<std::byte>(byte_value));
    }
  }
  void text(const std::string_view value) {
    frame(std::as_bytes(std::span(value.data(), value.size())));
  }
  void digest(const Digest256& value) { frame(value.bytes()); }
  void natural(const BigNat& value) {
    const auto bytes = value.canonical_magnitude_bytes();
    frame(std::span<const std::uint8_t>(bytes));
  }
  void rational(const ExactRational& value) {
    text(value.numerator_decimal());
    text(value.denominator_decimal());
  }
  [[nodiscard]] std::span<const std::byte> bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] Result<Digest256> fingerprint(
    const std::string_view domain, const CanonicalEncoder& encoder) {
  return sha256_domain_separated(domain, encoder.bytes());
}

[[nodiscard]] Result<ExactRational> natural_rational(const BigNat& value) {
  return ExactRational::make(value.value(), BigInt{1});
}

[[nodiscard]] bool finite_positive_image(const ExactRational& value) {
  const long double image = value.to_long_double();
  return value.is_positive() && std::isfinite(image) && image > 0.0L;
}

[[nodiscard]] const MetricRequirementClause* accepted_requirement_clause(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const ResolvedMetricContractV1& accepted) {
  const auto found = std::find_if(
      binding.accepted_requirements.clauses().begin(),
      binding.accepted_requirements.clauses().end(),
      [&](const MetricRequirementClause& candidate) {
        return candidate.origin.clause_id == accepted.clause_id;
      });
  return found == binding.accepted_requirements.clauses().end()
             ? nullptr
             : &*found;
}

[[nodiscard]] bool contract_selects_only_target(
    const ResolvedMetricContractV1& contract, const QueueId& target) {
  return contract.ordered_targets.size() == 1U &&
         contract.ordered_targets.front().queue_id == target;
}

[[nodiscard]] bool route_has_hypothesis(
    const MetricRouteAlternativeV1& route, const HypothesisKindV1 kind) {
  return std::any_of(
      route.hypotheses.begin(), route.hypotheses.end(),
      [&](const HypothesisRequirementV1& hypothesis) {
        return hypothesis.claim.kind == kind;
      });
}

[[nodiscard]] LabelledOccupancyEvidenceV1
accepted_labelled_occupancy_evidence(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const QueueId& target) {
  for (const ResolvedMetricContractV1& accepted :
       binding.accepted_metric_contracts) {
    if (!contract_selects_only_target(accepted, target)) {
      continue;
    }
    const MetricRequirementClause* clause =
        accepted_requirement_clause(binding, accepted);
    if (clause == nullptr) {
      continue;
    }
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.backend_route != accepted.backend_route ||
          route.access.runtime_access != accepted.runtime_access) {
        continue;
      }
      const bool lossless =
          route_has_hypothesis(route, HypothesisKindV1::lossless);
      const bool unit =
          route_has_hypothesis(route, HypothesisKindV1::unit_packets);
      // Section 12's labelled-occupancy premises are hypotheses, not a
      // converse consequence of stationarity plus eventual departure.
      const bool labelled =
          route_has_hypothesis(route, HypothesisKindV1::little_law);
      if (lossless && unit && labelled) {
        return LabelledOccupancyEvidenceV1{true, true, true, true, true,
                                           true};
      }
    }
  }
  return LabelledOccupancyEvidenceV1{false, false, false, false, false,
                                     false};
}

struct AcceptedFifoAuthorizationGroupV1 final {
  std::vector<FifoDelayOutputV1> outputs;
  std::optional<FifoConditionV1> condition;
};

struct AcceptedFifoAuthorizationV1 final {
  FifoTagAssumptionsV1 assumptions;
  std::vector<AcceptedFifoAuthorizationGroupV1> groups;
};

[[nodiscard]] Result<AcceptedFifoAuthorizationV1>
accepted_fifo_authorization(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const QueueId& target, const bool predictive) {
  std::optional<FifoTagAssumptionsV1> assumptions;
  std::vector<AcceptedFifoAuthorizationGroupV1> groups;
  for (const ResolvedMetricContractV1& accepted :
       binding.accepted_metric_contracts) {
    if (accepted.backend_route != BackendRouteKindV1::palm_or_fifo_law ||
        !contract_selects_only_target(accepted, target)) {
      continue;
    }
    const MetricRequirementClause* clause =
        accepted_requirement_clause(binding, accepted);
    if (clause == nullptr ||
        (clause->origin.kind != MetricKindV1::fifo_delay &&
         clause->origin.kind != MetricKindV1::fifo_delay_conditioned)) {
      continue;
    }
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.backend_route != accepted.backend_route ||
          route.access.runtime_access != accepted.runtime_access ||
          route.semantic.entrance !=
              EntranceLawRequirementV1::admission_palm ||
          !route.semantic.require_full_history_predictive_sufficiency) {
        continue;
      }
      FifoTagAssumptionsV1 candidate_assumptions{
          route_has_hypothesis(route, HypothesisKindV1::fifo),
          route_has_hypothesis(route, HypothesisKindV1::unit_packets),
          route_has_hypothesis(route, HypothesisKindV1::lossless), true,
          route_has_hypothesis(
              route, HypothesisKindV1::positive_finite_intensity),
          predictive, true};
      if (!candidate_assumptions.global_fifo ||
          !candidate_assumptions.unit_packets ||
          !candidate_assumptions.lossless ||
          !candidate_assumptions.finite_batches_almost_surely ||
          !candidate_assumptions.positive_finite_admission_intensity ||
          !candidate_assumptions.full_history_predictive_service ||
          !candidate_assumptions.passive_tag) {
        continue;
      }
      FifoDelayOutputV1 candidate_output =
          FifoDelayPmfOutputV1{BigNat{0U}};
      std::optional<FifoConditionV1> candidate_condition;
      if (clause->origin.kind == MetricKindV1::fifo_delay) {
        candidate_output =
            std::get<FifoDelayParametersV1>(clause->origin.parameters)
                .output;
      } else {
        const auto& parameters =
            std::get<FifoDelayConditionedParametersV1>(
                clause->origin.parameters);
        candidate_output = parameters.output;
        candidate_condition = parameters.condition;
      }
      if (!assumptions.has_value()) {
        assumptions = candidate_assumptions;
      }
      auto group = std::find_if(
          groups.begin(), groups.end(),
          [&](const AcceptedFifoAuthorizationGroupV1& existing) {
            return existing.condition == candidate_condition;
          });
      if (group == groups.end()) {
        groups.push_back(AcceptedFifoAuthorizationGroupV1{
            {}, std::move(candidate_condition)});
        group = std::prev(groups.end());
      }
      const auto duplicate = std::find(
          group->outputs.begin(), group->outputs.end(),
          candidate_output);
      if (duplicate == group->outputs.end()) {
        group->outputs.push_back(std::move(candidate_output));
      }
    }
  }
  if (!assumptions.has_value() || groups.empty()) {
    return fail<AcceptedFifoAuthorizationV1>(
        "c23.fifo_route_unavailable",
        "no accepted scalar FIFO route for the selected target retains an "
        "admission-Palm entrance and full-history predictive continuation",
        DiagnosticCategory::unavailable);
  }
  return Result<AcceptedFifoAuthorizationV1>::success(
      AcceptedFifoAuthorizationV1{*assumptions, std::move(groups)});
}

[[nodiscard]] std::optional<std::size_t> event_target_ordinal(
    const EventIndicator& indicator);

[[nodiscard]] bool has_accepted_event_palm_route(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const EventIndicator& indicator) {
  const std::optional<std::size_t> target_ordinal =
      event_target_ordinal(indicator);
  const bool packet_count_entrance =
      std::holds_alternative<TargetArrivalEventCountV1>(
          indicator.count_rule);
  for (const ResolvedMetricContractV1& accepted :
       binding.accepted_metric_contracts) {
    const MetricRequirementClause* clause =
        accepted_requirement_clause(binding, accepted);
    if (clause == nullptr ||
        (target_ordinal.has_value() &&
         (*target_ordinal >= binding.target_selection.ordered_targets.size() ||
          !contract_selects_only_target(
              accepted, binding.target_selection
                            .ordered_targets[*target_ordinal])))) {
      continue;
    }
    bool matching_event = false;
    if (std::holds_alternative<TargetArrivalEventCountV1>(
            indicator.count_rule) &&
        target_ordinal.has_value() &&
        (clause->origin.kind == MetricKindV1::fifo_delay ||
         clause->origin.kind == MetricKindV1::fifo_delay_conditioned)) {
      // Packet-count Palm tilting is the same admission-Palm entrance
      // negotiated by FIFO delay requests.  It is deliberately not treated
      // as the binary admission event used by an event-gap request.
      matching_event = true;
    } else if (clause->origin.kind ==
                   MetricKindV1::event_gap_distribution &&
        target_ordinal.has_value()) {
      const GapEventKind expected =
          std::get<EventGapDistributionParametersV1>(
              clause->origin.parameters)
              .event;
      matching_event = std::visit(
          [&](const auto& count) {
            using Count = std::decay_t<decltype(count)>;
            if constexpr (!std::is_same_v<Count, BinaryEventCountV1>) {
              return false;
            } else {
              return std::visit(
                  [&](const auto& predicate) {
                    using Predicate = std::decay_t<decltype(predicate)>;
                    if constexpr (std::is_same_v<
                                      Predicate,
                                      TargetDeparturePredicateV1>) {
                      return expected == GapEventKind::departure &&
                             predicate.value &&
                             predicate.target_ordinal == *target_ordinal;
                    } else if constexpr (std::is_same_v<
                                             Predicate,
                                             PositiveTargetArrivalPredicateV1>) {
                      return expected == GapEventKind::admission &&
                             predicate.target_ordinal == *target_ordinal;
                    } else if constexpr (std::is_same_v<
                                             Predicate,
                                             BusyDenialEdgePredicateV1>) {
                      return expected == GapEventKind::busy_denial &&
                             predicate.target_ordinal == *target_ordinal;
                    }
                    return false;
                  },
                  count.predicate);
            }
          },
          indicator.count_rule);
    } else if (clause->origin.kind ==
               MetricKindV1::counterfactual_opportunity_gap) {
      const auto* binary =
          std::get_if<BinaryEventCountV1>(&indicator.count_rule);
      const auto* exact =
          binary == nullptr
              ? nullptr
              : std::get_if<ExactRuntimeMarkPredicateV1>(
                    &binary->predicate);
      if (exact != nullptr &&
          exact->codec ==
              CodecIdentityV1{std::string(kCounterfactualPermissionCodec),
                              1U} &&
          exact->canonical_value == std::vector<std::byte>{std::byte{1}}) {
        const auto descriptor = std::find_if(
            binding.retained_mark_schema.begin(),
            binding.retained_mark_schema.end(),
            [&](const RuntimeMarkDescriptorV1& candidate) {
              return candidate.c14_mark.kind ==
                         MetricMarkKindV1::counterfactual_permission &&
                     candidate.id == exact->mark_id &&
                     candidate.c14_mark.codec == exact->codec;
            });
        matching_event =
            descriptor != binding.retained_mark_schema.end() &&
            std::count_if(
                binding.retained_mark_schema.begin(),
                binding.retained_mark_schema.end(),
                [](const RuntimeMarkDescriptorV1& candidate) {
                  return candidate.c14_mark.kind ==
                         MetricMarkKindV1::counterfactual_permission;
                }) == 1;
      }
    }
    if (!matching_event) {
      continue;
    }
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      const EntranceLawRequirementV1 required_entrance =
          packet_count_entrance
              ? EntranceLawRequirementV1::admission_palm
              : EntranceLawRequirementV1::event_palm;
      const HypothesisKindV1 required_intensity =
          packet_count_entrance
              ? HypothesisKindV1::positive_finite_intensity
              : HypothesisKindV1::positive_event_intensity;
      if (route.access.backend_route == accepted.backend_route &&
          route.access.runtime_access == accepted.runtime_access &&
          route.semantic.entrance == required_entrance &&
          route_has_hypothesis(route, required_intensity)) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] bool has_accepted_admission_palm_route(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const QueueId& target) {
  for (const ResolvedMetricContractV1& accepted :
       binding.accepted_metric_contracts) {
    if (accepted.backend_route != BackendRouteKindV1::palm_or_fifo_law ||
        !contract_selects_only_target(accepted, target)) {
      continue;
    }
    const MetricRequirementClause* clause =
        accepted_requirement_clause(binding, accepted);
    if (clause == nullptr) {
      continue;
    }
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.backend_route == accepted.backend_route &&
          route.access.runtime_access == accepted.runtime_access &&
          route.semantic.entrance ==
              EntranceLawRequirementV1::admission_palm) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] std::optional<std::size_t> event_target_ordinal(
    const EventIndicator& indicator) {
  return std::visit(
      [](const auto& count) -> std::optional<std::size_t> {
        using Count = std::decay_t<decltype(count)>;
        if constexpr (std::is_same_v<Count, TargetArrivalEventCountV1>) {
          return count.target_ordinal;
        } else {
          return std::visit(
              [](const auto& predicate) -> std::optional<std::size_t> {
                using Predicate = std::decay_t<decltype(predicate)>;
                if constexpr (std::is_same_v<Predicate,
                                             TargetDeparturePredicateV1> ||
                              std::is_same_v<Predicate,
                                             PositiveTargetArrivalPredicateV1> ||
                              std::is_same_v<Predicate,
                                             BusyDenialEdgePredicateV1>) {
                  return predicate.target_ordinal;
                }
                return std::nullopt;
              },
              count.predicate);
        }
      },
      indicator.count_rule);
}

[[nodiscard]] Result<PalmConditionV1> resolve_fifo_condition(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const FifoConditionV1& condition) {
  return std::visit(
      [&](const auto& typed) -> Result<PalmConditionV1> {
        using Condition = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<Condition, FifoRankConditionV1>) {
          return Result<PalmConditionV1>::success(
              PalmConditionV1{RankPalmConditionV1{typed.one_based_rank}});
        } else if constexpr (std::is_same_v<Condition,
                                            FifoBatchConditionV1>) {
          return Result<PalmConditionV1>::success(
              PalmConditionV1{BatchPalmConditionV1{typed.batch_size}});
        } else {
          constexpr MetricMarkKindV1 kind =
              std::is_same_v<Condition, FifoClassConditionV1>
                  ? MetricMarkKindV1::class_label
                  : MetricMarkKindV1::phase_label;
          const auto descriptor = std::find_if(
              binding.retained_mark_schema.begin(),
              binding.retained_mark_schema.end(),
              [kind](const RuntimeMarkDescriptorV1& candidate) {
                return candidate.c14_mark.kind == kind &&
                       candidate.c14_mark.reveal_stage ==
                           MetricRevealStageV1::entrance_label;
              });
          if (descriptor == binding.retained_mark_schema.end() ||
              std::find_if(std::next(descriptor),
                           binding.retained_mark_schema.end(),
                           [kind](const RuntimeMarkDescriptorV1& candidate) {
                             return candidate.c14_mark.kind == kind &&
                                    candidate.c14_mark.reveal_stage ==
                                        MetricRevealStageV1::entrance_label;
                           }) != binding.retained_mark_schema.end()) {
            return fail<PalmConditionV1>(
                "c23.fifo_condition_mark_unavailable",
                "the accepted class/phase condition does not resolve to "
                "one retained entrance-label mark",
                DiagnosticCategory::unavailable);
          }
          if (descriptor->c14_mark.codec.id != kTypedEntranceLabelCodec ||
              descriptor->c14_mark.codec.version != 1U) {
            return fail<PalmConditionV1>(
                "c23.fifo_condition_label_codec_unavailable",
                "class/phase conditioning requires the canonical C23 "
                "typed-label entrance codec; an arbitrary provider codec "
                "cannot be guessed from its bytes",
                DiagnosticCategory::unavailable);
          }
          const TypedLabel& label = [&]() -> const TypedLabel& {
            if constexpr (std::is_same_v<Condition,
                                         FifoClassConditionV1>) {
              return typed.class_id;
            } else {
              return typed.phase_id;
            }
          }();
          const std::vector<std::uint8_t> encoded = label.canonical_bytes();
          std::vector<std::byte> canonical_value;
          canonical_value.reserve(encoded.size());
          for (const std::uint8_t value : encoded) {
            canonical_value.push_back(static_cast<std::byte>(value));
          }
          return Result<PalmConditionV1>::success(PalmConditionV1{
              RetainedMarkPalmConditionV1{
                  descriptor->id, descriptor->c14_mark.codec,
                  std::move(canonical_value)}});
        }
      },
      condition);
}

[[nodiscard]] Result<TagInitialLaw> condition_tag_initial_law_impl(
    const TagInitialLaw& law, const PalmConditionV1& condition);

[[nodiscard]] Result<bool> matches_event_predicate(
    const TemporalEdgePredicateV1& predicate, const MarkedFluxEdgeV1& edge) {
  return std::visit(
      [&](const auto& typed) -> Result<bool> {
        using T = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<T, AnyEdgePredicateV1>) {
          return Result<bool>::success(true);
        } else if constexpr (std::is_same_v<T,
                                            TargetDeparturePredicateV1>) {
          if (typed.target_ordinal >= edge.target_departures.size()) {
            return fail<bool>("c23.event_departure_mark_missing",
                              "the binary event requests an absent target "
                              "departure mark",
                              DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              (edge.target_departures[typed.target_ordinal] != 0U) ==
              typed.value);
        } else if constexpr (std::is_same_v<
                                 T, PositiveTargetArrivalPredicateV1>) {
          if (typed.target_ordinal >= edge.target_arrivals.size()) {
            return fail<bool>("c23.event_arrival_mark_missing",
                              "the binary event requests an absent target "
                              "arrival mark",
                              DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              !edge.target_arrivals[typed.target_ordinal].is_zero());
        } else if constexpr (std::is_same_v<T,
                                            BusyDenialEdgePredicateV1>) {
          if (typed.target_ordinal >= edge.target_departures.size() ||
              typed.target_ordinal >=
                  edge.prearrival_target_backlog.size()) {
            return fail<bool>("c23.event_busy_denial_marks_missing",
                              "busy denial requires retained backlog and "
                              "actual departure marks",
                              DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              !edge.prearrival_target_backlog[typed.target_ordinal].is_zero() &&
              edge.target_departures[typed.target_ordinal] == 0U);
        } else {
          const CausalMarkV1* retained = nullptr;
          std::size_t matches = 0U;
          for (const CausalMarkV1& mark : edge.marks) {
            if (mark.mark.mark == typed.mark_id) {
              retained = &mark;
              ++matches;
            }
          }
          if (matches == 0U) {
            return fail<bool>("c23.event_runtime_mark_missing",
                              "the binary event requests an absent retained "
                              "runtime mark",
                              DiagnosticCategory::unavailable);
          }
          if (matches != 1U) {
            return fail<bool>("c23.event_runtime_mark_duplicate",
                              "the stationary edge retains duplicate event "
                              "runtime marks",
                              DiagnosticCategory::internal);
          }
          if (!(retained->mark.value.codec == typed.codec)) {
            return fail<bool>("c23.event_runtime_mark_codec_mismatch",
                              "the event runtime mark codec does not match "
                              "the retained mark",
                              DiagnosticCategory::unavailable);
          }
          return Result<bool>::success(
              retained->mark.value.canonical_value == typed.canonical_value);
        }
      },
      predicate);
}

[[nodiscard]] Result<RuntimeMarkIdV1> tag_departure_mark_id() {
  auto label = TypedLabel::text(std::string(kTagDepartureMark));
  if (!label) {
    return Result<RuntimeMarkIdV1>::failure(label.error());
  }
  return Result<RuntimeMarkIdV1>::success(
      RuntimeMarkIdV1(std::move(label).value()));
}

[[nodiscard]] ReducedStateV1 tagged_state_value(const std::size_t base_index,
                                                const BigNat& predecessors,
                                                const bool departed) {
  CanonicalEncoder encoder;
  encoder.byte(departed ? 1U : 0U);
  encoder.u64(static_cast<std::uint64_t>(base_index));
  encoder.natural(predecessors);
  return ReducedStateV1{
      CodecIdentityV1{std::string(kTagStateCodec), 1U},
      std::vector<std::byte>(encoder.bytes().begin(), encoder.bytes().end())};
}

[[nodiscard]] CausalMarkV1 tag_departure_mark(
    const RuntimeMarkIdV1& id, const bool departed) {
  return CausalMarkV1{
      RuntimeDecodedMarkV1{
          id,
          CanonicalRuntimeValueV1{
              CodecIdentityV1{std::string(kTagDepartureCodec), 1U},
              {departed ? std::byte{1} : std::byte{0}}}},
      CausalStageV1::psi};
}

[[nodiscard]] Result<Digest256> tagged_source_fingerprint(
    const metrics::detail::TagInitialLawCore& initial,
    const stationary::detail::TemporalServiceKernelCore& service) {
  CanonicalEncoder encoder;
  encoder.digest(initial.projection_fingerprint);
  encoder.digest(initial.entrance_identity);
  encoder.digest(service.continuation_schema_identity);
  encoder.digest(service.target_selection_identity);
  encoder.digest(service.target_service_schema_identity);
  encoder.u64(static_cast<std::uint64_t>(initial.target_ordinal));
  for (const TagInitialAtomV1& atom : initial.atoms) {
    encoder.u64(static_cast<std::uint64_t>(atom.continuation_index));
    encoder.natural(atom.state.predecessors);
    encoder.rational(atom.exact_mass);
  }
  return fingerprint("mwperf.c23.passive_fifo_source.v1", encoder);
}

}  // namespace

const ExactRational& PalmLaw::exact_event_intensity() const noexcept {
  return core_->exact_event_intensity;
}
const PalmNumericalDiagnosticsV1& PalmLaw::diagnostics() const noexcept {
  return core_->diagnostics;
}
std::span<const PalmAtomV1> PalmLaw::atoms() const noexcept {
  return core_->atoms;
}
const std::string& PalmLaw::event_type_id() const noexcept {
  return core_->event_type_id;
}
const std::string& PalmLaw::label_schema_id() const noexcept {
  return core_->label_schema_id;
}
const Digest256& PalmLaw::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& PalmLaw::source_law_identity() const noexcept {
  return core_->source_law_identity;
}
const Digest256& PalmLaw::timing_identity() const noexcept {
  return core_->timing_identity;
}
const InitialLaw& PalmLaw::initial_law() const noexcept {
  return core_->initial_law;
}

const ExactRational& AdmissionRate::exact_value() const noexcept {
  return core_->exact_value;
}
long double AdmissionRate::numerical_value() const noexcept {
  return core_->numerical_value;
}
const Digest256& AdmissionRate::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& AdmissionRate::fingerprint() const noexcept {
  return core_->fingerprint;
}
std::size_t AdmissionRate::target_ordinal() const noexcept {
  return core_->target_ordinal;
}

std::span<const StationaryQueueMassV1> StationaryQueueLaw::atoms() const
    noexcept {
  return core_->atoms;
}
const ExtendedNonnegativeV1& StationaryQueueLaw::mean_backlog() const
    noexcept {
  return core_->mean_backlog;
}
const LabelledOccupancyEvidenceV1&
StationaryQueueLaw::labelled_evidence() const noexcept {
  return core_->labelled_evidence;
}
const Digest256& StationaryQueueLaw::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& StationaryQueueLaw::fingerprint() const noexcept {
  return core_->fingerprint;
}
std::size_t StationaryQueueLaw::target_ordinal() const noexcept {
  return core_->target_ordinal;
}

std::span<const AdmissionPalmAtomV1> AdmissionPalmLaw::atoms() const noexcept {
  return core_->atoms;
}
const AdmissionRate& AdmissionPalmLaw::admission_rate() const noexcept {
  return core_->admission_rate;
}
const StationaryQueueLaw& AdmissionPalmLaw::stationary_queue_law() const
    noexcept {
  return core_->stationary_queue_law;
}
const PalmNumericalDiagnosticsV1& AdmissionPalmLaw::diagnostics() const
    noexcept {
  return core_->diagnostics;
}
const Digest256& AdmissionPalmLaw::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& AdmissionPalmLaw::marked_edge_identity() const noexcept {
  return core_->marked_edge_identity;
}
const Digest256& AdmissionPalmLaw::timing_identity() const noexcept {
  return core_->timing_identity;
}
std::size_t AdmissionPalmLaw::target_ordinal() const noexcept {
  return core_->target_ordinal;
}

std::span<const TagInitialAtomV1> TagInitialLaw::atoms() const noexcept {
  return core_->atoms;
}
const AdmissionRate& TagInitialLaw::admission_rate() const noexcept {
  return core_->admission_rate;
}
const StationaryQueueLaw& TagInitialLaw::stationary_queue_law() const
    noexcept {
  return core_->stationary_queue_law;
}
const FifoTagAssumptionsV1& TagInitialLaw::assumptions() const noexcept {
  return core_->assumptions;
}
const std::optional<PalmConditionV1>& TagInitialLaw::conditioning() const
    noexcept {
  return core_->conditioning;
}
bool TagInitialLaw::is_unconditioned_all_admissions() const noexcept {
  return !core_->conditioning.has_value();
}
const Digest256& TagInitialLaw::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& TagInitialLaw::entrance_identity() const noexcept {
  return core_->entrance_identity;
}
std::size_t TagInitialLaw::target_ordinal() const noexcept {
  return core_->target_ordinal;
}

std::span<const DelayTailV1> DelayLaw::tails() const noexcept {
  return core_->tails;
}
std::span<const DelayMassV1> DelayLaw::finite_pmf() const noexcept {
  return core_->finite_pmf;
}
const ExactRational& DelayLaw::unresolved_tail_mass() const noexcept {
  return core_->unresolved_tail_mass;
}
const ExactRational& DelayLaw::proven_defective_mass() const noexcept {
  return core_->proven_defective_mass;
}
AbsorptionStatusV1 DelayLaw::absorption_status() const noexcept {
  return core_->absorption_status;
}
const ExtendedNonnegativeV1& DelayLaw::mean_sojourn() const noexcept {
  return core_->mean_sojourn;
}
const HorizonSpec& DelayLaw::horizon() const noexcept {
  return core_->horizon;
}
const DelayLawDiagnosticsV1& DelayLaw::diagnostics() const noexcept {
  return core_->diagnostics;
}
const StoppedMetricBundle& DelayLaw::stopped_backend_result() const noexcept {
  return core_->stopped_backend_result;
}
const AdmissionRate& DelayLaw::admission_rate() const noexcept {
  return core_->admission_rate;
}
const StationaryQueueLaw& DelayLaw::stationary_queue_law() const noexcept {
  return core_->stationary_queue_law;
}
const std::optional<PalmConditionV1>& DelayLaw::conditioning() const noexcept {
  return core_->conditioning;
}
bool DelayLaw::is_unconditioned_all_admissions() const noexcept {
  return core_->unconditioned_all_admissions;
}
const Digest256& DelayLaw::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& DelayLaw::source_fingerprint() const noexcept {
  return core_->source_fingerprint;
}
std::size_t DelayLaw::target_ordinal() const noexcept {
  return core_->target_ordinal;
}

Result<DelayQuantileV1> DelayLaw::quantile(
    const ExactRational& probability) const {
  if (!probability.is_positive() || probability > ExactRational::one()) {
    return fail<DelayQuantileV1>(
        "c23.invalid_delay_quantile_probability",
        "a delay quantile probability must lie in the exact interval (0,1]");
  }
  const bool authorized = std::any_of(
      core_->authorized_outputs.begin(), core_->authorized_outputs.end(),
      [&](const FifoDelayOutputV1& output) {
        const auto* quantile =
            std::get_if<FifoDelayQuantileOutputV1>(&output);
        return quantile != nullptr && quantile->probability == probability;
      });
  if (!authorized) {
    return fail<DelayQuantileV1>(
        "c23.fifo_quantile_not_authorized",
        "the requested quantile does not match the accepted C14 FIFO "
        "output",
        DiagnosticCategory::unavailable);
  }
  ExactRational cumulative = ExactRational::zero();
  for (const DelayMassV1& atom : core_->finite_pmf) {
    const ExactRational below = cumulative;
    cumulative = cumulative + atom.exact_probability;
    if (cumulative >= probability) {
      return Result<DelayQuantileV1>::success(DelayQuantileV1{
          DelayQuantileStatusV1::established, probability,
          atom.sojourn_slots, below, cumulative});
    }
  }
  if (core_->absorption_status == AbsorptionStatusV1::defective) {
    const ExactRational attainable =
        ExactRational::one() - core_->proven_defective_mass;
    if (probability > attainable) {
      return Result<DelayQuantileV1>::success(DelayQuantileV1{
          DelayQuantileStatusV1::beyond_defective_mass, probability,
          std::nullopt, cumulative, attainable});
    }
  }
  const ExactRational established_cdf =
      ExactRational::one() - core_->unresolved_tail_mass -
      core_->proven_defective_mass;
  return Result<DelayQuantileV1>::success(DelayQuantileV1{
      DelayQuantileStatusV1::unresolved_horizon, probability, std::nullopt,
      cumulative, established_cdf});
}

Result<DelayMomentV1> DelayLaw::moment(const BigNat& order) const {
  if (order.is_zero()) {
    return fail<DelayMomentV1>("c23.invalid_delay_moment_order",
                               "a FIFO delay moment order must be positive");
  }
  const bool authorized = std::any_of(
      core_->authorized_outputs.begin(), core_->authorized_outputs.end(),
      [&](const FifoDelayOutputV1& output) {
        const auto* moment = std::get_if<FifoDelayMomentOutputV1>(&output);
        return moment != nullptr && moment->order == order;
      });
  if (!authorized) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_not_authorized",
        "the requested moment does not match the accepted C14 FIFO output",
        DiagnosticCategory::unavailable);
  }
  const auto evaluated = std::find_if(
      core_->requested_moments.begin(), core_->requested_moments.end(),
      [&](const DelayMomentV1& moment) { return moment.order == order; });
  if (evaluated == core_->requested_moments.end()) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_result_unavailable",
        "the exact requested FIFO moment was not retained by its stopped "
        "evaluation",
        DiagnosticCategory::internal);
  }
  return Result<DelayMomentV1>::success(*evaluated);
}

Result<PalmLaw> construct_event_palm_law(
    const StationaryTemporalLaw& law, const EventIndicator& indicator) {
  try {
    if (indicator.event_type_id.empty() || indicator.label_schema_id.empty()) {
      return fail<PalmLaw>("c23.invalid_event_palm_schema",
                           "event Palm type and label-schema identifiers "
                           "must be nonempty");
    }
    const auto& law_core = detail::C23CoreAccess::core(law);
    if (!law_core.source || !law_core.source->temporal_source ||
        law_core.projection_fingerprint != law_core.source->fingerprint ||
        !nonzero_digest(law_core.source->fingerprint)) {
      return fail<PalmLaw>("c23.event_palm_source_binding_mismatch",
                           "event Palm construction requires one live exact "
                           "C21 stationary temporal source");
    }
    const auto& source = *law_core.source;
    const auto& temporal = *source.temporal_source;
    if (!has_accepted_event_palm_route(source.provider_binding, indicator)) {
      return fail<PalmLaw>(
          "c23.event_palm_route_unavailable",
          "the originating C21 projection has no accepted target-matching "
          "event-Palm route",
          DiagnosticCategory::unavailable);
    }
    if (source.atoms.size() != temporal.nodes.size() ||
        source.provider_binding.timing !=
            TimingConvention::early_service_late_admission) {
      return fail<PalmLaw>("c23.event_palm_temporal_shape_mismatch",
                           "the C21 source does not retain one chronological "
                           "node per stationary slot atom under the required "
                           "timing convention",
                           DiagnosticCategory::unavailable);
    }

    std::vector<std::size_t> counts(source.atoms.size(), 0U);
    ExactRational intensity = ExactRational::zero();
    CompensatedSum numerical_intensity;
    std::size_t label_count = 0U;
    std::size_t materialized_atom_count = 0U;
    for (std::size_t index = 0U; index < source.atoms.size(); ++index) {
      const auto& atom = source.atoms[index];
      std::size_t count = 0U;
      auto resolved = std::visit(
          [&](const auto& rule) -> Result<std::size_t> {
            using T = std::decay_t<decltype(rule)>;
            if constexpr (std::is_same_v<T, BinaryEventCountV1>) {
              auto matches = matches_event_predicate(rule.predicate,
                                                     atom.reward_edge);
              if (!matches) {
                return Result<std::size_t>::failure(matches.error());
              }
              return Result<std::size_t>::success(matches.value() ? 1U : 0U);
            } else {
              if (rule.target_ordinal >=
                  atom.reward_edge.target_arrivals.size()) {
                return fail<std::size_t>(
                    "c23.event_count_target_not_retained",
                    "the event-count rule requests an absent target arrival "
                    "coordinate",
                    DiagnosticCategory::unavailable);
              }
              return bounded_size(atom.reward_edge.target_arrivals[
                                      rule.target_ordinal],
                                  "an event Palm label count",
                                  kMaximumEnumeratedPalmLabels);
            }
          },
          indicator.count_rule);
      if (!resolved) {
        return Result<PalmLaw>::failure(resolved.error());
      }
      count = resolved.value();
      if (count > kMaximumEnumeratedPalmLabels - label_count) {
        return fail<PalmLaw>("c23.event_palm_label_budget_exceeded",
                             "the total event-label enumeration exceeds the "
                             "C23 materialization budget",
                             DiagnosticCategory::resource_limit);
      }
      label_count += count;
      const std::size_t successor_count =
          temporal.nodes[index].transitions.size();
      if (successor_count != 0U &&
          count > kMaximumEnumeratedPalmLabels / successor_count) {
        return fail<PalmLaw>(
            "c23.event_palm_atom_budget_exceeded",
            "the event-label and chronological-successor product exceeds "
            "the C23 materialization budget",
            DiagnosticCategory::resource_limit);
      }
      const std::size_t expanded_count = count * successor_count;
      if (expanded_count >
          kMaximumEnumeratedPalmLabels - materialized_atom_count) {
        return fail<PalmLaw>(
            "c23.event_palm_atom_budget_exceeded",
            "the expanded event-Palm entrance exceeds the C23 "
            "materialization budget",
            DiagnosticCategory::resource_limit);
      }
      materialized_atom_count += expanded_count;
      counts[index] = count;
      auto count_rational = ExactRational::make(BigInt(count), BigInt{1});
      if (!count_rational) {
        return Result<PalmLaw>::failure(count_rational.error());
      }
      const ExactRational intensity_term =
          atom.exact_mass * count_rational.value();
      intensity = intensity + intensity_term;
      numerical_intensity.add(intensity_term.to_long_double());
    }
    if (!intensity.is_positive()) {
      return fail<PalmLaw>("c23.event_palm_zero_intensity",
                           "a Palm law is unavailable for a zero-intensity "
                           "event",
                           DiagnosticCategory::unavailable);
    }
    if (!finite_positive_image(intensity) ||
        !std::isfinite(numerical_intensity.value()) ||
        numerical_intensity.value() <= 0.0L) {
      return fail<PalmLaw>("c23.event_palm_intensity_numerically_unresolved",
                           "the positive exact event intensity has no "
                           "certifiable finite positive long-double image",
                           DiagnosticCategory::unavailable);
    }

    std::vector<PalmAtomV1> atoms;
    std::vector<metrics::detail::TemporalEntranceAtomCore> entrance;
    atoms.reserve(materialized_atom_count);
    entrance.reserve(materialized_atom_count);
    CompensatedSum numerical_total;
    ExactRational exact_total = ExactRational::zero();
    for (std::size_t index = 0U; index < source.atoms.size(); ++index) {
      if (counts[index] == 0U) {
        continue;
      }
      for (const auto& transition : temporal.nodes[index].transitions) {
        auto mass = checked_divide(
            source.atoms[index].exact_mass * transition.exact_mass,
            intensity);
        if (!mass) {
          return Result<PalmLaw>::failure(mass.error());
        }
        const long double image = mass.value().to_long_double();
        if (!std::isfinite(image) || image <= 0.0L) {
          return fail<PalmLaw>(
              "c23.event_palm_atom_numerically_unresolved",
              "a positive exact event-Palm atom has no finite positive "
              "long-double image",
              DiagnosticCategory::unavailable);
        }
        for (std::size_t label = 1U; label <= counts[index]; ++label) {
          atoms.push_back(PalmAtomV1{
              transition.successor_index,
              temporal.nodes[transition.successor_index].decoded_state,
              BigNat{label}, mass.value(), image});
          entrance.push_back(metrics::detail::TemporalEntranceAtomCore{
              transition.successor_index,
              temporal.nodes[transition.successor_index].decoded_state,
              mass.value()});
          exact_total = exact_total + mass.value();
          numerical_total.add(image);
        }
      }
    }
    if (!(exact_total == ExactRational::one())) {
      return fail<PalmLaw>("c23.event_palm_exact_normalization_failure",
                           "labelled event-Palm masses do not sum exactly to "
                           "one",
                           DiagnosticCategory::internal,
                           {"mass " + exact_total.to_canonical_string()});
    }
    auto initial_core = std::make_shared<const metrics::detail::InitialLawCore>(
        metrics::detail::InitialLawCore{
            InitialLawKindV1::event_palm, source.temporal_source,
            std::move(entrance), source.fingerprint, source.fingerprint, true});
    InitialLaw initial =
        detail::C23CoreAccess::initial_law(std::move(initial_core));
    auto core = std::make_shared<const metrics::detail::PalmLawCore>(
        metrics::detail::PalmLawCore{
            intensity,
            PalmNumericalDiagnosticsV1{
                numerical_intensity.value(), numerical_intensity.correction(),
                numerical_total.value(), numerical_total.value() - 1.0L},
            std::move(atoms), indicator.event_type_id,
            indicator.label_schema_id, source.fingerprint, source.fingerprint,
            source.provider_binding.timing_identity, std::move(initial)});
    return Result<PalmLaw>::success(
        detail::C23CoreAccess::palm_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<PalmLaw>("c23.event_palm_allocation_failure",
                         "constructing the labelled event-Palm law exhausted "
                         "memory",
                         DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<PalmLaw>("c23.event_palm_exception",
                         "event-Palm construction raised an unexpected "
                         "exception",
                         DiagnosticCategory::internal);
  }
}

namespace {

[[nodiscard]] Result<AdmissionPalmLaw>
construct_admission_palm_law_impl(
    const StationaryMarkedEdge& edge, const ArrivalCountMark& mark,
    const std::optional<std::size_t> maximum_entrance_atoms,
    std::size_t* const actual_entrance_atoms) {
  try {
    if (mark.semantics !=
        AdmissionCountingSemanticsV1::retained_edge_packet_labels) {
      return fail<AdmissionPalmLaw>(
          "c23.invalid_admission_counting_semantics",
          "admission Palm construction requires one retained label per "
          "packet on the already-realized stationary edge; nonempty-slot "
          "conditioning and arrival redraws are not packet Palm laws");
    }
    const auto& edge_core = detail::C23CoreAccess::core(edge);
    if (!edge_core.source || !edge_core.source->temporal_source ||
        edge_core.projection_fingerprint != edge_core.source->fingerprint ||
        edge_core.source->provider_binding.timing !=
            TimingConvention::early_service_late_admission) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_palm_source_binding_mismatch",
          "admission Palm construction requires one exact C21 stationary "
          "marked-edge source under early-service/late-admission timing");
    }
    const auto& source = *edge_core.source;
    if (mark.target_ordinal >=
        source.provider_binding.target_selection.ordered_targets.size()) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_target_not_selected",
          "the admission count requests a target absent from the exact C21 "
          "target selection",
          DiagnosticCategory::unavailable);
    }
    if (!has_accepted_admission_palm_route(
            source.provider_binding,
            source.provider_binding.target_selection
                .ordered_targets[mark.target_ordinal])) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_palm_route_unavailable",
          "the originating C21 projection has no accepted target-matching "
          "admission-Palm route",
          DiagnosticCategory::unavailable);
    }

    ExactRational intensity = ExactRational::zero();
    CompensatedSum numerical_intensity;
    std::size_t total_labels = 0U;
    for (const auto& atom : source.atoms) {
      if (mark.target_ordinal >= atom.reward_edge.target_arrivals.size()) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_batch_mark_not_retained",
            "a stationary slot atom omits the selected target arrival batch",
            DiagnosticCategory::unavailable);
      }
      auto batch = bounded_size(
          atom.reward_edge.target_arrivals[mark.target_ordinal],
          "an admission batch", kMaximumEnumeratedPalmLabels);
      if (!batch) {
        return Result<AdmissionPalmLaw>::failure(batch.error());
      }
      if (batch.value() > kMaximumEnumeratedPalmLabels - total_labels) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_palm_label_budget_exceeded",
            "the total within-batch rank enumeration exceeds the C23 "
            "materialization budget",
            DiagnosticCategory::resource_limit);
      }
      total_labels += batch.value();
      auto batch_rational = natural_rational(
          atom.reward_edge.target_arrivals[mark.target_ordinal]);
      if (!batch_rational) {
        return Result<AdmissionPalmLaw>::failure(batch_rational.error());
      }
      const ExactRational intensity_term =
          atom.exact_mass * batch_rational.value();
      intensity = intensity + intensity_term;
      numerical_intensity.add(intensity_term.to_long_double());
    }
    if (maximum_entrance_atoms.has_value() &&
        total_labels > *maximum_entrance_atoms) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_palm_state_budget_exceeded",
          "the packet-Palm entrance exceeds the authored maximum_states grant before labelled-atom materialization",
          DiagnosticCategory::resource_limit);
    }
    if (!intensity.is_positive()) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_palm_zero_intensity",
          "the selected target has zero exact stationary admission "
          "intensity",
          DiagnosticCategory::unavailable);
    }
    if (!finite_positive_image(intensity) ||
        !std::isfinite(numerical_intensity.value()) ||
        numerical_intensity.value() <= 0.0L) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_intensity_numerically_unresolved",
          "the positive exact admission intensity has no certifiable finite "
          "positive long-double image",
          DiagnosticCategory::unavailable);
    }

    std::vector<StationaryQueueMassV1> queue_atoms;
    ExactRational exact_queue_mean = ExactRational::zero();
    for (const auto& atom : source.atoms) {
      if (mark.target_ordinal >=
          atom.reward_edge.prearrival_target_backlog.size()) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_backlog_mark_not_retained",
            "a stationary slot atom omits the selected predecision target "
            "backlog",
            DiagnosticCategory::unavailable);
      }
      const BigNat& backlog =
          atom.reward_edge.prearrival_target_backlog[mark.target_ordinal];
      auto present = std::find_if(
          queue_atoms.begin(), queue_atoms.end(),
          [&](const StationaryQueueMassV1& candidate) {
            return candidate.backlog == backlog;
          });
      if (present == queue_atoms.end()) {
        queue_atoms.push_back(StationaryQueueMassV1{
            backlog, atom.exact_mass, atom.exact_mass.to_long_double()});
      } else {
        present->exact_mass = present->exact_mass + atom.exact_mass;
        present->numerical_mass = present->exact_mass.to_long_double();
      }
      auto backlog_rational = natural_rational(backlog);
      if (!backlog_rational) {
        return Result<AdmissionPalmLaw>::failure(backlog_rational.error());
      }
      exact_queue_mean =
          exact_queue_mean + atom.exact_mass * backlog_rational.value();
    }
    std::sort(queue_atoms.begin(), queue_atoms.end(),
              [](const StationaryQueueMassV1& left,
                 const StationaryQueueMassV1& right) {
                return left.backlog < right.backlog;
              });

    CanonicalEncoder rate_encoder;
    rate_encoder.digest(source.fingerprint);
    rate_encoder.u64(static_cast<std::uint64_t>(mark.target_ordinal));
    rate_encoder.rational(intensity);
    auto rate_fingerprint =
        fingerprint("mwperf.c23.admission_rate.v1", rate_encoder);
    if (!rate_fingerprint) {
      return Result<AdmissionPalmLaw>::failure(rate_fingerprint.error());
    }
    CanonicalEncoder queue_encoder;
    queue_encoder.digest(source.fingerprint);
    queue_encoder.u64(static_cast<std::uint64_t>(mark.target_ordinal));
    for (const auto& atom : queue_atoms) {
      queue_encoder.natural(atom.backlog);
      queue_encoder.rational(atom.exact_mass);
    }
    auto queue_fingerprint =
        fingerprint("mwperf.c23.stationary_queue_law.v1", queue_encoder);
    if (!queue_fingerprint) {
      return Result<AdmissionPalmLaw>::failure(queue_fingerprint.error());
    }
    CanonicalEncoder edge_encoder;
    edge_encoder.digest(source.fingerprint);
    edge_encoder.u64(static_cast<std::uint64_t>(mark.target_ordinal));
    auto edge_identity =
        fingerprint("mwperf.c23.stationary_marked_edge.v1", edge_encoder);
    if (!edge_identity) {
      return Result<AdmissionPalmLaw>::failure(edge_identity.error());
    }

    const QueueId& target =
        source.provider_binding.target_selection
            .ordered_targets[mark.target_ordinal];
    // Only an accepted explicit labelled/Little witness supplies the
    // two-sided occupancy hypotheses.  Eventual departure alone is not the
    // converse of Proposition 12.4a.
    const LabelledOccupancyEvidenceV1 evidence =
        accepted_labelled_occupancy_evidence(source.provider_binding,
                                              target);

    auto rate_core =
        std::make_shared<const metrics::detail::AdmissionRateCore>(
            metrics::detail::AdmissionRateCore{
                edge_core.source, intensity, intensity.to_long_double(),
                source.fingerprint, rate_fingerprint.value(),
                mark.target_ordinal});
    AdmissionRate rate =
        detail::C23CoreAccess::admission_rate(std::move(rate_core));
    auto queue_core =
        std::make_shared<const metrics::detail::StationaryQueueLawCore>(
            metrics::detail::StationaryQueueLawCore{
                edge_core.source, std::move(queue_atoms),
                ExtendedNonnegativeV1{ExtendedNonnegativeStatusV1::finite,
                                      exact_queue_mean},
                evidence, source.fingerprint, queue_fingerprint.value(),
                mark.target_ordinal});
    StationaryQueueLaw queue =
        detail::C23CoreAccess::stationary_queue_law(std::move(queue_core));

    std::vector<AdmissionPalmAtomV1> palm_atoms;
    palm_atoms.reserve(total_labels);
    ExactRational exact_total = ExactRational::zero();
    CompensatedSum numerical_total;
    for (std::size_t index = 0U; index < source.atoms.size(); ++index) {
      const auto& atom = source.atoms[index];
      const MarkedFluxEdgeV1& reward = atom.reward_edge;
      const BigNat& batch = reward.target_arrivals[mark.target_ordinal];
      auto batch_size = bounded_size(batch, "an admission batch",
                                     kMaximumEnumeratedPalmLabels);
      if (!batch_size) {
        return Result<AdmissionPalmLaw>::failure(batch_size.error());
      }
      if (batch_size.value() == 0U) {
        continue;
      }
      if (mark.target_ordinal >= reward.target_departures.size()) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_departure_mark_not_retained",
            "a stationary slot atom omits the selected actual-departure mark",
            DiagnosticCategory::unavailable);
      }
      const std::uint8_t departure =
          reward.target_departures[mark.target_ordinal];
      if (departure > 1U) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_departure_not_binary",
            "unit-packet FIFO admission timing requires a binary actual "
            "departure mark");
      }
      const BigNat& backlog =
          reward.prearrival_target_backlog[mark.target_ordinal];
      auto after_service = checked_subtract(backlog, BigNat{departure});
      if (!after_service) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_departure_exceeds_backlog",
            "the retained actual departure exceeds the predecision backlog");
      }
      const BigNat first_eligible = after_service.value() + batch;
      auto per_label = checked_divide(atom.exact_mass, intensity);
      if (!per_label) {
        return Result<AdmissionPalmLaw>::failure(per_label.error());
      }
      const long double image = per_label.value().to_long_double();
      if (!std::isfinite(image) || image <= 0.0L) {
        return fail<AdmissionPalmLaw>(
            "c23.admission_palm_atom_numerically_unresolved",
            "a positive exact admission-Palm atom has no finite positive "
            "long-double image",
            DiagnosticCategory::unavailable);
      }
      for (std::size_t rank = 1U; rank <= batch_size.value(); ++rank) {
        const BigNat rank_value{rank};
        auto rank_minus_one = checked_subtract(rank_value, BigNat{1U});
        if (!rank_minus_one) {
          return Result<AdmissionPalmLaw>::failure(rank_minus_one.error());
        }
        const BigNat predecessors =
            after_service.value() + rank_minus_one.value();
        if (!(predecessors < first_eligible)) {
          return fail<AdmissionPalmLaw>(
              "c23.admission_rank_invariant_failure",
              "the exact entrance rank does not satisfy 0 <= R0 < N(t+1)",
              DiagnosticCategory::internal);
        }
        palm_atoms.push_back(AdmissionPalmAtomV1{
            index, batch, rank_value, backlog, departure, first_eligible,
            reward.phase_after, reward.marks, atom.entrance_labels,
            per_label.value(), image});
        exact_total = exact_total + per_label.value();
        numerical_total.add(image);
      }
    }
    if (!(exact_total == ExactRational::one())) {
      return fail<AdmissionPalmLaw>(
          "c23.admission_palm_exact_normalization_failure",
          "within-batch labelled admission-Palm masses do not sum exactly "
          "to one",
          DiagnosticCategory::internal,
          {"mass " + exact_total.to_canonical_string()});
    }
    auto core =
        std::make_shared<const metrics::detail::AdmissionPalmLawCore>(
            metrics::detail::AdmissionPalmLawCore{
                edge_core.source, std::move(palm_atoms), std::move(rate),
                std::move(queue),
                PalmNumericalDiagnosticsV1{
                    numerical_intensity.value(),
                    numerical_intensity.correction(), numerical_total.value(),
                    numerical_total.value() - 1.0L},
                source.fingerprint, edge_identity.value(),
                source.provider_binding.timing_identity,
                mark.target_ordinal});
    if (actual_entrance_atoms != nullptr) {
      *actual_entrance_atoms = total_labels;
    }
    return Result<AdmissionPalmLaw>::success(
        detail::C23CoreAccess::admission_palm_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<AdmissionPalmLaw>(
        "c23.admission_palm_allocation_failure",
        "constructing the labelled admission-Palm law exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<AdmissionPalmLaw>(
        "c23.admission_palm_exception",
        "admission-Palm construction raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<AdmissionPalmLaw> construct_admission_palm_law(
    const StationaryMarkedEdge& edge, const ArrivalCountMark& mark) {
  return construct_admission_palm_law_impl(
      edge, mark, std::nullopt, nullptr);
}

Result<metrics::detail::BoundedAdmissionPalmLawV1>
metrics::detail::construct_admission_palm_law_bounded(
    const StationaryMarkedEdge& edge, const ArrivalCountMark& mark,
    const std::size_t maximum_entrance_atoms) {
  std::size_t actual_entrance_atoms = 0U;
  auto law = construct_admission_palm_law_impl(
      edge, mark, maximum_entrance_atoms, &actual_entrance_atoms);
  if (!law) {
    return Result<BoundedAdmissionPalmLawV1>::failure(law.error());
  }
  return Result<BoundedAdmissionPalmLawV1>::success(
      BoundedAdmissionPalmLawV1{
          std::move(law).value(), actual_entrance_atoms});
}

Result<TagInitialLaw> lift_fifo_tag_state(
    const AdmissionPalmLaw& law, const PredictiveServiceSplit& split) {
  try {
    const auto& palm = detail::C23CoreAccess::core(law);
    const auto& service = detail::C23CoreAccess::core(split);
    if (!palm.source || !service.source ||
        !same_source_owner(palm.source, service.source) ||
        palm.projection_fingerprint != service.projection_fingerprint ||
        palm.projection_fingerprint != palm.source->fingerprint ||
        service.target_selection_identity !=
            palm.source->provider_binding.target_selection_identity ||
        service.target_service_schema_identity !=
            palm.source->provider_binding.target_service_schema_identity) {
      return fail<TagInitialLaw>(
          "c23.fifo_split_projection_binding_mismatch",
          "the admission Palm law and predictive P0/P1 split must share the "
          "same C21 source owner, projection, target, and service schema");
    }
    const auto& source = *palm.source;
    const auto& temporal = *source.temporal_source;
    if (palm.target_ordinal >=
        source.provider_binding.target_selection.ordered_targets.size()) {
      return fail<TagInitialLaw>(
          "c23.fifo_target_not_selected",
          "the Palm target is absent from the predictive service selection",
          DiagnosticCategory::unavailable);
    }

    const bool predictive =
        source.provider_binding.capabilities.palm_or_fifo_route &&
        source.provider_binding.capabilities.retains_predictive_phase &&
        source.provider_binding.capabilities.retains_target_departure &&
        source.provider_binding.capabilities.retains_arrival_batch &&
        source.provider_binding.capabilities.exact_complete_residence_words &&
        source.provider_binding.capabilities.finite_phase_time_homogeneous &&
        source.provider_binding.capabilities
            .unbounded_stationary_temporal_continuation;
    const QueueId& target =
        source.provider_binding.target_selection
            .ordered_targets[palm.target_ordinal];
    auto accepted = accepted_fifo_authorization(
        source.provider_binding, target, predictive);
    if (!accepted) {
      return Result<TagInitialLaw>::failure(accepted.error());
    }
    const FifoTagAssumptionsV1 assumptions = accepted.value().assumptions;
    if (!assumptions.global_fifo || !assumptions.unit_packets ||
        !assumptions.lossless ||
        !assumptions.positive_finite_admission_intensity ||
        !assumptions.full_history_predictive_service) {
      return fail<TagInitialLaw>(
          "c23.fifo_tag_hypotheses_unavailable",
          "the target's accepted FIFO route does not establish global FIFO, "
          "unit packets, losslessness, positive finite intensity, and "
          "full-history predictive service continuation",
          DiagnosticCategory::unavailable);
    }

    std::vector<metrics::detail::FifoAuthorizationGroupCore>
        authorization_groups;
    authorization_groups.reserve(accepted.value().groups.size());
    for (const AcceptedFifoAuthorizationGroupV1& group :
         accepted.value().groups) {
      std::optional<PalmConditionV1> resolved_condition;
      if (group.condition.has_value()) {
        auto resolved =
            resolve_fifo_condition(source.provider_binding, *group.condition);
        if (!resolved) {
          return Result<TagInitialLaw>::failure(resolved.error());
        }
        resolved_condition = std::move(resolved).value();
      }
      authorization_groups.push_back(
          metrics::detail::FifoAuthorizationGroupCore{
              std::move(resolved_condition), group.outputs});
    }

    std::vector<std::size_t> service_partition_count(source.atoms.size(), 0U);
    const auto validate_partition =
        [&](const std::span<const stationary::detail::PredictiveServiceAtomCore>
                atoms,
            const std::uint8_t expected_departure) -> Result<void> {
      for (const auto& atom : atoms) {
        if (atom.target_ordinal != palm.target_ordinal) {
          continue;
        }
        if (atom.temporal_atom_index >= source.atoms.size()) {
          return fail<void>("c23.fifo_split_atom_out_of_range",
                            "a predictive service atom names no C21 temporal "
                            "slot",
                            DiagnosticCategory::internal);
        }
        const auto& reward =
            source.atoms[atom.temporal_atom_index].reward_edge;
        const auto& temporal_row =
            temporal.nodes[atom.temporal_atom_index];
        ExactRational exact_left_mass = ExactRational::zero();
        for (const auto& source_atom : source.atoms) {
          if (source_atom.stationary_left_state ==
              source.atoms[atom.temporal_atom_index]
                  .stationary_left_state) {
            exact_left_mass = exact_left_mass + source_atom.exact_mass;
          }
        }
        if (palm.target_ordinal >= reward.target_departures.size() ||
            atom.target_departure != expected_departure ||
            reward.target_departures[palm.target_ordinal] !=
                expected_departure ||
            atom.stationary_left_state !=
                source.atoms[atom.temporal_atom_index].stationary_left_state ||
            atom.stationary_right_state !=
                source.atoms[atom.temporal_atom_index]
                    .stationary_right_state ||
            !(atom.exact_left_mass == exact_left_mass) ||
            !(atom.exact_joint_mass ==
              source.atoms[atom.temporal_atom_index].exact_mass) ||
            !(atom.exact_left_mass * atom.exact_conditional_mass ==
              atom.exact_joint_mass) ||
            !(atom.raw_edge ==
              source.atoms[atom.temporal_atom_index].raw_edge) ||
            !(temporal_row.decoded_state == atom.stationary_left_state)) {
          return fail<void>(
              "c23.fifo_split_not_chronological_partition",
              "P0/P1 is not the exact actual-departure partition of the "
              "retained C21 chronological source, including its stationary "
              "left, joint, and conditional masses");
        }
        ExactRational temporal_row_mass = ExactRational::zero();
        for (const auto& transition : temporal_row.transitions) {
          if (transition.successor_index >= temporal.nodes.size() ||
              !(transition.edge == reward) ||
              !(temporal.nodes[transition.successor_index].decoded_state ==
                atom.stationary_right_state) ||
              !transition.exact_mass.is_positive()) {
            return fail<void>(
                "c23.fifo_split_temporal_row_mismatch",
                "a P0/P1 atom does not induce the complete chronological "
                "continuation row of its declared C21 temporal state",
                DiagnosticCategory::internal);
          }
          temporal_row_mass = temporal_row_mass + transition.exact_mass;
        }
        if (!(temporal_row_mass == ExactRational::one())) {
          return fail<void>(
              "c23.fifo_split_temporal_row_mass_mismatch",
              "the chronological continuation row underlying P0+P1 does "
              "not have exact unit mass",
              DiagnosticCategory::internal);
        }
        ++service_partition_count[atom.temporal_atom_index];
      }
      return Result<void>::success();
    };
    auto p0 = validate_partition(service.p0_atoms, 0U);
    if (!p0) {
      return Result<TagInitialLaw>::failure(p0.error());
    }
    auto p1 = validate_partition(service.p1_atoms, 1U);
    if (!p1) {
      return Result<TagInitialLaw>::failure(p1.error());
    }
    if (std::any_of(service_partition_count.begin(),
                    service_partition_count.end(),
                    [](const std::size_t count) { return count != 1U; })) {
      return fail<TagInitialLaw>(
          "c23.fifo_split_incomplete",
          "P0+P1 does not classify every chronological C21 service slot "
          "exactly once for the selected target");
    }

    std::size_t materialized_atom_count = 0U;
    for (const AdmissionPalmAtomV1& palm_atom : palm.atoms) {
      if (palm_atom.edge_atom_index >= temporal.nodes.size()) {
        return fail<TagInitialLaw>(
            "c23.fifo_palm_edge_index_out_of_range",
            "an admission-Palm atom names no latent C21 temporal slot",
            DiagnosticCategory::internal);
      }
      const std::size_t successor_count =
          temporal.nodes[palm_atom.edge_atom_index].transitions.size();
      if (successor_count >
          kMaximumEnumeratedPalmLabels - materialized_atom_count) {
        return fail<TagInitialLaw>(
            "c23.fifo_entrance_atom_budget_exceeded",
            "the expanded passive-tag Palm entrance exceeds the C23 "
            "materialization budget",
            DiagnosticCategory::resource_limit);
      }
      materialized_atom_count += successor_count;
    }
    std::vector<TagInitialAtomV1> atoms;
    atoms.reserve(materialized_atom_count);
    ExactRational total = ExactRational::zero();
    CompensatedSum numerical_total;
    for (const AdmissionPalmAtomV1& palm_atom : palm.atoms) {
      if (palm_atom.edge_atom_index >= temporal.nodes.size()) {
        return fail<TagInitialLaw>(
            "c23.fifo_palm_edge_index_out_of_range",
            "an admission-Palm atom names no latent C21 temporal slot",
            DiagnosticCategory::internal);
      }
      if (palm_atom.within_batch_rank.is_zero() ||
          palm_atom.within_batch_rank > palm_atom.batch_size) {
        return fail<TagInitialLaw>("c23.invalid_fifo_entrance_rank",
                                   "within-batch FIFO rank must be in 1..A");
      }
      auto after_service = checked_subtract(
          palm_atom.prearrival_backlog, BigNat{palm_atom.actual_departure});
      if (!after_service) {
        return fail<TagInitialLaw>(
            "c23.fifo_entrance_departure_exceeds_backlog",
            "the retained actual departure exceeds the predecision backlog");
      }
      auto rank_minus_one =
          checked_subtract(palm_atom.within_batch_rank, BigNat{1U});
      if (!rank_minus_one) {
        return Result<TagInitialLaw>::failure(rank_minus_one.error());
      }
      const BigNat expected_predecessors =
          after_service.value() + rank_minus_one.value();
      const BigNat expected_total =
          after_service.value() + palm_atom.batch_size;
      if (!(expected_total == palm_atom.first_eligible_backlog) ||
          !(expected_predecessors < expected_total)) {
        return fail<TagInitialLaw>(
            "c23.fifo_entrance_timing_invariant_failure",
            "FIFO tag initialization violates R0=N(t)-D(t)+j-1 or "
            "N(t+1)=N(t)-D(t)+A(t+1)",
            DiagnosticCategory::internal);
      }

      const auto& row = temporal.nodes[palm_atom.edge_atom_index];
      for (const auto& transition : row.transitions) {
        if (transition.successor_index >= temporal.nodes.size()) {
          return fail<TagInitialLaw>(
              "c23.fifo_entrance_successor_out_of_range",
              "the retained C21 continuation names no successor node",
              DiagnosticCategory::internal);
        }
        const auto& successor = temporal.nodes[transition.successor_index];
        if (palm.target_ordinal >= successor.state_target_backlog.size() ||
            !(successor.state_target_backlog[palm.target_ordinal] ==
              expected_total)) {
          return fail<TagInitialLaw>(
              "c23.fifo_first_eligible_backlog_mismatch",
              "the post-boundary predictive state does not retain the exact "
              "N(t+1) queue length");
        }
        const ExactRational mass =
            palm_atom.exact_mass * transition.exact_mass;
        const long double image = mass.to_long_double();
        if (!std::isfinite(image) || image <= 0.0L) {
          return fail<TagInitialLaw>(
              "c23.fifo_entrance_atom_numerically_unresolved",
              "a positive exact FIFO entrance atom has no finite positive "
              "long-double image",
              DiagnosticCategory::unavailable);
        }
        atoms.push_back(TagInitialAtomV1{
            TagState{successor.decoded_state, expected_predecessors},
            transition.successor_index,
            TagEntranceLabelV1{
                palm_atom.batch_size, palm_atom.within_batch_rank,
                palm_atom.first_eligible_phase,
                palm_atom.retained_edge_marks,
                palm_atom.entrance_labels},
            mass, image});
        total = total + mass;
        numerical_total.add(image);
      }
    }
    if (!(total == ExactRational::one())) {
      return fail<TagInitialLaw>(
          "c23.fifo_entrance_exact_normalization_failure",
          "post-boundary FIFO tag entrances do not sum exactly to one",
          DiagnosticCategory::internal,
          {"mass " + total.to_canonical_string()});
    }
    if (!std::isfinite(numerical_total.value())) {
      return fail<TagInitialLaw>(
          "c23.fifo_entrance_numerically_unresolved",
          "the exact FIFO entrance has no finite long-double image",
          DiagnosticCategory::unavailable);
    }

    CanonicalEncoder identity_encoder;
    identity_encoder.digest(palm.projection_fingerprint);
    identity_encoder.digest(palm.marked_edge_identity);
    identity_encoder.digest(service.projection_fingerprint);
    identity_encoder.u64(static_cast<std::uint64_t>(palm.target_ordinal));
    for (const TagInitialAtomV1& atom : atoms) {
      identity_encoder.u64(
          static_cast<std::uint64_t>(atom.continuation_index));
      identity_encoder.natural(atom.state.predecessors);
      identity_encoder.natural(atom.label.batch_size);
      identity_encoder.natural(atom.label.within_batch_rank);
      identity_encoder.rational(atom.exact_mass);
    }
    auto entrance_identity =
        fingerprint("mwperf.c23.fifo_tag_entrance.v1", identity_encoder);
    if (!entrance_identity) {
      return Result<TagInitialLaw>::failure(entrance_identity.error());
    }
    const auto unconditioned_group = std::find_if(
        authorization_groups.begin(), authorization_groups.end(),
        [](const metrics::detail::FifoAuthorizationGroupCore& group) {
          return !group.condition.has_value();
        });
    const bool one_condition_only =
        authorization_groups.size() == 1U &&
        authorization_groups.front().condition.has_value();
    std::vector<FifoDelayOutputV1> active_outputs;
    if (unconditioned_group != authorization_groups.end()) {
      active_outputs = unconditioned_group->outputs;
    } else if (one_condition_only) {
      active_outputs = authorization_groups.front().outputs;
    }
    auto split_owner = detail::C23CoreAccess::core_ptr(split);
    auto core = std::make_shared<const metrics::detail::TagInitialLawCore>(
        metrics::detail::TagInitialLawCore{
            palm.source, std::move(split_owner), std::move(atoms),
            palm.admission_rate, palm.stationary_queue_law, assumptions,
            authorization_groups, std::move(active_outputs), std::nullopt,
            palm.projection_fingerprint,
            entrance_identity.value(), palm.target_ordinal});
    TagInitialLaw lifted =
        detail::C23CoreAccess::tag_initial_law(std::move(core));
    if (!one_condition_only) {
      return Result<TagInitialLaw>::success(std::move(lifted));
    }
    return condition_tag_initial_law_impl(
        lifted, *authorization_groups.front().condition);
  } catch (const std::bad_alloc&) {
    return fail<TagInitialLaw>(
        "c23.fifo_tag_lift_allocation_failure",
        "lifting the admission Palm entrance to a passive FIFO tag exhausted "
        "memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<TagInitialLaw>(
        "c23.fifo_tag_lift_exception",
        "FIFO tag initialization raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

namespace {

[[nodiscard]] bool matches_condition(const TagInitialAtomV1& atom,
                                     const PalmConditionV1& condition) {
  return std::visit(
      [&](const auto& typed) {
        using T = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<T, RankPalmConditionV1>) {
          return atom.label.within_batch_rank == typed.rank;
        } else if constexpr (std::is_same_v<T, BatchPalmConditionV1>) {
          return atom.label.batch_size == typed.batch_size;
        } else if constexpr (std::is_same_v<T, PhasePalmConditionV1>) {
          return atom.label.phase == typed.phase;
        } else {
          return std::any_of(
              atom.label.entrance_labels.begin(),
              atom.label.entrance_labels.end(),
              [&](const RuntimeDecodedMarkV1& mark) {
                return mark.mark == typed.mark_id &&
                       mark.value.codec == typed.codec &&
                       mark.value.canonical_value == typed.canonical_value;
              });
        }
      },
      condition);
}

void encode_condition(CanonicalEncoder& encoder,
                      const PalmConditionV1& condition) {
  encoder.byte(static_cast<std::uint8_t>(condition.index()));
  std::visit(
      [&](const auto& typed) {
        using T = std::decay_t<decltype(typed)>;
        if constexpr (std::is_same_v<T, RankPalmConditionV1>) {
          encoder.natural(typed.rank);
        } else if constexpr (std::is_same_v<T, BatchPalmConditionV1>) {
          encoder.natural(typed.batch_size);
        } else if constexpr (std::is_same_v<T, PhasePalmConditionV1>) {
          encoder.byte(static_cast<std::uint8_t>(typed.phase.family));
          encoder.frame(std::span<const std::byte>(
              typed.phase.canonical_state.data(),
              typed.phase.canonical_state.size()));
        } else {
          const auto id_bytes = typed.mark_id.canonical_bytes();
          encoder.frame(std::span<const std::uint8_t>(id_bytes));
          encoder.text(typed.codec.id);
          encoder.u64(typed.codec.version);
          encoder.frame(std::span<const std::byte>(
              typed.canonical_value.data(), typed.canonical_value.size()));
        }
      },
      condition);
}

Result<TagInitialLaw> condition_tag_initial_law_impl(
    const TagInitialLaw& law, const PalmConditionV1& condition) {
  try {
    const auto& original = detail::C23CoreAccess::core(law);
    if (original.conditioning.has_value()) {
      return fail<TagInitialLaw>(
          "c23.fifo_entrance_already_conditioned",
          "analysis-v1 applies exactly one rank, batch, phase, or retained-"
          "mark condition to the all-admission Palm entrance");
    }
    const auto authorization = std::find_if(
        original.authorization_groups.begin(),
        original.authorization_groups.end(),
        [&](const metrics::detail::FifoAuthorizationGroupCore& group) {
          return group.condition.has_value() && *group.condition == condition;
        });
    if (authorization == original.authorization_groups.end()) {
      return fail<TagInitialLaw>(
          "c23.fifo_condition_not_authorized",
          "the requested FIFO Palm condition is not one of the accepted "
          "C14 entrance conditions",
          DiagnosticCategory::unavailable);
    }
    ExactRational selected_mass = ExactRational::zero();
    for (const TagInitialAtomV1& atom : original.atoms) {
      if (matches_condition(atom, condition)) {
        selected_mass = selected_mass + atom.exact_mass;
      }
    }
    if (!selected_mass.is_positive()) {
      return fail<TagInitialLaw>(
          "c23.fifo_condition_zero_palm_mass",
          "the requested FIFO entrance condition has zero exact Palm mass",
          DiagnosticCategory::unavailable);
    }
    if (!finite_positive_image(selected_mass)) {
      return fail<TagInitialLaw>(
          "c23.fifo_condition_numerically_unresolved",
          "the positive exact conditioning mass has no finite positive "
          "long-double image",
          DiagnosticCategory::unavailable);
    }
    std::vector<TagInitialAtomV1> atoms;
    ExactRational total = ExactRational::zero();
    for (const TagInitialAtomV1& atom : original.atoms) {
      if (!matches_condition(atom, condition)) {
        continue;
      }
      auto normalized = checked_divide(atom.exact_mass, selected_mass);
      if (!normalized) {
        return Result<TagInitialLaw>::failure(normalized.error());
      }
      const long double image = normalized.value().to_long_double();
      if (!std::isfinite(image) || image <= 0.0L) {
        return fail<TagInitialLaw>(
            "c23.fifo_condition_atom_numerically_unresolved",
            "a positive conditioned FIFO entrance atom has no finite "
            "positive long-double image",
            DiagnosticCategory::unavailable);
      }
      TagInitialAtomV1 copy = atom;
      copy.exact_mass = normalized.value();
      copy.numerical_mass = image;
      atoms.push_back(std::move(copy));
      total = total + normalized.value();
    }
    if (!(total == ExactRational::one())) {
      return fail<TagInitialLaw>(
          "c23.fifo_condition_exact_normalization_failure",
          "the conditioned FIFO entrance does not normalize exactly",
          DiagnosticCategory::internal);
    }
    CanonicalEncoder encoder;
    encoder.digest(original.entrance_identity);
    encode_condition(encoder, condition);
    for (const auto& atom : atoms) {
      encoder.u64(static_cast<std::uint64_t>(atom.continuation_index));
      encoder.natural(atom.state.predecessors);
      encoder.rational(atom.exact_mass);
    }
    auto identity =
        fingerprint("mwperf.c23.conditioned_fifo_entrance.v1", encoder);
    if (!identity) {
      return Result<TagInitialLaw>::failure(identity.error());
    }
    auto core = std::make_shared<const metrics::detail::TagInitialLawCore>(
        metrics::detail::TagInitialLawCore{
            original.source, original.split, std::move(atoms),
            original.admission_rate, original.stationary_queue_law,
            original.assumptions, original.authorization_groups,
            authorization->outputs, condition,
            original.projection_fingerprint, identity.value(),
            original.target_ordinal});
    return Result<TagInitialLaw>::success(
        detail::C23CoreAccess::tag_initial_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<TagInitialLaw>(
        "c23.fifo_condition_allocation_failure",
        "conditioning the FIFO Palm entrance exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<TagInitialLaw>(
        "c23.fifo_condition_exception",
        "conditioning the FIFO Palm entrance raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<TagInitialLaw> condition_tag_initial_law(
    const TagInitialLaw& law, const PalmConditionV1& condition) {
  return condition_tag_initial_law_impl(law, condition);
}

Result<TagInitialLaw> condition_tag_initial_law(
    const TagInitialLaw& law, const FifoConditionV1& condition) {
  const auto& original = detail::C23CoreAccess::core(law);
  if (!original.source) {
    return fail<TagInitialLaw>(
        "c23.fifo_condition_source_missing",
        "an authored FIFO condition requires the retained C21 source",
        DiagnosticCategory::internal);
  }
  auto resolved =
      resolve_fifo_condition(original.source->provider_binding, condition);
  if (!resolved) {
    return Result<TagInitialLaw>::failure(resolved.error());
  }
  return condition_tag_initial_law_impl(law, resolved.value());
}

Result<TagTransition> advance_passive_fifo_tag(
    const TagState& state, const TemporalServiceStep& step) {
  if (step.actual_target_departure > 1U) {
    return fail<TagTransition>("c23.nonbinary_fifo_service_step",
                               "a unit-packet FIFO service step must have "
                               "actual departure d in {0,1}");
  }
  if (state.predecessors.is_zero() &&
      step.actual_target_departure == 1U) {
    return Result<TagTransition>::success(
        TagTransition{true, std::nullopt});
  }
  BigNat predecessors = state.predecessors;
  if (step.actual_target_departure == 1U) {
    auto decremented = checked_subtract(predecessors, BigNat{1U});
    if (!decremented) {
      return Result<TagTransition>::failure(decremented.error());
    }
    predecessors = std::move(decremented).value();
  }
  if (step.successor_total_backlog.is_zero() ||
      !(predecessors < step.successor_total_backlog)) {
    return fail<TagTransition>(
        "c23.fifo_successor_rank_invariant_failure",
        "a surviving FIFO tag must satisfy 0 <= R' < N' in the exact "
        "successor state");
  }
  return Result<TagTransition>::success(TagTransition{
      false,
      TagState{step.successor_untagged_state, std::move(predecessors)}});
}

namespace {

struct LiftedTagNodeV1 final {
  std::size_t base_node_index;
  BigNat predecessors;
};

struct LiftedTagGraphV1 final {
  std::shared_ptr<const metrics::detail::TemporalSourceCore> source;
  AuditedTemporalKernel audited_kernel;
  InitialLaw initial_law;
  std::size_t live_state_count;
  std::size_t maximum_initial_rank;
  std::size_t row_atom_count;
  std::size_t maximum_row_width;
};

[[nodiscard]] Result<Digest256> derived_schema_identity(
    const std::string_view domain, const Digest256& base,
    const std::string_view suffix) {
  CanonicalEncoder encoder;
  encoder.digest(base);
  encoder.text(suffix);
  return fingerprint(domain, encoder);
}

[[nodiscard]] std::pair<std::size_t, BigInt> lifted_key(
    const std::size_t base_node_index, const BigNat& predecessors) {
  return {base_node_index, predecessors.value()};
}

struct LazyLiftedTagAtomV1 final {
  std::size_t base_transition_index;
  bool tag_departed;
  std::optional<std::size_t> live_successor_index;
};

// Private F-C23-05 adapter.  Rows do not exist until requested from an
// entrance-reachable lifted state.  Each requested row is built exactly once,
// and every temporal service atom is advanced through the public F-C23-04
// primitive before the row is cached.  The finite cache is materialized only
// because C22's audited carrier is a value graph.
class LazyPassiveFifoTagAdapterV1 final {
 public:
  LazyPassiveFifoTagAdapterV1(
      const metrics::detail::TagInitialLawCore& initial,
      const metrics::detail::TemporalSourceCore& base,
      const std::size_t maximum_live_states,
      const std::size_t maximum_row_width)
      : initial_(initial),
        base_(base),
        maximum_live_states_(maximum_live_states),
        maximum_row_width_budget_(maximum_row_width) {}

  [[nodiscard]] Result<std::size_t> add_seed(
      const std::size_t base_index, const BigNat& predecessors) {
    if (base_index >= base_.nodes.size()) {
      return fail<std::size_t>(
          "c23.fifo_entrance_continuation_out_of_range",
          "a FIFO entrance names no base chronological continuation node",
          DiagnosticCategory::internal);
    }
    return add_node(base_index, predecessors);
  }

  [[nodiscard]] Result<void> expand_reachable() {
    for (std::size_t index = 0U; index < nodes_.size(); ++index) {
      auto built = ensure_row(index);
      if (!built) {
        return built;
      }
    }
    return Result<void>::success();
  }

  [[nodiscard]] const std::vector<LiftedTagNodeV1>& nodes() const noexcept {
    return nodes_;
  }

  [[nodiscard]] const std::vector<LazyLiftedTagAtomV1>& row(
      const std::size_t index) const {
    return *rows_[index];
  }

  [[nodiscard]] const std::map<std::pair<std::size_t, BigInt>, std::size_t>&
  index() const noexcept {
    return index_;
  }

  [[nodiscard]] std::size_t row_atom_count() const noexcept {
    return row_atom_count_;
  }

  [[nodiscard]] std::size_t maximum_row_width() const noexcept {
    return maximum_row_width_;
  }

 private:
  [[nodiscard]] Result<std::size_t> add_node(
      const std::size_t base_index, const BigNat& predecessors) {
    const auto key = lifted_key(base_index, predecessors);
    const auto found = index_.find(key);
    if (found != index_.end()) {
      return Result<std::size_t>::success(found->second);
    }
    if (nodes_.size() >= maximum_live_states_) {
      return fail<std::size_t>(
          "c23.fifo_lift_state_budget_exceeded",
          "the entrance-reachable passive FIFO tag graph exceeds its "
          "materialization budget",
          DiagnosticCategory::resource_limit);
    }
    const std::size_t index = nodes_.size();
    nodes_.push_back(LiftedTagNodeV1{base_index, predecessors});
    rows_.push_back(std::nullopt);
    index_.emplace(key, index);
    return Result<std::size_t>::success(index);
  }

  [[nodiscard]] Result<void> ensure_row(const std::size_t index) {
    if (index >= nodes_.size()) {
      return fail<void>("c23.fifo_lazy_row_out_of_range",
                        "the lazy FIFO tag adapter received an invalid row",
                        DiagnosticCategory::internal);
    }
    if (rows_[index].has_value()) {
      return Result<void>::success();
    }
    const LiftedTagNodeV1 current = nodes_[index];
    if (current.base_node_index >= base_.nodes.size()) {
      return fail<void>(
          "c23.fifo_lazy_base_state_out_of_range",
          "the lazy FIFO tag adapter received an invalid base state",
          DiagnosticCategory::internal);
    }
    const auto& base_node = base_.nodes[current.base_node_index];
    if (base_node.transitions.size() > maximum_row_width_budget_) {
      return fail<void>(
          "c23.fifo_lift_row_width_budget_exceeded",
          "an entrance-reachable passive FIFO tag row exceeds the authored max_row_atoms grant before materialization",
          DiagnosticCategory::resource_limit);
    }
    if (base_node.transitions.size() >
        kMaximumEnumeratedPalmLabels - row_atom_count_) {
      return fail<void>(
          "c23.fifo_lift_row_atom_budget_exceeded",
          "the entrance-reachable passive FIFO tag rows exceed the C23 "
          "materialization budget",
          DiagnosticCategory::resource_limit);
    }
    std::vector<LazyLiftedTagAtomV1> built_row;
    built_row.reserve(base_node.transitions.size());
    for (std::size_t transition_index = 0U;
         transition_index < base_node.transitions.size();
         ++transition_index) {
      const auto& transition = base_node.transitions[transition_index];
      if (transition.successor_index >= base_.nodes.size()) {
        return fail<void>(
            "c23.fifo_base_successor_out_of_range",
            "the C21 temporal source contains an invalid successor index",
            DiagnosticCategory::internal);
      }
      if (initial_.target_ordinal >=
              transition.edge.target_departures.size() ||
          initial_.target_ordinal >=
              base_.nodes[transition.successor_index]
                  .state_target_backlog.size()) {
        return fail<void>(
            "c23.fifo_service_marks_not_retained",
            "the temporal service row omits the selected departure or "
            "successor backlog mark",
            DiagnosticCategory::unavailable);
      }
      const std::uint8_t departure =
          transition.edge.target_departures[initial_.target_ordinal];
      const auto& successor_base = base_.nodes[transition.successor_index];
      const TagState public_state{base_node.decoded_state,
                                  current.predecessors};
      const TemporalServiceStep step{
          successor_base.decoded_state,
          successor_base.state_target_backlog[initial_.target_ordinal],
          departure};
      trace_passive_tag_adapter_advance();
      auto advanced = advance_passive_fifo_tag(public_state, step);
      if (!advanced) {
        return Result<void>::failure(advanced.error());
      }
      if (advanced.value().tag_departed ==
          advanced.value().survivor.has_value()) {
        return fail<void>(
            "c23.fifo_lazy_advance_shape_invalid",
            "F-C23-04 returned an inconsistent departed/survivor shape",
            DiagnosticCategory::internal);
      }
      std::optional<std::size_t> successor;
      if (!advanced.value().tag_departed) {
        auto inserted = add_node(
            transition.successor_index,
            advanced.value().survivor->predecessors);
        if (!inserted) {
          return Result<void>::failure(inserted.error());
        }
        successor = inserted.value();
      }
      built_row.push_back(LazyLiftedTagAtomV1{
          transition_index, advanced.value().tag_departed, successor});
    }
    row_atom_count_ += built_row.size();
    maximum_row_width_ =
        std::max(maximum_row_width_, built_row.size());
    rows_[index] = std::move(built_row);
    return Result<void>::success();
  }

  const metrics::detail::TagInitialLawCore& initial_;
  const metrics::detail::TemporalSourceCore& base_;
  std::size_t maximum_live_states_;
  std::size_t maximum_row_width_budget_;
  std::vector<LiftedTagNodeV1> nodes_;
  std::vector<std::optional<std::vector<LazyLiftedTagAtomV1>>> rows_;
  std::map<std::pair<std::size_t, BigInt>, std::size_t> index_;
  std::size_t row_atom_count_{0U};
  std::size_t maximum_row_width_{0U};
};

[[nodiscard]] Result<LiftedTagGraphV1> build_lifted_tag_graph(
    const metrics::detail::TagInitialLawCore& initial,
    const TemporalServiceKernel& public_service,
    const stationary::detail::TemporalServiceKernelCore& service,
    const std::optional<std::size_t> maximum_states_budget,
    const std::optional<std::size_t> maximum_row_atoms_budget) {
  if (!initial.source || !initial.source->temporal_source ||
      !same_source_owner(initial.source, service.source)) {
    return fail<LiftedTagGraphV1>(
        "c23.fifo_service_source_owner_mismatch",
        "the FIFO entrance and temporal service kernel do not share one C21 "
        "source owner");
  }
  const auto& base = *initial.source->temporal_source;
  if (base.nodes.empty()) {
    return fail<LiftedTagGraphV1>(
        "c23.fifo_empty_temporal_source",
        "a FIFO delay law requires a nonempty temporal source",
        DiagnosticCategory::unavailable);
  }
  if (maximum_states_budget.has_value() &&
      base.nodes.size() > *maximum_states_budget) {
    return fail<LiftedTagGraphV1>(
        "c23.fifo_lift_state_budget_exceeded",
        "the terminal extension alone exceeds the authored maximum_states grant before lifted-state materialization",
        DiagnosticCategory::resource_limit);
  }
  if (base.nodes.size() > kMaximumEnumeratedPalmLabels) {
    return fail<LiftedTagGraphV1>(
        "c23.fifo_lift_state_budget_exceeded",
        "the terminal extension exceeds the C23 materialization budget",
        DiagnosticCategory::resource_limit);
  }
  if (maximum_row_atoms_budget.has_value() &&
      std::ranges::any_of(base.nodes, [&](const auto& node) {
        return node.transitions.size() > *maximum_row_atoms_budget;
      })) {
    return fail<LiftedTagGraphV1>(
        "c23.fifo_lift_row_width_budget_exceeded",
        "a passive FIFO base row exceeds the authored max_row_atoms grant before lifted-graph materialization",
        DiagnosticCategory::resource_limit);
  }
  std::size_t maximum_live_states =
      kMaximumEnumeratedPalmLabels - base.nodes.size();
  if (maximum_states_budget.has_value()) {
    maximum_live_states = std::min(
        maximum_live_states,
        *maximum_states_budget - base.nodes.size());
  }
  const std::size_t maximum_row_width =
      maximum_row_atoms_budget.value_or(kMaximumEnumeratedPalmLabels);
  auto marker_id = tag_departure_mark_id();
  if (!marker_id) {
    return Result<LiftedTagGraphV1>::failure(marker_id.error());
  }

  std::size_t maximum_rank = 0U;
  for (const TagInitialAtomV1& atom : initial.atoms) {
    auto rank = bounded_size(atom.state.predecessors,
                             "an initial FIFO predecessor rank",
                             kMaximumEnumeratedPalmLabels);
    if (!rank) {
      return Result<LiftedTagGraphV1>::failure(rank.error());
    }
    maximum_rank = std::max(maximum_rank, rank.value());
  }
  LazyPassiveFifoTagAdapterV1 adapter(
      initial, base, maximum_live_states, maximum_row_width);
  for (const TagInitialAtomV1& atom : initial.atoms) {
    auto inserted = adapter.add_seed(atom.continuation_index,
                                     atom.state.predecessors);
    if (!inserted) {
      return Result<LiftedTagGraphV1>::failure(inserted.error());
    }
  }
  auto expanded = adapter.expand_reachable();
  if (!expanded) {
    return Result<LiftedTagGraphV1>::failure(expanded.error());
  }
  const auto& lifted_nodes = adapter.nodes();
  const auto& lifted_index = adapter.index();
  if (lifted_nodes.size() > kMaximumEnumeratedPalmLabels ||
      base.nodes.size() >
          kMaximumEnumeratedPalmLabels - lifted_nodes.size()) {
    return fail<LiftedTagGraphV1>(
        "c23.fifo_lift_state_budget_exceeded",
        "the entrance-reachable live tag states plus the finite C22 terminal "
        "extension exceed the C23 materialization budget",
        DiagnosticCategory::resource_limit);
  }

  auto source_fingerprint = tagged_source_fingerprint(initial, service);
  if (!source_fingerprint) {
    return Result<LiftedTagGraphV1>::failure(source_fingerprint.error());
  }
  auto exact_schema = derived_schema_identity(
      "mwperf.c23.tag_exact_schema.v1", base.binding.exact_state_schema_identity,
      kTagStateCodec);
  auto reduced_schema = derived_schema_identity(
      "mwperf.c23.tag_reduced_schema.v1",
      base.binding.reduced_state_schema_identity, kTagStateCodec);
  auto mark_schema = derived_schema_identity(
      "mwperf.c23.tag_mark_schema.v1", base.binding.mark_schema_identity,
      kTagDepartureMark);
  auto continuation_schema = derived_schema_identity(
      "mwperf.c23.tag_continuation_schema.v1",
      base.binding.continuation_schema_identity, kTagStateCodec);
  if (!exact_schema || !reduced_schema || !mark_schema ||
      !continuation_schema) {
    if (!exact_schema) {
      return Result<LiftedTagGraphV1>::failure(exact_schema.error());
    }
    if (!reduced_schema) {
      return Result<LiftedTagGraphV1>::failure(reduced_schema.error());
    }
    if (!mark_schema) {
      return Result<LiftedTagGraphV1>::failure(mark_schema.error());
    }
    return Result<LiftedTagGraphV1>::failure(continuation_schema.error());
  }

  std::vector<metrics::detail::TemporalNodeCore> nodes;
  nodes.reserve(lifted_nodes.size() + base.nodes.size());
  for (const LiftedTagNodeV1& lifted : lifted_nodes) {
    const auto& base_node = base.nodes[lifted.base_node_index];
    nodes.push_back(metrics::detail::TemporalNodeCore{
        tagged_state_value(lifted.base_node_index, lifted.predecessors, false),
        {}, base_node.invariant_component, base_node.state_target_backlog,
        std::nullopt});
  }
  // C22 requires a complete pre-killing source.  Keep one terminal-extension
  // node per untagged base node so a tagged-departure edge still carries its
  // real N/phase successor.  These nodes are never reached by the killed
  // survivor chain: the exact true departure mark classifies the incoming
  // edge first.  Their copied rows preserve the untagged P0+P1 projection
  // without pretending that a departed tag is a live R=0 tag.
  const std::size_t departed_offset = nodes.size();
  for (std::size_t base_index = 0U; base_index < base.nodes.size();
       ++base_index) {
    const auto& base_node = base.nodes[base_index];
    nodes.push_back(metrics::detail::TemporalNodeCore{
        tagged_state_value(base_index, BigNat{0U}, true), {},
        base_node.invariant_component, base_node.state_target_backlog,
        std::nullopt});
  }
  std::size_t row_atom_count = adapter.row_atom_count();
  std::size_t actual_maximum_row_width = adapter.maximum_row_width();
  for (std::size_t index = 0U; index < lifted_nodes.size(); ++index) {
    const auto& lifted = lifted_nodes[index];
    const auto& base_node = base.nodes[lifted.base_node_index];
    const auto& adapted_row = adapter.row(index);
    auto& output_row = nodes[index].transitions;
    output_row.reserve(adapted_row.size());
    for (const LazyLiftedTagAtomV1& adapted : adapted_row) {
      if (adapted.base_transition_index >= base_node.transitions.size()) {
        return fail<LiftedTagGraphV1>(
            "c23.fifo_lazy_transition_missing",
            "the cached lazy FIFO row names no base service atom",
            DiagnosticCategory::internal);
      }
      const auto& transition =
          base_node.transitions[adapted.base_transition_index];
      std::size_t successor_index =
          departed_offset + transition.successor_index;
      if (!adapted.tag_departed) {
        if (!adapted.live_successor_index.has_value() ||
            *adapted.live_successor_index >= lifted_nodes.size()) {
          return fail<LiftedTagGraphV1>(
              "c23.fifo_lift_successor_missing",
              "the cached lazy FIFO row omitted an exact live successor",
              DiagnosticCategory::internal);
        }
        successor_index = *adapted.live_successor_index;
      }
      MarkedFluxEdgeV1 edge = transition.edge;
      if (std::any_of(edge.marks.begin(), edge.marks.end(),
                      [&](const CausalMarkV1& retained) {
                        return retained.mark.mark == marker_id.value();
                      })) {
        return fail<LiftedTagGraphV1>(
            "c23.tag_departure_mark_collision",
            "the C21 retained-mark alphabet already contains the reserved "
            "C23 tagged-departure identity",
            DiagnosticCategory::internal);
      }
      edge.pre_state = nodes[index].decoded_state;
      edge.successor_state = nodes[successor_index].decoded_state;
      edge.marks.push_back(
          tag_departure_mark(marker_id.value(), adapted.tag_departed));
      output_row.push_back(metrics::detail::TemporalTransitionCore{
          successor_index, std::move(edge), transition.exact_mass});
    }
  }
  for (std::size_t base_index = 0U; base_index < base.nodes.size();
       ++base_index) {
    const auto& base_node = base.nodes[base_index];
    if (maximum_row_atoms_budget.has_value() &&
        base_node.transitions.size() > *maximum_row_atoms_budget) {
      return fail<LiftedTagGraphV1>(
          "c23.fifo_lift_row_width_budget_exceeded",
          "a passive FIFO terminal-extension row exceeds the authored max_row_atoms grant before materialization",
          DiagnosticCategory::resource_limit);
    }
    if (base_node.transitions.size() >
        std::numeric_limits<std::size_t>::max() - row_atom_count) {
      return fail<LiftedTagGraphV1>(
          "c23.fifo_lift_row_atom_count_overflow",
          "the terminal-extension FIFO row-atom count overflows size_t",
          DiagnosticCategory::resource_limit);
    }
    row_atom_count += base_node.transitions.size();
    actual_maximum_row_width = std::max(
        actual_maximum_row_width, base_node.transitions.size());
    if (row_atom_count > kMaximumEnumeratedPalmLabels) {
      return fail<LiftedTagGraphV1>(
          "c23.fifo_lift_row_atom_budget_exceeded",
          "the passive FIFO terminal-extension rows exceed the C23 "
          "materialization budget",
          DiagnosticCategory::resource_limit);
    }
    auto& output_row = nodes[departed_offset + base_index].transitions;
    output_row.reserve(base_node.transitions.size());
    for (const auto& transition : base_node.transitions) {
      MarkedFluxEdgeV1 edge = transition.edge;
      if (std::any_of(edge.marks.begin(), edge.marks.end(),
                      [&](const CausalMarkV1& retained) {
                        return retained.mark.mark == marker_id.value();
                      })) {
        return fail<LiftedTagGraphV1>(
            "c23.tag_departure_mark_collision",
            "the C21 retained-mark alphabet already contains the reserved "
            "C23 tagged-departure identity",
            DiagnosticCategory::internal);
      }
      const std::size_t successor_index =
          departed_offset + transition.successor_index;
      edge.pre_state = nodes[departed_offset + base_index].decoded_state;
      edge.successor_state = nodes[successor_index].decoded_state;
      edge.marks.push_back(tag_departure_mark(marker_id.value(), false));
      output_row.push_back(metrics::detail::TemporalTransitionCore{
          successor_index, std::move(edge), transition.exact_mass});
    }
  }

  std::vector<metrics::detail::TemporalEntranceAtomCore> entrance;
  entrance.reserve(initial.atoms.size());
  for (const TagInitialAtomV1& atom : initial.atoms) {
    const auto found = lifted_index.find(lifted_key(
        atom.continuation_index, atom.state.predecessors));
    if (found == lifted_index.end()) {
      return fail<LiftedTagGraphV1>(
          "c23.fifo_lift_entrance_missing",
          "the lifted graph omitted a positive FIFO entrance atom",
          DiagnosticCategory::internal);
    }
    entrance.push_back(metrics::detail::TemporalEntranceAtomCore{
        found->second, nodes[found->second].decoded_state,
        atom.exact_mass});
  }

  metrics::detail::TemporalSourceBindingV1 binding = base.binding;
  binding.kind = AuditedTemporalSourceKindV1::passive_fifo_tag;
  binding.source_fingerprint = source_fingerprint.value();
  binding.projection_fingerprint = initial.projection_fingerprint;
  binding.exact_state_schema_identity = exact_schema.value();
  binding.reduced_state_schema_identity = reduced_schema.value();
  binding.mark_schema_identity = mark_schema.value();
  binding.continuation_schema_identity = continuation_schema.value();
  binding.state_codec = CodecIdentityV1{std::string(kTagStateCodec), 1U};
  auto lifted_source =
      std::make_shared<const metrics::detail::TemporalSourceCore>(
          metrics::detail::TemporalSourceCore{
              std::move(binding), std::move(nodes), entrance, {},
              base.maximum_state_offset, base.maximum_edge_offset,
              maximum_states_budget, maximum_row_atoms_budget,
              true, true, true});
  auto audited = temporal::detail::c20_mint_passive_fifo_temporal_kernel(
      public_service, lifted_source);
  if (!audited) {
    return Result<LiftedTagGraphV1>::failure(audited.error());
  }
  auto initial_core =
      std::make_shared<const metrics::detail::InitialLawCore>(
          metrics::detail::InitialLawCore{
              InitialLawKindV1::fifo_tag, lifted_source, std::move(entrance),
              source_fingerprint.value(), initial.projection_fingerprint,
              true});
  InitialLaw closed_initial =
      detail::C23CoreAccess::initial_law(std::move(initial_core));
  return Result<LiftedTagGraphV1>::success(LiftedTagGraphV1{
      std::move(lifted_source), std::move(audited).value(),
      std::move(closed_initial), lifted_nodes.size(), maximum_rank,
      row_atom_count, actual_maximum_row_width});
}

struct PolynomialStateV1 final {
  std::size_t base_state;
  std::size_t remaining_predecessors;

  friend bool operator<(const PolynomialStateV1& left,
                        const PolynomialStateV1& right) noexcept {
    return std::tie(left.base_state, left.remaining_predecessors) <
           std::tie(right.base_state, right.remaining_predecessors);
  }
};

[[nodiscard]] Result<std::vector<ExactRational>> polynomial_fifo_tails(
    const metrics::detail::TemporalSourceCore& source,
    const std::size_t target_ordinal,
    const std::span<const TagInitialAtomV1> entrance,
    const std::size_t maximum_tail_index,
    const CoefficientWorkBudgetV1 budget) {
  try {
    std::map<PolynomialStateV1, ExactRational> current;
    for (const TagInitialAtomV1& atom : entrance) {
      auto remaining = bounded_size(atom.state.predecessors,
                                    "a polynomial FIFO predecessor rank",
                                    kMaximumEnumeratedPalmLabels);
      if (!remaining) {
        return Result<std::vector<ExactRational>>::failure(
            remaining.error());
      }
      const PolynomialStateV1 key{atom.continuation_index,
                                  remaining.value()};
      const auto [found, inserted] = current.emplace(key, atom.exact_mass);
      if (!inserted) {
        found->second = found->second + atom.exact_mass;
      }
      if (current.size() > budget.maximum_frontier_states) {
        return fail<std::vector<ExactRational>>(
            "c23.fifo_coefficient_frontier_budget_exceeded",
            "the optional FIFO coefficient frontier exceeds its configured "
            "state budget",
            DiagnosticCategory::resource_limit,
            {"frontier states " + std::to_string(current.size()),
             "limit " +
                 std::to_string(budget.maximum_frontier_states)});
      }
    }
    std::vector<ExactRational> tails;
    tails.reserve(maximum_tail_index + 1U);
    ExactRational initial_total = ExactRational::zero();
    for (const auto& [key, mass] : current) {
      static_cast<void>(key);
      initial_total = initial_total + mass;
    }
    tails.push_back(initial_total);
    std::size_t transition_work = 0U;
    for (std::size_t step = 0U; step < maximum_tail_index; ++step) {
      std::map<PolynomialStateV1, ExactRational> next;
      for (const auto& [state, state_mass] : current) {
        if (state.base_state >= source.nodes.size()) {
          return fail<std::vector<ExactRational>>(
              "c23.polynomial_state_out_of_range",
              "the coefficient evaluator received an invalid base state",
              DiagnosticCategory::internal);
        }
        for (const auto& transition :
             source.nodes[state.base_state].transitions) {
          if (transition_work >= budget.maximum_transition_work) {
            return fail<std::vector<ExactRational>>(
                "c23.fifo_coefficient_work_budget_exceeded",
                "the optional FIFO coefficient evaluator exhausted its "
                "transition-work budget",
                DiagnosticCategory::resource_limit,
                {"completed transition atoms " +
                     std::to_string(transition_work),
                 "limit " +
                     std::to_string(budget.maximum_transition_work)});
          }
          ++transition_work;
          if (transition.successor_index >= source.nodes.size()) {
            return fail<std::vector<ExactRational>>(
                "c23.polynomial_successor_out_of_range",
                "the coefficient evaluator received an invalid successor",
                DiagnosticCategory::internal);
          }
          if (target_ordinal >= transition.edge.target_departures.size()) {
            return fail<std::vector<ExactRational>>(
                "c23.polynomial_departure_mark_missing",
                "the coefficient evaluator lacks the selected departure "
                "mark",
                DiagnosticCategory::unavailable);
          }
          const std::size_t departure =
              transition.edge.target_departures[target_ordinal];
          if (departure > 1U) {
            return fail<std::vector<ExactRational>>(
                "c23.polynomial_departure_not_binary",
                "the FIFO coefficient evaluator requires binary service");
          }
          if (state.remaining_predecessors == 0U && departure == 1U) {
            continue;
          }
          const std::size_t successor_remaining =
              state.remaining_predecessors - departure;
          const PolynomialStateV1 successor{
              transition.successor_index, successor_remaining};
          const ExactRational mass = state_mass * transition.exact_mass;
          const auto [found, inserted] = next.emplace(successor, mass);
          if (!inserted) {
            found->second = found->second + mass;
          }
          if (next.size() > budget.maximum_frontier_states) {
            return fail<std::vector<ExactRational>>(
                "c23.fifo_coefficient_frontier_budget_exceeded",
                "the optional FIFO coefficient frontier exceeds its "
                "configured state budget",
                DiagnosticCategory::resource_limit,
                {"frontier states " + std::to_string(next.size()),
                 "limit " +
                     std::to_string(budget.maximum_frontier_states)});
          }
        }
      }
      ExactRational tail = ExactRational::zero();
      for (const auto& [key, mass] : next) {
        static_cast<void>(key);
        tail = tail + mass;
      }
      tails.push_back(std::move(tail));
      current = std::move(next);
    }
    return Result<std::vector<ExactRational>>::success(std::move(tails));
  } catch (const std::bad_alloc&) {
    return fail<std::vector<ExactRational>>(
        "c23.fifo_coefficient_allocation_failure",
        "the optional FIFO coefficient evaluator exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<std::vector<ExactRational>>(
        "c23.fifo_coefficient_exception",
        "the optional FIFO coefficient evaluator raised an unexpected "
        "exception",
        DiagnosticCategory::internal);
  }
}

struct ExactSquareSolutionV1 final {
  std::vector<ExactRational> values;
  std::size_t rank;
};

[[nodiscard]] Result<ExactSquareSolutionV1> solve_exact_square(
    std::vector<ExactRational> coefficients,
    std::vector<ExactRational> right_hand_side,
    const std::size_t dimension) {
  if (dimension == 0U) {
    return Result<ExactSquareSolutionV1>::success(
        ExactSquareSolutionV1{{}, 0U});
  }
  if (dimension > std::numeric_limits<std::size_t>::max() / dimension ||
      coefficients.size() != dimension * dimension ||
      right_hand_side.size() != dimension) {
    return fail<ExactSquareSolutionV1>(
        "c23.fifo_moment_linear_dimension_mismatch",
        "the exact FIFO moment solve received inconsistent dimensions",
        DiagnosticCategory::internal);
  }
  std::size_t rank = 0U;
  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension &&
           coefficients[pivot * dimension + column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return fail<ExactSquareSolutionV1>(
          "c23.fifo_moment_linear_system_singular",
          "the finite exact FIFO moment subsystem is singular",
          DiagnosticCategory::internal,
          {"pivot column " + std::to_string(column),
           "rank " + std::to_string(rank),
           "dimension " + std::to_string(dimension)});
    }
    ++rank;
    if (pivot != column) {
      for (std::size_t entry = 0U; entry < dimension; ++entry) {
        std::swap(coefficients[column * dimension + entry],
                  coefficients[pivot * dimension + entry]);
      }
      std::swap(right_hand_side[column], right_hand_side[pivot]);
    }
    const ExactRational pivot_value =
        coefficients[column * dimension + column];
    for (std::size_t entry = column; entry < dimension; ++entry) {
      auto quotient = checked_divide(
          coefficients[column * dimension + entry], pivot_value);
      if (!quotient) {
        return Result<ExactSquareSolutionV1>::failure(quotient.error());
      }
      coefficients[column * dimension + entry] =
          std::move(quotient).value();
    }
    auto rhs = checked_divide(right_hand_side[column], pivot_value);
    if (!rhs) {
      return Result<ExactSquareSolutionV1>::failure(rhs.error());
    }
    right_hand_side[column] = std::move(rhs).value();
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const ExactRational factor =
          coefficients[row * dimension + column];
      if (factor.is_zero()) {
        continue;
      }
      for (std::size_t entry = column; entry < dimension; ++entry) {
        coefficients[row * dimension + entry] =
            coefficients[row * dimension + entry] -
            factor * coefficients[column * dimension + entry];
      }
      right_hand_side[row] =
          right_hand_side[row] - factor * right_hand_side[column];
    }
  }
  return Result<ExactSquareSolutionV1>::success(
      ExactSquareSolutionV1{std::move(right_hand_side), rank});
}

[[nodiscard]] Result<ExactRational> binomial_rational(
    const std::size_t order, std::size_t choose) {
  choose = std::min(choose, order - choose);
  BigInt coefficient{1};
  for (std::size_t index = 1U; index <= choose; ++index) {
    coefficient *= BigInt(order - choose + index);
    coefficient /= BigInt(index);
  }
  return ExactRational::make(std::move(coefficient), BigInt{1});
}

[[nodiscard]] Result<DelayMomentV1> exact_fifo_moment(
    const LiftedTagGraphV1& graph, const BigNat& authored_order,
    const ExtendedNonnegativeV1& first_moment,
    std::size_t& remaining_moment_work) {
  auto converted = bounded_size(authored_order, "a FIFO delay moment order",
                                kMaximumExactMomentOrder);
  if (!converted) {
    return Result<DelayMomentV1>::failure(converted.error());
  }
  if (converted.value() == 0U) {
    return fail<DelayMomentV1>("c23.invalid_delay_moment_order",
                               "a FIFO delay moment order must be positive");
  }
  if (first_moment.status ==
      ExtendedNonnegativeStatusV1::positive_infinity) {
    return Result<DelayMomentV1>::success(DelayMomentV1{
        authored_order, DelayMomentStatusV1::positive_infinity,
        std::nullopt});
  }
  if (first_moment.status != ExtendedNonnegativeStatusV1::finite ||
      !first_moment.exact_value.has_value()) {
    return Result<DelayMomentV1>::success(DelayMomentV1{
        authored_order, DelayMomentStatusV1::unresolved, std::nullopt});
  }
  if (converted.value() == 1U) {
    return Result<DelayMomentV1>::success(DelayMomentV1{
        authored_order, DelayMomentStatusV1::established,
        first_moment.exact_value});
  }

  const std::size_t states = graph.live_state_count;
  if (!graph.source || states == 0U || states > graph.source->nodes.size()) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_lift_shape_mismatch",
        "the passive FIFO lift has no valid live-state domain",
        DiagnosticCategory::internal);
  }
  std::vector<ExactRational> entrance(states, ExactRational::zero());
  std::vector<bool> reachable(states, false);
  std::vector<std::size_t> reachable_states;
  for (const auto& atom : graph.source->stationary_entrance) {
    if (atom.node_index >= states) {
      return fail<DelayMomentV1>(
          "c23.fifo_moment_entrance_out_of_range",
          "the passive FIFO entrance names a non-live lifted state",
          DiagnosticCategory::internal);
    }
    entrance[atom.node_index] =
        entrance[atom.node_index] + atom.exact_mass;
    if (atom.exact_mass.is_positive() && !reachable[atom.node_index]) {
      reachable[atom.node_index] = true;
      reachable_states.push_back(atom.node_index);
    }
  }
  ExactRational entrance_total = ExactRational::zero();
  for (std::size_t state = 0U; state < states; ++state) {
    entrance_total = entrance_total + entrance[state];
  }
  if (!(entrance_total == ExactRational::one())) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_entrance_mass_mismatch",
        "the passive FIFO moment entrance does not have exact unit mass",
        DiagnosticCategory::internal);
  }

  std::size_t reachable_row_atom_count = 0U;
  for (std::size_t cursor = 0U; cursor < reachable_states.size(); ++cursor) {
    const std::size_t state = reachable_states[cursor];
    const std::size_t row_size =
        graph.source->nodes[state].transitions.size();
    if (row_size >
        std::numeric_limits<std::size_t>::max() -
            reachable_row_atom_count) {
      return fail<DelayMomentV1>(
          "c23.fifo_moment_row_work_overflow",
          "the reachable FIFO moment row-atom count overflows size_t",
          DiagnosticCategory::resource_limit);
    }
    reachable_row_atom_count += row_size;
    ExactRational row_total = ExactRational::zero();
    for (const auto& transition : graph.source->nodes[state].transitions) {
      if (transition.successor_index >= graph.source->nodes.size() ||
          !transition.exact_mass.is_positive()) {
        return fail<DelayMomentV1>(
            "c23.fifo_moment_row_invalid",
            "the exact FIFO moment recurrence received an invalid lifted "
            "transition row",
            DiagnosticCategory::internal,
            {"state index " + std::to_string(state)});
      }
      row_total = row_total + transition.exact_mass;
      if (transition.successor_index < states &&
          !reachable[transition.successor_index]) {
        reachable[transition.successor_index] = true;
        reachable_states.push_back(transition.successor_index);
      }
    }
    if (!(row_total == ExactRational::one())) {
      return fail<DelayMomentV1>(
          "c23.fifo_moment_row_mass_mismatch",
          "the exact FIFO moment recurrence requires unit-mass lifted "
          "transition rows",
          DiagnosticCategory::internal,
          {"state index " + std::to_string(state),
           "row mass " + row_total.to_canonical_string()});
    }
  }
  const std::size_t dimension = reachable_states.size();
  if (dimension != 0U &&
      dimension > std::numeric_limits<std::size_t>::max() / dimension) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_dimension_overflow",
        "the exact FIFO moment matrix dimension overflows size_t",
        DiagnosticCategory::resource_limit);
  }
  if (dimension != 0U &&
      dimension > kMaximumExactMomentMatrixCells / dimension) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_matrix_budget_exceeded",
        "the reachable exact FIFO moment subsystem exceeds the dense "
        "rational-matrix materialization budget",
        DiagnosticCategory::resource_limit,
        {"dimension " + std::to_string(dimension),
         "maximum cells " +
             std::to_string(kMaximumExactMomentMatrixCells)});
  }
  const std::size_t requested_order = converted.value();
  const std::size_t lower_order_pairs =
      requested_order % 2U == 0U
          ? (requested_order / 2U) * (requested_order - 1U)
          : requested_order * ((requested_order - 1U) / 2U);
  if (!consume_bounded_work(
          remaining_moment_work,
          {requested_order, dimension, dimension, dimension}) ||
      !consume_bounded_work(
          remaining_moment_work,
          {lower_order_pairs, reachable_row_atom_count}) ||
      !consume_bounded_work(remaining_moment_work,
                            {requested_order + 1U, dimension})) {
    return fail<DelayMomentV1>(
        "c23.fifo_moment_work_budget_exceeded",
        "the authorized higher FIFO moment exceeds the exact arithmetic "
        "work budget",
        DiagnosticCategory::resource_limit,
        {"order " + std::to_string(requested_order),
         "reachable dimension " + std::to_string(dimension),
         "reachable row atoms " +
             std::to_string(reachable_row_atom_count),
         "joint work budget " +
             std::to_string(kMaximumExactMomentArithmeticWork)});
  }
  std::vector<ExactRational> coefficients(
      dimension * dimension, ExactRational::zero());
  std::vector<std::optional<std::size_t>> local(states);
  for (std::size_t index = 0U; index < dimension; ++index) {
    local[reachable_states[index]] = index;
  }
  for (std::size_t row = 0U; row < dimension; ++row) {
    coefficients[row * dimension + row] = ExactRational::one();
    const std::size_t state = reachable_states[row];
    for (const auto& transition : graph.source->nodes[state].transitions) {
      if (transition.successor_index < states) {
        if (!local[transition.successor_index].has_value()) {
          return fail<DelayMomentV1>(
              "c23.fifo_moment_reachable_successor_missing",
              "the exact FIFO moment subsystem omitted a reachable live "
              "successor",
              DiagnosticCategory::internal);
        }
        const std::size_t column = *local[transition.successor_index];
        coefficients[row * dimension + column] =
            coefficients[row * dimension + column] -
            transition.exact_mass;
      }
    }
  }

  std::vector<std::vector<ExactRational>> moments;
  moments.reserve(converted.value() + 1U);
  moments.emplace_back(dimension, ExactRational::one());
  for (std::size_t order = 1U; order <= converted.value(); ++order) {
    std::vector<ExactRational> rhs(dimension, ExactRational::one());
    for (std::size_t local_state = 0U; local_state < dimension;
         ++local_state) {
      const std::size_t state = reachable_states[local_state];
      for (std::size_t lower = 1U; lower < order; ++lower) {
        auto coefficient = binomial_rational(order, lower);
        if (!coefficient) {
          return Result<DelayMomentV1>::failure(coefficient.error());
        }
        ExactRational propagated = ExactRational::zero();
        for (const auto& transition :
             graph.source->nodes[state].transitions) {
          if (transition.successor_index < states) {
            if (!local[transition.successor_index].has_value()) {
              return fail<DelayMomentV1>(
                  "c23.fifo_moment_reachable_successor_missing",
                  "the exact FIFO moment recurrence omitted a reachable "
                  "live successor",
                  DiagnosticCategory::internal);
            }
            propagated =
                propagated + transition.exact_mass *
                                 moments[lower]
                                        [*local[transition.successor_index]];
          }
        }
        rhs[local_state] =
            rhs[local_state] + coefficient.value() * propagated;
      }
    }
    auto solved = solve_exact_square(coefficients, std::move(rhs),
                                     dimension);
    if (!solved) {
      return Result<DelayMomentV1>::failure(solved.error());
    }
    std::vector<ExactRational> values(dimension, ExactRational::zero());
    for (std::size_t local_state = 0U; local_state < dimension;
         ++local_state) {
      if (!solved.value().values[local_state].is_nonnegative()) {
        return fail<DelayMomentV1>(
            "c23.negative_exact_fifo_moment",
            "the exact FIFO moment recurrence produced a negative value",
            DiagnosticCategory::internal,
            {"state index " +
                 std::to_string(reachable_states[local_state]),
             "order " + std::to_string(order)});
      }
      values[local_state] = solved.value().values[local_state];
    }
    moments.push_back(std::move(values));
    if (order == 1U) {
      ExactRational solved_first = ExactRational::zero();
      for (std::size_t state = 0U; state < states; ++state) {
        if (entrance[state].is_positive()) {
          solved_first = solved_first +
                         entrance[state] * moments.back()[*local[state]];
        }
      }
      if (!(solved_first == *first_moment.exact_value)) {
        return fail<DelayMomentV1>(
            "c23.fifo_moment_first_order_crosscheck_failure",
            "the exact higher-moment recurrence disagrees with C22's "
            "minimal first-moment potential",
            DiagnosticCategory::internal);
      }
    }
  }
  ExactRational result = ExactRational::zero();
  for (std::size_t state = 0U; state < states; ++state) {
    if (entrance[state].is_positive()) {
      result = result +
               entrance[state] * moments.back()[*local[state]];
    }
  }
  return Result<DelayMomentV1>::success(DelayMomentV1{
      authored_order, DelayMomentStatusV1::established,
      std::move(result)});
}

}  // namespace

namespace {

[[nodiscard]] Result<DelayLaw> evaluate_fifo_delay_distribution_impl(
    const TagInitialLaw& initial_law,
    const TemporalServiceKernel& service_kernel,
    const HorizonSpec& horizon, const SolverPolicy& policy,
    const std::optional<std::size_t> maximum_states_budget,
    const std::optional<std::size_t> maximum_row_atoms_budget,
    std::size_t* const actual_state_count,
    std::size_t* const actual_maximum_row_atoms) {
  begin_fifo_execution_trace();
  const CoefficientWorkBudgetV1 coefficient_budget =
      coefficient_work_budget();
  const bool force_coefficient_mismatch =
      consume_coefficient_mismatch_override();
  try {
    const auto& initial = detail::C23CoreAccess::core(initial_law);
    const auto& service = detail::C23CoreAccess::core(service_kernel);
    if (!initial.source || !service.source ||
        !same_source_owner(initial.source, service.source) ||
        initial.projection_fingerprint != service.projection_fingerprint ||
        initial.projection_fingerprint != initial.source->fingerprint ||
        service.continuation_schema_identity !=
            initial.source->provider_binding.continuation_schema_identity ||
        service.target_selection_identity !=
            initial.source->provider_binding.target_selection_identity ||
        service.target_service_schema_identity !=
            initial.source->provider_binding.target_service_schema_identity) {
      return fail<DelayLaw>(
          "c23.fifo_service_kernel_binding_mismatch",
          "the FIFO tag entrance and chronological service kernel must share "
          "one exact C21 source, projection, target, timing, and schema");
    }
    if (!initial.assumptions.global_fifo ||
        !initial.assumptions.unit_packets || !initial.assumptions.lossless ||
        !initial.assumptions.finite_batches_almost_surely ||
        !initial.assumptions.positive_finite_admission_intensity ||
        !initial.assumptions.full_history_predictive_service ||
        !initial.assumptions.passive_tag) {
      return fail<DelayLaw>(
          "c23.fifo_delay_hypotheses_unavailable",
          "the tag entrance does not retain every mathematical premise for "
          "the passive FIFO delay recursion",
          DiagnosticCategory::unavailable);
    }
    if (initial.authorized_outputs.empty()) {
      return fail<DelayLaw>(
          "c23.fifo_request_selection_required",
          "the accepted analysis contains multiple FIFO Palm entrance "
          "conditions; select one authorized condition before evaluation",
          DiagnosticCategory::unavailable);
    }
    if (policy.analysis_fingerprint !=
        initial.source->provider_binding.authored_analysis_identity) {
      return fail<DelayLaw>(
          "c23.fifo_solver_policy_binding_mismatch",
          "the FIFO evaluator requires the solver policy of the originating "
          "authored analysis");
    }
    std::optional<BigNat> authorized_finite_horizon;
    bool mean_requested = false;
    for (const FifoDelayOutputV1& authorized :
         initial.authorized_outputs) {
      std::visit(
          [&](const auto& output) {
            using Output = std::decay_t<decltype(output)>;
            if constexpr (std::is_same_v<Output,
                                         FifoDelayPmfOutputV1> ||
                          std::is_same_v<Output,
                                         FifoDelayTailOutputV1>) {
              if (!authorized_finite_horizon.has_value() ||
                  *authorized_finite_horizon < output.horizon) {
                authorized_finite_horizon = output.horizon;
              }
            } else if constexpr (std::is_same_v<
                                     Output, FifoDelayMomentOutputV1>) {
              // An order-p finite-moment contract (p>=1) implies the first
              // moment needed by C22's stopped evaluation.
              mean_requested = true;
            }
          },
          authorized);
    }
    const bool exact_horizon_match =
        !authorized_finite_horizon.has_value() ||
        *authorized_finite_horizon == horizon.maximum_tail_index;
    if (!exact_horizon_match ||
        horizon.include_infinite_horizon_mean != mean_requested ||
        !horizon.include_eventual_typed_exit_probabilities) {
      return fail<DelayLaw>(
          "c23.fifo_horizon_not_authorized",
          "the FIFO horizon and infinite-horizon flags must match the "
          "accepted C14 output set; defect classification is mandatory",
          DiagnosticCategory::unavailable);
    }
    auto maximum = bounded_size(horizon.maximum_tail_index,
                                "the FIFO delay tail horizon");
    if (!maximum) {
      return Result<DelayLaw>::failure(maximum.error());
    }
    if (maximum.value() == std::numeric_limits<std::size_t>::max()) {
      return fail<DelayLaw>(
          "c23.fifo_tail_horizon_overflow",
          "the FIFO tail horizon leaves no addressable index-zero entry",
          DiagnosticCategory::resource_limit);
    }

    auto lifted = build_lifted_tag_graph(
        initial, service_kernel, service, maximum_states_budget,
        maximum_row_atoms_budget);
    if (!lifted) {
      return Result<DelayLaw>::failure(lifted.error());
    }
    auto marker_id = tag_departure_mark_id();
    if (!marker_id) {
      return Result<DelayLaw>::failure(marker_id.error());
    }
    SafeSet safe{AnyStatePredicateV1{}};
    AbsorptionMarks absorption{{TypedAbsorptionMarkV1{
        std::string(kTagDepartureType),
        AnyStatePredicateV1{},
        ExactRuntimeMarkPredicateV1{
            marker_id.value(),
            CodecIdentityV1{std::string(kTagDepartureCodec), 1U},
            {std::byte{1}}}}}};
    trace_construct_killed_kernel();
    auto killed = construct_killed_kernel(lifted.value().audited_kernel,
                                          safe, absorption);
    if (!killed) {
      return Result<DelayLaw>::failure(killed.error());
    }
    trace_evaluate_hit_survival_absorption();
    auto stopped = evaluate_hit_survival_absorption(
        killed.value(), lifted.value().initial_law, horizon, policy);
    if (!stopped) {
      return Result<DelayLaw>::failure(stopped.error());
    }

    const LabelledOccupancyEvidenceV1& labelled =
        initial.stationary_queue_law.labelled_evidence();
    const bool stationary_labelled_occupancy =
        labelled.two_sided_stationary &&
        labelled.finite_slot_occupancy_almost_surely &&
        labelled.occupancy_equals_admitted_not_departed &&
        labelled.every_present_label_has_finite_admission_epoch &&
        labelled.lossless && labelled.unit_packets;
    if (stationary_labelled_occupancy &&
        (stopped.value().absorption_status ==
             AbsorptionStatusV1::defective ||
         !stopped.value().exact_defect_probability.is_zero())) {
      return fail<DelayLaw>(
          "c23.stationary_fifo_nondefectiveness_contradiction",
          "a two-sided stationary finite labelled-occupancy FIFO entrance "
          "must have zero infinite-delay Palm mass",
          DiagnosticCategory::internal);
    }
    const AbsorptionStatusV1 absorption_status =
        stationary_labelled_occupancy
            ? AbsorptionStatusV1::nondefective
            : stopped.value().absorption_status;
    const ExactRational proven_defective_mass =
        stationary_labelled_occupancy
            ? ExactRational::zero()
            : stopped.value().exact_defect_probability;

    bool coefficient_performed = false;
    bool coefficient_exact = false;
    std::optional<Diagnostic> coefficient_diagnostic;
    {
      trace_coefficient_backend();
      auto coefficient_tails = polynomial_fifo_tails(
          *initial.source->temporal_source, initial.target_ordinal,
          initial.atoms, maximum.value(), coefficient_budget);
      coefficient_performed = coefficient_tails.has_value();
      if (!coefficient_performed) {
        coefficient_diagnostic.emplace(
            std::move(coefficient_tails.error()));
      } else {
        coefficient_exact =
            coefficient_tails.value().size() ==
            stopped.value().survival_tails.size();
        if (coefficient_exact) {
          for (std::size_t index = 0U;
               index < coefficient_tails.value().size(); ++index) {
            coefficient_exact =
                coefficient_exact &&
                coefficient_tails.value()[index] ==
                    stopped.value().survival_tails[index].exact_probability;
          }
        }
        if (force_coefficient_mismatch) {
          coefficient_exact = false;
        }
      }
    }
    if (coefficient_performed && !coefficient_exact) {
      coefficient_diagnostic = diagnostic(
          DiagnosticCategory::internal,
          "c23.fifo_coefficient_crosscheck_failure",
          "the optional chronological departure-polynomial expansion "
          "disagrees with the authoritative explicit passive-tag killed "
          "kernel; coefficient access is disabled");
    }

    std::vector<DelayTailV1> tails;
    tails.reserve(stopped.value().survival_tails.size());
    for (const SurvivalTailV1& tail : stopped.value().survival_tails) {
      tails.push_back(DelayTailV1{tail.index, tail.exact_probability});
    }
    std::vector<DelayMassV1> pmf;
    pmf.reserve(maximum.value());
    for (const TypedAbsorptionMassV1& mass :
         stopped.value().absorption_masses) {
      if (mass.type_id == kTagDepartureType) {
        pmf.push_back(
            DelayMassV1{mass.hitting_time, mass.exact_probability});
      }
    }
    if (pmf.size() != maximum.value() ||
        tails.size() != maximum.value() + 1U) {
      return fail<DelayLaw>(
          "c23.fifo_stopped_output_shape_mismatch",
          "the C22 stopped result did not return one FIFO tail per requested "
          "index and one tagged-departure mass per completed slot",
          DiagnosticCategory::internal);
    }
    for (std::size_t index = 0U; index < pmf.size(); ++index) {
      if (!(tails[index].exact_probability -
                tails[index + 1U].exact_probability ==
            pmf[index].exact_probability) ||
          !(pmf[index].sojourn_slots == BigNat{index + 1U})) {
        return fail<DelayLaw>(
            "c23.fifo_tail_pmf_identity_failure",
            "the exact C22 result violates P(T=k+1)=q_k-q_(k+1)",
            DiagnosticCategory::internal,
            {"step " + std::to_string(index + 1U)});
      }
    }
    ExactRational maximum_row_residual = ExactRational::zero();
    for (const KilledRowDiagnosticsV1& row :
         killed.value().row_diagnostics()) {
      maximum_row_residual =
          std::max(maximum_row_residual,
                   absolute_value(row.exact_balance_residual));
    }
    ExactRational unresolved = tails.back().exact_probability;
    if (absorption_status != AbsorptionStatusV1::not_established) {
      if (proven_defective_mass > unresolved) {
        return fail<DelayLaw>(
            "c23.fifo_defect_exceeds_finite_tail",
            "the exact eventual defect exceeds the finite-horizon survivor "
            "mass",
            DiagnosticCategory::internal);
      }
      unresolved = unresolved - proven_defective_mass;
    }
    ExtendedNonnegativeV1 mean_sojourn =
        stopped.value().mean_stopping_time;
    if (absorption_status == AbsorptionStatusV1::defective &&
        proven_defective_mass.is_positive()) {
      mean_sojourn = ExtendedNonnegativeV1{
          ExtendedNonnegativeStatusV1::positive_infinity, std::nullopt};
    }
    std::vector<DelayMomentV1> requested_moments;
    std::size_t remaining_moment_work =
        kMaximumExactMomentArithmeticWork;
    for (const FifoDelayOutputV1& authorized :
         initial.authorized_outputs) {
      if (const auto* moment =
              std::get_if<FifoDelayMomentOutputV1>(&authorized)) {
        auto evaluated = exact_fifo_moment(
            lifted.value(), moment->order, mean_sojourn,
            remaining_moment_work);
        if (!evaluated) {
          return Result<DelayLaw>::failure(evaluated.error());
        }
        requested_moments.push_back(std::move(evaluated).value());
      }
    }
    const DelayLawDiagnosticsV1 diagnostics{
        ExactRational::zero(), maximum_row_residual,
        killed.value().state_count(), lifted.value().row_atom_count,
        lifted.value().maximum_initial_rank, maximum.value(),
        coefficient_performed, coefficient_exact,
        std::move(coefficient_diagnostic),
        initial.conditioning.has_value(),
        "early_service_late_admission:first_eligible_t_plus_1:T_equals_sigma_"
        "plus_1"};
    auto core = std::make_shared<const metrics::detail::DelayLawCore>(
        metrics::detail::DelayLawCore{
            std::move(tails), std::move(pmf), unresolved,
            proven_defective_mass, absorption_status,
            std::move(mean_sojourn), horizon, diagnostics,
            stopped.value(), initial.admission_rate,
            initial.stationary_queue_law, initial.authorized_outputs,
            std::move(requested_moments), initial.conditioning,
            !initial.conditioning.has_value(), initial.projection_fingerprint,
            lifted.value().source->binding.source_fingerprint,
            initial.target_ordinal});
    if (actual_state_count != nullptr) {
      *actual_state_count = lifted.value().source->nodes.size();
    }
    if (actual_maximum_row_atoms != nullptr) {
      *actual_maximum_row_atoms = lifted.value().maximum_row_width;
    }
    return Result<DelayLaw>::success(
        detail::C23CoreAccess::delay_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<DelayLaw>(
        "c23.fifo_delay_allocation_failure",
        "evaluating the passive FIFO delay law exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<DelayLaw>(
        "c23.fifo_delay_exception",
        "FIFO delay evaluation raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<DelayLaw> evaluate_fifo_delay_distribution(
    const TagInitialLaw& initial_law,
    const TemporalServiceKernel& service_kernel,
    const HorizonSpec& horizon, const SolverPolicy& policy) {
  return evaluate_fifo_delay_distribution_impl(
      initial_law, service_kernel, horizon, policy, std::nullopt,
      std::nullopt, nullptr, nullptr);
}

Result<metrics::detail::BoundedFifoDelayLawV1>
metrics::detail::evaluate_fifo_delay_distribution_bounded(
    const TagInitialLaw& initial_law,
    const TemporalServiceKernel& service_kernel,
    const HorizonSpec& horizon, const SolverPolicy& policy,
    const std::size_t maximum_states,
    const std::size_t maximum_row_atoms) {
  std::size_t actual_states = 0U;
  std::size_t actual_row_atoms = 0U;
  auto law = evaluate_fifo_delay_distribution_impl(
      initial_law, service_kernel, horizon, policy, maximum_states,
      maximum_row_atoms, &actual_states, &actual_row_atoms);
  if (!law) {
    return Result<BoundedFifoDelayLawV1>::failure(law.error());
  }
  return Result<BoundedFifoDelayLawV1>::success(
      BoundedFifoDelayLawV1{
          std::move(law).value(), actual_states, actual_row_atoms});
}

Diagnostic verify_little_identity(const StationaryQueueLaw& queue_law,
                                  const AdmissionRate& rate,
                                  const DelayLaw& delay_law) {
  const auto& queue = detail::C23CoreAccess::core(queue_law);
  const auto& admission = detail::C23CoreAccess::core(rate);
  const auto& delay = detail::C23CoreAccess::core(delay_law);
  const auto& retained_queue =
      detail::C23CoreAccess::core(delay.stationary_queue_law);
  const auto& retained_rate =
      detail::C23CoreAccess::core(delay.admission_rate);
  if (!same_source_owner(queue.source, admission.source) ||
      !same_source_owner(queue.source, retained_queue.source) ||
      !same_source_owner(admission.source, retained_rate.source) ||
      queue.projection_fingerprint != admission.projection_fingerprint ||
      queue.projection_fingerprint != delay.projection_fingerprint ||
      queue.target_ordinal != admission.target_ordinal ||
      queue.target_ordinal != delay.target_ordinal ||
      queue.fingerprint != retained_queue.fingerprint ||
      admission.fingerprint != retained_rate.fingerprint) {
    return diagnostic(
        DiagnosticCategory::input_validation,
        "c23.little_identity_binding_mismatch",
        "Little verification requires the queue law, admission rate, and "
        "delay law of the same projection and target");
  }
  if (!delay.unconditioned_all_admissions || delay.conditioning.has_value()) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_conditioned_delay_nonapplicable",
        "aggregate Little identity uses the unconditioned all-admission Palm "
        "delay; a rank, batch, phase, or class-conditioned delay is not "
        "applicable with the total admission rate");
  }
  const auto& evidence = queue.labelled_evidence;
  if (!evidence.two_sided_stationary ||
      !evidence.finite_slot_occupancy_almost_surely ||
      !evidence.occupancy_equals_admitted_not_departed ||
      !evidence.every_present_label_has_finite_admission_epoch ||
      !evidence.lossless || !evidence.unit_packets) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_labelled_occupancy_unavailable",
        "the queue law does not establish the two-sided stationary labelled-"
        "occupancy hypotheses required for Little identity");
  }
  if (!admission.exact_value.is_positive() ||
      !finite_positive_image(admission.exact_value)) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_admission_rate_unavailable",
        "Little identity requires a positive finite admission intensity");
  }

  const ExtendedNonnegativeV1& mean_queue = queue.mean_backlog;
  const ExtendedNonnegativeV1& mean_delay = delay.mean_sojourn;
  if (mean_queue.status == ExtendedNonnegativeStatusV1::not_established ||
      mean_queue.status ==
          ExtendedNonnegativeStatusV1::numerically_unresolved ||
      mean_delay.status == ExtendedNonnegativeStatusV1::not_established ||
      mean_delay.status ==
          ExtendedNonnegativeStatusV1::numerically_unresolved) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_moment_unresolved",
        "Little identity is structurally applicable, but one of E[N] or "
        "E^A[T] is not established");
  }
  if (mean_queue.status == ExtendedNonnegativeStatusV1::positive_infinity &&
      mean_delay.status == ExtendedNonnegativeStatusV1::positive_infinity) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_extended_infinite_structural",
        "the labelled identity is structurally applicable in [0,infinity], "
        "but infinity equals infinity is not a finite numerical "
        "verification");
  }
  if (mean_queue.status == ExtendedNonnegativeStatusV1::positive_infinity ||
      mean_delay.status == ExtendedNonnegativeStatusV1::positive_infinity) {
    return diagnostic(
        DiagnosticCategory::input_validation,
        "c23.little_identity_extended_value_mismatch",
        "one side of E[N]=lambda E^A[T] is finite and the other is positive "
        "infinity");
  }
  if (!mean_queue.exact_value.has_value() ||
      !mean_delay.exact_value.has_value()) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_exact_moment_unavailable",
        "finite Little verification requires exact values for both moments");
  }
  const ExactRational right =
      admission.exact_value * *mean_delay.exact_value;
  const ExactRational residual = *mean_queue.exact_value - right;
  if (!residual.is_zero()) {
    return diagnostic(
        DiagnosticCategory::input_validation,
        "c23.little_identity_mismatch",
        "the exact stationary labelled counts do not satisfy "
        "E[N]=lambda E^A[T]",
        {"E[N] " + mean_queue.exact_value->to_canonical_string(),
         "lambda E^A[T] " + right.to_canonical_string(),
         "exact residual " + residual.to_canonical_string()});
  }
  const long double left_image = mean_queue.exact_value->to_long_double();
  const long double right_image = right.to_long_double();
  if (!std::isfinite(left_image) || !std::isfinite(right_image)) {
    return diagnostic(
        DiagnosticCategory::unavailable,
        "c23.little_identity_numerical_image_unavailable",
        "the exact finite Little identity holds, but its long-double images "
        "are not finite");
  }
  return diagnostic(
      DiagnosticCategory::information,
      "c23.little_identity_verified",
      "the exact finite stationary labelled identity E[N]=lambda E^A[T] "
      "is verified",
      {"exact residual 0/1", "numerical residual " +
                                  std::to_string(left_image - right_image)});
}

#if defined(MWPERF_C23_TEST_SEAMS)
namespace testing {

void C23FixtureAccess::limit_next_coefficient_backend(
    const std::size_t maximum_frontier_states,
    const std::size_t maximum_transition_work) noexcept {
  g_next_coefficient_work_budget = CoefficientWorkBudgetV1{
      maximum_frontier_states, maximum_transition_work};
}

void C23FixtureAccess::mismatch_next_coefficient_crosscheck() noexcept {
  g_mismatch_next_coefficient_crosscheck = true;
}

std::vector<C23ExecutionStageV1>
C23FixtureAccess::last_fifo_execution_trace() {
  return g_fifo_execution_trace;
}

Result<C23SyntheticAdmissionPalmInspectionV1>
C23FixtureAccess::inspect_admission_palm(
    std::vector<C23SyntheticAdmissionEdgeV1> edges) {
  try {
    ExactRational stationary_total = ExactRational::zero();
    ExactRational intensity = ExactRational::zero();
    std::size_t label_count = 0U;
    for (const auto& edge : edges) {
      if (!edge.exact_slot_mass.is_nonnegative()) {
        return fail<C23SyntheticAdmissionPalmInspectionV1>(
            "c23.test_negative_slot_mass",
            "synthetic stationary slot masses must be nonnegative");
      }
      if (edge.actual_departure > 1U) {
        return fail<C23SyntheticAdmissionPalmInspectionV1>(
            "c23.test_nonbinary_departure",
            "synthetic unit-packet departure marks must be binary");
      }
      auto after = checked_subtract(edge.prearrival_backlog,
                                    BigNat{edge.actual_departure});
      if (!after) {
        return fail<C23SyntheticAdmissionPalmInspectionV1>(
            "c23.test_departure_exceeds_backlog",
            "a synthetic departure exceeds its predecision backlog");
      }
      auto batch = bounded_size(edge.arrival_batch, "a synthetic batch",
                                kMaximumEnumeratedPalmLabels);
      if (!batch) {
        return Result<C23SyntheticAdmissionPalmInspectionV1>::failure(
            batch.error());
      }
      if (batch.value() > kMaximumEnumeratedPalmLabels - label_count) {
        return fail<C23SyntheticAdmissionPalmInspectionV1>(
            "c23.test_label_budget_exceeded",
            "synthetic admission labels exceed the test-seam budget",
            DiagnosticCategory::resource_limit);
      }
      label_count += batch.value();
      auto batch_rational = natural_rational(edge.arrival_batch);
      if (!batch_rational) {
        return Result<C23SyntheticAdmissionPalmInspectionV1>::failure(
            batch_rational.error());
      }
      stationary_total = stationary_total + edge.exact_slot_mass;
      intensity = intensity + edge.exact_slot_mass * batch_rational.value();
    }
    if (!(stationary_total == ExactRational::one())) {
      return fail<C23SyntheticAdmissionPalmInspectionV1>(
          "c23.test_stationary_mass_not_one",
          "synthetic stationary edge masses must sum exactly to one");
    }
    if (!intensity.is_positive()) {
      return fail<C23SyntheticAdmissionPalmInspectionV1>(
          "c23.test_zero_admission_intensity",
          "synthetic admission Palm inspection requires positive intensity",
          DiagnosticCategory::unavailable);
    }
    std::vector<C23SyntheticPalmAtomInspectionV1> atoms;
    atoms.reserve(label_count);
    ExactRational total = ExactRational::zero();
    for (std::size_t index = 0U; index < edges.size(); ++index) {
      auto batch = bounded_size(edges[index].arrival_batch,
                                "a synthetic batch",
                                kMaximumEnumeratedPalmLabels);
      if (!batch) {
        return Result<C23SyntheticAdmissionPalmInspectionV1>::failure(
            batch.error());
      }
      auto per_label = checked_divide(edges[index].exact_slot_mass, intensity);
      if (!per_label) {
        return Result<C23SyntheticAdmissionPalmInspectionV1>::failure(
            per_label.error());
      }
      auto after_service = checked_subtract(
          edges[index].prearrival_backlog,
          BigNat{edges[index].actual_departure});
      if (!after_service) {
        return Result<C23SyntheticAdmissionPalmInspectionV1>::failure(
            after_service.error());
      }
      const BigNat first_eligible =
          after_service.value() + edges[index].arrival_batch;
      for (std::size_t rank = 1U; rank <= batch.value(); ++rank) {
        const BigNat rank_value{rank};
        auto rank_minus_one = checked_subtract(rank_value, BigNat{1U});
        if (!rank_minus_one) {
          return Result<C23SyntheticAdmissionPalmInspectionV1>::failure(
              rank_minus_one.error());
        }
        atoms.push_back(C23SyntheticPalmAtomInspectionV1{
            index, edges[index].arrival_batch, rank_value, first_eligible,
            after_service.value() + rank_minus_one.value(),
            per_label.value()});
        total = total + per_label.value();
      }
    }
    if (!(total == ExactRational::one())) {
      return fail<C23SyntheticAdmissionPalmInspectionV1>(
          "c23.test_palm_normalization_failure",
          "synthetic labelled Palm masses do not sum exactly to one",
          DiagnosticCategory::internal);
    }
    return Result<C23SyntheticAdmissionPalmInspectionV1>::success(
        C23SyntheticAdmissionPalmInspectionV1{
            intensity, std::move(atoms), total});
  } catch (const std::bad_alloc&) {
    return fail<C23SyntheticAdmissionPalmInspectionV1>(
        "c23.test_palm_allocation_failure",
        "synthetic Palm inspection exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<StationaryMarkedEdge>
C23FixtureAccess::with_synthetic_admission_edges(
    const StationaryMarkedEdge& seed,
    std::vector<C23SyntheticAdmissionEdgeV1> edges) {
  try {
    const auto& original = detail::C23CoreAccess::core(seed);
    if (!original.source || original.source->atoms.empty() || edges.empty() ||
        original.source->provider_binding.target_selection.ordered_targets
            .empty()) {
      return fail<StationaryMarkedEdge>(
          "c23.test_synthetic_admission_seed_invalid",
          "synthetic admission edges require a nonempty real C21 marked-edge "
          "source with a selected target");
    }
    ExactRational exact_total = ExactRational::zero();
    for (const auto& edge : edges) {
      if (!edge.exact_slot_mass.is_nonnegative() ||
          edge.actual_departure > 1U) {
        return fail<StationaryMarkedEdge>(
            "c23.test_synthetic_admission_edge_invalid",
            "synthetic admission edges require nonnegative mass and binary "
            "departure");
      }
      auto after_service = checked_subtract(
          edge.prearrival_backlog, BigNat{edge.actual_departure});
      if (!after_service) {
        return fail<StationaryMarkedEdge>(
            "c23.test_synthetic_admission_departure_exceeds_backlog",
            "a synthetic admission departure exceeds its predecision "
            "backlog");
      }
      const long double image = edge.exact_slot_mass.to_long_double();
      if (!std::isfinite(image) || image < 0.0L ||
          (edge.exact_slot_mass.is_positive() && image == 0.0L)) {
        return fail<StationaryMarkedEdge>(
            "c23.test_synthetic_admission_numerical_image_unavailable",
            "a synthetic exact slot mass has no finite faithful numerical "
            "image",
            DiagnosticCategory::unavailable);
      }
      exact_total = exact_total + edge.exact_slot_mass;
    }
    if (!(exact_total == ExactRational::one())) {
      return fail<StationaryMarkedEdge>(
          "c23.test_synthetic_admission_mass_not_one",
          "synthetic stationary admission edge masses must sum exactly to "
          "one");
    }

    auto source_value = *original.source;
    const auto templates = source_value.atoms;
    source_value.atoms.clear();
    source_value.atoms.reserve(edges.size());
    for (std::size_t index = 0U; index < edges.size(); ++index) {
      auto atom = templates[index % templates.size()];
      if (atom.reward_edge.prearrival_target_backlog.empty() ||
          atom.reward_edge.target_departures.empty() ||
          atom.reward_edge.target_arrivals.empty()) {
        return fail<StationaryMarkedEdge>(
            "c23.test_synthetic_admission_target_marks_missing",
            "the real C21 seed does not retain target-zero admission marks",
            DiagnosticCategory::unavailable);
      }
      atom.exact_mass = edges[index].exact_slot_mass;
      atom.numerical_mass = edges[index].exact_slot_mass.to_long_double();
      atom.numerical_image_status =
          NumericalProbabilityImageStatusV1::finite;
      atom.reward_edge.prearrival_target_backlog[0U] =
          edges[index].prearrival_backlog;
      atom.reward_edge.target_departures[0U] =
          edges[index].actual_departure;
      atom.reward_edge.target_arrivals[0U] = edges[index].arrival_batch;
      source_value.atoms.push_back(std::move(atom));
    }
    auto source = std::make_shared<const
        stationary::detail::StationaryProjectionSourceCore>(
        std::move(source_value));
    auto edge_value = original;
    edge_value.source = std::move(source);
    auto edge_core = std::make_shared<const
        stationary::detail::StationaryMarkedEdgeCore>(
        std::move(edge_value));
    return Result<StationaryMarkedEdge>::success(
        detail::C23CoreAccess::stationary_marked_edge(
            std::move(edge_core)));
  } catch (const std::bad_alloc&) {
    return fail<StationaryMarkedEdge>(
        "c23.test_synthetic_admission_allocation_failure",
        "constructing synthetic admission edge fixtures exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<StationaryMarkedEdge>(
        "c23.test_synthetic_admission_exception",
        "constructing synthetic admission edge fixtures raised an unexpected "
        "exception",
        DiagnosticCategory::internal);
  }
}

Result<std::vector<ExactRational>>
C23FixtureAccess::departure_polynomial_tails(
    std::vector<C23SyntheticServiceStateV1> states,
    std::vector<C23SyntheticPolynomialEntranceV1> entrance,
    const std::size_t maximum_tail_index) {
  try {
    if (states.empty()) {
      return fail<std::vector<ExactRational>>(
          "c23.test_empty_polynomial_source",
          "the synthetic polynomial source must be nonempty");
    }
    for (const auto& state : states) {
      ExactRational row_total = ExactRational::zero();
      for (const auto& transition : state.transitions) {
        if (transition.successor_index >= states.size() ||
            transition.departure > 1U ||
            !transition.exact_mass.is_nonnegative()) {
          return fail<std::vector<ExactRational>>(
              "c23.test_invalid_polynomial_row",
              "synthetic polynomial rows require in-range successors, "
              "binary departures, and nonnegative masses");
        }
        row_total = row_total + transition.exact_mass;
      }
      if (!(row_total == ExactRational::one())) {
        return fail<std::vector<ExactRational>>(
            "c23.test_polynomial_row_mass_not_one",
            "each synthetic polynomial row must sum exactly to one");
      }
    }
    std::map<PolynomialStateV1, ExactRational> current;
    ExactRational entrance_total = ExactRational::zero();
    for (const auto& atom : entrance) {
      if (atom.state_index >= states.size() ||
          !atom.exact_mass.is_nonnegative()) {
        return fail<std::vector<ExactRational>>(
            "c23.test_invalid_polynomial_entrance",
            "a synthetic polynomial entrance has an invalid state or mass");
      }
      const PolynomialStateV1 key{atom.state_index, atom.predecessors};
      const auto found = current.find(key);
      if (found == current.end()) {
        current.emplace(key, atom.exact_mass);
      } else {
        found->second = found->second + atom.exact_mass;
      }
      entrance_total = entrance_total + atom.exact_mass;
    }
    if (!(entrance_total == ExactRational::one())) {
      return fail<std::vector<ExactRational>>(
          "c23.test_polynomial_entrance_mass_not_one",
          "the synthetic polynomial entrance must sum exactly to one");
    }
    std::vector<ExactRational> tails;
    tails.reserve(maximum_tail_index + 1U);
    tails.push_back(ExactRational::one());
    for (std::size_t step = 0U; step < maximum_tail_index; ++step) {
      std::map<PolynomialStateV1, ExactRational> next;
      for (const auto& [state, mass] : current) {
        for (const auto& transition : states[state.base_state].transitions) {
          if (state.remaining_predecessors == 0U &&
              transition.departure == 1U) {
            continue;
          }
          const PolynomialStateV1 successor{
              transition.successor_index,
              state.remaining_predecessors - transition.departure};
          const ExactRational branch = mass * transition.exact_mass;
          const auto found = next.find(successor);
          if (found == next.end()) {
            next.emplace(successor, branch);
          } else {
            found->second = found->second + branch;
          }
        }
      }
      ExactRational tail = ExactRational::zero();
      for (const auto& [key, mass] : next) {
        static_cast<void>(key);
        tail = tail + mass;
      }
      tails.push_back(std::move(tail));
      current = std::move(next);
    }
    return Result<std::vector<ExactRational>>::success(std::move(tails));
  } catch (const std::bad_alloc&) {
    return fail<std::vector<ExactRational>>(
        "c23.test_polynomial_allocation_failure",
        "synthetic polynomial propagation exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<StationaryQueueLaw>
C23FixtureAccess::with_labelled_occupancy_evidence(
    const StationaryQueueLaw& law,
    const LabelledOccupancyEvidenceV1 evidence) {
  try {
    const auto& original = detail::C23CoreAccess::core(law);
    auto core =
        std::make_shared<const metrics::detail::StationaryQueueLawCore>(
            metrics::detail::StationaryQueueLawCore{
                original.source, original.atoms, original.mean_backlog,
                evidence, original.projection_fingerprint,
                original.fingerprint, original.target_ordinal});
    return Result<StationaryQueueLaw>::success(
        detail::C23CoreAccess::stationary_queue_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<StationaryQueueLaw>(
        "c23.test_queue_evidence_allocation_failure",
        "copying the test-only queue evidence exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<AdmissionRate> C23FixtureAccess::with_exact_admission_rate(
    const AdmissionRate& rate, ExactRational exact_value) {
  try {
    const auto& original = detail::C23CoreAccess::core(rate);
    const long double numerical_value = exact_value.to_long_double();
    auto core = std::make_shared<const metrics::detail::AdmissionRateCore>(
        metrics::detail::AdmissionRateCore{
            original.source, std::move(exact_value),
            numerical_value, original.projection_fingerprint,
            original.fingerprint, original.target_ordinal});
    return Result<AdmissionRate>::success(
        detail::C23CoreAccess::admission_rate(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<AdmissionRate>(
        "c23.test_rate_allocation_failure",
        "copying the test-only admission rate exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<PredictiveServiceSplit>
C23FixtureAccess::with_predictive_split_fault(
    const PredictiveServiceSplit& split,
    const C23PredictiveSplitFaultV1 fault) {
  try {
    auto core = detail::C23CoreAccess::core(split);
    switch (fault) {
      case C23PredictiveSplitFaultV1::conditional_mass_mismatch: {
        auto* atoms = !core.p0_atoms.empty() ? &core.p0_atoms
                                             : &core.p1_atoms;
        if (atoms->empty()) {
          return fail<PredictiveServiceSplit>(
              "c23.test_empty_predictive_split",
              "a predictive split fault requires at least one atom");
        }
        atoms->front().exact_conditional_mass = ExactRational::zero();
        break;
      }
      case C23PredictiveSplitFaultV1::incomplete_partition: {
        auto* atoms = !core.p0_atoms.empty() ? &core.p0_atoms
                                             : &core.p1_atoms;
        if (atoms->empty()) {
          return fail<PredictiveServiceSplit>(
              "c23.test_empty_predictive_split",
              "a predictive split fault requires at least one atom");
        }
        atoms->erase(atoms->begin());
        break;
      }
      case C23PredictiveSplitFaultV1::service_schema_mismatch: {
        std::vector<std::byte> bytes(
            core.target_service_schema_identity.bytes().begin(),
            core.target_service_schema_identity.bytes().end());
        bytes.front() ^= std::byte{0x01};
        auto changed = Digest256::from_bytes(bytes);
        if (!changed) {
          return Result<PredictiveServiceSplit>::failure(changed.error());
        }
        core.target_service_schema_identity = std::move(changed).value();
        break;
      }
      case C23PredictiveSplitFaultV1::successor_phase_schema_mismatch: {
        auto* atoms = !core.p0_atoms.empty() ? &core.p0_atoms
                                             : &core.p1_atoms;
        if (atoms->empty()) {
          return fail<PredictiveServiceSplit>(
              "c23.test_empty_predictive_split",
              "a predictive split fault requires at least one atom");
        }
        atoms->front().stationary_right_state.codec.id +=
            ".c23-foreign-successor-phase";
        break;
      }
    }
    auto copied = std::make_shared<const
        stationary::detail::PredictiveServiceSplitCore>(std::move(core));
    return Result<PredictiveServiceSplit>::success(
        detail::C23CoreAccess::predictive_service_split(
            std::move(copied)));
  } catch (const std::bad_alloc&) {
    return fail<PredictiveServiceSplit>(
        "c23.test_split_fault_allocation_failure",
        "copying the test-only predictive split exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<AdmissionPalmLaw> C23FixtureAccess::with_admission_palm_fault(
    const AdmissionPalmLaw& law, const C23AdmissionPalmFaultV1 fault) {
  try {
    auto core = detail::C23CoreAccess::core(law);
    if (core.atoms.empty()) {
      return fail<AdmissionPalmLaw>(
          "c23.test_empty_admission_palm",
          "an admission-Palm fault requires at least one atom");
    }
    AdmissionPalmAtomV1& atom = core.atoms.front();
    switch (fault) {
      case C23AdmissionPalmFaultV1::rank_zero:
        atom.within_batch_rank = BigNat{0U};
        break;
      case C23AdmissionPalmFaultV1::rank_above_batch:
        atom.within_batch_rank = atom.batch_size + BigNat{1U};
        break;
      case C23AdmissionPalmFaultV1::departure_exceeds_backlog:
        atom.prearrival_backlog = BigNat{0U};
        atom.actual_departure = 1U;
        break;
    }
    auto copied =
        std::make_shared<const metrics::detail::AdmissionPalmLawCore>(
            std::move(core));
    return Result<AdmissionPalmLaw>::success(
        detail::C23CoreAccess::admission_palm_law(std::move(copied)));
  } catch (const std::bad_alloc&) {
    return fail<AdmissionPalmLaw>(
        "c23.test_admission_fault_allocation_failure",
        "copying the test-only admission Palm law exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<TagInitialLaw> C23FixtureAccess::with_fifo_assumptions(
    const TagInitialLaw& law, FifoTagAssumptionsV1 assumptions) {
  try {
    auto core = detail::C23CoreAccess::core(law);
    core.assumptions = assumptions;
    auto copied =
        std::make_shared<const metrics::detail::TagInitialLawCore>(
            std::move(core));
    return Result<TagInitialLaw>::success(
        detail::C23CoreAccess::tag_initial_law(std::move(copied)));
  } catch (const std::bad_alloc&) {
    return fail<TagInitialLaw>(
        "c23.test_fifo_assumption_allocation_failure",
        "copying the test-only FIFO assumptions exhausted memory",
        DiagnosticCategory::resource_limit);
  }
}

Result<DelayLaw> C23FixtureAccess::evaluate_synthetic_fifo_delay(
    const TagInitialLaw& seed_initial,
    const TemporalServiceKernel& seed_service,
    std::vector<C23SyntheticFifoNodeV1> synthetic_nodes,
    std::vector<C23SyntheticFifoEntranceV1> synthetic_entrance,
    std::vector<FifoDelayOutputV1> authorized_outputs,
    const HorizonSpec& horizon, const SolverPolicy& policy) {
  try {
    const auto& seed = detail::C23CoreAccess::core(seed_initial);
    const auto& seed_kernel = detail::C23CoreAccess::core(seed_service);
    if (!seed.source || !seed.source->temporal_source || !seed.split ||
        !seed_kernel.source ||
        !same_source_owner(seed.source, seed_kernel.source) ||
        synthetic_nodes.empty() || synthetic_entrance.empty() ||
        authorized_outputs.empty()) {
      return fail<DelayLaw>(
          "c23.test_synthetic_fifo_seed_invalid",
          "a synthetic FIFO evaluation requires one valid projection-bound "
          "seed and nonempty nodes, entrance, and output authorization");
    }
    const std::size_t target_count =
        seed.source->provider_binding.target_selection.ordered_targets.size();
    if (target_count == 0U || seed.target_ordinal >= target_count) {
      return fail<DelayLaw>(
          "c23.test_synthetic_fifo_target_invalid",
          "the synthetic FIFO seed has no selected target");
    }

    std::vector<ReducedStateV1> decoded_states;
    decoded_states.reserve(synthetic_nodes.size());
    for (std::size_t index = 0U; index < synthetic_nodes.size(); ++index) {
      CanonicalEncoder encoder;
      encoder.u64(static_cast<std::uint64_t>(index));
      encoder.natural(synthetic_nodes[index].total_backlog);
      encoder.byte(
          static_cast<std::uint8_t>(synthetic_nodes[index].phase.family));
      encoder.frame(std::span<const std::byte>(
          synthetic_nodes[index].phase.canonical_state.data(),
          synthetic_nodes[index].phase.canonical_state.size()));
      decoded_states.push_back(ReducedStateV1{
          seed.source->temporal_source->binding.state_codec,
          std::vector<std::byte>(encoder.bytes().begin(),
                                 encoder.bytes().end())});
    }

    std::vector<metrics::detail::TemporalNodeCore> nodes;
    nodes.reserve(synthetic_nodes.size());
    for (std::size_t index = 0U; index < synthetic_nodes.size(); ++index) {
      const auto& input = synthetic_nodes[index];
      if (input.transitions.empty()) {
        return fail<DelayLaw>(
            "c23.test_synthetic_fifo_empty_row",
            "every synthetic FIFO service state requires a complete row");
      }
      ExactRational row_total = ExactRational::zero();
      std::vector<metrics::detail::TemporalTransitionCore> transitions;
      transitions.reserve(input.transitions.size());
      for (const auto& transition : input.transitions) {
        if (transition.successor_index >= synthetic_nodes.size() ||
            transition.departure > 1U ||
            !transition.exact_mass.is_positive()) {
          return fail<DelayLaw>(
              "c23.test_synthetic_fifo_invalid_transition",
              "synthetic FIFO transitions require an in-range successor, "
              "binary departure, and positive exact mass");
        }
        auto after_service = checked_subtract(
            input.total_backlog, BigNat{transition.departure});
        if (!after_service) {
          return fail<DelayLaw>(
              "c23.test_synthetic_fifo_departure_exceeds_backlog",
              "a synthetic FIFO service departure exceeds total backlog");
        }
        const BigNat& successor_backlog =
            synthetic_nodes[transition.successor_index].total_backlog;
        auto arrivals = checked_subtract(successor_backlog,
                                         after_service.value());
        if (!arrivals) {
          return fail<DelayLaw>(
              "c23.test_synthetic_fifo_conservation_failure",
              "a synthetic FIFO transition cannot satisfy N'=N-D+A with "
              "a nonnegative arrival batch");
        }
        std::vector<BigNat> prearrival(target_count, BigNat{0U});
        std::vector<std::uint8_t> departures(target_count, 0U);
        std::vector<BigNat> arrival_batches(target_count, BigNat{0U});
        prearrival[seed.target_ordinal] = input.total_backlog;
        departures[seed.target_ordinal] = transition.departure;
        arrival_batches[seed.target_ordinal] = arrivals.value();
        transitions.push_back(metrics::detail::TemporalTransitionCore{
            transition.successor_index,
            MarkedFluxEdgeV1{
                decoded_states[index],
                decoded_states[transition.successor_index],
                std::move(prearrival), std::move(departures),
                std::move(arrival_batches), input.phase,
                synthetic_nodes[transition.successor_index].phase, {}},
            transition.exact_mass});
        row_total = row_total + transition.exact_mass;
      }
      if (!(row_total == ExactRational::one())) {
        return fail<DelayLaw>(
            "c23.test_synthetic_fifo_row_mass_not_one",
            "every synthetic FIFO service row must sum exactly to one");
      }
      std::vector<BigNat> state_backlog(target_count, BigNat{0U});
      state_backlog[seed.target_ordinal] = input.total_backlog;
      nodes.push_back(metrics::detail::TemporalNodeCore{
          decoded_states[index], std::move(transitions), std::nullopt,
          std::move(state_backlog), std::nullopt});
    }

    std::vector<ExactRational> entrance_by_state(
        synthetic_nodes.size(), ExactRational::zero());
    ExactRational entrance_total = ExactRational::zero();
    for (const auto& atom : synthetic_entrance) {
      if (atom.state_index >= synthetic_nodes.size() ||
          !atom.exact_mass.is_positive() ||
          !(atom.predecessors <
            synthetic_nodes[atom.state_index].total_backlog)) {
        return fail<DelayLaw>(
            "c23.test_synthetic_fifo_invalid_entrance",
            "a synthetic FIFO entrance requires an in-range state, positive "
            "mass, and 0 <= R < N");
      }
      entrance_by_state[atom.state_index] =
          entrance_by_state[atom.state_index] + atom.exact_mass;
      entrance_total = entrance_total + atom.exact_mass;
    }
    if (!(entrance_total == ExactRational::one())) {
      return fail<DelayLaw>(
          "c23.test_synthetic_fifo_entrance_mass_not_one",
          "the synthetic FIFO entrance must sum exactly to one");
    }
    std::vector<metrics::detail::TemporalEntranceAtomCore> base_entrance;
    for (std::size_t index = 0U; index < entrance_by_state.size(); ++index) {
      if (entrance_by_state[index].is_positive()) {
        base_entrance.push_back(metrics::detail::TemporalEntranceAtomCore{
            index, decoded_states[index], entrance_by_state[index]});
      }
    }

    auto temporal_binding = seed.source->temporal_source->binding;
    auto temporal_source =
        std::make_shared<const metrics::detail::TemporalSourceCore>(
            metrics::detail::TemporalSourceCore{
                std::move(temporal_binding), std::move(nodes),
                std::move(base_entrance), {}, 4096U, 4096U, std::nullopt,
                std::nullopt, true, true, true});
    auto source_value = *seed.source;
    source_value.atoms.clear();
    source_value.temporal_source = temporal_source;
    auto source = std::make_shared<const
        stationary::detail::StationaryProjectionSourceCore>(
        std::move(source_value));

    auto service_value = seed_kernel;
    service_value.source = source;
    service_value.chronological_service_atoms.clear();
    auto service_core = std::make_shared<const
        stationary::detail::TemporalServiceKernelCore>(
        std::move(service_value));
    TemporalServiceKernel service =
        detail::C23CoreAccess::temporal_service_kernel(
            std::move(service_core));

    auto split_value = *seed.split;
    split_value.source = source;
    split_value.p0_atoms.clear();
    split_value.p1_atoms.clear();
    auto split = std::make_shared<const
        stationary::detail::PredictiveServiceSplitCore>(
        std::move(split_value));

    const auto& seed_rate = detail::C23CoreAccess::core(seed.admission_rate);
    auto rate_core =
        std::make_shared<const metrics::detail::AdmissionRateCore>(
            metrics::detail::AdmissionRateCore{
                source, seed_rate.exact_value, seed_rate.numerical_value,
                seed_rate.projection_fingerprint, seed_rate.fingerprint,
                seed_rate.target_ordinal});
    AdmissionRate rate =
        detail::C23CoreAccess::admission_rate(std::move(rate_core));

    const auto& seed_queue =
        detail::C23CoreAccess::core(seed.stationary_queue_law);
    auto queue_core =
        std::make_shared<const metrics::detail::StationaryQueueLawCore>(
            metrics::detail::StationaryQueueLawCore{
                source, {},
                ExtendedNonnegativeV1{
                    ExtendedNonnegativeStatusV1::not_established,
                    std::nullopt},
                LabelledOccupancyEvidenceV1{
                    false, false, false, false, false, false},
                seed_queue.projection_fingerprint, seed_queue.fingerprint,
                seed_queue.target_ordinal});
    StationaryQueueLaw queue =
        detail::C23CoreAccess::stationary_queue_law(
            std::move(queue_core));

    CanonicalEncoder entrance_encoder;
    entrance_encoder.digest(seed.entrance_identity);
    std::vector<TagInitialAtomV1> atoms;
    atoms.reserve(synthetic_entrance.size());
    for (const auto& input : synthetic_entrance) {
      entrance_encoder.u64(static_cast<std::uint64_t>(input.state_index));
      entrance_encoder.natural(input.predecessors);
      entrance_encoder.rational(input.exact_mass);
      const long double image = input.exact_mass.to_long_double();
      if (!std::isfinite(image) || image <= 0.0L) {
        return fail<DelayLaw>(
            "c23.test_synthetic_fifo_numerical_entrance_unavailable",
            "a positive synthetic FIFO entrance has no finite numerical "
            "image",
            DiagnosticCategory::unavailable);
      }
      atoms.push_back(TagInitialAtomV1{
          TagState{decoded_states[input.state_index], input.predecessors},
          input.state_index,
          TagEntranceLabelV1{
              BigNat{1U}, BigNat{1U},
              synthetic_nodes[input.state_index].phase, {}, {}},
          input.exact_mass, image});
    }
    auto entrance_identity = fingerprint(
        "mwperf.c23.test.synthetic_fifo_entrance.v1", entrance_encoder);
    if (!entrance_identity) {
      return Result<DelayLaw>::failure(entrance_identity.error());
    }
    std::vector<metrics::detail::FifoAuthorizationGroupCore> groups{
        metrics::detail::FifoAuthorizationGroupCore{
            std::nullopt, authorized_outputs}};
    auto initial_core =
        std::make_shared<const metrics::detail::TagInitialLawCore>(
            metrics::detail::TagInitialLawCore{
                source, std::move(split), std::move(atoms), std::move(rate),
                std::move(queue), seed.assumptions, std::move(groups),
                std::move(authorized_outputs), std::nullopt,
                seed.projection_fingerprint, entrance_identity.value(),
                seed.target_ordinal});
    TagInitialLaw initial =
        detail::C23CoreAccess::tag_initial_law(std::move(initial_core));
    return evaluate_fifo_delay_distribution(initial, service, horizon,
                                             policy);
  } catch (const std::bad_alloc&) {
    return fail<DelayLaw>(
        "c23.test_synthetic_fifo_allocation_failure",
        "constructing the test-only synthetic FIFO graph exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<DelayLaw>(
        "c23.test_synthetic_fifo_exception",
        "constructing the test-only synthetic FIFO graph raised an "
        "unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace testing
#endif

}  // namespace mwperf
