#pragma once

#include <cstddef>
#include <optional>
#include <vector>

#include "mwperf/math/exact_rational.hpp"
#include "mwperf/result.hpp"

namespace mwperf::metrics::detail {

// A dependency-neutral exact finite sub-Markov input used by C22's private
// adapters.  The caller supplies the already classified physical exits.  The
// solver never manufactures an exit from a row-sum residual and never
// normalizes a survivor row.
struct ExactKilledTransition final {
  std::size_t successor_index;
  ExactRational exact_mass;
};

struct ExactKilledTypedExit final {
  std::size_t exit_type_index;
  ExactRational exact_mass;
};

struct ExactKilledRow final {
  std::vector<ExactKilledTransition> survivors;
  std::vector<ExactKilledTypedExit> typed_exits;
  // This is the mass of the full audited source row before killing.  The
  // exact finite route requires it to equal one independently of the sum of
  // the classified output records.
  ExactRational exact_source_mass;
};

struct ExactKilledSystem final {
  std::size_t state_count;
  std::size_t exit_type_count;
  std::vector<ExactKilledRow> rows;
};

struct ExactKilledRowAudit final {
  std::size_t state_index;
  ExactRational exact_source_mass;
  ExactRational exact_survivor_mass;
  std::vector<ExactRational> exact_typed_exit_masses;
  ExactRational exact_classified_mass;
  ExactRational exact_balance_residual;
};

struct ExactKilledValidation final {
  std::vector<ExactKilledRowAudit> rows;
  // Dense row-major coalesced survivor matrix and dense state-major exit
  // matrix.  Duplicate input records are combined exactly in index order.
  std::vector<ExactRational> survivor_matrix;
  std::vector<ExactRational> typed_exit_matrix;
};

struct ExactClosedSurvivorClass final {
  std::size_t component_index;
  std::vector<std::size_t> member_indices;
};

struct ExactSurvivorClassification final {
  std::vector<std::vector<std::size_t>> strongly_connected_components;
  std::vector<std::size_t> component_by_state;
  std::vector<ExactClosedSurvivorClass> closed_survivor_classes;
  // True exactly when a positive-support survivor path reaches a closed
  // unit-mass survivor class.  Those and only those coordinates have an
  // infinite minimal residence/absorption potential in the finite system.
  std::vector<bool> can_reach_closed_survivor;
};

enum class ExactPotentialStatus {
  finite,
  positive_infinity,
};

struct ExactPotentialCoordinate final {
  ExactPotentialStatus status;
  std::optional<ExactRational> exact_value;
};

struct ExactMinimalPotential final {
  std::vector<ExactPotentialCoordinate> coordinates;
  ExactSurvivorClassification classification;
  // For finite coordinates this stores g - 1 - Kg and is exactly zero.
  // Infinite coordinates have no finite algebraic residual and carry no
  // entry here.
  std::vector<std::optional<ExactRational>> exact_equation_residuals;
  std::size_t finite_system_dimension;
  std::size_t finite_system_rank;
  // One exact application of the positive affine map from the zero vector,
  // followed by the full-rank transient solve and its exact fixed-point
  // residual, certifies that the pivoted result is the zero-start minimal
  // branch rather than an arbitrary algebraic solution.
  std::size_t zero_start_certificate_iterations;
  bool zero_start_monotone;
  bool direct_acceleration_certified;
};

struct ExactMinimalTypedExitProbabilities final {
  std::size_t state_count;
  std::size_t exit_type_count;
  // State-major h_t, the minimal probability of eventual absorption through
  // each declared type.  Nonabsorbing closed classes receive the zero
  // solution, as required by zero-start iteration.
  std::vector<ExactRational> state_major_probabilities;
  // The probability of never taking any declared exit.  In an exact finite
  // system this is one minus the sum of the typed eventual probabilities.
  std::vector<ExactRational> defect_probabilities;
  // State-major residual h_t - b_t - K h_t, exactly zero.
  std::vector<ExactRational> exact_equation_residuals;
  // Residual defect - K defect, exactly zero on transient coordinates and
  // with the closed-class boundary value one on closed survivor states.
  std::vector<ExactRational> exact_defect_residuals;
  ExactSurvivorClassification classification;
  std::size_t transient_system_dimension;
  std::size_t transient_system_rank;
  // The typed probabilities are solved simultaneously conceptually.  A
  // single exact zero-start image supplies their common monotonicity lower
  // bound; the full-rank solve is accepted only after every exact residual
  // and boundary value agrees with that minimal branch.
  std::size_t zero_start_certificate_iterations;
  bool zero_start_monotone;
  bool direct_acceleration_certified;
};

[[nodiscard]] Result<ExactKilledValidation> validate_exact_killed_system(
    const ExactKilledSystem& system);

[[nodiscard]] Result<ExactSurvivorClassification>
classify_exact_survivor_support(const ExactKilledSystem& system);

[[nodiscard]] Result<ExactMinimalPotential> compute_exact_minimal_potential(
    const ExactKilledSystem& system);

[[nodiscard]] Result<ExactMinimalTypedExitProbabilities>
compute_exact_minimal_typed_exit_probabilities(
    const ExactKilledSystem& system);

}  // namespace mwperf::metrics::detail
