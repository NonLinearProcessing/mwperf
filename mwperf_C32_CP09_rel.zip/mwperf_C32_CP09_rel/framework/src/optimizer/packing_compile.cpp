#include "mwperf/optimizer/packing.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic packing_compile_diagnostic(
    const DiagnosticCategory category, std::string code,
    std::string message, std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

template <typename Value>
[[nodiscard]] Result<Value> packing_compile_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(packing_compile_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes)));
}

template <typename Value>
[[nodiscard]] Result<Value> packing_compile_resource_failure(
    std::string code, std::string message) {
  return Result<Value>::failure(packing_compile_diagnostic(
      DiagnosticCategory::resource_limit, std::move(code),
      std::move(message)));
}

}  // namespace

Result<PackingProblem> compile_packing_problem(
    const ResolvedPackingConstraint& constraint) {
  try {
    const std::size_t resource_count = constraint.resources.size();
    const std::size_t queue_count = constraint.demands.size();

    if (constraint.capacity.size() != resource_count) {
      return packing_compile_failure<PackingProblem>(
          "packing_compiled_capacity_dimension_mismatch",
          "the bound packing capacity dimension differs from its resource "
          "dimension",
          {"resources: " + std::to_string(resource_count),
           "capacity coordinates: " +
               std::to_string(constraint.capacity.size())});
    }
    if (queue_count == 0U) {
      return packing_compile_failure<PackingProblem>(
          "packing_compiled_queue_dimension_empty",
          "a compiled resource-packing family requires at least one queue");
    }

    std::vector<PackingResource> resources;
    resources.reserve(resource_count);
    std::set<ResourceId> resource_labels;
    for (std::size_t ordinal = 0U; ordinal < resource_count; ++ordinal) {
      const ResolvedResource& resource = constraint.resources[ordinal];
      if (resource.index.ordinal() != ordinal) {
        return packing_compile_failure<PackingProblem>(
            "packing_compiled_resource_order_invalid",
            "the bound packing resources are not in dense declared order",
            {"position: " + std::to_string(ordinal),
             "stored resource index: " +
                 std::to_string(resource.index.ordinal())});
      }
      if (!resource_labels.insert(resource.id).second) {
        return packing_compile_failure<PackingProblem>(
            "packing_compiled_resource_label_duplicate",
            "a bound packing resource label occurs more than once");
      }
      resources.push_back(PackingResource{resource.index, resource.id});
    }

    std::vector<std::optional<CompiledPackingDemand>> canonical(queue_count);
    for (const ResolvedPackingDemand& record : constraint.demands) {
      const std::size_t queue = record.queue.ordinal();
      if (queue >= queue_count || canonical[queue].has_value()) {
        return packing_compile_failure<PackingProblem>(
            "packing_compiled_queue_coverage_invalid",
            "the bound packing demands do not cover every dense queue "
            "exactly once",
            {"dense queue index: " + std::to_string(queue)});
      }
      if (record.demand.size() != resource_count) {
        return packing_compile_failure<PackingProblem>(
            "packing_compiled_demand_dimension_mismatch",
            "a bound packing demand dimension differs from the resource "
            "dimension",
            {"dense queue index: " + std::to_string(queue),
             "resources: " + std::to_string(resource_count),
             "demand coordinates: " +
                 std::to_string(record.demand.size())});
      }
      canonical[queue] =
          CompiledPackingDemand{record.queue, record.demand};
    }

    std::vector<CompiledPackingDemand> demands;
    demands.reserve(queue_count);
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if (!canonical[queue].has_value()) {
        return packing_compile_failure<PackingProblem>(
            "packing_compiled_queue_coverage_invalid",
            "the bound packing demands omit a dense queue",
            {"dense queue index: " + std::to_string(queue)});
      }
      demands.push_back(std::move(*canonical[queue]));
    }

    return Result<PackingProblem>::success(PackingProblem(
        std::move(resources),
        CapacityVector::from_values(constraint.capacity),
        std::move(demands)));
  } catch (const std::bad_alloc&) {
    return packing_compile_resource_failure<PackingProblem>(
        "packing_compile_allocation_failure",
        "allocation failed while compiling immutable packing geometry");
  } catch (const std::length_error&) {
    return packing_compile_resource_failure<PackingProblem>(
        "packing_compile_representation_failure",
        "immutable packing geometry exceeds a host container limit");
  }
}

}  // namespace mwperf
