#include "mwperf/optimizer/forced_target.hpp"

#include <cstddef>
#include <cstdint>
#include <new>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic forced_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic forced_resource_error(
    std::string code, std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] bool known_forced_bit(const ForcedTargetBit bit) noexcept {
  switch (bit) {
    case ForcedTargetBit::zero:
    case ForcedTargetBit::one:
      return true;
  }
  return false;
}

[[nodiscard]] OptimizerQueryKind query_kind_for(
    const ForcedTargetBit bit) noexcept {
  return bit == ForcedTargetBit::zero ? OptimizerQueryKind::forced_zero
                                      : OptimizerQueryKind::forced_one;
}

struct ObjectiveParts final {
  BigNat primary;
  BigNat secondary;
  BigNat composite;
};

[[nodiscard]] ObjectiveParts recompute_objectives(
    const Schedule& schedule, const PrimaryWeights& original_primary,
    const LexWeights& conditioned_weights, const TargetIndex target) {
  BigNat primary(std::uint64_t{0U});
  BigNat secondary(std::uint64_t{0U});
  BigNat composite(std::uint64_t{0U});
  for (std::size_t ordinal = 0U; ordinal < schedule.size(); ++ordinal) {
    if (schedule.bytes()[ordinal] == 0U) {
      continue;
    }
    if (ordinal != target.ordinal()) {
      primary += original_primary.values()[ordinal];
    }
    secondary += conditioned_weights.secondary_weights()[ordinal];
    composite += conditioned_weights.values()[ordinal];
  }
  return ObjectiveParts{std::move(primary), std::move(secondary),
                        std::move(composite)};
}

template <typename ExactSolve>
[[nodiscard]] Result<PrimaryOptimum> solve_forced_target_core(
    OptimizerExecutionContext& context,
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility,
    const PrimaryWeights& primary,
    const TargetIndex target,
    const ForcedTargetBit bit,
    const PriorityOrder& priority,
    ExactSolve&& exact_solve) {
  if (!known_forced_bit(bit)) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_bit_invalid",
        "the requested forced-target bit is outside the closed binary "
        "domain"));
  }
  if (primary.dimension() != eligibility.dimension()) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_dimension_identity_mismatch",
        "primary weights and eligibility belong to different queue "
        "dimensions"));
  }
  if (!primary.dimension().matches(descriptor)) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_descriptor_dimension_mismatch",
        "the forced-target query is not bound to the supplied compiled "
        "constraint"));
  }
  if (!context.matches_dimension(primary.dimension())) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_optimizer_context_mismatch",
        "the process-local optimizer context is not bound to the forced "
        "query dimension"));
  }
  if (target.ordinal() >= primary.size()) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_out_of_range",
        "the forced-target dense index is outside the query dimension",
        {"target index: " + std::to_string(target.ordinal()),
         "queue dimension: " + std::to_string(primary.size())}));
  }
  if (!target.matches(primary.dimension())) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_identity_mismatch",
        "the forced target belongs to a different queue dimension"));
  }

  // The target has zero primary weight because Psi_e^b scores only s_{-e}.
  // Its eligibility is then replaced by the requested structural side: a
  // forced-one target is eligible even when its current backlog is zero, and
  // a forced-zero target cannot enter the witness. All other coordinates
  // retain their caller-supplied eligibility exactly.
  std::vector<BigNat> residual_primary_values(primary.values().begin(),
                                              primary.values().end());
  residual_primary_values[target.ordinal()] = BigNat(std::uint64_t{0U});
  auto residual_primary_result = PrimaryWeights::from_values(
      primary.dimension(), std::move(residual_primary_values));
  if (!residual_primary_result) {
    return Result<PrimaryOptimum>::failure(
        std::move(residual_primary_result.error()));
  }
  PrimaryWeights residual_primary =
      std::move(residual_primary_result).value();

  std::vector<std::uint8_t> conditioned_bytes(eligibility.bytes().begin(),
                                              eligibility.bytes().end());
  conditioned_bytes[target.ordinal()] =
      bit == ForcedTargetBit::one ? std::uint8_t{1U} : std::uint8_t{0U};
  auto conditioned_eligibility_result = EligibilityMask::from_bytes(
      eligibility.dimension(), std::move(conditioned_bytes));
  if (!conditioned_eligibility_result) {
    return Result<PrimaryOptimum>::failure(
        std::move(conditioned_eligibility_result.error()));
  }
  EligibilityMask conditioned_eligibility =
      std::move(conditioned_eligibility_result).value();

  // This is the same implementation used by F-C05-01, reached through its
  // non-catalog core so F-C05-04 retains the authoritative DAG children
  // F-C05-02 and F-C05-03 only.
  auto lex_result = detail::LexWeightsAccess::compose(
      residual_primary, priority, conditioned_eligibility);
  if (!lex_result) {
    return Result<PrimaryOptimum>::failure(std::move(lex_result.error()));
  }
  LexWeights lex_weights = std::move(lex_result).value();

  auto budget_result = begin_search_budget(context);
  if (!budget_result) {
    return Result<PrimaryOptimum>::failure(std::move(budget_result.error()));
  }
  SearchBudget budget = std::move(budget_result).value();
  const OptimizerQueryKind query_kind = query_kind_for(bit);
  auto identity = budget.set_query_identity(query_kind, target);
  if (!identity) {
    return Result<PrimaryOptimum>::failure(std::move(identity.error()));
  }

  const detail::ForcedTargetCondition condition{.target = target, .bit = bit};
  auto solution_result = exact_solve(descriptor, conditioned_eligibility,
                                     lex_weights, budget, condition);
  if (!solution_result) {
    // An unavailable backend, an infeasible side, or exact search exhaustion
    // is terminal. No incumbent or partially stripped objective escapes.
    return Result<PrimaryOptimum>::failure(
        std::move(solution_result.error()));
  }
  OptimizerSolution solution = std::move(solution_result).value();

  auto validated = detail::validate_optimizer_solution_core(
      solution, descriptor, conditioned_eligibility, lex_weights);
  if (!validated) {
    return Result<PrimaryOptimum>::failure(std::move(validated.error()));
  }
  if (solution.accounting() != budget.accounting()) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_accounting_mismatch",
        "the forced-target result is not tied to its live solve budget"));
  }

  const bool selected =
      solution.schedule().bytes()[target.ordinal()] != 0U;
  const bool required = bit == ForcedTargetBit::one;
  if (selected != required) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_witness_side_mismatch",
        "the exact optimizer witness violates the requested forced side",
        {"target index: " + std::to_string(target.ordinal()),
         "requested side: " + std::string(to_string(bit))}));
  }

  ObjectiveParts objectives = recompute_objectives(
      solution.schedule(), primary, lex_weights, target);
  if (objectives.composite != solution.composite_objective()) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_composite_objective_mismatch",
        "the validated forced-target witness does not reproduce its exact "
        "composite objective"));
  }
  BigNat reconstructed = objectives.primary * lex_weights.primary_scale();
  reconstructed += objectives.secondary;
  if (reconstructed != objectives.composite) {
    return Result<PrimaryOptimum>::failure(forced_error(
        "forced_target_objective_decomposition_mismatch",
        "the forced-target primary and priority components do not reconstruct "
        "the exact composite objective"));
  }

  return Result<PrimaryOptimum>::success(PrimaryOptimum{
      .value = std::move(objectives.primary),
      .witness = solution.schedule(),
      .secondary_code = std::move(objectives.secondary),
      .target = target,
      .side = bit,
      .family = solution.family(),
      .backend_id = solution.backend_id(),
      .accounting = solution.accounting(),
  });
}

}  // namespace

Result<PrimaryOptimum> solve_forced_target(
    OptimizerExecutionContext& context,
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility,
    const PrimaryWeights& primary,
    const TargetIndex target,
    const ForcedTargetBit bit,
    const PriorityOrder& priority) {
  try {
    return solve_forced_target_core(
        context, descriptor, eligibility, primary, target, bit, priority,
        [](const ConstraintDescriptor& exact_descriptor,
           const EligibilityMask& exact_eligibility,
           const LexWeights& exact_weights, SearchBudget& budget,
           const detail::ForcedTargetCondition& condition) {
          return detail::solve_exact_conditioned(
              exact_descriptor, exact_eligibility, exact_weights, budget,
              condition);
        });
  } catch (const std::bad_alloc&) {
    return Result<PrimaryOptimum>::failure(forced_resource_error(
        "forced_target_allocation_failure",
        "allocation failed during the cold exact forced-target query"));
  } catch (const std::length_error&) {
    return Result<PrimaryOptimum>::failure(forced_resource_error(
        "forced_target_representation_failure",
        "the cold exact forced-target query exceeds a host container limit"));
  }
}

#if defined(MWPERF_C05_TEST_SEAMS)
Result<PrimaryOptimum> detail::solve_forced_target_with_backend_services(
    OptimizerExecutionContext& context,
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility,
    const PrimaryWeights& primary,
    const TargetIndex target,
    const ForcedTargetBit bit,
    const PriorityOrder& priority,
    const ExactOptimizerBackendServices& services) {
  try {
    return solve_forced_target_core(
        context, descriptor, eligibility, primary, target, bit, priority,
        [&services](const ConstraintDescriptor& exact_descriptor,
                    const EligibilityMask& exact_eligibility,
                    const LexWeights& exact_weights, SearchBudget& budget,
                    const detail::ForcedTargetCondition& condition) {
          return solve_exact_with_backend_services(
              exact_descriptor, exact_eligibility, exact_weights, budget,
              condition, services);
        });
  } catch (const std::bad_alloc&) {
    return Result<PrimaryOptimum>::failure(forced_resource_error(
        "forced_target_allocation_failure",
        "allocation failed during the cold exact forced-target query"));
  } catch (const std::length_error&) {
    return Result<PrimaryOptimum>::failure(forced_resource_error(
        "forced_target_representation_failure",
        "the cold exact forced-target query exceeds a host container limit"));
  }
}
#endif

}  // namespace mwperf
