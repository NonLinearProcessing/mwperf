#include "mwperf/optimizer/exact_optimizer.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/conflict.hpp"
#include "mwperf/optimizer/packing.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {
namespace {

[[nodiscard]] Diagnostic registration_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Result<void> verify_conflict_binding(
    const ResolvedConflictConstraint& constraint,
    const ConflictProblem& problem) {
  const std::size_t queue_count = constraint.adjacency.size();
  if (problem.queue_count() != queue_count ||
      problem.adjacency().size() != queue_count ||
      problem.closed_neighborhoods().size() != queue_count ||
      problem.edges().size() != constraint.conflicts.size()) {
    return Result<void>::failure(registration_error(
        "conflict_compiled_product_binding_mismatch",
        "the immutable conflict problem does not match its bound descriptor",
        {"descriptor queues/conflicts: " + std::to_string(queue_count) +
             "/" + std::to_string(constraint.conflicts.size()),
         "compiled queues/conflicts: " +
             std::to_string(problem.queue_count()) + "/" +
             std::to_string(problem.edges().size())}));
  }

  for (std::size_t queue = 0; queue < queue_count; ++queue) {
    std::vector<std::uint8_t> expected(queue_count, 0U);
    for (const DenseQueueIndex neighbor : constraint.adjacency[queue]) {
      if (neighbor.ordinal() >= queue_count ||
          neighbor.ordinal() == queue ||
          expected[neighbor.ordinal()] != 0U) {
        return Result<void>::failure(registration_error(
            "conflict_descriptor_adjacency_invalid",
            "the bound conflict descriptor has corrupt adjacency"));
      }
      expected[neighbor.ordinal()] = 1U;
    }
    for (std::size_t other = 0; other < queue_count; ++other) {
      if (problem.adjacency()[queue].test(other) !=
          (expected[other] != 0U)) {
        return Result<void>::failure(registration_error(
            "conflict_compiled_product_binding_mismatch",
            "the immutable conflict adjacency differs from its bound "
            "descriptor",
            {"dense queue index: " + std::to_string(queue)}));
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> verify_packing_binding(
    const ResolvedPackingConstraint& constraint,
    const PackingProblem& problem) {
  const std::size_t resource_count = constraint.resources.size();
  const std::size_t queue_count = constraint.demands.size();
  if (problem.resource_count() != resource_count ||
      problem.queue_count() != queue_count ||
      constraint.capacity.size() != resource_count ||
      problem.capacity().size() != resource_count ||
      problem.resources().size() != resource_count ||
      problem.demands().size() != queue_count) {
    return Result<void>::failure(registration_error(
        "packing_compiled_product_binding_mismatch",
        "the immutable packing problem does not match its bound descriptor",
        {"descriptor resources/queues: " +
             std::to_string(resource_count) + "/" +
             std::to_string(queue_count),
         "compiled resources/queues: " +
             std::to_string(problem.resource_count()) + "/" +
             std::to_string(problem.queue_count())}));
  }

  for (std::size_t resource = 0; resource < resource_count; ++resource) {
    if (constraint.resources[resource].index.ordinal() != resource ||
        problem.resources()[resource].index.ordinal() != resource ||
        problem.resources()[resource].id != constraint.resources[resource].id ||
        problem.capacity()[resource] != constraint.capacity[resource]) {
      return Result<void>::failure(registration_error(
          "packing_compiled_product_binding_mismatch",
          "the immutable packing resource geometry differs from its bound "
          "descriptor",
          {"dense resource index: " + std::to_string(resource)}));
    }
  }

  std::vector<std::uint8_t> seen(queue_count, 0U);
  for (const ResolvedPackingDemand& demand : constraint.demands) {
    const std::size_t queue = demand.queue.ordinal();
    if (queue >= queue_count || seen[queue] != 0U ||
        demand.demand.size() != resource_count) {
      return Result<void>::failure(registration_error(
          "packing_descriptor_queue_binding_invalid",
          "the bound packing descriptor has corrupt dense queue coverage"));
    }
    seen[queue] = 1U;
    const CompiledPackingDemand& compiled = problem.demands()[queue];
    if (compiled.queue.ordinal() != queue ||
        compiled.demand != demand.demand) {
      return Result<void>::failure(registration_error(
          "packing_compiled_product_binding_mismatch",
          "the immutable packing demand differs from its bound descriptor",
          {"dense queue index: " + std::to_string(queue)}));
    }
  }
  return Result<void>::success();
}

}  // namespace

Result<const ConflictProblem*> C08CompiledProductAccess::conflicts(
    const CompiledConstraintProduct& product,
    const ExactBackendAuthority& authority) {
  (void)authority;
  if (product.family_ != ServiceFamily::pairwise_conflicts ||
      product.compiled_type_tag_ != ConflictProblem::compiled_type_tag() ||
      !product.owner_) {
    return Result<const ConflictProblem*>::failure(registration_error(
        "conflict_compiled_product_type_mismatch",
        "the conflict backend did not receive a typed C08 compiled product"));
  }
  return Result<const ConflictProblem*>::success(
      static_cast<const ConflictProblem*>(product.owner_.get()));
}

Result<const PackingProblem*> C08CompiledProductAccess::packing(
    const CompiledConstraintProduct& product,
    const ExactBackendAuthority& authority) {
  (void)authority;
  if (product.family_ != ServiceFamily::resource_packing ||
      product.compiled_type_tag_ != PackingProblem::compiled_type_tag() ||
      !product.owner_) {
    return Result<const PackingProblem*>::failure(registration_error(
        "packing_compiled_product_type_mismatch",
        "the packing backend did not receive a typed C08 compiled product"));
  }
  return Result<const PackingProblem*>::success(
      static_cast<const PackingProblem*>(product.owner_.get()));
}

Result<ExactBackendCandidate> dispatch_registered_conflicts(
    const ResolvedConflictConstraint& constraint,
    const CompiledConstraintProduct& product,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    const std::optional<ForcedTargetCondition>& condition,
    const ExactBackendAuthority& authority) {
  auto recovered = C08CompiledProductAccess::conflicts(product, authority);
  if (!recovered) {
    return Result<ExactBackendCandidate>::failure(
        std::move(recovered.error()));
  }
  auto binding = verify_conflict_binding(constraint, *recovered.value());
  if (!binding) {
    return Result<ExactBackendCandidate>::failure(std::move(binding.error()));
  }
  auto witness = solve_mwis_exact(
      *recovered.value(), eligibility, weights, budget,
      condition.has_value() ? &*condition : nullptr);
  if (!witness) {
    return Result<ExactBackendCandidate>::failure(std::move(witness.error()));
  }
  ConflictExactWitness exact = std::move(witness).value();
  return Result<ExactBackendCandidate>::success(authority.make_candidate(
      std::move(exact.schedule), std::move(exact.composite_objective),
      ServiceFamily::pairwise_conflicts,
      OptimizerId::mwis_branch_memo_exact, budget.accounting(),
      std::move(exact.proof_notes)));
}

Result<ExactBackendCandidate> dispatch_registered_packing(
    const ResolvedPackingConstraint& constraint,
    const CompiledConstraintProduct& product,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    const std::optional<ForcedTargetCondition>& condition,
    const ExactBackendAuthority& authority) {
  auto recovered = C08CompiledProductAccess::packing(product, authority);
  if (!recovered) {
    return Result<ExactBackendCandidate>::failure(
        std::move(recovered.error()));
  }
  auto binding = verify_packing_binding(constraint, *recovered.value());
  if (!binding) {
    return Result<ExactBackendCandidate>::failure(std::move(binding.error()));
  }
  auto witness = solve_packing_exact(
      *recovered.value(), eligibility, weights, budget,
      condition.has_value() ? &*condition : nullptr);
  if (!witness) {
    return Result<ExactBackendCandidate>::failure(std::move(witness.error()));
  }
  PackingExactWitness exact = std::move(witness).value();
  return Result<ExactBackendCandidate>::success(authority.make_candidate(
      std::move(exact.schedule), std::move(exact.composite_objective),
      ServiceFamily::resource_packing,
      OptimizerId::binary_packing_memo_exact, budget.accounting(),
      std::move(exact.proof_notes)));
}

}  // namespace mwperf::detail
