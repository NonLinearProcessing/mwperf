#include "mwperf/optimizer/conflict.hpp"

#include <algorithm>
#include <bit>
#include <compare>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <new>
#include <optional>
#include <ranges>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

constexpr std::size_t kBitsPerWord =
    std::numeric_limits<std::uint64_t>::digits;

[[nodiscard]] std::size_t word_count_for(
    const std::size_t logical_size) noexcept {
  return logical_size / kBitsPerWord +
         (logical_size % kBitsPerWord == 0U ? 0U : 1U);
}

[[nodiscard]] Diagnostic conflict_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

template <typename Value>
[[nodiscard]] Result<Value> conflict_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(conflict_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes)));
}

template <typename Value>
[[nodiscard]] Result<Value> conflict_resource_failure(
    std::string code, std::string message) {
  return Result<Value>::failure(conflict_diagnostic(
      DiagnosticCategory::resource_limit, std::move(code),
      std::move(message)));
}

[[nodiscard]] auto edge_key(const ConflictEdge& edge) noexcept {
  return std::pair{edge.first.ordinal(), edge.second.ordinal()};
}

}  // namespace

QueueSubset QueueSubset::none(const std::size_t logical_size) {
  return QueueSubset(logical_size,
                     std::vector<std::uint64_t>(
                         word_count_for(logical_size), std::uint64_t{0U}));
}

Result<QueueSubset> QueueSubset::from_bytes(
    const std::span<const std::uint8_t> bytes) {
  try {
    QueueSubset subset = none(bytes.size());
    for (std::size_t index = 0U; index < bytes.size(); ++index) {
      if (bytes[index] > 1U) {
        return conflict_failure<QueueSubset>(
            "queue_subset_not_binary",
            "a canonical queue subset contains a value outside the binary "
            "domain",
            {"dense queue index: " + std::to_string(index),
             "stored value: " + std::to_string(bytes[index])});
      }
      if (bytes[index] != 0U && !subset.set(index)) {
        return conflict_failure<QueueSubset>(
            "queue_subset_construction_invariant",
            "a valid dense queue index could not be inserted into its "
            "canonical subset");
      }
    }
    return Result<QueueSubset>::success(std::move(subset));
  } catch (const std::bad_alloc&) {
    return conflict_resource_failure<QueueSubset>(
        "queue_subset_allocation_failure",
        "allocation failed while constructing a canonical queue subset");
  } catch (const std::length_error&) {
    return conflict_resource_failure<QueueSubset>(
        "queue_subset_representation_failure",
        "the canonical queue subset exceeds a host container limit");
  }
}

bool QueueSubset::empty() const noexcept {
  return std::ranges::all_of(words_,
                             [](const std::uint64_t word) {
                               return word == 0U;
                             });
}

bool QueueSubset::test(const std::size_t index) const noexcept {
  if (index >= logical_size_) {
    return false;
  }
  const std::size_t word = index / kBitsPerWord;
  if (word >= words_.size()) {
    return false;
  }
  const std::size_t bit = index % kBitsPerWord;
  return (words_[word] & (std::uint64_t{1U} << bit)) != 0U;
}

std::optional<std::size_t> QueueSubset::first_set() const noexcept {
  for (std::size_t word_index = 0U; word_index < words_.size();
       ++word_index) {
    const std::uint64_t word = words_[word_index];
    if (word == 0U) {
      continue;
    }
    const std::size_t bit = std::countr_zero(word);
    const std::size_t index = word_index * kBitsPerWord + bit;
    if (index < logical_size_) {
      return index;
    }
  }
  return std::nullopt;
}

bool QueueSubset::canonical() const noexcept {
  if (words_.size() != word_count_for(logical_size_)) {
    return false;
  }
  const std::size_t used_tail_bits = logical_size_ % kBitsPerWord;
  if (used_tail_bits == 0U || words_.empty()) {
    return true;
  }
  const std::uint64_t used_mask =
      (std::uint64_t{1U} << used_tail_bits) - std::uint64_t{1U};
  return (words_.back() & ~used_mask) == 0U;
}

bool QueueSubset::set(const std::size_t index) noexcept {
  if (index >= logical_size_) {
    return false;
  }
  const std::size_t word = index / kBitsPerWord;
  if (word >= words_.size()) {
    return false;
  }
  words_[word] |= std::uint64_t{1U} << (index % kBitsPerWord);
  return true;
}

bool QueueSubset::reset(const std::size_t index) noexcept {
  if (index >= logical_size_) {
    return false;
  }
  const std::size_t word = index / kBitsPerWord;
  if (word >= words_.size()) {
    return false;
  }
  words_[word] &= ~(std::uint64_t{1U} << (index % kBitsPerWord));
  return true;
}

bool QueueSubset::subtract(const QueueSubset& other) noexcept {
  if (logical_size_ != other.logical_size_ ||
      words_.size() != other.words_.size()) {
    return false;
  }
  for (std::size_t word = 0U; word < words_.size(); ++word) {
    words_[word] &= ~other.words_[word];
  }
  return true;
}

bool QueueSubset::intersect(const QueueSubset& other) noexcept {
  if (logical_size_ != other.logical_size_ ||
      words_.size() != other.words_.size()) {
    return false;
  }
  for (std::size_t word = 0U; word < words_.size(); ++word) {
    words_[word] &= other.words_[word];
  }
  return true;
}

bool QueueSubset::unite(const QueueSubset& other) noexcept {
  if (logical_size_ != other.logical_size_ ||
      words_.size() != other.words_.size()) {
    return false;
  }
  for (std::size_t word = 0U; word < words_.size(); ++word) {
    words_[word] |= other.words_[word];
  }
  return true;
}

std::strong_ordering operator<=>(const QueueSubset& lhs,
                                 const QueueSubset& rhs) noexcept {
  if (lhs.logical_size_ < rhs.logical_size_) {
    return std::strong_ordering::less;
  }
  if (lhs.logical_size_ > rhs.logical_size_) {
    return std::strong_ordering::greater;
  }
  if (lhs.words_.size() < rhs.words_.size()) {
    return std::strong_ordering::less;
  }
  if (lhs.words_.size() > rhs.words_.size()) {
    return std::strong_ordering::greater;
  }
  for (std::size_t word = 0U; word < lhs.words_.size(); ++word) {
    if (lhs.words_[word] < rhs.words_[word]) {
      return std::strong_ordering::less;
    }
    if (lhs.words_[word] > rhs.words_[word]) {
      return std::strong_ordering::greater;
    }
  }
  return std::strong_ordering::equal;
}

Result<void> detail::validate_conflict_problem(
    const ConflictProblem& problem) {
  const std::size_t queue_count = problem.queue_count();
  if (problem.closed_neighborhoods().size() != queue_count) {
    return Result<void>::failure(conflict_diagnostic(
        DiagnosticCategory::internal,
        "conflict_problem_neighborhood_dimension_mismatch",
        "the immutable conflict adjacency and closed-neighborhood "
        "dimensions differ"));
  }

  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    const QueueSubset& row = problem.adjacency()[queue];
    const QueueSubset& closed = problem.closed_neighborhoods()[queue];
    if (!row.canonical() || !closed.canonical() ||
        row.size() != queue_count || closed.size() != queue_count) {
      return Result<void>::failure(conflict_diagnostic(
          DiagnosticCategory::internal,
          "conflict_problem_subset_invalid",
          "an immutable conflict bitset is malformed or has another logical "
          "queue dimension",
          {"dense queue index: " + std::to_string(queue)}));
    }
    if (row.test(queue)) {
      return Result<void>::failure(conflict_diagnostic(
          DiagnosticCategory::internal, "conflict_problem_self_conflict",
          "an immutable conflict adjacency contains a self-conflict",
          {"dense queue index: " + std::to_string(queue)}));
    }
    QueueSubset expected_closed = row;
    if (!expected_closed.set(queue) || expected_closed != closed) {
      return Result<void>::failure(conflict_diagnostic(
          DiagnosticCategory::internal,
          "conflict_problem_closed_neighborhood_invalid",
          "an immutable closed neighborhood does not equal adjacency plus "
          "its own queue",
          {"dense queue index: " + std::to_string(queue)}));
    }
    for (std::size_t neighbor = 0U; neighbor < queue_count; ++neighbor) {
      if (row.test(neighbor) !=
          problem.adjacency()[neighbor].test(queue)) {
        return Result<void>::failure(conflict_diagnostic(
            DiagnosticCategory::internal,
            "conflict_problem_adjacency_asymmetric",
            "the immutable conflict adjacency is not symmetric",
            {"first dense queue index: " + std::to_string(queue),
             "second dense queue index: " +
                 std::to_string(neighbor)}));
      }
    }
  }

  std::size_t edge_position = 0U;
  std::optional<std::pair<std::size_t, std::size_t>> previous;
  for (const ConflictEdge& edge : problem.edges()) {
    const auto key = edge_key(edge);
    if (!(key.first < key.second) || key.second >= queue_count ||
        (previous.has_value() && !(previous.value() < key))) {
      return Result<void>::failure(conflict_diagnostic(
          DiagnosticCategory::internal,
          "conflict_problem_edge_order_invalid",
          "the immutable conflict edge list is not in strict canonical "
          "order",
          {"edge position: " + std::to_string(edge_position)}));
    }
    if (!problem.adjacency()[key.first].test(key.second)) {
      return Result<void>::failure(conflict_diagnostic(
          DiagnosticCategory::internal,
          "conflict_problem_edge_adjacency_mismatch",
          "an immutable conflict edge is absent from its adjacency"));
    }
    previous = key;
    ++edge_position;
  }

  edge_position = 0U;
  for (std::size_t first = 0U; first < queue_count; ++first) {
    for (std::size_t second = first + 1U; second < queue_count; ++second) {
      if (!problem.adjacency()[first].test(second)) {
        continue;
      }
      if (edge_position >= problem.edges().size() ||
          edge_key(problem.edges()[edge_position]) !=
              std::pair{first, second}) {
        return Result<void>::failure(conflict_diagnostic(
            DiagnosticCategory::internal,
            "conflict_problem_edge_coverage_invalid",
            "the immutable conflict edge list and adjacency describe "
            "different graphs"));
      }
      ++edge_position;
    }
  }
  if (edge_position != problem.edges().size()) {
    return Result<void>::failure(conflict_diagnostic(
        DiagnosticCategory::internal,
        "conflict_problem_edge_coverage_invalid",
        "the immutable conflict edge list contains an adjacency duplicate"));
  }

  std::vector<std::size_t> expected_isolated;
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    if (problem.adjacency()[queue].empty()) {
      expected_isolated.push_back(queue);
    }
  }
  if (!std::ranges::equal(expected_isolated, problem.isolated_queues())) {
    return Result<void>::failure(conflict_diagnostic(
        DiagnosticCategory::internal,
        "conflict_problem_isolated_queues_invalid",
        "the immutable isolated-queue list disagrees with the conflict "
        "adjacency"));
  }
  return Result<void>::success();
}

Result<ConflictProblem> compile_conflict_problem(
    const ResolvedConflictConstraint& constraint) {
  try {
    const std::size_t queue_count = constraint.adjacency.size();
    std::vector<QueueSubset> expected;
    expected.reserve(queue_count);
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      expected.push_back(QueueSubset::none(queue_count));
    }

    std::set<std::pair<std::size_t, std::size_t>> seen;
    std::vector<ConflictEdge> edges;
    edges.reserve(constraint.conflicts.size());
    for (const ResolvedConflictPair& conflict : constraint.conflicts) {
      std::size_t first = conflict.first.ordinal();
      std::size_t second = conflict.second.ordinal();
      if (first >= queue_count || second >= queue_count) {
        return conflict_failure<ConflictProblem>(
            "conflict_compile_endpoint_out_of_range",
            "a bound conflict pair has an out-of-range dense queue "
            "endpoint");
      }
      if (first == second) {
        return conflict_failure<ConflictProblem>(
            "conflict_compile_self_pair",
            "a bound conflict pair contains the same queue twice",
            {"dense queue index: " + std::to_string(first)});
      }

      DenseQueueIndex first_index = conflict.first;
      DenseQueueIndex second_index = conflict.second;
      if (second < first) {
        std::swap(first, second);
        std::swap(first_index, second_index);
      }
      if (!seen.emplace(first, second).second) {
        return conflict_failure<ConflictProblem>(
            "conflict_compile_duplicate_pair",
            "an undirected bound conflict pair occurs more than once",
            {"first dense queue index: " + std::to_string(first),
             "second dense queue index: " + std::to_string(second)});
      }
      if (!expected[first].set(second) || !expected[second].set(first)) {
        return conflict_failure<ConflictProblem>(
            "conflict_compile_adjacency_construction_invariant",
            "a range-checked conflict endpoint could not enter its "
            "canonical adjacency");
      }
      edges.push_back(ConflictEdge{.first = first_index,
                                   .second = second_index});
    }
    std::ranges::sort(edges, [](const ConflictEdge& lhs,
                               const ConflictEdge& rhs) {
      return edge_key(lhs) < edge_key(rhs);
    });

    std::vector<QueueSubset> supplied;
    supplied.reserve(queue_count);
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      QueueSubset row = QueueSubset::none(queue_count);
      for (const DenseQueueIndex neighbor_index :
           constraint.adjacency[queue]) {
        const std::size_t neighbor = neighbor_index.ordinal();
        if (neighbor >= queue_count) {
          return conflict_failure<ConflictProblem>(
              "conflict_compile_adjacency_endpoint_out_of_range",
              "a bound conflict adjacency contains an out-of-range dense "
              "queue index",
              {"row dense queue index: " + std::to_string(queue)});
        }
        if (neighbor == queue) {
          return conflict_failure<ConflictProblem>(
              "conflict_compile_adjacency_self_pair",
              "a bound conflict adjacency contains its own queue",
              {"dense queue index: " + std::to_string(queue)});
        }
        if (row.test(neighbor)) {
          return conflict_failure<ConflictProblem>(
              "conflict_compile_adjacency_duplicate",
              "a bound conflict adjacency row repeats a neighbor",
              {"row dense queue index: " + std::to_string(queue),
               "neighbor dense queue index: " +
                   std::to_string(neighbor)});
        }
        if (!row.set(neighbor)) {
          return conflict_failure<ConflictProblem>(
              "conflict_compile_adjacency_construction_invariant",
              "a range-checked adjacency endpoint could not enter its "
              "canonical bitset");
        }
      }
      supplied.push_back(std::move(row));
    }
    if (supplied != expected) {
      return conflict_failure<ConflictProblem>(
          "conflict_compile_adjacency_mismatch",
          "the bound conflict adjacency does not exactly reproduce the "
          "canonical undirected conflict pairs");
    }

    std::vector<QueueSubset> closed = expected;
    std::vector<std::size_t> isolated;
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if (expected[queue].empty()) {
        isolated.push_back(queue);
      }
      if (!closed[queue].set(queue)) {
        return conflict_failure<ConflictProblem>(
            "conflict_compile_closed_neighborhood_invariant",
            "a valid queue could not enter its closed neighborhood");
      }
    }

    ConflictProblem problem(std::move(expected), std::move(closed),
                            std::move(edges), std::move(isolated));
    auto valid = detail::validate_conflict_problem(problem);
    if (!valid) {
      return Result<ConflictProblem>::failure(std::move(valid.error()));
    }
    return Result<ConflictProblem>::success(std::move(problem));
  } catch (const std::bad_alloc&) {
    return conflict_resource_failure<ConflictProblem>(
        "conflict_compile_allocation_failure",
        "allocation failed while compiling immutable conflict geometry");
  } catch (const std::length_error&) {
    return conflict_resource_failure<ConflictProblem>(
        "conflict_compile_representation_failure",
        "immutable conflict geometry exceeds a host container limit");
  }
}

}  // namespace mwperf
