#include "mwperf/optimizer/exact_optimizer.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/lexicographic.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic resolver_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic unsupported_tie(const TiePolicy policy) {
  std::string requested;
  switch (policy) {
    case TiePolicy::configured_priority:
      requested = "configured_priority";
      break;
    case TiePolicy::random:
      requested = "random";
      break;
    case TiePolicy::sticky:
      requested = "sticky";
      break;
    case TiePolicy::round_robin:
      requested = "round_robin";
      break;
    case TiePolicy::arrival_observing:
      requested = "arrival_observing";
      break;
  }
  if (requested.empty()) {
    requested = "unknown";
  }
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = "unsupported_tie_policy",
      .message =
          "the analytical MaxWeight resolver accepts only the configured "
          "deterministic priority tie policy",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {"requested tie policy: " + requested},
  };
}

struct ObjectiveParts final {
  BigNat primary;
  BigNat priority;
  BigNat composite;
};

[[nodiscard]] ObjectiveParts recompute_objectives(
    const Schedule& schedule, const PrimaryWeights& primary,
    const LexWeights& weights) {
  BigNat primary_total(std::uint64_t{0U});
  BigNat priority_code(std::uint64_t{0U});
  BigNat composite_total(std::uint64_t{0U});
  for (std::size_t ordinal = 0U; ordinal < schedule.size(); ++ordinal) {
    if (schedule.bytes()[ordinal] == 0U) {
      continue;
    }
    primary_total += primary.values()[ordinal];
    priority_code += weights.secondary_weights()[ordinal];
    composite_total += weights.values()[ordinal];
  }
  return ObjectiveParts{std::move(primary_total), std::move(priority_code),
                        std::move(composite_total)};
}

template <typename ExactSolve>
[[nodiscard]] Result<ScheduleDecision> resolve_maxweight_schedule_core(
    const ResolvedInstance& instance, const Backlog& backlog,
    const TieContext& tie_context, OptimizerExecutionContext& context,
    ExactSolve&& exact_solve) {
  if (!backlog.dimension().matches(instance)) {
    return Result<ScheduleDecision>::failure(resolver_error(
        "maxweight_backlog_instance_mismatch",
        "the backlog is not bound to the supplied resolved physical "
        "instance",
        {"backlog queue cardinality: " + std::to_string(backlog.size()),
         "instance queue cardinality: " +
             std::to_string(instance.queues().size())}));
  }
  if (!context.matches_dimension(backlog.dimension())) {
    return Result<ScheduleDecision>::failure(resolver_error(
        "maxweight_optimizer_context_mismatch",
        "the process-local optimizer context is not bound to the resolved "
        "instance and backlog dimension"));
  }

  std::vector<std::uint8_t> eligible_bytes;
  eligible_bytes.reserve(backlog.size());
  for (const BigNat& value : backlog.values()) {
    eligible_bytes.push_back(value.is_zero() ? std::uint8_t{0U}
                                             : std::uint8_t{1U});
  }
  auto eligibility_result = EligibilityMask::from_bytes(
      backlog.dimension(), std::move(eligible_bytes));
  if (!eligibility_result) {
    return Result<ScheduleDecision>::failure(
        std::move(eligibility_result.error()));
  }
  EligibilityMask eligibility = std::move(eligibility_result).value();

  if (tie_context.policy() != TiePolicy::configured_priority) {
    return Result<ScheduleDecision>::failure(
        unsupported_tie(tie_context.policy()));
  }

  std::vector<BigNat> backlog_values(backlog.values().begin(),
                                     backlog.values().end());
  auto primary_result = PrimaryWeights::from_values(
      backlog.dimension(), std::move(backlog_values));
  if (!primary_result) {
    return Result<ScheduleDecision>::failure(
        std::move(primary_result.error()));
  }
  PrimaryWeights primary = std::move(primary_result).value();

  auto lex_result = compose_lexicographic_weights(
      primary, instance.priority(), eligibility);
  if (!lex_result) {
    return Result<ScheduleDecision>::failure(std::move(lex_result.error()));
  }
  LexWeights lex_weights = std::move(lex_result).value();

  auto budget_result = begin_search_budget(context);
  if (!budget_result) {
    return Result<ScheduleDecision>::failure(
        std::move(budget_result.error()));
  }
  SearchBudget budget = std::move(budget_result).value();
  auto identity = budget.set_query_kind(OptimizerQueryKind::ordinary);
  if (!identity) {
    return Result<ScheduleDecision>::failure(std::move(identity.error()));
  }

  auto solution_result = exact_solve(instance.constraint(), eligibility,
                                     lex_weights, budget);
  if (!solution_result) {
    // Unavailability and exact resource exhaustion are terminal. In
    // particular, no incumbent or prior schedule is substituted.
    return Result<ScheduleDecision>::failure(
        std::move(solution_result.error()));
  }
  OptimizerSolution solution = std::move(solution_result).value();

  auto validated = validate_optimizer_solution(
      solution, instance.constraint(), eligibility, lex_weights);
  if (!validated) {
    return Result<ScheduleDecision>::failure(std::move(validated.error()));
  }
  if (solution.accounting() != budget.accounting()) {
    return Result<ScheduleDecision>::failure(resolver_error(
        "maxweight_accounting_mismatch",
        "the MaxWeight result is not tied to its live solve budget"));
  }
  if (solution.accounting().query_kind() != OptimizerQueryKind::ordinary ||
      solution.accounting().target().has_value()) {
    return Result<ScheduleDecision>::failure(resolver_error(
        "maxweight_query_identity_mismatch",
        "the MaxWeight result accounting does not identify an ordinary "
        "unconditioned solve"));
  }

  ObjectiveParts objectives =
      recompute_objectives(solution.schedule(), primary, lex_weights);
  if (objectives.composite != solution.composite_objective()) {
    return Result<ScheduleDecision>::failure(resolver_error(
        "maxweight_composite_objective_mismatch",
        "the validated MaxWeight schedule does not reproduce its exact "
        "composite objective"));
  }
  BigNat reconstructed = objectives.primary * lex_weights.primary_scale();
  reconstructed += objectives.priority;
  if (reconstructed != objectives.composite) {
    return Result<ScheduleDecision>::failure(resolver_error(
        "maxweight_objective_decomposition_mismatch",
        "the MaxWeight primary and priority components do not reconstruct "
        "the exact composite objective"));
  }

  return Result<ScheduleDecision>::success(ScheduleDecision{
      .schedule = solution.schedule(),
      .primary_objective = std::move(objectives.primary),
      .composite_objective = std::move(objectives.composite),
      .priority_code = std::move(objectives.priority),
      .eligibility = std::move(eligibility),
      .family = solution.family(),
      .backend_id = solution.backend_id(),
      .accounting = solution.accounting(),
  });
}

}  // namespace

Result<ScheduleDecision> resolve_maxweight_schedule(
    const ResolvedInstance& instance, const Backlog& backlog,
    const TieContext& tie_context, OptimizerExecutionContext& context) {
  return resolve_maxweight_schedule_core(
      instance, backlog, tie_context, context,
      [](const ConstraintDescriptor& descriptor,
         const EligibilityMask& eligibility, const LexWeights& weights,
         SearchBudget& budget) {
        return solve_exact(descriptor, eligibility, weights, budget);
      });
}

#if defined(MWPERF_C05_TEST_SEAMS)
Result<ScheduleDecision>
detail::resolve_maxweight_schedule_with_backend_services(
    const ResolvedInstance& instance, const Backlog& backlog,
    const TieContext& tie_context, OptimizerExecutionContext& context,
    const ExactOptimizerBackendServices& services) {
  return resolve_maxweight_schedule_core(
      instance, backlog, tie_context, context,
      [&services](const ConstraintDescriptor& descriptor,
                  const EligibilityMask& eligibility,
                  const LexWeights& weights, SearchBudget& budget) {
        return solve_exact_with_backend_services(
            descriptor, eligibility, weights, budget, std::nullopt,
            services);
      });
}
#endif

}  // namespace mwperf
