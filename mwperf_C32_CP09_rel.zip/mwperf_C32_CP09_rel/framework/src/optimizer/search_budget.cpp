#include "mwperf/optimizer/search_budget.hpp"

#include <exception>
#include <new>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {

[[nodiscard]] std::optional<BigNat> aggregate_search_state_limit(
    const std::optional<BigNat>& assigned_max_calls,
    const std::optional<BigNat>& effective_per_call) {
  if (assigned_max_calls.has_value() &&
      effective_per_call.has_value()) {
    return *assigned_max_calls * *effective_per_call;
  }
  if (assigned_max_calls.has_value() &&
      assigned_max_calls->is_zero()) {
    return BigNat{0U};
  }
  return std::nullopt;
}

// The one mutable call ledger for an execution context.  Its definition is
// deliberately confined to this translation unit: observers can extend its
// lifetime and read detached snapshots, but no external type can name its
// fields or acquire mutable authority.
class OptimizerCallLedgerState final {
 public:
  OptimizerCallLedgerState(std::optional<BigNat> assigned_max_calls_value,
                           std::optional<BigNat> effective_per_call)
      : assigned_max_calls(std::move(assigned_max_calls_value)),
        calls_reserved(0U),
        assigned_max_search_states(aggregate_search_state_limit(
            assigned_max_calls, effective_per_call)),
        search_states_expanded(0U),
        context_active(true) {}

  std::optional<BigNat> assigned_max_calls;
  BigNat calls_reserved;
  std::optional<BigNat> assigned_max_search_states;
  BigNat search_states_expanded;
  bool context_active;
};

}  // namespace detail

namespace {

[[nodiscard]] Diagnostic internal_error(std::string code,
                                        std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic call_limit_exhausted(
    const BigNat& limit, const BigNat& calls_reserved) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "optimizer_call_limit_exhausted",
      .message =
          "the process-local optimizer call subgrant is exhausted",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {
          "assigned process-local maximum optimizer calls: " +
              limit.to_decimal_string(),
          "successfully reserved optimizer calls: " +
              calls_reserved.to_decimal_string(),
      },
  };
}

[[nodiscard]] std::string optional_limit_text(
    const std::optional<BigNat>& value) {
  return value.has_value() ? value->to_decimal_string() : "unbounded";
}

[[nodiscard]] std::optional<BigNat> exact_minimum(
    const std::optional<BigNat>& first,
    const std::optional<BigNat>& second) {
  if (!first.has_value()) {
    return second;
  }
  if (!second.has_value()) {
    return first;
  }
  return *first < *second ? first : second;
}

[[nodiscard]] Result<void> validate_base_policy(
    const OptimizerBudgetPolicy& policy) {
  const std::optional<BigNat> expected =
      exact_minimum(policy.physical_per_call, policy.analysis_per_call);
  if (policy.effective_per_call != expected) {
    Diagnostic diagnostic = internal_error(
        "optimizer_budget_effective_limit_inconsistent",
        "the C04 optimizer policy does not contain the exact minimum of its "
        "physical and analysis per-call limits");
    diagnostic.notes = {
        "physical per-call limit: " +
            optional_limit_text(policy.physical_per_call),
        "analysis per-call limit: " +
            optional_limit_text(policy.analysis_per_call),
        "expected effective per-call limit: " +
            optional_limit_text(expected),
        "reported effective per-call limit: " +
            optional_limit_text(policy.effective_per_call),
    };
    return Result<void>::failure(std::move(diagnostic));
  }
  return Result<void>::success();
}

[[nodiscard]] Diagnostic assigned_subgrant_exceeds_base(
    const BigNat& assigned, const BigNat& base) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = "optimizer_assigned_call_subgrant_exceeds_base",
      .message =
          "the process-local optimizer call subgrant exceeds the C04 base "
          "policy",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {
          "assigned process-local maximum optimizer calls: " +
              assigned.to_decimal_string(),
          "C04 base maximum optimizer calls: " + base.to_decimal_string(),
      },
  };
}

[[nodiscard]] Diagnostic state_limit_exhausted(
    const BigNat& limit, const BigNat& completed,
    const ServiceFamily family, const OptimizerQueryKind query_kind,
    const std::optional<TargetIndex>& target) {
  std::vector<std::string> notes{
      "effective per-call expansion limit: " + limit.to_decimal_string(),
      "completed recursive expansions: " + completed.to_decimal_string(),
      "service family: " + std::string(to_string(family)),
      "query kind: " + std::string(to_string(query_kind)),
  };
  if (target.has_value()) {
    notes.push_back("target dense index: " +
                    std::to_string(target->ordinal()));
  }
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "search_state_limit_exhausted",
      .message =
          "the exact recursive optimizer search-state limit is exhausted",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic aggregate_state_limit_exhausted(
    const BigNat& limit, const BigNat& completed) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "optimizer_search_state_limit_exhausted",
      .message =
          "the execution-wide exact recursive optimizer search-state limit is exhausted",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {
          "assigned execution-wide maximum recursive expansions: " +
              limit.to_decimal_string(),
          "completed execution-wide recursive expansions: " +
              completed.to_decimal_string(),
      },
  };
}

[[nodiscard]] bool known_query_kind(const OptimizerQueryKind kind) noexcept {
  switch (kind) {
    case OptimizerQueryKind::ordinary:
    case OptimizerQueryKind::forced_zero:
    case OptimizerQueryKind::forced_one:
    case OptimizerQueryKind::integral_support:
    case OptimizerQueryKind::rational_support:
    case OptimizerQueryKind::generic_exact:
      return true;
  }
  return false;
}

[[nodiscard]] bool known_service_family(const ServiceFamily family) noexcept {
  switch (family) {
    case ServiceFamily::crossbar_matching:
    case ServiceFamily::nonoverlapping_intervals:
    case ServiceFamily::node_exclusive_matching:
    case ServiceFamily::pairwise_conflicts:
    case ServiceFamily::resource_packing:
      return true;
  }
  return false;
}

}  // namespace

bool OptimizerCallLedgerSnapshot::has_remaining_capacity() const noexcept {
  return context_active_ &&
         (!assigned_max_calls_.has_value() ||
          calls_reserved_ < *assigned_max_calls_);
}

OptimizerCallLedgerSnapshot OptimizerCallLedgerObserver::snapshot() const {
  if (!state_) {
    return OptimizerCallLedgerSnapshot(
        std::nullopt, BigNat{0U}, std::nullopt, BigNat{0U}, false);
  }
  return OptimizerCallLedgerSnapshot(
      state_->assigned_max_calls, state_->calls_reserved,
      state_->assigned_max_search_states, state_->search_states_expanded,
      state_->context_active);
}

OptimizerExecutionContext::OptimizerExecutionContext(
    OptimizerBudgetPolicy base_policy,
    std::optional<BigNat> assigned_max_calls,
    std::optional<QueueDimensionToken> instance_binding)
    : base_policy_(std::move(base_policy)),
      instance_binding_(std::move(instance_binding)),
      ledger_state_(std::make_shared<detail::OptimizerCallLedgerState>(
          std::move(assigned_max_calls), base_policy_.effective_per_call)) {}

OptimizerExecutionContext::OptimizerExecutionContext(
    OptimizerExecutionContext&& other) noexcept
    : base_policy_(std::move(other.base_policy_)),
      instance_binding_(std::move(other.instance_binding_)),
      ledger_state_(std::move(other.ledger_state_)) {}

OptimizerExecutionContext::~OptimizerExecutionContext() noexcept {
  if (ledger_state_) {
    ledger_state_->context_active = false;
  }
}

Result<OptimizerExecutionContext> OptimizerExecutionContext::from_policy(
    OptimizerBudgetPolicy base_policy,
    std::optional<BigNat> assigned_max_calls,
    std::optional<QueueDimensionToken> instance_binding) {
  auto policy_validation = validate_base_policy(base_policy);
  if (!policy_validation) {
    return Result<OptimizerExecutionContext>::failure(
        policy_validation.error());
  }

  if (!assigned_max_calls.has_value()) {
    assigned_max_calls = base_policy.max_calls;
  }
  if (base_policy.max_calls.has_value() &&
      assigned_max_calls.has_value() &&
      *assigned_max_calls > *base_policy.max_calls) {
    return Result<OptimizerExecutionContext>::failure(
        assigned_subgrant_exceeds_base(*assigned_max_calls,
                                       *base_policy.max_calls));
  }
  if (instance_binding.has_value() &&
      !instance_binding->matches_optimizer_policy(base_policy)) {
    return Result<OptimizerExecutionContext>::failure(internal_error(
        "optimizer_context_binding_policy_mismatch",
        "the execution context's request binding does not match its C04 "
        "base optimizer policy"));
  }

  try {
    return Result<OptimizerExecutionContext>::success(
        OptimizerExecutionContext(std::move(base_policy),
                                  std::move(assigned_max_calls),
                                  std::move(instance_binding)));
  } catch (const std::bad_alloc&) {
    return Result<OptimizerExecutionContext>::failure(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "optimizer_context_allocation_failure",
        .message = "constructing the execution-local optimizer ledger "
                   "exhausted memory",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  } catch (const std::exception&) {
    return Result<OptimizerExecutionContext>::failure(internal_error(
        "optimizer_context_construction_failure",
        "constructing the execution-local optimizer ledger raised an "
        "unexpected exception"));
  } catch (...) {
    return Result<OptimizerExecutionContext>::failure(internal_error(
        "optimizer_context_construction_unknown_failure",
        "constructing the execution-local optimizer ledger raised an "
        "unknown exception"));
  }
}

Result<OptimizerExecutionContext>
OptimizerExecutionContext::from_resolved_instance(
    const ResolvedInstance& instance,
    std::optional<BigNat> assigned_max_calls) {
  return from_policy(instance.optimizer_budget(), std::move(assigned_max_calls),
                     QueueDimensionToken::from_instance(instance));
}

#if defined(MWPERF_C05_TEST_SEAMS)
Result<OptimizerExecutionContext> OptimizerExecutionContext::for_fixture(
    OptimizerBudgetPolicy base_policy,
    std::optional<BigNat> assigned_max_calls,
    std::optional<QueueDimensionToken> instance_binding) {
  return from_policy(std::move(base_policy), std::move(assigned_max_calls),
                     std::move(instance_binding));
}
#endif

bool OptimizerExecutionContext::matches_dimension(
    const QueueDimensionToken& dimension) const noexcept {
  return active() && instance_binding_.has_value() &&
         *instance_binding_ == dimension;
}

const std::optional<BigNat>& OptimizerExecutionContext::assigned_max_calls()
    const noexcept {
  static const std::optional<BigNat> inactive = std::nullopt;
  return ledger_state_ ? ledger_state_->assigned_max_calls : inactive;
}

bool OptimizerExecutionContext::active() const noexcept {
  return ledger_state_ && ledger_state_->context_active;
}

OptimizerCallLedgerSnapshot OptimizerExecutionContext::ledger_snapshot()
    const {
  return ledger_observer().snapshot();
}

OptimizerCallLedgerObserver OptimizerExecutionContext::ledger_observer()
    const {
  return OptimizerCallLedgerObserver(ledger_state_);
}

detail::OptimizerCallLedgerTransaction::OptimizerCallLedgerTransaction(
    OptimizerExecutionContext& context) {
  (void)context;
}

detail::OptimizerCallLedgerTransaction::~OptimizerCallLedgerTransaction()
    noexcept {
  // Reservations are attempted scientific work, including when a later row
  // or slot invariant rejects the result.  C27 reports that work on every
  // terminal path, so a validation scope must never reset the shared ledger.
}

SearchBudget::SearchBudget(BigNat call_ordinal,
                           std::optional<BigNat> effective_limit,
                           std::optional<QueueDimensionToken> instance_binding,
                           std::shared_ptr<detail::OptimizerCallLedgerState>
                               ledger_state)
    : call_ordinal_(std::move(call_ordinal)),
      effective_limit_(std::move(effective_limit)),
      completed_expansions_(std::uint64_t{0U}),
      instance_binding_(std::move(instance_binding)),
      ledger_state_(std::move(ledger_state)),
      query_kind_(OptimizerQueryKind::generic_exact),
      query_target_(std::nullopt),
      claimed_family_(std::nullopt),
      query_kind_explicit_(false),
      dispatch_claimed_(false),
      exhausted_(false),
      active_(true) {}

SearchBudget::SearchBudget(SearchBudget&& other) noexcept
    : call_ordinal_(std::move(other.call_ordinal_)),
      effective_limit_(std::move(other.effective_limit_)),
      completed_expansions_(std::move(other.completed_expansions_)),
      instance_binding_(std::move(other.instance_binding_)),
      ledger_state_(std::move(other.ledger_state_)),
      query_kind_(other.query_kind_),
      query_target_(other.query_target_),
      claimed_family_(other.claimed_family_),
      query_kind_explicit_(other.query_kind_explicit_),
      dispatch_claimed_(other.dispatch_claimed_),
      exhausted_(other.exhausted_),
      active_(other.active_) {
  other.active_ = false;
}

bool SearchBudget::matches_dimension(
    const QueueDimensionToken& dimension) const noexcept {
  return has_live_context() && instance_binding_.has_value() &&
         *instance_binding_ == dimension;
}

bool SearchBudget::has_live_context() const noexcept {
  return active_ && ledger_state_ && ledger_state_->context_active;
}

Diagnostic SearchBudget::inactive_diagnostic() const {
  if (active_ && ledger_state_ && !ledger_state_->context_active) {
    return internal_error(
        "optimizer_execution_context_inactive",
        "a search budget cannot authorize or account for work after its execution context is destroyed");
  }
  return internal_error(
      "search_budget_moved_from",
      "a moved-from search budget cannot authorize or account for work");
}

Result<void> SearchBudget::set_query_kind(const OptimizerQueryKind kind) {
  return set_query_identity(kind, std::nullopt);
}

Result<void> SearchBudget::set_query_identity(
    const OptimizerQueryKind kind, std::optional<TargetIndex> target) {
  if (!has_live_context()) {
    return Result<void>::failure(inactive_diagnostic());
  }
  if (dispatch_claimed_) {
    return Result<void>::failure(internal_error(
        "search_budget_query_after_dispatch",
        "the optimizer query kind cannot change after dispatch is claimed"));
  }
  if (query_kind_explicit_) {
    return Result<void>::failure(internal_error(
        "search_budget_query_already_set",
        "the optimizer query kind may be set at most once"));
  }
  if (!known_query_kind(kind)) {
    return Result<void>::failure(internal_error(
        "search_budget_query_kind_invalid",
        "the optimizer query kind is outside the closed C05 domain"));
  }
  const bool forced = kind == OptimizerQueryKind::forced_zero ||
                      kind == OptimizerQueryKind::forced_one;
  if (forced && !target.has_value()) {
    return Result<void>::failure(internal_error(
        "search_budget_target_required",
        "a forced-target optimizer query must retain its dense target"));
  }
  if (!forced && target.has_value()) {
    return Result<void>::failure(internal_error(
        "search_budget_target_forbidden",
        "a non-forced optimizer query cannot carry a target"));
  }
  query_kind_ = kind;
  query_target_ = std::move(target);
  query_kind_explicit_ = true;
  return Result<void>::success();
}

Result<void> SearchBudget::claim_dispatch(const ServiceFamily family) {
  if (!has_live_context()) {
    return Result<void>::failure(inactive_diagnostic());
  }
  if (dispatch_claimed_) {
    return Result<void>::failure(internal_error(
        "search_budget_dispatch_already_claimed",
        "one optimizer call reservation cannot authorize two dispatches"));
  }
  if (!known_service_family(family)) {
    return Result<void>::failure(internal_error(
        "search_budget_family_invalid",
        "the optimizer service family is outside the closed C04 domain"));
  }
  claimed_family_ = family;
  dispatch_claimed_ = true;
  return Result<void>::success();
}

Result<void> SearchBudget::charge_expansion() {
  if (!has_live_context()) {
    return Result<void>::failure(inactive_diagnostic());
  }
  if (!dispatch_claimed_ || !claimed_family_.has_value()) {
    return Result<void>::failure(internal_error(
        "search_budget_dispatch_not_claimed",
        "recursive work cannot be charged before exact dispatch claims the "
        "search budget"));
  }

  if (effective_limit_.has_value() &&
      completed_expansions_ >= *effective_limit_) {
    exhausted_ = true;
    return Result<void>::failure(state_limit_exhausted(
        *effective_limit_, completed_expansions_, *claimed_family_,
        query_kind_, query_target_));
  }
  if (!ledger_state_) {
    return Result<void>::failure(internal_error(
        "optimizer_search_state_ledger_missing",
        "an active search budget lost its execution-wide recursive-state ledger"));
  }
  if (ledger_state_->assigned_max_search_states.has_value() &&
      ledger_state_->search_states_expanded >=
          *ledger_state_->assigned_max_search_states) {
    exhausted_ = true;
    return Result<void>::failure(aggregate_state_limit_exhausted(
        *ledger_state_->assigned_max_search_states,
        ledger_state_->search_states_expanded));
  }

  // Allocate both next values before publishing either increment. Recursive
  // work is never rolled back: once both swaps complete, the solve-local and
  // execution-wide counters permanently record the same successful charge.
  BigNat next_local = completed_expansions_;
  ++next_local;
  BigNat next_aggregate = ledger_state_->search_states_expanded;
  ++next_aggregate;
  completed_expansions_.swap(next_local);
  ledger_state_->search_states_expanded.swap(next_aggregate);
  return Result<void>::success();
}

SearchAccounting SearchBudget::accounting() const {
  return SearchAccounting(call_ordinal_, effective_limit_,
                          completed_expansions_, query_kind_,
                          claimed_family_, exhausted_, query_target_);
}

Result<void> detail::SearchBudgetAccess::claim_dispatch(
    SearchBudget& budget, const ServiceFamily family) {
  return budget.claim_dispatch(family);
}

Result<void> detail::SearchBudgetAccess::charge_expansion(
    SearchBudget& budget) {
  return budget.charge_expansion();
}

Result<SearchBudget> detail::SearchBudgetAccess::begin(
    OptimizerExecutionContext& context) {
  if (!context.active()) {
    return Result<SearchBudget>::failure(internal_error(
        "optimizer_execution_context_moved_from",
        "a moved-from optimizer execution context cannot reserve work"));
  }
  OptimizerCallLedgerState& ledger = *context.ledger_state_;
  if (ledger.assigned_max_calls.has_value() &&
      ledger.calls_reserved >= *ledger.assigned_max_calls) {
    return Result<SearchBudget>::failure(call_limit_exhausted(
        *ledger.assigned_max_calls, ledger.calls_reserved));
  }

  // Construct every potentially allocating value before publishing the
  // reservation to the live ledger. After the swap, all remaining moves are
  // noexcept, so either no reservation is observed or exactly one is.
  BigNat next_ordinal = ledger.calls_reserved;
  ++next_ordinal;
  SearchBudget budget(next_ordinal,
                      context.base_policy_.effective_per_call,
                      context.instance_binding_, context.ledger_state_);
  ledger.calls_reserved.swap(next_ordinal);
  return Result<SearchBudget>::success(std::move(budget));
}

Result<SearchBudget> begin_search_budget(OptimizerExecutionContext& context) {
  return detail::SearchBudgetAccess::begin(context);
}

}  // namespace mwperf
