#include "mwperf/optimizer/conflict.hpp"

#include <cstddef>
#include <cstdint>
#include <map>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {
namespace {

[[nodiscard]] Diagnostic mwis_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

template <typename Value>
[[nodiscard]] Result<Value> mwis_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(mwis_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes)));
}

[[nodiscard]] Diagnostic mwis_allocation_diagnostic() {
  return mwis_diagnostic(
      DiagnosticCategory::resource_limit, "mwis_solve_allocation_failure",
      "allocation failed during the cold exact MWIS recursion");
}

[[nodiscard]] Diagnostic mwis_representation_diagnostic() {
  return mwis_diagnostic(
      DiagnosticCategory::resource_limit,
      "mwis_solve_representation_failure",
      "the cold exact MWIS workspace exceeds a host container limit");
}

struct MwisValue final {
  BigNat score;
  QueueSubset selected;
};

struct MwisSolveControl final {
  bool force_distinct_branch_equality = false;
  bool equality_fault_used = false;
#if defined(MWPERF_C08_TEST_SEAMS)
  MwisTestTrace* trace = nullptr;
#endif
};

class ExactMwisSolver final {
 public:
  ExactMwisSolver(const ConflictProblem& problem, const LexWeights& weights,
                  SearchBudget& budget, MwisSolveControl& control)
      : problem_(problem),
        weights_(weights),
        budget_(budget),
        control_(control) {}

  [[nodiscard]] Result<MwisValue> solve(const QueueSubset& active) {
    return solve_state(active);
  }

 private:
  const ConflictProblem& problem_;
  const LexWeights& weights_;
  SearchBudget& budget_;
  MwisSolveControl& control_;
  // Ordered solely to make representation and diagnostics replayable. The
  // recurrence never iterates this table to choose work.
  std::map<QueueSubset, MwisValue> memo_;

  [[nodiscard]] Result<std::vector<QueueSubset>> components(
      const QueueSubset& active) const {
    if (!active.canonical() || active.size() != problem_.queue_count()) {
      return mwis_failure<std::vector<QueueSubset>>(
          "mwis_component_subset_invalid",
          "component decomposition received a malformed queue subset");
    }

    QueueSubset unseen = active;
    std::vector<QueueSubset> result;
    while (const std::optional<std::size_t> root = unseen.first_set()) {
      QueueSubset component = QueueSubset::none(problem_.queue_count());
      if (!component.set(*root) || !unseen.reset(*root)) {
        return mwis_failure<std::vector<QueueSubset>>(
            "mwis_component_root_invariant",
            "a valid component root could not enter the solve-local "
            "component partition");
      }

      std::vector<std::size_t> frontier{*root};
      for (std::size_t cursor = 0U; cursor < frontier.size(); ++cursor) {
        const std::size_t vertex = frontier[cursor];
        for (std::size_t neighbor = 0U;
             neighbor < problem_.queue_count(); ++neighbor) {
          if (!unseen.test(neighbor) ||
              !problem_.adjacency()[vertex].test(neighbor)) {
            continue;
          }
          if (!unseen.reset(neighbor) || !component.set(neighbor)) {
            return mwis_failure<std::vector<QueueSubset>>(
                "mwis_component_growth_invariant",
                "a range-checked adjacent queue could not enter its "
                "solve-local component");
          }
          frontier.push_back(neighbor);
        }
      }
      result.push_back(std::move(component));
    }
    return Result<std::vector<QueueSubset>>::success(std::move(result));
  }

  [[nodiscard]] Result<MwisValue> solve_state(const QueueSubset& active) {
    if (!active.canonical() || active.size() != problem_.queue_count()) {
      return mwis_failure<MwisValue>(
          "mwis_state_key_invalid",
          "the exact MWIS recursion received a malformed canonical memo "
          "key");
    }

    // Base states and memo hits are deliberately recognized before the sole
    // expansion charge, exactly as required by the C05 accounting contract.
    if (active.empty()) {
#if defined(MWPERF_C08_TEST_SEAMS)
      if (control_.trace != nullptr) {
        ++control_.trace->base_calls;
      }
#endif
      return Result<MwisValue>::success(MwisValue{
          .score = BigNat(std::uint64_t{0U}),
          .selected = QueueSubset::none(problem_.queue_count()),
      });
    }
    const auto memo = memo_.find(active);
    if (memo != memo_.end()) {
#if defined(MWPERF_C08_TEST_SEAMS)
      if (control_.trace != nullptr) {
        ++control_.trace->memo_hits;
      }
#endif
      return Result<MwisValue>::success(memo->second);
    }

    auto charged = SearchBudgetAccess::charge_expansion(budget_);
    if (!charged) {
      return Result<MwisValue>::failure(std::move(charged.error()));
    }
#if defined(MWPERF_C08_TEST_SEAMS)
    if (control_.trace != nullptr) {
      control_.trace->expanded_keys.push_back(active);
    }
#endif

    auto component_result = components(active);
    if (!component_result) {
      return Result<MwisValue>::failure(
          std::move(component_result.error()));
    }
    std::vector<QueueSubset> induced_components =
        std::move(component_result).value();
    if (induced_components.empty()) {
      return mwis_failure<MwisValue>(
          "mwis_nonbase_component_partition_empty",
          "a nonempty MWIS state produced no induced component");
    }
#if defined(MWPERF_C08_TEST_SEAMS)
    if (control_.trace != nullptr) {
      std::vector<std::size_t> minima;
      minima.reserve(induced_components.size());
      for (const QueueSubset& component : induced_components) {
        const std::optional<std::size_t> minimum = component.first_set();
        if (!minimum.has_value()) {
          return mwis_failure<MwisValue>(
              "mwis_trace_component_minimum_missing",
              "a traced nonempty component has no dense minimum");
        }
        minima.push_back(*minimum);
      }
      control_.trace->component_minima.push_back(std::move(minima));
    }
#endif

    MwisValue optimum{
        .score = BigNat(std::uint64_t{0U}),
        .selected = QueueSubset::none(problem_.queue_count()),
    };
    if (induced_components.size() > 1U) {
      // Components were discovered from the lowest unseen queue and each BFS
      // scans neighbors in ascending dense order. Their order is therefore
      // the normative order of smallest dense queue index.
      for (const QueueSubset& component : induced_components) {
        auto child = solve_state(component);
        if (!child) {
          return Result<MwisValue>::failure(std::move(child.error()));
        }
        MwisValue exact_component = std::move(child).value();
        optimum.score += exact_component.score;
        if (!optimum.selected.unite(exact_component.selected)) {
          return mwis_failure<MwisValue>(
              "mwis_component_union_dimension_mismatch",
              "an exact component result belongs to another queue "
              "dimension");
        }
      }
    } else {
      const std::optional<std::size_t> pivot = active.first_set();
      if (!pivot.has_value()) {
        return mwis_failure<MwisValue>(
            "mwis_nonbase_pivot_missing",
            "a nonempty exact MWIS state has no lowest-index pivot");
      }

      QueueSubset exclude_subset = active;
      if (!exclude_subset.reset(*pivot)) {
        return mwis_failure<MwisValue>(
            "mwis_exclude_subset_invariant",
            "the lowest-index MWIS pivot could not be removed from its "
            "exclude child");
      }
      auto excluded = solve_state(exclude_subset);
      if (!excluded) {
        return Result<MwisValue>::failure(std::move(excluded.error()));
      }

      QueueSubset include_subset = active;
      if (!include_subset.subtract(
              problem_.closed_neighborhoods()[*pivot])) {
        return mwis_failure<MwisValue>(
            "mwis_include_subset_dimension_mismatch",
            "the pivot closed neighborhood belongs to another queue "
            "dimension");
      }
      auto included = solve_state(include_subset);
      if (!included) {
        return Result<MwisValue>::failure(std::move(included.error()));
      }
      MwisValue include_value = std::move(included).value();
      include_value.score += weights_.values()[*pivot];
      if (!include_value.selected.set(*pivot)) {
        return mwis_failure<MwisValue>(
            "mwis_include_reconstruction_invariant",
            "the lowest-index MWIS pivot could not enter its exact "
            "reconstruction");
      }
      MwisValue exclude_value = std::move(excluded).value();

      if (control_.force_distinct_branch_equality &&
          !control_.equality_fault_used) {
        include_value.score = exclude_value.score;
        control_.equality_fault_used = true;
      }

      if (include_value.score == exclude_value.score) {
        if (include_value.selected != exclude_value.selected) {
          return mwis_failure<MwisValue>(
              "mwis_composite_equality_invariant",
              "distinct MWIS schedules have equal purported composite "
              "scores",
              {"pivot dense queue index: " + std::to_string(*pivot)});
        }
        optimum = std::move(include_value);
      } else if (include_value.score > exclude_value.score) {
        optimum = std::move(include_value);
      } else {
        optimum = std::move(exclude_value);
      }
    }

    // Publish the memo entry only after every required child completed. A
    // failed child or exhausted charge therefore leaves no usable incumbent.
    const auto [position, inserted] = memo_.emplace(active, optimum);
    if (!inserted) {
      return mwis_failure<MwisValue>(
          "mwis_memo_duplicate_completion",
          "a completed MWIS key was inserted twice into its cold memo");
    }
    return Result<MwisValue>::success(position->second);
  }
};

[[nodiscard]] Result<void> validate_mwis_query(
    const ConflictProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const SearchBudget& budget) {
  auto valid_problem = validate_conflict_problem(problem);
  if (!valid_problem) {
    return valid_problem;
  }
  if (eligibility.dimension() != weights.dimension()) {
    return Result<void>::failure(mwis_diagnostic(
        DiagnosticCategory::internal,
        "mwis_query_dimension_identity_mismatch",
        "MWIS eligibility and weights belong to different queue "
        "dimensions"));
  }
  if (weights.dimension().family() != ServiceFamily::pairwise_conflicts) {
    return Result<void>::failure(mwis_diagnostic(
        DiagnosticCategory::internal, "mwis_query_family_mismatch",
        "the MWIS primitive received a queue dimension for another service "
        "family"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(mwis_diagnostic(
        DiagnosticCategory::internal, "mwis_query_eligibility_mismatch",
        "the MWIS eligibility mask disagrees with the mask embedded in its "
        "exact weights"));
  }
  if (eligibility.size() != problem.queue_count() ||
      weights.size() != problem.queue_count()) {
    return Result<void>::failure(mwis_diagnostic(
        DiagnosticCategory::internal, "mwis_query_dimension_mismatch",
        "the MWIS query does not match its compiled queue dimension",
        {"compiled queues: " + std::to_string(problem.queue_count()),
         "eligibility entries: " +
             std::to_string(eligibility.size()),
         "weight entries: " + std::to_string(weights.size())}));
  }
  if (!budget.matches_dimension(weights.dimension())) {
    return Result<void>::failure(mwis_diagnostic(
        DiagnosticCategory::internal, "mwis_budget_dimension_mismatch",
        "the MWIS search budget belongs to another exact query dimension"));
  }
  if (!budget.dispatch_claimed() || !budget.claimed_family().has_value() ||
      *budget.claimed_family() != ServiceFamily::pairwise_conflicts) {
    return Result<void>::failure(mwis_diagnostic(
        DiagnosticCategory::internal, "mwis_budget_dispatch_mismatch",
        "the MWIS search budget was not claimed by the conflict family"));
  }
  return Result<void>::success();
}

}  // namespace

[[nodiscard]] static Result<ConflictExactWitness> solve_mwis_exact_controlled(
    const ConflictProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition, MwisSolveControl& control) {
  auto valid = validate_mwis_query(problem, eligibility, weights, budget);
  if (!valid) {
    return Result<ConflictExactWitness>::failure(std::move(valid.error()));
  }

  auto active_result = QueueSubset::from_bytes(eligibility.bytes());
  if (!active_result) {
    return Result<ConflictExactWitness>::failure(
        std::move(active_result.error()));
  }
  QueueSubset active = std::move(active_result).value();
  std::optional<std::size_t> committed_target;

  if (condition != nullptr) {
    switch (condition->bit) {
      case ForcedTargetBit::zero:
      case ForcedTargetBit::one:
        break;
      default:
        return mwis_failure<ConflictExactWitness>(
            "mwis_forced_bit_invalid",
            "the MWIS forced-target bit is outside the closed binary "
            "domain");
    }
    const std::size_t target = condition->target.ordinal();
    if (target >= problem.queue_count()) {
      return mwis_failure<ConflictExactWitness>(
          "mwis_forced_target_out_of_range",
          "the MWIS forced target lies outside the compiled queue "
          "dimension");
    }
    if (!condition->target.matches(weights.dimension())) {
      return mwis_failure<ConflictExactWitness>(
          "mwis_forced_target_identity_mismatch",
          "the MWIS forced target belongs to another queue dimension");
    }
    const bool target_required = condition->bit == ForcedTargetBit::one;
    const bool target_eligible = eligibility.bytes()[target] != 0U;
    if (target_required != target_eligible) {
      return mwis_failure<ConflictExactWitness>(
          "mwis_forced_target_eligibility_mismatch",
          "the conditioned target eligibility disagrees with its forced "
          "side");
    }
    if (target_required) {
      if (!active.subtract(problem.closed_neighborhoods()[target])) {
        return mwis_failure<ConflictExactWitness>(
            "mwis_forced_neighborhood_dimension_mismatch",
            "the forced target closed neighborhood belongs to another "
            "queue dimension");
      }
      committed_target = target;
    }
    // On forced zero C05's conditioned eligibility already removed the
    // target. No further geometry or weight reinterpretation is needed.
  }

  ExactMwisSolver solver(problem, weights, budget, control);
  auto optimum_result = solver.solve(active);
  if (!optimum_result) {
    // This includes search_state_limit_exhausted. The solver and its
    // incomplete memo die here, so no incumbent can cross the ABI.
    return Result<ConflictExactWitness>::failure(
        std::move(optimum_result.error()));
  }
  MwisValue optimum = std::move(optimum_result).value();
  if (committed_target.has_value()) {
    if (optimum.selected.test(*committed_target) ||
        !optimum.selected.set(*committed_target)) {
      return mwis_failure<ConflictExactWitness>(
          "mwis_forced_target_reconstruction_invariant",
          "the committed MWIS target was not disjoint from its residual "
          "solution");
    }
    optimum.score += weights.values()[*committed_target];
  }

  std::vector<std::uint8_t> selected(problem.queue_count(),
                                     std::uint8_t{0U});
  BigNat recomputed(std::uint64_t{0U});
  for (std::size_t queue = 0U; queue < problem.queue_count(); ++queue) {
    if (!optimum.selected.test(queue)) {
      continue;
    }
    selected[queue] = std::uint8_t{1U};
    recomputed += weights.values()[queue];
    QueueSubset conflicts = problem.adjacency()[queue];
    if (!conflicts.intersect(optimum.selected) || !conflicts.empty()) {
      return mwis_failure<ConflictExactWitness>(
          "mwis_reconstruction_not_independent",
          "the exact MWIS reconstruction contains a conflicting queue",
          {"dense queue index: " + std::to_string(queue)});
    }
  }
  if (recomputed != optimum.score) {
    return mwis_failure<ConflictExactWitness>(
        "mwis_reconstruction_objective_mismatch",
        "the exact MWIS reconstruction does not reproduce its score",
        {"reported objective: " + optimum.score.to_decimal_string(),
         "recomputed objective: " + recomputed.to_decimal_string()});
  }

  auto schedule =
      Schedule::from_bytes(weights.dimension(), std::move(selected));
  if (!schedule) {
    return Result<ConflictExactWitness>::failure(std::move(schedule.error()));
  }
  std::vector<std::string> proof_notes{
      "exact arbitrary-precision MWIS include/exclude recurrence",
      "lowest-dense-index pivots and canonical induced-component order",
      "cold solve-local exact memo with new nonbase-key accounting",
      "exponential worst-case state count; no presolve, bound, or incumbent",
  };
  if (condition != nullptr) {
    proof_notes.push_back(
        condition->bit == ForcedTargetBit::one
            ? "forced-one target committed outside its closed-neighborhood residual"
            : "forced-zero target removed before exact recursion");
  }
  return Result<ConflictExactWitness>::success(ConflictExactWitness{
      .schedule = std::move(schedule).value(),
      .composite_objective = std::move(recomputed),
      .proof_notes = std::move(proof_notes),
  });
}

Result<ConflictExactWitness> solve_mwis_exact(
    const ConflictProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition) {
  try {
    MwisSolveControl control;
    return solve_mwis_exact_controlled(problem, eligibility, weights, budget,
                                       condition, control);
  } catch (const std::bad_alloc&) {
    return Result<ConflictExactWitness>::failure(
        mwis_allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<ConflictExactWitness>::failure(
        mwis_representation_diagnostic());
  }
}

#if defined(MWPERF_C08_TEST_SEAMS)
Result<ConflictExactWitness> solve_mwis_exact_with_test_control(
    const ConflictProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition, const MwisTestFault fault,
    MwisTestTrace& trace) {
  try {
    trace = MwisTestTrace{};
    MwisSolveControl control{
        .force_distinct_branch_equality =
            fault == MwisTestFault::force_distinct_branch_equality,
        .equality_fault_used = false,
        .trace = &trace,
    };
    return solve_mwis_exact_controlled(problem, eligibility, weights, budget,
                                       condition, control);
  } catch (const std::bad_alloc&) {
    return Result<ConflictExactWitness>::failure(
        mwis_allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<ConflictExactWitness>::failure(
        mwis_representation_diagnostic());
  }
}
#endif

}  // namespace mwperf::detail
