#include "mwperf/optimizer/exact_optimizer.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <new>
#include <optional>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/solution_validation.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {

[[nodiscard]] Result<ExactBackendCandidate> dispatch_registered_crossbar(
    const ResolvedCrossbarConstraint&, const CompiledConstraintProduct&,
    const EligibilityMask&, const LexWeights&, SearchBudget&,
    const std::optional<ForcedTargetCondition>&,
    const ExactBackendAuthority&);

[[nodiscard]] Result<ExactBackendCandidate> dispatch_registered_intervals(
    const ResolvedIntervalConstraint&, const CompiledConstraintProduct&,
    const EligibilityMask&, const LexWeights&, SearchBudget&,
    const std::optional<ForcedTargetCondition>&,
    const ExactBackendAuthority&);

[[nodiscard]] Result<ExactBackendCandidate>
dispatch_registered_node_exclusive(
    const ResolvedNodeExclusiveConstraint&,
    const CompiledConstraintProduct&, const EligibilityMask&,
    const LexWeights&, SearchBudget&,
    const std::optional<ForcedTargetCondition>&,
    const ExactBackendAuthority&);

[[nodiscard]] Result<ExactBackendCandidate> dispatch_registered_conflicts(
    const ResolvedConflictConstraint&, const CompiledConstraintProduct&,
    const EligibilityMask&, const LexWeights&, SearchBudget&,
    const std::optional<ForcedTargetCondition>&,
    const ExactBackendAuthority&);

[[nodiscard]] Result<ExactBackendCandidate> dispatch_registered_packing(
    const ResolvedPackingConstraint&, const CompiledConstraintProduct&,
    const EligibilityMask&, const LexWeights&, SearchBudget&,
    const std::optional<ForcedTargetCondition>&,
    const ExactBackendAuthority&);

}  // namespace detail

namespace {

[[nodiscard]] Diagnostic dispatch_internal(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic dispatch_resource_error(
    std::string code, std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

#if defined(MWPERF_C05_TEST_SEAMS)
[[nodiscard]] Diagnostic unavailable_backend(
    const ConstraintDescriptor& descriptor) {
  const ServiceFamily family = descriptor.family();
  const OptimizerId backend = descriptor.identity().optimizer;

  switch (family) {
    case ServiceFamily::crossbar_matching:
    case ServiceFamily::nonoverlapping_intervals:
    case ServiceFamily::node_exclusive_matching:
    case ServiceFamily::pairwise_conflicts:
    case ServiceFamily::resource_packing:
      return dispatch_internal(
          "optimizer_registered_backend_route_missing",
          "an implemented exact family reached the unavailable-backend route",
          {"service family: " + std::string(to_string(family)),
           "optimizer backend: " + std::string(to_string(backend))});
  }
  return dispatch_internal(
      "optimizer_unknown_service_family",
      "the exact dispatcher received a service family outside its closed "
      "domain");
}
#endif

[[nodiscard]] bool known_forced_bit(const ForcedTargetBit bit) noexcept {
  switch (bit) {
    case ForcedTargetBit::zero:
    case ForcedTargetBit::one:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_forced_query(
    const OptimizerQueryKind kind) noexcept {
  return kind == OptimizerQueryKind::forced_zero ||
         kind == OptimizerQueryKind::forced_one;
}

[[nodiscard]] Result<void> validate_dispatch_query(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    const SearchBudget& budget,
    const std::optional<detail::ForcedTargetCondition>& condition) {
  if (eligibility.dimension() != weights.dimension()) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_dispatch_dimension_identity_mismatch",
        "eligibility and exact weights belong to different queue dimensions"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_dispatch_eligibility_mismatch",
        "the separately carried eligibility mask disagrees with the mask "
        "bound into the exact weights"));
  }
  if (!weights.dimension().matches(descriptor)) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_dispatch_descriptor_dimension_mismatch",
        "the exact query dimension is not bound to this compiled constraint",
        {"query queue cardinality: " + std::to_string(weights.size()),
         "descriptor family: " +
             std::string(to_string(descriptor.family()))}));
  }
  if (!budget.matches_dimension(weights.dimension())) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_dispatch_context_dimension_mismatch",
        "the reserved optimizer budget is not bound to this exact query "
        "dimension"));
  }
  if (!descriptor.compiled_product().has_owner() ||
      descriptor.compiled_product().family() != descriptor.family()) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_dispatch_compiled_product_mismatch",
        "the constraint descriptor does not own a matching compiled product"));
  }

  if (condition.has_value()) {
    if (!known_forced_bit(condition->bit)) {
      return Result<void>::failure(dispatch_internal(
          "optimizer_forced_bit_invalid",
          "the forced-target bit is outside the closed binary domain"));
    }
    if (condition->target.ordinal() >= weights.size()) {
      return Result<void>::failure(dispatch_internal(
          "optimizer_forced_target_out_of_range",
          "the forced-target dense index is outside the exact query "
          "dimension"));
    }
    if (!condition->target.matches(weights.dimension())) {
      return Result<void>::failure(dispatch_internal(
          "optimizer_forced_target_identity_mismatch",
          "the forced target belongs to a different exact query dimension"));
    }

    const OptimizerQueryKind expected_kind =
        condition->bit == ForcedTargetBit::zero
            ? OptimizerQueryKind::forced_zero
            : OptimizerQueryKind::forced_one;
    if (budget.query_kind() != expected_kind) {
      return Result<void>::failure(dispatch_internal(
          "optimizer_forced_query_kind_mismatch",
          "the reserved query kind disagrees with its forced-target bit"));
    }
    if (!budget.query_target().has_value() ||
        *budget.query_target() != condition->target) {
      return Result<void>::failure(dispatch_internal(
          "optimizer_forced_query_target_mismatch",
          "the reserved query target disagrees with its forced-target "
          "condition"));
    }
  } else if (is_forced_query(budget.query_kind())) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_forced_condition_missing",
        "a forced optimizer reservation requires a typed target condition"));
  } else if (budget.query_target().has_value()) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_query_target_unexpected",
        "a non-forced optimizer query cannot carry a target identity"));
  }

  return Result<void>::success();
}

[[nodiscard]] bool has_eligible_queue(
    const EligibilityMask& eligibility) noexcept {
  return std::any_of(eligibility.bytes().begin(), eligibility.bytes().end(),
                     [](const std::uint8_t value) { return value != 0U; });
}

[[nodiscard]] Result<void> crosscheck_backend_candidate(
    const detail::ExactBackendCandidate& candidate,
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    const SearchBudget& budget,
    const detail::ForcedTargetCondition* condition) {
  const DerivedServiceIdentity expected = descriptor.identity();
  if (candidate.family() != expected.family) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_backend_family_mismatch",
        "the exact backend returned a solution for another service family",
        {"expected: " + std::string(to_string(expected.family)),
         "reported: " + std::string(to_string(candidate.family()))}));
  }
  if (candidate.backend_id() != expected.optimizer) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_backend_identity_mismatch",
        "the exact backend returned the wrong optimizer identity",
        {"expected: " + std::string(to_string(expected.optimizer)),
         "reported: " + std::string(to_string(candidate.backend_id()))}));
  }
  if (candidate.schedule().dimension() != weights.dimension() ||
      candidate.schedule().dimension() != eligibility.dimension()) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_backend_schedule_dimension_mismatch",
        "the exact backend returned a schedule from another queue "
        "dimension"));
  }

  const SearchAccounting observed = budget.accounting();
  if (candidate.accounting() != observed) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_backend_accounting_mismatch",
        "the exact backend return does not contain the live solve budget's "
        "accounting snapshot"));
  }
  if (!candidate.accounting().family().has_value() ||
      *candidate.accounting().family() != expected.family ||
      candidate.accounting().exhausted()) {
    return Result<void>::failure(dispatch_internal(
        "optimizer_backend_accounting_invalid",
        "a successful exact solution must report its dispatched family and "
        "must not report exhaustion"));
  }

  if (condition != nullptr) {
    const bool selected =
        candidate.schedule().bytes()[condition->target.ordinal()] != 0U;
    const bool required = condition->bit == ForcedTargetBit::one;
    if (selected != required) {
      return Result<void>::failure(dispatch_internal(
          "optimizer_backend_forced_side_mismatch",
          "the exact backend witness violates its forced-target condition"));
    }
  }

  return Result<void>::success();
}

}  // namespace

detail::ExactBackendCandidate detail::ExactBackendAuthority::make_candidate(
    Schedule schedule, BigNat composite_objective,
    const ServiceFamily family, const OptimizerId backend_id,
    SearchAccounting accounting, std::vector<std::string> proof_notes) const {
  // The capability is created only around a live, already claimed dispatch.
  // Its address binding is deliberately not serialized into scientific
  // accounting; it merely prevents candidate construction outside that call.
  (void)budget_;
  return ExactBackendCandidate(
      std::move(schedule), std::move(composite_objective), family, backend_id,
      std::move(accounting), std::move(proof_notes));
}

OptimizerSolution detail::ExactDispatchAccess::promote(
    ExactBackendCandidate candidate) {
  return OptimizerSolution(
      std::move(candidate.schedule_),
      std::move(candidate.composite_objective_), candidate.family_,
      candidate.backend_id_, ProvenOptimal(ProvenOptimal::ExactBackendTag{}),
      std::move(candidate.accounting_), std::move(candidate.proof_notes_));
}

Result<OptimizerSolution> detail::ExactDispatchAccess::validate_and_promote(
    ExactBackendCandidate candidate, const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    const SearchBudget& budget, const ForcedTargetCondition* condition) {
  auto checked = crosscheck_backend_candidate(
      candidate, descriptor, eligibility, weights, budget, condition);
  if (!checked) {
    return Result<OptimizerSolution>::failure(std::move(checked.error()));
  }

  OptimizerSolution solution =
      promote(std::move(candidate));
  auto validated = detail::validate_optimizer_solution_core(
      solution, descriptor, eligibility, weights);
  if (!validated) {
    return Result<OptimizerSolution>::failure(std::move(validated.error()));
  }
  return Result<OptimizerSolution>::success(std::move(solution));
}

namespace {
#if defined(MWPERF_C05_TEST_SEAMS)
template <typename Constraint>
[[nodiscard]] const detail::ExactBackend<Constraint>& backend_for(
    const detail::ExactOptimizerBackendServices& services) {
  if constexpr (std::is_same_v<Constraint, ResolvedCrossbarConstraint>) {
    return services.crossbar;
  } else if constexpr (std::is_same_v<Constraint,
                                      ResolvedIntervalConstraint>) {
    return services.intervals;
  } else if constexpr (std::is_same_v<Constraint,
                                      ResolvedNodeExclusiveConstraint>) {
    return services.node_exclusive;
  } else if constexpr (std::is_same_v<Constraint,
                                      ResolvedConflictConstraint>) {
    return services.conflicts;
  } else {
    static_assert(std::is_same_v<Constraint, ResolvedPackingConstraint>);
    return services.packing;
  }
}
#endif

}  // namespace

Result<OptimizerSolution> detail::ExactDispatchAccess::dispatch(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget, const ForcedTargetCondition* condition) {
  try {
    // The call reservation is single-use even when the query is malformed or
    // a backend is unavailable. Claim before inspecting or invoking any
    // backend so no failure path can reuse the reservation for a second solve.
    auto claim = detail::SearchBudgetAccess::claim_dispatch(
        budget, descriptor.family());
    if (!claim) {
      return Result<OptimizerSolution>::failure(std::move(claim.error()));
    }

    const std::optional<ForcedTargetCondition> owned_condition =
        condition == nullptr
            ? std::nullopt
            : std::optional<ForcedTargetCondition>{*condition};
    auto query = validate_dispatch_query(descriptor, eligibility, weights,
                                         budget, owned_condition);
    if (!query) {
      return Result<OptimizerSolution>::failure(std::move(query.error()));
    }

    // With no eligible coordinate, downward closure leaves exactly the empty
    // schedule. Forced-one is deliberately excluded: its target eligibility
    // is structural and only the family conditioning adapter may decide that
    // side.
    if (!has_eligible_queue(eligibility) &&
        (condition == nullptr || condition->bit == ForcedTargetBit::zero)) {
      ExactBackendCandidate candidate(
          Schedule::none(eligibility.dimension()), BigNat(std::uint64_t{0U}),
          descriptor.family(), descriptor.identity().optimizer,
          budget.accounting(), {"C05 exact empty-eligibility base case"});
      return validate_and_promote(std::move(candidate), descriptor,
                                  eligibility, weights, budget, condition);
    }

    ExactBackendAuthority authority(budget);
    return std::visit(
        [&](const auto& concrete) -> Result<OptimizerSolution> {
        using Constraint = std::decay_t<decltype(concrete)>;
        Result<ExactBackendCandidate> candidate = [&]() {
          if constexpr (std::is_same_v<Constraint,
                                       ResolvedCrossbarConstraint>) {
            return dispatch_registered_crossbar(
                concrete, descriptor.compiled_product(), eligibility,
                weights, budget, owned_condition, authority);
          } else if constexpr (std::is_same_v<
                                   Constraint,
                                   ResolvedIntervalConstraint>) {
            return dispatch_registered_intervals(
                concrete, descriptor.compiled_product(), eligibility,
                weights, budget, owned_condition, authority);
          } else if constexpr (std::is_same_v<
                                   Constraint,
                                   ResolvedNodeExclusiveConstraint>) {
            return dispatch_registered_node_exclusive(
                concrete, descriptor.compiled_product(), eligibility,
                weights, budget, owned_condition, authority);
          } else if constexpr (std::is_same_v<
                                   Constraint,
                                   ResolvedConflictConstraint>) {
            return dispatch_registered_conflicts(
                concrete, descriptor.compiled_product(), eligibility,
                weights, budget, owned_condition, authority);
          } else if constexpr (std::is_same_v<
                                   Constraint,
                                   ResolvedPackingConstraint>) {
            return dispatch_registered_packing(
                concrete, descriptor.compiled_product(), eligibility,
                weights, budget, owned_condition, authority);
          } else {
            static_assert(!sizeof(Constraint),
                          "unhandled closed exact constraint variant");
          }
        }();
        if (!candidate) {
          return Result<OptimizerSolution>::failure(
              std::move(candidate.error()));
        }
        return validate_and_promote(
            std::move(candidate).value(), descriptor, eligibility, weights,
            budget, condition);
        },
        descriptor.value());
  } catch (const std::bad_alloc&) {
    return Result<OptimizerSolution>::failure(dispatch_resource_error(
        "optimizer_dispatch_allocation_failure",
        "allocation failed during the cold exact optimizer dispatch"));
  } catch (const std::length_error&) {
    return Result<OptimizerSolution>::failure(dispatch_resource_error(
        "optimizer_dispatch_representation_failure",
        "the cold exact optimizer dispatch exceeds a host container limit"));
  }
}

#if defined(MWPERF_C05_TEST_SEAMS)
Result<OptimizerSolution>
detail::ExactDispatchAccess::dispatch_with_backend_services(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget, const ForcedTargetCondition* condition,
    const ExactOptimizerBackendServices& services) {
  try {
    auto claim =
        SearchBudgetAccess::claim_dispatch(budget, descriptor.family());
    if (!claim) {
      return Result<OptimizerSolution>::failure(std::move(claim.error()));
    }

    const std::optional<ForcedTargetCondition> owned_condition =
        condition == nullptr
            ? std::nullopt
            : std::optional<ForcedTargetCondition>{*condition};
    auto query = validate_dispatch_query(descriptor, eligibility, weights,
                                         budget, owned_condition);
    if (!query) {
      return Result<OptimizerSolution>::failure(std::move(query.error()));
    }

    if (!has_eligible_queue(eligibility) &&
        (condition == nullptr || condition->bit == ForcedTargetBit::zero)) {
      ExactBackendCandidate candidate(
          Schedule::none(eligibility.dimension()), BigNat(std::uint64_t{0U}),
          descriptor.family(), descriptor.identity().optimizer,
          budget.accounting(), {"C05 exact empty-eligibility base case"});
      return validate_and_promote(std::move(candidate), descriptor,
                                  eligibility, weights, budget, condition);
    }

    ExactBackendAuthority authority(budget);
    return std::visit(
        [&](const auto& concrete) -> Result<OptimizerSolution> {
        using Constraint = std::decay_t<decltype(concrete)>;
        const auto& backend = backend_for<Constraint>(services);
        if (!backend) {
          return Result<OptimizerSolution>::failure(
              unavailable_backend(descriptor));
        }
        auto candidate = backend(concrete, descriptor.compiled_product(),
                                 eligibility, weights, budget,
                                 owned_condition, authority);
        if (!candidate) {
          return Result<OptimizerSolution>::failure(
              std::move(candidate.error()));
        }
        return validate_and_promote(
            std::move(candidate).value(), descriptor, eligibility, weights,
            budget, condition);
        },
        descriptor.value());
  } catch (const std::bad_alloc&) {
    return Result<OptimizerSolution>::failure(dispatch_resource_error(
        "optimizer_dispatch_allocation_failure",
        "allocation failed during the cold exact optimizer dispatch"));
  } catch (const std::length_error&) {
    return Result<OptimizerSolution>::failure(dispatch_resource_error(
        "optimizer_dispatch_representation_failure",
        "the cold exact optimizer dispatch exceeds a host container limit"));
  }
}
#endif

Result<OptimizerSolution> solve_exact(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget) {
  return detail::ExactDispatchAccess::dispatch(
      descriptor, eligibility, weights, budget, nullptr);
}

Result<OptimizerSolution> detail::solve_exact_conditioned(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    std::optional<detail::ForcedTargetCondition> condition) {
  return ExactDispatchAccess::dispatch(
      descriptor, eligibility, weights, budget,
      condition.has_value() ? &*condition : nullptr);
}

#if defined(MWPERF_C05_TEST_SEAMS)
Result<OptimizerSolution> detail::solve_exact_with_backend_services(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    std::optional<detail::ForcedTargetCondition> condition,
    const ExactOptimizerBackendServices& services) {
  return ExactDispatchAccess::dispatch_with_backend_services(
      descriptor, eligibility, weights, budget,
      condition.has_value() ? &*condition : nullptr, services);
}
#endif

}  // namespace mwperf
