#include "mwperf/optimizer/interval.hpp"

#include <cstddef>
#include <cstdint>
#include <new>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {
namespace {

[[nodiscard]] Diagnostic interval_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic interval_allocation_error() {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "interval_solve_allocation_failure",
      .message =
          "allocation failed during the cold exact interval solve",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] bool interval_key_less(const ExactInterval& lhs,
                                     const ExactInterval& rhs) {
  if (lhs.right != rhs.right) {
    return lhs.right < rhs.right;
  }
  if (lhs.left != rhs.left) {
    return lhs.left < rhs.left;
  }
  return lhs.queue < rhs.queue;
}

[[nodiscard]] bool intervals_compatible(const ExactInterval& lhs,
                                        const ExactInterval& rhs) {
  // Both intervals are half-open. Exact endpoint contact is compatible in
  // either orientation.
  return lhs.right <= rhs.left || rhs.right <= lhs.left;
}

[[nodiscard]] bool known_forced_bit(const ForcedTargetBit bit) noexcept {
  switch (bit) {
    case ForcedTargetBit::zero:
    case ForcedTargetBit::one:
      return true;
  }
  return false;
}

// This validation is intentionally linear. IntervalProblem is immutable in
// production, but checking it at the solve boundary keeps a corrupt test or
// future compiled product from reaching unchecked indices without changing
// the O(m) solve bound.
[[nodiscard]] Result<void> validate_interval_problem(
    const IntervalProblem& problem) {
  const std::span<const ExactInterval> intervals = problem.intervals();
  const std::span<const std::optional<std::size_t>> predecessors =
      problem.predecessors();
  const std::span<const std::size_t> queue_to_ordered =
      problem.queue_to_ordered();
  const std::size_t queue_count = problem.queue_count();

  if (queue_count == 0U) {
    return Result<void>::failure(interval_error(
        "interval_problem_empty",
        "an exact interval problem must contain at least one queue"));
  }
  if (intervals.size() != queue_count ||
      predecessors.size() != queue_count ||
      queue_to_ordered.size() != queue_count) {
    return Result<void>::failure(interval_error(
        "interval_problem_dimension_corrupt",
        "the compiled interval arrays have inconsistent dimensions",
        {"interval records: " + std::to_string(intervals.size()),
         "predecessor records: " +
             std::to_string(predecessors.size()),
         "queue map records: " +
             std::to_string(queue_to_ordered.size())}));
  }

  std::vector<std::uint8_t> seen(queue_count, std::uint8_t{0U});
  for (std::size_t ordered = 0U; ordered < queue_count; ++ordered) {
    const ExactInterval& interval = intervals[ordered];
    const std::size_t queue = interval.queue.ordinal();
    if (queue >= queue_count) {
      return Result<void>::failure(interval_error(
          "interval_problem_queue_out_of_range",
          "a compiled interval contains an out-of-range dense queue",
          {"ordered position: " + std::to_string(ordered),
           "dense queue index: " + std::to_string(queue)}));
    }
    if (seen[queue] != 0U) {
      return Result<void>::failure(interval_error(
          "interval_problem_queue_duplicate",
          "a dense queue occurs more than once in the compiled intervals",
          {"dense queue index: " + std::to_string(queue)}));
    }
    seen[queue] = 1U;

    if (!(interval.left < interval.right)) {
      return Result<void>::failure(interval_error(
          "interval_problem_bounds_corrupt",
          "a compiled interval does not satisfy exact left < right",
          {"dense queue index: " + std::to_string(queue)}));
    }
    if (queue_to_ordered[queue] != ordered) {
      return Result<void>::failure(interval_error(
          "interval_problem_queue_map_corrupt",
          "the dense-queue reconstruction map is not the inverse of the "
          "ordered interval array",
          {"dense queue index: " + std::to_string(queue),
           "expected ordered position: " + std::to_string(ordered),
           "reported ordered position: " +
               std::to_string(queue_to_ordered[queue])}));
    }
    if (ordered != 0U &&
        !interval_key_less(intervals[ordered - 1U], interval)) {
      return Result<void>::failure(interval_error(
          "interval_problem_order_corrupt",
          "compiled intervals are not in strict exact "
          "right/left/queue order",
          {"first invalid ordered position: " +
           std::to_string(ordered)}));
    }

    const std::optional<std::size_t> predecessor = predecessors[ordered];
    if (predecessor.has_value()) {
      if (*predecessor >= ordered) {
        return Result<void>::failure(interval_error(
            "interval_problem_predecessor_not_earlier",
            "a compiled predecessor does not precede its interval",
            {"ordered position: " + std::to_string(ordered),
             "predecessor: " + std::to_string(*predecessor)}));
      }
      if (!(intervals[*predecessor].right <= interval.left)) {
        return Result<void>::failure(interval_error(
            "interval_problem_predecessor_incompatible",
            "a compiled predecessor is not half-open compatible with its "
            "interval",
            {"ordered position: " + std::to_string(ordered),
             "predecessor: " + std::to_string(*predecessor)}));
      }
      if (*predecessor + 1U < ordered &&
          intervals[*predecessor + 1U].right <= interval.left) {
        return Result<void>::failure(interval_error(
            "interval_problem_predecessor_nonmaximal",
            "a compiled predecessor is not the latest compatible earlier "
            "interval",
            {"ordered position: " + std::to_string(ordered),
             "predecessor: " + std::to_string(*predecessor)}));
      }
    } else if (ordered != 0U &&
               intervals.front().right <= interval.left) {
      return Result<void>::failure(interval_error(
          "interval_problem_predecessor_missing",
          "a compiled interval omits an existing compatible predecessor",
          {"ordered position: " + std::to_string(ordered)}));
    }
  }

  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    const std::size_t ordered = queue_to_ordered[queue];
    if (seen[queue] == 0U || ordered >= queue_count ||
        intervals[ordered].queue.ordinal() != queue) {
      return Result<void>::failure(interval_error(
          "interval_problem_queue_map_corrupt",
          "the compiled interval queue map is not a dense bijection",
          {"dense queue index: " + std::to_string(queue)}));
    }
  }

  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_interval_query(
    const IntervalProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition) {
  if (eligibility.dimension() != weights.dimension()) {
    return Result<void>::failure(interval_error(
        "interval_query_dimension_identity_mismatch",
        "interval eligibility and weights belong to different queue "
        "dimensions"));
  }
  if (weights.dimension().family() !=
      ServiceFamily::nonoverlapping_intervals) {
    return Result<void>::failure(interval_error(
        "interval_query_family_mismatch",
        "the interval primitive received a queue dimension for another "
        "service family"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(interval_error(
        "interval_query_eligibility_mismatch",
        "the interval eligibility mask disagrees with the mask embedded in "
        "the exact weights"));
  }
  if (eligibility.size() != problem.queue_count() ||
      weights.size() != problem.queue_count()) {
    return Result<void>::failure(interval_error(
        "interval_query_dimension_mismatch",
        "the interval query does not match its compiled queue dimension",
        {"compiled queues: " + std::to_string(problem.queue_count()),
         "eligibility entries: " + std::to_string(eligibility.size()),
         "weight entries: " + std::to_string(weights.size())}));
  }

  if (condition == nullptr) {
    return Result<void>::success();
  }
  if (!known_forced_bit(condition->bit)) {
    return Result<void>::failure(interval_error(
        "interval_forced_bit_invalid",
        "the interval forced-target bit is outside the binary domain"));
  }
  const std::size_t target = condition->target.ordinal();
  if (target >= problem.queue_count()) {
    return Result<void>::failure(interval_error(
        "interval_forced_target_out_of_range",
        "the interval forced target lies outside the compiled queue "
        "dimension",
        {"target dense index: " + std::to_string(target)}));
  }
  if (!condition->target.matches(weights.dimension())) {
    return Result<void>::failure(interval_error(
        "interval_forced_target_identity_mismatch",
        "the interval forced target belongs to another queue dimension"));
  }
  const bool target_eligible = eligibility.bytes()[target] != 0U;
  const bool target_required = condition->bit == ForcedTargetBit::one;
  if (target_eligible != target_required) {
    return Result<void>::failure(interval_error(
        "interval_forced_target_eligibility_mismatch",
        "the conditioned target eligibility does not match the requested "
        "forced side",
        {"target dense index: " + std::to_string(target),
         "requested side: " + std::string(to_string(condition->bit))}));
  }
  return Result<void>::success();
}

enum class IntervalDecision : std::uint8_t {
  skip,
  take,
};

[[nodiscard]] Result<IntervalExactWitness> solve_interval_exact_core(
    const IntervalProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition,
    const IntervalTestFault fault) {
  try {
    auto problem_validation = validate_interval_problem(problem);
    if (!problem_validation) {
      return Result<IntervalExactWitness>::failure(
          std::move(problem_validation.error()));
    }
    auto query_validation =
        validate_interval_query(problem, eligibility, weights, condition);
    if (!query_validation) {
      return Result<IntervalExactWitness>::failure(
          std::move(query_validation.error()));
    }
    if (fault != IntervalTestFault::none &&
        fault != IntervalTestFault::force_equal_transition) {
      return Result<IntervalExactWitness>::failure(interval_error(
          "interval_test_fault_invalid",
          "the interval test fault is outside its closed domain"));
    }

    const std::span<const ExactInterval> intervals = problem.intervals();
    const std::span<const std::optional<std::size_t>> predecessors =
        problem.predecessors();
    const std::size_t queue_count = problem.queue_count();

    std::vector<std::uint8_t> enabled(queue_count, std::uint8_t{0U});
    for (std::size_t ordered = 0U; ordered < queue_count; ++ordered) {
      const std::size_t queue = intervals[ordered].queue.ordinal();
      enabled[ordered] = eligibility.bytes()[queue];
    }

    std::optional<std::size_t> committed_target;
    if (condition != nullptr) {
      const std::size_t target_queue = condition->target.ordinal();
      const std::size_t target_ordered =
          problem.queue_to_ordered()[target_queue];
      enabled[target_ordered] = std::uint8_t{0U};

      if (condition->bit == ForcedTargetBit::one) {
        committed_target = target_queue;
        const ExactInterval& target = intervals[target_ordered];
        // The target is committed outside the residual DP. Remove precisely
        // the intervals that conflict with it; touching intervals on either
        // side remain available. The immutable predecessor table is valid for
        // every subset obtained by disabling take branches.
        for (std::size_t ordered = 0U; ordered < queue_count; ++ordered) {
          if (ordered != target_ordered &&
              !intervals_compatible(intervals[ordered], target)) {
            enabled[ordered] = std::uint8_t{0U};
          }
        }
      }
    }

    const BigNat zero(std::uint64_t{0U});
    std::vector<BigNat> scores(queue_count + 1U, zero);
    std::vector<IntervalDecision> decisions(queue_count + 1U,
                                            IntervalDecision::skip);
    bool fault_injected = false;

    for (std::size_t state = 1U; state <= queue_count; ++state) {
      const std::size_t ordered = state - 1U;
      const BigNat& skip_score = scores[state - 1U];
      if (enabled[ordered] == 0U) {
        // Ineligibility removes the take branch. It is not a zero-weight
        // alternative and therefore cannot create an equality diagnostic.
        scores[state] = skip_score;
        continue;
      }

      const std::optional<std::size_t> predecessor = predecessors[ordered];
      const std::size_t predecessor_state =
          predecessor.has_value() ? *predecessor + 1U : 0U;
      BigNat take_score =
          weights.at(intervals[ordered].queue) + scores[predecessor_state];
      if (fault == IntervalTestFault::force_equal_transition &&
          !fault_injected) {
        take_score = skip_score;
        fault_injected = true;
      }

      if (take_score == skip_score) {
        return Result<IntervalExactWitness>::failure(interval_error(
            "interval_composite_equality_invariant",
            "distinct take and skip schedules have equal composite scores",
            {"ordered position: " + std::to_string(ordered),
             "dense queue index: " +
                 std::to_string(intervals[ordered].queue.ordinal())}));
      }
      if (take_score > skip_score) {
        scores[state] = std::move(take_score);
        decisions[state] = IntervalDecision::take;
      } else {
        scores[state] = skip_score;
      }
    }

    if (fault == IntervalTestFault::force_equal_transition &&
        !fault_injected) {
      return Result<IntervalExactWitness>::failure(interval_error(
          "interval_test_equal_transition_unreachable",
          "the requested equality fault had no eligible interval branch"));
    }

    std::vector<std::uint8_t> selected(queue_count, std::uint8_t{0U});
    std::size_t state = queue_count;
    while (state != 0U) {
      const std::size_t ordered = state - 1U;
      if (decisions[state] == IntervalDecision::skip) {
        --state;
        continue;
      }
      if (decisions[state] != IntervalDecision::take ||
          enabled[ordered] == 0U) {
        return Result<IntervalExactWitness>::failure(interval_error(
            "interval_traceback_decision_corrupt",
            "interval traceback encountered an invalid take decision",
            {"DP state: " + std::to_string(state)}));
      }
      const std::size_t queue = intervals[ordered].queue.ordinal();
      if (selected[queue] != 0U) {
        return Result<IntervalExactWitness>::failure(interval_error(
            "interval_traceback_queue_duplicate",
            "interval traceback selected a dense queue more than once",
            {"dense queue index: " + std::to_string(queue)}));
      }
      selected[queue] = 1U;

      const std::optional<std::size_t> predecessor = predecessors[ordered];
      const std::size_t next_state =
          predecessor.has_value() ? *predecessor + 1U : 0U;
      if (next_state >= state) {
        return Result<IntervalExactWitness>::failure(interval_error(
            "interval_traceback_cycle",
            "interval traceback did not strictly decrease its DP state",
            {"DP state: " + std::to_string(state),
             "next state: " + std::to_string(next_state)}));
      }
      state = next_state;
    }

    BigNat expected_objective = scores.back();
    if (committed_target.has_value()) {
      if (selected[*committed_target] != 0U) {
        return Result<IntervalExactWitness>::failure(interval_error(
            "interval_forced_target_residual_corrupt",
            "the forced target unexpectedly entered the residual DP"));
      }
      selected[*committed_target] = 1U;
      expected_objective += weights.values()[*committed_target];
    }

    BigNat recomputed_objective(std::uint64_t{0U});
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if (selected[queue] != 0U) {
        recomputed_objective += weights.values()[queue];
      }
    }
    if (recomputed_objective != expected_objective) {
      return Result<IntervalExactWitness>::failure(interval_error(
          "interval_objective_reconstruction_invariant",
          "the reconstructed interval schedule does not reproduce its exact "
          "DP objective",
          {"DP objective: " + expected_objective.to_decimal_string(),
           "recomputed objective: " +
               recomputed_objective.to_decimal_string()}));
    }

    auto schedule =
        Schedule::from_bytes(weights.dimension(), std::move(selected));
    if (!schedule) {
      return Result<IntervalExactWitness>::failure(
          std::move(schedule.error()));
    }
    return Result<IntervalExactWitness>::success(IntervalExactWitness{
        .schedule = std::move(schedule).value(),
        .composite_objective = std::move(recomputed_objective),
        .proof_notes = {
            "C06 exact weighted-interval dynamic program",
            "exact half-open predecessor compatibility",
            "cold solve with solve-local scores and backpointers",
        },
    });
  } catch (const std::bad_alloc&) {
    return Result<IntervalExactWitness>::failure(
        interval_allocation_error());
  } catch (const std::length_error&) {
    return Result<IntervalExactWitness>::failure(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "interval_solve_representation_failure",
        .message =
            "the cold exact interval workspace exceeds a host container limit",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  }
}

}  // namespace

Result<IntervalExactWitness> solve_interval_exact(
    const IntervalProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition) {
  return solve_interval_exact_core(problem, eligibility, weights, condition,
                                   IntervalTestFault::none);
}

#if defined(MWPERF_C06_TEST_SEAMS)
Result<IntervalExactWitness> solve_interval_exact_with_fault(
    const IntervalProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition,
    const IntervalTestFault fault) {
  return solve_interval_exact_core(problem, eligibility, weights, condition,
                                   fault);
}
#endif

}  // namespace mwperf::detail
