#include "mwperf/optimizer/exact_optimizer.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/node_exclusive.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {

namespace {

[[nodiscard]] Diagnostic registration_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Result<void> verify_node_exclusive_binding(
    const ResolvedNodeExclusiveConstraint& constraint,
    const NodeExclusiveProblem& problem) {
  if (constraint.vertices.size() != problem.vertex_count() ||
      constraint.links.size() != problem.queue_count() ||
      problem.vertices().size() != problem.vertex_count() ||
      problem.links().size() != problem.queue_count() ||
      problem.queue_to_link().size() != problem.queue_count()) {
    return Result<void>::failure(registration_error(
        "node_exclusive_compiled_product_binding_mismatch",
        "the immutable node-exclusive problem does not match its bound "
        "descriptor",
        {"descriptor vertices/queues: " +
             std::to_string(constraint.vertices.size()) + "/" +
             std::to_string(constraint.links.size()),
         "compiled vertices/queues: " +
             std::to_string(problem.vertex_count()) + "/" +
             std::to_string(problem.queue_count())}));
  }

  std::vector<std::uint8_t> seen_vertices(problem.vertex_count(), 0U);
  for (const ResolvedVertex& vertex : constraint.vertices) {
    const std::size_t ordinal = vertex.index.ordinal();
    if (ordinal >= problem.vertex_count() ||
        seen_vertices[ordinal] != 0U ||
        problem.vertices()[ordinal].index.ordinal() != ordinal) {
      return Result<void>::failure(registration_error(
          "node_exclusive_descriptor_vertex_binding_invalid",
          "the bound node-exclusive descriptor has corrupt dense vertex "
          "coverage"));
    }
    seen_vertices[ordinal] = 1U;
  }

  std::vector<std::uint8_t> seen_queues(problem.queue_count(), 0U);
  for (const ResolvedNodeExclusiveLink& link : constraint.links) {
    const std::size_t queue = link.queue.ordinal();
    if (queue >= problem.queue_count() || seen_queues[queue] != 0U) {
      return Result<void>::failure(registration_error(
          "node_exclusive_descriptor_queue_binding_invalid",
          "the bound node-exclusive descriptor has corrupt dense queue "
          "coverage"));
    }
    seen_queues[queue] = 1U;

    const std::size_t position = problem.queue_to_link()[queue];
    if (position >= problem.links().size()) {
      return Result<void>::failure(registration_error(
          "node_exclusive_compiled_product_binding_mismatch",
          "the immutable node-exclusive problem has an out-of-range queue "
          "map",
          {"dense queue index: " + std::to_string(queue)}));
    }

    std::size_t first = link.u.ordinal();
    std::size_t second = link.v.ordinal();
    if (second < first) {
      std::swap(first, second);
    }
    const NodeExclusiveLabelledLink& compiled = problem.links()[position];
    if (compiled.queue.ordinal() != queue || compiled.first != first ||
        compiled.second != second) {
      return Result<void>::failure(registration_error(
          "node_exclusive_compiled_product_binding_mismatch",
          "the immutable node-exclusive problem geometry differs from its "
          "bound descriptor",
          {"dense queue index: " + std::to_string(queue)}));
    }
  }
  return Result<void>::success();
}

}  // namespace

Result<const NodeExclusiveProblem*>
C07CompiledProductAccess::node_exclusive(
    const CompiledConstraintProduct& product,
    const ExactBackendAuthority& authority) {
  (void)authority;
  if (product.family_ != ServiceFamily::node_exclusive_matching ||
      product.compiled_type_tag_ !=
          NodeExclusiveProblem::compiled_type_tag() ||
      !product.owner_) {
    return Result<const NodeExclusiveProblem*>::failure(registration_error(
        "node_exclusive_compiled_product_type_mismatch",
        "the node-exclusive backend did not receive a typed C07 compiled "
        "product"));
  }
  return Result<const NodeExclusiveProblem*>::success(
      static_cast<const NodeExclusiveProblem*>(product.owner_.get()));
}

Result<ExactBackendCandidate> dispatch_registered_node_exclusive(
    const ResolvedNodeExclusiveConstraint& constraint,
    const CompiledConstraintProduct& product,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    const std::optional<ForcedTargetCondition>& condition,
    const ExactBackendAuthority& authority) {
  auto recovered =
      C07CompiledProductAccess::node_exclusive(product, authority);
  if (!recovered) {
    return Result<ExactBackendCandidate>::failure(
        std::move(recovered.error()));
  }
  auto binding = verify_node_exclusive_binding(constraint,
                                                *recovered.value());
  if (!binding) {
    return Result<ExactBackendCandidate>::failure(std::move(binding.error()));
  }

  auto witness = solve_node_exclusive_exact(
      *recovered.value(), eligibility, weights,
      condition.has_value() ? &*condition : nullptr);
  if (!witness) {
    return Result<ExactBackendCandidate>::failure(std::move(witness.error()));
  }
  NodeExclusiveExactWitness exact = std::move(witness).value();
  return Result<ExactBackendCandidate>::success(authority.make_candidate(
      std::move(exact.schedule), std::move(exact.composite_objective),
      ServiceFamily::node_exclusive_matching,
      OptimizerId::edmonds_blossom_exact, budget.accounting(),
      std::move(exact.proof_notes)));
}

}  // namespace mwperf::detail
