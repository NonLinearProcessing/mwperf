#include "mwperf/optimizer/lexicographic.hpp"

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic lex_error(std::string code, std::string message,
                                   std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

}  // namespace

#if defined(MWPERF_C05_TEST_SEAMS)
QueueDimensionToken QueueDimensionToken::for_fixture(
    Digest256 combined_input, const std::size_t cardinality,
    const ConstraintDescriptor& descriptor,
    const PriorityOrder& configured_priority,
    const OptimizerBudgetPolicy& base_optimizer_policy) {
  const CompiledConstraintProduct& product = descriptor.compiled_product();
  return QueueDimensionToken(
      std::move(combined_input), cardinality, descriptor.family(),
      std::make_shared<const PriorityOrder>(configured_priority),
      base_optimizer_policy, product.owner_);
}

PriorityOrder detail::LexicographicTestAccess::make_priority_for_fixture(
    std::vector<DenseQueueIndex> rank_to_queue,
    std::vector<std::size_t> queue_to_rank) {
  return PriorityOrder(std::move(rank_to_queue), std::move(queue_to_rank));
}
#endif

Result<LexWeights> detail::LexWeightsAccess::compose(
    const NonnegativeIntegralWeights& primary,
    const PriorityOrder& priority, const EligibilityMask& eligibility) {
  if (primary.dimension() != eligibility.dimension()) {
    return Result<LexWeights>::failure(lex_error(
        "lexicographic_dimension_identity_mismatch",
        "primary weights and eligibility belong to different queue dimensions"));
  }

  if (!primary.dimension().matches_priority(priority)) {
    return Result<LexWeights>::failure(lex_error(
        "lexicographic_priority_identity_mismatch",
        "the priority order does not match the configured queue-dimension identity"));
  }

  const std::size_t dimension = primary.size();
  if (priority.size() != dimension) {
    return Result<LexWeights>::failure(lex_error(
        "lexicographic_priority_dimension_mismatch",
        "the priority order does not match the exact weight dimension",
        {"expected " + std::to_string(dimension) + " ranks; received " +
         std::to_string(priority.size())}));
  }
  if (priority.queue_to_rank().size() != dimension) {
    return Result<LexWeights>::failure(lex_error(
        "lexicographic_priority_inverse_dimension_mismatch",
        "the priority inverse-rank table does not match the exact weight dimension",
        {"expected " + std::to_string(dimension) + " inverse ranks; received " +
         std::to_string(priority.queue_to_rank().size())}));
  }

  // Recheck the C04 invariant at this trust boundary. This makes a malformed
  // test/future-child PriorityOrder fail transactionally instead of indexing a
  // composite-weight vector with a duplicated or out-of-range queue.
  std::vector<std::uint8_t> seen(dimension, 0U);
  for (std::size_t rank = 0; rank < dimension; ++rank) {
    const DenseQueueIndex queue = priority.queue_at_rank(rank);
    const std::size_t ordinal = queue.ordinal();
    if (ordinal >= dimension) {
      return Result<LexWeights>::failure(lex_error(
          "lexicographic_priority_index_out_of_range",
          "the priority order contains an out-of-range dense queue index"));
    }
    if (seen[ordinal] != 0U) {
      return Result<LexWeights>::failure(lex_error(
          "lexicographic_priority_not_permutation",
          "the priority order contains a repeated dense queue index"));
    }
    if (priority.queue_to_rank()[ordinal] != rank) {
      return Result<LexWeights>::failure(lex_error(
          "lexicographic_priority_inverse_mismatch",
          "the priority rank and inverse-rank tables disagree"));
    }
    seen[ordinal] = 1U;
  }

  // B and every priority bit are arbitrary-precision integers. The shift is a
  // cpp_int operation, never a native-width shift, so m >= 65 has exactly the
  // same semantics as a small instance and cannot overflow.
  BigInt base_value = 1;
  base_value <<= dimension;
  BigInt next_priority_bit = base_value;
  if (dimension != 0U) {
    next_priority_bit >>= 1U;
  }

  std::vector<BigNat> composite(dimension, BigNat(std::uint64_t{0U}));
  std::vector<BigNat> secondary(dimension, BigNat(std::uint64_t{0U}));

  for (std::size_t rank = 0; rank < dimension; ++rank) {
    const std::size_t ordinal = priority.queue_at_rank(rank).ordinal();

    BigInt composite_value =
        base_value * primary.values()[ordinal].value() + next_priority_bit;
    auto exact_composite = BigNat::from_big_int(std::move(composite_value));
    auto exact_secondary = BigNat::from_big_int(next_priority_bit);
    if (!exact_composite || !exact_secondary) {
      return Result<LexWeights>::failure(lex_error(
          "lexicographic_nonnegative_invariant_broken",
          "exact lexicographic composition unexpectedly produced a negative value"));
    }
    composite[ordinal] = std::move(exact_composite).value();
    secondary[ordinal] = std::move(exact_secondary).value();
    next_priority_bit >>= 1U;
  }

  auto exact_base = BigNat::from_big_int(std::move(base_value));
  if (!exact_base) {
    return Result<LexWeights>::failure(lex_error(
        "lexicographic_scale_invariant_broken",
        "the exact lexicographic primary scale is unexpectedly negative"));
  }

  // For every binary schedule, the sum of secondary bits lies in [0,B-1].
  // Hence losing one unit of primary objective loses B and cannot be offset by
  // all secondary bits. At equal primary objective, the distinct powers of two
  // encode the priority-ordered schedule bits injectively, and maximization
  // selects the lexicographically largest bit vector. The composite optimum is
  // therefore the unique configured-priority member of the primary face.
  return Result<LexWeights>::success(LexWeights(
      primary, std::move(composite), std::move(exact_base).value(),
      std::move(secondary), eligibility));
}

Result<LexWeights> compose_lexicographic_weights(
    const NonnegativeIntegralWeights& primary,
    const PriorityOrder& priority, const EligibilityMask& eligibility) {
  return detail::LexWeightsAccess::compose(primary, priority, eligibility);
}

}  // namespace mwperf
