#include "mwperf/optimizer/crossbar.hpp"

#include <cstddef>
#include <cstdint>
#include <limits>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {
namespace {

[[nodiscard]] Diagnostic crossbar_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

template <typename Value>
[[nodiscard]] Result<Value> crossbar_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(crossbar_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes)));
}

[[nodiscard]] Result<void> validate_problem_and_query(
    const CrossbarProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition) {
  const std::size_t input_count = problem.input_count();
  const std::size_t output_count = problem.output_count();
  const std::size_t queue_count = problem.queue_count();

  if (input_count == 0U || output_count == 0U || queue_count == 0U) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::internal, "crossbar_problem_empty",
        "the immutable crossbar problem has an empty structural dimension"));
  }
  if (input_count >
          std::numeric_limits<std::size_t>::max() - output_count ||
      input_count + output_count ==
          std::numeric_limits<std::size_t>::max()) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::resource_limit,
        "crossbar_padded_dimension_overflow",
        "the exact padded crossbar dimension exceeds the host index range"));
  }
  if (eligibility.dimension() != weights.dimension()) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::internal,
        "crossbar_query_dimension_identity_mismatch",
        "crossbar eligibility and weights belong to different queue "
        "dimensions"));
  }
  if (weights.dimension().family() != ServiceFamily::crossbar_matching) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::internal, "crossbar_query_family_mismatch",
        "the exact crossbar query dimension belongs to another service "
        "family"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::internal,
        "crossbar_query_eligibility_mismatch",
        "the crossbar eligibility mask disagrees with the mask carried by "
        "the exact weights"));
  }
  if (eligibility.size() != queue_count || weights.size() != queue_count) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::internal, "crossbar_query_dimension_mismatch",
        "the crossbar query does not match the compiled queue dimension",
        {"compiled queues: " + std::to_string(queue_count),
         "eligibility entries: " + std::to_string(eligibility.size()),
         "weight entries: " + std::to_string(weights.size())}));
  }
  if (problem.row_edge_queues().size() != input_count) {
    return Result<void>::failure(crossbar_diagnostic(
        DiagnosticCategory::internal,
        "crossbar_problem_adjacency_dimension_mismatch",
        "the sparse crossbar row adjacency has the wrong input dimension"));
  }

  std::vector<std::uint8_t> adjacency_seen(queue_count, 0U);
  std::set<std::pair<std::size_t, std::size_t>> endpoint_pairs;
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    const CrossbarQueueEdge& edge = problem.queue_edges()[queue];
    if (edge.queue.ordinal() != queue) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_problem_queue_reconstruction_invalid",
          "the compiled queue-edge reconstruction is not in dense queue "
          "order",
          {"dense queue index: " + std::to_string(queue),
           "stored queue index: " +
               std::to_string(edge.queue.ordinal())}));
    }
    if (edge.input >= input_count || edge.output >= output_count) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_problem_endpoint_out_of_range",
          "a compiled crossbar queue edge has an out-of-range endpoint",
          {"dense queue index: " + std::to_string(queue)}));
    }
    if (!endpoint_pairs.emplace(edge.input, edge.output).second) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_problem_endpoint_duplicate",
          "the compiled crossbar geometry contains a duplicate real port "
          "pair"));
    }
  }

  for (std::size_t input = 0U; input < input_count; ++input) {
    std::optional<std::pair<std::size_t, std::size_t>> previous;
    for (const std::size_t queue : problem.row_edge_queues()[input]) {
      if (queue >= queue_count) {
        return Result<void>::failure(crossbar_diagnostic(
            DiagnosticCategory::internal,
            "crossbar_problem_adjacency_queue_out_of_range",
            "the sparse crossbar adjacency contains an out-of-range queue "
            "index"));
      }
      if (adjacency_seen[queue] != 0U) {
        return Result<void>::failure(crossbar_diagnostic(
            DiagnosticCategory::internal,
            "crossbar_problem_adjacency_queue_duplicate",
            "a dense queue occurs more than once in the sparse crossbar "
            "adjacency",
            {"dense queue index: " + std::to_string(queue)}));
      }
      adjacency_seen[queue] = 1U;
      const CrossbarQueueEdge& edge = problem.queue_edges()[queue];
      if (edge.input != input) {
        return Result<void>::failure(crossbar_diagnostic(
            DiagnosticCategory::internal,
            "crossbar_problem_adjacency_endpoint_mismatch",
            "a sparse crossbar row contains an edge belonging to another "
            "input"));
      }
      const std::pair<std::size_t, std::size_t> key{edge.output, queue};
      if (previous.has_value() && !(previous.value() < key)) {
        return Result<void>::failure(crossbar_diagnostic(
            DiagnosticCategory::internal,
            "crossbar_problem_adjacency_order_invalid",
            "a sparse crossbar row is not in strict structural order"));
      }
      previous = key;
    }
  }
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    if (adjacency_seen[queue] == 0U) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_problem_adjacency_queue_missing",
          "the sparse crossbar adjacency omits a dense queue",
          {"dense queue index: " + std::to_string(queue)}));
    }
  }

  if (condition != nullptr) {
    switch (condition->bit) {
      case ForcedTargetBit::zero:
      case ForcedTargetBit::one:
        break;
      default:
        return Result<void>::failure(crossbar_diagnostic(
            DiagnosticCategory::internal, "crossbar_forced_bit_invalid",
            "the crossbar forced-target bit is outside the closed binary "
            "domain"));
    }
    const std::size_t target = condition->target.ordinal();
    if (target >= queue_count) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_forced_target_out_of_range",
          "the crossbar forced target lies outside the compiled queue "
          "dimension"));
    }
    if (!condition->target.matches(weights.dimension())) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_forced_target_identity_mismatch",
          "the crossbar forced target belongs to another queue dimension"));
    }
    const bool target_eligible = eligibility.bytes()[target] != 0U;
    const bool target_required = condition->bit == ForcedTargetBit::one;
    if (target_eligible != target_required) {
      return Result<void>::failure(crossbar_diagnostic(
          DiagnosticCategory::internal,
          "crossbar_forced_target_eligibility_mismatch",
          "the conditioned target eligibility disagrees with its forced "
          "side"));
    }
  }

  return Result<void>::success();
}

struct AllowedArc final {
  bool allowed;
  std::optional<std::size_t> real_queue;
};

template <typename Visitor>
void for_each_allowed_arc(const CrossbarProblem& problem,
                          const std::vector<std::uint8_t>& active,
                          const std::size_t row, Visitor&& visitor) {
  const std::size_t input_count = problem.input_count();
  const std::size_t output_count = problem.output_count();
  if (row < input_count) {
    for (const std::size_t queue : problem.row_edge_queues()[row]) {
      if (active[queue] != 0U) {
        visitor(problem.queue_edges()[queue].output,
                std::optional<std::size_t>{queue});
      }
    }
    visitor(problem.own_dummy_column(row), std::optional<std::size_t>{});
    return;
  }

  const std::size_t output = row - input_count;
  visitor(output, std::optional<std::size_t>{});
  for (std::size_t input = 0U; input < input_count; ++input) {
    visitor(output_count + input, std::optional<std::size_t>{});
  }
}

[[nodiscard]] AllowedArc find_allowed_arc(
    const CrossbarProblem& problem,
    const std::vector<std::uint8_t>& active, const std::size_t row,
    const std::size_t column) {
  const std::size_t input_count = problem.input_count();
  const std::size_t output_count = problem.output_count();
  const std::size_t padded_dimension = input_count + output_count;
  if (row >= padded_dimension || column >= padded_dimension) {
    return {false, std::nullopt};
  }

  if (row < input_count) {
    if (column < output_count) {
      for (const std::size_t queue : problem.row_edge_queues()[row]) {
        const CrossbarQueueEdge& edge = problem.queue_edges()[queue];
        if (edge.output == column && active[queue] != 0U) {
          return {true, queue};
        }
      }
      return {false, std::nullopt};
    }
    return {column == problem.own_dummy_column(row), std::nullopt};
  }

  const std::size_t private_output = row - input_count;
  if (column < output_count) {
    return {column == private_output, std::nullopt};
  }
  return {true, std::nullopt};
}

[[nodiscard]] BigInt exact_arc_cost(
    const std::optional<std::size_t>& real_queue,
    const LexWeights& weights) {
  if (!real_queue.has_value()) {
    return BigInt{0};
  }
  BigInt cost = weights.values()[*real_queue].value();
  cost = -cost;
  return cost;
}

struct HungarianState final {
  std::vector<std::size_t> row_to_column;
  std::vector<BigInt> row_potential;
  std::vector<BigInt> column_potential;
};

[[nodiscard]] Result<HungarianState> run_sparse_hungarian(
    const CrossbarProblem& problem,
    const std::vector<std::uint8_t>& active,
    const LexWeights& weights) {
  const std::size_t dimension =
      problem.input_count() + problem.output_count();

  // One-based arrays retain column zero as the usual augmenting-tree root.
  // Every row has at least its structural private/real dummy arc, so every
  // row minimum exists without a numeric infinity sentinel.
  std::vector<BigInt> row_potential(dimension + 1U, BigInt{0});
  std::vector<BigInt> column_potential(dimension + 1U, BigInt{0});
  std::vector<std::size_t> column_to_row(dimension + 1U, 0U);

  for (std::size_t row = 0U; row < dimension; ++row) {
    std::optional<BigInt> minimum_cost;
    for_each_allowed_arc(
        problem, active, row,
        [&](const std::size_t,
            const std::optional<std::size_t>& real_queue) {
          BigInt cost = exact_arc_cost(real_queue, weights);
          if (!minimum_cost.has_value() || cost < *minimum_cost) {
            minimum_cost = std::move(cost);
          }
        });
    if (!minimum_cost.has_value()) {
      return crossbar_failure<HungarianState>(
          "crossbar_hungarian_row_without_arc",
          "a padded crossbar row has no allowed assignment arc");
    }
    row_potential[row + 1U] = std::move(*minimum_cost);
  }

  for (std::size_t inserted_row = 1U; inserted_row <= dimension;
       ++inserted_row) {
    column_to_row[0U] = inserted_row;
    std::size_t current_column = 0U;
    std::vector<std::optional<BigInt>> minimum_slack(dimension + 1U);
    std::vector<std::size_t> predecessor_column(dimension + 1U, 0U);
    std::vector<std::uint8_t> predecessor_defined(dimension + 1U, 0U);
    std::vector<std::uint8_t> used_column(dimension + 1U, 0U);

    do {
      if (current_column > dimension ||
          used_column[current_column] != 0U) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_tree_invariant_broken",
            "the exact Hungarian augmenting tree revisited an invalid "
            "column");
      }
      used_column[current_column] = 1U;
      const std::size_t current_row = column_to_row[current_column];
      if (current_row == 0U || current_row > dimension) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_matching_index_invalid",
            "the exact Hungarian matching contains an invalid row index");
      }

      bool negative_reduced_cost = false;
      std::size_t bad_column = 0U;
      for_each_allowed_arc(
          problem, active, current_row - 1U,
          [&](const std::size_t column,
              const std::optional<std::size_t>& real_queue) {
            const std::size_t one_based_column = column + 1U;
            if (used_column[one_based_column] != 0U) {
              return;
            }
            BigInt reduced_cost = exact_arc_cost(real_queue, weights);
            reduced_cost -= row_potential[current_row];
            reduced_cost -= column_potential[one_based_column];
            if (reduced_cost < 0) {
              negative_reduced_cost = true;
              bad_column = column;
              return;
            }

            const bool improves =
                !minimum_slack[one_based_column].has_value() ||
                reduced_cost < *minimum_slack[one_based_column];
            const bool stable_equal_predecessor =
                minimum_slack[one_based_column].has_value() &&
                reduced_cost == *minimum_slack[one_based_column] &&
                (predecessor_defined[one_based_column] == 0U ||
                 current_column <
                     predecessor_column[one_based_column]);
            if (improves || stable_equal_predecessor) {
              minimum_slack[one_based_column] = std::move(reduced_cost);
              predecessor_column[one_based_column] = current_column;
              predecessor_defined[one_based_column] = 1U;
            }
          });
      if (negative_reduced_cost) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_dual_infeasible",
            "an allowed crossbar arc has negative exact reduced cost during "
            "augmentation",
            {"row: " + std::to_string(current_row - 1U),
             "column: " + std::to_string(bad_column)});
      }

      std::optional<BigInt> delta;
      std::size_t next_column = 0U;
      for (std::size_t column = 1U; column <= dimension; ++column) {
        if (used_column[column] != 0U ||
            !minimum_slack[column].has_value()) {
          continue;
        }
        if (!delta.has_value() || *minimum_slack[column] < *delta ||
            (*minimum_slack[column] == *delta && column < next_column)) {
          delta = *minimum_slack[column];
          next_column = column;
        }
      }
      if (!delta.has_value()) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_no_augmenting_path",
            "the structurally padded crossbar assignment has no augmenting "
            "path",
            {"the all-unmatched dummy assignment proves this is an internal "
             "invariant failure"});
      }
      if (*delta < 0) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_negative_label_update",
            "the exact Hungarian label update is unexpectedly negative");
      }

      for (std::size_t column = 0U; column <= dimension; ++column) {
        if (used_column[column] != 0U) {
          const std::size_t row = column_to_row[column];
          if (row == 0U || row > dimension) {
            return crossbar_failure<HungarianState>(
                "crossbar_hungarian_matching_index_invalid",
                "a used Hungarian column has no valid matched row");
          }
          row_potential[row] += *delta;
          column_potential[column] -= *delta;
        } else if (minimum_slack[column].has_value()) {
          *minimum_slack[column] -= *delta;
        }
      }
      current_column = next_column;
    } while (column_to_row[current_column] != 0U);

    std::size_t augmentation_steps = 0U;
    do {
      if (current_column > dimension ||
          predecessor_defined[current_column] == 0U) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_predecessor_missing",
            "the exact Hungarian augmenting path has no predecessor");
      }
      const std::size_t previous_column =
          predecessor_column[current_column];
      if (previous_column > dimension) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_predecessor_invalid",
            "the exact Hungarian augmenting path has an invalid predecessor "
            "column");
      }
      column_to_row[current_column] = column_to_row[previous_column];
      current_column = previous_column;
      ++augmentation_steps;
      if (augmentation_steps > dimension) {
        return crossbar_failure<HungarianState>(
            "crossbar_hungarian_predecessor_cycle",
            "the exact Hungarian predecessor chain contains a cycle");
      }
    } while (current_column != 0U);
  }

  std::vector<std::size_t> row_to_column(dimension, dimension);
  std::vector<std::uint8_t> seen_rows(dimension, 0U);
  for (std::size_t column = 1U; column <= dimension; ++column) {
    const std::size_t row = column_to_row[column];
    if (row == 0U || row > dimension || seen_rows[row - 1U] != 0U) {
      return crossbar_failure<HungarianState>(
          "crossbar_hungarian_not_a_permutation",
          "the exact Hungarian result is not a row/column permutation");
    }
    seen_rows[row - 1U] = 1U;
    row_to_column[row - 1U] = column - 1U;
  }

  return Result<HungarianState>::success(HungarianState{
      .row_to_column = std::move(row_to_column),
      .row_potential = std::move(row_potential),
      .column_potential = std::move(column_potential),
  });
}

[[nodiscard]] bool inject_forbidden_assignment(
    const CrossbarProblem& problem,
    const std::vector<std::uint8_t>& active,
    std::vector<std::size_t>& row_to_column) {
  const std::size_t dimension =
      problem.input_count() + problem.output_count();
  for (std::size_t row = 0U; row < dimension; ++row) {
    for (std::size_t column = 0U; column < dimension; ++column) {
      if (!find_allowed_arc(problem, active, row, column).allowed) {
        row_to_column[row] = column;
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] Result<BigInt> verify_exact_assignment(
    const CrossbarProblem& problem,
    const std::vector<std::uint8_t>& active, const LexWeights& weights,
    const HungarianState& state) {
  const std::size_t dimension =
      problem.input_count() + problem.output_count();
  if (state.row_to_column.size() != dimension ||
      state.row_potential.size() != dimension + 1U ||
      state.column_potential.size() != dimension + 1U) {
    return crossbar_failure<BigInt>(
        "crossbar_hungarian_workspace_dimension_mismatch",
        "the exact Hungarian result has inconsistent workspace dimensions");
  }

  std::vector<std::uint8_t> seen_columns(dimension, 0U);
  BigInt assignment_cost = 0;
  for (std::size_t row = 0U; row < dimension; ++row) {
    const std::size_t column = state.row_to_column[row];
    if (column >= dimension) {
      return crossbar_failure<BigInt>(
          "crossbar_hungarian_assignment_index_invalid",
          "the exact Hungarian result contains an out-of-range column",
          {"row: " + std::to_string(row)});
    }
    const AllowedArc arc = find_allowed_arc(problem, active, row, column);
    if (!arc.allowed) {
      return crossbar_failure<BigInt>(
          "crossbar_hungarian_forbidden_arc",
          "the exact Hungarian result traversed a structurally forbidden or "
          "ineligible crossbar arc",
          {"row: " + std::to_string(row),
           "column: " + std::to_string(column)});
    }
    if (seen_columns[column] != 0U) {
      return crossbar_failure<BigInt>(
          "crossbar_hungarian_not_a_permutation",
          "the exact Hungarian result assigns one column more than once",
          {"column: " + std::to_string(column)});
    }
    seen_columns[column] = 1U;

    BigInt cost = exact_arc_cost(arc.real_queue, weights);
    BigInt reduced_cost = cost;
    reduced_cost -= state.row_potential[row + 1U];
    reduced_cost -= state.column_potential[column + 1U];
    if (reduced_cost != 0) {
      return crossbar_failure<BigInt>(
          "crossbar_hungarian_matched_arc_not_tight",
          "a matched crossbar assignment arc is not exactly dual-tight",
          {"row: " + std::to_string(row),
           "column: " + std::to_string(column)});
    }
    assignment_cost += cost;
  }

  for (std::size_t row = 0U; row < dimension; ++row) {
    bool dual_violation = false;
    std::size_t bad_column = 0U;
    for_each_allowed_arc(
        problem, active, row,
        [&](const std::size_t column,
            const std::optional<std::size_t>& real_queue) {
          BigInt reduced_cost = exact_arc_cost(real_queue, weights);
          reduced_cost -= state.row_potential[row + 1U];
          reduced_cost -= state.column_potential[column + 1U];
          if (reduced_cost < 0) {
            dual_violation = true;
            bad_column = column;
          }
        });
    if (dual_violation) {
      return crossbar_failure<BigInt>(
          "crossbar_hungarian_dual_infeasible",
          "an allowed crossbar arc violates exact dual feasibility after "
          "augmentation",
          {"row: " + std::to_string(row),
           "column: " + std::to_string(bad_column)});
    }
  }

  BigInt dual_objective = 0;
  for (std::size_t index = 1U; index <= dimension; ++index) {
    dual_objective += state.row_potential[index];
    dual_objective += state.column_potential[index];
  }
  if (dual_objective != assignment_cost) {
    return crossbar_failure<BigInt>(
        "crossbar_hungarian_primal_dual_mismatch",
        "the exact padded assignment cost does not equal its exact dual "
        "certificate");
  }

  return Result<BigInt>::success(std::move(assignment_cost));
}

[[nodiscard]] Result<CrossbarExactWitness> solve_crossbar_exact_core(
    const CrossbarProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition,
    const CrossbarTestFault fault) {
  try {
    auto valid =
        validate_problem_and_query(problem, eligibility, weights, condition);
    if (!valid) {
      return Result<CrossbarExactWitness>::failure(std::move(valid.error()));
    }
    if (fault != CrossbarTestFault::none &&
        fault != CrossbarTestFault::force_forbidden_assignment) {
      return crossbar_failure<CrossbarExactWitness>(
          "crossbar_test_fault_invalid",
          "the crossbar test fault is outside its closed domain");
    }

    std::vector<std::uint8_t> active(eligibility.bytes().begin(),
                                     eligibility.bytes().end());
    std::optional<std::size_t> committed_target;
    if (condition != nullptr && condition->bit == ForcedTargetBit::one) {
      const std::size_t target = condition->target.ordinal();
      const CrossbarQueueEdge& target_edge = problem.queue_edges()[target];
      for (std::size_t queue = 0U; queue < problem.queue_count(); ++queue) {
        const CrossbarQueueEdge& edge = problem.queue_edges()[queue];
        if (edge.input == target_edge.input ||
            edge.output == target_edge.output) {
          active[queue] = 0U;
        }
      }
      committed_target = target;
    }

    auto hungarian_result = run_sparse_hungarian(problem, active, weights);
    if (!hungarian_result) {
      return Result<CrossbarExactWitness>::failure(
          std::move(hungarian_result.error()));
    }
    HungarianState state = std::move(hungarian_result).value();

    if (fault == CrossbarTestFault::force_forbidden_assignment &&
        !inject_forbidden_assignment(problem, active,
                                     state.row_to_column)) {
      return crossbar_failure<CrossbarExactWitness>(
          "crossbar_test_fault_unavailable",
          "the requested test-only forbidden-arc fault has no forbidden arc "
          "in this padded instance");
    }

    auto verified = verify_exact_assignment(problem, active, weights, state);
    if (!verified) {
      return Result<CrossbarExactWitness>::failure(
          std::move(verified.error()));
    }
    BigInt assignment_cost = std::move(verified).value();

    std::vector<std::uint8_t> selected(problem.queue_count(), 0U);
    BigNat objective(std::uint64_t{0U});
    for (std::size_t input = 0U; input < problem.input_count(); ++input) {
      const std::size_t column = state.row_to_column[input];
      if (column >= problem.output_count()) {
        continue;
      }
      const AllowedArc arc = find_allowed_arc(problem, active, input, column);
      if (!arc.allowed || !arc.real_queue.has_value()) {
        return crossbar_failure<CrossbarExactWitness>(
            "crossbar_projection_real_arc_invalid",
            "a real-real padded assignment arc has no queue reconstruction "
            "record");
      }
      const std::size_t queue = *arc.real_queue;
      if (selected[queue] != 0U) {
        return crossbar_failure<CrossbarExactWitness>(
            "crossbar_projection_queue_duplicate",
            "the padded crossbar assignment projects one queue more than "
            "once");
      }
      selected[queue] = 1U;
      objective += weights.values()[queue];
    }

    BigInt expected_assignment_cost = objective.value();
    expected_assignment_cost = -expected_assignment_cost;
    if (assignment_cost != expected_assignment_cost) {
      return crossbar_failure<CrossbarExactWitness>(
          "crossbar_projection_objective_mismatch",
          "the projected real-edge objective does not reproduce the exact "
          "padded assignment cost");
    }

    if (committed_target.has_value()) {
      if (selected[*committed_target] != 0U) {
        return crossbar_failure<CrossbarExactWitness>(
            "crossbar_forced_target_residual_selected",
            "the forced-one target unexpectedly entered its residual "
            "matching");
      }
      selected[*committed_target] = 1U;
      objective += weights.values()[*committed_target];
    }

    auto schedule =
        Schedule::from_bytes(weights.dimension(), std::move(selected));
    if (!schedule) {
      return Result<CrossbarExactWitness>::failure(
          std::move(schedule.error()));
    }

    std::vector<std::string> proof_notes{
        "exact sparse structurally filtered padded Hungarian assignment",
        "signed arbitrary-precision primal-dual workspace is cold per solve",
        "recursive search budget expansions are not consumed"};
    if (committed_target.has_value()) {
      proof_notes.push_back(
          "forced-one target committed after exact conflicting-edge "
          "residual solve");
    } else if (condition != nullptr) {
      proof_notes.push_back(
          "forced-zero target excluded by the conditioned eligibility mask");
    }

    return Result<CrossbarExactWitness>::success(CrossbarExactWitness{
        .schedule = std::move(schedule).value(),
        .composite_objective = std::move(objective),
        .proof_notes = std::move(proof_notes),
    });
  } catch (const std::bad_alloc&) {
    return Result<CrossbarExactWitness>::failure(crossbar_diagnostic(
        DiagnosticCategory::resource_limit,
        "crossbar_solve_allocation_failure",
        "allocation failed during the cold exact crossbar solve"));
  } catch (const std::length_error&) {
    return Result<CrossbarExactWitness>::failure(crossbar_diagnostic(
        DiagnosticCategory::resource_limit,
        "crossbar_solve_representation_failure",
        "the cold exact crossbar workspace exceeds a host container limit"));
  }
}

}  // namespace

Result<CrossbarExactWitness> solve_crossbar_exact(
    const CrossbarProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition) {
  return solve_crossbar_exact_core(problem, eligibility, weights, condition,
                                   CrossbarTestFault::none);
}

#if defined(MWPERF_C06_TEST_SEAMS)
Result<CrossbarExactWitness> solve_crossbar_exact_with_fault(
    const CrossbarProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition,
    const CrossbarTestFault fault) {
  return solve_crossbar_exact_core(problem, eligibility, weights, condition,
                                   fault);
}
#endif

}  // namespace mwperf::detail
