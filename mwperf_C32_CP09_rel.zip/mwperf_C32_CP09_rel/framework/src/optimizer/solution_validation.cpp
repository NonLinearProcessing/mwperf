#include "mwperf/optimizer/solution_validation.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic validation_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Result<void> invalid_descriptor(
    const ServiceFamily family, std::string reason) {
  return Result<void>::failure(validation_error(
      "optimizer_constraint_descriptor_invalid",
      "the immutable constraint descriptor is inconsistent at the optimizer "
      "validation boundary",
      {"service family: " + std::string(to_string(family)),
       std::move(reason)}));
}

[[nodiscard]] Result<void> infeasible_schedule(
    const ServiceFamily family, std::string reason) {
  return Result<void>::failure(validation_error(
      "optimizer_schedule_infeasible",
      "the exact optimizer returned a schedule outside the configured "
      "feasible family",
      {"service family: " + std::string(to_string(family)),
       std::move(reason)}));
}

[[nodiscard]] std::size_t descriptor_queue_count(
    const ConstraintDescriptor& descriptor) {
  return std::visit(
      []<typename Constraint>(const Constraint& constraint) {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          return constraint.edges.size();
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          return constraint.intervals.size();
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          return constraint.links.size();
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          return constraint.adjacency.size();
        } else {
          return constraint.demands.size();
        }
      },
      descriptor.value());
}

[[nodiscard]] Result<void> mark_queue_once(
    std::vector<std::uint8_t>& seen, const DenseQueueIndex queue,
    const ServiceFamily family) {
  const std::size_t ordinal = queue.ordinal();
  if (ordinal >= seen.size()) {
    return invalid_descriptor(
        family, "a constraint queue index lies outside the dense dimension");
  }
  if (seen[ordinal] != 0U) {
    return invalid_descriptor(
        family, "a dense queue occurs more than once in the constraint "
                "geometry");
  }
  seen[ordinal] = 1U;
  return Result<void>::success();
}

[[nodiscard]] Result<void> require_complete_geometry(
    const std::vector<std::uint8_t>& seen, const ServiceFamily family) {
  if (std::ranges::find(seen, std::uint8_t{0U}) != seen.end()) {
    return invalid_descriptor(
        family, "the constraint geometry does not contain every dense queue");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_crossbar_feasibility(
    const ResolvedCrossbarConstraint& constraint,
    const Schedule& schedule) {
  constexpr ServiceFamily family = ServiceFamily::crossbar_matching;
  std::vector<std::uint8_t> seen(schedule.size(), 0U);
  std::vector<std::uint8_t> used_inputs(constraint.inputs.size(), 0U);
  std::vector<std::uint8_t> used_outputs(constraint.outputs.size(), 0U);

  for (const ResolvedCrossbarEdge& edge : constraint.edges) {
    auto marked = mark_queue_once(seen, edge.queue, family);
    if (!marked) {
      return marked;
    }
    const std::size_t input = edge.input.ordinal();
    const std::size_t output = edge.output.ordinal();
    if (input >= used_inputs.size() || output >= used_outputs.size()) {
      return invalid_descriptor(
          family, "a crossbar edge has an out-of-range port index");
    }
    if (!schedule.at(edge.queue)) {
      continue;
    }
    if (used_inputs[input] != 0U || used_outputs[output] != 0U) {
      return infeasible_schedule(
          family,
          "two selected edges share a crossbar input or output port");
    }
    used_inputs[input] = 1U;
    used_outputs[output] = 1U;
  }
  return require_complete_geometry(seen, family);
}

[[nodiscard]] Result<void> validate_interval_feasibility(
    const ResolvedIntervalConstraint& constraint,
    const Schedule& schedule) {
  constexpr ServiceFamily family =
      ServiceFamily::nonoverlapping_intervals;
  std::vector<std::uint8_t> seen(schedule.size(), 0U);
  std::vector<const ResolvedInterval*> selected;
  selected.reserve(constraint.intervals.size());

  for (const ResolvedInterval& interval : constraint.intervals) {
    auto marked = mark_queue_once(seen, interval.queue, family);
    if (!marked) {
      return marked;
    }
    if (!(interval.left < interval.right)) {
      return invalid_descriptor(
          family, "a bound interval does not satisfy exact left < right");
    }
    if (schedule.at(interval.queue)) {
      selected.push_back(&interval);
    }
  }
  auto complete = require_complete_geometry(seen, family);
  if (!complete) {
    return complete;
  }

  std::ranges::sort(selected, [](const ResolvedInterval* lhs,
                                 const ResolvedInterval* rhs) {
    if (lhs->left != rhs->left) {
      return lhs->left < rhs->left;
    }
    if (lhs->right != rhs->right) {
      return lhs->right < rhs->right;
    }
    return lhs->queue < rhs->queue;
  });
  for (std::size_t index = 1U; index < selected.size(); ++index) {
    // Intervals are half-open, so exact endpoint contact is feasible.
    if (!(selected[index - 1U]->right <= selected[index]->left)) {
      return infeasible_schedule(
          family, "two selected half-open intervals overlap exactly");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_node_exclusive_feasibility(
    const ResolvedNodeExclusiveConstraint& constraint,
    const Schedule& schedule) {
  constexpr ServiceFamily family =
      ServiceFamily::node_exclusive_matching;
  std::vector<std::uint8_t> seen(schedule.size(), 0U);
  std::vector<std::uint8_t> used_vertices(constraint.vertices.size(), 0U);

  for (const ResolvedNodeExclusiveLink& link : constraint.links) {
    auto marked = mark_queue_once(seen, link.queue, family);
    if (!marked) {
      return marked;
    }
    const std::size_t u = link.u.ordinal();
    const std::size_t v = link.v.ordinal();
    if (u >= used_vertices.size() || v >= used_vertices.size() || u == v) {
      return invalid_descriptor(
          family,
          "a node-exclusive link has invalid bound endpoint indices");
    }
    if (!schedule.at(link.queue)) {
      continue;
    }
    if (used_vertices[u] != 0U || used_vertices[v] != 0U) {
      return infeasible_schedule(
          family, "two selected links share a node-exclusive endpoint");
    }
    used_vertices[u] = 1U;
    used_vertices[v] = 1U;
  }
  return require_complete_geometry(seen, family);
}

[[nodiscard]] Result<void> validate_conflict_feasibility(
    const ResolvedConflictConstraint& constraint,
    const Schedule& schedule) {
  constexpr ServiceFamily family = ServiceFamily::pairwise_conflicts;
  if (constraint.adjacency.size() != schedule.size()) {
    return invalid_descriptor(
        family, "the conflict adjacency dimension is inconsistent");
  }
  for (const ResolvedConflictPair& conflict : constraint.conflicts) {
    const std::size_t first = conflict.first.ordinal();
    const std::size_t second = conflict.second.ordinal();
    if (first >= schedule.size() || second >= schedule.size() ||
        first == second) {
      return invalid_descriptor(
          family, "a conflict pair has invalid dense queue indices");
    }
    if (schedule.at(conflict.first) && schedule.at(conflict.second)) {
      return infeasible_schedule(
          family, "both endpoints of an undirected conflict are selected");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_packing_feasibility(
    const ResolvedPackingConstraint& constraint,
    const Schedule& schedule) {
  constexpr ServiceFamily family = ServiceFamily::resource_packing;
  const std::size_t resource_count = constraint.resources.size();
  if (constraint.capacity.size() != resource_count) {
    return invalid_descriptor(
        family, "packing resource and capacity dimensions disagree");
  }

  std::vector<std::uint8_t> seen(schedule.size(), 0U);
  std::vector<BigInt> used(resource_count, BigInt{0});
  for (const ResolvedPackingDemand& demand : constraint.demands) {
    auto marked = mark_queue_once(seen, demand.queue, family);
    if (!marked) {
      return marked;
    }
    if (demand.demand.size() != resource_count) {
      return invalid_descriptor(
          family, "a packing demand vector has the wrong resource dimension");
    }
    if (!schedule.at(demand.queue)) {
      continue;
    }
    for (std::size_t resource = 0U; resource < resource_count; ++resource) {
      used[resource] += demand.demand[resource].value();
      if (used[resource] > constraint.capacity[resource].value()) {
        return infeasible_schedule(
            family, "selected demands exceed a resource capacity");
      }
    }
  }
  return require_complete_geometry(seen, family);
}

[[nodiscard]] Result<void> validate_family_feasibility(
    const ConstraintDescriptor& descriptor, const Schedule& schedule) {
  return std::visit(
      [&schedule]<typename Constraint>(const Constraint& constraint) {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          return validate_crossbar_feasibility(constraint, schedule);
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          return validate_interval_feasibility(constraint, schedule);
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          return validate_node_exclusive_feasibility(constraint, schedule);
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          return validate_conflict_feasibility(constraint, schedule);
        } else {
          return validate_packing_feasibility(constraint, schedule);
        }
      },
      descriptor.value());
}

[[nodiscard]] bool known_query_kind(const OptimizerQueryKind kind) noexcept {
  switch (kind) {
    case OptimizerQueryKind::ordinary:
    case OptimizerQueryKind::forced_zero:
    case OptimizerQueryKind::forced_one:
    case OptimizerQueryKind::integral_support:
    case OptimizerQueryKind::rational_support:
    case OptimizerQueryKind::generic_exact:
      return true;
  }
  return false;
}

[[nodiscard]] bool polynomial_family(const ServiceFamily family) noexcept {
  switch (family) {
    case ServiceFamily::crossbar_matching:
    case ServiceFamily::nonoverlapping_intervals:
    case ServiceFamily::node_exclusive_matching:
      return true;
    case ServiceFamily::pairwise_conflicts:
    case ServiceFamily::resource_packing:
      return false;
  }
  return false;
}

[[nodiscard]] Result<void> validate_accounting(
    const SearchAccounting& accounting, const ServiceFamily family,
    const QueueDimensionToken& dimension) {
  if (accounting.call_ordinal().is_zero()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_zero_call_ordinal",
        "a successful optimizer solution must identify a reserved call"));
  }
  if (!known_query_kind(accounting.query_kind())) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_query_kind_invalid",
        "the optimizer solution reports an unknown query kind"));
  }
  const bool forced =
      accounting.query_kind() == OptimizerQueryKind::forced_zero ||
      accounting.query_kind() == OptimizerQueryKind::forced_one;
  if (forced && !accounting.target().has_value()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_target_missing",
        "forced-query accounting must retain the conditioned target"));
  }
  if (!forced && accounting.target().has_value()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_target_forbidden",
        "non-forced optimizer accounting cannot carry a target"));
  }
  if (accounting.target().has_value() &&
      accounting.target()->ordinal() >= dimension.cardinality()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_target_out_of_range",
        "the optimizer accounting target lies outside the queue dimension"));
  }
  if (accounting.target().has_value() &&
      !accounting.target()->matches(dimension)) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_target_identity_mismatch",
        "the optimizer accounting target belongs to another queue "
        "dimension"));
  }
  if (accounting.effective_per_call_limit() !=
      dimension.base_optimizer_policy().effective_per_call) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_effective_limit_mismatch",
        "the optimizer accounting limit differs from the immutable "
        "queue-dimension policy"));
  }
  if (!accounting.family().has_value()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_family_missing",
        "the optimizer solution accounting has no claimed service family"));
  }
  if (*accounting.family() != family) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_family_mismatch",
        "the optimizer solution accounting names a different service family",
        {"expected: " + std::string(to_string(family)),
         "reported: " + std::string(to_string(*accounting.family()))}));
  }
  if (accounting.exhausted()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_exhausted_success",
        "an exhausted exact search cannot return a successful optimizer "
        "solution"));
  }
  if (accounting.effective_per_call_limit().has_value() &&
      accounting.completed_expansions() >
          *accounting.effective_per_call_limit()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_expansion_limit_exceeded",
        "the successful optimizer solution reports more recursive expansions "
        "than its per-call limit",
        {"effective limit: " +
             accounting.effective_per_call_limit()->to_decimal_string(),
         "reported expansions: " +
             accounting.completed_expansions().to_decimal_string()}));
  }
  if (polynomial_family(family) &&
      !accounting.completed_expansions().is_zero()) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_polynomial_expansions",
        "a polynomial exact backend must not charge recursive search states",
        {"service family: " + std::string(to_string(family)),
         "reported expansions: " +
             accounting.completed_expansions().to_decimal_string()}));
  }
  return Result<void>::success();
}

}  // namespace

Result<void> detail::validate_optimizer_solution_core(
    const OptimizerSolution& solution,
    const ConstraintDescriptor& constraint,
    const EligibilityMask& eligibility, const LexWeights& weights) {
  const Schedule& schedule = solution.schedule();
  if (schedule.dimension() != eligibility.dimension() ||
      schedule.dimension() != weights.dimension()) {
    return Result<void>::failure(validation_error(
        "optimizer_solution_dimension_identity_mismatch",
        "the optimizer schedule, eligibility, and weights belong to different "
        "queue dimensions"));
  }
  if (schedule.size() != eligibility.size() ||
      schedule.size() != weights.size() ||
      schedule.size() != descriptor_queue_count(constraint)) {
    return Result<void>::failure(validation_error(
        "optimizer_solution_dimension_mismatch",
        "the optimizer query or solution does not match the constraint queue "
        "dimension",
        {"schedule entries: " + std::to_string(schedule.size()),
         "eligibility entries: " + std::to_string(eligibility.size()),
         "weight entries: " + std::to_string(weights.size()),
         "constraint queues: " +
             std::to_string(descriptor_queue_count(constraint))}));
  }
  if (!schedule.dimension().matches(constraint)) {
    return Result<void>::failure(validation_error(
        "optimizer_solution_constraint_identity_mismatch",
        "the optimizer query dimension is not bound to this immutable "
        "constraint descriptor"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(validation_error(
        "optimizer_weight_eligibility_mismatch",
        "the composite weights carry a different eligibility mask from the "
        "validated query"));
  }
  if (solution.accounting().target().has_value() &&
      (solution.accounting().target()->ordinal() >= schedule.size() ||
       !solution.accounting().target()->matches(schedule.dimension()))) {
    return Result<void>::failure(validation_error(
        "optimizer_accounting_target_identity_mismatch",
        "the optimizer accounting target is out of range or belongs to "
        "another queue dimension"));
  }
  for (std::size_t ordinal = 0U; ordinal < schedule.size(); ++ordinal) {
    if (schedule.bytes()[ordinal] > 1U) {
      return Result<void>::failure(validation_error(
          "optimizer_schedule_not_binary",
          "the optimizer returned a schedule value outside the binary domain",
          {"queue index: " + std::to_string(ordinal)}));
    }
    if (schedule.bytes()[ordinal] != 0U &&
        eligibility.bytes()[ordinal] == 0U) {
      return Result<void>::failure(validation_error(
          "optimizer_schedule_ineligible",
          "the optimizer selected a queue excluded by the eligibility mask",
          {"queue index: " + std::to_string(ordinal)}));
    }
  }

  if (solution.accounting().target().has_value()) {
    const std::size_t target = solution.accounting().target()->ordinal();
    const bool selected = schedule.bytes()[target] != 0U;
    const bool target_eligible = eligibility.bytes()[target] != 0U;
    if (solution.accounting().query_kind() ==
            OptimizerQueryKind::forced_zero &&
        (selected || target_eligible)) {
      return Result<void>::failure(validation_error(
          "optimizer_accounting_forced_zero_witness_mismatch",
          "forced-zero accounting requires the target to be removed from "
          "eligibility and absent from the witness"));
    }
    if (solution.accounting().query_kind() ==
            OptimizerQueryKind::forced_one &&
        (!selected || !target_eligible)) {
      return Result<void>::failure(validation_error(
          "optimizer_accounting_forced_one_witness_mismatch",
          "forced-one accounting requires the target to be structurally "
          "eligible and selected in the witness"));
    }
  }

  const ServiceFamily expected_family = constraint.family();
  if (!constraint.compiled_product().has_owner() ||
      constraint.compiled_product().family() != expected_family) {
    return Result<void>::failure(validation_error(
        "optimizer_constraint_product_mismatch",
        "the constraint's compiled product is null or names a different "
        "service family"));
  }
  if (solution.family() != expected_family) {
    return Result<void>::failure(validation_error(
        "optimizer_solution_family_mismatch",
        "the optimizer solution names a different service family",
        {"expected: " + std::string(to_string(expected_family)),
         "reported: " + std::string(to_string(solution.family()))}));
  }
  const OptimizerId expected_backend = constraint.identity().optimizer;
  if (solution.backend_id() != expected_backend) {
    return Result<void>::failure(validation_error(
        "optimizer_solution_backend_mismatch",
        "the optimizer solution names a backend inconsistent with dispatch",
        {"expected: " + std::string(to_string(expected_backend)),
         "reported: " + std::string(to_string(solution.backend_id()))}));
  }

  auto feasible = validate_family_feasibility(constraint, schedule);
  if (!feasible) {
    return feasible;
  }

  BigNat exact_objective(std::uint64_t{0U});
  for (std::size_t ordinal = 0U; ordinal < schedule.size(); ++ordinal) {
    if (schedule.bytes()[ordinal] != 0U) {
      exact_objective += weights.values()[ordinal];
    }
  }
  if (solution.composite_objective() != exact_objective) {
    return Result<void>::failure(validation_error(
        "optimizer_solution_objective_mismatch",
        "the optimizer solution's reported composite objective is not the "
        "exact selected-weight sum",
        {"expected: " + exact_objective.to_decimal_string(),
         "reported: " +
             solution.composite_objective().to_decimal_string()}));
  }

  return validate_accounting(solution.accounting(), expected_family,
                             schedule.dimension());
}

Result<void> validate_optimizer_solution(
    const OptimizerSolution& solution,
    const ConstraintDescriptor& constraint,
    const EligibilityMask& eligibility, const LexWeights& weights) {
  return detail::validate_optimizer_solution_core(solution, constraint,
                                                   eligibility, weights);
}

#if defined(MWPERF_C05_TEST_SEAMS)
SearchAccounting SearchAccounting::for_fixture(
    BigNat call_ordinal,
    std::optional<BigNat> effective_per_call_limit,
    BigNat completed_expansions, const OptimizerQueryKind query_kind,
    const std::optional<ServiceFamily> family, const bool exhausted,
    const std::optional<TargetIndex> target) {
  return SearchAccounting(
      std::move(call_ordinal), std::move(effective_per_call_limit),
      std::move(completed_expansions), query_kind, family, exhausted, target);
}

#endif

}  // namespace mwperf
