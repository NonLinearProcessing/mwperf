#include "mwperf/optimizer/packing.hpp"

#include <compare>
#include <cstddef>
#include <cstdint>
#include <map>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/optimizer/conflict.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic packing_diagnostic(
    const DiagnosticCategory category, std::string code,
    std::string message, std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic packing_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return packing_diagnostic(DiagnosticCategory::internal, std::move(code),
                            std::move(message), std::move(notes));
}

[[nodiscard]] Diagnostic packing_resource_error(
    std::string code, std::string message) {
  return packing_diagnostic(DiagnosticCategory::resource_limit,
                            std::move(code), std::move(message));
}

[[nodiscard]] bool known_forced_bit(const ForcedTargetBit bit) noexcept {
  switch (bit) {
    case ForcedTargetBit::zero:
    case ForcedTargetBit::one:
      return true;
  }
  return false;
}

[[nodiscard]] bool demand_fits(
    const std::span<const BigNat> demand,
    const CapacityVector& remaining_capacity) noexcept {
  if (demand.size() != remaining_capacity.size()) {
    return false;
  }
  for (std::size_t resource = 0U; resource < demand.size(); ++resource) {
    if (demand[resource] > remaining_capacity[resource]) {
      return false;
    }
  }
  return true;
}

// This full check is linear in the immutable input size. It protects every
// public primitive from malformed seam/future-owner data before an unchecked
// queue or resource coordinate can enter recursion.
[[nodiscard]] Result<void> validate_packing_problem(
    const PackingProblem& problem) {
  const std::size_t resource_count = problem.resource_count();
  const std::size_t queue_count = problem.queue_count();

  if (queue_count == 0U) {
    return Result<void>::failure(packing_error(
        "packing_problem_queue_dimension_empty",
        "an exact packing problem requires at least one queue"));
  }
  if (problem.capacity().size() != resource_count) {
    return Result<void>::failure(packing_error(
        "packing_problem_capacity_dimension_mismatch",
        "the immutable packing capacity dimension differs from its "
        "resource dimension"));
  }

  std::set<ResourceId> labels;
  for (std::size_t resource = 0U; resource < resource_count; ++resource) {
    const PackingResource& record = problem.resources()[resource];
    if (record.index.ordinal() != resource) {
      return Result<void>::failure(packing_error(
          "packing_problem_resource_order_invalid",
          "the immutable packing resources are not in dense declared order",
          {"position: " + std::to_string(resource),
           "stored resource index: " +
               std::to_string(record.index.ordinal())}));
    }
    if (!labels.insert(record.id).second) {
      return Result<void>::failure(packing_error(
          "packing_problem_resource_label_duplicate",
          "the immutable packing problem repeats a resource label"));
    }
  }

  if (problem.demands().size() != queue_count) {
    return Result<void>::failure(packing_error(
        "packing_problem_demand_dimension_mismatch",
        "the immutable packing queue and demand dimensions differ"));
  }
  for (std::size_t queue = 0U; queue < queue_count; ++queue) {
    const CompiledPackingDemand& record = problem.demands()[queue];
    if (record.queue.ordinal() != queue) {
      return Result<void>::failure(packing_error(
          "packing_problem_queue_order_invalid",
          "the immutable packing demands are not in dense queue order",
          {"position: " + std::to_string(queue),
           "stored dense queue index: " +
               std::to_string(record.queue.ordinal())}));
    }
    if (record.demand.size() != resource_count) {
      return Result<void>::failure(packing_error(
          "packing_problem_demand_vector_dimension_mismatch",
          "an immutable packing demand vector differs from the resource "
          "dimension",
          {"dense queue index: " + std::to_string(queue),
           "resources: " + std::to_string(resource_count),
           "demand coordinates: " +
               std::to_string(record.demand.size())}));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_packing_query(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const SearchBudget& budget,
    const detail::ForcedTargetCondition* condition) {
  if (eligibility.dimension() != weights.dimension()) {
    return Result<void>::failure(packing_error(
        "packing_query_dimension_identity_mismatch",
        "packing eligibility and weights belong to different queue "
        "dimensions"));
  }
  if (weights.dimension().family() != ServiceFamily::resource_packing) {
    return Result<void>::failure(packing_error(
        "packing_query_family_mismatch",
        "the packing primitive received a queue dimension for another "
        "service family"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(packing_error(
        "packing_query_eligibility_mismatch",
        "the packing eligibility mask disagrees with the mask embedded in "
        "the exact weights"));
  }
  if (eligibility.size() != problem.queue_count() ||
      weights.size() != problem.queue_count()) {
    return Result<void>::failure(packing_error(
        "packing_query_dimension_mismatch",
        "the packing query does not match its compiled queue dimension",
        {"compiled queues: " + std::to_string(problem.queue_count()),
         "eligibility entries: " + std::to_string(eligibility.size()),
         "weight entries: " + std::to_string(weights.size())}));
  }
  if (!budget.dispatch_claimed() || !budget.claimed_family().has_value() ||
      *budget.claimed_family() != ServiceFamily::resource_packing) {
    return Result<void>::failure(packing_error(
        "packing_search_budget_not_claimed",
        "the packing primitive requires a search budget claimed for the "
        "resource-packing family"));
  }
  if (!budget.matches_dimension(weights.dimension())) {
    return Result<void>::failure(packing_error(
        "packing_search_budget_dimension_mismatch",
        "the packing search budget is not bound to the exact query "
        "dimension"));
  }

  if (condition == nullptr) {
    return Result<void>::success();
  }
  if (!known_forced_bit(condition->bit)) {
    return Result<void>::failure(packing_error(
        "packing_forced_bit_invalid",
        "the packing forced-target bit is outside the closed binary "
        "domain"));
  }
  const std::size_t target = condition->target.ordinal();
  if (target >= problem.queue_count()) {
    return Result<void>::failure(packing_error(
        "packing_forced_target_out_of_range",
        "the packing forced target lies outside the compiled queue "
        "dimension"));
  }
  if (!condition->target.matches(weights.dimension())) {
    return Result<void>::failure(packing_error(
        "packing_forced_target_identity_mismatch",
        "the packing forced target belongs to another queue dimension"));
  }
  const bool required = condition->bit == ForcedTargetBit::one;
  const bool target_eligible = eligibility.bytes()[target] != 0U;
  if (required != target_eligible) {
    return Result<void>::failure(packing_error(
        "packing_forced_target_eligibility_mismatch",
        "the conditioned target eligibility disagrees with its forced "
        "side"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<CapacityVector> subtract_demand(
    const CapacityVector& capacity,
    const std::span<const BigNat> demand) {
  if (!demand_fits(demand, capacity)) {
    return Result<CapacityVector>::failure(packing_error(
        "packing_capacity_subtraction_precondition",
        "packing demand subtraction was requested without componentwise "
        "feasibility"));
  }
  std::vector<BigNat> result;
  result.reserve(capacity.size());
  for (std::size_t resource = 0U; resource < capacity.size(); ++resource) {
    auto difference = checked_subtract(capacity[resource], demand[resource]);
    if (!difference) {
      return Result<CapacityVector>::failure(packing_error(
          "packing_capacity_subtraction_underflow",
          "an exact residual-capacity subtraction unexpectedly underflowed",
          {"resource index: " + std::to_string(resource)}));
    }
    result.push_back(std::move(difference).value());
  }
  return Result<CapacityVector>::success(
      CapacityVector::from_values(std::move(result)));
}

struct PackingMemoKeyLess final {
  [[nodiscard]] bool operator()(const PackingMemoKey& lhs,
                                const PackingMemoKey& rhs) const noexcept {
    const std::strong_ordering subset_order =
        lhs.queues() <=> rhs.queues();
    if (subset_order != std::strong_ordering::equal) {
      return subset_order == std::strong_ordering::less;
    }
    const std::span<const BigNat> left =
        lhs.remaining_capacity().values();
    const std::span<const BigNat> right =
        rhs.remaining_capacity().values();
    const std::size_t common =
        left.size() < right.size() ? left.size() : right.size();
    for (std::size_t resource = 0U; resource < common; ++resource) {
      if (left[resource] != right[resource]) {
        return left[resource] < right[resource];
      }
    }
    return left.size() < right.size();
  }
};

struct PackingMemoValue final {
  BigNat score;
  QueueSubset selected;
};

struct PackingRecursionObserver final {
  std::vector<PackingMemoKey>* expanded_keys{nullptr};
  std::size_t* base_calls{nullptr};
  std::size_t* memo_hits{nullptr};
  bool force_distinct_branch_score_equality{false};
};

class PackingRecursion final {
 public:
  PackingRecursion(const PackingProblem& problem, const LexWeights& weights,
                   SearchBudget& budget,
                   PackingRecursionObserver* observer = nullptr)
      : problem_(problem),
        weights_(weights),
        budget_(budget),
        observer_(observer) {}

  [[nodiscard]] Result<PackingMemoValue> solve(
      QueueSubset queues, CapacityVector remaining_capacity) {
    // The required accounting order is encoded literally: normalize, base,
    // memo, one charge, then expansion. A failed child prevents insertion of
    // this key, and the public stack discards the whole solve-local map.
    auto normalized = normalize_packing_subproblem(
        problem_, std::move(queues), std::move(remaining_capacity));
    if (!normalized) {
      return Result<PackingMemoValue>::failure(
          std::move(normalized.error()));
    }
    PackingMemoKey key = std::move(normalized).value();
    if (key.queues().empty()) {
      if (observer_ != nullptr && observer_->base_calls != nullptr) {
        ++*observer_->base_calls;
      }
      return Result<PackingMemoValue>::success(PackingMemoValue{
          .score = BigNat(std::uint64_t{0U}),
          .selected = QueueSubset::none(problem_.queue_count()),
      });
    }

    const auto memoized = memo_.find(key);
    if (memoized != memo_.end()) {
      if (observer_ != nullptr && observer_->memo_hits != nullptr) {
        ++*observer_->memo_hits;
      }
      return Result<PackingMemoValue>::success(memoized->second);
    }

    auto charged = detail::SearchBudgetAccess::charge_expansion(budget_);
    if (!charged) {
      return Result<PackingMemoValue>::failure(std::move(charged.error()));
    }
    if (observer_ != nullptr && observer_->expanded_keys != nullptr) {
      observer_->expanded_keys->push_back(key);
    }

    const std::optional<std::size_t> pivot_value = key.queues().first_set();
    if (!pivot_value.has_value() || *pivot_value >= problem_.queue_count()) {
      return Result<PackingMemoValue>::failure(packing_error(
          "packing_pivot_invariant",
          "a nonempty canonical packing subset has no in-range pivot"));
    }
    const std::size_t pivot = *pivot_value;

    QueueSubset child_queues = key.queues();
    if (!child_queues.reset(pivot)) {
      return Result<PackingMemoValue>::failure(packing_error(
          "packing_subset_reset_invariant",
          "the packing pivot could not be removed from its canonical "
          "subset"));
    }

    auto skip = solve(child_queues, key.remaining_capacity());
    if (!skip) {
      return Result<PackingMemoValue>::failure(std::move(skip.error()));
    }

    const CompiledPackingDemand& pivot_demand = problem_.demands()[pivot];
    if (!demand_fits(pivot_demand.demand, key.remaining_capacity())) {
      return Result<PackingMemoValue>::failure(packing_error(
          "packing_normalization_invariant",
          "normalization retained a queue that does not fit the current "
          "capacity",
          {"dense queue index: " + std::to_string(pivot)}));
    }
    auto reduced_capacity = subtract_demand(key.remaining_capacity(),
                                            pivot_demand.demand);
    if (!reduced_capacity) {
      return Result<PackingMemoValue>::failure(
          std::move(reduced_capacity.error()));
    }
    auto take = solve(child_queues, std::move(reduced_capacity).value());
    if (!take) {
      return Result<PackingMemoValue>::failure(std::move(take.error()));
    }
    take.value().score += weights_.values()[pivot];
    if (!take.value().selected.set(pivot)) {
      return Result<PackingMemoValue>::failure(packing_error(
          "packing_subset_set_invariant",
          "the packing pivot could not be inserted into its reconstructed "
          "selection"));
    }

    PackingMemoValue best = std::move(skip).value();
    if (observer_ != nullptr &&
        observer_->force_distinct_branch_score_equality) {
      // One-shot test injection: simulate a malformed score representation
      // at a genuine pair of distinct completed branches. Production cannot
      // manufacture this equality because every eligible composite weight
      // carries a unique positive secondary bit.
      take.value().score = best.score;
      observer_->force_distinct_branch_score_equality = false;
    }
    if (take.value().score > best.score) {
      best = std::move(take).value();
    } else if (take.value().score == best.score &&
               take.value().selected != best.selected) {
      return Result<PackingMemoValue>::failure(packing_error(
          "packing_composite_equality_invariant",
          "distinct packing schedules have equal purported composite "
          "objective values"));
    }

    const auto [position, inserted] = memo_.emplace(std::move(key), best);
    if (!inserted) {
      return Result<PackingMemoValue>::failure(packing_error(
          "packing_memo_insertion_invariant",
          "a new packing subproblem unexpectedly collided with an existing "
          "memo entry"));
    }
    return Result<PackingMemoValue>::success(position->second);
  }

 private:
  const PackingProblem& problem_;
  const LexWeights& weights_;
  SearchBudget& budget_;
  PackingRecursionObserver* observer_;
  std::map<PackingMemoKey, PackingMemoValue, PackingMemoKeyLess> memo_;
};

[[nodiscard]] Result<void> validate_packing_result(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const QueueSubset& selected,
    const BigNat& objective,
    const detail::ForcedTargetCondition* condition) {
  if (selected.size() != problem.queue_count() || !selected.canonical()) {
    return Result<void>::failure(packing_error(
        "packing_result_subset_invalid",
        "the reconstructed packing selection is not a canonical queue "
        "subset"));
  }

  std::vector<BigNat> used;
  used.reserve(problem.resource_count());
  for (std::size_t resource = 0U; resource < problem.resource_count();
       ++resource) {
    used.emplace_back(std::uint64_t{0U});
  }
  BigNat recomputed(std::uint64_t{0U});
  for (std::size_t queue = 0U; queue < problem.queue_count(); ++queue) {
    if (!selected.test(queue)) {
      continue;
    }
    const bool forced_target =
        condition != nullptr && condition->bit == ForcedTargetBit::one &&
        condition->target.ordinal() == queue;
    if (eligibility.bytes()[queue] == 0U && !forced_target) {
      return Result<void>::failure(packing_error(
          "packing_result_ineligible_queue",
          "the reconstructed packing result selects an ineligible queue",
          {"dense queue index: " + std::to_string(queue)}));
    }
    recomputed += weights.values()[queue];
    const CompiledPackingDemand& record = problem.demands()[queue];
    for (std::size_t resource = 0U; resource < problem.resource_count();
         ++resource) {
      used[resource] += record.demand[resource];
    }
  }
  for (std::size_t resource = 0U; resource < problem.resource_count();
       ++resource) {
    if (used[resource] > problem.capacity()[resource]) {
      return Result<void>::failure(packing_error(
          "packing_result_capacity_violation",
          "the reconstructed packing result exceeds a resource capacity",
          {"resource index: " + std::to_string(resource)}));
    }
  }
  if (recomputed != objective) {
    return Result<void>::failure(packing_error(
        "packing_result_objective_mismatch",
        "the reconstructed packing result does not reproduce its exact "
        "objective",
        {"reported objective: " + objective.to_decimal_string(),
         "recomputed objective: " + recomputed.to_decimal_string()}));
  }
  return Result<void>::success();
}

}  // namespace

Result<PackingMemoKey> normalize_packing_subproblem(
    const PackingProblem& problem, QueueSubset queues,
    CapacityVector remaining_capacity) {
  try {
    auto valid_problem = validate_packing_problem(problem);
    if (!valid_problem) {
      return Result<PackingMemoKey>::failure(
          std::move(valid_problem.error()));
    }
    if (queues.size() != problem.queue_count() || !queues.canonical()) {
      return Result<PackingMemoKey>::failure(packing_error(
          "packing_memo_queue_subset_invalid",
          "a packing memo subset has the wrong logical dimension or a "
          "noncanonical bit pattern",
          {"compiled queues: " + std::to_string(problem.queue_count()),
           "subset logical size: " + std::to_string(queues.size())}));
    }
    if (remaining_capacity.size() != problem.resource_count()) {
      return Result<PackingMemoKey>::failure(packing_error(
          "packing_memo_capacity_dimension_mismatch",
          "a packing memo capacity vector differs from the resource "
          "dimension",
          {"compiled resources: " +
               std::to_string(problem.resource_count()),
           "capacity coordinates: " +
               std::to_string(remaining_capacity.size())}));
    }

    for (std::size_t queue = 0U; queue < problem.queue_count(); ++queue) {
      if (queues.test(queue) &&
          !demand_fits(problem.demands()[queue].demand,
                       remaining_capacity)) {
        if (!queues.reset(queue)) {
          return Result<PackingMemoKey>::failure(packing_error(
              "packing_normalization_reset_invariant",
              "packing normalization could not remove an infeasible queue"));
        }
      }
    }
    return Result<PackingMemoKey>::success(PackingMemoKey(
        std::move(queues), std::move(remaining_capacity)));
  } catch (const std::bad_alloc&) {
    return Result<PackingMemoKey>::failure(packing_resource_error(
        "packing_normalization_allocation_failure",
        "allocation failed while normalizing an exact packing state"));
  } catch (const std::length_error&) {
    return Result<PackingMemoKey>::failure(packing_resource_error(
        "packing_normalization_representation_failure",
        "an exact packing memo key exceeds a host container limit"));
  }
}

namespace detail {

namespace {

[[nodiscard]] Result<PackingExactWitness> solve_packing_exact_core(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition,
    PackingRecursionObserver* observer) {
  try {
    auto valid_problem = validate_packing_problem(problem);
    if (!valid_problem) {
      return Result<PackingExactWitness>::failure(
          std::move(valid_problem.error()));
    }
    auto valid_query = validate_packing_query(problem, eligibility, weights,
                                              budget, condition);
    if (!valid_query) {
      return Result<PackingExactWitness>::failure(
          std::move(valid_query.error()));
    }

    auto active_result = QueueSubset::from_bytes(eligibility.bytes());
    if (!active_result) {
      return Result<PackingExactWitness>::failure(
          std::move(active_result.error()));
    }
    QueueSubset active = std::move(active_result).value();
    CapacityVector remaining_capacity = problem.capacity();
    std::optional<std::size_t> committed_target;

    if (condition != nullptr && condition->bit == ForcedTargetBit::one) {
      const std::size_t target = condition->target.ordinal();
      const CompiledPackingDemand& target_demand = problem.demands()[target];
      if (!demand_fits(target_demand.demand, remaining_capacity)) {
        return Result<PackingExactWitness>::failure(packing_diagnostic(
            DiagnosticCategory::unavailable, "infeasible_side",
            "the forced-one packing target exceeds the original capacity",
            {"target dense index: " + std::to_string(target)}));
      }
      auto residual = subtract_demand(remaining_capacity,
                                      target_demand.demand);
      if (!residual) {
        return Result<PackingExactWitness>::failure(
            std::move(residual.error()));
      }
      remaining_capacity = std::move(residual).value();
      if (!active.reset(target)) {
        return Result<PackingExactWitness>::failure(packing_error(
            "packing_forced_target_subset_invariant",
            "the forced-one packing target could not be removed from the "
            "residual subset"));
      }
      committed_target = target;
    }

    PackingRecursion recursion(problem, weights, budget, observer);
    auto optimum = recursion.solve(std::move(active),
                                   std::move(remaining_capacity));
    if (!optimum) {
      // In particular, search exhaustion propagates without converting the
      // partially computed branch or solve-local memo into a witness.
      return Result<PackingExactWitness>::failure(
          std::move(optimum.error()));
    }
    PackingMemoValue exact = std::move(optimum).value();

    if (committed_target.has_value()) {
      if (!exact.selected.set(*committed_target)) {
        return Result<PackingExactWitness>::failure(packing_error(
            "packing_forced_target_reconstruction_invariant",
            "the forced-one packing target could not be committed to the "
            "residual optimum"));
      }
      exact.score += weights.values()[*committed_target];
    }

    auto validated = validate_packing_result(
        problem, eligibility, weights, exact.selected, exact.score,
        condition);
    if (!validated) {
      return Result<PackingExactWitness>::failure(
          std::move(validated.error()));
    }

    std::vector<std::uint8_t> selected_bytes(problem.queue_count(),
                                              std::uint8_t{0U});
    for (std::size_t queue = 0U; queue < problem.queue_count(); ++queue) {
      selected_bytes[queue] =
          exact.selected.test(queue) ? std::uint8_t{1U} : std::uint8_t{0U};
    }
    auto schedule = Schedule::from_bytes(weights.dimension(),
                                         std::move(selected_bytes));
    if (!schedule) {
      return Result<PackingExactWitness>::failure(
          std::move(schedule.error()));
    }

    std::vector<std::string> proof_notes{
        "exact arbitrary-precision binary packing take/skip recursion",
        "memoized by canonical queue subset and unchanged exact residual capacity",
        "normalization removes only current-capacity-infeasible queues",
        "cold solve-local memo with atomic search-budget exhaustion",
        "completed nonbase memo-key expansions: " +
            budget.completed_expansions().to_decimal_string(),
    };
    if (committed_target.has_value()) {
      proof_notes.push_back(
          "forced-one target committed after exact capacity subtraction");
    } else if (condition != nullptr) {
      proof_notes.push_back(
          "forced-zero target excluded from the initial queue subset");
    }
    return Result<PackingExactWitness>::success(PackingExactWitness{
        .schedule = std::move(schedule).value(),
        .composite_objective = std::move(exact.score),
        .proof_notes = std::move(proof_notes),
    });
  } catch (const std::bad_alloc&) {
    return Result<PackingExactWitness>::failure(packing_resource_error(
        "packing_solve_allocation_failure",
        "allocation failed during the cold exact packing solve"));
  } catch (const std::length_error&) {
    return Result<PackingExactWitness>::failure(packing_resource_error(
        "packing_solve_representation_failure",
        "the cold exact packing solve exceeds a host container limit"));
  }
}

}  // namespace

Result<PackingExactWitness> solve_packing_exact(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition) {
  return solve_packing_exact_core(problem, eligibility, weights, budget,
                                  condition, nullptr);
}

#if defined(MWPERF_C08_TEST_SEAMS)
Result<PackingExactWitness> solve_packing_exact_with_instrumentation(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    PackingSolveInstrumentation& instrumentation,
    const PackingSolveFault fault,
    const ForcedTargetCondition* condition) {
  switch (fault) {
    case PackingSolveFault::none:
    case PackingSolveFault::force_distinct_branch_score_equality:
      break;
    default:
      return Result<PackingExactWitness>::failure(packing_error(
          "packing_test_fault_invalid",
          "the packing test fault is outside the closed seam domain"));
  }
  instrumentation.expanded_keys.clear();
  instrumentation.base_calls = 0U;
  instrumentation.memo_hits = 0U;
  PackingRecursionObserver observer{
      .expanded_keys = &instrumentation.expanded_keys,
      .base_calls = &instrumentation.base_calls,
      .memo_hits = &instrumentation.memo_hits,
      .force_distinct_branch_score_equality =
          fault == PackingSolveFault::force_distinct_branch_score_equality,
  };
  return solve_packing_exact_core(problem, eligibility, weights, budget,
                                  condition, &observer);
}
#endif

}  // namespace detail
}  // namespace mwperf
