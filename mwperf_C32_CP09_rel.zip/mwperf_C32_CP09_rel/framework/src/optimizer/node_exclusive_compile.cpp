#include "mwperf/optimizer/node_exclusive.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic node_exclusive_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

template <typename Value>
[[nodiscard]] Result<Value> node_exclusive_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(node_exclusive_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes)));
}

template <typename Value>
[[nodiscard]] Result<Value> node_exclusive_resource_failure(
    std::string code, std::string message) {
  return Result<Value>::failure(node_exclusive_diagnostic(
      DiagnosticCategory::resource_limit, std::move(code),
      std::move(message)));
}

[[nodiscard]] auto link_key(const NodeExclusiveLabelledLink& link) noexcept {
  return std::tuple{link.first, link.second, link.queue.ordinal()};
}

[[nodiscard]] Result<void> validate_compiled_problem(
    const NodeExclusiveProblem& problem) {
  const std::size_t vertex_count = problem.vertex_count();
  const std::size_t queue_count = problem.queue_count();
  const std::span<const NodeExclusiveVertex> vertices = problem.vertices();
  const std::span<const NodeExclusiveLabelledLink> links = problem.links();
  const std::span<const std::size_t> offsets = problem.incidence_offsets();
  const std::span<const NodeExclusiveIncidence> incidence =
      problem.incidence();
  const std::span<const NodeExclusiveParallelGroup> groups =
      problem.parallel_groups();
  const std::span<const std::size_t> queue_to_link =
      problem.queue_to_link();

  if (links.size() != queue_count) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_problem_queue_dimension_mismatch",
        "the immutable node-exclusive link and queue dimensions differ"));
  }
  if (vertex_count == std::numeric_limits<std::size_t>::max() ||
      offsets.size() != vertex_count + 1U || offsets.empty() ||
      offsets.front() != 0U) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_problem_incidence_offsets_invalid",
        "the immutable node-exclusive incidence offsets have an invalid "
        "dimension or origin"));
  }
  if (queue_count > std::numeric_limits<std::size_t>::max() / 2U ||
      incidence.size() != queue_count * 2U ||
      offsets.back() != incidence.size()) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_problem_incidence_dimension_mismatch",
        "the immutable node-exclusive incidence CSR does not contain two "
        "entries per labelled link"));
  }

  std::vector<std::uint8_t> vertex_seen(vertex_count, 0U);
  for (std::size_t ordinal = 0U; ordinal < vertex_count; ++ordinal) {
    const std::size_t stored = vertices[ordinal].index.ordinal();
    if (stored >= vertex_count || vertex_seen[stored] != 0U ||
        stored != ordinal) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_vertex_map_invalid",
          "the immutable node-exclusive vertices are not in dense index "
          "order"));
    }
    vertex_seen[stored] = 1U;
    if (offsets[ordinal] > offsets[ordinal + 1U] ||
        offsets[ordinal + 1U] > incidence.size()) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_incidence_offsets_invalid",
          "the immutable node-exclusive incidence offsets are not a valid "
          "monotone CSR partition"));
    }
    const bool isolated = offsets[ordinal] == offsets[ordinal + 1U];
    if (vertices[ordinal].isolated != isolated) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_isolation_flag_mismatch",
          "a compiled vertex isolation flag disagrees with its incidence "
          "range",
          {"dense vertex index: " + std::to_string(ordinal)}));
    }
  }

  std::vector<std::uint8_t> queue_seen(queue_count, 0U);
  std::optional<std::tuple<std::size_t, std::size_t, std::size_t>> previous;
  for (std::size_t position = 0U; position < links.size(); ++position) {
    const NodeExclusiveLabelledLink& link = links[position];
    const std::size_t queue = link.queue.ordinal();
    if (queue >= queue_count || queue_seen[queue] != 0U ||
        queue_to_link[queue] != position) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_queue_map_invalid",
          "the immutable node-exclusive queue reconstruction is not a "
          "dense bijection"));
    }
    queue_seen[queue] = 1U;
    if (!(link.first < link.second) || link.second >= vertex_count) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_endpoint_invalid",
          "a compiled node-exclusive link has noncanonical or out-of-range "
          "endpoints",
          {"dense queue index: " + std::to_string(queue)}));
    }
    const auto key = link_key(link);
    if (previous.has_value() && !(previous.value() < key)) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_link_order_invalid",
          "the immutable node-exclusive links are not in strict canonical "
          "order"));
    }
    previous = key;
  }

  std::size_t group_cursor = 0U;
  std::optional<std::pair<std::size_t, std::size_t>> previous_pair;
  for (const NodeExclusiveParallelGroup& group : groups) {
    if (group.begin != group_cursor || group.begin >= group.end ||
        group.end > links.size() || !(group.first < group.second) ||
        group.second >= vertex_count) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_parallel_group_invalid",
          "the immutable node-exclusive parallel groups do not form a "
          "valid nonempty partition"));
    }
    const std::pair<std::size_t, std::size_t> key{group.first, group.second};
    if (previous_pair.has_value() && !(previous_pair.value() < key)) {
      return Result<void>::failure(node_exclusive_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_problem_parallel_group_order_invalid",
          "the immutable node-exclusive parallel groups are not in strict "
          "endpoint order"));
    }
    for (std::size_t position = group.begin; position < group.end;
         ++position) {
      if (links[position].first != group.first ||
          links[position].second != group.second) {
        return Result<void>::failure(node_exclusive_diagnostic(
            DiagnosticCategory::internal,
            "node_exclusive_problem_parallel_group_membership_invalid",
            "a compiled parallel group contains a link with another "
            "endpoint pair"));
      }
    }
    previous_pair = key;
    group_cursor = group.end;
  }
  if (group_cursor != links.size()) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_problem_parallel_group_coverage_invalid",
        "the immutable node-exclusive parallel groups omit labelled links"));
  }

  std::vector<std::uint8_t> incidence_count(queue_count, 0U);
  for (std::size_t vertex = 0U; vertex < vertex_count; ++vertex) {
    std::optional<std::pair<std::size_t, std::size_t>> prior;
    for (std::size_t cursor = offsets[vertex];
         cursor < offsets[vertex + 1U]; ++cursor) {
      const NodeExclusiveIncidence& item = incidence[cursor];
      if (item.link >= links.size()) {
        return Result<void>::failure(node_exclusive_diagnostic(
            DiagnosticCategory::internal,
            "node_exclusive_problem_incidence_link_out_of_range",
            "the immutable incidence CSR contains an out-of-range link "
            "index"));
      }
      const NodeExclusiveLabelledLink& link = links[item.link];
      const std::size_t expected_opposite =
          link.first == vertex
              ? link.second
              : (link.second == vertex
                     ? link.first
                     : std::numeric_limits<std::size_t>::max());
      if (item.opposite != expected_opposite ||
          item.opposite >= vertex_count) {
        return Result<void>::failure(node_exclusive_diagnostic(
            DiagnosticCategory::internal,
            "node_exclusive_problem_incidence_endpoint_mismatch",
            "an immutable incidence record disagrees with its labelled "
            "link endpoints"));
      }
      const std::pair<std::size_t, std::size_t> key{item.opposite, item.link};
      if (prior.has_value() && !(prior.value() < key)) {
        return Result<void>::failure(node_exclusive_diagnostic(
            DiagnosticCategory::internal,
            "node_exclusive_problem_incidence_order_invalid",
            "a vertex incidence range is not in strict canonical order"));
      }
      prior = key;
      if (incidence_count[item.link] == 2U) {
        return Result<void>::failure(node_exclusive_diagnostic(
            DiagnosticCategory::internal,
            "node_exclusive_problem_incidence_duplicate",
            "a labelled link occurs more than twice in the incidence CSR"));
      }
      ++incidence_count[item.link];
    }
  }
  if (std::ranges::find_if(incidence_count, [](const std::uint8_t count) {
        return count != 2U;
      }) != incidence_count.end()) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_problem_incidence_coverage_invalid",
        "each labelled link must occur exactly twice in the incidence CSR"));
  }

  std::vector<std::size_t> expected_isolated;
  for (std::size_t vertex = 0U; vertex < vertex_count; ++vertex) {
    if (offsets[vertex] == offsets[vertex + 1U]) {
      expected_isolated.push_back(vertex);
    }
  }
  if (!std::ranges::equal(expected_isolated,
                          problem.isolated_vertices())) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_problem_isolated_vertices_invalid",
        "the immutable isolated-vertex list disagrees with the incidence "
        "CSR"));
  }

  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_representative_query(
    const NodeExclusiveProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights) {
  if (eligibility.dimension() != weights.dimension()) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_query_dimension_identity_mismatch",
        "node-exclusive eligibility and weights belong to different queue "
        "dimensions"));
  }
  if (weights.dimension().family() !=
      ServiceFamily::node_exclusive_matching) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_query_family_mismatch",
        "the node-exclusive primitive received a queue dimension for "
        "another service family"));
  }
  if (weights.eligibility() != eligibility) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_query_eligibility_mismatch",
        "the node-exclusive eligibility mask disagrees with the mask "
        "embedded in the exact weights"));
  }
  if (eligibility.size() != problem.queue_count() ||
      weights.size() != problem.queue_count()) {
    return Result<void>::failure(node_exclusive_diagnostic(
        DiagnosticCategory::internal,
        "node_exclusive_query_dimension_mismatch",
        "the node-exclusive query does not match its compiled queue "
        "dimension",
        {"compiled queues: " + std::to_string(problem.queue_count()),
         "eligibility entries: " + std::to_string(eligibility.size()),
         "weight entries: " + std::to_string(weights.size())}));
  }
  return Result<void>::success();
}

}  // namespace

Result<RepresentativeGraph>
detail::select_parallel_link_representatives_active(
    const NodeExclusiveProblem& problem,
    const std::span<const std::uint8_t> active,
    const LexWeights& weights) {
  try {
    auto valid_problem = validate_compiled_problem(problem);
    if (!valid_problem) {
      return Result<RepresentativeGraph>::failure(
          std::move(valid_problem.error()));
    }
    if (active.size() != problem.queue_count() ||
        weights.size() != problem.queue_count()) {
      return node_exclusive_failure<RepresentativeGraph>(
          "node_exclusive_active_dimension_mismatch",
          "the solve-local active mask does not match the immutable "
          "node-exclusive queue dimension");
    }
    if (weights.dimension().family() !=
        ServiceFamily::node_exclusive_matching) {
      return node_exclusive_failure<RepresentativeGraph>(
          "node_exclusive_query_family_mismatch",
          "the node-exclusive primitive received a queue dimension for "
          "another service family");
    }

    for (std::size_t queue = 0U; queue < active.size(); ++queue) {
      if (active[queue] > 1U) {
        return node_exclusive_failure<RepresentativeGraph>(
            "node_exclusive_active_mask_nonbinary",
            "the solve-local node-exclusive active mask is not binary",
            {"dense queue index: " + std::to_string(queue)});
      }
      if (active[queue] != 0U &&
          weights.eligibility().bytes()[queue] == 0U) {
        return node_exclusive_failure<RepresentativeGraph>(
            "node_exclusive_active_mask_expands_eligibility",
            "the solve-local node-exclusive active mask enables an "
            "ineligible queue",
            {"dense queue index: " + std::to_string(queue)});
      }
    }

    std::vector<RepresentativeEdge> representatives;
    representatives.reserve(problem.parallel_groups().size());
    for (const NodeExclusiveParallelGroup& group :
         problem.parallel_groups()) {
      std::optional<std::size_t> best;
      for (std::size_t position = group.begin; position < group.end;
           ++position) {
        const NodeExclusiveLabelledLink& link = problem.links()[position];
        const std::size_t queue = link.queue.ordinal();
        if (active[queue] == 0U) {
          continue;
        }
        if (!best.has_value()) {
          best = position;
          continue;
        }
        const DenseQueueIndex best_queue = problem.links()[*best].queue;
        const BigNat& candidate_weight = weights.at(link.queue);
        const BigNat& best_weight = weights.at(best_queue);
        if (candidate_weight == best_weight) {
          return node_exclusive_failure<RepresentativeGraph>(
              "node_exclusive_parallel_composite_equality_invariant",
              "two eligible parallel queue labels have equal supplied "
              "composite weights",
              {"first dense queue index: " +
                   std::to_string(best_queue.ordinal()),
               "second dense queue index: " + std::to_string(queue)});
        }
        if (candidate_weight > best_weight) {
          best = position;
        }
      }
      if (!best.has_value()) {
        continue;
      }
      const NodeExclusiveLabelledLink& selected = problem.links()[*best];
      representatives.push_back(RepresentativeEdge{
          .first = group.first,
          .second = group.second,
          .queue = selected.queue,
          .weight = weights.at(selected.queue),
      });
    }

    return Result<RepresentativeGraph>::success(RepresentativeGraph(
        problem.vertex_count(), weights.dimension(),
        std::move(representatives)));
  } catch (const std::bad_alloc&) {
    return node_exclusive_resource_failure<RepresentativeGraph>(
        "node_exclusive_representative_allocation_failure",
        "allocation failed during solve-local parallel-link reduction");
  } catch (const std::length_error&) {
    return node_exclusive_resource_failure<RepresentativeGraph>(
        "node_exclusive_representative_representation_failure",
        "the solve-local representative graph exceeds a host container "
        "limit");
  }
}

Result<NodeExclusiveProblem> compile_node_exclusive_problem(
    const ResolvedNodeExclusiveConstraint& constraint) {
  try {
    const std::size_t vertex_count = constraint.vertices.size();
    const std::size_t queue_count = constraint.links.size();
    if (queue_count > std::numeric_limits<std::size_t>::max() / 2U ||
        vertex_count == std::numeric_limits<std::size_t>::max()) {
      return node_exclusive_resource_failure<NodeExclusiveProblem>(
          "node_exclusive_compile_dimension_overflow",
          "the bound node-exclusive geometry exceeds the host index range");
    }

    std::vector<std::optional<NodeExclusiveVertex>> vertices_by_index(
        vertex_count);
    for (const ResolvedVertex& vertex : constraint.vertices) {
      const std::size_t ordinal = vertex.index.ordinal();
      if (ordinal >= vertex_count || vertices_by_index[ordinal].has_value()) {
        return node_exclusive_failure<NodeExclusiveProblem>(
            "node_exclusive_compiled_vertex_coverage_invalid",
            "the bound node-exclusive vertices are not a dense "
            "permutation");
      }
      vertices_by_index[ordinal] =
          NodeExclusiveVertex{.index = vertex.index, .isolated = true};
    }

    std::vector<std::optional<NodeExclusiveLabelledLink>> links_by_queue(
        queue_count);
    for (const ResolvedNodeExclusiveLink& source : constraint.links) {
      const std::size_t queue = source.queue.ordinal();
      const std::size_t u = source.u.ordinal();
      const std::size_t v = source.v.ordinal();
      if (queue >= queue_count || links_by_queue[queue].has_value()) {
        return node_exclusive_failure<NodeExclusiveProblem>(
            "node_exclusive_compiled_queue_coverage_invalid",
            "the bound node-exclusive links do not cover every dense queue "
            "exactly once");
      }
      if (u >= vertex_count || v >= vertex_count) {
        return node_exclusive_failure<NodeExclusiveProblem>(
            "node_exclusive_compiled_endpoint_out_of_range",
            "a bound node-exclusive link has an out-of-range vertex "
            "endpoint",
            {"dense queue index: " + std::to_string(queue)});
      }
      if (u == v) {
        return node_exclusive_failure<NodeExclusiveProblem>(
            "node_exclusive_compiled_self_loop",
            "a bound node-exclusive link has identical endpoints",
            {"dense queue index: " + std::to_string(queue)});
      }
      links_by_queue[queue] = NodeExclusiveLabelledLink{
          .queue = source.queue,
          .first = std::min(u, v),
          .second = std::max(u, v),
      };
    }

    std::vector<NodeExclusiveVertex> vertices;
    vertices.reserve(vertex_count);
    for (std::size_t ordinal = 0U; ordinal < vertex_count; ++ordinal) {
      if (!vertices_by_index[ordinal].has_value()) {
        return node_exclusive_failure<NodeExclusiveProblem>(
            "node_exclusive_compiled_vertex_coverage_invalid",
            "the bound node-exclusive vertices omit a dense index",
            {"missing dense vertex index: " + std::to_string(ordinal)});
      }
      vertices.push_back(std::move(*vertices_by_index[ordinal]));
    }

    std::vector<NodeExclusiveLabelledLink> links;
    links.reserve(queue_count);
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if (!links_by_queue[queue].has_value()) {
        return node_exclusive_failure<NodeExclusiveProblem>(
            "node_exclusive_compiled_queue_coverage_invalid",
            "the bound node-exclusive links omit a dense queue",
            {"missing dense queue index: " + std::to_string(queue)});
      }
      links.push_back(std::move(*links_by_queue[queue]));
    }
    std::ranges::sort(links, [](const NodeExclusiveLabelledLink& lhs,
                               const NodeExclusiveLabelledLink& rhs) {
      return link_key(lhs) < link_key(rhs);
    });

    std::vector<std::size_t> queue_to_link(queue_count, queue_count);
    std::vector<NodeExclusiveParallelGroup> groups;
    groups.reserve(links.size());
    for (std::size_t position = 0U; position < links.size();) {
      const std::size_t begin = position;
      const std::size_t first = links[position].first;
      const std::size_t second = links[position].second;
      while (position < links.size() && links[position].first == first &&
             links[position].second == second) {
        queue_to_link[links[position].queue.ordinal()] = position;
        ++position;
      }
      groups.push_back(NodeExclusiveParallelGroup{
          .first = first,
          .second = second,
          .begin = begin,
          .end = position,
      });
    }

    std::vector<std::vector<NodeExclusiveIncidence>> by_vertex(vertex_count);
    for (std::size_t position = 0U; position < links.size(); ++position) {
      const NodeExclusiveLabelledLink& link = links[position];
      by_vertex[link.first].push_back(
          NodeExclusiveIncidence{.link = position,
                                 .opposite = link.second});
      by_vertex[link.second].push_back(
          NodeExclusiveIncidence{.link = position,
                                 .opposite = link.first});
    }

    std::vector<std::size_t> offsets(vertex_count + 1U, 0U);
    std::vector<NodeExclusiveIncidence> incidence;
    incidence.reserve(queue_count * 2U);
    std::vector<std::size_t> isolated;
    for (std::size_t vertex = 0U; vertex < vertex_count; ++vertex) {
      std::ranges::sort(
          by_vertex[vertex],
          [](const NodeExclusiveIncidence& lhs,
             const NodeExclusiveIncidence& rhs) {
            return std::pair{lhs.opposite, lhs.link} <
                   std::pair{rhs.opposite, rhs.link};
          });
      if (by_vertex[vertex].empty()) {
        isolated.push_back(vertex);
      } else {
        vertices[vertex].isolated = false;
      }
      incidence.insert(incidence.end(), by_vertex[vertex].begin(),
                       by_vertex[vertex].end());
      offsets[vertex + 1U] = incidence.size();
    }

    NodeExclusiveProblem problem(
        std::move(vertices), std::move(links), std::move(offsets),
        std::move(incidence), std::move(groups), std::move(queue_to_link),
        std::move(isolated));
    auto valid = validate_compiled_problem(problem);
    if (!valid) {
      return Result<NodeExclusiveProblem>::failure(std::move(valid.error()));
    }
    return Result<NodeExclusiveProblem>::success(std::move(problem));
  } catch (const std::bad_alloc&) {
    return node_exclusive_resource_failure<NodeExclusiveProblem>(
        "node_exclusive_compile_allocation_failure",
        "allocation failed while compiling immutable node-exclusive "
        "geometry");
  } catch (const std::length_error&) {
    return node_exclusive_resource_failure<NodeExclusiveProblem>(
        "node_exclusive_compile_representation_failure",
        "immutable node-exclusive geometry exceeds a host container limit");
  }
}

Result<RepresentativeGraph> select_parallel_link_representatives(
    const NodeExclusiveProblem& problem,
    const EligibilityMask& eligibility, const LexWeights& weights) {
  auto valid_query =
      validate_representative_query(problem, eligibility, weights);
  if (!valid_query) {
    return Result<RepresentativeGraph>::failure(
        std::move(valid_query.error()));
  }
  return detail::select_parallel_link_representatives_active(
      problem, eligibility.bytes(), weights);
}

}  // namespace mwperf
