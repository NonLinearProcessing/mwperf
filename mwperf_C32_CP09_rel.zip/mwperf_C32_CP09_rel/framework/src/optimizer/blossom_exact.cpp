/*
 * Exact weighted-Blossom implementation for mwperf.
 *
 * This file is a C++/Boost.Multiprecision translation of the integer path in
 * NetworkX 3.6.1, networkx.algorithms.matching.max_weight_matching, itself an
 * implementation of the Edmonds/Galil primal-dual weighted matching method.
 * Upstream provenance: tag networkx-3.6.1, commit
 * 7530809bfa1ea7ed6fdf918a4d1431488953cb1f, matching.py SHA-256
 * 5e08becf2f42da936f1b04e2c53155eeeb7b5be97cb3bcd480985af6ff03d2cf.
 * The translation removes the floating-point and maximum-cardinality modes,
 * replaces every objective/dual/slack value with mwperf::BigInt, replaces
 * assertion-only failures with typed diagnostics, and checks an explicit
 * exact primal-dual certificate before returning.
 *
 * NetworkX is distributed under the 3-clause BSD license:
 *
 * Copyright (c) 2004-2025, NetworkX Developers
 * Aric Hagberg <hagberg@lanl.gov>
 * Dan Schult <dschult@colgate.edu>
 * Pieter Swart <swart@lanl.gov>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright notice,
 *   this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * * Neither the name of the NetworkX Developers nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "mwperf/optimizer/node_exclusive.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <limits>
#include <map>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {
namespace {

using Vertex = std::size_t;
using EdgeIndex = std::size_t;
using BlossomIndex = std::size_t;

[[nodiscard]] Diagnostic blossom_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

struct BlossomFailure final {
  Diagnostic diagnostic;
};

void fail(std::string code, std::string message,
          std::vector<std::string> notes = {}) {
  throw BlossomFailure{blossom_diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::move(notes))};
}

void require(const bool condition, std::string code, std::string message,
             std::vector<std::string> notes = {}) {
  if (!condition) {
    fail(std::move(code), std::move(message), std::move(notes));
  }
}

enum class Label : std::uint8_t {
  none = 0U,
  outer = 1U,
  inner = 2U,
  breadcrumb = 5U,
};

struct DirectedEdge final {
  Vertex first;
  Vertex second;
  EdgeIndex edge;
};

struct BlossomNode final {
  bool active{false};
  bool nontrivial{false};
  std::optional<BlossomIndex> parent;
  Vertex base{0U};
  std::vector<BlossomIndex> children;
  // cycle_edges[i] runs from children[i] to children[(i + 1) mod k].
  std::vector<DirectedEdge> cycle_edges;
  std::vector<Vertex> leaves;
  BigInt dual{0};
  Label label{Label::none};
  std::optional<DirectedEdge> label_edge;
  std::optional<EdgeIndex> best_edge;
  // nullopt means "not computed"; an engaged empty vector is meaningful.
  std::optional<std::vector<EdgeIndex>> best_edge_set;
};

struct MatchingPayload final {
  std::vector<std::size_t> selected_edges;
  std::vector<std::optional<std::size_t>> vertex_mates;
  BigNat objective{std::uint64_t{0U}};
};

class ExactBlossomSolver final {
 public:
  ExactBlossomSolver(const RepresentativeGraph& graph,
                     const BlossomTestFault fault)
      : graph_(graph),
        edges_(graph.edges()),
        vertex_count_(graph.vertex_count()),
        edge_count_(edges_.size()),
        fault_(fault) {
    validate_and_initialize();
  }

  [[nodiscard]] MatchingPayload run() {
    if (vertex_count_ == 0U) {
      verify_certificate(BigNat(std::uint64_t{0U}));
      return MatchingPayload{};
    }

    while (run_stage()) {
      // Every successful stage augments exactly once. No recursive search
      // budget is involved; this is only a structural sanity assertion.
    }

    MatchingPayload payload = extract_matching();
    verify_certificate(payload.objective);
    return payload;
  }

#if defined(MWPERF_C07_TEST_SEAMS)
  [[nodiscard]] bool observed_negative_internal_raw_slack() const noexcept {
    return observed_negative_internal_raw_slack_;
  }
#endif

 private:
  const RepresentativeGraph& graph_;
  std::span<const RepresentativeEdge> edges_;
  std::size_t vertex_count_;
  std::size_t edge_count_;
  BlossomTestFault fault_;

  std::vector<std::vector<EdgeIndex>> adjacency_;
  std::map<std::pair<Vertex, Vertex>, EdgeIndex> edge_by_pair_;
  std::vector<std::optional<Vertex>> mate_;
  std::vector<BigInt> vertex_dual_;
  std::vector<BlossomNode> nodes_;
  std::vector<BlossomIndex> in_blossom_;
  std::vector<std::uint8_t> allowable_;
  std::deque<Vertex> scan_queue_;
#if defined(MWPERF_C07_TEST_SEAMS)
  bool observed_negative_internal_raw_slack_{false};
#endif

  [[nodiscard]] static std::pair<Vertex, Vertex> endpoint_key(
      Vertex first, Vertex second) noexcept {
    if (second < first) {
      std::swap(first, second);
    }
    return {first, second};
  }

  [[nodiscard]] bool is_active(const BlossomIndex blossom) const noexcept {
    return blossom < nodes_.size() && nodes_[blossom].active;
  }

  [[nodiscard]] bool is_nontrivial(
      const BlossomIndex blossom) const noexcept {
    return is_active(blossom) && nodes_[blossom].nontrivial;
  }

  [[nodiscard]] Vertex other_endpoint(const EdgeIndex edge,
                                      const Vertex vertex) const {
    require(edge < edge_count_, "blossom_edge_index_out_of_range",
            "the Blossom arena referenced an out-of-range edge");
    const RepresentativeEdge& record = edges_[edge];
    if (record.first == vertex) {
      return record.second;
    }
    require(record.second == vertex, "blossom_edge_endpoint_mismatch",
            "a Blossom adjacency edge is not incident to its vertex");
    return record.first;
  }

  [[nodiscard]] DirectedEdge direct_edge(const EdgeIndex edge,
                                         const Vertex from) const {
    return DirectedEdge{from, other_endpoint(edge, from), edge};
  }

  [[nodiscard]] static DirectedEdge reverse_edge(
      const DirectedEdge& edge) noexcept {
    return DirectedEdge{edge.second, edge.first, edge.edge};
  }

  void validate_and_initialize() {
    if (fault_ != BlossomTestFault::none &&
        fault_ != BlossomTestFault::force_certificate_mismatch) {
      fail("blossom_test_fault_invalid",
           "the Blossom test fault lies outside its closed domain");
    }
    if (graph_.dimension().family() !=
        ServiceFamily::node_exclusive_matching) {
      fail("blossom_graph_family_mismatch",
           "the representative graph belongs to another service family");
    }
    if (graph_.queue_count() == 0U) {
      fail("blossom_graph_queue_dimension_empty",
           "a representative graph requires a nonempty queue dimension");
    }
    if (vertex_count_ >
        (std::numeric_limits<std::size_t>::max)() / 2U) {
      throw BlossomFailure{blossom_diagnostic(
          DiagnosticCategory::resource_limit,
          "blossom_arena_dimension_overflow",
          "the exact Blossom arena exceeds the host index range")};
    }

    adjacency_.assign(vertex_count_, {});
    std::set<std::size_t> seen_queues;
    std::optional<std::pair<Vertex, Vertex>> previous_pair;
    for (EdgeIndex edge = 0U; edge < edge_count_; ++edge) {
      const RepresentativeEdge& record = edges_[edge];
      if (record.first >= vertex_count_ || record.second >= vertex_count_ ||
          record.first >= record.second) {
        fail("blossom_graph_endpoint_invalid",
             "a representative edge does not have strict in-range endpoints",
             {"representative edge index: " + std::to_string(edge)});
      }
      const std::pair<Vertex, Vertex> pair{record.first, record.second};
      if (previous_pair.has_value() && !(previous_pair.value() < pair)) {
        fail("blossom_graph_edge_order_invalid",
             "representative edges are not in strict canonical endpoint order",
             {"representative edge index: " + std::to_string(edge)});
      }
      previous_pair = pair;
      if (record.queue.ordinal() >= graph_.queue_count() ||
          !seen_queues.insert(record.queue.ordinal()).second) {
        fail("blossom_graph_queue_map_invalid",
             "representative edges do not map injectively into the dense queue catalog",
             {"representative edge index: " + std::to_string(edge)});
      }
      edge_by_pair_.emplace(pair, edge);
      adjacency_[record.first].push_back(edge);
      adjacency_[record.second].push_back(edge);
    }
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      std::ranges::sort(
          adjacency_[vertex],
          [this, vertex](const EdgeIndex lhs, const EdgeIndex rhs) {
            const Vertex lhs_other = other_endpoint(lhs, vertex);
            const Vertex rhs_other = other_endpoint(rhs, vertex);
            if (lhs_other != rhs_other) {
              return lhs_other < rhs_other;
            }
            return lhs < rhs;
          });
    }

    mate_.assign(vertex_count_, std::nullopt);
    in_blossom_.resize(vertex_count_);
    nodes_.resize(vertex_count_ * 2U);
    allowable_.assign(edge_count_, std::uint8_t{0U});

    BigInt maximum_weight = 0;
    for (const RepresentativeEdge& edge : edges_) {
      if (edge.weight.value() > maximum_weight) {
        maximum_weight = edge.weight.value();
      }
    }
    vertex_dual_.assign(vertex_count_, maximum_weight);
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      BlossomNode& node = nodes_[vertex];
      node.active = true;
      node.nontrivial = false;
      node.parent.reset();
      node.base = vertex;
      node.children.clear();
      node.cycle_edges.clear();
      node.leaves = {vertex};
      node.dual = 0;
      node.label = Label::none;
      node.label_edge.reset();
      node.best_edge.reset();
      node.best_edge_set.reset();
      in_blossom_[vertex] = vertex;
    }
  }

  [[nodiscard]] BigInt raw_slack(const EdgeIndex edge) const {
    require(edge < edge_count_, "blossom_edge_index_out_of_range",
            "slack was requested for an out-of-range edge");
    const RepresentativeEdge& record = edges_[edge];
    BigInt slack = vertex_dual_[record.first];
    slack += vertex_dual_[record.second];
    BigInt twice_weight = record.weight.value();
    twice_weight <<= 1U;
    slack -= twice_weight;
    return slack;
  }

  [[nodiscard]] BigInt checked_external_slack(const EdgeIndex edge) const {
    const RepresentativeEdge& record = edges_[edge];
    require(in_blossom_[record.first] != in_blossom_[record.second],
            "blossom_internal_edge_slack_requested",
            "raw slack is undefined for an edge internal to a top-level blossom");
    BigInt slack = raw_slack(edge);
    require(slack >= 0, "blossom_negative_exact_slack",
            "an edge between distinct top-level blossoms has negative exact slack",
            {"representative edge index: " + std::to_string(edge)});
    return slack;
  }

  [[nodiscard]] bool edge_better(const EdgeIndex candidate,
                                 const EdgeIndex incumbent) const {
    const BigInt candidate_slack = checked_external_slack(candidate);
    const BigInt incumbent_slack = checked_external_slack(incumbent);
    return candidate_slack < incumbent_slack ||
           (candidate_slack == incumbent_slack && candidate < incumbent);
  }

  void enqueue_blossom_leaves(const BlossomIndex blossom) {
    require(is_active(blossom), "blossom_queue_node_inactive",
            "an inactive blossom was added to the scan queue");
    // Leaves are stored in ascending dense-vertex order.
    for (const Vertex leaf : nodes_[blossom].leaves) {
      scan_queue_.push_back(leaf);
    }
  }

  [[nodiscard]] BlossomIndex allocate_blossom() {
    for (BlossomIndex id = vertex_count_; id < nodes_.size(); ++id) {
      if (!nodes_[id].active) {
        BlossomNode& node = nodes_[id];
        node = BlossomNode{};
        node.active = true;
        node.nontrivial = true;
        return id;
      }
    }
    fail("blossom_arena_exhausted",
         "the exact Blossom arena exhausted its structurally sufficient slots");
    return 0U;  // fail() always throws; keeps the helper sanitizer-neutral.
  }

  [[nodiscard]] std::size_t child_position(
      const BlossomIndex blossom, const BlossomIndex child) const {
    require(is_nontrivial(blossom), "blossom_child_search_invalid",
            "a child was requested from a trivial or inactive blossom");
    const auto& children = nodes_[blossom].children;
    const auto found = std::ranges::find(children, child);
    require(found != children.end(), "blossom_child_missing",
            "the nested blossom hierarchy does not contain an expected child");
    return static_cast<std::size_t>(found - children.begin());
  }

  [[nodiscard]] static std::size_t cyclic_advance(
      const std::size_t position, const std::size_t count,
      const bool forward) {
    require(count != 0U && position < count,
            "blossom_cycle_position_invalid",
            "an invalid position was used in a blossom cycle");
    if (forward) {
      return position + 1U == count ? 0U : position + 1U;
    }
    return position == 0U ? count - 1U : position - 1U;
  }

  void assign_label(const Vertex inside, const Label label,
                    const std::optional<DirectedEdge>& through) {
    require(inside < vertex_count_, "blossom_label_vertex_out_of_range",
            "a label operation received an out-of-range vertex");
    require(label == Label::outer || label == Label::inner,
            "blossom_label_kind_invalid",
            "a search-tree label is outside the S/T domain");
    const BlossomIndex blossom = in_blossom_[inside];
    require(is_active(blossom), "blossom_label_top_inactive",
            "a vertex belongs to an inactive top-level blossom");
    require(nodes_[inside].label == Label::none &&
                nodes_[blossom].label == Label::none,
            "blossom_label_reassignment",
            "an alternating-tree node was labeled more than once");
    if (through.has_value()) {
      require(through->second == inside,
              "blossom_label_edge_orientation_invalid",
              "a label edge is not oriented into the labeled vertex");
    }

    nodes_[inside].label = label;
    nodes_[blossom].label = label;
    nodes_[inside].label_edge = through;
    nodes_[blossom].label_edge = through;
    nodes_[inside].best_edge.reset();
    nodes_[blossom].best_edge.reset();

    if (label == Label::outer) {
      enqueue_blossom_leaves(blossom);
      return;
    }

    const Vertex base = nodes_[blossom].base;
    require(base < vertex_count_ && mate_[base].has_value(),
            "blossom_inner_base_unmatched",
            "a T-blossom base has no matched edge into the alternating tree");
    const Vertex matched = *mate_[base];
    const auto matched_edge = edge_by_pair_.find(endpoint_key(base, matched));
    require(matched_edge != edge_by_pair_.end(),
            "blossom_mate_edge_missing",
            "a T-blossom base mate is not a representative edge");
    assign_label(matched, Label::outer,
                 DirectedEdge{base, matched, matched_edge->second});
  }

  [[nodiscard]] std::optional<Vertex> scan_blossom(Vertex first,
                                                    Vertex second) {
    std::optional<Vertex> v{first};
    std::optional<Vertex> w{second};
    std::vector<BlossomIndex> breadcrumbs;
    std::optional<Vertex> base;

    while (v.has_value()) {
      const BlossomIndex blossom = in_blossom_[*v];
      require(is_active(blossom), "blossom_scan_top_inactive",
              "blossom scanning reached an inactive top-level node");
      if (nodes_[blossom].label == Label::breadcrumb) {
        base = nodes_[blossom].base;
        break;
      }
      require(nodes_[blossom].label == Label::outer,
              "blossom_scan_non_outer",
              "blossom scanning left the outer alternating forest");
      breadcrumbs.push_back(blossom);
      nodes_[blossom].label = Label::breadcrumb;

      if (!nodes_[blossom].label_edge.has_value()) {
        require(!mate_[nodes_[blossom].base].has_value(),
                "blossom_root_base_matched",
                "an alternating-tree root unexpectedly has a matched base");
        v.reset();
      } else {
        const DirectedEdge tree_edge = *nodes_[blossom].label_edge;
        require(mate_[nodes_[blossom].base].has_value() &&
                    tree_edge.first == *mate_[nodes_[blossom].base],
                "blossom_outer_tree_edge_mismatch",
                "an outer blossom tree edge disagrees with its base mate");
        v = tree_edge.first;
        const BlossomIndex inner = in_blossom_[*v];
        require(nodes_[inner].label == Label::inner &&
                    nodes_[inner].label_edge.has_value(),
                "blossom_scan_inner_link_missing",
                "the alternating-tree inner predecessor is missing");
        v = nodes_[inner].label_edge->first;
      }
      if (w.has_value()) {
        std::swap(v, w);
      }
    }

    for (const BlossomIndex blossom : breadcrumbs) {
      require(nodes_[blossom].label == Label::breadcrumb,
              "blossom_breadcrumb_corrupt",
              "a Blossom breadcrumb changed during ancestor scanning");
      nodes_[blossom].label = Label::outer;
    }
    return base;
  }

  [[nodiscard]] bool leaf_in(const BlossomIndex blossom,
                             const Vertex vertex) const {
    require(is_active(blossom), "blossom_membership_node_inactive",
            "membership was requested from an inactive blossom");
    const auto& leaves = nodes_[blossom].leaves;
    return std::binary_search(leaves.begin(), leaves.end(), vertex);
  }

  void validate_new_cycle(const BlossomIndex blossom) const {
    const BlossomNode& node = nodes_[blossom];
    require(node.children.size() >= 3U &&
                (node.children.size() % 2U) == 1U &&
                node.cycle_edges.size() == node.children.size(),
            "blossom_cycle_shape_invalid",
            "a contracted blossom is not an odd cycle of at least three children");
    for (std::size_t position = 0U; position < node.children.size();
         ++position) {
      const std::size_t next =
          position + 1U == node.children.size() ? 0U : position + 1U;
      const DirectedEdge& edge = node.cycle_edges[position];
      require(edge.edge < edge_count_ &&
                  leaf_in(node.children[position], edge.first) &&
                  leaf_in(node.children[next], edge.second),
              "blossom_cycle_edge_invalid",
              "a blossom cycle edge does not connect consecutive children");
      const RepresentativeEdge& record = edges_[edge.edge];
      require(endpoint_key(edge.first, edge.second) ==
                  endpoint_key(record.first, record.second),
              "blossom_cycle_edge_reconstruction_mismatch",
              "a blossom cycle edge does not reconstruct its representative edge");
    }
  }

  void add_blossom(const Vertex base, Vertex first, Vertex second,
                   const EdgeIndex joining_edge) {
    const BlossomIndex base_blossom = in_blossom_[base];
    BlossomIndex first_blossom = in_blossom_[first];
    BlossomIndex second_blossom = in_blossom_[second];
    const BlossomIndex blossom = allocate_blossom();
    BlossomNode& node = nodes_[blossom];
    node.base = base;
    node.parent.reset();
    nodes_[base_blossom].parent = blossom;

    std::vector<BlossomIndex> path;
    std::vector<DirectedEdge> cycle_edges{
        DirectedEdge{first, second, joining_edge}};

    while (first_blossom != base_blossom) {
      nodes_[first_blossom].parent = blossom;
      path.push_back(first_blossom);
      require(nodes_[first_blossom].label_edge.has_value(),
              "blossom_first_stem_edge_missing",
              "the first contraction stem has no alternating-tree edge");
      const DirectedEdge edge = *nodes_[first_blossom].label_edge;
      cycle_edges.push_back(edge);
      require(nodes_[first_blossom].label == Label::inner ||
                  (nodes_[first_blossom].label == Label::outer &&
                   mate_[nodes_[first_blossom].base].has_value() &&
                   edge.first == *mate_[nodes_[first_blossom].base]),
              "blossom_first_stem_label_invalid",
              "the first contraction stem is not alternating");
      first = edge.first;
      first_blossom = in_blossom_[first];
    }
    path.push_back(base_blossom);
    std::ranges::reverse(path);
    std::ranges::reverse(cycle_edges);

    while (second_blossom != base_blossom) {
      nodes_[second_blossom].parent = blossom;
      path.push_back(second_blossom);
      require(nodes_[second_blossom].label_edge.has_value(),
              "blossom_second_stem_edge_missing",
              "the second contraction stem has no alternating-tree edge");
      const DirectedEdge edge = *nodes_[second_blossom].label_edge;
      cycle_edges.push_back(reverse_edge(edge));
      require(nodes_[second_blossom].label == Label::inner ||
                  (nodes_[second_blossom].label == Label::outer &&
                   mate_[nodes_[second_blossom].base].has_value() &&
                   edge.first == *mate_[nodes_[second_blossom].base]),
              "blossom_second_stem_label_invalid",
              "the second contraction stem is not alternating");
      second = edge.first;
      second_blossom = in_blossom_[second];
    }

    node.children = std::move(path);
    node.cycle_edges = std::move(cycle_edges);
    node.leaves.clear();
    for (const BlossomIndex child : node.children) {
      require(is_active(child), "blossom_contraction_child_inactive",
              "a contraction attempted to absorb an inactive child");
      node.leaves.insert(node.leaves.end(), nodes_[child].leaves.begin(),
                         nodes_[child].leaves.end());
    }
    std::ranges::sort(node.leaves);
    require(std::adjacent_find(node.leaves.begin(), node.leaves.end()) ==
                node.leaves.end(),
            "blossom_contraction_leaf_duplicate",
            "a contracted blossom contains a vertex more than once");
    require(std::binary_search(node.leaves.begin(), node.leaves.end(), base),
            "blossom_contraction_base_missing",
            "a contracted blossom does not contain its base vertex");

    require(nodes_[base_blossom].label == Label::outer,
            "blossom_contraction_base_not_outer",
            "the base child of a new blossom is not outer");
    node.label = Label::outer;
    node.label_edge = nodes_[base_blossom].label_edge;
    node.dual = 0;
    validate_new_cycle(blossom);

    for (const Vertex vertex : node.leaves) {
      if (nodes_[in_blossom_[vertex]].label == Label::inner) {
        scan_queue_.push_back(vertex);
      }
      in_blossom_[vertex] = blossom;
    }

    std::map<BlossomIndex, EdgeIndex> best_to;
    for (const BlossomIndex child : node.children) {
      std::vector<EdgeIndex> candidates;
      if (is_nontrivial(child) &&
          nodes_[child].best_edge_set.has_value()) {
        candidates = std::move(*nodes_[child].best_edge_set);
        nodes_[child].best_edge_set.reset();
      } else {
        for (const Vertex vertex : nodes_[child].leaves) {
          candidates.insert(candidates.end(), adjacency_[vertex].begin(),
                            adjacency_[vertex].end());
        }
      }
      for (const EdgeIndex edge : candidates) {
        const RepresentativeEdge& record = edges_[edge];
        Vertex inside = record.first;
        Vertex outside = record.second;
        if (in_blossom_[outside] == blossom) {
          std::swap(inside, outside);
        }
        if (in_blossom_[inside] != blossom ||
            in_blossom_[outside] == blossom) {
          continue;
        }
        const BlossomIndex neighbor = in_blossom_[outside];
        if (nodes_[neighbor].label != Label::outer) {
          continue;
        }
        const auto found = best_to.find(neighbor);
        if (found == best_to.end() || edge_better(edge, found->second)) {
          best_to[neighbor] = edge;
        }
      }
      nodes_[child].best_edge.reset();
    }

    std::vector<EdgeIndex> best_set;
    best_set.reserve(best_to.size());
    for (const auto& [neighbor, edge] : best_to) {
      (void)neighbor;
      best_set.push_back(edge);
    }
    node.best_edge_set = std::move(best_set);
    node.best_edge.reset();
    for (const EdgeIndex edge : *node.best_edge_set) {
      if (!node.best_edge.has_value() ||
          edge_better(edge, *node.best_edge)) {
        node.best_edge = edge;
      }
    }
  }

  void deactivate_blossom(const BlossomIndex blossom) {
    require(blossom >= vertex_count_ && is_nontrivial(blossom),
            "blossom_deactivation_invalid",
            "only an active nontrivial blossom may be deactivated");
    nodes_[blossom] = BlossomNode{};
  }

  // Expand a top-level blossom. During a stage a T-blossom must be split
  // while preserving every alternating-tree reachability label. At the end
  // of a stage no labels need to survive, but zero-dual nested blossoms are
  // recursively removed as required by the primal-dual representation.
  void expand_blossom(const BlossomIndex blossom, const bool end_stage) {
    require(is_nontrivial(blossom) &&
                !nodes_[blossom].parent.has_value(),
            "blossom_expansion_target_invalid",
            "only a top-level nontrivial blossom may be expanded");

    if (end_stage) {
      // The Python reference uses a trampoline here. Keep the same bounded
      // process-stack behavior: every recursive expansion request is an
      // explicit heap-backed work item, so allocation failure remains inside
      // the typed Result boundary even for deeply nested odd sets.
      std::vector<BlossomIndex> pending{blossom};
      while (!pending.empty()) {
        const BlossomIndex current = pending.back();
        pending.pop_back();
        require(is_nontrivial(current) &&
                    !nodes_[current].parent.has_value(),
                "blossom_end_stage_expansion_invalid",
                "an end-stage expansion work item is not top-level");
        const std::vector<BlossomIndex> current_children =
            nodes_[current].children;
        for (auto iterator = current_children.rbegin();
             iterator != current_children.rend(); ++iterator) {
          const BlossomIndex child = *iterator;
          require(is_active(child) && nodes_[child].parent == current,
                  "blossom_expansion_child_invalid",
                  "an expanding blossom has an invalid immediate child");
          nodes_[child].parent.reset();
          if (is_nontrivial(child) && nodes_[child].dual == 0) {
            pending.push_back(child);
          } else {
            for (const Vertex leaf : nodes_[child].leaves) {
              in_blossom_[leaf] = child;
            }
          }
        }
        deactivate_blossom(current);
      }
      return;
    }

    // In-stage expansion never recursively removes a child. Keep structural
    // copies while relabeling around this exact odd cycle.
    const std::vector<BlossomIndex> children = nodes_[blossom].children;
    const std::vector<DirectedEdge> cycle_edges =
        nodes_[blossom].cycle_edges;
    const Label old_label = nodes_[blossom].label;
    const std::optional<DirectedEdge> old_label_edge =
        nodes_[blossom].label_edge;

    for (const BlossomIndex child : children) {
      require(is_active(child) && nodes_[child].parent == blossom,
              "blossom_expansion_child_invalid",
              "an expanding blossom has an invalid immediate child");
      nodes_[child].parent.reset();
      for (const Vertex leaf : nodes_[child].leaves) {
        in_blossom_[leaf] = child;
      }
    }

    if (old_label == Label::inner) {
      require(old_label_edge.has_value(),
              "blossom_expansion_label_edge_missing",
              "an in-stage T-blossom expansion has no entering tree edge");
      const BlossomIndex entry_child =
          in_blossom_[old_label_edge->second];
      const auto entry_found = std::ranges::find(children, entry_child);
      require(entry_found != children.end(),
              "blossom_expansion_entry_child_missing",
              "the entering tree edge does not terminate in an immediate child");

      std::size_t position =
          static_cast<std::size_t>(entry_found - children.begin());
      const bool forward = (position % 2U) == 1U;
      DirectedEdge tree_edge = *old_label_edge;

      while (position != 0U) {
        const std::size_t previous = cyclic_advance(
            position, children.size(), false);
        const DirectedEdge step_edge =
            forward ? cycle_edges[position]
                    : reverse_edge(cycle_edges[previous]);

        // The current T child is reached through tree_edge; the endpoint in
        // the next S child must be cleared before assign_label inspects it.
        nodes_[tree_edge.second].label = Label::none;
        nodes_[step_edge.second].label = Label::none;
        assign_label(tree_edge.second, Label::inner, tree_edge);
        allowable_[step_edge.edge] = std::uint8_t{1U};

        position = cyclic_advance(position, children.size(), forward);
        const std::size_t tree_previous = cyclic_advance(
            position, children.size(), false);
        tree_edge = forward ? cycle_edges[position]
                            : reverse_edge(cycle_edges[tree_previous]);
        allowable_[tree_edge.edge] = std::uint8_t{1U};
        position = cyclic_advance(position, children.size(), forward);
      }

      // Label the base T child without automatically stepping through its
      // mate: the continuation around the old odd cycle is reconstructed
      // explicitly below.
      const BlossomIndex base_child = children[0U];
      // A valid delta-4 expansion may leave a stale label on this child.
      // NetworkX/Galil intentionally overwrites it here; requiring `none`
      // would reject the S-blossom-relabel/expand case.
      nodes_[tree_edge.second].label = Label::inner;
      nodes_[tree_edge.second].label_edge = tree_edge;
      nodes_[tree_edge.second].best_edge.reset();
      nodes_[base_child].label = Label::inner;
      nodes_[base_child].label_edge = tree_edge;
      nodes_[base_child].best_edge.reset();

      position = cyclic_advance(position, children.size(), forward);
      while (children[position] != entry_child) {
        const BlossomIndex child = children[position];
        if (nodes_[child].label == Label::outer) {
          position = cyclic_advance(position, children.size(), forward);
          continue;
        }

        std::optional<Vertex> reached;
        for (const Vertex leaf : nodes_[child].leaves) {
          if (nodes_[leaf].label != Label::none) {
            reached = leaf;
            break;
          }
        }
        if (reached.has_value()) {
          require(nodes_[*reached].label == Label::inner &&
                      in_blossom_[*reached] == child &&
                      nodes_[*reached].label_edge.has_value(),
                  "blossom_expansion_reached_vertex_invalid",
                  "a reachable vertex in an expanding T-blossom has invalid bookkeeping");
          const DirectedEdge reaching_edge =
              *nodes_[*reached].label_edge;
          const Vertex child_base = nodes_[child].base;
          require(mate_[child_base].has_value(),
                  "blossom_expansion_child_base_unmatched",
                  "a reached T child has no base mate");
          const Vertex matched_base = *mate_[child_base];
          nodes_[*reached].label = Label::none;
          nodes_[*reached].label_edge.reset();
          nodes_[matched_base].label = Label::none;
          nodes_[matched_base].label_edge.reset();
          assign_label(*reached, Label::inner, reaching_edge);
        }
        position = cyclic_advance(position, children.size(), forward);
      }
    }

    deactivate_blossom(blossom);
  }

  // Flip the alternating path inside `blossom` from `vertex` to its base,
  // then rotate the child cycle so that `vertex` becomes the new base.
  void augment_blossom(const BlossomIndex blossom, const Vertex vertex) {
    enum class TaskKind : std::uint8_t {
      enter,
      set_match,
      rotate,
    };
    struct Task final {
      TaskKind kind;
      BlossomIndex blossom;
      Vertex first;
      Vertex second;
      std::size_t rotation;
    };
    struct CycleStep final {
      BlossomIndex first_child;
      BlossomIndex second_child;
      DirectedEdge edge;
    };

    // This is the C++ analogue of the pinned NetworkX trampoline. Tasks are
    // pushed in reverse execution order, keeping arbitrarily deep blossom
    // nesting off the native call stack.
    std::vector<Task> tasks{
        Task{TaskKind::enter, blossom, vertex, 0U, 0U}};
    while (!tasks.empty()) {
      const Task task = tasks.back();
      tasks.pop_back();

      if (task.kind == TaskKind::set_match) {
        require(edge_by_pair_.contains(endpoint_key(task.first, task.second)),
                "blossom_internal_match_edge_missing",
                "internal augmentation selected a nonrepresentative edge");
        mate_[task.first] = task.second;
        mate_[task.second] = task.first;
        continue;
      }

      if (task.kind == TaskKind::rotate) {
        require(is_nontrivial(task.blossom),
                "blossom_rotation_target_invalid",
                "an internal augmentation rotation targets an inactive blossom");
        BlossomNode& node = nodes_[task.blossom];
        require(task.rotation < node.children.size(),
                "blossom_rotation_position_invalid",
                "an internal augmentation rotation is out of range");
        std::rotate(node.children.begin(),
                    node.children.begin() +
                        static_cast<std::ptrdiff_t>(task.rotation),
                    node.children.end());
        std::rotate(node.cycle_edges.begin(),
                    node.cycle_edges.begin() +
                        static_cast<std::ptrdiff_t>(task.rotation),
                    node.cycle_edges.end());
        node.base = nodes_[node.children.front()].base;
        require(node.base == task.first,
                "blossom_augmented_base_mismatch",
                "internal augmentation did not rotate the requested vertex to the base");
        validate_new_cycle(task.blossom);
        continue;
      }

      require(task.kind == TaskKind::enter &&
                  is_nontrivial(task.blossom) &&
                  leaf_in(task.blossom, task.first),
              "blossom_internal_augmentation_invalid",
              "internal augmentation does not start in the requested blossom");
      BlossomIndex child = task.first;
      std::size_t ascent_steps = 0U;
      while (nodes_[child].parent != task.blossom) {
        require(nodes_[child].parent.has_value() &&
                    ++ascent_steps <= nodes_.size(),
                "blossom_parent_chain_corrupt",
                "internal augmentation could not reach an immediate child");
        child = *nodes_[child].parent;
      }

      const BlossomNode& node = nodes_[task.blossom];
      const std::size_t initial = child_position(task.blossom, child);
      std::size_t position = initial;
      const bool forward = (initial % 2U) == 1U;
      std::vector<CycleStep> steps;
      while (position != 0U) {
        position = cyclic_advance(position, node.children.size(), forward);
        const BlossomIndex first_child = node.children[position];
        const std::size_t previous = cyclic_advance(
            position, node.children.size(), false);
        const DirectedEdge cycle_edge =
            forward ? node.cycle_edges[position]
                    : reverse_edge(node.cycle_edges[previous]);
        position = cyclic_advance(position, node.children.size(), forward);
        const BlossomIndex second_child = node.children[position];
        steps.push_back(CycleStep{first_child, second_child, cycle_edge});
      }

      tasks.push_back(Task{TaskKind::rotate, task.blossom, task.first, 0U,
                           initial});
      for (auto iterator = steps.rbegin(); iterator != steps.rend();
           ++iterator) {
        tasks.push_back(Task{TaskKind::set_match, 0U,
                             iterator->edge.first,
                             iterator->edge.second, 0U});
        if (is_nontrivial(iterator->second_child)) {
          tasks.push_back(Task{TaskKind::enter, iterator->second_child,
                               iterator->edge.second, 0U, 0U});
        }
        if (is_nontrivial(iterator->first_child)) {
          tasks.push_back(Task{TaskKind::enter, iterator->first_child,
                               iterator->edge.first, 0U, 0U});
        }
      }
      if (is_nontrivial(child)) {
        tasks.push_back(
            Task{TaskKind::enter, child, task.first, 0U, 0U});
      }
    }
  }

  void augment_matching(const Vertex first, const Vertex second) {
    const std::pair<Vertex, Vertex> starts[2]{{first, second},
                                              {second, first}};
    for (const auto& [start, opposite] : starts) {
      Vertex current = start;
      Vertex new_mate = opposite;
      while (true) {
        const BlossomIndex outer = in_blossom_[current];
        require(nodes_[outer].label == Label::outer,
                "blossom_augmentation_outer_label_missing",
                "augmentation tracing left the outer alternating forest");
        const std::optional<DirectedEdge> stem = nodes_[outer].label_edge;
        require((!stem.has_value() &&
                 !mate_[nodes_[outer].base].has_value()) ||
                    (stem.has_value() &&
                     mate_[nodes_[outer].base].has_value() &&
                     stem->first == *mate_[nodes_[outer].base]),
                "blossom_augmentation_outer_stem_invalid",
                "an outer blossom has an inconsistent tree stem");
        if (is_nontrivial(outer)) {
          augment_blossom(outer, current);
        }
        require(edge_by_pair_.contains(endpoint_key(current, new_mate)),
                "blossom_augmentation_edge_missing",
                "augmentation attempted to match a nonrepresentative edge");
        mate_[current] = new_mate;

        if (!stem.has_value()) {
          break;
        }
        const Vertex inner_base = stem->first;
        const BlossomIndex inner = in_blossom_[inner_base];
        require(nodes_[inner].label == Label::inner &&
                    nodes_[inner].label_edge.has_value() &&
                    nodes_[inner].base == inner_base,
                "blossom_augmentation_inner_stem_invalid",
                "augmentation tracing found an invalid inner blossom");
        const DirectedEdge predecessor = *nodes_[inner].label_edge;
        current = predecessor.first;
        new_mate = predecessor.second;
        if (is_nontrivial(inner)) {
          augment_blossom(inner, new_mate);
        }
        require(edge_by_pair_.contains(endpoint_key(current, new_mate)),
                "blossom_augmentation_predecessor_edge_missing",
                "the alternating-tree predecessor is not a representative edge");
        mate_[new_mate] = current;
      }
    }
    verify_mate_symmetry();
  }

  void verify_mate_symmetry() const {
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      if (!mate_[vertex].has_value()) {
        continue;
      }
      const Vertex matched = *mate_[vertex];
      require(matched < vertex_count_ && mate_[matched] == vertex,
              "blossom_matching_asymmetric",
              "the current primal matching is not symmetric",
              {"vertex: " + std::to_string(vertex)});
      require(edge_by_pair_.contains(endpoint_key(vertex, matched)),
              "blossom_matching_edge_missing",
              "the current primal matching uses a nonrepresentative edge");
    }
  }

  void reset_stage() {
    for (BlossomIndex blossom = 0U; blossom < nodes_.size(); ++blossom) {
      if (!is_active(blossom)) {
        continue;
      }
      BlossomNode& node = nodes_[blossom];
      node.label = Label::none;
      node.label_edge.reset();
      node.best_edge.reset();
      if (node.nontrivial) {
        node.best_edge_set.reset();
      }
    }
    std::ranges::fill(allowable_, std::uint8_t{0U});
    scan_queue_.clear();

    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      if (!mate_[vertex].has_value() &&
          nodes_[in_blossom_[vertex]].label == Label::none) {
        assign_label(vertex, Label::outer, std::nullopt);
      }
    }
  }

  void remember_best_edge(std::optional<EdgeIndex>& slot,
                          const EdgeIndex candidate) {
    if (!slot.has_value() || edge_better(candidate, *slot)) {
      slot = candidate;
    }
  }

  [[nodiscard]] DirectedEdge orient_from_outer(const EdgeIndex edge) const {
    require(edge < edge_count_, "blossom_delta_edge_out_of_range",
            "a dual update selected an out-of-range edge");
    const RepresentativeEdge& record = edges_[edge];
    const bool first_outer =
        nodes_[in_blossom_[record.first]].label == Label::outer;
    const bool second_outer =
        nodes_[in_blossom_[record.second]].label == Label::outer;
    require(first_outer || second_outer,
            "blossom_delta_edge_has_no_outer_endpoint",
            "a dual update edge is not incident to the outer forest");
    if (first_outer) {
      return DirectedEdge{record.first, record.second, edge};
    }
    return DirectedEdge{record.second, record.first, edge};
  }

  enum class DeltaKind : std::uint8_t {
    vertex_dual = 1U,
    outer_to_free = 2U,
    outer_to_outer = 3U,
    inner_blossom = 4U,
  };

  struct DeltaChoice final {
    DeltaKind kind;
    BigInt value;
    std::optional<EdgeIndex> edge;
    std::optional<BlossomIndex> blossom;
  };

  [[nodiscard]] DeltaChoice choose_delta() const {
    require(vertex_count_ != 0U, "blossom_delta_empty_graph",
            "a dual update was requested for an empty graph");
    const auto minimum_dual =
        std::ranges::min_element(vertex_dual_);
    require(minimum_dual != vertex_dual_.end() && *minimum_dual >= 0,
            "blossom_vertex_dual_negative",
            "the exact Blossom vertex dual became negative");
    DeltaChoice choice{DeltaKind::vertex_dual, *minimum_dual,
                       std::nullopt, std::nullopt};

    // Delta-2 candidates are cached per unreached vertex.
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      if (nodes_[in_blossom_[vertex]].label != Label::none ||
          !nodes_[vertex].best_edge.has_value()) {
        continue;
      }
      const BigInt candidate =
          checked_external_slack(*nodes_[vertex].best_edge);
      if (candidate < choice.value) {
        choice = DeltaChoice{DeltaKind::outer_to_free, candidate,
                             nodes_[vertex].best_edge, std::nullopt};
      }
    }

    // Delta-3 is half of an S-to-S slack. Integral weights and the doubled
    // dual formulation make every such minimum exactly even.
    for (BlossomIndex blossom = 0U; blossom < nodes_.size(); ++blossom) {
      if (!is_active(blossom) || nodes_[blossom].parent.has_value() ||
          nodes_[blossom].label != Label::outer ||
          !nodes_[blossom].best_edge.has_value()) {
        continue;
      }
      const BigInt slack =
          checked_external_slack(*nodes_[blossom].best_edge);
      require((slack % 2) == 0,
              "blossom_outer_slack_parity_invalid",
              "an S-to-S exact slack is not even in the doubled formulation");
      const BigInt candidate = slack / 2;
      if (candidate < choice.value) {
        choice = DeltaChoice{DeltaKind::outer_to_outer, candidate,
                             nodes_[blossom].best_edge, std::nullopt};
      }
    }

    // Delta-4 expands the first canonical top-level T-blossom attaining a
    // strictly smaller value. Earlier delta kinds intentionally win ties.
    for (BlossomIndex blossom = vertex_count_; blossom < nodes_.size();
         ++blossom) {
      if (!is_nontrivial(blossom) ||
          nodes_[blossom].parent.has_value() ||
          nodes_[blossom].label != Label::inner) {
        continue;
      }
      require(nodes_[blossom].dual >= 0,
              "blossom_odd_set_dual_negative",
              "a Blossom odd-set dual became negative");
      if (nodes_[blossom].dual < choice.value) {
        choice = DeltaChoice{DeltaKind::inner_blossom,
                             nodes_[blossom].dual, std::nullopt, blossom};
      }
    }
    return choice;
  }

  void apply_delta(const DeltaChoice& choice) {
    require(choice.value >= 0, "blossom_delta_negative",
            "the exact primal-dual update selected a negative delta");
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      const Label label = nodes_[in_blossom_[vertex]].label;
      if (label == Label::outer) {
        vertex_dual_[vertex] -= choice.value;
      } else if (label == Label::inner) {
        vertex_dual_[vertex] += choice.value;
      }
      require(vertex_dual_[vertex] >= 0,
              "blossom_vertex_dual_underflow",
              "a dual update made a vertex dual negative");
    }
    for (BlossomIndex blossom = vertex_count_; blossom < nodes_.size();
         ++blossom) {
      if (!is_nontrivial(blossom) ||
          nodes_[blossom].parent.has_value()) {
        continue;
      }
      if (nodes_[blossom].label == Label::outer) {
        nodes_[blossom].dual += choice.value;
      } else if (nodes_[blossom].label == Label::inner) {
        nodes_[blossom].dual -= choice.value;
      }
      require(nodes_[blossom].dual >= 0,
              "blossom_odd_set_dual_underflow",
              "a dual update made an odd-set dual negative");
    }
  }

  [[nodiscard]] bool run_stage() {
    reset_stage();
    bool augmented = false;

    while (true) {
      while (!scan_queue_.empty() && !augmented) {
        const Vertex vertex = scan_queue_.front();
        scan_queue_.pop_front();
        require(nodes_[in_blossom_[vertex]].label == Label::outer,
                "blossom_scan_queue_label_invalid",
                "the scan queue contains a vertex outside the outer forest");

        for (const EdgeIndex edge : adjacency_[vertex]) {
          const Vertex neighbor = other_endpoint(edge, vertex);
          const BlossomIndex vertex_blossom = in_blossom_[vertex];
          const BlossomIndex neighbor_blossom = in_blossom_[neighbor];
          if (vertex_blossom == neighbor_blossom) {
            continue;
          }

          std::optional<BigInt> slack;
          if (allowable_[edge] == 0U) {
            slack = checked_external_slack(edge);
            if (*slack == 0) {
              allowable_[edge] = std::uint8_t{1U};
            }
          }

          if (allowable_[edge] != 0U) {
            if (nodes_[neighbor_blossom].label == Label::none) {
              assign_label(neighbor, Label::inner,
                           DirectedEdge{vertex, neighbor, edge});
            } else if (nodes_[neighbor_blossom].label == Label::outer) {
              const std::optional<Vertex> base =
                  scan_blossom(vertex, neighbor);
              if (base.has_value()) {
                add_blossom(*base, vertex, neighbor, edge);
              } else {
                augment_matching(vertex, neighbor);
                augmented = true;
                break;
              }
            } else if (nodes_[neighbor].label == Label::none) {
              require(nodes_[neighbor_blossom].label == Label::inner,
                      "blossom_reached_inner_label_invalid",
                      "a reachable inner-blossom vertex has an invalid top-level label");
              nodes_[neighbor].label = Label::inner;
              nodes_[neighbor].label_edge =
                  DirectedEdge{vertex, neighbor, edge};
            }
          } else if (nodes_[neighbor_blossom].label == Label::outer) {
            require(slack.has_value(),
                    "blossom_nonallowable_slack_missing",
                    "a nonallowable S-to-S edge has no exact slack");
            remember_best_edge(nodes_[vertex_blossom].best_edge, edge);
          } else if (nodes_[neighbor].label == Label::none) {
            require(slack.has_value(),
                    "blossom_nonallowable_slack_missing",
                    "a nonallowable S-to-free edge has no exact slack");
            remember_best_edge(nodes_[neighbor].best_edge, edge);
          }
        }
      }

      if (augmented) {
        break;
      }

      const DeltaChoice choice = choose_delta();
      apply_delta(choice);
      if (choice.kind == DeltaKind::vertex_dual) {
        verify_mate_symmetry();
        return false;
      }
      if (choice.kind == DeltaKind::outer_to_free ||
          choice.kind == DeltaKind::outer_to_outer) {
        require(choice.edge.has_value(), "blossom_delta_edge_missing",
                "an edge-triggered dual update has no selected edge");
        const DirectedEdge oriented = orient_from_outer(*choice.edge);
        allowable_[*choice.edge] = std::uint8_t{1U};
        scan_queue_.push_back(oriented.first);
      } else {
        require(choice.kind == DeltaKind::inner_blossom &&
                    choice.blossom.has_value(),
                "blossom_delta_blossom_missing",
                "a blossom-triggered dual update has no selected blossom");
        expand_blossom(*choice.blossom, false);
      }
    }

    verify_mate_symmetry();
    // End-stage expansion uses a snapshot-like ascending scan; recursive
    // expansion may deactivate descendants before their slot is reached.
    for (BlossomIndex blossom = vertex_count_; blossom < nodes_.size();
         ++blossom) {
      if (is_nontrivial(blossom) &&
          !nodes_[blossom].parent.has_value() &&
          nodes_[blossom].label == Label::outer &&
          nodes_[blossom].dual == 0) {
        expand_blossom(blossom, true);
      }
    }
    return true;
  }

  [[nodiscard]] MatchingPayload extract_matching() const {
    verify_mate_symmetry();
    std::vector<EdgeIndex> selected;
    BigNat objective(std::uint64_t{0U});
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      if (!mate_[vertex].has_value() || vertex > *mate_[vertex]) {
        continue;
      }
      const auto edge = edge_by_pair_.find(
          endpoint_key(vertex, *mate_[vertex]));
      require(edge != edge_by_pair_.end(),
              "blossom_matching_edge_missing",
              "the final matching contains a nonrepresentative edge");
      selected.push_back(edge->second);
      objective += edges_[edge->second].weight;
    }
    std::ranges::sort(selected);
    require(std::adjacent_find(selected.begin(), selected.end()) ==
                selected.end(),
            "blossom_selected_edge_duplicate",
            "the final matching contains a representative edge twice");
    return MatchingPayload{.selected_edges = std::move(selected),
                           .vertex_mates = mate_,
                           .objective = std::move(objective)};
  }

  [[nodiscard]] BigInt full_slack(const EdgeIndex edge) const {
    const RepresentativeEdge& record = edges_[edge];
    BigInt result = raw_slack(edge);
    for (BlossomIndex blossom = vertex_count_; blossom < nodes_.size();
         ++blossom) {
      if (is_nontrivial(blossom) && leaf_in(blossom, record.first) &&
          leaf_in(blossom, record.second)) {
        result += (nodes_[blossom].dual << 1U);
      }
    }
    return result;
  }

  void verify_hierarchy() const {
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      require(is_active(vertex) && !nodes_[vertex].nontrivial &&
                  nodes_[vertex].base == vertex &&
                  nodes_[vertex].leaves == std::vector<Vertex>{vertex},
              "blossom_trivial_node_corrupt",
              "a trivial Blossom node has corrupt immutable identity");
    }

    for (BlossomIndex blossom = vertex_count_; blossom < nodes_.size();
         ++blossom) {
      if (!is_nontrivial(blossom)) {
        continue;
      }
      const BlossomNode& node = nodes_[blossom];
      require(node.dual >= 0 && node.children.size() >= 3U &&
                  (node.children.size() % 2U) == 1U &&
                  node.cycle_edges.size() == node.children.size() &&
                  (node.leaves.size() % 2U) == 1U,
              "blossom_hierarchy_node_invalid",
              "an active nontrivial blossom violates odd-set invariants");
      std::vector<Vertex> child_leaves;
      for (const BlossomIndex child : node.children) {
        require(is_active(child) && nodes_[child].parent == blossom,
                "blossom_hierarchy_child_invalid",
                "a blossom child has an invalid parent relation");
        child_leaves.insert(child_leaves.end(), nodes_[child].leaves.begin(),
                            nodes_[child].leaves.end());
      }
      std::ranges::sort(child_leaves);
      require(child_leaves == node.leaves &&
                  std::adjacent_find(node.leaves.begin(), node.leaves.end()) ==
                      node.leaves.end() &&
                  std::binary_search(node.leaves.begin(), node.leaves.end(),
                                     node.base) &&
                  nodes_[node.children.front()].base == node.base,
              "blossom_hierarchy_leaf_partition_invalid",
              "a blossom does not equal the disjoint union of its children");
      validate_new_cycle(blossom);
    }

    for (BlossomIndex blossom = 0U; blossom < nodes_.size(); ++blossom) {
      if (!is_active(blossom)) {
        continue;
      }
      BlossomIndex cursor = blossom;
      std::size_t steps = 0U;
      while (nodes_[cursor].parent.has_value()) {
        require(++steps <= nodes_.size() &&
                    is_nontrivial(*nodes_[cursor].parent),
                "blossom_hierarchy_cycle",
                "the blossom parent relation is cyclic or inactive");
        cursor = *nodes_[cursor].parent;
      }
    }
    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      BlossomIndex root = vertex;
      while (nodes_[root].parent.has_value()) {
        root = *nodes_[root].parent;
      }
      require(in_blossom_[vertex] == root && leaf_in(root, vertex),
              "blossom_top_level_map_invalid",
              "a vertex does not map to its hierarchy root");
    }
  }

  void verify_certificate(const BigNat& objective) {
    verify_hierarchy();
    verify_mate_symmetry();
    for (const BigInt& dual : vertex_dual_) {
      require(dual >= 0, "blossom_certificate_vertex_dual_negative",
              "the final certificate has a negative vertex dual");
    }

    for (EdgeIndex edge = 0U; edge < edge_count_; ++edge) {
      const BigInt slack = full_slack(edge);
#if defined(MWPERF_C07_TEST_SEAMS)
      const BigInt unadjusted_slack = raw_slack(edge);
      if (unadjusted_slack < 0 && slack >= 0) {
        observed_negative_internal_raw_slack_ = true;
      }
#endif
      require(slack >= 0, "blossom_certificate_dual_infeasible",
              "the exact Blossom certificate has a negative edge slack",
              {"representative edge index: " + std::to_string(edge)});
      const RepresentativeEdge& record = edges_[edge];
      if (mate_[record.first] == record.second ||
          mate_[record.second] == record.first) {
        require(mate_[record.first] == record.second &&
                    mate_[record.second] == record.first && slack == 0,
                "blossom_certificate_matched_edge_not_tight",
                "a matched representative edge is not exactly tight",
                {"representative edge index: " + std::to_string(edge)});
      }
    }

    for (Vertex vertex = 0U; vertex < vertex_count_; ++vertex) {
      if (!mate_[vertex].has_value()) {
        require(vertex_dual_[vertex] == 0,
                "blossom_certificate_free_vertex_dual_nonzero",
                "an unmatched vertex has nonzero exact dual value",
                {"vertex: " + std::to_string(vertex)});
      }
    }

    BigInt doubled_dual_objective = 0;
    for (const BigInt& dual : vertex_dual_) {
      doubled_dual_objective += dual;
    }
    for (BlossomIndex blossom = vertex_count_; blossom < nodes_.size();
         ++blossom) {
      if (!is_nontrivial(blossom)) {
        continue;
      }
      const BlossomNode& node = nodes_[blossom];
      require(node.dual >= 0,
              "blossom_certificate_odd_set_dual_negative",
              "the final certificate has a negative odd-set dual");
      doubled_dual_objective +=
          BigInt(node.leaves.size() - 1U) * node.dual;
      if (node.dual == 0) {
        continue;
      }

      std::size_t internal_matching_edges = 0U;
      for (const Vertex vertex : node.leaves) {
        if (mate_[vertex].has_value() && vertex < *mate_[vertex] &&
            leaf_in(blossom, *mate_[vertex])) {
          ++internal_matching_edges;
        }
      }
      require(internal_matching_edges == (node.leaves.size() - 1U) / 2U,
              "blossom_certificate_positive_odd_set_not_full",
              "a positive-dual blossom is not full in the primal matching");
      for (std::size_t position = 1U;
           position < node.cycle_edges.size(); position += 2U) {
        const DirectedEdge& edge = node.cycle_edges[position];
        require(mate_[edge.first] == edge.second &&
                    mate_[edge.second] == edge.first,
                "blossom_certificate_cycle_edge_not_matched",
                "a positive-dual blossom lacks a required alternating-cycle match");
      }
    }

    BigInt doubled_primal_objective = objective.value();
    doubled_primal_objective <<= 1U;
    if (fault_ == BlossomTestFault::force_certificate_mismatch) {
      ++doubled_dual_objective;
    }
    require(doubled_dual_objective == doubled_primal_objective,
            "blossom_primal_dual_objective_mismatch",
            "the exact Blossom primal and dual objectives disagree",
            {"doubled primal: " + doubled_primal_objective.str(),
             "doubled dual: " + doubled_dual_objective.str()});
  }
};

[[nodiscard]] MatchingPayload solve_payload(
    const RepresentativeGraph& graph, const BlossomTestFault fault) {
  return ExactBlossomSolver(graph, fault).run();
}

#if defined(MWPERF_C07_TEST_SEAMS)
[[nodiscard]] bool solve_and_observe_negative_internal_raw_slack(
    const RepresentativeGraph& graph) {
  ExactBlossomSolver solver(graph, BlossomTestFault::none);
  (void)solver.run();
  return solver.observed_negative_internal_raw_slack();
}
#endif

[[nodiscard]] Diagnostic allocation_diagnostic() {
  return blossom_diagnostic(
      DiagnosticCategory::resource_limit,
      "blossom_solve_allocation_failure",
      "allocation failed during the cold exact Blossom solve");
}

[[nodiscard]] Diagnostic representation_diagnostic() {
  return blossom_diagnostic(
      DiagnosticCategory::resource_limit,
      "blossom_solve_representation_failure",
      "the cold exact Blossom workspace exceeds a host container limit");
}

}  // namespace

Result<RepresentativeMatching> solve_blossom_exact(
    const RepresentativeGraph& graph) {
  try {
    MatchingPayload payload = solve_payload(graph, BlossomTestFault::none);
    return Result<RepresentativeMatching>::success(RepresentativeMatching(
        std::move(payload.selected_edges), std::move(payload.vertex_mates),
        std::move(payload.objective)));
  } catch (BlossomFailure& failure) {
    return Result<RepresentativeMatching>::failure(
        std::move(failure.diagnostic));
  } catch (const std::bad_alloc&) {
    return Result<RepresentativeMatching>::failure(allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<RepresentativeMatching>::failure(
        representation_diagnostic());
  }
}

#if defined(MWPERF_C07_TEST_SEAMS)
Result<RepresentativeMatching> solve_blossom_exact_with_fault(
    const RepresentativeGraph& graph, const BlossomTestFault fault) {
  try {
    MatchingPayload payload = solve_payload(graph, fault);
    return Result<RepresentativeMatching>::success(RepresentativeMatching(
        std::move(payload.selected_edges), std::move(payload.vertex_mates),
        std::move(payload.objective)));
  } catch (BlossomFailure& failure) {
    return Result<RepresentativeMatching>::failure(
        std::move(failure.diagnostic));
  } catch (const std::bad_alloc&) {
    return Result<RepresentativeMatching>::failure(allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<RepresentativeMatching>::failure(
        representation_diagnostic());
  }
}

Result<bool> blossom_observed_negative_internal_raw_slack_for_test(
    const RepresentativeGraph& graph) {
  try {
    return Result<bool>::success(
        solve_and_observe_negative_internal_raw_slack(graph));
  } catch (BlossomFailure& failure) {
    return Result<bool>::failure(std::move(failure.diagnostic));
  } catch (const std::bad_alloc&) {
    return Result<bool>::failure(allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<bool>::failure(representation_diagnostic());
  }
}
#endif

Result<NodeExclusiveExactWitness> expand_representative_matching(
    const RepresentativeMatching& matching,
    const RepresentativeGraph& graph) {
  try {
    if (graph.dimension().family() !=
        ServiceFamily::node_exclusive_matching) {
      return Result<NodeExclusiveExactWitness>::failure(blossom_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_expansion_family_mismatch",
          "representative expansion received another service family"));
    }
    if (graph.queue_count() == 0U) {
      return Result<NodeExclusiveExactWitness>::failure(blossom_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_expansion_queue_dimension_empty",
          "representative expansion requires a nonempty queue dimension"));
    }
    if (matching.vertex_mates().size() != graph.vertex_count()) {
      return Result<NodeExclusiveExactWitness>::failure(blossom_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_expansion_mate_dimension_mismatch",
          "the representative matching mate array does not match the graph"));
    }

    std::vector<std::uint8_t> queue_seen(graph.queue_count(),
                                         std::uint8_t{0U});
    std::optional<std::pair<Vertex, Vertex>> previous_pair;
    for (EdgeIndex edge = 0U; edge < graph.edges().size(); ++edge) {
      const RepresentativeEdge& record = graph.edges()[edge];
      const std::pair<Vertex, Vertex> pair{record.first, record.second};
      if (record.first >= record.second ||
          record.second >= graph.vertex_count() ||
          (previous_pair.has_value() && !(previous_pair.value() < pair)) ||
          record.queue.ordinal() >= graph.queue_count() ||
          queue_seen[record.queue.ordinal()] != 0U) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_expansion_graph_corrupt",
                "the representative graph violates endpoint or queue-map invariants",
                {"representative edge index: " + std::to_string(edge)}));
      }
      previous_pair = pair;
      queue_seen[record.queue.ordinal()] = std::uint8_t{1U};
    }

    std::vector<std::optional<Vertex>> expected_mates(graph.vertex_count(),
                                                       std::nullopt);
    std::vector<std::uint8_t> selected_queues(graph.queue_count(),
                                              std::uint8_t{0U});
    BigNat recomputed_objective(std::uint64_t{0U});
    std::optional<EdgeIndex> previous_edge;
    for (const EdgeIndex edge : matching.selected_edges()) {
      if (edge >= graph.edges().size() ||
          (previous_edge.has_value() && !(*previous_edge < edge))) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_expansion_selected_edge_invalid",
                "selected representative edges are not strict in-range indices"));
      }
      previous_edge = edge;
      const RepresentativeEdge& record = graph.edges()[edge];
      if (expected_mates[record.first].has_value() ||
          expected_mates[record.second].has_value()) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_expansion_not_a_matching",
                "selected representative edges share an endpoint",
                {"representative edge index: " + std::to_string(edge)}));
      }
      if (selected_queues[record.queue.ordinal()] != 0U) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_expansion_queue_duplicate",
                "two selected representatives map to the same queue"));
      }
      expected_mates[record.first] = record.second;
      expected_mates[record.second] = record.first;
      selected_queues[record.queue.ordinal()] = std::uint8_t{1U};
      recomputed_objective += record.weight;
    }

    if (!std::ranges::equal(expected_mates, matching.vertex_mates())) {
      return Result<NodeExclusiveExactWitness>::failure(blossom_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_expansion_mate_map_mismatch",
          "the representative edge list and mate map describe different matchings"));
    }
    if (recomputed_objective != matching.objective()) {
      return Result<NodeExclusiveExactWitness>::failure(blossom_diagnostic(
          DiagnosticCategory::internal,
          "node_exclusive_expansion_objective_mismatch",
          "the selected representatives do not reproduce the exact matching objective",
          {"reported objective: " +
               matching.objective().to_decimal_string(),
           "recomputed objective: " +
               recomputed_objective.to_decimal_string()}));
    }

    auto schedule = Schedule::from_bytes(graph.dimension(),
                                         std::move(selected_queues));
    if (!schedule) {
      return Result<NodeExclusiveExactWitness>::failure(
          std::move(schedule.error()));
    }
    return Result<NodeExclusiveExactWitness>::success(
        NodeExclusiveExactWitness{
            .schedule = std::move(schedule).value(),
            .composite_objective = std::move(recomputed_objective),
            .proof_notes = {
                "exact arbitrary-precision Edmonds/Galil weighted Blossom",
                "exact primal-dual strong-duality certificate checked",
                "cold solve-local blossom forest, duals, slacks, and representatives",
                "recursive search budget expansions are not consumed",
            },
        });
  } catch (const std::bad_alloc&) {
    return Result<NodeExclusiveExactWitness>::failure(
        allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<NodeExclusiveExactWitness>::failure(
        representation_diagnostic());
  }
}

Result<NodeExclusiveExactWitness> solve_node_exclusive_exact(
    const NodeExclusiveProblem& problem,
    const EligibilityMask& eligibility, const LexWeights& weights,
    const ForcedTargetCondition* condition) {
  try {
    // The public reduction performs the complete immutable-problem and query
    // identity validation before this adapter touches any reconstruction map.
    auto unconditioned = select_parallel_link_representatives(
        problem, eligibility, weights);
    if (!unconditioned) {
      return Result<NodeExclusiveExactWitness>::failure(
          std::move(unconditioned.error()));
    }

    std::optional<std::size_t> committed_target;
    RepresentativeGraph residual_graph = std::move(unconditioned).value();
    if (condition != nullptr) {
      switch (condition->bit) {
        case ForcedTargetBit::zero:
        case ForcedTargetBit::one:
          break;
        default:
          return Result<NodeExclusiveExactWitness>::failure(
              blossom_diagnostic(
                  DiagnosticCategory::internal,
                  "node_exclusive_forced_bit_invalid",
                  "the node-exclusive forced-target bit is outside the closed binary domain"));
      }
      const std::size_t target = condition->target.ordinal();
      if (target >= problem.queue_count()) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_forced_target_out_of_range",
                "the node-exclusive forced target lies outside the compiled queue dimension"));
      }
      if (!condition->target.matches(weights.dimension())) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_forced_target_identity_mismatch",
                "the node-exclusive forced target belongs to another queue dimension"));
      }
      const bool target_required =
          condition->bit == ForcedTargetBit::one;
      const bool target_eligible = eligibility.bytes()[target] != 0U;
      if (target_required != target_eligible) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_forced_target_eligibility_mismatch",
                "the conditioned target eligibility disagrees with its forced side"));
      }

      if (target_required) {
        const std::size_t target_position = problem.queue_to_link()[target];
        if (target_position >= problem.links().size() ||
            problem.links()[target_position].queue.ordinal() != target) {
          return Result<NodeExclusiveExactWitness>::failure(
              blossom_diagnostic(
                  DiagnosticCategory::internal,
                  "node_exclusive_forced_target_geometry_corrupt",
                  "the forced target has no valid compiled link reconstruction"));
        }
        const NodeExclusiveLabelledLink& target_link =
            problem.links()[target_position];
        std::vector<std::uint8_t> active(eligibility.bytes().begin(),
                                         eligibility.bytes().end());
        for (const NodeExclusiveLabelledLink& link : problem.links()) {
          if (link.first == target_link.first ||
              link.first == target_link.second ||
              link.second == target_link.first ||
              link.second == target_link.second) {
            active[link.queue.ordinal()] = std::uint8_t{0U};
          }
        }
        auto conditioned_graph =
            select_parallel_link_representatives_active(problem, active,
                                                        weights);
        if (!conditioned_graph) {
          return Result<NodeExclusiveExactWitness>::failure(
              std::move(conditioned_graph.error()));
        }
        residual_graph = std::move(conditioned_graph).value();
        committed_target = target;
      }
    }

    auto matching = solve_blossom_exact(residual_graph);
    if (!matching) {
      return Result<NodeExclusiveExactWitness>::failure(
          std::move(matching.error()));
    }
    auto expanded = expand_representative_matching(matching.value(),
                                                   residual_graph);
    if (!expanded) {
      return Result<NodeExclusiveExactWitness>::failure(
          std::move(expanded.error()));
    }
    NodeExclusiveExactWitness witness = std::move(expanded).value();

    if (committed_target.has_value()) {
      std::vector<std::uint8_t> selected(witness.schedule.bytes().begin(),
                                         witness.schedule.bytes().end());
      if (selected[*committed_target] != 0U) {
        return Result<NodeExclusiveExactWitness>::failure(
            blossom_diagnostic(
                DiagnosticCategory::internal,
                "node_exclusive_forced_target_residual_selected",
                "the forced-one target unexpectedly entered the residual matching"));
      }
      selected[*committed_target] = std::uint8_t{1U};
      witness.composite_objective += weights.values()[*committed_target];
      auto committed =
          Schedule::from_bytes(weights.dimension(), std::move(selected));
      if (!committed) {
        return Result<NodeExclusiveExactWitness>::failure(
            std::move(committed.error()));
      }
      witness.schedule = std::move(committed).value();
      witness.proof_notes.push_back(
          "forced-one labelled target committed after removing both endpoint neighborhoods");
    } else if (condition != nullptr) {
      witness.proof_notes.push_back(
          "forced-zero labelled target excluded before parallel reduction");
    }
    return Result<NodeExclusiveExactWitness>::success(std::move(witness));
  } catch (const std::bad_alloc&) {
    return Result<NodeExclusiveExactWitness>::failure(
        allocation_diagnostic());
  } catch (const std::length_error&) {
    return Result<NodeExclusiveExactWitness>::failure(
        representation_diagnostic());
  }
}

}  // namespace mwperf::detail
