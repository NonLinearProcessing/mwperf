#include "mwperf/optimizer/exact_optimizer.hpp"

#include <cstddef>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/crossbar.hpp"
#include "mwperf/optimizer/interval.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf::detail {

namespace {

[[nodiscard]] Diagnostic registration_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Result<void> verify_crossbar_binding(
    const ResolvedCrossbarConstraint& constraint,
    const CrossbarProblem& problem) {
  if (constraint.inputs.size() != problem.input_count() ||
      constraint.outputs.size() != problem.output_count() ||
      constraint.edges.size() != problem.queue_count()) {
    return Result<void>::failure(registration_error(
        "crossbar_compiled_product_binding_mismatch",
        "the immutable crossbar problem does not match its bound descriptor",
        {"descriptor inputs/outputs/queues: " +
             std::to_string(constraint.inputs.size()) + "/" +
             std::to_string(constraint.outputs.size()) + "/" +
             std::to_string(constraint.edges.size()),
         "compiled inputs/outputs/queues: " +
             std::to_string(problem.input_count()) + "/" +
             std::to_string(problem.output_count()) + "/" +
             std::to_string(problem.queue_count())}));
  }
  std::vector<std::uint8_t> seen(problem.queue_count(), 0U);
  for (const ResolvedCrossbarEdge& edge : constraint.edges) {
    const std::size_t queue = edge.queue.ordinal();
    if (queue >= problem.queue_count() || seen[queue] != 0U) {
      return Result<void>::failure(registration_error(
          "crossbar_descriptor_queue_binding_invalid",
          "the bound crossbar descriptor has corrupt dense queue coverage"));
    }
    seen[queue] = 1U;
    const CrossbarQueueEdge& compiled = problem.queue_edges()[queue];
    if (compiled.queue.ordinal() != queue ||
        compiled.input != edge.input.ordinal() ||
        compiled.output != edge.output.ordinal()) {
      return Result<void>::failure(registration_error(
          "crossbar_compiled_product_binding_mismatch",
          "the immutable crossbar problem edge map differs from its bound "
          "descriptor",
          {"dense queue index: " + std::to_string(queue)}));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> verify_interval_binding(
    const ResolvedIntervalConstraint& constraint,
    const IntervalProblem& problem) {
  if (constraint.intervals.size() != problem.queue_count() ||
      problem.intervals().size() != problem.queue_count() ||
      problem.queue_to_ordered().size() != problem.queue_count()) {
    return Result<void>::failure(registration_error(
        "interval_compiled_product_binding_mismatch",
        "the immutable interval problem does not match its bound descriptor"));
  }
  std::vector<std::uint8_t> seen(problem.queue_count(), 0U);
  for (const ResolvedInterval& interval : constraint.intervals) {
    const std::size_t queue = interval.queue.ordinal();
    if (queue >= problem.queue_count() || seen[queue] != 0U) {
      return Result<void>::failure(registration_error(
          "interval_descriptor_queue_binding_invalid",
          "the bound interval descriptor has corrupt dense queue coverage"));
    }
    seen[queue] = 1U;
    const std::size_t ordered = problem.queue_to_ordered()[queue];
    if (ordered >= problem.intervals().size()) {
      return Result<void>::failure(registration_error(
          "interval_compiled_product_binding_mismatch",
          "the immutable interval problem has an out-of-range queue map",
          {"dense queue index: " + std::to_string(queue)}));
    }
    const ExactInterval& compiled = problem.intervals()[ordered];
    if (compiled.queue.ordinal() != queue ||
        compiled.left != interval.left || compiled.right != interval.right) {
      return Result<void>::failure(registration_error(
          "interval_compiled_product_binding_mismatch",
          "the immutable interval problem geometry differs from its bound "
          "descriptor",
          {"dense queue index: " + std::to_string(queue)}));
    }
  }
  return Result<void>::success();
}

}  // namespace

// Narrow recovery authority for the two C06 type-erased products. The private
// tag check precedes every cast, so C04/C05 fixture owners cannot be mistaken
// for a concrete C06 object merely by carrying the same family enum.
Result<const CrossbarProblem*> C06CompiledProductAccess::crossbar(
    const CompiledConstraintProduct& product,
    const ExactBackendAuthority& authority) {
  (void)authority;
  if (product.family_ != ServiceFamily::crossbar_matching ||
      product.compiled_type_tag_ != CrossbarProblem::compiled_type_tag() ||
      !product.owner_) {
    return Result<const CrossbarProblem*>::failure(registration_error(
        "crossbar_compiled_product_type_mismatch",
        "the crossbar backend did not receive a typed C06 crossbar compiled "
        "product"));
  }
  return Result<const CrossbarProblem*>::success(
      static_cast<const CrossbarProblem*>(product.owner_.get()));
}

Result<const IntervalProblem*> C06CompiledProductAccess::intervals(
    const CompiledConstraintProduct& product,
    const ExactBackendAuthority& authority) {
  (void)authority;
  if (product.family_ != ServiceFamily::nonoverlapping_intervals ||
      product.compiled_type_tag_ != IntervalProblem::compiled_type_tag() ||
      !product.owner_) {
    return Result<const IntervalProblem*>::failure(registration_error(
        "interval_compiled_product_type_mismatch",
        "the interval backend did not receive a typed C06 interval compiled "
        "product"));
  }
  return Result<const IntervalProblem*>::success(
      static_cast<const IntervalProblem*>(product.owner_.get()));
}

// The two functions below are the only C06 production registrations. They
// recover the typed immutable geometry, invoke the cold family primitive, and
// use the C05 dispatch-created authority to package (but not promote) the
// claimed exact witness.
Result<ExactBackendCandidate> dispatch_registered_crossbar(
    const ResolvedCrossbarConstraint& constraint,
    const CompiledConstraintProduct& product,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    const std::optional<ForcedTargetCondition>& condition,
    const ExactBackendAuthority& authority) {
  auto recovered = C06CompiledProductAccess::crossbar(product, authority);
  if (!recovered) {
    return Result<ExactBackendCandidate>::failure(
        std::move(recovered.error()));
  }
  auto binding = verify_crossbar_binding(constraint, *recovered.value());
  if (!binding) {
    return Result<ExactBackendCandidate>::failure(std::move(binding.error()));
  }
  auto witness = solve_crossbar_exact(
      *recovered.value(), eligibility, weights,
      condition.has_value() ? &*condition : nullptr);
  if (!witness) {
    return Result<ExactBackendCandidate>::failure(std::move(witness.error()));
  }
  CrossbarExactWitness exact = std::move(witness).value();
  return Result<ExactBackendCandidate>::success(authority.make_candidate(
      std::move(exact.schedule), std::move(exact.composite_objective),
      ServiceFamily::crossbar_matching, OptimizerId::hungarian_exact,
      budget.accounting(), std::move(exact.proof_notes)));
}

Result<ExactBackendCandidate> dispatch_registered_intervals(
    const ResolvedIntervalConstraint& constraint,
    const CompiledConstraintProduct& product,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    const std::optional<ForcedTargetCondition>& condition,
    const ExactBackendAuthority& authority) {
  auto recovered = C06CompiledProductAccess::intervals(product, authority);
  if (!recovered) {
    return Result<ExactBackendCandidate>::failure(
        std::move(recovered.error()));
  }
  auto binding = verify_interval_binding(constraint, *recovered.value());
  if (!binding) {
    return Result<ExactBackendCandidate>::failure(std::move(binding.error()));
  }
  auto witness = solve_interval_exact(
      *recovered.value(), eligibility, weights,
      condition.has_value() ? &*condition : nullptr);
  if (!witness) {
    return Result<ExactBackendCandidate>::failure(std::move(witness.error()));
  }
  IntervalExactWitness exact = std::move(witness).value();
  return Result<ExactBackendCandidate>::success(authority.make_candidate(
      std::move(exact.schedule), std::move(exact.composite_objective),
      ServiceFamily::nonoverlapping_intervals,
      OptimizerId::weighted_interval_dp_exact, budget.accounting(),
      std::move(exact.proof_notes)));
}

}  // namespace mwperf::detail
