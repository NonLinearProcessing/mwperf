#include "mwperf/model/constraint_descriptor.hpp"

#include <algorithm>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <stdexcept>
#include <type_traits>
#include <utility>

#include "mwperf/optimizer/crossbar.hpp"
#include "mwperf/optimizer/conflict.hpp"
#include "mwperf/optimizer/interval.hpp"
#include "mwperf/optimizer/node_exclusive.hpp"
#include "mwperf/optimizer/packing.hpp"

namespace mwperf {
namespace detail {

struct ConstraintIndexFactory final {
  template <typename Domain>
  [[nodiscard]] static DenseConstraintIndex<Domain> make(
      const std::size_t ordinal) noexcept {
    return DenseConstraintIndex<Domain>(ordinal);
  }
};

struct ConstraintDescriptorFactory final {
  [[nodiscard]] static CompiledConstraintProduct make_product(
      ServiceFamily family, std::shared_ptr<const void> owner,
      const void* compiled_type_tag) {
    return CompiledConstraintProduct(family, std::move(owner),
                                     compiled_type_tag);
  }

  [[nodiscard]] static ConstraintDescriptor make(
      ConstraintVariant value, CompiledConstraintProduct compiled_product) {
    return ConstraintDescriptor(std::move(value),
                                std::move(compiled_product));
  }
};

}  // namespace detail
namespace {

[[nodiscard]] Diagnostic constraint_error(
    const ModelProvenance& provenance, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  std::optional<std::string> path;
  if (provenance.location.has_value()) {
    path = provenance.location->authored_path;
    notes.insert(notes.begin(),
                 "line " + std::to_string(provenance.location->line) +
                     ", column " +
                     std::to_string(provenance.location->column));
  }
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::move(path),
                    provenance.json_pointer.empty()
                        ? std::nullopt
                        : std::optional<std::string>{provenance.json_pointer},
                    std::move(notes)};
}

[[nodiscard]] Diagnostic constraint_unavailable(
    const ModelProvenance& provenance, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  Diagnostic diagnostic =
      constraint_error(provenance, std::move(code), std::move(message),
                       std::move(notes));
  diagnostic.category = DiagnosticCategory::unavailable;
  return diagnostic;
}

#if defined(MWPERF_C04_TEST_SEAMS)
[[nodiscard]] Diagnostic constraint_internal(
    const ModelProvenance& provenance, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  Diagnostic diagnostic =
      constraint_error(provenance, std::move(code), std::move(message),
                       std::move(notes));
  diagnostic.category = DiagnosticCategory::internal;
  return diagnostic;
}
#endif

template <typename Value>
[[nodiscard]] Result<Value> failure(Diagnostic diagnostic) {
  return Result<Value>::failure(std::move(diagnostic));
}

[[nodiscard]] std::string queue_description(const QueueId& id) {
  if (const BigNat* numeric = id.label().numeric_value(); numeric != nullptr) {
    return "numeric queue " + numeric->to_decimal_string();
  }
  return "string queue \"" + *id.label().text_value() + "\"";
}

[[nodiscard]] Result<DenseQueueIndex> resolve_queue_once(
    const QueueCatalog& catalog, const AuthoredField<QueueId>& authored,
    std::vector<std::uint8_t>& seen) {
  auto resolved = catalog.resolve(authored.value, authored.provenance);
  if (!resolved) {
    return Result<DenseQueueIndex>::failure(std::move(resolved.error()));
  }
  const std::size_t ordinal = resolved.value().ordinal();
  if (seen[ordinal] != 0U) {
    return Result<DenseQueueIndex>::failure(constraint_error(
        authored.provenance, "duplicate_constraint_queue",
        "the constraint assigns " + queue_description(authored.value) +
            " more than once"));
  }
  seen[ordinal] = 1U;
  return resolved;
}

[[nodiscard]] Result<void> require_complete_queue_coverage(
    const QueueCatalog& catalog, const std::vector<std::uint8_t>& seen,
    const ModelProvenance& provenance) {
  for (std::size_t ordinal = 0U; ordinal < seen.size(); ++ordinal) {
    if (seen[ordinal] == 0U) {
      auto index = catalog.index_at(ordinal);
      if (!index) {
        return Result<void>::failure(std::move(index.error()));
      }
      return Result<void>::failure(constraint_error(
          provenance, "missing_constraint_queue",
          "the constraint does not assign " +
              queue_description(catalog.queue_id(index.value())),
          {"every catalog queue must occur exactly once in this constraint "
           "family"}));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ConstraintVariant> bind_crossbar(
    const CrossbarMaxWeightScheduler& scheduler,
    const QueueCatalog& catalog) {
  if (scheduler.legacy_form || !scheduler.constraint.value.has_value()) {
    return failure<ConstraintVariant>(constraint_error(
        scheduler.provenance, "crossbar_constraint_unavailable",
        "the generalized analytical crossbar scheduler requires an explicit "
        "constraint"));
  }
  const CrossbarConstraint& authored = *scheduler.constraint.value;
  if (authored.inputs.value.empty()) {
    return failure<ConstraintVariant>(constraint_error(
        authored.inputs.provenance, "empty_crossbar_inputs",
        "a crossbar constraint must declare at least one input"));
  }
  if (authored.outputs.value.empty()) {
    return failure<ConstraintVariant>(constraint_error(
        authored.outputs.provenance, "empty_crossbar_outputs",
        "a crossbar constraint must declare at least one output"));
  }
  if (authored.edges.value.empty()) {
    return failure<ConstraintVariant>(constraint_error(
        authored.edges.provenance, "empty_crossbar_edges",
        "a crossbar constraint must declare at least one queue-labelled edge"));
  }

  std::map<PortId, std::size_t> inputs;
  std::vector<ResolvedInputPort> resolved_inputs;
  resolved_inputs.reserve(authored.inputs.value.size());
  for (std::size_t index = 0U; index < authored.inputs.value.size(); ++index) {
    const auto& port = authored.inputs.value[index];
    if (!inputs.emplace(port.value, index).second) {
      return failure<ConstraintVariant>(constraint_error(
          port.provenance, "duplicate_crossbar_input",
          "a crossbar input label is declared more than once"));
    }
    resolved_inputs.push_back(ResolvedInputPort{
        detail::ConstraintIndexFactory::make<detail::InputIndexTag>(index),
        port.value, port.provenance});
  }

  std::map<PortId, std::size_t> outputs;
  std::vector<ResolvedOutputPort> resolved_outputs;
  resolved_outputs.reserve(authored.outputs.value.size());
  for (std::size_t index = 0U; index < authored.outputs.value.size(); ++index) {
    const auto& port = authored.outputs.value[index];
    if (!outputs.emplace(port.value, index).second) {
      return failure<ConstraintVariant>(constraint_error(
          port.provenance, "duplicate_crossbar_output",
          "a crossbar output label is declared more than once"));
    }
    resolved_outputs.push_back(ResolvedOutputPort{
        detail::ConstraintIndexFactory::make<detail::OutputIndexTag>(index),
        port.value, port.provenance});
  }

  std::vector<std::uint8_t> seen(catalog.size(), 0U);
  std::set<std::pair<std::size_t, std::size_t>> endpoint_pairs;
  std::vector<ResolvedCrossbarEdge> edges;
  edges.reserve(authored.edges.value.size());
  for (const CrossbarEdge& edge : authored.edges.value) {
    const auto input = inputs.find(edge.input.value);
    if (input == inputs.end()) {
      return failure<ConstraintVariant>(constraint_error(
          edge.input.provenance, "undeclared_crossbar_input",
          "a crossbar edge refers to an undeclared input"));
    }
    const auto output = outputs.find(edge.output.value);
    if (output == outputs.end()) {
      return failure<ConstraintVariant>(constraint_error(
          edge.output.provenance, "undeclared_crossbar_output",
          "a crossbar edge refers to an undeclared output"));
    }
    auto queue = resolve_queue_once(catalog, edge.queue_id, seen);
    if (!queue) {
      return failure<ConstraintVariant>(std::move(queue.error()));
    }
    if (!endpoint_pairs.emplace(input->second, output->second).second) {
      return failure<ConstraintVariant>(constraint_error(
          edge.provenance, "duplicate_crossbar_endpoint_pair",
          "more than one queue is assigned to the same crossbar input/output "
          "pair"));
    }
    edges.push_back(ResolvedCrossbarEdge{
        queue.value(),
        detail::ConstraintIndexFactory::make<detail::InputIndexTag>(
            input->second),
        detail::ConstraintIndexFactory::make<detail::OutputIndexTag>(
            output->second),
        edge.provenance});
  }
  auto complete =
      require_complete_queue_coverage(catalog, seen, authored.provenance);
  if (!complete) {
    return failure<ConstraintVariant>(std::move(complete.error()));
  }
  return Result<ConstraintVariant>::success(ResolvedCrossbarConstraint{
      std::move(resolved_inputs), std::move(resolved_outputs),
      std::move(edges), authored.provenance});
}

[[nodiscard]] Result<ConstraintVariant> bind_intervals(
    const IntervalMaxWeightScheduler& scheduler,
    const QueueCatalog& catalog) {
  const IntervalConstraint& authored = scheduler.constraint.value;
  std::vector<std::uint8_t> seen(catalog.size(), 0U);
  std::vector<ResolvedInterval> intervals;
  intervals.reserve(authored.intervals.value.size());
  for (const IntervalRecord& interval : authored.intervals.value) {
    if (!(interval.left.value < interval.right.value)) {
      return failure<ConstraintVariant>(constraint_error(
          interval.provenance, "invalid_interval",
          "an interval must satisfy exact left < right"));
    }
    auto queue = resolve_queue_once(catalog, interval.queue_id, seen);
    if (!queue) {
      return failure<ConstraintVariant>(std::move(queue.error()));
    }
    intervals.push_back(ResolvedInterval{queue.value(), interval.left.value,
                                         interval.right.value,
                                         interval.provenance});
  }
  auto complete =
      require_complete_queue_coverage(catalog, seen, authored.provenance);
  if (!complete) {
    return failure<ConstraintVariant>(std::move(complete.error()));
  }
  return Result<ConstraintVariant>::success(ResolvedIntervalConstraint{
      std::move(intervals), authored.provenance});
}

[[nodiscard]] Result<ConstraintVariant> bind_node_exclusive(
    const NodeExclusiveMaxWeightScheduler& scheduler,
    const QueueCatalog& catalog) {
  const NodeExclusiveConstraint& authored = scheduler.constraint.value;
  if (authored.vertices.value.empty()) {
    return failure<ConstraintVariant>(constraint_error(
        authored.vertices.provenance, "empty_node_vertex_set",
        "a node-exclusive constraint must declare at least one vertex"));
  }
  if (authored.links.value.empty()) {
    return failure<ConstraintVariant>(constraint_error(
        authored.links.provenance, "empty_node_link_set",
        "a node-exclusive constraint must declare at least one queue-labelled "
        "link"));
  }

  std::map<VertexId, std::size_t> vertices;
  std::vector<ResolvedVertex> resolved_vertices;
  resolved_vertices.reserve(authored.vertices.value.size());
  for (std::size_t index = 0U; index < authored.vertices.value.size(); ++index) {
    const auto& vertex = authored.vertices.value[index];
    if (!vertices.emplace(vertex.value, index).second) {
      return failure<ConstraintVariant>(constraint_error(
          vertex.provenance, "duplicate_node_vertex",
          "a node-exclusive vertex label is declared more than once"));
    }
    resolved_vertices.push_back(ResolvedVertex{
        detail::ConstraintIndexFactory::make<detail::VertexIndexTag>(index),
        vertex.value, vertex.provenance});
  }

  std::vector<std::uint8_t> seen(catalog.size(), 0U);
  std::vector<ResolvedNodeExclusiveLink> links;
  links.reserve(authored.links.value.size());
  for (const NodeExclusiveLink& link : authored.links.value) {
    const auto u = vertices.find(link.u.value);
    if (u == vertices.end()) {
      return failure<ConstraintVariant>(constraint_error(
          link.u.provenance, "undeclared_link_vertex",
          "a node-exclusive link refers to an undeclared endpoint"));
    }
    const auto v = vertices.find(link.v.value);
    if (v == vertices.end()) {
      return failure<ConstraintVariant>(constraint_error(
          link.v.provenance, "undeclared_link_vertex",
          "a node-exclusive link refers to an undeclared endpoint"));
    }
    if (u->second == v->second) {
      return failure<ConstraintVariant>(constraint_error(
          link.provenance, "node_link_self_loop",
          "a node-exclusive link must have two distinct endpoints"));
    }
    auto queue = resolve_queue_once(catalog, link.queue_id, seen);
    if (!queue) {
      return failure<ConstraintVariant>(std::move(queue.error()));
    }
    links.push_back(ResolvedNodeExclusiveLink{
        queue.value(),
        detail::ConstraintIndexFactory::make<detail::VertexIndexTag>(u->second),
        detail::ConstraintIndexFactory::make<detail::VertexIndexTag>(v->second),
        link.provenance});
  }
  auto complete =
      require_complete_queue_coverage(catalog, seen, authored.provenance);
  if (!complete) {
    return failure<ConstraintVariant>(std::move(complete.error()));
  }
  return Result<ConstraintVariant>::success(ResolvedNodeExclusiveConstraint{
      std::move(resolved_vertices), std::move(links), authored.provenance});
}

[[nodiscard]] Result<ConstraintVariant> bind_conflicts(
    const ConflictGraphMaxWeightScheduler& scheduler,
    const QueueCatalog& catalog) {
  const ConflictConstraint& authored = scheduler.constraint.value;
  std::set<std::pair<std::size_t, std::size_t>> seen_pairs;
  std::vector<ResolvedConflictPair> pairs;
  std::vector<std::vector<DenseQueueIndex>> adjacency(catalog.size());
  pairs.reserve(authored.conflicts.value.size());

  for (const ConflictPair& conflict : authored.conflicts.value) {
    auto first = catalog.resolve(conflict.first.value,
                                 conflict.first.provenance);
    if (!first) {
      return failure<ConstraintVariant>(std::move(first.error()));
    }
    auto second = catalog.resolve(conflict.second.value,
                                  conflict.second.provenance);
    if (!second) {
      return failure<ConstraintVariant>(std::move(second.error()));
    }
    if (first.value() == second.value()) {
      return failure<ConstraintVariant>(constraint_error(
          conflict.provenance, "conflict_self_pair",
          "a queue cannot conflict with itself"));
    }
    DenseQueueIndex low = first.value();
    DenseQueueIndex high = second.value();
    if (high < low) {
      std::swap(low, high);
    }
    const auto key = std::pair{low.ordinal(), high.ordinal()};
    if (!seen_pairs.insert(key).second) {
      return failure<ConstraintVariant>(constraint_error(
          conflict.provenance, "duplicate_conflict_pair",
          "an undirected conflict pair is declared more than once"));
    }
    adjacency[low.ordinal()].push_back(high);
    adjacency[high.ordinal()].push_back(low);
    pairs.push_back(ResolvedConflictPair{low, high, conflict.provenance});
  }
  return Result<ConstraintVariant>::success(ResolvedConflictConstraint{
      std::move(pairs), std::move(adjacency), authored.provenance});
}

[[nodiscard]] Result<ConstraintVariant> bind_packing(
    const ResourcePackingMaxWeightScheduler& scheduler,
    const QueueCatalog& catalog) {
  const PackingConstraint& authored = scheduler.constraint.value;
  std::map<ResourceId, std::size_t> resources;
  std::vector<ResolvedResource> resolved_resources;
  resolved_resources.reserve(authored.resources.value.size());
  for (std::size_t index = 0U; index < authored.resources.value.size();
       ++index) {
    const auto& resource = authored.resources.value[index];
    if (!resources.emplace(resource.value, index).second) {
      return failure<ConstraintVariant>(constraint_error(
          resource.provenance, "duplicate_packing_resource",
          "a packing resource label is declared more than once"));
    }
    resolved_resources.push_back(ResolvedResource{
        detail::ConstraintIndexFactory::make<detail::ResourceIndexTag>(index),
        resource.value, resource.provenance});
  }
  if (authored.capacity.value.size() != authored.resources.value.size()) {
    return failure<ConstraintVariant>(constraint_error(
        authored.capacity.provenance, "packing_capacity_dimension",
        "the packing capacity vector length must equal the resource count"));
  }

  std::vector<BigNat> capacity;
  capacity.reserve(authored.capacity.value.size());
  for (const auto& value : authored.capacity.value) {
    capacity.push_back(value.value);
  }

  std::vector<std::uint8_t> seen(catalog.size(), 0U);
  std::vector<ResolvedPackingDemand> demands;
  demands.reserve(authored.demands.value.size());
  for (const PackingDemand& demand : authored.demands.value) {
    if (demand.demand.value.size() != authored.resources.value.size()) {
      return failure<ConstraintVariant>(constraint_error(
          demand.demand.provenance, "packing_demand_dimension",
          "a packing demand vector length must equal the resource count"));
    }
    auto queue = resolve_queue_once(catalog, demand.queue_id, seen);
    if (!queue) {
      return failure<ConstraintVariant>(std::move(queue.error()));
    }
    std::vector<BigNat> values;
    values.reserve(demand.demand.value.size());
    for (const auto& value : demand.demand.value) {
      values.push_back(value.value);
    }
    demands.push_back(ResolvedPackingDemand{queue.value(), std::move(values),
                                            demand.provenance});
  }
  auto complete =
      require_complete_queue_coverage(catalog, seen, authored.provenance);
  if (!complete) {
    return failure<ConstraintVariant>(std::move(complete.error()));
  }
  return Result<ConstraintVariant>::success(ResolvedPackingConstraint{
      std::move(resolved_resources), std::move(capacity), std::move(demands),
      authored.provenance});
}

[[nodiscard]] ServiceFamily family_of(
    const ConstraintVariant& constraint) noexcept {
  return std::visit(
      []<typename Constraint>(const Constraint&) noexcept {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          return ServiceFamily::crossbar_matching;
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          return ServiceFamily::nonoverlapping_intervals;
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          return ServiceFamily::node_exclusive_matching;
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          return ServiceFamily::pairwise_conflicts;
        } else {
          return ServiceFamily::resource_packing;
        }
      },
      constraint);
}

[[nodiscard]] const ModelProvenance& provenance_of(
    const ConstraintVariant& constraint) noexcept {
  return std::visit(
      [](const auto& value) -> const ModelProvenance& {
        return value.provenance;
      },
      constraint);
}

[[nodiscard]] Result<ConstraintVariant> bind_constraint_geometry(
    const AuthoredSchedulerConfig& scheduler, const QueueCatalog& catalog) {
  return std::visit(
      [&catalog]<typename Scheduler>(const Scheduler& value)
          -> Result<ConstraintVariant> {
        using Type = std::decay_t<Scheduler>;
        if constexpr (std::is_same_v<Type, CrossbarMaxWeightScheduler>) {
          return bind_crossbar(value, catalog);
        } else if constexpr (std::is_same_v<Type,
                                            IntervalMaxWeightScheduler>) {
          return bind_intervals(value, catalog);
        } else if constexpr (std::is_same_v<
                                 Type, NodeExclusiveMaxWeightScheduler>) {
          return bind_node_exclusive(value, catalog);
        } else if constexpr (std::is_same_v<
                                 Type, ConflictGraphMaxWeightScheduler>) {
          return bind_conflicts(value, catalog);
        } else if constexpr (std::is_same_v<
                                 Type, ResourcePackingMaxWeightScheduler>) {
          return bind_packing(value, catalog);
        } else {
          return failure<ConstraintVariant>(constraint_unavailable(
              value.provenance, "unsupported_scheduler_family",
              "the compatibility scheduler has no analytical constraint "
              "descriptor"));
        }
      },
      scheduler.value);
}

[[nodiscard]] Diagnostic missing_compiler(
    const ConstraintVariant& geometry) {
  switch (family_of(geometry)) {
    case ServiceFamily::crossbar_matching:
    case ServiceFamily::nonoverlapping_intervals:
      return constraint_unavailable(
          provenance_of(geometry), "constraint_compiler_unavailable_c06",
          "the C06 crossbar/interval constraint compiler is not available at "
          "checkpoint C04");
    case ServiceFamily::node_exclusive_matching:
      return constraint_unavailable(
          provenance_of(geometry), "constraint_compiler_unavailable_c07",
          "the C07 node-exclusive constraint compiler is not available at "
          "checkpoint C04");
    case ServiceFamily::pairwise_conflicts:
    case ServiceFamily::resource_packing:
      return constraint_unavailable(
          provenance_of(geometry), "constraint_compiler_unavailable_c08",
          "the C08 recursive constraint compiler is not available at "
          "checkpoint C04");
  }
  return constraint_unavailable(
      provenance_of(geometry), "constraint_compiler_unavailable",
      "the constraint compiler is not available at checkpoint C04");
}

}  // namespace

std::string_view to_string(const ExactSchedulerName value) noexcept {
  switch (value) {
    case ExactSchedulerName::crossbar_max_weight:
      return "crossbar_max_weight";
    case ExactSchedulerName::interval_max_weight:
      return "interval_max_weight";
    case ExactSchedulerName::node_exclusive_max_weight:
      return "node_exclusive_max_weight";
    case ExactSchedulerName::conflict_graph_max_weight:
      return "conflict_graph_max_weight";
    case ExactSchedulerName::resource_packing_max_weight:
      return "resource_packing_max_weight";
  }
  return "unknown";
}

std::string_view to_string(const ServiceFamily value) noexcept {
  switch (value) {
    case ServiceFamily::crossbar_matching:
      return "crossbar_matching";
    case ServiceFamily::nonoverlapping_intervals:
      return "nonoverlapping_intervals";
    case ServiceFamily::node_exclusive_matching:
      return "node_exclusive_matching";
    case ServiceFamily::pairwise_conflicts:
      return "pairwise_conflicts";
    case ServiceFamily::resource_packing:
      return "resource_packing";
  }
  return "unknown";
}

std::string_view to_string(const OptimizerId value) noexcept {
  switch (value) {
    case OptimizerId::hungarian_exact:
      return "hungarian_exact";
    case OptimizerId::weighted_interval_dp_exact:
      return "weighted_interval_dp_exact";
    case OptimizerId::edmonds_blossom_exact:
      return "edmonds_blossom_exact";
    case OptimizerId::mwis_branch_memo_exact:
      return "mwis_branch_memo_exact";
    case OptimizerId::binary_packing_memo_exact:
      return "binary_packing_memo_exact";
  }
  return "unknown";
}

ServiceFamily ConstraintDescriptor::family() const noexcept {
  return family_of(value_);
}

DerivedServiceIdentity ConstraintDescriptor::identity() const noexcept {
  switch (family()) {
    case ServiceFamily::crossbar_matching:
      return {ExactSchedulerName::crossbar_max_weight,
              ServiceFamily::crossbar_matching, OptimizerId::hungarian_exact};
    case ServiceFamily::nonoverlapping_intervals:
      return {ExactSchedulerName::interval_max_weight,
              ServiceFamily::nonoverlapping_intervals,
              OptimizerId::weighted_interval_dp_exact};
    case ServiceFamily::node_exclusive_matching:
      return {ExactSchedulerName::node_exclusive_max_weight,
              ServiceFamily::node_exclusive_matching,
              OptimizerId::edmonds_blossom_exact};
    case ServiceFamily::pairwise_conflicts:
      return {ExactSchedulerName::conflict_graph_max_weight,
              ServiceFamily::pairwise_conflicts,
              OptimizerId::mwis_branch_memo_exact};
    case ServiceFamily::resource_packing:
      return {ExactSchedulerName::resource_packing_max_weight,
              ServiceFamily::resource_packing,
              OptimizerId::binary_packing_memo_exact};
  }
  return {ExactSchedulerName::crossbar_max_weight,
          ServiceFamily::crossbar_matching, OptimizerId::hungarian_exact};
}

std::string ConstraintDescriptor::summary() const {
  return std::visit(
      [this]<typename Constraint>(const Constraint& constraint) {
        std::string output(to_string(family()));
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          output += " queues=" + std::to_string(constraint.edges.size());
          output += " inputs=" + std::to_string(constraint.inputs.size());
          output += " outputs=" + std::to_string(constraint.outputs.size());
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          output += " queues=" + std::to_string(constraint.intervals.size());
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          output += " queues=" + std::to_string(constraint.links.size());
          output += " vertices=" +
                    std::to_string(constraint.vertices.size());
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          output += " queues=" + std::to_string(constraint.adjacency.size());
          output +=
              " conflicts=" + std::to_string(constraint.conflicts.size());
        } else {
          output += " queues=" + std::to_string(constraint.demands.size());
          output +=
              " resources=" + std::to_string(constraint.resources.size());
        }
        return output;
      },
      value_);
}

bool ServiceableMask::all() const noexcept {
  return std::all_of(values_.begin(), values_.end(),
                     [](const std::uint8_t value) { return value != 0U; });
}

Result<ConstraintDescriptor> compile_constraint_descriptor(
    const AuthoredSchedulerConfig& scheduler, const QueueCatalog& catalog) {
  try {
    auto geometry = bind_constraint_geometry(scheduler, catalog);
    if (!geometry) {
      return failure<ConstraintDescriptor>(std::move(geometry.error()));
    }

    auto product = std::visit(
        [&geometry]<typename Constraint>(const Constraint& constraint)
            -> Result<CompiledConstraintProduct> {
          using Type = std::decay_t<Constraint>;
          if constexpr (std::is_same_v<Type,
                                       ResolvedCrossbarConstraint>) {
            auto compiled = compile_crossbar_problem(constraint);
            if (!compiled) {
              return Result<CompiledConstraintProduct>::failure(
                  std::move(compiled.error()));
            }
            std::shared_ptr<const void> owner =
                std::make_shared<const CrossbarProblem>(
                    std::move(compiled).value());
            return Result<CompiledConstraintProduct>::success(
                detail::ConstraintDescriptorFactory::make_product(
                    ServiceFamily::crossbar_matching, std::move(owner),
                    CrossbarProblem::compiled_type_tag()));
          } else if constexpr (std::is_same_v<
                                   Type, ResolvedIntervalConstraint>) {
            auto compiled = compile_interval_problem(constraint);
            if (!compiled) {
              return Result<CompiledConstraintProduct>::failure(
                  std::move(compiled.error()));
            }
            std::shared_ptr<const void> owner =
                std::make_shared<const IntervalProblem>(
                    std::move(compiled).value());
            return Result<CompiledConstraintProduct>::success(
                detail::ConstraintDescriptorFactory::make_product(
                    ServiceFamily::nonoverlapping_intervals,
                    std::move(owner), IntervalProblem::compiled_type_tag()));
          } else if constexpr (std::is_same_v<
                                   Type, ResolvedNodeExclusiveConstraint>) {
            auto compiled = compile_node_exclusive_problem(constraint);
            if (!compiled) {
              return Result<CompiledConstraintProduct>::failure(
                  std::move(compiled.error()));
            }
            std::shared_ptr<const void> owner =
                std::make_shared<const NodeExclusiveProblem>(
                    std::move(compiled).value());
            return Result<CompiledConstraintProduct>::success(
                detail::ConstraintDescriptorFactory::make_product(
                    ServiceFamily::node_exclusive_matching,
                    std::move(owner),
                    NodeExclusiveProblem::compiled_type_tag()));
          } else if constexpr (std::is_same_v<
                                   Type, ResolvedConflictConstraint>) {
            auto compiled = compile_conflict_problem(constraint);
            if (!compiled) {
              return Result<CompiledConstraintProduct>::failure(
                  std::move(compiled.error()));
            }
            std::shared_ptr<const void> owner =
                std::make_shared<const ConflictProblem>(
                    std::move(compiled).value());
            return Result<CompiledConstraintProduct>::success(
                detail::ConstraintDescriptorFactory::make_product(
                    ServiceFamily::pairwise_conflicts, std::move(owner),
                    ConflictProblem::compiled_type_tag()));
          } else if constexpr (std::is_same_v<
                                   Type, ResolvedPackingConstraint>) {
            auto compiled = compile_packing_problem(constraint);
            if (!compiled) {
              return Result<CompiledConstraintProduct>::failure(
                  std::move(compiled.error()));
            }
            std::shared_ptr<const void> owner =
                std::make_shared<const PackingProblem>(
                    std::move(compiled).value());
            return Result<CompiledConstraintProduct>::success(
                detail::ConstraintDescriptorFactory::make_product(
                    ServiceFamily::resource_packing, std::move(owner),
                    PackingProblem::compiled_type_tag()));
          } else {
            return Result<CompiledConstraintProduct>::failure(
                missing_compiler(geometry.value()));
          }
        },
        geometry.value());
    if (!product) {
      return failure<ConstraintDescriptor>(std::move(product.error()));
    }
    return Result<ConstraintDescriptor>::success(
        detail::ConstraintDescriptorFactory::make(
            std::move(geometry).value(), std::move(product).value()));
  } catch (const std::bad_alloc&) {
    return failure<ConstraintDescriptor>(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "constraint_compile_allocation_failure",
        .message =
            "allocation failed while publishing immutable compiled "
            "constraint geometry",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  } catch (const std::length_error&) {
    return failure<ConstraintDescriptor>(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "constraint_compile_representation_failure",
        .message =
            "compiled constraint geometry exceeds a host container limit",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  }
}

#if defined(MWPERF_C04_TEST_SEAMS)
Result<CompiledConstraintProduct> CompiledConstraintProduct::for_fixture(
    const ServiceFamily family, std::shared_ptr<const void> owner) {
  if (!owner) {
    return Result<CompiledConstraintProduct>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "null_compiled_constraint_product",
        "a compiled constraint product must own a non-null immutable object",
        std::nullopt,
        std::nullopt,
        {},
    });
  }
  return Result<CompiledConstraintProduct>::success(
      CompiledConstraintProduct(family, std::move(owner)));
}

Result<ConstraintDescriptor>
detail::compile_constraint_descriptor_with_child_services(
    const AuthoredSchedulerConfig& scheduler, const QueueCatalog& catalog,
    const ConstraintCompilerServices& children) {
  auto geometry = bind_constraint_geometry(scheduler, catalog);
  if (!geometry) {
    return failure<ConstraintDescriptor>(std::move(geometry.error()));
  }

  auto product = std::visit(
      [&children, &geometry]<typename Constraint>(const Constraint& constraint)
          -> Result<CompiledConstraintProduct> {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          if (children.crossbar) {
            return children.crossbar(constraint);
          }
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          if (children.intervals) {
            return children.intervals(constraint);
          }
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          if (children.node_exclusive) {
            return children.node_exclusive(constraint);
          }
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          if (children.conflicts) {
            return children.conflicts(constraint);
          }
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedPackingConstraint>) {
          if (children.packing) {
            return children.packing(constraint);
          }
        }
        return Result<CompiledConstraintProduct>::failure(
            missing_compiler(geometry.value()));
      },
      geometry.value());
  if (!product) {
    return failure<ConstraintDescriptor>(std::move(product.error()));
  }

  const ServiceFamily expected_family = family_of(geometry.value());
  if (!product.value().has_owner() ||
      product.value().family() != expected_family) {
    return failure<ConstraintDescriptor>(constraint_internal(
        provenance_of(geometry.value()),
        "compiled_constraint_product_mismatch",
        "the family compiler returned a null or differently tagged compiled "
        "constraint product"));
  }
  return Result<ConstraintDescriptor>::success(
      ConstraintDescriptorFactory::make(std::move(geometry).value(),
                                        std::move(product).value()));
}
#endif

ServiceableMask compute_individual_serviceability(
    const ConstraintDescriptor& descriptor) {
  return std::visit(
      []<typename Constraint>(const Constraint& constraint) {
        using Type = std::decay_t<Constraint>;
        if constexpr (std::is_same_v<Type, ResolvedCrossbarConstraint>) {
          return ServiceableMask(
              std::vector<std::uint8_t>(constraint.edges.size(), 1U));
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedIntervalConstraint>) {
          return ServiceableMask(
              std::vector<std::uint8_t>(constraint.intervals.size(), 1U));
        } else if constexpr (std::is_same_v<
                                 Type, ResolvedNodeExclusiveConstraint>) {
          return ServiceableMask(
              std::vector<std::uint8_t>(constraint.links.size(), 1U));
        } else if constexpr (std::is_same_v<Type,
                                            ResolvedConflictConstraint>) {
          return ServiceableMask(
              std::vector<std::uint8_t>(constraint.adjacency.size(), 1U));
        } else {
          std::vector<std::uint8_t> serviceable(constraint.demands.size(), 0U);
          for (const ResolvedPackingDemand& demand : constraint.demands) {
            const bool fits =
                std::equal(demand.demand.begin(), demand.demand.end(),
                           constraint.capacity.begin(),
                           [](const BigNat& needed, const BigNat& available) {
                             return needed <= available;
                           });
            serviceable[demand.queue.ordinal()] = fits ? 1U : 0U;
          }
          return ServiceableMask(std::move(serviceable));
        }
      },
      descriptor.value());
}

}  // namespace mwperf
