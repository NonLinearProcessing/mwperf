#include "mwperf/model/framework_scope.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <functional>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/config/schema_versions.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace mwperf {

namespace detail {

// Defined only in this translation unit. Friending this builder keeps every
// constructor-enforced resolved carrier inaccessible to installed callers.
struct ResolutionBuilder final {
  [[nodiscard]] static ConfiguredArrivalBinding configured_arrival(
      PhysicalBindingIdentity identity,
      std::vector<BoundQueueReference> references,
      std::shared_ptr<const void> product_owner,
      ArrivalCompiledProductKind product_kind,
      std::optional<ArrivalProductBindingIdentity> product_identity) {
    return ConfiguredArrivalBinding(std::move(identity),
                                    std::move(references),
                                    std::move(product_owner), product_kind,
                                    std::move(product_identity));
  }

  [[nodiscard]] static ResolvedTargetSet targets(
      std::vector<ResolvedTarget> values) {
    return ResolvedTargetSet(std::move(values));
  }

  [[nodiscard]] static InitialLawBinding initial_law(
      PhysicalBindingIdentity identity, ResolvedTransientInitialLaw law,
      std::shared_ptr<const void> product_owner,
      InitialCompiledProductKind product_kind,
      std::optional<ArrivalProductBindingIdentity> product_identity) {
    return InitialLawBinding(std::move(identity), std::move(law),
                             std::move(product_owner), product_kind,
                             std::move(product_identity));
  }

  [[nodiscard]] static ResolvedInstance publish(
      AuthoredModelConfig model, AnalysisSpec analysis,
      InputFingerprintBundle fingerprints, QueueCatalog queues,
      PriorityOrder priority, ConstraintDescriptor constraint,
      ServiceableMask serviceable, OptimizerBudgetPolicy optimizer_budget,
      ResolvedTargetSet targets, ConfiguredArrivalBinding arrival,
      QueueMask positive_arrival_support,
      std::optional<InitialLawBinding> initial_law,
      const TimingConvention timing) {
    const DerivedServiceIdentity identity = constraint.identity();
    return ResolvedInstance(
        std::move(model), std::move(analysis), std::move(fingerprints),
        std::move(queues), std::move(priority), std::move(constraint),
        identity, std::move(serviceable), std::move(optimizer_budget),
        std::move(targets), std::move(arrival),
        std::move(positive_arrival_support), std::move(initial_law), timing);
  }
};

}  // namespace detail

namespace {

class InternalArrivalCompilationToken final {
 public:
  InternalArrivalCompilationToken(PhysicalBindingIdentity binding,
                                  std::shared_ptr<const void> owner,
                                  ArrivalCompiledProductKind kind,
                                  std::optional<ArrivalProductBindingIdentity>
                                      product_identity)
      : binding_(std::move(binding)),
        owner_(std::move(owner)),
        kind_(kind),
        product_identity_(std::move(product_identity)) {}
  [[nodiscard]] const PhysicalBindingIdentity& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] const std::shared_ptr<const void>& owner() const noexcept {
    return owner_;
  }
  [[nodiscard]] ArrivalCompiledProductKind kind() const noexcept {
    return kind_;
  }
  [[nodiscard]] const std::optional<ArrivalProductBindingIdentity>&
  product_identity() const noexcept {
    return product_identity_;
  }

 private:
  PhysicalBindingIdentity binding_;
  std::shared_ptr<const void> owner_;
  ArrivalCompiledProductKind kind_;
  std::optional<ArrivalProductBindingIdentity> product_identity_;
};

class InternalInitialCompilationToken final {
 public:
  InternalInitialCompilationToken(PhysicalBindingIdentity binding,
                                  std::shared_ptr<const void> owner,
                                  InitialCompiledProductKind kind,
                                  std::optional<ArrivalProductBindingIdentity>
                                      product_identity)
      : binding_(std::move(binding)),
        owner_(std::move(owner)),
        kind_(kind),
        product_identity_(std::move(product_identity)) {}
  [[nodiscard]] const PhysicalBindingIdentity& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] const std::shared_ptr<const void>& owner() const noexcept {
    return owner_;
  }
  [[nodiscard]] InitialCompiledProductKind kind() const noexcept {
    return kind_;
  }
  [[nodiscard]] const std::optional<ArrivalProductBindingIdentity>&
  product_identity() const noexcept {
    return product_identity_;
  }

 private:
  PhysicalBindingIdentity binding_;
  std::shared_ptr<const void> owner_;
  InitialCompiledProductKind kind_;
  std::optional<ArrivalProductBindingIdentity> product_identity_;
};

[[nodiscard]] ArrivalProductBindingIdentity arrival_product_identity(
    const ArrivalBinding& binding) {
  return ArrivalProductBindingIdentity{
      binding.family, binding.timing, binding.queue_cardinality,
      binding.law_digest.value(), binding.catalog_digest.value()};
}

[[nodiscard]] bool product_identity_matches(
    const ArrivalProductBindingIdentity& product,
    const PhysicalBindingIdentity& physical) noexcept {
  return product.family == physical.arrival_family &&
         product.timing == physical.timing &&
         product.queue_cardinality == physical.queue_cardinality;
}

[[nodiscard]] bool product_identity_matches(
    const ArrivalProductBindingIdentity& product,
    const ArrivalBinding& binding) noexcept {
  return product.family == binding.family && product.timing == binding.timing &&
         product.queue_cardinality == binding.queue_cardinality &&
         product.law_digest == binding.law_digest.value() &&
         product.catalog_digest == binding.catalog_digest.value();
}

struct BoundArrivalInput final {
  PhysicalBindingIdentity identity;
  std::vector<BoundQueueReference> references;
};

struct ChildServices final {
  using ConstraintCompiler = std::function<Result<ConstraintDescriptor>(
      const AuthoredSchedulerConfig&, const QueueCatalog&)>;
  using ArrivalCompiler = std::function<Result<InternalArrivalCompilationToken>(
      const AuthoredArrivalConfig&, const PhysicalBindingIdentity&,
      std::span<const BoundQueueReference>,
      const QueueCatalog&)>;
  using SupportCompiler = std::function<Result<QueueMask>(
      const InternalArrivalCompilationToken&, const PhysicalBindingIdentity&,
      std::span<const BoundQueueReference>,
      const QueueCatalog&)>;
  using InitialCompiler = std::function<Result<InternalInitialCompilationToken>(
      const InternalArrivalCompilationToken&,
      const ResolvedTransientInitialLaw&, const PhysicalBindingIdentity&,
      std::span<const BoundQueueReference>,
      const QueueCatalog&)>;

  ConstraintCompiler constraint;
  ArrivalCompiler arrival;
  SupportCompiler support;
  InitialCompiler initial;
};

template <typename... Callables>
struct Overloaded : Callables... {
  using Callables::operator()...;
};
template <typename... Callables>
Overloaded(Callables...) -> Overloaded<Callables...>;

template <typename T>
[[nodiscard]] Result<T> fail(Diagnostic diagnostic) {
  return Result<T>::failure(std::move(diagnostic));
}

[[nodiscard]] Diagnostic diagnostic_at(
    const DiagnosticCategory category, std::string code, std::string message,
    const ModelProvenance& provenance,
    std::vector<std::string> notes = {}) {
  Diagnostic diagnostic{category,
                        std::move(code),
                        std::move(message),
                        std::nullopt,
                        provenance.json_pointer,
                        std::move(notes)};
  if (provenance.location.has_value()) {
    diagnostic.authored_path = provenance.location->authored_path;
    diagnostic.notes.push_back(
        "source line " + std::to_string(provenance.location->line) +
        ", column " + std::to_string(provenance.location->column));
  }
  return diagnostic;
}

[[nodiscard]] Diagnostic diagnostic_at(
    const DiagnosticCategory category, std::string code, std::string message,
    const SourceNode& source, std::vector<std::string> notes = {}) {
  return diagnostic_at(category, std::move(code), std::move(message),
                       authored_provenance(source), std::move(notes));
}

[[nodiscard]] Result<void> validate_fingerprint_binding(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis,
    const InputFingerprintBundle& supplied) {
  InputFingerprintBundle expected = supplied;
  try {
    expected = fingerprint_inputs(canonicalize_authored_inputs(model, analysis));
  } catch (const std::exception&) {
    return Result<void>::failure(diagnostic_at(
        DiagnosticCategory::internal, "input_fingerprint_validation_failed",
        "the authored input pair could not be canonicalized for fingerprint "
        "binding",
        model.provenance));
  } catch (...) {
    return Result<void>::failure(diagnostic_at(
        DiagnosticCategory::internal, "input_fingerprint_validation_failed",
        "the authored input pair could not be canonicalized for fingerprint "
        "binding",
        model.provenance));
  }

  if (expected == supplied) {
    return Result<void>::success();
  }

  std::vector<std::string> notes;
  if (expected.model != supplied.model) {
    notes.emplace_back("model digest does not match the authored model");
  }
  if (expected.analysis != supplied.analysis) {
    notes.emplace_back("analysis digest does not match the authored analysis");
  }
  if (expected.combined != supplied.combined) {
    notes.emplace_back("combined digest does not match the input pair");
  }
  notes.emplace_back("the supplied digest bundle was not replaced or repaired");
  return Result<void>::failure(diagnostic_at(
      DiagnosticCategory::internal, "input_fingerprint_mismatch",
      "the supplied input fingerprint bundle is not bound to the authored "
      "model and analysis",
      model.provenance, std::move(notes)));
}

[[nodiscard]] Result<const GeneralizedSwitchConfig*> generalized_switch(
    const AuthoredModelConfig& model) {
  if (const auto* generalized =
          std::get_if<GeneralizedSwitchConfig>(&model.switch_config)) {
    return Result<const GeneralizedSwitchConfig*>::success(generalized);
  }
  const auto& legacy =
      std::get<LegacyCrossbarSwitchConfig>(model.switch_config);
  return fail<const GeneralizedSwitchConfig*>(diagnostic_at(
      DiagnosticCategory::unavailable, "unsupported_switch_kind",
      "the analytical framework accepts only switch.kind=generalized",
      legacy.provenance,
      {"legacy_crossbar is retained by C03 only for this scope diagnostic"}));
}

[[nodiscard]] Result<void> validate_scheduler_scope(
    const AuthoredSchedulerConfig& scheduler) {
  return std::visit(
      Overloaded{
          [](const UnsupportedCompatibilityScheduler& value) {
            return Result<void>::failure(diagnostic_at(
                DiagnosticCategory::unavailable,
                "unsupported_scheduler_family",
                "the analytical framework accepts only the five exact "
                "MaxWeight scheduler families",
                value.provenance));
          },
          [](const CrossbarMaxWeightScheduler& value) {
            if (value.legacy_form || !value.constraint.value.has_value()) {
              return Result<void>::failure(diagnostic_at(
                  DiagnosticCategory::input_validation,
                  "scheduler_switch_incompatible",
                  "crossbar_max_weight must carry explicit generalized "
                  "constraint geometry",
                  value.provenance));
            }
            return Result<void>::success();
          },
          [](const auto&) { return Result<void>::success(); },
      },
      scheduler.value);
}

[[nodiscard]] ModelProvenance target_provenance(const TargetSet& targets,
                                                const std::size_t index) {
  const auto items = targets.source.array_items();
  if (index < items.size()) {
    return authored_provenance(items[index]);
  }
  ModelProvenance provenance = authored_provenance(targets.source);
  provenance.json_pointer += "/" + std::to_string(index);
  return provenance;
}

[[nodiscard]] Result<ResolvedTargetSet> bind_targets(
    const TargetSet& authored, const QueueCatalog& queues) {
  if (authored.queue_ids.empty()) {
    return fail<ResolvedTargetSet>(diagnostic_at(
        DiagnosticCategory::input_validation, "empty_target_set",
        "analysis targets must contain at least one queue", authored.source));
  }

  std::vector<std::uint8_t> seen(queues.size(), 0U);
  std::vector<ResolvedTarget> resolved;
  resolved.reserve(authored.queue_ids.size());
  for (std::size_t index = 0U; index < authored.queue_ids.size(); ++index) {
    ModelProvenance provenance = target_provenance(authored, index);
    auto queue = queues.resolve(QueueId(authored.queue_ids[index]), provenance);
    if (!queue) {
      return fail<ResolvedTargetSet>(queue.error());
    }
    const std::size_t ordinal = queue.value().ordinal();
    if (seen[ordinal] != 0U) {
      return fail<ResolvedTargetSet>(diagnostic_at(
          DiagnosticCategory::input_validation, "duplicate_target_queue",
          "an analysis target queue occurs more than once", provenance));
    }
    seen[ordinal] = 1U;
    resolved.push_back(
        ResolvedTarget{queue.value(), std::move(provenance)});
  }
  return Result<ResolvedTargetSet>::success(
      detail::ResolutionBuilder::targets(std::move(resolved)));
}

[[nodiscard]] Result<void> append_arrival_reference(
    const AuthoredField<QueueId>& authored, const QueueCatalog& queues,
    std::vector<BoundQueueReference>& output) {
  auto queue = queues.resolve(authored.value, authored.provenance);
  if (!queue) {
    return Result<void>::failure(queue.error());
  }
  output.push_back(BoundQueueReference{queue.value(), authored.provenance});
  return Result<void>::success();
}

[[nodiscard]] Result<BoundArrivalInput> bind_arrival(
    const AuthoredArrivalConfig& authored, const QueueCatalog& queues,
    const Digest256& combined_input) {
  std::vector<BoundQueueReference> references;
  std::optional<Diagnostic> failure;
  std::optional<ArrivalFamily> family;

  std::visit(
      Overloaded{
          [&](const DeterministicTraceArrival& arrival) {
            family = ArrivalFamily::deterministic_trace;
            references.reserve(arrival.events.value.size());
            for (const auto& event : arrival.events.value) {
              auto result = append_arrival_reference(event.queue_id, queues,
                                                     references);
              if (!result) {
                failure = result.error();
                break;
              }
            }
          },
          [&](const PeriodicGlobalPhaseArrival& arrival) {
            family = ArrivalFamily::periodic_global_phase;
            for (const auto& source : arrival.sources.value) {
              for (const auto& entry : source.entries.value) {
                auto result = append_arrival_reference(entry.queue_id, queues,
                                                       references);
                if (!result) {
                  failure = result.error();
                  return;
                }
              }
            }
          },
          [&](const PeriodicSourceDelaysArrival& arrival) {
            family = ArrivalFamily::periodic_source_delays;
            for (const auto& source : arrival.sources.value) {
              for (const auto& entry : source.entries.value) {
                auto result = append_arrival_reference(entry.queue_id, queues,
                                                       references);
                if (!result) {
                  failure = result.error();
                  return;
                }
              }
            }
          },
          [&](const IndependentMarkedRenewalArrival& arrival) {
            family = ArrivalFamily::independent_marked_renewal;
            for (const auto& source : arrival.sources.value) {
              std::visit(
                  Overloaded{
                      [&](const FactorizedRenewalSource& factorized) {
                        for (const auto& mass :
                             factorized.destination_pmf.value) {
                          auto result = append_arrival_reference(
                              mass.queue_id, queues, references);
                          if (!result) {
                            failure = result.error();
                            return;
                          }
                        }
                      },
                      [&](const JointRenewalSource& joint) {
                        for (const auto& mass : joint.joint_pmf.value) {
                          auto result = append_arrival_reference(
                              mass.queue_id, queues, references);
                          if (!result) {
                            failure = result.error();
                            return;
                          }
                        }
                      },
                  },
                  source);
              if (failure.has_value()) {
                return;
              }
            }
          },
          [&](const IndependentPrivateMarkovRenewalArrival& arrival) {
            family = ArrivalFamily::independent_private_markov_renewal;
            for (const auto& source : arrival.sources.value) {
              for (const auto& mass : source.destination_pmf.value) {
                auto result = append_arrival_reference(mass.queue_id, queues,
                                                       references);
                if (!result) {
                  failure = result.error();
                  return;
                }
              }
            }
          },
          [&](const SharedJointRoundMarkovRenewalArrival& arrival) {
            family = ArrivalFamily::shared_joint_round_markov_renewal;
            for (const auto& outcome : arrival.outcomes.value) {
              for (const auto& emission : outcome.emissions.value) {
                auto result = append_arrival_reference(
                    emission.queue_id, queues, references);
                if (!result) {
                  failure = result.error();
                  return;
                }
              }
            }
          },
          [&](const IidIndependentBernoulliArrival& arrival) {
            family = ArrivalFamily::iid_independent_bernoulli;
            references.reserve(arrival.rates.overrides.value.size());
            for (const QueueRateOverride& item :
                 arrival.rates.overrides.value) {
              auto result = append_arrival_reference(item.queue_id, queues,
                                                     references);
              if (!result) {
                failure = result.error();
                return;
              }
            }
          },
          [&](const IidCountTableArrival& arrival) {
            family = ArrivalFamily::iid_count_table;
            for (const IidCountOutcome& outcome : arrival.outcomes.value) {
              for (const IidCountEntry& count : outcome.counts.value) {
                auto result = append_arrival_reference(count.queue_id, queues,
                                                       references);
                if (!result) {
                  failure = result.error();
                  return;
                }
              }
            }
          },
          [&](const IidIndependentPoissonArrival& arrival) {
            family = ArrivalFamily::iid_independent_poisson;
            references.reserve(arrival.rates.overrides.value.size());
            for (const QueueRateOverride& item :
                 arrival.rates.overrides.value) {
              auto result = append_arrival_reference(item.queue_id, queues,
                                                     references);
              if (!result) {
                failure = result.error();
                return;
              }
            }
          },
          [&](const IidMixedPoissonArrival& arrival) {
            family = ArrivalFamily::iid_mixed_poisson;
            references.reserve(arrival.rates.overrides.value.size());
            for (const QueueRateOverride& item :
                 arrival.rates.overrides.value) {
              auto result = append_arrival_reference(item.queue_id, queues,
                                                     references);
              if (!result) {
                failure = result.error();
                return;
              }
            }
          },
          [&](const UnsupportedCompatibilityArrival& arrival) {
            failure = diagnostic_at(
                DiagnosticCategory::unavailable,
                "unsupported_arrival_family",
                "the analytical framework accepts only registered native "
                "count-law arrival families",
                arrival.provenance);
          },
      },
      authored.value);

  if (failure.has_value()) {
    return fail<BoundArrivalInput>(std::move(*failure));
  }
  if (!family.has_value()) {
    return fail<BoundArrivalInput>(diagnostic_at(
        DiagnosticCategory::internal, "arrival_family_not_bound",
        "the authored arrival did not resolve to a closed C04 family",
        authored.provenance));
  }
  return Result<BoundArrivalInput>::success(BoundArrivalInput{
      .identity = PhysicalBindingIdentity{
          .combined_input = combined_input,
          .arrival_family = *family,
          .timing = TimingConvention::early_service_late_admission,
          .queue_cardinality = queues.size(),
      },
      .references = std::move(references),
  });
}

[[nodiscard]] Result<void> validate_observation_targets(
    const AuthoredTelemetryConfig& telemetry, const QueueCatalog& queues) {
  if (!telemetry.observation.has_value()) {
    return Result<void>::success();
  }
  std::vector<std::uint8_t> seen(queues.size(), 0U);
  for (const AuthoredObservationTarget& target :
       telemetry.observation->targets.value) {
    auto queue = queues.resolve(target.queue_id.value,
                                target.queue_id.provenance);
    if (!queue) {
      return Result<void>::failure(queue.error());
    }
    if (seen[queue.value().ordinal()] != 0U) {
      return Result<void>::failure(diagnostic_at(
          DiagnosticCategory::input_validation,
          "duplicate_observation_target",
          "telemetry.observation may name each resolved queue at most once",
          target.queue_id.provenance));
    }
    seen[queue.value().ordinal()] = 1U;
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::optional<ResolvedTransientInitialLaw>>
bind_transient_initial_law(const AnalysisSpec& analysis,
                           const QueueCatalog& queues) {
  const auto* transient =
      std::get_if<TransientSelection>(&analysis.context->selection);
  if (transient == nullptr) {
    return Result<std::optional<ResolvedTransientInitialLaw>>::success(
        std::nullopt);
  }

  std::vector<ResolvedTransientInitialAtom> atoms;
  atoms.reserve(transient->atoms.size());
  for (const auto& atom : transient->atoms) {
    std::vector<BigNat> backlog;
    backlog.reserve(queues.size());
    for (std::size_t index = 0U; index < queues.size(); ++index) {
      backlog.emplace_back(std::uint64_t{0U});
    }
    std::vector<std::uint8_t> seen(queues.size(), 0U);
    std::vector<ResolvedBacklogEntry> authored_backlog;
    authored_backlog.reserve(atom.backlog.size());
    for (const auto& entry : atom.backlog) {
      // C03 retains the complete record because queue_id and value are already
      // typed.  Recover the queue leaf here so an otherwise valid transient
      // atom reports a failed catalog binding at the authored reference itself.
      const SourceNode* queue_source = entry.source.find("queue_id");
      if (queue_source == nullptr) {
        queue_source = &entry.source;
      }
      const ModelProvenance provenance = authored_provenance(*queue_source);
      auto queue = queues.resolve(QueueId(entry.queue_id), provenance);
      if (!queue) {
        return fail<std::optional<ResolvedTransientInitialLaw>>(queue.error());
      }
      const std::size_t ordinal = queue.value().ordinal();
      if (seen[ordinal] != 0U) {
        return fail<std::optional<ResolvedTransientInitialLaw>>(diagnostic_at(
            DiagnosticCategory::input_validation,
            "duplicate_initial_backlog_queue",
            "a transient initial atom names a backlog queue more than once",
            entry.source));
      }
      seen[ordinal] = 1U;
      backlog[ordinal] = entry.value;
      authored_backlog.push_back(
          ResolvedBacklogEntry{queue.value(), entry.value, *queue_source});
    }
    if (std::ranges::any_of(seen,
                            [](const std::uint8_t value) { return value == 0U; })) {
      return fail<std::optional<ResolvedTransientInitialLaw>>(diagnostic_at(
          DiagnosticCategory::input_validation,
          "incomplete_initial_backlog",
          "each transient initial atom must name every resolved queue exactly "
          "once",
          atom.source));
    }

    const SourceNode* probability_source = atom.source.find("probability");
    if (probability_source == nullptr) {
      probability_source = &atom.source;
    }
    const SourceNode* arrival_state_source = atom.source.find("arrival_state");
    if (arrival_state_source == nullptr) {
      arrival_state_source = &atom.source;
    }
    atoms.push_back(ResolvedTransientInitialAtom{
        .probability = atom.probability,
        .probability_source = *probability_source,
        .backlog = std::move(backlog),
        .authored_backlog = std::move(authored_backlog),
        .arrival_state = atom.arrival_state,
        .arrival_state_source = *arrival_state_source,
        .controller_state = atom.controller_state,
        .static_context = atom.static_context,
        .surrogate_initial = atom.surrogate_initial,
        .source = atom.source,
    });
  }
  return Result<std::optional<ResolvedTransientInitialLaw>>::success(
      ResolvedTransientInitialLaw{std::move(atoms), transient->source});
}

[[nodiscard]] std::optional<BigNat> physical_per_call_cap(
    const AuthoredSchedulerConfig& scheduler) {
  return std::visit(
      Overloaded{
          [](const ConflictGraphMaxWeightScheduler& value) {
            return value.max_search_states.value;
          },
          [](const ResourcePackingMaxWeightScheduler& value) {
            return value.max_search_states.value;
          },
          [](const auto&) { return std::optional<BigNat>{}; },
      },
      scheduler.value);
}

[[nodiscard]] std::optional<BigNat> minimum_cap(
    const std::optional<BigNat>& first, const std::optional<BigNat>& second) {
  if (!first.has_value()) {
    return second;
  }
  if (!second.has_value()) {
    return first;
  }
  return *first < *second ? first : second;
}

[[nodiscard]] OptimizerBudgetPolicy optimizer_budget(
    const AuthoredSchedulerConfig& scheduler,
    const OptimizerResolution& resolution) {
  const std::optional<BigNat> physical = physical_per_call_cap(scheduler);
  const std::optional<BigNat> analysis =
      resolution.max_search_states_per_call;
  return OptimizerBudgetPolicy{
      .physical_per_call = physical,
      .analysis_per_call = analysis,
      .effective_per_call = minimum_cap(physical, analysis),
      .max_calls = resolution.max_calls,
  };
}

[[nodiscard]] Diagnostic c09_unavailable(const std::string& code,
                                          const std::string& operation) {
  return Diagnostic{
      DiagnosticCategory::unavailable,
      code,
      "the C09 arrival " + operation + " child is not yet available",
      std::nullopt,
      std::nullopt,
      {},
  };
}

[[nodiscard]] ChildServices registered_children() {
  ChildServices children;
  children.constraint = compile_constraint_descriptor;
  children.arrival = [](const AuthoredArrivalConfig& authored,
                        const PhysicalBindingIdentity& identity,
                        std::span<const BoundQueueReference>,
                        const QueueCatalog& queues) {
    auto compiled = compile_arrival_law(authored, queues);
    if (!compiled) {
      return Result<InternalArrivalCompilationToken>::failure(
          compiled.error());
    }
    const ArrivalBinding& compiled_binding =
        arrival_law_binding(compiled.value());
    const ArrivalProductBindingIdentity product_identity =
        arrival_product_identity(compiled_binding);
    auto expected_catalog_digest = detail::digest_queue_catalog(queues);
    if (!expected_catalog_digest) {
      return Result<InternalArrivalCompilationToken>::failure(
          expected_catalog_digest.error());
    }
    if (!product_identity_matches(product_identity, identity) ||
        product_identity.catalog_digest !=
            expected_catalog_digest.value().value()) {
      return Result<InternalArrivalCompilationToken>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "arrival_compilation_binding_mismatch",
          "the C09 arrival compiler returned a law for another physical "
          "binding",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    try {
      auto owner = std::make_shared<const CompiledArrivalLaw>(
          std::move(compiled.value()));
      return Result<InternalArrivalCompilationToken>::success(
          InternalArrivalCompilationToken(
              identity, std::move(owner),
              ArrivalCompiledProductKind::compiled_arrival_law_v1,
              product_identity));
    } catch (const std::bad_alloc&) {
      return Result<InternalArrivalCompilationToken>::failure(Diagnostic{
          DiagnosticCategory::resource_limit,
          "arrival_compilation_product_allocation_failure",
          "retaining the compiled arrival law exhausted memory",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
  };
  children.support = [](const InternalArrivalCompilationToken& token,
                        const PhysicalBindingIdentity& identity,
                        std::span<const BoundQueueReference>,
                        const QueueCatalog& queues) {
    if (token.binding() != identity ||
        identity.queue_cardinality != queues.size() ||
        token.kind() !=
            ArrivalCompiledProductKind::compiled_arrival_law_v1 ||
        !token.product_identity().has_value() ||
        !product_identity_matches(*token.product_identity(), identity)) {
      return Result<QueueMask>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "arrival_support_binding_mismatch",
          "positive arrival support was requested with another physical "
          "binding",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    auto expected_catalog_digest = detail::digest_queue_catalog(queues);
    if (!expected_catalog_digest ||
        token.product_identity()->catalog_digest !=
            expected_catalog_digest.value().value()) {
      return Result<QueueMask>::failure(
          expected_catalog_digest
              ? Diagnostic{DiagnosticCategory::internal,
                           "arrival_support_binding_mismatch",
                           "positive arrival support was requested with "
                           "another queue catalog",
                           std::nullopt,
                           std::nullopt,
                           {}}
              : expected_catalog_digest.error());
    }
    const auto owner =
        std::static_pointer_cast<const CompiledArrivalLaw>(token.owner());
    if (!product_identity_matches(*token.product_identity(),
                                  arrival_law_binding(*owner))) {
      return Result<QueueMask>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "arrival_support_binding_mismatch",
          "the retained arrival product does not match its C09 identity",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    return Result<QueueMask>::success(positive_arrival_support(*owner));
  };
  children.initial = [](const InternalArrivalCompilationToken& token,
                        const ResolvedTransientInitialLaw& resolved,
                        const PhysicalBindingIdentity& identity,
                        std::span<const BoundQueueReference>,
                        const QueueCatalog& queues) {
    if (token.binding() != identity ||
        identity.queue_cardinality != queues.size() ||
        token.kind() !=
            ArrivalCompiledProductKind::compiled_arrival_law_v1 ||
        !token.product_identity().has_value() ||
        !product_identity_matches(*token.product_identity(), identity)) {
      return Result<InternalInitialCompilationToken>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "initial_law_binding_mismatch",
          "the initial physical law was requested with another physical "
          "binding",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    auto expected_catalog_digest = detail::digest_queue_catalog(queues);
    if (!expected_catalog_digest ||
        token.product_identity()->catalog_digest !=
            expected_catalog_digest.value().value()) {
      return Result<InternalInitialCompilationToken>::failure(
          expected_catalog_digest
              ? Diagnostic{DiagnosticCategory::internal,
                           "initial_law_binding_mismatch",
                           "the initial physical law was requested with "
                           "another queue catalog",
                           std::nullopt,
                           std::nullopt,
                           {}}
              : expected_catalog_digest.error());
    }
    const auto arrival =
        std::static_pointer_cast<const CompiledArrivalLaw>(token.owner());
    if (!product_identity_matches(*token.product_identity(),
                                  arrival_law_binding(*arrival))) {
      return Result<InternalInitialCompilationToken>::failure(Diagnostic{
          DiagnosticCategory::internal,
          "initial_law_binding_mismatch",
          "the retained arrival product does not match its C09 identity",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    auto initial = compile_initial_physical_law(resolved, *arrival);
    if (!initial) {
      return Result<InternalInitialCompilationToken>::failure(initial.error());
    }
    try {
      if (!product_identity_matches(*token.product_identity(),
                                    initial.value().arrival_binding())) {
        return Result<InternalInitialCompilationToken>::failure(Diagnostic{
            DiagnosticCategory::internal,
            "initial_law_binding_mismatch",
            "the compiled initial law does not match its arrival product",
            std::nullopt,
            std::nullopt,
            {},
        });
      }
      auto owner = std::make_shared<const InitialPhysicalLaw>(
          std::move(initial.value()));
      return Result<InternalInitialCompilationToken>::success(
          InternalInitialCompilationToken(
              identity, std::move(owner),
              InitialCompiledProductKind::initial_physical_law_v1,
              token.product_identity()));
    } catch (const std::bad_alloc&) {
      return Result<InternalInitialCompilationToken>::failure(Diagnostic{
          DiagnosticCategory::resource_limit,
          "initial_law_product_allocation_failure",
          "retaining the compiled initial physical law exhausted memory",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
  };
  return children;
}

[[nodiscard]] Result<ResolvedInstance> resolve_with_children(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis,
    const InputFingerprintBundle& fingerprints,
    const ChildServices& children) {
  auto fingerprint_check =
      validate_fingerprint_binding(model, analysis, fingerprints);
  if (!fingerprint_check) {
    return fail<ResolvedInstance>(fingerprint_check.error());
  }

  auto generalized = generalized_switch(model);
  if (!generalized) {
    return fail<ResolvedInstance>(generalized.error());
  }

  auto queues = build_queue_catalog(model.switch_config);
  if (!queues) {
    return fail<ResolvedInstance>(queues.error());
  }

  if (model.schema_version.value == kPhysicalSchemaVersionV4 &&
      generalized.value()->queue_capacity.value.has_value()) {
    return fail<ResolvedInstance>(diagnostic_at(
        DiagnosticCategory::unavailable,
        "schema4_finite_queue_capacity_unsupported",
        "the schema-4 analytical route requires queue_capacity='NoDrop'",
        generalized.value()->queue_capacity.provenance,
        {"finite-buffer drop dynamics are not substituted by a lossless law"}));
  }

  auto observation_targets =
      validate_observation_targets(model.telemetry, queues.value());
  if (!observation_targets) {
    return fail<ResolvedInstance>(observation_targets.error());
  }

  // queue_capacity is an identity-bound declaration carried through to C15's
  // FrameworkProblemView.  Resolution deliberately does not install finite-
  // buffer truncation or drop dynamics: the integration contract requires
  // the caller to oversize the declared buffer and externally establish that
  // no drop occurs, leaving the existing lossless queue evolution unchanged.
  auto scheduler_scope = validate_scheduler_scope(model.scheduler);
  if (!scheduler_scope) {
    return fail<ResolvedInstance>(scheduler_scope.error());
  }

  auto priority = resolve_priority(model.scheduler, queues.value());
  if (!priority) {
    return fail<ResolvedInstance>(priority.error());
  }

  auto constraint = children.constraint
                        ? children.constraint(model.scheduler, queues.value())
                        : compile_constraint_descriptor(model.scheduler,
                                                        queues.value());
  if (!constraint) {
    return fail<ResolvedInstance>(constraint.error());
  }

  ServiceableMask serviceable =
      compute_individual_serviceability(constraint.value());
  if (!serviceable.all()) {
    for (std::size_t index = 0U; index < queues.value().size(); ++index) {
      auto queue = queues.value().index_at(index);
      if (!queue) {
        return fail<ResolvedInstance>(queue.error());
      }
      if (!serviceable.at(queue.value())) {
        return fail<ResolvedInstance>(diagnostic_at(
            DiagnosticCategory::unavailable,
            "queue_not_individually_serviceable",
            "every queue must have a feasible singleton service schedule",
            queues.value().entry(queue.value()).provenance,
            {"the queue is retained even when its positive arrival support is "
             "zero"}));
      }
    }
    return fail<ResolvedInstance>(Diagnostic{
        DiagnosticCategory::internal,
        "serviceability_mask_inconsistent",
        "the serviceability mask reported a failure without a queue index",
        std::nullopt,
        std::nullopt,
        {},
    });
  }

  if (!analysis.context) {
    return fail<ResolvedInstance>(diagnostic_at(
        DiagnosticCategory::internal, "analysis_context_missing",
        "the C03 analysis object has no immutable analysis context",
        analysis.source));
  }
  auto targets = bind_targets(analysis.context->targets, queues.value());
  if (!targets) {
    return fail<ResolvedInstance>(targets.error());
  }

  auto arrival =
      bind_arrival(model.arrival, queues.value(), fingerprints.combined);
  if (!arrival) {
    return fail<ResolvedInstance>(arrival.error());
  }

  auto transient = bind_transient_initial_law(analysis, queues.value());
  if (!transient) {
    return fail<ResolvedInstance>(transient.error());
  }

  const OptimizerBudgetPolicy budget =
      optimizer_budget(model.scheduler, analysis.context->resolution.optimizer);

  if (!children.arrival) {
    return fail<ResolvedInstance>(c09_unavailable(
        "arrival_compiler_unavailable_c09", "compiler"));
  }
  auto compilation = children.arrival(
      model.arrival, arrival.value().identity, arrival.value().references,
      queues.value());
  if (!compilation) {
    return fail<ResolvedInstance>(compilation.error());
  }
  if (!compilation.value().owner()) {
    return fail<ResolvedInstance>(Diagnostic{
        DiagnosticCategory::internal,
        "null_arrival_compilation_product",
        "the arrival compiler succeeded without an owned compiled product",
        std::nullopt,
        std::nullopt,
        {},
    });
  }
  if (compilation.value().binding() != arrival.value().identity) {
    return fail<ResolvedInstance>(Diagnostic{
        DiagnosticCategory::internal,
        "arrival_compilation_binding_mismatch",
        "the arrival compiler returned a product for another physical binding",
        std::nullopt,
        std::nullopt,
        {},
    });
  }
  if (compilation.value().kind() ==
          ArrivalCompiledProductKind::compiled_arrival_law_v1 &&
      (!compilation.value().product_identity().has_value() ||
       !product_identity_matches(*compilation.value().product_identity(),
                                 arrival.value().identity))) {
    return fail<ResolvedInstance>(Diagnostic{
        DiagnosticCategory::internal,
        "arrival_compilation_binding_mismatch",
        "the C09 arrival product omitted or mismatched its typed identity",
        std::nullopt,
        std::nullopt,
        {},
    });
  }

  if (!children.support) {
    return fail<ResolvedInstance>(c09_unavailable(
        "arrival_support_unavailable_c09", "positive-support"));
  }
  auto support = children.support(
      compilation.value(), arrival.value().identity,
      arrival.value().references, queues.value());
  if (!support) {
    return fail<ResolvedInstance>(support.error());
  }
  if (support.value().size() != queues.value().size()) {
    return fail<ResolvedInstance>(Diagnostic{
        DiagnosticCategory::internal,
        "arrival_support_dimension_mismatch",
        "the arrival support mask does not match the resolved queue catalog",
        std::nullopt,
        std::nullopt,
        {},
    });
  }

  std::optional<InitialLawBinding> initial_law;
  if (transient.value().has_value()) {
    if (!children.initial) {
      return fail<ResolvedInstance>(c09_unavailable(
          "initial_law_compiler_unavailable_c09", "initial-law compiler"));
    }
    auto initial_result = children.initial(
        compilation.value(), *transient.value(), arrival.value().identity,
        arrival.value().references, queues.value());
    if (!initial_result) {
      return fail<ResolvedInstance>(initial_result.error());
    }
    if (!initial_result.value().owner()) {
      return fail<ResolvedInstance>(Diagnostic{
          DiagnosticCategory::internal,
          "null_initial_compilation_product",
          "the initial-law compiler succeeded without an owned product",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    if (initial_result.value().binding() != arrival.value().identity) {
      return fail<ResolvedInstance>(Diagnostic{
          DiagnosticCategory::internal,
          "initial_compilation_binding_mismatch",
          "the initial-law compiler returned a product for another physical "
          "binding",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    if (initial_result.value().kind() ==
            InitialCompiledProductKind::initial_physical_law_v1 &&
        (!initial_result.value().product_identity().has_value() ||
         !product_identity_matches(*initial_result.value().product_identity(),
                                   arrival.value().identity) ||
         initial_result.value().product_identity() !=
             compilation.value().product_identity())) {
      return fail<ResolvedInstance>(Diagnostic{
          DiagnosticCategory::internal,
          "initial_compilation_binding_mismatch",
          "the C09 initial-law product omitted or mismatched its typed "
          "arrival identity",
          std::nullopt,
          std::nullopt,
          {},
      });
    }
    initial_law = detail::ResolutionBuilder::initial_law(
        arrival.value().identity, std::move(*transient.value()),
        initial_result.value().owner(), initial_result.value().kind(),
        initial_result.value().product_identity());
  }

  ConfiguredArrivalBinding configured_arrival =
      detail::ResolutionBuilder::configured_arrival(
          arrival.value().identity, std::move(arrival.value().references),
          compilation.value().owner(), compilation.value().kind(),
          compilation.value().product_identity());

  return Result<ResolvedInstance>::success(
      detail::ResolutionBuilder::publish(
          model, analysis, fingerprints, std::move(queues.value()),
          std::move(priority.value()), std::move(constraint.value()),
          std::move(serviceable), budget, std::move(targets.value()),
          std::move(configured_arrival), std::move(support.value()),
          std::move(initial_law),
      TimingConvention::early_service_late_admission));
}

}  // namespace

#if defined(MWPERF_C04_TEST_SEAMS)
Result<detail::ArrivalCompilationToken>
detail::ArrivalCompilationToken::for_fixture(
    PhysicalBindingIdentity binding, std::shared_ptr<const void> owner) {
  if (!owner) {
    return Result<ArrivalCompilationToken>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "null_arrival_compilation_fixture",
        "an arrival compilation fixture must own a non-null product",
        std::nullopt,
        std::nullopt,
        {},
    });
  }
  return Result<ArrivalCompilationToken>::success(
      ArrivalCompilationToken(std::move(binding), std::move(owner)));
}

Result<detail::InitialCompilationToken>
detail::InitialCompilationToken::for_fixture(
    PhysicalBindingIdentity binding, std::shared_ptr<const void> owner) {
  if (!owner) {
    return Result<InitialCompilationToken>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "null_initial_compilation_fixture",
        "an initial-law compilation fixture must own a non-null product",
        std::nullopt,
        std::nullopt,
        {},
    });
  }
  return Result<InitialCompilationToken>::success(
      InitialCompilationToken(std::move(binding), std::move(owner)));
}

Result<ResolvedInstance> detail::resolve_physical_instance_with_child_services(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis,
    const InputFingerprintBundle& fingerprints,
    const ResolutionChildServices& children) {
  ChildServices internal;
  internal.constraint = children.constraint;
  if (children.arrival) {
    internal.arrival = [&children](
                                   const AuthoredArrivalConfig& arrival,
                                   const PhysicalBindingIdentity& identity,
                                   std::span<const BoundQueueReference> references,
                                   const QueueCatalog& queues) {
      auto token = children.arrival(arrival, identity, references, queues);
      if (!token) {
        return Result<InternalArrivalCompilationToken>::failure(token.error());
      }
      return Result<InternalArrivalCompilationToken>::success(
          InternalArrivalCompilationToken(
              token.value().binding(), token.value().owner_for_adapter(),
              ArrivalCompiledProductKind::opaque_test_fixture,
              std::nullopt));
    };
  }
  if (children.support) {
    internal.support = [&children](
                           const InternalArrivalCompilationToken& token,
                           const PhysicalBindingIdentity& identity,
                           std::span<const BoundQueueReference> references,
                           const QueueCatalog& queues) {
      auto external = ArrivalCompilationToken::for_fixture(token.binding(),
                                                           token.owner());
      if (!external) {
        return Result<QueueMask>::failure(external.error());
      }
      return children.support(external.value(), identity, references, queues);
    };
  }
  if (children.initial) {
    internal.initial = [&children](
                           const InternalArrivalCompilationToken& token,
                           const ResolvedTransientInitialLaw& law,
                           const PhysicalBindingIdentity& identity,
                           std::span<const BoundQueueReference> references,
                           const QueueCatalog& queues) {
      auto external = ArrivalCompilationToken::for_fixture(token.binding(),
                                                           token.owner());
      if (!external) {
        return Result<InternalInitialCompilationToken>::failure(
            external.error());
      }
      auto initial =
          children.initial(external.value(), law, identity, references, queues);
      if (!initial) {
        return Result<InternalInitialCompilationToken>::failure(
            initial.error());
      }
      return Result<InternalInitialCompilationToken>::success(
          InternalInitialCompilationToken(
              initial.value().binding(),
              initial.value().owner_for_adapter(),
              InitialCompiledProductKind::opaque_test_fixture,
              std::nullopt));
    };
  }
  return resolve_with_children(model, analysis, fingerprints, internal);
}
#endif

Result<ResolvedInstance> resolve_physical_instance(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis,
    const InputFingerprintBundle& fingerprints) {
  const ChildServices children = registered_children();
  return resolve_with_children(model, analysis, fingerprints, children);
}

}  // namespace mwperf
