#include "mwperf/model/priority_order.hpp"

#include <concepts>
#include <cstddef>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic_at(const DiagnosticCategory category,
                                       std::string code,
                                       std::string message,
                                       const ModelProvenance& provenance,
                                       std::vector<std::string> notes = {}) {
  std::optional<std::string> path;
  if (provenance.location.has_value()) {
    path = provenance.location->authored_path;
    notes.insert(notes.begin(),
                 "line " + std::to_string(provenance.location->line) +
                     ", column " +
                     std::to_string(provenance.location->column));
  }
  return Diagnostic{category,
                    std::move(code),
                    std::move(message),
                    std::move(path),
                    provenance.json_pointer,
                    std::move(notes)};
}

[[nodiscard]] Result<const AuthoredPriority*> scheduler_priority(
    const AuthoredSchedulerConfig& scheduler) {
  return std::visit(
      [&scheduler](const auto& value) -> Result<const AuthoredPriority*> {
        using Scheduler = std::decay_t<decltype(value)>;
        if constexpr (std::same_as<Scheduler,
                                   UnsupportedCompatibilityScheduler>) {
          return Result<const AuthoredPriority*>::failure(diagnostic_at(
              DiagnosticCategory::unavailable, "unsupported_scheduler",
              "the scheduler does not define the deterministic exact "
              "priority required by the analytical framework",
              scheduler.provenance));
        } else {
          return Result<const AuthoredPriority*>::success(&value.priority);
        }
      },
      scheduler.value);
}

}  // namespace

DenseQueueIndex PriorityOrder::queue_at_rank(const std::size_t rank) const {
  return rank_to_queue_.at(rank);
}

std::size_t PriorityOrder::rank_of(const DenseQueueIndex queue) const {
  return queue_to_rank_.at(queue.ordinal());
}

bool PriorityOrder::is_catalog_order() const noexcept {
  for (std::size_t rank = 0; rank < rank_to_queue_.size(); ++rank) {
    if (rank_to_queue_[rank].ordinal() != rank ||
        queue_to_rank_[rank] != rank) {
      return false;
    }
  }
  return true;
}

Result<PriorityOrder> resolve_priority(
    const AuthoredSchedulerConfig& authored_scheduler,
    const QueueCatalog& queues) {
  Result<const AuthoredPriority*> extracted =
      scheduler_priority(authored_scheduler);
  if (!extracted) {
    return Result<PriorityOrder>::failure(std::move(extracted.error()));
  }
  const AuthoredPriority& priority = *extracted.value();

  std::vector<DenseQueueIndex> rank_to_queue;
  rank_to_queue.reserve(queues.size());
  std::vector<std::size_t> queue_to_rank(queues.size(), 0U);

  if (!priority.value.has_value()) {
    for (std::size_t rank = 0; rank < queues.size(); ++rank) {
      Result<DenseQueueIndex> dense = queues.index_at(rank);
      if (!dense) {
        return Result<PriorityOrder>::failure(std::move(dense.error()));
      }
      rank_to_queue.push_back(dense.value());
      queue_to_rank[rank] = rank;
    }
    return Result<PriorityOrder>::success(PriorityOrder(
        std::move(rank_to_queue), std::move(queue_to_rank)));
  }

  const auto& authored_order = *priority.value;
  if (authored_order.size() != queues.size()) {
    return Result<PriorityOrder>::failure(diagnostic_at(
        DiagnosticCategory::input_validation, "priority_length_mismatch",
        "an explicit scheduler priority must contain exactly one reference "
        "for every catalog queue",
        priority.provenance,
        {"catalog queues: " + std::to_string(queues.size()),
         "priority entries: " + std::to_string(authored_order.size())}));
  }

  std::vector<std::optional<std::size_t>> first_rank(queues.size());
  for (std::size_t rank = 0; rank < authored_order.size(); ++rank) {
    const AuthoredField<QueueId>& authored = authored_order[rank];
    Result<DenseQueueIndex> dense =
        queues.resolve(authored.value, authored.provenance);
    if (!dense) {
      return Result<PriorityOrder>::failure(std::move(dense.error()));
    }
    const std::size_t ordinal = dense.value().ordinal();
    if (first_rank[ordinal].has_value()) {
      return Result<PriorityOrder>::failure(diagnostic_at(
          DiagnosticCategory::input_validation, "duplicate_priority_queue",
          "an explicit scheduler priority must be a queue permutation",
          authored.provenance,
          {"first priority rank: " +
           std::to_string(*first_rank[ordinal])}));
    }
    first_rank[ordinal] = rank;
    queue_to_rank[ordinal] = rank;
    rank_to_queue.push_back(dense.value());
  }

  return Result<PriorityOrder>::success(PriorityOrder(
      std::move(rank_to_queue), std::move(queue_to_rank)));
}

}  // namespace mwperf
