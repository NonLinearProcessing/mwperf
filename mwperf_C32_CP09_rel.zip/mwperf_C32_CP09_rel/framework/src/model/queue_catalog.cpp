#include "mwperf/model/queue_catalog.hpp"

#include <cstddef>
#include <optional>
#include <string>
#include <utility>
#include <variant>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic_at(const DiagnosticCategory category,
                                       std::string code,
                                       std::string message,
                                       const ModelProvenance& provenance,
                                       std::vector<std::string> notes = {}) {
  std::optional<std::string> path;
  if (provenance.location.has_value()) {
    path = provenance.location->authored_path;
    notes.insert(notes.begin(),
                 "line " + std::to_string(provenance.location->line) +
                     ", column " +
                     std::to_string(provenance.location->column));
  }
  return Diagnostic{category,
                    std::move(code),
                    std::move(message),
                    std::move(path),
                    provenance.json_pointer,
                    std::move(notes)};
}

[[nodiscard]] Diagnostic legacy_switch_diagnostic(
    const LegacyCrossbarSwitchConfig& legacy) {
  return diagnostic_at(
      DiagnosticCategory::unavailable, "unsupported_switch_kind",
      "the analytical framework requires switch.kind=generalized; "
      "legacy_crossbar is outside the C04 physical scope",
      legacy.provenance);
}

}  // namespace

const QueueCatalogEntry& QueueCatalog::entry(const DenseQueueIndex index) const {
  return entries_.at(index.ordinal());
}

const QueueId& QueueCatalog::queue_id(const DenseQueueIndex index) const {
  return entry(index).id;
}

Result<DenseQueueIndex> QueueCatalog::index_at(
    const std::size_t ordinal) const {
  // Deliberately pass through C02's sole approved mathematical-to-index
  // boundary, even though this caller begins with a native traversal value.
  Result<std::size_t> checked = checked_index(BigNat(ordinal), entries_.size());
  if (!checked) {
    return Result<DenseQueueIndex>::failure(std::move(checked.error()));
  }
  return Result<DenseQueueIndex>::success(
      make_dense_index(checked.value()));
}

Result<DenseQueueIndex> QueueCatalog::resolve(
    const QueueId& id, const ModelProvenance& reference) const {
  const auto found = reverse_.find(id);
  if (found == reverse_.end()) {
    return Result<DenseQueueIndex>::failure(diagnostic_at(
        DiagnosticCategory::input_validation, "unknown_queue_reference",
        "the authored queue reference is not present in switch.queues",
        reference));
  }
  return Result<DenseQueueIndex>::success(found->second);
}

Result<QueueCatalog> build_queue_catalog(
    const AuthoredSwitchConfig& authored_switch) {
  if (const auto* legacy =
          std::get_if<LegacyCrossbarSwitchConfig>(&authored_switch)) {
    return Result<QueueCatalog>::failure(legacy_switch_diagnostic(*legacy));
  }

  const auto& generalized = std::get<GeneralizedSwitchConfig>(authored_switch);
  const auto& authored_queues = generalized.queues.value;
  if (authored_queues.empty()) {
    return Result<QueueCatalog>::failure(diagnostic_at(
        DiagnosticCategory::input_validation, "empty_queue_catalog",
        "switch.queues must contain at least one queue",
        generalized.queues.provenance));
  }

  std::vector<QueueCatalogEntry> entries;
  entries.reserve(authored_queues.size());
  std::map<QueueId, DenseQueueIndex> reverse;
  std::optional<BigNat> greatest_legacy_coordinate;
  std::optional<ModelProvenance> greatest_coordinate_provenance;

  for (std::size_t ordinal = 0; ordinal < authored_queues.size(); ++ordinal) {
    // checked_index is the explicit boundary even though the vector's native
    // size already constrains this particular traversal ordinal.
    Result<std::size_t> checked =
        checked_index(BigNat(ordinal), authored_queues.size());
    if (!checked) {
      return Result<QueueCatalog>::failure(std::move(checked.error()));
    }
    const DenseQueueIndex dense = QueueCatalog::make_dense_index(checked.value());
    const AuthoredQueue& queue = authored_queues[ordinal];

    const auto [existing, inserted] = reverse.emplace(queue.id.value, dense);
    if (!inserted) {
      const QueueCatalogEntry& first = entries[existing->second.ordinal()];
      return Result<QueueCatalog>::failure(diagnostic_at(
          DiagnosticCategory::input_validation, "duplicate_queue_id",
          "each typed queue ID must occur exactly once in switch.queues",
          queue.id.provenance,
          {"first definition: " + first.provenance.json_pointer}));
    }

    entries.push_back(QueueCatalogEntry{queue.id.value, queue.legacy_voq.value,
                                        queue.provenance});

    if (queue.legacy_voq.value.has_value()) {
      const LegacyVoqCoordinate& coordinate = *queue.legacy_voq.value;
      const BigNat* candidates[] = {&coordinate.source.value,
                                    &coordinate.destination.value};
      for (const BigNat* candidate : candidates) {
        if (!greatest_legacy_coordinate.has_value() ||
            *greatest_legacy_coordinate < *candidate) {
          greatest_legacy_coordinate = *candidate;
          greatest_coordinate_provenance =
              candidate == &coordinate.source.value
                  ? coordinate.source.provenance
                  : coordinate.destination.provenance;
        }
      }
    }
  }

  std::optional<LegacyPortExtent> extent;
  if (generalized.legacy_n_ports.value.has_value()) {
    const BigNat& declared = *generalized.legacy_n_ports.value;
    if (declared.is_zero()) {
      return Result<QueueCatalog>::failure(diagnostic_at(
          DiagnosticCategory::input_validation, "invalid_legacy_port_extent",
          "switch.legacy_n_ports must be positive when present",
          generalized.legacy_n_ports.provenance));
    }
    if (greatest_legacy_coordinate.has_value() &&
        !(*greatest_legacy_coordinate < declared)) {
      return Result<QueueCatalog>::failure(diagnostic_at(
          DiagnosticCategory::input_validation, "legacy_voq_out_of_extent",
          "a legacy_voq coordinate is outside switch.legacy_n_ports",
          greatest_coordinate_provenance.value_or(
              generalized.legacy_n_ports.provenance),
          {"every legacy coordinate must be strictly less than the declared "
           "port extent"}));
    }
    extent = LegacyPortExtent{declared, false,
                              generalized.legacy_n_ports.provenance};
  } else if (greatest_legacy_coordinate.has_value()) {
    BigNat derived = *greatest_legacy_coordinate;
    ++derived;
    extent = LegacyPortExtent{std::move(derived), true,
                              generalized.legacy_n_ports.provenance};
  }

  return Result<QueueCatalog>::success(QueueCatalog(
      std::move(entries), std::move(reverse), std::move(extent)));
}

}  // namespace mwperf
