#include "mwperf/model/typed_label.hpp"

#include <algorithm>
#include <compare>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic label_diagnostic(std::string code,
                                          std::string message) {
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    std::nullopt,
                    {}};
}

struct Utf8Summary final {
  std::uint32_t first_code_point;
  std::uint32_t last_code_point;
};

[[nodiscard]] bool is_continuation(const std::uint8_t byte) noexcept {
  return (byte & 0xC0U) == 0x80U;
}

[[nodiscard]] bool decode_utf8_code_point(const std::string_view input,
                                          std::size_t& offset,
                                          std::uint32_t& code_point) noexcept {
  const auto byte_at = [&input](const std::size_t index) {
    return static_cast<std::uint8_t>(
        static_cast<unsigned char>(input[index]));
  };

  const std::uint8_t first = byte_at(offset);
  if (first <= 0x7FU) {
    code_point = first;
    ++offset;
    return true;
  }

  if (first >= 0xC2U && first <= 0xDFU) {
    if (input.size() - offset < 2U) {
      return false;
    }
    const std::uint8_t second = byte_at(offset + 1U);
    if (!is_continuation(second)) {
      return false;
    }
    code_point = (static_cast<std::uint32_t>(first & 0x1FU) << 6U) |
                 static_cast<std::uint32_t>(second & 0x3FU);
    offset += 2U;
    return true;
  }

  if (first >= 0xE0U && first <= 0xEFU) {
    if (input.size() - offset < 3U) {
      return false;
    }
    const std::uint8_t second = byte_at(offset + 1U);
    const std::uint8_t third = byte_at(offset + 2U);
    if (!is_continuation(second) || !is_continuation(third)) {
      return false;
    }
    if ((first == 0xE0U && second < 0xA0U) ||
        (first == 0xEDU && second > 0x9FU)) {
      return false;
    }
    code_point = (static_cast<std::uint32_t>(first & 0x0FU) << 12U) |
                 (static_cast<std::uint32_t>(second & 0x3FU) << 6U) |
                 static_cast<std::uint32_t>(third & 0x3FU);
    offset += 3U;
    return true;
  }

  if (first >= 0xF0U && first <= 0xF4U) {
    if (input.size() - offset < 4U) {
      return false;
    }
    const std::uint8_t second = byte_at(offset + 1U);
    const std::uint8_t third = byte_at(offset + 2U);
    const std::uint8_t fourth = byte_at(offset + 3U);
    if (!is_continuation(second) || !is_continuation(third) ||
        !is_continuation(fourth)) {
      return false;
    }
    if ((first == 0xF0U && second < 0x90U) ||
        (first == 0xF4U && second > 0x8FU)) {
      return false;
    }
    code_point = (static_cast<std::uint32_t>(first & 0x07U) << 18U) |
                 (static_cast<std::uint32_t>(second & 0x3FU) << 12U) |
                 (static_cast<std::uint32_t>(third & 0x3FU) << 6U) |
                 static_cast<std::uint32_t>(fourth & 0x3FU);
    offset += 4U;
    return true;
  }

  // This also rejects continuation bytes in lead position, overlong two-byte
  // leads C0/C1, five/six-byte legacy forms, and values above U+10FFFF.
  return false;
}

[[nodiscard]] bool inspect_utf8(const std::string_view input,
                                Utf8Summary& summary) noexcept {
  if (input.empty()) {
    return false;
  }

  std::size_t offset = 0U;
  std::uint32_t code_point = 0U;
  if (!decode_utf8_code_point(input, offset, code_point)) {
    return false;
  }
  summary.first_code_point = code_point;
  summary.last_code_point = code_point;

  while (offset < input.size()) {
    if (!decode_utf8_code_point(input, offset, code_point)) {
      return false;
    }
    summary.last_code_point = code_point;
  }
  return true;
}

// This fixed Unicode White_Space set makes "already trimmed" independent of
// the process locale and of a platform C library's character classification.
[[nodiscard]] constexpr bool is_unicode_white_space(
    const std::uint32_t code_point) noexcept {
  return (code_point >= 0x0009U && code_point <= 0x000DU) ||
         code_point == 0x0020U || code_point == 0x0085U ||
         code_point == 0x00A0U || code_point == 0x1680U ||
         (code_point >= 0x2000U && code_point <= 0x200AU) ||
         code_point == 0x2028U || code_point == 0x2029U ||
         code_point == 0x202FU || code_point == 0x205FU ||
         code_point == 0x3000U;
}

[[nodiscard]] std::strong_ordering compare_unsigned_bytes(
    const std::string_view left, const std::string_view right) noexcept {
  const std::size_t shared_size = std::min(left.size(), right.size());
  for (std::size_t index = 0U; index < shared_size; ++index) {
    const auto left_byte =
        static_cast<unsigned char>(left[index]);
    const auto right_byte =
        static_cast<unsigned char>(right[index]);
    if (left_byte < right_byte) {
      return std::strong_ordering::less;
    }
    if (left_byte > right_byte) {
      return std::strong_ordering::greater;
    }
  }
  return left.size() <=> right.size();
}

[[nodiscard]] std::string_view json_kind_name(
    const JsonValue::Kind kind) noexcept {
  switch (kind) {
    case JsonValue::Kind::number:
      return "number";
    case JsonValue::Kind::string:
      return "string";
    case JsonValue::Kind::boolean:
      return "boolean";
    case JsonValue::Kind::null_value:
      return "null";
    case JsonValue::Kind::array:
      return "array";
    case JsonValue::Kind::object:
      return "object";
  }
  return "unknown";
}

}  // namespace

JsonValue::JsonValue(Storage storage) : storage_(std::move(storage)) {}

JsonValue JsonValue::number(std::string lexeme, BoundPolicy bound_policy) {
  return JsonValue(Storage(std::in_place_type<Number>, std::move(lexeme),
                           std::move(bound_policy)));
}

JsonValue JsonValue::string(std::string utf8) {
  return JsonValue(Storage(std::in_place_type<String>, std::move(utf8)));
}

JsonValue JsonValue::boolean(const bool value) {
  return JsonValue(Storage(std::in_place_type<bool>, value));
}

JsonValue JsonValue::null() {
  return JsonValue(Storage(std::in_place_type<Null>));
}

JsonValue JsonValue::array() {
  return JsonValue(Storage(std::in_place_type<Array>));
}

JsonValue JsonValue::object() {
  return JsonValue(Storage(std::in_place_type<Object>));
}

JsonValue::Kind JsonValue::kind() const noexcept {
  switch (storage_.index()) {
    case 0U:
      return Kind::number;
    case 1U:
      return Kind::string;
    case 2U:
      return Kind::boolean;
    case 3U:
      return Kind::null_value;
    case 4U:
      return Kind::array;
    case 5U:
      return Kind::object;
    default:
      return Kind::object;
  }
}

const std::string* JsonValue::number_lexeme() const noexcept {
  const Number* number = std::get_if<Number>(&storage_);
  return number == nullptr ? nullptr : &number->lexeme;
}

const BoundPolicy* JsonValue::number_bound_policy() const noexcept {
  const Number* number = std::get_if<Number>(&storage_);
  return number == nullptr ? nullptr : &number->bound_policy;
}

const std::string* JsonValue::string_value() const noexcept {
  const String* string = std::get_if<String>(&storage_);
  return string == nullptr ? nullptr : &string->utf8;
}

const bool* JsonValue::boolean_value() const noexcept {
  return std::get_if<bool>(&storage_);
}

TypedLabel::TypedLabel(Storage storage) : storage_(std::move(storage)) {}

TypedLabel::TypedLabel(TypedLabel&& other) : storage_(other.storage_) {}

TypedLabel& TypedLabel::operator=(TypedLabel&& other) {
  if (this != &other) {
    storage_ = other.storage_;
  }
  return *this;
}

TypedLabel TypedLabel::numeric(BigNat value) {
  return TypedLabel(Storage(std::in_place_type<BigNat>, std::move(value)));
}

Result<TypedLabel> TypedLabel::text(std::string utf8) {
  if (utf8.empty()) {
    return Result<TypedLabel>::failure(label_diagnostic(
        "typed_label_empty", "a string label must not be empty"));
  }

  Utf8Summary summary{};
  if (!inspect_utf8(utf8, summary)) {
    return Result<TypedLabel>::failure(label_diagnostic(
        "typed_label_invalid_utf8", "a string label must be valid UTF-8"));
  }
  if (is_unicode_white_space(summary.first_code_point) ||
      is_unicode_white_space(summary.last_code_point)) {
    return Result<TypedLabel>::failure(label_diagnostic(
        "typed_label_not_trimmed",
        "a string label must already be trimmed"));
  }

  return Result<TypedLabel>::success(
      TypedLabel(Storage(std::in_place_type<std::string>, std::move(utf8))));
}

bool TypedLabel::is_numeric() const noexcept {
  return std::holds_alternative<BigNat>(storage_);
}

bool TypedLabel::is_text() const noexcept {
  return std::holds_alternative<std::string>(storage_);
}

const BigNat* TypedLabel::numeric_value() const noexcept {
  return std::get_if<BigNat>(&storage_);
}

const std::string* TypedLabel::text_value() const noexcept {
  return std::get_if<std::string>(&storage_);
}

std::vector<std::uint8_t> TypedLabel::canonical_bytes() const {
  std::vector<std::uint8_t> encoded;
  if (const BigNat* numeric = numeric_value(); numeric != nullptr) {
    const std::vector<std::uint8_t> magnitude =
        numeric->canonical_magnitude_bytes();
    encoded.reserve(1U + magnitude.size());
    encoded.push_back(0U);
    encoded.insert(encoded.end(), magnitude.begin(), magnitude.end());
    return encoded;
  }

  const std::string& text = *text_value();
  encoded.reserve(1U + text.size());
  encoded.push_back(1U);
  for (const unsigned char byte : text) {
    encoded.push_back(static_cast<std::uint8_t>(byte));
  }
  return encoded;
}

std::uint64_t TypedLabel::stable_hash() const {
  const std::vector<std::uint8_t> encoded = canonical_bytes();
  return stable_identity_hash(encoded);
}

std::strong_ordering operator<=>(const TypedLabel& left,
                                 const TypedLabel& right) noexcept {
  if (left.storage_.index() != right.storage_.index()) {
    return left.storage_.index() < right.storage_.index()
               ? std::strong_ordering::less
               : std::strong_ordering::greater;
  }

  if (const BigNat* left_numeric = left.numeric_value();
      left_numeric != nullptr) {
    const BigNat& right_numeric = *right.numeric_value();
    if (left_numeric->value() < right_numeric.value()) {
      return std::strong_ordering::less;
    }
    if (left_numeric->value() > right_numeric.value()) {
      return std::strong_ordering::greater;
    }
    return std::strong_ordering::equal;
  }

  return compare_unsigned_bytes(*left.text_value(), *right.text_value());
}

Result<TypedLabel> parse_typed_label(const JsonValue& value) {
  if (const std::string* numeric_lexeme = value.number_lexeme();
      numeric_lexeme != nullptr) {
    const BoundPolicy* bound_policy = value.number_bound_policy();
    if (bound_policy == nullptr) {
      return Result<TypedLabel>::failure(label_diagnostic(
          "typed_label_internal_number",
          "a numeric label is missing its exact-number bound policy"));
    }
    Result<BigNat> parsed = parse_exact_nonnegative_integer(
        JsonNumber(*numeric_lexeme), *bound_policy);
    if (!parsed) {
      return Result<TypedLabel>::failure(parsed.error());
    }
    return Result<TypedLabel>::success(
        TypedLabel::numeric(std::move(parsed).value()));
  }

  if (const std::string* text = value.string_value(); text != nullptr) {
    return TypedLabel::text(*text);
  }

  if (value.kind() == JsonValue::Kind::boolean) {
    return Result<TypedLabel>::failure(label_diagnostic(
        "typed_label_boolean",
        "a boolean is not a numeric or string label"));
  }

  std::string message{"a typed label must be a number or string, not "};
  message += json_kind_name(value.kind());
  return Result<TypedLabel>::failure(
      label_diagnostic("typed_label_wrong_type", std::move(message)));
}

std::vector<std::uint8_t> canonical_typed_label_bytes(
    const TypedLabel& label) {
  return label.canonical_bytes();
}

std::uint64_t stable_identity_hash(
    const std::span<const std::uint8_t> bytes) noexcept {
  constexpr std::uint64_t offset_basis = 14695981039346656037ULL;
  constexpr std::uint64_t prime = 1099511628211ULL;

  std::uint64_t hash = offset_basis;
  for (const std::uint8_t byte : bytes) {
    hash ^= byte;
    hash *= prime;
  }
  return hash;
}

}  // namespace mwperf
