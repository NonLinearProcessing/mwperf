#include "mwperf/model/resolved_instance.hpp"

#include <algorithm>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"

namespace mwperf {

std::string_view to_string(const ArrivalFamily family) noexcept {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return "deterministic_trace";
    case ArrivalFamily::periodic_global_phase:
      return "periodic_global_phase";
    case ArrivalFamily::periodic_source_delays:
      return "periodic_source_delays";
    case ArrivalFamily::independent_marked_renewal:
      return "independent_marked_renewal";
    case ArrivalFamily::independent_private_markov_renewal:
      return "independent_private_markov_renewal";
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return "shared_joint_round_markov_renewal";
    case ArrivalFamily::iid_independent_bernoulli:
      return "iid_independent_bernoulli";
    case ArrivalFamily::iid_count_table:
      return "iid_count_table";
    case ArrivalFamily::iid_independent_poisson:
      return "iid_independent_poisson";
    case ArrivalFamily::iid_mixed_poisson:
      return "iid_mixed_poisson";
  }
  return "unknown";
}

Result<QueueMask> QueueMask::from_bytes(std::vector<std::uint8_t> values,
                                       const std::size_t expected_size) {
  if (values.size() != expected_size) {
    return Result<QueueMask>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "arrival_support_dimension_mismatch",
        "the arrival support mask does not match the resolved queue catalog",
        std::nullopt,
        std::nullopt,
        {"expected " + std::to_string(expected_size) + " entries; received " +
         std::to_string(values.size())},
    });
  }
  if (std::ranges::any_of(values,
                          [](const std::uint8_t value) { return value > 1U; })) {
    return Result<QueueMask>::failure(Diagnostic{
        DiagnosticCategory::internal,
        "arrival_support_mask_not_binary",
        "the arrival support compiler returned a non-binary mask",
        std::nullopt,
        std::nullopt,
        {},
    });
  }
  return Result<QueueMask>::success(QueueMask(std::move(values)));
}

struct ResolvedInstance::Storage final {
  AuthoredModelConfig model;
  AnalysisSpec analysis;
  InputFingerprintBundle fingerprints;
  QueueCatalog queues;
  PriorityOrder priority;
  ConstraintDescriptor constraint;
  DerivedServiceIdentity service_identity;
  ServiceableMask serviceable;
  OptimizerBudgetPolicy optimizer_budget;
  ResolvedTargetSet targets;
  ConfiguredArrivalBinding arrival;
  QueueMask positive_arrival_support;
  std::optional<InitialLawBinding> initial_law;
  TimingConvention timing;
};

ResolvedInstance::ResolvedInstance(
    AuthoredModelConfig model, AnalysisSpec analysis,
    InputFingerprintBundle fingerprints, QueueCatalog queues,
    PriorityOrder priority, ConstraintDescriptor constraint,
    DerivedServiceIdentity service_identity,
    ServiceableMask serviceable, OptimizerBudgetPolicy optimizer_budget,
    ResolvedTargetSet targets, ConfiguredArrivalBinding arrival,
    QueueMask positive_arrival_support,
    std::optional<InitialLawBinding> initial_law,
    const TimingConvention timing)
    : storage_(std::make_shared<const Storage>(Storage{
          .model = std::move(model),
          .analysis = std::move(analysis),
          .fingerprints = std::move(fingerprints),
          .queues = std::move(queues),
          .priority = std::move(priority),
          .constraint = std::move(constraint),
          .service_identity = service_identity,
          .serviceable = std::move(serviceable),
          .optimizer_budget = std::move(optimizer_budget),
          .targets = std::move(targets),
          .arrival = std::move(arrival),
          .positive_arrival_support = std::move(positive_arrival_support),
          .initial_law = std::move(initial_law),
          .timing = timing,
      })) {}

ResolvedInstance::~ResolvedInstance() = default;

const AuthoredModelConfig& ResolvedInstance::authored_model() const noexcept {
  return storage_->model;
}

const AnalysisSpec& ResolvedInstance::analysis_spec() const noexcept {
  return storage_->analysis;
}

const InputFingerprintBundle& ResolvedInstance::fingerprints() const noexcept {
  return storage_->fingerprints;
}

const QueueCatalog& ResolvedInstance::queues() const noexcept {
  return storage_->queues;
}

const PriorityOrder& ResolvedInstance::priority() const noexcept {
  return storage_->priority;
}

const ConstraintDescriptor& ResolvedInstance::constraint() const noexcept {
  return storage_->constraint;
}

const DerivedServiceIdentity& ResolvedInstance::service_identity()
    const noexcept {
  return storage_->service_identity;
}

const ServiceableMask& ResolvedInstance::serviceable() const noexcept {
  return storage_->serviceable;
}

const OptimizerBudgetPolicy& ResolvedInstance::optimizer_budget()
    const noexcept {
  return storage_->optimizer_budget;
}

const ResolvedTargetSet& ResolvedInstance::targets() const noexcept {
  return storage_->targets;
}

const ConfiguredArrivalBinding& ResolvedInstance::arrival() const noexcept {
  return storage_->arrival;
}

const QueueMask& ResolvedInstance::positive_arrival_support() const noexcept {
  return storage_->positive_arrival_support;
}

const std::optional<InitialLawBinding>& ResolvedInstance::initial_law()
    const noexcept {
  return storage_->initial_law;
}

TimingConvention ResolvedInstance::timing() const noexcept {
  return storage_->timing;
}

const AuthoredRunConfig& ResolvedInstance::run_provenance() const noexcept {
  return storage_->model.run;
}

const AuthoredTelemetryConfig& ResolvedInstance::telemetry_provenance()
    const noexcept {
  return storage_->model.telemetry;
}

const AuthoredMetadata& ResolvedInstance::metadata_provenance() const noexcept {
  return storage_->model.metadata;
}

}  // namespace mwperf
