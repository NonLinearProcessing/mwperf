#include "mwperf/sampling/estimators.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <memory>
#include <new>
#include <numeric>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <boost/math/special_functions/beta.hpp>
#include <boost/multiprecision/cpp_dec_float.hpp>

#include "c24_internal.hpp"
#include "mwperf/core/sha256.hpp"

namespace mwperf::sampling::detail {
namespace {

void append_u64(std::vector<std::byte>& bytes, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    bytes.push_back(
        static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_string(std::vector<std::byte>& bytes,
                   const std::string_view value) {
  append_u64(bytes, static_cast<std::uint64_t>(value.size()));
  for (const char character : value) {
    bytes.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_digest(std::vector<std::byte>& bytes,
                   const Digest256& digest) {
  bytes.insert(bytes.end(), digest.bytes().begin(), digest.bytes().end());
}

void append_bool(std::vector<std::byte>& bytes, const bool value) {
  bytes.push_back(value ? std::byte{1} : std::byte{0});
}

void append_long_double(std::vector<std::byte>& bytes,
                        const long double value) {
  std::array<char, 192U> buffer{};
  const auto converted = std::to_chars(
      buffer.data(), buffer.data() + buffer.size(), value,
      std::chars_format::scientific,
      std::numeric_limits<long double>::max_digits10);
  if (converted.ec != std::errc{}) {
    throw std::runtime_error("long-double canonicalization failed");
  }
  append_string(bytes,
                std::string_view(
                    buffer.data(),
                    static_cast<std::size_t>(converted.ptr -
                                             buffer.data())));
}

[[nodiscard]] bool valid_stage(const StageTag stage) noexcept {
  return stage == StageTag::prearrival_closure ||
         stage == StageTag::postarrival_closure ||
         stage == StageTag::generic_sampling ||
         stage == StageTag::importance_proposal;
}

template <typename T, typename Callback>
[[nodiscard]] Result<T> invoke_guarded(std::string_view operation,
                                       Callback&& callback) {
  try {
    return std::forward<Callback>(callback)();
  } catch (const std::bad_alloc&) {
    return Result<T>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.callback_allocation_failure",
        std::string(operation) + " exhausted memory"));
  } catch (const std::exception&) {
    return Result<T>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.callback_exception",
        std::string(operation) +
            " raised an exception; the fixed plan is failed without retry"));
  } catch (...) {
    return Result<T>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.callback_unknown_exception",
        std::string(operation) +
            " raised an unknown exception; the fixed plan is failed "
            "without retry"));
  }
}

[[nodiscard]] Result<Digest256> plan_digest(
    const SamplingPlanSpecV1& spec,
    const sampling::detail::NormalizedSamplerCore& sampler,
    const AcceptedSamplingClauseV1& accepted) {
  try {
    std::vector<std::byte> bytes;
    append_string(bytes, spec.estimator_id);
    append_digest(bytes, spec.metric_target_digest);
    append_digest(bytes, sampler.seal_digest);
    append_digest(bytes, sampler.accepted_contract_digest);
    append_string(bytes, accepted.clause_id.metric_id);
    append_u64(bytes,
               static_cast<std::uint64_t>(accepted.clause_id.authored_index));
    append_u64(bytes,
               static_cast<std::uint64_t>(accepted.backend_route));
    append_u64(bytes,
               static_cast<std::uint64_t>(sampler.contract.reveal_stage));
    append_u64(bytes,
               static_cast<std::uint64_t>(sampler.contract.dependence));
    append_u64(bytes, spec.seed.value());
    append_u64(bytes, static_cast<std::uint64_t>(spec.stage));
    append_string(bytes, spec.accuracy.replications.to_decimal_string());
    append_string(bytes,
                  spec.accuracy.confidence_level.to_canonical_string());
    append_u64(bytes,
               static_cast<std::uint64_t>(spec.accuracy.interval));
    append_u64(bytes,
               static_cast<std::uint64_t>(spec.accuracy.estimand));
    append_bool(bytes, spec.accuracy.almost_sure_lower.has_value());
    if (spec.accuracy.almost_sure_lower.has_value()) {
      append_string(bytes, spec.accuracy.almost_sure_lower
                               ->to_canonical_string());
    }
    append_bool(bytes, spec.accuracy.almost_sure_upper.has_value());
    if (spec.accuracy.almost_sure_upper.has_value()) {
      append_string(bytes, spec.accuracy.almost_sure_upper
                               ->to_canonical_string());
    }
    append_string(bytes, spec.draw_cap.to_decimal_string());
    append_bool(bytes, spec.fixed_budget);
    append_bool(bytes, spec.request_rao_blackwellization);
    append_bool(bytes, spec.total_variation.has_value());
    if (spec.total_variation.has_value()) {
      append_long_double(bytes, spec.total_variation->epsilon);
      append_long_double(bytes, spec.total_variation->alpha);
      append_u64(bytes, static_cast<std::uint64_t>(
                            spec.total_variation->simultaneous_rows));
    }
    return sha256_domain_separated("mwperf.c24.sampling-plan.v1", bytes);
  } catch (const std::bad_alloc&) {
    return Result<Digest256>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.plan_digest_allocation_failure",
        "canonical sampling-plan digest construction exhausted memory"));
  } catch (const std::exception&) {
    return Result<Digest256>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.plan_digest_numeric_encoding_failure",
        "the sampling plan's numerical fields could not be encoded "
        "canonically"));
  }
}

using StatisticalFloat = boost::multiprecision::cpp_dec_float_100;

[[nodiscard]] StatisticalFloat statistical_image(
    const ExactRational& value) {
  return StatisticalFloat(value.numerator_decimal()) /
         StatisticalFloat(value.denominator_decimal());
}

[[nodiscard]] StatisticalFloat statistical_image(const BigNat& value) {
  return StatisticalFloat(value.to_decimal_string());
}

[[nodiscard]] StatisticalFloat statistical_image(
    const std::size_t value) {
  return StatisticalFloat(std::to_string(value));
}

// Convert a finite binary floating-point value without first reducing it to a
// short decimal spelling.  cpp_dec_float_100 then carries substantially more
// precision than every supported host long-double representation through the
// transcendental calculation.
[[nodiscard]] StatisticalFloat statistical_image(const long double value) {
  if (value == 0.0L) return StatisticalFloat{0};
  const bool negative = std::signbit(value);
  int exponent = 0;
  long double fraction = std::frexp(std::fabs(value), &exponent);
  BigInt significand = 0;
  for (int bit = 0; bit < std::numeric_limits<long double>::digits; ++bit) {
    fraction = std::ldexp(fraction, 1);
    significand <<= 1U;
    if (fraction >= 1.0L) {
      ++significand;
      fraction -= 1.0L;
    }
  }
  StatisticalFloat result(significand.convert_to<std::string>());
  using boost::multiprecision::pow;
  const int binary_exponent =
      exponent - std::numeric_limits<long double>::digits;
  if (binary_exponent >= 0) {
    result *= pow(StatisticalFloat{2}, binary_exponent);
  } else {
    result /= pow(StatisticalFloat{2}, -binary_exponent);
  }
  return negative ? -result : result;
}

[[nodiscard]] bool finite_statistical(const StatisticalFloat& value) {
  const StatisticalFloat infinity =
      std::numeric_limits<StatisticalFloat>::infinity();
  return value == value && value != infinity && value != -infinity;
}

enum class OutwardDirection : std::uint8_t { downward, upward };

[[nodiscard]] std::optional<long double> outward_image(
    const StatisticalFloat& value, const OutwardDirection direction) {
  if (!finite_statistical(value)) return std::nullopt;
  long double image = value.convert_to<long double>();
  if (!std::isfinite(image)) return std::nullopt;
  const long double destination =
      direction == OutwardDirection::downward
          ? -std::numeric_limits<long double>::infinity()
          : std::numeric_limits<long double>::infinity();
  // The conversion is normally correctly rounded.  Verify its direction in
  // the promoted domain instead of relying on that implementation property.
  for (unsigned int guard = 0U; guard < 8U; ++guard) {
    const StatisticalFloat promoted = statistical_image(image);
    const bool enclosed = direction == OutwardDirection::downward
                              ? promoted <= value
                              : promoted >= value;
    if (enclosed) return image;
    image = std::nextafter(image, destination);
    if (!std::isfinite(image)) return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] bool reward_within_exact_range(
    const long double value, const ExactRational& lower,
    const ExactRational& upper) {
  const StatisticalFloat promoted = statistical_image(value);
  return promoted >= statistical_image(lower) &&
         promoted <= statistical_image(upper);
}

[[nodiscard]] Result<FixedSampleIntervalV1> clopper_pearson(
    const std::size_t successes, const std::size_t trials,
    const ExactRational& exact_confidence,
    const ConditionalSampleDependenceV1 dependence) {
  try {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    if (trials == 0U || successes > trials) {
      return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
          DiagnosticCategory::internal, "c24.clopper_pearson_invalid_counts",
          "the exact-binomial interval received inconsistent fixed counts"));
    }
    const StatisticalFloat exact_confidence_image =
        statistical_image(exact_confidence);
    const StatisticalFloat alpha =
        StatisticalFloat{1} - exact_confidence_image;
    const StatisticalFloat half_tail = alpha / 2;
    const auto confidence_image = outward_image(
        exact_confidence_image, OutwardDirection::downward);
    if (!finite_statistical(alpha) || !confidence_image ||
        *confidence_image <= 0.0L || *confidence_image >= 1.0L || alpha <= 0 ||
        alpha >= 1) {
      return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
          DiagnosticCategory::resource_limit,
          "c24.clopper_pearson_precision_unavailable",
          "the exact confidence tail is outside the supported statistical "
          "image; no interval was published"));
    }
    long double lower = 0.0L;
    long double upper = 1.0L;
    if (successes != 0U) {
      const StatisticalFloat first = statistical_image(successes);
      const StatisticalFloat second =
          statistical_image(trials - successes + 1U);
      const StatisticalFloat quantile =
          boost::math::ibeta_inv(first, second, half_tail);
      auto image = outward_image(quantile, OutwardDirection::downward);
      if (!image) throw std::runtime_error("lower beta image unavailable");
      lower = std::max(0.0L, *image);
      // Verify the defining lower-tail inequality after conversion.  A strict
      // high-precision guard makes equality widen by one host ulp rather than
      // risk relying on an inverse-beta rounding accident.
      const StatisticalFloat guarded_tail =
          half_tail * (StatisticalFloat{1} - StatisticalFloat("1e-80"));
      for (unsigned int guard = 0U;
           guard < 8U &&
           boost::math::ibeta(first, second, statistical_image(lower)) >
               guarded_tail;
           ++guard) {
        lower = std::nextafter(
            lower, -std::numeric_limits<long double>::infinity());
        if (lower < 0.0L) lower = 0.0L;
      }
      if (boost::math::ibeta(first, second, statistical_image(lower)) >
          half_tail) {
        throw std::runtime_error("lower beta tail verification failed");
      }
    }
    if (successes != trials) {
      const StatisticalFloat first = statistical_image(successes + 1U);
      const StatisticalFloat second = statistical_image(trials - successes);
      const StatisticalFloat quantile =
          boost::math::ibetac_inv(first, second, half_tail);
      auto image = outward_image(quantile, OutwardDirection::upward);
      if (!image) throw std::runtime_error("upper beta image unavailable");
      upper = std::min(1.0L, *image);
      const StatisticalFloat guarded_tail =
          half_tail * (StatisticalFloat{1} - StatisticalFloat("1e-80"));
      for (unsigned int guard = 0U;
           guard < 8U &&
           boost::math::ibetac(first, second, statistical_image(upper)) >
               guarded_tail;
           ++guard) {
        upper = std::nextafter(
            upper, std::numeric_limits<long double>::infinity());
        if (upper > 1.0L) upper = 1.0L;
      }
      if (boost::math::ibetac(first, second, statistical_image(upper)) >
          half_tail) {
        throw std::runtime_error("upper beta tail verification failed");
      }
    }
    if (!std::isfinite(lower) || !std::isfinite(upper) ||
        lower < 0.0L || upper > 1.0L || lower > upper) {
      return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
          DiagnosticCategory::internal,
          "c24.clopper_pearson_nonfinite",
          "the checked inverse-beta evaluation did not produce a valid "
          "two-sided Clopper--Pearson interval"));
    }
    return Result<FixedSampleIntervalV1>::success(
         {StatisticalIntervalKindV1::exact_binomial,
         *confidence_image,
         lower,
         upper,
         BigNat(static_cast<std::uint64_t>(trials)),
         dependence,
         true,
         true,
         SamplingClaimScopeV1::row_conditional_surrogate,
         "two-sided equal-tail Clopper-Pearson coverage for one binary "
         "row-conditional proportion",
         0.0L,
         1.0L});
  } catch (const std::exception&) {
    return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.clopper_pearson_inverse_beta_failure",
        "the checked inverse-beta evaluation failed; no interval was "
        "published"));
  }
}

[[nodiscard]] Result<FixedSampleIntervalV1> hoeffding_interval(
    const long double mean, const ExactRational& exact_lower,
    const ExactRational& exact_upper,
    const MonteCarloAccuracyV1& accuracy,
    const ConditionalSampleDependenceV1 dependence,
    const SamplingClaimScopeV1 scope, std::string coverage_statement) {
  try {
    const StatisticalFloat lower_exact = statistical_image(exact_lower);
    const StatisticalFloat upper_exact = statistical_image(exact_upper);
    const StatisticalFloat confidence_exact =
        statistical_image(accuracy.confidence_level);
    const StatisticalFloat alpha = StatisticalFloat{1} - confidence_exact;
    if (!std::isfinite(mean) || !finite_statistical(lower_exact) ||
        !finite_statistical(upper_exact) || lower_exact > upper_exact ||
        !finite_statistical(alpha) || alpha <= 0 || alpha >= 1 ||
        accuracy.replications.is_zero()) {
      return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
          DiagnosticCategory::resource_limit,
          "c24.hoeffding_numeric_image_unavailable",
          "the exact confidence or reward range is outside the supported "
          "statistical image; no Hoeffding interval was published"));
    }
    using boost::multiprecision::log;
    using boost::multiprecision::sqrt;
    const StatisticalFloat count = statistical_image(accuracy.replications);
    StatisticalFloat radius =
        (upper_exact - lower_exact) *
        sqrt(log(StatisticalFloat{2} / alpha) /
             (StatisticalFloat{2} * count));
    // cpp_dec_float_100 is substantially wider than the public numerical
    // image, but its transcendental result is still rounded.  Inflate the
    // radius before the directed host conversion so that this internal
    // rounding cannot make the reported interval anti-conservative.
    radius += StatisticalFloat("1e-80") *
              (abs(radius) + abs(upper_exact - lower_exact) + 1);
    const StatisticalFloat promoted_mean = statistical_image(mean);
    const StatisticalFloat candidate_lower = promoted_mean - radius;
    const StatisticalFloat candidate_upper = promoted_mean + radius;
    const StatisticalFloat interval_lower_exact =
        candidate_lower < lower_exact ? lower_exact : candidate_lower;
    const StatisticalFloat interval_upper_exact =
        candidate_upper > upper_exact ? upper_exact : candidate_upper;
    auto lower_bound =
        outward_image(lower_exact, OutwardDirection::downward);
    auto upper_bound =
        outward_image(upper_exact, OutwardDirection::upward);
    auto interval_lower =
        outward_image(interval_lower_exact, OutwardDirection::downward);
    auto interval_upper =
        outward_image(interval_upper_exact, OutwardDirection::upward);
    const auto confidence =
        outward_image(confidence_exact, OutwardDirection::downward);
    if (!lower_bound || !upper_bound || !interval_lower || !interval_upper ||
        !confidence || *confidence <= 0.0L || *confidence >= 1.0L ||
        *interval_lower > *interval_upper) {
      return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
          DiagnosticCategory::resource_limit,
          "c24.hoeffding_interval_not_representable",
          "the checked Hoeffding calculation was not representable as a "
          "finite outward-rounded long-double interval"));
    }
    return Result<FixedSampleIntervalV1>::success(
        {StatisticalIntervalKindV1::hoeffding,
         *confidence,
         *interval_lower,
         *interval_upper,
         accuracy.replications,
         dependence,
         true,
         true,
         scope,
         std::move(coverage_statement),
         *lower_bound,
         *upper_bound});
  } catch (const std::exception&) {
    return Result<FixedSampleIntervalV1>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.hoeffding_interval_not_representable",
        "the promoted Hoeffding calculation failed; no interval was "
        "published"));
  }
}

struct CompensatedSum final {
  long double sum{0.0L};
  long double correction{0.0L};

  void add(const long double value) noexcept {
    const long double updated = sum + value;
    if (std::fabs(sum) >= std::fabs(value)) {
      correction += (sum - updated) + value;
    } else {
      correction += (value - updated) + sum;
    }
    sum = updated;
  }

  [[nodiscard]] long double value() const noexcept {
    return sum + correction;
  }

  [[nodiscard]] bool finite() const noexcept {
    return std::isfinite(sum) && std::isfinite(correction) &&
           std::isfinite(value());
  }
};

struct StableMoments final {
  long double mean{0.0L};
  std::optional<long double> variance;
  std::size_t count{0U};
  long double online_center{0.0L};
  CompensatedSum total;
  CompensatedSum centered_second_moment;
  bool valid{true};

  // Replications are added in their authored index order.  The compensated
  // total preserves the published mean under severe cancellation, while the
  // Welford/West centered update avoids forming a difference of two large
  // raw second moments.  The M2 increments themselves are accumulated with
  // Neumaier compensation in the same deterministic order.
  void add(const long double value) noexcept {
    if (!valid) return;
    if (!std::isfinite(value) ||
        count == std::numeric_limits<std::size_t>::max()) {
      valid = false;
      return;
    }

    total.add(value);
    if (!total.finite()) {
      valid = false;
      return;
    }

    ++count;
    if (count == 1U) {
      online_center = value;
      mean = value;
      return;
    }

    const long double delta = value - online_center;
    const long double updated_center =
        online_center + delta / static_cast<long double>(count);
    const long double delta_after_update = value - updated_center;
    const long double m2_increment = delta * delta_after_update;
    if (!std::isfinite(delta) || !std::isfinite(updated_center) ||
        !std::isfinite(delta_after_update) ||
        !std::isfinite(m2_increment) || m2_increment < 0.0L) {
      valid = false;
      return;
    }
    online_center = updated_center;
    centered_second_moment.add(m2_increment);
    if (!centered_second_moment.finite() ||
        centered_second_moment.value() < 0.0L) {
      valid = false;
      return;
    }

    mean = total.value() / static_cast<long double>(count);
    const long double sample_variance =
        centered_second_moment.value() /
        static_cast<long double>(count - 1U);
    if (!std::isfinite(mean) || !std::isfinite(sample_variance) ||
        sample_variance < 0.0L) {
      valid = false;
      return;
    }
    variance = sample_variance;
  }

  [[nodiscard]] std::optional<long double> sample_variance() const noexcept {
    return variance;
  }

  [[nodiscard]] bool finite() const noexcept {
    return valid && count != 0U && std::isfinite(mean);
  }
};

[[nodiscard]] bool has_duplicate_samples(
    const std::span<const Sample> samples) {
  for (std::size_t left = 0U; left < samples.size(); ++left) {
    for (std::size_t right = left + 1U; right < samples.size(); ++right) {
      if (samples[left] == samples[right]) return true;
    }
  }
  return false;
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

[[nodiscard]] Result<const ConditionalSamplingRewardV1*> validate_reward(
    const RewardDecoder& reward, const SamplingPlanCore& plan,
    const NormalizedSamplerCore& sampler,
    const bool importance) {
  if (!reward.conditional_sampling ||
      !reward.conditional_sampling->decode ||
      reward.requires_temporal_continuation) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_row_conditional_reward_decoder",
            "C24 requires a non-temporal row-conditional reward decoder "
            "with an executable residual-sample branch"));
  }
  const auto& decoder = *reward.conditional_sampling;
  if (decoder.decoder_id.empty() ||
      !nonzero_digest(decoder.decoder_digest) ||
      decoder.metric_target_digest != plan.metric_target_digest ||
      decoder.output_schema != sampler.contract.output_schema ||
      decoder.integrability != reward.integrability) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.reward_decoder_binding_mismatch",
            "the reward decoder must bind the plan target, sampler output "
            "schema, decoder identity, and integrability declaration"));
  }
  if (!importance && decoder.integrability !=
      StationaryRewardIntegrabilityV1::finite_absolute) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.reward_not_finite_absolute_integrable",
            "a finite row-conditional C24 reward estimate requires an "
            "audited finite-absolute-integrability declaration"));
  }
  if (decoder.almost_sure_lower.has_value() !=
          decoder.almost_sure_upper.has_value() ||
      (decoder.almost_sure_lower.has_value() &&
       (*decoder.almost_sure_lower > *decoder.almost_sure_upper ||
        !std::isfinite(
            decoder.almost_sure_lower->to_long_double()) ||
        !std::isfinite(
            decoder.almost_sure_upper->to_long_double())))) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_reward_range",
            "an audited reward range must provide two finite ordered exact "
            "bounds"));
  }
  const bool iid = sampler.contract.dependence ==
                       ConditionalSampleDependenceV1::iid_cold_replications ||
                   sampler.contract.dependence ==
                       ConditionalSampleDependenceV1::iid_proposal;
  if (importance && plan.accuracy.interval !=
                        StatisticalIntervalKindV1::none) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.importance_interval_not_supported",
            "self-normalized importance estimates do not inherit exact "
            "binomial or Hoeffding finite-sample intervals"));
  }
  if (!importance && plan.accuracy.interval ==
                         StatisticalIntervalKindV1::exact_binomial &&
      (!iid || !decoder.binary_indicator ||
       plan.accuracy.estimand !=
           StatisticalEstimandKindV1::binary_proportion ||
       (decoder.almost_sure_lower.has_value() &&
        (*decoder.almost_sure_lower != ExactRational::zero() ||
         *decoder.almost_sure_upper != ExactRational::one())))) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.exact_binomial_premise_mismatch",
            "exact_binomial requires an IID binary indicator and a binary "
            "proportion estimand"));
  }
  if (!importance && plan.accuracy.interval ==
                         StatisticalIntervalKindV1::hoeffding &&
      (!iid || !decoder.almost_sure_lower.has_value() ||
       !decoder.almost_sure_upper.has_value() ||
       (plan.accuracy.estimand !=
            StatisticalEstimandKindV1::bounded_iid &&
        plan.accuracy.estimand !=
            StatisticalEstimandKindV1::binary_proportion) ||
       !plan.accuracy.almost_sure_lower.has_value() ||
       !plan.accuracy.almost_sure_upper.has_value() ||
       *decoder.almost_sure_lower !=
           *plan.accuracy.almost_sure_lower ||
       *decoder.almost_sure_upper !=
           *plan.accuracy.almost_sure_upper)) {
    return Result<const ConditionalSamplingRewardV1*>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.hoeffding_premise_mismatch",
            "Hoeffding requires IID rewards, audited almost-sure bounds, "
            "and a bounded-IID estimand"));
  }
  return Result<const ConditionalSamplingRewardV1*>::success(&decoder);
}

[[nodiscard]] Result<void> claim_sampling_execution(
    SamplingExecutionObserverV1& observer, const SamplingPlanCore& plan,
    const std::size_t replications) {
  auto& state = C24CoreAccess::sampling_execution_state(observer);
  if (!state || state->plan_digest != plan.plan_digest ||
      state->stage != plan.stage || state->draw_cap != plan.draw_cap) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sampling_observer_plan_mismatch",
        "the execution observer is not bound to this exact sampling plan, "
        "stage, and draw cap"));
  }
  if (state->estimator_claimed) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sampling_observer_reused",
        "one execution observer may account for exactly one C24 estimator "
        "invocation"));
  }
  try {
    state->replay_streams.reserve(replications);
    state->estimator_claimed = true;
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.sampling_observer_allocation_failure",
        "reserving failure-path sampling provenance exhausted memory"));
  }
}

[[nodiscard]] Result<void> record_consumed_sampling_draw(
    SamplingExecutionObserverV1& observer,
    SamplingReplicationReplayV1 replay, const bool failed) {
  auto& state = C24CoreAccess::sampling_execution_state(observer);
  if (!state || !state->estimator_claimed) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.sampling_observer_not_claimed",
        "a consumed conditional-generator draw has no claimed execution "
        "observer"));
  }
  try {
    const BigNat next_draw = state->generator_draws + BigNat{1U};
    state->replay_streams.push_back(std::move(replay));
    state->generator_draws = next_draw;
    if (failed) {
      state->failed_draws = state->failed_draws + BigNat{1U};
    }
    if (state->generator_draws > state->draw_cap) {
      return Result<void>::failure(sampling_diagnostic(
          DiagnosticCategory::resource_limit,
          "c24.generator_draw_cap_exhausted",
          "the actual conditional-generator call count exceeded the fixed "
          "sampling-plan draw cap"));
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.sampling_observer_allocation_failure",
        "retaining failure-path sampling provenance exhausted memory"));
  }
}

struct FixedDrawBank final {
  std::vector<Sample> samples;
  std::vector<SamplingReplicationReplayV1> replay_streams;
  std::vector<Sample> finite_support_snapshot;
};

[[nodiscard]] Result<FixedDrawBank> draw_fixed_bank(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const SamplingPlanCore& plan, const std::size_t replications,
    SamplingExecutionObserverV1& observer) {
  const auto& sampler = C24CoreAccess::sampler_core(access);
  if (!sampler) {
    return Result<FixedDrawBank>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sampling_plan_access_binding_mismatch",
        "the fixed draw bank requires a validated sampler handle"));
  }
  auto binding = validate_plan_access_binding(*sampler, plan);
  if (!binding) {
    return Result<FixedDrawBank>::failure(binding.error());
  }
  auto row_digest = conditioning_state_digest(state);
  if (!row_digest) {
    return Result<FixedDrawBank>::failure(row_digest.error());
  }
  std::vector<Sample> fixed_support_snapshot;
  if (sampler->contract.support_kind ==
      ConditionalSupportKindV1::finite_declared) {
    auto declared = invoke_guarded<std::vector<Sample>>(
        "the fixed-bank support enumerator", [&] {
          auto enumerate_support = sampler->enumerate_support;
          return enumerate_support(state);
        });
    if (!declared) {
      return Result<FixedDrawBank>::failure(declared.error());
    }
    fixed_support_snapshot = std::move(declared).value();
    if (!sampler->contract.finite_support_cardinality.has_value() ||
        fixed_support_snapshot.size() !=
            *sampler->contract.finite_support_cardinality ||
        has_duplicate_samples(fixed_support_snapshot)) {
      return Result<FixedDrawBank>::failure(sampling_diagnostic(
          DiagnosticCategory::input_validation,
          "c24.invalid_fixed_bank_support_snapshot",
          "a finite fixed draw bank requires one exact declared support "
          "snapshot with the sealed cardinality and distinct atoms"));
    }
    for (const Sample& atom : fixed_support_snapshot) {
      auto validation = validate_sealed_completed_sample(
          *sampler, state, atom);
      if (!validation) {
        return Result<FixedDrawBank>::failure(validation.error());
      }
    }
  }
  std::vector<Sample> samples;
  std::vector<SamplingReplicationReplayV1> replay_streams;
  try {
    samples.reserve(replications);
    replay_streams.reserve(replications);
    for (std::size_t index = 0U; index < replications; ++index) {
      const BigNat replication_index(
          static_cast<std::uint64_t>(index));
      auto bank = C24RngAccess::make(
          access.seal_digest(), row_digest.value(), plan.estimator_id,
          replication_index, plan.seed, plan.stage);
      if (!bank) {
        return Result<FixedDrawBank>::failure(bank.error());
      }
      auto sample = fixed_support_snapshot.empty()
                        ? draw_conditional_sample(access, state, bank.value())
                        : draw_conditional_sample_from_frozen_support(
                              access, state, bank.value(),
                              fixed_support_snapshot);
      auto replay = C24RngAccess::capture_replay_record(bank.value());
      if (!sample) {
        // Binding failures can precede RNG consumption.  A completed replay
        // record is the typed witness that the generator was actually
        // entered; retain it before propagating the failed draw.
        if (!C24RngAccess::draw_was_consumed(bank.value())) {
          return Result<FixedDrawBank>::failure(sample.error());
        }
        if (!replay) {
          return Result<FixedDrawBank>::failure(replay.error());
        }
        auto accounted = record_consumed_sampling_draw(
            observer, replay.value(), true);
        if (!accounted) {
          return Result<FixedDrawBank>::failure(accounted.error());
        }
        return Result<FixedDrawBank>::failure(sample.error());
      }
      if (!replay) {
        return Result<FixedDrawBank>::failure(replay.error());
      }
      auto accounted = record_consumed_sampling_draw(
          observer, replay.value(), false);
      if (!accounted) {
        return Result<FixedDrawBank>::failure(accounted.error());
      }
      samples.push_back(std::move(sample).value());
      replay_streams.push_back(std::move(replay).value());
    }
    return Result<FixedDrawBank>::success(
        {std::move(samples), std::move(replay_streams),
         std::move(fixed_support_snapshot)});
  } catch (const std::bad_alloc&) {
    return Result<FixedDrawBank>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.sample_bank_allocation_failure",
        "the fixed residual sample bank exhausted memory"));
  }
}

[[nodiscard]] std::size_t canonical_byte_count(
    const ConditioningState& state, const std::span<const Sample> samples) {
  std::size_t total = state.codec.id.size() + state.canonical_value.size();
  for (const Sample& sample : samples) {
    total += sample.successor_state.codec.id.size() +
             sample.successor_state.canonical_value.size();
    for (const auto& mark : sample.ordered_marks) {
      total += mark.codec.id.size() + mark.canonical_value.size();
    }
  }
  return total;
}

}  // namespace

Result<std::size_t> fixed_replication_count(const SamplingPlanCore& plan) {
  const BigInt maximum = std::numeric_limits<std::size_t>::max();
  if (plan.accuracy.replications.is_zero() ||
      plan.accuracy.replications.value() > maximum) {
    return Result<std::size_t>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.replication_count_not_addressable",
        "the positive fixed replication count must fit the host address "
        "space"));
  }
  return Result<std::size_t>::success(
      plan.accuracy.replications.value().convert_to<std::size_t>());
}

}  // namespace mwperf::sampling::detail

namespace mwperf {
namespace {

using sampling::detail::C24CoreAccess;
using sampling::detail::CompensatedSum;
using sampling::detail::OutwardDirection;
using sampling::detail::StableMoments;
using sampling::detail::StatisticalFloat;
using sampling::detail::finite_statistical;
using sampling::detail::outward_image;
using sampling::detail::statistical_image;

[[nodiscard]] SamplingCostCountersV1 costs_for(
    const std::size_t draws, const std::size_t failed,
    const std::size_t exact_atoms, const std::size_t bytes) {
  return {BigNat(static_cast<std::uint64_t>(draws)),
          BigNat(static_cast<std::uint64_t>(failed)),
          BigNat(static_cast<std::uint64_t>(exact_atoms)), BigNat(0U),
          BigNat(static_cast<std::uint64_t>(bytes))};
}

[[nodiscard]] SamplingEvidenceSnapshotV1 sampling_evidence_for(
    const ConditionalSamplerContractV1& contract) {
  return {contract.runtime_provenance,
          contract.normalization_evidence,
          contract.termination_evidence,
          contract.v1_evidence_scope,
          contract.v1_evidence_reference,
          contract.v2_evidence_scope,
          contract.v2_evidence_reference,
          contract.foreign_construction_evidence};
}

[[nodiscard]] Result<void> validate_interval_plan(
    const SamplingPlanSpecV1& spec) {
  if (spec.accuracy.confidence_level <= ExactRational::zero() ||
      spec.accuracy.confidence_level >= ExactRational::one()) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.invalid_confidence_level",
        "a Monte Carlo confidence level must lie strictly between zero and "
        "one"));
  }
  switch (spec.accuracy.estimand) {
    case StatisticalEstimandKindV1::binary_proportion:
    case StatisticalEstimandKindV1::bounded_iid:
    case StatisticalEstimandKindV1::point_with_variance_diagnostics:
      break;
    default:
      return Result<void>::failure(sampling::detail::sampling_diagnostic(
          DiagnosticCategory::input_validation,
          "c24.unknown_statistical_estimand",
          "the sampling plan uses an estimand outside analysis-v1"));
  }
  switch (spec.accuracy.interval) {
    case StatisticalIntervalKindV1::exact_binomial:
      if (spec.accuracy.estimand !=
              StatisticalEstimandKindV1::binary_proportion ||
          !spec.accuracy.almost_sure_lower.has_value() ||
          !spec.accuracy.almost_sure_upper.has_value() ||
          *spec.accuracy.almost_sure_lower != ExactRational::zero() ||
          *spec.accuracy.almost_sure_upper != ExactRational::one()) {
        return Result<void>::failure(sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.exact_binomial_estimand_mismatch",
            "exact_binomial is available only for a binary proportion with "
            "an authored almost-sure range exactly [0,1]"));
      }
      break;
    case StatisticalIntervalKindV1::hoeffding:
      if ((spec.accuracy.estimand !=
               StatisticalEstimandKindV1::bounded_iid &&
           spec.accuracy.estimand !=
               StatisticalEstimandKindV1::binary_proportion) ||
          !spec.accuracy.almost_sure_lower.has_value() ||
          !spec.accuracy.almost_sure_upper.has_value() ||
          *spec.accuracy.almost_sure_lower >
              *spec.accuracy.almost_sure_upper) {
        return Result<void>::failure(sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.hoeffding_contract_incomplete",
            "Hoeffding requires a bounded estimand and ordered almost-sure "
            "reward bounds"));
      }
      break;
    case StatisticalIntervalKindV1::none:
      if (spec.accuracy.estimand != StatisticalEstimandKindV1::
                                          point_with_variance_diagnostics) {
        return Result<void>::failure(sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.none_estimand_mismatch",
            "the analysis-v1 no-interval contract requires the "
            "point-with-variance-diagnostics estimand"));
      }
      break;
    default:
      return Result<void>::failure(sampling::detail::sampling_diagnostic(
          DiagnosticCategory::input_validation,
          "c24.unsupported_interval_method",
          "the sampling plan requests an interval outside analysis-v1"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_empirical_row_plan(
    const sampling::detail::SamplingPlanCore& plan,
    const ConditionalSampleDependenceV1 dependence) {
  if (plan.request_rao_blackwellization) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.empirical_row_rao_blackwell_not_supported",
        "a discrete empirical-row estimator cannot request reward "
        "Rao--Blackwellization"));
  }
  if (plan.accuracy.interval != StatisticalIntervalKindV1::none) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.empirical_row_reward_interval_not_supported",
        "a discrete empirical row cannot publish a reward confidence "
        "interval; use its separately authored finite-support TV request"));
  }
  if (dependence == ConditionalSampleDependenceV1::iid_proposal) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.proposal_requires_importance_estimator",
        "a proposal-law sampler cannot publish a target empirical row; "
        "use the bound importance estimator"));
  }
  if (plan.accepted_backend_route !=
      BackendRouteKindV1::conditional_row_monte_carlo) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.empirical_row_requires_row_route",
        "empirical-row estimation requires the C14-accepted conditional-row "
        "Monte Carlo backend route"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_reward_plan(
    const sampling::detail::SamplingPlanCore& plan,
    const ConditionalSampleDependenceV1 dependence) {
  if (plan.total_variation.has_value()) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.reward_total_variation_not_supported",
        "a scalar reward estimator cannot publish an empirical-row total "
        "variation statement"));
  }
  if (dependence == ConditionalSampleDependenceV1::iid_proposal) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.proposal_requires_importance_estimator",
        "a proposal-law sampler cannot publish a target reward estimate or "
        "Rao--Blackwell estimate; use the bound importance estimator"));
  }
  if (plan.accepted_backend_route !=
      BackendRouteKindV1::conditional_reward_monte_carlo) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.reward_requires_reward_route",
        "reward and Rao--Blackwell estimation require the C14-accepted "
        "conditional-reward Monte Carlo backend route"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_importance_plan(
    const sampling::detail::SamplingPlanCore& plan) {
  if (plan.total_variation.has_value()) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.importance_total_variation_not_supported",
        "a self-normalized importance estimate cannot publish an "
        "empirical-row total variation statement"));
  }
  if (plan.request_rao_blackwellization) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.importance_rao_blackwell_not_supported",
        "the core-v1 self-normalized importance estimator has no "
        "Rao--Blackwell branch"));
  }
  if (plan.accuracy.interval != StatisticalIntervalKindV1::none) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.importance_interval_not_supported",
        "self-normalized importance estimates do not inherit exact "
        "binomial or Hoeffding finite-sample intervals"));
  }
  if (plan.accepted_backend_route !=
      BackendRouteKindV1::conditional_reward_monte_carlo) {
    return Result<void>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.importance_requires_reward_route",
        "self-normalized importance estimation requires the C14-accepted "
        "conditional-reward Monte Carlo backend route"));
  }
  return Result<void>::success();
}

}  // namespace

Result<SamplingPlan> SamplingPlan::from_accepted_clause(
    const NormalizedSamplerAccess& access, SamplingPlanSpecV1 spec) {
  const auto& sampler = C24CoreAccess::sampler_core(access);
  if (!sampler) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.sampling_plan_requires_validated_access",
            "a C24 plan can be minted only from a validated normalized "
            "sampler handle"));
  }
  const auto accepted = std::ranges::find_if(
      sampler->accepted_sampling_clauses,
      [&](const AcceptedSamplingClauseV1& clause) {
        return clause.metric_target_digest == spec.metric_target_digest;
      });
  if (accepted == sampler->accepted_sampling_clauses.end()) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.sampling_plan_target_not_accepted",
            "the plan target must be the canonical support-clause digest "
            "of a C17-sealed accepted Monte Carlo row/reward route"));
  }
  if (!spec.fixed_budget || spec.estimator_id.empty() ||
      !sampling::detail::nonzero_digest(spec.metric_target_digest) ||
      spec.accuracy.replications.is_zero() ||
      spec.draw_cap < spec.accuracy.replications ||
      !sampling::detail::valid_stage(spec.stage)) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_fixed_sampling_plan",
            "a C24 plan requires a named fixed positive replication count, "
            "a sufficient draw cap, and an admitted typed RNG stage"));
  }
  if (spec.stage !=
      sampling::detail::required_sampler_stage(sampler->contract)) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.sampling_plan_reveal_stage_mismatch",
            "the plan RNG stage must equal the stage implied by the sealed "
            "sampler reveal and proposal-dependence contract"));
  }
  auto address_probe = make_estimator_instance_key(
      spec.metric_target_digest, spec.metric_target_digest,
      spec.estimator_id, BigNat(0U));
  if (!address_probe) {
    return Result<SamplingPlan>::failure(address_probe.error());
  }
  auto intervals = validate_interval_plan(spec);
  if (!intervals) {
    return Result<SamplingPlan>::failure(intervals.error());
  }
  if (spec.accuracy != accepted->accepted_accuracy) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.sampling_plan_accuracy_not_accepted",
            "the fixed replication count, confidence, interval, estimand, "
            "and bounds must exactly equal the C14 accuracy retained by the "
            "accepted C17 sampling clause"));
  }
  if (!sampler->accepted_generator_draw_cap.has_value() ||
      spec.draw_cap > *sampler->accepted_generator_draw_cap) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.sampling_plan_draw_cap_exceeds_accepted_grant",
            "the sampling-plan draw cap must not exceed the hard generator-"
            "draw grant retained from the accepted C14 analysis request"));
  }
  if (spec.total_variation.has_value() &&
      (!std::isfinite(spec.total_variation->epsilon) ||
       !std::isfinite(spec.total_variation->alpha) ||
       spec.total_variation->epsilon <= 0.0L ||
       spec.total_variation->alpha <= 0.0L ||
       spec.total_variation->alpha >= 1.0L ||
       spec.total_variation->simultaneous_rows == 0U)) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_total_variation_request",
            "a TV request requires positive epsilon, alpha in (0,1), and a "
            "positive explicit row-family size"));
  }
  // C14 owns the authored statistical procedure and hard sampling budget.
  // C24 freezes that accepted accuracy verbatim and adds only the concrete
  // estimator/RNG address and estimator-specific options.
  auto digest = sampling::detail::plan_digest(spec, *sampler, *accepted);
  if (!digest) {
    return Result<SamplingPlan>::failure(digest.error());
  }
  try {
    auto core = std::make_shared<const sampling::detail::SamplingPlanCore>(
        sampling::detail::SamplingPlanCore{
            std::move(spec.accuracy), spec.seed,
            std::move(spec.estimator_id),
            std::move(spec.metric_target_digest), std::move(spec.draw_cap),
            spec.stage, spec.request_rao_blackwellization,
            spec.total_variation, std::move(digest).value(),
            sampler->seal_digest, sampler->accepted_contract_digest,
            accepted->clause_id, accepted->backend_route,
            accepted->accepted_accuracy, sampler->contract.reveal_stage,
            sampler->contract.dependence});
    return Result<SamplingPlan>::success(
        C24CoreAccess::sampling_plan(std::move(core)));
  } catch (const std::bad_alloc&) {
    return Result<SamplingPlan>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.sampling_plan_allocation_failure",
            "sampling plan construction exhausted memory"));
  }
}

Result<BigNat> SamplingPlan::sufficient_iid_tv_budget(
    const std::size_t support_cardinality, const long double epsilon,
    const long double alpha, const std::size_t simultaneous_rows) {
  if (support_cardinality == 0U || simultaneous_rows == 0U ||
      !std::isfinite(epsilon) || !std::isfinite(alpha) ||
      epsilon <= 0.0L || alpha <= 0.0L || alpha >= 1.0L) {
    return Result<BigNat>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.invalid_tv_budget_inputs",
        "the IID TV budget requires finite positive support cardinality and "
        "epsilon, alpha in (0,1), and a positive row-family size"));
  }
  using sampling::detail::StatisticalFloat;
  try {
    const StatisticalFloat epsilon_image =
        sampling::detail::statistical_image(epsilon);
    const StatisticalFloat alpha_image =
        sampling::detail::statistical_image(alpha);
    const StatisticalFloat support_image =
        sampling::detail::statistical_image(support_cardinality);
    const StatisticalFloat rows_image =
        sampling::detail::statistical_image(simultaneous_rows);
    using boost::multiprecision::ceil;
    using boost::multiprecision::log;
    const StatisticalFloat numerator =
        support_image * log(StatisticalFloat{2}) + log(rows_image) -
        log(alpha_image);
    const StatisticalFloat real_required =
        numerator /
        (StatisticalFloat{2} * epsilon_image * epsilon_image);
    const StatisticalFloat required = ceil(real_required);
    const StatisticalFloat maximum(
        std::to_string(std::numeric_limits<std::uint64_t>::max()));
    if (!sampling::detail::finite_statistical(required) || required <= 0 ||
        required > maximum) {
      return Result<BigNat>::failure(sampling::detail::sampling_diagnostic(
          DiagnosticCategory::resource_limit,
          "c24.tv_budget_not_addressable",
          "the sufficient IID TV budget is outside the version-1 "
          "addressable range"));
    }
    std::uint64_t candidate = required.convert_to<std::uint64_t>();
    const StatisticalFloat log_target = log(alpha_image);
    const StatisticalFloat numerical_guard("1e-80");
    const auto log_bound = [&](const std::uint64_t count) {
      return log(rows_image) + support_image * log(StatisticalFloat{2}) -
             StatisticalFloat{2} * StatisticalFloat(count) * epsilon_image *
                 epsilon_image;
    };
    // Verify the integer after the ceiling in the promoted domain.  Values
    // within the high-precision guard of equality are widened by one sample.
    while (log_bound(candidate) >
           log_target - numerical_guard *
                            (abs(log_target) + abs(log_bound(candidate)) + 1)) {
      if (candidate == std::numeric_limits<std::uint64_t>::max()) {
        return Result<BigNat>::failure(sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.tv_budget_not_addressable",
            "the conservatively rounded IID TV budget exceeds the "
            "version-1 addressable range"));
      }
      ++candidate;
    }
    return Result<BigNat>::success(BigNat(candidate));
  } catch (const std::exception&) {
    return Result<BigNat>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.tv_budget_not_addressable",
        "the sufficient IID TV budget could not be evaluated in the promoted "
        "statistical domain"));
  }
}

const MonteCarloAccuracyV1& SamplingPlan::accuracy() const noexcept {
  return core_->accuracy;
}
MasterSeed SamplingPlan::seed() const noexcept { return core_->seed; }
std::string_view SamplingPlan::estimator_id() const noexcept {
  return core_->estimator_id;
}
const Digest256& SamplingPlan::metric_target_digest() const noexcept {
  return core_->metric_target_digest;
}
const Digest256& SamplingPlan::plan_digest() const noexcept {
  return core_->plan_digest;
}
const Digest256& SamplingPlan::seal_digest() const noexcept {
  return core_->seal_digest;
}
const Digest256& SamplingPlan::accepted_contract_digest() const noexcept {
  return core_->accepted_contract_digest;
}
const MetricClauseIdV1& SamplingPlan::accepted_clause_id() const noexcept {
  return core_->accepted_clause_id;
}
BackendRouteKindV1 SamplingPlan::accepted_backend_route() const noexcept {
  return core_->accepted_backend_route;
}
const MonteCarloAccuracyV1& SamplingPlan::accepted_clause_accuracy()
    const noexcept {
  return core_->accepted_clause_accuracy;
}
const BigNat& SamplingPlan::replications() const noexcept {
  return core_->accuracy.replications;
}
const BigNat& SamplingPlan::draw_cap() const noexcept {
  return core_->draw_cap;
}
StageTag SamplingPlan::stage() const noexcept { return core_->stage; }
bool SamplingPlan::requests_rao_blackwellization() const noexcept {
  return core_->request_rao_blackwellization;
}
const std::optional<TotalVariationRequestV1>&
SamplingPlan::total_variation_request() const noexcept {
  return core_->total_variation;
}

Result<SamplingExecutionObserverV1> SamplingExecutionObserverV1::for_plan(
    const SamplingPlan& plan) {
  try {
    return Result<SamplingExecutionObserverV1>::success(
        SamplingExecutionObserverV1(
            std::make_shared<sampling::detail::SamplingExecutionState>(
                sampling::detail::SamplingExecutionState{
                    plan.plan_digest(), plan.stage(), plan.draw_cap(),
                    BigNat{0U}, BigNat{0U}, {}, false})));
  } catch (const std::bad_alloc&) {
    return Result<SamplingExecutionObserverV1>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.sampling_observer_allocation_failure",
            "creating execution-local sampling accounting exhausted "
            "memory"));
  }
}

const Digest256& SamplingExecutionObserverV1::plan_digest() const noexcept {
  return state_->plan_digest;
}

StageTag SamplingExecutionObserverV1::stage() const noexcept {
  return state_->stage;
}

const BigNat& SamplingExecutionObserverV1::draw_cap() const noexcept {
  return state_->draw_cap;
}

const BigNat& SamplingExecutionObserverV1::generator_draws() const noexcept {
  return state_->generator_draws;
}

const BigNat& SamplingExecutionObserverV1::failed_draws() const noexcept {
  return state_->failed_draws;
}

std::span<const SamplingReplicationReplayV1>
SamplingExecutionObserverV1::replay_streams() const noexcept {
  return state_->replay_streams;
}

std::span<const Sample> EmpiricalResidual::samples() const noexcept {
  return core_->samples;
}
const Digest256& EmpiricalResidual::seal_digest() const noexcept {
  return core_->seal_digest;
}
const Digest256& EmpiricalResidual::conditioning_row_digest() const noexcept {
  return core_->conditioning_row_digest;
}
const Digest256& EmpiricalResidual::plan_digest() const noexcept {
  return core_->plan_digest;
}
const Digest256& EmpiricalResidual::metric_target_digest() const noexcept {
  return core_->metric_target_digest;
}

EmpiricalResidual Estimate::empirical_residual() const {
  if (!empirical_residual_) {
    throw std::logic_error("estimate has no empirical residual bank");
  }
  return C24CoreAccess::empirical_residual(empirical_residual_);
}

[[nodiscard]] static Result<EmpiricalRow> estimate_discrete_kernel_row_impl(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const SamplingPlan& plan, SamplingExecutionObserverV1& observer) {
  const auto& sampler = C24CoreAccess::sampler_core(access);
  const auto& plan_core = C24CoreAccess::plan_core(plan);
  if (!sampler || !plan_core ||
      state.codec != sampler->shape.conditioning_state_codec) {
    return Result<EmpiricalRow>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_empirical_row_binding",
            "empirical row estimation requires one validated sampler, plan, "
            "and conditioning row"));
  }
  auto access_binding = sampling::detail::validate_plan_access_binding(
      *sampler, *plan_core);
  if (!access_binding) {
    return Result<EmpiricalRow>::failure(access_binding.error());
  }
  auto conditioning_domain = sampling::detail::validate_sealed_state_domain(
      sampler->validate_state_domain, state, false);
  if (!conditioning_domain) {
    return Result<EmpiricalRow>::failure(conditioning_domain.error());
  }
  auto plan_validation = validate_empirical_row_plan(
      *plan_core, sampler->contract.dependence);
  if (!plan_validation) {
    return Result<EmpiricalRow>::failure(plan_validation.error());
  }
  auto count_result = sampling::detail::fixed_replication_count(*plan_core);
  if (!count_result) {
    return Result<EmpiricalRow>::failure(count_result.error());
  }
  const std::size_t count = count_result.value();
  auto observer_claim = sampling::detail::claim_sampling_execution(
      observer, *plan_core, count);
  if (!observer_claim) {
    return Result<EmpiricalRow>::failure(observer_claim.error());
  }
  const bool iid = sampler->contract.dependence ==
                       ConditionalSampleDependenceV1::iid_cold_replications ||
                   sampler->contract.dependence ==
                       ConditionalSampleDependenceV1::iid_proposal;
  if (plan_core->total_variation.has_value()) {
    if (!iid || sampler->contract.support_kind !=
                    ConditionalSupportKindV1::finite_declared ||
        !sampler->contract.finite_support_cardinality.has_value()) {
      return Result<EmpiricalRow>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.tv_bound_premise_mismatch",
              "the finite-support TV statement requires IID cold draws and "
              "an exactly declared finite row support"));
    }
    auto required = SamplingPlan::sufficient_iid_tv_budget(
        *sampler->contract.finite_support_cardinality,
        plan_core->total_variation->epsilon,
        plan_core->total_variation->alpha,
        plan_core->total_variation->simultaneous_rows);
    if (!required) {
      return Result<EmpiricalRow>::failure(required.error());
    }
    if (plan_core->accuracy.replications < required.value()) {
      return Result<EmpiricalRow>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.insufficient_tv_replication_budget",
              "the authored fixed replication count does not meet the "
              "declared finite-support TV procedure"));
    }
  }

  auto bank_result = sampling::detail::draw_fixed_bank(
      access, state, *plan_core, count, observer);
  if (!bank_result) {
    return Result<EmpiricalRow>::failure(bank_result.error());
  }
  auto bank = std::move(bank_result).value();
  std::vector<Sample> support = std::move(bank.finite_support_snapshot);
  const std::vector<Sample>& samples = bank.samples;
  if (support.empty()) {
    std::vector<std::pair<Digest256, Sample>> keyed_support;
    for (const Sample& sample : samples) {
      if (std::find(support.begin(), support.end(), sample) !=
          support.end()) {
        continue;
      }
      auto digest = sampling::detail::sample_digest(sample);
      if (!digest) return Result<EmpiricalRow>::failure(digest.error());
      support.push_back(sample);
      keyed_support.emplace_back(std::move(digest).value(), sample);
    }
    std::sort(keyed_support.begin(), keyed_support.end(),
              [](const auto& left, const auto& right) {
                return left.first < right.first;
              });
    support.clear();
    support.reserve(keyed_support.size());
    for (auto& keyed : keyed_support) {
      support.push_back(std::move(keyed.second));
    }
  }
  std::vector<EmpiricalRowAtomV1> atoms;
  atoms.reserve(support.size());
  BigNat counted_total(0U);
  ExactRational probability_total = ExactRational::zero();
  for (const Sample& atom : support) {
    const std::size_t occurrences = static_cast<std::size_t>(
        std::count(samples.begin(), samples.end(), atom));
    BigNat exact_count(static_cast<std::uint64_t>(occurrences));
    auto probability = ExactRational::make(
        exact_count.value(), plan_core->accuracy.replications.value());
    if (!probability) {
      return Result<EmpiricalRow>::failure(probability.error());
    }
    atoms.push_back({atom, std::move(exact_count),
                     std::move(probability).value()});
    counted_total = counted_total + atoms.back().count;
    probability_total = probability_total + atoms.back().probability;
  }
  if (counted_total != plan_core->accuracy.replications ||
      probability_total != ExactRational::one()) {
    return Result<EmpiricalRow>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.empirical_row_exact_normalization_failure",
            "the exact published counts and rational probabilities must "
            "sum to the authored fixed replication total and one"));
  }
  auto row_digest = sampling::detail::conditioning_state_digest(state);
  if (!row_digest) {
    return Result<EmpiricalRow>::failure(row_digest.error());
  }
  std::optional<TotalVariationBoundV1> tv_bound;
  if (plan_core->total_variation.has_value()) {
    using sampling::detail::StatisticalFloat;
    const StatisticalFloat epsilon = sampling::detail::statistical_image(
        plan_core->total_variation->epsilon);
    using boost::multiprecision::exp;
    using boost::multiprecision::log;
    const StatisticalFloat exponent =
        sampling::detail::statistical_image(support.size()) *
            log(StatisticalFloat{2}) -
        StatisticalFloat{2} * sampling::detail::statistical_image(count) *
            epsilon * epsilon +
        log(sampling::detail::statistical_image(
            plan_core->total_variation->simultaneous_rows));
    if (!sampling::detail::finite_statistical(exponent)) {
      return Result<EmpiricalRow>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::resource_limit,
              "c24.tv_failure_bound_not_representable",
              "the requested finite-support TV failure bound is not "
              "representable in the analysis-v1 numeric image"));
    }
    long double advertised_failure_bound = 1.0L;
    if (exponent < 0) {
      const long double least_positive =
          std::numeric_limits<long double>::denorm_min() > 0.0L
              ? std::numeric_limits<long double>::denorm_min()
              : std::numeric_limits<long double>::min();
      const StatisticalFloat least_positive_image =
          sampling::detail::statistical_image(least_positive);
      if (exponent < log(least_positive_image)) {
        // The mathematical exponential is strictly positive but lies below
        // every positive host value.  Publishing the least positive value is
        // the tightest representable conservative upper bound and avoids a
        // false zero caused by multiprecision exponential underflow.
        advertised_failure_bound = least_positive;
      } else {
        // Inflate in the promoted domain before directed conversion.  This
        // covers the finite cpp_dec_float evaluation error as well as the
        // host long-double conversion error.
        const StatisticalFloat exact_bound =
            exp(exponent) *
            (StatisticalFloat{1} + StatisticalFloat("1e-80"));
        auto outward = sampling::detail::outward_image(
            exact_bound, sampling::detail::OutwardDirection::upward);
        if (!outward || *outward <= 0.0L) {
          return Result<EmpiricalRow>::failure(
              sampling::detail::sampling_diagnostic(
                  DiagnosticCategory::resource_limit,
                  "c24.tv_failure_bound_not_representable",
                  "the requested finite-support TV failure bound has no "
                  "positive finite outward long-double image"));
        }
        advertised_failure_bound = std::min(1.0L, *outward);
      }
    }
    tv_bound = TotalVariationBoundV1{
        support.size(),
        plan_core->total_variation->epsilon,
        plan_core->total_variation->alpha,
        plan_core->total_variation->simultaneous_rows,
        advertised_failure_bound,
        true,
        true,
        SamplingClaimScopeV1::row_conditional_surrogate};
  }
  return Result<EmpiricalRow>::success(C24CoreAccess::empirical_row(
      plan_core->accuracy.replications, std::move(atoms), iid,
      sampler->seal_digest, std::move(row_digest).value(),
      plan_core->plan_digest, plan_core->metric_target_digest,
      sampling_evidence_for(sampler->contract),
      costs_for(count, 0U, 0U,
                sampling::detail::canonical_byte_count(state, samples)),
      std::move(bank.replay_streams),
      tv_bound, 0U));
}

[[nodiscard]] static Result<Estimate> estimate_reward_expectation_impl(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const RewardDecoder& reward, const SamplingPlan& plan,
    SamplingExecutionObserverV1& observer) {
  const auto& sampler = C24CoreAccess::sampler_core(access);
  const auto& plan_core = C24CoreAccess::plan_core(plan);
  if (!sampler || !plan_core ||
      state.codec != sampler->shape.conditioning_state_codec) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_reward_estimator_binding",
            "reward estimation requires one validated sampler, plan, and "
            "conditioning row"));
  }
  auto access_binding = sampling::detail::validate_plan_access_binding(
      *sampler, *plan_core);
  if (!access_binding) {
    return Result<Estimate>::failure(access_binding.error());
  }
  auto plan_validation = validate_reward_plan(
      *plan_core, sampler->contract.dependence);
  if (!plan_validation) {
    return Result<Estimate>::failure(plan_validation.error());
  }
  auto decoder_result = sampling::detail::validate_reward(
      reward, *plan_core, *sampler, false);
  if (!decoder_result) {
    return Result<Estimate>::failure(decoder_result.error());
  }
  const ConditionalSamplingRewardV1& decoder = *decoder_result.value();
  if (plan_core->request_rao_blackwellization &&
      plan_core->accuracy.interval ==
          StatisticalIntervalKindV1::exact_binomial) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_exact_binomial_invalid",
            "an exact-binomial interval cannot be transferred to a "
            "generally fractional conditional expectation h(C)"));
  }
  std::optional<AuditedExactInnovationKernel> bound_innovation;
  if (plan_core->request_rao_blackwellization) {
    auto innovation = access.bind_exact_innovation_kernel(state, plan);
    if (!innovation) {
      return Result<Estimate>::failure(innovation.error());
    }
    bound_innovation.emplace(std::move(innovation).value());
  }
  auto count_result = sampling::detail::fixed_replication_count(*plan_core);
  if (!count_result) {
    return Result<Estimate>::failure(count_result.error());
  }
  const std::size_t count = count_result.value();
  auto observer_claim = sampling::detail::claim_sampling_execution(
      observer, *plan_core, count);
  if (!observer_claim) {
    return Result<Estimate>::failure(observer_claim.error());
  }
  auto bank_result = sampling::detail::draw_fixed_bank(
      access, state, *plan_core, count, observer);
  if (!bank_result) {
    return Result<Estimate>::failure(bank_result.error());
  }
  auto bank = std::move(bank_result).value();
  const std::vector<Sample>& samples = bank.samples;
  auto row_digest = sampling::detail::conditioning_state_digest(state);
  if (!row_digest) {
    return Result<Estimate>::failure(row_digest.error());
  }
  auto residual =
      std::make_shared<const sampling::detail::EmpiricalResidualCore>(
          sampling::detail::EmpiricalResidualCore{
              sampler, state, samples, std::move(bank.replay_streams),
              sampler->seal_digest,
              row_digest.value(), plan_core->plan_digest,
              plan_core->metric_target_digest,
              sampler->contract.configured_arrival_law,
              sampler->contract.residual_schema,
              sampler->contract.output_schema,
              sampler->contract.dependence ==
                      ConditionalSampleDependenceV1::iid_cold_replications ||
                  sampler->contract.dependence ==
                      ConditionalSampleDependenceV1::iid_proposal,
              plan_core->request_rao_blackwellization,
              plan_core->accuracy});
  if (plan_core->request_rao_blackwellization) {
    return rao_blackwellize_known_innovation(
        C24CoreAccess::empirical_residual(residual), *bound_innovation,
        reward);
  }
  std::vector<long double> rewards;
  rewards.reserve(count);
  StableMoments moments;
  std::size_t successes = 0U;
  for (const Sample& sample : samples) {
    auto decoded = sampling::detail::invoke_guarded<long double>(
        "the row-conditional reward decoder",
        [&] {
          auto decode = decoder.decode;
          return decode(state, sample);
        });
    if (!decoded || !std::isfinite(decoded.value())) {
      return Result<Estimate>::failure(
          decoded ? sampling::detail::sampling_diagnostic(
                        DiagnosticCategory::input_validation,
                        "c24.nonfinite_reward",
                        "the row-conditional reward decoder returned a "
                        "nonfinite value")
                  : decoded.error());
    }
    const long double value = decoded.value();
    if (decoder.binary_indicator && value != 0.0L && value != 1.0L) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.nonbinary_indicator_reward",
              "a reward declared binary must return exactly zero or one"));
    }
    if (decoder.almost_sure_lower.has_value() &&
        !sampling::detail::reward_within_exact_range(
            value, *decoder.almost_sure_lower,
            *decoder.almost_sure_upper)) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.reward_outside_audited_range",
              "the decoded reward violated its audited almost-sure range"));
    }
    successes += value == 1.0L ? 1U : 0U;
    moments.add(value);
    rewards.push_back(value);
  }
  if (!moments.finite()) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.reward_moment_overflow",
            "the fixed reward bank produced nonfinite stable moment "
            "diagnostics"));
  }
  std::optional<FixedSampleIntervalV1> interval;
  if (plan_core->accuracy.interval ==
      StatisticalIntervalKindV1::exact_binomial) {
    auto exact = sampling::detail::clopper_pearson(
        successes, count, plan_core->accuracy.confidence_level,
        sampler->contract.dependence);
    if (!exact) return Result<Estimate>::failure(exact.error());
    interval = std::move(exact).value();
  } else if (plan_core->accuracy.interval ==
             StatisticalIntervalKindV1::hoeffding) {
    auto bounded = sampling::detail::hoeffding_interval(
        moments.mean, *decoder.almost_sure_lower,
        *decoder.almost_sure_upper, plan_core->accuracy,
        sampler->contract.dependence,
        SamplingClaimScopeV1::row_conditional_surrogate,
        "two-sided fixed-budget Hoeffding coverage for one bounded "
        "row-conditional surrogate reward");
    if (!bounded) return Result<Estimate>::failure(bounded.error());
    interval = std::move(bounded).value();
  }
  Estimate raw = C24CoreAccess::estimate(
      moments.mean, moments.sample_variance(), std::move(interval),
      SamplingClaimScopeV1::row_conditional_surrogate,
      plan_core->accuracy.replications, std::move(rewards), {},
      std::nullopt, std::nullopt,
      costs_for(count, 0U, 0U,
                sampling::detail::canonical_byte_count(
                    state, samples)),
      sampling_evidence_for(sampler->contract),
      residual->replay_streams,
      sampler->seal_digest, row_digest.value(), plan_core->plan_digest,
      plan_core->metric_target_digest, std::nullopt, std::nullopt,
      residual);
  return Result<Estimate>::success(std::move(raw));
}

[[nodiscard]] static Result<Estimate> estimate_importance_weighted_impl(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const AuditedTargetDensityRatio& ratio, const RewardDecoder& reward,
    const SamplingPlan& plan, SamplingExecutionObserverV1& observer) {
  const auto& sampler = C24CoreAccess::sampler_core(access);
  const auto& plan_core = C24CoreAccess::plan_core(plan);
  const auto& ratio_core = C24CoreAccess::target_ratio_core(ratio);
  if (!sampler || !plan_core || !ratio_core) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_importance_authority",
            "importance estimation requires validated sampler, plan, and "
            "nonconstructible density-ratio authorities"));
  }
  auto access_binding = sampling::detail::validate_plan_access_binding(
      *sampler, *plan_core);
  if (!access_binding) {
    return Result<Estimate>::failure(access_binding.error());
  }
  auto plan_validation = validate_importance_plan(*plan_core);
  if (!plan_validation) {
    return Result<Estimate>::failure(plan_validation.error());
  }
  if (plan_core->stage != StageTag::importance_proposal) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.importance_stage_mismatch",
            "self-normalized importance estimation requires the dedicated "
            "importance-proposal RNG stage"));
  }
  auto row_digest = sampling::detail::conditioning_state_digest(state);
  if (!row_digest) return Result<Estimate>::failure(row_digest.error());
  if (ratio_core->sampler.get() != sampler.get() ||
      ratio_core->seal_digest != sampler->seal_digest ||
      ratio_core->conditioning_row_digest != row_digest.value() ||
      ratio_core->plan_digest != plan_core->plan_digest ||
      ratio_core->metric_target_digest !=
          plan_core->metric_target_digest ||
      ratio_core->proposal_law_identity !=
          sampler->contract.proposal_law_identity ||
      ratio_core->output_schema != sampler->contract.output_schema) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.importance_binding_mismatch",
            "seal, row, plan, target, proposal, and output-schema bindings "
            "must all match before an importance draw"));
  }
  const auto& contract = ratio_core->contract;
  if (contract.target_kind != ImportanceTargetKindV1::transition_row ||
      !contract.transition_ratio_only ||
      !contract.proposal_dominates_target ||
      !contract.positive_finite_weight_mean ||
      !contract.weighted_reward_integrable || !contract.iid_proposal ||
      sampler->contract.dependence !=
          ConditionalSampleDependenceV1::iid_proposal) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.importance_population_premise_missing",
            "core-v1 importance sampling requires audited target domination, "
            "finite positive weight mean, weighted integrability, and IID "
            "proposal provenance"));
  }
  auto decoder_result = sampling::detail::validate_reward(
      reward, *plan_core, *sampler, true);
  if (!decoder_result) return Result<Estimate>::failure(decoder_result.error());
  const auto& decoder = *decoder_result.value();
  if (decoder.decoder_digest != contract.reward_decoder_digest) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.importance_reward_digest_mismatch",
            "the audited target ratio is bound to a different reward "
            "decoder identity"));
  }
  auto count_result = sampling::detail::fixed_replication_count(*plan_core);
  if (!count_result) return Result<Estimate>::failure(count_result.error());
  const std::size_t count = count_result.value();
  auto observer_claim = sampling::detail::claim_sampling_execution(
      observer, *plan_core, count);
  if (!observer_claim) {
    return Result<Estimate>::failure(observer_claim.error());
  }
  auto bank_result = sampling::detail::draw_fixed_bank(
      access, state, *plan_core, count, observer);
  if (!bank_result) return Result<Estimate>::failure(bank_result.error());
  auto bank = std::move(bank_result).value();
  const std::vector<Sample>& samples = bank.samples;

  std::vector<long double> rewards;
  std::vector<long double> log_weights;
  std::vector<ImportanceWeightRecordV1> weight_records;
  rewards.reserve(count);
  log_weights.reserve(count);
  weight_records.reserve(count);
  std::size_t zeros = 0U;
  long double maximum_log =
      -std::numeric_limits<long double>::infinity();
  long double minimum_positive_log =
      std::numeric_limits<long double>::infinity();
  for (const Sample& sample : samples) {
    auto decoded = sampling::detail::invoke_guarded<long double>(
        "the importance reward decoder",
        [&] {
          auto decode = decoder.decode;
          return decode(state, sample);
        });
    if (!decoded || !std::isfinite(decoded.value())) {
      return Result<Estimate>::failure(
          decoded ? sampling::detail::sampling_diagnostic(
                        DiagnosticCategory::input_validation,
                        "c24.nonfinite_importance_reward",
                        "an importance reward must be finite")
                  : decoded.error());
    }
    const long double reward_value = decoded.value();
    if (decoder.binary_indicator && reward_value != 0.0L &&
        reward_value != 1.0L) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.nonbinary_indicator_reward",
              "a reward declared binary must return exactly zero or one"));
    }
    if (decoder.almost_sure_lower.has_value() &&
        !sampling::detail::reward_within_exact_range(
            reward_value, *decoder.almost_sure_lower,
            *decoder.almost_sure_upper)) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.reward_outside_audited_range",
              "the decoded reward violated its audited almost-sure range"));
    }
    auto weight = sampling::detail::invoke_guarded<ImportanceWeightV1>(
        "the audited target density-ratio operation",
        [&] {
          auto ratio_operation = ratio_core->ratio;
          return ratio_operation(state, sample);
        });
    if (!weight) return Result<Estimate>::failure(weight.error());
    long double log_weight;
    switch (weight.value().representation) {
      case ImportanceWeightRepresentationV1::direct_nonnegative: {
        const long double direct = weight.value().value;
        if (!std::isfinite(direct) || std::signbit(direct)) {
          return Result<Estimate>::failure(
              sampling::detail::sampling_diagnostic(
                  DiagnosticCategory::input_validation,
                  "c24.invalid_direct_importance_weight",
                  "a direct importance weight must be finite and "
                  "nonnegative"));
        }
        log_weight = direct == 0.0L
                         ? -std::numeric_limits<long double>::infinity()
                         : std::log(direct);
        break;
      }
      case ImportanceWeightRepresentationV1::log_nonnegative:
        log_weight = weight.value().value;
        if (std::isnan(log_weight) ||
            log_weight == std::numeric_limits<long double>::infinity()) {
          return Result<Estimate>::failure(
              sampling::detail::sampling_diagnostic(
                  DiagnosticCategory::input_validation,
                  "c24.invalid_log_importance_weight",
                  "a log importance weight may be finite or negative "
                  "infinity, but never NaN or positive infinity"));
        }
        break;
      default:
        return Result<Estimate>::failure(
            sampling::detail::sampling_diagnostic(
                DiagnosticCategory::input_validation,
                "c24.unknown_importance_weight_representation",
                "the density-ratio callback returned a weight "
                "representation outside schema v1"));
    }
    if (log_weight == -std::numeric_limits<long double>::infinity()) {
      ++zeros;
    } else {
      maximum_log = std::max(maximum_log, log_weight);
      minimum_positive_log = std::min(minimum_positive_log, log_weight);
    }
    rewards.push_back(reward_value);
    log_weights.push_back(log_weight);
    weight_records.push_back(
        {weight.value().representation, weight.value().value, 0.0L});
  }
  if (!std::isfinite(maximum_log)) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.zero_importance_denominator",
            "all fixed-plan importance weights are zero; C24 does not retry "
            "or change estimators"));
  }
  CompensatedSum denominator;
  CompensatedSum numerator;
  CompensatedSum squares;
  for (std::size_t index = 0U; index < count; ++index) {
    const long double scaled =
        log_weights[index] ==
                -std::numeric_limits<long double>::infinity()
            ? 0.0L
            : std::exp(log_weights[index] - maximum_log);
    if (scaled == 0.0L && std::isfinite(log_weights[index])) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::resource_limit,
              "c24.importance_weight_precision_underflow",
              "a finite positive importance weight underflowed in the "
              "common scaled representation; no altered estimator was "
              "published"));
    }
    weight_records[index].common_scaled_weight = scaled;
    denominator.add(scaled);
    numerator.add(scaled * rewards[index]);
    squares.add(scaled * scaled);
  }
  const long double sum_weights = denominator.value();
  const long double sum_squares = squares.value();
  if (!std::isfinite(sum_weights) || sum_weights <= 0.0L ||
      !std::isfinite(sum_squares) || sum_squares <= 0.0L) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_importance_denominator",
            "the scaled fixed-plan importance denominator is nonfinite or "
            "zero"));
  }
  const long double estimate = numerator.value() / sum_weights;
  const long double maximum_scaled = std::max_element(
      weight_records.begin(), weight_records.end(),
      [](const ImportanceWeightRecordV1& left,
         const ImportanceWeightRecordV1& right) {
        return left.common_scaled_weight < right.common_scaled_weight;
      })->common_scaled_weight;
  long double maximum_normalized = maximum_scaled / sum_weights;
  long double ess = sum_weights * sum_weights / sum_squares;
  const long double positive_dynamic_range =
      maximum_log - minimum_positive_log;
  if (!std::isfinite(estimate) || !std::isfinite(maximum_normalized) ||
      !std::isfinite(ess) || !std::isfinite(positive_dynamic_range) ||
      maximum_normalized < 0.0L ||
      maximum_normalized >
          1.0L + 64.0L * std::numeric_limits<long double>::epsilon() ||
      ess <= 0.0L ||
      ess > static_cast<long double>(count) *
                (1.0L + 64.0L *
                            std::numeric_limits<long double>::epsilon())) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.importance_diagnostic_overflow",
            "the fixed importance bank produced a nonfinite or invalid "
            "estimate, ESS, maximum normalized weight, or positive-weight "
            "dynamic range"));
  }
  maximum_normalized = std::clamp(maximum_normalized, 0.0L, 1.0L);
  ess = std::clamp(ess, 1.0L, static_cast<long double>(count));
  ImportanceDiagnosticsV1 diagnostics{
      ess,
      maximum_normalized,
      zeros,
      positive_dynamic_range,
      zeros != 0U,
      zeros != 0U,
      true,
      true,
      contract.weighted_second_moment};
  return Result<Estimate>::success(C24CoreAccess::estimate(
      estimate, std::nullopt, std::nullopt,
      SamplingClaimScopeV1::self_normalized_target_row,
      plan_core->accuracy.replications, std::move(rewards),
      std::move(weight_records), diagnostics, std::nullopt,
      costs_for(count, 0U, 0U,
                sampling::detail::canonical_byte_count(
                    state, samples)),
      sampling_evidence_for(sampler->contract),
      std::move(bank.replay_streams), sampler->seal_digest,
      row_digest.value(), plan_core->plan_digest,
      plan_core->metric_target_digest,
      sampler->contract.proposal_law_identity,
      ratio_core->contract.target_law_identity));
}

[[nodiscard]] static Result<Estimate> rao_blackwellize_known_innovation_impl(
    const EmpiricalResidual& residual,
    const AuditedExactInnovationKernel& innovation,
    const RewardDecoder& reward) {
  const auto& residual_core = C24CoreAccess::residual_core(residual);
  const auto& innovation_core =
      C24CoreAccess::exact_innovation_core(innovation);
  if (!residual_core || !innovation_core) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_binding_mismatch",
            "Rao--Blackwell integration requires sealed residual and exact-"
            "innovation authorities"));
  }
  if (!residual_core->rao_blackwell_authorized) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_not_requested",
            "the residual bank's accepted sampling plan did not request "
            "Rao--Blackwellization"));
  }
  if (innovation_core->sampler.get() != residual_core->sampler.get() ||
      innovation_core->seal_digest != residual_core->seal_digest ||
      innovation_core->conditioning_row_digest !=
          residual_core->conditioning_row_digest ||
      innovation_core->plan_digest != residual_core->plan_digest ||
      innovation_core->metric_target_digest !=
          residual_core->metric_target_digest ||
      innovation_core->configured_arrival_law !=
          residual_core->configured_arrival_law ||
      innovation_core->residual_schema != residual_core->residual_schema ||
      innovation_core->output_schema != residual_core->output_schema) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_binding_mismatch",
            "Rao--Blackwell integration requires identical seal, row, plan, "
            "target, configured-arrival, residual, and output bindings"));
  }
  if (!reward.conditional_sampling ||
      !reward.conditional_sampling->decode ||
      reward.requires_temporal_continuation ||
      reward.conditional_sampling->decoder_id.empty() ||
      !sampling::detail::nonzero_digest(
          reward.conditional_sampling->decoder_digest) ||
      reward.conditional_sampling->metric_target_digest !=
          residual_core->metric_target_digest ||
      reward.conditional_sampling->decoder_digest !=
          innovation_core->contract.reward_decoder_digest ||
      reward.conditional_sampling->output_schema !=
          residual_core->output_schema ||
      reward.conditional_sampling->integrability != reward.integrability ||
      reward.integrability !=
          StationaryRewardIntegrabilityV1::finite_absolute) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_reward_binding_mismatch",
            "the non-temporal Rao--Blackwell reward must bind its decoder, "
            "integrability class, residual plan target, and completed "
            "output schema"));
  }
  const auto& decoder = *reward.conditional_sampling;
  if (!decoder.finite_second_moment &&
      !(decoder.almost_sure_lower.has_value() &&
        decoder.almost_sure_upper.has_value())) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_second_moment_missing",
            "Rao--Blackwellization requires an audited finite second "
            "moment or a finite almost-sure reward range"));
  }
  if (decoder.almost_sure_lower.has_value() !=
          decoder.almost_sure_upper.has_value() ||
      (decoder.almost_sure_lower.has_value() &&
       (*decoder.almost_sure_lower > *decoder.almost_sure_upper ||
        !std::isfinite(decoder.almost_sure_lower->to_long_double()) ||
        !std::isfinite(decoder.almost_sure_upper->to_long_double())))) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_invalid_reward_range",
            "a Rao--Blackwell reward range must provide two finite ordered "
            "exact bounds"));
  }
  if (residual_core->accuracy.interval ==
      StatisticalIntervalKindV1::exact_binomial) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_exact_binomial_invalid",
            "an exact-binomial interval cannot be transferred to a "
            "generally fractional conditional expectation h(C)"));
  }
  if (residual_core->accuracy.interval ==
          StatisticalIntervalKindV1::hoeffding &&
      (!residual_core->iid_replications ||
       !decoder.almost_sure_lower.has_value() ||
       !decoder.almost_sure_upper.has_value() ||
       !residual_core->accuracy.almost_sure_lower.has_value() ||
       !residual_core->accuracy.almost_sure_upper.has_value() ||
       *decoder.almost_sure_lower !=
           *residual_core->accuracy.almost_sure_lower ||
       *decoder.almost_sure_upper !=
           *residual_core->accuracy.almost_sure_upper)) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_hoeffding_premise_mismatch",
            "Rao--Blackwell Hoeffding coverage requires the same audited "
            "reward range and IID residual bank"));
  }
  std::vector<long double> conditional_means;
  conditional_means.reserve(residual_core->samples.size());
  StableMoments moments;
  std::size_t exact_atoms = 0U;
  StatisticalFloat promoted_integral_sum{0};
  StatisticalFloat promoted_absolute_term_sum{0};
  for (const Sample& residual_sample : residual_core->samples) {
    auto atoms = sampling::detail::invoke_guarded<
        std::vector<ExactInnovationAtomV1>>(
        "the audited exact-innovation operation", [&] {
          auto integrate = innovation_core->integrate;
          return integrate(residual_core->conditioning_state,
                           residual_sample);
        });
    if (!atoms || atoms.value().empty()) {
      return Result<Estimate>::failure(
          atoms ? sampling::detail::sampling_diagnostic(
                      DiagnosticCategory::input_validation,
                      "c24.empty_exact_innovation_row",
                      "an exact innovation row must contain positive total "
                      "mass")
                : atoms.error());
    }
    ExactRational exact_total = ExactRational::zero();
    StatisticalFloat promoted_conditional{0};
    for (const ExactInnovationAtomV1& atom : atoms.value()) {
      auto completed_validation =
          sampling::detail::validate_sealed_completed_sample(
              *residual_core->sampler,
              residual_core->conditioning_state,
              atom.completed_sample);
      if (!completed_validation) {
        return Result<Estimate>::failure(completed_validation.error());
      }
      if (!atom.probability.is_nonnegative()) {
        return Result<Estimate>::failure(
            sampling::detail::sampling_diagnostic(
                DiagnosticCategory::input_validation,
                "c24.negative_exact_innovation_mass",
                "an exact innovation atom cannot have negative mass"));
      }
      exact_total = exact_total + atom.probability;
      auto decoded = sampling::detail::invoke_guarded<long double>(
          "the Rao--Blackwell reward decoder", [&] {
            auto decode = decoder.decode;
            return decode(residual_core->conditioning_state,
                          atom.completed_sample);
          });
      if (!decoded || !std::isfinite(decoded.value())) {
        return Result<Estimate>::failure(
            decoded ? sampling::detail::sampling_diagnostic(
                          DiagnosticCategory::input_validation,
                          "c24.nonfinite_integrated_reward",
                          "the exactly integrated reward must be finite")
                  : decoded.error());
      }
      if (decoder.almost_sure_lower.has_value() &&
          !sampling::detail::reward_within_exact_range(
              decoded.value(), *decoder.almost_sure_lower,
              *decoder.almost_sure_upper)) {
        return Result<Estimate>::failure(
            sampling::detail::sampling_diagnostic(
                DiagnosticCategory::input_validation,
                "c24.integrated_reward_outside_audited_range",
                "an exact-innovation atom decoded outside the audited "
                "almost-sure reward range"));
      }
      const StatisticalFloat product =
          statistical_image(atom.probability) *
          statistical_image(decoded.value());
      promoted_conditional += product;
      promoted_absolute_term_sum += abs(product);
    }
    if (exact_total != ExactRational::one()) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.unnormalized_exact_innovation_row",
              "the configured joint exact-innovation atoms must sum exactly "
              "to one"));
    }
    exact_atoms += atoms.value().size();
    const long double conditional_image =
        promoted_conditional.convert_to<long double>();
    if (!finite_statistical(promoted_conditional) ||
        !std::isfinite(conditional_image)) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.exact_innovation_numerical_overflow",
              "the deterministic innovation integral or its local rounding "
              "error bound became nonfinite"));
    }
    promoted_integral_sum += promoted_conditional;
    moments.add(conditional_image);
    conditional_means.push_back(conditional_image);
  }
  if (!moments.finite()) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_moment_overflow",
            "the conditional-integral bank produced nonfinite stable moment "
            "diagnostics"));
  }
  const StatisticalFloat replication_count =
      statistical_image(residual_core->samples.size());
  const StatisticalFloat promoted_average =
      promoted_integral_sum / replication_count;
  const StatisticalFloat reported_average = statistical_image(moments.mean);
  const StatisticalFloat arithmetic_guard =
      StatisticalFloat("1e-80") *
      (abs(promoted_average) +
       promoted_absolute_term_sum / replication_count + 1);
  const StatisticalFloat numerical_integration_error =
      abs(promoted_average - reported_average) + arithmetic_guard;
  const StatisticalFloat declared_integration_error = statistical_image(
      innovation_core->contract.maximum_absolute_integration_error);
  const StatisticalFloat total_integration_error =
      declared_integration_error + numerical_integration_error;
  auto exact_integration_error_image = outward_image(
      total_integration_error, OutwardDirection::upward);
  if (!finite_statistical(declared_integration_error) ||
      declared_integration_error < 0 || !exact_integration_error_image ||
      *exact_integration_error_image < 0.0L) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.exact_integration_error_not_representable",
            "the declared and local exact-innovation numerical errors "
            "could not be represented by a finite upper bound"));
  }
  const long double exact_integration_error =
      *exact_integration_error_image;
  std::optional<FixedSampleIntervalV1> interval;
  if (residual_core->accuracy.interval ==
      StatisticalIntervalKindV1::hoeffding) {
    auto bounded = sampling::detail::hoeffding_interval(
        moments.mean,
        *decoder.almost_sure_lower,
        *decoder.almost_sure_upper,
        residual_core->accuracy,
        ConditionalSampleDependenceV1::iid_cold_replications,
        SamplingClaimScopeV1::rao_blackwell_row,
        "two-sided fixed-budget Hoeffding coverage for the bounded "
        "numerical Rao--Blackwell integrand, expanded by the separately "
        "reported deterministic integration-error bound");
    if (!bounded) return Result<Estimate>::failure(bounded.error());
    FixedSampleIntervalV1 expanded = std::move(bounded).value();
    expanded.lower = std::max(
        *expanded.almost_sure_lower,
        std::nextafter(
            expanded.lower - exact_integration_error,
            -std::numeric_limits<long double>::infinity()));
    expanded.upper = std::min(
        *expanded.almost_sure_upper,
        std::nextafter(
            expanded.upper + exact_integration_error,
            std::numeric_limits<long double>::infinity()));
    if (!std::isfinite(expanded.lower) ||
        !std::isfinite(expanded.upper) ||
        expanded.lower > expanded.upper) {
      return Result<Estimate>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::resource_limit,
              "c24.rao_blackwell_interval_not_representable",
              "the sampling interval plus deterministic integration-error "
              "bound is not representable as a finite ordered interval"));
    }
    interval = std::move(expanded);
  }
  return Result<Estimate>::success(C24CoreAccess::estimate(
      moments.mean, moments.sample_variance(), std::move(interval),
      SamplingClaimScopeV1::rao_blackwell_row,
      BigNat(static_cast<std::uint64_t>(residual_core->samples.size())),
      std::move(conditional_means), {}, std::nullopt,
      exact_integration_error,
      costs_for(residual_core->samples.size(), 0U, exact_atoms,
                sampling::detail::canonical_byte_count(
                    residual_core->conditioning_state,
                    residual_core->samples)),
      sampling_evidence_for(residual_core->sampler->contract),
      residual_core->replay_streams,
      residual_core->seal_digest, residual_core->conditioning_row_digest,
      residual_core->plan_digest, residual_core->metric_target_digest,
      std::nullopt, std::nullopt,
      residual_core));
}

Result<EmpiricalRow> estimate_discrete_kernel_row(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const SamplingPlan& plan) {
  auto observer = SamplingExecutionObserverV1::for_plan(plan);
  if (!observer) {
    return Result<EmpiricalRow>::failure(observer.error());
  }
  return estimate_discrete_kernel_row_observed(
      access, state, plan, observer.value());
}

Result<EmpiricalRow> estimate_discrete_kernel_row_observed(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const SamplingPlan& plan, SamplingExecutionObserverV1& observer) {
  try {
    return estimate_discrete_kernel_row_impl(
        access, state, plan, observer);
  } catch (const std::bad_alloc&) {
    return Result<EmpiricalRow>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.empirical_row_allocation_failure",
            "empirical row estimation exhausted memory; the fixed plan "
            "was not reduced or retried"));
  } catch (const std::exception&) {
    return Result<EmpiricalRow>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.empirical_row_exception",
            "empirical row estimation failed transactionally"));
  } catch (...) {
    return Result<EmpiricalRow>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.empirical_row_unknown_exception",
            "empirical row estimation raised an unknown exception"));
  }
}

Result<Estimate> estimate_reward_expectation(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const RewardDecoder& reward, const SamplingPlan& plan) {
  auto observer = SamplingExecutionObserverV1::for_plan(plan);
  if (!observer) {
    return Result<Estimate>::failure(observer.error());
  }
  return estimate_reward_expectation_observed(
      access, state, reward, plan, observer.value());
}

Result<Estimate> estimate_reward_expectation_observed(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const RewardDecoder& reward, const SamplingPlan& plan,
    SamplingExecutionObserverV1& observer) {
  try {
    return estimate_reward_expectation_impl(
        access, state, reward, plan, observer);
  } catch (const std::bad_alloc&) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.reward_estimator_allocation_failure",
            "reward estimation exhausted memory; the fixed plan was not "
            "reduced or retried"));
  } catch (const std::exception&) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.reward_estimator_exception",
            "reward estimation failed transactionally"));
  } catch (...) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.reward_estimator_unknown_exception",
            "reward estimation raised an unknown exception"));
  }
}

Result<Estimate> estimate_importance_weighted(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const AuditedTargetDensityRatio& ratio, const RewardDecoder& reward,
    const SamplingPlan& plan) {
  auto observer = SamplingExecutionObserverV1::for_plan(plan);
  if (!observer) {
    return Result<Estimate>::failure(observer.error());
  }
  return estimate_importance_weighted_observed(
      access, state, ratio, reward, plan, observer.value());
}

Result<Estimate> estimate_importance_weighted_observed(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const AuditedTargetDensityRatio& ratio, const RewardDecoder& reward,
    const SamplingPlan& plan, SamplingExecutionObserverV1& observer) {
  try {
    return estimate_importance_weighted_impl(
        access, state, ratio, reward, plan, observer);
  } catch (const std::bad_alloc&) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.importance_estimator_allocation_failure",
            "importance estimation exhausted memory; the fixed plan was "
            "not reduced or retried"));
  } catch (const std::exception&) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.importance_estimator_exception",
            "importance estimation failed transactionally"));
  } catch (...) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.importance_estimator_unknown_exception",
            "importance estimation raised an unknown exception"));
  }
}

Result<Estimate> rao_blackwellize_known_innovation(
    const EmpiricalResidual& residual,
    const AuditedExactInnovationKernel& innovation,
    const RewardDecoder& reward) {
  try {
    return rao_blackwellize_known_innovation_impl(
        residual, innovation, reward);
  } catch (const std::bad_alloc&) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.rao_blackwell_allocation_failure",
            "Rao--Blackwell integration exhausted memory without drawing a "
            "replacement residual or arrival"));
  } catch (const std::exception&) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.rao_blackwell_exception",
            "Rao--Blackwell integration failed transactionally"));
  } catch (...) {
    return Result<Estimate>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.rao_blackwell_unknown_exception",
            "Rao--Blackwell integration raised an unknown exception"));
  }
}

}  // namespace mwperf
