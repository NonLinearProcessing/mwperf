#include "mwperf/sampling/conditional_generator.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <functional>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <ranges>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "../kernel/c17_core_internal.hpp"
#include "c24_internal.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace mwperf::sampling::detail {
namespace {

void append_u32(std::vector<std::byte>& bytes, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    bytes.push_back(
        static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_u64(std::vector<std::byte>& bytes, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    bytes.push_back(
        static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_bytes(std::vector<std::byte>& bytes,
                  const std::span<const std::byte> value) {
  append_u64(bytes, static_cast<std::uint64_t>(value.size()));
  bytes.insert(bytes.end(), value.begin(), value.end());
}

void append_string(std::vector<std::byte>& bytes,
                   const std::string_view value) {
  append_u64(bytes, static_cast<std::uint64_t>(value.size()));
  for (const char character : value) {
    bytes.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_codec(std::vector<std::byte>& bytes,
                  const CodecIdentityV1& codec) {
  append_string(bytes, codec.id);
  append_u32(bytes, codec.version);
}

void append_runtime_value(std::vector<std::byte>& bytes,
                          const CanonicalRuntimeValueV1& value) {
  append_codec(bytes, value.codec);
  append_bytes(bytes, value.canonical_value);
}

[[nodiscard]] Result<void> validate_sample_shape(
    const TransitionKernelAccessShapeV1& shape, const Sample& sample) {
  if (sample.successor_state.codec != shape.successor_state_codec ||
      sample.ordered_marks.size() != shape.ordered_mark_codecs.size()) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.malformed_sample_shape",
        "the conditional generator returned a successor or ordered mark "
        "shape outside its sealed output schema"));
  }
  for (std::size_t index = 0U;
       index < shape.ordered_mark_codecs.size(); ++index) {
    if (sample.ordered_marks[index].codec !=
        shape.ordered_mark_codecs[index]) {
      return Result<void>::failure(sampling_diagnostic(
          DiagnosticCategory::input_validation,
          "c24.malformed_sample_mark_codec",
          "the conditional generator returned an ordered mark with a "
          "codec different from the sealed schema"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool has_duplicate_samples(
    const std::span<const Sample> samples) {
  for (std::size_t left = 0U; left < samples.size(); ++left) {
    for (std::size_t right = left + 1U; right < samples.size(); ++right) {
      if (samples[left] == samples[right]) return true;
    }
  }
  return false;
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::ranges::any_of(digest.bytes(), [](const std::byte byte) {
    return byte != std::byte{0};
  });
}

[[nodiscard]] bool is_c24_sampling_backend(
    const BackendRouteKindV1 route) noexcept {
  return route == BackendRouteKindV1::conditional_row_monte_carlo ||
         route == BackendRouteKindV1::conditional_reward_monte_carlo;
}

[[nodiscard]] bool monte_carlo_accuracy_satisfies(
    const MonteCarloAccuracyV1& offered,
    const MonteCarloAccuracyV1& required) {
  if (offered.replications < required.replications ||
      offered.confidence_level < required.confidence_level ||
      offered.interval != required.interval ||
      offered.estimand != required.estimand) {
    return false;
  }
  if (required.almost_sure_lower.has_value() &&
      (!offered.almost_sure_lower.has_value() ||
       *offered.almost_sure_lower > *required.almost_sure_lower)) {
    return false;
  }
  if (required.almost_sure_upper.has_value() &&
      (!offered.almost_sure_upper.has_value() ||
       *offered.almost_sure_upper < *required.almost_sure_upper)) {
    return false;
  }
  return true;
}

[[nodiscard]] Result<std::vector<AcceptedSamplingClauseV1>>
accepted_sampling_clauses(
    const surrogate::detail::SealedFrameworkCore& framework) {
  const AcceptedCapabilityContract& accepted =
      framework.inputs().accepted_contract;
  if (framework.descriptor().core.runtime_access !=
          RuntimeAccessTagV1::normalized_conditional_sampler ||
      accepted.runtime_access() !=
          RuntimeAccessTagV1::normalized_conditional_sampler ||
      accepted.contract_digest() != framework.validated_contract_digest()) {
    return Result<std::vector<AcceptedSamplingClauseV1>>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.accepted_sampler_contract_mismatch",
            "a C24 handle requires the same normalized-sampler runtime tag "
            "and accepted-contract identity retained by the C17 seal"));
  }

  std::vector<AcceptedSamplingClauseV1> clauses;
  for (const ResolvedMetricContractV1& resolved :
       accepted.metric_contracts()) {
    if (resolved.runtime_access !=
            RuntimeAccessTagV1::normalized_conditional_sampler ||
        resolved.solver_regime != SolverRegimeV1::monte_carlo ||
        !is_c24_sampling_backend(resolved.backend_route)) {
      continue;
    }
    const auto requirement = std::ranges::find_if(
        accepted.requirements().clauses(),
        [&](const MetricRequirementClause& candidate) {
          return candidate.origin.clause_id == resolved.clause_id;
        });
    const auto support = std::ranges::find_if(
        accepted.structural_manifest().clauses(),
        [&](const MetricSupportClauseV1& candidate) {
          return candidate.clause_id == resolved.clause_id;
        });
    if (requirement == accepted.requirements().clauses().end() ||
        support == accepted.structural_manifest().clauses().end() ||
        support->runtime_access !=
            RuntimeAccessTagV1::normalized_conditional_sampler ||
        support->solver_route != SolverRegimeV1::monte_carlo ||
        !std::holds_alternative<MonteCarloAccuracyV1>(
            requirement->accuracy.contract) ||
        !std::holds_alternative<MonteCarloAccuracyV1>(
            support->requested_accuracy) ||
        !monte_carlo_accuracy_satisfies(
            std::get<MonteCarloAccuracyV1>(support->requested_accuracy),
            std::get<MonteCarloAccuracyV1>(
                requirement->accuracy.contract)) ||
        !nonzero_digest(resolved.support_clause_digest)) {
      return Result<std::vector<AcceptedSamplingClauseV1>>::failure(
          sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.accepted_sampling_clause_incomplete",
              "the C17-sealed sampling route must retain its exact C14 "
              "Monte Carlo requirement, support clause, backend, and "
              "canonical support-clause digest"));
    }
    clauses.push_back(AcceptedSamplingClauseV1{
        resolved.clause_id, resolved.support_clause_digest,
        resolved.backend_route,
        std::get<MonteCarloAccuracyV1>(requirement->accuracy.contract)});
  }
  if (clauses.empty()) {
    return Result<std::vector<AcceptedSamplingClauseV1>>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.accepted_sampling_clause_missing",
            "the V0 seal contains no accepted conditional row/reward Monte "
            "Carlo clause for its normalized sampler access"));
  }
  std::ranges::sort(clauses, {}, [](const AcceptedSamplingClauseV1& value) {
    return value.clause_id;
  });
  return Result<std::vector<AcceptedSamplingClauseV1>>::success(
      std::move(clauses));
}

[[nodiscard]] UnavailableOptionalAuthorityV1 unavailable_authority(
    std::string code, std::string message) {
  return {sampling_diagnostic(DiagnosticCategory::unavailable,
                              std::move(code), std::move(message))};
}

[[nodiscard]] bool accepted_sampling_target(
    const std::span<const AcceptedSamplingClauseV1> accepted,
    const Digest256& target) {
  return std::ranges::any_of(
      accepted, [&](const AcceptedSamplingClauseV1& clause) {
        return clause.metric_target_digest == target;
      });
}

[[nodiscard]] TargetDensityRatioAuthorityV1 validate_target_ratio_authority(
    const NormalizedConditionalSamplerAccess& raw,
    const ConditionalSamplerContractV1& sampler,
    const std::span<const AcceptedSamplingClauseV1> accepted) {
  const auto& contract = raw.ratio_contract();
  auto operation = C24CoreAccess::ratio_operation(raw);
  const bool has_contract = contract.has_value();
  const bool has_operation = static_cast<bool>(operation);
  if (!has_contract && !has_operation) {
    return unavailable_authority(
        "c24.target_density_ratio_unavailable",
        "the sealed conditional sampler declares no target density-ratio "
        "authority");
  }
  if (has_contract != has_operation) {
    return unavailable_authority(
        "c24.incomplete_target_density_ratio_authority",
        "the sealed target density-ratio authority must contain both its "
        "contract and operation");
  }
  if (contract->schema_version != 1U ||
      contract->target_kind != ImportanceTargetKindV1::transition_row ||
      !contract->transition_ratio_only ||
      !nonzero_digest(contract->target_law_identity) ||
      !nonzero_digest(contract->metric_target_digest) ||
      !nonzero_digest(contract->reward_decoder_digest) ||
      contract->residual_schema != sampler.residual_schema ||
      contract->output_schema != sampler.output_schema) {
    return unavailable_authority(
        "c24.invalid_target_ratio_binding",
        "the optional target density ratio is not a version-1 transition "
        "ratio bound to the sampler residual/output schemas and nonzero "
        "target, law, and reward identities");
  }
  if (!accepted_sampling_target(accepted,
                                contract->metric_target_digest)) {
    return unavailable_authority(
        "c24.target_ratio_target_not_accepted",
        "the optional target density ratio does not bind an accepted "
        "sampling-clause target");
  }
  return AvailableTargetDensityRatioAuthorityV1{*contract,
                                                 std::move(operation)};
}

[[nodiscard]] ExactInnovationAuthorityV1 validate_exact_innovation_authority(
    const NormalizedConditionalSamplerAccess& raw,
    const ConditionalSamplerContractV1& sampler,
    const std::span<const AcceptedSamplingClauseV1> accepted) {
  const auto& contract = raw.innovation_contract();
  auto operation = C24CoreAccess::innovation_operation(raw);
  const bool has_contract = contract.has_value();
  const bool has_operation = static_cast<bool>(operation);
  if (!has_contract && !has_operation) {
    return unavailable_authority(
        "c24.exact_innovation_unavailable",
        "the sealed conditional sampler declares no exact-innovation "
        "authority");
  }
  if (has_contract != has_operation) {
    return unavailable_authority(
        "c24.incomplete_exact_innovation_authority",
        "the sealed exact-innovation authority must contain both its "
        "contract and operation");
  }
  if (contract->schema_version != 1U ||
      !contract->configured_joint_innovation ||
      !nonzero_digest(contract->representation_identity) ||
      !nonzero_digest(contract->metric_target_digest) ||
      !nonzero_digest(contract->reward_decoder_digest) ||
      contract->configured_arrival_law !=
          sampler.configured_arrival_law ||
      contract->residual_schema != sampler.residual_schema ||
      contract->output_schema != sampler.output_schema ||
      !contract->maximum_absolute_integration_error.is_nonnegative()) {
    return unavailable_authority(
        "c24.invalid_exact_innovation_binding",
        "the optional exact innovation is not a nonnegative-error, "
        "version-1 joint configured innovation bound to the sampler "
        "arrival, residual, and output identities");
  }
  if (!accepted_sampling_target(accepted,
                                contract->metric_target_digest)) {
    return unavailable_authority(
        "c24.exact_innovation_target_not_accepted",
        "the optional exact innovation does not bind an accepted "
        "sampling-clause target");
  }
  return AvailableExactInnovationAuthorityV1{*contract,
                                              std::move(operation)};
}

}  // namespace

Diagnostic sampling_diagnostic(const DiagnosticCategory category,
                               std::string code, std::string message) {
  return {category, std::move(code), std::move(message), std::nullopt,
          std::nullopt, {}};
}

Result<void> validate_sealed_state_domain(
    const ValidateReducedStateDomainV1& prototype,
    const ReducedStateV1& state, const bool successor) {
  try {
    if (!prototype) {
      return Result<void>::failure(sampling_diagnostic(
          DiagnosticCategory::internal,
          "c24.missing_sealed_state_domain_validator",
          "the V0-sealed sampler lost its exact reduced-state domain "
          "validator"));
    }
    auto validate = prototype;
    const auto valid = validate(state);
    if (!valid) {
      return Result<void>::failure(sampling_diagnostic(
          DiagnosticCategory::input_validation,
          successor ? "c24.successor_state_outside_sealed_domain"
                    : "c24.conditioning_state_outside_sealed_domain",
          successor
              ? "a sampled or declared successor is outside the exact "
                "reduced-state domain retained by the V0 seal"
              : "the conditioning row is outside the exact reduced-state "
                "domain retained by the V0 seal"));
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.state_domain_validation_allocation_failure",
        "sealed reduced-state domain validation exhausted memory"));
  } catch (const std::exception&) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.state_domain_validation_exception",
        "sealed reduced-state domain validation raised an exception"));
  } catch (...) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.state_domain_validation_unknown_exception",
        "sealed reduced-state domain validation raised an unknown "
        "exception"));
  }
}

Result<void> validate_sealed_completed_sample(
    const NormalizedSamplerCore& sampler,
    const ConditioningState& conditioning_state, const Sample& sample) {
  auto shape = validate_sample_shape(sampler.shape, sample);
  if (!shape) return shape;

  auto successor_domain = validate_sealed_state_domain(
      sampler.validate_state_domain, sample.successor_state, true);
  if (!successor_domain) return successor_domain;

  try {
    if (!sampler.validate_sample) {
      return Result<void>::failure(sampling_diagnostic(
          DiagnosticCategory::internal,
          "c24.missing_sealed_sample_validator",
          "the V0-sealed sampler lost its completed-sample validation "
          "authority"));
    }
    // Copy the immutable prototype for every atom.  A value-captured mutable
    // validator therefore cannot carry an undeclared cursor between draws,
    // support atoms, or exact-innovation atoms.
    auto validate = sampler.validate_sample;
    return validate(conditioning_state, sample);
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.sample_validation_allocation_failure",
        "completed-sample semantic validation exhausted memory"));
  } catch (const std::exception&) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sample_validation_exception",
        "the sealed completed-sample validator raised an exception"));
  } catch (...) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sample_validation_unknown_exception",
        "the sealed completed-sample validator raised an unknown "
        "exception"));
  }
}

Result<Digest256> conditioning_state_digest(
    const ConditioningState& state) {
  try {
    std::vector<std::byte> bytes;
    bytes.reserve(state.codec.id.size() + state.canonical_value.size() +
                  24U);
    append_runtime_value(bytes, state);
    return sha256_domain_separated("mwperf.c24.conditioning-state.v1",
                                   bytes);
  } catch (const std::bad_alloc&) {
    return Result<Digest256>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.conditioning_digest_allocation_failure",
        "canonical conditioning-state digest construction exhausted "
        "memory"));
  }
}

Result<Digest256> sample_digest(const Sample& sample) {
  try {
    std::vector<std::byte> bytes;
    append_runtime_value(bytes, sample.successor_state);
    append_u64(bytes,
               static_cast<std::uint64_t>(sample.ordered_marks.size()));
    for (const CanonicalRuntimeValueV1& mark : sample.ordered_marks) {
      append_runtime_value(bytes, mark);
    }
    return sha256_domain_separated("mwperf.c24.sample.v1", bytes);
  } catch (const std::bad_alloc&) {
    return Result<Digest256>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.sample_digest_allocation_failure",
        "canonical sample digest construction exhausted memory"));
  }
}

StageTag required_sampler_stage(
    const ConditionalSamplerContractV1& contract) noexcept {
  if (contract.dependence == ConditionalSampleDependenceV1::iid_proposal) {
    return StageTag::importance_proposal;
  }
  switch (contract.reveal_stage) {
    case ConditionalSamplerRevealStageV1::prearrival_residual:
      return StageTag::prearrival_closure;
    case ConditionalSamplerRevealStageV1::postarrival_residual:
      return StageTag::postarrival_closure;
    case ConditionalSamplerRevealStageV1::generic_row_residual:
      return StageTag::generic_sampling;
  }
  return StageTag::solver_sampling;
}

Result<void> validate_plan_access_binding(
    const NormalizedSamplerCore& sampler, const SamplingPlanCore& plan) {
  const auto clause = std::ranges::find_if(
      sampler.accepted_sampling_clauses,
      [&](const AcceptedSamplingClauseV1& candidate) {
        return candidate.clause_id == plan.accepted_clause_id &&
               candidate.metric_target_digest ==
                   plan.metric_target_digest &&
               candidate.backend_route == plan.accepted_backend_route;
      });
  if (plan.seal_digest != sampler.seal_digest ||
      plan.accepted_contract_digest != sampler.accepted_contract_digest ||
      clause == sampler.accepted_sampling_clauses.end()) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sampling_plan_access_binding_mismatch",
        "the sampling plan was not minted from this V0 seal, accepted "
        "contract, Monte Carlo clause, backend, and metric target"));
  }
  if (plan.reveal_stage != sampler.contract.reveal_stage ||
      plan.dependence != sampler.contract.dependence ||
      plan.stage != required_sampler_stage(sampler.contract)) {
    return Result<void>::failure(sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sampling_plan_stage_or_dependence_mismatch",
        "the sampling plan's retained reveal stage, dependence, and typed "
        "RNG stage must equal the sealed sampler contract before draws"));
  }
  return Result<void>::success();
}

Result<RngBank> C24RngAccess::make(
    const Digest256& seal_digest, const Digest256& row_digest,
    const std::string_view estimator_id,
    const BigNat& replication_index, const MasterSeed seed,
    const StageTag stage) {
  auto key = make_estimator_instance_key(
      seal_digest, row_digest, estimator_id, replication_index);
  if (!key) {
    return Result<RngBank>::failure(key.error());
  }
  try {
    DeterministicRng draw = derive_rng_stream(seed, stage, key.value());
    DeterministicRng closed_auxiliary = derive_rng_stream(
        seed, StageTag::solver_sampling, key.value());
    const Digest256 stream_identity = draw.stream_identity();
    return Result<RngBank>::success(RngBank(
        seal_digest, seed, std::move(key).value(), std::move(draw),
        std::move(closed_auxiliary), stream_identity, nullptr, false,
        std::nullopt, std::nullopt, true, stage));
  } catch (const std::bad_alloc&) {
    return Result<RngBank>::failure(sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.estimator_rng_allocation_failure",
        "the estimator-local addressed RNG bank exhausted memory"));
  } catch (const std::exception&) {
    return Result<RngBank>::failure(sampling_diagnostic(
        DiagnosticCategory::internal,
        "c24.estimator_rng_construction_failure",
        "the estimator-local addressed RNG bank could not be derived"));
  }
}

Result<std::reference_wrapper<DeterministicRng>> C24RngAccess::consume(
    RngBank& bank, const Digest256& expected_seal,
    const StageTag expected_stage) {
  if (!bank.estimator_purpose_ || !bank.estimator_stage_.has_value() ||
      bank.combined_input_ != expected_seal ||
      *bank.estimator_stage_ != expected_stage ||
      bank.initial_joint_atom_.derivation_stage() !=
          *bank.estimator_stage_) {
    return Result<std::reference_wrapper<DeterministicRng>>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_estimator_rng_bank",
            "a conditional residual draw requires a C24 estimator-local "
            "bank bound to the same V0 seal and typed stage"));
  }
  if (bank.estimator_draw_consumed_) {
    return Result<std::reference_wrapper<DeterministicRng>>::failure(
        sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.estimator_rng_bank_reused",
            "one addressed estimator RNG bank may dispatch exactly one "
            "conditional draw"));
  }
  bank.estimator_draw_consumed_ = true;
  return Result<std::reference_wrapper<DeterministicRng>>::success(
      std::ref(bank.initial_joint_atom_));
}

Result<SamplingReplicationReplayV1> C24RngAccess::capture_replay_record(
    const RngBank& bank) {
  if (!bank.estimator_purpose_ || !bank.estimator_stage_.has_value() ||
      !bank.estimator_draw_consumed_ ||
      bank.initial_joint_atom_.derivation_stage() !=
          *bank.estimator_stage_ ||
      !bank.tie_resolution_.consumed_words().is_zero() ||
      bank.configured_arrival_stream_identity_ !=
          bank.initial_joint_atom_.stream_identity()) {
    return Result<SamplingReplicationReplayV1>::failure(
        sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.invalid_completed_estimator_rng_bank",
            "replay provenance may be captured only from the exact completed "
            "estimator RNG bank with its configured stream identity intact"));
  }
  try {
    return Result<SamplingReplicationReplayV1>::success(
        SamplingReplicationReplayV1{
            bank.configured_arrival_stream_identity_,
            bank.initial_joint_atom_.consumed_words()});
  } catch (const std::bad_alloc&) {
    return Result<SamplingReplicationReplayV1>::failure(
        sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.replay_provenance_allocation_failure",
            "capturing completed estimator replay provenance exhausted "
            "memory"));
  }
}

bool C24RngAccess::draw_was_consumed(const RngBank& bank) noexcept {
  return bank.estimator_purpose_ && bank.estimator_stage_.has_value() &&
         bank.estimator_draw_consumed_;
}

std::shared_ptr<surrogate::detail::SealedFrameworkCore>
C24CoreAccess::descriptor_core(
    const AuditedSamplerDescriptor& descriptor) noexcept {
  return descriptor.core_;
}

const NormalizedConditionalSamplerAccess* C24CoreAccess::raw_sampler(
    const surrogate::detail::SealedFrameworkCore& core) noexcept {
  return std::get_if<NormalizedConditionalSamplerAccess>(&core.access());
}

ConditionalSamplerCallbackV1 C24CoreAccess::draw_operation(
    const NormalizedConditionalSamplerAccess& sampler) {
  return sampler.operation_.fresh_copy();
}

ConditionalSampleValidatorV1 C24CoreAccess::sample_validator(
    const NormalizedConditionalSamplerAccess& sampler) {
  return sampler.sample_validator_.fresh_copy();
}

ConditionalSupportEnumeratorV1 C24CoreAccess::support_enumerator(
    const NormalizedConditionalSamplerAccess& sampler) {
  return sampler.support_enumerator_.has_value()
             ? sampler.support_enumerator_->fresh_copy()
             : ConditionalSupportEnumeratorV1{};
}

ConditionalSupportQueryV1 C24CoreAccess::support_query(
    const NormalizedConditionalSamplerAccess& sampler) {
  return sampler.support_query_.has_value()
             ? sampler.support_query_->fresh_copy()
             : ConditionalSupportQueryV1{};
}

ConditionalTargetRatioCallbackV1 C24CoreAccess::ratio_operation(
    const NormalizedConditionalSamplerAccess& sampler) {
  return sampler.ratio_.has_value() ? sampler.ratio_->fresh_copy()
                                    : ConditionalTargetRatioCallbackV1{};
}

ConditionalExactInnovationCallbackV1 C24CoreAccess::innovation_operation(
    const NormalizedConditionalSamplerAccess& sampler) {
  return sampler.innovation_.has_value()
             ? sampler.innovation_->fresh_copy()
             : ConditionalExactInnovationCallbackV1{};
}

NormalizedSamplerAccess C24CoreAccess::normalized_sampler(
    std::shared_ptr<const NormalizedSamplerCore> core) {
  return NormalizedSamplerAccess(std::move(core));
}

const std::shared_ptr<const NormalizedSamplerCore>&
C24CoreAccess::sampler_core(
    const NormalizedSamplerAccess& access) noexcept {
  return access.core_;
}

SamplingPlan C24CoreAccess::sampling_plan(
    std::shared_ptr<const SamplingPlanCore> core) {
  return SamplingPlan(std::move(core));
}

const std::shared_ptr<const SamplingPlanCore>& C24CoreAccess::plan_core(
    const SamplingPlan& plan) noexcept {
  return plan.core_;
}

std::shared_ptr<SamplingExecutionState>&
C24CoreAccess::sampling_execution_state(
    SamplingExecutionObserverV1& observer) noexcept {
  return observer.state_;
}

EmpiricalRow C24CoreAccess::empirical_row(
    BigNat total, std::vector<EmpiricalRowAtomV1> atoms,
    const bool iid_replications, Digest256 seal_digest,
    Digest256 row_digest, Digest256 plan_digest,
    Digest256 metric_target_digest,
    SamplingEvidenceSnapshotV1 sampling_evidence,
    SamplingCostCountersV1 costs,
    std::vector<SamplingReplicationReplayV1> replay_streams,
    std::optional<TotalVariationBoundV1> tv_bound,
    const std::size_t failed_draws) {
  return EmpiricalRow(
      std::move(total), std::move(atoms), iid_replications,
      std::move(seal_digest), std::move(row_digest),
      std::move(plan_digest), std::move(metric_target_digest),
      std::move(sampling_evidence),
      std::move(costs),
      std::move(replay_streams),
      std::move(tv_bound), failed_draws);
}

Estimate C24CoreAccess::estimate(
    const long double value,
    std::optional<long double> sample_variance,
    std::optional<FixedSampleIntervalV1> interval,
    const SamplingClaimScopeV1 claim_scope, BigNat replications,
    std::vector<long double> raw_rewards,
    std::vector<ImportanceWeightRecordV1> raw_weights,
    std::optional<ImportanceDiagnosticsV1> importance_diagnostics,
    std::optional<long double> exact_integration_absolute_error,
    SamplingCostCountersV1 costs,
    SamplingEvidenceSnapshotV1 sampling_evidence,
    std::vector<SamplingReplicationReplayV1> replay_streams,
    Digest256 seal_digest, Digest256 row_digest, Digest256 plan_digest,
    Digest256 metric_target_digest,
    std::optional<Digest256> proposal_law_identity,
    std::optional<Digest256> target_law_identity,
    std::shared_ptr<const EmpiricalResidualCore> residual) {
  return Estimate(
      value, sample_variance, std::move(interval), claim_scope,
      std::move(replications), std::move(raw_rewards),
      std::move(raw_weights), std::move(importance_diagnostics),
      exact_integration_absolute_error, std::move(costs),
      std::move(sampling_evidence), std::move(replay_streams),
      std::move(seal_digest),
      std::move(row_digest), std::move(plan_digest),
      std::move(metric_target_digest), std::move(proposal_law_identity),
      std::move(target_law_identity), std::move(residual));
}

EmpiricalResidual C24CoreAccess::empirical_residual(
    std::shared_ptr<const EmpiricalResidualCore> core) {
  return EmpiricalResidual(std::move(core));
}

const std::shared_ptr<const EmpiricalResidualCore>&
C24CoreAccess::residual_core(const EmpiricalResidual& residual) noexcept {
  return residual.core_;
}

AuditedTargetDensityRatio C24CoreAccess::target_ratio(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework,
    Digest256 plan_binding, std::shared_ptr<const TargetRatioCore> core) {
  return AuditedTargetDensityRatio(std::move(framework),
                                   std::move(plan_binding),
                                   std::move(core));
}

const std::shared_ptr<const TargetRatioCore>&
C24CoreAccess::target_ratio_core(
    const AuditedTargetDensityRatio& ratio) noexcept {
  return ratio.sampling_core_;
}

AuditedExactInnovationKernel C24CoreAccess::exact_innovation(
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework,
    Digest256 representation_binding,
    std::shared_ptr<const ExactInnovationCore> core) {
  return AuditedExactInnovationKernel(
      std::move(framework), std::move(representation_binding),
      std::move(core));
}

const std::shared_ptr<const ExactInnovationCore>&
C24CoreAccess::exact_innovation_core(
    const AuditedExactInnovationKernel& innovation) noexcept {
  return innovation.sampling_core_;
}

}  // namespace mwperf::sampling::detail

namespace mwperf {

const Digest256& NormalizedSamplerAccess::seal_digest() const noexcept {
  return core_->seal_digest;
}

const TransitionKernelAccessShapeV1& NormalizedSamplerAccess::shape()
    const noexcept {
  return core_->shape;
}

const ConditionalSamplerContractV1& NormalizedSamplerAccess::contract()
    const noexcept {
  return core_->contract;
}

const Digest256& NormalizedSamplerAccess::accepted_contract_digest()
    const noexcept {
  return core_->accepted_contract_digest;
}

std::span<const AcceptedSamplingClauseV1>
NormalizedSamplerAccess::accepted_sampling_clauses() const noexcept {
  return core_->accepted_sampling_clauses;
}

bool NormalizedSamplerAccess::target_density_ratio_available()
    const noexcept {
  return std::holds_alternative<
      sampling::detail::AvailableTargetDensityRatioAuthorityV1>(
      core_->target_density_ratio);
}

bool NormalizedSamplerAccess::exact_innovation_available() const noexcept {
  return std::holds_alternative<
      sampling::detail::AvailableExactInnovationAuthorityV1>(
      core_->exact_innovation);
}

Result<AuditedTargetDensityRatio>
NormalizedSamplerAccess::bind_target_density_ratio(
    const ConditioningState& row, const SamplingPlan& plan) const {
  using sampling::detail::C24CoreAccess;
  const auto* authority = std::get_if<
      sampling::detail::AvailableTargetDensityRatioAuthorityV1>(
      &core_->target_density_ratio);
  if (authority == nullptr) {
    const auto* unavailable = std::get_if<
        sampling::detail::UnavailableOptionalAuthorityV1>(
        &core_->target_density_ratio);
    return Result<AuditedTargetDensityRatio>::failure(
        unavailable != nullptr
            ? unavailable->reason
            : sampling::detail::sampling_diagnostic(
                  DiagnosticCategory::internal,
                  "c24.invalid_target_density_ratio_state",
                  "the normalized sampler lost its closed target "
                  "density-ratio availability state"));
  }
  if (row.codec != core_->shape.conditioning_state_codec) {
    return Result<AuditedTargetDensityRatio>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.target_ratio_row_codec_mismatch",
            "the target density ratio can bind only a conditioning row in "
            "the sealed sampler domain"));
  }
  auto row_domain = sampling::detail::validate_sealed_state_domain(
      core_->validate_state_domain, row, false);
  if (!row_domain) {
    return Result<AuditedTargetDensityRatio>::failure(
        row_domain.error());
  }
  const auto& plan_core = C24CoreAccess::plan_core(plan);
  if (!plan_core) {
    return Result<AuditedTargetDensityRatio>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_sampling_plan",
            "the target density ratio requires a validated sampling plan"));
  }
  auto plan_binding = sampling::detail::validate_plan_access_binding(
      *core_, *plan_core);
  if (!plan_binding) {
    return Result<AuditedTargetDensityRatio>::failure(
        plan_binding.error());
  }
  if (plan_core->metric_target_digest !=
      authority->contract.metric_target_digest) {
    return Result<AuditedTargetDensityRatio>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.target_ratio_plan_target_mismatch",
            "the accepted sampling plan and density ratio must bind the "
            "same metric target"));
  }
  auto row_digest = sampling::detail::conditioning_state_digest(row);
  if (!row_digest) {
    return Result<AuditedTargetDensityRatio>::failure(row_digest.error());
  }
  try {
    auto ratio_core =
        std::make_shared<const sampling::detail::TargetRatioCore>(
            sampling::detail::TargetRatioCore{
                core_, authority->contract, authority->operation,
                core_->seal_digest, row_digest.value(),
                plan_core->plan_digest, plan_core->metric_target_digest,
                core_->contract.proposal_law_identity,
                core_->contract.output_schema});
    return Result<AuditedTargetDensityRatio>::success(
        C24CoreAccess::target_ratio(
            core_->framework_core, plan_core->plan_digest,
            std::move(ratio_core)));
  } catch (const std::bad_alloc&) {
    return Result<AuditedTargetDensityRatio>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.target_ratio_binding_allocation_failure",
            "binding the audited target density ratio exhausted memory"));
  } catch (const std::exception&) {
    return Result<AuditedTargetDensityRatio>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.target_ratio_binding_exception",
            "binding the audited target density ratio failed"));
  } catch (...) {
    return Result<AuditedTargetDensityRatio>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.target_ratio_binding_unknown_exception",
            "binding the audited target density ratio raised an unknown "
            "exception"));
  }
}

Result<AuditedExactInnovationKernel>
NormalizedSamplerAccess::bind_exact_innovation_kernel(
    const ConditioningState& row, const SamplingPlan& plan) const {
  using sampling::detail::C24CoreAccess;
  const auto* authority = std::get_if<
      sampling::detail::AvailableExactInnovationAuthorityV1>(
      &core_->exact_innovation);
  if (authority == nullptr) {
    const auto* unavailable = std::get_if<
        sampling::detail::UnavailableOptionalAuthorityV1>(
        &core_->exact_innovation);
    return Result<AuditedExactInnovationKernel>::failure(
        unavailable != nullptr
            ? unavailable->reason
            : sampling::detail::sampling_diagnostic(
                  DiagnosticCategory::internal,
                  "c24.invalid_exact_innovation_state",
                  "the normalized sampler lost its closed exact-innovation "
                  "availability state"));
  }
  if (row.codec != core_->shape.conditioning_state_codec) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.exact_innovation_row_codec_mismatch",
            "the exact innovation can bind only a conditioning row in the "
            "sealed sampler domain"));
  }
  auto row_domain = sampling::detail::validate_sealed_state_domain(
      core_->validate_state_domain, row, false);
  if (!row_domain) {
    return Result<AuditedExactInnovationKernel>::failure(
        row_domain.error());
  }
  const auto& plan_core = C24CoreAccess::plan_core(plan);
  if (!plan_core) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.invalid_sampling_plan",
            "the exact innovation requires a validated sampling plan"));
  }
  auto plan_binding = sampling::detail::validate_plan_access_binding(
      *core_, *plan_core);
  if (!plan_binding) {
    return Result<AuditedExactInnovationKernel>::failure(
        plan_binding.error());
  }
  if (!plan_core->request_rao_blackwellization) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.rao_blackwell_not_requested",
            "an exact-innovation authority can bind only a sampling plan "
            "that explicitly requests Rao--Blackwellization"));
  }
  if (plan_core->metric_target_digest !=
      authority->contract.metric_target_digest) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.exact_innovation_plan_target_mismatch",
            "the exact innovation and accepted sampling plan must bind the "
            "same metric target"));
  }
  auto row_digest = sampling::detail::conditioning_state_digest(row);
  if (!row_digest) {
    return Result<AuditedExactInnovationKernel>::failure(
        row_digest.error());
  }
  try {
    auto innovation_core =
        std::make_shared<const sampling::detail::ExactInnovationCore>(
            sampling::detail::ExactInnovationCore{
                core_, authority->contract, authority->operation, row,
                core_->seal_digest, row_digest.value(),
                plan_core->plan_digest, plan_core->metric_target_digest,
                core_->contract.configured_arrival_law,
                core_->contract.residual_schema,
                core_->contract.output_schema});
    return Result<AuditedExactInnovationKernel>::success(
        C24CoreAccess::exact_innovation(
            core_->framework_core,
            authority->contract.representation_identity,
            std::move(innovation_core)));
  } catch (const std::bad_alloc&) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.exact_innovation_binding_allocation_failure",
            "binding the audited exact innovation exhausted memory"));
  } catch (const std::exception&) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.exact_innovation_binding_exception",
            "binding the audited exact innovation failed"));
  } catch (...) {
    return Result<AuditedExactInnovationKernel>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.exact_innovation_binding_unknown_exception",
            "binding the audited exact innovation raised an unknown "
            "exception"));
  }
}

Result<NormalizedSamplerAccess> validate_conditional_generator(
    const AuditedSamplerDescriptor& descriptor) {
  using sampling::detail::C24CoreAccess;
  try {
    auto framework = C24CoreAccess::descriptor_core(descriptor);
    if (!framework || !framework->report().passed()) {
      return Result<NormalizedSamplerAccess>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.sampler_requires_passing_v0_seal",
              "a normalized sampling handle can be issued only from a "
              "passing C17 V0 sampler descriptor"));
    }
    const auto* raw = C24CoreAccess::raw_sampler(*framework);
    if (raw == nullptr || !raw->contract().has_value() ||
        !raw->has_operation() || !raw->has_sample_validator()) {
      return Result<NormalizedSamplerAccess>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.sealed_sampler_binding_invalid",
              "the audited descriptor does not retain a complete normalized "
              "conditional sampler authority"));
    }
    const ConditionalSamplerContractV1& contract = *raw->contract();
    if (!contract.normalized_probability_law ||
        !contract.almost_sure_return ||
        !contract.persistent_memory_is_explicit ||
        !contract.no_hidden_warm_state ||
        (contract.support_kind ==
             ConditionalSupportKindV1::finite_declared &&
         !raw->has_support_enumerator()) ||
        (contract.support_kind ==
             ConditionalSupportKindV1::membership_query &&
         !raw->has_support_query())) {
      return Result<NormalizedSamplerAccess>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.incomplete_sealed_sampler_contract",
              "the V0-sealed sampler lacks a required support, persistence, "
              "normalization, or return declaration"));
    }
    auto accepted = sampling::detail::accepted_sampling_clauses(*framework);
    if (!accepted) {
      return Result<NormalizedSamplerAccess>::failure(accepted.error());
    }
    auto target_density_ratio =
        sampling::detail::validate_target_ratio_authority(
            *raw, contract, accepted.value());
    auto exact_innovation =
        sampling::detail::validate_exact_innovation_authority(
            *raw, contract, accepted.value());
    auto core = std::make_shared<const sampling::detail::NormalizedSamplerCore>(
        sampling::detail::NormalizedSamplerCore{
            framework,
            framework->execution_seal_digest(),
            framework->validated_contract_digest(),
            std::move(accepted).value(),
            framework->inputs().instance.analysis_spec().context
                ? framework->inputs()
                      .instance.analysis_spec()
                      .context->resolution.sampling.max_generator_draws
                : std::nullopt,
            raw->shape(),
            contract,
            framework->inputs().exact_state_schema.validate_domain,
            C24CoreAccess::draw_operation(*raw),
            C24CoreAccess::sample_validator(*raw),
            C24CoreAccess::support_enumerator(*raw),
            C24CoreAccess::support_query(*raw),
            std::move(target_density_ratio),
            std::move(exact_innovation)});
    return Result<NormalizedSamplerAccess>::success(
        C24CoreAccess::normalized_sampler(std::move(core)));
  } catch (const std::bad_alloc&) {
    return Result<NormalizedSamplerAccess>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::resource_limit,
            "c24.sampler_validation_allocation_failure",
            "operational sampler validation exhausted memory"));
  } catch (const std::exception&) {
    return Result<NormalizedSamplerAccess>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.sampler_validation_exception",
            "operational sampler validation raised an exception"));
  } catch (...) {
    return Result<NormalizedSamplerAccess>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::internal,
            "c24.sampler_validation_unknown_exception",
            "operational sampler validation raised an unknown exception"));
  }
}

namespace {

Result<Sample> draw_conditional_sample_impl(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    RngBank& rng_bank,
    const std::optional<std::span<const Sample>> finite_support_snapshot) {
  const auto& core = sampling::detail::C24CoreAccess::sampler_core(access);
  if (!core || state.codec != core->shape.conditioning_state_codec) {
    return Result<Sample>::failure(
        sampling::detail::sampling_diagnostic(
            DiagnosticCategory::input_validation,
            "c24.conditioning_state_codec_mismatch",
            "a conditional draw requires a state in the sealed conditioning "
            "domain"));
  }
  auto conditioning_domain = sampling::detail::validate_sealed_state_domain(
      core->validate_state_domain, state, false);
  if (!conditioning_domain) {
    return Result<Sample>::failure(conditioning_domain.error());
  }
  auto rng = sampling::detail::C24RngAccess::consume(
      rng_bank, core->seal_digest,
      sampling::detail::required_sampler_stage(core->contract));
  if (!rng) {
    return Result<Sample>::failure(rng.error());
  }
  try {
    // The sealed operation is an immutable prototype.  Copy it for every
    // addressed invocation so ordinary value-captured mutable closure state
    // cannot become undeclared warm generator memory across replications.
    // State deliberately shared through an external pointer remains subject
    // to the descriptor's explicit-memory declaration and replay audit.
    auto draw = core->draw;
    auto sample = draw(state, rng.value().get());
    if (!sample) {
      return Result<Sample>::failure(sample.error());
    }
    auto validation = sampling::detail::validate_sealed_completed_sample(
        *core, state, sample.value());
    if (!validation) {
      return Result<Sample>::failure(validation.error());
    }
    bool supported = false;
    if (core->contract.support_kind ==
        ConditionalSupportKindV1::finite_declared) {
      std::vector<Sample> owned_support;
      std::span<const Sample> support;
      if (finite_support_snapshot.has_value()) {
        support = *finite_support_snapshot;
      } else {
        auto enumerate_support = core->enumerate_support;
        auto enumerated = enumerate_support(state);
        if (!enumerated) {
          return Result<Sample>::failure(enumerated.error());
        }
        owned_support = std::move(enumerated).value();
        support = owned_support;
      }
      if (!core->contract.finite_support_cardinality.has_value() ||
          support.size() != *core->contract.finite_support_cardinality ||
          sampling::detail::has_duplicate_samples(support)) {
        return Result<Sample>::failure(
            sampling::detail::sampling_diagnostic(
                DiagnosticCategory::input_validation,
                "c24.invalid_declared_finite_support",
                "the exact support enumerator must return the declared "
                "number of distinct canonical atoms"));
      }
      // A fixed-bank caller validates its one immutable snapshot before the
      // first stochastic invocation.  The public one-draw path owns its local
      // snapshot and therefore validates every atom here.
      if (!finite_support_snapshot.has_value()) {
        for (const Sample& declared : support) {
          auto declared_validation =
              sampling::detail::validate_sealed_completed_sample(
                  *core, state, declared);
          if (!declared_validation) {
            return Result<Sample>::failure(declared_validation.error());
          }
        }
      }
      supported = std::ranges::find(support, sample.value()) != support.end();
    } else {
      if (finite_support_snapshot.has_value()) {
        return Result<Sample>::failure(
            sampling::detail::sampling_diagnostic(
                DiagnosticCategory::internal,
                "c24.frozen_support_on_query_sampler",
                "an estimator finite-support snapshot cannot be applied to a "
                "membership-query sampler"));
      }
      auto query_support = core->query_support;
      auto query = query_support(state, sample.value());
      if (!query) {
        return Result<Sample>::failure(query.error());
      }
      supported = query.value();
    }
    if (!supported) {
      return Result<Sample>::failure(
          sampling::detail::sampling_diagnostic(
              DiagnosticCategory::input_validation,
              "c24.sample_outside_declared_support",
              "the conditional generator returned an atom outside its "
              "sealed row support"));
    }
    return sample;
  } catch (const std::bad_alloc&) {
    return Result<Sample>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::resource_limit,
        "c24.sample_allocation_failure",
        "the conditional sample operation exhausted memory"));
  } catch (const std::exception&) {
    return Result<Sample>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sample_operation_exception",
        "an exception from the conditional generator is a failed draw, not "
        "discardable probability mass"));
  } catch (...) {
    return Result<Sample>::failure(sampling::detail::sampling_diagnostic(
        DiagnosticCategory::input_validation,
        "c24.sample_operation_unknown_exception",
        "an unknown exception from the conditional generator is a failed "
        "draw"));
  }
}

}  // namespace

Result<Sample> draw_conditional_sample(
    const NormalizedSamplerAccess& access,
    const ConditioningState& state, RngBank& rng_bank) {
  return draw_conditional_sample_impl(access, state, rng_bank, std::nullopt);
}

namespace sampling::detail {

Result<Sample> draw_conditional_sample_from_frozen_support(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    RngBank& rng_bank,
    const std::span<const Sample> finite_support_snapshot) {
  return draw_conditional_sample_impl(access, state, rng_bank,
                                      finite_support_snapshot);
}

}  // namespace sampling::detail

}  // namespace mwperf
