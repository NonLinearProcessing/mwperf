#pragma once

#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/sampling/estimators.hpp"

namespace mwperf::sampling::detail {

struct UnavailableOptionalAuthorityV1 final {
  Diagnostic reason;
};

struct AvailableTargetDensityRatioAuthorityV1 final {
  ConditionalTargetRatioContractV1 contract;
  ConditionalTargetRatioCallbackV1 operation;
};

using TargetDensityRatioAuthorityV1 =
    std::variant<UnavailableOptionalAuthorityV1,
                 AvailableTargetDensityRatioAuthorityV1>;

struct AvailableExactInnovationAuthorityV1 final {
  ConditionalExactInnovationContractV1 contract;
  ConditionalExactInnovationCallbackV1 operation;
};

using ExactInnovationAuthorityV1 =
    std::variant<UnavailableOptionalAuthorityV1,
                 AvailableExactInnovationAuthorityV1>;

struct C24RngAccess final {
  [[nodiscard]] static Result<RngBank> make(
      const Digest256& seal_digest, const Digest256& row_digest,
      std::string_view estimator_id, const BigNat& replication_index,
      MasterSeed seed, StageTag stage);
  [[nodiscard]] static Result<std::reference_wrapper<DeterministicRng>>
  consume(RngBank& bank, const Digest256& expected_seal,
          StageTag expected_stage);
  [[nodiscard]] static Result<SamplingReplicationReplayV1>
  capture_replay_record(const RngBank& bank);
  [[nodiscard]] static bool draw_was_consumed(
      const RngBank& bank) noexcept;
};

struct NormalizedSamplerCore final {
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework_core;
  Digest256 seal_digest;
  Digest256 accepted_contract_digest;
  std::vector<AcceptedSamplingClauseV1> accepted_sampling_clauses;
  std::optional<BigNat> accepted_generator_draw_cap;
  TransitionKernelAccessShapeV1 shape;
  ConditionalSamplerContractV1 contract;
  ValidateReducedStateDomainV1 validate_state_domain;
  ConditionalSamplerCallbackV1 draw;
  ConditionalSampleValidatorV1 validate_sample;
  ConditionalSupportEnumeratorV1 enumerate_support;
  ConditionalSupportQueryV1 query_support;
  TargetDensityRatioAuthorityV1 target_density_ratio;
  ExactInnovationAuthorityV1 exact_innovation;
};

struct SamplingPlanCore final {
  MonteCarloAccuracyV1 accuracy;
  MasterSeed seed;
  std::string estimator_id;
  Digest256 metric_target_digest;
  BigNat draw_cap;
  StageTag stage;
  bool request_rao_blackwellization;
  std::optional<TotalVariationRequestV1> total_variation;
  Digest256 plan_digest;
  Digest256 seal_digest;
  Digest256 accepted_contract_digest;
  MetricClauseIdV1 accepted_clause_id;
  BackendRouteKindV1 accepted_backend_route;
  MonteCarloAccuracyV1 accepted_clause_accuracy;
  ConditionalSamplerRevealStageV1 reveal_stage;
  ConditionalSampleDependenceV1 dependence;
};

// Mutable accounting authority is translation-unit internal and reachable
// only through C24CoreAccess.  The public observer holds this state read-only.
struct SamplingExecutionState final {
  Digest256 plan_digest;
  StageTag stage;
  BigNat draw_cap;
  BigNat generator_draws{0U};
  BigNat failed_draws{0U};
  std::vector<SamplingReplicationReplayV1> replay_streams;
  bool estimator_claimed{false};
};

struct TargetRatioCore final {
  std::shared_ptr<const NormalizedSamplerCore> sampler;
  ConditionalTargetRatioContractV1 contract;
  ConditionalTargetRatioCallbackV1 ratio;
  Digest256 seal_digest;
  Digest256 conditioning_row_digest;
  Digest256 plan_digest;
  Digest256 metric_target_digest;
  Digest256 proposal_law_identity;
  Digest256 output_schema;
};

struct ExactInnovationCore final {
  std::shared_ptr<const NormalizedSamplerCore> sampler;
  ConditionalExactInnovationContractV1 contract;
  ConditionalExactInnovationCallbackV1 integrate;
  ConditioningState conditioning_state;
  Digest256 seal_digest;
  Digest256 conditioning_row_digest;
  Digest256 plan_digest;
  Digest256 metric_target_digest;
  Digest256 configured_arrival_law;
  Digest256 residual_schema;
  Digest256 output_schema;
};

struct EmpiricalResidualCore final {
  std::shared_ptr<const NormalizedSamplerCore> sampler;
  ConditioningState conditioning_state;
  std::vector<Sample> samples;
  std::vector<SamplingReplicationReplayV1> replay_streams;
  Digest256 seal_digest;
  Digest256 conditioning_row_digest;
  Digest256 plan_digest;
  Digest256 metric_target_digest;
  Digest256 configured_arrival_law;
  Digest256 residual_schema;
  Digest256 output_schema;
  bool iid_replications;
  bool rao_blackwell_authorized;
  MonteCarloAccuracyV1 accuracy;
};

class C24CoreAccess final {
 public:
  C24CoreAccess() = delete;

  [[nodiscard]] static std::shared_ptr<
      surrogate::detail::SealedFrameworkCore>
  descriptor_core(const AuditedSamplerDescriptor& descriptor) noexcept;
  [[nodiscard]] static const NormalizedConditionalSamplerAccess*
  raw_sampler(const surrogate::detail::SealedFrameworkCore& core) noexcept;
  [[nodiscard]] static ConditionalSamplerCallbackV1 draw_operation(
      const NormalizedConditionalSamplerAccess& sampler);
  [[nodiscard]] static ConditionalSampleValidatorV1 sample_validator(
      const NormalizedConditionalSamplerAccess& sampler);
  [[nodiscard]] static ConditionalSupportEnumeratorV1 support_enumerator(
      const NormalizedConditionalSamplerAccess& sampler);
  [[nodiscard]] static ConditionalSupportQueryV1 support_query(
      const NormalizedConditionalSamplerAccess& sampler);
  [[nodiscard]] static ConditionalTargetRatioCallbackV1 ratio_operation(
      const NormalizedConditionalSamplerAccess& sampler);
  [[nodiscard]] static ConditionalExactInnovationCallbackV1
  innovation_operation(const NormalizedConditionalSamplerAccess& sampler);

  [[nodiscard]] static NormalizedSamplerAccess normalized_sampler(
      std::shared_ptr<const NormalizedSamplerCore> core);
  [[nodiscard]] static const std::shared_ptr<const NormalizedSamplerCore>&
  sampler_core(const NormalizedSamplerAccess& access) noexcept;

  [[nodiscard]] static SamplingPlan sampling_plan(
      std::shared_ptr<const SamplingPlanCore> core);
  [[nodiscard]] static const std::shared_ptr<const SamplingPlanCore>&
  plan_core(const SamplingPlan& plan) noexcept;

  [[nodiscard]] static std::shared_ptr<SamplingExecutionState>&
  sampling_execution_state(SamplingExecutionObserverV1& observer) noexcept;

  [[nodiscard]] static EmpiricalRow empirical_row(
      BigNat total, std::vector<EmpiricalRowAtomV1> atoms,
      bool iid_replications, Digest256 seal_digest, Digest256 row_digest,
      Digest256 plan_digest, Digest256 metric_target_digest,
      SamplingEvidenceSnapshotV1 sampling_evidence,
      SamplingCostCountersV1 costs,
      std::vector<SamplingReplicationReplayV1> replay_streams,
      std::optional<TotalVariationBoundV1> tv_bound,
      std::size_t failed_draws);

  [[nodiscard]] static Estimate estimate(
      long double value, std::optional<long double> sample_variance,
      std::optional<FixedSampleIntervalV1> interval,
      SamplingClaimScopeV1 claim_scope, BigNat replications,
      std::vector<long double> raw_rewards,
      std::vector<ImportanceWeightRecordV1> raw_weights,
      std::optional<ImportanceDiagnosticsV1> importance_diagnostics,
      std::optional<long double> exact_integration_absolute_error,
      SamplingCostCountersV1 costs,
      SamplingEvidenceSnapshotV1 sampling_evidence,
      std::vector<SamplingReplicationReplayV1> replay_streams,
      Digest256 seal_digest, Digest256 row_digest, Digest256 plan_digest,
      Digest256 metric_target_digest,
      std::optional<Digest256> proposal_law_identity,
      std::optional<Digest256> target_law_identity,
      std::shared_ptr<const EmpiricalResidualCore> residual = {});

  [[nodiscard]] static EmpiricalResidual empirical_residual(
      std::shared_ptr<const EmpiricalResidualCore> core);
  [[nodiscard]] static const std::shared_ptr<const EmpiricalResidualCore>&
  residual_core(const EmpiricalResidual& residual) noexcept;

  [[nodiscard]] static AuditedTargetDensityRatio target_ratio(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework,
      Digest256 plan_binding,
      std::shared_ptr<const TargetRatioCore> core);
  [[nodiscard]] static const std::shared_ptr<const TargetRatioCore>&
  target_ratio_core(const AuditedTargetDensityRatio& ratio) noexcept;

  [[nodiscard]] static AuditedExactInnovationKernel exact_innovation(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework,
      Digest256 representation_binding,
      std::shared_ptr<const ExactInnovationCore> core);
  [[nodiscard]] static const std::shared_ptr<const ExactInnovationCore>&
  exact_innovation_core(
      const AuditedExactInnovationKernel& innovation) noexcept;
};

[[nodiscard]] Result<Digest256> conditioning_state_digest(
    const ConditioningState& state);
[[nodiscard]] Result<Digest256> sample_digest(const Sample& sample);
[[nodiscard]] Result<void> validate_sealed_state_domain(
    const ValidateReducedStateDomainV1& prototype,
    const ReducedStateV1& state, bool successor);
[[nodiscard]] Result<void> validate_sealed_completed_sample(
    const NormalizedSamplerCore& sampler,
    const ConditioningState& conditioning_state, const Sample& sample);
[[nodiscard]] Result<std::size_t> fixed_replication_count(
    const SamplingPlanCore& plan);
[[nodiscard]] StageTag required_sampler_stage(
    const ConditionalSamplerContractV1& contract) noexcept;
[[nodiscard]] Result<void> validate_plan_access_binding(
    const NormalizedSamplerCore& sampler, const SamplingPlanCore& plan);
// Estimator-only draw path.  The caller has already obtained and validated one
// immutable finite-support snapshot for the complete fixed bank.  Reusing that
// snapshot avoids consulting a potentially stateful enumerator between
// replications while retaining the public one-draw operation's own audit.
[[nodiscard]] Result<Sample> draw_conditional_sample_from_frozen_support(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    RngBank& rng_bank, std::span<const Sample> finite_support_snapshot);
[[nodiscard]] Diagnostic sampling_diagnostic(DiagnosticCategory category,
                                             std::string code,
                                             std::string message);

}  // namespace mwperf::sampling::detail
