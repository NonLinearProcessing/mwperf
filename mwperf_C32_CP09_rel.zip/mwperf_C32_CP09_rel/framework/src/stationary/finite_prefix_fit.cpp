#include "mwperf/stationary/finite_prefix_fit.hpp"

#include <algorithm>
#include <array>
#include <functional>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    const DiagnosticCategory category = DiagnosticCategory::input_validation) {
  return Result<T>::failure(Diagnostic{category, std::move(code),
                                       std::move(message), std::nullopt,
                                       std::nullopt, {}});
}

[[nodiscard]] ExactRational rational_from_size(const std::size_t value) {
  return ExactRational::make(BigInt{value}, BigInt{1}).value();
}

[[nodiscard]] ExactRational rational_from_nat(const BigNat& value) {
  return ExactRational::make(value.value(), BigInt{1}).value();
}

[[nodiscard]] bool is_probability(const ExactRational& value) {
  return value.is_nonnegative() && value <= ExactRational::one();
}

[[nodiscard]] Result<std::vector<FinitePrefixFitArrivalAtomV1>>
canonical_arrival_atoms(
    std::vector<FinitePrefixFitArrivalAtomV1> atoms,
    const FinitePrefixFitLimitsV1& limits) {
  if (atoms.empty()) {
    return fail<std::vector<FinitePrefixFitArrivalAtomV1>>(
        "c19.empty_arrival_pmf", "an IID arrival PMF must have an atom");
  }
  if (atoms.size() > limits.maximum_arrival_atoms) {
    return fail<std::vector<FinitePrefixFitArrivalAtomV1>>(
        "c19.fit_arrival_atom_limit",
        "the exact target-arrival PMF exceeds the fit admission limit",
        DiagnosticCategory::resource_limit);
  }
  std::sort(atoms.begin(), atoms.end(), [](const auto& left,
                                           const auto& right) {
    return left.count < right.count;
  });
  std::vector<FinitePrefixFitArrivalAtomV1> canonical;
  canonical.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!atom.mass.is_nonnegative()) {
      return fail<std::vector<FinitePrefixFitArrivalAtomV1>>(
          "c19.negative_arrival_mass",
          "IID arrival probabilities must be nonnegative");
    }
    if (!canonical.empty() && canonical.back().count == atom.count) {
      canonical.back().mass = canonical.back().mass + atom.mass;
    } else {
      canonical.push_back(std::move(atom));
    }
  }
  std::erase_if(canonical, [](const auto& atom) {
    return atom.mass.is_zero();
  });
  ExactRational total = ExactRational::zero();
  for (const auto& atom : canonical) {
    total = total + atom.mass;
  }
  if (!(total == ExactRational::one())) {
    return fail<std::vector<FinitePrefixFitArrivalAtomV1>>(
        "c19.arrival_mass_not_normalized",
        "IID arrival probabilities must total exactly one");
  }
  return Result<std::vector<FinitePrefixFitArrivalAtomV1>>::success(
      std::move(canonical));
}

[[nodiscard]] Result<std::vector<FinitePrefixFitSelectionSeedAtomV1>>
canonical_selection_seed(
    std::vector<FinitePrefixFitSelectionSeedAtomV1> atoms,
    const FinitePrefixFitLimitsV1& limits) {
  if (atoms.size() > limits.maximum_selection_seed_atoms) {
    return fail<std::vector<FinitePrefixFitSelectionSeedAtomV1>>(
        "c19.fit_selection_seed_limit",
        "the exact selected-support seed exceeds the fit admission limit",
        DiagnosticCategory::resource_limit);
  }
  if (atoms.empty()) {
    return Result<std::vector<FinitePrefixFitSelectionSeedAtomV1>>::success(
        {});
  }
  std::sort(atoms.begin(), atoms.end(), [](const auto& left,
                                           const auto& right) {
    return left.backlog < right.backlog;
  });
  std::vector<FinitePrefixFitSelectionSeedAtomV1> canonical;
  canonical.reserve(atoms.size());
  for (auto& atom : atoms) {
    if (!atom.selection_mass.is_nonnegative()) {
      return fail<std::vector<FinitePrefixFitSelectionSeedAtomV1>>(
          "c19.scalar_selection_seed_negative",
          "selected scalar seed masses must be nonnegative");
    }
    if (!canonical.empty() && canonical.back().backlog == atom.backlog) {
      canonical.back().selection_mass =
          canonical.back().selection_mass + atom.selection_mass;
    } else {
      canonical.push_back(std::move(atom));
    }
  }
  std::erase_if(canonical, [](const auto& atom) {
    return atom.selection_mass.is_zero();
  });
  ExactRational total = ExactRational::zero();
  for (const auto& atom : canonical) {
    total = total + atom.selection_mass;
  }
  if (!(total == ExactRational::one())) {
    return fail<std::vector<FinitePrefixFitSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_not_normalized",
        "selected scalar seed masses must total exactly one");
  }
  return Result<std::vector<FinitePrefixFitSelectionSeedAtomV1>>::success(
      std::move(canonical));
}

[[nodiscard]] Result<void> validate_response(
    const std::vector<ExactRational>& service_by_level,
    const ExactRational& tail_service,
    const FinitePrefixFitLimitsV1& limits) {
  if (service_by_level.empty()) {
    return Result<void>::failure(Diagnostic{
        DiagnosticCategory::input_validation,
        "c19.finite_prefix_response_shape",
        "the finite-prefix fit requires mu(0) through mu(K)", std::nullopt,
        std::nullopt, {}});
  }
  const std::size_t cutoff = service_by_level.size() - 1U;
  if (cutoff > limits.maximum_cutoff) {
    return Result<void>::failure(Diagnostic{
        DiagnosticCategory::resource_limit, "c19.fit_cutoff_limit",
        "the finite-prefix cutoff exceeds the fit admission limit",
        std::nullopt, std::nullopt, {}});
  }
  if (service_by_level.size() > limits.maximum_closure_states) {
    return Result<void>::failure(Diagnostic{
        DiagnosticCategory::resource_limit, "c19.fit_closure_state_limit",
        "the finite-closure state domain exceeds the fit admission limit",
        std::nullopt, std::nullopt, {}});
  }
  for (std::size_t level = 0U; level < service_by_level.size(); ++level) {
    if (!is_probability(service_by_level[level])) {
      return Result<void>::failure(Diagnostic{
          DiagnosticCategory::input_validation,
          "c19.response_out_of_range",
          "a service probability lies outside [0,1]", std::nullopt,
          std::nullopt, {}});
    }
    if (level == 0U && !service_by_level[level].is_zero()) {
      return Result<void>::failure(Diagnostic{
          DiagnosticCategory::input_validation, "c19.mu_zero_nonzero",
          "SF.14 requires mu(0)=0", std::nullopt, std::nullopt, {}});
    }
  }
  if (!is_probability(tail_service)) {
    return Result<void>::failure(Diagnostic{
        DiagnosticCategory::input_validation,
        "c19.response_out_of_range",
        "the tail service lies outside [0,1]", std::nullopt, std::nullopt,
        {}});
  }
  return Result<void>::success();
}

struct ArrivalProfile final {
  std::vector<FinitePrefixFitArrivalAtomV1> atoms;
  std::vector<ExactRational> reverse_survival;
  ExactRational mean;
  std::optional<ExactRational> second_moment;
  std::optional<ExactRational> third_moment;
};

[[nodiscard]] ArrivalProfile make_arrival_profile(
    std::vector<FinitePrefixFitArrivalAtomV1> atoms,
    const bool second_moment_available,
    const bool third_moment_available,
    const std::optional<FinitePrefixFitArrivalMomentsV1>& analytic_moments) {
  ExactRational mean = ExactRational::zero();
  ExactRational second = ExactRational::zero();
  ExactRational third = ExactRational::zero();
  for (const auto& atom : atoms) {
    const ExactRational count = rational_from_nat(atom.count);
    const ExactRational weighted_count = atom.mass * count;
    const ExactRational weighted_square = weighted_count * count;
    mean = mean + weighted_count;
    second = second + weighted_square;
    if (third_moment_available) {
      third = third + weighted_square * count;
    }
  }
  std::vector<ExactRational> reverse(atoms.size(), ExactRational::zero());
  ExactRational suffix = ExactRational::zero();
  for (std::size_t position = atoms.size(); position-- > 0U;) {
    suffix = suffix + atoms[position].mass;
    reverse[position] = suffix;
  }
  if (analytic_moments) {
    return {std::move(atoms), std::move(reverse), analytic_moments->mean,
            analytic_moments->second, analytic_moments->third};
  }
  return {std::move(atoms), std::move(reverse), std::move(mean),
          second_moment_available
              ? std::optional<ExactRational>(std::move(second))
              : std::nullopt,
          third_moment_available
              ? std::optional<ExactRational>(std::move(third))
              : std::nullopt};
}

[[nodiscard]] ExactRational arrival_probability(
    const ArrivalProfile& arrival, const BigInt& count) {
  if (count < 0) {
    return ExactRational::zero();
  }
  const auto found = std::lower_bound(
      arrival.atoms.begin(), arrival.atoms.end(), count,
      [](const FinitePrefixFitArrivalAtomV1& atom, const BigInt& wanted) {
        return atom.count.value() < wanted;
      });
  if (found == arrival.atoms.end() || found->count.value() != count) {
    return ExactRational::zero();
  }
  return found->mass;
}

[[nodiscard]] ExactRational arrival_survival(
    const ArrivalProfile& arrival, const BigInt& threshold) {
  if (threshold <= 0) {
    return ExactRational::one();
  }
  const auto found = std::lower_bound(
      arrival.atoms.begin(), arrival.atoms.end(), threshold,
      [](const FinitePrefixFitArrivalAtomV1& atom, const BigInt& wanted) {
        return atom.count.value() < wanted;
      });
  if (found == arrival.atoms.end()) {
    return ExactRational::zero();
  }
  return arrival.reverse_survival[static_cast<std::size_t>(
      found - arrival.atoms.begin())];
}

[[nodiscard]] ExactRational transition_probability(
    const ArrivalProfile& arrival,
    const std::vector<ExactRational>& service_by_level,
    const std::size_t source, const std::size_t destination) {
  const ExactRational& mu = service_by_level[source];
  const BigInt offset = BigInt{destination} - BigInt{source};
  return mu * arrival_probability(arrival, offset + 1) +
         (ExactRational::one() - mu) *
             arrival_probability(arrival, offset);
}

[[nodiscard]] Result<ExactRational> next_cut_weight(
    const ArrivalProfile& arrival,
    const std::vector<ExactRational>& service_by_level,
    const std::vector<ExactRational>& weights, const std::size_t cut) {
  const ExactRational denominator =
      service_by_level[cut] * arrival_probability(arrival, BigInt{0});
  ExactRational numerator = ExactRational::zero();
  for (std::size_t source = 0U; source < cut; ++source) {
    const BigInt distance = BigInt{cut - source};
    numerator =
        numerator +
        weights[source] *
            ((ExactRational::one() - service_by_level[source]) *
                 arrival_survival(arrival, distance) +
             service_by_level[source] *
                 arrival_survival(arrival, distance + 1));
  }
  if (denominator.is_zero()) {
    if (numerator.is_zero()) {
      return fail<ExactRational>(
          "c19.cut_underdetermined_closed_class",
          "SF.19 has zero denominator and zero crossing flux",
          DiagnosticCategory::unavailable);
    }
    return fail<ExactRational>(
        "c19.cut_inconsistent_zero_denominator",
        "SF.19 has positive crossing flux but zero downward coefficient");
  }
  return checked_divide(numerator, denominator);
}

struct FiniteClosure final {
  bool closed;
  std::vector<std::size_t> reachable;
  std::vector<std::size_t> selected_class;
};

[[nodiscard]] Result<FiniteClosure> prove_finite_closure(
    const ArrivalProfile& arrival,
    const std::vector<ExactRational>& service_by_level,
    const std::vector<FinitePrefixFitSelectionSeedAtomV1>& selection_seed) {
  const std::size_t maximum = service_by_level.size() - 1U;
  std::vector<std::uint8_t> seen(maximum + 1U, 0U);
  std::vector<std::size_t> queue;
  queue.reserve(maximum + 1U);
  bool closed = true;
  for (const auto& atom : selection_seed) {
    if (atom.backlog.value() > BigInt{maximum}) {
      closed = false;
      continue;
    }
    const std::size_t level = atom.backlog.value().convert_to<std::size_t>();
    if (atom.selection_mass.is_positive() && seen[level] == 0U) {
      seen[level] = 1U;
      queue.push_back(level);
    }
  }
  if (queue.empty()) {
    return Result<FiniteClosure>::success({false, {}, {}});
  }
  for (std::size_t cursor = 0U; cursor < queue.size(); ++cursor) {
    const std::size_t source = queue[cursor];
    const ExactRational& mu = service_by_level[source];
    const std::array<std::pair<bool, ExactRational>, 2U> branches{{
        {false, ExactRational::one() - mu}, {true, mu}}};
    for (const auto& arrival_atom : arrival.atoms) {
      if (!arrival_atom.mass.is_positive()) {
        continue;
      }
      for (const auto& [departure, branch_mass] : branches) {
        if (!branch_mass.is_positive()) {
          continue;
        }
        BigInt destination = BigInt{source} + arrival_atom.count.value();
        if (departure) {
          destination -= 1;
        }
        if (destination < 0) {
          return fail<FiniteClosure>(
              "c19.scalar_negative_successor",
              "SF.14 produced a negative level from a positive event");
        }
        if (destination > BigInt{maximum}) {
          closed = false;
          continue;
        }
        const std::size_t native = destination.convert_to<std::size_t>();
        if (seen[native] == 0U) {
          seen[native] = 1U;
          queue.push_back(native);
        }
      }
    }
  }
  std::sort(queue.begin(), queue.end());
  if (!closed) {
    return Result<FiniteClosure>::success(
        {false, std::move(queue), {}});
  }

  const std::size_t count = queue.size();
  std::vector<int> discovery(count, -1);
  std::vector<int> low(count, -1);
  std::vector<std::size_t> stack;
  stack.reserve(count);
  std::vector<std::uint8_t> on_stack(count, 0U);
  std::vector<std::vector<std::size_t>> components;
  int next_discovery = 0;
  std::function<void(std::size_t)> visit = [&](const std::size_t vertex) {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = 1U;
    for (std::size_t successor = 0U; successor < count; ++successor) {
      if (!transition_probability(arrival, service_by_level, queue[vertex],
                                  queue[successor])
               .is_positive()) {
        continue;
      }
      if (discovery[successor] == -1) {
        visit(successor);
        low[vertex] = std::min(low[vertex], low[successor]);
      } else if (on_stack[successor] != 0U) {
        low[vertex] = std::min(low[vertex], discovery[successor]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::size_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = 0U;
      component.push_back(member);
      if (member == vertex) {
        break;
      }
    }
    std::sort(component.begin(), component.end());
    components.push_back(std::move(component));
  };
  for (std::size_t vertex = 0U; vertex < count; ++vertex) {
    if (discovery[vertex] == -1) {
      visit(vertex);
    }
  }
  std::sort(components.begin(), components.end());
  std::vector<std::size_t> component_of(count, 0U);
  for (std::size_t component = 0U; component < components.size(); ++component) {
    for (const std::size_t member : components[component]) {
      component_of[member] = component;
    }
  }
  std::vector<std::uint8_t> component_closed(components.size(), 1U);
  for (std::size_t source = 0U; source < count; ++source) {
    for (std::size_t destination = 0U; destination < count; ++destination) {
      if (component_of[source] != component_of[destination] &&
          transition_probability(arrival, service_by_level, queue[source],
                                 queue[destination])
              .is_positive()) {
        component_closed[component_of[source]] = 0U;
      }
    }
  }
  std::vector<std::size_t> closed_components;
  for (std::size_t component = 0U; component < components.size(); ++component) {
    if (component_closed[component] != 0U) {
      closed_components.push_back(component);
    }
  }
  if (closed_components.size() != 1U) {
    return fail<FiniteClosure>(
        "c19.scalar_stationary_class_ambiguous",
        "the selected scalar seed does not reach exactly one closed class");
  }
  std::vector<std::size_t> selected;
  for (const std::size_t position :
       components[closed_components.front()]) {
    selected.push_back(queue[position]);
  }
  return Result<FiniteClosure>::success(
      {true, std::move(queue), std::move(selected)});
}

[[nodiscard]] Result<std::vector<ExactRational>> exact_invariant(
    const std::vector<ExactRational>& matrix, const std::size_t dimension) {
  std::vector<std::vector<ExactRational>> augmented(
      dimension,
      std::vector<ExactRational>(dimension + 1U, ExactRational::zero()));
  for (std::size_t equation = 0U; equation + 1U < dimension; ++equation) {
    for (std::size_t variable = 0U; variable < dimension; ++variable) {
      augmented[equation][variable] =
          matrix[variable * dimension + equation] -
          (variable == equation ? ExactRational::one()
                                : ExactRational::zero());
    }
  }
  for (std::size_t variable = 0U; variable < dimension; ++variable) {
    augmented[dimension - 1U][variable] = ExactRational::one();
  }
  augmented[dimension - 1U][dimension] = ExactRational::one();

  std::size_t rank = 0U;
  for (std::size_t column = 0U; column < dimension && rank < dimension;
       ++column) {
    std::size_t pivot = rank;
    while (pivot < dimension && augmented[pivot][column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      continue;
    }
    std::swap(augmented[pivot], augmented[rank]);
    const ExactRational divisor = augmented[rank][column];
    for (std::size_t entry = column; entry <= dimension; ++entry) {
      auto divided = checked_divide(augmented[rank][entry], divisor);
      if (!divided) {
        return Result<std::vector<ExactRational>>::failure(divided.error());
      }
      augmented[rank][entry] = std::move(divided).value();
    }
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == rank || augmented[row][column].is_zero()) {
        continue;
      }
      const ExactRational factor = augmented[row][column];
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        augmented[row][entry] =
            augmented[row][entry] - factor * augmented[rank][entry];
      }
    }
    ++rank;
  }
  if (rank != dimension) {
    return fail<std::vector<ExactRational>>(
        "c19.multiple_finite_classes",
        "the exact finite closure has no uniquely selected invariant law",
        DiagnosticCategory::unavailable);
  }
  std::vector<ExactRational> solution(dimension, ExactRational::zero());
  for (std::size_t row = 0U; row < dimension; ++row) {
    std::size_t pivot = 0U;
    while (pivot < dimension && augmented[row][pivot].is_zero()) {
      ++pivot;
    }
    if (pivot < dimension) {
      solution[pivot] = augmented[row][dimension];
    }
  }
  for (const auto& mass : solution) {
    if (!mass.is_nonnegative()) {
      return fail<std::vector<ExactRational>>(
          "c19.negative_finite_stationary_mass",
          "the exact finite invariant solve produced negative mass",
          DiagnosticCategory::internal);
    }
  }
  return Result<std::vector<ExactRational>>::success(std::move(solution));
}

[[nodiscard]] Result<FinitePrefixFitResultV1> finite_closure_fit(
    const ArrivalProfile& arrival,
    std::vector<ExactRational> service_by_level,
    ExactRational tail_service, FinitePrefixFitBindingV1 binding,
    const FiniteClosure& closure) {
  const std::size_t maximum = service_by_level.size() - 1U;
  const std::size_t class_size = closure.selected_class.size();
  std::vector<ExactRational> matrix(class_size * class_size,
                                    ExactRational::zero());
  for (std::size_t row = 0U; row < class_size; ++row) {
    ExactRational total = ExactRational::zero();
    for (std::size_t column = 0U; column < class_size; ++column) {
      const ExactRational value = transition_probability(
          arrival, service_by_level, closure.selected_class[row],
          closure.selected_class[column]);
      matrix[row * class_size + column] = value;
      total = total + value;
    }
    if (!(total == ExactRational::one())) {
      return fail<FinitePrefixFitResultV1>(
          "c19.finite_row_mass",
          "an exactly selected closed SF.14 row does not total one",
          DiagnosticCategory::internal);
    }
  }
  auto invariant = exact_invariant(matrix, class_size);
  if (!invariant) {
    return Result<FinitePrefixFitResultV1>::failure(invariant.error());
  }
  std::vector<ExactRational> masses(maximum + 1U, ExactRational::zero());
  ExactRational mean = ExactRational::zero();
  ExactRational second_moment = ExactRational::zero();
  for (std::size_t index = 0U; index < class_size; ++index) {
    masses[closure.selected_class[index]] = invariant.value()[index];
    const ExactRational level =
        rational_from_size(closure.selected_class[index]);
    mean = mean + level * invariant.value()[index];
    second_moment =
        second_moment + level * level * invariant.value()[index];
  }
  ExactRational total = ExactRational::zero();
  for (const auto& mass : masses) {
    total = total + mass;
  }
  const ExactRational normalization = total - ExactRational::one();
  ExactRational invariance = ExactRational::zero();
  for (std::size_t destination = 0U; destination < class_size;
       ++destination) {
    ExactRational incoming = ExactRational::zero();
    for (std::size_t source = 0U; source < class_size; ++source) {
      incoming = incoming + invariant.value()[source] *
                                matrix[source * class_size + destination];
    }
    invariance = std::max(
        invariance,
        absolute_value(incoming - invariant.value()[destination]));
  }
  std::vector<BigNat> reachable;
  reachable.reserve(closure.reachable.size());
  for (const std::size_t state : closure.reachable) {
    reachable.emplace_back(static_cast<std::uint64_t>(state));
  }
  return Result<FinitePrefixFitResultV1>::success(
      FinitePrefixFitResultV1{
          FinitePrefixFitStatusV1::finite_closed_tail_unreachable,
          std::move(binding),
          std::move(service_by_level),
          std::move(tail_service),
          arrival.mean,
          arrival.second_moment,
          arrival.third_moment,
          std::move(masses),
          ExactRational::zero(),
          std::move(mean),
          std::move(second_moment),
          FinitePrefixFitSlackApplicabilityV1::not_applicable_off_class,
          std::nullopt,
          {std::move(normalization), std::move(invariance), std::nullopt},
          BigNat{static_cast<std::uint64_t>(closure.reachable.size())},
          std::move(reachable)});
}

[[nodiscard]] Result<FinitePrefixFitResultV1> status_fit(
    const FinitePrefixFitStatusV1 status, const ArrivalProfile& arrival,
    std::vector<ExactRational> service_by_level,
    ExactRational tail_service, FinitePrefixFitBindingV1 binding,
    std::optional<ExactRational> slack, const std::size_t terms) {
  return Result<FinitePrefixFitResultV1>::success(
      FinitePrefixFitResultV1{
          status,
          std::move(binding),
          std::move(service_by_level),
          std::move(tail_service),
          arrival.mean,
          arrival.second_moment,
          arrival.third_moment,
          std::nullopt,
          std::nullopt,
          std::nullopt,
          std::nullopt,
          slack ? FinitePrefixFitSlackApplicabilityV1::applicable
                : FinitePrefixFitSlackApplicabilityV1::
                      stationary_law_not_established,
          std::move(slack),
          {std::nullopt, std::nullopt, std::nullopt},
          BigNat{static_cast<std::uint64_t>(terms)},
          {}});
}

}  // namespace

Result<FinitePrefixFitResultV1> fit_finite_prefix_constant_tail(
    FinitePrefixFitInputV1 input) {
  // All cardinality checks precede cutoff-sized allocations.
  auto valid_response = validate_response(
      input.service_by_level, input.constant_tail_service, input.limits);
  if (!valid_response) {
    return Result<FinitePrefixFitResultV1>::failure(valid_response.error());
  }
  auto canonical_arrival = canonical_arrival_atoms(
      std::move(input.target_arrival_atoms), input.limits);
  if (!canonical_arrival) {
    return Result<FinitePrefixFitResultV1>::failure(
        canonical_arrival.error());
  }
  auto canonical_seed = canonical_selection_seed(
      std::move(input.selection_seed), input.limits);
  if (!canonical_seed) {
    return Result<FinitePrefixFitResultV1>::failure(canonical_seed.error());
  }
  if (input.analytic_arrival_moments &&
      (!input.analytic_arrival_moments->mean.is_nonnegative() ||
       !input.analytic_arrival_moments->second.is_nonnegative() ||
       !input.analytic_arrival_moments->third.is_nonnegative())) {
    return fail<FinitePrefixFitResultV1>(
        "c19.analytic_arrival_moment_negative",
        "analytic arrival moments supplied to the finite-prefix fit must be nonnegative");
  }
  ArrivalProfile arrival = make_arrival_profile(
      std::move(canonical_arrival).value(),
      input.second_arrival_moment_available,
      input.third_arrival_moment_available,
      input.analytic_arrival_moments);
  const std::size_t maximum = input.service_by_level.size() - 1U;

  // A proved finite selected class is authoritative even when c-lambda is
  // zero or negative.  This ordering is part of the public fit contract.
  auto closure = prove_finite_closure(
      arrival, input.service_by_level, canonical_seed.value());
  if (!closure) {
    return Result<FinitePrefixFitResultV1>::failure(closure.error());
  }
  if (closure.value().closed &&
      !input.arrival_support_extends_beyond_projection) {
    return finite_closure_fit(
        arrival, std::move(input.service_by_level),
        std::move(input.constant_tail_service), std::move(input.binding),
        closure.value());
  }

  const ExactRational slack = input.constant_tail_service - arrival.mean;
  if (!slack.is_positive()) {
    return status_fit(
        FinitePrefixFitStatusV1::outside_strict_tail_profile, arrival,
        std::move(input.service_by_level),
        std::move(input.constant_tail_service), std::move(input.binding),
        slack, maximum + 1U);
  }
  const ExactRational a0 = arrival_probability(arrival, BigInt{0});
  if (!a0.is_positive()) {
    return status_fit(FinitePrefixFitStatusV1::unsupported_assumptions,
                      arrival, std::move(input.service_by_level),
                      std::move(input.constant_tail_service),
                      std::move(input.binding), slack, 0U);
  }

  std::vector<ExactRational> weights{ExactRational::one()};
  weights.reserve(maximum + 1U);
  for (std::size_t cut = 1U; cut <= maximum; ++cut) {
    auto weight =
        next_cut_weight(arrival, input.service_by_level, weights, cut);
    if (!weight) {
      if (weight.error().code == "c19.cut_inconsistent_zero_denominator") {
        return status_fit(FinitePrefixFitStatusV1::unsupported_assumptions,
                          arrival, std::move(input.service_by_level),
                          std::move(input.constant_tail_service),
                          std::move(input.binding), slack, cut);
      }
      if (weight.error().code != "c19.cut_underdetermined_closed_class") {
        return Result<FinitePrefixFitResultV1>::failure(weight.error());
      }
      return status_fit(
          FinitePrefixFitStatusV1::degenerate_or_selected_closed_class,
          arrival, std::move(input.service_by_level),
          std::move(input.constant_tail_service), std::move(input.binding),
          slack, cut);
    }
    if (!weight.value().is_nonnegative()) {
      return fail<FinitePrefixFitResultV1>(
          "c19.negative_cut_weight",
          "SF.19 produced a negative stationary weight",
          DiagnosticCategory::internal);
    }
    weights.push_back(std::move(weight).value());
  }

  ExactRational normalizer = ExactRational::zero();
  for (std::size_t level = 0U; level <= maximum; ++level) {
    normalizer = normalizer +
                 weights[level] *
                     (input.constant_tail_service -
                      input.service_by_level[level]);
  }
  if (!normalizer.is_positive()) {
    return fail<FinitePrefixFitResultV1>(
        "c19.constant_tail_normalizer_nonpositive",
        "SF.22d requires B(1)>0 on the strict-tail branch");
  }
  auto pi0 = checked_divide(slack, normalizer);
  if (!pi0 || !pi0.value().is_positive()) {
    return fail<FinitePrefixFitResultV1>(
        "c19.constant_tail_pi_zero",
        "SF.22d did not produce a positive empty probability",
        DiagnosticCategory::internal);
  }

  std::vector<ExactRational> masses;
  masses.reserve(maximum + 1U);
  ExactRational prefix_total = ExactRational::zero();
  ExactRational correction_derivative = ExactRational::zero();
  ExactRational correction_quadratic = ExactRational::zero();
  for (std::size_t level = 0U; level <= maximum; ++level) {
    const ExactRational mass = pi0.value() * weights[level];
    if (!mass.is_nonnegative()) {
      return fail<FinitePrefixFitResultV1>(
          "c19.negative_stationary_mass",
          "SF.22d produced a negative stationary probability",
          DiagnosticCategory::internal);
    }
    const ExactRational level_value = rational_from_size(level);
    const ExactRational response_correction =
        input.constant_tail_service - input.service_by_level[level];
    prefix_total = prefix_total + mass;
    correction_derivative =
        correction_derivative + level_value * mass * response_correction;
    correction_quadratic =
        correction_quadratic +
        level_value * level_value * mass * response_correction;
    masses.push_back(mass);
  }
  const ExactRational tail_mass = ExactRational::one() - prefix_total;
  if (!tail_mass.is_nonnegative()) {
    return fail<FinitePrefixFitResultV1>(
        "c19.negative_tail_mass",
        "SF.22 normalization produced negative aggregate tail mass",
        DiagnosticCategory::internal);
  }

  FinitePrefixFitStatusV1 status =
      FinitePrefixFitStatusV1::strict_tail_stable;
  std::optional<ExactRational> mean;
  std::optional<ExactRational> second_backlog_moment;
  std::optional<ExactRational> mean_identity_residual;
  if (!arrival.second_moment) {
    status = FinitePrefixFitStatusV1::required_moment_unavailable;
  } else {
    const ExactRational two =
        ExactRational::make(BigInt{2}, BigInt{1}).value();
    const ExactRational numerator =
        *arrival.second_moment + arrival.mean -
        two * arrival.mean * arrival.mean +
        two * correction_derivative;
    auto divided = checked_divide(numerator, two * slack);
    if (!divided || !divided.value().is_nonnegative()) {
      return fail<FinitePrefixFitResultV1>(
          "c19.constant_tail_mean_invariant",
          "SF.22e did not produce a finite nonnegative mean",
          DiagnosticCategory::internal);
    }
    mean = std::move(divided).value();
    mean_identity_residual = two * slack * *mean - numerator;

    // With X=A-D and Q'=Q+X, the exact stationary third-power drift
    // identity is
    //
    //   0 = 3 E[Q^2 X] + 3 E[Q X^2] + E[X^3].
    //
    // IID late arrivals are independent of (Q,D), and D is binary.  Writing
    // c for the constant-tail service, C1=sum q*pi_q(c-mu_q), and
    // C2=sum q^2*pi_q(c-mu_q), this gives
    //
    //   3(c-lambda) E[Q^2]
    //     = 3 C2 + 3 a2 E[Q]
    //       + 3(1-2 lambda)(c E[Q]-C1)
    //       + a3 - 3 a2 lambda + 3 lambda^2 - lambda.
    //
    // No tail-shape approximation enters this identity beyond the already
    // explicit constant-tail response model.
    if (arrival.third_moment) {
      const ExactRational three =
          ExactRational::make(BigInt{3}, BigInt{1}).value();
      const ExactRational one_minus_twice_mean =
          ExactRational::one() - two * arrival.mean;
      const ExactRational numerator_second =
          three * correction_quadratic +
          three * *arrival.second_moment * *mean +
          three * one_minus_twice_mean *
              (input.constant_tail_service * *mean -
               correction_derivative) +
          *arrival.third_moment -
          three * *arrival.second_moment * arrival.mean +
          three * arrival.mean * arrival.mean - arrival.mean;
      auto divided_second =
          checked_divide(numerator_second, three * slack);
      if (!divided_second || !divided_second.value().is_nonnegative()) {
        return fail<FinitePrefixFitResultV1>(
            "c19.constant_tail_second_moment_invariant",
            "the stationary third-power drift identity did not produce a "
            "finite nonnegative second backlog moment",
            DiagnosticCategory::internal);
      }
      second_backlog_moment = std::move(divided_second).value();
    }
  }
  const ExactRational normalization_residual =
      prefix_total + tail_mass - ExactRational::one();
  const ExactRational invariance_residual =
      pi0.value() * normalizer - slack;

  return Result<FinitePrefixFitResultV1>::success(
      FinitePrefixFitResultV1{
          status,
          std::move(input.binding),
          std::move(input.service_by_level),
          std::move(input.constant_tail_service),
          arrival.mean,
          arrival.second_moment,
          arrival.third_moment,
          std::move(masses),
          std::move(tail_mass),
          std::move(mean),
          std::move(second_backlog_moment),
          FinitePrefixFitSlackApplicabilityV1::applicable,
          slack,
          {normalization_residual, invariance_residual,
           std::move(mean_identity_residual)},
          BigNat{static_cast<std::uint64_t>(maximum + 1U)},
          {}});
}

}  // namespace mwperf
