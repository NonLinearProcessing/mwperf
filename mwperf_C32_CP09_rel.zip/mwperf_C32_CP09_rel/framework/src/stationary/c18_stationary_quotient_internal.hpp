#pragma once

#include "mwperf/stationary/flux.hpp"

namespace mwperf::detail {

// Private C27 adapter for F-C18-02.  It certifies the canonical slot-zero
// representatives of a finite stationary chain when C09 supplies an exact
// finite-phase time-homogeneous row.  Certification and assembly are atomic:
// the mark-preserving completion cannot be reused with another provider or
// state domain.
[[nodiscard]] Result<TransitionMatrix>
assemble_finite_stationary_time_homogeneous_transition_matrix(
    const StateDomain& domain, const AuditedRowProvider& provider);

}  // namespace mwperf::detail
