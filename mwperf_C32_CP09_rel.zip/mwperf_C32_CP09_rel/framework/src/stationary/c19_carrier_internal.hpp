#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/stationary/analytic.hpp"
#include "mwperf/surrogate/kernel_access.hpp"

namespace mwperf::stationary::detail {

// C19-private immutable restrictions.  They are deliberately absent from the
// installed interface: only the C17/C19 mints can create audited views that
// own one of these snapshots.
struct C19CarrierLineageV1 final {
  Digest256 lineage_identity;
  Digest256 analysis_fingerprint;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  ArrivalFamily arrival_family;
};

struct C19LittleLawPremisesV1 final {
  bool lossless;
  bool unit_packets;
  bool eventual_departure;
  bool positive_finite_intensity;
  bool finite_first_backlog_moment;
  bool little_law;
};

struct C19ScalarSelectionSeedAtomV1 final {
  BigNat backlog;
  ExactRational selection_mass;
};

struct C19ScalarResponseCarrierSpecV1 final {
  C19CarrierLineageV1 lineage;
  std::vector<ScalarArrivalMassV1> arrival_atoms;
  bool second_moment_available;
  bool temporal_iid;
  std::vector<ExactRational> service_by_level;
  std::optional<BigNat> constant_tail_from;
  std::optional<ExactRational> constant_tail_service;
  std::vector<C19ScalarSelectionSeedAtomV1> selection_seed;
  C19LittleLawPremisesV1 little_law_premises;
  SelectionSpec selection;
};

struct C19PhaseResponseCarrierSpecV1 final {
  C19CarrierLineageV1 lineage;
  std::vector<ArrivalPhaseIdentityV1> phases;
  std::vector<ExactPhaseArrivalBlockV1> arrival_blocks;
  std::vector<ExactRational> configured_phase_marginal;
  std::vector<ExactRational> service_row_major;
  PhaseLevelCompletionV1 completion;
  SelectionSpec selection;
  SolverPolicy solver_policy;
};

enum class C19FixedPointStoppingNormV1 : std::uint8_t {
  maximum_absolute,
};

struct C19NamedFixedPointSolutionV1 final {
  TypedLabel id;
  std::vector<ExactRational> parameters;
};

using C19ExactFixedPointMapV1 =
    std::function<Result<std::vector<ExactRational>>(
        std::span<const ExactRational>)>;

struct C19FixedPointCarrierSpecV1 final {
  C19CarrierLineageV1 lineage;
  std::vector<ExactRational> domain_lower;
  std::vector<ExactRational> domain_upper;
  std::vector<ExactRational> codomain_lower;
  std::vector<ExactRational> codomain_upper;
  std::vector<ExactRational> cold_initial;
  C19FixedPointStoppingNormV1 stopping_norm;
  BigNat iteration_budget;
  BigNat evaluation_budget;
  bool uniqueness_declared;
  std::vector<C19NamedFixedPointSolutionV1> named_solutions;
  C19ExactFixedPointMapV1 map;
  ArtifactObjectReferenceV1 stable_map_identity;
  AnalyticFamilyIdentityV1 family_identity;
  FiniteParameterAnalyticFamilyAccessShapeV1 access_shape;
  SelectionSpec selection;
  SolverPolicy solver_policy;
};

struct AuditedScalarResponseCarrierCore final {
  std::vector<ScalarArrivalMassV1> arrival_atoms;
  bool second_moment_available;
  bool temporal_iid;
  std::vector<ExactRational> service_by_level;
  std::optional<BigNat> constant_tail_from;
  std::optional<ExactRational> constant_tail_service;
  std::vector<C19ScalarSelectionSeedAtomV1> selection_seed;
  C19LittleLawPremisesV1 little_law_premises;
  StationaryAnalyticLawIdentityV1 identity;
  std::shared_ptr<const void> seal;
};

struct AuditedPhaseResponseCarrierCore final {
  std::vector<ArrivalPhaseIdentityV1> phases;
  std::vector<ExactPhaseArrivalBlockV1> arrival_blocks;
  std::vector<ExactRational> configured_phase_marginal;
  std::vector<ExactRational> service_row_major;
  PhaseLevelCompletionV1 completion;
  SolverPolicy solver_policy;
  StationaryAnalyticLawIdentityV1 identity;
  ArrivalBinding configured_arrival;
  std::shared_ptr<const void> seal;
};

struct AuditedFixedPointCarrierCore final {
  std::vector<ExactRational> domain_lower;
  std::vector<ExactRational> domain_upper;
  std::vector<ExactRational> codomain_lower;
  std::vector<ExactRational> codomain_upper;
  std::vector<ExactRational> cold_initial;
  C19FixedPointStoppingNormV1 stopping_norm;
  BigNat iteration_budget;
  BigNat evaluation_budget;
  bool uniqueness_declared;
  std::vector<C19NamedFixedPointSolutionV1> named_solutions;
  C19ExactFixedPointMapV1 map;
  ArtifactObjectReferenceV1 stable_map_identity;
  AnalyticFamilyIdentityV1 family_identity;
  FiniteParameterAnalyticFamilyAccessShapeV1 access_shape;
  SolverPolicy solver_policy;
  StationaryAnalyticLawIdentityV1 identity;
  std::shared_ptr<const void> seal;
};

// These mints are linked only by the compact C19 mathematical support object.
// The returned public handles remain non-default- and non-caller-constructible.
[[nodiscard]] Result<AuditedResponseLaw> mint_c19_scalar_response(
    C19ScalarResponseCarrierSpecV1 spec);
[[nodiscard]] Result<AuditedThreeBinResponse> mint_c19_three_bin_response(
    C19ScalarResponseCarrierSpecV1 spec);
[[nodiscard]] Result<AuditedPhaseResponse> mint_c19_phase_response(
    C19PhaseResponseCarrierSpecV1 spec);
[[nodiscard]] Result<AuditedFixedPointFamily> mint_c19_fixed_point_family(
    C19FixedPointCarrierSpecV1 spec);

}  // namespace mwperf::stationary::detail
