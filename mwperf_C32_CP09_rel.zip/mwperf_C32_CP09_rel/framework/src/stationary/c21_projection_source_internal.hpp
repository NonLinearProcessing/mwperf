#pragma once

#include <cstddef>
#include <memory>
#include <vector>

#include "temporal/temporal_contract_internal.hpp"
#include "mwperf/stationary/suspension.hpp"
#include "temporal/c20_stationary_bridge_internal.hpp"

namespace mwperf::stationary::detail {

struct StationaryTemporalAtomCore final {
  std::size_t event_state_index;
  std::size_t word_index;
  BigNat residence_offset;
  ReducedStateV1 raw_left_state;
  ReducedStateV1 stationary_left_state;
  CompletedReducedEdge raw_edge;
  ReducedStateV1 raw_right_state;
  std::vector<RuntimeDecodedMarkV1> entrance_labels;
  ReducedStateV1 stationary_right_state;
  MarkedFluxEdgeV1 reward_edge;
  ExactRational exact_mass;
  long double numerical_mass;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

struct StationaryProjectionSourceCore final {
  EventInvariantLaw event_law;
  AuditedResidenceProvider provider;
  PositiveFiniteMean denominator;
  temporal::detail::C20StationarySourceBindingV1 provider_binding;
  std::vector<StationaryTemporalAtomCore> atoms;
  std::shared_ptr<const metrics::detail::TemporalSourceCore> temporal_source;
  Digest256 fingerprint;
};

// These immutable carrier cores live in a dependency-private header so the
// later C23 implementation can inspect and preserve the exact C21 source
// owner.  They remain absent from the installed API and expose no callback,
// row provider, executor, or controller-visible residence suffix.
struct StationaryTemporalLawCore final {
  std::shared_ptr<const StationaryProjectionSourceCore> source;
  StationaryTemporalDiagnosticsV1 diagnostics;
  Digest256 projection_fingerprint;
};

struct StationaryMarkedEdgeCore final {
  std::shared_ptr<const StationaryProjectionSourceCore> source;
  std::vector<StationaryMarkedEdgeAtomV1> atoms;
  std::vector<StationaryStateMassV1> left_marginal;
  std::vector<StationaryStateMassV1> right_marginal;
  std::vector<StationaryConditionalMarkedRowV1> conditional_rows;
  std::vector<StationaryEndpointRowV1> endpoint_rows;
  StationaryMarkedEdgeDiagnosticsV1 diagnostics;
  Digest256 projection_fingerprint;
};

struct PredictiveServiceAtomCore final {
  std::size_t temporal_atom_index;
  std::size_t target_ordinal;
  ReducedStateV1 stationary_left_state;
  ReducedStateV1 stationary_right_state;
  std::uint8_t target_departure;
  // The split is a rowwise continuation, not merely a stationary joint
  // measure. Retain both measures so a later FIFO consumer cannot confuse
  // pi(x)P_d(x,x') with P_d(x,x').
  ExactRational exact_left_mass;
  ExactRational exact_joint_mass;
  ExactRational exact_conditional_mass;
  CompletedReducedEdge raw_edge;
};

struct PredictiveServiceSplitCore final {
  std::shared_ptr<const StationaryProjectionSourceCore> source;
  std::vector<PredictiveServiceAtomCore> p0_atoms;
  std::vector<PredictiveServiceAtomCore> p1_atoms;
  Digest256 target_selection_identity;
  Digest256 target_service_schema_identity;
  Digest256 projection_fingerprint;
};

struct TemporalServiceKernelCore final {
  std::shared_ptr<const StationaryProjectionSourceCore> source;
  std::vector<PredictiveServiceAtomCore> chronological_service_atoms;
  Digest256 continuation_schema_identity;
  Digest256 target_selection_identity;
  Digest256 target_service_schema_identity;
  Digest256 projection_fingerprint;
};

}  // namespace mwperf::stationary::detail
