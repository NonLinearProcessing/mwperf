#pragma once

#include <cstddef>

#include "mwperf/stationary/suspension.hpp"

namespace mwperf::stationary::detail {

struct BoundedStationaryTemporalProjectionV1 final {
  StationaryTemporalProjection projection;
  std::size_t actual_state_count;
  std::size_t actual_maximum_row_atoms;
};

// C27-only bounded carrier. The public F-C21-04 contract remains unchanged;
// analysis-v1 uses this path to make the authored C03 representation grants
// hard construction limits and to retain those grants in C22 budget reports.
[[nodiscard]] Result<BoundedStationaryTemporalProjectionV1>
build_stationary_temporal_projection_bounded(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean, std::size_t maximum_states,
    std::size_t maximum_row_atoms);

}  // namespace mwperf::stationary::detail
