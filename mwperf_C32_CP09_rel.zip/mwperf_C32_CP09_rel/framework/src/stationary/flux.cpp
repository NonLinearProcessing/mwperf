#include "mwperf/stationary/flux.hpp"

#include <Eigen/Dense>

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <limits>
#include <locale>
#include <numeric>
#include <set>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>

#include "kernel/c17_core_internal.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "stationary/c18_stationary_quotient_internal.hpp"

namespace mwperf {

static_assert(std::is_signed_v<Eigen::Index> &&
                  std::numeric_limits<Eigen::Index>::digits >=
                      std::numeric_limits<std::ptrdiff_t>::digits,
              "the C27 pre-provider ptrdiff_t bound must fit Eigen::Index");

namespace stationary::detail {

struct EndpointRowCore final {
  std::vector<EndpointRowAtomV1> atoms;
  std::vector<MarkedFluxAtomV1> marked_atoms;
  ExactRational exact_total_mass;
  long double numerical_total_mass;
  long double numerical_residual_from_one;
};

struct CompletionBoundMarkedFluxCore final {
  BoundaryCompletionKindV1 completion_kind;
  std::optional<Digest256> completion_identity;
  bool physical_mark_preserving;
  std::vector<CompletionBoundMarkedRowV1> rows;
  std::vector<LeakageRecordV1> leakage;
  ExactRational exact_completed_mass;
};

enum class SelectionIdentityKind : std::uint8_t {
  unique,
  one_class,
  mixture,
};

struct SelectionIdentityComponent final {
  TypedLabel class_id;
  ExactRational exact_weight;

  friend bool operator==(const SelectionIdentityComponent&,
                         const SelectionIdentityComponent&) = default;
};

struct SelectionIdentity final {
  SelectionIdentityKind kind;
  std::vector<SelectionIdentityComponent> components;

  friend bool operator==(const SelectionIdentity&,
                         const SelectionIdentity&) = default;
};

struct ProductionBinding final {
  AuditedFrameworkBindingsV1 framework;
  TargetSelection target_selection;
  CompiledArrivalLaw configured_arrival;
  CodecIdentityV1 reduced_state_codec;
  ResolvedInstance instance;
};

struct FixtureBinding final {
  ResolvedInstance instance;
  TargetSelection target_selection;
  std::optional<CompiledArrivalLaw> configured_arrival;
  std::optional<FrameworkProblemFingerprintsV1> problem_fingerprints;
  std::optional<Digest256> problem_view_digest;
};

struct TransitionMatrixCore final {
  std::vector<ReducedStateV1> states;
  std::vector<ExactRational> exact_entries;
  std::vector<long double> numerical_entries;
  std::vector<std::uint8_t> exact_support;
  std::size_t nonzero_count;
  std::vector<MatrixRowDiagnosticV1> row_diagnostics;
  CompletionBoundMarkedFlux marked_flux;
  Digest256 matrix_identity;
  SelectionIdentity bound_selection;
  Digest256 bound_selector_digest;
  SolverPolicy bound_solver_policy;
  std::optional<ProductionBinding> production_binding;
  std::optional<FixtureBinding> fixture_binding;
  std::optional<Digest256> exact_state_schema_digest;
  std::optional<Digest256> reduced_state_schema_digest;
  std::vector<ArrivalPhaseIdentityV1> state_phases;
  std::vector<ArrivalPhaseIdentityV1> configured_phase_states;
  std::vector<ExactRational> configured_phase_masses;
  std::optional<std::vector<ExactRational>> configured_phase_kernel;
};

struct ClassDecompositionCore final {
  TransitionMatrix matrix;
  std::vector<CommunicatingClassV1> classes;
  std::vector<std::size_t> closed_class_indices;
  std::vector<std::size_t> transient_state_indices;
};

struct InvariantSelectionCore final {
  ClassDecomposition decomposition;
  std::vector<SelectedInvariantClassV1> selected_classes;
  Digest256 selector_digest;
};

struct InvariantLawCore final {
  TransitionMatrix matrix;
  std::vector<long double> masses;
  std::vector<SelectedInvariantClassV1> selected_classes;
  InvariantSolveDiagnosticsV1 diagnostics;
};

}  // namespace stationary::detail

namespace detail {

class C18CoreAccess final {
 public:
  C18CoreAccess() = delete;

  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  provider_core(const AuditedRowProvider& provider) {
    return provider.core_;
  }

  [[nodiscard]] static EndpointRow endpoint_row(
      std::shared_ptr<const stationary::detail::EndpointRowCore> core) {
    return EndpointRow(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::EndpointRowCore& core(
      const EndpointRow& row) {
    return *row.core_;
  }

  [[nodiscard]] static CompletionBoundMarkedFlux marked_flux(
      std::shared_ptr<const
          stationary::detail::CompletionBoundMarkedFluxCore> core) {
    return CompletionBoundMarkedFlux(std::move(core));
  }
  [[nodiscard]] static const
      stationary::detail::CompletionBoundMarkedFluxCore&
  core(const CompletionBoundMarkedFlux& flux) {
    return *flux.core_;
  }

  [[nodiscard]] static TransitionMatrix transition_matrix(
      std::shared_ptr<const stationary::detail::TransitionMatrixCore> core) {
    return TransitionMatrix(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::TransitionMatrixCore& core(
      const TransitionMatrix& matrix) {
    return *matrix.core_;
  }
  [[nodiscard]] static const void* carrier_identity(
      const TransitionMatrix& matrix) noexcept {
    return matrix.core_.get();
  }

  [[nodiscard]] static ClassDecomposition class_decomposition(
      std::shared_ptr<const stationary::detail::ClassDecompositionCore> core) {
    return ClassDecomposition(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::ClassDecompositionCore& core(
      const ClassDecomposition& decomposition) {
    return *decomposition.core_;
  }

  [[nodiscard]] static InvariantSelection invariant_selection(
      std::shared_ptr<const stationary::detail::InvariantSelectionCore> core) {
    return InvariantSelection(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::InvariantSelectionCore& core(
      const InvariantSelection& selection) {
    return *selection.core_;
  }

  [[nodiscard]] static InvariantLaw invariant_law(
      std::shared_ptr<const stationary::detail::InvariantLawCore> core) {
    return InvariantLaw(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::InvariantLawCore& core(
      const InvariantLaw& law) {
    return *law.core_;
  }
};

}  // namespace detail

namespace {

template <typename T>
[[nodiscard]] Result<T> fail(std::string code, std::string message,
                             std::vector<std::string> notes = {},
                             DiagnosticCategory category =
                                 DiagnosticCategory::input_validation) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

[[nodiscard]] Diagnostic finding(std::string code, std::string message,
                                 std::vector<std::string> notes = {},
                                 DiagnosticCategory category =
                                     DiagnosticCategory::input_validation) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::nullopt, std::move(notes)};
}

[[nodiscard]] std::string numerical_note_value(const long double value) {
  std::ostringstream output;
  output.imbue(std::locale::classic());
  output << std::scientific
         << std::setprecision(std::numeric_limits<long double>::max_digits10)
         << value;
  return output.str();
}

[[nodiscard]] ExactRational exact_probability_count_product(
    const ExactRational& probability, const BigNat& count) {
  // The denominator is already positive, so construction cannot fail.  Form
  // p*A exactly before taking the numerical image; separate images can turn a
  // finite product into 0*infinity.
  auto product = ExactRational::make(
      probability.numerator() * count.value(), probability.denominator());
  return std::move(product).value();
}

class CompensatedSum final {
 public:
  void add(const long double value) noexcept {
    const long double updated = sum_ + value;
    if (std::fabs(sum_) >= std::fabs(value)) {
      correction_ += (sum_ - updated) + value;
    } else {
      correction_ += (value - updated) + sum_;
    }
    sum_ = updated;
  }

  [[nodiscard]] long double value() const noexcept {
    return sum_ + correction_;
  }

 private:
  long double sum_{0.0L};
  long double correction_{0.0L};
};

[[nodiscard]] bool byte_span_less(const std::span<const std::byte> left,
                                  const std::span<const std::byte> right) {
  return std::lexicographical_compare(
      left.begin(), left.end(), right.begin(), right.end(),
      [](const std::byte a, const std::byte b) {
        return std::to_integer<unsigned int>(a) <
               std::to_integer<unsigned int>(b);
      });
}

[[nodiscard]] bool state_less(const ReducedStateV1& left,
                              const ReducedStateV1& right) {
  if (left.codec.id != right.codec.id) {
    return left.codec.id < right.codec.id;
  }
  if (left.codec.version != right.codec.version) {
    return left.codec.version < right.codec.version;
  }
  return byte_span_less(left.canonical_value, right.canonical_value);
}

[[nodiscard]] std::optional<std::size_t> state_index(
    const std::span<const ReducedStateV1> states,
    const ReducedStateV1& wanted) {
  const auto found = std::lower_bound(states.begin(), states.end(), wanted,
                                      state_less);
  if (found == states.end() || !(*found == wanted)) {
    return std::nullopt;
  }
  return static_cast<std::size_t>(found - states.begin());
}

[[nodiscard]] ArrivalPhaseIdentityV1 phase_identity(
    const ArrivalPhase& phase) {
  const auto bytes = arrival_phase_canonical_state(phase);
  return ArrivalPhaseIdentityV1{
      arrival_phase_family(phase),
      std::vector<std::byte>(bytes.begin(), bytes.end())};
}

[[nodiscard]] std::pair<long double, NumericalProbabilityImageStatusV1>
numerical_image(const ExactRational& value) {
  const long double image = value.to_long_double();
  if (!std::isfinite(image)) {
    return {image, NumericalProbabilityImageStatusV1::overflow};
  }
  if (value.is_positive() && image == 0.0L) {
    return {image, NumericalProbabilityImageStatusV1::positive_underflow};
  }
  return {image, NumericalProbabilityImageStatusV1::finite};
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

class IdentityEncoder final {
 public:
  void u64(std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(
          static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void byte(std::uint8_t value) { bytes_.push_back(std::byte{value}); }
  void framed(std::span<const std::byte> bytes) {
    u64(static_cast<std::uint64_t>(bytes.size()));
    bytes_.insert(bytes_.end(), bytes.begin(), bytes.end());
  }
  void text(const std::string& value) {
    framed(std::as_bytes(std::span(value.data(), value.size())));
  }
  void digest(const Digest256& value) { framed(value.bytes()); }
  void rational(const ExactRational& value) {
    text(value.numerator_decimal());
    text(value.denominator_decimal());
  }
  void label(const TypedLabel& value) {
    const auto bytes = value.canonical_bytes();
    framed(std::as_bytes(std::span(bytes.data(), bytes.size())));
  }
  template <StrongIdDomainName Domain>
  void id(const StrongId<Domain>& value) {
    const auto bytes = value.canonical_bytes();
    framed(std::as_bytes(std::span(bytes.data(), bytes.size())));
  }
  void state(const ReducedStateV1& value) {
    text(value.codec.id);
    u64(value.codec.version);
    framed(value.canonical_value);
  }
  void phase(const ArrivalPhaseIdentityV1& value) {
    byte(static_cast<std::uint8_t>(value.family));
    framed(value.canonical_state);
  }
  [[nodiscard]] Result<Digest256> finish(std::string_view domain) const {
    return sha256_domain_separated(domain, bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

void encode_marked_edge(IdentityEncoder& encoder,
                        const MarkedFluxEdgeV1& edge) {
  encoder.state(edge.pre_state);
  encoder.state(edge.successor_state);
  encoder.phase(edge.phase_before);
  encoder.phase(edge.phase_after);
  encoder.u64(edge.prearrival_target_backlog.size());
  for (const BigNat& value : edge.prearrival_target_backlog) {
    encoder.text(value.to_decimal_string());
  }
  encoder.u64(edge.target_departures.size());
  for (const std::uint8_t value : edge.target_departures) {
    encoder.byte(value);
  }
  encoder.u64(edge.target_arrivals.size());
  for (const BigNat& value : edge.target_arrivals) {
    encoder.text(value.to_decimal_string());
  }
  encoder.u64(edge.marks.size());
  for (const CausalMarkV1& mark : edge.marks) {
    encoder.id(mark.mark.mark);
    encoder.byte(static_cast<std::uint8_t>(mark.reveal_stage));
    encoder.text(mark.mark.value.codec.id);
    encoder.u64(mark.mark.value.codec.version);
    encoder.framed(mark.mark.value.canonical_value);
  }
}

[[nodiscard]] std::string marked_edge_sort_key(
    const std::optional<MarkedFluxEdgeV1>& edge) {
  if (!edge.has_value()) {
    return {};
  }
  IdentityEncoder encoder;
  encode_marked_edge(encoder, *edge);
  auto digest = encoder.finish("mwperf.c18.marked_edge.sort.v1");
  return digest ? digest.value().hex() : std::string{};
}

[[nodiscard]] std::string canonical_state_note(
    const ReducedStateV1& state) {
  static constexpr char hex[] = "0123456789abcdef";
  std::string value;
  value.reserve(state.canonical_value.size() * 2U);
  for (const std::byte byte : state.canonical_value) {
    const auto integer = std::to_integer<unsigned int>(byte);
    value.push_back(hex[(integer >> 4U) & 0x0fU]);
    value.push_back(hex[integer & 0x0fU]);
  }
  return state.codec.id + ":v" + std::to_string(state.codec.version) + ":" +
         value;
}

[[nodiscard]] Result<stationary::detail::SelectionIdentity>
selection_identity(const SelectionSpec& selection) {
  using Kind = stationary::detail::SelectionIdentityKind;
  using Component = stationary::detail::SelectionIdentityComponent;
  if (std::holds_alternative<StationaryUniqueSelection>(selection)) {
    return Result<stationary::detail::SelectionIdentity>::success(
        {Kind::unique, {}});
  }
  if (const auto* one =
          std::get_if<StationaryClassSelection>(&selection)) {
    return Result<stationary::detail::SelectionIdentity>::success(
        {Kind::one_class,
         {Component{one->class_id, ExactRational::one()}}});
  }
  const auto* mixture =
      std::get_if<StationaryMixtureSelection>(&selection);
  if (mixture == nullptr || mixture->components.empty()) {
    return fail<stationary::detail::SelectionIdentity>(
        "c18.stationary_selection_required",
        "the finite invariant backend requires a stationary selection");
  }

  ExactRational total = ExactRational::zero();
  for (std::size_t i = 0; i < mixture->components.size(); ++i) {
    const auto& component = mixture->components[i];
    const ExactRational& weight = component.probability.exact_value();
    if (!weight.is_nonnegative()) {
      return fail<stationary::detail::SelectionIdentity>(
          "c18.negative_mixture_weight",
          "stationary mixture weights must be nonnegative",
          {"component " + std::to_string(i)});
    }
    for (std::size_t j = 0; j < i; ++j) {
      if (mixture->components[j].class_id == component.class_id) {
        return fail<stationary::detail::SelectionIdentity>(
            "c18.duplicate_mixture_class",
            "a stationary mixture may name each class at most once");
      }
    }
    total = total + weight;
  }
  if (!total.is_positive()) {
    return fail<stationary::detail::SelectionIdentity>(
        "c18.nonpositive_mixture_total",
        "stationary mixture weights require a positive exact total");
  }
  std::vector<Component> normalized;
  normalized.reserve(mixture->components.size());
  for (const auto& component : mixture->components) {
    auto divided = checked_divide(component.probability.exact_value(), total);
    if (!divided) {
      return Result<stationary::detail::SelectionIdentity>::failure(
          divided.error());
    }
    normalized.push_back(
        Component{component.class_id, std::move(divided).value()});
  }
  return Result<stationary::detail::SelectionIdentity>::success(
      {Kind::mixture, std::move(normalized)});
}

[[nodiscard]] Result<Digest256> selector_digest(
    const stationary::detail::SelectionIdentity& selection) {
  IdentityEncoder encoder;
  encoder.byte(static_cast<std::uint8_t>(selection.kind));
  encoder.u64(selection.components.size());
  for (const auto& component : selection.components) {
    encoder.label(component.class_id);
    encoder.rational(component.exact_weight);
  }
  return encoder.finish("mwperf.c18.invariant_selector.v1");
}

[[nodiscard]] Result<SolverPolicy> solver_policy(
    const ResolvedInstance& instance) {
  if (!instance.analysis_spec().context) {
    return fail<SolverPolicy>("c18.analysis_context_missing",
                              "the resolved analysis has no context");
  }
  const AnalysisContext& context = *instance.analysis_spec().context;
  const auto* enumerated = std::get_if<EnumeratedSolver>(&context.solver);
  if (enumerated == nullptr) {
    return fail<SolverPolicy>(
        "c18.enumerated_solver_required",
        "the finite stationary matrix requires an enumerated solver");
  }
  if (!context.resolution.tolerance.linear_residual_abs.has_value()) {
    return fail<SolverPolicy>(
        "c18.linear_residual_tolerance_required",
        "Analysis-v1 must declare linear_residual_abs for a stationary solve");
  }
  const ExactRational& absolute =
      *context.resolution.tolerance.linear_residual_abs;
  if (!absolute.is_nonnegative()) {
    return fail<SolverPolicy>("c18.negative_solver_tolerance",
                              "the linear residual tolerance is negative");
  }
  return Result<SolverPolicy>::success(SolverPolicy{
      enumerated->linear_method, enumerated->max_iterations, absolute,
      ExactRational::zero(), instance.fingerprints().analysis});
}

[[nodiscard]] Result<void> validate_policy(const SolverPolicy& policy) {
  if (!policy.absolute_residual_tolerance.is_nonnegative() ||
      !policy.relative_residual_tolerance.is_zero() ||
      !nonzero_digest(policy.analysis_fingerprint)) {
    return fail<void>(
        "c18.invalid_solver_policy",
        "the C18 Analysis-v1 policy requires nonnegative absolute tolerance, "
        "exactly zero relative tolerance, and its analysis fingerprint");
  }
  const long double absolute =
      policy.absolute_residual_tolerance.to_long_double();
  if (!std::isfinite(absolute) || absolute < 0.0L) {
    return fail<void>("c18.unusable_solver_tolerance",
                      "the solver tolerance has no finite numerical image");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<MarkedFluxEdgeV1> project_edge(
    const CompletedReducedEdge& edge) {
  if (!edge.opportunity().prearrival_backlog.has_value()) {
    return fail<MarkedFluxEdgeV1>(
        "c18.prearrival_backlog_missing",
        "a marked stationary edge must retain its exact prearrival backlog");
  }
  const TargetBacklogV1& backlog =
      *edge.opportunity().prearrival_backlog;
  if (edge.action().actual_departure.size() == 0U) {
    return fail<MarkedFluxEdgeV1>(
        "c18.departure_vector_missing",
        "a marked stationary edge must retain its actual departure vector");
  }

  std::vector<BigNat> values(backlog.values().begin(), backlog.values().end());
  std::vector<std::uint8_t> departures;
  std::vector<BigNat> arrivals;
  departures.reserve(backlog.size());
  arrivals.reserve(backlog.size());
  for (std::size_t target = 0; target < backlog.size(); ++target) {
    const std::size_t physical =
        backlog.target_at_target_ordinal(target).ordinal();
    const std::uint8_t departure =
        edge.action().actual_departure.bytes()[physical];
    departures.push_back(departure);
    BigNat arrival(0U);
    for (const ArrivalBatchEntry& entry : edge.arrival().batch.entries()) {
      if (entry.queue.ordinal() == physical) {
        arrival = entry.count;
        break;
      }
    }
    arrivals.push_back(std::move(arrival));
    auto after_departure = checked_subtract(
        backlog.value_at_target_ordinal(target), BigNat(departure));
    if (!after_departure) {
      return fail<MarkedFluxEdgeV1>(
          "c18.departure_exceeds_backlog",
          "a marked edge has D greater than its exact prearrival backlog",
          {"target " + std::to_string(target)});
    }
  }
  return Result<MarkedFluxEdgeV1>::success(MarkedFluxEdgeV1{
      edge.pre_state(), edge.successor_state(), std::move(values),
      std::move(departures), std::move(arrivals),
      phase_identity(edge.arrival().phase_before),
      phase_identity(edge.arrival().phase_after),
      std::vector<CausalMarkV1>(edge.marks().begin(), edge.marks().end())});
}

[[nodiscard]] Result<void> validate_marked_edge(
    const MarkedFluxEdgeV1& edge, const ReducedStateV1& expected_pre_state,
    const ExactReducedStateSchemaV1& schema) {
  if (!(edge.pre_state == expected_pre_state)) {
    return fail<void>("c18.marked_edge_prestate_mismatch",
                      "a marked row atom has a foreign predecision state");
  }
  auto decoded_pre = schema.decode(edge.pre_state);
  if (!decoded_pre) {
    return Result<void>::failure(decoded_pre.error());
  }
  auto decoded_successor = schema.decode(edge.successor_state);
  if (!decoded_successor) {
    return Result<void>::failure(decoded_successor.error());
  }
  const ExactReducedCoordinatesV1& pre = decoded_pre.value();
  const ExactReducedCoordinatesV1& successor = decoded_successor.value();
  if (!(phase_identity(pre.arrival_phase) == edge.phase_before) ||
      !(phase_identity(successor.arrival_phase) == edge.phase_after)) {
    return fail<void>(
        "c18.arrival_phase_endpoint_mismatch",
        "the marked phase transition does not match the decoded state phases");
  }
  if (edge.prearrival_target_backlog.size() != pre.backlog.size() ||
      edge.target_departures.size() != pre.backlog.size() ||
      edge.target_arrivals.size() != pre.backlog.size() ||
      successor.backlog.size() != pre.backlog.size()) {
    return fail<void>("c18.marked_edge_target_dimension_mismatch",
                      "the marked edge target vectors have different sizes");
  }
  for (std::size_t target = 0; target < pre.backlog.size(); ++target) {
    if (!(edge.prearrival_target_backlog[target] ==
          pre.backlog.value_at_target_ordinal(target)) ||
        edge.target_departures[target] > 1U) {
      return fail<void>(
          "c18.marked_edge_prestate_coordinate_mismatch",
          "the marked n or D coordinate differs from the decoded state",
          {"target " + std::to_string(target)});
    }
    auto after_departure = checked_subtract(
        edge.prearrival_target_backlog[target],
        BigNat(edge.target_departures[target]));
    if (!after_departure) {
      return fail<void>("c18.departure_exceeds_backlog",
                        "a marked edge has D greater than n");
    }
    const BigNat endpoint =
        std::move(after_departure).value() + edge.target_arrivals[target];
    if (!(endpoint == successor.backlog.value_at_target_ordinal(target))) {
      return fail<void>(
          "c18.mark_to_endpoint_mismatch",
          "the stored successor differs from exact n-D+A",
          {"target " + std::to_string(target)});
    }
  }
  return Result<void>::success();
}

[[nodiscard]] long double residual_bound(const SolverPolicy& policy,
                                         const long double scale) {
  return policy.absolute_residual_tolerance.to_long_double() +
         policy.relative_residual_tolerance.to_long_double() * scale;
}

[[nodiscard]] Result<Digest256> matrix_identity(
    const stationary::detail::TransitionMatrixCore& matrix) {
  IdentityEncoder encoder;
  encoder.u64(matrix.states.size());
  for (const ReducedStateV1& state : matrix.states) {
    encoder.state(state);
  }
  for (const ExactRational& entry : matrix.exact_entries) {
    encoder.rational(entry);
  }
  const auto& flux = detail::C18CoreAccess::core(matrix.marked_flux);
  encoder.byte(static_cast<std::uint8_t>(flux.completion_kind));
  encoder.byte(flux.physical_mark_preserving ? 1U : 0U);
  encoder.byte(flux.completion_identity.has_value() ? 1U : 0U);
  if (flux.completion_identity) {
    encoder.digest(*flux.completion_identity);
  }
  encoder.rational(flux.exact_completed_mass);
  encoder.u64(flux.leakage.size());
  for (const LeakageRecordV1& record : flux.leakage) {
    encoder.u64(record.source_index);
    encoder.state(record.original_successor);
    encoder.rational(record.exact_mass);
    encoder.byte(record.original_edge.has_value() ? 1U : 0U);
    if (record.original_edge) {
      encode_marked_edge(encoder, *record.original_edge);
    }
  }
  for (const auto& row : flux.rows) {
    encoder.u64(row.atoms.size());
    for (const auto& atom : row.atoms) {
      encoder.u64(atom.successor_index);
      encoder.rational(atom.exact_mass);
      encoder.byte(atom.completed_from_leakage ? 1U : 0U);
      encoder.byte(atom.edge.has_value() ? 1U : 0U);
      if (!atom.edge) {
        continue;
      }
      encode_marked_edge(encoder, *atom.edge);
    }
  }
  encoder.digest(matrix.bound_selector_digest);
  encoder.byte(static_cast<std::uint8_t>(matrix.bound_solver_policy.linear_method));
  encoder.rational(matrix.bound_solver_policy.absolute_residual_tolerance);
  encoder.rational(matrix.bound_solver_policy.relative_residual_tolerance);
  encoder.digest(matrix.bound_solver_policy.analysis_fingerprint);
  encoder.byte(matrix.bound_solver_policy.max_iterations.has_value() ? 1U :
                                                                    0U);
  if (matrix.bound_solver_policy.max_iterations) {
    encoder.text(matrix.bound_solver_policy.max_iterations->to_decimal_string());
  }
  encoder.byte(matrix.exact_state_schema_digest.has_value() ? 1U : 0U);
  if (matrix.exact_state_schema_digest) {
    encoder.digest(*matrix.exact_state_schema_digest);
  }
  encoder.byte(matrix.reduced_state_schema_digest.has_value() ? 1U : 0U);
  if (matrix.reduced_state_schema_digest) {
    encoder.digest(*matrix.reduced_state_schema_digest);
  }
  encoder.u64(matrix.state_phases.size());
  for (const ArrivalPhaseIdentityV1& phase : matrix.state_phases) {
    encoder.phase(phase);
  }
  encoder.u64(matrix.configured_phase_states.size());
  for (std::size_t phase = 0; phase < matrix.configured_phase_states.size();
       ++phase) {
    encoder.phase(matrix.configured_phase_states[phase]);
    encoder.rational(matrix.configured_phase_masses[phase]);
  }
  encoder.byte(matrix.configured_phase_kernel.has_value() ? 1U : 0U);
  if (matrix.configured_phase_kernel) {
    encoder.u64(matrix.configured_phase_kernel->size());
    for (const ExactRational& mass : *matrix.configured_phase_kernel) {
      encoder.rational(mass);
    }
  }
  encoder.byte(matrix.production_binding.has_value() ? 1U : 0U);
  if (matrix.production_binding) {
    const AuditedFrameworkBindingsV1& binding =
        matrix.production_binding->framework;
    encoder.digest(binding.problem_fingerprints.authored_inputs.model);
    encoder.digest(binding.problem_fingerprints.authored_inputs.analysis);
    encoder.digest(binding.problem_fingerprints.authored_inputs.combined);
    encoder.digest(binding.problem_fingerprints.resolved_instance);
    encoder.digest(binding.problem_fingerprints.constraint);
    encoder.digest(binding.problem_fingerprints.target_selection);
    encoder.digest(binding.problem_fingerprints.tie_and_timing);
    encoder.digest(binding.problem_fingerprints.compiled_arrival);
    encoder.digest(binding.problem_view_digest.value());
    encoder.digest(binding.exact_state_schema_digest);
    encoder.digest(binding.reduced_state_schema_digest);
    encoder.digest(binding.descriptor_digest);
    encoder.digest(binding.access_digest);
    encoder.digest(binding.accepted_contract_digest);
    encoder.digest(binding.normalized_metric_requirements_digest);
    encoder.digest(binding.ordered_target_digest);
    encoder.digest(binding.selection_digest);
    encoder.digest(binding.build_request_digest);
    encoder.u64(matrix.production_binding->target_selection.ordered_targets.size());
    for (const QueueId& target :
         matrix.production_binding->target_selection.ordered_targets) {
      encoder.id(target);
    }
    encoder.id(matrix.production_binding->target_selection
                   .construction_group_binding);
  }
  encoder.byte(matrix.fixture_binding.has_value() ? 1U : 0U);
  if (matrix.fixture_binding) {
    const auto& binding = *matrix.fixture_binding;
    encoder.digest(binding.instance.fingerprints().model);
    encoder.digest(binding.instance.fingerprints().analysis);
    encoder.digest(binding.instance.fingerprints().combined);
    encoder.byte(static_cast<std::uint8_t>(binding.instance.timing()));
    encoder.u64(binding.target_selection.schema_version);
    encoder.u64(binding.target_selection.ordered_targets.size());
    for (const QueueId& target :
         binding.target_selection.ordered_targets) {
      encoder.id(target);
    }
    encoder.id(binding.target_selection.construction_group_binding);
    encoder.byte(binding.configured_arrival.has_value() ? 1U : 0U);
    if (binding.configured_arrival) {
      const BuilderArrivalView arrival =
          builder_arrival_view(*binding.configured_arrival);
      encoder.byte(static_cast<std::uint8_t>(arrival.binding().family));
      encoder.byte(static_cast<std::uint8_t>(arrival.binding().timing));
      encoder.u64(arrival.binding().queue_cardinality);
      encoder.digest(arrival.binding().law_digest.value());
      encoder.digest(arrival.binding().catalog_digest.value());
      encoder.digest(arrival.digest().value());
    }
    encoder.byte(binding.problem_view_digest.has_value() ? 1U : 0U);
    if (binding.problem_view_digest) {
      encoder.digest(*binding.problem_view_digest);
    }
  }
  return encoder.finish("mwperf.c18.transition_matrix.v1");
}

[[nodiscard]] Result<void> validate_boundary_shape(
    const BoundaryRule& boundary) {
  if (boundary.kind == BoundaryCompletionKindV1::exact_closed) {
    if (boundary.apply || !boundary.physical_mark_preserving) {
      return fail<void>(
          "c18.invalid_exact_closed_boundary",
          "an exact-closed rule has no completion callback and is the "
          "original physical marked row law");
    }
    return Result<void>::success();
  }
  if (!boundary.completion_identity.has_value() ||
      !nonzero_digest(*boundary.completion_identity) || !boundary.apply) {
    return fail<void>(
        "c18.incomplete_boundary_rule",
        "a computational completion requires an identity and exact map");
  }
  if (boundary.kind == BoundaryCompletionKindV1::state_only_completion &&
      boundary.physical_mark_preserving) {
    return fail<void>(
        "c18.state_only_completion_not_mark_preserving",
        "a state-only completion cannot claim physical-mark preservation");
  }
  return Result<void>::success();
}

[[nodiscard]] bool same_stationary_quotient_margin(
    const PairMargin& left, const PairMargin& right) {
  return left.pair() == right.pair() &&
         left.evaluation_backlog() == right.evaluation_backlog() &&
         left.opportunity_certificate_digest() ==
             right.opportunity_certificate_digest() &&
         left.old_pair_linear_coordinate() ==
             right.old_pair_linear_coordinate() &&
         left.reoptimized_margin() == right.reoptimized_margin() &&
         left.fixed_out_objective() == right.fixed_out_objective() &&
         left.fixed_in_objective() == right.fixed_in_objective() &&
         left.regret0() == right.regret0() &&
         left.regret1() == right.regret1() &&
         left.forced_out_valid() == right.forced_out_valid() &&
         left.forced_in_valid() == right.forced_in_valid() &&
         left.pair_valid() == right.pair_valid() &&
         left.target_eligible() == right.target_eligible() &&
         left.representative_selection() ==
             right.representative_selection();
}

[[nodiscard]] bool same_stationary_quotient_unresolved(
    const std::span<const RuntimeFieldPatchV1> left,
    const std::span<const RuntimeFieldPatchV1> right) {
  if (left.size() != right.size()) return false;
  for (std::size_t index = 0U; index < left.size(); ++index) {
    if (std::ranges::find_if(
            left.begin(), left.begin() + index,
            [&](const RuntimeFieldPatchV1& prior) {
              return prior.field == left[index].field;
            }) != left.begin() + index) {
      return false;
    }
    const auto found = std::ranges::find_if(
        right, [&](const RuntimeFieldPatchV1& candidate) {
          return candidate.field == left[index].field;
        });
    if (found == right.end() || found->value != left[index].value) {
      return false;
    }
  }
  for (std::size_t index = 0U; index < right.size(); ++index) {
    if (std::ranges::find_if(
            right.begin(), right.begin() + index,
            [&](const RuntimeFieldPatchV1& prior) {
              return prior.field == right[index].field;
            }) != right.begin() + index) {
      return false;
    }
  }
  return true;
}

// Equality in the stationary state quotient erases only the physical slot.
// Predictive phase, backlog, controller, resources, margins, and every
// surrogate-owned coordinate remain exact.
[[nodiscard]] bool same_stationary_quotient_coordinates(
    const ExactReducedCoordinatesV1& left,
    const ExactReducedCoordinatesV1& right) {
  return left.backlog == right.backlog &&
         phase_identity(left.arrival_phase) ==
             phase_identity(right.arrival_phase) &&
         left.resources == right.resources &&
         left.margins.size() == right.margins.size() &&
         std::equal(left.margins.begin(), left.margins.end(),
                    right.margins.begin(),
                    same_stationary_quotient_margin) &&
         left.controller == right.controller &&
         same_stationary_quotient_unresolved(left.unresolved_fields,
                                              right.unresolved_fields);
}

}  // namespace

std::span<const EndpointRowAtomV1> EndpointRow::atoms() const noexcept {
  return core_->atoms;
}
std::span<const MarkedFluxAtomV1> EndpointRow::marked_atoms() const noexcept {
  return core_->marked_atoms;
}
const ExactRational& EndpointRow::exact_total_mass() const noexcept {
  return core_->exact_total_mass;
}
long double EndpointRow::numerical_total_mass() const noexcept {
  return core_->numerical_total_mass;
}
long double EndpointRow::numerical_residual_from_one() const noexcept {
  return core_->numerical_residual_from_one;
}

BoundaryCompletionKindV1 CompletionBoundMarkedFlux::completion_kind() const
    noexcept {
  return core_->completion_kind;
}
const std::optional<Digest256>& CompletionBoundMarkedFlux::completion_identity()
    const noexcept {
  return core_->completion_identity;
}
bool CompletionBoundMarkedFlux::physical_mark_preserving() const noexcept {
  return core_->physical_mark_preserving;
}
std::span<const CompletionBoundMarkedRowV1>
CompletionBoundMarkedFlux::rows() const noexcept {
  return core_->rows;
}
std::span<const LeakageRecordV1> CompletionBoundMarkedFlux::leakage() const
    noexcept {
  return core_->leakage;
}
const ExactRational& CompletionBoundMarkedFlux::exact_completed_mass() const
    noexcept {
  return core_->exact_completed_mass;
}

std::size_t TransitionMatrix::size() const noexcept {
  return core_->states.size();
}
std::span<const ReducedStateV1> TransitionMatrix::states() const noexcept {
  return core_->states;
}
const ExactRational& TransitionMatrix::exact_entry(
    const std::size_t row, const std::size_t column) const {
  return core_->exact_entries.at(row * size() + column);
}
long double TransitionMatrix::numerical_entry(
    const std::size_t row, const std::size_t column) const {
  return core_->numerical_entries.at(row * size() + column);
}
bool TransitionMatrix::exact_positive_support(
    const std::size_t row, const std::size_t column) const {
  return core_->exact_support.at(row * size() + column) != 0U;
}
std::size_t TransitionMatrix::nonzero_count() const noexcept {
  return core_->nonzero_count;
}
std::span<const MatrixRowDiagnosticV1> TransitionMatrix::row_diagnostics()
    const noexcept {
  return core_->row_diagnostics;
}
const CompletionBoundMarkedFlux& TransitionMatrix::marked_flux() const
    noexcept {
  return core_->marked_flux;
}
const Digest256& TransitionMatrix::matrix_identity() const noexcept {
  return core_->matrix_identity;
}
const SolverPolicy& TransitionMatrix::bound_solver_policy() const noexcept {
  return core_->bound_solver_policy;
}

std::span<const CommunicatingClassV1> ClassDecomposition::classes() const
    noexcept {
  return core_->classes;
}
std::span<const std::size_t> ClassDecomposition::closed_class_indices() const
    noexcept {
  return core_->closed_class_indices;
}
std::span<const std::size_t> ClassDecomposition::transient_state_indices()
    const noexcept {
  return core_->transient_state_indices;
}
const Digest256& ClassDecomposition::matrix_identity() const noexcept {
  return core_->matrix.matrix_identity();
}

std::span<const SelectedInvariantClassV1>
InvariantSelection::selected_classes() const noexcept {
  return core_->selected_classes;
}
const Digest256& InvariantSelection::matrix_identity() const noexcept {
  return core_->decomposition.matrix_identity();
}
const Digest256& InvariantSelection::selector_digest() const noexcept {
  return core_->selector_digest;
}

std::span<const long double> InvariantLaw::masses() const noexcept {
  return core_->masses;
}
std::span<const SelectedInvariantClassV1> InvariantLaw::selected_classes()
    const noexcept {
  return core_->selected_classes;
}
const InvariantSolveDiagnosticsV1& InvariantLaw::solve_diagnostics() const
    noexcept {
  return core_->diagnostics;
}
const TransitionMatrix& InvariantLaw::transition_matrix() const noexcept {
  return core_->matrix;
}
const CompletionBoundMarkedFlux& InvariantLaw::marked_flux() const noexcept {
  return core_->matrix.marked_flux();
}
const Digest256& InvariantLaw::matrix_identity() const noexcept {
  return core_->matrix.matrix_identity();
}

Result<EndpointRow> project_marked_row_to_endpoint(
    const MarkedKernelRow& row) {
  if (!(row.exact_total_mass() == ExactRational::one())) {
    return fail<EndpointRow>(
        "c18.marked_row_mass_not_one",
        "the exact C17 marked row must total exactly one",
        {"exact total " + row.exact_total_mass().to_canonical_string()});
  }
  if (row.atoms().empty()) {
    return fail<EndpointRow>("c18.empty_marked_row",
                             "an exact unit row cannot be empty");
  }

  std::vector<MarkedFluxAtomV1> marked;
  marked.reserve(row.atoms().size());
  std::vector<EndpointRowAtomV1> endpoints;
  ExactRational total = ExactRational::zero();
  std::optional<ReducedStateV1> common_pre_state;
  for (std::size_t index = 0; index < row.atoms().size(); ++index) {
    const MarkedKernelRowAtomV1& atom = row.atoms()[index];
    if (!atom.exact_mass.is_nonnegative() ||
        atom.exact_mass > ExactRational::one() ||
        (atom.structural_support && atom.exact_mass.is_zero()) ||
        !std::isfinite(atom.numerical_image) || atom.numerical_image < 0.0L ||
        atom.numerical_image_status ==
            NumericalProbabilityImageStatusV1::overflow) {
      return fail<EndpointRow>(
          "c18.invalid_marked_row_atom",
          "a C17 marked atom has invalid exact/support/numerical mass data",
          {"atom " + std::to_string(index)});
    }
    auto projected = project_edge(atom.edge);
    if (!projected) {
      return Result<EndpointRow>::failure(projected.error());
    }
    if (!common_pre_state) {
      common_pre_state = projected.value().pre_state;
    } else if (!(*common_pre_state == projected.value().pre_state)) {
      return fail<EndpointRow>(
          "c18.mixed_marked_row_prestates",
          "all atoms in one marked row must have one exact predecision state");
    }
    const auto image = numerical_image(atom.exact_mass);
    if (image.second == NumericalProbabilityImageStatusV1::overflow) {
      return fail<EndpointRow>(
          "c18.nonfinite_exact_mass_image",
          "an exact marked mass has no finite long-double image");
    }
    marked.push_back(MarkedFluxAtomV1{
        std::move(projected).value(), atom.exact_mass,
        atom.structural_support, image.first, image.second});
    total = total + atom.exact_mass;

    auto existing = std::find_if(
        endpoints.begin(), endpoints.end(), [&](const EndpointRowAtomV1& item) {
          return item.successor_state == atom.edge.successor_state();
        });
    if (existing == endpoints.end()) {
      endpoints.push_back(EndpointRowAtomV1{
          atom.edge.successor_state(), atom.exact_mass,
          atom.exact_mass.is_positive(), 0.0L,
          NumericalProbabilityImageStatusV1::finite});
    } else {
      existing->exact_mass = existing->exact_mass + atom.exact_mass;
      existing->exact_positive_support = existing->exact_mass.is_positive();
    }
  }
  if (!(total == ExactRational::one())) {
    return fail<EndpointRow>(
        "c18.marked_atom_total_mismatch",
        "the marked atom masses disagree with the exact unit row total");
  }

  std::sort(endpoints.begin(), endpoints.end(),
            [](const EndpointRowAtomV1& left,
               const EndpointRowAtomV1& right) {
              return state_less(left.successor_state, right.successor_state);
            });
  CompensatedSum numerical_total;
  for (EndpointRowAtomV1& endpoint : endpoints) {
    const auto image = numerical_image(endpoint.exact_mass);
    if (image.second == NumericalProbabilityImageStatusV1::overflow) {
      return fail<EndpointRow>(
          "c18.nonfinite_endpoint_mass_image",
          "an exact endpoint mass has no finite long-double image");
    }
    endpoint.numerical_image = image.first;
    endpoint.numerical_image_status = image.second;
    numerical_total.add(image.first);
  }
  const long double image_total = numerical_total.value();
  if (!std::isfinite(image_total)) {
    return fail<EndpointRow>("c18.nonfinite_endpoint_row_image",
                             "the endpoint row image is nonfinite");
  }
  auto core = std::make_shared<stationary::detail::EndpointRowCore>(
      stationary::detail::EndpointRowCore{
          std::move(endpoints), std::move(marked), std::move(total),
          image_total, image_total - 1.0L});
  return Result<EndpointRow>::success(
      detail::C18CoreAccess::endpoint_row(std::move(core)));
}

namespace {

[[nodiscard]] Result<BoundaryRule>
certify_stationary_time_homogeneous_quotient_boundary(
    const StateDomain& domain, const AuditedRowProvider& provider) {
  auto sealed = detail::C18CoreAccess::provider_core(provider);
  if (!sealed || !sealed->report().passed() || !sealed->row_available()) {
    return fail<BoundaryRule>(
        "c18.audited_row_provider_unavailable",
        "the stationary clock quotient requires the passing C17 V0-sealed row view",
        {}, DiagnosticCategory::unavailable);
  }
  const CompiledFrameworkCandidateInputsV1& inputs = sealed->inputs();
  const auto arrival =
      detail::ArrivalCoreAccess::law_core(inputs.configured_arrival);
  const ArrivalCapabilities& capabilities =
      inputs.accepted_contract.arrival_capabilities();
  const bool finite_or_sparse =
      std::holds_alternative<FiniteEnumeratedRowAccess>(sealed->access()) ||
      std::holds_alternative<SparseRowAccess>(sealed->access());
  const bool accepted_scalar_route = std::ranges::any_of(
      inputs.accepted_contract.metric_contracts(),
      [&](const ResolvedMetricContractV1& contract) {
        return contract.semantic == sealed->descriptor().core.semantic &&
               contract.runtime_access ==
                   sealed->descriptor().core.runtime_access &&
               contract.target_coupling ==
                   sealed->descriptor().core.target_coupling &&
               contract.backend_route ==
                   BackendRouteKindV1::framework_scalar_identity;
      });
  const bool finite_phase =
      arrival && arrival->builder_view.finite_phase().has_value() &&
      arrival->builder_view.transition_rows().has_value() &&
      arrival->builder_view.finite_phase()->row_clock_semantics ==
          ArrivalRowClockSemanticsV1::finite_phase_time_homogeneous;
  if (inputs.causal_program.event_clock_semantics !=
          EventClockSemanticsV1::finite_phase_time_homogeneous_quotient ||
      sealed->descriptor().core.semantic !=
          SemanticTagV1::stationary_marked_edge ||
      !accepted_scalar_route || !finite_or_sparse || !finite_phase ||
      !arrival->runtime.enumerate_time_homogeneous ||
      capabilities.finite_enumerated_predictive_phase !=
          CapabilityAvailability::available ||
      capabilities.finite_enumerated_transition_row !=
          CapabilityAvailability::available ||
      !arrival->builder_view.stationary_phase_law().has_value() ||
      capabilities.stationary_phase_law ==
          StationaryPhaseLawStatus::unavailable) {
    return fail<BoundaryRule>(
        "c18.stationary_time_homogeneous_quotient_unavailable",
        "erasing the physical slot requires C17's clock-erased stationary marked-edge scalar authority, a finite/sparse V0 row, exact finite predictive-phase transition rows, a proper stationary phase law, and C09's slot-free time-homogeneous enumerator");
  }
  if (domain.states.empty()) {
    return fail<BoundaryRule>(
        "c18.empty_stationary_quotient_domain",
        "the stationary clock quotient requires a nonempty finite canonical domain");
  }

  std::vector<ReducedStateV1> representatives = domain.states;
  std::ranges::sort(representatives, state_less);
  std::vector<ExactReducedCoordinatesV1> coordinates;
  coordinates.reserve(representatives.size());
  const auto& enumerated_phases =
      arrival->builder_view.finite_phase()->canonical_states;
  for (std::size_t index = 0U; index < representatives.size(); ++index) {
    if (index != 0U && representatives[index] == representatives[index - 1U]) {
      return fail<BoundaryRule>(
          "c18.duplicate_stationary_quotient_state",
          "the stationary clock quotient domain contains a duplicate canonical state");
    }
    auto valid =
        inputs.exact_state_schema.validate_domain(representatives[index]);
    if (!valid) return Result<BoundaryRule>::failure(valid.error());
    auto decoded = inputs.exact_state_schema.decode(representatives[index]);
    if (!decoded) return Result<BoundaryRule>::failure(decoded.error());
    const auto phase = detail::ArrivalCoreAccess::phase_core(
        decoded.value().arrival_phase);
    if (!decoded.value().boundary_index.is_zero() || !phase ||
        !phase->next_authored_slot.is_zero() ||
        phase->binding != arrival->binding ||
        std::ranges::find(enumerated_phases, phase->canonical_state) ==
            enumerated_phases.end()) {
      return fail<BoundaryRule>(
          "c18.noncanonical_stationary_quotient_state",
          "every finite stationary representative must retain the configured predictive phase at physical slot zero");
    }
    if (std::ranges::any_of(
            coordinates, [&](const ExactReducedCoordinatesV1& prior) {
              return same_stationary_quotient_coordinates(
                  prior, decoded.value());
            })) {
      return fail<BoundaryRule>(
          "c18.duplicate_stationary_quotient_class",
          "two finite stationary representatives differ only in the erased physical clock");
    }
    coordinates.push_back(std::move(decoded).value());
  }

  IdentityEncoder identity;
  identity.digest(sealed->execution_seal_digest());
  identity.digest(inputs.exact_state_schema.exact_state_schema_digest);
  identity.digest(inputs.exact_state_schema.reduced_state_schema_digest);
  identity.digest(arrival->binding.law_digest.value());
  identity.u64(representatives.size());
  for (const ReducedStateV1& state : representatives) identity.state(state);
  auto completion_identity = identity.finish(
      "mwperf.c18.stationary-time-homogeneous-quotient.v1");
  if (!completion_identity) {
    return Result<BoundaryRule>::failure(completion_identity.error());
  }

  const ExactReducedStateSchemaV1 schema = inputs.exact_state_schema;
  const ArrivalBinding arrival_binding = arrival->binding;
  ApplyBoundaryCompletionV1 apply =
      [schema, arrival_binding,
       representatives = std::move(representatives),
       coordinates = std::move(coordinates)](
          const MarkedFluxAtomV1& leaking)
      -> Result<std::vector<BoundaryCompletionAtomV1>> {
    auto successor = schema.decode(leaking.edge.successor_state);
    if (!successor) {
      return Result<std::vector<BoundaryCompletionAtomV1>>::failure(
          successor.error());
    }
    const auto phase = detail::ArrivalCoreAccess::phase_core(
        successor.value().arrival_phase);
    if (!(successor.value().boundary_index == BigNat{1U}) || !phase ||
        phase->binding != arrival_binding ||
        !(phase->next_authored_slot == BigNat{1U})) {
      return fail<std::vector<BoundaryCompletionAtomV1>>(
          "c18.stationary_quotient_not_one_step",
          "a stationary clock completion may erase exactly one audited physical-slot advance");
    }
    std::optional<std::size_t> match;
    for (std::size_t index = 0U; index < coordinates.size(); ++index) {
      if (!same_stationary_quotient_coordinates(
              successor.value(), coordinates[index])) {
        continue;
      }
      if (match.has_value()) {
        return fail<std::vector<BoundaryCompletionAtomV1>>(
            "c18.stationary_quotient_successor_ambiguous",
            "one physical successor maps to multiple stationary clock representatives");
      }
      match = index;
    }
    if (!match.has_value()) {
      return fail<std::vector<BoundaryCompletionAtomV1>>(
          "c18.stationary_quotient_successor_outside_domain",
          "the finite domain is not closed after erasing the audited physical slot");
    }
    MarkedFluxEdgeV1 transformed = leaking.edge;
    transformed.successor_state = representatives[*match];
    transformed.phase_after =
        phase_identity(coordinates[*match].arrival_phase);
    return Result<std::vector<BoundaryCompletionAtomV1>>::success({
        BoundaryCompletionAtomV1{
            representatives[*match], ExactRational::one(),
            std::move(transformed)}});
  };
  return Result<BoundaryRule>::success(BoundaryRule{
      BoundaryCompletionKindV1::marked_completion,
      std::move(completion_identity).value(), true, std::move(apply)});
}

}  // namespace

Result<TransitionMatrix>
detail::assemble_finite_stationary_time_homogeneous_transition_matrix(
    const StateDomain& domain, const AuditedRowProvider& provider) {
  auto boundary = certify_stationary_time_homogeneous_quotient_boundary(
      domain, provider);
  if (!boundary) {
    return Result<TransitionMatrix>::failure(boundary.error());
  }
  return assemble_finite_transition_matrix(domain, provider,
                                           boundary.value());
}

Result<TransitionMatrix> assemble_finite_transition_matrix(
    const StateDomain& domain, const AuditedRowProvider& provider,
    const BoundaryRule& boundary) {
  auto boundary_valid = validate_boundary_shape(boundary);
  if (!boundary_valid) {
    return Result<TransitionMatrix>::failure(boundary_valid.error());
  }
  auto sealed = detail::C18CoreAccess::provider_core(provider);
  if (!sealed || !sealed->report().passed() || !sealed->row_available()) {
    return fail<TransitionMatrix>(
        "c18.audited_row_provider_unavailable",
        "matrix assembly requires the passing C17 V0-sealed row view",
        {}, DiagnosticCategory::unavailable);
  }
  const CompiledFrameworkCandidateInputsV1& inputs = sealed->inputs();
  auto policy_result = solver_policy(inputs.instance);
  if (!policy_result) {
    return Result<TransitionMatrix>::failure(policy_result.error());
  }
  SolverPolicy policy = std::move(policy_result).value();
  auto policy_valid = validate_policy(policy);
  if (!policy_valid) {
    return Result<TransitionMatrix>::failure(policy_valid.error());
  }
  auto bound_selection = selection_identity(
      inputs.instance.analysis_spec().context->selection);
  if (!bound_selection) {
    return Result<TransitionMatrix>::failure(bound_selection.error());
  }
  auto c15_selector =
      artifact::detail::canonical_analysis_selection_digest_v1(
          inputs.instance.analysis_spec().context->selection);
  if (!c15_selector ||
      c15_selector.value() != inputs.framework_seed.bindings.selection_digest) {
    return fail<TransitionMatrix>(
        "c18.bound_selection_identity_mismatch",
        "the resolved stationary selection differs from the C17 seal");
  }
  auto normalized_selector = selector_digest(bound_selection.value());
  if (!normalized_selector) {
    return Result<TransitionMatrix>::failure(normalized_selector.error());
  }

  if (domain.states.empty()) {
    return fail<TransitionMatrix>("c18.empty_state_domain",
                                  "a finite stationary domain is nonempty");
  }
  std::vector<ReducedStateV1> states = domain.states;
  std::sort(states.begin(), states.end(), state_less);
  for (std::size_t index = 0; index < states.size(); ++index) {
    if (index != 0U && states[index] == states[index - 1U]) {
      return fail<TransitionMatrix>(
          "c18.duplicate_state",
          "the finite stationary domain contains a duplicate exact state",
          {"canonical index " + std::to_string(index)});
    }
    if (!(states[index].codec == inputs.exact_state_schema.reduced_state_codec)) {
      return fail<TransitionMatrix>(
          "c18.state_codec_mismatch",
          "a finite-domain state uses a foreign reduced-state codec");
    }
    auto valid = inputs.exact_state_schema.validate_domain(states[index]);
    if (!valid) {
      return Result<TransitionMatrix>::failure(valid.error());
    }
  }

  const std::size_t count = states.size();
  std::vector<ExactRational> exact_entries(
      count * count, ExactRational::zero());
  std::vector<CompletionBoundMarkedRowV1> flux_rows(count);
  std::vector<LeakageRecordV1> leakage;
  ExactRational completed_mass = ExactRational::zero();
  std::vector<ArrivalPhaseIdentityV1> state_phases;
  state_phases.reserve(count);

  for (std::size_t source = 0; source < count; ++source) {
    auto decoded_state = inputs.exact_state_schema.decode(states[source]);
    if (!decoded_state) {
      return Result<TransitionMatrix>::failure(decoded_state.error());
    }
    state_phases.push_back(
        phase_identity(decoded_state.value().arrival_phase));

    auto marked_row = compile_reduced_kernel_row(provider, states[source]);
    if (!marked_row) {
      return Result<TransitionMatrix>::failure(marked_row.error());
    }
    auto endpoint = project_marked_row_to_endpoint(marked_row.value());
    if (!endpoint) {
      return Result<TransitionMatrix>::failure(endpoint.error());
    }
    const long double row_image_error =
        std::fabs(endpoint.value().numerical_residual_from_one());
    const long double row_image_bound = residual_bound(policy, 1.0L);
    if (row_image_error > row_image_bound) {
      return fail<TransitionMatrix>(
          "c18.row_numerical_image_residual",
          "the unmodified long-double row image exceeds its declared bound",
          {"row " + std::to_string(source),
           "residual " + std::to_string(row_image_error),
           "bound " + std::to_string(row_image_bound)});
    }

    for (const MarkedFluxAtomV1& atom : endpoint.value().marked_atoms()) {
      auto edge_valid = validate_marked_edge(
          atom.edge, states[source], inputs.exact_state_schema);
      if (!edge_valid) {
        return Result<TransitionMatrix>::failure(edge_valid.error());
      }
      const auto inside = state_index(states, atom.edge.successor_state);
      if (inside.has_value()) {
        exact_entries[source * count + *inside] =
            exact_entries[source * count + *inside] + atom.exact_mass;
        flux_rows[source].atoms.push_back(CompletionBoundMarkedAtomV1{
            *inside, atom.exact_mass, atom.numerical_image, false, atom.edge});
        continue;
      }
      if (!atom.exact_mass.is_positive()) {
        continue;
      }
      leakage.push_back(
          LeakageRecordV1{source, atom.edge.successor_state, atom.exact_mass,
                          atom.edge});
      if (boundary.kind == BoundaryCompletionKindV1::exact_closed) {
        return fail<TransitionMatrix>(
            "c18.positive_domain_leakage",
            "a positive exact endpoint lies outside the declared closed domain",
            {"row " + std::to_string(source),
             "endpoint " +
                 canonical_state_note(atom.edge.successor_state),
             "mass " + atom.exact_mass.to_canonical_string()});
      }
      auto images = boundary.apply(atom);
      if (!images) {
        return Result<TransitionMatrix>::failure(images.error());
      }
      if (images.value().empty()) {
        return fail<TransitionMatrix>(
            "c18.partial_boundary_completion",
            "a positive leaking atom received no completion image");
      }
      std::sort(
          images.value().begin(), images.value().end(),
          [](const BoundaryCompletionAtomV1& left,
             const BoundaryCompletionAtomV1& right) {
            if (state_less(left.successor_state, right.successor_state)) {
              return true;
            }
            if (state_less(right.successor_state, left.successor_state)) {
              return false;
            }
            if (left.conditional_mass != right.conditional_mass) {
              return left.conditional_mass < right.conditional_mass;
            }
            return marked_edge_sort_key(left.transformed_edge) <
                   marked_edge_sort_key(right.transformed_edge);
          });
      ExactRational conditional_total = ExactRational::zero();
      for (std::size_t image_index = 0;
           image_index < images.value().size(); ++image_index) {
        const BoundaryCompletionAtomV1& image =
            images.value()[image_index];
        if (!image.conditional_mass.is_nonnegative()) {
          return fail<TransitionMatrix>(
              "c18.negative_completion_weight",
              "boundary conditional weights must be nonnegative");
        }
        conditional_total = conditional_total + image.conditional_mass;
        if (!image.conditional_mass.is_positive()) {
          continue;
        }
        const auto destination = state_index(states, image.successor_state);
        if (!destination.has_value()) {
          return fail<TransitionMatrix>(
              "c18.incomplete_boundary_endpoint",
              "a boundary completion image remains outside StateDomain",
              {"image " + std::to_string(image_index)});
        }
        if (boundary.kind ==
            BoundaryCompletionKindV1::state_only_completion) {
          if (image.transformed_edge.has_value()) {
            return fail<TransitionMatrix>(
                "c18.state_only_completion_has_marks",
                "a state-only completion must expose no affected edge law");
          }
        } else {
          if (!image.transformed_edge.has_value() ||
              !(image.transformed_edge->successor_state ==
                image.successor_state)) {
            return fail<TransitionMatrix>(
                "c18.marked_completion_edge_missing",
                "each positive marked completion image requires its matching "
                "transformed edge");
          }
          auto transformed_valid = validate_marked_edge(
              *image.transformed_edge, states[source],
              inputs.exact_state_schema);
          if (!transformed_valid) {
            return Result<TransitionMatrix>::failure(
                transformed_valid.error());
          }
          if (boundary.physical_mark_preserving &&
              (image.transformed_edge->prearrival_target_backlog !=
                   atom.edge.prearrival_target_backlog ||
               image.transformed_edge->target_departures !=
                   atom.edge.target_departures ||
               image.transformed_edge->target_arrivals !=
                   atom.edge.target_arrivals ||
               image.transformed_edge->phase_before != atom.edge.phase_before ||
               image.transformed_edge->phase_after != atom.edge.phase_after ||
               image.transformed_edge->marks != atom.edge.marks)) {
            return fail<TransitionMatrix>(
                "c18.completion_not_physical_mark_preserving",
                "the marked completion changed a retained physical edge mark");
          }
        }
        const ExactRational mass =
            atom.exact_mass * image.conditional_mass;
        const auto mass_image = numerical_image(mass);
        if (mass_image.second == NumericalProbabilityImageStatusV1::overflow) {
          return fail<TransitionMatrix>(
              "c18.nonfinite_completion_image",
              "a completed exact mass has no finite numerical image");
        }
        exact_entries[source * count + *destination] =
            exact_entries[source * count + *destination] + mass;
        flux_rows[source].atoms.push_back(CompletionBoundMarkedAtomV1{
            *destination, mass, mass_image.first, true,
            image.transformed_edge});
      }
      if (!(conditional_total == ExactRational::one())) {
        return fail<TransitionMatrix>(
            "c18.completion_weights_not_one",
            "boundary conditional weights must total exactly one",
            {"total " + conditional_total.to_canonical_string()});
      }
      completed_mass = completed_mass + atom.exact_mass;
    }
  }

  for (CompletionBoundMarkedRowV1& row : flux_rows) {
    std::sort(row.atoms.begin(), row.atoms.end(),
              [](const CompletionBoundMarkedAtomV1& left,
                 const CompletionBoundMarkedAtomV1& right) {
                if (left.successor_index != right.successor_index) {
                  return left.successor_index < right.successor_index;
                }
                if (left.completed_from_leakage !=
                    right.completed_from_leakage) {
                  return left.completed_from_leakage <
                         right.completed_from_leakage;
                }
                if (left.exact_mass != right.exact_mass) {
                  return left.exact_mass < right.exact_mass;
                }
                return marked_edge_sort_key(left.edge) <
                       marked_edge_sort_key(right.edge);
              });
  }

  std::vector<long double> numerical_entries(count * count, 0.0L);
  std::vector<std::uint8_t> support(count * count, 0U);
  std::vector<MatrixRowDiagnosticV1> row_diagnostics;
  row_diagnostics.reserve(count);
  std::size_t nonzero_count = 0U;
  for (std::size_t row = 0; row < count; ++row) {
    ExactRational exact_total = ExactRational::zero();
    CompensatedSum numerical_total;
    for (std::size_t column = 0; column < count; ++column) {
      const std::size_t offset = row * count + column;
      const ExactRational& entry = exact_entries[offset];
      if (!entry.is_nonnegative()) {
        return fail<TransitionMatrix>("c18.negative_transition",
                                      "a matrix entry is negative");
      }
      exact_total = exact_total + entry;
      const auto image = numerical_image(entry);
      if (image.second == NumericalProbabilityImageStatusV1::overflow) {
        return fail<TransitionMatrix>(
            "c18.nonfinite_transition_image",
            "an exact transition has no finite long-double image");
      }
      numerical_entries[offset] = image.first;
      numerical_total.add(image.first);
      if (entry.is_positive()) {
        support[offset] = 1U;
        ++nonzero_count;
      }
    }
    if (!(exact_total == ExactRational::one())) {
      return fail<TransitionMatrix>(
          "c18.matrix_row_mass_not_one",
          "the completed exact matrix row does not total one",
          {"row " + std::to_string(row),
           "total " + exact_total.to_canonical_string()});
    }
    const long double total_image = numerical_total.value();
    const long double raw_residual = total_image - 1.0L;
    const long double bound = residual_bound(policy, 1.0L);
    if (!std::isfinite(total_image) || std::fabs(raw_residual) > bound) {
      return fail<TransitionMatrix>(
          "c18.matrix_row_numerical_residual",
          "the unmodified numerical matrix row exceeds its declared bound",
          {"row " + std::to_string(row)});
    }
    row_diagnostics.push_back(MatrixRowDiagnosticV1{
        row, std::move(exact_total), total_image, raw_residual, bound});
  }

  auto flux_core =
      std::make_shared<stationary::detail::CompletionBoundMarkedFluxCore>(
          stationary::detail::CompletionBoundMarkedFluxCore{
              boundary.kind, boundary.completion_identity,
              boundary.physical_mark_preserving, std::move(flux_rows),
              std::move(leakage), completed_mass});
  CompletionBoundMarkedFlux flux =
      detail::C18CoreAccess::marked_flux(std::move(flux_core));

  std::vector<ArrivalPhaseIdentityV1> configured_phase_states;
  std::vector<ExactRational> configured_phase_masses;
  const BuilderArrivalView arrival_view =
      builder_arrival_view(inputs.configured_arrival);
  if (arrival_view.stationary_phase_law().has_value()) {
    const StationaryPhaseLawDescriptor& phase_law =
        *arrival_view.stationary_phase_law();
    if (phase_law.canonical_states.size() !=
        phase_law.probabilities.normalized_weights().size()) {
      return fail<TransitionMatrix>(
          "c18.configured_phase_law_dimension",
          "the configured stationary phase law has inconsistent dimensions");
    }
    for (std::size_t phase = 0; phase < phase_law.canonical_states.size();
         ++phase) {
      configured_phase_states.push_back(ArrivalPhaseIdentityV1{
          inputs.configured_arrival.family(),
          phase_law.canonical_states[phase]});
      configured_phase_masses.push_back(
          phase_law.probabilities.normalized_weights()[phase]);
    }
  }

  const Digest256 placeholder = Sha256().finalize();
  auto matrix_core = std::make_shared<stationary::detail::TransitionMatrixCore>(
      stationary::detail::TransitionMatrixCore{
          std::move(states), std::move(exact_entries),
          std::move(numerical_entries), std::move(support), nonzero_count,
          std::move(row_diagnostics), std::move(flux), placeholder,
          std::move(bound_selection).value(), normalized_selector.value(),
          policy,
          stationary::detail::ProductionBinding{
              inputs.framework_seed.bindings,
              inputs.framework_seed.target_selection,
              inputs.configured_arrival,
              inputs.exact_state_schema.reduced_state_codec,
              inputs.instance},
          std::nullopt, inputs.exact_state_schema.exact_state_schema_digest,
          inputs.exact_state_schema.reduced_state_schema_digest,
          std::move(state_phases), std::move(configured_phase_states),
          std::move(configured_phase_masses), std::nullopt});
  auto identity = matrix_identity(*matrix_core);
  if (!identity) {
    return Result<TransitionMatrix>::failure(identity.error());
  }
  matrix_core->matrix_identity = std::move(identity).value();
  return Result<TransitionMatrix>::success(
      detail::C18CoreAccess::transition_matrix(std::move(matrix_core)));
}

ClassDecomposition analyze_communicating_classes(
    const TransitionMatrix& matrix) {
  const std::size_t count = matrix.size();
  std::vector<int> discovery(count, -1);
  std::vector<int> low(count, -1);
  std::vector<std::size_t> stack;
  std::vector<std::uint8_t> on_stack(count, 0U);
  std::vector<std::vector<std::size_t>> components;
  int next_discovery = 0;
  std::function<void(std::size_t)> visit = [&](const std::size_t vertex) {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = 1U;
    for (std::size_t successor = 0; successor < count; ++successor) {
      if (!matrix.exact_positive_support(vertex, successor)) {
        continue;
      }
      if (discovery[successor] == -1) {
        visit(successor);
        low[vertex] = std::min(low[vertex], low[successor]);
      } else if (on_stack[successor] != 0U) {
        low[vertex] = std::min(low[vertex], discovery[successor]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::size_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = 0U;
      component.push_back(member);
      if (member == vertex) {
        break;
      }
    }
    std::sort(component.begin(), component.end());
    components.push_back(std::move(component));
  };
  for (std::size_t vertex = 0; vertex < count; ++vertex) {
    if (discovery[vertex] == -1) {
      visit(vertex);
    }
  }
  std::sort(components.begin(), components.end());
  std::vector<std::size_t> component_of(count, 0U);
  for (std::size_t component = 0; component < components.size(); ++component) {
    for (const std::size_t member : components[component]) {
      component_of[member] = component;
    }
  }

  std::vector<CommunicatingClassV1> classes;
  std::vector<std::size_t> closed;
  std::vector<std::uint8_t> state_is_closed(count, 0U);
  classes.reserve(components.size());
  for (std::size_t component = 0; component < components.size(); ++component) {
    std::set<std::size_t> outgoing;
    for (const std::size_t member : components[component]) {
      for (std::size_t successor = 0; successor < count; ++successor) {
        if (matrix.exact_positive_support(member, successor) &&
            component_of[successor] != component) {
          outgoing.insert(component_of[successor]);
        }
      }
    }
    std::vector<TypedLabel> outgoing_ids;
    for (const std::size_t target : outgoing) {
      outgoing_ids.push_back(TypedLabel::numeric(BigNat(target)));
    }
    const bool is_closed = outgoing.empty();
    classes.push_back(CommunicatingClassV1{
        TypedLabel::numeric(BigNat(component)), components[component],
        std::move(outgoing_ids), is_closed});
    if (is_closed) {
      closed.push_back(component);
      for (const std::size_t member : components[component]) {
        state_is_closed[member] = 1U;
      }
    }
  }
  std::vector<std::size_t> transient;
  for (std::size_t state = 0; state < count; ++state) {
    if (state_is_closed[state] == 0U) {
      transient.push_back(state);
    }
  }
  auto core =
      std::make_shared<stationary::detail::ClassDecompositionCore>(
          stationary::detail::ClassDecompositionCore{
              matrix, std::move(classes), std::move(closed),
              std::move(transient)});
  return detail::C18CoreAccess::class_decomposition(std::move(core));
}

Result<InvariantSelection> select_invariant_class(
    const ClassDecomposition& decomposition,
    const SelectionSpec& selection) {
  const auto& decomposition_core = detail::C18CoreAccess::core(decomposition);
  const auto& matrix_core =
      detail::C18CoreAccess::core(decomposition_core.matrix);
  auto supplied = selection_identity(selection);
  if (!supplied) {
    return Result<InvariantSelection>::failure(supplied.error());
  }
  if (!(supplied.value() == matrix_core.bound_selection)) {
    return fail<InvariantSelection>(
        "c18.selection_binding_mismatch",
        "the supplied selection differs from the matrix-bound normalized "
        "selection");
  }

  using Kind = stationary::detail::SelectionIdentityKind;
  std::vector<SelectedInvariantClassV1> selected;
  if (supplied.value().kind == Kind::unique) {
    if (decomposition_core.closed_class_indices.size() != 1U) {
      return fail<InvariantSelection>(
          "c18.stationary_class_ambiguous",
          "stationary_unique requires exactly one closed communicating class",
          {"closed classes " +
           std::to_string(decomposition_core.closed_class_indices.size())});
    }
    const std::size_t class_index =
        decomposition_core.closed_class_indices.front();
    selected.push_back(SelectedInvariantClassV1{
        decomposition_core.classes[class_index].class_id, class_index,
        ExactRational::one(), 1.0L});
  } else {
    for (const auto& wanted : supplied.value().components) {
      const auto found = std::find_if(
          decomposition_core.classes.begin(), decomposition_core.classes.end(),
          [&](const CommunicatingClassV1& candidate) {
            return candidate.class_id == wanted.class_id;
          });
      if (found == decomposition_core.classes.end()) {
        return fail<InvariantSelection>("c18.unknown_stationary_class",
                                        "the selector names an unknown class");
      }
      if (!found->closed) {
        return fail<InvariantSelection>(
            "c18.transient_class_selected",
            "stationary mixture mass may be assigned only to closed classes");
      }
      const std::size_t class_index = static_cast<std::size_t>(
          found - decomposition_core.classes.begin());
      const long double weight = wanted.exact_weight.to_long_double();
      if (!std::isfinite(weight) ||
          (wanted.exact_weight.is_positive() && weight <= 0.0L)) {
        return fail<InvariantSelection>(
            "c18.unusable_mixture_weight_image",
            "a positive exact mixture weight has no positive finite image");
      }
      selected.push_back(SelectedInvariantClassV1{
          wanted.class_id, class_index, wanted.exact_weight, weight});
    }
  }
  if (selected.empty()) {
    return fail<InvariantSelection>("c18.empty_invariant_selection",
                                    "no closed class has positive weight");
  }
  auto digest = selector_digest(supplied.value());
  if (!digest) {
    return Result<InvariantSelection>::failure(digest.error());
  }
  auto core = std::make_shared<stationary::detail::InvariantSelectionCore>(
      stationary::detail::InvariantSelectionCore{
          decomposition, std::move(selected), std::move(digest).value()});
  return Result<InvariantSelection>::success(
      detail::C18CoreAccess::invariant_selection(std::move(core)));
}

namespace {

struct ResidualSummary final {
  long double normalization;
  long double normalization_bound;
  long double l1;
  long double l1_bound;
  long double maximum;
  long double maximum_bound;
};

[[nodiscard]] ResidualSummary invariant_residual(
    const TransitionMatrix& matrix, const std::vector<long double>& masses,
    const SolverPolicy& policy,
    const std::span<const std::size_t> coordinates) {
  CompensatedSum normalization;
  long double normalization_scale = 0.0L;
  CompensatedSum l1;
  long double l1_scale = 0.0L;
  long double maximum = 0.0L;
  long double maximum_scale = 0.0L;
  for (const std::size_t state : coordinates) {
    normalization.add(masses[state]);
    normalization_scale += std::fabs(masses[state]);
  }
  for (const std::size_t destination : coordinates) {
    CompensatedSum image;
    long double component_scale = std::fabs(masses[destination]);
    for (const std::size_t source : coordinates) {
      const long double term =
          masses[source] * matrix.numerical_entry(source, destination);
      image.add(term);
      component_scale += std::fabs(term);
    }
    const long double residual = image.value() - masses[destination];
    l1.add(std::fabs(residual));
    l1_scale += component_scale;
    maximum = std::max(maximum, std::fabs(residual));
    maximum_scale = std::max(maximum_scale, component_scale);
  }
  return ResidualSummary{
      normalization.value() - 1.0L,
      residual_bound(policy, normalization_scale), l1.value(),
      residual_bound(policy, l1_scale), maximum,
      residual_bound(policy, maximum_scale)};
}

}  // namespace

Result<InvariantLaw> solve_invariant_distribution(
    const TransitionMatrix& matrix, const InvariantSelection& selection,
    const SolverPolicy& policy) {
  const auto& matrix_core = detail::C18CoreAccess::core(matrix);
  const auto& selection_core = detail::C18CoreAccess::core(selection);
  const TransitionMatrix& selection_matrix =
      detail::C18CoreAccess::core(selection_core.decomposition).matrix;
  if (detail::C18CoreAccess::carrier_identity(selection_matrix) !=
          detail::C18CoreAccess::carrier_identity(matrix) ||
      selection.matrix_identity() != matrix.matrix_identity() ||
      !(policy == matrix_core.bound_solver_policy)) {
    return fail<InvariantLaw>(
        "c18.solve_binding_mismatch",
        "matrix, selector, and solver policy do not share one bound identity");
  }
  auto policy_valid = validate_policy(policy);
  if (!policy_valid) {
    return Result<InvariantLaw>::failure(policy_valid.error());
  }
  if (policy.linear_method != LinearMethod::dense_pivoted) {
    return fail<InvariantLaw>(
        "c18.solver_method_unavailable",
        "C18 implements only the declared dense_pivoted finite solve",
        {}, DiagnosticCategory::unavailable);
  }

  const std::size_t count = matrix.size();
  std::vector<long double> masses(count, 0.0L);
  std::vector<ClassSolveDiagnosticV1> class_diagnostics;
  for (const SelectedInvariantClassV1& selected :
       selection_core.selected_classes) {
    // A normalized zero-weight mixture component remains in the returned
    // provenance but contributes the exact zero vector, so it has no class
    // law to obtain from a numerical factorization.
    if (selected.exact_weight.is_zero()) {
      continue;
    }
    const auto& class_record =
        detail::C18CoreAccess::core(selection_core.decomposition)
            .classes.at(selected.class_index);
    const std::vector<std::size_t>& members = class_record.member_indices;
    const std::size_t dimension = members.size();
    Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> coefficients(
        static_cast<Eigen::Index>(dimension),
        static_cast<Eigen::Index>(dimension));
    Eigen::Matrix<long double, Eigen::Dynamic, 1> rhs(
        static_cast<Eigen::Index>(dimension));
    coefficients.setZero();
    rhs.setZero();
    for (std::size_t equation = 0; equation + 1U < dimension;
         ++equation) {
      for (std::size_t variable = 0; variable < dimension; ++variable) {
        // Form P_{ji}-delta_ij in ExactRational before conversion.  This is
        // essential for near-reducible rows whose rounded diagonal image may
        // otherwise erase a and b.
        ExactRational coefficient = matrix.exact_entry(
            members[variable], members[equation]);
        if (variable == equation) {
          coefficient = coefficient - ExactRational::one();
        }
        coefficients(static_cast<Eigen::Index>(equation),
                     static_cast<Eigen::Index>(variable)) =
            coefficient.to_long_double();
      }
    }
    for (std::size_t variable = 0; variable < dimension; ++variable) {
      coefficients(static_cast<Eigen::Index>(dimension - 1U),
                   static_cast<Eigen::Index>(variable)) = 1.0L;
    }
    rhs(static_cast<Eigen::Index>(dimension - 1U)) = 1.0L;
    const long double eta = static_cast<long double>(dimension) *
                            std::numeric_limits<long double>::epsilon();
    Eigen::FullPivLU<decltype(coefficients)> factorization;
    factorization.setThreshold(eta);
    factorization.compute(coefficients);
    const std::size_t rank =
        static_cast<std::size_t>(factorization.rank());
    const long double rcond = factorization.rcond();
    const long double warning_threshold = std::sqrt(eta);
    const bool condition_warning =
        !std::isfinite(rcond) || rcond <= warning_threshold;
    const auto solution = factorization.solve(rhs);
    bool finite_nonnegative = true;
    std::vector<long double> class_masses(count, 0.0L);
    for (std::size_t local = 0; local < dimension; ++local) {
      const long double value = solution(static_cast<Eigen::Index>(local));
      if (!std::isfinite(value) || value < 0.0L) {
        finite_nonnegative = false;
      }
      class_masses[members[local]] = value;
    }
    const ResidualSummary residual = invariant_residual(
        matrix, class_masses, policy, members);
    const bool accepted = rank == dimension && finite_nonnegative &&
                          std::fabs(residual.normalization) <=
                              residual.normalization_bound &&
                          residual.l1 <= residual.l1_bound &&
                          residual.maximum <= residual.maximum_bound;
    class_diagnostics.push_back(ClassSolveDiagnosticV1{
        selected.class_id, dimension, rank, eta, rcond, warning_threshold,
        condition_warning, residual.normalization,
        residual.normalization_bound, residual.l1, residual.l1_bound,
        residual.maximum, residual.maximum_bound, finite_nonnegative,
        accepted ? StationaryLinearSolveStatusV1::solved
                 : StationaryLinearSolveStatusV1::numerically_unresolved});
    if (!accepted) {
      const bool rank_deficient = rank != dimension;
      return fail<InvariantLaw>(
          "c18.numerically_unresolved",
          rank_deficient
              ? "the augmented invariant system is not full rank at the "
                "explicit LU threshold"
              : "the selected class invariant vector failed finite, "
                "nonnegative, normalization, or invariance checks",
          {rank_deficient ? "reason rank_deficient"
                          : "reason class_residual",
           "method dense_pivoted",
           "class index " + std::to_string(selected.class_index),
           "rank " + std::to_string(rank),
           "dimension " + std::to_string(dimension),
           "eta " + numerical_note_value(eta),
           "rcond " + numerical_note_value(rcond),
           "condition warning threshold " +
               numerical_note_value(warning_threshold),
           std::string("condition warning ") +
               (condition_warning ? "true" : "false"),
           "normalization residual " +
               numerical_note_value(residual.normalization),
           "normalization bound " +
               numerical_note_value(residual.normalization_bound),
           "l1 residual " + numerical_note_value(residual.l1),
           "l1 bound " + numerical_note_value(residual.l1_bound),
           "maximum residual " + numerical_note_value(residual.maximum),
           "maximum bound " +
               numerical_note_value(residual.maximum_bound),
           std::string("finite nonnegative ") +
               (finite_nonnegative ? "true" : "false")});
    }
    for (std::size_t local = 0; local < dimension; ++local) {
      masses[members[local]] =
          selected.numerical_weight * class_masses[members[local]];
    }
  }
  std::vector<std::size_t> all_coordinates(count);
  std::iota(all_coordinates.begin(), all_coordinates.end(), 0U);
  const ResidualSummary aggregate =
      invariant_residual(matrix, masses, policy, all_coordinates);
  const bool finite_nonnegative = std::all_of(
      masses.begin(), masses.end(),
      [](const long double value) { return std::isfinite(value) && value >= 0; });
  if (!finite_nonnegative ||
      std::fabs(aggregate.normalization) > aggregate.normalization_bound ||
      aggregate.l1 > aggregate.l1_bound ||
      aggregate.maximum > aggregate.maximum_bound) {
    const std::size_t warning_count = static_cast<std::size_t>(std::count_if(
        class_diagnostics.begin(), class_diagnostics.end(),
        [](const ClassSolveDiagnosticV1& diagnostic) {
          return diagnostic.condition_warning;
        }));
    return fail<InvariantLaw>(
        "c18.numerically_unresolved",
        "the declared invariant mixture failed the full-domain checks",
        {"reason mixture_residual",
         "method dense_pivoted",
         "conditioning warnings " + std::to_string(warning_count),
         "normalization residual " +
             numerical_note_value(aggregate.normalization),
         "normalization bound " +
             numerical_note_value(aggregate.normalization_bound),
         "l1 residual " + numerical_note_value(aggregate.l1),
         "l1 bound " + numerical_note_value(aggregate.l1_bound),
         "maximum residual " + numerical_note_value(aggregate.maximum),
         "maximum bound " +
             numerical_note_value(aggregate.maximum_bound)});
  }
  InvariantSolveDiagnosticsV1 diagnostics{
      policy.linear_method, policy.absolute_residual_tolerance,
      policy.relative_residual_tolerance, selection_core.selected_classes,
      std::move(class_diagnostics),
      aggregate.normalization, aggregate.normalization_bound, aggregate.l1,
      aggregate.l1_bound, aggregate.maximum, aggregate.maximum_bound};
  auto core = std::make_shared<stationary::detail::InvariantLawCore>(
      stationary::detail::InvariantLawCore{
          matrix, std::move(masses), selection_core.selected_classes,
          std::move(diagnostics)});
  return Result<InvariantLaw>::success(
      detail::C18CoreAccess::invariant_law(std::move(core)));
}

namespace {

[[nodiscard]] std::size_t stage_ordinal(const CausalStageV1 stage) {
  const auto found =
      std::find(kCausalStageOrderV1.begin(), kCausalStageOrderV1.end(), stage);
  return static_cast<std::size_t>(found - kCausalStageOrderV1.begin());
}

[[nodiscard]] bool edge_has_required_marks(
    const MarkedFluxEdgeV1& edge,
    const std::span<const RequiredStationaryMarkV1> required) {
  for (const RequiredStationaryMarkV1& requirement : required) {
    std::size_t matches = 0U;
    for (const CausalMarkV1& candidate : edge.marks) {
      if (candidate.mark.mark == requirement.mark &&
          candidate.mark.value.codec == requirement.value_codec &&
          stage_ordinal(candidate.reveal_stage) <=
              stage_ordinal(requirement.latest_reveal_stage)) {
        ++matches;
      }
    }
    if (matches != 1U) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] Result<ExactRational> exact_long_double(
    const long double input) {
  static_assert(std::numeric_limits<long double>::radix == 2,
                "C18's exact numerical-image encoding requires binary radix");
  if (!std::isfinite(input)) {
    return fail<ExactRational>(
        "c18.nonfinite_metric_scalar",
        "a finite stationary result cannot encode NaN or infinity");
  }
  if (input == 0.0L) {
    return Result<ExactRational>::success(ExactRational::zero());
  }
  const bool negative = std::signbit(input);
  int exponent = 0;
  long double fraction = std::frexp(std::fabs(input), &exponent);
  BigInt significand = 0;
  for (int bit = 0; bit < std::numeric_limits<long double>::digits; ++bit) {
    fraction *= 2.0L;
    significand <<= 1U;
    if (fraction >= 1.0L) {
      ++significand;
      fraction -= 1.0L;
    }
  }
  if (negative) {
    significand = -significand;
  }
  const int binary_exponent =
      exponent - std::numeric_limits<long double>::digits;
  BigInt numerator = std::move(significand);
  BigInt denominator = 1;
  if (binary_exponent >= 0) {
    numerator <<= static_cast<unsigned int>(binary_exponent);
  } else {
    denominator <<= static_cast<unsigned int>(-binary_exponent);
  }
  return ExactRational::make(std::move(numerator), std::move(denominator));
}

[[nodiscard]] std::vector<std::byte> scalar_bytes(
    const ExactRational& value) {
  const std::string encoded = value.to_canonical_string();
  const auto bytes = std::as_bytes(std::span(encoded.data(), encoded.size()));
  return std::vector<std::byte>(bytes.begin(), bytes.end());
}

[[nodiscard]] Result<long double> evaluate_reward(
    const RewardDecoder& decoder, const StationaryRewardArgumentV1& argument) {
  auto value = decoder.decode(argument);
  if (!value) {
    return value;
  }
  const long double reward = value.value();
  if (std::isnan(reward) ||
      (decoder.integrability ==
           StationaryRewardIntegrabilityV1::finite_absolute &&
       !std::isfinite(reward)) ||
      (decoder.integrability ==
           StationaryRewardIntegrabilityV1::nonnegative_extended_real &&
       reward < 0.0L)) {
    return fail<long double>(
        "c18.reward_integrability_violation",
        "the decoded reward violates its declared integrability class");
  }
  return value;
}

}  // namespace

Result<MetricValue> evaluate_stationary_edge_reward(
    const InvariantLaw& law, const RewardDecoder& decoder) {
  if (decoder.requires_temporal_continuation) {
    return fail<MetricValue>(
        "missing_temporal_continuation",
        "a stationary one-edge flux cannot answer a temporal reward",
        {}, DiagnosticCategory::unavailable);
  }
  if (!decoder.decode || decoder.result_codec.id.empty() ||
      decoder.result_codec.version == 0U) {
    return fail<MetricValue>("c18.invalid_reward_decoder",
                             "the reward decoder or result codec is invalid");
  }
  if (decoder.domain == StationaryRewardDomainV1::state &&
      !decoder.required_marks.empty()) {
    return fail<MetricValue>(
        "c18.state_reward_requires_edge_mark",
        "a state reward cannot declare a one-edge mark requirement");
  }

  CompensatedSum total;
  CompensatedSum absolute_total;
  bool positive_infinity = false;
  if (decoder.domain == StationaryRewardDomainV1::state) {
    for (std::size_t state = 0; state < law.masses().size(); ++state) {
      if (law.masses()[state] == 0.0L) {
        continue;
      }
      auto reward = evaluate_reward(
          decoder, StationaryRewardArgumentV1{
                       law.transition_matrix().states()[state], nullptr});
      if (!reward) {
        return Result<MetricValue>::failure(reward.error());
      }
      if (std::isinf(reward.value())) {
        positive_infinity = true;
        continue;
      }
      const long double term = law.masses()[state] * reward.value();
      total.add(term);
      absolute_total.add(std::fabs(term));
    }
  } else {
    const auto rows = law.marked_flux().rows();
    for (std::size_t state = 0; state < rows.size(); ++state) {
      if (law.masses()[state] == 0.0L) {
        continue;
      }
      for (const CompletionBoundMarkedAtomV1& atom : rows[state].atoms) {
        if (!atom.exact_mass.is_positive()) {
          continue;
        }
        if (!atom.edge.has_value()) {
          return fail<MetricValue>(
              "c18.edge_reward_unavailable_after_state_completion",
              "positive completion mass has no transformed marked-edge law",
              {}, DiagnosticCategory::unavailable);
        }
        if (!edge_has_required_marks(*atom.edge, decoder.required_marks)) {
          return fail<MetricValue>(
              "c18.required_edge_mark_unavailable",
              "the completion-bound edge lacks a required mark identity, "
              "codec, or reveal-stage bound",
              {}, DiagnosticCategory::unavailable);
        }
        auto reward = evaluate_reward(
            decoder,
            StationaryRewardArgumentV1{
                law.transition_matrix().states()[state], &*atom.edge});
        if (!reward) {
          return Result<MetricValue>::failure(reward.error());
        }
        if (std::isinf(reward.value())) {
          positive_infinity = true;
          continue;
        }
        auto exact_reward = exact_long_double(reward.value());
        if (!exact_reward) {
          return Result<MetricValue>::failure(exact_reward.error());
        }
        const ExactRational exact_inner_term =
            atom.exact_mass * exact_reward.value();
        const long double term =
            law.masses()[state] * exact_inner_term.to_long_double();
        if (!std::isfinite(term)) {
          return fail<MetricValue>(
              "c18.reward_accumulation_nonfinite",
              "an exact mass-weighted edge reward has no finite stationary "
              "image");
        }
        total.add(term);
        absolute_total.add(std::fabs(term));
      }
    }
  }
  if (positive_infinity) {
    const std::string infinity = "+inf";
    const auto bytes =
        std::as_bytes(std::span(infinity.data(), infinity.size()));
    return Result<MetricValue>::success(MetricValue{
        decoder.result_codec,
        std::vector<std::byte>(bytes.begin(), bytes.end())});
  }
  const long double result = total.value();
  if (!std::isfinite(result) || !std::isfinite(absolute_total.value())) {
    return fail<MetricValue>(
        "c18.reward_accumulation_nonfinite",
        "the stationary reward or its absolute integral is nonfinite");
  }
  auto exact = exact_long_double(result);
  if (!exact) {
    return Result<MetricValue>::failure(exact.error());
  }
  return Result<MetricValue>::success(
      MetricValue{decoder.result_codec, scalar_bytes(exact.value())});
}

DiagnosticBundle compute_stationary_flux_diagnostics(
    const InvariantLaw& law, const ResolvedInstance& instance) {
  const TransitionMatrix& matrix = law.transition_matrix();
  const auto& matrix_core = detail::C18CoreAccess::core(matrix);
  const ClassDecomposition decomposition =
      analyze_communicating_classes(matrix);
  const auto& flux_core = detail::C18CoreAccess::core(matrix.marked_flux());
  const auto completed_image = numerical_image(flux_core.exact_completed_mass);
  DiagnosticBundle bundle{
      .instance_binding_matches = false,
      .fatal = false,
      .publication_allowed = false,
      .state_count = matrix.size(),
      .nonzero_count = matrix.nonzero_count(),
      .class_count = decomposition.classes().size(),
      .closed_class_count = decomposition.closed_class_indices().size(),
      .completion_kind = flux_core.completion_kind,
      .completion_mark_scope_available =
          flux_core.exact_completed_mass.is_zero() ||
          flux_core.completion_kind !=
              BoundaryCompletionKindV1::state_only_completion,
      .mark_to_endpoint_consistent = false,
      .completed_mass = completed_image.first,
      .exact_completed_mass = flux_core.exact_completed_mass,
      .row_diagnostics = std::vector<MatrixRowDiagnosticV1>(
          matrix.row_diagnostics().begin(), matrix.row_diagnostics().end()),
      .classes = std::vector<CommunicatingClassV1>(
          decomposition.classes().begin(), decomposition.classes().end()),
      .leakage = std::vector<LeakageRecordV1>(
          flux_core.leakage.begin(), flux_core.leakage.end()),
      .invariant = law.solve_diagnostics(),
      .arrival_phase_marginal_available = false,
      .arrival_phase_marginal_matches = false,
      .arrival_phase_marginal = {},
      .expected_departures = std::nullopt,
      .expected_arrivals = std::nullopt,
      .flow_difference = std::nullopt,
      .expected_target_departures = {},
      .expected_target_arrivals = {},
      .target_flow_differences = {},
      .findings = {}};

  bool binding_matches = false;
  if (matrix_core.production_binding.has_value()) {
    const auto& binding = *matrix_core.production_binding;
    binding_matches =
        instance.fingerprints() == binding.instance.fingerprints() &&
        instance.timing() == binding.instance.timing() &&
        instance.arrival().identity() == binding.instance.arrival().identity() &&
        instance.arrival().shares_compiled_product_with(
            binding.instance.arrival()) &&
        QueueDimensionToken::from_instance(instance) ==
            QueueDimensionToken::from_instance(binding.instance);
    if (binding_matches) {
      auto rebuilt = build_framework_problem_view_matching_arrival_projection(
          instance, binding.configured_arrival, binding.target_selection,
          binding.framework.problem_fingerprints.compiled_arrival);
      binding_matches =
          rebuilt.has_value() &&
          instance.fingerprints() ==
              binding.framework.problem_fingerprints.authored_inputs &&
          rebuilt.value().fingerprints() ==
              binding.framework.problem_fingerprints &&
          rebuilt.value().canonical_digest() ==
              binding.framework.problem_view_digest;
    }
  } else if (matrix_core.fixture_binding.has_value()) {
    const auto& fixture = *matrix_core.fixture_binding;
    const ResolvedInstance& bound = fixture.instance;
    binding_matches =
        instance.fingerprints() == bound.fingerprints() &&
        instance.timing() == bound.timing() &&
        instance.arrival().identity() == bound.arrival().identity() &&
        instance.arrival().shares_compiled_product_with(bound.arrival()) &&
        QueueDimensionToken::from_instance(instance) ==
            QueueDimensionToken::from_instance(bound);
    if (binding_matches && fixture.problem_view_digest.has_value()) {
      if (!fixture.configured_arrival.has_value() ||
          !fixture.problem_fingerprints.has_value()) {
        binding_matches = false;
      }
    }
    if (binding_matches && fixture.problem_view_digest.has_value()) {
      auto rebuilt = build_framework_problem_view_matching_arrival_projection(
          instance, *fixture.configured_arrival, fixture.target_selection,
          fixture.problem_fingerprints->compiled_arrival);
      binding_matches =
          rebuilt.has_value() && fixture.problem_fingerprints.has_value() &&
          rebuilt.value().fingerprints() == *fixture.problem_fingerprints &&
          rebuilt.value().canonical_digest().value() ==
              *fixture.problem_view_digest;
    }
  }
  bundle.instance_binding_matches = binding_matches;
  if (!binding_matches) {
    bundle.fatal = true;
    bundle.findings.push_back(finding(
        "c18.diagnostic_instance_binding_mismatch",
        "the supplied instance is not the matrix-bound resolved instance"));
    return bundle;
  }

  bool marked_consistent = flux_core.rows.size() == matrix.size();
  if (marked_consistent) {
    for (std::size_t source = 0; source < matrix.size(); ++source) {
      std::vector<ExactRational> row_mass(
          matrix.size(), ExactRational::zero());
      for (const CompletionBoundMarkedAtomV1& atom :
           flux_core.rows[source].atoms) {
        if (atom.successor_index >= matrix.size() ||
            !atom.exact_mass.is_nonnegative()) {
          marked_consistent = false;
          break;
        }
        row_mass[atom.successor_index] =
            row_mass[atom.successor_index] + atom.exact_mass;
        if (atom.edge.has_value() &&
            (!(atom.edge->pre_state == matrix.states()[source]) ||
             !(atom.edge->successor_state ==
               matrix.states()[atom.successor_index]))) {
          marked_consistent = false;
          break;
        }
        if (atom.edge.has_value() &&
            matrix_core.state_phases.size() == matrix.size() &&
            (!(atom.edge->phase_before == matrix_core.state_phases[source]) ||
             !(atom.edge->phase_after ==
               matrix_core.state_phases[atom.successor_index]))) {
          marked_consistent = false;
          break;
        }
      }
      if (!marked_consistent) {
        break;
      }
      for (std::size_t destination = 0; destination < matrix.size();
           ++destination) {
        if (!(row_mass[destination] ==
              matrix.exact_entry(source, destination))) {
          marked_consistent = false;
          break;
        }
      }
    }
  }
  bundle.mark_to_endpoint_consistent = marked_consistent;
  if (!marked_consistent) {
    bundle.fatal = true;
    bundle.findings.push_back(finding(
        "c18.marked_flux_endpoint_mismatch",
        "the completion-bound marked rows do not push forward to P"));
  }

  if (!matrix_core.configured_phase_states.empty()) {
    bundle.arrival_phase_marginal_available =
        matrix_core.state_phases.size() == matrix.size() &&
        matrix_core.configured_phase_states.size() ==
            matrix_core.configured_phase_masses.size();
    bool phase_matches = bundle.arrival_phase_marginal_available;
    std::vector<CompensatedSum> marginal(
        matrix_core.configured_phase_states.size());
    if (bundle.arrival_phase_marginal_available) {
      for (std::size_t state = 0; state < matrix.size(); ++state) {
        const auto found = std::find(
            matrix_core.configured_phase_states.begin(),
            matrix_core.configured_phase_states.end(),
            matrix_core.state_phases[state]);
        if (found == matrix_core.configured_phase_states.end()) {
          phase_matches = false;
          continue;
        }
        marginal[static_cast<std::size_t>(
                     found - matrix_core.configured_phase_states.begin())]
            .add(law.masses()[state]);
      }
      for (std::size_t phase = 0;
           phase < matrix_core.configured_phase_states.size(); ++phase) {
        const long double invariant_mass = marginal[phase].value();
        const long double configured_mass =
            matrix_core.configured_phase_masses[phase].to_long_double();
        const long double residual = invariant_mass - configured_mass;
        const long double scale =
            std::fabs(invariant_mass) + std::fabs(configured_mass);
        const long double bound =
            residual_bound(matrix_core.bound_solver_policy, scale);
        if (!std::isfinite(invariant_mass) ||
            !std::isfinite(configured_mass) || std::fabs(residual) > bound) {
          phase_matches = false;
        }
        bundle.arrival_phase_marginal.push_back(PhaseMarginalAtomV1{
            matrix_core.configured_phase_states[phase], invariant_mass,
            configured_mass, residual, bound});
      }
    }
    bundle.arrival_phase_marginal_matches = phase_matches;
    if (!phase_matches) {
      bundle.fatal = true;
      bundle.findings.push_back(finding(
          "c18.arrival_phase_marginal_mismatch",
          "the invariant H^A marginal differs from configured varpi_A"));
    }
  }

  const bool physical_scope =
      marked_consistent &&
      (flux_core.exact_completed_mass.is_zero() ||
       (flux_core.completion_kind ==
            BoundaryCompletionKindV1::marked_completion &&
        flux_core.physical_mark_preserving));
  if (physical_scope) {
    std::optional<std::size_t> target_count;
    bool flow_available = true;
    for (std::size_t source = 0; source < matrix.size(); ++source) {
      if (law.masses()[source] == 0.0L) {
        continue;
      }
      for (const auto& atom : flux_core.rows[source].atoms) {
        if (!atom.exact_mass.is_positive()) {
          continue;
        }
        if (!atom.edge.has_value()) {
          flow_available = false;
          break;
        }
        const std::size_t edge_targets = atom.edge->target_departures.size();
        if (atom.edge->target_arrivals.size() != edge_targets ||
            (target_count.has_value() && *target_count != edge_targets)) {
          flow_available = false;
          break;
        }
        target_count = edge_targets;
      }
    }
    if (flow_available && target_count.has_value()) {
      std::vector<CompensatedSum> departures(*target_count);
      std::vector<CompensatedSum> arrivals(*target_count);
      for (std::size_t source = 0; source < matrix.size(); ++source) {
        if (law.masses()[source] == 0.0L) {
          continue;
        }
        for (const auto& atom : flux_core.rows[source].atoms) {
          if (!atom.exact_mass.is_positive() || !atom.edge.has_value()) {
            continue;
          }
          for (std::size_t target = 0; target < *target_count; ++target) {
            const ExactRational exact_departure =
                exact_probability_count_product(
                    atom.exact_mass,
                    BigNat(atom.edge->target_departures[target]));
            const ExactRational exact_arrival =
                exact_probability_count_product(
                    atom.exact_mass,
                    atom.edge->target_arrivals[target]);
            const long double departure_term =
                law.masses()[source] * exact_departure.to_long_double();
            const long double arrival_term =
                law.masses()[source] * exact_arrival.to_long_double();
            if (!std::isfinite(departure_term) ||
                !std::isfinite(arrival_term)) {
              flow_available = false;
              break;
            }
            departures[target].add(departure_term);
            arrivals[target].add(arrival_term);
          }
          if (!flow_available) {
            break;
          }
        }
        if (!flow_available) {
          break;
        }
      }
      if (flow_available) {
        for (std::size_t target = 0; target < *target_count; ++target) {
          const long double departure = departures[target].value();
          const long double arrival = arrivals[target].value();
          if (!std::isfinite(departure) || !std::isfinite(arrival)) {
            flow_available = false;
            break;
          }
          bundle.expected_target_departures.push_back(departure);
          bundle.expected_target_arrivals.push_back(arrival);
          bundle.target_flow_differences.push_back(arrival - departure);
        }
      }
      if (!flow_available) {
        bundle.expected_target_departures.clear();
        bundle.expected_target_arrivals.clear();
        bundle.target_flow_differences.clear();
      } else if (*target_count == 1U) {
        bundle.expected_departures = departures.front().value();
        bundle.expected_arrivals = arrivals.front().value();
        bundle.flow_difference = arrivals.front().value() -
                                 departures.front().value();
      }
    }
  }
  bundle.publication_allowed = !bundle.fatal;
  return bundle;
}

#if defined(MWPERF_C18_TEST_SEAMS)

namespace testing {

Result<TransitionMatrix> C18FixtureAccess::transition_matrix(
    C18ExactMatrixFixtureV1 fixture) {
  auto policy_valid = validate_policy(fixture.bound_solver_policy);
  if (!policy_valid) {
    return Result<TransitionMatrix>::failure(policy_valid.error());
  }
  const std::size_t count = fixture.states.size();
  if (count == 0U || fixture.exact_entries.size() != count * count ||
      (fixture.numerical_entries.has_value() &&
       fixture.numerical_entries->size() != count * count) ||
      (!fixture.marked_rows.empty() &&
       fixture.marked_rows.size() != count)) {
    return fail<TransitionMatrix>(
        "c18.fixture_matrix_dimension",
        "the direct rational fixture dimensions are inconsistent");
  }
  auto bound_selection = selection_identity(fixture.bound_selection);
  if (!bound_selection) {
    return Result<TransitionMatrix>::failure(bound_selection.error());
  }
  auto bound_selector_digest = selector_digest(bound_selection.value());
  if (!bound_selector_digest) {
    return Result<TransitionMatrix>::failure(bound_selector_digest.error());
  }
  const bool has_bound_instance = fixture.bound_instance.has_value();
  const bool has_bound_arrival =
      fixture.bound_configured_arrival.has_value();
  const bool has_bound_targets = fixture.bound_target_selection.has_value();
  const bool has_exact_phase_kernel =
      fixture.configured_phase_kernel.has_value();
  const bool has_any_binding = has_bound_instance || has_bound_arrival ||
                               has_bound_targets || has_exact_phase_kernel;
  if (has_bound_arrival && has_exact_phase_kernel) {
    return fail<TransitionMatrix>(
        "c18.fixture_phase_authority_ambiguous",
        "a test-only phase law must have exactly one K_A authority");
  }
  if (has_any_binding &&
      !(has_bound_instance && has_bound_targets &&
        (has_bound_arrival || has_exact_phase_kernel))) {
    return fail<TransitionMatrix>(
        "c18.fixture_binding_incomplete",
        "the test-only phase authority requires its instance and target "
        "binding plus a compiled arrival or exact K_A");
  }
  if (!has_bound_instance &&
      (!fixture.configured_phase_states.empty() ||
       !fixture.configured_phase_masses.empty())) {
    return fail<TransitionMatrix>(
        "c18.fixture_phase_law_unbound",
        "a configured phase law requires its exact test-only binding");
  }

  std::optional<stationary::detail::FixtureBinding> fixture_binding;
  if (has_bound_instance) {
    const ResolvedInstance& bound = *fixture.bound_instance;
    const TargetSelection& targets = *fixture.bound_target_selection;
    if (!bound.analysis_spec().context) {
      return fail<TransitionMatrix>(
          "c18.fixture_analysis_context_missing",
          "a bound C18 fixture requires its resolved Analysis-v1 context");
    }
    auto fixture_analysis_selection =
        artifact::detail::canonical_analysis_selection_digest_v1(
            fixture.bound_selection);
    auto instance_analysis_selection =
        artifact::detail::canonical_analysis_selection_digest_v1(
            bound.analysis_spec().context->selection);
    if (!fixture_analysis_selection || !instance_analysis_selection ||
        fixture_analysis_selection.value() !=
            instance_analysis_selection.value()) {
      return fail<TransitionMatrix>(
          "c18.fixture_selection_binding_mismatch",
          "the fixture selection differs from its bound Analysis-v1 "
          "selection");
    }
    auto instance_policy = solver_policy(bound);
    if (!instance_policy ||
        !(fixture.bound_solver_policy == instance_policy.value())) {
      return fail<TransitionMatrix>(
          "c18.fixture_solver_binding_mismatch",
          "the fixture solver policy differs from its bound Analysis-v1 "
          "policy");
    }
    if (!fixture.exact_state_schema_digest.has_value() ||
        !nonzero_digest(*fixture.exact_state_schema_digest) ||
        !fixture.reduced_state_schema_digest.has_value() ||
        !nonzero_digest(*fixture.reduced_state_schema_digest)) {
      return fail<TransitionMatrix>(
          "c18.fixture_state_schema_binding_missing",
          "a bound fixture requires exact and reduced state-schema "
          "identities");
    }
    std::vector<QueueId> expected_targets;
    expected_targets.reserve(bound.targets().size());
    for (const auto& target : bound.targets().values()) {
      expected_targets.push_back(bound.queues().queue_id(target.queue));
    }
    if (targets.schema_version != 1U || targets.ordered_targets.empty() ||
        targets.ordered_targets != expected_targets) {
      return fail<TransitionMatrix>(
          "c18.fixture_target_binding_mismatch",
          "the fixture target selection differs from its bound instance");
    }
    std::optional<FrameworkProblemFingerprintsV1> problem_fingerprints;
    std::optional<Digest256> problem_view_digest;
    if (has_bound_arrival) {
      const CompiledArrivalLaw& configured_arrival =
          *fixture.bound_configured_arrival;
      const BuilderArrivalView arrival_view =
          builder_arrival_view(configured_arrival);
      if (arrival_view.version() != 1U ||
          arrival_view.binding().timing != bound.timing() ||
          arrival_view.binding().queue_cardinality != bound.queues().size()) {
        return fail<TransitionMatrix>(
            "c18.fixture_configured_arrival_binding_mismatch",
            "the fixture configured arrival differs in timing or queue "
            "dimension from its bound instance");
      }
      std::vector<ArrivalPhaseIdentityV1> expected_phase_states;
      std::vector<ExactRational> expected_phase_masses;
      if (arrival_view.stationary_phase_law().has_value()) {
        const StationaryPhaseLawDescriptor& phase_law =
            *arrival_view.stationary_phase_law();
        if (phase_law.canonical_states.size() !=
            phase_law.probabilities.normalized_weights().size()) {
          return fail<TransitionMatrix>(
              "c18.fixture_configured_phase_law_dimension",
              "the bound configured phase law has inconsistent dimensions");
        }
        expected_phase_states.reserve(phase_law.canonical_states.size());
        expected_phase_masses.reserve(phase_law.canonical_states.size());
        for (std::size_t phase = 0;
             phase < phase_law.canonical_states.size(); ++phase) {
          expected_phase_states.push_back(ArrivalPhaseIdentityV1{
              configured_arrival.family(),
              phase_law.canonical_states[phase]});
          expected_phase_masses.push_back(
              phase_law.probabilities.normalized_weights()[phase]);
        }
      }
      if (fixture.configured_phase_states != expected_phase_states ||
          fixture.configured_phase_masses != expected_phase_masses) {
        return fail<TransitionMatrix>(
            "c18.fixture_phase_law_binding_mismatch",
            "the fixture phase law differs from its bound configured arrival "
            "law");
      }
      auto problem =
          build_framework_problem_view(bound, configured_arrival, targets);
      if (!problem) {
        return Result<TransitionMatrix>::failure(problem.error());
      }
      problem_fingerprints = problem.value().fingerprints();
      problem_view_digest = problem.value().canonical_digest().value();
    }
    fixture_binding.emplace(stationary::detail::FixtureBinding{
        bound, targets, fixture.bound_configured_arrival,
        std::move(problem_fingerprints), std::move(problem_view_digest)});
  }

  std::vector<std::size_t> order(count);
  std::iota(order.begin(), order.end(), 0U);
  std::sort(order.begin(), order.end(), [&](const std::size_t left,
                                             const std::size_t right) {
    return state_less(fixture.states[left], fixture.states[right]);
  });
  std::vector<std::size_t> new_index(count);
  std::vector<ReducedStateV1> states;
  states.reserve(count);
  for (std::size_t canonical = 0; canonical < count; ++canonical) {
    new_index[order[canonical]] = canonical;
    states.push_back(fixture.states[order[canonical]]);
    if (canonical != 0U && states[canonical] == states[canonical - 1U]) {
      return fail<TransitionMatrix>("c18.duplicate_state",
                                    "the fixture domain has duplicate states");
    }
  }
  std::vector<ExactRational> exact_entries(count * count,
                                           ExactRational::zero());
  std::vector<long double> numerical_entries(count * count, 0.0L);
  std::vector<std::uint8_t> support(count * count, 0U);
  std::vector<MatrixRowDiagnosticV1> row_diagnostics;
  std::size_t nonzero_count = 0U;
  for (std::size_t row = 0; row < count; ++row) {
    ExactRational row_total = ExactRational::zero();
    CompensatedSum numerical_total;
    for (std::size_t column = 0; column < count; ++column) {
      const std::size_t original_offset =
          order[row] * count + order[column];
      const std::size_t offset = row * count + column;
      const ExactRational& exact = fixture.exact_entries[original_offset];
      if (!exact.is_nonnegative()) {
        return fail<TransitionMatrix>("c18.negative_transition",
                                      "a fixture matrix entry is negative");
      }
      exact_entries[offset] = exact;
      row_total = row_total + exact;
      const long double image = fixture.numerical_entries.has_value()
                                    ? (*fixture.numerical_entries)[original_offset]
                                    : exact.to_long_double();
      if (!std::isfinite(image) || image < 0.0L) {
        return fail<TransitionMatrix>(
            "c18.nonfinite_transition_image",
            "a fixture numerical matrix entry is negative or nonfinite");
      }
      numerical_entries[offset] = image;
      numerical_total.add(image);
      if (exact.is_positive()) {
        support[offset] = 1U;
        ++nonzero_count;
      }
    }
    if (!(row_total == ExactRational::one())) {
      return fail<TransitionMatrix>(
          "c18.matrix_row_mass_not_one",
          "a fixture exact row does not total exactly one");
    }
    const long double image_total = numerical_total.value();
    const long double residual = image_total - 1.0L;
    const long double bound =
        residual_bound(fixture.bound_solver_policy, 1.0L);
    if (std::fabs(residual) > bound) {
      return fail<TransitionMatrix>(
          "c18.matrix_row_numerical_residual",
          "the fixture numerical row residual exceeds its bound");
    }
    row_diagnostics.push_back(MatrixRowDiagnosticV1{
        row, std::move(row_total), image_total, residual, bound});
  }

  std::vector<CompletionBoundMarkedRowV1> marked_rows(count);
  if (!fixture.marked_rows.empty()) {
    for (std::size_t row = 0; row < count; ++row) {
      const auto& original_row = fixture.marked_rows[order[row]];
      std::vector<ExactRational> marked_total(count, ExactRational::zero());
      for (CompletionBoundMarkedAtomV1 atom : original_row.atoms) {
        if (atom.successor_index >= count ||
            !atom.exact_mass.is_nonnegative()) {
          return fail<TransitionMatrix>(
              "c18.fixture_marked_flux_invalid",
              "a fixture marked atom has an invalid destination or mass");
        }
        atom.successor_index = new_index[atom.successor_index];
        atom.numerical_image = atom.exact_mass.to_long_double();
        if (atom.completed_from_leakage &&
            fixture.completion_kind ==
                BoundaryCompletionKindV1::exact_closed) {
          return fail<TransitionMatrix>(
              "c18.fixture_exact_closed_has_completion",
              "an exact-closed fixture cannot mark any atom as completed");
        }
        if (atom.edge.has_value() &&
            (!(atom.edge->pre_state == states[row]) ||
             !(atom.edge->successor_state ==
               states[atom.successor_index]))) {
          return fail<TransitionMatrix>(
              "c18.fixture_marked_endpoint_mismatch",
              "a fixture marked edge does not bind its row/destination");
        }
        if (atom.edge.has_value()) {
          const MarkedFluxEdgeV1& edge = *atom.edge;
          const std::size_t targets = edge.prearrival_target_backlog.size();
          if (targets == 0U || edge.target_departures.size() != targets ||
              edge.target_arrivals.size() != targets) {
            return fail<TransitionMatrix>(
                "c18.fixture_marked_target_dimension",
                "a fixture marked edge requires equal nonempty n/D/A vectors");
          }
          if (fixture.bound_instance.has_value() &&
              targets != fixture.bound_instance->targets().size()) {
            return fail<TransitionMatrix>(
                "c18.fixture_target_binding_mismatch",
                "a fixture marked edge dimension differs from the bound "
                "target selection");
          }
          for (std::size_t target = 0; target < targets; ++target) {
            if (edge.target_departures[target] > 1U ||
                !checked_subtract(edge.prearrival_target_backlog[target],
                                  BigNat(edge.target_departures[target]))) {
              return fail<TransitionMatrix>(
                  "c18.departure_exceeds_backlog",
                  "a fixture marked edge has D greater than n");
            }
          }
          if (!fixture.state_phases.empty() &&
              (!(edge.phase_before == fixture.state_phases[order[row]]) ||
               !(edge.phase_after ==
                 fixture.state_phases[order[atom.successor_index]]))) {
            return fail<TransitionMatrix>(
                "c18.fixture_marked_phase_mismatch",
                "a fixture marked edge phase differs from its endpoint phase");
          }
          if (atom.completed_from_leakage &&
              fixture.completion_kind ==
                  BoundaryCompletionKindV1::state_only_completion) {
            return fail<TransitionMatrix>(
                "c18.fixture_state_only_completion_has_edge",
                "state-only completed fixture mass cannot retain an edge");
          }
        } else if (atom.completed_from_leakage &&
                   fixture.completion_kind ==
                       BoundaryCompletionKindV1::marked_completion) {
          return fail<TransitionMatrix>(
              "c18.fixture_marked_completion_missing_edge",
              "marked completed fixture mass requires a transformed edge");
        }
        marked_total[atom.successor_index] =
            marked_total[atom.successor_index] + atom.exact_mass;
        marked_rows[row].atoms.push_back(std::move(atom));
      }
      for (std::size_t column = 0; column < count; ++column) {
        if (!(marked_total[column] == exact_entries[row * count + column])) {
          return fail<TransitionMatrix>(
              "c18.fixture_marked_pushforward_mismatch",
              "fixture marked masses do not push forward to the exact matrix");
        }
      }
    }
  } else {
    for (std::size_t row = 0; row < count; ++row) {
      for (std::size_t column = 0; column < count; ++column) {
        const ExactRational& mass = exact_entries[row * count + column];
        if (mass.is_positive()) {
          marked_rows[row].atoms.push_back(CompletionBoundMarkedAtomV1{
              column, mass, mass.to_long_double(), false, std::nullopt});
        }
      }
    }
  }
  ExactRational completed_mass = ExactRational::zero();
  for (const auto& row : marked_rows) {
    for (const auto& atom : row.atoms) {
      if (atom.completed_from_leakage) {
        completed_mass = completed_mass + atom.exact_mass;
      }
    }
  }
  if (fixture.completion_kind != BoundaryCompletionKindV1::exact_closed &&
      (!fixture.completion_identity.has_value() ||
       !nonzero_digest(*fixture.completion_identity))) {
    return fail<TransitionMatrix>(
        "c18.fixture_completion_identity",
        "a fixture computational completion requires its identity");
  }
  if (fixture.completion_kind == BoundaryCompletionKindV1::exact_closed &&
      (!fixture.physical_mark_preserving || !completed_mass.is_zero())) {
    return fail<TransitionMatrix>(
        "c18.fixture_invalid_exact_closed_boundary",
        "an exact-closed fixture must preserve the original marked law and "
        "cannot carry completion mass");
  }
  if (fixture.completion_kind ==
          BoundaryCompletionKindV1::state_only_completion &&
      fixture.physical_mark_preserving) {
    return fail<TransitionMatrix>(
        "c18.fixture_state_only_completion_not_mark_preserving",
        "a state-only fixture completion cannot claim mark preservation");
  }
  auto flux_core =
      std::make_shared<stationary::detail::CompletionBoundMarkedFluxCore>(
          stationary::detail::CompletionBoundMarkedFluxCore{
              fixture.completion_kind, fixture.completion_identity,
              fixture.physical_mark_preserving,
              std::move(marked_rows), {}, completed_mass});
  CompletionBoundMarkedFlux flux =
      detail::C18CoreAccess::marked_flux(std::move(flux_core));
  if (!fixture.state_phases.empty() && fixture.state_phases.size() != count) {
    return fail<TransitionMatrix>(
        "c18.fixture_state_phase_dimension",
        "fixture state-phase identities must match the domain size");
  }
  std::vector<ArrivalPhaseIdentityV1> state_phases;
  if (!fixture.state_phases.empty()) {
    state_phases.reserve(count);
    for (const std::size_t original : order) {
      state_phases.push_back(fixture.state_phases[original]);
    }
  }
  if (fixture.configured_phase_states.size() !=
      fixture.configured_phase_masses.size()) {
    return fail<TransitionMatrix>(
        "c18.fixture_phase_law_dimension",
        "fixture configured phase states and masses have different sizes");
  }
  for (std::size_t phase = 0;
       phase < fixture.configured_phase_states.size(); ++phase) {
    if (std::find(fixture.configured_phase_states.begin(),
                  fixture.configured_phase_states.begin() +
                      static_cast<std::ptrdiff_t>(phase),
                  fixture.configured_phase_states[phase]) !=
        fixture.configured_phase_states.begin() +
            static_cast<std::ptrdiff_t>(phase)) {
      return fail<TransitionMatrix>(
          "c18.fixture_duplicate_phase_identity",
          "configured phase identities must be unique");
    }
  }
  if (!fixture.configured_phase_masses.empty()) {
    ExactRational phase_total = ExactRational::zero();
    for (const auto& mass : fixture.configured_phase_masses) {
      if (!mass.is_nonnegative()) {
        return fail<TransitionMatrix>("c18.fixture_negative_phase_mass",
                                      "a configured phase mass is negative");
      }
      phase_total = phase_total + mass;
    }
    if (!(phase_total == ExactRational::one())) {
      return fail<TransitionMatrix>(
          "c18.fixture_phase_mass_not_one",
          "configured phase masses must total exactly one");
    }
  }
  if (fixture.configured_phase_kernel.has_value()) {
    const std::size_t phase_count = fixture.configured_phase_states.size();
    const auto& phase_kernel = *fixture.configured_phase_kernel;
    if (phase_count == 0U ||
        phase_kernel.size() != phase_count * phase_count) {
      return fail<TransitionMatrix>(
          "c18.fixture_phase_kernel_dimension",
          "the exact configured phase kernel must be square on its phase "
          "identities");
    }
    for (std::size_t source_phase = 0; source_phase < phase_count;
         ++source_phase) {
      ExactRational row_total = ExactRational::zero();
      for (std::size_t next_phase = 0; next_phase < phase_count;
           ++next_phase) {
        const ExactRational& mass =
            phase_kernel[source_phase * phase_count + next_phase];
        if (!mass.is_nonnegative()) {
          return fail<TransitionMatrix>(
              "c18.fixture_negative_phase_transition",
              "an exact configured phase transition is negative");
        }
        row_total = row_total + mass;
      }
      if (!(row_total == ExactRational::one())) {
        return fail<TransitionMatrix>(
            "c18.fixture_phase_kernel_row_mass_not_one",
            "each exact configured phase-kernel row must total one");
      }
    }
    for (std::size_t next_phase = 0; next_phase < phase_count;
         ++next_phase) {
      ExactRational invariant_image = ExactRational::zero();
      for (std::size_t source_phase = 0; source_phase < phase_count;
           ++source_phase) {
        invariant_image =
            invariant_image +
            fixture.configured_phase_masses[source_phase] *
                phase_kernel[source_phase * phase_count + next_phase];
      }
      if (!(invariant_image ==
            fixture.configured_phase_masses[next_phase])) {
        return fail<TransitionMatrix>(
            "c18.fixture_phase_law_not_invariant",
            "the exact configured phase law does not satisfy varpi_A K_A = "
            "varpi_A");
      }
    }
    if (state_phases.size() != count) {
      return fail<TransitionMatrix>(
          "c18.fixture_phase_pushforward_unavailable",
          "SF.6 requires one configured phase identity for every matrix "
          "state");
    }
    std::vector<std::size_t> phase_indices;
    phase_indices.reserve(count);
    for (const ArrivalPhaseIdentityV1& state_phase : state_phases) {
      const auto found = std::find(fixture.configured_phase_states.begin(),
                                   fixture.configured_phase_states.end(),
                                   state_phase);
      if (found == fixture.configured_phase_states.end()) {
        return fail<TransitionMatrix>(
            "c18.fixture_unknown_state_phase",
            "a matrix state has no configured phase-kernel coordinate");
      }
      phase_indices.push_back(static_cast<std::size_t>(
          found - fixture.configured_phase_states.begin()));
    }
    for (std::size_t source = 0; source < count; ++source) {
      std::vector<ExactRational> pushforward(
          phase_count, ExactRational::zero());
      for (std::size_t destination = 0; destination < count;
           ++destination) {
        pushforward[phase_indices[destination]] =
            pushforward[phase_indices[destination]] +
            exact_entries[source * count + destination];
      }
      for (std::size_t next_phase = 0; next_phase < phase_count;
           ++next_phase) {
        if (!(pushforward[next_phase] ==
              phase_kernel[phase_indices[source] * phase_count +
                           next_phase])) {
          return fail<TransitionMatrix>(
              "c18.fixture_phase_pushforward_mismatch",
              "an exact matrix row does not satisfy the configured SF.6 "
              "phase pushforward");
        }
      }
    }
  }
  const Digest256 placeholder = Sha256().finalize();
  auto matrix_core = std::make_shared<stationary::detail::TransitionMatrixCore>(
      stationary::detail::TransitionMatrixCore{
          std::move(states), std::move(exact_entries),
          std::move(numerical_entries), std::move(support), nonzero_count,
          std::move(row_diagnostics), std::move(flux), placeholder,
          std::move(bound_selection).value(),
          std::move(bound_selector_digest).value(),
          fixture.bound_solver_policy, std::nullopt,
          std::move(fixture_binding),
          std::move(fixture.exact_state_schema_digest),
          std::move(fixture.reduced_state_schema_digest),
          std::move(state_phases),
          std::move(fixture.configured_phase_states),
          std::move(fixture.configured_phase_masses),
          std::move(fixture.configured_phase_kernel)});
  auto identity = matrix_identity(*matrix_core);
  if (!identity) {
    return Result<TransitionMatrix>::failure(identity.error());
  }
  matrix_core->matrix_identity = std::move(identity).value();
  return Result<TransitionMatrix>::success(
      detail::C18CoreAccess::transition_matrix(std::move(matrix_core)));
}

Result<long double> C18FixtureAccess::decode_metric_scalar(
    const MetricValue& value) {
  const std::string encoded(
      reinterpret_cast<const char*>(value.canonical_value.data()),
      value.canonical_value.size());
  const std::size_t slash = encoded.find('/');
  if (slash == std::string::npos || slash == 0U ||
      slash + 1U == encoded.size()) {
    return fail<long double>("c18.fixture_metric_scalar_encoding",
                             "the metric value is not a canonical rational");
  }
  try {
    BigInt numerator(encoded.substr(0U, slash));
    BigInt denominator(encoded.substr(slash + 1U));
    auto exact =
        ExactRational::make(std::move(numerator), std::move(denominator));
    if (!exact) {
      return Result<long double>::failure(exact.error());
    }
    return Result<long double>::success(exact.value().to_long_double());
  } catch (const std::exception&) {
    return fail<long double>("c18.fixture_metric_scalar_encoding",
                             "the metric rational bytes are malformed");
  }
}

}  // namespace testing

#endif

}  // namespace mwperf
