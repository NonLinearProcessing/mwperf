#include "mwperf/stationary/analytic.hpp"

#include <Eigen/Dense>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <numeric>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "kernel/c17_core_internal.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/stationary/finite_prefix_fit.hpp"
#include "mwperf/stationary/finite_prefix_summary.hpp"
#include "mwperf/stationary/three_bin_summary.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "stationary/c19_carrier_internal.hpp"

namespace mwperf {

namespace stationary::detail {

struct StationaryAnalyticLawIdentityCore final {
  AuditedFrameworkBindingsV1 framework;
  ArtifactValidationBindingsV1 artifact;
  Digest256 execution_seal_digest;
  std::optional<Digest256> carrier_snapshot_digest;
  ArtifactObjectReferenceV1 payload;
  std::optional<MetricClauseIdV1> accepted_metric_clause;
  std::optional<RealizedMetricBindingV1> realized_metric_binding;
  PayloadPhaseKindV1 payload_phase;
  std::optional<ResponseProductStageV1> response_stage;
  std::optional<ArtifactObjectReferenceV1> response_product;
  std::optional<ArtifactObjectReferenceV1> derivation;
  std::optional<BigNat> cutoff;
  std::optional<ExactRational> tail_service;
  ArrivalBinding configured_arrival;
  PortableAnalysisSelectionV1 selection;
  QueueId target;
  std::vector<QueueId> construction_targets;
  MetricResultScopeV1 result_scope;
};

struct ArrivalLawCore final {
  std::vector<ScalarArrivalMassV1> atoms;
  std::vector<ExactRational> reverse_survival;
  ExactRational mean;
  std::optional<ExactRational> second_moment;
  ArrivalBinding configured_arrival;
  QueueId target;
  Digest256 identity_digest;
  std::shared_ptr<const void> arrival_identity;
  std::shared_ptr<const void> seal;
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> sealed;
  StationaryAnalyticLawIdentityV1 identity;
  std::vector<C19ScalarSelectionSeedAtomV1> selection_seed;
};

struct ArrivalPmfCore final {
  std::shared_ptr<const ArrivalLawCore> law;
};

struct BernoulliRateCore final {
  ExactRational value;
  std::shared_ptr<const ArrivalLawCore> law;
};

struct ArrivalTransformCore final {
  std::shared_ptr<const ArrivalLawCore> law;
};

struct ScalarResponseData final {
  std::vector<ExactRational> prefix;
  std::optional<BigNat> constant_tail_from;
  std::optional<ExactRational> constant_tail_service;
};

struct ScalarFluxOperatorCore final {
  std::shared_ptr<const ArrivalLawCore> arrival;
  ScalarResponseData response;
  StationaryAnalyticLawIdentityV1 identity;
};

enum class ScalarLawRepresentation : std::uint8_t {
  finite,
  constant_tail,
  incomplete,
};

struct ScalarStationaryLawCore final {
  AnalyticStationaryStatusV1 status;
  bool normalized;
  ScalarLawRepresentation representation;
  std::vector<ExactRational> prefix_masses;
  std::optional<ExactRational> exact_tail_mass;
  std::optional<ExactRational> exact_mean_backlog;
  std::optional<long double> numerical_mean_backlog;
  AnalyticStationaryDiagnosticsV1 diagnostics;
  StationaryAnalyticLawIdentityV1 identity;
  std::shared_ptr<const ScalarFluxOperatorCore> flux;
  std::optional<BigNat> cutoff;
  std::optional<ExactRational> tail_service;
  std::optional<ScalarFiniteClosureProofV1> finite_closure_proof;
};

struct TransformReadoutCore final {
  AnalyticStationaryStatusV1 status;
  EvaluationPoint point;
  std::optional<ExactRational> exact_pgf;
  std::optional<long double> numerical_pgf;
  std::optional<ExactRational> exact_response_weighted_pgf;
  std::optional<long double> numerical_response_weighted_pgf;
  std::optional<ExactRational> exact_mean_backlog;
  StationaryAnalyticLawIdentityV1 identity;
};

struct PhaseArrivalKernelCore final {
  std::vector<ArrivalPhaseIdentityV1> phases;
  std::vector<ExactPhaseArrivalBlockV1> blocks;
  std::vector<ExactRational> configured_phase_marginal;
  std::vector<ExactRational> service_row_major;
  PhaseLevelCompletionV1 completion;
  StationaryAnalyticLawIdentityV1 identity;
  std::shared_ptr<const AuditedPhaseResponseCarrierCore> carrier;
  std::shared_ptr<const void> seal;
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> sealed;
};

struct BlockFluxOperatorCore final {
  std::shared_ptr<const PhaseArrivalKernelCore> arrival;
  std::size_t phase_count;
  std::size_t level_count;
  std::vector<ExactRational> entries;
  StationaryAnalyticLawIdentityV1 identity;
};

struct PhaseStationaryLawCore final {
  AnalyticStationaryStatusV1 status;
  std::vector<long double> masses;
  std::vector<SelectedInvariantClassV1> selected_classes;
  std::vector<PhaseMarginalAtomV1> phase_marginal;
  InvariantSolveDiagnosticsV1 diagnostics;
  StationaryAnalyticLawIdentityV1 identity;
  std::shared_ptr<const BlockFluxOperatorCore> flux;
};

struct FixedPointLawCore final {
  FixedPointTerminationV1 termination;
  std::vector<ExactRational> parameters;
  ExactRational iterate_difference;
  ExactRational fixed_point_residual;
  BigNat iteration_count;
  BigNat evaluation_count;
  Digest256 selector_digest;
  StationaryAnalyticLawIdentityV1 identity;
  std::shared_ptr<const AuditedFixedPointCarrierCore> carrier;
};

struct StationaryConditioningMassCore final {
  StationaryConditioningMassKindV1 kind;
  std::optional<ExactRational> mass;
  std::optional<StationaryConditioningRegionV1> region;
};

struct ThreeBinIidSummaryCore final {
  std::array<ThreeBinStationaryAtomV1, 4U> bins;
  std::optional<ExactRational> pi_zero;
  std::optional<ExactRational> pi_one;
  std::optional<ExactRational> pi_two;
  std::optional<ExactRational> tail_mass_from_three;
  ExactRational mu_zero;
  ExactRational mu_one;
  ExactRational mu_two;
  ExactRational mu_tail_from_three;
  ExactRational arrival_mean;
  std::optional<ExactRational> exact_mean_backlog;
  std::optional<long double> numerical_mean_backlog;
  std::optional<ExactRational> exact_mean_sojourn;
  std::optional<long double> numerical_mean_sojourn;
  MeanSojournCountingConventionV1 sojourn_counting_convention;
  TailSlackApplicabilityV1 tail_slack_applicability;
  std::optional<ExactRational> tail_slack;
  AnalyticStationaryStatusV1 status;
  AnalyticStationaryDiagnosticsV1 diagnostics;
  StationaryAnalyticLawIdentityV1 identity;
};

struct FinitePrefixIidSummaryCore final {
  BigNat cutoff;
  std::vector<ExactRational> service_by_level;
  FinitePrefixConstantTailCoefficientV1 tail_coefficient;
  std::optional<std::vector<ExactRational>> prefix_masses;
  std::optional<ExactRational> aggregate_tail_mass;
  ExactRational arrival_mean;
  std::optional<ExactRational> exact_mean_backlog;
  std::optional<long double> numerical_mean_backlog;
  std::optional<ExactRational> exact_mean_sojourn;
  std::optional<long double> numerical_mean_sojourn;
  MeanSojournCountingConventionV1 sojourn_counting_convention;
  TailSlackApplicabilityV1 tail_slack_applicability;
  std::optional<ExactRational> tail_slack;
  AnalyticStationaryStatusV1 status;
  AnalyticStationaryDiagnosticsV1 diagnostics;
  ArtifactObjectReferenceV1 response_identity;
  ArtifactObjectReferenceV1 response_product_identity;
  StationaryAnalyticLawIdentityV1 law_identity;
};

}  // namespace stationary::detail

namespace detail {

class C19CoreAccess final {
 public:
  C19CoreAccess() = delete;

  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  sealed(const AuditedResponseLaw& response) {
    return response.core_;
  }
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  sealed(const AuditedThreeBinResponse& response) {
    return response.core_;
  }
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  sealed(const AuditedPhaseResponse& response) {
    return response.core_;
  }
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  sealed(const AuditedFixedPointFamily& family) {
    return family.core_;
  }
  [[nodiscard]] static std::shared_ptr<const
      stationary::detail::AuditedScalarResponseCarrierCore>
  carrier(const AuditedResponseLaw& response) {
    return response.c19_carrier_;
  }
  [[nodiscard]] static std::shared_ptr<const
      stationary::detail::AuditedScalarResponseCarrierCore>
  carrier(const AuditedThreeBinResponse& response) {
    return response.c19_carrier_;
  }
  [[nodiscard]] static std::shared_ptr<const
      stationary::detail::AuditedPhaseResponseCarrierCore>
  carrier(const AuditedPhaseResponse& response) {
    return response.c19_carrier_;
  }
  [[nodiscard]] static std::shared_ptr<const
      stationary::detail::AuditedFixedPointCarrierCore>
  carrier(const AuditedFixedPointFamily& family) {
    return family.c19_carrier_;
  }
  [[nodiscard]] static AuditedResponseLaw scalar_restriction(
      const AuditedThreeBinResponse& response) {
    return AuditedResponseLaw(response.core_, response.c19_carrier_);
  }
  [[nodiscard]] static AuditedResponseLaw scalar_response(
      std::shared_ptr<const
                      stationary::detail::AuditedScalarResponseCarrierCore>
          carrier) {
    return AuditedResponseLaw(nullptr, std::move(carrier));
  }
  [[nodiscard]] static AuditedThreeBinResponse three_bin_response(
      std::shared_ptr<const
                      stationary::detail::AuditedScalarResponseCarrierCore>
          carrier) {
    return AuditedThreeBinResponse(nullptr, std::move(carrier));
  }
  [[nodiscard]] static AuditedPhaseResponse phase_response(
      std::shared_ptr<const
                      stationary::detail::AuditedPhaseResponseCarrierCore>
          carrier) {
    return AuditedPhaseResponse(nullptr, std::move(carrier));
  }
  [[nodiscard]] static AuditedFixedPointFamily fixed_point_family(
      std::shared_ptr<const
                      stationary::detail::AuditedFixedPointCarrierCore>
          carrier) {
    return AuditedFixedPointFamily(nullptr, std::move(carrier));
  }

  [[nodiscard]] static ArrivalLaw arrival_law(
      std::shared_ptr<const stationary::detail::ArrivalLawCore> core) {
    return ArrivalLaw(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::ArrivalLawCore& core(
      const ArrivalLaw& law) {
    return *law.core_;
  }
  [[nodiscard]] static std::shared_ptr<const stationary::detail::ArrivalLawCore>
  core_ptr(const ArrivalLaw& law) {
    return law.core_;
  }
  [[nodiscard]] static ArrivalPmf arrival_pmf(
      std::shared_ptr<const stationary::detail::ArrivalPmfCore> core) {
    return ArrivalPmf(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::ArrivalPmfCore& core(
      const ArrivalPmf& pmf) {
    return *pmf.core_;
  }
  [[nodiscard]] static BernoulliRate bernoulli_rate(
      std::shared_ptr<const stationary::detail::BernoulliRateCore> core) {
    return BernoulliRate(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::BernoulliRateCore& core(
      const BernoulliRate& rate) {
    return *rate.core_;
  }
  [[nodiscard]] static ArrivalTransform arrival_transform(
      std::shared_ptr<const stationary::detail::ArrivalTransformCore> core) {
    return ArrivalTransform(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::ArrivalTransformCore& core(
      const ArrivalTransform& transform) {
    return *transform.core_;
  }
  [[nodiscard]] static StationaryAnalyticLawIdentityV1 identity(
      std::shared_ptr<const
                      stationary::detail::StationaryAnalyticLawIdentityCore>
          core) {
    return StationaryAnalyticLawIdentityV1(std::move(core));
  }
  [[nodiscard]] static const
      stationary::detail::StationaryAnalyticLawIdentityCore&
  core(const StationaryAnalyticLawIdentityV1& identity) {
    return *identity.core_;
  }
  [[nodiscard]] static ScalarFluxOperator scalar_flux(
      std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore> core) {
    return ScalarFluxOperator(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::ScalarFluxOperatorCore& core(
      const ScalarFluxOperator& flux) {
    return *flux.core_;
  }
  [[nodiscard]] static std::shared_ptr<
      const stationary::detail::ScalarFluxOperatorCore>
  core_ptr(const ScalarFluxOperator& flux) {
    return flux.core_;
  }
  [[nodiscard]] static ScalarStationaryLaw scalar_law(
      std::shared_ptr<const stationary::detail::ScalarStationaryLawCore> core) {
    return ScalarStationaryLaw(std::move(core));
  }
  [[nodiscard]] static ScalarFiniteClosureProofV1 finite_closure_proof(
      StationaryAnalyticLawIdentityV1 law_identity,
      std::vector<BigNat> reachable_support) {
    return ScalarFiniteClosureProofV1(std::move(law_identity),
                                      std::move(reachable_support));
  }
  [[nodiscard]] static const stationary::detail::ScalarStationaryLawCore& core(
      const ScalarStationaryLaw& law) {
    return *law.core_;
  }
  [[nodiscard]] static TransformReadout transform_readout(
      std::shared_ptr<const stationary::detail::TransformReadoutCore> core) {
    return TransformReadout(std::move(core));
  }
  [[nodiscard]] static PhaseArrivalKernel phase_arrival_kernel(
      std::shared_ptr<const stationary::detail::PhaseArrivalKernelCore> core) {
    return PhaseArrivalKernel(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::PhaseArrivalKernelCore& core(
      const PhaseArrivalKernel& kernel) {
    return *kernel.core_;
  }
  [[nodiscard]] static std::shared_ptr<
      const stationary::detail::PhaseArrivalKernelCore>
  core_ptr(const PhaseArrivalKernel& kernel) {
    return kernel.core_;
  }
  [[nodiscard]] static BlockFluxOperator block_flux(
      std::shared_ptr<const stationary::detail::BlockFluxOperatorCore> core) {
    return BlockFluxOperator(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::BlockFluxOperatorCore& core(
      const BlockFluxOperator& flux) {
    return *flux.core_;
  }
  [[nodiscard]] static std::shared_ptr<
      const stationary::detail::BlockFluxOperatorCore>
  core_ptr(const BlockFluxOperator& flux) {
    return flux.core_;
  }
  [[nodiscard]] static PhaseStationaryLaw phase_law(
      std::shared_ptr<const stationary::detail::PhaseStationaryLawCore> core) {
    return PhaseStationaryLaw(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::PhaseStationaryLawCore& core(
      const PhaseStationaryLaw& law) {
    return *law.core_;
  }
  [[nodiscard]] static FixedPointLaw fixed_point_law(
      std::shared_ptr<const stationary::detail::FixedPointLawCore> core) {
    return FixedPointLaw(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::FixedPointLawCore& core(
      const FixedPointLaw& law) {
    return *law.core_;
  }
  [[nodiscard]] static StationaryConditioningMassStatus conditioning_mass(
      std::shared_ptr<const
                      stationary::detail::StationaryConditioningMassCore>
          core) {
    return StationaryConditioningMassStatus(std::move(core));
  }
  [[nodiscard]] static ThreeBinIidSummary three_bin_summary(
      std::shared_ptr<const stationary::detail::ThreeBinIidSummaryCore> core) {
    return ThreeBinIidSummary(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::ThreeBinIidSummaryCore& core(
      const ThreeBinIidSummary& summary) {
    return *summary.core_;
  }
  [[nodiscard]] static FinitePrefixIidSummary finite_prefix_summary(
      std::shared_ptr<const
                      stationary::detail::FinitePrefixIidSummaryCore>
          core) {
    return FinitePrefixIidSummary(std::move(core));
  }
  [[nodiscard]] static const
      stationary::detail::FinitePrefixIidSummaryCore&
  core(const FinitePrefixIidSummary& summary) {
    return *summary.core_;
  }
};

}  // namespace detail

namespace {

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    DiagnosticCategory category = DiagnosticCategory::input_validation) {
  return Result<T>::failure(Diagnostic{category, std::move(code),
                                       std::move(message), std::nullopt,
                                       std::nullopt, {}});
}

[[nodiscard]] Result<void> fail_void(
    std::string code, std::string message,
    DiagnosticCategory category = DiagnosticCategory::input_validation) {
  return Result<void>::failure(Diagnostic{category, std::move(code),
                                          std::move(message), std::nullopt,
                                          std::nullopt, {}});
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest);

[[nodiscard]] Result<std::vector<
    stationary::detail::C19ScalarSelectionSeedAtomV1>>
canonical_scalar_selection_seed(
    std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1> atoms);

#if defined(MWPERF_C19_TEST_SEAMS)
[[nodiscard]] Digest256 empty_digest() { return Sha256().finalize(); }

[[nodiscard]] QueueId fixture_queue() {
  return QueueId(TypedLabel::numeric(BigNat{0U}));
}

[[nodiscard]] ArtifactObjectReferenceV1 fixture_object() {
  return {TypedLabel::numeric(BigNat{0U}), empty_digest()};
}

[[nodiscard]] ArrivalBinding fixture_arrival_binding() {
  const Digest256 digest = empty_digest();
  return {ArrivalFamily::deterministic_trace,
          TimingConvention::early_service_late_admission, 1U,
          ArrivalLawDigest(digest), QueueCatalogDigest(digest)};
}

[[nodiscard]] AuditedFrameworkBindingsV1 fixture_framework() {
  const Digest256 digest = empty_digest();
  return {FrameworkProblemFingerprintsV1{
              InputFingerprintBundle{digest, digest, digest}, digest, digest,
              digest, digest, digest},
          FrameworkProblemViewDigest(digest),
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          std::nullopt};
}

[[nodiscard]] ArtifactValidationBindingsV1 fixture_artifact() {
  const Digest256 digest = empty_digest();
  return {digest,
          digest,
          ProviderIdentityV1{"c19.fixture", "1"},
          1U,
          digest,
          ConstructionMethodV1::closed_form,
          ProducerModeV1::inline_immediate,
          SemanticTagV1::scalar_backlog_response,
          RuntimeAccessTagV1::finite_parameter_analytic_family,
          PayloadClassV1{PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          digest,
          digest};
}

[[nodiscard, maybe_unused]] StationaryAnalyticLawIdentityV1 fixture_identity(
    const PayloadPhaseKindV1 payload_phase = PayloadPhaseKindV1::phase_free) {
  const QueueId target = fixture_queue();
  auto core = std::make_shared<
      stationary::detail::StationaryAnalyticLawIdentityCore>(
      stationary::detail::StationaryAnalyticLawIdentityCore{
          fixture_framework(), fixture_artifact(), empty_digest(),
          std::nullopt,
          fixture_object(), std::nullopt, std::nullopt, payload_phase,
          std::nullopt, std::nullopt, std::nullopt,
          std::nullopt, std::nullopt,
          fixture_arrival_binding(), PortableStationaryUniqueSelectionV1{},
          target, {target}, MetricResultScopeV1::surrogate_law});
  return detail::C19CoreAccess::identity(std::move(core));
}
#endif

struct LittleLawPremises final {
  bool lossless;
  bool unit_packets;
  bool eventual_departure;
  bool positive_finite_intensity;
  bool finite_first_backlog_moment;
  bool little_law;
};

[[nodiscard]] bool has_hypothesis(
    const std::span<const HypothesisClaimV1> claims,
    const HypothesisKindV1 kind,
    const std::optional<MomentVariableV1> variable = std::nullopt,
    const std::optional<BigNat> order = std::nullopt) {
  return std::any_of(claims.begin(), claims.end(), [&](const auto& claim) {
    return claim.kind == kind && (!variable || claim.variable == variable) &&
           (!order || claim.order == order);
  });
}

[[nodiscard]] LittleLawPremises little_law_premises(
    const MetricSupportClauseV1& clause) {
  const std::span<const HypothesisClaimV1> claims{clause.hypotheses};
  return {has_hypothesis(claims, HypothesisKindV1::lossless),
          has_hypothesis(claims, HypothesisKindV1::unit_packets),
          has_hypothesis(
              claims,
              HypothesisKindV1::eventual_departure_or_accessible_class),
          has_hypothesis(claims,
                         HypothesisKindV1::positive_finite_intensity),
          has_hypothesis(claims, HypothesisKindV1::moment_finite,
                         MomentVariableV1::backlog, BigNat{1U}),
          has_hypothesis(claims, HypothesisKindV1::little_law)};
}

[[nodiscard]] bool all_little_law_premises(
    const LittleLawPremises& premises) noexcept {
  return premises.lossless && premises.unit_packets &&
         premises.eventual_departure && premises.positive_finite_intensity &&
         premises.finite_first_backlog_moment && premises.little_law;
}

struct ScalarMetricAuthorization final {
  MetricClauseIdV1 clause_id;
  RealizedMetricBindingV1 realized_binding;
  LittleLawPremises premises;
};

[[nodiscard]] bool scalar_response_route_is_authorized(
    const BackendRouteKindV1 route,
    const MetricKindV1 metric_kind) noexcept {
  switch (route) {
    case BackendRouteKindV1::analytic_metric_family:
    case BackendRouteKindV1::stationary_invariant:
    case BackendRouteKindV1::stationary_edge_reward:
      return true;
    case BackendRouteKindV1::framework_scalar_identity:
      return metric_kind == MetricKindV1::stationary_throughput;
    default:
      return false;
  }
}

[[nodiscard]] bool deployed_response_matches(
    const DeployedResponseProductReferenceV1& deployed,
    const ResponseProductStageV1 stage,
    const ArtifactObjectReferenceV1& subject) noexcept {
  if (!is_point_valued_deployed_response_product_v1(deployed) ||
      !(deployed_response_product_subject_v1(deployed) == subject)) {
    return false;
  }
  switch (stage) {
    case ResponseProductStageV1::raw_response:
      return std::holds_alternative<RawResponseProductRef>(deployed);
    case ResponseProductStageV1::nominal_response:
      return std::holds_alternative<NominalResponseProductRef>(deployed);
    case ResponseProductStageV1::recoded_response:
      return std::holds_alternative<RecodedResponseProductRef>(deployed);
    default:
      return false;
  }
}

[[nodiscard]] Result<ScalarMetricAuthorization>
select_scalar_metric_authorization(
    const surrogate::detail::SealedFrameworkCore& sealed,
    const ResponseProductStageV1 selected_stage,
    const ArtifactObjectReferenceV1& selected_product) {
  const auto& inputs = sealed.inputs();
  const auto& descriptor = sealed.descriptor().core;
  if (descriptor.deployed_targets.size() != 1U) {
    return fail<ScalarMetricAuthorization>(
        "c19.scalar_analytic_route_unavailable",
        "the analytic deployed-response route requires one deployed target",
        DiagnosticCategory::unavailable);
  }
  std::optional<ScalarMetricAuthorization> strongest;
  for (const auto& contract : inputs.accepted_contract.metric_contracts()) {
    if (contract.semantic != SemanticTagV1::scalar_backlog_response ||
        contract.runtime_access !=
            RuntimeAccessTagV1::finite_parameter_analytic_family ||
        contract.ordered_targets.size() != 1U ||
        !(contract.ordered_targets.front().queue_id ==
          descriptor.deployed_targets.front())) {
      continue;
    }
    const auto clause = std::find_if(
        sealed.structural_manifest().clauses().begin(),
        sealed.structural_manifest().clauses().end(),
        [&](const auto& candidate) {
          return candidate.clause_id == contract.clause_id &&
                 candidate.semantic == contract.semantic &&
                 candidate.runtime_access == contract.runtime_access &&
                 candidate.ordered_targets == descriptor.deployed_targets &&
                 candidate.result_scope == MetricResultScopeV1::surrogate_law;
        });
    if (clause == sealed.structural_manifest().clauses().end() ||
        !scalar_response_route_is_authorized(
            contract.backend_route, clause->metric_kind)) {
      continue;
    }
    const auto binding = std::find_if(
        inputs.realized_metric_bindings.bindings().begin(),
        inputs.realized_metric_bindings.bindings().end(),
        [&](const auto& candidate) {
          return candidate.key.clause_id == contract.clause_id &&
                 candidate.key.role == MetricSupportRoleV1::deployed_response;
        });
    if (binding == inputs.realized_metric_bindings.bindings().end()) {
      continue;
    }
    const auto* deployed =
        std::get_if<DeployedResponseReferenceV1>(&binding->reference);
    if (deployed == nullptr ||
        !deployed_response_matches(deployed->selected_product, selected_stage,
                                   selected_product)) {
      continue;
    }
    ScalarMetricAuthorization candidate{
        clause->clause_id, *binding, little_law_premises(*clause)};
    if (!strongest) {
      strongest = candidate;
    }
    if (all_little_law_premises(candidate.premises)) {
      strongest = std::move(candidate);
      break;
    }
  }
  if (!strongest) {
    return fail<ScalarMetricAuthorization>(
        "c19.scalar_analytic_route_unavailable",
        "the accepted structural and realized bindings contain no matching "
        "stationary scalar deployed-response route",
        DiagnosticCategory::unavailable);
  }
  return Result<ScalarMetricAuthorization>::success(std::move(*strongest));
}

[[nodiscard]] const PortablePayloadContextV1* payload_context(
    const SurrogatePlug& plug) {
  return std::visit(
      [](const auto& payload) -> const PortablePayloadContextV1* {
        return &payload.context;
      },
      portable_source_v1(plug).value());
}

[[nodiscard]] std::optional<PortableAnalysisSelectionV1> sealed_selection(
    const surrogate::detail::SealedFrameworkCore& sealed) {
  const auto& context = sealed.inputs().instance.analysis_spec().context;
  if (!context) {
    return std::nullopt;
  }
  const SelectionSpec& selection = context->selection;
  if (std::holds_alternative<StationaryUniqueSelection>(selection)) {
    return PortableStationaryUniqueSelectionV1{};
  }
  if (const auto* one = std::get_if<StationaryClassSelection>(&selection)) {
    return PortableStationaryClassSelectionV1{one->class_id};
  }
  if (const auto* mixture =
          std::get_if<StationaryMixtureSelection>(&selection)) {
    std::vector<PortableStationaryMixtureComponentV1> components;
    components.reserve(mixture->components.size());
    ExactRational total = ExactRational::zero();
    for (const auto& component : mixture->components) {
      total = total + component.probability.exact_value();
    }
    if (!total.is_positive()) {
      return std::nullopt;
    }
    for (const auto& component : mixture->components) {
      auto weight = checked_divide(component.probability.exact_value(), total);
      if (!weight) {
        return std::nullopt;
      }
      components.push_back(
          {component.class_id, std::move(weight).value()});
    }
    return PortableStationaryMixtureSelectionV1{std::move(components)};
  }
  if (const auto* fixed = std::get_if<FixedPointSelection>(&selection)) {
    if (std::holds_alternative<FixedPointUniqueSelection>(*fixed)) {
      return PortableFixedPointUniqueSelectionV1{};
    }
    return PortableFixedPointIdSelectionV1{
        std::get<FixedPointIdSelection>(*fixed).solution_id};
  }
  return PortableTransientSelectionV1{};
}

[[nodiscard]] Result<StationaryAnalyticLawIdentityV1> production_identity(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed) {
  if (!sealed || !sealed->report().passed()) {
    return fail<StationaryAnalyticLawIdentityV1>(
        "c19.audited_view_unavailable",
        "C19 requires a passing C17 V0-sealed analytic view",
        DiagnosticCategory::unavailable);
  }
  const auto* context = payload_context(sealed->plug());
  if (context == nullptr ||
      sealed->inputs().framework_seed.target_selection.ordered_targets.size() !=
          1U) {
    return fail<StationaryAnalyticLawIdentityV1>(
        "c19.scalar_identity_scope",
        "the scalar analytic identity requires one sealed target");
  }
  auto selection = sealed_selection(*sealed);
  if (!selection) {
    return fail<StationaryAnalyticLawIdentityV1>(
        "c19.selection_identity_unavailable",
        "the sealed analysis selection cannot be represented by C19");
  }
  const ArrivalBinding& arrival_binding =
      arrival_law_binding(sealed->inputs().configured_arrival);
  std::optional<ResponseProductStageV1> stage;
  std::optional<ArtifactObjectReferenceV1> product;
  std::optional<ArtifactObjectReferenceV1> derivation;
  std::optional<MetricClauseIdV1> accepted_metric_clause;
  std::optional<RealizedMetricBindingV1> realized_metric_binding;
  std::optional<BigNat> cutoff;
  std::optional<ExactRational> tail_service;
  if (const auto* three_bin =
          std::get_if<PortableThreeBinScalarResponseV1>(
              &portable_source_v1(sealed->plug()).value())) {
    if (three_bin->selected_product !=
        three_bin->normalized_record.deployed_response_product_id) {
      return fail<StationaryAnalyticLawIdentityV1>(
          "c19.response_product_identity_mismatch",
          "the portable final response product differs from its normalized "
          "response row");
    }
    product = deployed_response_product_identity_v1(three_bin->selected_product);
    stage = std::visit(
        [](const auto& typed) { return std::decay_t<decltype(typed)>::stage(); },
        three_bin->selected_product);
    auto selected_derivation = std::visit(
        [&](const auto& selected)
            -> Result<std::optional<ArtifactObjectReferenceV1>> {
          using Selected = std::remove_cvref_t<decltype(selected)>;
          if constexpr (std::same_as<Selected, RawResponseProductId>) {
            if (!(selected == three_bin->normalized_record.raw_response.product_id)) {
              return fail<std::optional<ArtifactObjectReferenceV1>>(
                  "c19.raw_response_product_mismatch",
                  "the selected raw response is absent from the final row");
            }
            return Result<std::optional<ArtifactObjectReferenceV1>>::success(
                std::nullopt);
          } else if constexpr (std::same_as<Selected,
                                             NominalResponseProductId>) {
            if (!three_bin->normalized_record.nominal_response ||
                !(selected == three_bin->normalized_record.nominal_response
                                  ->product_id)) {
              return fail<std::optional<ArtifactObjectReferenceV1>>(
                  "c19.nominal_response_product_mismatch",
                  "the selected nominal response is absent from the final "
                  "row");
            }
            return Result<std::optional<ArtifactObjectReferenceV1>>::success(
                three_bin->normalized_record.nominal_response
                    ->derivation_certificate_id);
          } else {
            static_assert(std::same_as<Selected, RecodedResponseProductId>);
            if (!three_bin->normalized_record.recoded_response ||
                !(selected == three_bin->normalized_record.recoded_response
                                  ->product_id)) {
              return fail<std::optional<ArtifactObjectReferenceV1>>(
                  "c19.recoded_response_product_mismatch",
                  "the selected recoded response is absent from the final "
                  "row");
            }
            return Result<std::optional<ArtifactObjectReferenceV1>>::success(
                three_bin->normalized_record.recoded_response
                    ->derivation_certificate_id);
          }
        },
        three_bin->selected_product);
    if (!selected_derivation) {
      return Result<StationaryAnalyticLawIdentityV1>::failure(
          selected_derivation.error());
    }
    derivation = std::move(selected_derivation).value();
    auto authorization = select_scalar_metric_authorization(
        *sealed, *stage, *product);
    if (!authorization) {
      return Result<StationaryAnalyticLawIdentityV1>::failure(
          authorization.error());
    }
    accepted_metric_clause = authorization.value().clause_id;
    realized_metric_binding = authorization.value().realized_binding;
    cutoff = BigNat{2U};
    tail_service = three_bin->coefficients[2U];
  } else if (const auto* finite_prefix =
                 std::get_if<PortableFinitePrefixConstantTailResponseV1>(
                     &portable_source_v1(sealed->plug()).value())) {
    if (!(finite_prefix->selected_product ==
          finite_prefix->normalized_record.deployed_response_product_id) ||
        !(finite_prefix->selected_product ==
          finite_prefix->normalized_record.raw_response.product_id)) {
      return fail<StationaryAnalyticLawIdentityV1>(
          "c19.response_product_identity_mismatch",
          "the portable finite-prefix response product differs from its "
          "normalized raw response row");
    }
    stage = ResponseProductStageV1::raw_response;
    product = finite_prefix->selected_product.identity();
    derivation = std::nullopt;
    auto authorization = select_scalar_metric_authorization(
        *sealed, *stage, *product);
    if (!authorization) {
      return Result<StationaryAnalyticLawIdentityV1>::failure(
          authorization.error());
    }
    accepted_metric_clause = authorization.value().clause_id;
    realized_metric_binding = authorization.value().realized_binding;
    cutoff = finite_prefix->response_cutoff;
    tail_service = finite_prefix->constant_tail_service;
  }
  const QueueId target =
      sealed->inputs().framework_seed.target_selection.ordered_targets.front();
  const auto accepted_construction_targets =
      sealed->inputs().accepted_contract.construction_target_scope();
  auto core = std::make_shared<
      stationary::detail::StationaryAnalyticLawIdentityCore>(
      stationary::detail::StationaryAnalyticLawIdentityCore{
          sealed->inputs().framework_seed.bindings,
          sealed->artifact_bindings(),
          sealed->execution_seal_digest(),
          std::nullopt,
          context->payload_identity,
          std::move(accepted_metric_clause),
          std::move(realized_metric_binding),
          sealed->descriptor().core.phase.payload_phase,
          stage,
          product,
          derivation,
          cutoff,
          tail_service,
          arrival_binding,
          std::move(*selection),
          target,
          std::vector<QueueId>(accepted_construction_targets.begin(),
                               accepted_construction_targets.end()),
          MetricResultScopeV1::surrogate_law});
  return Result<StationaryAnalyticLawIdentityV1>::success(
      detail::C19CoreAccess::identity(std::move(core)));
}

[[nodiscard]] Result<std::size_t> native_index(const BigNat& value) {
  const BigInt maximum = std::numeric_limits<std::size_t>::max();
  if (value.value() > maximum) {
    return fail<std::size_t>("c19.index_out_of_range",
                             "an exact level does not fit the native index");
  }
  return Result<std::size_t>::success(value.value().convert_to<std::size_t>());
}

[[nodiscard]] ExactRational rational_from_nat(const BigNat& value) {
  return ExactRational::make(value.value(), BigInt{1}).value();
}

[[nodiscard]] ExactRational rational_from_size(const std::size_t value) {
  return ExactRational::make(BigInt{value}, BigInt{1}).value();
}

#if defined(MWPERF_C19_TEST_SEAMS)
[[nodiscard]] Digest256 fixture_arrival_digest(
    const std::span<const ScalarArrivalMassV1> atoms) {
  std::string canonical;
  for (const auto& atom : atoms) {
    const std::string count = atom.count.to_decimal_string();
    const std::string numerator = atom.mass.numerator_decimal();
    const std::string denominator = atom.mass.denominator_decimal();
    canonical += std::to_string(count.size()) + ":" + count;
    canonical += std::to_string(numerator.size()) + ":" + numerator;
    canonical += std::to_string(denominator.size()) + ":" + denominator;
  }
  auto digest = sha256_domain_separated(
      "mwperf.c19.fixture.arrival.v1",
      std::as_bytes(std::span(canonical.data(), canonical.size())));
  return digest ? std::move(digest).value() : empty_digest();
}
#endif

[[nodiscard]] Result<std::shared_ptr<const stationary::detail::ArrivalLawCore>>
make_arrival_core(
    std::vector<ScalarArrivalMassV1> atoms, ArrivalBinding binding,
    QueueId target, Digest256 identity_digest,
    std::shared_ptr<const void> arrival_identity,
    std::shared_ptr<surrogate::detail::SealedFrameworkCore> sealed,
    StationaryAnalyticLawIdentityV1 identity,
    const bool second_moment_available = true,
    std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1>
        selection_seed = {}) {
  if (atoms.empty()) {
    return fail<std::shared_ptr<const stationary::detail::ArrivalLawCore>>(
        "c19.empty_arrival_pmf", "an IID arrival PMF must have an atom");
  }
  std::sort(atoms.begin(), atoms.end(), [](const auto& left, const auto& right) {
    return left.count < right.count;
  });
  std::vector<ScalarArrivalMassV1> canonical;
  ExactRational total = ExactRational::zero();
  for (auto& atom : atoms) {
    if (!atom.mass.is_nonnegative()) {
      return fail<std::shared_ptr<const stationary::detail::ArrivalLawCore>>(
          "c19.negative_arrival_mass",
          "IID arrival probabilities must be nonnegative");
    }
    if (!canonical.empty() && canonical.back().count == atom.count) {
      canonical.back().mass = canonical.back().mass + atom.mass;
    } else {
      canonical.push_back(std::move(atom));
    }
  }
  std::erase_if(canonical, [](const ScalarArrivalMassV1& atom) {
    return atom.mass.is_zero();
  });
  for (const auto& atom : canonical) {
    total = total + atom.mass;
  }
  if (!(total == ExactRational::one())) {
    return fail<std::shared_ptr<const stationary::detail::ArrivalLawCore>>(
        "c19.arrival_mass_not_normalized",
        "IID arrival probabilities must total exactly one");
  }
  ExactRational mean = ExactRational::zero();
  ExactRational second = ExactRational::zero();
  for (const auto& atom : canonical) {
    const ExactRational count = rational_from_nat(atom.count);
    mean = mean + atom.mass * count;
    second = second + atom.mass * count * count;
  }
  std::vector<ExactRational> reverse(canonical.size(), ExactRational::zero());
  ExactRational suffix = ExactRational::zero();
  for (std::size_t position = canonical.size(); position-- > 0U;) {
    suffix = suffix + canonical[position].mass;
    reverse[position] = suffix;
  }
#if defined(MWPERF_C19_TEST_SEAMS)
  if (!sealed) {
    identity_digest = fixture_arrival_digest(canonical);
  }
#endif
  std::shared_ptr<const void> seal =
      sealed ? std::static_pointer_cast<const void>(sealed) : arrival_identity;
  auto core = std::make_shared<stationary::detail::ArrivalLawCore>(
      stationary::detail::ArrivalLawCore{
          std::move(canonical), std::move(reverse), std::move(mean),
          second_moment_available
              ? std::optional<ExactRational>(std::move(second))
              : std::nullopt,
          std::move(binding), std::move(target),
          std::move(identity_digest), std::move(arrival_identity),
          std::move(seal), std::move(sealed), std::move(identity),
          std::move(selection_seed)});
  return Result<
      std::shared_ptr<const stationary::detail::ArrivalLawCore>>::success(
      std::move(core));
}

[[nodiscard]] std::optional<SelectionKindV1> scalar_selection_kind(
    const SelectionSpec& selection) {
  if (std::holds_alternative<StationaryUniqueSelection>(selection)) {
    return SelectionKindV1::stationary_unique;
  }
  if (std::holds_alternative<StationaryClassSelection>(selection)) {
    return SelectionKindV1::stationary_class;
  }
  if (std::holds_alternative<StationaryMixtureSelection>(selection)) {
    return SelectionKindV1::stationary_mixture;
  }
  return std::nullopt;
}

[[nodiscard]] Result<std::vector<
    stationary::detail::C19ScalarSelectionSeedAtomV1>>
scalar_selection_seed_from_sealed(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed) {
  const auto& inputs = sealed->inputs();
  const auto& seed = inputs.framework_seed;
  const auto& analysis_context = inputs.instance.analysis_spec().context;
  if (!analysis_context) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_unavailable",
        "the sealed scalar analysis has no configured selection");
  }
  const SelectionSpec& selection = analysis_context->selection;
  const auto kind = scalar_selection_kind(selection);
  if (!kind || seed.initial_selection_authority.configured_kind != *kind) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_authority",
        "the sealed initial mapper has no authority for this stationary "
        "selection");
  }
  const bool unique = *kind == SelectionKindV1::stationary_unique;
  if (unique && seed.selection_support.named_classes.size() > 1U) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_stationary_uniqueness_contradicted",
        "stationary_unique cannot use a sealed domain advertising multiple "
        "stationary classes");
  }
  if ((unique &&
       (!seed.initial_selection_authority.uniqueness_evidence_digest ||
        !nonzero_digest(
            *seed.initial_selection_authority.uniqueness_evidence_digest))) ||
      (!unique &&
       seed.initial_selection_authority.uniqueness_evidence_digest)) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_authority",
        "the stationary selection has inconsistent sealed uniqueness "
        "authority");
  }
  const auto supports_kind =
      std::ranges::find(seed.selection_support.kinds, *kind) !=
      seed.selection_support.kinds.end();
  const auto supports_class = [&](const TypedLabel& id) {
    return std::ranges::find(seed.selection_support.named_classes, id) !=
           seed.selection_support.named_classes.end();
  };
  bool supported = supports_kind;
  if (const auto* one =
          std::get_if<StationaryClassSelection>(&selection)) {
    supported = supported && supports_class(one->class_id);
  } else if (const auto* mixture =
                 std::get_if<StationaryMixtureSelection>(&selection)) {
    supported = supported &&
                std::ranges::all_of(
                    mixture->components, [&](const auto& component) {
                      return supports_class(component.class_id);
                    });
  }
  if (!supported || !seed.initial_mapper ||
      !seed.exact_state_schema_validator ||
      !seed.reduced_state_domain_validator || !inputs.exact_state_schema.decode) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_unavailable",
        "the stationary selection or its sealed exact mapper/domain is "
        "unavailable");
  }
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(selection);
  if (!selection_digest ||
      selection_digest.value() != seed.bindings.selection_digest ||
      selection_digest.value() !=
          sealed->artifact_bindings().analysis_selection_digest) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_binding",
        "the stationary selection differs from the sealed analysis identity");
  }
  auto exact_schema = seed.exact_state_schema_validator(
      inputs.instance, seed.bindings.exact_state_schema_digest);
  if (!exact_schema) {
    return Result<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>::failure(
        exact_schema.error());
  }
  auto mapped = seed.initial_mapper(selection, std::nullopt);
  if (!mapped) {
    return Result<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>::failure(
        mapped.error());
  }
  const ReducedInitialLawCandidateV1& candidate = mapped.value();
  if (candidate.state_codec != seed.reduced_state_codec ||
      candidate.exact_state_schema_digest !=
          seed.bindings.exact_state_schema_digest ||
      candidate.reduced_state_schema_digest !=
          seed.bindings.reduced_state_schema_digest ||
      candidate.selection_digest != seed.bindings.selection_digest ||
      candidate.selection_support != seed.selection_support ||
      candidate.atoms.empty()) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_binding",
        "the selected scalar seed belongs to another codec, schema, or "
        "selection");
  }
  std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1> atoms;
  atoms.reserve(candidate.atoms.size());
  for (const auto& atom : candidate.atoms) {
    if (atom.state.codec != candidate.state_codec ||
        atom.physical_atom_ordinal ||
        atom.conditional_mass.kind() !=
            ProbabilityMassKindV1::exact_rational ||
        !atom.conditional_mass.structural_support() ||
        !atom.conditional_mass.exact_value().is_positive() ||
        atom.conditional_mass.exact_value() > ExactRational::one()) {
      return fail<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>(
          "c19.scalar_selection_seed_invalid",
          "a stationary scalar seed requires positive exact masses and no "
          "transient physical ordinal");
    }
    auto in_domain = seed.reduced_state_domain_validator(atom.state);
    if (!in_domain) {
      return Result<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>::failure(
          in_domain.error());
    }
    auto decoded = inputs.exact_state_schema.decode(atom.state);
    if (!decoded) {
      return Result<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>::failure(
          decoded.error());
    }
    if (!decoded.value().backlog.matches(inputs.instance) ||
        decoded.value().backlog.size() != 1U ||
        inputs.framework_seed.target_selection.ordered_targets.size() != 1U) {
      return fail<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>(
          "c19.scalar_selection_seed_scope",
          "the selected seed must decode to the singleton target backlog");
    }
    const std::size_t physical =
        decoded.value().backlog.ordered_targets().front().ordinal();
    const auto queues = inputs.instance.queues().entries();
    if (physical >= queues.size() ||
        !(queues[physical].id ==
          inputs.framework_seed.target_selection.ordered_targets.front())) {
      return fail<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>(
          "c19.scalar_selection_seed_scope",
          "the decoded seed backlog has a different target identity");
    }
    atoms.push_back({decoded.value().backlog.values().front(),
                     atom.conditional_mass.exact_value()});
  }
  return canonical_scalar_selection_seed(std::move(atoms));
}

[[nodiscard]] Result<ArrivalLaw> arrival_from_sealed(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed,
    std::optional<std::vector<ScalarArrivalMassV1>> supplied = std::nullopt,
    const bool solver_proves_stationary_unique = false) {
  if (!sealed) {
    return fail<ArrivalLaw>("c19.audited_view_unavailable",
                            "C19 requires an audited scalar response",
                            DiagnosticCategory::unavailable);
  }
  const ArrivalCapabilities configured_capabilities =
      arrival_capabilities(sealed->inputs().configured_arrival);
  const bool exact_factorized_iid =
      configured_capabilities.exact_factorized_iid_generator.has_value();
  const bool legacy_exact_joint_iid_capability =
      configured_capabilities.exact_iid_joint_vector.has_value();
  if (!exact_factorized_iid && !legacy_exact_joint_iid_capability) {
    return fail<ArrivalLaw>(
        "c19.temporal_iid_not_established",
        "the configured arrival provides neither the accepted exact "
        "factorized IID generator nor the legacy exact IID joint-vector "
        "capability",
        DiagnosticCategory::unavailable);
  }
  std::optional<BuilderArrivalView> legacy_view;
  if (!exact_factorized_iid) {
    legacy_view.emplace(
        builder_arrival_view(sealed->inputs().configured_arrival));
    if (!legacy_view->iid_joint_table().has_value()) {
      return fail<ArrivalLaw>(
          "c19.iid_joint_table_missing",
          "the legacy exact IID joint-vector capability has no table",
          DiagnosticCategory::internal);
    }
  }
  auto identity = production_identity(sealed);
  if (!identity) {
    return Result<ArrivalLaw>::failure(identity.error());
  }
  const auto& targets =
      sealed->inputs().framework_seed.target_selection.ordered_targets;
  if (targets.size() != 1U) {
    return fail<ArrivalLaw>("c19.scalar_target_required",
                            "the IID scalar route requires one target");
  }
  std::size_t coordinate = sealed->inputs().instance.queues().size();
  const auto entries = sealed->inputs().instance.queues().entries();
  for (std::size_t index = 0U; index < entries.size(); ++index) {
    if (entries[index].id == targets.front()) {
      coordinate = index;
      break;
    }
  }
  if (coordinate == entries.size()) {
    return fail<ArrivalLaw>("c19.target_not_in_arrival_catalog",
                            "the sealed target is absent from the arrival "
                            "queue catalog");
  }
  auto target_coordinate =
      sealed->inputs().instance.queues().index_at(coordinate);
  if (!target_coordinate) {
    return Result<ArrivalLaw>::failure(target_coordinate.error());
  }
  std::vector<ScalarArrivalMassV1> atoms;
  if (supplied) {
    atoms = std::move(*supplied);
  } else if (exact_factorized_iid) {
    auto projection = project_exact_factorized_iid_target_pmf(
        sealed->inputs().configured_arrival, target_coordinate.value());
    if (!projection) {
      return Result<ArrivalLaw>::failure(projection.error());
    }
    atoms.reserve(projection.value().size());
    for (auto& atom : projection.value()) {
      atoms.push_back(
          {std::move(atom.count), std::move(atom.probability)});
    }
  } else {
    // The table-bearing view exists only for this legacy fallback.  The
    // factorized path never copies or consumes the Cartesian table.
    for (const auto& joint : *legacy_view->iid_joint_table()) {
      if (joint.dense_counts.size() != entries.size()) {
        return fail<ArrivalLaw>(
            "c19.iid_joint_dimension",
            "an IID joint arrival atom has the wrong queue dimension");
      }
      atoms.push_back({joint.dense_counts[coordinate], joint.probability});
    }
  }
  Result<std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1>>
      selection_seed = Result<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>::success({});
  if (solver_proves_stationary_unique) {
    const auto& context =
        sealed->inputs().instance.analysis_spec().context;
    if (!context ||
        !std::holds_alternative<StationaryUniqueSelection>(
            context->selection)) {
      return fail<ArrivalLaw>(
          "c19.stationary_unique_selection_required",
          "the solver-owned IID summary requires stationary_unique",
          DiagnosticCategory::unavailable);
    }
    const auto& support = sealed->inputs().framework_seed.selection_support;
    const auto& authority =
        sealed->inputs().framework_seed.initial_selection_authority;
    if (std::ranges::find(support.kinds,
                          SelectionKindV1::stationary_unique) ==
            support.kinds.end() ||
        support.named_classes.size() > 1U) {
      return fail<ArrivalLaw>(
          "c19.stationary_unique_scope_unavailable",
          "the sealed selection scope does not admit a solver-proved "
          "unique stationary law",
          DiagnosticCategory::unavailable);
    }
    if (authority.configured_kind !=
            SelectionKindV1::stationary_unique ||
        (authority.uniqueness_evidence_digest &&
         !nonzero_digest(*authority.uniqueness_evidence_digest))) {
      return fail<ArrivalLaw>(
          "c19.stationary_unique_authority_contradiction",
          "the sealed initial-selection authority contradicts the "
          "stationary_unique analysis");
    }
  } else {
    selection_seed = scalar_selection_seed_from_sealed(sealed);
    if (!selection_seed) {
      const bool unique = std::holds_alternative<StationaryUniqueSelection>(
          sealed->inputs().instance.analysis_spec().context->selection);
      if (!unique ||
          selection_seed.error().code !=
              "c19.scalar_selection_seed_unavailable") {
        return Result<ArrivalLaw>::failure(selection_seed.error());
      }
    }
  }
  const ArrivalBinding& configured_arrival_binding =
      arrival_law_binding(sealed->inputs().configured_arrival);
  auto core = make_arrival_core(
      std::move(atoms), configured_arrival_binding, targets.front(),
      configured_arrival_binding.law_digest.value(), sealed, sealed,
      std::move(identity).value(), true,
      selection_seed
          ? std::move(selection_seed).value()
          : std::vector<
                stationary::detail::C19ScalarSelectionSeedAtomV1>{});
  if (!core) {
    return Result<ArrivalLaw>::failure(core.error());
  }
  return Result<ArrivalLaw>::success(
      detail::C19CoreAccess::arrival_law(std::move(core).value()));
}

[[nodiscard]] Result<ArrivalLaw> arrival_from_carrier(
    const std::shared_ptr<const
                          stationary::detail::AuditedScalarResponseCarrierCore>&
        carrier) {
  if (!carrier || !carrier->temporal_iid) {
    return fail<ArrivalLaw>(
        "c19.temporal_iid_not_established",
        "the configured arrival does not establish the exact temporal-IID "
        "hypothesis required by SF.14",
        DiagnosticCategory::unavailable);
  }
  auto core = make_arrival_core(
      carrier->arrival_atoms, carrier->identity.configured_arrival(),
      carrier->identity.target(),
      carrier->identity.configured_arrival().law_digest.value(),
      carrier->seal, nullptr, carrier->identity,
      carrier->second_moment_available, carrier->selection_seed);
  if (!core) {
    return Result<ArrivalLaw>::failure(core.error());
  }
  return Result<ArrivalLaw>::success(
      detail::C19CoreAccess::arrival_law(std::move(core).value()));
}

[[nodiscard]] ExactRational arrival_probability(
    const stationary::detail::ArrivalLawCore& arrival, const BigInt& count) {
  if (count < 0) {
    return ExactRational::zero();
  }
  const auto found = std::lower_bound(
      arrival.atoms.begin(), arrival.atoms.end(), count,
      [](const ScalarArrivalMassV1& atom, const BigInt& wanted) {
        return atom.count.value() < wanted;
      });
  if (found == arrival.atoms.end() || found->count.value() != count) {
    return ExactRational::zero();
  }
  return found->mass;
}

[[nodiscard]] ExactRational arrival_survival(
    const stationary::detail::ArrivalLawCore& arrival,
    const BigInt& threshold) {
  if (threshold <= 0) {
    return ExactRational::one();
  }
  const auto found = std::lower_bound(
      arrival.atoms.begin(), arrival.atoms.end(), threshold,
      [](const ScalarArrivalMassV1& atom, const BigInt& wanted) {
        return atom.count.value() < wanted;
      });
  if (found == arrival.atoms.end()) {
    return ExactRational::zero();
  }
  return arrival.reverse_survival[static_cast<std::size_t>(
      found - arrival.atoms.begin())];
}

[[nodiscard]] Result<ExactRational> service_probability(
    const stationary::detail::ScalarResponseData& response,
    const BigNat& level) {
  if (level.is_zero()) {
    return Result<ExactRational>::success(ExactRational::zero());
  }
  auto native = native_index(level);
  if (native && native.value() < response.prefix.size()) {
    const ExactRational& value = response.prefix[native.value()];
    if (!value.is_nonnegative() || value > ExactRational::one()) {
      return fail<ExactRational>("c19.response_out_of_range",
                                 "a service probability lies outside [0,1]");
    }
    return Result<ExactRational>::success(value);
  }
  if (response.constant_tail_from && response.constant_tail_service &&
      level >= *response.constant_tail_from) {
    const ExactRational& value = *response.constant_tail_service;
    if (!value.is_nonnegative() || value > ExactRational::one()) {
      return fail<ExactRational>("c19.response_out_of_range",
                                 "the tail service lies outside [0,1]");
    }
    return Result<ExactRational>::success(value);
  }
  return fail<ExactRational>(
      "c19.response_level_unavailable",
      "the declared scalar response does not cover the requested level",
      DiagnosticCategory::unavailable);
}

[[nodiscard]] Result<void> validate_response(
    const stationary::detail::ScalarResponseData& response) {
  for (std::size_t level = 0U; level < response.prefix.size(); ++level) {
    const ExactRational& value = response.prefix[level];
    if (!value.is_nonnegative() || value > ExactRational::one()) {
      return fail_void("c19.response_out_of_range",
                       "a service probability lies outside [0,1]");
    }
    if (level == 0U && !value.is_zero()) {
      return fail_void("c19.mu_zero_nonzero", "SF.14 requires mu(0)=0");
    }
  }
  if (response.constant_tail_from.has_value() !=
      response.constant_tail_service.has_value()) {
    return fail_void("c19.incomplete_constant_tail",
                     "a constant-tail response requires both cutoff and "
                     "service value");
  }
  if (response.constant_tail_service &&
      (!response.constant_tail_service->is_nonnegative() ||
       *response.constant_tail_service > ExactRational::one())) {
    return fail_void("c19.response_out_of_range",
                     "the tail service lies outside [0,1]");
  }
  if (response.constant_tail_from) {
    auto tail = native_index(*response.constant_tail_from);
    if (!tail) {
      return Result<void>::failure(tail.error());
    }
    for (std::size_t level = tail.value(); level < response.prefix.size();
         ++level) {
      if (!(response.prefix[level] == *response.constant_tail_service)) {
        return fail_void("c19.constant_tail_overlap_mismatch",
                         "explicit response values in the declared tail must "
                         "equal the tail service");
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<stationary::detail::ScalarResponseData>
sealed_scalar_response(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed) {
  if (!sealed || !sealed->report().passed()) {
    return fail<stationary::detail::ScalarResponseData>(
        "c19.audited_response_unavailable",
        "C19 requires a passing C17 V0-sealed response",
        DiagnosticCategory::unavailable);
  }
  const PortablePlugPayloadValueV1& source =
      portable_source_v1(sealed->plug()).value();
  stationary::detail::ScalarResponseData response;
  if (const auto* payload =
          std::get_if<PortableThreeBinScalarResponseV1>(&source)) {
    if (payload->context.semantic !=
            SemanticTagV1::scalar_backlog_response ||
        payload->context.runtime_access !=
            RuntimeAccessTagV1::finite_parameter_analytic_family) {
      return fail<stationary::detail::ScalarResponseData>(
          "c19.scalar_response_codec_unsupported",
          "the sealed ThreeBin response is not a scalar finite-parameter "
          "analytic family",
          DiagnosticCategory::unavailable);
    }
    response = stationary::detail::ScalarResponseData{
        {ExactRational::zero(), payload->coefficients[0U],
         payload->coefficients[1U]},
        BigNat{3U}, payload->coefficients[2U]};
  } else if (const auto* payload =
                 std::get_if<PortableFinitePrefixConstantTailResponseV1>(
                     &source)) {
    if (payload->context.semantic !=
            SemanticTagV1::scalar_backlog_response ||
        payload->context.runtime_access !=
            RuntimeAccessTagV1::finite_parameter_analytic_family) {
      return fail<stationary::detail::ScalarResponseData>(
          "c19.scalar_response_codec_unsupported",
          "the sealed finite-prefix response is not a scalar "
          "finite-parameter analytic family",
          DiagnosticCategory::unavailable);
    }
    auto cutoff = native_index(payload->response_cutoff);
    if (!cutoff || cutoff.value() ==
                       std::numeric_limits<std::size_t>::max() ||
        payload->service_by_level.size() != cutoff.value() + 1U ||
        payload->service_by_level.empty() ||
        !payload->service_by_level.front().is_zero() ||
        payload->constant_tail_from.value() !=
            payload->response_cutoff.value() + 1) {
      return fail<stationary::detail::ScalarResponseData>(
          "c19.finite_prefix_response_shape",
          "the sealed finite-prefix response requires mu(0)=0, exactly "
          "K+1 prefix coefficients, and a constant tail beginning at K+1");
    }
    response = stationary::detail::ScalarResponseData{
        payload->service_by_level, payload->constant_tail_from,
        payload->constant_tail_service};
  } else {
    return fail<stationary::detail::ScalarResponseData>(
        "c19.scalar_response_codec_unsupported",
        "the sealed analytic response does not use the declared C19 "
        "scalar response codecs",
        DiagnosticCategory::unavailable);
  }
  auto valid = validate_response(response);
  if (!valid) {
    return Result<stationary::detail::ScalarResponseData>::failure(
        valid.error());
  }
  return Result<stationary::detail::ScalarResponseData>::success(
      std::move(response));
}

[[nodiscard]] Result<ScalarFluxOperator> assemble_scalar_flux_impl(
    const std::shared_ptr<const stationary::detail::ArrivalLawCore>& arrival,
    stationary::detail::ScalarResponseData response) {
  auto valid = validate_response(response);
  if (!valid) {
    return Result<ScalarFluxOperator>::failure(valid.error());
  }
  StationaryAnalyticLawIdentityV1 identity = arrival->identity;
  if (response.constant_tail_from && response.constant_tail_service) {
    auto cutoff = checked_subtract(*response.constant_tail_from, BigNat{1U});
    if (!cutoff) {
      return fail<ScalarFluxOperator>(
          "c19.constant_tail_boundary_invalid",
          "a constant-tail response must begin at a positive level");
    }
    auto copied = detail::C19CoreAccess::core(identity);
    copied.cutoff = std::move(cutoff).value();
    copied.tail_service = *response.constant_tail_service;
    identity = detail::C19CoreAccess::identity(
        std::make_shared<
            stationary::detail::StationaryAnalyticLawIdentityCore>(
            std::move(copied)));
  }
  auto core =
      std::make_shared<stationary::detail::ScalarFluxOperatorCore>(
          stationary::detail::ScalarFluxOperatorCore{
              arrival, std::move(response), std::move(identity)});
  return Result<ScalarFluxOperator>::success(
      detail::C19CoreAccess::scalar_flux(std::move(core)));
}

[[nodiscard]] ExactRational transition_probability(
    const stationary::detail::ScalarFluxOperatorCore& flux,
    const BigNat& source, const BigNat& destination) {
  const auto mu_result = service_probability(flux.response, source);
  if (!mu_result) {
    return ExactRational::zero();
  }
  const ExactRational& mu = mu_result.value();
  const BigInt offset = destination.value() - source.value();
  return mu * arrival_probability(*flux.arrival, offset + 1) +
         (ExactRational::one() - mu) *
             arrival_probability(*flux.arrival, offset);
}

[[nodiscard]] Result<ExactRational> next_cut_weight(
    const stationary::detail::ScalarFluxOperatorCore& flux,
    const std::vector<ExactRational>& weights, const std::size_t cut) {
  const BigNat level{static_cast<std::uint64_t>(cut)};
  auto mu_cut = service_probability(flux.response, level);
  if (!mu_cut) {
    return Result<ExactRational>::failure(mu_cut.error());
  }
  const ExactRational a0 = arrival_probability(*flux.arrival, BigInt{0});
  const ExactRational denominator = mu_cut.value() * a0;
  ExactRational numerator = ExactRational::zero();
  for (std::size_t source = 0U; source < cut; ++source) {
    auto mu = service_probability(
        flux.response, BigNat{static_cast<std::uint64_t>(source)});
    if (!mu) {
      return Result<ExactRational>::failure(mu.error());
    }
    const BigInt distance = BigInt{cut - source};
    numerator = numerator +
                weights[source] *
                    ((ExactRational::one() - mu.value()) *
                         arrival_survival(*flux.arrival, distance) +
                     mu.value() *
                         arrival_survival(*flux.arrival, distance + 1));
  }
  if (denominator.is_zero()) {
    if (numerator.is_zero()) {
      return fail<ExactRational>(
          "c19.cut_underdetermined_closed_class",
          "SF.19 has zero denominator and zero crossing flux",
          DiagnosticCategory::unavailable);
    }
    return fail<ExactRational>(
        "c19.cut_inconsistent_zero_denominator",
        "SF.19 has positive crossing flux but zero downward coefficient");
  }
  return checked_divide(numerator, denominator);
}

struct FiniteClosure final {
  bool closed;
  std::vector<std::size_t> reachable;
  struct SelectedClass final {
    std::vector<std::size_t> members;
    ExactRational weight;
  };
  std::vector<SelectedClass> selected_classes;
};

[[nodiscard]] Result<FiniteClosure> prove_finite_closure(
    const stationary::detail::ScalarFluxOperatorCore& flux,
    const std::size_t maximum) {
  if (maximum == std::numeric_limits<std::size_t>::max()) {
    return fail<FiniteClosure>("c19.scalar_closure_dimension_overflow",
                               "the finite closure is not indexable");
  }
  std::vector<std::uint8_t> seen(maximum + 1U, 0U);
  std::vector<std::size_t> queue;
  bool closed = true;
  for (const auto& atom : flux.arrival->selection_seed) {
    auto level = native_index(atom.backlog);
    if (!level || level.value() > maximum) {
      closed = false;
      continue;
    }
    if (atom.selection_mass.is_positive() && seen[level.value()] == 0U) {
      seen[level.value()] = 1U;
      queue.push_back(level.value());
    }
  }
  if (queue.empty()) {
    return Result<FiniteClosure>::success({false, {}, {}});
  }
  for (std::size_t cursor = 0U; cursor < queue.size(); ++cursor) {
    const std::size_t source = queue[cursor];
    auto mu = service_probability(
        flux.response, BigNat{static_cast<std::uint64_t>(source)});
    if (!mu) {
      return Result<FiniteClosure>::failure(mu.error());
    }
    for (const auto& atom : flux.arrival->atoms) {
      if (!atom.mass.is_positive()) {
        continue;
      }
      const std::array<std::pair<bool, ExactRational>, 2U> branches{{
          {false, ExactRational::one() - mu.value()}, {true, mu.value()}}};
      for (const auto& [departure, branch_mass] : branches) {
        if (!branch_mass.is_positive()) {
          continue;
        }
        BigInt destination = BigInt{source} + atom.count.value();
        if (departure) {
          destination -= 1;
        }
        if (destination < 0) {
          return fail<FiniteClosure>(
              "c19.scalar_negative_successor",
              "SF.14 produced a negative level from a positive event");
        }
        if (destination > BigInt{maximum}) {
          closed = false;
          continue;
        }
        const std::size_t native = destination.convert_to<std::size_t>();
        if (seen[native] == 0U) {
          seen[native] = 1U;
          queue.push_back(native);
        }
      }
    }
  }
  std::sort(queue.begin(), queue.end());
  if (!closed) {
    return Result<FiniteClosure>::success(
        {false, std::move(queue), {}});
  }

  const std::size_t count = queue.size();
  std::vector<int> discovery(count, -1);
  std::vector<int> low(count, -1);
  std::vector<std::size_t> stack;
  std::vector<std::uint8_t> on_stack(count, 0U);
  std::vector<std::vector<std::size_t>> components;
  int next_discovery = 0;
  std::function<void(std::size_t)> visit = [&](const std::size_t vertex) {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = 1U;
    for (std::size_t successor = 0U; successor < count; ++successor) {
      if (!transition_probability(
               flux, BigNat{static_cast<std::uint64_t>(queue[vertex])},
               BigNat{static_cast<std::uint64_t>(queue[successor])})
               .is_positive()) {
        continue;
      }
      if (discovery[successor] == -1) {
        visit(successor);
        low[vertex] = std::min(low[vertex], low[successor]);
      } else if (on_stack[successor] != 0U) {
        low[vertex] = std::min(low[vertex], discovery[successor]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::size_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = 0U;
      component.push_back(member);
      if (member == vertex) {
        break;
      }
    }
    std::sort(component.begin(), component.end());
    components.push_back(std::move(component));
  };
  for (std::size_t vertex = 0U; vertex < count; ++vertex) {
    if (discovery[vertex] == -1) {
      visit(vertex);
    }
  }
  std::sort(components.begin(), components.end());
  std::vector<std::size_t> component_of(count, 0U);
  for (std::size_t component = 0U; component < components.size(); ++component) {
    for (const std::size_t member : components[component]) {
      component_of[member] = component;
    }
  }
  std::vector<std::uint8_t> component_closed(components.size(), 1U);
  for (std::size_t source = 0U; source < count; ++source) {
    for (std::size_t destination = 0U; destination < count; ++destination) {
      if (component_of[source] != component_of[destination] &&
          transition_probability(
              flux, BigNat{static_cast<std::uint64_t>(queue[source])},
              BigNat{static_cast<std::uint64_t>(queue[destination])})
              .is_positive()) {
        component_closed[component_of[source]] = 0U;
      }
    }
  }
  std::vector<std::size_t> closed_components;
  for (std::size_t component = 0U; component < components.size(); ++component) {
    if (component_closed[component] != 0U) {
      closed_components.push_back(component);
    }
  }
  const auto& selection = flux.identity.selection();
  const bool unique =
      std::holds_alternative<PortableStationaryUniqueSelectionV1>(selection);
  const bool one_class =
      std::holds_alternative<PortableStationaryClassSelectionV1>(selection);
  const auto* mixture =
      std::get_if<PortableStationaryMixtureSelectionV1>(&selection);
  if (!unique && !one_class && mixture == nullptr) {
    return fail<FiniteClosure>(
        "c19.scalar_stationary_selection_required",
        "finite scalar closure requires a stationary selection");
  }
  if (closed_components.size() != 1U) {
    return fail<FiniteClosure>(
        unique ? "c19.scalar_stationary_class_ambiguous"
               : "c19.scalar_stationary_class_seed_mismatch",
        "the selected scalar seed does not reach exactly one closed class");
  }
  if (mixture != nullptr && mixture->components.size() != 1U) {
    return fail<FiniteClosure>(
        "c19.scalar_stationary_mixture_binding_unavailable",
        "a multi-class scalar mixture requires an exact sealed "
        "class-identity-to-support binding",
        DiagnosticCategory::unavailable);
  }
  std::vector<FiniteClosure::SelectedClass> selected;
  {
    const std::size_t component = closed_components.front();
    std::vector<std::size_t> members;
    members.reserve(components[component].size());
    for (const std::size_t position : components[component]) {
      members.push_back(queue[position]);
    }
    selected.push_back({std::move(members), ExactRational::one()});
  }
  return Result<FiniteClosure>::success(
      {true, std::move(queue), std::move(selected)});
}

[[nodiscard]] Result<std::vector<ExactRational>> exact_invariant(
    const std::vector<ExactRational>& matrix, const std::size_t dimension) {
  std::vector<std::vector<ExactRational>> augmented(
      dimension,
      std::vector<ExactRational>(dimension + 1U, ExactRational::zero()));
  for (std::size_t equation = 0U; equation + 1U < dimension; ++equation) {
    for (std::size_t variable = 0U; variable < dimension; ++variable) {
      augmented[equation][variable] =
          matrix[variable * dimension + equation] -
          (variable == equation ? ExactRational::one()
                                : ExactRational::zero());
    }
  }
  for (std::size_t variable = 0U; variable < dimension; ++variable) {
    augmented[dimension - 1U][variable] = ExactRational::one();
  }
  augmented[dimension - 1U][dimension] = ExactRational::one();

  std::size_t rank = 0U;
  for (std::size_t column = 0U; column < dimension && rank < dimension;
       ++column) {
    std::size_t pivot = rank;
    while (pivot < dimension && augmented[pivot][column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      continue;
    }
    std::swap(augmented[pivot], augmented[rank]);
    const ExactRational divisor = augmented[rank][column];
    for (std::size_t entry = column; entry <= dimension; ++entry) {
      auto divided = checked_divide(augmented[rank][entry], divisor);
      if (!divided) {
        return Result<std::vector<ExactRational>>::failure(divided.error());
      }
      augmented[rank][entry] = std::move(divided).value();
    }
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == rank || augmented[row][column].is_zero()) {
        continue;
      }
      const ExactRational factor = augmented[row][column];
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        augmented[row][entry] =
            augmented[row][entry] - factor * augmented[rank][entry];
      }
    }
    ++rank;
  }
  if (rank != dimension) {
    return fail<std::vector<ExactRational>>(
        "c19.multiple_finite_classes",
        "the exact finite closure has no uniquely selected invariant law",
        DiagnosticCategory::unavailable);
  }
  std::vector<ExactRational> solution(dimension, ExactRational::zero());
  for (std::size_t row = 0U; row < dimension; ++row) {
    std::size_t pivot = 0U;
    while (pivot < dimension && augmented[row][pivot].is_zero()) {
      ++pivot;
    }
    if (pivot < dimension) {
      solution[pivot] = augmented[row][dimension];
    }
  }
  for (const auto& mass : solution) {
    if (!mass.is_nonnegative()) {
      return fail<std::vector<ExactRational>>(
          "c19.negative_finite_stationary_mass",
          "the exact finite invariant solve produced negative mass",
          DiagnosticCategory::internal);
    }
  }
  return Result<std::vector<ExactRational>>::success(std::move(solution));
}

[[nodiscard]] long double slack_condition_estimate(
    const ExactRational& slack);

[[nodiscard]] Result<ScalarStationaryLaw> finite_closure_law(
    const std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore>&
        flux,
    const FiniteClosure& closure,
    const std::size_t maximum,
    const AnalyticStationaryStatusV1 status =
        AnalyticStationaryStatusV1::finite_closed_tail_unreachable,
    std::optional<ExactRational> applicable_tail_slack = std::nullopt) {
  if (!closure.closed) {
    return fail<ScalarStationaryLaw>(
        "c19.finite_closure_not_proved",
        "positive deployed transitions cross the proposed finite boundary",
        DiagnosticCategory::unavailable);
  }
  const auto& states = closure.reachable;
  const std::size_t count = states.size();
  std::vector<ExactRational> masses(maximum + 1U, ExactRational::zero());
  ExactRational mean = ExactRational::zero();
  for (const auto& selected : closure.selected_classes) {
    const std::size_t class_size = selected.members.size();
    std::vector<ExactRational> matrix(class_size * class_size,
                                      ExactRational::zero());
    for (std::size_t row = 0U; row < class_size; ++row) {
      ExactRational total = ExactRational::zero();
      for (std::size_t column = 0U; column < class_size; ++column) {
        const ExactRational value = transition_probability(
            *flux,
            BigNat{static_cast<std::uint64_t>(selected.members[row])},
            BigNat{static_cast<std::uint64_t>(selected.members[column])});
        matrix[row * class_size + column] = value;
        total = total + value;
      }
      if (!(total == ExactRational::one())) {
        return fail<ScalarStationaryLaw>(
            "c19.finite_row_mass",
            "an exactly selected closed SF.14 row does not total one",
            DiagnosticCategory::internal);
      }
    }
    auto invariant = exact_invariant(matrix, class_size);
    if (!invariant) {
      return Result<ScalarStationaryLaw>::failure(invariant.error());
    }
    for (std::size_t index = 0U; index < class_size; ++index) {
      const ExactRational weighted =
          selected.weight * invariant.value()[index];
      masses[selected.members[index]] =
          masses[selected.members[index]] + weighted;
      mean = mean +
             weighted * rational_from_size(selected.members[index]);
    }
  }
  std::vector<BigNat> reachable_support;
  reachable_support.reserve(states.size());
  for (const std::size_t state : states) {
    reachable_support.emplace_back(static_cast<std::uint64_t>(state));
  }
  auto proof = detail::C19CoreAccess::finite_closure_proof(
      flux->identity, std::move(reachable_support));
  auto core = std::make_shared<stationary::detail::ScalarStationaryLawCore>(
      stationary::detail::ScalarStationaryLawCore{
          status,
          true,
          stationary::detail::ScalarLawRepresentation::finite,
          std::move(masses),
          ExactRational::zero(),
          mean,
          mean.to_long_double(),
          {ExactRational::zero(), ExactRational::zero(), ExactRational::zero(),
           applicable_tail_slack, BigNat{static_cast<std::uint64_t>(count)},
           applicable_tail_slack
               ? slack_condition_estimate(*applicable_tail_slack)
               : 1.0L},
          flux->identity,
          flux,
          BigNat{static_cast<std::uint64_t>(maximum)},
          std::nullopt,
          std::move(proof)});
  return Result<ScalarStationaryLaw>::success(
      detail::C19CoreAccess::scalar_law(std::move(core)));
}

[[nodiscard]] Result<ScalarStationaryLaw> status_law(
    const std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore>&
        flux,
    const AnalyticStationaryStatusV1 status,
    std::optional<ExactRational> slack = std::nullopt,
    std::optional<BigNat> terms = std::nullopt,
    std::optional<ExactRational> tail_bound = std::nullopt) {
  auto core = std::make_shared<stationary::detail::ScalarStationaryLawCore>(
      stationary::detail::ScalarStationaryLawCore{
          status, false,
          stationary::detail::ScalarLawRepresentation::incomplete, {},
          std::nullopt, std::nullopt, std::nullopt,
          {ExactRational::zero(), ExactRational::zero(),
           std::move(tail_bound),
           std::move(slack), std::move(terms), 0.0L},
          flux->identity, flux, std::nullopt, std::nullopt, std::nullopt});
  return Result<ScalarStationaryLaw>::success(
      detail::C19CoreAccess::scalar_law(std::move(core)));
}

[[nodiscard]] long double slack_condition_estimate(
    const ExactRational& slack) {
  const long double image = slack.to_long_double();
  if (!std::isfinite(image) || image <= 0.0L) {
    return std::numeric_limits<long double>::max();
  }
  const long double reciprocal = 1.0L / image;
  return std::isfinite(reciprocal)
             ? reciprocal
             : std::numeric_limits<long double>::max();
}

[[nodiscard]] Result<ScalarStationaryLaw> incomplete_cut_law(
    const std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore>&
        flux,
    const BigNat& requested_terms,
    std::optional<ExactRational> tail_bound = std::nullopt) {
  auto budget = native_index(requested_terms);
  if (!budget) {
    return Result<ScalarStationaryLaw>::failure(budget.error());
  }
  if (budget.value() == 0U) {
    return status_law(flux, AnalyticStationaryStatusV1::incomplete_tail,
                      std::nullopt, BigNat{0U}, std::move(tail_bound));
  }
  std::vector<ExactRational> weights{ExactRational::one()};
  std::size_t evaluated = 1U;
  while (evaluated < budget.value()) {
    auto next = next_cut_weight(*flux, weights, evaluated);
    if (!next) {
      if (next.error().code == "c19.cut_inconsistent_zero_denominator") {
        return status_law(
            flux, AnalyticStationaryStatusV1::unsupported_assumptions,
            std::nullopt, BigNat{static_cast<std::uint64_t>(evaluated)},
            std::move(tail_bound));
      }
      if (next.error().code != "c19.cut_underdetermined_closed_class") {
        return Result<ScalarStationaryLaw>::failure(next.error());
      }
      return status_law(
          flux,
          AnalyticStationaryStatusV1::degenerate_or_selected_closed_class,
          std::nullopt, BigNat{static_cast<std::uint64_t>(evaluated)},
          std::move(tail_bound));
    }
    if (!next.value().is_nonnegative()) {
      return fail<ScalarStationaryLaw>(
          "c19.negative_cut_weight",
          "SF.19 produced a negative stationary weight",
          DiagnosticCategory::internal);
    }
    weights.push_back(std::move(next).value());
    ++evaluated;
  }
  return status_law(
      flux, AnalyticStationaryStatusV1::incomplete_tail, std::nullopt,
      BigNat{static_cast<std::uint64_t>(evaluated)}, std::move(tail_bound));
}

[[nodiscard]] Result<ScalarStationaryLaw> solve_constant_tail_impl(
    const std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore>&
        flux,
    const Cutoff& cutoff, const TailService& tail_service) {
  auto native_cutoff = native_index(cutoff.value());
  if (!native_cutoff) {
    return Result<ScalarStationaryLaw>::failure(native_cutoff.error());
  }
  const std::size_t maximum = native_cutoff.value();

  if (maximum == std::numeric_limits<std::size_t>::max() ||
      flux->response.prefix.size() <= maximum) {
    // The pure fit accepts a complete mu(0)..mu(K) vector.  Preserve the
    // released C19 boundary ordering for an incomplete caller-supplied
    // prefix: closure and the status-only exits historically preceded the
    // first unavailable coefficient lookup.
    auto closure = prove_finite_closure(*flux, maximum);
    if (!closure) {
      return Result<ScalarStationaryLaw>::failure(closure.error());
    }
    if (closure.value().closed) {
      return finite_closure_law(flux, closure.value(), maximum);
    }
    const ExactRational slack =
        tail_service.value() - flux->arrival->mean;
    if (!slack.is_positive()) {
      return status_law(
          flux, AnalyticStationaryStatusV1::outside_strict_tail_profile,
          slack, cutoff.value() + BigNat{1U});
    }
    if (!arrival_probability(*flux->arrival, BigInt{0}).is_positive()) {
      return status_law(
          flux, AnalyticStationaryStatusV1::unsupported_assumptions,
          slack);
    }
    std::vector<ExactRational> weights{ExactRational::one()};
    weights.reserve(maximum + 1U);
    for (std::size_t cut = 1U; cut <= maximum; ++cut) {
      auto weight = next_cut_weight(*flux, weights, cut);
      if (!weight) {
        if (weight.error().code ==
            "c19.cut_inconsistent_zero_denominator") {
          return status_law(
              flux, AnalyticStationaryStatusV1::unsupported_assumptions,
              slack, BigNat{static_cast<std::uint64_t>(cut)});
        }
        if (weight.error().code !=
            "c19.cut_underdetermined_closed_class") {
          return Result<ScalarStationaryLaw>::failure(weight.error());
        }
        return status_law(
            flux,
            AnalyticStationaryStatusV1::
                degenerate_or_selected_closed_class,
            slack, BigNat{static_cast<std::uint64_t>(cut)});
      }
      if (!weight.value().is_nonnegative()) {
        return fail<ScalarStationaryLaw>(
            "c19.negative_cut_weight",
            "SF.19 produced a negative stationary weight",
            DiagnosticCategory::internal);
      }
      weights.push_back(std::move(weight).value());
    }
    // Only K=0 can reach this point with an incomplete prefix; all positive
    // cuts above query mu(cut).  Reproduce that final historical lookup.
    auto mu_zero = service_probability(flux->response, BigNat{0U});
    if (!mu_zero) {
      return Result<ScalarStationaryLaw>::failure(mu_zero.error());
    }
    return fail<ScalarStationaryLaw>(
        "c19.finite_prefix_fit_compatibility_invariant",
        "an incomplete response prefix unexpectedly covered its cutoff",
        DiagnosticCategory::internal);
  }

  std::vector<FinitePrefixFitArrivalAtomV1> arrival_atoms;
  arrival_atoms.reserve(flux->arrival->atoms.size());
  for (const auto& atom : flux->arrival->atoms) {
    arrival_atoms.push_back({atom.count, atom.mass});
  }
  std::vector<FinitePrefixFitSelectionSeedAtomV1> selection_seed;
  selection_seed.reserve(flux->arrival->selection_seed.size());
  for (const auto& atom : flux->arrival->selection_seed) {
    selection_seed.push_back({atom.backlog, atom.selection_mass});
  }
  std::vector<ExactRational> service_by_level(
      flux->response.prefix.begin(),
      flux->response.prefix.begin() + static_cast<std::ptrdiff_t>(maximum + 1U));
  const Digest256 coefficient_source_digest =
      flux->identity.response_product()
          ? flux->identity.response_product()->object_digest
          : flux->identity.payload().object_digest;
  auto fit = fit_finite_prefix_constant_tail(FinitePrefixFitInputV1{
      std::move(arrival_atoms),
      flux->arrival->second_moment.has_value(),
      flux->arrival->second_moment.has_value(),
      std::move(selection_seed),
      std::move(service_by_level),
      tail_service.value(),
      {coefficient_source_digest, flux->arrival->identity_digest},
      {maximum, flux->arrival->atoms.size(),
       flux->arrival->selection_seed.size(), maximum + 1U},
      std::nullopt,
      false});
  if (!fit) {
    if (fit.error().code == "c19.scalar_stationary_class_ambiguous") {
      const auto& selection = flux->identity.selection();
      const bool unique =
          std::holds_alternative<PortableStationaryUniqueSelectionV1>(
              selection);
      const bool one_class =
          std::holds_alternative<PortableStationaryClassSelectionV1>(
              selection);
      const bool mixture =
          std::holds_alternative<PortableStationaryMixtureSelectionV1>(
              selection);
      if (!unique && !one_class && !mixture) {
        return fail<ScalarStationaryLaw>(
            "c19.scalar_stationary_selection_required",
            "finite scalar closure requires a stationary selection");
      }
      if (!unique) {
        return fail<ScalarStationaryLaw>(
            "c19.scalar_stationary_class_seed_mismatch",
            "the selected scalar seed does not reach exactly one closed "
            "class");
      }
    }
    return Result<ScalarStationaryLaw>::failure(fit.error());
  }
  auto fitted = std::move(fit).value();

  if (fitted.status ==
      FinitePrefixFitStatusV1::finite_closed_tail_unreachable) {
    const auto& selection = flux->identity.selection();
    const bool unique =
        std::holds_alternative<PortableStationaryUniqueSelectionV1>(
            selection);
    const bool one_class =
        std::holds_alternative<PortableStationaryClassSelectionV1>(
            selection);
    if (const auto* mixture =
            std::get_if<PortableStationaryMixtureSelectionV1>(
                &selection);
        !unique && !one_class && mixture == nullptr) {
      return fail<ScalarStationaryLaw>(
          "c19.scalar_stationary_selection_required",
          "finite scalar closure requires a stationary selection");
    } else if (mixture != nullptr && mixture->components.size() != 1U) {
      return fail<ScalarStationaryLaw>(
          "c19.scalar_stationary_mixture_binding_unavailable",
          "a multi-class scalar mixture requires an exact sealed "
          "class-identity-to-support binding",
          DiagnosticCategory::unavailable);
    }
    if (!fitted.fitted_prefix_probabilities ||
        !fitted.fitted_tail_mass || !fitted.fitted_mean_backlog ||
        !fitted.fitted_tail_mass->is_zero()) {
      return fail<ScalarStationaryLaw>(
          "c19.finite_prefix_fit_shape",
          "the pure finite-closure fit did not return one normalized "
          "finite-support law",
          DiagnosticCategory::internal);
    }
    auto proof = detail::C19CoreAccess::finite_closure_proof(
        flux->identity, fitted.finite_reachable_support);
    const std::optional<long double> numerical_mean =
        fitted.fitted_mean_backlog
            ? std::optional<long double>(
                  fitted.fitted_mean_backlog->to_long_double())
            : std::nullopt;
    auto core = std::make_shared<stationary::detail::ScalarStationaryLawCore>(
        stationary::detail::ScalarStationaryLawCore{
            AnalyticStationaryStatusV1::finite_closed_tail_unreachable,
            true,
            stationary::detail::ScalarLawRepresentation::finite,
            std::move(*fitted.fitted_prefix_probabilities),
            ExactRational::zero(),
            std::move(fitted.fitted_mean_backlog),
            numerical_mean,
            {fitted.residuals.normalization.value_or(ExactRational::zero()),
             fitted.residuals.invariance.value_or(ExactRational::zero()),
             ExactRational::zero(), std::nullopt, fitted.terms_evaluated,
             1.0L},
            flux->identity,
            flux,
            cutoff.value(),
            std::nullopt,
            std::move(proof)});
    return Result<ScalarStationaryLaw>::success(
        detail::C19CoreAccess::scalar_law(std::move(core)));
  }

  if (!fitted.normalized_law_established()) {
    AnalyticStationaryStatusV1 status;
    switch (fitted.status) {
      case FinitePrefixFitStatusV1::outside_strict_tail_profile:
        status = AnalyticStationaryStatusV1::outside_strict_tail_profile;
        break;
      case FinitePrefixFitStatusV1::degenerate_or_selected_closed_class:
        status =
            AnalyticStationaryStatusV1::degenerate_or_selected_closed_class;
        break;
      case FinitePrefixFitStatusV1::unsupported_assumptions:
        status = AnalyticStationaryStatusV1::unsupported_assumptions;
        break;
      case FinitePrefixFitStatusV1::strict_tail_stable:
      case FinitePrefixFitStatusV1::finite_closed_tail_unreachable:
      case FinitePrefixFitStatusV1::required_moment_unavailable:
        return fail<ScalarStationaryLaw>(
            "c19.finite_prefix_fit_status_invariant",
            "the pure fit status contradicts its missing normalized law",
            DiagnosticCategory::internal);
    }
    std::optional<BigNat> terms;
    if (!fitted.terms_evaluated.is_zero()) {
      terms = fitted.terms_evaluated;
    }
    return status_law(flux, status, fitted.tail_slack, std::move(terms));
  }

  if ((fitted.status != FinitePrefixFitStatusV1::strict_tail_stable &&
       fitted.status !=
           FinitePrefixFitStatusV1::required_moment_unavailable) ||
      !fitted.fitted_prefix_probabilities || !fitted.fitted_tail_mass ||
      !fitted.tail_slack) {
    return fail<ScalarStationaryLaw>(
        "c19.finite_prefix_fit_status_invariant",
        "the pure constant-tail fit returned an inconsistent normalized law",
        DiagnosticCategory::internal);
  }
  std::optional<long double> numerical_mean;
  if (fitted.fitted_mean_backlog) {
    const long double image = fitted.fitted_mean_backlog->to_long_double();
    if (std::isfinite(image)) {
      numerical_mean = image;
    }
  }
  const AnalyticStationaryStatusV1 status =
      fitted.status == FinitePrefixFitStatusV1::strict_tail_stable
          ? AnalyticStationaryStatusV1::strict_tail_stable
          : AnalyticStationaryStatusV1::required_moment_unavailable;
  auto core = std::make_shared<stationary::detail::ScalarStationaryLawCore>(
      stationary::detail::ScalarStationaryLawCore{
          status,
          true,
          stationary::detail::ScalarLawRepresentation::constant_tail,
          std::move(*fitted.fitted_prefix_probabilities),
          std::move(fitted.fitted_tail_mass),
          std::move(fitted.fitted_mean_backlog),
          numerical_mean,
          {fitted.residuals.normalization.value_or(ExactRational::zero()),
           fitted.residuals.invariance.value_or(ExactRational::zero()),
           std::nullopt, fitted.tail_slack, fitted.terms_evaluated,
           slack_condition_estimate(*fitted.tail_slack)},
          flux->identity,
          flux,
          cutoff.value(),
          tail_service.value(),
          std::nullopt});
  return Result<ScalarStationaryLaw>::success(
      detail::C19CoreAccess::scalar_law(std::move(core)));
}

[[nodiscard]] Result<ScalarStationaryLaw> bernoulli_unit_rate_endpoint(
    const std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore>&
        flux,
    const std::size_t cutoff) {
  // At lambda=1 a unit-response level is absorbing; at lambda=0 the chain is
  // nonincreasing.  In either endpoint case the selected alpha0 support, not
  // an invented path from zero, determines which closed class is solved.
  if (flux->arrival->selection_seed.empty()) {
    if (flux->arrival->mean.is_zero() &&
        std::holds_alternative<PortableStationaryUniqueSelectionV1>(
            flux->identity.selection())) {
      bool every_positive_level_descends =
          flux->response.constant_tail_service &&
          flux->response.constant_tail_service->is_positive();
      for (std::size_t level = 1U;
           every_positive_level_descends && level <= cutoff; ++level) {
        auto service = service_probability(
            flux->response, BigNat{static_cast<std::uint64_t>(level)});
        if (!service) {
          return Result<ScalarStationaryLaw>::failure(service.error());
        }
        every_positive_level_descends = service.value().is_positive();
      }
      if (every_positive_level_descends) {
        const FiniteClosure delta_zero{
            true, {0U}, {{{0U}, ExactRational::one()}}};
        return finite_closure_law(
            flux, delta_zero, 0U,
            AnalyticStationaryStatusV1::degenerate_or_selected_closed_class);
      }
    }
    return status_law(
        flux, AnalyticStationaryStatusV1::multiple_classes_or_roots);
  }
  std::size_t maximum = cutoff;
  for (const auto& atom : flux->arrival->selection_seed) {
    if (!atom.selection_mass.is_positive()) {
      continue;
    }
    auto level = native_index(atom.backlog);
    if (!level) {
      return Result<ScalarStationaryLaw>::failure(level.error());
    }
    maximum = std::max(maximum, level.value());
  }
  if (flux->arrival->mean == ExactRational::one()) {
    if (flux->response.constant_tail_service != ExactRational::one() ||
        maximum == std::numeric_limits<std::size_t>::max()) {
      return status_law(flux, AnalyticStationaryStatusV1::not_summable);
    }
    maximum = std::max(maximum, cutoff + 1U);
  }
  auto closure = prove_finite_closure(*flux, maximum);
  if (!closure) {
    return Result<ScalarStationaryLaw>::failure(closure.error());
  }
  if (!closure.value().closed) {
    return status_law(flux, AnalyticStationaryStatusV1::not_summable);
  }
  return finite_closure_law(
      flux, closure.value(), maximum,
      AnalyticStationaryStatusV1::degenerate_or_selected_closed_class);
}

[[nodiscard]] Result<ScalarStationaryLaw> solve_bernoulli_impl(
    const std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore>&
        flux) {
  const ExactRational lambda = flux->arrival->mean;
  if (!flux->response.constant_tail_from ||
      !flux->response.constant_tail_service) {
    const std::size_t maximum = flux->response.prefix.empty()
                                    ? 0U
                                    : flux->response.prefix.size() - 1U;
    auto closure = prove_finite_closure(*flux, maximum);
    if (!closure) {
      return Result<ScalarStationaryLaw>::failure(closure.error());
    }
    if (closure.value().closed) {
      return finite_closure_law(flux, closure.value(), maximum,
                                AnalyticStationaryStatusV1::finite);
    }
    return status_law(flux, AnalyticStationaryStatusV1::incomplete_tail);
  }
  auto tail_from = native_index(*flux->response.constant_tail_from);
  if (!tail_from || tail_from.value() == 0U) {
    return fail<ScalarStationaryLaw>(
        "c19.invalid_constant_tail_start",
        "the Bernoulli response tail must begin at a positive level");
  }
  const std::size_t cutoff = tail_from.value() - 1U;

  // Endpoint and zero-response cases are class questions, so the exact
  // deployed closure test precedes every division in SF.21.
  auto closure = prove_finite_closure(*flux, cutoff);
  if (!closure) {
    return Result<ScalarStationaryLaw>::failure(closure.error());
  }
    if (closure.value().closed) {
      const auto status =
          lambda.is_zero() || lambda == ExactRational::one()
              ? AnalyticStationaryStatusV1::degenerate_or_selected_closed_class
              : AnalyticStationaryStatusV1::finite;
      return finite_closure_law(flux, closure.value(), cutoff, status);
  }

  const ExactRational one_minus_lambda = ExactRational::one() - lambda;
  if (lambda == ExactRational::one() || lambda.is_zero()) {
    return bernoulli_unit_rate_endpoint(flux, cutoff);
  }
  if (!lambda.is_positive() || !one_minus_lambda.is_positive()) {
    return status_law(flux, AnalyticStationaryStatusV1::not_summable);
  }
  const ExactRational c = *flux->response.constant_tail_service;
  const ExactRational slack = c - lambda;
  if (!slack.is_positive()) {
    return status_law(flux, AnalyticStationaryStatusV1::not_summable, slack);
  }

  // SF.21 generates the exact unnormalized birth--death weights.  The first
  // tail weight uses the boundary response mu(K); all subsequent ratios use c.
  std::vector<ExactRational> weights{ExactRational::one()};
  weights.reserve(cutoff + 2U);
  for (std::size_t level = 0U; level <= cutoff; ++level) {
    auto mu_n = service_probability(
        flux->response, BigNat{static_cast<std::uint64_t>(level)});
    auto mu_next = service_probability(
        flux->response, BigNat{static_cast<std::uint64_t>(level + 1U)});
    if (!mu_n || !mu_next) {
      return Result<ScalarStationaryLaw>::failure(
          !mu_n ? mu_n.error() : mu_next.error());
    }
    const ExactRational numerator =
        lambda * (ExactRational::one() - mu_n.value());
    const ExactRational denominator = one_minus_lambda * mu_next.value();
    if (denominator.is_zero()) {
      if (numerator.is_positive()) {
        return fail<ScalarStationaryLaw>(
            "c19.cut_inconsistent_zero_denominator",
            "SF.21 has positive upward weight but zero downward "
            "coefficient");
      }
      return status_law(
          flux, AnalyticStationaryStatusV1::degenerate_or_selected_closed_class,
          slack, BigNat{static_cast<std::uint64_t>(level + 1U)});
    }
    auto ratio = checked_divide(numerator, denominator);
    if (!ratio) {
      return Result<ScalarStationaryLaw>::failure(ratio.error());
    }
    weights.push_back(weights.back() * ratio.value());
  }
  const ExactRational tail_ratio_numerator =
      lambda * (ExactRational::one() - c);
  const ExactRational tail_ratio_denominator = one_minus_lambda * c;
  if (tail_ratio_denominator.is_zero()) {
    return status_law(flux, AnalyticStationaryStatusV1::not_summable, slack);
  }
  auto tail_ratio =
      checked_divide(tail_ratio_numerator, tail_ratio_denominator);
  if (!tail_ratio || tail_ratio.value() >= ExactRational::one()) {
    return status_law(flux, AnalyticStationaryStatusV1::not_summable, slack);
  }
  if (tail_ratio.value().is_zero()) {
    auto finite = prove_finite_closure(*flux, cutoff + 1U);
    if (!finite) {
      return Result<ScalarStationaryLaw>::failure(finite.error());
    }
    return finite_closure_law(
        flux, finite.value(), cutoff + 1U,
        AnalyticStationaryStatusV1::strict_tail_stable, slack);
  }
  const ExactRational one_minus_ratio =
      ExactRational::one() - tail_ratio.value();
  ExactRational prefix_weight = ExactRational::zero();
  for (std::size_t level = 0U; level <= cutoff; ++level) {
    prefix_weight = prefix_weight + weights[level];
  }
  auto tail_weight = checked_divide(weights[cutoff + 1U], one_minus_ratio);
  if (!tail_weight) {
    return Result<ScalarStationaryLaw>::failure(tail_weight.error());
  }
  const ExactRational normalizer = prefix_weight + tail_weight.value();
  if (!normalizer.is_positive()) {
    return fail<ScalarStationaryLaw>(
        "c19.bernoulli_normalizer_nonpositive",
        "the summable SF.21 weights require a positive total");
  }
  std::vector<ExactRational> masses;
  masses.reserve(cutoff + 1U);
  ExactRational prefix_mass = ExactRational::zero();
  ExactRational prefix_mean = ExactRational::zero();
  for (std::size_t level = 0U; level <= cutoff; ++level) {
    auto mass = checked_divide(weights[level], normalizer);
    if (!mass) {
      return Result<ScalarStationaryLaw>::failure(mass.error());
    }
    prefix_mass = prefix_mass + mass.value();
    prefix_mean =
        prefix_mean + rational_from_size(level) * mass.value();
    masses.push_back(std::move(mass).value());
  }
  auto first_tail_mass =
      checked_divide(weights[cutoff + 1U], normalizer);
  if (!first_tail_mass) {
    return Result<ScalarStationaryLaw>::failure(first_tail_mass.error());
  }
  auto aggregate_tail =
      checked_divide(first_tail_mass.value(), one_minus_ratio);
  if (!aggregate_tail) {
    return Result<ScalarStationaryLaw>::failure(aggregate_tail.error());
  }
  auto tail_level_term = checked_divide(
      rational_from_size(cutoff + 1U), one_minus_ratio);
  auto tail_offset_term = checked_divide(
      tail_ratio.value(), one_minus_ratio * one_minus_ratio);
  if (!tail_level_term || !tail_offset_term) {
    return Result<ScalarStationaryLaw>::failure(
        !tail_level_term ? tail_level_term.error() : tail_offset_term.error());
  }
  const ExactRational mean =
      prefix_mean + first_tail_mass.value() *
                        (tail_level_term.value() + tail_offset_term.value());
  if (!(prefix_mass + aggregate_tail.value() == ExactRational::one())) {
    return fail<ScalarStationaryLaw>(
        "c19.bernoulli_normalization_invariant",
        "the normalized SF.21 weights do not total exactly one",
        DiagnosticCategory::internal);
  }
  auto core = std::make_shared<stationary::detail::ScalarStationaryLawCore>(
      stationary::detail::ScalarStationaryLawCore{
          AnalyticStationaryStatusV1::strict_tail_stable,
          true,
          stationary::detail::ScalarLawRepresentation::constant_tail,
          std::move(masses),
          aggregate_tail.value(),
          mean,
          std::isfinite(mean.to_long_double())
              ? std::optional<long double>(mean.to_long_double())
              : std::nullopt,
          {ExactRational::zero(), ExactRational::zero(), std::nullopt, slack,
           BigNat{static_cast<std::uint64_t>(cutoff + 1U)},
           slack_condition_estimate(slack)},
          flux->identity,
          flux,
          BigNat{static_cast<std::uint64_t>(cutoff)},
          c,
          std::nullopt});
  return Result<ScalarStationaryLaw>::success(
      detail::C19CoreAccess::scalar_law(std::move(core)));
}

[[nodiscard]] ExactRational exact_power(ExactRational base,
                                        BigInt exponent) {
  ExactRational result = ExactRational::one();
  while (exponent > 0) {
    if ((exponent & 1) != 0) {
      result = result * base;
    }
    exponent >>= 1;
    if (exponent > 0) {
      base = base * base;
    }
  }
  return result;
}

[[nodiscard]] ExactRational arrival_pgf(
    const stationary::detail::ArrivalLawCore& arrival,
    const ExactRational& z) {
  ExactRational value = ExactRational::zero();
  for (const auto& atom : arrival.atoms) {
    value = value + atom.mass * exact_power(z, atom.count.value());
  }
  return value;
}

[[nodiscard]] Result<ExactRational> scalar_mass_at(
    const stationary::detail::ScalarStationaryLawCore& law,
    const BigNat& backlog) {
  auto index = native_index(backlog);
  if (index && index.value() < law.prefix_masses.size()) {
    return Result<ExactRational>::success(law.prefix_masses[index.value()]);
  }
  if (law.representation == stationary::detail::ScalarLawRepresentation::finite) {
    return Result<ExactRational>::success(ExactRational::zero());
  }
  if (!law.normalized ||
      law.representation !=
          stationary::detail::ScalarLawRepresentation::constant_tail ||
      !law.flux) {
    return fail<ExactRational>(
        "c19.stationary_mass_not_established",
        "the requested mass is unavailable without a normalized law",
        DiagnosticCategory::unavailable);
  }
  if (!index) {
    return Result<ExactRational>::failure(index.error());
  }
  std::vector<ExactRational> masses = law.prefix_masses;
  masses.reserve(index.value() + 1U);
  for (std::size_t cut = masses.size(); cut <= index.value(); ++cut) {
    auto next = next_cut_weight(*law.flux, masses, cut);
    if (!next) {
      return Result<ExactRational>::failure(next.error());
    }
    masses.push_back(std::move(next).value());
  }
  return Result<ExactRational>::success(masses[index.value()]);
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0U};
                     });
}

[[nodiscard]] Result<void> validate_solver_policy(
    const SolverPolicy& policy) {
  if (policy.linear_method != LinearMethod::dense_pivoted) {
    return fail_void("c19.solver_method_unavailable",
                     "C19 implements the declared dense_pivoted analytic "
                     "solve only",
                     DiagnosticCategory::unavailable);
  }
  if (!policy.absolute_residual_tolerance.is_nonnegative() ||
      !policy.relative_residual_tolerance.is_zero() ||
      !nonzero_digest(policy.analysis_fingerprint)) {
    return fail_void(
        "c19.invalid_solver_policy",
        "the analytic solver requires a nonnegative absolute tolerance, "
        "zero relative tolerance, and a nonzero analysis fingerprint");
  }
  const long double tolerance =
      policy.absolute_residual_tolerance.to_long_double();
  if (!std::isfinite(tolerance) || tolerance < 0.0L) {
    return fail_void("c19.unusable_solver_tolerance",
                     "the absolute tolerance has no finite numerical image");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<PortableAnalysisSelectionV1> portable_selection(
    const SelectionSpec& selection) {
  if (std::holds_alternative<TransientSelection>(selection)) {
    return Result<PortableAnalysisSelectionV1>::success(
        PortableTransientSelectionV1{});
  }
  if (std::holds_alternative<StationaryUniqueSelection>(selection)) {
    return Result<PortableAnalysisSelectionV1>::success(
        PortableStationaryUniqueSelectionV1{});
  }
  if (const auto* one = std::get_if<StationaryClassSelection>(&selection)) {
    return Result<PortableAnalysisSelectionV1>::success(
        PortableStationaryClassSelectionV1{one->class_id});
  }
  if (const auto* mixture =
          std::get_if<StationaryMixtureSelection>(&selection)) {
    if (mixture->components.empty()) {
      return fail<PortableAnalysisSelectionV1>(
          "c19.empty_stationary_mixture",
          "a stationary mixture must name at least one class");
    }
    ExactRational total = ExactRational::zero();
    for (std::size_t index = 0U; index < mixture->components.size(); ++index) {
      const auto& component = mixture->components[index];
      if (!component.probability.exact_value().is_nonnegative()) {
        return fail<PortableAnalysisSelectionV1>(
            "c19.negative_stationary_mixture_weight",
            "stationary mixture weights must be nonnegative");
      }
      for (std::size_t prior = 0U; prior < index; ++prior) {
        if (mixture->components[prior].class_id == component.class_id) {
          return fail<PortableAnalysisSelectionV1>(
              "c19.duplicate_stationary_mixture_class",
              "a stationary mixture may name each class only once");
        }
      }
      total = total + component.probability.exact_value();
    }
    if (!total.is_positive()) {
      return fail<PortableAnalysisSelectionV1>(
          "c19.nonpositive_stationary_mixture",
          "stationary mixture weights require positive total mass");
    }
    std::vector<PortableStationaryMixtureComponentV1> components;
    components.reserve(mixture->components.size());
    for (const auto& component : mixture->components) {
      auto weight = checked_divide(component.probability.exact_value(), total);
      if (!weight) {
        return Result<PortableAnalysisSelectionV1>::failure(weight.error());
      }
      components.push_back(
          {component.class_id, std::move(weight).value()});
    }
    return Result<PortableAnalysisSelectionV1>::success(
        PortableStationaryMixtureSelectionV1{std::move(components)});
  }
  const auto* fixed = std::get_if<FixedPointSelection>(&selection);
  if (fixed == nullptr) {
    return fail<PortableAnalysisSelectionV1>(
        "c19.selection_unavailable", "the analysis selector is unsupported");
  }
  if (std::holds_alternative<FixedPointUniqueSelection>(*fixed)) {
    return Result<PortableAnalysisSelectionV1>::success(
        PortableFixedPointUniqueSelectionV1{});
  }
  return Result<PortableAnalysisSelectionV1>::success(
      PortableFixedPointIdSelectionV1{
          std::get<FixedPointIdSelection>(*fixed).solution_id});
}

[[nodiscard]] ArrivalBinding carrier_arrival_binding(
    const stationary::detail::C19CarrierLineageV1& lineage) {
  return {lineage.arrival_family,
          TimingConvention::early_service_late_admission,
          1U,
          ArrivalLawDigest(lineage.lineage_identity),
          QueueCatalogDigest(lineage.lineage_identity)};
}

class C19SnapshotEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void boolean(const bool value) { byte(value ? 1U : 0U); }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  void count(const std::size_t value) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    u64(static_cast<std::uint64_t>(value));
  }
  void raw(const std::span<const std::byte> value) {
    count(value.size());
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void raw_u8(const std::span<const std::uint8_t> value) {
    count(value.size());
    for (const std::uint8_t item : value) {
      byte(item);
    }
  }
  void string(const std::string_view value) {
    count(value.size());
    for (const char item : value) {
      byte(static_cast<std::uint8_t>(static_cast<unsigned char>(item)));
    }
  }
  void digest(const Digest256& value) { raw(value.bytes()); }
  void rational(const ExactRational& value) {
    string(value.numerator_decimal());
    string(value.denominator_decimal());
  }
  void natural(const BigNat& value) {
    raw_u8(value.canonical_magnitude_bytes());
  }
  void label(const TypedLabel& value) { raw_u8(value.canonical_bytes()); }
  void codec(const CodecIdentityV1& value) {
    string(value.id);
    u64(value.version);
  }
  void object(const ArtifactObjectReferenceV1& value) {
    label(value.object_id);
    digest(value.object_digest);
  }
  void solver_policy(const SolverPolicy& value) {
    u64(static_cast<std::uint64_t>(value.linear_method));
    boolean(value.max_iterations.has_value());
    if (value.max_iterations) {
      natural(*value.max_iterations);
    }
    rational(value.absolute_residual_tolerance);
    rational(value.relative_residual_tolerance);
    digest(value.analysis_fingerprint);
  }
  [[nodiscard]] Result<Digest256> finish(const std::string_view domain) {
    return sha256_domain_separated(domain, bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

template <typename PhaseCarrier>
[[nodiscard]] Result<Digest256> phase_carrier_snapshot_digest(
    const PhaseCarrier& spec,
    const StationaryAnalyticLawIdentityV1& identity) {
  C19SnapshotEncoder encoder;
  encoder.digest(identity.execution_seal_digest());
  encoder.count(spec.phases.size());
  for (const auto& phase : spec.phases) {
    encoder.u64(static_cast<std::uint64_t>(phase.family));
    encoder.raw(phase.canonical_state);
  }
  encoder.count(spec.arrival_blocks.size());
  for (const auto& block : spec.arrival_blocks) {
    encoder.natural(block.arrival_count);
    encoder.count(block.row_major.size());
    for (const auto& mass : block.row_major) {
      encoder.rational(mass);
    }
  }
  encoder.count(spec.configured_phase_marginal.size());
  for (const auto& mass : spec.configured_phase_marginal) {
    encoder.rational(mass);
  }
  encoder.count(spec.service_row_major.size());
  for (const auto& service : spec.service_row_major) {
    encoder.rational(service);
  }
  encoder.u64(static_cast<std::uint64_t>(spec.completion.kind));
  encoder.natural(spec.completion.maximum_level);
  encoder.boolean(spec.completion.completion_identity.has_value());
  if (spec.completion.completion_identity) {
    encoder.digest(*spec.completion.completion_identity);
  }
  encoder.count(spec.completion.additive_atoms.size());
  for (const auto& atom : spec.completion.additive_atoms) {
    encoder.count(atom.source_flat_index);
    encoder.count(atom.successor_flat_index);
    encoder.rational(atom.mass);
  }
  encoder.solver_policy(spec.solver_policy);
  return encoder.finish("mwperf.c19.phase-carrier-snapshot.v1");
}

template <typename FixedCarrier>
[[nodiscard]] Result<Digest256> fixed_carrier_snapshot_digest(
    const FixedCarrier& spec,
    const StationaryAnalyticLawIdentityV1& identity) {
  C19SnapshotEncoder encoder;
  encoder.digest(identity.execution_seal_digest());
  const auto rationals = [&](const std::span<const ExactRational> values) {
    encoder.count(values.size());
    for (const auto& value : values) {
      encoder.rational(value);
    }
  };
  rationals(spec.domain_lower);
  rationals(spec.domain_upper);
  rationals(spec.codomain_lower);
  rationals(spec.codomain_upper);
  rationals(spec.cold_initial);
  encoder.u64(static_cast<std::uint64_t>(spec.stopping_norm));
  encoder.natural(spec.iteration_budget);
  encoder.natural(spec.evaluation_budget);
  encoder.boolean(spec.uniqueness_declared);
  encoder.count(spec.named_solutions.size());
  for (const auto& solution : spec.named_solutions) {
    encoder.label(solution.id);
    rationals(solution.parameters);
  }
  encoder.object(spec.stable_map_identity);
  encoder.string(spec.family_identity.family_id);
  encoder.u64(spec.family_identity.family_version);
  encoder.codec(spec.family_identity.parameter_schema);
  encoder.codec(spec.family_identity.domain_schema);
  encoder.codec(spec.access_shape.argument_codec);
  encoder.codec(spec.access_shape.response_codec);
  encoder.solver_policy(spec.solver_policy);
  return encoder.finish("mwperf.c19.fixed-carrier-snapshot.v1");
}

[[nodiscard]] StationaryAnalyticLawIdentityV1 identity_with_snapshot(
    const StationaryAnalyticLawIdentityV1& identity, Digest256 snapshot) {
  auto copied = detail::C19CoreAccess::core(identity);
  copied.carrier_snapshot_digest = std::move(snapshot);
  return detail::C19CoreAccess::identity(
      std::make_shared<stationary::detail::StationaryAnalyticLawIdentityCore>(
          std::move(copied)));
}

[[nodiscard]] Result<StationaryAnalyticLawIdentityV1> carrier_identity(
    const stationary::detail::C19CarrierLineageV1& lineage,
    const SelectionSpec& selection, const PayloadPhaseKindV1 payload_phase,
    const PayloadClassTagV1 payload_class) {
  if (!nonzero_digest(lineage.lineage_identity) ||
      !nonzero_digest(lineage.analysis_fingerprint)) {
    return fail<StationaryAnalyticLawIdentityV1>(
        "c19.carrier_lineage_identity",
        "a C19 audited carrier requires nonzero lineage and analysis "
        "identities");
  }
  auto portable = portable_selection(selection);
  if (!portable) {
    return Result<StationaryAnalyticLawIdentityV1>::failure(portable.error());
  }
  auto selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(selection);
  if (!selection_digest) {
    return Result<StationaryAnalyticLawIdentityV1>::failure(
        selection_digest.error());
  }
  const Digest256& bound = lineage.lineage_identity;
  const QueueId target(TypedLabel::numeric(BigNat{0U}));
  const ArtifactObjectReferenceV1 payload{
      TypedLabel::numeric(BigNat{19U}), bound};
  const MetricClauseIdV1 clause{"c19.fixture.metric", 0U};
  const RealizedReferenceCoreV1 reference_core{
      {target}, MetricTargetScopeV1::deployed_singleton_target,
      MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::deployed_surrogate_law, {}, {}};
  const RealizedMetricBindingV1 realized{
      {clause, MetricSupportRoleV1::deployed_payload},
      DeployedPayloadReferenceV1{reference_core, ArtifactPayloadRef{payload}}};
  const AuditedFrameworkBindingsV1 framework{
      FrameworkProblemFingerprintsV1{
          InputFingerprintBundle{bound, lineage.analysis_fingerprint, bound},
          bound, bound, bound, bound, bound},
      FrameworkProblemViewDigest(bound),
      bound,
      bound,
      bound,
      bound,
      bound,
      bound,
      bound,
      selection_digest.value(),
      bound,
      std::nullopt};
  const ArtifactValidationBindingsV1 artifact{
      bound,
      bound,
      ProviderIdentityV1{"c19.exact-carrier", "1"},
      1U,
      bound,
      lineage.construction_method,
      lineage.producer_mode,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      PayloadClassV1{payload_class, 1U},
      bound,
      selection_digest.value(),
      bound,
      bound,
      bound,
      bound,
      bound,
      bound,
      bound};
  auto core = std::make_shared<
      stationary::detail::StationaryAnalyticLawIdentityCore>(
      stationary::detail::StationaryAnalyticLawIdentityCore{
          framework,
          artifact,
          bound,
          std::nullopt,
          payload,
          clause,
          realized,
          payload_phase,
          std::nullopt,
          std::nullopt,
          std::nullopt,
          std::nullopt,
          std::nullopt,
          carrier_arrival_binding(lineage),
          std::move(portable).value(),
          target,
          {target},
          MetricResultScopeV1::surrogate_law});
  return Result<StationaryAnalyticLawIdentityV1>::success(
      detail::C19CoreAccess::identity(std::move(core)));
}

[[nodiscard]] const Digest256& bound_analysis_fingerprint(
    const StationaryAnalyticLawIdentityV1& identity) {
  return identity.framework()
      .problem_fingerprints.authored_inputs.analysis;
}

[[nodiscard]] Result<std::vector<
    stationary::detail::C19ScalarSelectionSeedAtomV1>>
canonical_scalar_selection_seed(
    std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1> atoms) {
  if (atoms.empty()) {
    return Result<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>::success({});
  }
  std::sort(atoms.begin(), atoms.end(), [](const auto& left,
                                           const auto& right) {
    return left.backlog < right.backlog;
  });
  std::vector<stationary::detail::C19ScalarSelectionSeedAtomV1> canonical;
  for (auto& atom : atoms) {
    if (!atom.selection_mass.is_nonnegative()) {
      return fail<std::vector<
          stationary::detail::C19ScalarSelectionSeedAtomV1>>(
          "c19.scalar_selection_seed_negative",
          "selected scalar seed masses must be nonnegative");
    }
    if (!canonical.empty() && canonical.back().backlog == atom.backlog) {
      canonical.back().selection_mass =
          canonical.back().selection_mass + atom.selection_mass;
    } else {
      canonical.push_back(std::move(atom));
    }
  }
  std::erase_if(canonical, [](const auto& atom) {
    return atom.selection_mass.is_zero();
  });
  ExactRational total = ExactRational::zero();
  for (const auto& atom : canonical) {
    total = total + atom.selection_mass;
  }
  if (!(total == ExactRational::one())) {
    return fail<std::vector<
        stationary::detail::C19ScalarSelectionSeedAtomV1>>(
        "c19.scalar_selection_seed_not_normalized",
        "selected scalar seed masses must total exactly one");
  }
  return Result<std::vector<
      stationary::detail::C19ScalarSelectionSeedAtomV1>>::success(
      std::move(canonical));
}

[[nodiscard]] Result<std::shared_ptr<const
    stationary::detail::AuditedScalarResponseCarrierCore>>
make_scalar_carrier(
    stationary::detail::C19ScalarResponseCarrierSpecV1 spec) {
  auto identity = carrier_identity(
      spec.lineage, spec.selection, PayloadPhaseKindV1::phase_free,
      PayloadClassTagV1::three_bin_scalar_response_v1);
  if (!identity) {
    return Result<std::shared_ptr<const
        stationary::detail::AuditedScalarResponseCarrierCore>>::failure(
        identity.error());
  }
  stationary::detail::ScalarResponseData response{
      spec.service_by_level, spec.constant_tail_from,
      spec.constant_tail_service};
  auto valid_response = validate_response(response);
  if (!valid_response) {
    return Result<std::shared_ptr<const
        stationary::detail::AuditedScalarResponseCarrierCore>>::failure(
        valid_response.error());
  }
  auto seed = canonical_scalar_selection_seed(std::move(spec.selection_seed));
  if (!seed) {
    return Result<std::shared_ptr<const
        stationary::detail::AuditedScalarResponseCarrierCore>>::failure(
        seed.error());
  }
  auto portable = portable_selection(spec.selection);
  if (!portable ||
      (!std::holds_alternative<PortableStationaryUniqueSelectionV1>(
           portable.value()) &&
       !std::holds_alternative<PortableStationaryClassSelectionV1>(
           portable.value()) &&
       !std::holds_alternative<PortableStationaryMixtureSelectionV1>(
           portable.value()))) {
    return fail<std::shared_ptr<const
        stationary::detail::AuditedScalarResponseCarrierCore>>(
        "c19.scalar_stationary_selection_required",
        "a scalar stationary carrier requires a stationary selection");
  }
  StationaryAnalyticLawIdentityV1 law_identity = std::move(identity).value();
  if (spec.constant_tail_from && spec.constant_tail_service) {
    auto cutoff = checked_subtract(*spec.constant_tail_from, BigNat{1U});
    if (!cutoff) {
      return fail<std::shared_ptr<const
          stationary::detail::AuditedScalarResponseCarrierCore>>(
          "c19.constant_tail_boundary_invalid",
          "a constant-tail response must begin at a positive level");
    }
    auto copied = detail::C19CoreAccess::core(law_identity);
    copied.cutoff = std::move(cutoff).value();
    copied.tail_service = spec.constant_tail_service;
    law_identity = detail::C19CoreAccess::identity(
        std::make_shared<
            stationary::detail::StationaryAnalyticLawIdentityCore>(
            std::move(copied)));
  }
  std::shared_ptr<const void> seal =
      std::make_shared<Digest256>(spec.lineage.lineage_identity);
  auto carrier = std::make_shared<
      stationary::detail::AuditedScalarResponseCarrierCore>(
      stationary::detail::AuditedScalarResponseCarrierCore{
          std::move(spec.arrival_atoms), spec.second_moment_available,
          spec.temporal_iid, std::move(spec.service_by_level),
          std::move(spec.constant_tail_from),
          std::move(spec.constant_tail_service), std::move(seed).value(),
          spec.little_law_premises, std::move(law_identity),
          std::move(seal)});
  return Result<std::shared_ptr<const
      stationary::detail::AuditedScalarResponseCarrierCore>>::success(
      std::move(carrier));
}

[[nodiscard]] Result<stationary::detail::ScalarResponseData>
scalar_response_from_carrier(
    const std::shared_ptr<const
                          stationary::detail::AuditedScalarResponseCarrierCore>&
        carrier,
    const stationary::detail::ArrivalLawCore& arrival) {
  if (!carrier || arrival.seal.get() != carrier->seal.get() ||
      !(arrival.identity == carrier->identity) ||
      !(arrival.configured_arrival == carrier->identity.configured_arrival())) {
    return fail<stationary::detail::ScalarResponseData>(
        "c19.response_arrival_identity_mismatch",
        "the response and arrival law do not share one immutable C19 "
        "carrier identity");
  }
  stationary::detail::ScalarResponseData response{
      carrier->service_by_level, carrier->constant_tail_from,
      carrier->constant_tail_service};
  auto valid = validate_response(response);
  if (!valid) {
    return Result<stationary::detail::ScalarResponseData>::failure(
        valid.error());
  }
  return Result<stationary::detail::ScalarResponseData>::success(
      std::move(response));
}

[[nodiscard]] LittleLawPremises carrier_little_law_premises(
    const stationary::detail::C19LittleLawPremisesV1& premises) {
  return {premises.lossless, premises.unit_packets,
          premises.eventual_departure, premises.positive_finite_intensity,
          premises.finite_first_backlog_moment, premises.little_law};
}

[[nodiscard]] Result<StationaryAnalyticLawIdentityV1>
identity_with_selection(const StationaryAnalyticLawIdentityV1& identity,
                        const SelectionSpec& selection) {
  auto portable = portable_selection(selection);
  if (!portable) {
    return Result<StationaryAnalyticLawIdentityV1>::failure(portable.error());
  }
  auto copied = detail::C19CoreAccess::core(identity);
  copied.selection = std::move(portable).value();
  return Result<StationaryAnalyticLawIdentityV1>::success(
      detail::C19CoreAccess::identity(
          std::make_shared<
              stationary::detail::StationaryAnalyticLawIdentityCore>(
              std::move(copied))));
}

[[nodiscard]] bool same_completion(const PhaseLevelCompletionV1& left,
                                   const PhaseLevelCompletionV1& right) {
  if (left.kind != right.kind ||
      !(left.maximum_level == right.maximum_level) ||
      left.completion_identity != right.completion_identity ||
      left.additive_atoms.size() != right.additive_atoms.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < left.additive_atoms.size(); ++index) {
    const auto& first = left.additive_atoms[index];
    const auto& second = right.additive_atoms[index];
    if (first.source_flat_index != second.source_flat_index ||
        first.successor_flat_index != second.successor_flat_index ||
        !(first.mass == second.mass)) {
      return false;
    }
  }
  return true;
}

#if defined(MWPERF_C19_TEST_SEAMS)
[[nodiscard]] bool same_phase_kernel(
    const stationary::detail::PhaseArrivalKernelCore& left,
    const stationary::detail::PhaseArrivalKernelCore& right) {
  if (left.phases != right.phases ||
      left.configured_phase_marginal != right.configured_phase_marginal ||
      left.blocks.size() != right.blocks.size() ||
      !same_completion(left.completion, right.completion)) {
    return false;
  }
  for (std::size_t index = 0U; index < left.blocks.size(); ++index) {
    if (!(left.blocks[index].arrival_count ==
          right.blocks[index].arrival_count) ||
        left.blocks[index].row_major != right.blocks[index].row_major) {
      return false;
    }
  }
  return true;
}
#endif

[[nodiscard]] Result<std::shared_ptr<
    const stationary::detail::PhaseArrivalKernelCore>>
make_phase_arrival_kernel(
    std::shared_ptr<const
                    stationary::detail::AuditedPhaseResponseCarrierCore>
        carrier) {
  const stationary::detail::AuditedPhaseResponseCarrierCore& fixture =
      *carrier;
  const std::size_t phase_count = fixture.phases.size();
  if (phase_count == 0U || fixture.arrival_blocks.empty()) {
    return fail<std::shared_ptr<
        const stationary::detail::PhaseArrivalKernelCore>>(
        "c19.empty_phase_kernel",
        "a Markov-additive kernel requires phases and arrival blocks");
  }
  if (phase_count > std::numeric_limits<std::size_t>::max() / phase_count) {
    return fail<std::shared_ptr<
        const stationary::detail::PhaseArrivalKernelCore>>(
        "c19.phase_dimension_overflow",
        "the exact phase block dimension is not representable");
  }
  for (std::size_t phase = 0U; phase < phase_count; ++phase) {
    for (std::size_t prior = 0U; prior < phase; ++prior) {
      if (fixture.phases[prior] == fixture.phases[phase]) {
        return fail<std::shared_ptr<
            const stationary::detail::PhaseArrivalKernelCore>>(
            "c19.duplicate_phase", "phase identities must be unique");
      }
    }
  }
  if (fixture.configured_phase_marginal.size() != phase_count) {
    return fail<std::shared_ptr<
        const stationary::detail::PhaseArrivalKernelCore>>(
        "c19.phase_marginal_dimension",
        "the configured phase marginal has the wrong dimension");
  }
  std::vector<ExactPhaseArrivalBlockV1> blocks = fixture.arrival_blocks;
  std::sort(blocks.begin(), blocks.end(), [](const auto& left,
                                             const auto& right) {
    return left.arrival_count < right.arrival_count;
  });
  const std::size_t block_size = phase_count * phase_count;
  for (std::size_t index = 0U; index < blocks.size(); ++index) {
    if (blocks[index].row_major.size() != block_size) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.phase_block_dimension",
          "every K_k block must have the declared phase dimensions");
    }
    if (index > 0U &&
        blocks[index - 1U].arrival_count == blocks[index].arrival_count) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.duplicate_phase_arrival_count",
          "the Markov-additive kernel must declare one block per arrival "
          "count");
    }
    for (const auto& mass : blocks[index].row_major) {
      if (!mass.is_nonnegative()) {
        return fail<std::shared_ptr<
            const stationary::detail::PhaseArrivalKernelCore>>(
            "c19.negative_phase_kernel_mass",
            "arrival-phase transition masses must be nonnegative");
      }
    }
  }
  ExactRational marginal_total = ExactRational::zero();
  for (const auto& mass : fixture.configured_phase_marginal) {
    if (!mass.is_nonnegative()) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.negative_phase_marginal",
          "configured phase masses must be nonnegative");
    }
    marginal_total = marginal_total + mass;
  }
  if (!(marginal_total == ExactRational::one())) {
    return fail<std::shared_ptr<
        const stationary::detail::PhaseArrivalKernelCore>>(
        "c19.phase_marginal_not_normalized",
        "the configured phase marginal must total exactly one");
  }
  for (std::size_t source = 0U; source < phase_count; ++source) {
    ExactRational row_total = ExactRational::zero();
    for (const auto& block : blocks) {
      for (std::size_t destination = 0U; destination < phase_count;
           ++destination) {
        row_total = row_total +
                    block.row_major[source * phase_count + destination];
      }
    }
    if (!(row_total == ExactRational::one())) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.phase_kernel_row_not_stochastic",
          "sum_k K_k 1 must equal one in every source phase");
    }
  }
  for (std::size_t destination = 0U; destination < phase_count;
       ++destination) {
    ExactRational image = ExactRational::zero();
    for (std::size_t source = 0U; source < phase_count; ++source) {
      ExactRational phase_transition = ExactRational::zero();
      for (const auto& block : blocks) {
        phase_transition =
            phase_transition +
            block.row_major[source * phase_count + destination];
      }
      image = image +
              fixture.configured_phase_marginal[source] * phase_transition;
    }
    if (!(image == fixture.configured_phase_marginal[destination])) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.configured_phase_law_not_invariant",
          "the configured phase marginal is not invariant for sum_k K_k");
    }
  }
  auto maximum = native_index(fixture.completion.maximum_level);
  if (!maximum || maximum.value() == std::numeric_limits<std::size_t>::max() ||
      maximum.value() + 1U >
          std::numeric_limits<std::size_t>::max() / phase_count) {
    return fail<std::shared_ptr<
        const stationary::detail::PhaseArrivalKernelCore>>(
        "c19.phase_level_dimension_overflow",
        "the declared phase-level representation is not indexable");
  }
  const std::size_t state_count = (maximum.value() + 1U) * phase_count;
  if (fixture.completion.kind == PhaseLevelCompletionKindV1::exact_closed) {
    if (fixture.completion.completion_identity.has_value() ||
        !fixture.completion.additive_atoms.empty()) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.exact_closure_has_completion",
          "an exact-closed phase family cannot carry additive completion");
    }
  } else {
    if (!fixture.completion.completion_identity.has_value() ||
        !nonzero_digest(*fixture.completion.completion_identity)) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.phase_completion_identity_required",
          "an additive phase completion requires a nonzero identity");
    }
  }
  for (const auto& atom : fixture.completion.additive_atoms) {
    if (atom.source_flat_index >= state_count ||
        atom.successor_flat_index >= state_count ||
        !atom.mass.is_nonnegative()) {
      return fail<std::shared_ptr<
          const stationary::detail::PhaseArrivalKernelCore>>(
          "c19.invalid_phase_completion_atom",
          "phase completion atoms require in-domain endpoints and "
          "nonnegative mass");
    }
  }
  auto core =
      std::make_shared<stationary::detail::PhaseArrivalKernelCore>(
          stationary::detail::PhaseArrivalKernelCore{
              fixture.phases, std::move(blocks),
              fixture.configured_phase_marginal, fixture.service_row_major,
              fixture.completion, fixture.identity, carrier,
              fixture.seal, nullptr});
  return Result<std::shared_ptr<
      const stationary::detail::PhaseArrivalKernelCore>>::success(
      std::move(core));
}

[[nodiscard]] Result<BlockFluxOperator> assemble_phase_flux_impl(
    std::shared_ptr<const stationary::detail::PhaseArrivalKernelCore> arrival,
    const std::vector<ExactRational>& service_row_major) {
  const std::size_t phase_count = arrival->phases.size();
  const std::size_t maximum =
      native_index(arrival->completion.maximum_level).value();
  const std::size_t level_count = maximum + 1U;
  const std::size_t state_count = level_count * phase_count;
  if (service_row_major.size() != state_count) {
    return fail<BlockFluxOperator>(
        "c19.phase_response_dimension",
        "the phase response must provide one service value per level/phase");
  }
  for (std::size_t state = 0U; state < state_count; ++state) {
    const auto& service = service_row_major[state];
    if (!service.is_nonnegative() || service > ExactRational::one()) {
      return fail<BlockFluxOperator>(
          "c19.phase_response_out_of_range",
          "phase-indexed service probabilities must lie in [0,1]");
    }
    if (state < phase_count && !service.is_zero()) {
      return fail<BlockFluxOperator>("c19.phase_mu_zero_nonzero",
                                     "SF.26 requires mu(0,h)=0");
    }
  }
  std::vector<ExactRational> entries(state_count * state_count,
                                     ExactRational::zero());
  std::vector<ExactRational> leaked_by_phase(state_count * phase_count,
                                             ExactRational::zero());
  const BigInt maximum_exact = arrival->completion.maximum_level.value();
  const auto place = [&](const std::size_t source,
                         const std::size_t destination_phase,
                         const BigInt& destination_level,
                         const ExactRational& mass) {
    if (mass.is_zero()) {
      return Result<void>::success();
    }
    if (destination_level < 0) {
      return fail_void("c19.phase_level_underflow",
                       "SF.26 produced a negative destination level",
                       DiagnosticCategory::internal);
    }
    if (destination_level > maximum_exact) {
      leaked_by_phase[source * phase_count + destination_phase] =
          leaked_by_phase[source * phase_count + destination_phase] + mass;
      return Result<void>::success();
    }
    const std::size_t level = destination_level.convert_to<std::size_t>();
    const std::size_t destination = level * phase_count + destination_phase;
    entries[source * state_count + destination] =
        entries[source * state_count + destination] + mass;
    return Result<void>::success();
  };
  for (std::size_t level = 0U; level < level_count; ++level) {
    for (std::size_t source_phase = 0U; source_phase < phase_count;
         ++source_phase) {
      const std::size_t source = level * phase_count + source_phase;
      const ExactRational& service = service_row_major[source];
      for (const auto& block : arrival->blocks) {
        for (std::size_t destination_phase = 0U;
             destination_phase < phase_count; ++destination_phase) {
          const ExactRational& kernel_mass =
              block.row_major[source_phase * phase_count + destination_phase];
          auto no_departure = place(
              source, destination_phase,
              BigInt{level} + block.arrival_count.value(),
              (ExactRational::one() - service) * kernel_mass);
          if (!no_departure) {
            return Result<BlockFluxOperator>::failure(no_departure.error());
          }
          auto departure = place(
              source, destination_phase,
              BigInt{level} + block.arrival_count.value() - 1,
              service * kernel_mass);
          if (!departure) {
            return Result<BlockFluxOperator>::failure(departure.error());
          }
        }
      }
    }
  }
  if (arrival->completion.kind == PhaseLevelCompletionKindV1::exact_closed) {
    if (std::any_of(leaked_by_phase.begin(), leaked_by_phase.end(),
                    [](const ExactRational& mass) {
                      return !mass.is_zero();
                    })) {
      return fail<BlockFluxOperator>(
          "c19.phase_cutoff_leaks",
          "the declared exact phase cutoff omits positive SF.26 mass");
    }
  } else {
    std::vector<ExactRational> completed_by_phase(
        state_count * phase_count, ExactRational::zero());
    for (const auto& atom : arrival->completion.additive_atoms) {
      const std::size_t destination_phase =
          atom.successor_flat_index % phase_count;
      completed_by_phase[atom.source_flat_index * phase_count +
                         destination_phase] =
          completed_by_phase[atom.source_flat_index * phase_count +
                             destination_phase] +
          atom.mass;
      entries[atom.source_flat_index * state_count +
              atom.successor_flat_index] =
          entries[atom.source_flat_index * state_count +
                  atom.successor_flat_index] +
          atom.mass;
    }
    if (completed_by_phase != leaked_by_phase) {
      return fail<BlockFluxOperator>(
          "c19.phase_completion_leak_mismatch",
          "additive completion must equal every source/next-phase leaked "
          "mass exactly");
    }
  }
  for (std::size_t source = 0U; source < state_count; ++source) {
    ExactRational row_total = ExactRational::zero();
    for (std::size_t destination = 0U; destination < state_count;
         ++destination) {
      row_total = row_total + entries[source * state_count + destination];
    }
    if (!(row_total == ExactRational::one())) {
      return fail<BlockFluxOperator>(
          "c19.completed_phase_row_not_stochastic",
          "the completed SF.26 phase-level row must total exactly one",
          DiagnosticCategory::internal);
    }
  }
  const StationaryAnalyticLawIdentityV1 identity = arrival->identity;
  auto core = std::make_shared<stationary::detail::BlockFluxOperatorCore>(
      stationary::detail::BlockFluxOperatorCore{
          std::move(arrival), phase_count, level_count, std::move(entries),
          identity});
  return Result<BlockFluxOperator>::success(
      detail::C19CoreAccess::block_flux(std::move(core)));
}

struct PhaseClass final {
  TypedLabel class_id;
  std::vector<std::size_t> members;
  bool closed;
};

class PhaseCompensatedSum final {
 public:
  void add(const long double value) noexcept {
    const long double updated = sum_ + value;
    if (std::fabs(sum_) >= std::fabs(value)) {
      correction_ += (sum_ - updated) + value;
    } else {
      correction_ += (value - updated) + sum_;
    }
    sum_ = updated;
  }

  [[nodiscard]] long double value() const noexcept {
    return sum_ + correction_;
  }

 private:
  long double sum_{0.0L};
  long double correction_{0.0L};
};

struct PhaseResidualSummary final {
  long double normalization;
  long double normalization_bound;
  long double l1;
  long double l1_bound;
  long double maximum;
  long double maximum_bound;
};

[[nodiscard]] long double phase_residual_bound(const SolverPolicy& policy,
                                               const long double scale) {
  return policy.absolute_residual_tolerance.to_long_double() +
         policy.relative_residual_tolerance.to_long_double() * scale;
}

[[nodiscard]] PhaseResidualSummary phase_invariant_residual(
    const stationary::detail::BlockFluxOperatorCore& flux,
    const std::span<const long double> masses, const SolverPolicy& policy,
    const std::span<const std::size_t> coordinates) {
  const std::size_t state_count = flux.phase_count * flux.level_count;
  PhaseCompensatedSum normalization;
  long double normalization_scale = 0.0L;
  PhaseCompensatedSum l1;
  long double l1_scale = 0.0L;
  long double maximum = 0.0L;
  long double maximum_scale = 0.0L;
  for (const std::size_t state : coordinates) {
    normalization.add(masses[state]);
    normalization_scale += std::fabs(masses[state]);
  }
  for (const std::size_t destination : coordinates) {
    PhaseCompensatedSum image;
    long double component_scale = std::fabs(masses[destination]);
    for (const std::size_t source : coordinates) {
      const long double term =
          masses[source] *
          flux.entries[source * state_count + destination].to_long_double();
      image.add(term);
      component_scale += std::fabs(term);
    }
    const long double residual = image.value() - masses[destination];
    l1.add(std::fabs(residual));
    l1_scale += component_scale;
    maximum = std::max(maximum, std::fabs(residual));
    maximum_scale = std::max(maximum_scale, component_scale);
  }
  return {normalization.value() - 1.0L,
          phase_residual_bound(policy, normalization_scale),
          l1.value(),
          phase_residual_bound(policy, l1_scale),
          maximum,
          phase_residual_bound(policy, maximum_scale)};
}

[[nodiscard]] std::vector<PhaseClass> phase_classes(
    const stationary::detail::BlockFluxOperatorCore& flux) {
  const std::size_t count = flux.entries.empty()
                                ? 0U
                                : flux.phase_count * flux.level_count;
  std::vector<int> discovery(count, -1);
  std::vector<int> low(count, -1);
  std::vector<std::size_t> stack;
  std::vector<std::uint8_t> on_stack(count, 0U);
  std::vector<std::vector<std::size_t>> components;
  int next_discovery = 0;
  std::function<void(std::size_t)> visit = [&](const std::size_t vertex) {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = 1U;
    for (std::size_t successor = 0U; successor < count; ++successor) {
      if (!flux.entries[vertex * count + successor].is_positive()) {
        continue;
      }
      if (discovery[successor] == -1) {
        visit(successor);
        low[vertex] = std::min(low[vertex], low[successor]);
      } else if (on_stack[successor] != 0U) {
        low[vertex] = std::min(low[vertex], discovery[successor]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::size_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = 0U;
      component.push_back(member);
      if (member == vertex) {
        break;
      }
    }
    std::sort(component.begin(), component.end());
    components.push_back(std::move(component));
  };
  for (std::size_t vertex = 0U; vertex < count; ++vertex) {
    if (discovery[vertex] == -1) {
      visit(vertex);
    }
  }
  std::sort(components.begin(), components.end());
  std::vector<std::size_t> component_of(count, 0U);
  for (std::size_t component = 0U; component < components.size(); ++component) {
    for (const std::size_t member : components[component]) {
      component_of[member] = component;
    }
  }
  std::vector<PhaseClass> classes;
  classes.reserve(components.size());
  for (std::size_t component = 0U; component < components.size(); ++component) {
    bool closed = true;
    for (const std::size_t member : components[component]) {
      for (std::size_t successor = 0U; successor < count; ++successor) {
        if (flux.entries[member * count + successor].is_positive() &&
            component_of[successor] != component) {
          closed = false;
        }
      }
    }
    classes.push_back(
        {TypedLabel::numeric(BigNat{component}), components[component], closed});
  }
  return classes;
}

[[nodiscard]] Result<std::vector<SelectedInvariantClassV1>>
select_phase_classes(const std::vector<PhaseClass>& classes,
                     const SelectionSpec& selection) {
  auto portable = portable_selection(selection);
  if (!portable) {
    return Result<std::vector<SelectedInvariantClassV1>>::failure(
        portable.error());
  }
  std::vector<std::size_t> closed;
  for (std::size_t index = 0U; index < classes.size(); ++index) {
    if (classes[index].closed) {
      closed.push_back(index);
    }
  }
  std::vector<SelectedInvariantClassV1> selected;
  if (std::holds_alternative<PortableStationaryUniqueSelectionV1>(
          portable.value())) {
    if (closed.size() != 1U) {
      return fail<std::vector<SelectedInvariantClassV1>>(
          "c19.stationary_class_ambiguous",
          "stationary_unique requires exactly one closed phase-level class");
    }
    const std::size_t index = closed.front();
    selected.push_back(
        {classes[index].class_id, index, ExactRational::one(), 1.0L});
    return Result<std::vector<SelectedInvariantClassV1>>::success(
        std::move(selected));
  }
  const auto append = [&](const TypedLabel& class_id,
                          const ExactRational& exact_weight)
      -> Result<void> {
    const auto found = std::find_if(
        classes.begin(), classes.end(), [&](const PhaseClass& candidate) {
          return candidate.class_id == class_id;
        });
    if (found == classes.end()) {
      return fail_void("c19.unknown_stationary_class",
                       "the selector names an unknown phase-level class");
    }
    if (!found->closed) {
      return fail_void(
          "c19.transient_stationary_class",
          "stationary mass may be assigned only to a closed class");
    }
    const long double weight = exact_weight.to_long_double();
    if (!std::isfinite(weight) ||
        (exact_weight.is_positive() && weight <= 0.0L)) {
      return fail_void(
          "c19.unusable_stationary_mixture_weight",
          "a positive exact mixture weight has no positive finite image");
    }
    selected.push_back(
        {class_id, static_cast<std::size_t>(found - classes.begin()),
         exact_weight, weight});
    return Result<void>::success();
  };
  if (const auto* one =
          std::get_if<PortableStationaryClassSelectionV1>(&portable.value())) {
    auto added = append(one->class_id, ExactRational::one());
    if (!added) {
      return Result<std::vector<SelectedInvariantClassV1>>::failure(
          added.error());
    }
  } else if (const auto* mixture =
                 std::get_if<PortableStationaryMixtureSelectionV1>(
                     &portable.value())) {
    for (const auto& component : mixture->components) {
      auto added = append(component.class_id, component.probability);
      if (!added) {
        return Result<std::vector<SelectedInvariantClassV1>>::failure(
            added.error());
      }
    }
  } else {
    return fail<std::vector<SelectedInvariantClassV1>>(
        "c19.stationary_selection_required",
        "the phase-level stationary solve requires a stationary selector");
  }
  return Result<std::vector<SelectedInvariantClassV1>>::success(
      std::move(selected));
}

[[nodiscard]] std::vector<ExactRational> invariant_coefficients(
    const stationary::detail::BlockFluxOperatorCore& flux,
    const std::vector<std::size_t>& members) {
  const std::size_t state_count = flux.phase_count * flux.level_count;
  const std::size_t dimension = members.size();
  std::vector<ExactRational> coefficients(dimension * dimension,
                                          ExactRational::zero());
  for (std::size_t equation = 0U; equation + 1U < dimension; ++equation) {
    for (std::size_t variable = 0U; variable < dimension; ++variable) {
      ExactRational coefficient =
          flux.entries[members[variable] * state_count + members[equation]];
      if (variable == equation) {
        coefficient = coefficient - ExactRational::one();
      }
      coefficients[equation * dimension + variable] = std::move(coefficient);
    }
  }
  for (std::size_t variable = 0U; variable < dimension; ++variable) {
    coefficients[(dimension - 1U) * dimension + variable] =
        ExactRational::one();
  }
  return coefficients;
}

[[nodiscard]] Result<std::vector<ExactRational>> exact_invariant_law(
    std::vector<ExactRational> coefficients, const std::size_t dimension) {
  if (dimension == 0U || dimension * dimension != coefficients.size()) {
    return fail<std::vector<ExactRational>>(
        "c19.invalid_invariant_system",
        "the augmented invariant system has invalid dimensions",
        DiagnosticCategory::internal);
  }
  std::vector<ExactRational> rhs(dimension, ExactRational::zero());
  rhs.back() = ExactRational::one();
  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension &&
           coefficients[pivot * dimension + column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return fail<std::vector<ExactRational>>(
          "c19.singular_invariant_system",
          "the selected closed-class invariant system is singular",
          DiagnosticCategory::unavailable);
    }
    if (pivot != column) {
      for (std::size_t entry = column; entry < dimension; ++entry) {
        std::swap(coefficients[column * dimension + entry],
                  coefficients[pivot * dimension + entry]);
      }
      std::swap(rhs[column], rhs[pivot]);
    }
    const ExactRational pivot_value =
        coefficients[column * dimension + column];
    for (std::size_t entry = column; entry < dimension; ++entry) {
      auto divided = checked_divide(
          coefficients[column * dimension + entry], pivot_value);
      if (!divided) {
        return Result<std::vector<ExactRational>>::failure(divided.error());
      }
      coefficients[column * dimension + entry] =
          std::move(divided).value();
    }
    auto divided_rhs = checked_divide(rhs[column], pivot_value);
    if (!divided_rhs) {
      return Result<std::vector<ExactRational>>::failure(divided_rhs.error());
    }
    rhs[column] = std::move(divided_rhs).value();
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const ExactRational factor = coefficients[row * dimension + column];
      if (factor.is_zero()) {
        continue;
      }
      for (std::size_t entry = column; entry < dimension; ++entry) {
        coefficients[row * dimension + entry] =
            coefficients[row * dimension + entry] -
            factor * coefficients[column * dimension + entry];
      }
      rhs[row] = rhs[row] - factor * rhs[column];
    }
  }
  return Result<std::vector<ExactRational>>::success(std::move(rhs));
}

[[nodiscard]] Result<PhaseStationaryLaw> solve_phase_stationary_impl(
    std::shared_ptr<const stationary::detail::BlockFluxOperatorCore> flux,
    const SelectionSpec& selection, const SolverPolicy& policy) {
  auto valid_policy = validate_solver_policy(policy);
  if (!valid_policy) {
    return Result<PhaseStationaryLaw>::failure(valid_policy.error());
  }
  if (flux->arrival->carrier &&
      (!(policy == flux->arrival->carrier->solver_policy) ||
       policy.analysis_fingerprint !=
           bound_analysis_fingerprint(flux->identity))) {
    return fail<PhaseStationaryLaw>(
        "c19.phase_solver_analysis_mismatch",
        "the phase solver policy differs from the analysis sealed into the "
        "exact carrier");
  }
  auto canonical_selection = portable_selection(selection);
  if (!canonical_selection) {
    return Result<PhaseStationaryLaw>::failure(canonical_selection.error());
  }
  const bool identity_is_sealed =
      flux->arrival->sealed != nullptr || flux->arrival->carrier != nullptr;
  Result<StationaryAnalyticLawIdentityV1> identity =
      identity_is_sealed
          ? Result<StationaryAnalyticLawIdentityV1>::success(flux->identity)
          : identity_with_selection(flux->identity, selection);
  if (identity_is_sealed &&
      !(canonical_selection.value() == flux->identity.selection())) {
    return fail<PhaseStationaryLaw>(
        "c19.phase_selection_binding_mismatch",
        "the supplied phase-level selector differs from the sealed analysis "
        "selection");
  }
  if (!identity) {
    return Result<PhaseStationaryLaw>::failure(identity.error());
  }
  auto classes = phase_classes(*flux);
  auto selected = select_phase_classes(classes, selection);
  if (!selected) {
    return Result<PhaseStationaryLaw>::failure(selected.error());
  }
  const std::size_t state_count = flux->phase_count * flux->level_count;
  std::vector<ExactRational> exact_masses(state_count,
                                          ExactRational::zero());
  std::vector<ClassSolveDiagnosticV1> class_diagnostics;
  for (const auto& chosen : selected.value()) {
    if (chosen.exact_weight.is_zero()) {
      continue;
    }
    const auto& members = classes[chosen.class_index].members;
    const auto coefficients = invariant_coefficients(*flux, members);
    auto local = exact_invariant_law(coefficients, members.size());
    if (!local) {
      return Result<PhaseStationaryLaw>::failure(local.error());
    }
    ExactRational normalization = ExactRational::zero();
    for (const auto& mass : local.value()) {
      if (!mass.is_nonnegative()) {
        return fail<PhaseStationaryLaw>(
            "c19.negative_phase_stationary_mass",
            "the exact selected-class solve produced negative mass",
            DiagnosticCategory::internal);
      }
      normalization = normalization + mass;
    }
    if (!(normalization == ExactRational::one())) {
      return fail<PhaseStationaryLaw>(
          "c19.phase_class_normalization_invariant",
          "the exact selected-class law is not normalized",
          DiagnosticCategory::internal);
    }
    for (std::size_t local_index = 0U; local_index < members.size();
         ++local_index) {
      exact_masses[members[local_index]] =
          exact_masses[members[local_index]] +
          chosen.exact_weight * local.value()[local_index];
    }
    const std::size_t dimension = members.size();
    Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> numerical(
        static_cast<Eigen::Index>(dimension),
        static_cast<Eigen::Index>(dimension));
    for (std::size_t row = 0U; row < dimension; ++row) {
      for (std::size_t column = 0U; column < dimension; ++column) {
        numerical(static_cast<Eigen::Index>(row),
                  static_cast<Eigen::Index>(column)) =
            coefficients[row * dimension + column].to_long_double();
      }
    }
    const long double eta = static_cast<long double>(dimension) *
                            std::numeric_limits<long double>::epsilon();
    Eigen::FullPivLU<decltype(numerical)> factorization;
    factorization.setThreshold(eta);
    factorization.compute(numerical);
    const std::size_t rank =
        static_cast<std::size_t>(factorization.rank());
    const long double rcond = factorization.rcond();
    const long double warning_threshold = std::sqrt(eta);
    std::vector<long double> class_masses(state_count, 0.0L);
    bool finite_nonnegative = true;
    for (std::size_t local_index = 0U; local_index < members.size();
         ++local_index) {
      const ExactRational& exact = local.value()[local_index];
      const long double numerical_mass = exact.to_long_double();
      if (!std::isfinite(numerical_mass) || numerical_mass < 0.0L ||
          (exact.is_positive() && numerical_mass <= 0.0L)) {
        finite_nonnegative = false;
      }
      class_masses[members[local_index]] = numerical_mass;
    }
    const PhaseResidualSummary class_residual = phase_invariant_residual(
        *flux, class_masses, policy, members);
    const bool residuals_accepted =
        std::fabs(class_residual.normalization) <=
            class_residual.normalization_bound &&
        class_residual.l1 <= class_residual.l1_bound &&
        class_residual.maximum <= class_residual.maximum_bound;
    const bool accepted =
        rank == dimension && finite_nonnegative && residuals_accepted;
    class_diagnostics.push_back(ClassSolveDiagnosticV1{
        chosen.class_id,
        dimension,
        rank,
        eta,
        rcond,
        warning_threshold,
        !std::isfinite(rcond) || rcond <= warning_threshold,
        class_residual.normalization,
        class_residual.normalization_bound,
        class_residual.l1,
        class_residual.l1_bound,
        class_residual.maximum,
        class_residual.maximum_bound,
        finite_nonnegative,
        accepted ? StationaryLinearSolveStatusV1::solved
                 : StationaryLinearSolveStatusV1::numerically_unresolved});
    if (!accepted) {
      return fail<PhaseStationaryLaw>(
          "c19.phase_invariant_numerically_unresolved",
          rank != dimension
              ? "the exact augmented invariant system is rank-deficient in "
                "the declared numerical image"
              : "the exact selected-class law has no acceptable finite "
                "numerical SF.27 image",
          DiagnosticCategory::unavailable);
    }
  }
  ExactRational normalization = ExactRational::zero();
  for (const auto& mass : exact_masses) {
    normalization = normalization + mass;
  }
  if (!(normalization == ExactRational::one())) {
    return fail<PhaseStationaryLaw>(
        "c19.phase_mixture_normalization_invariant",
        "the exact selected phase-level mixture is not normalized",
        DiagnosticCategory::internal);
  }
  for (std::size_t destination = 0U; destination < state_count;
       ++destination) {
    ExactRational image = ExactRational::zero();
    for (std::size_t source = 0U; source < state_count; ++source) {
      image = image + exact_masses[source] *
                          flux->entries[source * state_count + destination];
    }
    if (!(image == exact_masses[destination])) {
      return fail<PhaseStationaryLaw>(
          "c19.phase_invariance_residual",
          "the exact selected phase-level law fails SF.27",
          DiagnosticCategory::internal);
    }
  }
  std::vector<ExactRational> exact_phase_marginal(
      flux->phase_count, ExactRational::zero());
  for (std::size_t level = 0U; level < flux->level_count; ++level) {
    for (std::size_t phase = 0U; phase < flux->phase_count; ++phase) {
      exact_phase_marginal[phase] =
          exact_phase_marginal[phase] +
          exact_masses[level * flux->phase_count + phase];
    }
  }
  if (exact_phase_marginal != flux->arrival->configured_phase_marginal) {
    return fail<PhaseStationaryLaw>(
        "c19.configured_phase_marginal_mismatch",
        "the selected invariant law has a different phase mixture than the "
        "configured arrival law");
  }
  std::vector<long double> masses;
  masses.reserve(state_count);
  for (const auto& exact : exact_masses) {
    const long double numerical = exact.to_long_double();
    if (!std::isfinite(numerical) ||
        (exact.is_positive() && numerical <= 0.0L)) {
      return fail<PhaseStationaryLaw>(
          "c19.unusable_phase_stationary_image",
          "an exact stationary mass has no finite nonnegative numerical "
          "image",
          DiagnosticCategory::unavailable);
    }
    masses.push_back(numerical);
  }
  std::vector<std::size_t> all_coordinates(state_count);
  std::iota(all_coordinates.begin(), all_coordinates.end(), 0U);
  const PhaseResidualSummary aggregate =
      phase_invariant_residual(*flux, masses, policy, all_coordinates);
  if (std::fabs(aggregate.normalization) > aggregate.normalization_bound ||
      aggregate.l1 > aggregate.l1_bound ||
      aggregate.maximum > aggregate.maximum_bound) {
    return fail<PhaseStationaryLaw>(
        "c19.phase_mixture_numerically_unresolved",
        "the selected phase-level mixture has no acceptable numerical SF.27 "
        "image",
        DiagnosticCategory::unavailable);
  }
  std::vector<PhaseMarginalAtomV1> phase_marginal;
  phase_marginal.reserve(flux->phase_count);
  for (std::size_t phase = 0U; phase < flux->phase_count; ++phase) {
    PhaseCompensatedSum marginal;
    for (std::size_t level = 0U; level < flux->level_count; ++level) {
      marginal.add(masses[level * flux->phase_count + phase]);
    }
    const long double invariant_mass = marginal.value();
    const long double configured_mass =
        flux->arrival->configured_phase_marginal[phase].to_long_double();
    const long double residual = invariant_mass - configured_mass;
    const long double bound = phase_residual_bound(
        policy, std::fabs(invariant_mass) + std::fabs(configured_mass));
    if (!std::isfinite(invariant_mass) || !std::isfinite(configured_mass) ||
        (flux->arrival->configured_phase_marginal[phase].is_positive() &&
         configured_mass <= 0.0L) ||
        std::fabs(residual) > bound) {
      return fail<PhaseStationaryLaw>(
          "c19.phase_marginal_numerically_unresolved",
          "the numerical phase marginal does not satisfy SF.27a",
          DiagnosticCategory::unavailable);
    }
    phase_marginal.push_back({flux->arrival->phases[phase], invariant_mass,
                              configured_mass, residual, bound});
  }
  InvariantSolveDiagnosticsV1 diagnostics{
      policy.linear_method,
      policy.absolute_residual_tolerance,
      policy.relative_residual_tolerance,
      selected.value(),
      std::move(class_diagnostics),
      aggregate.normalization,
      aggregate.normalization_bound,
      aggregate.l1,
      aggregate.l1_bound,
      aggregate.maximum,
      aggregate.maximum_bound};
  auto core = std::make_shared<stationary::detail::PhaseStationaryLawCore>(
      stationary::detail::PhaseStationaryLawCore{
          AnalyticStationaryStatusV1::finite, std::move(masses),
          selected.value(), std::move(phase_marginal), std::move(diagnostics),
          std::move(identity).value(), std::move(flux)});
  return Result<PhaseStationaryLaw>::success(
      detail::C19CoreAccess::phase_law(std::move(core)));
}

[[nodiscard]] Result<LittleLawPremises> validate_three_bin_summary_boundary(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed,
    const stationary::detail::ArrivalLawCore& arrival) {
  if (!sealed || !sealed->report().passed() || !sealed->is_three_bin() ||
      arrival.sealed.get() != sealed.get()) {
    return fail<LittleLawPremises>(
        "c19.three_bin_seal_mismatch",
        "the response and IID arrival must share one passing C17 three-bin "
        "seal");
  }
  const auto* payload = std::get_if<PortableThreeBinScalarResponseV1>(
      &portable_source_v1(sealed->plug()).value());
  const auto& inputs = sealed->inputs();
  const auto& descriptor = sealed->descriptor().core;
  const auto& artifact = sealed->artifact_bindings();
  if (payload == nullptr ||
      descriptor.semantic != SemanticTagV1::scalar_backlog_response ||
      descriptor.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      descriptor.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
      descriptor.tail.kind != TailRepresentationKindV1::constant_response ||
      !descriptor.tail.boundary ||
      !(*descriptor.tail.boundary == BigNat{3U}) ||
      descriptor.deployed_targets.size() != 1U ||
      !std::holds_alternative<FiniteParameterAnalyticFamilyAccess>(
          sealed->access()) ||
      inputs.causal_program.mode !=
          ExactCausalProgramModeV1::closed_three_bin_scalar) {
    return fail<LittleLawPremises>(
        "c19.three_bin_contract_mismatch",
        "F-C19-09 requires the phase-free singleton three-bin analytic "
        "contract with tail boundary three");
  }
  const auto& context = payload->context;
  const auto& normalized = payload->normalized_record;
  const QueueId& target = descriptor.deployed_targets.front();
  const ArrivalBinding& configured_binding =
      arrival_law_binding(inputs.configured_arrival);
  // CP06.4 binds the Full Orbit response to the canonical configured law,
  // not to a construction-view representation that may or may not carry the
  // optional legacy Cartesian IID table. Other providers and archived Full
  // Orbit artifacts without the compact capability retain their existing
  // compiled-view binding contract.
  const Digest256& expected_payload_arrival_binding =
      artifact.provider.provider_id == "full_orbit_framework_sampler" &&
              inputs.accepted_contract.arrival_capabilities()
                  .exact_factorized_iid_generator.has_value()
          ? configured_binding.law_digest.value()
          : inputs.framework_seed.bindings.problem_fingerprints
                .compiled_arrival;
  if (context.semantic != descriptor.semantic ||
      context.runtime_access != descriptor.runtime_access ||
      !(context.payload_class == descriptor.payload_class) ||
      context.ordered_deployed_targets != descriptor.deployed_targets ||
      context.build_identity_digest != inputs.build_identity.digest() ||
      context.build_identity_digest != artifact.build_identity_digest ||
      context.request_digest != inputs.final_request_identity ||
      context.request_digest != artifact.request_digest ||
      context.framework_problem_view_digest !=
          artifact.framework_problem_view_digest ||
      context.structural_manifest_echo.manifest_digest !=
          sealed->structural_manifest().canonical_digest() ||
      context.realized_metric_bindings.request_digest !=
          inputs.final_request_identity ||
      context.realized_metric_bindings.payload_digest !=
          context.payload_digest ||
      context.realized_metric_bindings.bindings !=
          std::vector<RealizedMetricBindingV1>(
              inputs.realized_metric_bindings.bindings().begin(),
              inputs.realized_metric_bindings.bindings().end()) ||
      !(payload->deployed_target == target) ||
      !(normalized.deployed_target == target) ||
      normalized.deployed_response_product_id != payload->selected_product ||
      normalized.configured_arrival_binding !=
          expected_payload_arrival_binding ||
      !(arrival.target == target) ||
      !(arrival.configured_arrival == configured_binding)) {
    return fail<LittleLawPremises>(
        "c19.three_bin_identity_mismatch",
        "the three-bin payload, response product, target, build, or "
        "configured-arrival identity differs from the sealed contract");
  }

  auto expected_identity = production_identity(sealed);
  if (!expected_identity || !(arrival.identity == expected_identity.value())) {
    return fail<LittleLawPremises>(
        "c19.three_bin_law_identity_mismatch",
        "the IID arrival does not retain the complete response-law identity");
  }

  const auto& retained_clause = arrival.identity.accepted_metric_clause();
  const auto& retained_binding = arrival.identity.realized_metric_binding();
  if (!retained_clause || !retained_binding ||
      arrival.identity.payload_phase() != PayloadPhaseKindV1::phase_free) {
    return fail<LittleLawPremises>(
        "c19.three_bin_analytic_route_unavailable",
        "the law identity does not retain its phase-free structural and "
        "realized deployed-response witnesses",
        DiagnosticCategory::unavailable);
  }
  const auto clause = std::find_if(
      sealed->structural_manifest().clauses().begin(),
      sealed->structural_manifest().clauses().end(),
      [&](const auto& candidate) {
        return candidate.clause_id == *retained_clause &&
               candidate.semantic == SemanticTagV1::scalar_backlog_response &&
               candidate.runtime_access ==
                   RuntimeAccessTagV1::finite_parameter_analytic_family &&
               candidate.ordered_targets == descriptor.deployed_targets &&
               candidate.result_scope == MetricResultScopeV1::surrogate_law;
      });
  const auto contract = std::find_if(
      inputs.accepted_contract.metric_contracts().begin(),
      inputs.accepted_contract.metric_contracts().end(),
      [&](const auto& candidate) {
        return clause != sealed->structural_manifest().clauses().end() &&
               candidate.clause_id == *retained_clause &&
               scalar_response_route_is_authorized(
                   candidate.backend_route, clause->metric_kind) &&
               candidate.semantic == SemanticTagV1::scalar_backlog_response &&
               candidate.runtime_access ==
                   RuntimeAccessTagV1::finite_parameter_analytic_family &&
               candidate.ordered_targets.size() == 1U &&
               candidate.ordered_targets.front().queue_id == target;
      });
  const auto binding = std::find(
      inputs.realized_metric_bindings.bindings().begin(),
      inputs.realized_metric_bindings.bindings().end(), *retained_binding);
  const ArtifactObjectReferenceV1& selected_product =
      deployed_response_product_identity_v1(payload->selected_product);
  const auto* deployed =
      binding == inputs.realized_metric_bindings.bindings().end()
          ? nullptr
          : std::get_if<DeployedResponseReferenceV1>(&binding->reference);
  if (contract == inputs.accepted_contract.metric_contracts().end() ||
      clause == sealed->structural_manifest().clauses().end() ||
      binding == inputs.realized_metric_bindings.bindings().end() ||
      binding->key.clause_id != *retained_clause ||
      binding->key.role != MetricSupportRoleV1::deployed_response ||
      deployed == nullptr ||
      deployed->selected_product.index() != payload->selected_product.index() ||
      !(deployed_response_product_subject_v1(deployed->selected_product) ==
        selected_product)) {
    return fail<LittleLawPremises>(
        "c19.three_bin_analytic_route_unavailable",
        "the retained structural or realized deployed-response witness does "
        "not match the sealed analytic route",
        DiagnosticCategory::unavailable);
  }
  return Result<LittleLawPremises>::success(little_law_premises(*clause));
}

[[nodiscard]] Result<LittleLawPremises>
validate_finite_prefix_summary_boundary(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed,
    const stationary::detail::ArrivalLawCore& arrival) {
  if (!sealed || !sealed->report().passed() ||
      arrival.sealed.get() != sealed.get()) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_seal_mismatch",
        "the response and IID arrival must share one passing C17 "
        "finite-prefix seal");
  }
  const auto* payload =
      std::get_if<PortableFinitePrefixConstantTailResponseV1>(
          &portable_source_v1(sealed->plug()).value());
  const auto& inputs = sealed->inputs();
  const auto& descriptor = sealed->descriptor().core;
  const auto& artifact = sealed->artifact_bindings();
  if (payload == nullptr ||
      descriptor.payload_class.tag !=
          PayloadClassTagV1::finite_prefix_constant_tail_response_v1 ||
      descriptor.payload_class.version != 1U ||
      descriptor.semantic != SemanticTagV1::scalar_backlog_response ||
      descriptor.runtime_access !=
          RuntimeAccessTagV1::finite_parameter_analytic_family ||
      descriptor.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
      descriptor.tail.kind != TailRepresentationKindV1::constant_response ||
      !descriptor.tail.boundary ||
      descriptor.deployed_targets.size() != 1U ||
      !std::holds_alternative<FiniteParameterAnalyticFamilyAccess>(
          sealed->access()) ||
      inputs.causal_program.mode !=
          ExactCausalProgramModeV1::closed_finite_prefix_constant_tail_scalar) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_contract_mismatch",
        "the K-wide IID summary requires the phase-free singleton "
        "finite-prefix/constant-tail analytic contract");
  }
  if (descriptor.tail.boundary->value() !=
          payload->response_cutoff.value() + 1 ||
      !(payload->constant_tail_from == *descriptor.tail.boundary) ||
      !(payload->response_cutoff ==
        payload->normalized_record.response_cutoff)) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_tail_contract_mismatch",
        "the descriptor and normalized response must share cutoff K and "
        "tail boundary K+1");
  }

  const auto& context = payload->context;
  const auto& normalized = payload->normalized_record;
  const QueueId& target = descriptor.deployed_targets.front();
  const ArrivalBinding& configured_binding =
      arrival_law_binding(inputs.configured_arrival);
  const Digest256& expected_payload_arrival_binding =
      artifact.provider.provider_id == "full_orbit_framework_sampler" &&
              inputs.accepted_contract.arrival_capabilities()
                  .exact_factorized_iid_generator.has_value()
          ? configured_binding.law_digest.value()
          : inputs.framework_seed.bindings.problem_fingerprints
                .compiled_arrival;
  if (context.semantic != descriptor.semantic ||
      context.runtime_access != descriptor.runtime_access ||
      !(context.payload_class == descriptor.payload_class) ||
      context.ordered_deployed_targets != descriptor.deployed_targets ||
      context.build_identity_digest != inputs.build_identity.digest() ||
      context.build_identity_digest != artifact.build_identity_digest ||
      context.request_digest != inputs.final_request_identity ||
      context.request_digest != artifact.request_digest ||
      context.framework_problem_view_digest !=
          artifact.framework_problem_view_digest ||
      context.structural_manifest_echo.manifest_digest !=
          sealed->structural_manifest().canonical_digest() ||
      context.realized_metric_bindings.request_digest !=
          inputs.final_request_identity ||
      context.realized_metric_bindings.payload_digest !=
          context.payload_digest ||
      context.realized_metric_bindings.bindings !=
          std::vector<RealizedMetricBindingV1>(
              inputs.realized_metric_bindings.bindings().begin(),
              inputs.realized_metric_bindings.bindings().end()) ||
      !(payload->deployed_target == target) ||
      !(normalized.deployed_target == target) ||
      !(normalized.raw_response.deployed_target == target) ||
      !(payload->selected_product ==
        normalized.deployed_response_product_id) ||
      !(payload->selected_product == normalized.raw_response.product_id) ||
      normalized.configured_arrival_binding !=
          expected_payload_arrival_binding ||
      normalized.raw_response.configured_arrival_binding !=
          expected_payload_arrival_binding ||
      !(arrival.target == target) ||
      !(arrival.configured_arrival == configured_binding)) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_identity_mismatch",
        "the K-wide payload, raw response, target, build, or configured "
        "arrival identity differs from the sealed contract");
  }

  auto expected_identity = production_identity(sealed);
  if (!expected_identity || !(arrival.identity == expected_identity.value())) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_law_identity_mismatch",
        "the IID arrival does not retain the complete K-wide response-law "
        "identity");
  }
  const auto& retained_clause = arrival.identity.accepted_metric_clause();
  const auto& retained_binding = arrival.identity.realized_metric_binding();
  if (!retained_clause || !retained_binding ||
      arrival.identity.payload_phase() != PayloadPhaseKindV1::phase_free) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_analytic_route_unavailable",
        "the K-wide law identity does not retain its phase-free structural "
        "and realized deployed-response witnesses",
        DiagnosticCategory::unavailable);
  }
  const auto clause = std::find_if(
      sealed->structural_manifest().clauses().begin(),
      sealed->structural_manifest().clauses().end(),
      [&](const auto& candidate) {
        return candidate.clause_id == *retained_clause &&
               candidate.semantic == SemanticTagV1::scalar_backlog_response &&
               candidate.runtime_access ==
                   RuntimeAccessTagV1::finite_parameter_analytic_family &&
               candidate.ordered_targets == descriptor.deployed_targets &&
               candidate.result_scope == MetricResultScopeV1::surrogate_law;
      });
  const auto contract = std::find_if(
      inputs.accepted_contract.metric_contracts().begin(),
      inputs.accepted_contract.metric_contracts().end(),
      [&](const auto& candidate) {
        return clause != sealed->structural_manifest().clauses().end() &&
               candidate.clause_id == *retained_clause &&
               scalar_response_route_is_authorized(
                   candidate.backend_route, clause->metric_kind) &&
               candidate.semantic == SemanticTagV1::scalar_backlog_response &&
               candidate.runtime_access ==
                   RuntimeAccessTagV1::finite_parameter_analytic_family &&
               candidate.ordered_targets.size() == 1U &&
               candidate.ordered_targets.front().queue_id == target;
      });
  const auto binding = std::find(
      inputs.realized_metric_bindings.bindings().begin(),
      inputs.realized_metric_bindings.bindings().end(), *retained_binding);
  const auto* deployed =
      binding == inputs.realized_metric_bindings.bindings().end()
          ? nullptr
          : std::get_if<DeployedResponseReferenceV1>(&binding->reference);
  if (contract == inputs.accepted_contract.metric_contracts().end() ||
      clause == sealed->structural_manifest().clauses().end() ||
      binding == inputs.realized_metric_bindings.bindings().end() ||
      binding->key.clause_id != *retained_clause ||
      binding->key.role != MetricSupportRoleV1::deployed_response ||
      deployed == nullptr ||
      !deployed_response_matches(deployed->selected_product,
                                 ResponseProductStageV1::raw_response,
                                 payload->selected_product.identity())) {
    return fail<LittleLawPremises>(
        "c19.finite_prefix_analytic_route_unavailable",
        "the retained structural or realized deployed-response witness does "
        "not match the K-wide analytic route",
        DiagnosticCategory::unavailable);
  }
  return Result<LittleLawPremises>::success(little_law_premises(*clause));
}

[[nodiscard]] StationaryConditioningMassStatus conditioning_mass(
    const std::optional<ExactRational>& mass,
    const StationaryConditioningRegionV1 region, const bool aggregate) {
  StationaryConditioningMassKindV1 kind =
      StationaryConditioningMassKindV1::stationary_law_not_established;
  std::optional<ExactRational> retained_mass;
  std::optional<StationaryConditioningRegionV1> retained_region;
  if (mass) {
    if (mass->is_zero()) {
      kind = StationaryConditioningMassKindV1::established_zero;
    } else if (aggregate) {
      kind = StationaryConditioningMassKindV1::aggregate_only;
      retained_mass = mass;
      retained_region = region;
    } else {
      kind = StationaryConditioningMassKindV1::established_positive;
      retained_mass = mass;
    }
  }
  return detail::C19CoreAccess::conditioning_mass(
      std::make_shared<stationary::detail::StationaryConditioningMassCore>(
          stationary::detail::StationaryConditioningMassCore{
              kind, std::move(retained_mass), std::move(retained_region)}));
}

[[nodiscard]] Result<ThreeBinIidSummary> summarize_three_bin_law(
    const std::shared_ptr<const stationary::detail::ArrivalLawCore>& arrival,
    const stationary::detail::ScalarResponseData& response,
    const ScalarStationaryLaw& law, const LittleLawPremises premises) {
  if (response.prefix.size() != 3U || !response.prefix[0U].is_zero() ||
      !response.constant_tail_from ||
      !(*response.constant_tail_from == BigNat{3U}) ||
      !response.constant_tail_service) {
    return fail<ThreeBinIidSummary>(
        "c19.three_bin_response_shape",
        "the IID summary requires mu(0)=0, levels one and two, and a tail "
        "beginning at level three");
  }

  std::optional<ExactRational> pi_zero;
  std::optional<ExactRational> pi_one;
  std::optional<ExactRational> pi_two;
  std::optional<ExactRational> tail_mass;
  if (law.normalized_law_established()) {
    auto zero = law.mass(BigNat{0U});
    auto one = law.mass(BigNat{1U});
    auto two = law.mass(BigNat{2U});
    if (!zero || !one || !two) {
      return fail<ThreeBinIidSummary>(
          "c19.three_bin_boundary_mass_invariant",
          "a normalized three-bin law must expose all boundary and aggregate "
          "tail masses",
          DiagnosticCategory::internal);
    }
    pi_zero = std::move(zero).value();
    pi_one = std::move(one).value();
    pi_two = std::move(two).value();
    tail_mass = ExactRational::one() - *pi_zero - *pi_one - *pi_two;
    if (!tail_mass->is_nonnegative()) {
      return fail<ThreeBinIidSummary>(
          "c19.three_bin_negative_aggregate_tail",
          "the normalized law gives negative mass to N>=3",
          DiagnosticCategory::internal);
    }
    if (!(*pi_zero + *pi_one + *pi_two + *tail_mass ==
          ExactRational::one())) {
      return fail<ThreeBinIidSummary>(
          "c19.three_bin_normalization_invariant",
          "the exact three-bin boundary masses and aggregate tail do not "
          "total one",
          DiagnosticCategory::internal);
    }
  }

  std::optional<ExactRational> exact_sojourn;
  std::optional<long double> numerical_sojourn;
  if (premises.lossless && premises.unit_packets &&
      premises.eventual_departure && premises.positive_finite_intensity &&
      premises.finite_first_backlog_moment && premises.little_law &&
      arrival->mean.is_positive() && law.exact_mean_backlog()) {
    auto quotient = checked_divide(*law.exact_mean_backlog(), arrival->mean);
    if (!quotient) {
      return Result<ThreeBinIidSummary>::failure(quotient.error());
    }
    exact_sojourn = std::move(quotient).value();
    const long double numerical = exact_sojourn->to_long_double();
    if (std::isfinite(numerical)) {
      numerical_sojourn = numerical;
    }
  }

  TailSlackApplicabilityV1 slack_applicability =
      TailSlackApplicabilityV1::stationary_law_not_established;
  std::optional<ExactRational> slack;
  if (law.status() ==
      AnalyticStationaryStatusV1::finite_closed_tail_unreachable) {
    if (!law.finite_closure_proof()) {
      return fail<ThreeBinIidSummary>(
          "c19.three_bin_finite_closure_proof_missing",
          "the finite-closed three-bin branch requires its solver-owned "
          "closure proof",
          DiagnosticCategory::internal);
    }
    slack_applicability = TailSlackApplicabilityV1::not_applicable_off_class;
  } else if (law.diagnostics().tail_slack) {
    slack_applicability = TailSlackApplicabilityV1::applicable;
    slack = law.diagnostics().tail_slack;
  }

  const std::array<StationaryConditioningRegionV1, 4U> regions{
      StationaryConditioningRegionV1::backlog_zero,
      StationaryConditioningRegionV1::backlog_one,
      StationaryConditioningRegionV1::backlog_two,
      StationaryConditioningRegionV1::backlog_at_least_three};
  const std::array<ExactRational, 4U> responses{
      ExactRational::zero(), response.prefix[1U], response.prefix[2U],
      *response.constant_tail_service};
  const std::array<std::optional<ExactRational>, 4U> masses{
      pi_zero, pi_one, pi_two, tail_mass};
  std::array<ThreeBinStationaryAtomV1, 4U> bins{
      ThreeBinStationaryAtomV1{
          regions[0U], responses[0U],
          conditioning_mass(masses[0U], regions[0U], false)},
      ThreeBinStationaryAtomV1{
          regions[1U], responses[1U],
          conditioning_mass(masses[1U], regions[1U], false)},
      ThreeBinStationaryAtomV1{
          regions[2U], responses[2U],
          conditioning_mass(masses[2U], regions[2U], false)},
      ThreeBinStationaryAtomV1{
          regions[3U], responses[3U],
          conditioning_mass(masses[3U], regions[3U], true)}};

  auto core = std::make_shared<stationary::detail::ThreeBinIidSummaryCore>(
      stationary::detail::ThreeBinIidSummaryCore{
          std::move(bins),
          std::move(pi_zero),
          std::move(pi_one),
          std::move(pi_two),
          std::move(tail_mass),
          responses[0U],
          responses[1U],
          responses[2U],
          responses[3U],
          arrival->mean,
          law.exact_mean_backlog(),
          law.numerical_mean_backlog(),
          std::move(exact_sojourn),
          std::move(numerical_sojourn),
          MeanSojournCountingConventionV1::includes_departure_slot,
          slack_applicability,
          std::move(slack),
          law.status(),
          law.diagnostics(),
          law.identity()});
  return Result<ThreeBinIidSummary>::success(
      detail::C19CoreAccess::three_bin_summary(std::move(core)));
}

[[nodiscard]] Result<FinitePrefixIidSummary> summarize_finite_prefix_law(
    const std::shared_ptr<surrogate::detail::SealedFrameworkCore>& sealed,
    const std::shared_ptr<const stationary::detail::ArrivalLawCore>& arrival,
    const stationary::detail::ScalarResponseData& response,
    const ScalarStationaryLaw& law, const LittleLawPremises premises) {
  const auto* payload = sealed
                            ? std::get_if<
                                  PortableFinitePrefixConstantTailResponseV1>(
                                  &portable_source_v1(sealed->plug()).value())
                            : nullptr;
  if (payload == nullptr || !response.constant_tail_from ||
      !response.constant_tail_service || response.prefix.empty() ||
      !response.prefix.front().is_zero()) {
    return fail<FinitePrefixIidSummary>(
        "c19.finite_prefix_response_shape",
        "the K-wide IID summary requires a sealed finite prefix, structural "
        "mu(0)=0, and a typed constant-tail coefficient");
  }
  auto cutoff_index = native_index(payload->response_cutoff);
  if (!cutoff_index ||
      response.prefix.size() != cutoff_index.value() + 1U ||
      response.constant_tail_from->value() !=
          payload->response_cutoff.value() + 1 ||
      !(*response.constant_tail_service == payload->constant_tail_service)) {
    return fail<FinitePrefixIidSummary>(
        "c19.finite_prefix_response_shape",
        "the K-wide IID summary requires prefix mu(0)..mu(K) and a tail "
        "beginning at K+1");
  }

  std::optional<std::vector<ExactRational>> prefix_masses;
  std::optional<ExactRational> aggregate_tail_mass;
  if (law.normalized_law_established()) {
    std::vector<ExactRational> masses;
    masses.reserve(response.prefix.size());
    ExactRational prefix_total = ExactRational::zero();
    for (std::size_t level = 0U; level < response.prefix.size(); ++level) {
      auto mass = law.mass(BigNat{static_cast<std::uint64_t>(level)});
      if (!mass) {
        return fail<FinitePrefixIidSummary>(
            "c19.finite_prefix_boundary_mass_invariant",
            "a normalized K-wide law must expose every prefix mass",
            DiagnosticCategory::internal);
      }
      prefix_total = prefix_total + mass.value();
      masses.push_back(std::move(mass).value());
    }
    ExactRational tail = ExactRational::one() - prefix_total;
    if (!tail.is_nonnegative() ||
        !(prefix_total + tail == ExactRational::one())) {
      return fail<FinitePrefixIidSummary>(
          "c19.finite_prefix_normalization_invariant",
          "the exact K-wide prefix and aggregate tail masses must be "
          "nonnegative and total one",
          DiagnosticCategory::internal);
    }
    prefix_masses = std::move(masses);
    aggregate_tail_mass = std::move(tail);
  }

  std::optional<ExactRational> exact_sojourn;
  std::optional<long double> numerical_sojourn;
  if (premises.lossless && premises.unit_packets &&
      premises.eventual_departure && premises.positive_finite_intensity &&
      premises.finite_first_backlog_moment && premises.little_law &&
      arrival->mean.is_positive() && law.exact_mean_backlog()) {
    auto quotient = checked_divide(*law.exact_mean_backlog(), arrival->mean);
    if (!quotient) {
      return Result<FinitePrefixIidSummary>::failure(quotient.error());
    }
    exact_sojourn = std::move(quotient).value();
    const long double numerical = exact_sojourn->to_long_double();
    if (std::isfinite(numerical)) {
      numerical_sojourn = numerical;
    }
  }

  TailSlackApplicabilityV1 slack_applicability =
      TailSlackApplicabilityV1::stationary_law_not_established;
  std::optional<ExactRational> slack;
  if (law.status() ==
      AnalyticStationaryStatusV1::finite_closed_tail_unreachable) {
    if (!law.finite_closure_proof()) {
      return fail<FinitePrefixIidSummary>(
          "c19.finite_prefix_closure_proof_missing",
          "the finite-closed K-wide branch requires its solver-owned "
          "closure proof",
          DiagnosticCategory::internal);
    }
    slack_applicability = TailSlackApplicabilityV1::not_applicable_off_class;
  } else if (law.diagnostics().tail_slack) {
    slack_applicability = TailSlackApplicabilityV1::applicable;
    slack = law.diagnostics().tail_slack;
  }

  auto core =
      std::make_shared<stationary::detail::FinitePrefixIidSummaryCore>(
          stationary::detail::FinitePrefixIidSummaryCore{
              payload->response_cutoff,
              response.prefix,
              FinitePrefixConstantTailCoefficientV1{
                  *response.constant_tail_from,
                  *response.constant_tail_service},
              std::move(prefix_masses),
              std::move(aggregate_tail_mass),
              arrival->mean,
              law.exact_mean_backlog(),
              law.numerical_mean_backlog(),
              std::move(exact_sojourn),
              std::move(numerical_sojourn),
              MeanSojournCountingConventionV1::includes_departure_slot,
              slack_applicability,
              std::move(slack),
              law.status(),
              law.diagnostics(),
              payload->normalized_record.response_row_id,
              payload->selected_product.identity(),
              law.identity()});
  return Result<FinitePrefixIidSummary>::success(
      detail::C19CoreAccess::finite_prefix_summary(std::move(core)));
}

[[nodiscard]] ExactRational maximum_difference(
    const std::span<const ExactRational> left,
    const std::span<const ExactRational> right) {
  ExactRational maximum = ExactRational::zero();
  for (std::size_t index = 0U; index < left.size(); ++index) {
    maximum = std::max(maximum, absolute_value(left[index] - right[index]));
  }
  return maximum;
}

#if defined(MWPERF_C19_TEST_SEAMS)
[[nodiscard]] Result<FixedPointLaw> solve_fixed_point_fixture(
    testing::ExactFixedPointFixtureV1 fixture,
    const SelectionSpec& selection, const SolverPolicy& policy) {
  auto valid_policy = validate_solver_policy(policy);
  if (!valid_policy) {
    return Result<FixedPointLaw>::failure(valid_policy.error());
  }
  if (!policy.max_iterations.has_value()) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_budget_required",
        "the fixed-point map requires an explicit evaluation budget");
  }
  auto budget = native_index(*policy.max_iterations);
  if (!budget || budget.value() == 0U) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_budget_invalid",
        "the fixed-point evaluation budget must be positive");
  }
  const std::size_t dimension = fixture.lower.size();
  if (dimension == 0U || fixture.upper.size() != dimension ||
      fixture.cold_initial.size() != dimension || !fixture.map) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_family_dimension",
        "the fixed-point family requires equal nonempty domain and cold "
        "dimensions plus a declared map");
  }
  for (std::size_t index = 0U; index < dimension; ++index) {
    if (fixture.lower[index] > fixture.upper[index] ||
        fixture.cold_initial[index] < fixture.lower[index] ||
        fixture.cold_initial[index] > fixture.upper[index]) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_cold_domain",
          "the declared cold fixed-point iterate must lie in its domain");
    }
  }
  for (std::size_t index = 0U; index < fixture.named_solutions.size();
       ++index) {
    const auto& solution = fixture.named_solutions[index];
    if (solution.parameters.size() != dimension) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_named_solution_dimension",
          "a declared fixed-point solution has the wrong dimension");
    }
    for (std::size_t coordinate = 0U; coordinate < dimension; ++coordinate) {
      if (solution.parameters[coordinate] < fixture.lower[coordinate] ||
          solution.parameters[coordinate] > fixture.upper[coordinate]) {
        return fail<FixedPointLaw>(
            "c19.fixed_point_named_solution_domain",
            "a declared fixed-point solution lies outside the domain");
      }
    }
    for (std::size_t prior = 0U; prior < index; ++prior) {
      if (fixture.named_solutions[prior].id == solution.id) {
        return fail<FixedPointLaw>(
            "c19.duplicate_fixed_point_id",
            "a declared fixed-point solution ID must be unique");
      }
    }
  }
  const auto* fixed = std::get_if<FixedPointSelection>(&selection);
  if (fixed == nullptr) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_selection_required",
        "the fixed-point family requires a fixed-point selector");
  }
  const testing::ExactNamedFixedPointSolutionV1* selected_solution = nullptr;
  if (fixture.uniqueness_declared) {
    if (!std::holds_alternative<FixedPointUniqueSelection>(*fixed)) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_unique_selector_required",
          "a family declared unique requires fixed_point_unique selection");
    }
  } else {
    const auto* one = std::get_if<FixedPointIdSelection>(fixed);
    if (one == nullptr) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_ambiguous",
          "a nonunique fixed-point family requires an explicit solution ID");
    }
    const auto named = std::find_if(
        fixture.named_solutions.begin(), fixture.named_solutions.end(),
        [&](const auto& solution) { return solution.id == one->solution_id; });
    if (named == fixture.named_solutions.end()) {
      return fail<FixedPointLaw>(
          "c19.unknown_fixed_point_id",
          "the selector names no declared fixed-point solution");
    }
    selected_solution = &*named;
  }
  auto selector_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(selection);
  if (!selector_digest) {
    return Result<FixedPointLaw>::failure(selector_digest.error());
  }
  auto identity = identity_with_selection(fixture_identity(), selection);
  if (!identity) {
    return Result<FixedPointLaw>::failure(identity.error());
  }
  std::vector<ExactRational> candidate = fixture.cold_initial;
  ExactRational iterate_difference = ExactRational::zero();
  ExactRational residual = ExactRational::zero();
  std::size_t iterations = 0U;
  std::size_t evaluations = 0U;
  FixedPointTerminationV1 termination =
      FixedPointTerminationV1::iteration_budget_exhausted;
  while (evaluations < budget.value()) {
    auto image = fixture.map(candidate);
    ++evaluations;
    if (!image) {
      return Result<FixedPointLaw>::failure(image.error());
    }
    if (image.value().size() != dimension) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_codomain_dimension",
          "the fixed-point map returned the wrong codomain dimension");
    }
    for (std::size_t index = 0U; index < dimension; ++index) {
      if (image.value()[index] < fixture.lower[index] ||
          image.value()[index] > fixture.upper[index]) {
        return fail<FixedPointLaw>(
            "c19.fixed_point_left_domain",
            "the fixed-point map left its declared domain");
      }
    }
    residual = maximum_difference(image.value(), candidate);
    if (residual <= policy.absolute_residual_tolerance) {
      termination =
          selected_solution != nullptr &&
                  maximum_difference(candidate,
                                     selected_solution->parameters) >
                      policy.absolute_residual_tolerance
              ? FixedPointTerminationV1::selected_root_unavailable
              : FixedPointTerminationV1::converged;
      break;
    }
    if (evaluations == budget.value()) {
      break;
    }
    iterate_difference = residual;
    candidate = std::move(image).value();
    ++iterations;
  }
  auto core = std::make_shared<stationary::detail::FixedPointLawCore>(
      stationary::detail::FixedPointLawCore{
          termination, std::move(candidate), std::move(iterate_difference),
          std::move(residual), BigNat{iterations}, BigNat{evaluations},
          std::move(selector_digest).value(), std::move(identity).value()});
  return Result<FixedPointLaw>::success(
      detail::C19CoreAccess::fixed_point_law(std::move(core)));
}
#endif

[[nodiscard]] bool valid_codec_identity(const CodecIdentityV1& codec) {
  return !codec.id.empty() && codec.version != 0U;
}

[[nodiscard]] Result<FixedPointLaw> solve_fixed_point_carrier(
    std::shared_ptr<const
                    stationary::detail::AuditedFixedPointCarrierCore>
        carrier,
    const SelectionSpec& selection, const SolverPolicy& policy) {
  if (!carrier) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_carrier_unavailable",
        "the audited family has no immutable exact C19 fixed-point carrier",
        DiagnosticCategory::unavailable);
  }
  auto valid_policy = validate_solver_policy(policy);
  if (!valid_policy) {
    return Result<FixedPointLaw>::failure(valid_policy.error());
  }
  if (!(policy == carrier->solver_policy) ||
      policy.analysis_fingerprint !=
          bound_analysis_fingerprint(carrier->identity)) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_solver_analysis_mismatch",
        "the fixed-point policy differs from the analysis sealed into the "
        "exact carrier");
  }
  auto portable = portable_selection(selection);
  if (!portable || !(portable.value() == carrier->identity.selection())) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_selection_binding_mismatch",
        "the supplied fixed-point selector differs from the sealed carrier");
  }
  if (!carrier->identity.accepted_metric_clause() ||
      !carrier->identity.realized_metric_binding() ||
      carrier->identity.payload_phase() != PayloadPhaseKindV1::phase_free ||
      !nonzero_digest(carrier->identity.execution_seal_digest()) ||
      !carrier->identity.carrier_snapshot_digest() ||
      !nonzero_digest(*carrier->identity.carrier_snapshot_digest()) ||
      !carrier->seal || !carrier->map ||
      !nonzero_digest(carrier->stable_map_identity.object_digest)) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_carrier_identity_incomplete",
        "the fixed-point carrier lacks its map, seal, clause, evidence, or "
        "stable map identity");
  }
  auto carrier_snapshot =
      fixed_carrier_snapshot_digest(*carrier, carrier->identity);
  if (!carrier_snapshot ||
      carrier_snapshot.value() != *carrier->identity.carrier_snapshot_digest()) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_carrier_snapshot_mismatch",
        "the fixed-point carrier differs from its sealed C19 snapshot "
        "identity");
  }
  if (carrier->family_identity.family_id.empty() ||
      carrier->family_identity.family_version == 0U ||
      !valid_codec_identity(carrier->family_identity.parameter_schema) ||
      !valid_codec_identity(carrier->family_identity.domain_schema) ||
      !valid_codec_identity(carrier->access_shape.argument_codec) ||
      !valid_codec_identity(carrier->access_shape.response_codec) ||
      !(carrier->family_identity.domain_schema ==
        carrier->access_shape.argument_codec) ||
      carrier->access_shape.response_codec !=
          CodecIdentityV1{carrier->family_identity.family_id + ".response",
                          carrier->family_identity.family_version}) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_family_schema_mismatch",
        "the fixed-point carrier's registered family and access codecs do "
        "not match");
  }
  if (carrier->stopping_norm !=
      stationary::detail::C19FixedPointStoppingNormV1::maximum_absolute) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_norm_unavailable",
        "C19 implements only the carrier-declared maximum-absolute norm",
        DiagnosticCategory::unavailable);
  }
  auto iteration_budget = native_index(carrier->iteration_budget);
  auto evaluation_budget = native_index(carrier->evaluation_budget);
  if (!iteration_budget || !evaluation_budget ||
      iteration_budget.value() == 0U || evaluation_budget.value() == 0U ||
      !policy.max_iterations ||
      !(*policy.max_iterations == carrier->iteration_budget)) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_budget_invalid",
        "the fixed-point iteration and evaluation budgets must be positive "
        "and bound to the supplied policy");
  }
  const std::size_t dimension = carrier->domain_lower.size();
  if (dimension == 0U || carrier->domain_upper.size() != dimension ||
      carrier->codomain_lower.size() != dimension ||
      carrier->codomain_upper.size() != dimension ||
      carrier->cold_initial.size() != dimension ||
      carrier->domain_lower != carrier->codomain_lower ||
      carrier->domain_upper != carrier->codomain_upper) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_family_dimension",
        "SF.37 requires one nonempty exact self-map domain and codomain");
  }
  for (std::size_t coordinate = 0U; coordinate < dimension; ++coordinate) {
    if (carrier->domain_lower[coordinate] >
            carrier->domain_upper[coordinate] ||
        carrier->cold_initial[coordinate] <
            carrier->domain_lower[coordinate] ||
        carrier->cold_initial[coordinate] >
            carrier->domain_upper[coordinate]) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_cold_domain",
          "the declared cold initializer lies outside the exact domain");
    }
  }
  for (std::size_t index = 0U; index < carrier->named_solutions.size();
       ++index) {
    const auto& named = carrier->named_solutions[index];
    if (named.parameters.size() != dimension) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_named_solution_dimension",
          "a declared fixed-point solution has the wrong dimension");
    }
    for (std::size_t coordinate = 0U; coordinate < dimension; ++coordinate) {
      if (named.parameters[coordinate] < carrier->domain_lower[coordinate] ||
          named.parameters[coordinate] > carrier->domain_upper[coordinate]) {
        return fail<FixedPointLaw>(
            "c19.fixed_point_named_solution_domain",
            "a declared fixed-point solution lies outside the exact domain");
      }
    }
    for (std::size_t prior = 0U; prior < index; ++prior) {
      if (carrier->named_solutions[prior].id == named.id) {
        return fail<FixedPointLaw>(
            "c19.duplicate_fixed_point_id",
            "declared fixed-point solution identities must be unique");
      }
    }
  }
  const stationary::detail::C19NamedFixedPointSolutionV1* selected_solution =
      nullptr;
  const auto* fixed = std::get_if<FixedPointSelection>(&selection);
  if (fixed == nullptr) {
    return fail<FixedPointLaw>(
        "c19.fixed_point_selection_required",
        "the fixed-point family requires a fixed-point selector");
  }
  if (carrier->uniqueness_declared) {
    if (!std::holds_alternative<FixedPointUniqueSelection>(*fixed)) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_unique_selector_required",
          "a carrier declared unique requires fixed_point_unique selection");
    }
  } else {
    const auto* selected = std::get_if<FixedPointIdSelection>(fixed);
    if (selected == nullptr) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_ambiguous",
          "a nonunique family requires an explicit fixed-point identity");
    }
    const auto found = std::find_if(
        carrier->named_solutions.begin(), carrier->named_solutions.end(),
        [&](const auto& named) { return named.id == selected->solution_id; });
    if (found == carrier->named_solutions.end()) {
      return fail<FixedPointLaw>(
          "c19.unknown_fixed_point_id",
          "the selector names no carrier-owned fixed-point solution");
    }
    selected_solution = &*found;
  }
  auto selector_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(selection);
  if (!selector_digest) {
    return Result<FixedPointLaw>::failure(selector_digest.error());
  }

  std::vector<ExactRational> candidate = carrier->cold_initial;
  ExactRational iterate_difference = ExactRational::zero();
  ExactRational residual = ExactRational::zero();
  std::size_t iterations = 0U;
  std::size_t evaluations = 0U;
  FixedPointTerminationV1 termination =
      FixedPointTerminationV1::iteration_budget_exhausted;
  while (evaluations < evaluation_budget.value()) {
    auto image = carrier->map(candidate);
    ++evaluations;
    if (!image) {
      return Result<FixedPointLaw>::failure(image.error());
    }
    if (image.value().size() != dimension) {
      return fail<FixedPointLaw>(
          "c19.fixed_point_codomain_dimension",
          "the carrier-owned map returned the wrong codomain dimension");
    }
    for (std::size_t coordinate = 0U; coordinate < dimension; ++coordinate) {
      if (image.value()[coordinate] < carrier->codomain_lower[coordinate] ||
          image.value()[coordinate] > carrier->codomain_upper[coordinate]) {
        return fail<FixedPointLaw>(
            "c19.fixed_point_left_codomain",
            "the carrier-owned map left its declared exact codomain");
      }
    }
    residual = maximum_difference(image.value(), candidate);
    if (residual <= policy.absolute_residual_tolerance) {
      termination =
          selected_solution != nullptr &&
                  maximum_difference(candidate,
                                     selected_solution->parameters) >
                      policy.absolute_residual_tolerance
              ? FixedPointTerminationV1::selected_root_unavailable
              : FixedPointTerminationV1::converged;
      break;
    }
    if (iterations == iteration_budget.value()) {
      termination = FixedPointTerminationV1::iteration_budget_exhausted;
      break;
    }
    if (evaluations == evaluation_budget.value()) {
      termination = FixedPointTerminationV1::evaluation_budget_exhausted;
      break;
    }
    iterate_difference = residual;
    candidate = std::move(image).value();
    ++iterations;
  }
  auto core = std::make_shared<stationary::detail::FixedPointLawCore>(
      stationary::detail::FixedPointLawCore{
          termination, std::move(candidate), std::move(iterate_difference),
          std::move(residual), BigNat{iterations}, BigNat{evaluations},
          std::move(selector_digest).value(), carrier->identity,
          std::move(carrier)});
  return Result<FixedPointLaw>::success(
      detail::C19CoreAccess::fixed_point_law(std::move(core)));
}

}  // namespace

namespace stationary::detail {

Result<AuditedResponseLaw> mint_c19_scalar_response(
    C19ScalarResponseCarrierSpecV1 spec) {
  auto carrier = make_scalar_carrier(std::move(spec));
  if (!carrier) {
    return Result<AuditedResponseLaw>::failure(carrier.error());
  }
  return Result<AuditedResponseLaw>::success(
      ::mwperf::detail::C19CoreAccess::scalar_response(
          std::move(carrier).value()));
}

Result<AuditedThreeBinResponse> mint_c19_three_bin_response(
    C19ScalarResponseCarrierSpecV1 spec) {
  auto carrier = make_scalar_carrier(std::move(spec));
  if (!carrier) {
    return Result<AuditedThreeBinResponse>::failure(carrier.error());
  }
  return Result<AuditedThreeBinResponse>::success(
      ::mwperf::detail::C19CoreAccess::three_bin_response(
          std::move(carrier).value()));
}

Result<AuditedPhaseResponse> mint_c19_phase_response(
    C19PhaseResponseCarrierSpecV1 spec) {
  auto valid_policy = validate_solver_policy(spec.solver_policy);
  if (!valid_policy) {
    return Result<AuditedPhaseResponse>::failure(valid_policy.error());
  }
  if (spec.solver_policy.analysis_fingerprint !=
      spec.lineage.analysis_fingerprint) {
    return fail<AuditedPhaseResponse>(
        "c19.phase_solver_analysis_mismatch",
        "the phase carrier policy must name its originating analysis");
  }
  auto portable = portable_selection(spec.selection);
  if (!portable ||
      (!std::holds_alternative<PortableStationaryUniqueSelectionV1>(
           portable.value()) &&
       !std::holds_alternative<PortableStationaryClassSelectionV1>(
           portable.value()) &&
       !std::holds_alternative<PortableStationaryMixtureSelectionV1>(
           portable.value()))) {
    return fail<AuditedPhaseResponse>(
        "c19.phase_stationary_selection_required",
        "an exact phase carrier requires a stationary selection");
  }
  auto identity = carrier_identity(
      spec.lineage, spec.selection,
      PayloadPhaseKindV1::predictive_phase_indexed,
      PayloadClassTagV1::finite_parameter_analytic_data_v1);
  if (!identity) {
    return Result<AuditedPhaseResponse>::failure(identity.error());
  }
  std::sort(spec.arrival_blocks.begin(), spec.arrival_blocks.end(),
            [](const auto& left, const auto& right) {
              return left.arrival_count < right.arrival_count;
            });
  auto snapshot = phase_carrier_snapshot_digest(spec, identity.value());
  if (!snapshot) {
    return Result<AuditedPhaseResponse>::failure(snapshot.error());
  }
  StationaryAnalyticLawIdentityV1 law_identity = identity_with_snapshot(
      identity.value(), std::move(snapshot).value());
  std::shared_ptr<const void> seal =
      std::make_shared<Digest256>(spec.lineage.lineage_identity);
  const ArrivalBinding configured_arrival =
      law_identity.configured_arrival();
  auto carrier = std::make_shared<AuditedPhaseResponseCarrierCore>(
      AuditedPhaseResponseCarrierCore{
          std::move(spec.phases), std::move(spec.arrival_blocks),
          std::move(spec.configured_phase_marginal),
          std::move(spec.service_row_major), std::move(spec.completion),
          std::move(spec.solver_policy), std::move(law_identity),
          configured_arrival, std::move(seal)});
  return Result<AuditedPhaseResponse>::success(
      ::mwperf::detail::C19CoreAccess::phase_response(std::move(carrier)));
}

Result<AuditedFixedPointFamily> mint_c19_fixed_point_family(
    C19FixedPointCarrierSpecV1 spec) {
  auto valid_policy = validate_solver_policy(spec.solver_policy);
  if (!valid_policy) {
    return Result<AuditedFixedPointFamily>::failure(valid_policy.error());
  }
  if (spec.solver_policy.analysis_fingerprint !=
      spec.lineage.analysis_fingerprint) {
    return fail<AuditedFixedPointFamily>(
        "c19.fixed_point_solver_analysis_mismatch",
        "the fixed-point carrier policy must name its originating analysis");
  }
  auto portable = portable_selection(spec.selection);
  if (!portable ||
      (!std::holds_alternative<PortableFixedPointUniqueSelectionV1>(
           portable.value()) &&
       !std::holds_alternative<PortableFixedPointIdSelectionV1>(
           portable.value()))) {
    return fail<AuditedFixedPointFamily>(
        "c19.fixed_point_selection_required",
        "an exact fixed-point carrier requires a fixed-point selection");
  }
  auto identity = carrier_identity(
      spec.lineage, spec.selection, PayloadPhaseKindV1::phase_free,
      PayloadClassTagV1::finite_parameter_analytic_data_v1);
  if (!identity) {
    return Result<AuditedFixedPointFamily>::failure(identity.error());
  }
  auto snapshot = fixed_carrier_snapshot_digest(spec, identity.value());
  if (!snapshot) {
    return Result<AuditedFixedPointFamily>::failure(snapshot.error());
  }
  StationaryAnalyticLawIdentityV1 law_identity = identity_with_snapshot(
      identity.value(), std::move(snapshot).value());
  std::shared_ptr<const void> seal =
      std::make_shared<Digest256>(spec.lineage.lineage_identity);
  auto carrier = std::make_shared<AuditedFixedPointCarrierCore>(
      AuditedFixedPointCarrierCore{
          std::move(spec.domain_lower), std::move(spec.domain_upper),
          std::move(spec.codomain_lower), std::move(spec.codomain_upper),
          std::move(spec.cold_initial), spec.stopping_norm,
          std::move(spec.iteration_budget), std::move(spec.evaluation_budget),
          spec.uniqueness_declared, std::move(spec.named_solutions),
          std::move(spec.map), std::move(spec.stable_map_identity),
          std::move(spec.family_identity), std::move(spec.access_shape),
          std::move(spec.solver_policy), std::move(law_identity),
          std::move(seal)});
  return Result<AuditedFixedPointFamily>::success(
      ::mwperf::detail::C19CoreAccess::fixed_point_family(
          std::move(carrier)));
}

}  // namespace stationary::detail

const AuditedFrameworkBindingsV1& StationaryAnalyticLawIdentityV1::framework()
    const noexcept {
  return core_->framework;
}
const ArtifactValidationBindingsV1& StationaryAnalyticLawIdentityV1::artifact()
    const noexcept {
  return core_->artifact;
}
const Digest256& StationaryAnalyticLawIdentityV1::execution_seal_digest()
    const noexcept {
  return core_->execution_seal_digest;
}
const std::optional<Digest256>&
StationaryAnalyticLawIdentityV1::carrier_snapshot_digest() const noexcept {
  return core_->carrier_snapshot_digest;
}
const ArtifactObjectReferenceV1& StationaryAnalyticLawIdentityV1::payload()
    const noexcept {
  return core_->payload;
}
const std::optional<MetricClauseIdV1>&
StationaryAnalyticLawIdentityV1::accepted_metric_clause() const noexcept {
  return core_->accepted_metric_clause;
}
const std::optional<RealizedMetricBindingV1>&
StationaryAnalyticLawIdentityV1::realized_metric_binding() const noexcept {
  return core_->realized_metric_binding;
}
PayloadPhaseKindV1 StationaryAnalyticLawIdentityV1::payload_phase()
    const noexcept {
  return core_->payload_phase;
}
const std::optional<ResponseProductStageV1>&
StationaryAnalyticLawIdentityV1::response_stage() const noexcept {
  return core_->response_stage;
}
const std::optional<ArtifactObjectReferenceV1>&
StationaryAnalyticLawIdentityV1::response_product() const noexcept {
  return core_->response_product;
}
const std::optional<ArtifactObjectReferenceV1>&
StationaryAnalyticLawIdentityV1::derivation() const noexcept {
  return core_->derivation;
}
const std::optional<BigNat>& StationaryAnalyticLawIdentityV1::cutoff()
    const noexcept {
  return core_->cutoff;
}
const std::optional<ExactRational>&
StationaryAnalyticLawIdentityV1::tail_service() const noexcept {
  return core_->tail_service;
}
const ArrivalBinding& StationaryAnalyticLawIdentityV1::configured_arrival()
    const noexcept {
  return core_->configured_arrival;
}
const PortableAnalysisSelectionV1& StationaryAnalyticLawIdentityV1::selection()
    const noexcept {
  return core_->selection;
}
const QueueId& StationaryAnalyticLawIdentityV1::target() const noexcept {
  return core_->target;
}
std::span<const QueueId>
StationaryAnalyticLawIdentityV1::construction_targets() const noexcept {
  return core_->construction_targets;
}
MetricResultScopeV1 StationaryAnalyticLawIdentityV1::result_scope()
    const noexcept {
  return core_->result_scope;
}
bool operator==(const StationaryAnalyticLawIdentityV1& left,
                const StationaryAnalyticLawIdentityV1& right) {
  return left.core_->framework == right.core_->framework &&
         left.core_->artifact == right.core_->artifact &&
         left.core_->execution_seal_digest == right.core_->execution_seal_digest &&
         left.core_->carrier_snapshot_digest ==
             right.core_->carrier_snapshot_digest &&
         left.core_->payload == right.core_->payload &&
         left.core_->accepted_metric_clause ==
             right.core_->accepted_metric_clause &&
         left.core_->realized_metric_binding ==
             right.core_->realized_metric_binding &&
         left.core_->payload_phase == right.core_->payload_phase &&
         left.core_->response_stage == right.core_->response_stage &&
         left.core_->response_product == right.core_->response_product &&
         left.core_->derivation == right.core_->derivation &&
         left.core_->cutoff == right.core_->cutoff &&
         left.core_->tail_service == right.core_->tail_service &&
         left.core_->configured_arrival == right.core_->configured_arrival &&
         left.core_->selection == right.core_->selection &&
         left.core_->target == right.core_->target &&
         left.core_->construction_targets == right.core_->construction_targets &&
         left.core_->result_scope == right.core_->result_scope;
}

StationaryConditioningMassKindV1
StationaryConditioningMassStatus::kind() const noexcept {
  return core_->kind;
}
const std::optional<ExactRational>& StationaryConditioningMassStatus::mass()
    const noexcept {
  return core_->mass;
}
const std::optional<StationaryConditioningRegionV1>&
StationaryConditioningMassStatus::region() const noexcept {
  return core_->region;
}
bool operator==(const StationaryConditioningMassStatus& left,
                const StationaryConditioningMassStatus& right) {
  return left.core_->kind == right.core_->kind &&
         left.core_->mass == right.core_->mass &&
         left.core_->region == right.core_->region;
}

std::span<const ThreeBinStationaryAtomV1, 4> ThreeBinIidSummary::bins()
    const noexcept {
  return core_->bins;
}
const std::optional<ExactRational>& ThreeBinIidSummary::pi_zero()
    const noexcept {
  return core_->pi_zero;
}
const std::optional<ExactRational>& ThreeBinIidSummary::pi_one()
    const noexcept {
  return core_->pi_one;
}
const std::optional<ExactRational>& ThreeBinIidSummary::pi_two()
    const noexcept {
  return core_->pi_two;
}
const std::optional<ExactRational>& ThreeBinIidSummary::tail_mass_from_three()
    const noexcept {
  return core_->tail_mass_from_three;
}
const ExactRational& ThreeBinIidSummary::mu_zero() const noexcept {
  return core_->mu_zero;
}
const ExactRational& ThreeBinIidSummary::mu_one() const noexcept {
  return core_->mu_one;
}
const ExactRational& ThreeBinIidSummary::mu_two() const noexcept {
  return core_->mu_two;
}
const ExactRational& ThreeBinIidSummary::mu_tail_from_three() const noexcept {
  return core_->mu_tail_from_three;
}
const ExactRational& ThreeBinIidSummary::arrival_mean() const noexcept {
  return core_->arrival_mean;
}
const std::optional<ExactRational>& ThreeBinIidSummary::exact_mean_backlog()
    const noexcept {
  return core_->exact_mean_backlog;
}
const std::optional<long double>& ThreeBinIidSummary::numerical_mean_backlog()
    const noexcept {
  return core_->numerical_mean_backlog;
}
const std::optional<ExactRational>& ThreeBinIidSummary::exact_mean_sojourn()
    const noexcept {
  return core_->exact_mean_sojourn;
}
const std::optional<long double>& ThreeBinIidSummary::numerical_mean_sojourn()
    const noexcept {
  return core_->numerical_mean_sojourn;
}
MeanSojournCountingConventionV1
ThreeBinIidSummary::sojourn_counting_convention() const noexcept {
  return core_->sojourn_counting_convention;
}
TailSlackApplicabilityV1 ThreeBinIidSummary::tail_slack_applicability()
    const noexcept {
  return core_->tail_slack_applicability;
}
const std::optional<ExactRational>& ThreeBinIidSummary::tail_slack()
    const noexcept {
  return core_->tail_slack;
}
AnalyticStationaryStatusV1 ThreeBinIidSummary::status() const noexcept {
  return core_->status;
}
const AnalyticStationaryDiagnosticsV1& ThreeBinIidSummary::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const StationaryAnalyticLawIdentityV1& ThreeBinIidSummary::law_identity()
    const noexcept {
  return core_->identity;
}

const BigNat& FinitePrefixIidSummary::cutoff() const noexcept {
  return core_->cutoff;
}
std::span<const ExactRational> FinitePrefixIidSummary::service_by_level()
    const noexcept {
  return core_->service_by_level;
}
const FinitePrefixConstantTailCoefficientV1&
FinitePrefixIidSummary::tail_coefficient() const noexcept {
  return core_->tail_coefficient;
}
const std::optional<std::vector<ExactRational>>&
FinitePrefixIidSummary::prefix_masses() const noexcept {
  return core_->prefix_masses;
}
const std::optional<ExactRational>&
FinitePrefixIidSummary::aggregate_tail_mass() const noexcept {
  return core_->aggregate_tail_mass;
}
const ExactRational& FinitePrefixIidSummary::arrival_mean() const noexcept {
  return core_->arrival_mean;
}
const std::optional<ExactRational>&
FinitePrefixIidSummary::exact_mean_backlog() const noexcept {
  return core_->exact_mean_backlog;
}
const std::optional<long double>&
FinitePrefixIidSummary::numerical_mean_backlog() const noexcept {
  return core_->numerical_mean_backlog;
}
const std::optional<ExactRational>&
FinitePrefixIidSummary::exact_mean_sojourn() const noexcept {
  return core_->exact_mean_sojourn;
}
const std::optional<long double>&
FinitePrefixIidSummary::numerical_mean_sojourn() const noexcept {
  return core_->numerical_mean_sojourn;
}
MeanSojournCountingConventionV1
FinitePrefixIidSummary::sojourn_counting_convention() const noexcept {
  return core_->sojourn_counting_convention;
}
TailSlackApplicabilityV1
FinitePrefixIidSummary::tail_slack_applicability() const noexcept {
  return core_->tail_slack_applicability;
}
const std::optional<ExactRational>& FinitePrefixIidSummary::tail_slack()
    const noexcept {
  return core_->tail_slack;
}
AnalyticStationaryStatusV1 FinitePrefixIidSummary::status() const noexcept {
  return core_->status;
}
const AnalyticStationaryDiagnosticsV1& FinitePrefixIidSummary::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const ArtifactObjectReferenceV1& FinitePrefixIidSummary::response_identity()
    const noexcept {
  return core_->response_identity;
}
const ArtifactObjectReferenceV1&
FinitePrefixIidSummary::response_product_identity() const noexcept {
  return core_->response_product_identity;
}
const StationaryAnalyticLawIdentityV1&
FinitePrefixIidSummary::law_identity() const noexcept {
  return core_->law_identity;
}

Result<ArrivalLaw> ArrivalLaw::from_audited(
    const AuditedResponseLaw& response) {
  if (auto carrier = detail::C19CoreAccess::carrier(response)) {
    return arrival_from_carrier(carrier);
  }
  return arrival_from_sealed(detail::C19CoreAccess::sealed(response));
}
Result<ArrivalLaw> ArrivalLaw::from_audited(
    const AuditedThreeBinResponse& response) {
  if (auto carrier = detail::C19CoreAccess::carrier(response)) {
    return arrival_from_carrier(carrier);
  }
  return arrival_from_sealed(detail::C19CoreAccess::sealed(response));
}
std::span<const ScalarArrivalMassV1> ArrivalLaw::atoms() const noexcept {
  return core_->atoms;
}
const ExactRational& ArrivalLaw::mean() const noexcept { return core_->mean; }
const std::optional<ExactRational>& ArrivalLaw::second_moment() const noexcept {
  return core_->second_moment;
}
const ArrivalBinding& ArrivalLaw::configured_arrival() const noexcept {
  return core_->configured_arrival;
}
const QueueId& ArrivalLaw::target() const noexcept { return core_->target; }
const Digest256& ArrivalLaw::identity_digest() const noexcept {
  return core_->identity_digest;
}

ArrivalPmf ArrivalPmf::from(const ArrivalLaw& law) {
  return detail::C19CoreAccess::arrival_pmf(
      std::make_shared<stationary::detail::ArrivalPmfCore>(
          stationary::detail::ArrivalPmfCore{
              detail::C19CoreAccess::core_ptr(law)}));
}
std::span<const ScalarArrivalMassV1> ArrivalPmf::atoms() const noexcept {
  return core_->law->atoms;
}
Result<ExactRational> ArrivalPmf::probability(const BigNat& count) const {
  return Result<ExactRational>::success(
      arrival_probability(*core_->law, count.value()));
}
Result<ExactRational> ArrivalPmf::survival(const BigNat& count) const {
  return Result<ExactRational>::success(
      arrival_survival(*core_->law, count.value()));
}
const Digest256& ArrivalPmf::identity_digest() const noexcept {
  return core_->law->identity_digest;
}

Result<BernoulliRate> BernoulliRate::from(const ArrivalLaw& law) {
  const auto& core = detail::C19CoreAccess::core(law);
  for (const auto& atom : core.atoms) {
    if (atom.mass.is_positive() && atom.count.value() > 1) {
      return fail<BernoulliRate>(
          "c19.arrival_not_bernoulli",
          "the selected IID arrival marginal is not Bernoulli",
          DiagnosticCategory::unavailable);
    }
  }
  return Result<BernoulliRate>::success(
      detail::C19CoreAccess::bernoulli_rate(
          std::make_shared<stationary::detail::BernoulliRateCore>(
              stationary::detail::BernoulliRateCore{
                  arrival_probability(core, BigInt{1}),
                  detail::C19CoreAccess::core_ptr(law)})));
}
const ExactRational& BernoulliRate::value() const noexcept {
  return core_->value;
}
const Digest256& BernoulliRate::identity_digest() const noexcept {
  return core_->law->identity_digest;
}

ArrivalTransform ArrivalTransform::from(const ArrivalLaw& law) {
  return detail::C19CoreAccess::arrival_transform(
      std::make_shared<stationary::detail::ArrivalTransformCore>(
          stationary::detail::ArrivalTransformCore{
              detail::C19CoreAccess::core_ptr(law)}));
}
const Digest256& ArrivalTransform::identity_digest() const noexcept {
  return core_->law->identity_digest;
}

Result<EvaluationPoint> EvaluationPoint::make(ExactRational z) {
  if (!z.is_nonnegative() || z > ExactRational::one()) {
    return fail<EvaluationPoint>("c19.evaluation_point_out_of_range",
                                 "a stationary PGF point must lie in [0,1]");
  }
  return Result<EvaluationPoint>::success(EvaluationPoint(std::move(z)));
}

Result<TailService> TailService::make(ExactRational value) {
  if (!value.is_nonnegative() || value > ExactRational::one()) {
    return fail<TailService>("c19.tail_service_out_of_range",
                             "a tail service probability must lie in [0,1]");
  }
  return Result<TailService>::success(TailService(std::move(value)));
}

TailPolicy TailPolicy::exact_finite_closure(Cutoff cutoff) {
  return TailPolicy(ScalarTailCompletionKindV1::exact_finite_closure,
                    std::move(cutoff), std::nullopt, std::nullopt,
                    std::nullopt);
}
TailPolicy TailPolicy::constant_response(Cutoff cutoff,
                                         TailService service) {
  return TailPolicy(ScalarTailCompletionKindV1::constant_response,
                    std::move(cutoff), std::move(service), std::nullopt,
                    std::nullopt);
}
TailPolicy TailPolicy::certified_truncation(
    Cutoff cutoff, ExactRational tail_mass_bound) {
  return TailPolicy(ScalarTailCompletionKindV1::certified_truncation,
                    std::move(cutoff), std::nullopt,
                    std::move(tail_mass_bound), std::nullopt);
}
TailPolicy TailPolicy::no_completion(BigNat maximum_terms) {
  return TailPolicy(ScalarTailCompletionKindV1::no_completion, std::nullopt,
                    std::nullopt, std::nullopt, std::move(maximum_terms));
}
ScalarTailCompletionKindV1 TailPolicy::kind() const noexcept { return kind_; }
const std::optional<Cutoff>& TailPolicy::cutoff() const noexcept {
  return cutoff_;
}
const std::optional<TailService>& TailPolicy::tail_service() const noexcept {
  return service_;
}
const std::optional<ExactRational>& TailPolicy::tail_mass_bound()
    const noexcept {
  return tail_mass_bound_;
}
const std::optional<BigNat>& TailPolicy::maximum_terms() const noexcept {
  return maximum_terms_;
}

const StationaryAnalyticLawIdentityV1& ScalarFluxOperator::identity()
    const noexcept {
  return core_->identity;
}
Result<ExactRational> ScalarFluxOperator::arrival_probability(
    const BigNat& count) const {
  return Result<ExactRational>::success(
      ::mwperf::arrival_probability(*core_->arrival, count.value()));
}
Result<ExactRational> ScalarFluxOperator::arrival_survival(
    const BigNat& count) const {
  return Result<ExactRational>::success(
      ::mwperf::arrival_survival(*core_->arrival, count.value()));
}
Result<ExactRational> ScalarFluxOperator::service_probability(
    const BigNat& backlog) const {
  return ::mwperf::service_probability(core_->response, backlog);
}
Result<ExactRational> ScalarFluxOperator::transition_probability(
    const BigNat& source, const BigNat& destination) const {
  auto mu = ::mwperf::service_probability(core_->response, source);
  if (!mu) {
    return Result<ExactRational>::failure(mu.error());
  }
  return Result<ExactRational>::success(
      ::mwperf::transition_probability(*core_, source, destination));
}

const StationaryAnalyticLawIdentityV1&
ScalarFiniteClosureProofV1::law_identity() const noexcept {
  return law_identity_;
}
std::span<const BigNat> ScalarFiniteClosureProofV1::reachable_support()
    const noexcept {
  return reachable_support_;
}

AnalyticStationaryStatusV1 ScalarStationaryLaw::status() const noexcept {
  return core_->status;
}
bool ScalarStationaryLaw::normalized_law_established() const noexcept {
  return core_->normalized;
}
Result<ExactRational> ScalarStationaryLaw::mass(const BigNat& backlog) const {
  return scalar_mass_at(*core_, backlog);
}
const std::optional<ExactRational>& ScalarStationaryLaw::exact_tail_mass()
    const noexcept {
  return core_->exact_tail_mass;
}
const std::optional<ExactRational>& ScalarStationaryLaw::exact_mean_backlog()
    const noexcept {
  return core_->exact_mean_backlog;
}
const std::optional<long double>& ScalarStationaryLaw::numerical_mean_backlog()
    const noexcept {
  return core_->numerical_mean_backlog;
}
const AnalyticStationaryDiagnosticsV1& ScalarStationaryLaw::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const std::optional<ScalarFiniteClosureProofV1>&
ScalarStationaryLaw::finite_closure_proof() const noexcept {
  return core_->finite_closure_proof;
}
const StationaryAnalyticLawIdentityV1& ScalarStationaryLaw::identity()
    const noexcept {
  return core_->identity;
}

AnalyticStationaryStatusV1 TransformReadout::status() const noexcept {
  return core_->status;
}
const EvaluationPoint& TransformReadout::point() const noexcept {
  return core_->point;
}
const std::optional<ExactRational>& TransformReadout::exact_pgf()
    const noexcept {
  return core_->exact_pgf;
}
const std::optional<long double>& TransformReadout::numerical_pgf()
    const noexcept {
  return core_->numerical_pgf;
}
const std::optional<ExactRational>&
TransformReadout::exact_response_weighted_pgf() const noexcept {
  return core_->exact_response_weighted_pgf;
}
const std::optional<long double>&
TransformReadout::numerical_response_weighted_pgf() const noexcept {
  return core_->numerical_response_weighted_pgf;
}
const std::optional<ExactRational>& TransformReadout::exact_mean_backlog()
    const noexcept {
  return core_->exact_mean_backlog;
}
const StationaryAnalyticLawIdentityV1& TransformReadout::identity()
    const noexcept {
  return core_->identity;
}

Result<PhaseArrivalKernel> PhaseArrivalKernel::from_audited(
    const AuditedPhaseResponse& response) {
  auto carrier = detail::C19CoreAccess::carrier(response);
  if (!carrier) {
    return fail<PhaseArrivalKernel>(
        "c19.phase_carrier_unavailable",
        "the audited phase response has no immutable exact C19 carrier",
        DiagnosticCategory::unavailable);
  }
  if (!carrier->identity.accepted_metric_clause() ||
      !carrier->identity.realized_metric_binding() || !carrier->seal ||
      !nonzero_digest(carrier->identity.execution_seal_digest()) ||
      !carrier->identity.carrier_snapshot_digest() ||
      !nonzero_digest(*carrier->identity.carrier_snapshot_digest()) ||
      carrier->identity.payload_phase() !=
          PayloadPhaseKindV1::predictive_phase_indexed ||
      !(carrier->configured_arrival ==
        carrier->identity.configured_arrival()) ||
      carrier->solver_policy.analysis_fingerprint !=
          bound_analysis_fingerprint(carrier->identity)) {
    return fail<PhaseArrivalKernel>(
        "c19.phase_carrier_identity_incomplete",
        "the phase carrier lacks its sealed analysis, arrival, clause, or "
        "evidence identity");
  }
  auto carrier_snapshot =
      phase_carrier_snapshot_digest(*carrier, carrier->identity);
  if (!carrier_snapshot ||
      carrier_snapshot.value() != *carrier->identity.carrier_snapshot_digest()) {
    return fail<PhaseArrivalKernel>(
        "c19.phase_carrier_snapshot_mismatch",
        "the phase carrier differs from its sealed C19 snapshot identity");
  }
  auto core = make_phase_arrival_kernel(std::move(carrier));
  if (!core) {
    return Result<PhaseArrivalKernel>::failure(core.error());
  }
  return Result<PhaseArrivalKernel>::success(
      detail::C19CoreAccess::phase_arrival_kernel(std::move(core).value()));
}

std::span<const ArrivalPhaseIdentityV1> PhaseArrivalKernel::phases()
    const noexcept {
  return core_->phases;
}

std::span<const ExactPhaseArrivalBlockV1> PhaseArrivalKernel::blocks()
    const noexcept {
  return core_->blocks;
}

std::span<const ExactRational>
PhaseArrivalKernel::configured_phase_marginal() const noexcept {
  return core_->configured_phase_marginal;
}

const PhaseLevelCompletionV1& PhaseArrivalKernel::completion() const noexcept {
  return core_->completion;
}

std::size_t BlockFluxOperator::phase_count() const noexcept {
  return core_->phase_count;
}

const BigNat& BlockFluxOperator::maximum_level() const noexcept {
  return core_->arrival->completion.maximum_level;
}

Result<ExactRational> BlockFluxOperator::transition_probability(
    const BigNat& source_level, const std::size_t source_phase,
    const BigNat& destination_level,
    const std::size_t destination_phase) const {
  auto source = native_index(source_level);
  auto destination = native_index(destination_level);
  if (!source) {
    return Result<ExactRational>::failure(source.error());
  }
  if (!destination) {
    return Result<ExactRational>::failure(destination.error());
  }
  if (source.value() >= core_->level_count ||
      destination.value() >= core_->level_count ||
      source_phase >= core_->phase_count ||
      destination_phase >= core_->phase_count) {
    return fail<ExactRational>(
        "c19.phase_transition_index",
        "the requested phase-level transition lies outside the declared "
        "finite representation");
  }
  const std::size_t state_count = core_->phase_count * core_->level_count;
  const std::size_t source_index =
      source.value() * core_->phase_count + source_phase;
  const std::size_t destination_index =
      destination.value() * core_->phase_count + destination_phase;
  return Result<ExactRational>::success(
      core_->entries[source_index * state_count + destination_index]);
}

const StationaryAnalyticLawIdentityV1& BlockFluxOperator::identity()
    const noexcept {
  return core_->identity;
}

AnalyticStationaryStatusV1 PhaseStationaryLaw::status() const noexcept {
  return core_->status;
}

Result<long double> PhaseStationaryLaw::mass(
    const BigNat& level, const std::size_t phase) const {
  auto native = native_index(level);
  if (!native) {
    return Result<long double>::failure(native.error());
  }
  if (native.value() >= core_->flux->level_count ||
      phase >= core_->flux->phase_count) {
    return fail<long double>(
        "c19.phase_stationary_index",
        "the requested phase-level mass lies outside the solved law");
  }
  return Result<long double>::success(
      core_->masses[native.value() * core_->flux->phase_count + phase]);
}

std::span<const SelectedInvariantClassV1>
PhaseStationaryLaw::selected_classes() const noexcept {
  return core_->selected_classes;
}

std::span<const PhaseMarginalAtomV1> PhaseStationaryLaw::phase_marginal()
    const noexcept {
  return core_->phase_marginal;
}

const InvariantSolveDiagnosticsV1& PhaseStationaryLaw::diagnostics()
    const noexcept {
  return core_->diagnostics;
}

const StationaryAnalyticLawIdentityV1& PhaseStationaryLaw::identity()
    const noexcept {
  return core_->identity;
}

FixedPointTerminationV1 FixedPointLaw::termination() const noexcept {
  return core_->termination;
}

std::span<const ExactRational> FixedPointLaw::parameters() const noexcept {
  return core_->parameters;
}

const ExactRational& FixedPointLaw::iterate_difference() const noexcept {
  return core_->iterate_difference;
}

const ExactRational& FixedPointLaw::fixed_point_residual() const noexcept {
  return core_->fixed_point_residual;
}

const BigNat& FixedPointLaw::iteration_count() const noexcept {
  return core_->iteration_count;
}

const BigNat& FixedPointLaw::evaluation_count() const noexcept {
  return core_->evaluation_count;
}

const Digest256& FixedPointLaw::selector_digest() const noexcept {
  return core_->selector_digest;
}

const StationaryAnalyticLawIdentityV1& FixedPointLaw::identity()
    const noexcept {
  return core_->identity;
}

Result<ScalarFluxOperator> assemble_iid_scalar_flux(
    const AuditedResponseLaw& response, const ArrivalPmf& arrival) {
  const auto& arrival_core = detail::C19CoreAccess::core(arrival).law;
  if (auto carrier = detail::C19CoreAccess::carrier(response)) {
    auto decoded = scalar_response_from_carrier(carrier, *arrival_core);
    if (!decoded) {
      return Result<ScalarFluxOperator>::failure(decoded.error());
    }
    return assemble_scalar_flux_impl(arrival_core,
                                     std::move(decoded).value());
  }
  const auto sealed = detail::C19CoreAccess::sealed(response);
  if (!sealed || arrival_core->sealed.get() != sealed.get()) {
    return fail<ScalarFluxOperator>(
        "c19.response_arrival_identity_mismatch",
        "the response and arrival PMF do not share one C17 seal");
  }
  auto decoded = sealed_scalar_response(sealed);
  if (!decoded) {
    return Result<ScalarFluxOperator>::failure(decoded.error());
  }
  return assemble_scalar_flux_impl(arrival_core, std::move(decoded).value());
}

Result<ScalarStationaryLaw> solve_scalar_cut_recursion(
    const ScalarFluxOperator& flux, const TailPolicy& tail_policy) {
  const auto core = detail::C19CoreAccess::core_ptr(flux);
  switch (tail_policy.kind()) {
    case ScalarTailCompletionKindV1::exact_finite_closure: {
      if (!tail_policy.cutoff()) {
        return fail<ScalarStationaryLaw>("c19.finite_cutoff_missing",
                                         "finite closure requires a cutoff");
      }
      auto maximum = native_index(tail_policy.cutoff()->value());
      if (!maximum) {
        return Result<ScalarStationaryLaw>::failure(maximum.error());
      }
      auto closure = prove_finite_closure(*core, maximum.value());
      if (!closure) {
        return Result<ScalarStationaryLaw>::failure(closure.error());
      }
      return finite_closure_law(core, closure.value(), maximum.value(),
                                AnalyticStationaryStatusV1::finite);
    }
    case ScalarTailCompletionKindV1::constant_response:
      if (!tail_policy.cutoff() || !tail_policy.tail_service()) {
        return fail<ScalarStationaryLaw>(
            "c19.constant_tail_policy_incomplete",
            "constant response completion requires a cutoff and service");
      }
      if (!core->response.constant_tail_from ||
          !core->response.constant_tail_service ||
          core->response.constant_tail_from->value() !=
              tail_policy.cutoff()->value().value() + 1 ||
          !(*core->response.constant_tail_service ==
            tail_policy.tail_service()->value())) {
        return fail<ScalarStationaryLaw>(
            "c19.constant_tail_policy_mismatch",
            "constant-response completion requires the response's full "
            "declared tail to match the TailPolicy cutoff and service");
      }
      return solve_constant_tail_impl(core, *tail_policy.cutoff(),
                                      *tail_policy.tail_service());
    case ScalarTailCompletionKindV1::certified_truncation:
      if (!tail_policy.tail_mass_bound() ||
          !tail_policy.tail_mass_bound()->is_nonnegative()) {
        return fail<ScalarStationaryLaw>(
            "c19.invalid_tail_bound",
            "a certified truncation requires a nonnegative exact bound");
      }
      if (!tail_policy.cutoff()) {
        return fail<ScalarStationaryLaw>(
            "c19.truncation_cutoff_missing",
            "a certified truncation requires an exact cutoff");
      }
      return incomplete_cut_law(
          core, tail_policy.cutoff()->value() + BigNat{1U},
          *tail_policy.tail_mass_bound());
    case ScalarTailCompletionKindV1::no_completion:
      if (!tail_policy.maximum_terms()) {
        return fail<ScalarStationaryLaw>(
            "c19.term_budget_missing",
            "no-completion recursion requires an exact term budget");
      }
      return incomplete_cut_law(core, *tail_policy.maximum_terms());
  }
  return fail<ScalarStationaryLaw>("c19.unknown_tail_policy",
                                   "the scalar tail policy is unknown");
}

Result<TransformReadout> evaluate_scalar_pgf_and_moments(
    const ScalarStationaryLaw& law, const ArrivalTransform& arrival_transform,
    const EvaluationPoint& point) {
  const auto& law_core = detail::C19CoreAccess::core(law);
  const auto& transform_core = detail::C19CoreAccess::core(arrival_transform);
  if (!law_core.flux ||
      law_core.flux->arrival->arrival_identity.get() !=
          transform_core.law->arrival_identity.get()) {
    return fail<TransformReadout>(
        "c19.transform_arrival_identity_mismatch",
        "the stationary law and arrival transform have different identities");
  }
  std::optional<ExactRational> pgf;
  std::optional<ExactRational> response_pgf;
  if (law_core.normalized) {
    const ExactRational& z = point.value();
    if (z == ExactRational::one()) {
      pgf = ExactRational::one();
      response_pgf = law_core.flux->arrival->mean;
    } else if (law_core.representation ==
               stationary::detail::ScalarLawRepresentation::finite) {
      ExactRational total = ExactRational::zero();
      ExactRational response_total = ExactRational::zero();
      for (std::size_t level = 0U; level < law_core.prefix_masses.size();
           ++level) {
        const ExactRational power = exact_power(z, BigInt{level});
        total = total + law_core.prefix_masses[level] * power;
        if (law_core.prefix_masses[level].is_zero()) {
          continue;
        }
        auto mu = service_probability(
            law_core.flux->response,
            BigNat{static_cast<std::uint64_t>(level)});
        if (!mu) {
          return Result<TransformReadout>::failure(mu.error());
        }
        response_total = response_total +
                         law_core.prefix_masses[level] * mu.value() * power;
      }
      pgf = total;
      response_pgf = response_total;
    } else if (law_core.representation ==
                   stationary::detail::ScalarLawRepresentation::constant_tail &&
               law_core.tail_service) {
      if (z.is_zero()) {
        pgf = law_core.prefix_masses.front();
        response_pgf = ExactRational::zero();
      } else {
        const ExactRational c = *law_core.tail_service;
        const ExactRational g = arrival_pgf(*law_core.flux->arrival, z);
        ExactRational correction = ExactRational::zero();
        for (std::size_t level = 0U; level < law_core.prefix_masses.size();
             ++level) {
          auto mu = service_probability(
              law_core.flux->response,
              BigNat{static_cast<std::uint64_t>(level)});
          if (!mu) {
            return Result<TransformReadout>::failure(mu.error());
          }
          correction = correction + law_core.prefix_masses[level] *
                                          (c - mu.value()) *
                                          exact_power(z, BigInt{level});
        }
        const ExactRational numerator =
            g * (ExactRational::one() - z) * correction;
        const ExactRational denominator =
            g * (c + (ExactRational::one() - c) * z) - z;
        auto quotient = checked_divide(numerator, denominator);
        if (!quotient) {
          return fail<TransformReadout>(
              "c19.pgf_removable_limit_unavailable",
              "the exact PGF quotient is singular at this evaluation point",
              DiagnosticCategory::unavailable);
        }
        pgf = std::move(quotient).value();
        response_pgf = c * *pgf - correction;
      }
    }
  }
  auto core = std::make_shared<stationary::detail::TransformReadoutCore>(
      stationary::detail::TransformReadoutCore{
          law_core.status,
          point,
          pgf,
          pgf ? std::optional<long double>(pgf->to_long_double())
              : std::nullopt,
          response_pgf,
          response_pgf
              ? std::optional<long double>(response_pgf->to_long_double())
              : std::nullopt,
          law_core.exact_mean_backlog,
          law_core.identity});
  return Result<TransformReadout>::success(
      detail::C19CoreAccess::transform_readout(std::move(core)));
}

Result<ScalarStationaryLaw> solve_bernoulli_birth_death(
    const AuditedResponseLaw& response, const BernoulliRate& arrival) {
  const auto& arrival_core = detail::C19CoreAccess::core(arrival).law;
  if (auto carrier = detail::C19CoreAccess::carrier(response)) {
    auto decoded = scalar_response_from_carrier(carrier, *arrival_core);
    if (!decoded) {
      return Result<ScalarStationaryLaw>::failure(decoded.error());
    }
    auto flux = assemble_scalar_flux_impl(arrival_core,
                                          std::move(decoded).value());
    if (!flux) {
      return Result<ScalarStationaryLaw>::failure(flux.error());
    }
    return solve_bernoulli_impl(
        detail::C19CoreAccess::core_ptr(flux.value()));
  }
  const auto sealed = detail::C19CoreAccess::sealed(response);
  if (!sealed || arrival_core->sealed.get() != sealed.get()) {
    return fail<ScalarStationaryLaw>(
        "c19.response_arrival_identity_mismatch",
        "the response and Bernoulli rate do not share one C17 seal");
  }
  auto decoded = sealed_scalar_response(sealed);
  if (!decoded) {
    return Result<ScalarStationaryLaw>::failure(decoded.error());
  }
  auto flux = assemble_scalar_flux_impl(arrival_core, decoded.value());
  if (!flux) {
    return Result<ScalarStationaryLaw>::failure(flux.error());
  }
  return solve_bernoulli_impl(detail::C19CoreAccess::core_ptr(flux.value()));
}

Result<ScalarStationaryLaw> solve_constant_tail_response(
    const AuditedResponseLaw& response, const ArrivalLaw& arrival,
    const Cutoff& cutoff, const TailService& tail_service) {
  const auto arrival_core = detail::C19CoreAccess::core_ptr(arrival);
  if (auto carrier = detail::C19CoreAccess::carrier(response)) {
    auto decoded = scalar_response_from_carrier(carrier, *arrival_core);
    if (!decoded) {
      return Result<ScalarStationaryLaw>::failure(decoded.error());
    }
    if (!decoded.value().constant_tail_from ||
        decoded.value().constant_tail_from->value() !=
            cutoff.value().value() + 1 ||
        !decoded.value().constant_tail_service ||
        !(*decoded.value().constant_tail_service == tail_service.value())) {
      return fail<ScalarStationaryLaw>(
          "c19.constant_tail_family_mismatch",
          "the supplied cutoff/tail do not match the carrier response "
          "family");
    }
    auto flux = assemble_scalar_flux_impl(arrival_core,
                                          std::move(decoded).value());
    if (!flux) {
      return Result<ScalarStationaryLaw>::failure(flux.error());
    }
    return solve_constant_tail_impl(
        detail::C19CoreAccess::core_ptr(flux.value()), cutoff, tail_service);
  }
  const auto sealed = detail::C19CoreAccess::sealed(response);
  if (!sealed || arrival_core->sealed.get() != sealed.get()) {
    return fail<ScalarStationaryLaw>(
        "c19.response_arrival_identity_mismatch",
        "the response and arrival law do not share one C17 seal");
  }
  auto decoded = sealed_scalar_response(sealed);
  if (!decoded) {
    return Result<ScalarStationaryLaw>::failure(decoded.error());
  }
  if (!decoded.value().constant_tail_from ||
      decoded.value().constant_tail_from->value() !=
          cutoff.value().value() + 1 ||
      !decoded.value().constant_tail_service ||
      !(*decoded.value().constant_tail_service == tail_service.value())) {
    return fail<ScalarStationaryLaw>(
        "c19.constant_tail_family_mismatch",
        "the supplied cutoff/tail do not match the sealed response family");
  }
  auto flux = assemble_scalar_flux_impl(arrival_core, std::move(decoded).value());
  if (!flux) {
    return Result<ScalarStationaryLaw>::failure(flux.error());
  }
  return solve_constant_tail_impl(detail::C19CoreAccess::core_ptr(flux.value()),
                                  cutoff, tail_service);
}

namespace {

[[nodiscard]] Result<ThreeBinIidSummary>
summarize_three_bin_iid_response_impl(
    const AuditedThreeBinResponse& response, const ArrivalLaw& arrival,
    const bool require_solver_proved_stationary_unique) {
  const auto arrival_core = detail::C19CoreAccess::core_ptr(arrival);
  if (require_solver_proved_stationary_unique &&
      !std::holds_alternative<PortableStationaryUniqueSelectionV1>(
          arrival_core->identity.selection())) {
    return fail<ThreeBinIidSummary>(
        "c19.stationary_unique_selection_required",
        "the solver-owned IID summary requires stationary_unique",
        DiagnosticCategory::unavailable);
  }
  const auto carrier = detail::C19CoreAccess::carrier(response);
  const auto sealed = detail::C19CoreAccess::sealed(response);
  Result<LittleLawPremises> premises = carrier
      ? Result<LittleLawPremises>::success(
            carrier_little_law_premises(carrier->little_law_premises))
      : validate_three_bin_summary_boundary(sealed, *arrival_core);
  if (!premises) {
    return Result<ThreeBinIidSummary>::failure(premises.error());
  }
  Result<stationary::detail::ScalarResponseData> decoded =
      carrier ? scalar_response_from_carrier(carrier, *arrival_core)
              : sealed_scalar_response(sealed);
  if (!decoded || !decoded.value().constant_tail_service) {
    return !decoded
               ? Result<ThreeBinIidSummary>::failure(decoded.error())
               : fail<ThreeBinIidSummary>(
                     "c19.three_bin_tail_unavailable",
                     "the sealed three-bin response has no exact tail "
                     "service");
  }
  auto tail = TailService::make(*decoded.value().constant_tail_service);
  if (!tail) {
    return Result<ThreeBinIidSummary>::failure(tail.error());
  }
  const Cutoff cutoff{BigNat{2U}};
  const AuditedResponseLaw restriction =
      detail::C19CoreAccess::scalar_restriction(response);
  auto law = solve_constant_tail_response(restriction, arrival, cutoff,
                                          tail.value());
  if (!law) {
    return Result<ThreeBinIidSummary>::failure(law.error());
  }
  if (!(law.value().identity() == arrival_core->identity) ||
      law.value().identity().cutoff() != std::optional<BigNat>{BigNat{2U}} ||
      law.value().identity().tail_service() !=
          decoded.value().constant_tail_service) {
    return fail<ThreeBinIidSummary>(
        "c19.three_bin_solver_identity_drift",
        "the same-seal constant-tail bridge changed the response-law "
        "identity",
        DiagnosticCategory::internal);
  }
  if (require_solver_proved_stationary_unique) {
    const auto status = law.value().status();
    const bool strict_tail_unique =
        status == AnalyticStationaryStatusV1::strict_tail_stable ||
        status == AnalyticStationaryStatusV1::required_moment_unavailable;
    if (!law.value().normalized_law_established() || !strict_tail_unique) {
      return fail<ThreeBinIidSummary>(
          "c19.stationary_unique_not_established",
          "the exact IID scalar solve did not establish a normalized unique "
          "stationary law",
          DiagnosticCategory::unavailable);
    }
    if (!law.value().diagnostics().normalization_residual.is_zero() ||
        !law.value().diagnostics().invariance_residual.is_zero()) {
      return fail<ThreeBinIidSummary>(
          "c19.stationary_unique_residual_invariant",
          "a solver-proved exact stationary law must have zero exact "
          "normalization and invariance residuals",
          DiagnosticCategory::internal);
    }
  }
  return summarize_three_bin_law(arrival_core, decoded.value(), law.value(),
                                 premises.value());
}

}  // namespace

Result<ThreeBinIidSummary> summarize_three_bin_iid_response(
    const AuditedThreeBinResponse& response, const ArrivalLaw& arrival) {
  return summarize_three_bin_iid_response_impl(response, arrival, false);
}

Result<ThreeBinIidSummary> summarize_three_bin_iid_stationary_unique(
    const AuditedThreeBinResponse& response) {
  const auto sealed = detail::C19CoreAccess::sealed(response);
  Result<ArrivalLaw> arrival = sealed
      ? arrival_from_sealed(sealed, std::nullopt, true)
      : arrival_from_carrier(detail::C19CoreAccess::carrier(response));
  if (!arrival) {
    return Result<ThreeBinIidSummary>::failure(arrival.error());
  }
  return summarize_three_bin_iid_response_impl(response, arrival.value(),
                                               true);
}

namespace {

[[nodiscard]] Result<FinitePrefixIidSummary>
summarize_finite_prefix_iid_response_impl(
    const AuditedResponseLaw& response, const ArrivalLaw& arrival,
    const bool require_stationary_unique) {
  const auto arrival_core = detail::C19CoreAccess::core_ptr(arrival);
  if (require_stationary_unique &&
      !std::holds_alternative<PortableStationaryUniqueSelectionV1>(
          arrival_core->identity.selection())) {
    return fail<FinitePrefixIidSummary>(
        "c19.stationary_unique_selection_required",
        "the solver-owned K-wide IID summary requires stationary_unique",
        DiagnosticCategory::unavailable);
  }
  const auto sealed = detail::C19CoreAccess::sealed(response);
  auto premises = validate_finite_prefix_summary_boundary(sealed, *arrival_core);
  if (!premises) {
    return Result<FinitePrefixIidSummary>::failure(premises.error());
  }
  auto decoded = sealed_scalar_response(sealed);
  if (!decoded || !decoded.value().constant_tail_service ||
      !decoded.value().constant_tail_from) {
    return !decoded
               ? Result<FinitePrefixIidSummary>::failure(decoded.error())
               : fail<FinitePrefixIidSummary>(
                     "c19.finite_prefix_tail_unavailable",
                     "the sealed K-wide response has no exact tail "
                     "coefficient");
  }
  const auto* payload =
      std::get_if<PortableFinitePrefixConstantTailResponseV1>(
          &portable_source_v1(sealed->plug()).value());
  if (payload == nullptr) {
    return fail<FinitePrefixIidSummary>(
        "c19.finite_prefix_payload_unavailable",
        "the sealed scalar response is not the K-wide sibling payload",
        DiagnosticCategory::unavailable);
  }
  auto tail = TailService::make(*decoded.value().constant_tail_service);
  if (!tail) {
    return Result<FinitePrefixIidSummary>::failure(tail.error());
  }

  // This is the sole dynamic solve.  The public bridge assembles its own
  // scalar flux from the same sealed response and exact projected IID law.
  auto law = solve_constant_tail_response(
      response, arrival, Cutoff{payload->response_cutoff}, tail.value());
  if (!law) {
    return Result<FinitePrefixIidSummary>::failure(law.error());
  }
  if (!(law.value().identity() == arrival_core->identity) ||
      law.value().identity().cutoff() !=
          std::optional<BigNat>{payload->response_cutoff} ||
      law.value().identity().tail_service() !=
          decoded.value().constant_tail_service ||
      law.value().identity().response_product() !=
          std::optional<ArtifactObjectReferenceV1>{
              payload->selected_product.identity()}) {
    return fail<FinitePrefixIidSummary>(
        "c19.finite_prefix_solver_identity_drift",
        "the same-seal constant-tail solve changed the K-wide response-law "
        "identity",
        DiagnosticCategory::internal);
  }
  if (law.value().normalized_law_established() &&
      (!law.value().diagnostics().normalization_residual.is_zero() ||
       !law.value().diagnostics().invariance_residual.is_zero())) {
    return fail<FinitePrefixIidSummary>(
        "c19.finite_prefix_residual_invariant",
        "an exact normalized K-wide stationary law must have zero exact "
        "normalization and invariance residuals",
        DiagnosticCategory::internal);
  }
  return summarize_finite_prefix_law(
      sealed, arrival_core, decoded.value(), law.value(), premises.value());
}

}  // namespace

Result<FinitePrefixIidSummary> summarize_finite_prefix_iid_response(
    const AuditedResponseLaw& response, const ArrivalLaw& arrival) {
  return summarize_finite_prefix_iid_response_impl(response, arrival, false);
}

Result<FinitePrefixIidSummary>
summarize_finite_prefix_iid_stationary_unique(
    const AuditedResponseLaw& response) {
  const auto sealed = detail::C19CoreAccess::sealed(response);
  auto arrival = arrival_from_sealed(sealed, std::nullopt, true);
  if (!arrival) {
    return Result<FinitePrefixIidSummary>::failure(arrival.error());
  }
  return summarize_finite_prefix_iid_response_impl(response, arrival.value(),
                                                   true);
}

Result<BlockFluxOperator> assemble_markov_additive_blocks(
    const PhaseArrivalKernel& arrival,
    const AuditedPhaseResponse& response) {
  const auto& arrival_core = detail::C19CoreAccess::core(arrival);
  const auto carrier = detail::C19CoreAccess::carrier(response);
  if (!carrier || !arrival_core.carrier ||
      arrival_core.carrier.get() != carrier.get() ||
      arrival_core.seal.get() != carrier->seal.get() ||
      !(arrival_core.identity == carrier->identity) ||
      !(arrival_core.completion.maximum_level ==
        carrier->completion.maximum_level) ||
      !same_completion(arrival_core.completion, carrier->completion)) {
    return fail<BlockFluxOperator>(
        "c19.phase_response_arrival_identity_mismatch",
        "the phase kernel and response do not share one immutable carrier, "
        "analysis, arrival, completion, and seal identity");
  }
  return assemble_phase_flux_impl(detail::C19CoreAccess::core_ptr(arrival),
                                  carrier->service_row_major);
}

Result<PhaseStationaryLaw> solve_markov_additive_stationary(
    const BlockFluxOperator& flux, const SelectionSpec& selection,
    const SolverPolicy& policy) {
  return solve_phase_stationary_impl(detail::C19CoreAccess::core_ptr(flux),
                                     selection, policy);
}

Result<FixedPointLaw> solve_declared_fixed_point(
    const AuditedFixedPointFamily& family, const SelectionSpec& selection,
    const SolverPolicy& policy) {
  return solve_fixed_point_carrier(detail::C19CoreAccess::carrier(family),
                                   selection, policy);
}

#if defined(MWPERF_C19_TEST_SEAMS)
namespace testing {

Result<ArrivalLaw> C19FixtureAccess::arrival_law(
    std::vector<ScalarArrivalMassV1> atoms) {
  auto token = std::make_shared<int>(0);
  auto core = make_arrival_core(
      std::move(atoms), fixture_arrival_binding(), fixture_queue(),
      empty_digest(), token, nullptr, fixture_identity());
  if (!core) {
    return Result<ArrivalLaw>::failure(core.error());
  }
  return Result<ArrivalLaw>::success(
      detail::C19CoreAccess::arrival_law(std::move(core).value()));
}

Result<ArrivalLaw> C19FixtureAccess::arrival_law_without_second_moment(
    std::vector<ScalarArrivalMassV1> atoms) {
  auto token = std::make_shared<int>(0);
  auto core = make_arrival_core(
      std::move(atoms), fixture_arrival_binding(), fixture_queue(),
      empty_digest(), token, nullptr, fixture_identity(), false);
  if (!core) {
    return Result<ArrivalLaw>::failure(core.error());
  }
  return Result<ArrivalLaw>::success(
      detail::C19CoreAccess::arrival_law(std::move(core).value()));
}

Result<ArrivalLaw> C19FixtureAccess::arrival_law(
    const AuditedResponseLaw& response,
    std::vector<ScalarArrivalMassV1> atoms) {
  return arrival_from_sealed(detail::C19CoreAccess::sealed(response),
                             std::move(atoms));
}

Result<ArrivalLaw> C19FixtureAccess::arrival_law(
    const AuditedThreeBinResponse& response,
    std::vector<ScalarArrivalMassV1> atoms) {
  return arrival_from_sealed(detail::C19CoreAccess::sealed(response),
                             std::move(atoms));
}

Result<ScalarFluxOperator> C19FixtureAccess::scalar_flux(
    const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response) {
  return assemble_scalar_flux_impl(
      detail::C19CoreAccess::core_ptr(arrival),
      stationary::detail::ScalarResponseData{
          std::move(response.service_by_level),
          std::move(response.constant_tail_from),
          std::move(response.constant_tail_service)});
}

Result<ScalarStationaryLaw> C19FixtureAccess::solve_bernoulli(
    const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response) {
  auto bernoulli = BernoulliRate::from(arrival);
  if (!bernoulli) {
    return Result<ScalarStationaryLaw>::failure(bernoulli.error());
  }
  auto flux = scalar_flux(arrival, std::move(response));
  if (!flux) {
    return Result<ScalarStationaryLaw>::failure(flux.error());
  }
  return solve_bernoulli_impl(detail::C19CoreAccess::core_ptr(flux.value()));
}

Result<ScalarStationaryLaw> C19FixtureAccess::solve_constant_tail(
    const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response,
    const Cutoff& cutoff, const TailService& tail_service) {
  if (!response.constant_tail_from || !response.constant_tail_service ||
      response.constant_tail_from->value() != cutoff.value().value() + 1 ||
      !(*response.constant_tail_service == tail_service.value())) {
    return fail<ScalarStationaryLaw>(
        "c19.constant_tail_fixture_mismatch",
        "the fixture response, cutoff, and tail service disagree");
  }
  auto flux = scalar_flux(arrival, std::move(response));
  if (!flux) {
    return Result<ScalarStationaryLaw>::failure(flux.error());
  }
  return solve_constant_tail_impl(detail::C19CoreAccess::core_ptr(flux.value()),
                                  cutoff, tail_service);
}

Result<PhaseArrivalKernel> C19FixtureAccess::phase_arrival_kernel(
    ExactPhaseResponseFixtureV1 fixture) {
  auto core = make_phase_arrival_kernel(
      fixture,
      fixture_identity(PayloadPhaseKindV1::predictive_phase_indexed), nullptr);
  if (!core) {
    return Result<PhaseArrivalKernel>::failure(core.error());
  }
  return Result<PhaseArrivalKernel>::success(
      detail::C19CoreAccess::phase_arrival_kernel(std::move(core).value()));
}

Result<PhaseArrivalKernel> C19FixtureAccess::phase_arrival_kernel(
    const AuditedPhaseResponse& response,
    ExactPhaseResponseFixtureV1 fixture) {
  const auto sealed = detail::C19CoreAccess::sealed(response);
  auto identity = production_identity(sealed);
  if (!identity) {
    return Result<PhaseArrivalKernel>::failure(identity.error());
  }
  auto core = make_phase_arrival_kernel(
      fixture, std::move(identity).value(), sealed);
  if (!core) {
    return Result<PhaseArrivalKernel>::failure(core.error());
  }
  return Result<PhaseArrivalKernel>::success(
      detail::C19CoreAccess::phase_arrival_kernel(std::move(core).value()));
}

Result<BlockFluxOperator> C19FixtureAccess::phase_flux(
    ExactPhaseResponseFixtureV1 fixture) {
  auto arrival = phase_arrival_kernel(fixture);
  if (!arrival) {
    return Result<BlockFluxOperator>::failure(arrival.error());
  }
  return assemble_phase_flux_impl(
      detail::C19CoreAccess::core_ptr(arrival.value()),
      fixture.service_row_major);
}

Result<BlockFluxOperator> C19FixtureAccess::phase_flux(
    const PhaseArrivalKernel& arrival,
    ExactPhaseResponseFixtureV1 fixture) {
  const auto arrival_core = detail::C19CoreAccess::core_ptr(arrival);
  auto candidate = make_phase_arrival_kernel(
      fixture, arrival_core->identity, arrival_core->sealed);
  if (!candidate) {
    return Result<BlockFluxOperator>::failure(candidate.error());
  }
  if (!same_phase_kernel(*arrival_core, *candidate.value())) {
    return fail<BlockFluxOperator>(
        "c19.phase_fixture_kernel_mismatch",
        "the exact phase response fixture does not match the arrival kernel");
  }
  return assemble_phase_flux_impl(std::move(arrival_core),
                                  fixture.service_row_major);
}

Result<FixedPointLaw> C19FixtureAccess::fixed_point_law(
    ExactFixedPointFixtureV1 fixture, const SelectionSpec& selection,
    const SolverPolicy& policy) {
  return solve_fixed_point_fixture(std::move(fixture), selection, policy);
}

Result<ThreeBinIidSummary> C19ThreeBinFixtureAccess::summarize(
    const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response,
    const ExactLittleLawPremisesFixtureV1 little_law) {
  stationary::detail::ScalarResponseData decoded{
      std::move(response.service_by_level),
      std::move(response.constant_tail_from),
      std::move(response.constant_tail_service)};
  if (decoded.prefix.size() != 3U || !decoded.constant_tail_from ||
      !(*decoded.constant_tail_from == BigNat{3U}) ||
      !decoded.constant_tail_service) {
    return fail<ThreeBinIidSummary>(
        "c19.three_bin_fixture_shape",
        "the exact F-C19-09 seam requires cutoff two and tail from three");
  }
  auto flux = assemble_scalar_flux_impl(detail::C19CoreAccess::core_ptr(arrival),
                                        decoded);
  if (!flux) {
    return Result<ThreeBinIidSummary>::failure(flux.error());
  }
  auto tail = TailService::make(*decoded.constant_tail_service);
  if (!tail) {
    return Result<ThreeBinIidSummary>::failure(tail.error());
  }
  auto law = solve_constant_tail_impl(
      detail::C19CoreAccess::core_ptr(flux.value()), Cutoff{BigNat{2U}},
      tail.value());
  if (!law) {
    return Result<ThreeBinIidSummary>::failure(law.error());
  }
  return summarize_three_bin_law(
      detail::C19CoreAccess::core_ptr(arrival), decoded, law.value(),
      LittleLawPremises{little_law.lossless, little_law.unit_packets,
                        little_law.eventual_departure,
                        little_law.positive_finite_intensity,
                        little_law.finite_first_backlog_moment,
                        little_law.little_law});
}

}  // namespace testing
#endif

}  // namespace mwperf
