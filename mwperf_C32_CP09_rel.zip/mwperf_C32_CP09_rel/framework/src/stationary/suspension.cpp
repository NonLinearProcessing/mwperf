#include "mwperf/stationary/suspension.hpp"

#include <Eigen/Dense>

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <locale>
#include <memory>
#include <numeric>
#include <optional>
#include <set>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "stationary/c21_bounded_projection_internal.hpp"
#include "stationary/c21_projection_source_internal.hpp"
#include "temporal/c20_stationary_bridge_internal.hpp"

namespace mwperf {

static_assert(std::is_signed_v<Eigen::Index> &&
                  std::numeric_limits<Eigen::Index>::digits >=
                      std::numeric_limits<std::ptrdiff_t>::digits,
              "the C27 pre-provider ptrdiff_t bound must fit Eigen::Index");

namespace stationary::detail {

struct EventInvariantLawCore final {
  EmbeddedKernel kernel;
  temporal::detail::C20StationaryKernelBindingV1 binding;
  std::vector<EventInvariantMassV1> masses;
  std::vector<SelectedInvariantClassV1> selected_classes;
  EventInvariantDiagnosticsV1 diagnostics;
  SolverPolicy policy;
  Digest256 selection_digest;
  Digest256 fingerprint;
};

struct PositiveFiniteMeanCore final {
  EventInvariantLaw event_law;
  AuditedResidenceProvider provider;
  temporal::detail::C20StationarySourceBindingV1 provider_binding;
  PositiveFiniteMeanDiagnosticsV1 diagnostics;
  Digest256 fingerprint;
};

struct StationaryTemporalProjectionCore final {
  StationaryTemporalLaw temporal_law;
  StationaryMarkedEdge marked_edge;
  StationaryProjectionSlotV1<AuditedCylinderLaw> cylinder_law;
  StationaryProjectionSlotV1<AuditedTemporalLaw> audited_temporal_law;
  StationaryProjectionSlotV1<AuditedTemporalKernel> temporal_kernel;
  StationaryProjectionSlotV1<InitialLaw> initial_law;
  StationaryProjectionSlotV1<PredictiveServiceSplit>
      predictive_service_split;
  StationaryProjectionSlotV1<TemporalServiceKernel> temporal_service_kernel;
  Digest256 fingerprint;
  StationaryProjectionDiagnosticsV1 diagnostics;
};

}  // namespace stationary::detail

namespace detail {

class C21CoreAccess final {
 public:
  C21CoreAccess() = delete;

  [[nodiscard]] static EventInvariantLaw event_law(
      std::shared_ptr<const stationary::detail::EventInvariantLawCore> core) {
    return EventInvariantLaw(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::EventInvariantLawCore& core(
      const EventInvariantLaw& law) {
    return *law.core_;
  }
  [[nodiscard]] static const void* carrier_identity(
      const EventInvariantLaw& law) noexcept {
    return law.core_.get();
  }

  [[nodiscard]] static PositiveFiniteMean positive_mean(
      std::shared_ptr<const stationary::detail::PositiveFiniteMeanCore> core) {
    return PositiveFiniteMean(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::PositiveFiniteMeanCore& core(
      const PositiveFiniteMean& mean) {
    return *mean.core_;
  }

  [[nodiscard]] static StationaryTemporalLaw temporal_law(
      std::shared_ptr<const stationary::detail::StationaryTemporalLawCore>
          core) {
    return StationaryTemporalLaw(std::move(core));
  }
  [[nodiscard]] static const stationary::detail::StationaryTemporalLawCore&
  core(const StationaryTemporalLaw& law) {
    return *law.core_;
  }

  [[nodiscard]] static StationaryMarkedEdge marked_edge(
      std::shared_ptr<const stationary::detail::StationaryMarkedEdgeCore>
          core) {
    return StationaryMarkedEdge(std::move(core));
  }

  [[nodiscard]] static InitialLaw initial_law(
      std::shared_ptr<const metrics::detail::InitialLawCore> core) {
    return InitialLaw(std::move(core));
  }
  [[nodiscard]] static PredictiveServiceSplit predictive_service_split(
      std::shared_ptr<const
                      stationary::detail::PredictiveServiceSplitCore> core) {
    return PredictiveServiceSplit(std::move(core));
  }
  [[nodiscard]] static TemporalServiceKernel temporal_service_kernel(
      std::shared_ptr<const stationary::detail::TemporalServiceKernelCore>
          core) {
    return TemporalServiceKernel(std::move(core));
  }

  [[nodiscard]] static StationaryTemporalProjection projection(
      std::shared_ptr<const
                      stationary::detail::StationaryTemporalProjectionCore>
          core) {
    return StationaryTemporalProjection(std::move(core));
  }
};

}  // namespace detail

namespace {

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    DiagnosticCategory category = DiagnosticCategory::input_validation,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

class CompensatedSum final {
 public:
  void add(const long double value) noexcept {
    const long double next = sum_ + value;
    if (std::fabs(sum_) >= std::fabs(value)) {
      correction_ += (sum_ - next) + value;
    } else {
      correction_ += (value - next) + sum_;
    }
    sum_ = next;
  }
  [[nodiscard]] long double value() const noexcept {
    return sum_ + correction_;
  }
  [[nodiscard]] long double correction() const noexcept {
    return correction_;
  }

 private:
  long double sum_{0.0L};
  long double correction_{0.0L};
};

[[nodiscard]] bool byte_span_less(const std::span<const std::byte> left,
                                  const std::span<const std::byte> right) {
  return std::lexicographical_compare(
      left.begin(), left.end(), right.begin(), right.end(),
      [](const std::byte a, const std::byte b) {
        return std::to_integer<unsigned int>(a) <
               std::to_integer<unsigned int>(b);
      });
}

[[nodiscard]] bool state_less(const ReducedStateV1& left,
                              const ReducedStateV1& right) {
  if (left.codec.id != right.codec.id) {
    return left.codec.id < right.codec.id;
  }
  if (left.codec.version != right.codec.version) {
    return left.codec.version < right.codec.version;
  }
  return byte_span_less(left.canonical_value, right.canonical_value);
}

[[nodiscard]] bool phase_less(const ArrivalPhaseIdentityV1& left,
                              const ArrivalPhaseIdentityV1& right) {
  if (left.family != right.family) {
    return static_cast<std::underlying_type_t<ArrivalFamily>>(left.family) <
           static_cast<std::underlying_type_t<ArrivalFamily>>(right.family);
  }
  return byte_span_less(left.canonical_state, right.canonical_state);
}

[[nodiscard]] ArrivalPhaseIdentityV1 phase_identity(
    const ArrivalPhase& phase) {
  const auto bytes = arrival_phase_canonical_state(phase);
  return ArrivalPhaseIdentityV1{
      arrival_phase_family(phase),
      std::vector<std::byte>(bytes.begin(), bytes.end())};
}

[[nodiscard]] std::pair<long double, NumericalProbabilityImageStatusV1>
numerical_image(const ExactRational& value) {
  const long double image = value.to_long_double();
  if (!std::isfinite(image)) {
    return {image, NumericalProbabilityImageStatusV1::overflow};
  }
  if (value.is_positive() && image == 0.0L) {
    return {image, NumericalProbabilityImageStatusV1::positive_underflow};
  }
  return {image, NumericalProbabilityImageStatusV1::finite};
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

class IdentityEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void u32(const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void framed(const std::span<const std::byte> value) {
    u64(static_cast<std::uint64_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void text(const std::string_view value) {
    framed(std::as_bytes(std::span(value.data(), value.size())));
  }
  void digest(const Digest256& value) { framed(value.bytes()); }
  void rational(const ExactRational& value) {
    text(value.numerator_decimal());
    text(value.denominator_decimal());
  }
  void state(const ReducedStateV1& value) {
    text(value.codec.id);
    u32(value.codec.version);
    framed(value.canonical_value);
  }
  void label(const TypedLabel& value) {
    const auto bytes = value.canonical_bytes();
    framed(std::as_bytes(std::span(bytes.data(), bytes.size())));
  }
  [[nodiscard]] Result<Digest256> finish(
      const std::string_view domain) const {
    return sha256_domain_separated(domain, bytes_);
  }
  [[nodiscard]] const std::vector<std::byte>& bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] Result<ExactRational> rational_from_nat(const BigNat& value) {
  return ExactRational::make(value.value(), BigInt{1});
}

[[nodiscard]] Result<ExactRational> exact_long_double(
    const long double input) {
  static_assert(std::numeric_limits<long double>::radix == 2);
  if (!std::isfinite(input)) {
    return fail<ExactRational>(
        "c21.nonfinite_metric_scalar",
        "a finite stationary metric value cannot encode NaN or infinity");
  }
  if (input == 0.0L) {
    return Result<ExactRational>::success(ExactRational::zero());
  }
  const bool negative = std::signbit(input);
  int exponent = 0;
  long double fraction = std::frexp(std::fabs(input), &exponent);
  BigInt significand = 0;
  int bits_used = 0;
  for (; bits_used < std::numeric_limits<long double>::digits &&
         fraction != 0.0L;
       ++bits_used) {
    fraction *= 2.0L;
    significand <<= 1U;
    if (fraction >= 1.0L) {
      ++significand;
      fraction -= 1.0L;
    }
  }
  if (negative) {
    significand = -significand;
  }
  const int binary_exponent =
      exponent - bits_used;
  BigInt numerator = std::move(significand);
  BigInt denominator = 1;
  if (binary_exponent >= 0) {
    numerator <<= static_cast<unsigned int>(binary_exponent);
  } else {
    denominator <<= static_cast<unsigned int>(-binary_exponent);
  }
  return ExactRational::make(std::move(numerator), std::move(denominator));
}

// Return an exact dyadic enclosure from above without requiring a
// denominator wider than sixty bits.  Very small positive residuals therefore
// remain positive under bounded audit integer implementations, while large
// values use an integer numerator with promoted range.  Multiplication by a
// power of two is exact in the source floating format and ceil supplies the
// directed upper rounding.
[[nodiscard]] Result<ExactRational> nonnegative_long_double_upper_bound(
    const long double input) {
  if (!std::isfinite(input) || input < 0.0L) {
    return fail<ExactRational>(
        "c21.invalid_nonnegative_numerical_bound",
        "a numerical residual bound must be finite and nonnegative");
  }
  if (input == 0.0L) {
    return Result<ExactRational>::success(ExactRational::zero());
  }

  int exponent = 0;
  const long double fraction = std::frexp(input, &exponent);
  constexpr int kMagnitudeBits = 60;
  BigInt numerator;
  BigInt denominator = 1;
  if (exponent <= kMagnitudeBits) {
    const int denominator_bits =
        std::clamp(kMagnitudeBits - exponent, 0, kMagnitudeBits);
    const long double scaled = std::ldexp(input, denominator_bits);
    const long double rounded = std::ceil(scaled);
    if (!std::isfinite(rounded) || rounded < 1.0L ||
        rounded > std::ldexp(1.0L, kMagnitudeBits)) {
      return fail<ExactRational>(
          "c21.numerical_bound_range_failure",
          "a finite numerical residual could not be enclosed in the "
          "bounded dyadic range");
    }
    numerator = static_cast<std::uint64_t>(rounded);
    denominator <<= static_cast<unsigned int>(denominator_bits);
  } else {
    const long double scaled = std::ldexp(fraction, kMagnitudeBits);
    const long double rounded = std::ceil(scaled);
    if (!std::isfinite(rounded) || rounded < 1.0L ||
        rounded > std::ldexp(1.0L, kMagnitudeBits)) {
      return fail<ExactRational>(
          "c21.numerical_bound_range_failure",
          "a finite numerical residual could not be enclosed in promoted "
          "dyadic range");
    }
    numerator = static_cast<std::uint64_t>(rounded);
    numerator <<= static_cast<unsigned int>(exponent - kMagnitudeBits);
  }
  return ExactRational::make(std::move(numerator),
                             std::move(denominator));
}

[[nodiscard]] long double residual_bound(const SolverPolicy& policy,
                                         const long double scale) {
  return policy.absolute_residual_tolerance.to_long_double() +
         policy.relative_residual_tolerance.to_long_double() * scale;
}

[[nodiscard]] Result<void> validate_policy(
    const SolverPolicy& policy,
    const temporal::detail::C20StationarySourceBindingV1& source) {
  if (policy.linear_method != LinearMethod::dense_pivoted) {
    return fail<void>(
        "c21.solver_method_unavailable",
        "C21 v1 implements only the dense_pivoted finite invariant solve",
        DiagnosticCategory::unavailable);
  }
  if (!policy.absolute_residual_tolerance.is_nonnegative() ||
      !policy.relative_residual_tolerance.is_zero() ||
      !nonzero_digest(policy.analysis_fingerprint)) {
    return fail<void>(
        "c21.invalid_solver_policy",
        "the C21 finite invariant policy requires a nonnegative absolute "
        "tolerance, zero relative tolerance, and a bound analysis identity");
  }
  const long double tolerance =
      policy.absolute_residual_tolerance.to_long_double();
  if (!std::isfinite(tolerance) || tolerance < 0.0L) {
    return fail<void>(
        "c21.unusable_solver_tolerance",
        "the exact residual tolerance has no finite nonnegative image",
        DiagnosticCategory::unavailable);
  }
  const auto* enumerated = std::get_if<EnumeratedSolver>(
      &source.configured_solver);
  if (enumerated == nullptr ||
      enumerated->linear_method != policy.linear_method ||
      enumerated->max_iterations != policy.max_iterations ||
      source.authored_analysis_identity != policy.analysis_fingerprint) {
    return fail<void>(
        "c21.solver_policy_binding_mismatch",
        "the supplied solver policy differs from the analysis sealed into "
        "the C20 stationary source");
  }
  return Result<void>::success();
}

[[nodiscard]] bool has_exact_c21_stationary_route(
    const temporal::detail::C20StationaryCapabilityFactsV1& facts) {
  return facts.stationary_invariant_route ||
         facts.stationary_edge_reward_route ||
         facts.finite_temporal_cylinder_route ||
         facts.stationary_temporal_law_route ||
         facts.residence_or_stopped_route || facts.palm_or_fifo_route;
}

[[nodiscard]] Result<void> require_configured_slot_phase_law(
    const std::optional<StationaryPhaseLawDescriptor>& configured) {
  if (!configured.has_value()) {
    return fail<void>(
        "c21.configured_slot_phase_law_unavailable",
        "C21 stationary suspension requires the sealed configured "
        "ordinary-slot stationary arrival-phase law so that (12.13a) can "
        "be verified; an unavailable phase law is not inferred from the "
        "event-entry marginal",
        DiagnosticCategory::unavailable);
  }
  return Result<void>::success();
}

}  // namespace

namespace {

struct EventClassAnalysis final {
  std::vector<CommunicatingClassV1> classes;
  std::vector<std::size_t> closed_class_indices;
  std::vector<std::size_t> transient_state_indices;
};

[[nodiscard]] Result<void> validate_embedded_kernel(
    const EmbeddedKernel& kernel) {
  const auto states = kernel.domain().states();
  const auto rows = kernel.rows();
  if (states.empty() || rows.size() != states.size()) {
    return fail<void>(
        "c21.invalid_finite_event_domain",
        "C21 requires a nonempty finite event domain with one complete row "
        "per state");
  }
  for (std::size_t row = 0U; row < rows.size(); ++row) {
    if (!(rows[row].word_row.entry_state() == states[row]) ||
        !(rows[row].word_row.exact_total_mass() == ExactRational::one()) ||
        !(rows[row].exact_total_mass == ExactRational::one())) {
      return fail<void>(
          "c21.incomplete_embedded_event_row",
          "an embedded event row is foreign, incomplete, or has excess "
          "mass",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(row)});
    }
    ExactRational total = ExactRational::zero();
    std::vector<std::uint8_t> seen(states.size(), 0U);
    for (const EmbeddedKernelAtomV1& atom : rows[row].endpoint_atoms) {
      if (atom.endpoint_index >= states.size() ||
          !atom.exact_mass.is_positive() ||
          seen[atom.endpoint_index] != 0U) {
        return fail<void>(
            "c21.invalid_embedded_event_atom",
            "an embedded row contains an off-domain, duplicate, or "
            "nonpositive endpoint atom",
            DiagnosticCategory::input_validation,
            {"row " + std::to_string(row)});
      }
      seen[atom.endpoint_index] = 1U;
      total = total + atom.exact_mass;
    }
    if (!(total == ExactRational::one())) {
      return fail<void>(
          "c21.embedded_event_row_mass_not_one",
          "the explicit embedded endpoint atoms do not have exact unit "
          "mass; C21 never completes or renormalizes the row",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(row),
           "mass " + total.to_canonical_string()});
    }
  }
  return Result<void>::success();
}

[[nodiscard]] ExactRational matrix_entry(const EmbeddedKernel& kernel,
                                         const std::size_t row,
                                         const std::size_t column) {
  for (const EmbeddedKernelAtomV1& atom :
       kernel.rows()[row].endpoint_atoms) {
    if (atom.endpoint_index == column) {
      return atom.exact_mass;
    }
  }
  return ExactRational::zero();
}

[[nodiscard]] EventClassAnalysis analyze_event_classes(
    const EmbeddedKernel& kernel) {
  const std::size_t count = kernel.domain().states().size();
  std::vector<std::vector<std::size_t>> adjacency(count);
  for (std::size_t source = 0U; source < count; ++source) {
    for (const EmbeddedKernelAtomV1& atom :
         kernel.rows()[source].endpoint_atoms) {
      if (atom.exact_mass.is_positive()) {
        adjacency[source].push_back(atom.endpoint_index);
      }
    }
  }

  std::vector<std::size_t> canonical_order(count);
  std::iota(canonical_order.begin(), canonical_order.end(), 0U);
  const auto states = kernel.domain().states();
  std::stable_sort(canonical_order.begin(), canonical_order.end(),
                   [&](const std::size_t left, const std::size_t right) {
                     return state_less(states[left], states[right]);
                   });
  std::vector<std::size_t> canonical_rank(count);
  for (std::size_t rank = 0U; rank < count; ++rank) {
    canonical_rank[canonical_order[rank]] = rank;
  }
  for (auto& successors : adjacency) {
    std::stable_sort(successors.begin(), successors.end(),
                     [&](const std::size_t left, const std::size_t right) {
                       return canonical_rank[left] < canonical_rank[right];
                     });
  }

  constexpr std::size_t unseen = std::numeric_limits<std::size_t>::max();
  std::vector<std::size_t> discovery(count, unseen);
  std::vector<std::size_t> low(count, unseen);
  std::vector<std::size_t> stack;
  std::vector<std::uint8_t> on_stack(count, 0U);
  std::vector<std::vector<std::size_t>> components;
  std::size_t next_discovery = 0U;
  std::function<void(std::size_t)> visit = [&](const std::size_t vertex) {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = 1U;
    for (const std::size_t successor : adjacency[vertex]) {
      if (discovery[successor] == unseen) {
        visit(successor);
        low[vertex] = std::min(low[vertex], low[successor]);
      } else if (on_stack[successor] != 0U) {
        low[vertex] = std::min(low[vertex], discovery[successor]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::size_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = 0U;
      component.push_back(member);
      if (member == vertex) {
        break;
      }
    }
    std::stable_sort(component.begin(), component.end(),
                     [&](const std::size_t left, const std::size_t right) {
                       return canonical_rank[left] < canonical_rank[right];
                     });
    components.push_back(std::move(component));
  };
  for (const std::size_t vertex : canonical_order) {
    if (discovery[vertex] == unseen) {
      visit(vertex);
    }
  }
  std::stable_sort(
      components.begin(), components.end(),
      [&](const std::vector<std::size_t>& left,
          const std::vector<std::size_t>& right) {
        return std::lexicographical_compare(
            left.begin(), left.end(), right.begin(), right.end(),
            [&](const std::size_t a, const std::size_t b) {
              return canonical_rank[a] < canonical_rank[b];
            });
      });

  std::vector<std::size_t> component_of(count, 0U);
  for (std::size_t component = 0U; component < components.size();
       ++component) {
    for (const std::size_t state : components[component]) {
      component_of[state] = component;
    }
  }

  EventClassAnalysis output;
  output.classes.reserve(components.size());
  std::vector<std::uint8_t> in_closed(count, 0U);
  for (std::size_t component = 0U; component < components.size();
       ++component) {
    std::set<std::size_t> outgoing;
    for (const std::size_t source : components[component]) {
      for (const std::size_t successor : adjacency[source]) {
        if (component_of[successor] != component) {
          outgoing.insert(component_of[successor]);
        }
      }
    }
    std::vector<TypedLabel> outgoing_ids;
    outgoing_ids.reserve(outgoing.size());
    for (const std::size_t target : outgoing) {
      outgoing_ids.push_back(TypedLabel::numeric(BigNat{target}));
    }
    const bool closed = outgoing.empty();
    output.classes.push_back(CommunicatingClassV1{
        TypedLabel::numeric(BigNat{component}), components[component],
        std::move(outgoing_ids), closed});
    if (closed) {
      output.closed_class_indices.push_back(component);
      for (const std::size_t member : components[component]) {
        in_closed[member] = 1U;
      }
    }
  }
  for (const std::size_t state : canonical_order) {
    if (in_closed[state] == 0U) {
      output.transient_state_indices.push_back(state);
    }
  }
  return output;
}

[[nodiscard]] Result<std::vector<SelectedInvariantClassV1>>
select_event_classes(const EventClassAnalysis& classes,
                     const SelectionSpec& selection) {
  std::vector<SelectedInvariantClassV1> selected;
  const auto append = [&](const TypedLabel& id,
                          const ExactRational& weight) -> Result<void> {
    const auto found = std::find_if(
        classes.classes.begin(), classes.classes.end(),
        [&](const CommunicatingClassV1& candidate) {
          return candidate.class_id == id;
        });
    if (found == classes.classes.end()) {
      return fail<void>("c21.unknown_event_class",
                        "the stationary selector names an unknown event "
                        "communicating class");
    }
    if (!found->closed) {
      return fail<void>("c21.transient_event_class_selected",
                        "event invariant mass may be assigned only to a "
                        "closed communicating class");
    }
    const auto image = numerical_image(weight);
    if (image.second != NumericalProbabilityImageStatusV1::finite ||
        (weight.is_positive() && image.first <= 0.0L)) {
      return fail<void>(
          "c21.unusable_event_mixture_weight",
          "a selected exact event-class weight has no finite positive "
          "numerical image",
          DiagnosticCategory::unavailable);
    }
    selected.push_back(SelectedInvariantClassV1{
        id, static_cast<std::size_t>(found - classes.classes.begin()),
        weight, image.first});
    return Result<void>::success();
  };

  if (std::holds_alternative<StationaryUniqueSelection>(selection)) {
    if (classes.closed_class_indices.size() != 1U) {
      return fail<std::vector<SelectedInvariantClassV1>>(
          "c21.event_class_selection_required",
          "stationary_unique is admissible only when the embedded event "
          "kernel has exactly one closed class",
          DiagnosticCategory::input_validation,
          {"closed classes " +
           std::to_string(classes.closed_class_indices.size())});
    }
    const std::size_t index = classes.closed_class_indices.front();
    auto added = append(classes.classes[index].class_id,
                        ExactRational::one());
    if (!added) {
      return Result<std::vector<SelectedInvariantClassV1>>::failure(
          added.error());
    }
  } else if (const auto* one =
                 std::get_if<StationaryClassSelection>(&selection)) {
    auto added = append(one->class_id, ExactRational::one());
    if (!added) {
      return Result<std::vector<SelectedInvariantClassV1>>::failure(
          added.error());
    }
  } else if (const auto* mixture =
                 std::get_if<StationaryMixtureSelection>(&selection)) {
    if (mixture->components.empty()) {
      return fail<std::vector<SelectedInvariantClassV1>>(
          "c21.empty_event_class_mixture",
          "an event-class mixture must name at least one class");
    }
    ExactRational total = ExactRational::zero();
    for (std::size_t index = 0U; index < mixture->components.size();
         ++index) {
      const auto& component = mixture->components[index];
      const ExactRational& weight = component.probability.exact_value();
      if (!weight.is_nonnegative()) {
        return fail<std::vector<SelectedInvariantClassV1>>(
            "c21.negative_event_mixture_weight",
            "event-class mixture weights must be exact nonnegative values");
      }
      for (std::size_t earlier = 0U; earlier < index; ++earlier) {
        if (mixture->components[earlier].class_id == component.class_id) {
          return fail<std::vector<SelectedInvariantClassV1>>(
              "c21.duplicate_event_mixture_class",
              "an event-class mixture may name each class at most once");
        }
      }
      total = total + weight;
    }
    if (!total.is_positive()) {
      return fail<std::vector<SelectedInvariantClassV1>>(
          "c21.nonpositive_event_mixture_total",
          "event-class mixture weights require a positive exact total");
    }
    for (const auto& component : mixture->components) {
      auto normalized =
          checked_divide(component.probability.exact_value(), total);
      if (!normalized) {
        return Result<std::vector<SelectedInvariantClassV1>>::failure(
            normalized.error());
      }
      auto added = append(component.class_id, normalized.value());
      if (!added) {
        return Result<std::vector<SelectedInvariantClassV1>>::failure(
            added.error());
      }
    }
  } else {
    return fail<std::vector<SelectedInvariantClassV1>>(
        "c21.stationary_event_selection_required",
        "the embedded event kernel requires a stationary unique, class, or "
        "mixture selector");
  }
  return Result<std::vector<SelectedInvariantClassV1>>::success(
      std::move(selected));
}

// C18 selection semantics identify a mixture by its normalized event-epoch
// weights. C15-authored probabilities are individually bounded by one, but a
// direct C21 caller may supply equivalent positive weights whose total is not
// one (for example 1,1). Normalize before comparing with the selection sealed
// into C20 provenance; this changes neither class support nor slot-time class
// weights.
[[nodiscard]] Result<SelectionSpec> normalized_event_selection(
    const SelectionSpec& selection) {
  const auto* mixture =
      std::get_if<StationaryMixtureSelection>(&selection);
  if (mixture == nullptr) {
    return Result<SelectionSpec>::success(selection);
  }
  if (mixture->components.empty()) {
    return fail<SelectionSpec>(
        "c21.empty_event_class_mixture",
        "an event-class mixture must name at least one class");
  }
  ExactRational total = ExactRational::zero();
  for (std::size_t index = 0U; index < mixture->components.size(); ++index) {
    const auto& component = mixture->components[index];
    const ExactRational& weight = component.probability.exact_value();
    if (!weight.is_nonnegative()) {
      return fail<SelectionSpec>(
          "c21.negative_event_mixture_weight",
          "event-class mixture weights must be exact nonnegative values");
    }
    for (std::size_t earlier = 0U; earlier < index; ++earlier) {
      if (mixture->components[earlier].class_id == component.class_id) {
        return fail<SelectionSpec>(
            "c21.duplicate_event_mixture_class",
            "an event-class mixture may name each class at most once");
      }
    }
    total = total + weight;
  }
  if (!total.is_positive()) {
    return fail<SelectionSpec>(
        "c21.nonpositive_event_mixture_total",
        "event-class mixture weights require a positive exact total");
  }

  std::vector<StationaryMixtureComponent> normalized;
  normalized.reserve(mixture->components.size());
  for (const auto& component : mixture->components) {
    auto weight = checked_divide(component.probability.exact_value(), total);
    if (!weight) {
      return Result<SelectionSpec>::failure(weight.error());
    }
    auto probability = AuthoredProbability::from_exact(weight.value());
    if (!probability) {
      return Result<SelectionSpec>::failure(probability.error());
    }
    normalized.push_back({component.class_id, std::move(probability).value(),
                          component.source});
  }
  return Result<SelectionSpec>::success(StationaryMixtureSelection{
      std::move(normalized), mixture->source});
}

[[nodiscard]] Result<std::vector<ExactRational>> exact_invariant_law(
    std::vector<ExactRational> coefficients, const std::size_t dimension) {
  if (dimension == 0U ||
      dimension > std::numeric_limits<std::size_t>::max() / dimension ||
      coefficients.size() != dimension * dimension) {
    return fail<std::vector<ExactRational>>(
        "c21.invalid_event_invariant_system",
        "the exact event invariant system has invalid dimensions",
        DiagnosticCategory::internal);
  }
  std::vector<ExactRational> rhs(dimension, ExactRational::zero());
  rhs.back() = ExactRational::one();
  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension &&
           coefficients[pivot * dimension + column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return fail<std::vector<ExactRational>>(
          "c21.singular_event_invariant_system",
          "the selected closed event class produced a singular constrained "
          "invariant system",
          DiagnosticCategory::unavailable);
    }
    if (pivot != column) {
      for (std::size_t entry = column; entry < dimension; ++entry) {
        std::swap(coefficients[column * dimension + entry],
                  coefficients[pivot * dimension + entry]);
      }
      std::swap(rhs[column], rhs[pivot]);
    }
    const ExactRational pivot_value =
        coefficients[column * dimension + column];
    for (std::size_t entry = column; entry < dimension; ++entry) {
      auto value = checked_divide(
          coefficients[column * dimension + entry], pivot_value);
      if (!value) {
        return Result<std::vector<ExactRational>>::failure(value.error());
      }
      coefficients[column * dimension + entry] = std::move(value).value();
    }
    auto rhs_value = checked_divide(rhs[column], pivot_value);
    if (!rhs_value) {
      return Result<std::vector<ExactRational>>::failure(rhs_value.error());
    }
    rhs[column] = std::move(rhs_value).value();
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const ExactRational factor =
          coefficients[row * dimension + column];
      if (factor.is_zero()) {
        continue;
      }
      for (std::size_t entry = column; entry < dimension; ++entry) {
        coefficients[row * dimension + entry] =
            coefficients[row * dimension + entry] -
            factor * coefficients[column * dimension + entry];
      }
      rhs[row] = rhs[row] - factor * rhs[column];
    }
  }
  return Result<std::vector<ExactRational>>::success(std::move(rhs));
}

struct NumericalResidual final {
  long double normalization;
  long double normalization_bound;
  long double l1;
  long double l1_bound;
  long double maximum;
  long double maximum_bound;
};

[[nodiscard]] NumericalResidual invariant_residual(
    const EmbeddedKernel& kernel, const std::vector<long double>& masses,
    const SolverPolicy& policy,
    const std::span<const std::size_t> coordinates) {
  CompensatedSum normalization;
  long double normalization_scale = 0.0L;
  for (const std::size_t state : coordinates) {
    normalization.add(masses[state]);
    normalization_scale += std::fabs(masses[state]);
  }
  CompensatedSum l1;
  long double l1_scale = 0.0L;
  long double maximum = 0.0L;
  long double maximum_scale = 0.0L;
  for (const std::size_t destination : coordinates) {
    CompensatedSum image;
    long double scale = std::fabs(masses[destination]);
    for (const std::size_t source : coordinates) {
      const long double term =
          masses[source] * matrix_entry(kernel, source, destination)
                               .to_long_double();
      image.add(term);
      scale += std::fabs(term);
    }
    const long double residual = image.value() - masses[destination];
    l1.add(std::fabs(residual));
    l1_scale += scale;
    maximum = std::max(maximum, std::fabs(residual));
    maximum_scale = std::max(maximum_scale, scale);
  }
  return NumericalResidual{
      normalization.value() - 1.0L,
      residual_bound(policy, normalization_scale), l1.value(),
      residual_bound(policy, l1_scale), maximum,
      residual_bound(policy, maximum_scale)};
}

[[nodiscard]] Result<Digest256> event_law_fingerprint(
    const EmbeddedKernel& kernel,
    const temporal::detail::C20StationaryKernelBindingV1& binding,
    const std::span<const SelectedInvariantClassV1> selected,
    const std::span<const EventInvariantMassV1> masses,
    const SolverPolicy& policy, const Digest256& selection_digest) {
  IdentityEncoder encoder;
  encoder.u32(1U);
  encoder.digest(kernel.fingerprint());
  encoder.digest(binding.finite_event_domain_identity);
  encoder.digest(binding.finite_event_domain_content_identity);
  encoder.digest(binding.source.execution_seal_identity);
  encoder.digest(binding.source.provider_romr_identity);
  encoder.digest(binding.source.descriptor_identity);
  encoder.digest(binding.source.accepted_contract_identity);
  encoder.digest(binding.source.normalized_requirements_identity);
  encoder.digest(binding.source.selection_identity);
  encoder.digest(binding.source.authored_analysis_identity);
  encoder.digest(binding.source.resolved_instance_identity);
  encoder.digest(binding.source.configured_arrival_identity);
  encoder.digest(binding.source.configured_arrival_view_identity);
  encoder.digest(binding.source.configured_arrival_law_identity);
  encoder.digest(binding.source.configured_arrival_catalog_identity);
  encoder.digest(binding.source.exact_state_schema_identity);
  encoder.digest(binding.source.reduced_state_schema_identity);
  encoder.digest(binding.source.ownership_schema_identity);
  encoder.digest(binding.source.exact_update_schema_identity);
  encoder.digest(binding.source.mark_schema_identity);
  encoder.digest(binding.source.timing_identity);
  encoder.digest(binding.source.continuation_schema_identity);
  encoder.digest(binding.source.target_selection_identity);
  encoder.digest(binding.source.target_service_schema_identity);
  encoder.digest(selection_digest);
  encoder.byte(static_cast<std::uint8_t>(policy.linear_method));
  encoder.rational(policy.absolute_residual_tolerance);
  encoder.rational(policy.relative_residual_tolerance);
  encoder.digest(policy.analysis_fingerprint);
  encoder.u64(static_cast<std::uint64_t>(selected.size()));
  for (const SelectedInvariantClassV1& item : selected) {
    encoder.label(item.class_id);
    encoder.u64(static_cast<std::uint64_t>(item.class_index));
    encoder.rational(item.exact_weight);
  }
  encoder.u64(static_cast<std::uint64_t>(masses.size()));
  for (const EventInvariantMassV1& mass : masses) {
    encoder.u64(static_cast<std::uint64_t>(mass.state_index));
    encoder.rational(mass.exact_mass);
  }
  return encoder.finish("mwperf.c21.event-invariant-law.v1");
}

}  // namespace

Result<EventInvariantLaw> select_event_invariant_law(
    const EmbeddedKernel& kernel, const SelectionSpec& selection,
    const SolverPolicy& policy) {
  try {
    auto binding = temporal::detail::c20_stationary_kernel_binding(kernel);
    if (!binding) {
      return Result<EventInvariantLaw>::failure(binding.error());
    }
    if (!has_exact_c21_stationary_route(
            binding.value().source.capabilities) ||
        !binding.value().source.capabilities.exact_complete_residence_words) {
      return fail<EventInvariantLaw>(
          "c21.exact_stationary_route_unavailable",
          "the accepted C14/C20 source does not authorize an exact finite "
          "stationary invariant route",
          DiagnosticCategory::unavailable);
    }
    if (!binding.value().source.capabilities.finite_phase_time_homogeneous ||
        binding.value().source.event_clock_semantics !=
            EventClockSemanticsV1::finite_phase_time_homogeneous_quotient) {
      return fail<EventInvariantLaw>(
          "c21.nonhomogeneous_event_kernel_unavailable",
          "C21 exact embedded-kernel assembly requires the audited finite-"
          "phase time-homogeneous event-state quotient; absolute-slot or "
          "nonhomogeneous arrivals remain countable and kernel-unavailable",
          DiagnosticCategory::unavailable);
    }
    auto configured_phase = require_configured_slot_phase_law(
        binding.value().source.configured_stationary_phase_law);
    if (!configured_phase) {
      return Result<EventInvariantLaw>::failure(configured_phase.error());
    }
    auto valid_policy = validate_policy(policy, binding.value().source);
    if (!valid_policy) {
      return Result<EventInvariantLaw>::failure(valid_policy.error());
    }
    auto normalized_selection = normalized_event_selection(selection);
    if (!normalized_selection) {
      return Result<EventInvariantLaw>::failure(normalized_selection.error());
    }
    auto supplied_selection_digest =
        artifact::detail::canonical_analysis_selection_digest_v1(
            normalized_selection.value());
    if (!supplied_selection_digest) {
      return Result<EventInvariantLaw>::failure(
          supplied_selection_digest.error());
    }
    if (supplied_selection_digest.value() !=
        binding.value().source.selection_identity) {
      return fail<EventInvariantLaw>(
          "c21.event_selection_binding_mismatch",
          "the supplied event selector differs from the selection sealed "
          "into the C20 stationary source");
    }
    auto valid_kernel = validate_embedded_kernel(kernel);
    if (!valid_kernel) {
      return Result<EventInvariantLaw>::failure(valid_kernel.error());
    }

    EventClassAnalysis classes = analyze_event_classes(kernel);
    auto selected =
        select_event_classes(classes, normalized_selection.value());
    if (!selected) {
      return Result<EventInvariantLaw>::failure(selected.error());
    }
    const std::size_t state_count = kernel.domain().states().size();
    std::vector<ExactRational> exact_masses(state_count,
                                            ExactRational::zero());
    std::vector<ClassSolveDiagnosticV1> class_diagnostics;
    for (const SelectedInvariantClassV1& chosen : selected.value()) {
      if (chosen.exact_weight.is_zero()) {
        continue;
      }
      const std::vector<std::size_t>& members =
          classes.classes[chosen.class_index].member_indices;
      const std::size_t dimension = members.size();
      if (dimension == 0U ||
          dimension > std::numeric_limits<std::size_t>::max() / dimension) {
        return fail<EventInvariantLaw>(
            "c21.event_invariant_dimension_overflow",
            "the selected event class is too large for a dense constrained "
            "invariant system",
            DiagnosticCategory::resource_limit);
      }
      std::vector<ExactRational> coefficients(
          dimension * dimension, ExactRational::zero());
      for (std::size_t equation = 0U; equation + 1U < dimension;
           ++equation) {
        for (std::size_t variable = 0U; variable < dimension; ++variable) {
          ExactRational coefficient = matrix_entry(
              kernel, members[variable], members[equation]);
          if (variable == equation) {
            coefficient = coefficient - ExactRational::one();
          }
          coefficients[equation * dimension + variable] =
              std::move(coefficient);
        }
      }
      for (std::size_t variable = 0U; variable < dimension; ++variable) {
        coefficients[(dimension - 1U) * dimension + variable] =
            ExactRational::one();
      }
      auto local = exact_invariant_law(coefficients, dimension);
      if (!local) {
        return Result<EventInvariantLaw>::failure(local.error());
      }
      ExactRational local_total = ExactRational::zero();
      for (const ExactRational& mass : local.value()) {
        if (!mass.is_nonnegative()) {
          return fail<EventInvariantLaw>(
              "c21.negative_exact_event_invariant_mass",
              "the exact constrained event solve produced negative mass",
              DiagnosticCategory::internal);
        }
        local_total = local_total + mass;
      }
      if (!(local_total == ExactRational::one())) {
        return fail<EventInvariantLaw>(
            "c21.event_class_normalization_invariant",
            "the exact selected-class event invariant law is not "
            "normalized",
            DiagnosticCategory::internal);
      }
      for (std::size_t local_index = 0U; local_index < dimension;
           ++local_index) {
        exact_masses[members[local_index]] =
            exact_masses[members[local_index]] +
            chosen.exact_weight * local.value()[local_index];
      }

      Eigen::Matrix<long double, Eigen::Dynamic, Eigen::Dynamic> numerical(
          static_cast<Eigen::Index>(dimension),
          static_cast<Eigen::Index>(dimension));
      for (std::size_t row = 0U; row < dimension; ++row) {
        for (std::size_t column = 0U; column < dimension; ++column) {
          numerical(static_cast<Eigen::Index>(row),
                    static_cast<Eigen::Index>(column)) =
              coefficients[row * dimension + column].to_long_double();
        }
      }
      const long double eta = static_cast<long double>(dimension) *
                              std::numeric_limits<long double>::epsilon();
      Eigen::FullPivLU<decltype(numerical)> factorization;
      factorization.setThreshold(eta);
      factorization.compute(numerical);
      const std::size_t rank =
          static_cast<std::size_t>(factorization.rank());
      const long double rcond = factorization.rcond();
      const long double warning_threshold = std::sqrt(eta);
      bool finite_nonnegative = true;
      std::vector<long double> local_images(state_count, 0.0L);
      for (std::size_t local_index = 0U; local_index < dimension;
           ++local_index) {
        const ExactRational& exact = local.value()[local_index];
        const auto image = numerical_image(exact);
        if (image.second != NumericalProbabilityImageStatusV1::finite ||
            image.first < 0.0L ||
            (exact.is_positive() && image.first <= 0.0L)) {
          finite_nonnegative = false;
        }
        local_images[members[local_index]] = image.first;
      }
      const NumericalResidual residual = invariant_residual(
          kernel, local_images, policy, members);
      const bool accepted =
          rank == dimension && finite_nonnegative &&
          std::fabs(residual.normalization) <=
              residual.normalization_bound &&
          residual.l1 <= residual.l1_bound &&
          residual.maximum <= residual.maximum_bound;
      class_diagnostics.push_back(ClassSolveDiagnosticV1{
          chosen.class_id,
          dimension,
          rank,
          eta,
          rcond,
          warning_threshold,
          !std::isfinite(rcond) || rcond <= warning_threshold,
          residual.normalization,
          residual.normalization_bound,
          residual.l1,
          residual.l1_bound,
          residual.maximum,
          residual.maximum_bound,
          finite_nonnegative,
          accepted ? StationaryLinearSolveStatusV1::solved
                   : StationaryLinearSolveStatusV1::numerically_unresolved});
      if (!accepted) {
        return fail<EventInvariantLaw>(
            "c21.event_invariant_numerically_unresolved",
            "the exact selected-class event law has no acceptable pivoted "
            "numerical image under the declared residual policy",
            DiagnosticCategory::unavailable,
            {"class index " + std::to_string(chosen.class_index),
             "rank " + std::to_string(rank),
             "dimension " + std::to_string(dimension)});
      }
    }

    ExactRational exact_total = ExactRational::zero();
    bool exact_nonnegative = true;
    for (const ExactRational& mass : exact_masses) {
      exact_total = exact_total + mass;
      exact_nonnegative = exact_nonnegative && mass.is_nonnegative();
    }
    const ExactRational normalization_residual =
        exact_total - ExactRational::one();
    std::vector<ExactRational> exact_residuals;
    exact_residuals.reserve(state_count);
    bool exact_invariant = true;
    for (std::size_t destination = 0U; destination < state_count;
         ++destination) {
      ExactRational image = ExactRational::zero();
      for (std::size_t source = 0U; source < state_count; ++source) {
        image = image + exact_masses[source] *
                            matrix_entry(kernel, source, destination);
      }
      exact_residuals.push_back(image - exact_masses[destination]);
      exact_invariant = exact_invariant && exact_residuals.back().is_zero();
    }
    if (!exact_nonnegative || !normalization_residual.is_zero() ||
        !exact_invariant) {
      return fail<EventInvariantLaw>(
          "c21.exact_event_invariant_check_failed",
          "the assembled exact event mixture failed nonnegativity, "
          "normalization, or invariance",
          DiagnosticCategory::internal);
    }

    std::vector<EventInvariantMassV1> masses;
    masses.reserve(state_count);
    std::vector<long double> numerical_masses;
    numerical_masses.reserve(state_count);
    for (std::size_t state = 0U; state < state_count; ++state) {
      const auto image = numerical_image(exact_masses[state]);
      if (image.second != NumericalProbabilityImageStatusV1::finite) {
        return fail<EventInvariantLaw>(
            "c21.event_invariant_image_out_of_range",
            "an exact event invariant mass has no finite faithful numerical "
            "image",
            DiagnosticCategory::unavailable);
      }
      masses.push_back(EventInvariantMassV1{
          state, exact_masses[state], image.first, image.second});
      numerical_masses.push_back(image.first);
    }
    std::vector<std::size_t> all_coordinates(state_count);
    std::iota(all_coordinates.begin(), all_coordinates.end(), 0U);
    const NumericalResidual aggregate = invariant_residual(
        kernel, numerical_masses, policy, all_coordinates);
    if (std::fabs(aggregate.normalization) >
            aggregate.normalization_bound ||
        aggregate.l1 > aggregate.l1_bound ||
        aggregate.maximum > aggregate.maximum_bound) {
      return fail<EventInvariantLaw>(
          "c21.event_mixture_numerically_unresolved",
          "the selected exact event-class mixture exceeds the declared "
          "numerical residual policy",
          DiagnosticCategory::unavailable);
    }
    InvariantSolveDiagnosticsV1 solve{
        policy.linear_method,
        policy.absolute_residual_tolerance,
        policy.relative_residual_tolerance,
        selected.value(),
        std::move(class_diagnostics),
        aggregate.normalization,
        aggregate.normalization_bound,
        aggregate.l1,
        aggregate.l1_bound,
        aggregate.maximum,
        aggregate.maximum_bound};
    EventInvariantDiagnosticsV1 diagnostics{
        std::move(classes.classes),
        std::move(classes.closed_class_indices),
        std::move(classes.transient_state_indices),
        std::move(solve),
        normalization_residual,
        std::move(exact_residuals),
        exact_nonnegative,
        normalization_residual.is_zero(),
        exact_invariant};
    auto fingerprint = event_law_fingerprint(
        kernel, binding.value(), selected.value(), masses, policy,
        supplied_selection_digest.value());
    if (!fingerprint) {
      return Result<EventInvariantLaw>::failure(fingerprint.error());
    }
    auto core = std::make_shared<const
                                 stationary::detail::EventInvariantLawCore>(
        stationary::detail::EventInvariantLawCore{
            kernel, std::move(binding).value(), std::move(masses),
            selected.value(), std::move(diagnostics), policy,
            supplied_selection_digest.value(),
            std::move(fingerprint).value()});
    return Result<EventInvariantLaw>::success(
        detail::C21CoreAccess::event_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<EventInvariantLaw>(
        "c21.event_invariant_allocation_failure",
        "constructing the finite event invariant law exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<EventInvariantLaw>(
        "c21.event_invariant_exception",
        "the finite event invariant solve raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

namespace {

struct MeanEvidence final {
  ResidenceExpectationMethodV1 method;
  std::optional<ExactRational> exact_value;
  ExactRational evaluated_sum;
  ExactRational lower_bound;
  ExactRational upper_bound;
  ExactRational tail_lower_bound;
  ExactRational tail_upper_bound;
  bool support_complete;
  bool tail_certified;
  bool declared_infinite;
  bool arithmetic_overflow;
};

[[nodiscard]] Result<PositiveFiniteMeanDiagnosticsV1>
validate_positive_finite_mean_evidence(
    const MeanEvidence& evidence, const std::size_t event_states_visited,
    const std::size_t words_visited,
    const std::size_t offsets_certified,
    const long double numerical_sum = 0.0L,
    const long double numerical_correction = 0.0L) {
  if (evidence.declared_infinite) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.infinite_mean_residence",
        "the complete residence law has infinite mean; almost-sure finite "
        "words do not establish a stationary suspension denominator",
        DiagnosticCategory::unavailable);
  }
  if (evidence.arithmetic_overflow) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.mean_residence_arithmetic_overflow",
        "residence expectation accumulation exceeded its certified "
        "arithmetic representation",
        DiagnosticCategory::resource_limit);
  }
  if (!std::isfinite(numerical_sum) ||
      !std::isfinite(numerical_correction)) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.mean_residence_arithmetic_overflow",
        "the compensated residence expectation has no finite numerical "
        "sum and correction",
        DiagnosticCategory::resource_limit);
  }
  if (!evidence.lower_bound.is_positive() ||
      evidence.lower_bound < ExactRational::one() ||
      evidence.upper_bound < evidence.lower_bound ||
      !evidence.evaluated_sum.is_nonnegative() ||
      !evidence.tail_lower_bound.is_nonnegative() ||
      !evidence.tail_upper_bound.is_nonnegative() ||
      evidence.tail_upper_bound < evidence.tail_lower_bound ||
      !(evidence.lower_bound ==
        evidence.evaluated_sum + evidence.tail_lower_bound) ||
      !(evidence.upper_bound ==
        evidence.evaluated_sum + evidence.tail_upper_bound)) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.nonpositive_or_invalid_mean_residence",
        "a stationary suspension requires a consistent strictly positive "
        "residence-mean enclosure");
  }
  if (!evidence.support_complete && !evidence.tail_certified) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.mean_residence_tail_uncertified",
        "a truncated or sampled residence enumeration without a certified "
        "tail cannot establish a finite mean",
        DiagnosticCategory::unavailable);
  }
  if (evidence.exact_value.has_value() &&
      (!evidence.support_complete ||
       !evidence.tail_lower_bound.is_zero() ||
       !evidence.tail_upper_bound.is_zero() ||
       !(evidence.lower_bound == *evidence.exact_value) ||
       !(evidence.upper_bound == *evidence.exact_value) ||
       !(*evidence.exact_value == evidence.evaluated_sum))) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.invalid_exact_mean_evidence",
        "an exact residence mean requires complete support and a zero tail "
        "enclosure");
  }
  const long double lower = evidence.lower_bound.to_long_double();
  const long double upper = evidence.upper_bound.to_long_double();
  long double value = evidence.exact_value.has_value()
                          ? evidence.exact_value->to_long_double()
                          : numerical_sum;
  if (!evidence.exact_value.has_value() && value == 0.0L &&
      lower == upper) {
    value = lower;
  }
  if (!std::isfinite(lower) || !std::isfinite(upper) || lower <= 0.0L ||
      upper < lower || !std::isfinite(value) || value <= 0.0L) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.mean_residence_numerically_unresolved",
        "the positive finite residence enclosure has no usable promoted "
        "numerical image",
        DiagnosticCategory::unavailable);
  }
  if (!evidence.exact_value.has_value() &&
      (value < lower || value > upper)) {
    // A certified enclosure is not silently represented by its midpoint.
    // The supplied numerical estimate must itself lie inside the proof
    // interval, and exact_value remains absent.
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.mean_residence_estimate_outside_enclosure",
        "the numerical residence estimate lies outside its certified exact "
        "enclosure",
        DiagnosticCategory::unavailable);
  }
  const long double condition =
      upper / std::max(lower, std::numeric_limits<long double>::min());
  return Result<PositiveFiniteMeanDiagnosticsV1>::success(
      PositiveFiniteMeanDiagnosticsV1{
          evidence.method,
          evidence.exact_value,
          evidence.evaluated_sum,
          evidence.lower_bound,
          evidence.upper_bound,
          evidence.tail_lower_bound,
          evidence.tail_upper_bound,
          value,
          numerical_correction,
          lower,
          upper,
          condition,
          ResidenceRangeStatusV1::finite_native_range,
          event_states_visited,
          words_visited,
          offsets_certified,
          evidence.support_complete,
          evidence.tail_certified});
}

[[nodiscard]] Result<Digest256> mean_fingerprint(
    const stationary::detail::EventInvariantLawCore& law,
    const temporal::detail::C20StationarySourceBindingV1& provider,
    const PositiveFiniteMeanDiagnosticsV1& diagnostics) {
  IdentityEncoder encoder;
  encoder.u32(1U);
  encoder.digest(law.fingerprint);
  encoder.digest(provider.provider_romr_identity);
  encoder.digest(provider.execution_seal_identity);
  encoder.digest(provider.descriptor_identity);
  encoder.digest(provider.accepted_contract_identity);
  encoder.digest(provider.normalized_requirements_identity);
  encoder.digest(provider.selection_identity);
  encoder.digest(provider.authored_analysis_identity);
  encoder.digest(provider.resolved_instance_identity);
  encoder.digest(provider.configured_arrival_identity);
  encoder.digest(provider.configured_arrival_view_identity);
  encoder.digest(provider.configured_arrival_law_identity);
  encoder.digest(provider.configured_arrival_catalog_identity);
  encoder.digest(provider.exact_state_schema_identity);
  encoder.digest(provider.reduced_state_schema_identity);
  encoder.digest(provider.ownership_schema_identity);
  encoder.digest(provider.exact_update_schema_identity);
  encoder.digest(provider.mark_schema_identity);
  encoder.digest(provider.timing_identity);
  encoder.digest(provider.continuation_schema_identity);
  encoder.digest(provider.target_selection_identity);
  encoder.digest(provider.target_service_schema_identity);
  encoder.byte(static_cast<std::uint8_t>(diagnostics.method));
  encoder.rational(diagnostics.exact_evaluated_sum);
  encoder.rational(diagnostics.exact_lower_bound);
  encoder.rational(diagnostics.exact_upper_bound);
  encoder.rational(diagnostics.exact_tail_lower_bound);
  encoder.rational(diagnostics.exact_tail_upper_bound);
  encoder.byte(diagnostics.support_complete ? 1U : 0U);
  encoder.byte(diagnostics.tail_certified ? 1U : 0U);
  return encoder.finish("mwperf.c21.positive-finite-mean.v1");
}

[[nodiscard]] bool same_source_binding(
    const temporal::detail::C20StationarySourceBindingV1& left,
    const temporal::detail::C20StationarySourceBindingV1& right) {
  return left.seal_token == right.seal_token &&
         left.provider_romr_identity == right.provider_romr_identity &&
         left.execution_seal_identity == right.execution_seal_identity &&
         left.descriptor_identity == right.descriptor_identity &&
         left.accepted_contract_identity == right.accepted_contract_identity &&
         left.normalized_requirements_identity ==
             right.normalized_requirements_identity &&
         left.selection_identity == right.selection_identity &&
         left.authored_analysis_identity == right.authored_analysis_identity &&
         left.resolved_instance_identity == right.resolved_instance_identity &&
         left.configured_arrival_identity ==
             right.configured_arrival_identity &&
         left.configured_arrival_view_identity ==
             right.configured_arrival_view_identity &&
         left.configured_arrival_law_identity ==
             right.configured_arrival_law_identity &&
         left.configured_arrival_catalog_identity ==
             right.configured_arrival_catalog_identity &&
         left.exact_state_schema_identity ==
             right.exact_state_schema_identity &&
         left.reduced_state_schema_identity ==
             right.reduced_state_schema_identity &&
         left.ownership_schema_identity == right.ownership_schema_identity &&
         left.exact_update_schema_identity ==
             right.exact_update_schema_identity &&
         left.mark_schema_identity == right.mark_schema_identity &&
         left.timing_identity == right.timing_identity &&
         left.continuation_schema_identity ==
             right.continuation_schema_identity &&
         left.target_selection_identity ==
             right.target_selection_identity &&
         left.target_service_schema_identity ==
             right.target_service_schema_identity &&
         left.state_codec == right.state_codec && left.timing == right.timing &&
         left.event_clock_semantics == right.event_clock_semantics &&
         left.frozen_representation_budget ==
             right.frozen_representation_budget;
}

[[nodiscard]] Result<const stationary::detail::PositiveFiniteMeanCore*>
require_three_way_identity(const EventInvariantLaw& law,
                           const AuditedResidenceProvider& provider,
                           const PositiveFiniteMean& mean) {
  const auto& law_core = detail::C21CoreAccess::core(law);
  const auto& mean_core = detail::C21CoreAccess::core(mean);
  if (detail::C21CoreAccess::carrier_identity(mean_core.event_law) !=
          detail::C21CoreAccess::carrier_identity(law) ||
      mean_core.diagnostics.exact_value == std::nullopt ||
      !mean_core.diagnostics.support_complete ||
      !mean_core.diagnostics.tail_certified) {
    return fail<const stationary::detail::PositiveFiniteMeanCore*>(
        "c21.event_law_denominator_binding_mismatch",
        "the event law and positive-finite denominator do not share one "
        "complete proof identity");
  }
  auto matched = temporal::detail::c20_require_stationary_kernel_provider_match(
      law_core.kernel, provider);
  if (!matched) {
    return Result<const stationary::detail::PositiveFiniteMeanCore*>::failure(
        matched.error());
  }
  auto provider_binding =
      temporal::detail::c20_stationary_provider_binding(provider);
  if (!provider_binding) {
    return Result<const stationary::detail::PositiveFiniteMeanCore*>::failure(
        provider_binding.error());
  }
  if (!same_source_binding(law_core.binding.source,
                           provider_binding.value()) ||
      !same_source_binding(mean_core.provider_binding,
                           provider_binding.value()) ||
      mean_core.event_law.fingerprint() != law.fingerprint() ||
      mean_core.fingerprint != mean.fingerprint()) {
    return fail<const stationary::detail::PositiveFiniteMeanCore*>(
        "c21.three_way_source_identity_mismatch",
        "the event law, residence provider, and denominator disagree on a "
        "finite domain, V0 seal, selection, arrival, schema, timing, "
        "continuation, or target-service identity");
  }
  return Result<const stationary::detail::PositiveFiniteMeanCore*>::success(
      &mean_core);
}

}  // namespace

Result<PositiveFiniteMean> compute_mean_residence(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider) {
  try {
    const auto& law_core = detail::C21CoreAccess::core(law);
    auto matched = temporal::detail::c20_require_stationary_kernel_provider_match(
        law_core.kernel, provider);
    if (!matched) {
      return Result<PositiveFiniteMean>::failure(matched.error());
    }
    auto provider_binding =
        temporal::detail::c20_stationary_provider_binding(provider);
    if (!provider_binding) {
      return Result<PositiveFiniteMean>::failure(provider_binding.error());
    }
    if (!same_source_binding(law_core.binding.source,
                             provider_binding.value())) {
      return fail<PositiveFiniteMean>(
          "c21.mean_residence_source_binding_mismatch",
          "the event invariant law and residence provider do not share all "
          "stationary source identities");
    }
    const auto& capabilities = provider_binding.value().capabilities;
    if (!has_exact_c21_stationary_route(capabilities) ||
        !capabilities.exact_complete_residence_words ||
        !capabilities.finite_phase_time_homogeneous) {
      return fail<PositiveFiniteMean>(
          "c21.mean_residence_exact_route_unavailable",
          "a positive-finite C21 denominator requires the exact complete-"
          "word finite-phase stationary route",
          DiagnosticCategory::unavailable);
    }

    ExactRational exact_sum = ExactRational::zero();
    CompensatedSum numerical_sum;
    std::size_t states_visited = 0U;
    std::size_t words_visited = 0U;
    std::size_t offsets_certified = 0U;
    const auto rows = law_core.kernel.rows();
    for (const EventInvariantMassV1& event_mass : law_core.masses) {
      if (!event_mass.exact_mass.is_positive()) {
        continue;
      }
      if (event_mass.state_index >= rows.size()) {
        return fail<PositiveFiniteMean>(
            "c21.event_mass_state_out_of_range",
            "an event invariant mass names no embedded row",
            DiagnosticCategory::internal);
      }
      ++states_visited;
      const ResidenceWordRow& row =
          rows[event_mass.state_index].word_row;
      if (!(row.exact_total_mass() == ExactRational::one()) ||
          row.provider_fingerprint() !=
              provider_binding.value().provider_romr_identity) {
        return fail<PositiveFiniteMean>(
            "c21.mean_residence_word_row_binding_mismatch",
            "a residence-word row is incomplete or belongs to another "
            "provider");
      }
      for (const ResidenceWordRowAtomV1& atom : row.atoms()) {
        if (!atom.exact_mass.is_positive()) {
          return fail<PositiveFiniteMean>(
              "c21.nonpositive_residence_word_mass",
              "a complete residence row contains a nonpositive published "
              "word mass");
        }
        const ResidenceWord& word = atom.word;
        if (word.length().is_zero() || word.edges().empty() ||
            word.continuation_path().size() != word.edges().size() + 1U ||
            word.length().value() != BigInt(word.edges().size())) {
          return fail<PositiveFiniteMean>(
              "c21.invalid_residence_word_length",
              "every exact residence word must have integer length at least "
              "one with exactly ell completed slots");
        }
        if (offsets_certified >
            std::numeric_limits<std::size_t>::max() - word.edges().size()) {
          return fail<PositiveFiniteMean>(
              "c21.mean_residence_offset_count_overflow",
              "residence offset accounting exceeds the host diagnostic "
              "range",
              DiagnosticCategory::resource_limit);
        }
        offsets_certified += word.edges().size();
        ++words_visited;
        auto length = rational_from_nat(word.length());
        if (!length) {
          return Result<PositiveFiniteMean>::failure(length.error());
        }
        const ExactRational term = event_mass.exact_mass * atom.exact_mass *
                                   length.value();
        if (!term.is_nonnegative()) {
          return fail<PositiveFiniteMean>(
              "c21.negative_mean_residence_term",
              "a probability-weighted residence length is negative",
              DiagnosticCategory::internal);
        }
        const long double image = term.to_long_double();
        if (!std::isfinite(image)) {
          return fail<PositiveFiniteMean>(
              "c21.mean_residence_product_overflow",
              "an exact probability-times-length term has no finite "
              "numerical image",
              DiagnosticCategory::unavailable);
        }
        exact_sum = exact_sum + term;
        numerical_sum.add(image);
      }
    }
    if (exact_sum < ExactRational::one()) {
      return fail<PositiveFiniteMean>(
          "c21.mean_residence_below_one",
          "a complete positive-integer residence law cannot have mean below "
          "one");
    }
    MeanEvidence evidence{
        ResidenceExpectationMethodV1::finite_exact_enumeration,
        exact_sum,
        exact_sum,
        exact_sum,
        exact_sum,
        ExactRational::zero(),
        ExactRational::zero(),
        true,
        true,
        false,
        false};
    auto diagnostics = validate_positive_finite_mean_evidence(
        evidence, states_visited, words_visited, offsets_certified,
        numerical_sum.value(), numerical_sum.correction());
    if (!diagnostics) {
      return Result<PositiveFiniteMean>::failure(diagnostics.error());
    }
    auto fingerprint = mean_fingerprint(law_core, provider_binding.value(),
                                        diagnostics.value());
    if (!fingerprint) {
      return Result<PositiveFiniteMean>::failure(fingerprint.error());
    }
    auto core = std::make_shared<const
                                 stationary::detail::PositiveFiniteMeanCore>(
        stationary::detail::PositiveFiniteMeanCore{
            law, provider, std::move(provider_binding).value(),
            std::move(diagnostics).value(),
            std::move(fingerprint).value()});
    return Result<PositiveFiniteMean>::success(
        detail::C21CoreAccess::positive_mean(std::move(core)));
  } catch (const std::bad_alloc&) {
    return fail<PositiveFiniteMean>(
        "c21.mean_residence_allocation_failure",
        "evaluating the exact residence mean exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<PositiveFiniteMean>(
        "c21.mean_residence_exception",
        "residence-mean evaluation raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

namespace {

[[nodiscard]] std::size_t stage_ordinal(const CausalStageV1 stage) {
  const auto found =
      std::find(kCausalStageOrderV1.begin(), kCausalStageOrderV1.end(), stage);
  return static_cast<std::size_t>(found - kCausalStageOrderV1.begin());
}

[[nodiscard]] bool edge_has_required_marks(
    const MarkedFluxEdgeV1& edge,
    const std::span<const RequiredStationaryMarkV1> requirements) {
  for (const RequiredStationaryMarkV1& requirement : requirements) {
    std::size_t matches = 0U;
    for (const CausalMarkV1& candidate : edge.marks) {
      if (candidate.mark.mark == requirement.mark &&
          candidate.mark.value.codec == requirement.value_codec &&
          stage_ordinal(candidate.reveal_stage) <=
              stage_ordinal(requirement.latest_reveal_stage)) {
        ++matches;
      }
    }
    if (matches != 1U) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] Result<MarkedFluxEdgeV1> project_marked_edge(
    const EmbeddedKernel& kernel, const ReducedStateV1& stationary_left,
    const CompletedReducedEdge& raw_edge,
    const ReducedStateV1& stationary_right) {
  auto decoded_left =
      temporal::detail::c20_decode_stationary_state(kernel, stationary_left);
  auto decoded_right =
      temporal::detail::c20_decode_stationary_state(kernel, stationary_right);
  if (!decoded_left) {
    return Result<MarkedFluxEdgeV1>::failure(decoded_left.error());
  }
  if (!decoded_right) {
    return Result<MarkedFluxEdgeV1>::failure(decoded_right.error());
  }
  const TargetBacklogV1& left_backlog = decoded_left.value().backlog;
  const TargetBacklogV1& right_backlog = decoded_right.value().backlog;
  if (left_backlog.size() == 0U ||
      left_backlog.size() != right_backlog.size()) {
    return fail<MarkedFluxEdgeV1>(
        "c21.stationary_edge_target_dimension_mismatch",
        "a stationary marked edge requires one common nonempty target "
        "backlog dimension");
  }
  std::vector<BigNat> prearrival(left_backlog.values().begin(),
                                 left_backlog.values().end());
  std::vector<std::uint8_t> departures;
  std::vector<BigNat> arrivals;
  departures.reserve(left_backlog.size());
  arrivals.reserve(left_backlog.size());
  for (std::size_t target = 0U; target < left_backlog.size(); ++target) {
    if (!(left_backlog.target_at_target_ordinal(target) ==
          right_backlog.target_at_target_ordinal(target))) {
      return fail<MarkedFluxEdgeV1>(
          "c21.stationary_edge_target_order_mismatch",
          "stationary left and right states use different target orders");
    }
    const std::size_t physical =
        left_backlog.target_at_target_ordinal(target).ordinal();
    if (physical >= raw_edge.action().actual_departure.bytes().size()) {
      return fail<MarkedFluxEdgeV1>(
          "c21.stationary_edge_departure_dimension_mismatch",
          "the retained actual-departure vector omits a selected target");
    }
    const std::uint8_t departure =
        raw_edge.action().actual_departure.bytes()[physical];
    if (departure > 1U) {
      return fail<MarkedFluxEdgeV1>(
          "c21.stationary_edge_nonbinary_departure",
          "the retained unit-packet departure coordinate is not binary");
    }
    departures.push_back(departure);
    BigNat arrival{0U};
    for (const ArrivalBatchEntry& entry : raw_edge.arrival().batch.entries()) {
      if (entry.queue.ordinal() == physical) {
        arrival = entry.count;
        break;
      }
    }
    arrivals.push_back(arrival);
    auto after_departure = checked_subtract(
        left_backlog.value_at_target_ordinal(target), BigNat{departure});
    if (!after_departure) {
      return fail<MarkedFluxEdgeV1>(
          "c21.stationary_edge_departure_exceeds_backlog",
          "the retained actual departure exceeds the prearrival backlog");
    }
    const BigNat endpoint =
        std::move(after_departure).value() + arrivals.back();
    if (!(endpoint == right_backlog.value_at_target_ordinal(target))) {
      return fail<MarkedFluxEdgeV1>(
          "c21.stationary_edge_queue_update_mismatch",
          "the stationary marked edge violates the exact n-D+A queue "
          "recursion",
          DiagnosticCategory::input_validation,
          {"target " + std::to_string(target)});
    }
  }
  const ArrivalPhaseIdentityV1 left_phase =
      phase_identity(decoded_left.value().arrival_phase);
  const ArrivalPhaseIdentityV1 right_phase =
      phase_identity(decoded_right.value().arrival_phase);
  if (!(left_phase == phase_identity(raw_edge.arrival().phase_before)) ||
      !(right_phase == phase_identity(raw_edge.arrival().phase_after))) {
    return fail<MarkedFluxEdgeV1>(
        "c21.stationary_edge_phase_update_mismatch",
        "the stationary endpoint phases disagree with the retained "
        "configured-arrival transition");
  }
  return Result<MarkedFluxEdgeV1>::success(MarkedFluxEdgeV1{
      stationary_left,
      stationary_right,
      std::move(prearrival),
      std::move(departures),
      std::move(arrivals),
      left_phase,
      right_phase,
      std::vector<CausalMarkV1>(raw_edge.marks().begin(),
                                raw_edge.marks().end())});
}

[[nodiscard]] std::vector<std::byte> marked_edge_key_bytes(
    const MarkedFluxEdgeV1& edge) {
  IdentityEncoder encoder;
  encoder.state(edge.pre_state);
  encoder.state(edge.successor_state);
  encoder.byte(static_cast<std::uint8_t>(edge.phase_before.family));
  encoder.framed(edge.phase_before.canonical_state);
  encoder.byte(static_cast<std::uint8_t>(edge.phase_after.family));
  encoder.framed(edge.phase_after.canonical_state);
  encoder.u64(static_cast<std::uint64_t>(
      edge.prearrival_target_backlog.size()));
  for (const BigNat& value : edge.prearrival_target_backlog) {
    encoder.text(value.to_decimal_string());
  }
  encoder.u64(static_cast<std::uint64_t>(edge.target_departures.size()));
  for (const std::uint8_t value : edge.target_departures) {
    encoder.byte(value);
  }
  encoder.u64(static_cast<std::uint64_t>(edge.target_arrivals.size()));
  for (const BigNat& value : edge.target_arrivals) {
    encoder.text(value.to_decimal_string());
  }
  encoder.u64(static_cast<std::uint64_t>(edge.marks.size()));
  for (const CausalMarkV1& mark : edge.marks) {
    encoder.byte(static_cast<std::uint8_t>(mark.reveal_stage));
    const auto id = mark.mark.mark.canonical_bytes();
    encoder.framed(std::as_bytes(std::span(id.data(), id.size())));
    encoder.text(mark.mark.value.codec.id);
    encoder.u32(mark.mark.value.codec.version);
    encoder.framed(mark.mark.value.canonical_value);
  }
  return encoder.bytes();
}

struct FluxMassInput final {
  MarkedFluxEdgeV1 edge;
  ExactRational mass;
  std::optional<std::size_t> raw_atom_index;
  std::optional<CompletedReducedEdge> raw_edge;
};

struct CoalescedFluxAtom final {
  MarkedFluxEdgeV1 edge;
  ExactRational mass;
  std::optional<std::size_t> representative_raw_atom_index;
  std::optional<CompletedReducedEdge> representative_raw_edge;
  std::vector<std::byte> canonical_key;
};

// Compare the complete mathematical C17 outcome while deliberately ignoring
// the two raw state values.  Those values retain the absolute physical clock;
// the stationary edge keys their separately audited quotient images instead.
// Internal branch/stream/SearchAccounting provenance is already excluded by
// the public value comparator used here.
[[nodiscard]] bool same_retained_edge_marks_ignoring_raw_state(
    const CompletedReducedEdge& left, const CompletedReducedEdge& right) {
  const OpportunityMark& left_opportunity = left.opportunity();
  const OpportunityMark& right_opportunity = right.opportunity();
  const ResolvedAction& left_action = left.action();
  const ResolvedAction& right_action = right.action();
  const PostClosure& left_post = left.postclosure();
  const PostClosure& right_post = right.postclosure();
  return left_opportunity.prearrival_backlog ==
             right_opportunity.prearrival_backlog &&
         left_opportunity.resolver_face == right_opportunity.resolver_face &&
         same_exact_opportunity_evidence(
             left_opportunity.exact_opportunity_evidence,
             right_opportunity.exact_opportunity_evidence) &&
         left_opportunity.opportunity == right_opportunity.opportunity &&
         left_opportunity.marks == right_opportunity.marks &&
         left_action.schedule == right_action.schedule &&
         left_action.actual_departure == right_action.actual_departure &&
         left_action.schedule_identity == right_action.schedule_identity &&
         left_action.evidence == right_action.evidence &&
         left_action.decision == right_action.decision &&
         left_action.interim_controller == right_action.interim_controller &&
         left_action.postupdate_controller_tape ==
             right_action.postupdate_controller_tape &&
         left_action.marks == right_action.marks &&
         same_arrival_transition_value(left.arrival(), right.arrival()) &&
         left_post.unresolved_patch == right_post.unresolved_patch &&
         left_post.marks == right_post.marks &&
         left.marks().size() == right.marks().size() &&
         std::equal(left.marks().begin(), left.marks().end(),
                    right.marks().begin(), right.marks().end()) &&
         left.stage_trace() == right.stage_trace();
}

[[nodiscard]] bool same_flux_atom_value(const CoalescedFluxAtom& candidate,
                                        const FluxMassInput& input) {
  if (!(candidate.edge == input.edge) ||
      candidate.representative_raw_edge.has_value() !=
          input.raw_edge.has_value()) {
    return false;
  }
  return !input.raw_edge.has_value() ||
         same_retained_edge_marks_ignoring_raw_state(
             *candidate.representative_raw_edge, *input.raw_edge);
}

[[nodiscard]] Result<std::vector<CoalescedFluxAtom>> coalesce_flux_atoms(
    std::vector<FluxMassInput> inputs) {
  std::vector<CoalescedFluxAtom> output;
  for (FluxMassInput& input : inputs) {
    if (!input.mass.is_nonnegative()) {
      return fail<std::vector<CoalescedFluxAtom>>(
          "c21.negative_stationary_edge_mass",
          "a stationary marked-edge atom has negative exact mass");
    }
    if (input.mass.is_zero()) {
      continue;
    }
    const auto found = std::find_if(
        output.begin(), output.end(), [&](const CoalescedFluxAtom& candidate) {
          return same_flux_atom_value(candidate, input);
        });
    if (found == output.end()) {
      output.push_back(CoalescedFluxAtom{
          std::move(input.edge), input.mass, input.raw_atom_index,
          std::move(input.raw_edge), {}});
      output.back().canonical_key =
          marked_edge_key_bytes(output.back().edge);
    } else {
      found->mass = found->mass + input.mass;
    }
  }
  std::stable_sort(output.begin(), output.end(),
                   [](const CoalescedFluxAtom& left,
                      const CoalescedFluxAtom& right) {
                     return byte_span_less(left.canonical_key,
                                           right.canonical_key);
                   });
  return Result<std::vector<CoalescedFluxAtom>>::success(std::move(output));
}

[[nodiscard]] Result<std::vector<stationary::detail::StationaryTemporalAtomCore>>
integrate_stationary_atoms(const EventInvariantLaw& law,
                           const AuditedResidenceProvider& provider,
                           const PositiveFiniteMean& mean,
                           const std::optional<std::size_t>
                               maximum_states_budget) {
  auto identity = require_three_way_identity(law, provider, mean);
  if (!identity) {
    return Result<std::vector<
        stationary::detail::StationaryTemporalAtomCore>>::failure(
        identity.error());
  }
  const auto& law_core = detail::C21CoreAccess::core(law);
  const ExactRational& denominator =
      *identity.value()->diagnostics.exact_value;
  std::vector<stationary::detail::StationaryTemporalAtomCore> atoms;
  for (const EventInvariantMassV1& event_mass : law_core.masses) {
    if (!event_mass.exact_mass.is_positive()) {
      continue;
    }
    const ResidenceWordRow& row =
        law_core.kernel.rows()[event_mass.state_index].word_row;
    if (!(row.entry_state() ==
          law_core.kernel.domain().states()[event_mass.state_index])) {
      return fail<std::vector<
          stationary::detail::StationaryTemporalAtomCore>>(
          "c21.stationary_word_row_entry_mismatch",
          "a residence-word row does not begin at its embedded event state");
    }
    for (std::size_t word_index = 0U; word_index < row.atoms().size();
         ++word_index) {
      const ResidenceWordRowAtomV1& word_atom = row.atoms()[word_index];
      if (!word_atom.exact_mass.is_positive()) {
        continue;
      }
      auto slot_mass = checked_divide(
          event_mass.exact_mass * word_atom.exact_mass, denominator);
      if (!slot_mass) {
        return Result<std::vector<
            stationary::detail::StationaryTemporalAtomCore>>::failure(
            slot_mass.error());
      }
      const ResidenceWord& word = word_atom.word;
      const auto edges = word.edges();
      const auto path = word.continuation_path();
      if (edges.empty() || path.size() != edges.size() + 1U ||
          word.length().value() != BigInt(edges.size()) ||
          !(word.entry_state() == row.entry_state()) ||
          !(edges.back().successor_state() == word.raw_terminal_state())) {
        return fail<std::vector<
            stationary::detail::StationaryTemporalAtomCore>>(
            "c21.invalid_stationary_residence_word",
            "a complete stationary residence has inconsistent event entry, "
            "raw terminal, edge, length, or continuation-path coordinates");
      }
      auto event_endpoint =
          temporal::detail::c20_project_time_homogeneous_stationary_state(
              law_core.kernel, word.event_endpoint());
      if (!event_endpoint) {
        return Result<std::vector<
            stationary::detail::StationaryTemporalAtomCore>>::failure(
            event_endpoint.error());
      }
      if (!law_core.kernel.domain().index_of(event_endpoint.value())
               .has_value()) {
        return fail<std::vector<
            stationary::detail::StationaryTemporalAtomCore>>(
            "c21.stationary_word_endpoint_outside_domain",
            "a residence word has no audited quotient endpoint in the "
            "finite event domain");
      }
      for (std::size_t offset = 0U; offset < edges.size(); ++offset) {
        if (maximum_states_budget.has_value() &&
            atoms.size() >= *maximum_states_budget) {
          return fail<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>(
              "c21.stationary_temporal_state_budget_exceeded",
              "the chronological stationary source exceeds the authored maximum_states grant before latent-state materialization",
              DiagnosticCategory::resource_limit);
        }
        const ReducedStateV1 raw_left = path[offset];
        const ReducedStateV1 raw_right = path[offset + 1U];
        if (!(edges[offset].pre_state() == raw_left) ||
            (offset + 1U < edges.size() &&
             !(edges[offset].successor_state() == raw_right))) {
          return fail<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>(
              "c21.stationary_word_edge_path_mismatch",
              "a residence edge is not adjacent to its declared raw "
              "continuation states");
        }
        auto stationary_left =
            temporal::detail::c20_project_time_homogeneous_stationary_state(
                law_core.kernel, raw_left);
        auto stationary_right =
            temporal::detail::c20_project_time_homogeneous_stationary_state(
                law_core.kernel, raw_right);
        if (!stationary_left) {
          return Result<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>::failure(
              stationary_left.error());
        }
        if (!stationary_right) {
          return Result<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>::failure(
              stationary_right.error());
        }
        auto entrance_labels =
            temporal::detail::c20_decode_stationary_entrance_labels(
                law_core.kernel, raw_right);
        if (!entrance_labels) {
          return Result<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>::failure(
              entrance_labels.error());
        }
        auto reward_edge = project_marked_edge(
            law_core.kernel, stationary_left.value(), edges[offset],
            stationary_right.value());
        if (!reward_edge) {
          return Result<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>::failure(
              reward_edge.error());
        }
        const auto image = numerical_image(slot_mass.value());
        if (image.second == NumericalProbabilityImageStatusV1::overflow) {
          return fail<std::vector<
              stationary::detail::StationaryTemporalAtomCore>>(
              "c21.stationary_slot_mass_overflow",
              "an exact stationary slot atom has no finite numerical image",
              DiagnosticCategory::unavailable);
        }
        atoms.push_back(stationary::detail::StationaryTemporalAtomCore{
            event_mass.state_index,
            word_index,
            BigNat{offset},
            raw_left,
            std::move(stationary_left).value(),
            edges[offset],
            raw_right,
            std::move(entrance_labels).value(),
            std::move(stationary_right).value(),
            std::move(reward_edge).value(),
            slot_mass.value(),
            image.first,
            image.second});
      }
    }
  }
  ExactRational exact_total = ExactRational::zero();
  for (const auto& atom : atoms) {
    exact_total = exact_total + atom.exact_mass;
  }
  if (!(exact_total == ExactRational::one())) {
    return fail<std::vector<stationary::detail::StationaryTemporalAtomCore>>(
        "c21.stationary_suspension_mass_not_one",
        "the exact latent (event,word,offset) suspension does not have unit "
        "mass",
        DiagnosticCategory::internal,
        {"mass " + exact_total.to_canonical_string()});
  }
  return Result<std::vector<stationary::detail::StationaryTemporalAtomCore>>::
      success(std::move(atoms));
}

[[nodiscard]] std::optional<std::size_t> stationary_atom_index(
    const std::span<const stationary::detail::StationaryTemporalAtomCore>
        atoms,
    const std::size_t event_state_index, const std::size_t word_index,
    const BigNat& offset) {
  for (std::size_t index = 0U; index < atoms.size(); ++index) {
    if (atoms[index].event_state_index == event_state_index &&
        atoms[index].word_index == word_index &&
        atoms[index].residence_offset == offset) {
      return index;
    }
  }
  return std::nullopt;
}

[[nodiscard]] std::optional<std::size_t> invariant_component_for_state(
    const stationary::detail::EventInvariantLawCore& law,
    const std::size_t event_state_index) {
  for (const std::size_t class_index :
       law.diagnostics.closed_class_indices) {
    if (class_index >= law.diagnostics.classes.size()) {
      continue;
    }
    const auto& members =
        law.diagnostics.classes[class_index].member_indices;
    if (std::find(members.begin(), members.end(), event_state_index) !=
        members.end()) {
      return class_index;
    }
  }
  return std::nullopt;
}

struct StationaryTemporalOffsetBudget final {
  std::size_t maximum_state_offset;
  std::optional<std::size_t> maximum_edge_offset;
};

[[nodiscard]] Result<std::size_t> bounded_stationary_offset(
    const BigNat& offset, const std::string_view description) {
  if (offset.bit_length() > std::numeric_limits<std::size_t>::digits) {
    return fail<std::size_t>(
        "c21.stationary_temporal_offset_budget_overflow",
        std::string(description) +
            " cannot be represented by the audited temporal source index",
        DiagnosticCategory::resource_limit,
        {"authored offset " + offset.to_decimal_string()});
  }
  const std::size_t represented = offset.value().convert_to<std::size_t>();
  if (represented == std::numeric_limits<std::size_t>::max()) {
    return fail<std::size_t>(
        "c21.stationary_temporal_offset_budget_overflow",
        std::string(description) +
            " leaves no representable completed-step successor",
        DiagnosticCategory::resource_limit,
        {"authored offset " + offset.to_decimal_string()});
  }
  return Result<std::size_t>::success(represented);
}

[[nodiscard]] Result<StationaryTemporalOffsetBudget>
stationary_temporal_offset_budget(
    const temporal::detail::C20StationarySourceBindingV1& binding) {
  const auto& capabilities = binding.capabilities;
  if (capabilities.unbounded_stationary_temporal_continuation) {
    if (!capabilities.stationary_temporal_law_route &&
        !capabilities.stationary_stopped_kernel_route) {
      return fail<StationaryTemporalOffsetBudget>(
          "c21.unowned_unbounded_temporal_capability",
          "an unbounded temporal budget is not owned by an accepted "
          "sequential temporal-law or stopped-kernel route",
          DiagnosticCategory::internal);
    }
    return Result<StationaryTemporalOffsetBudget>::success(
        StationaryTemporalOffsetBudget{
            std::numeric_limits<std::size_t>::max(),
            std::numeric_limits<std::size_t>::max()});
  }

  std::size_t maximum_state_offset = 0U;
  if (capabilities.maximum_stationary_state_offset.has_value()) {
    auto bounded = bounded_stationary_offset(
        *capabilities.maximum_stationary_state_offset,
        "the accepted stationary StateAt budget");
    if (!bounded) {
      return Result<StationaryTemporalOffsetBudget>::failure(
          bounded.error());
    }
    maximum_state_offset = bounded.value();
  }

  std::optional<std::size_t> maximum_edge_offset;
  if (capabilities.maximum_stationary_edge_offset.has_value()) {
    auto bounded = bounded_stationary_offset(
        *capabilities.maximum_stationary_edge_offset,
        "the accepted stationary EdgeMarkAt budget");
    if (!bounded) {
      return Result<StationaryTemporalOffsetBudget>::failure(
          bounded.error());
    }
    maximum_edge_offset = bounded.value();
  }

  const bool temporal_view_authorized =
      capabilities.finite_temporal_cylinder_route ||
      capabilities.stationary_temporal_law_route ||
      capabilities.stationary_stopped_kernel_route;
  if (temporal_view_authorized &&
      !capabilities.maximum_stationary_state_offset.has_value() &&
      !maximum_edge_offset.has_value()) {
    return fail<StationaryTemporalOffsetBudget>(
        "c21.stationary_temporal_budget_missing",
        "an accepted bounded stationary temporal view has no retained "
        "typed state or edge offset budget",
        DiagnosticCategory::internal);
  }
  if (capabilities.stationary_stopped_kernel_route) {
    return fail<StationaryTemporalOffsetBudget>(
        "c21.bounded_stopped_kernel_capability",
        "an accepted stopped-kernel route did not retain its genuine "
        "sequential continuation authority",
        DiagnosticCategory::internal);
  }
  return Result<StationaryTemporalOffsetBudget>::success(
      StationaryTemporalOffsetBudget{maximum_state_offset,
                                     maximum_edge_offset});
}

// Build the genuine latent chronological continuation retained by C21.  A
// node keeps the unrevealed residence suffix in its (event,word,offset)
// identity.  The construction never powers or disintegrates the stationary
// marked edge.
[[nodiscard]] Result<std::shared_ptr<const metrics::detail::TemporalSourceCore>>
build_stationary_temporal_source(
    const stationary::detail::EventInvariantLawCore& law,
    const std::span<const stationary::detail::StationaryTemporalAtomCore>
        atoms,
    const Digest256& projection_fingerprint,
    const std::optional<std::size_t> maximum_states_budget,
    const std::optional<std::size_t> maximum_row_atoms_budget) {
  if (maximum_states_budget.has_value() &&
      atoms.size() > *maximum_states_budget) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c21.stationary_temporal_state_budget_exceeded",
        "the chronological stationary source exceeds the authored maximum_states grant before materialization",
        DiagnosticCategory::resource_limit);
  }
  std::vector<metrics::detail::TemporalNodeCore> nodes;
  std::vector<metrics::detail::TemporalEntranceAtomCore> entrance;
  nodes.reserve(atoms.size());
  entrance.reserve(atoms.size());
  for (std::size_t index = 0U; index < atoms.size(); ++index) {
    nodes.push_back(metrics::detail::TemporalNodeCore{
        atoms[index].stationary_left_state, {},
        invariant_component_for_state(law, atoms[index].event_state_index),
        atoms[index].reward_edge.prearrival_target_backlog});
    entrance.push_back(metrics::detail::TemporalEntranceAtomCore{
        index, atoms[index].stationary_left_state, atoms[index].exact_mass});
  }

  for (std::size_t index = 0U; index < atoms.size(); ++index) {
    const auto& atom = atoms[index];
    if (atom.event_state_index >= law.kernel.rows().size()) {
      return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
          "c21.stationary_temporal_node_event_state_out_of_range",
          "a latent suspension node names an event state outside the "
          "embedded kernel",
          DiagnosticCategory::internal);
    }
    const auto row = law.kernel.rows()[atom.event_state_index].word_row.atoms();
    if (atom.word_index >= row.size()) {
      return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
          "c21.stationary_temporal_node_word_out_of_range",
          "a latent suspension node names a word outside its exact row",
          DiagnosticCategory::internal);
    }
    const ResidenceWord& word = row[atom.word_index].word;
    const std::size_t word_length = word.edges().size();
    const BigInt offset_value = atom.residence_offset.value();
    if (offset_value < 0 || offset_value >= BigInt(word_length)) {
      return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
          "c21.stationary_temporal_offset_out_of_range",
          "a latent suspension offset lies outside its complete word",
          DiagnosticCategory::internal);
    }
    const std::size_t offset = offset_value.convert_to<std::size_t>();
    auto& transitions = nodes[index].transitions;
    if (offset + 1U < word_length) {
      const auto successor = stationary_atom_index(
          atoms, atom.event_state_index, atom.word_index,
          BigNat{offset + 1U});
      if (!successor.has_value()) {
        return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
            "c21.stationary_temporal_interior_successor_missing",
            "an interior residence offset has no latent successor",
            DiagnosticCategory::internal);
      }
      if (!(atom.stationary_right_state ==
            atoms[*successor].stationary_left_state)) {
        return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
            "c21.stationary_temporal_interior_state_mismatch",
            "an interior residence edge does not meet its latent successor",
            DiagnosticCategory::internal);
      }
      if (maximum_row_atoms_budget.has_value() &&
          transitions.size() >= *maximum_row_atoms_budget) {
        return fail<std::shared_ptr<const
            metrics::detail::TemporalSourceCore>>(
            "c21.stationary_temporal_row_atom_budget_exceeded",
            "the chronological stationary source exceeds the authored max_row_atoms grant before transition materialization",
            DiagnosticCategory::resource_limit);
      }
      transitions.push_back(metrics::detail::TemporalTransitionCore{
          *successor, atom.reward_edge, ExactRational::one()});
    } else {
      auto projected_endpoint =
          temporal::detail::c20_project_time_homogeneous_stationary_state(
              law.kernel, word.event_endpoint());
      if (!projected_endpoint) {
        return Result<std::shared_ptr<const
            metrics::detail::TemporalSourceCore>>::failure(
                projected_endpoint.error());
      }
      const auto endpoint_index =
          law.kernel.domain().index_of(projected_endpoint.value());
      if (!endpoint_index.has_value()) {
        return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
            "c21.stationary_temporal_endpoint_outside_domain",
            "a terminal residence edge has no finite-domain endpoint",
            DiagnosticCategory::internal);
      }
      const auto next_words =
          law.kernel.rows()[*endpoint_index].word_row.atoms();
      for (std::size_t next_word = 0U; next_word < next_words.size();
           ++next_word) {
        if (next_words[next_word].exact_mass.is_zero()) {
          continue;
        }
        const auto successor = stationary_atom_index(
            atoms, *endpoint_index, next_word, BigNat{0U});
        if (!successor.has_value()) {
          return fail<std::shared_ptr<const
              metrics::detail::TemporalSourceCore>>(
              "c21.stationary_temporal_boundary_successor_missing",
              "an exact endpoint word branch has no latent offset-zero "
              "successor",
              DiagnosticCategory::internal);
        }
        if (!(atom.stationary_right_state ==
              atoms[*successor].stationary_left_state)) {
          return fail<std::shared_ptr<const
              metrics::detail::TemporalSourceCore>>(
              "c21.stationary_temporal_boundary_state_mismatch",
              "a residence terminal does not meet the next event word's "
              "offset-zero state",
              DiagnosticCategory::internal);
        }
        if (maximum_row_atoms_budget.has_value() &&
            transitions.size() >= *maximum_row_atoms_budget) {
          return fail<std::shared_ptr<const
              metrics::detail::TemporalSourceCore>>(
              "c21.stationary_temporal_row_atom_budget_exceeded",
              "the chronological stationary source exceeds the authored max_row_atoms grant before transition materialization",
              DiagnosticCategory::resource_limit);
        }
        transitions.push_back(metrics::detail::TemporalTransitionCore{
            *successor, atom.reward_edge,
            next_words[next_word].exact_mass});
      }
    }
    ExactRational row_total = ExactRational::zero();
    for (const auto& transition : transitions) {
      if (!transition.exact_mass.is_positive()) {
        return fail<std::shared_ptr<const
            metrics::detail::TemporalSourceCore>>(
            "c21.stationary_temporal_nonpositive_transition",
            "a latent temporal row retained a nonpositive transition",
            DiagnosticCategory::internal);
      }
      row_total = row_total + transition.exact_mass;
    }
    if (!(row_total == ExactRational::one())) {
      return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
          "c21.stationary_temporal_row_mass_not_one",
          "a latent chronological temporal row does not have exact unit "
          "mass",
          DiagnosticCategory::internal,
          {"row " + std::to_string(index),
           "mass " + row_total.to_canonical_string()});
    }
  }

  const auto& binding = law.binding.source;
  auto offset_budget = stationary_temporal_offset_budget(binding);
  if (!offset_budget) {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::failure(
            offset_budget.error());
  }
  metrics::detail::TemporalSourceBindingV1 source_binding{
      AuditedTemporalSourceKindV1::stationary_projection,
      binding.seal_token,
      projection_fingerprint,
      projection_fingerprint,
      binding.accepted_contract_identity,
      binding.normalized_requirements_identity,
      binding.authored_analysis_identity,
      binding.resolved_instance_identity,
      binding.target_selection_identity,
      binding.configured_arrival_identity,
      binding.selection_identity,
      binding.exact_state_schema_identity,
      binding.reduced_state_schema_identity,
      binding.mark_schema_identity,
      binding.continuation_schema_identity,
      binding.target_service_schema_identity,
      binding.timing_identity,
      binding.state_codec};
  try {
    return Result<std::shared_ptr<const
        metrics::detail::TemporalSourceCore>>::success(
        std::make_shared<const metrics::detail::TemporalSourceCore>(
            metrics::detail::TemporalSourceCore{
                std::move(source_binding), std::move(nodes),
                std::move(entrance),
                binding.capabilities.f05_authorizations,
                offset_budget.value().maximum_state_offset,
                offset_budget.value().maximum_edge_offset,
                maximum_states_budget, maximum_row_atoms_budget,
                true, true, true}));
  } catch (const std::bad_alloc&) {
    return fail<std::shared_ptr<const metrics::detail::TemporalSourceCore>>(
        "c21.stationary_temporal_source_allocation_failure",
        "materializing the latent chronological temporal source exhausted "
        "memory",
        DiagnosticCategory::resource_limit);
  }
}

[[nodiscard]] Result<StationaryTemporalDiagnosticsV1>
stationary_temporal_diagnostics(
    const std::span<const stationary::detail::StationaryTemporalAtomCore>
        atoms,
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const SolverPolicy& policy) {
  ExactRational exact_total = ExactRational::zero();
  CompensatedSum numerical_total;
  std::vector<std::pair<ArrivalPhaseIdentityV1, ExactRational>> occupation;
  for (const auto& atom : atoms) {
    exact_total = exact_total + atom.exact_mass;
    numerical_total.add(atom.numerical_mass);
    const ArrivalPhaseIdentityV1& phase = atom.reward_edge.phase_before;
    const auto found = std::find_if(
        occupation.begin(), occupation.end(),
        [&](const auto& candidate) { return candidate.first == phase; });
    if (found == occupation.end()) {
      occupation.emplace_back(phase, atom.exact_mass);
    } else {
      found->second = found->second + atom.exact_mass;
    }
  }
  std::stable_sort(occupation.begin(), occupation.end(),
                   [](const auto& left, const auto& right) {
                     return phase_less(left.first, right.first);
                   });

  const bool configured_available =
      binding.configured_stationary_phase_law.has_value();
  auto configured_phase = require_configured_slot_phase_law(
      binding.configured_stationary_phase_law);
  if (!configured_phase) {
    return Result<StationaryTemporalDiagnosticsV1>::failure(
        configured_phase.error());
  }
  std::vector<StationaryPhaseOccupationAtomV1> diagnostics;
  bool configured_matches = true;
  if (configured_available) {
    const StationaryPhaseLawDescriptor& configured =
        *binding.configured_stationary_phase_law;
    const auto configured_masses =
        configured.probabilities.normalized_weights();
    if (configured.canonical_states.size() != configured_masses.size()) {
      return fail<StationaryTemporalDiagnosticsV1>(
          "c21.configured_phase_law_dimension_mismatch",
          "the configured ordinary-slot phase law has inconsistent state "
          "and mass dimensions");
    }
    for (std::size_t index = 0U; index < configured.canonical_states.size();
         ++index) {
      const ArrivalPhaseIdentityV1 phase{
          binding.configured_arrival_binding.family,
          configured.canonical_states[index]};
      const auto found = std::find_if(
          occupation.begin(), occupation.end(),
          [&](const auto& candidate) { return candidate.first == phase; });
      const ExactRational observed =
          found == occupation.end() ? ExactRational::zero() : found->second;
      const ExactRational& expected = configured_masses[index];
      const long double observed_image = observed.to_long_double();
      const long double expected_image = expected.to_long_double();
      const long double residual = observed_image - expected_image;
      const long double bound = residual_bound(
          policy, std::fabs(observed_image) + std::fabs(expected_image));
      diagnostics.push_back(StationaryPhaseOccupationAtomV1{
          phase, observed, observed_image, expected, expected_image, residual,
          bound});
      configured_matches = configured_matches && observed == expected &&
                           std::isfinite(residual) &&
                           std::fabs(residual) <= bound;
    }
    for (const auto& [phase, mass] : occupation) {
      const bool named = std::any_of(
          configured.canonical_states.begin(),
          configured.canonical_states.end(),
          [&](const std::vector<std::byte>& candidate) {
            return phase.family == binding.configured_arrival_binding.family &&
                   phase.canonical_state == candidate;
          });
      if (!named && mass.is_positive()) {
        diagnostics.push_back(StationaryPhaseOccupationAtomV1{
            phase, mass, mass.to_long_double(), ExactRational::zero(), 0.0L,
            mass.to_long_double(),
            residual_bound(policy, std::fabs(mass.to_long_double()))});
        configured_matches = false;
      }
    }
  } else {
    diagnostics.reserve(occupation.size());
    for (const auto& [phase, mass] : occupation) {
      diagnostics.push_back(StationaryPhaseOccupationAtomV1{
          phase, mass, mass.to_long_double(), std::nullopt, std::nullopt,
          0.0L, residual_bound(policy, std::fabs(mass.to_long_double()))});
    }
  }
  if (configured_available && !configured_matches) {
    return fail<StationaryTemporalDiagnosticsV1>(
        "c21.configured_slot_phase_identity_mismatch",
        "the length-biased ordinary-slot phase occupation does not equal "
        "the configured stationary phase law (12.13a); the event-entry "
        "phase marginal is not substituted",
        DiagnosticCategory::input_validation);
  }
  return Result<StationaryTemporalDiagnosticsV1>::success(
      StationaryTemporalDiagnosticsV1{
          exact_total,
          numerical_total.value(),
          numerical_total.correction(),
          numerical_total.value() - 1.0L,
          std::move(diagnostics),
          configured_available,
          configured_matches,
          true,
          true});
}

struct MetricEnvelope final {
  Digest256 source_fingerprint;
  std::optional<ExactRational> exact_numerator;
  ExactRational exact_denominator;
  std::optional<ExactRational> exact_ratio;
  ExactRational exact_absolute_numerator;
  ExactRational exact_ratio_residual_bound;
  bool positive_infinity;
};

class EnvelopeEncoder final {
 public:
  void byte(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void u32(const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void frame(const std::span<const std::byte> value) {
    if (value.size() > std::numeric_limits<std::uint32_t>::max()) {
      throw std::length_error("C21 metric envelope field exceeds u32");
    }
    u32(static_cast<std::uint32_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void text(const std::string& value) {
    frame(std::as_bytes(std::span(value.data(), value.size())));
  }
  void rational(const ExactRational& value) {
    text(value.numerator_decimal());
    text(value.denominator_decimal());
  }
  void natural(const BigNat& value) { text(value.to_decimal_string()); }
  [[nodiscard]] std::vector<std::byte> finish() && {
    return std::move(bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] Result<MetricValue> encode_metric_envelope(
    const CodecIdentityV1& result_codec, const MetricEnvelope& envelope) {
  if (result_codec.id.empty() || result_codec.version == 0U) {
    return fail<MetricValue>("c21.invalid_metric_result_codec",
                             "a stationary metric result codec is invalid");
  }
  try {
    EnvelopeEncoder encoder;
    encoder.u32(1U);
    encoder.frame(envelope.source_fingerprint.bytes());
    encoder.byte(envelope.exact_numerator.has_value() ? 1U : 0U);
    if (envelope.exact_numerator) {
      encoder.rational(*envelope.exact_numerator);
    }
    encoder.rational(envelope.exact_denominator);
    encoder.byte(envelope.exact_ratio.has_value() ? 1U : 0U);
    if (envelope.exact_ratio) {
      encoder.rational(*envelope.exact_ratio);
    }
    encoder.rational(envelope.exact_absolute_numerator);
    encoder.rational(envelope.exact_ratio_residual_bound);
    encoder.byte(envelope.positive_infinity ? 1U : 0U);
    return Result<MetricValue>::success(
        MetricValue{result_codec, std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c21.metric_envelope_allocation_failure",
        "encoding the stationary metric envelope exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c21.metric_envelope_encoding_failure",
        "the stationary metric envelope could not be encoded",
        DiagnosticCategory::internal);
  }
}

struct BacklogMass final {
  BigNat level;
  ExactRational mass;
};

struct BacklogPmfEnvelope final {
  Digest256 source_fingerprint;
  bool complete_domain;
  std::optional<BigNat> max_level;
  std::vector<BacklogMass> atoms;
  ExactRational returned_mass;
  ExactRational omitted_tail_mass;
};

struct BacklogPgfAtom final {
  ExactRational point;
  ExactRational value;
};

struct BacklogPgfEnvelope final {
  Digest256 source_fingerprint;
  std::vector<BacklogPgfAtom> atoms;
};

struct BacklogQuantileEnvelope final {
  Digest256 source_fingerprint;
  ExactRational probability;
  DiscreteQuantileConventionV1 convention;
  BigNat quantile;
  ExactRational cdf_below;
  ExactRational cdf_at_quantile;
};

[[nodiscard]] Result<void> encode_count(EnvelopeEncoder& encoder,
                                        const std::size_t count,
                                        const std::string_view object) {
  if (count > std::numeric_limits<std::uint32_t>::max()) {
    return fail<void>(
        "c21.stationary_metric_output_too_large",
        std::string(object) +
            " exceeds the version-1 stationary metric result envelope",
        DiagnosticCategory::resource_limit);
  }
  encoder.u32(static_cast<std::uint32_t>(count));
  return Result<void>::success();
}

[[nodiscard]] Result<MetricValue> encode_backlog_pmf_envelope(
    const BacklogPmfEnvelope& envelope) {
  try {
    EnvelopeEncoder encoder;
    encoder.u32(1U);
    encoder.frame(envelope.source_fingerprint.bytes());
    encoder.byte(envelope.complete_domain ? 0U : 1U);
    if (!envelope.complete_domain) {
      if (!envelope.max_level.has_value()) {
        return fail<MetricValue>(
            "c21.stationary_pmf_domain_inconsistent",
            "a finite stationary PMF output window has no maximum level",
            DiagnosticCategory::internal);
      }
      encoder.natural(*envelope.max_level);
    }
    auto count = encode_count(encoder, envelope.atoms.size(),
                              "the stationary backlog PMF");
    if (!count) {
      return Result<MetricValue>::failure(count.error());
    }
    for (const BacklogMass& atom : envelope.atoms) {
      encoder.natural(atom.level);
      encoder.rational(atom.mass);
    }
    encoder.rational(envelope.returned_mass);
    encoder.rational(envelope.omitted_tail_mass);
    return Result<MetricValue>::success(MetricValue{
        {"mwperf.c21.stationary_backlog_pmf", 1U},
        std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c21.stationary_pmf_encoding_allocation_failure",
        "encoding the exact stationary backlog PMF exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c21.stationary_pmf_encoding_failure",
        "the exact stationary backlog PMF could not be encoded",
        DiagnosticCategory::internal);
  }
}

[[nodiscard]] Result<MetricValue> encode_backlog_pgf_envelope(
    const BacklogPgfEnvelope& envelope) {
  try {
    EnvelopeEncoder encoder;
    encoder.u32(1U);
    encoder.frame(envelope.source_fingerprint.bytes());
    auto count = encode_count(encoder, envelope.atoms.size(),
                              "the stationary backlog PGF");
    if (!count) {
      return Result<MetricValue>::failure(count.error());
    }
    for (const BacklogPgfAtom& atom : envelope.atoms) {
      encoder.rational(atom.point);
      encoder.rational(atom.value);
    }
    return Result<MetricValue>::success(MetricValue{
        {"mwperf.c21.stationary_backlog_pgf", 1U},
        std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c21.stationary_pgf_encoding_allocation_failure",
        "encoding the exact stationary backlog PGF exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c21.stationary_pgf_encoding_failure",
        "the exact stationary backlog PGF could not be encoded",
        DiagnosticCategory::internal);
  }
}

[[nodiscard]] Result<MetricValue> encode_backlog_quantile_envelope(
    const BacklogQuantileEnvelope& envelope) {
  try {
    EnvelopeEncoder encoder;
    encoder.u32(1U);
    encoder.frame(envelope.source_fingerprint.bytes());
    encoder.rational(envelope.probability);
    encoder.byte(static_cast<std::uint8_t>(envelope.convention));
    encoder.natural(envelope.quantile);
    encoder.rational(envelope.cdf_below);
    encoder.rational(envelope.cdf_at_quantile);
    return Result<MetricValue>::success(MetricValue{
        {"mwperf.c21.stationary_backlog_quantile", 1U},
        std::move(encoder).finish()});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c21.stationary_quantile_encoding_allocation_failure",
        "encoding the exact stationary backlog quantile exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c21.stationary_quantile_encoding_failure",
        "the exact stationary backlog quantile could not be encoded",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<MetricValue> suspend_event_law_to_slots(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean, const RewardDecoder& decoder) {
  try {
    auto identity = require_three_way_identity(law, provider, mean);
    if (!identity) {
      return Result<MetricValue>::failure(identity.error());
    }
    const auto& law_core = detail::C21CoreAccess::core(law);
    const bool reward_route_accepted =
        decoder.domain == StationaryRewardDomainV1::state
            ? law_core.binding.source.capabilities.stationary_invariant_route
            : law_core.binding.source.capabilities
                  .stationary_edge_reward_route;
    if (!reward_route_accepted) {
      return fail<MetricValue>(
          "c21.stationary_reward_capability_not_accepted",
          "the accepted C14 contract does not authorize the C21 stationary "
          "reward route",
          DiagnosticCategory::unavailable);
    }
    if (!decoder.decode || decoder.result_codec.id.empty() ||
        decoder.result_codec.version == 0U) {
      return fail<MetricValue>("c21.invalid_reward_decoder",
                               "the stationary reward decoder or result "
                               "codec is invalid");
    }
    if (decoder.requires_temporal_continuation) {
      return fail<MetricValue>(
          "c14_capability_missing_temporal_continuation",
          "F-C21-03 evaluates per-slot state or one-edge rewards; a request "
          "requiring temporal continuation must use an available audited "
          "temporal view",
          DiagnosticCategory::unavailable);
    }
    if (decoder.domain == StationaryRewardDomainV1::state &&
        !decoder.required_marks.empty()) {
      return fail<MetricValue>(
          "c21.state_reward_requires_edge_mark",
          "a state-only reward cannot declare completed-edge mark "
          "requirements");
    }
    auto atoms = integrate_stationary_atoms(
        law, provider, mean, std::nullopt);
    if (!atoms) {
      return Result<MetricValue>::failure(atoms.error());
    }
    auto temporal_diagnostics = stationary_temporal_diagnostics(
        atoms.value(), law_core.binding.source, law_core.policy);
    if (!temporal_diagnostics) {
      return Result<MetricValue>::failure(temporal_diagnostics.error());
    }

    ExactRational numerator = ExactRational::zero();
    ExactRational absolute_numerator = ExactRational::zero();
    CompensatedSum numerical_numerator;
    bool positive_infinity = false;
    for (const auto& atom : atoms.value()) {
      if (decoder.domain == StationaryRewardDomainV1::one_edge &&
          !edge_has_required_marks(atom.reward_edge,
                                   decoder.required_marks)) {
        return fail<MetricValue>(
            "c14_capability_missing_mark",
            "a stationary residence slot lacks a required mark identity, "
            "codec, or causal reveal-stage bound",
            DiagnosticCategory::unavailable);
      }
      const StationaryRewardArgumentV1 argument{
          atom.stationary_left_state,
          decoder.domain == StationaryRewardDomainV1::one_edge
              ? &atom.reward_edge
              : nullptr};
      auto decoded = decoder.decode(argument);
      if (!decoded) {
        return Result<MetricValue>::failure(decoded.error());
      }
      const long double reward = decoded.value();
      if (std::isnan(reward) ||
          (decoder.integrability ==
               StationaryRewardIntegrabilityV1::finite_absolute &&
           !std::isfinite(reward)) ||
          (decoder.integrability ==
               StationaryRewardIntegrabilityV1::nonnegative_extended_real &&
           reward < 0.0L)) {
        return fail<MetricValue>(
            "c21.reward_integrability_not_established",
            "the decoded stationary reward violates its declared signed or "
            "nonnegative integrability class",
            DiagnosticCategory::unavailable);
      }
      if (std::isinf(reward)) {
        positive_infinity = true;
        continue;
      }
      auto exact_reward = exact_long_double(reward);
      if (!exact_reward) {
        return Result<MetricValue>::failure(exact_reward.error());
      }
      // atom.exact_mass already includes division by Lbar.  Multiplying by
      // the common denominator reconstructs the raw renewal-reward
      // numerator, which is recorded separately in the result envelope.
      const ExactRational raw_weight =
          atom.exact_mass * *identity.value()->diagnostics.exact_value;
      const ExactRational term = raw_weight * exact_reward.value();
      numerator = numerator + term;
      absolute_numerator =
          absolute_numerator + raw_weight * absolute_value(exact_reward.value());
      numerical_numerator.add(term.to_long_double());
    }
    const ExactRational& denominator =
        *identity.value()->diagnostics.exact_value;
    if (positive_infinity) {
      if (decoder.integrability !=
          StationaryRewardIntegrabilityV1::nonnegative_extended_real) {
        return fail<MetricValue>(
            "c21.signed_reward_not_absolutely_integrable",
            "a signed stationary reward has no established finite absolute "
            "integral",
            DiagnosticCategory::unavailable);
      }
      return encode_metric_envelope(
          decoder.result_codec,
          MetricEnvelope{mean.fingerprint(), std::nullopt, denominator,
                         std::nullopt, absolute_numerator,
                         ExactRational::zero(), true});
    }
    auto ratio = checked_divide(numerator, denominator);
    if (!ratio) {
      return Result<MetricValue>::failure(ratio.error());
    }
    const long double numerical_ratio =
        numerical_numerator.value() / mean.numerical_value();
    const long double exact_ratio_image = ratio.value().to_long_double();
    if (!std::isfinite(numerical_ratio) ||
        !std::isfinite(exact_ratio_image) ||
        !std::isfinite(absolute_numerator.to_long_double())) {
      return fail<MetricValue>(
          "c21.stationary_reward_numerically_unresolved",
          "the exact stationary reward has no finite ratio or absolute-"
          "integral image",
          DiagnosticCategory::unavailable);
    }
    const long double actual_ratio_residual =
        std::fabs(numerical_ratio - exact_ratio_image);
    const long double epsilon =
        std::numeric_limits<long double>::epsilon();
    const long double rounding_allowance =
        epsilon + epsilon * std::fabs(numerical_ratio) +
        epsilon * std::fabs(exact_ratio_image);
    const long double residual_with_rounding =
        actual_ratio_residual + rounding_allowance;
    if (!std::isfinite(actual_ratio_residual) ||
        !std::isfinite(rounding_allowance) ||
        !std::isfinite(residual_with_rounding)) {
      return fail<MetricValue>(
          "c21.stationary_reward_numerically_unresolved",
          "the stationary reward ratio residual exceeds the promoted "
          "numerical range",
          DiagnosticCategory::unavailable);
    }
    auto exact_residual_bound = nonnegative_long_double_upper_bound(
        residual_with_rounding);
    if (!exact_residual_bound) {
      return Result<MetricValue>::failure(exact_residual_bound.error());
    }
    return encode_metric_envelope(
        decoder.result_codec,
        MetricEnvelope{mean.fingerprint(), numerator, denominator,
                       ratio.value(), absolute_numerator,
                       exact_residual_bound.value(), false});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c21.stationary_reward_allocation_failure",
        "evaluating the stationary suspension reward exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c21.stationary_reward_exception",
        "stationary suspension reward evaluation raised an unexpected "
        "exception",
        DiagnosticCategory::internal);
  }
}

namespace {

[[nodiscard]] Result<Digest256> projection_fingerprint(
    const stationary::detail::EventInvariantLawCore& law,
    const PositiveFiniteMean& mean,
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const std::span<const stationary::detail::StationaryTemporalAtomCore>
        atoms) {
  IdentityEncoder encoder;
  encoder.u32(1U);
  encoder.digest(law.fingerprint);
  encoder.digest(mean.fingerprint());
  encoder.digest(binding.provider_romr_identity);
  encoder.digest(binding.execution_seal_identity);
  encoder.digest(binding.descriptor_identity);
  encoder.digest(binding.accepted_contract_identity);
  encoder.digest(binding.normalized_requirements_identity);
  encoder.digest(binding.selection_identity);
  encoder.digest(binding.authored_analysis_identity);
  encoder.digest(binding.configured_arrival_identity);
  encoder.digest(binding.configured_arrival_view_identity);
  encoder.digest(binding.configured_arrival_law_identity);
  encoder.digest(binding.configured_arrival_catalog_identity);
  encoder.digest(binding.exact_state_schema_identity);
  encoder.digest(binding.reduced_state_schema_identity);
  encoder.digest(binding.ownership_schema_identity);
  encoder.digest(binding.exact_update_schema_identity);
  encoder.digest(binding.mark_schema_identity);
  encoder.digest(binding.timing_identity);
  encoder.digest(binding.continuation_schema_identity);
  encoder.digest(binding.target_selection_identity);
  encoder.digest(binding.target_service_schema_identity);
  encoder.digest(law.binding.finite_event_domain_identity);
  encoder.digest(law.binding.finite_event_domain_content_identity);
  encoder.digest(law.binding.embedded_kernel_identity);
  encoder.u64(static_cast<std::uint64_t>(atoms.size()));
  for (const auto& atom : atoms) {
    encoder.u64(static_cast<std::uint64_t>(atom.event_state_index));
    encoder.u64(static_cast<std::uint64_t>(atom.word_index));
    encoder.text(atom.residence_offset.to_decimal_string());
    encoder.state(atom.stationary_left_state);
    encoder.state(atom.stationary_right_state);
    encoder.rational(atom.exact_mass);
    encoder.u64(static_cast<std::uint64_t>(atom.entrance_labels.size()));
    for (const RuntimeDecodedMarkV1& label : atom.entrance_labels) {
      const auto id = label.mark.canonical_bytes();
      encoder.framed(std::as_bytes(std::span(id.data(), id.size())));
      encoder.text(label.value.codec.id);
      encoder.u32(label.value.codec.version);
      encoder.framed(label.value.canonical_value);
    }
    const std::vector<std::byte> edge_key =
        marked_edge_key_bytes(atom.reward_edge);
    encoder.framed(edge_key);
  }
  return encoder.finish("mwperf.c21.stationary-temporal-projection.v1");
}

[[nodiscard]] std::vector<StationaryStateMassV1> state_marginal(
    const std::span<const StationaryMarkedEdgeAtomV1> atoms,
    const bool left) {
  std::vector<StationaryStateMassV1> result;
  for (const StationaryMarkedEdgeAtomV1& atom : atoms) {
    const ReducedStateV1& state =
        left ? atom.stationary_left_state : atom.stationary_right_state;
    const auto found = std::find_if(
        result.begin(), result.end(),
        [&](const StationaryStateMassV1& candidate) {
          return candidate.state == state;
        });
    if (found == result.end()) {
      const auto image = numerical_image(atom.exact_mass);
      result.push_back(StationaryStateMassV1{
          state, atom.exact_mass, image.first, image.second});
    } else {
      found->exact_mass = found->exact_mass + atom.exact_mass;
      const auto image = numerical_image(found->exact_mass);
      found->numerical_mass = image.first;
      found->numerical_image_status = image.second;
    }
  }
  std::stable_sort(result.begin(), result.end(),
                   [](const StationaryStateMassV1& a,
                      const StationaryStateMassV1& b) {
                     return state_less(a.state, b.state);
                   });
  return result;
}

[[nodiscard]] bool exact_marginals_equal(
    const std::span<const StationaryStateMassV1> left,
    const std::span<const StationaryStateMassV1> right) {
  if (left.size() != right.size()) {
    return false;
  }
  for (std::size_t index = 0U; index < left.size(); ++index) {
    if (!(left[index].state == right[index].state) ||
        !(left[index].exact_mass == right[index].exact_mass)) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] Result<std::shared_ptr<const
                                      stationary::detail::StationaryMarkedEdgeCore>>
build_marked_edge_core(
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        source) {
  std::vector<FluxMassInput> flux_inputs;
  flux_inputs.reserve(source->atoms.size());
  for (std::size_t index = 0U; index < source->atoms.size(); ++index) {
    flux_inputs.push_back(FluxMassInput{
        source->atoms[index].reward_edge, source->atoms[index].exact_mass,
        index, source->atoms[index].raw_edge});
  }
  auto coalesced = coalesce_flux_atoms(std::move(flux_inputs));
  if (!coalesced) {
    return Result<std::shared_ptr<const
        stationary::detail::StationaryMarkedEdgeCore>>::failure(
        coalesced.error());
  }
  std::vector<StationaryMarkedEdgeAtomV1> atoms;
  atoms.reserve(coalesced.value().size());
  ExactRational exact_total = ExactRational::zero();
  CompensatedSum numerical_total;
  for (const CoalescedFluxAtom& atom : coalesced.value()) {
    if (!atom.representative_raw_atom_index.has_value() ||
        *atom.representative_raw_atom_index >= source->atoms.size()) {
      return fail<std::shared_ptr<const
          stationary::detail::StationaryMarkedEdgeCore>>(
          "c21.stationary_edge_raw_provenance_missing",
          "a coalesced stationary edge has no retained raw residence "
          "representative",
          DiagnosticCategory::internal);
    }
    const auto& raw = source->atoms[*atom.representative_raw_atom_index];
    const auto image = numerical_image(atom.mass);
    atoms.push_back(StationaryMarkedEdgeAtomV1{
        atom.edge.pre_state, raw.raw_edge, atom.edge.successor_state,
        atom.mass, image.first, image.second});
    exact_total = exact_total + atom.mass;
    numerical_total.add(image.first);
  }
  std::vector<StationaryStateMassV1> left = state_marginal(atoms, true);
  std::vector<StationaryStateMassV1> right = state_marginal(atoms, false);
  const bool marginals_equal = exact_marginals_equal(left, right);

  std::vector<StationaryConditionalMarkedRowV1> conditional_rows;
  std::vector<StationaryEndpointRowV1> endpoint_rows;
  long double maximum_left_right_residual = 0.0L;
  long double maximum_endpoint_residual = 0.0L;
  for (const StationaryStateMassV1& state_mass : left) {
    std::vector<StationaryConditionalMarkedAtomV1> marked_atoms;
    struct EndpointAccumulator final {
      ReducedStateV1 state;
      ExactRational mass;
    };
    std::vector<EndpointAccumulator> endpoints;
    ExactRational marked_total = ExactRational::zero();
    for (std::size_t edge_index = 0U; edge_index < atoms.size();
         ++edge_index) {
      if (!(atoms[edge_index].stationary_left_state == state_mass.state)) {
        continue;
      }
      auto conditional = checked_divide(atoms[edge_index].exact_mass,
                                        state_mass.exact_mass);
      if (!conditional) {
        return Result<std::shared_ptr<const
            stationary::detail::StationaryMarkedEdgeCore>>::failure(
            conditional.error());
      }
      const auto image = numerical_image(conditional.value());
      marked_atoms.push_back(StationaryConditionalMarkedAtomV1{
          edge_index, conditional.value(), image.first, image.second});
      marked_total = marked_total + conditional.value();
      const auto found = std::find_if(
          endpoints.begin(), endpoints.end(), [&](const auto& candidate) {
            return candidate.state ==
                   atoms[edge_index].stationary_right_state;
          });
      if (found == endpoints.end()) {
        endpoints.push_back(EndpointAccumulator{
            atoms[edge_index].stationary_right_state,
            atoms[edge_index].exact_mass});
      } else {
        found->mass = found->mass + atoms[edge_index].exact_mass;
      }
    }
    if (!(marked_total == ExactRational::one())) {
      return fail<std::shared_ptr<const
          stationary::detail::StationaryMarkedEdgeCore>>(
          "c21.stationary_conditional_row_mass_not_one",
          "a positive stationary marked row does not have exact unit "
          "conditional mass",
          DiagnosticCategory::internal);
    }
    conditional_rows.push_back(StationaryConditionalMarkedRowV1{
        state_mass.state, state_mass.exact_mass,
        state_mass.numerical_mass, std::move(marked_atoms), marked_total,
        marked_total.to_long_double()});
    std::stable_sort(endpoints.begin(), endpoints.end(),
                     [](const auto& a, const auto& b) {
                       return state_less(a.state, b.state);
                     });
    std::vector<StationaryEndpointAtomV1> endpoint_atoms;
    ExactRational endpoint_total = ExactRational::zero();
    for (const EndpointAccumulator& endpoint : endpoints) {
      auto conditional = checked_divide(endpoint.mass, state_mass.exact_mass);
      if (!conditional) {
        return Result<std::shared_ptr<const
            stationary::detail::StationaryMarkedEdgeCore>>::failure(
            conditional.error());
      }
      const auto image = numerical_image(conditional.value());
      endpoint_atoms.push_back(StationaryEndpointAtomV1{
          endpoint.state, conditional.value(), image.first, image.second});
      endpoint_total = endpoint_total + conditional.value();
    }
    if (!(endpoint_total == ExactRational::one())) {
      return fail<std::shared_ptr<const
          stationary::detail::StationaryMarkedEdgeCore>>(
          "c21.stationary_endpoint_row_mass_not_one",
          "the endpoint pushforward of a positive marked row does not have "
          "unit conditional mass",
          DiagnosticCategory::internal);
    }
    endpoint_rows.push_back(StationaryEndpointRowV1{
        state_mass.state, state_mass.exact_mass,
        state_mass.numerical_mass, std::move(endpoint_atoms), endpoint_total,
        endpoint_total.to_long_double()});
  }
  for (const StationaryStateMassV1& left_atom : left) {
    const auto found = std::find_if(
        right.begin(), right.end(), [&](const StationaryStateMassV1& item) {
          return item.state == left_atom.state;
        });
    const long double right_mass =
        found == right.end() ? 0.0L : found->numerical_mass;
    maximum_left_right_residual = std::max(
        maximum_left_right_residual,
        std::fabs(left_atom.numerical_mass - right_mass));
    maximum_endpoint_residual = std::max(
        maximum_endpoint_residual,
        std::fabs(left_atom.numerical_mass - right_mass));
  }
  const bool exact_mass_one = exact_total == ExactRational::one();
  if (!exact_mass_one || !marginals_equal) {
    return fail<std::shared_ptr<const
        stationary::detail::StationaryMarkedEdgeCore>>(
        "c21.stationary_edge_invariance_failure",
        "the stationary marked edge fails exact mass, marginal, or endpoint "
        "invariance",
        DiagnosticCategory::internal);
  }
  auto core = std::make_shared<const
                               stationary::detail::StationaryMarkedEdgeCore>(
      stationary::detail::StationaryMarkedEdgeCore{
          source,
          std::move(atoms),
          std::move(left),
          std::move(right),
          std::move(conditional_rows),
          std::move(endpoint_rows),
          StationaryMarkedEdgeDiagnosticsV1{
              exact_total,
              numerical_total.value(),
              numerical_total.correction(),
              numerical_total.value() - 1.0L,
              maximum_left_right_residual,
              maximum_endpoint_residual,
              marginals_equal,
              true,
              marginals_equal,
              true,
              std::nullopt},
          source->fingerprint});
  return Result<std::shared_ptr<const
      stationary::detail::StationaryMarkedEdgeCore>>::success(
      std::move(core));
}

[[nodiscard]] StationaryProjectionUnavailableV1 unavailable(
    const StationaryProjectionUnavailableKindV1 kind, std::string code,
    std::string message) {
  return StationaryProjectionUnavailableV1{
      kind, std::move(code), std::move(message)};
}

template <typename Predicate>
[[nodiscard]] bool has_accepted_route_clause(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const BackendRouteKindV1 backend, Predicate predicate) {
  for (const ResolvedMetricContractV1& contract :
       binding.accepted_metric_contracts) {
    if (contract.backend_route != backend) {
      continue;
    }
    const auto clause = std::find_if(
        binding.accepted_requirements.clauses().begin(),
        binding.accepted_requirements.clauses().end(),
        [&](const MetricRequirementClause& candidate) {
          return candidate.origin.clause_id == contract.clause_id;
        });
    if (clause == binding.accepted_requirements.clauses().end()) {
      continue;
    }
    for (const MetricRouteAlternativeV1& route :
         clause->route_alternatives) {
      if (route.access.backend_route == backend &&
          predicate(*clause, route)) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] bool requests_admission_fifo_views(
    const temporal::detail::C20StationarySourceBindingV1& binding) {
  return has_accepted_route_clause(
      binding, BackendRouteKindV1::palm_or_fifo_law,
      [](const MetricRequirementClause& clause,
         const MetricRouteAlternativeV1& route) {
        const bool fifo_kind =
            clause.origin.kind == MetricKindV1::fifo_delay ||
            clause.origin.kind == MetricKindV1::fifo_delay_conditioned ||
            clause.origin.kind == MetricKindV1::joint_delay;
        return fifo_kind &&
               route.semantic.entrance ==
                   EntranceLawRequirementV1::admission_palm &&
               std::holds_alternative<StoppedPathRequirementV1>(
                   route.semantic.law);
      });
}

[[nodiscard]] Result<std::vector<
    stationary::detail::PredictiveServiceAtomCore>> service_atoms(
    const std::shared_ptr<const
                          stationary::detail::StationaryProjectionSourceCore>&
        source) {
  std::vector<stationary::detail::PredictiveServiceAtomCore> result;
  result.reserve(source->atoms.size());
  std::vector<StationaryMarkedEdgeAtomV1> edge_atoms;
  edge_atoms.reserve(source->atoms.size());
  for (const auto& atom : source->atoms) {
    edge_atoms.push_back(StationaryMarkedEdgeAtomV1{
        atom.stationary_left_state, atom.raw_edge,
        atom.stationary_right_state, atom.exact_mass,
        atom.numerical_mass, atom.numerical_image_status});
  }
  const std::vector<StationaryStateMassV1> left =
      state_marginal(edge_atoms, true);
  for (std::size_t index = 0U; index < source->atoms.size(); ++index) {
    const auto& atom = source->atoms[index];
    if (atom.reward_edge.target_departures.empty() ||
        atom.reward_edge.target_departures.size() !=
            source->provider_binding.target_selection.ordered_targets.size() ||
        std::any_of(atom.reward_edge.target_departures.begin(),
                    atom.reward_edge.target_departures.end(),
                    [](const std::uint8_t value) { return value > 1U; })) {
      return fail<std::vector<
          stationary::detail::PredictiveServiceAtomCore>>(
          "c21.predictive_service_split_shape_mismatch",
          "the accepted FIFO service route requires one retained binary "
          "actual-departure coordinate for every ordered metric target",
          DiagnosticCategory::unavailable);
    }
    const auto row = std::find_if(
        left.begin(), left.end(), [&](const StationaryStateMassV1& candidate) {
          return candidate.state == atom.stationary_left_state;
        });
    if (row == left.end() || !row->exact_mass.is_positive()) {
      return fail<std::vector<
          stationary::detail::PredictiveServiceAtomCore>>(
          "c21.predictive_service_left_mass_missing",
          "a positive chronological service atom has no positive stationary "
          "left-state mass",
          DiagnosticCategory::internal);
    }
    auto conditional = checked_divide(atom.exact_mass, row->exact_mass);
    if (!conditional) {
      return Result<std::vector<
          stationary::detail::PredictiveServiceAtomCore>>::failure(
          conditional.error());
    }
    for (std::size_t target = 0U;
         target < atom.reward_edge.target_departures.size(); ++target) {
      result.push_back(stationary::detail::PredictiveServiceAtomCore{
          index, target, atom.stationary_left_state,
          atom.stationary_right_state,
          atom.reward_edge.target_departures[target], row->exact_mass,
          atom.exact_mass, conditional.value(), atom.raw_edge});
    }
  }
  for (const StationaryStateMassV1& row : left) {
    for (std::size_t target = 0U;
         target < source->provider_binding.target_selection.ordered_targets.size();
         ++target) {
      ExactRational row_total = ExactRational::zero();
      for (const auto& atom : result) {
        if (atom.target_ordinal == target &&
            atom.stationary_left_state == row.state) {
          row_total = row_total + atom.exact_conditional_mass;
        }
      }
      if (!(row_total == ExactRational::one())) {
        return fail<std::vector<
            stationary::detail::PredictiveServiceAtomCore>>(
            "c21.predictive_service_row_mass_not_one",
            "the exact P0+P1 service continuation does not have unit mass "
            "on a positive stationary predictive row",
            DiagnosticCategory::internal,
            {"target ordinal " + std::to_string(target),
             "row mass " + row_total.to_canonical_string()});
      }
    }
  }
  return Result<std::vector<
      stationary::detail::PredictiveServiceAtomCore>>::success(
      std::move(result));
}

}  // namespace

namespace {

[[nodiscard]] Result<StationaryTemporalProjection>
build_stationary_temporal_projection_impl(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean,
    const std::optional<std::size_t> maximum_states_budget,
    const std::optional<std::size_t> maximum_row_atoms_budget,
    std::size_t* const actual_state_count,
    std::size_t* const actual_maximum_row_atoms) {
  try {
    auto identity = require_three_way_identity(law, provider, mean);
    if (!identity) {
      return Result<StationaryTemporalProjection>::failure(identity.error());
    }
    const auto& law_core = detail::C21CoreAccess::core(law);
    auto integrated = integrate_stationary_atoms(
        law, provider, mean, maximum_states_budget);
    if (!integrated) {
      return Result<StationaryTemporalProjection>::failure(
          integrated.error());
    }
    auto temporal_diagnostics = stationary_temporal_diagnostics(
        integrated.value(), law_core.binding.source, law_core.policy);
    if (!temporal_diagnostics) {
      return Result<StationaryTemporalProjection>::failure(
          temporal_diagnostics.error());
    }
    auto fingerprint = projection_fingerprint(
        law_core, mean, law_core.binding.source, integrated.value());
    if (!fingerprint) {
      return Result<StationaryTemporalProjection>::failure(
          fingerprint.error());
    }
    auto chronological_source = build_stationary_temporal_source(
        law_core, integrated.value(), fingerprint.value(),
        maximum_states_budget, maximum_row_atoms_budget);
    if (!chronological_source) {
      return Result<StationaryTemporalProjection>::failure(
          chronological_source.error());
    }
    if (actual_state_count != nullptr) {
      *actual_state_count = chronological_source.value()->nodes.size();
    }
    if (actual_maximum_row_atoms != nullptr) {
      *actual_maximum_row_atoms = 0U;
      for (const auto& node : chronological_source.value()->nodes) {
        *actual_maximum_row_atoms = std::max(
            *actual_maximum_row_atoms, node.transitions.size());
      }
    }
    auto source = std::make_shared<const
                                   stationary::detail::StationaryProjectionSourceCore>(
        stationary::detail::StationaryProjectionSourceCore{
            law, provider, mean, law_core.binding.source,
            std::move(integrated).value(), chronological_source.value(),
            fingerprint.value()});
    auto temporal_core = std::make_shared<const
        stationary::detail::StationaryTemporalLawCore>(
        stationary::detail::StationaryTemporalLawCore{
            source, std::move(temporal_diagnostics).value(),
            fingerprint.value()});
    StationaryTemporalLaw temporal_law =
        detail::C21CoreAccess::temporal_law(std::move(temporal_core));
    auto edge_core = build_marked_edge_core(source);
    if (!edge_core) {
      return Result<StationaryTemporalProjection>::failure(edge_core.error());
    }
    StationaryMarkedEdge marked_edge =
        detail::C21CoreAccess::marked_edge(edge_core.value());

    auto minted = temporal::detail::c20_mint_stationary_projection_views(
        law_core.kernel, provider, source, chronological_source.value(),
        fingerprint.value());
    if (!minted) {
      return Result<StationaryTemporalProjection>::failure(minted.error());
    }
    if (minted.value().projection_fingerprint != fingerprint.value()) {
      return fail<StationaryTemporalProjection>(
          "c21.audited_projection_mint_fingerprint_mismatch",
          "the private C20 stationary mint returned a foreign projection "
          "fingerprint",
          DiagnosticCategory::internal);
    }
    const auto& facts = law_core.binding.source.capabilities;
    const bool expects_cylinder = facts.finite_temporal_cylinder_route;
    const bool expects_temporal_law =
        facts.stationary_temporal_law_route;
    const bool expects_temporal_kernel =
        facts.stationary_stopped_kernel_route;
    if ((expects_cylinder &&
         !minted.value().cylinder_law.has_value()) ||
        (expects_temporal_law && !minted.value().temporal_law.has_value()) ||
        (expects_temporal_kernel &&
         !minted.value().temporal_kernel.has_value())) {
      return fail<StationaryTemporalProjection>(
          "c21.required_audited_projection_view_unavailable",
          "an accepted C14 temporal route could not be atomically restricted "
          "by the private stationary-projection mint",
          DiagnosticCategory::unavailable);
    }
    if (minted.value().cylinder_law) {
      auto match =
          temporal::detail::c20_require_stationary_projection_view_match(
              law_core.kernel, provider, source,
              chronological_source.value(), fingerprint.value(),
              *minted.value().cylinder_law);
      if (!match) {
        return Result<StationaryTemporalProjection>::failure(match.error());
      }
    }
    if (minted.value().temporal_law) {
      auto match =
          temporal::detail::c20_require_stationary_projection_view_match(
              law_core.kernel, provider, source,
              chronological_source.value(), fingerprint.value(),
              *minted.value().temporal_law);
      if (!match) {
        return Result<StationaryTemporalProjection>::failure(match.error());
      }
    }
    if (minted.value().temporal_kernel) {
      auto match =
          temporal::detail::c20_require_stationary_projection_view_match(
              law_core.kernel, provider, source,
              chronological_source.value(), fingerprint.value(),
              *minted.value().temporal_kernel);
      if (!match) {
        return Result<StationaryTemporalProjection>::failure(match.error());
      }
    }

    StationaryProjectionSlotV1<AuditedCylinderLaw> cylinder_slot =
        expects_cylinder && minted.value().cylinder_law
            ? StationaryProjectionSlotV1<AuditedCylinderLaw>{
                  *minted.value().cylinder_law}
            : StationaryProjectionSlotV1<AuditedCylinderLaw>{unavailable(
                  StationaryProjectionUnavailableKindV1::unrequested,
                  "c21.cylinder_law_unrequested",
                  "the accepted plan did not request a finite cylinder "
                  "restriction")};
    StationaryProjectionSlotV1<AuditedTemporalLaw> temporal_law_slot =
        expects_temporal_law && minted.value().temporal_law
            ? StationaryProjectionSlotV1<AuditedTemporalLaw>{
                  *minted.value().temporal_law}
            : StationaryProjectionSlotV1<AuditedTemporalLaw>{unavailable(
                  StationaryProjectionUnavailableKindV1::unrequested,
                  "c21.audited_temporal_law_unrequested",
                  "the accepted plan did not request an audited generic "
                  "temporal-law restriction")};
    StationaryProjectionSlotV1<AuditedTemporalKernel> kernel_slot =
        expects_temporal_kernel && minted.value().temporal_kernel
            ? StationaryProjectionSlotV1<AuditedTemporalKernel>{
                  *minted.value().temporal_kernel}
            : StationaryProjectionSlotV1<AuditedTemporalKernel>{unavailable(
                  StationaryProjectionUnavailableKindV1::unrequested,
                  "c21.temporal_kernel_unrequested",
                  "the accepted plan did not request a stationary temporal "
                  "kernel restriction")};

    StationaryProjectionSlotV1<InitialLaw> initial_slot = unavailable(
        StationaryProjectionUnavailableKindV1::unrequested,
        "c21.stationary_initial_law_unrequested",
        "the accepted plan did not request a stationary stopped entrance");
    if (facts.stationary_stopped_entrance_route) {
      auto initial_core =
          std::make_shared<const metrics::detail::InitialLawCore>(
              metrics::detail::InitialLawCore{
                  InitialLawKindV1::stationary,
                  chronological_source.value(),
                  chronological_source.value()->stationary_entrance,
                  fingerprint.value(), fingerprint.value(), true});
      initial_slot =
          detail::C21CoreAccess::initial_law(std::move(initial_core));
    }

    StationaryProjectionSlotV1<PredictiveServiceSplit> split_slot =
        unavailable(StationaryProjectionUnavailableKindV1::unrequested,
                    "c21.predictive_service_split_unrequested",
                    "the accepted plan did not request FIFO tag "
                    "initialization");
    StationaryProjectionSlotV1<TemporalServiceKernel> service_kernel_slot =
        unavailable(StationaryProjectionUnavailableKindV1::unrequested,
                    "c21.temporal_service_kernel_unrequested",
                    "the accepted plan did not request passive FIFO service "
                    "continuation");
    if (facts.palm_or_fifo_route &&
        requests_admission_fifo_views(law_core.binding.source)) {
      if (!facts.retains_target_departure || !facts.retains_arrival_batch) {
        return fail<StationaryTemporalProjection>(
            "c21.fifo_service_marks_unavailable",
            "an accepted Palm/FIFO route lacks retained actual departure or "
            "arrival marks",
            DiagnosticCategory::unavailable);
      }
      auto service = service_atoms(source);
      if (!service) {
        return Result<StationaryTemporalProjection>::failure(service.error());
      }
      std::vector<stationary::detail::PredictiveServiceAtomCore> p0;
      std::vector<stationary::detail::PredictiveServiceAtomCore> p1;
      for (const auto& atom : service.value()) {
        (atom.target_departure == 0U ? p0 : p1).push_back(atom);
      }
      auto split_core = std::make_shared<const
          stationary::detail::PredictiveServiceSplitCore>(
          stationary::detail::PredictiveServiceSplitCore{
              source, std::move(p0), std::move(p1),
              law_core.binding.source.target_selection_identity,
              law_core.binding.source.target_service_schema_identity,
              fingerprint.value()});
      split_slot = detail::C21CoreAccess::predictive_service_split(
          std::move(split_core));
      auto service_core = std::make_shared<const
          stationary::detail::TemporalServiceKernelCore>(
          stationary::detail::TemporalServiceKernelCore{
              source, std::move(service).value(),
              law_core.binding.source.continuation_schema_identity,
              law_core.binding.source.target_selection_identity,
              law_core.binding.source.target_service_schema_identity,
              fingerprint.value()});
      service_kernel_slot = detail::C21CoreAccess::temporal_service_kernel(
          std::move(service_core));
    }

    const auto& edge_diagnostics = marked_edge.diagnostics();
    StationaryProjectionDiagnosticsV1 projection_diagnostics{
        law.fingerprint(),
        law_core.binding.source.provider_romr_identity,
        mean.fingerprint(),
        temporal_law.diagnostics().exact_total_mass,
        temporal_law.diagnostics().numerical_total_mass,
        true,
        temporal_law.diagnostics().configured_phase_identity_matches,
        edge_diagnostics.exact_total_mass == ExactRational::one(),
        edge_diagnostics.exact_left_right_marginals_equal,
        edge_diagnostics.exact_endpoint_invariance_holds,
        true};
    auto projection_core = std::make_shared<const
        stationary::detail::StationaryTemporalProjectionCore>(
        stationary::detail::StationaryTemporalProjectionCore{
            std::move(temporal_law),
            std::move(marked_edge),
            std::move(cylinder_slot),
            std::move(temporal_law_slot),
            std::move(kernel_slot),
            std::move(initial_slot),
            std::move(split_slot),
            std::move(service_kernel_slot),
            fingerprint.value(),
            std::move(projection_diagnostics)});
    return Result<StationaryTemporalProjection>::success(
        detail::C21CoreAccess::projection(std::move(projection_core)));
  } catch (const std::bad_alloc&) {
    return fail<StationaryTemporalProjection>(
        "c21.stationary_projection_allocation_failure",
        "constructing the stationary temporal projection exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<StationaryTemporalProjection>(
        "c21.stationary_projection_exception",
        "stationary temporal projection raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace

Result<StationaryTemporalProjection> build_stationary_temporal_projection(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean) {
  return build_stationary_temporal_projection_impl(
      law, provider, mean, std::nullopt, std::nullopt, nullptr, nullptr);
}

Result<stationary::detail::BoundedStationaryTemporalProjectionV1>
stationary::detail::build_stationary_temporal_projection_bounded(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean, const std::size_t maximum_states,
    const std::size_t maximum_row_atoms) {
  std::size_t actual_states = 0U;
  std::size_t actual_row_atoms = 0U;
  auto projection = build_stationary_temporal_projection_impl(
      law, provider, mean, maximum_states, maximum_row_atoms,
      &actual_states, &actual_row_atoms);
  if (!projection) {
    return Result<BoundedStationaryTemporalProjectionV1>::failure(
        projection.error());
  }
  return Result<BoundedStationaryTemporalProjectionV1>::success(
      BoundedStationaryTemporalProjectionV1{
          std::move(projection).value(), actual_states,
          actual_row_atoms});
}

namespace {

[[nodiscard]] bool same_tail_resolution_value(const TailResolution& left,
                                               const TailResolution& right) {
  if (left.index() != right.index()) {
    return false;
  }
  switch (left.index()) {
    case 0U:
      return true;
    case 1U:
      return std::get<FiniteClosedTailResolution>(left).max_level ==
             std::get<FiniteClosedTailResolution>(right).max_level;
    case 2U:
      return std::get<ConstantResponseTailResolution>(left).cutoff ==
             std::get<ConstantResponseTailResolution>(right).cutoff;
    case 3U: {
      const auto& lhs =
          std::get<CertifiedTruncationTailResolution>(left);
      const auto& rhs =
          std::get<CertifiedTruncationTailResolution>(right);
      return lhs.max_level == rhs.max_level &&
             lhs.max_tail_mass == rhs.max_tail_mass;
    }
    default:
      return false;
  }
}

[[nodiscard]] bool same_resolution_value(const ResolutionEnvelope& left,
                                         const ResolutionEnvelope& right) {
  return left.level.max_states == right.level.max_states &&
         left.level.max_row_atoms == right.level.max_row_atoms &&
         same_tail_resolution_value(left.tail, right.tail) &&
         left.phase.max_phase_states == right.phase.max_phase_states &&
         left.optimizer.max_calls == right.optimizer.max_calls &&
         left.optimizer.max_search_states_per_call ==
             right.optimizer.max_search_states_per_call &&
         left.sampling.max_generator_draws ==
             right.sampling.max_generator_draws &&
         left.tolerance.linear_residual_abs ==
             right.tolerance.linear_residual_abs &&
         left.tolerance.integration_abs ==
             right.tolerance.integration_abs &&
         left.tolerance.tail_abs == right.tolerance.tail_abs &&
         left.tolerance.fixed_point_abs ==
             right.tolerance.fixed_point_abs;
}

[[nodiscard]] bool same_solver_value(const SolverSpec& left,
                                     const SolverSpec& right) {
  if (left.index() != right.index()) {
    return false;
  }
  switch (left.index()) {
    case 0U: {
      const auto& lhs = std::get<EnumeratedSolver>(left);
      const auto& rhs = std::get<EnumeratedSolver>(right);
      return lhs.linear_method == rhs.linear_method &&
             lhs.max_iterations == rhs.max_iterations;
    }
    case 1U: {
      const auto& lhs = std::get<AnalyticSolver>(left);
      const auto& rhs = std::get<AnalyticSolver>(right);
      return lhs.precision_bits == rhs.precision_bits &&
             lhs.max_iterations == rhs.max_iterations;
    }
    case 2U: {
      const auto& lhs = std::get<MonteCarloSolver>(left);
      const auto& rhs = std::get<MonteCarloSolver>(right);
      return lhs.replications == rhs.replications &&
             lhs.confidence_level == rhs.confidence_level &&
             lhs.interval_method == rhs.interval_method;
    }
    case 3U:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] bool same_analysis_context_value(
    const AnalysisContext& left, const AnalysisContext& right,
    const Digest256& required_selection_identity) {
  if (left.targets.queue_ids != right.targets.queue_ids ||
      !same_resolution_value(left.resolution, right.resolution) ||
      !same_solver_value(left.solver, right.solver)) {
    return false;
  }
  auto left_selection =
      artifact::detail::canonical_analysis_selection_digest_v1(
          left.selection);
  auto right_selection =
      artifact::detail::canonical_analysis_selection_digest_v1(
          right.selection);
  return left_selection && right_selection &&
         left_selection.value() == right_selection.value() &&
         left_selection.value() == required_selection_identity;
}

[[nodiscard]] SolverRegimeV1 solver_regime_value(
    const MetricSolverRegimeV1 regime) {
  switch (regime) {
    case MetricSolverRegimeV1::enumerated:
      return SolverRegimeV1::enumerated;
    case MetricSolverRegimeV1::analytic:
      return SolverRegimeV1::analytic;
    case MetricSolverRegimeV1::monte_carlo:
      return SolverRegimeV1::monte_carlo;
    case MetricSolverRegimeV1::direct:
      return SolverRegimeV1::direct;
  }
  return SolverRegimeV1::direct;
}

[[nodiscard]] TargetCouplingV1 target_coupling_value(
    const MetricTargetCouplingV1 coupling) {
  switch (coupling) {
    case MetricTargetCouplingV1::scalar_singleton:
      return TargetCouplingV1::scalar_target;
    case MetricTargetCouplingV1::common_schedule_coupled:
      return TargetCouplingV1::common_schedule_projection;
  }
  return TargetCouplingV1::scalar_target;
}

[[nodiscard]] bool matching_metric_contract(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const MetricRequest& request, const BackendRouteKindV1 route) {
  const MetricRequestHeader& header = metric_request_header(request);
  if (header.kind != metric_request_kind(request) || !header.context) {
    return false;
  }
  const MetricRequestParametersV1 parameters =
      metric_request_parameters(request);
  return std::any_of(
      binding.accepted_metric_contracts.begin(),
      binding.accepted_metric_contracts.end(),
      [&](const ResolvedMetricContractV1& contract) {
        if (contract.authored_metric_index != header.authored_index ||
            contract.metric_id != header.metric_id ||
            contract.clause_id.authored_index != header.authored_index ||
            contract.clause_id.metric_id != header.metric_id ||
            contract.ordered_targets != header.ordered_targets ||
            contract.backend_route != route ||
            contract.target_coupling !=
                target_coupling_value(header.coupling) ||
            contract.solver_regime != solver_regime_value(header.solver_regime)) {
          return false;
        }
        const auto clause = std::find_if(
            binding.accepted_requirements.clauses().begin(),
            binding.accepted_requirements.clauses().end(),
            [&](const MetricRequirementClause& candidate) {
              return candidate.origin.clause_id == contract.clause_id;
            });
        if (clause == binding.accepted_requirements.clauses().end() ||
            clause->origin.kind != header.kind ||
            clause->origin.parameters != parameters ||
            clause->origin.wire_coupling != header.coupling ||
            clause->origin.ordered_targets != header.ordered_targets ||
            clause->origin.selection_regime != header.selection_regime ||
            clause->origin.solver_regime != header.solver_regime ||
            !clause->origin.context) {
          return false;
        }
        return same_analysis_context_value(
            *header.context, *clause->origin.context,
            binding.selection_identity);
      });
}

[[nodiscard]] std::optional<std::size_t> target_ordinal(
    const temporal::detail::C20StationarySourceBindingV1& binding,
    const ResolvedMetricTargetV1& requested) {
  const auto found = std::find(binding.target_selection.ordered_targets.begin(),
                               binding.target_selection.ordered_targets.end(),
                               requested.queue_id);
  if (found == binding.target_selection.ordered_targets.end()) {
    return std::nullopt;
  }
  return static_cast<std::size_t>(
      found - binding.target_selection.ordered_targets.begin());
}

[[nodiscard]] Result<BigInt> integer_power(BigInt base,
                                           const BigNat& exact_exponent) {
  if (exact_exponent.bit_length() > 20U) {
    return fail<BigInt>(
        "c21.metric_moment_order_resource_limit",
        "the exact stationary moment order exceeds the C21 finite "
        "enumeration resource envelope",
        DiagnosticCategory::resource_limit);
  }
  const auto exponent = exact_exponent.value().convert_to<std::uint64_t>();
  if (exponent > 1000000U) {
    return fail<BigInt>(
        "c21.metric_moment_order_resource_limit",
        "the exact stationary moment order exceeds the C21 finite "
        "enumeration resource envelope",
        DiagnosticCategory::resource_limit);
  }
  BigInt value = 1;
  std::uint64_t remaining = exponent;
  while (remaining != 0U) {
    if ((remaining & 1U) != 0U) {
      value *= base;
    }
    remaining >>= 1U;
    if (remaining != 0U) {
      base *= base;
    }
  }
  return Result<BigInt>::success(std::move(value));
}

[[nodiscard]] Result<ExactRational> rational_power(
    ExactRational base, const BigNat& exact_exponent) {
  if (exact_exponent.is_zero()) {
    // The PGF convention includes z^0=1, including at z=0.
    return Result<ExactRational>::success(ExactRational::one());
  }
  if (base.is_zero()) {
    return Result<ExactRational>::success(ExactRational::zero());
  }
  if (base == ExactRational::one()) {
    return Result<ExactRational>::success(ExactRational::one());
  }
  const ExactRational minus_one =
      ExactRational::make(BigInt{-1}, BigInt{1}).value();
  if (base == minus_one) {
    const bool odd = (exact_exponent.value() & BigInt{1}) != 0;
    return Result<ExactRational>::success(
        odd ? minus_one : ExactRational::one());
  }
  if (exact_exponent.bit_length() > 20U) {
    return fail<ExactRational>(
        "c21.metric_pgf_exponent_resource_limit",
        "a stationary PGF backlog exponent exceeds the C21 finite exact "
        "enumeration resource envelope",
        DiagnosticCategory::resource_limit);
  }
  const auto exponent = exact_exponent.value().convert_to<std::uint64_t>();
  if (exponent > 1000000U) {
    return fail<ExactRational>(
        "c21.metric_pgf_exponent_resource_limit",
        "a stationary PGF backlog exponent exceeds the C21 finite exact "
        "enumeration resource envelope",
        DiagnosticCategory::resource_limit);
  }
  ExactRational value = ExactRational::one();
  std::uint64_t remaining = exponent;
  while (remaining != 0U) {
    if ((remaining & 1U) != 0U) {
      value = value * base;
    }
    remaining >>= 1U;
    if (remaining != 0U) {
      base = base * base;
    }
  }
  return Result<ExactRational>::success(std::move(value));
}

[[nodiscard]] Result<std::vector<BacklogMass>> stationary_backlog_masses(
    const stationary::detail::StationaryProjectionSourceCore& source,
    const std::size_t target) {
  std::vector<BacklogMass> masses;
  for (const auto& atom : source.atoms) {
    if (target >= atom.reward_edge.prearrival_target_backlog.size()) {
      return fail<std::vector<BacklogMass>>(
          "c21.metric_target_not_retained",
          "the stationary temporal law omits the requested backlog "
          "coordinate",
          DiagnosticCategory::unavailable);
    }
    const BigNat& level =
        atom.reward_edge.prearrival_target_backlog[target];
    const auto found = std::find_if(
        masses.begin(), masses.end(), [&](const BacklogMass& candidate) {
          return candidate.level == level;
        });
    if (found == masses.end()) {
      masses.push_back(BacklogMass{level, atom.exact_mass});
    } else {
      found->mass = found->mass + atom.exact_mass;
    }
  }
  std::stable_sort(masses.begin(), masses.end(),
                   [](const BacklogMass& left, const BacklogMass& right) {
                     return left.level < right.level;
                   });
  ExactRational total = ExactRational::zero();
  for (const BacklogMass& atom : masses) {
    if (!atom.mass.is_positive()) {
      return fail<std::vector<BacklogMass>>(
          "c21.stationary_backlog_pmf_nonpositive_atom",
          "an exact stationary backlog atom has nonpositive mass",
          DiagnosticCategory::internal);
    }
    total = total + atom.mass;
  }
  if (!(total == ExactRational::one())) {
    return fail<std::vector<BacklogMass>>(
        "c21.stationary_backlog_pmf_mass_not_one",
        "the exact stationary backlog marginal does not have unit mass",
        DiagnosticCategory::internal);
  }
  return Result<std::vector<BacklogMass>>::success(std::move(masses));
}

[[nodiscard]] Result<MetricValue> evaluate_distributional_stationary_metric(
    const stationary::detail::StationaryTemporalLawCore& law,
    const MetricRequest& request, const std::size_t target) {
  if (!law.source) {
    return fail<MetricValue>(
        "c21.stationary_temporal_law_binding_mismatch",
        "a distributional stationary metric has no projection-bound source",
        DiagnosticCategory::internal);
  }
  auto masses = stationary_backlog_masses(*law.source, target);
  if (!masses) {
    return Result<MetricValue>::failure(masses.error());
  }
  const MetricKindV1 kind = metric_request_kind(request);
  if (kind == MetricKindV1::stationary_backlog_pmf) {
    const auto parameters = std::get<StationaryBacklogPmfParametersV1>(
        metric_request_parameters(request));
    const auto* through =
        std::get_if<PmfThroughLevelV1>(&parameters.domain);
    std::vector<BacklogMass> output;
    output.reserve(masses.value().size());
    ExactRational returned = ExactRational::zero();
    for (const BacklogMass& atom : masses.value()) {
      if (through == nullptr || atom.level <= through->max_level) {
        output.push_back(atom);
        returned = returned + atom.mass;
      }
    }
    const ExactRational omitted = ExactRational::one() - returned;
    if (!returned.is_nonnegative() || !omitted.is_nonnegative()) {
      return fail<MetricValue>(
          "c21.stationary_pmf_window_mass_inconsistent",
          "the exact stationary PMF output window has invalid returned or "
          "omitted mass",
          DiagnosticCategory::internal);
    }
    return encode_backlog_pmf_envelope(BacklogPmfEnvelope{
        law.projection_fingerprint, through == nullptr,
        through == nullptr ? std::optional<BigNat>{}
                           : std::optional<BigNat>{through->max_level},
        std::move(output), returned, omitted});
  }

  if (kind == MetricKindV1::stationary_backlog_pgf) {
    const auto parameters = std::get<StationaryBacklogPgfParametersV1>(
        metric_request_parameters(request));
    if (parameters.points.empty() ||
        !std::is_sorted(parameters.points.begin(), parameters.points.end()) ||
        std::adjacent_find(parameters.points.begin(),
                           parameters.points.end()) !=
            parameters.points.end()) {
      return fail<MetricValue>(
          "c21.stationary_pgf_domain_invalid",
          "stationary PGF points must be a nonempty canonical "
          "duplicate-free ordered exact domain");
    }
    std::vector<BacklogPgfAtom> output;
    output.reserve(parameters.points.size());
    for (const ExactRational& point : parameters.points) {
      if (!std::isfinite(point.to_long_double())) {
        return fail<MetricValue>(
            "c21.stationary_pgf_point_numerically_unresolved",
            "a stationary PGF point has no finite numerical image",
            DiagnosticCategory::unavailable);
      }
      ExactRational value = ExactRational::zero();
      for (const BacklogMass& atom : masses.value()) {
        auto power = rational_power(point, atom.level);
        if (!power) {
          return Result<MetricValue>::failure(power.error());
        }
        value = value + atom.mass * power.value();
      }
      if (!std::isfinite(value.to_long_double())) {
        return fail<MetricValue>(
            "c21.stationary_pgf_value_numerically_unresolved",
            "an exact stationary PGF value has no finite numerical image",
            DiagnosticCategory::unavailable);
      }
      output.push_back(BacklogPgfAtom{point, std::move(value)});
    }
    return encode_backlog_pgf_envelope(
        BacklogPgfEnvelope{law.projection_fingerprint, std::move(output)});
  }

  if (kind == MetricKindV1::stationary_backlog_quantile) {
    const auto parameters =
        std::get<StationaryBacklogQuantileParametersV1>(
            metric_request_parameters(request));
    if (!parameters.probability.is_positive() ||
        !(parameters.probability < ExactRational::one()) ||
        parameters.convention !=
            DiscreteQuantileConventionV1::lower_inverse_cdf) {
      return fail<MetricValue>(
          "c21.stationary_quantile_domain_invalid",
          "a stationary backlog quantile requires probability in (0,1) and "
          "the lower inverse-CDF convention");
    }
    ExactRational cdf = ExactRational::zero();
    for (const BacklogMass& atom : masses.value()) {
      const ExactRational below = cdf;
      cdf = cdf + atom.mass;
      if (!(cdf < parameters.probability)) {
        return encode_backlog_quantile_envelope(BacklogQuantileEnvelope{
            law.projection_fingerprint, parameters.probability,
            parameters.convention, atom.level, below, cdf});
      }
    }
    return fail<MetricValue>(
        "c21.stationary_quantile_not_resolved",
        "the exact unit-mass stationary backlog law did not resolve the "
        "requested quantile",
        DiagnosticCategory::internal);
  }

  return fail<MetricValue>(
      "c14_capability_stationary_temporal_metric_unsupported",
      "the request is not a C21 single-slot distributional metric",
      DiagnosticCategory::unavailable);
}

[[nodiscard]] Result<ExactRational> direct_metric_reward(
    const stationary::detail::StationaryTemporalAtomCore& atom,
    const MetricRequest& request, const std::size_t target) {
  if (target >= atom.reward_edge.prearrival_target_backlog.size() ||
      target >= atom.reward_edge.target_departures.size() ||
      target >= atom.reward_edge.target_arrivals.size()) {
    return fail<ExactRational>(
        "c21.metric_target_not_retained",
        "the stationary temporal law does not retain the requested target "
        "coordinate",
        DiagnosticCategory::unavailable);
  }
  const MetricKindV1 kind = metric_request_kind(request);
  const BigNat& backlog = atom.reward_edge.prearrival_target_backlog[target];
  if (kind == MetricKindV1::stationary_empty_probability) {
    return Result<ExactRational>::success(
        backlog.is_zero() ? ExactRational::one() : ExactRational::zero());
  }
  if (kind == MetricKindV1::stationary_backlog_tail) {
    const auto parameters =
        std::get<StationaryBacklogTailParametersV1>(
            metric_request_parameters(request));
    return Result<ExactRational>::success(
        backlog >= parameters.threshold ? ExactRational::one()
                                        : ExactRational::zero());
  }
  BigInt base = backlog.value();
  BigNat order{1U};
  if (kind == MetricKindV1::stationary_backlog_moment) {
    order = std::get<StationaryBacklogMomentParametersV1>(
                metric_request_parameters(request))
                .order;
  } else if (kind == MetricKindV1::stationary_edge_reward) {
    const auto parameters =
        std::get<StationaryEdgeRewardParametersV1>(
            metric_request_parameters(request));
    order = parameters.moment_order;
    switch (parameters.reward) {
      case EdgeRewardKind::departure:
        base = atom.reward_edge.target_departures[target];
        break;
      case EdgeRewardKind::arrival:
        base = atom.reward_edge.target_arrivals[target].value();
        break;
      case EdgeRewardKind::increment:
        base = atom.reward_edge.target_arrivals[target].value() -
               atom.reward_edge.target_departures[target];
        break;
    }
  } else {
    return fail<ExactRational>(
        "c14_capability_stationary_temporal_metric_unsupported",
        "F-C21-05 dispatches only retained state and adjacent-edge rewards; "
        "run, gap, lag, hitting, distributional, and FIFO requests require "
        "their C22/C23 typed views",
        DiagnosticCategory::unavailable);
  }
  auto powered = integer_power(std::move(base), order);
  if (!powered) {
    return Result<ExactRational>::failure(powered.error());
  }
  return ExactRational::make(std::move(powered).value(), BigInt{1});
}

}  // namespace

Result<MetricValue> evaluate_stationary_temporal_metric(
    const StationaryTemporalLaw& law, const MetricRequest& request) {
  try {
    const auto& core = detail::C21CoreAccess::core(law);
    if (!core.source ||
        core.projection_fingerprint != core.source->fingerprint) {
      return fail<MetricValue>(
          "c21.stationary_temporal_law_binding_mismatch",
          "the stationary temporal law has lost its projection-bound source",
          DiagnosticCategory::internal);
    }
    const MetricRequestHeader& header = metric_request_header(request);
    if (header.ordered_targets.size() != 1U) {
      return fail<MetricValue>(
          "c14_capability_target_scope_unsupported",
          "this C21 scalar stationary temporal dispatcher requires exactly "
          "one retained target",
          DiagnosticCategory::unavailable);
    }
    const MetricKindV1 kind = metric_request_kind(request);
    const bool edge_metric = kind == MetricKindV1::stationary_edge_reward;
    const BackendRouteKindV1 required_route =
        edge_metric ? BackendRouteKindV1::stationary_edge_reward
                    : BackendRouteKindV1::stationary_invariant;
    if (!matching_metric_contract(core.source->provider_binding, request,
                                  required_route)) {
      return fail<MetricValue>(
          "c14_capability_stationary_route_not_accepted",
          "the request has no exact matching accepted C14 stationary route "
          "for this projection",
          DiagnosticCategory::unavailable);
    }
    switch (kind) {
      case MetricKindV1::stationary_empty_probability:
      case MetricKindV1::stationary_backlog_pmf:
      case MetricKindV1::stationary_backlog_pgf:
      case MetricKindV1::stationary_backlog_moment:
      case MetricKindV1::stationary_backlog_quantile:
      case MetricKindV1::stationary_backlog_tail:
      case MetricKindV1::stationary_edge_reward:
        break;
      default:
        return fail<MetricValue>(
            "c14_capability_stationary_temporal_metric_unsupported",
            "the accepted request requires a multi-slot, stopped, Palm, or "
            "FIFO operation outside F-C21-05",
            DiagnosticCategory::unavailable);
    }
    const auto target = target_ordinal(core.source->provider_binding,
                                       header.ordered_targets.front());
    if (!target.has_value()) {
      return fail<MetricValue>(
          "c14_capability_target_not_retained",
          "the requested target is absent from the projection-bound target "
          "service schema",
          DiagnosticCategory::unavailable);
    }
    if (kind == MetricKindV1::stationary_backlog_pmf ||
        kind == MetricKindV1::stationary_backlog_pgf ||
        kind == MetricKindV1::stationary_backlog_quantile) {
      return evaluate_distributional_stationary_metric(core, request,
                                                       *target);
    }
    const auto& mean_core = detail::C21CoreAccess::core(
        core.source->denominator);
    if (!mean_core.diagnostics.exact_value.has_value()) {
      return fail<MetricValue>(
          "c21.stationary_metric_denominator_unavailable",
          "the stationary temporal law has no exact positive-finite "
          "denominator",
          DiagnosticCategory::internal);
    }
    const ExactRational& denominator =
        *mean_core.diagnostics.exact_value;
    ExactRational numerator = ExactRational::zero();
    ExactRational absolute_numerator = ExactRational::zero();
    CompensatedSum numerical_numerator;
    for (const auto& atom : core.source->atoms) {
      auto reward = direct_metric_reward(atom, request, *target);
      if (!reward) {
        return Result<MetricValue>::failure(reward.error());
      }
      const ExactRational raw_weight = atom.exact_mass * denominator;
      const ExactRational term = raw_weight * reward.value();
      numerator = numerator + term;
      absolute_numerator = absolute_numerator +
                           raw_weight * absolute_value(reward.value());
      numerical_numerator.add(term.to_long_double());
    }
    auto ratio = checked_divide(numerator, denominator);
    if (!ratio) {
      return Result<MetricValue>::failure(ratio.error());
    }
    const long double exact_ratio_image = ratio.value().to_long_double();
    const long double numerical_ratio =
        numerical_numerator.value() /
        core.source->denominator.numerical_value();
    if (!std::isfinite(exact_ratio_image) ||
        !std::isfinite(numerical_ratio) ||
        !std::isfinite(absolute_numerator.to_long_double())) {
      return fail<MetricValue>(
          "c21.stationary_metric_numerically_unresolved",
          "the exact stationary metric has no finite numerical ratio or "
          "absolute-integral image",
          DiagnosticCategory::unavailable);
    }
    const long double actual_ratio_residual =
        std::fabs(numerical_ratio - exact_ratio_image);
    const long double epsilon =
        std::numeric_limits<long double>::epsilon();
    const long double rounding_allowance =
        epsilon + epsilon * std::fabs(numerical_ratio) +
        epsilon * std::fabs(exact_ratio_image);
    const long double residual_with_rounding =
        actual_ratio_residual + rounding_allowance;
    if (!std::isfinite(actual_ratio_residual) ||
        !std::isfinite(rounding_allowance) ||
        !std::isfinite(residual_with_rounding)) {
      return fail<MetricValue>(
          "c21.stationary_metric_numerically_unresolved",
          "the stationary metric ratio residual exceeds the promoted "
          "numerical range",
          DiagnosticCategory::unavailable);
    }
    auto bound =
        nonnegative_long_double_upper_bound(residual_with_rounding);
    if (!bound) {
      return Result<MetricValue>::failure(bound.error());
    }
    return encode_metric_envelope(
        CodecIdentityV1{"mwperf.c21.stationary_metric_envelope", 1U},
        MetricEnvelope{core.projection_fingerprint, numerator, denominator,
                       ratio.value(), absolute_numerator, bound.value(),
                       false});
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c21.stationary_metric_allocation_failure",
        "stationary temporal metric dispatch exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c21.stationary_metric_exception",
        "stationary temporal metric dispatch raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

const EmbeddedKernel& EventInvariantLaw::embedded_kernel() const noexcept {
  return core_->kernel;
}
const FiniteEventStateDomain& EventInvariantLaw::domain() const noexcept {
  return core_->kernel.domain();
}
std::span<const EventInvariantMassV1> EventInvariantLaw::masses()
    const noexcept {
  return core_->masses;
}
std::span<const SelectedInvariantClassV1>
EventInvariantLaw::selected_classes() const noexcept {
  return core_->selected_classes;
}
const EventInvariantDiagnosticsV1& EventInvariantLaw::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const Digest256& EventInvariantLaw::fingerprint() const noexcept {
  return core_->fingerprint;
}

const std::optional<ExactRational>& PositiveFiniteMean::exact_value()
    const noexcept {
  return core_->diagnostics.exact_value;
}
long double PositiveFiniteMean::numerical_value() const noexcept {
  return core_->diagnostics.numerical_value;
}
const ExactRational& PositiveFiniteMean::exact_lower_bound() const noexcept {
  return core_->diagnostics.exact_lower_bound;
}
const ExactRational& PositiveFiniteMean::exact_upper_bound() const noexcept {
  return core_->diagnostics.exact_upper_bound;
}
const PositiveFiniteMeanDiagnosticsV1& PositiveFiniteMean::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const Digest256& PositiveFiniteMean::event_law_fingerprint() const noexcept {
  return core_->event_law.fingerprint();
}
const Digest256& PositiveFiniteMean::provider_fingerprint() const noexcept {
  return core_->provider_binding.provider_romr_identity;
}
const Digest256& PositiveFiniteMean::fingerprint() const noexcept {
  return core_->fingerprint;
}

const Digest256& StationaryTemporalLaw::projection_fingerprint()
    const noexcept {
  return core_->projection_fingerprint;
}
const StationaryTemporalDiagnosticsV1& StationaryTemporalLaw::diagnostics()
    const noexcept {
  return core_->diagnostics;
}

std::span<const StationaryMarkedEdgeAtomV1> StationaryMarkedEdge::atoms()
    const noexcept {
  return core_->atoms;
}
std::span<const StationaryStateMassV1> StationaryMarkedEdge::left_marginal()
    const noexcept {
  return core_->left_marginal;
}
std::span<const StationaryStateMassV1> StationaryMarkedEdge::right_marginal()
    const noexcept {
  return core_->right_marginal;
}
std::span<const StationaryConditionalMarkedRowV1>
StationaryMarkedEdge::positive_conditional_rows() const noexcept {
  return core_->conditional_rows;
}
std::span<const StationaryEndpointRowV1> StationaryMarkedEdge::endpoint_rows()
    const noexcept {
  return core_->endpoint_rows;
}
const StationaryMarkedEdgeDiagnosticsV1& StationaryMarkedEdge::diagnostics()
    const noexcept {
  return core_->diagnostics;
}
const Digest256& StationaryMarkedEdge::projection_fingerprint()
    const noexcept {
  return core_->projection_fingerprint;
}

InitialLawKindV1 InitialLaw::kind() const noexcept { return core_->kind; }
const Digest256& InitialLaw::source_fingerprint() const noexcept {
  return core_->source_fingerprint;
}
const Digest256& InitialLaw::projection_fingerprint() const noexcept {
  return core_->projection_fingerprint;
}
bool InitialLaw::has_projection_binding() const noexcept {
  return core_->has_projection_binding;
}
const Digest256& PredictiveServiceSplit::projection_fingerprint()
    const noexcept {
  return core_->projection_fingerprint;
}
const Digest256& TemporalServiceKernel::projection_fingerprint()
    const noexcept {
  return core_->projection_fingerprint;
}

const StationaryTemporalLaw& StationaryTemporalProjection::temporal_law()
    const noexcept {
  return core_->temporal_law;
}
const StationaryMarkedEdge& StationaryTemporalProjection::marked_edge()
    const noexcept {
  return core_->marked_edge;
}
const StationaryProjectionSlotV1<AuditedCylinderLaw>&
StationaryTemporalProjection::cylinder_law() const noexcept {
  return core_->cylinder_law;
}
const StationaryProjectionSlotV1<AuditedTemporalLaw>&
StationaryTemporalProjection::audited_temporal_law() const noexcept {
  return core_->audited_temporal_law;
}
const StationaryProjectionSlotV1<AuditedTemporalKernel>&
StationaryTemporalProjection::temporal_kernel() const noexcept {
  return core_->temporal_kernel;
}
const StationaryProjectionSlotV1<InitialLaw>&
StationaryTemporalProjection::initial_law() const noexcept {
  return core_->initial_law;
}
const StationaryProjectionSlotV1<PredictiveServiceSplit>&
StationaryTemporalProjection::predictive_service_split() const noexcept {
  return core_->predictive_service_split;
}
const StationaryProjectionSlotV1<TemporalServiceKernel>&
StationaryTemporalProjection::temporal_service_kernel() const noexcept {
  return core_->temporal_service_kernel;
}
const Digest256& StationaryTemporalProjection::fingerprint() const noexcept {
  return core_->fingerprint;
}
const StationaryProjectionDiagnosticsV1&
StationaryTemporalProjection::diagnostics() const noexcept {
  return core_->diagnostics;
}

#if defined(MWPERF_C21_TEST_SEAMS)
namespace testing {
namespace {

class EnvelopeReader final {
 public:
  explicit EnvelopeReader(const std::span<const std::byte> bytes)
      : bytes_(bytes) {}

  [[nodiscard]] std::optional<std::uint8_t> byte() {
    if (cursor_ == bytes_.size()) {
      return std::nullopt;
    }
    return std::to_integer<std::uint8_t>(bytes_[cursor_++]);
  }

  [[nodiscard]] std::optional<std::uint32_t> u32() {
    if (bytes_.size() - cursor_ < 4U) {
      return std::nullopt;
    }
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
      value = static_cast<std::uint32_t>(
          (value << 8U) |
          std::to_integer<std::uint8_t>(bytes_[cursor_++]));
    }
    return value;
  }

  [[nodiscard]] std::optional<std::vector<std::byte>> frame() {
    const auto width = u32();
    if (!width.has_value() ||
        static_cast<std::size_t>(*width) > bytes_.size() - cursor_) {
      return std::nullopt;
    }
    std::vector<std::byte> value(
        bytes_.begin() + static_cast<std::ptrdiff_t>(cursor_),
        bytes_.begin() +
            static_cast<std::ptrdiff_t>(cursor_ + *width));
    cursor_ += *width;
    return value;
  }

  [[nodiscard]] bool exhausted() const noexcept {
    return cursor_ == bytes_.size();
  }

 private:
  std::span<const std::byte> bytes_;
  std::size_t cursor_{0U};
};

[[nodiscard]] std::optional<BigInt> parse_canonical_integer(
    const std::span<const std::byte> bytes) {
  if (bytes.empty()) {
    return std::nullopt;
  }
  std::size_t cursor = 0U;
  bool negative = false;
  if (std::to_integer<unsigned char>(bytes.front()) ==
      static_cast<unsigned char>('-')) {
    negative = true;
    cursor = 1U;
  }
  if (cursor == bytes.size()) {
    return std::nullopt;
  }
  if (bytes.size() - cursor > 1U &&
      std::to_integer<unsigned char>(bytes[cursor]) ==
          static_cast<unsigned char>('0')) {
    return std::nullopt;
  }
  BigInt value = 0;
  for (; cursor < bytes.size(); ++cursor) {
    const unsigned char character =
        std::to_integer<unsigned char>(bytes[cursor]);
    if (character < static_cast<unsigned char>('0') ||
        character > static_cast<unsigned char>('9')) {
      return std::nullopt;
    }
    value *= 10;
    value += static_cast<unsigned int>(character -
                                       static_cast<unsigned char>('0'));
  }
  if (negative) {
    if (value == 0) {
      return std::nullopt;
    }
    value = -value;
  }
  return value;
}

[[nodiscard]] std::optional<ExactRational> read_rational(
    EnvelopeReader& reader) {
  const auto numerator_bytes = reader.frame();
  const auto denominator_bytes = reader.frame();
  if (!numerator_bytes.has_value() || !denominator_bytes.has_value()) {
    return std::nullopt;
  }
  const auto numerator = parse_canonical_integer(*numerator_bytes);
  const auto denominator = parse_canonical_integer(*denominator_bytes);
  if (!numerator.has_value() || !denominator.has_value()) {
    return std::nullopt;
  }
  auto rational = ExactRational::make(*numerator, *denominator);
  const auto bytes_as_text = [](const std::span<const std::byte> value) {
    std::string text;
    text.reserve(value.size());
    for (const std::byte element : value) {
      text.push_back(static_cast<char>(
          std::to_integer<unsigned char>(element)));
    }
    return text;
  };
  if (!rational || rational.value().numerator_decimal() !=
                       bytes_as_text(*numerator_bytes) ||
      rational.value().denominator_decimal() !=
          bytes_as_text(*denominator_bytes)) {
    // Reduction changes a noncanonical envelope spelling; encoder output is
    // always already reduced.
    return std::nullopt;
  }
  return std::move(rational).value();
}

[[nodiscard]] std::optional<BigNat> read_natural(EnvelopeReader& reader) {
  const auto bytes = reader.frame();
  if (!bytes.has_value()) {
    return std::nullopt;
  }
  auto integer = parse_canonical_integer(*bytes);
  if (!integer.has_value() || *integer < 0) {
    return std::nullopt;
  }
  auto natural = BigNat::from_big_int(std::move(*integer));
  if (!natural) {
    return std::nullopt;
  }
  std::string spelling;
  spelling.reserve(bytes->size());
  for (const std::byte value : *bytes) {
    spelling.push_back(
        static_cast<char>(std::to_integer<unsigned char>(value)));
  }
  if (natural.value().to_decimal_string() != spelling) {
    return std::nullopt;
  }
  return std::move(natural).value();
}

[[nodiscard]] std::optional<Digest256> read_digest(EnvelopeReader& reader) {
  const auto bytes = reader.frame();
  if (!bytes.has_value()) {
    return std::nullopt;
  }
  auto digest = Digest256::from_bytes(*bytes);
  if (!digest) {
    return std::nullopt;
  }
  return std::move(digest).value();
}

[[nodiscard]] bool codec_is(const MetricValue& value,
                            const std::string_view id) {
  return value.codec.id == id && value.codec.version == 1U;
}

struct SeamStateMass final {
  ReducedStateV1 state;
  ExactRational mass;
};

[[nodiscard]] std::vector<SeamStateMass> seam_state_marginal(
    const std::span<const CoalescedFluxAtom> atoms, const bool left) {
  std::vector<SeamStateMass> result;
  for (const CoalescedFluxAtom& atom : atoms) {
    const ReducedStateV1& state =
        left ? atom.edge.pre_state : atom.edge.successor_state;
    const auto found = std::find_if(
        result.begin(), result.end(), [&](const SeamStateMass& candidate) {
          return candidate.state == state;
        });
    if (found == result.end()) {
      result.push_back(SeamStateMass{state, atom.mass});
    } else {
      found->mass = found->mass + atom.mass;
    }
  }
  std::stable_sort(result.begin(), result.end(),
                   [](const SeamStateMass& lhs, const SeamStateMass& rhs) {
                     return state_less(lhs.state, rhs.state);
                   });
  return result;
}

[[nodiscard]] bool seam_marginals_equal(
    const std::span<const SeamStateMass> left,
    const std::span<const SeamStateMass> right) {
  return left.size() == right.size() &&
         std::equal(left.begin(), left.end(), right.begin(),
                    [](const SeamStateMass& lhs, const SeamStateMass& rhs) {
                      return lhs.state == rhs.state && lhs.mass == rhs.mass;
                    });
}

}  // namespace

std::vector<StationaryTemporalAtomInspectionV1>
C21FixtureAccess::temporal_atoms(const StationaryTemporalLaw& law) {
  const auto& core = detail::C21CoreAccess::core(law);
  std::vector<StationaryTemporalAtomInspectionV1> result;
  if (!core.source) {
    return result;
  }
  result.reserve(core.source->atoms.size());
  for (const auto& atom : core.source->atoms) {
    result.push_back(StationaryTemporalAtomInspectionV1{
        atom.event_state_index, atom.word_index, atom.residence_offset,
        atom.stationary_left_state, atom.raw_edge,
        atom.stationary_right_state, atom.exact_mass,
        atom.numerical_mass});
  }
  return result;
}

Result<StationaryMetricEnvelopeInspectionV1>
C21FixtureAccess::decode_metric_envelope(const MetricValue& value) {
  EnvelopeReader reader(value.canonical_value);
  const auto version = reader.u32();
  const auto digest_bytes = reader.frame();
  if (!version.has_value() || *version != 1U ||
      !digest_bytes.has_value()) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope has an invalid version or source digest");
  }
  auto digest = Digest256::from_bytes(*digest_bytes);
  if (!digest) {
    return Result<StationaryMetricEnvelopeInspectionV1>::failure(
        digest.error());
  }
  const auto numerator_present = reader.byte();
  if (!numerator_present.has_value() || *numerator_present > 1U) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric numerator presence tag is invalid");
  }
  std::optional<ExactRational> numerator;
  if (*numerator_present == 1U) {
    numerator = read_rational(reader);
    if (!numerator.has_value()) {
      return fail<StationaryMetricEnvelopeInspectionV1>(
          "c21.test_metric_envelope_malformed",
          "the C21 metric numerator is not a canonical rational");
    }
  }
  const auto denominator = read_rational(reader);
  const auto ratio_present = reader.byte();
  if (!denominator.has_value() || !ratio_present.has_value() ||
      *ratio_present > 1U) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric denominator or ratio tag is invalid");
  }
  std::optional<ExactRational> ratio;
  if (*ratio_present == 1U) {
    ratio = read_rational(reader);
    if (!ratio.has_value()) {
      return fail<StationaryMetricEnvelopeInspectionV1>(
          "c21.test_metric_envelope_malformed",
          "the C21 metric ratio is not a canonical rational");
    }
  }
  const auto absolute_numerator = read_rational(reader);
  const auto residual_bound_value = read_rational(reader);
  const auto infinity = reader.byte();
  if (!absolute_numerator.has_value() ||
      !residual_bound_value.has_value() || !infinity.has_value() ||
      *infinity > 1U) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope has an invalid absolute numerator, "
        "residual bound, or infinity tag");
  }
  if (!reader.exhausted()) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope has trailing bytes");
  }
  if (!denominator->is_positive()) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope denominator is not positive");
  }
  if (!absolute_numerator->is_nonnegative()) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope absolute numerator is negative");
  }
  if (!residual_bound_value->is_nonnegative()) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope residual bound is negative");
  }
  if ((*infinity == 1U && (numerator.has_value() || ratio.has_value())) ||
      (*infinity == 0U && (!numerator.has_value() || !ratio.has_value()))) {
    return fail<StationaryMetricEnvelopeInspectionV1>(
        "c21.test_metric_envelope_malformed",
        "the C21 metric envelope finite/infinite presence tags disagree");
  }
  const long double positive_infinity =
      std::numeric_limits<long double>::infinity();
  return Result<StationaryMetricEnvelopeInspectionV1>::success(
      StationaryMetricEnvelopeInspectionV1{
          std::move(digest).value(), numerator, *denominator, ratio,
          numerator ? numerator->to_long_double() : positive_infinity,
          denominator->to_long_double(),
          ratio ? ratio->to_long_double() : positive_infinity,
          absolute_numerator->to_long_double(),
          residual_bound_value->to_long_double(), *infinity == 1U});
}

Result<StationaryBacklogPmfInspectionV1>
C21FixtureAccess::decode_stationary_backlog_pmf(const MetricValue& value) {
  if (!codec_is(value, "mwperf.c21.stationary_backlog_pmf")) {
    return fail<StationaryBacklogPmfInspectionV1>(
        "c21.test_stationary_pmf_codec_mismatch",
        "the metric value does not use the C21 stationary backlog PMF "
        "codec");
  }
  EnvelopeReader reader(value.canonical_value);
  const auto version = reader.u32();
  auto digest = read_digest(reader);
  const auto domain = reader.byte();
  if (!version.has_value() || *version != 1U || !digest.has_value() ||
      !domain.has_value() || *domain > 1U) {
    return fail<StationaryBacklogPmfInspectionV1>(
        "c21.test_stationary_pmf_malformed",
        "the stationary backlog PMF has an invalid version, binding, or "
        "domain tag");
  }
  const bool complete = *domain == 0U;
  std::optional<BigNat> max_level;
  if (!complete) {
    max_level = read_natural(reader);
    if (!max_level.has_value()) {
      return fail<StationaryBacklogPmfInspectionV1>(
          "c21.test_stationary_pmf_malformed",
          "the stationary backlog PMF output window has no canonical "
          "maximum level");
    }
  }
  const auto count = reader.u32();
  if (!count.has_value()) {
    return fail<StationaryBacklogPmfInspectionV1>(
        "c21.test_stationary_pmf_malformed",
        "the stationary backlog PMF has no atom count");
  }
  std::vector<StationaryBacklogPmfAtomInspectionV1> atoms;
  atoms.reserve(*count);
  ExactRational sum = ExactRational::zero();
  for (std::uint32_t index = 0U; index < *count; ++index) {
    auto level = read_natural(reader);
    auto mass = read_rational(reader);
    if (!level.has_value() || !mass.has_value() || !mass->is_positive() ||
        (!atoms.empty() && !(atoms.back().level < *level)) ||
        (max_level.has_value() && *max_level < *level)) {
      return fail<StationaryBacklogPmfInspectionV1>(
          "c21.test_stationary_pmf_malformed",
          "the stationary backlog PMF contains a noncanonical level or "
          "mass atom");
    }
    sum = sum + *mass;
    atoms.push_back(
        StationaryBacklogPmfAtomInspectionV1{std::move(*level), *mass});
  }
  auto returned = read_rational(reader);
  auto omitted = read_rational(reader);
  if (!returned.has_value() || !omitted.has_value() ||
      !returned->is_nonnegative() || !omitted->is_nonnegative() ||
      !(sum == *returned) ||
      !(*returned + *omitted == ExactRational::one()) ||
      (complete && !omitted->is_zero()) || !reader.exhausted()) {
    return fail<StationaryBacklogPmfInspectionV1>(
        "c21.test_stationary_pmf_malformed",
        "the stationary backlog PMF mass accounting is inconsistent or has "
        "trailing bytes");
  }
  return Result<StationaryBacklogPmfInspectionV1>::success(
      StationaryBacklogPmfInspectionV1{
          std::move(*digest), complete, std::move(max_level),
          std::move(atoms), *returned, *omitted});
}

Result<StationaryBacklogPgfInspectionV1>
C21FixtureAccess::decode_stationary_backlog_pgf(const MetricValue& value) {
  if (!codec_is(value, "mwperf.c21.stationary_backlog_pgf")) {
    return fail<StationaryBacklogPgfInspectionV1>(
        "c21.test_stationary_pgf_codec_mismatch",
        "the metric value does not use the C21 stationary backlog PGF "
        "codec");
  }
  EnvelopeReader reader(value.canonical_value);
  const auto version = reader.u32();
  auto digest = read_digest(reader);
  const auto count = reader.u32();
  if (!version.has_value() || *version != 1U || !digest.has_value() ||
      !count.has_value() || *count == 0U) {
    return fail<StationaryBacklogPgfInspectionV1>(
        "c21.test_stationary_pgf_malformed",
        "the stationary backlog PGF has an invalid version, binding, or "
        "point count");
  }
  std::vector<StationaryBacklogPgfAtomInspectionV1> atoms;
  atoms.reserve(*count);
  for (std::uint32_t index = 0U; index < *count; ++index) {
    auto point = read_rational(reader);
    auto exact_value = read_rational(reader);
    if (!point.has_value() || !exact_value.has_value() ||
        !std::isfinite(point->to_long_double()) ||
        !std::isfinite(exact_value->to_long_double()) ||
        (!atoms.empty() && !(atoms.back().point < *point))) {
      return fail<StationaryBacklogPgfInspectionV1>(
          "c21.test_stationary_pgf_malformed",
          "the stationary backlog PGF contains a noncanonical point/value "
          "pair");
    }
    atoms.push_back(StationaryBacklogPgfAtomInspectionV1{
        *point, *exact_value});
  }
  if (!reader.exhausted()) {
    return fail<StationaryBacklogPgfInspectionV1>(
        "c21.test_stationary_pgf_malformed",
        "the stationary backlog PGF has trailing bytes");
  }
  return Result<StationaryBacklogPgfInspectionV1>::success(
      StationaryBacklogPgfInspectionV1{std::move(*digest),
                                       std::move(atoms)});
}

Result<StationaryBacklogQuantileInspectionV1>
C21FixtureAccess::decode_stationary_backlog_quantile(
    const MetricValue& value) {
  if (!codec_is(value, "mwperf.c21.stationary_backlog_quantile")) {
    return fail<StationaryBacklogQuantileInspectionV1>(
        "c21.test_stationary_quantile_codec_mismatch",
        "the metric value does not use the C21 stationary backlog quantile "
        "codec");
  }
  EnvelopeReader reader(value.canonical_value);
  const auto version = reader.u32();
  auto digest = read_digest(reader);
  auto probability = read_rational(reader);
  const auto convention = reader.byte();
  auto quantile = read_natural(reader);
  auto cdf_below = read_rational(reader);
  auto cdf_at = read_rational(reader);
  if (!version.has_value() || *version != 1U || !digest.has_value() ||
      !probability.has_value() || !probability->is_positive() ||
      !(probability.value() < ExactRational::one()) ||
      !convention.has_value() ||
      *convention != static_cast<std::uint8_t>(
                         DiscreteQuantileConventionV1::lower_inverse_cdf) ||
      !quantile.has_value() || !cdf_below.has_value() ||
      !cdf_at.has_value() || !cdf_below->is_nonnegative() ||
      !cdf_at->is_nonnegative() || !(*cdf_below < *probability) ||
      *cdf_at < *probability || ExactRational::one() < *cdf_at ||
      !reader.exhausted()) {
    return fail<StationaryBacklogQuantileInspectionV1>(
        "c21.test_stationary_quantile_malformed",
        "the stationary backlog quantile is inconsistent or has trailing "
        "bytes");
  }
  return Result<StationaryBacklogQuantileInspectionV1>::success(
      StationaryBacklogQuantileInspectionV1{
          std::move(*digest), *probability,
          DiscreteQuantileConventionV1::lower_inverse_cdf,
          std::move(*quantile), *cdf_below, *cdf_at});
}

Result<C21MarkedEdgeCoalescingInspectionV1>
C21FixtureAccess::inspect_marked_edge_coalescing(
    std::vector<C21MarkedEdgeFixtureAtomV1> atoms) {
  std::vector<FluxMassInput> inputs;
  inputs.reserve(atoms.size());
  for (auto& atom : atoms) {
    inputs.push_back(FluxMassInput{std::move(atom.edge), atom.exact_mass,
                                   std::nullopt, std::nullopt});
  }
  auto coalesced = coalesce_flux_atoms(std::move(inputs));
  if (!coalesced) {
    return Result<C21MarkedEdgeCoalescingInspectionV1>::failure(
        coalesced.error());
  }
  ExactRational total = ExactRational::zero();
  ExactRational departures = ExactRational::zero();
  ExactRational arrivals = ExactRational::zero();
  bool queue_updates_hold = true;
  std::vector<std::pair<ReducedStateV1, ReducedStateV1>> endpoints;
  for (const CoalescedFluxAtom& atom : coalesced.value()) {
    total = total + atom.mass;
    const MarkedFluxEdgeV1& edge = atom.edge;
    queue_updates_hold =
        queue_updates_hold &&
        edge.prearrival_target_backlog.size() ==
            edge.target_departures.size() &&
        edge.target_departures.size() == edge.target_arrivals.size();
    if (queue_updates_hold) {
      for (std::size_t target = 0U;
           target < edge.target_departures.size(); ++target) {
        queue_updates_hold =
            queue_updates_hold &&
            BigInt(edge.target_departures[target]) <=
                edge.prearrival_target_backlog[target].value();
        auto arrival = rational_from_nat(edge.target_arrivals[target]);
        if (!arrival) {
          return Result<C21MarkedEdgeCoalescingInspectionV1>::failure(
              arrival.error());
        }
        departures = departures +
                     atom.mass *
                         ExactRational::make(
                             BigInt(edge.target_departures[target]),
                             BigInt{1})
                             .value();
        arrivals = arrivals + atom.mass * arrival.value();
      }
    }
    const bool endpoint_seen = std::any_of(
        endpoints.begin(), endpoints.end(), [&](const auto& candidate) {
          return candidate.first == edge.pre_state &&
                 candidate.second == edge.successor_state;
        });
    if (!endpoint_seen) {
      endpoints.emplace_back(edge.pre_state, edge.successor_state);
    }
  }
  const auto left = seam_state_marginal(coalesced.value(), true);
  const auto right = seam_state_marginal(coalesced.value(), false);
  const bool invariant = seam_marginals_equal(left, right);
  return Result<C21MarkedEdgeCoalescingInspectionV1>::success(
      C21MarkedEdgeCoalescingInspectionV1{
          coalesced.value().size(), endpoints.size(), total, departures,
          arrivals, queue_updates_hold, invariant, invariant});
}

Result<PositiveFiniteMeanDiagnosticsV1>
C21FixtureAccess::inspect_positive_finite_mean_evidence(
    C21MeanEvidenceFixtureV1 evidence) {
  const ExactRational upper =
      evidence.upper_bound.value_or(evidence.lower_bound);
  const ExactRational tail_upper =
      evidence.tail_upper.value_or(evidence.tail_lower);
  MeanEvidence validated{
      evidence.kind == C21MeanEvidenceKindV1::finite_exact
          ? ResidenceExpectationMethodV1::finite_exact_enumeration
          : ResidenceExpectationMethodV1::certified_tail_summation,
      evidence.kind == C21MeanEvidenceKindV1::finite_exact
          ? std::optional<ExactRational>{evidence.evaluated_sum}
          : std::nullopt,
      evidence.evaluated_sum,
      evidence.lower_bound,
      upper,
      evidence.tail_lower,
      tail_upper,
      evidence.support_complete,
      evidence.tail_certified,
      evidence.kind == C21MeanEvidenceKindV1::positive_infinity,
      evidence.kind == C21MeanEvidenceKindV1::arithmetic_overflow};
  if (evidence.kind == C21MeanEvidenceKindV1::uncertified_tail) {
    validated.support_complete = false;
    validated.tail_certified = false;
  }
  if ((evidence.kind == C21MeanEvidenceKindV1::finite_exact ||
       evidence.kind ==
           C21MeanEvidenceKindV1::certified_finite_enclosure) &&
      (!evidence.upper_bound.has_value() ||
       !evidence.tail_upper.has_value())) {
    return fail<PositiveFiniteMeanDiagnosticsV1>(
        "c21.mean_residence_tail_bound_missing",
        "finite mean evidence requires explicit denominator and tail upper "
        "bounds",
        DiagnosticCategory::unavailable);
  }
  const long double estimate =
      evidence.kind == C21MeanEvidenceKindV1::finite_exact
          ? evidence.evaluated_sum.to_long_double()
          : evidence.lower_bound.to_long_double();
  return validate_positive_finite_mean_evidence(validated, 0U, 0U, 0U,
                                                estimate, 0.0L);
}

Result<void>
C21FixtureAccess::inspect_missing_configured_phase_law_requirement() {
  return require_configured_slot_phase_law(std::nullopt);
}

}  // namespace testing
#endif

}  // namespace mwperf
