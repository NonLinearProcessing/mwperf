#include "artifact_auxiliary_validation.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <utility>
#include <vector>

namespace mwperf::artifact::detail {
namespace {

constexpr std::uint32_t kProtocolVersion = 1U;

template <typename T>
[[nodiscard]] Result<T> failure(std::string code, std::string message,
                                std::optional<std::string> path =
                                    std::nullopt) {
  return Result<T>::failure(
      Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), std::nullopt, std::move(path), {}});
}

template <typename Value>
[[nodiscard]] bool strictly_ordered_unique(
    const std::span<const Value> values) {
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (!(values[index - 1U] < values[index])) {
      return false;
    }
  }
  return true;
}

template <typename Value, typename Projection>
[[nodiscard]] bool strictly_ordered_unique_by(
    const std::span<const Value> values, Projection projection) {
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (!(projection(values[index - 1U]) < projection(values[index]))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool unique_targets(const std::span<const QueueId> values) {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    if (std::find(values.begin() + static_cast<std::ptrdiff_t>(left + 1U),
                  values.end(), values[left]) != values.end()) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool ordered_target_subset(
    const std::span<const QueueId> candidate,
    const std::span<const QueueId> accepted) {
  std::size_t accepted_index = 0U;
  for (const QueueId& target : candidate) {
    while (accepted_index < accepted.size() &&
           accepted[accepted_index] != target) {
      ++accepted_index;
    }
    if (accepted_index == accepted.size()) {
      return false;
    }
    ++accepted_index;
  }
  return true;
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

[[nodiscard]] bool portable_code(const std::string_view value) noexcept {
  if (value.empty()) {
    return false;
  }
  const auto ascii_alnum = [](const char character) {
    return (character >= '0' && character <= '9') ||
           (character >= 'A' && character <= 'Z') ||
           (character >= 'a' && character <= 'z');
  };
  if (!ascii_alnum(value.front())) {
    return false;
  }
  return std::all_of(
      value.begin(), value.end(), [ascii_alnum](const char character) {
        return ascii_alnum(character) || character == '.' ||
               character == '_' || character == ':' || character == '+' ||
               character == '-';
      });
}

[[nodiscard]] bool is_evidence_reference_kind(
    const ArtifactReferenceKindV1 kind) noexcept {
  return static_cast<std::uint8_t>(kind) >=
             static_cast<std::uint8_t>(
                 ArtifactReferenceKindV1::raw_response_bound_evidence) &&
         static_cast<std::uint8_t>(kind) <=
             static_cast<std::uint8_t>(
                 ArtifactReferenceKindV1::physical_transfer_evidence);
}

[[nodiscard]] bool manifest_allows_scope_pair(
    const MetricSupportManifest& manifest,
    const MetricResultScopeV1 result_scope,
    const MetricEvidenceScopeV1 evidence_scope) {
  for (const MetricSupportClauseV1& clause : manifest.clauses()) {
    if (std::any_of(
            clause.required_roles.begin(), clause.required_roles.end(),
            [result_scope, evidence_scope](
                const MetricSupportRoleRequirementV1& role) {
              return role.result_scope == result_scope &&
                     role.evidence_scope == evidence_scope;
            })) {
      return true;
    }
  }
  return false;
}

[[nodiscard]] bool contains_family_identity(
    const std::span<const FamilyEvidenceEnvelopeV1> family_evidence,
    const ArtifactObjectReferenceV1& identity) {
  return std::any_of(
      family_evidence.begin(), family_evidence.end(),
      [&identity](const FamilyEvidenceEnvelopeV1& evidence) {
        return evidence.evidence_id == identity;
      });
}

[[nodiscard]] bool valid_build_stage(const StageTag stage) noexcept {
  return stage == StageTag::surrogate_build_input ||
         stage == StageTag::surrogate_build_context ||
         stage == StageTag::surrogate_build_probe ||
         stage == StageTag::surrogate_build_final;
}

[[nodiscard]] Result<void> validate_provenance(
    const ArtifactProvenanceV1& provenance) {
  const auto empty_optional = [](const std::optional<std::string>& value) {
    return value.has_value() && value->empty();
  };
  if (empty_optional(provenance.source_document_id) ||
      empty_optional(provenance.source_revision_id) ||
      empty_optional(provenance.compiler_identity) ||
      (provenance.provider_source_digest.has_value() &&
       !nonzero_digest(*provenance.provider_source_digest)) ||
      (provenance.provider_build_digest.has_value() &&
       !nonzero_digest(*provenance.provider_build_digest))) {
    return failure<void>(
        "c15.provenance_optional_field_shape",
        "present provenance strings must be nonempty and present source/build "
        "digests must be nonzero",
        "/provenance");
  }

  if (!strictly_ordered_unique_by<ArtifactComponentDigestV1>(
          provenance.component_digests,
          [](const ArtifactComponentDigestV1& component)
              -> const std::string& { return component.component_name; }) ||
      std::any_of(provenance.component_digests.begin(),
                  provenance.component_digests.end(),
                  [](const ArtifactComponentDigestV1& component) {
                    return !portable_code(component.component_name) ||
                           !nonzero_digest(component.component_digest);
                  })) {
    return failure<void>(
        "c15.provenance_component_digest_order",
        "provenance component digests require canonical unique portable "
        "names and nonzero digests",
        "/provenance/component_digests");
  }
  if (!strictly_ordered_unique<std::string>(provenance.method_decisions) ||
      std::any_of(provenance.method_decisions.begin(),
                  provenance.method_decisions.end(),
                  [](const std::string& decision) {
                    return decision.empty();
                  })) {
    return failure<void>(
        "c15.provenance_method_decision_order",
        "provenance method decisions must be nonempty and form a canonical "
        "strictly ordered set",
        "/provenance/method_decisions");
  }
  if (!strictly_ordered_unique_by<SeedStreamCountV1>(
          provenance.seed_stream_counts,
          [](const SeedStreamCountV1& stream) {
            return std::tuple{stage_tag_value(stream.stage),
                              stream.stream_instance_id};
          }) ||
      std::any_of(provenance.seed_stream_counts.begin(),
                  provenance.seed_stream_counts.end(),
                  [](const SeedStreamCountV1& stream) {
                    return !valid_build_stage(stream.stage);
                  })) {
    return failure<void>(
        "c15.provenance_seed_stream_order",
        "provenance seed-stream counts require a closed build stage and one "
        "canonical unique stage/stream identity",
        "/provenance/seed_stream_counts");
  }
  return Result<void>::success();
}

}  // namespace

Result<void> validate_artifact_auxiliary_ledgers_v1(
    const std::span<const ScopedArtifactEvidenceV1> scoped_evidence,
    const std::span<const FamilyEvidenceEnvelopeV1> family_evidence,
    const std::span<const ArtifactDiagnosticComponentV1> diagnostics,
    const ArtifactProvenanceV1& provenance,
    const std::span<const QueueId> accepted_construction_target_scope,
    const MetricSupportManifest& accepted_structural_manifest) {
  if (!unique_targets(accepted_construction_target_scope)) {
    return failure<void>(
        "c15.auxiliary_invalid_accepted_targets",
        "accepted construction targets supplied to auxiliary validation must be "
        "duplicate-free");
  }
  if (!strictly_ordered_unique_by<ScopedArtifactEvidenceV1>(
          scoped_evidence,
          [](const ScopedArtifactEvidenceV1& evidence)
              -> const TypedLabel& { return evidence.evidence_id.object_id; })) {
    return failure<void>(
        "c15.scoped_evidence_ledger_order",
        "scoped evidence ledger must be canonical and unique by evidence "
        "object ID",
        "/scoped_evidence");
  }

  for (std::size_t index = 0U; index < scoped_evidence.size(); ++index) {
    const ScopedArtifactEvidenceV1& evidence = scoped_evidence[index];
    const std::string path = "/scoped_evidence/" + std::to_string(index);
    if (!is_evidence_reference_kind(evidence.reference_kind) ||
        metric_result_scope_bit_v1(evidence.result_scope) == 0U ||
        metric_evidence_scope_bit_v1(evidence.evidence_scope) == 0U ||
        !manifest_allows_scope_pair(accepted_structural_manifest,
                                    evidence.result_scope,
                                    evidence.evidence_scope)) {
      return failure<void>(
          "c15.scoped_evidence_scope_promotion",
          "scoped evidence kind/result/evidence scope is not one exact "
          "accepted metric-role scope",
          path);
    }
    if (evidence.ordered_targets.empty() ||
        !unique_targets(evidence.ordered_targets) ||
        !ordered_target_subset(evidence.ordered_targets,
                               accepted_construction_target_scope)) {
      return failure<void>(
          "c15.scoped_evidence_target_scope",
          "scoped evidence targets must be a nonempty duplicate-free "
          "order-preserving subset of the accepted construction targets",
          path + "/ordered_targets");
    }
    if (evidence.subject_references.empty() ||
        !strictly_ordered_unique<ArtifactObjectReferenceV1>(
            evidence.subject_references) ||
        !strictly_ordered_unique<ArtifactObjectReferenceV1>(
            evidence.parent_references) ||
        !strictly_ordered_unique<ArtifactObjectReferenceV1>(
            evidence.family_envelope_ids) ||
        !strictly_ordered_unique<RealizedInternalReferenceV1>(
            evidence.internal_references)) {
      return failure<void>(
          "c15.scoped_evidence_reference_order",
          "scoped evidence requires a nonempty canonical subject set and "
          "canonical unique parent/family/internal-reference ledgers",
          path);
    }
    if (std::find(evidence.parent_references.begin(),
                  evidence.parent_references.end(), evidence.evidence_id) !=
        evidence.parent_references.end()) {
      return failure<void>(
          "c15.scoped_evidence_self_parent",
          "scoped evidence cannot name its own identity as a lineage parent",
          path + "/parent_references");
    }
    if (!std::all_of(
            evidence.family_envelope_ids.begin(),
            evidence.family_envelope_ids.end(),
            [family_evidence](const ArtifactObjectReferenceV1& identity) {
              return contains_family_identity(family_evidence, identity);
            })) {
      return failure<void>(
          "c15.scoped_evidence_family_reference",
          "scoped evidence contains a dangling family-envelope reference",
          path + "/family_envelope_ids");
    }
    for (const RealizedInternalReferenceV1& relation :
         evidence.internal_references) {
      if (static_cast<std::uint8_t>(relation.relation) >
              static_cast<std::uint8_t>(
                  MetricRoleRelationKindV1::subject) ||
          internal_reference_purpose_bit_v1(relation.purpose) == 0U) {
        return failure<void>(
            "c15.scoped_evidence_internal_reference",
            "scoped evidence contains an unknown relation or internal "
            "reference purpose",
            path + "/internal_references");
      }
    }
    auto digest = scoped_artifact_evidence_digest_v1(evidence);
    if (!digest || digest.value() != evidence.evidence_id.object_digest) {
      return failure<void>(
          "c15.scoped_evidence_identity_mismatch",
          "scoped evidence identity does not match its canonical content "
          "digest with only its own digest omitted",
          path + "/evidence_id/object_digest");
    }
    if (std::any_of(
            family_evidence.begin(), family_evidence.end(),
            [&evidence](const FamilyEvidenceEnvelopeV1& family) {
              return family.evidence_id.object_id ==
                     evidence.evidence_id.object_id;
            })) {
      return failure<void>(
          "c15.evidence_object_id_collision",
          "family and scoped evidence ledgers cannot reuse one evidence "
          "object ID",
          path + "/evidence_id/object_id");
    }
  }

  if (!strictly_ordered_unique_by<ArtifactDiagnosticComponentV1>(
          diagnostics,
          [](const ArtifactDiagnosticComponentV1& item)
              -> const TypedLabel& { return item.diagnostic_id; })) {
    return failure<void>(
        "c15.diagnostic_ledger_order",
        "diagnostic components must be canonical and unique by diagnostic ID",
        "/diagnostic_components");
  }
  for (std::size_t index = 0U; index < diagnostics.size(); ++index) {
    const ArtifactDiagnosticComponentV1& item = diagnostics[index];
    const std::string path =
        "/diagnostic_components/" + std::to_string(index);
    if (item.diagnostic_schema_version != kProtocolVersion ||
        static_cast<std::uint8_t>(item.scope) >
            static_cast<std::uint8_t>(
                ArtifactDiagnosticScopeV1::physical_fidelity) ||
        !portable_code(item.code) || item.message.empty() ||
        !strictly_ordered_unique<ArtifactObjectReferenceV1>(
            item.subject_references) ||
        !strictly_ordered_unique<ArtifactObjectReferenceV1>(
            item.evidence_references)) {
      return failure<void>(
          "c15.diagnostic_component_shape",
          "diagnostic component has a non-v1 scope, empty text, nonportable "
          "code, or noncanonical reference set",
          path);
    }
  }

  return validate_provenance(provenance);
}

}  // namespace mwperf::artifact::detail
