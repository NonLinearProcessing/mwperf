#pragma once

#include <span>

#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf::artifact::detail {

// Private, noncatalog portion of F-C15-06.  This checks the generic scoped
// evidence, diagnostics and provenance ledgers without interpreting a
// provider theorem.  F-C15-06 remains responsible for resolving subject and
// parent references (and generic diagnostic evidence references) against the
// complete payload/product object ledger and for comparing evidence objects
// with realized metric-role bindings.
[[nodiscard]] Result<void> validate_artifact_auxiliary_ledgers_v1(
    std::span<const ScopedArtifactEvidenceV1> scoped_evidence,
    std::span<const FamilyEvidenceEnvelopeV1> family_evidence,
    std::span<const ArtifactDiagnosticComponentV1> diagnostics,
    const ArtifactProvenanceV1& provenance,
    std::span<const QueueId> accepted_construction_target_scope,
    const MetricSupportManifest& accepted_structural_manifest);

}  // namespace mwperf::artifact::detail
