#include "family_evidence_validation.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <nlohmann/json.hpp>

#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"

namespace mwperf::artifact::detail {
namespace {

using Json = nlohmann::ordered_json;

constexpr std::uint32_t kProtocolVersion = 1U;
constexpr std::size_t kHardMaximumBodyBytes = kNonScientificByteCeiling;
constexpr std::size_t kMaximumNestingDepth = 64U;
constexpr std::size_t kMaximumObjectEntries =
    std::numeric_limits<std::size_t>::max();
constexpr std::size_t kMaximumArrayEntries =
    std::numeric_limits<std::size_t>::max();
constexpr std::size_t kMaximumStringBytes = kNonScientificByteCeiling;
constexpr std::size_t kMaximumScalarCount =
    std::numeric_limits<std::size_t>::max();
constexpr std::size_t kMaximumDecodedAllocationBytes =
    kNonScientificByteCeiling;
constexpr std::size_t kMaximumRationalBits =
    std::numeric_limits<std::size_t>::max();
constexpr std::size_t kMaximumRationalDecimalDigits =
    std::numeric_limits<std::size_t>::max();

[[nodiscard]] Diagnostic diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::optional<std::string> path = std::nullopt) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::move(path), {}};
}

template <typename T>
[[nodiscard]] Result<T> failure(
    std::string code, std::string message,
    std::optional<std::string> path = std::nullopt,
    const DiagnosticCategory category = DiagnosticCategory::input_validation) {
  return Result<T>::failure(diagnostic(category, std::move(code),
                                       std::move(message), std::move(path)));
}

[[nodiscard]] std::optional<std::size_t> first_invalid_utf8(
    const std::span<const std::byte> bytes) noexcept {
  std::size_t offset = 0U;
  while (offset < bytes.size()) {
    const auto first = std::to_integer<unsigned char>(bytes[offset]);
    if (first <= 0x7fU) {
      ++offset;
      continue;
    }

    std::size_t continuation_count = 0U;
    std::uint32_t code_point = 0U;
    std::uint32_t minimum = 0U;
    if (first >= 0xc2U && first <= 0xdfU) {
      continuation_count = 1U;
      code_point = static_cast<std::uint32_t>(first & 0x1fU);
      minimum = 0x80U;
    } else if (first >= 0xe0U && first <= 0xefU) {
      continuation_count = 2U;
      code_point = static_cast<std::uint32_t>(first & 0x0fU);
      minimum = 0x800U;
    } else if (first >= 0xf0U && first <= 0xf4U) {
      continuation_count = 3U;
      code_point = static_cast<std::uint32_t>(first & 0x07U);
      minimum = 0x10000U;
    } else {
      return offset;
    }

    if (continuation_count > bytes.size() - offset - 1U) {
      return offset;
    }
    for (std::size_t index = 1U; index <= continuation_count; ++index) {
      const auto continuation =
          std::to_integer<unsigned char>(bytes[offset + index]);
      if ((continuation & 0xc0U) != 0x80U) {
        return offset + index;
      }
      code_point = (code_point << 6U) |
                   static_cast<std::uint32_t>(continuation & 0x3fU);
    }
    if (code_point < minimum || code_point > 0x10ffffU ||
        (code_point >= 0xd800U && code_point <= 0xdfffU)) {
      return offset;
    }
    offset += continuation_count + 1U;
  }
  return std::nullopt;
}

[[nodiscard]] bool has_exact_keys(
    const std::vector<std::string>& keys,
    const std::span<const std::string_view> expected) {
  if (keys.size() != expected.size()) {
    return false;
  }
  return std::all_of(expected.begin(), expected.end(),
                     [&keys](const std::string_view expected_key) {
                       return std::find(keys.begin(), keys.end(),
                                        expected_key) != keys.end();
                     });
}

[[nodiscard]] bool canonical_key_order(
    const std::vector<std::string>& keys) {
  static constexpr std::array<std::string_view, 3U> kRationalKeys{
      "kind", "numerator", "denominator"};
  static constexpr std::array<std::string_view, 2U> kBinary64Keys{
      "kind", "bits"};
  if (has_exact_keys(keys, kRationalKeys)) {
    return std::equal(keys.begin(), keys.end(), kRationalKeys.begin());
  }
  if (has_exact_keys(keys, kBinary64Keys)) {
    return std::equal(keys.begin(), keys.end(), kBinary64Keys.begin());
  }
  return std::adjacent_find(
             keys.begin(), keys.end(),
             [](const std::string& left, const std::string& right) {
               return left >= right;
             }) == keys.end();
}

// nlohmann's ordinary DOM construction retains the last decoded duplicate
// key.  This SAX pass therefore rejects duplicates, raw floating syntax and
// all fixed resource-limit violations before a DOM is allocated.
class FamilyBodyPreflight final : public nlohmann::json_sax<Json> {
 public:
  [[nodiscard]] bool null() override { return scalar_value(kNodeBytes); }
  [[nodiscard]] bool boolean(bool /*unused*/) override {
    return scalar_value(kNodeBytes);
  }
  [[nodiscard]] bool number_integer(number_integer_t /*unused*/) override {
    return scalar_value(kNodeBytes);
  }
  [[nodiscard]] bool number_unsigned(number_unsigned_t /*unused*/) override {
    return scalar_value(kNodeBytes);
  }
  [[nodiscard]] bool number_float(number_float_t /*unused*/,
                                  const string_t& /*unused*/) override {
    return reject(DiagnosticCategory::input_validation,
                  "c15.family_body_raw_float_forbidden",
                  "family evidence must encode scientific real values with "
                  "the reserved rational or binary64 scalar object");
  }
  [[nodiscard]] bool string(string_t& value) override {
    if (!check_string(value) ||
        !scalar_value(kNodeBytes + kStringBytes)) {
      return false;
    }
    // DOM, typed decode and scalar conversion buffers may coexist.
    return charge(value.size()) && charge(value.size()) &&
           charge(value.size());
  }
  [[nodiscard]] bool binary(binary_t& /*unused*/) override {
    return reject(DiagnosticCategory::input_validation,
                  "c15.family_body_binary_forbidden",
                  "family evidence bodies use canonical JSON, not a binary "
                  "JSON extension");
  }
  [[nodiscard]] bool start_object(std::size_t /*unused*/) override {
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= kMaximumNestingDepth) {
      return reject(DiagnosticCategory::resource_limit,
                    "c15.family_body_nesting_limit",
                    "family evidence body exceeds its fixed nesting-depth "
                    "limit");
    }
    if (!charge(kNodeBytes + kContainerBytes)) {
      return false;
    }
    frames_.push_back(Frame{FrameKind::object, {}});
    return true;
  }
  [[nodiscard]] bool key(string_t& value) override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject(DiagnosticCategory::input_validation,
                    "c15.family_body_invalid_json",
                    "family evidence body has an object key outside an "
                    "object");
    }
    if (!check_string(value)) {
      return false;
    }
    if (object_entries_ == kMaximumObjectEntries) {
      return reject(DiagnosticCategory::resource_limit,
                    "c15.family_body_object_entries_limit",
                    "family evidence body exceeds its fixed cumulative "
                    "object-entry limit");
    }
    ++object_entries_;
    Frame& frame = frames_.back();
    if (std::find(frame.keys.begin(), frame.keys.end(), value) !=
        frame.keys.end()) {
      return reject(DiagnosticCategory::input_validation,
                    "c15.family_body_duplicate_key",
                    "family evidence body contains a duplicate decoded "
                    "object key");
    }
    if (!charge(kStringBytes) || !charge(value.size())) {
      return false;
    }
    frame.keys.push_back(value);
    return true;
  }
  [[nodiscard]] bool end_object() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject(DiagnosticCategory::input_validation,
                    "c15.family_body_invalid_json",
                    "family evidence body has an unmatched object "
                    "terminator");
    }
    if (!canonical_key_order(frames_.back().keys)) {
      return reject(DiagnosticCategory::input_validation,
                    "c15.family_body_noncanonical_key_order",
                    "ordinary family-body object keys must be strictly "
                    "lexicographic; reserved scalar objects use their fixed "
                    "protocol order");
    }
    frames_.pop_back();
    return true;
  }
  [[nodiscard]] bool start_array(std::size_t /*unused*/) override {
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= kMaximumNestingDepth) {
      return reject(DiagnosticCategory::resource_limit,
                    "c15.family_body_nesting_limit",
                    "family evidence body exceeds its fixed nesting-depth "
                    "limit");
    }
    if (!charge(kNodeBytes + kContainerBytes)) {
      return false;
    }
    frames_.push_back(Frame{FrameKind::array, {}});
    return true;
  }
  [[nodiscard]] bool end_array() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::array) {
      return reject(DiagnosticCategory::input_validation,
                    "c15.family_body_invalid_json",
                    "family evidence body has an unmatched array "
                    "terminator");
    }
    frames_.pop_back();
    return true;
  }
  [[nodiscard]] bool parse_error(
      std::size_t /*position*/, const std::string& /*last_token*/,
      const nlohmann::detail::exception& error) override {
    if (!diagnostic_.has_value()) {
      diagnostic_ = diagnostic(
          DiagnosticCategory::input_validation,
          "c15.family_body_invalid_json",
          std::string("family evidence body is not strict JSON: ") +
              error.what());
    }
    return false;
  }

  [[nodiscard]] const std::optional<Diagnostic>& error() const noexcept {
    return diagnostic_;
  }

 private:
  static constexpr std::size_t kNodeBytes = 64U;
  static constexpr std::size_t kContainerBytes = 32U;
  static constexpr std::size_t kStringBytes = 32U;

  enum class FrameKind : std::uint8_t { object, array };
  struct Frame final {
    FrameKind kind;
    std::vector<std::string> keys;
  };

  [[nodiscard]] bool reject(const DiagnosticCategory category,
                            std::string code, std::string message) {
    if (!diagnostic_.has_value()) {
      diagnostic_ = diagnostic(category, std::move(code),
                               std::move(message));
    }
    return false;
  }
  [[nodiscard]] bool check_string(const std::string_view value) {
    if (value.size() > kMaximumStringBytes) {
      return reject(DiagnosticCategory::resource_limit,
                    "c15.family_body_string_limit",
                    "family evidence body contains a decoded string above "
                    "its fixed size limit");
    }
    return true;
  }
  [[nodiscard]] bool charge(const std::size_t amount) {
    if (amount > kMaximumDecodedAllocationBytes ||
        decoded_allocation_bytes_ >
            kMaximumDecodedAllocationBytes - amount) {
      return reject(DiagnosticCategory::resource_limit,
                    "c15.family_body_allocation_limit",
                    "family evidence body exceeds its fixed decoded "
                    "allocation limit");
    }
    decoded_allocation_bytes_ += amount;
    return true;
  }
  [[nodiscard]] bool begin_value() {
    if (!frames_.empty() && frames_.back().kind == FrameKind::array) {
      if (array_entries_ == kMaximumArrayEntries) {
        return reject(DiagnosticCategory::resource_limit,
                      "c15.family_body_array_entries_limit",
                      "family evidence body exceeds its fixed cumulative "
                      "array-entry limit");
      }
      ++array_entries_;
    }
    return true;
  }
  [[nodiscard]] bool scalar_value(const std::size_t allocation) {
    if (!begin_value()) {
      return false;
    }
    if (scalar_count_ == kMaximumScalarCount) {
      return reject(DiagnosticCategory::resource_limit,
                    "c15.family_body_scalar_limit",
                    "family evidence body exceeds its fixed scalar-count "
                    "limit");
    }
    ++scalar_count_;
    return charge(allocation);
  }

  std::vector<Frame> frames_;
  std::size_t object_entries_{0U};
  std::size_t array_entries_{0U};
  std::size_t scalar_count_{0U};
  std::size_t decoded_allocation_bytes_{0U};
  std::optional<Diagnostic> diagnostic_;
};

[[nodiscard]] std::string child_path(const std::string_view parent,
                                     const std::string_view child) {
  std::string result(parent);
  result.push_back('/');
  for (const char character : child) {
    if (character == '~') {
      result += "~0";
    } else if (character == '/') {
      result += "~1";
    } else {
      result.push_back(character);
    }
  }
  return result;
}

[[nodiscard]] Result<void> validate_body_node(
    const Json& value, const std::string& path) {
  if (value.is_object()) {
    const bool has_kind = value.contains("kind");
    const bool kind_is_string = has_kind && value.at("kind").is_string();
    const std::string kind =
        kind_is_string ? value.at("kind").get<std::string>() : std::string{};
    const bool reserved_rational = kind == "rational";
    const bool reserved_binary64 = kind == "binary64";
    const bool rational_key_shape =
        value.size() == 3U && value.contains("kind") &&
        value.contains("numerator") && value.contains("denominator");
    const bool binary_key_shape =
        value.size() == 2U && value.contains("kind") &&
        value.contains("bits");

    if (reserved_rational || rational_key_shape) {
      if (!reserved_rational || !rational_key_shape ||
          !value.at("numerator").is_string() ||
          !value.at("denominator").is_string()) {
        return failure<void>(
            "c15.family_body_rational_shape",
            "reserved rational scalar requires exactly kind, numerator and "
            "denominator strings", path);
      }
      auto parsed = PortableScientificScalar::parse_rational(
          value.at("numerator").get<std::string>(),
          value.at("denominator").get<std::string>(),
          RationalBoundPolicy{kMaximumRationalBits,
                              kMaximumRationalDecimalDigits});
      if (!parsed) {
        return Result<void>::failure(parsed.error());
      }
      return Result<void>::success();
    }
    if (reserved_binary64 || binary_key_shape) {
      if (!reserved_binary64 || !binary_key_shape ||
          !value.at("bits").is_string()) {
        return failure<void>(
            "c15.family_body_binary64_shape",
            "reserved binary64 scalar requires exactly kind and bits "
            "strings", path);
      }
      auto parsed = PortableScientificScalar::parse_binary64(
          value.at("bits").get<std::string>());
      if (!parsed) {
        return Result<void>::failure(parsed.error());
      }
      return Result<void>::success();
    }

    for (auto iterator = value.begin(); iterator != value.end(); ++iterator) {
      auto valid = validate_body_node(*iterator,
                                      child_path(path, iterator.key()));
      if (!valid) {
        return valid;
      }
    }
  } else if (value.is_array()) {
    for (std::size_t index = 0U; index < value.size(); ++index) {
      auto valid = validate_body_node(
          value[index], child_path(path, std::to_string(index)));
      if (!valid) {
        return valid;
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_canonical_body(
    const std::span<const std::byte> bytes) {
  try {
    if (bytes.empty()) {
      return failure<void>("c15.family_body_empty",
                           "canonical family evidence body must be nonempty",
                           "/canonical_family_body");
    }
    if (bytes.size() >= 3U &&
        std::to_integer<unsigned char>(bytes[0U]) == 0xefU &&
        std::to_integer<unsigned char>(bytes[1U]) == 0xbbU &&
        std::to_integer<unsigned char>(bytes[2U]) == 0xbfU) {
      return failure<void>(
          "c15.family_body_bom_forbidden",
          "canonical family evidence body must not begin with a UTF-8 BOM",
          "/canonical_family_body");
    }
    if (first_invalid_utf8(bytes).has_value()) {
      return failure<void>("c15.family_body_invalid_utf8",
                           "family evidence body is not valid UTF-8",
                           "/canonical_family_body");
    }

    const char* const begin = reinterpret_cast<const char*>(bytes.data());
    const char* const end = begin + bytes.size();
    FamilyBodyPreflight preflight;
    const bool preflight_ok = Json::sax_parse(
        begin, end, &preflight, Json::input_format_t::json, true, false);
    if (!preflight_ok) {
      if (preflight.error().has_value()) {
        return Result<void>::failure(*preflight.error());
      }
      return failure<void>("c15.family_body_invalid_json",
                           "family evidence body is not strict JSON",
                           "/canonical_family_body");
    }

    const Json document = Json::parse(begin, end, nullptr, true, false);
    auto valid_nodes =
        validate_body_node(document, "/canonical_family_body");
    if (!valid_nodes) {
      return valid_nodes;
    }
    const std::string canonical = document.dump();
    if (canonical.size() != bytes.size() ||
        !std::equal(canonical.begin(), canonical.end(), begin)) {
      return failure<void>(
          "c15.family_body_noncanonical_json",
          "family evidence body is valid JSON but not its exact canonical "
          "encoding", "/canonical_family_body");
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return failure<void>(
        "c15.family_body_allocation_failure",
        "allocation failed within the fixed family evidence body bounds",
        "/canonical_family_body", DiagnosticCategory::resource_limit);
  } catch (const std::length_error&) {
    return failure<void>(
        "c15.family_body_length_failure",
        "family evidence body exceeded a bounded container size",
        "/canonical_family_body", DiagnosticCategory::resource_limit);
  } catch (const nlohmann::json::exception& error) {
    return failure<void>(
        "c15.family_body_json_exception",
        std::string("family evidence body is not canonical JSON: ") +
            error.what(),
        "/canonical_family_body");
  } catch (const std::exception& error) {
    return failure<void>(
        "c15.family_body_validation_exception",
        std::string("unexpected family evidence body validation failure: ") +
            error.what(),
        "/canonical_family_body", DiagnosticCategory::internal);
  } catch (...) {
    return failure<void>(
        "c15.family_body_unknown_exception",
        "unknown family evidence body validation failure",
        "/canonical_family_body", DiagnosticCategory::internal);
  }
}

template <typename Value>
[[nodiscard]] bool strictly_ordered_unique(
    const std::span<const Value> values) {
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (!(values[index - 1U] < values[index])) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool unique_values(const std::span<const QueueId> values) {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    if (std::find(values.begin() + static_cast<std::ptrdiff_t>(left + 1U),
                  values.end(), values[left]) != values.end()) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool manifest_allows_evidence_scope(
    const MetricSupportManifest& manifest,
    const MetricEvidenceScopeV1 evidence_scope) {
  for (const MetricSupportClauseV1& clause : manifest.clauses()) {
    if (std::any_of(
            clause.required_roles.begin(), clause.required_roles.end(),
            [evidence_scope](const MetricSupportRoleRequirementV1& role) {
              return role.evidence_scope == evidence_scope;
            })) {
      return true;
    }
  }
  return false;
}

}  // namespace

Result<void> validate_family_evidence_ledger_v1(
    const std::span<const FamilyEvidenceEnvelopeV1> ledger,
    const ProviderIdentityV1& expected_provider,
    const Digest256& expected_scientific_contract_digest,
    const Digest256& expected_request_digest,
    const Digest256& expected_payload_digest,
    const std::span<const QueueId> accepted_construction_target_scope,
    const ValidatedProviderManifest& validated_full_manifest,
    const MetricSupportManifest& accepted_structural_manifest) {
  const SurrogateProviderManifestV1& manifest =
      validated_full_manifest.value();
  if (manifest.provider != expected_provider ||
      validated_full_manifest.scientific_contract_digest().value() !=
          expected_scientific_contract_digest) {
    return failure<void>(
        "c15.family_evidence_manifest_context_mismatch",
        "family evidence expectations do not match the validated full "
        "provider manifest");
  }
  if (!unique_values(accepted_construction_target_scope)) {
    return failure<void>(
        "c15.family_evidence_invalid_accepted_scope",
        "accepted construction-target scope must be duplicate-free");
  }
  for (std::size_t index = 1U; index < ledger.size(); ++index) {
    if (!(ledger[index - 1U].evidence_id.object_id <
          ledger[index].evidence_id.object_id)) {
      return failure<void>(
          "c15.family_evidence_noncanonical_ledger",
          "family evidence envelopes must be sorted uniquely by evidence "
          "object ID", "/family_evidence");
    }
  }

  for (std::size_t index = 0U; index < ledger.size(); ++index) {
    const FamilyEvidenceEnvelopeV1& evidence = ledger[index];
    const std::string path = "/family_evidence/" + std::to_string(index);
    if (evidence.envelope_version != kProtocolVersion) {
      return failure<void>("c15.family_evidence_unsupported_version",
                           "family evidence envelope version must equal one",
                           path + "/envelope_version");
    }

    const auto schema_matches = [&evidence](
                                    const FamilyEvidenceSchemaV1& schema) {
      return schema.schema_id == evidence.family_evidence_schema_id &&
             schema.schema_version ==
                 evidence.family_evidence_schema_version;
    };
    const auto schema_iterator = std::find_if(
        manifest.allowed_family_evidence_schemas.begin(),
        manifest.allowed_family_evidence_schemas.end(), schema_matches);
    if (schema_iterator == manifest.allowed_family_evidence_schemas.end() ||
        std::count_if(manifest.allowed_family_evidence_schemas.begin(),
                      manifest.allowed_family_evidence_schemas.end(),
                      schema_matches) != 1) {
      return failure<void>(
          "c15.family_evidence_schema_not_allowed",
          "family evidence schema ID/version does not resolve exactly once "
          "in the validated provider manifest",
          path + "/family_evidence_schema_id");
    }

    const auto anchor_matches = [&evidence](
                                    const FamilyEvidenceConformanceReportAnchorV1&
                                        anchor) {
      return anchor.family_evidence_schema_id ==
                 evidence.family_evidence_schema_id &&
             anchor.family_evidence_schema_version ==
                 evidence.family_evidence_schema_version;
    };
    const auto anchor_iterator = std::find_if(
        manifest.family_evidence_conformance_report_anchors.begin(),
        manifest.family_evidence_conformance_report_anchors.end(),
        anchor_matches);
    if (anchor_iterator ==
            manifest.family_evidence_conformance_report_anchors.end() ||
        std::count_if(
            manifest.family_evidence_conformance_report_anchors.begin(),
            manifest.family_evidence_conformance_report_anchors.end(),
            anchor_matches) != 1) {
      return failure<void>(
          "c15.family_evidence_conformance_anchor_missing",
          "family evidence schema does not resolve exactly one full-manifest "
          "conformance-report anchor",
          path + "/provider_conformance_report_ref");
    }

    const ProviderConformanceReportRef& report =
        evidence.provider_conformance_report_ref;
    if (report.report_schema_version != anchor_iterator->report_schema_version ||
        report.report_id != anchor_iterator->report_id ||
        report.report_digest != anchor_iterator->report_digest ||
        report.provider != expected_provider ||
        report.provider_scientific_contract_digest !=
            expected_scientific_contract_digest ||
        report.family_evidence_schema_id !=
            evidence.family_evidence_schema_id ||
        report.family_evidence_schema_version !=
            evidence.family_evidence_schema_version) {
      return failure<void>(
          "c15.family_evidence_conformance_report_mismatch",
          "provider conformance report reference does not exactly match its "
          "full-manifest schema anchor and artifact context",
          path + "/provider_conformance_report_ref");
    }
    if (evidence.provider != expected_provider ||
        evidence.provider_scientific_contract_digest !=
            expected_scientific_contract_digest ||
        evidence.request_digest != expected_request_digest ||
        evidence.payload_digest != expected_payload_digest) {
      return failure<void>(
          "c15.family_evidence_context_mismatch",
          "family evidence envelope has stale provider, scientific, request "
          "or payload identity",
          path);
    }

    const std::size_t maximum_body_bytes = std::min(
        schema_iterator->maximum_canonical_body_bytes,
        kHardMaximumBodyBytes);
    if (evidence.canonical_family_body.empty() ||
        evidence.canonical_family_body.size() > maximum_body_bytes) {
      return failure<void>(
          "c15.family_evidence_body_size",
          "canonical family evidence body is empty or exceeds the tighter "
          "schema/core byte ceiling",
          path + "/canonical_family_body",
          evidence.canonical_family_body.size() > maximum_body_bytes
              ? DiagnosticCategory::resource_limit
              : DiagnosticCategory::input_validation);
    }
    auto body_valid = validate_canonical_body(evidence.canonical_family_body);
    if (!body_valid) {
      return body_valid;
    }
    auto body_digest =
        family_evidence_body_digest_v1(evidence.canonical_family_body);
    if (!body_digest ||
        body_digest.value() != evidence.canonical_family_body_digest) {
      return failure<void>(
          "c15.family_evidence_body_digest_mismatch",
          "canonical family evidence body does not match its "
          "domain-separated digest",
          path + "/canonical_family_body_digest");
    }

    if (!strictly_ordered_unique<ArtifactObjectReferenceV1>(
            evidence.subject_references) ||
        !strictly_ordered_unique<ArtifactObjectReferenceV1>(
            evidence.parent_references)) {
      return failure<void>(
          "c15.family_evidence_noncanonical_references",
          "family evidence subject and parent references must be canonical "
          "strictly ordered sets",
          path);
    }
    if (metric_evidence_scope_bit_v1(evidence.evidence_scope_tag) == 0U ||
        !manifest_allows_evidence_scope(accepted_structural_manifest,
                                        evidence.evidence_scope_tag)) {
      return failure<void>(
          "c15.family_evidence_scope_promotion",
          "family evidence scope is outside every accepted manifest role",
          path + "/evidence_scope_tag");
    }
    if (evidence.evidence_scope_tag != MetricEvidenceScopeV1::none &&
        evidence.subject_references.empty()) {
      return failure<void>(
          "c15.family_evidence_subject_required",
          "a scoped family evidence claim requires at least one canonical "
          "subject reference",
          path + "/subject_references");
    }
    if (!unique_values(evidence.construction_target_scope) ||
        !std::equal(evidence.construction_target_scope.begin(),
                    evidence.construction_target_scope.end(),
                    accepted_construction_target_scope.begin(),
                    accepted_construction_target_scope.end())) {
      return failure<void>(
          "c15.family_evidence_target_scope_mismatch",
          "family evidence construction targets must exactly equal the "
          "duplicate-free accepted construction scope and order",
          path + "/construction_target_scope");
    }

    auto envelope_digest = family_evidence_envelope_digest_v1(evidence);
    if (!envelope_digest ||
        envelope_digest.value() != evidence.evidence_id.object_digest) {
      return failure<void>(
          "c15.family_evidence_identity_mismatch",
          "family evidence identity does not match the canonical envelope "
          "digest with only its own object digest omitted",
          path + "/evidence_id/object_digest");
    }
  }
  return Result<void>::success();
}

}  // namespace mwperf::artifact::detail
