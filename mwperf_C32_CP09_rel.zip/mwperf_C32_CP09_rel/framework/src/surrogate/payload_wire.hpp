#pragma once

#include <cstdint>

#include <nlohmann/json.hpp>

#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf::artifact::detail {

using OrderedJson = nlohmann::ordered_json;

namespace wire {

[[nodiscard]] OrderedJson encode_typed_label(const TypedLabel& value);
[[nodiscard]] Result<TypedLabel> decode_typed_label(const OrderedJson& value,
                                                    std::string path);
[[nodiscard]] OrderedJson encode_digest(const Digest256& value);
[[nodiscard]] Result<Digest256> decode_digest(const OrderedJson& value,
                                              std::string path);
[[nodiscard]] OrderedJson encode_big_nat(const BigNat& value);
[[nodiscard]] Result<BigNat> decode_big_nat(const OrderedJson& value,
                                            std::string path);
[[nodiscard]] OrderedJson encode_scalar(
    const PortableScientificScalar& value);
[[nodiscard]] Result<PortableScientificScalar> decode_scalar(
    const OrderedJson& value, std::string path);
[[nodiscard]] OrderedJson encode_artifact_object_reference(
    const ArtifactObjectReferenceV1& value);
[[nodiscard]] Result<ArtifactObjectReferenceV1>
decode_artifact_object_reference(const OrderedJson& value, std::string path);

[[nodiscard]] OrderedJson encode_payload_wire_v1(
    const ArtifactPayloadV1& payload);
[[nodiscard]] Result<ArtifactPayloadV1> decode_payload_wire_v1(
    const OrderedJson& payload, const PayloadWireAccess& access,
    std::string path = "/artifact/payload");

}  // namespace wire
}  // namespace mwperf::artifact::detail
