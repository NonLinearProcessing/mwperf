#include "mwperf/surrogate/surrogate_artifact.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <map>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"

namespace mwperf::artifact::detail {
namespace {

[[nodiscard]] Result<void> schedule_failure(std::string code,
                                            std::string message,
                                            std::string pointer) {
  return Result<void>::failure(Diagnostic{
      DiagnosticCategory::input_validation, std::move(code),
      std::move(message), std::nullopt, std::move(pointer), {}});
}

template <typename Value>
[[nodiscard]] bool contains(const std::set<Value>& values,
                            const Value& value) {
  return values.find(value) != values.end();
}

struct CatalogView final {
  std::map<QueueId, std::size_t> ordinal_by_queue;
  std::vector<QueueId> queues;
};

[[nodiscard]] Result<CatalogView> validate_catalog(
    const FrameworkProblemView& problem_view) {
  CatalogView result;
  result.queues.reserve(problem_view.queues().size());
  for (std::size_t ordinal = 0U; ordinal < problem_view.queues().size();
       ++ordinal) {
    const auto& entry = problem_view.queues()[ordinal];
    if (entry.dense_index != ordinal) {
      return Result<CatalogView>::failure(Diagnostic{
          DiagnosticCategory::input_validation,
          "c15.common_schedule_noncanonical_queue_catalog",
          "the portable queue catalog dense indices are not canonical",
          std::nullopt, "/framework_problem_view/queues", {}});
    }
    if (!result.ordinal_by_queue.emplace(entry.queue_id, ordinal).second) {
      return Result<CatalogView>::failure(Diagnostic{
          DiagnosticCategory::input_validation,
          "c15.common_schedule_duplicate_catalog_queue",
          "the portable queue catalog contains a duplicate queue identity",
          std::nullopt, "/framework_problem_view/queues", {}});
    }
    result.queues.push_back(entry.queue_id);
  }
  return Result<CatalogView>::success(std::move(result));
}

template <typename Id>
[[nodiscard]] Result<void> require_unique_domain(
    const std::vector<Id>& values, const std::string& pointer,
    const std::string& domain_name, const bool require_nonempty) {
  if (require_nonempty && values.empty()) {
    return schedule_failure(
        "c15.common_schedule_empty_geometry_domain",
        "the " + domain_name + " domain must not be empty", pointer);
  }
  std::set<Id> unique;
  for (const auto& value : values) {
    if (!unique.insert(value).second) {
      return schedule_failure(
          "c15.common_schedule_duplicate_geometry_id",
          "the " + domain_name + " domain contains a duplicate identity",
          pointer);
    }
  }
  return Result<void>::success();
}

template <typename Row, typename QueueOf>
[[nodiscard]] Result<void> require_exact_queue_coverage(
    const std::vector<Row>& rows, const CatalogView& catalog,
    const std::string& pointer, QueueOf&& queue_of) {
  if (rows.size() != catalog.queues.size()) {
    return schedule_failure(
        "c15.common_schedule_geometry_queue_coverage",
        "the portable constraint geometry must cover every catalog queue "
        "exactly once",
        pointer);
  }
  std::set<QueueId> seen;
  for (const auto& row : rows) {
    const QueueId& queue = queue_of(row);
    if (catalog.ordinal_by_queue.find(queue) ==
        catalog.ordinal_by_queue.end()) {
      return schedule_failure(
          "c15.common_schedule_unknown_geometry_queue",
          "the portable constraint geometry names an unknown queue", pointer);
    }
    if (!seen.insert(queue).second) {
      return schedule_failure(
          "c15.common_schedule_duplicate_geometry_queue",
          "the portable constraint geometry assigns a queue more than once",
          pointer);
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool exact_key(const SchedulerConstraintPairV1& actual,
                             const ServiceFamily family,
                             const OptimizerId optimizer) {
  return actual == SchedulerConstraintPairV1{family, optimizer};
}

[[nodiscard]] Result<void> validate_crossbar_geometry(
    const PortableCrossbarConstraintV1& geometry, const CatalogView& catalog,
    const SchedulerConstraintPairV1& key) {
  if (!exact_key(key, ServiceFamily::crossbar_matching,
                 OptimizerId::hungarian_exact)) {
    return schedule_failure(
        "c15.common_schedule_geometry_key_mismatch",
        "crossbar geometry requires the exact crossbar/Hungarian key",
        "/framework_problem_view/constraint_geometry");
  }
  auto inputs = require_unique_domain(
      geometry.inputs, "/framework_problem_view/constraint_geometry/inputs",
      "crossbar input", true);
  if (!inputs) return inputs;
  auto outputs = require_unique_domain(
      geometry.outputs, "/framework_problem_view/constraint_geometry/outputs",
      "crossbar output", true);
  if (!outputs) return outputs;
  auto coverage = require_exact_queue_coverage(
      geometry.edges, catalog,
      "/framework_problem_view/constraint_geometry/edges",
      [](const PortableCrossbarEdgeV1& edge) -> const QueueId& {
        return edge.queue;
      });
  if (!coverage) return coverage;

  const std::set<PortId> input_ids(geometry.inputs.begin(),
                                   geometry.inputs.end());
  const std::set<PortId> output_ids(geometry.outputs.begin(),
                                    geometry.outputs.end());
  std::set<std::pair<PortId, PortId>> endpoint_pairs;
  for (const auto& edge : geometry.edges) {
    if (!contains(input_ids, edge.input) ||
        !contains(output_ids, edge.output)) {
      return schedule_failure(
          "c15.common_schedule_unknown_crossbar_port",
          "a crossbar edge names an undeclared input or output",
          "/framework_problem_view/constraint_geometry/edges");
    }
    if (!endpoint_pairs.emplace(edge.input, edge.output).second) {
      return schedule_failure(
          "c15.common_schedule_duplicate_crossbar_edge",
          "two queue records use the same crossbar endpoint pair",
          "/framework_problem_view/constraint_geometry/edges");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_interval_geometry(
    const PortableIntervalConstraintV1& geometry, const CatalogView& catalog,
    const SchedulerConstraintPairV1& key) {
  if (!exact_key(key, ServiceFamily::nonoverlapping_intervals,
                 OptimizerId::weighted_interval_dp_exact)) {
    return schedule_failure(
        "c15.common_schedule_geometry_key_mismatch",
        "interval geometry requires the exact interval/weighted-DP key",
        "/framework_problem_view/constraint_geometry");
  }
  auto coverage = require_exact_queue_coverage(
      geometry.intervals, catalog,
      "/framework_problem_view/constraint_geometry/intervals",
      [](const PortableIntervalV1& interval) -> const QueueId& {
        return interval.queue;
      });
  if (!coverage) return coverage;
  for (const auto& interval : geometry.intervals) {
    if (!(interval.left < interval.right)) {
      return schedule_failure(
          "c15.common_schedule_invalid_interval",
          "a portable interval must satisfy exact left < right",
          "/framework_problem_view/constraint_geometry/intervals");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_node_geometry(
    const PortableNodeExclusiveConstraintV1& geometry,
    const CatalogView& catalog, const SchedulerConstraintPairV1& key) {
  if (!exact_key(key, ServiceFamily::node_exclusive_matching,
                 OptimizerId::edmonds_blossom_exact)) {
    return schedule_failure(
        "c15.common_schedule_geometry_key_mismatch",
        "node-exclusive geometry requires the exact matching/Blossom key",
        "/framework_problem_view/constraint_geometry");
  }
  auto vertices = require_unique_domain(
      geometry.vertices,
      "/framework_problem_view/constraint_geometry/vertices",
      "node-exclusive vertex", true);
  if (!vertices) return vertices;
  auto coverage = require_exact_queue_coverage(
      geometry.links, catalog,
      "/framework_problem_view/constraint_geometry/links",
      [](const PortableNodeExclusiveLinkV1& link) -> const QueueId& {
        return link.queue;
      });
  if (!coverage) return coverage;
  if (geometry.links.empty()) {
    return schedule_failure(
        "c15.common_schedule_empty_node_link_set",
        "node-exclusive geometry must contain a queue-labelled link",
        "/framework_problem_view/constraint_geometry/links");
  }
  const std::set<VertexId> vertex_ids(geometry.vertices.begin(),
                                      geometry.vertices.end());
  for (const auto& link : geometry.links) {
    if (!contains(vertex_ids, link.u) || !contains(vertex_ids, link.v)) {
      return schedule_failure(
          "c15.common_schedule_unknown_link_vertex",
          "a node-exclusive link names an undeclared endpoint",
          "/framework_problem_view/constraint_geometry/links");
    }
    if (link.u == link.v) {
      return schedule_failure(
          "c15.common_schedule_self_link",
          "a node-exclusive link must have distinct endpoints",
          "/framework_problem_view/constraint_geometry/links");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_conflict_geometry(
    const PortableConflictConstraintV1& geometry, const CatalogView& catalog,
    const SchedulerConstraintPairV1& key) {
  if (!exact_key(key, ServiceFamily::pairwise_conflicts,
                 OptimizerId::mwis_branch_memo_exact)) {
    return schedule_failure(
        "c15.common_schedule_geometry_key_mismatch",
        "conflict geometry requires the exact conflict/MWIS key",
        "/framework_problem_view/constraint_geometry");
  }
  if (geometry.queues != catalog.queues) {
    return schedule_failure(
        "c15.common_schedule_conflict_catalog_mismatch",
        "the conflict queue domain must equal the canonical queue catalog",
        "/framework_problem_view/constraint_geometry/queues");
  }
  std::set<std::pair<std::size_t, std::size_t>> pairs;
  for (const auto& pair : geometry.conflicts) {
    const auto first = catalog.ordinal_by_queue.find(pair.first);
    const auto second = catalog.ordinal_by_queue.find(pair.second);
    if (first == catalog.ordinal_by_queue.end() ||
        second == catalog.ordinal_by_queue.end()) {
      return schedule_failure(
          "c15.common_schedule_unknown_conflict_queue",
          "a conflict pair names an unknown queue",
          "/framework_problem_view/constraint_geometry/conflicts");
    }
    if (first->second >= second->second) {
      return schedule_failure(
          "c15.common_schedule_noncanonical_conflict_pair",
          "each conflict pair must contain two distinct queues in canonical "
          "catalog order",
          "/framework_problem_view/constraint_geometry/conflicts");
    }
    if (!pairs.emplace(first->second, second->second).second) {
      return schedule_failure(
          "c15.common_schedule_duplicate_conflict_pair",
          "an undirected conflict pair occurs more than once",
          "/framework_problem_view/constraint_geometry/conflicts");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_packing_geometry(
    const PortablePackingConstraintV1& geometry, const CatalogView& catalog,
    const SchedulerConstraintPairV1& key) {
  if (!exact_key(key, ServiceFamily::resource_packing,
                 OptimizerId::binary_packing_memo_exact)) {
    return schedule_failure(
        "c15.common_schedule_geometry_key_mismatch",
        "packing geometry requires the exact packing/binary-recursion key",
        "/framework_problem_view/constraint_geometry");
  }
  auto resources = require_unique_domain(
      geometry.resources,
      "/framework_problem_view/constraint_geometry/resources",
      "packing resource", false);
  if (!resources) return resources;
  if (geometry.capacity.size() != geometry.resources.size()) {
    return schedule_failure(
        "c15.common_schedule_packing_capacity_dimension",
        "the packing capacity vector must align with the resource domain",
        "/framework_problem_view/constraint_geometry/capacity");
  }
  auto coverage = require_exact_queue_coverage(
      geometry.demands, catalog,
      "/framework_problem_view/constraint_geometry/demands",
      [](const PortablePackingDemandV1& demand) -> const QueueId& {
        return demand.queue;
      });
  if (!coverage) return coverage;
  for (const auto& demand : geometry.demands) {
    if (demand.demand.size() != geometry.resources.size()) {
      return schedule_failure(
          "c15.common_schedule_packing_demand_dimension",
          "every packing demand vector must align with the resource domain",
          "/framework_problem_view/constraint_geometry/demands");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_geometry(
    const FrameworkProblemView& problem_view, const CatalogView& catalog) {
  return std::visit(
      [&catalog, &problem_view](const auto& geometry) -> Result<void> {
        using Geometry = std::decay_t<decltype(geometry)>;
        if constexpr (std::is_same_v<Geometry,
                                     PortableCrossbarConstraintV1>) {
          return validate_crossbar_geometry(
              geometry, catalog, problem_view.applicability_key());
        } else if constexpr (std::is_same_v<
                                 Geometry, PortableIntervalConstraintV1>) {
          return validate_interval_geometry(
              geometry, catalog, problem_view.applicability_key());
        } else if constexpr (std::is_same_v<
                                 Geometry,
                                 PortableNodeExclusiveConstraintV1>) {
          return validate_node_geometry(
              geometry, catalog, problem_view.applicability_key());
        } else if constexpr (std::is_same_v<
                                 Geometry, PortableConflictConstraintV1>) {
          return validate_conflict_geometry(
              geometry, catalog, problem_view.applicability_key());
        } else {
          return validate_packing_geometry(
              geometry, catalog, problem_view.applicability_key());
        }
      },
      problem_view.constraint_geometry());
}

[[nodiscard]] Result<void> validate_schedule_feasibility(
    const std::set<QueueId>& selected,
    const PortableConstraintGeometryV1& geometry) {
  return std::visit(
      [&selected](const auto& constraint) -> Result<void> {
        using Geometry = std::decay_t<decltype(constraint)>;
        if constexpr (std::is_same_v<Geometry,
                                     PortableCrossbarConstraintV1>) {
          std::set<PortId> used_inputs;
          std::set<PortId> used_outputs;
          for (const auto& edge : constraint.edges) {
            if (!contains(selected, edge.queue)) continue;
            if (!used_inputs.insert(edge.input).second ||
                !used_outputs.insert(edge.output).second) {
              return schedule_failure(
                  "c15.common_schedule_infeasible_crossbar",
                  "two selected crossbar edges share an endpoint",
                  "/common_schedule/selected_full_schedule");
            }
          }
        } else if constexpr (std::is_same_v<
                                 Geometry, PortableIntervalConstraintV1>) {
          std::vector<const PortableIntervalV1*> selected_intervals;
          for (const auto& interval : constraint.intervals) {
            if (contains(selected, interval.queue)) {
              selected_intervals.push_back(&interval);
            }
          }
          std::sort(selected_intervals.begin(), selected_intervals.end(),
                    [](const auto* left, const auto* right) {
                      if (left->left != right->left) {
                        return left->left < right->left;
                      }
                      if (left->right != right->right) {
                        return left->right < right->right;
                      }
                      return left->queue < right->queue;
                    });
          for (std::size_t index = 1U; index < selected_intervals.size();
               ++index) {
            if (!(selected_intervals[index - 1U]->right <=
                  selected_intervals[index]->left)) {
              return schedule_failure(
                  "c15.common_schedule_infeasible_interval",
                  "two selected half-open intervals overlap",
                  "/common_schedule/selected_full_schedule");
            }
          }
        } else if constexpr (std::is_same_v<
                                 Geometry,
                                 PortableNodeExclusiveConstraintV1>) {
          std::set<VertexId> used_vertices;
          for (const auto& link : constraint.links) {
            if (!contains(selected, link.queue)) continue;
            if (!used_vertices.insert(link.u).second ||
                !used_vertices.insert(link.v).second) {
              return schedule_failure(
                  "c15.common_schedule_infeasible_node_exclusive",
                  "two selected links share a node",
                  "/common_schedule/selected_full_schedule");
            }
          }
        } else if constexpr (std::is_same_v<
                                 Geometry, PortableConflictConstraintV1>) {
          for (const auto& pair : constraint.conflicts) {
            if (contains(selected, pair.first) &&
                contains(selected, pair.second)) {
              return schedule_failure(
                  "c15.common_schedule_infeasible_conflict",
                  "both endpoints of a conflict pair are selected",
                  "/common_schedule/selected_full_schedule");
            }
          }
        } else {
          std::vector<BigInt> used(constraint.resources.size(), BigInt{0});
          for (const auto& demand : constraint.demands) {
            if (!contains(selected, demand.queue)) continue;
            for (std::size_t resource = 0U; resource < used.size();
                 ++resource) {
              used[resource] += demand.demand[resource].value();
              if (used[resource] > constraint.capacity[resource].value()) {
                return schedule_failure(
                    "c15.common_schedule_infeasible_packing",
                    "selected packing demands exceed a resource capacity",
                    "/common_schedule/selected_full_schedule");
              }
            }
          }
        }
        return Result<void>::success();
      },
      geometry);
}

}  // namespace

Result<void> validate_common_schedule_realization_v1(
    const CommonScheduleRealizationV1& realization,
    const std::span<const QueueId> ordered_targets,
    const FrameworkProblemView& problem_view) {
  auto catalog_result = validate_catalog(problem_view);
  if (!catalog_result) {
    return Result<void>::failure(catalog_result.error());
  }
  const CatalogView& catalog = catalog_result.value();
  auto geometry_result = validate_geometry(problem_view, catalog);
  if (!geometry_result) return geometry_result;

  if (ordered_targets.empty()) {
    return schedule_failure(
        "c15.common_schedule_empty_target_vector",
        "a common schedule realization requires at least one target",
        "/common_schedule/ordered_targets");
  }
  std::set<QueueId> target_set;
  std::map<QueueId, std::size_t> target_position;
  for (std::size_t index = 0U; index < ordered_targets.size(); ++index) {
    const QueueId& target = ordered_targets[index];
    if (catalog.ordinal_by_queue.find(target) ==
        catalog.ordinal_by_queue.end()) {
      return schedule_failure(
          "c15.common_schedule_unknown_target",
          "the ordered target vector names an unknown queue",
          "/common_schedule/ordered_targets");
    }
    if (!target_set.insert(target).second) {
      return schedule_failure(
          "c15.common_schedule_duplicate_target",
          "the ordered target vector contains a duplicate queue",
          "/common_schedule/ordered_targets");
    }
    target_position.emplace(target, index);
  }

  const std::size_t target_count = ordered_targets.size();
  if (realization.current_target_backlogs.size() != target_count ||
      realization.retained_target_backlogs.size() != target_count ||
      realization.joint_target_departures.size() != target_count) {
    return schedule_failure(
        "c15.common_schedule_target_dimension",
        "current backlog, retained backlog, and departure vectors must align "
        "with the exact ordered target vector",
        "/common_schedule");
  }
  if (realization.selected_schedule_backlogs.size() !=
      realization.selected_full_schedule.size()) {
    return schedule_failure(
        "c15.common_schedule_selected_backlog_dimension",
        "selected-schedule backlogs must align with the selected schedule",
        "/common_schedule/selected_schedule_backlogs");
  }
  if (realization.structurally_witnessed_projection !=
      realization.projection_witness.has_value()) {
    return schedule_failure(
        "c15.common_schedule_projection_witness_shape",
        "the schedule-vector field is either an unwitnessed full schedule or "
        "a target projection with exactly one structural witness reference",
        "/common_schedule/projection_witness");
  }

  std::set<QueueId> selected;
  std::optional<std::size_t> previous_canonical_position;
  std::map<QueueId, std::size_t> selected_position;
  for (std::size_t index = 0U;
       index < realization.selected_full_schedule.size(); ++index) {
    const QueueId& queue = realization.selected_full_schedule[index];
    const auto catalog_entry = catalog.ordinal_by_queue.find(queue);
    if (catalog_entry == catalog.ordinal_by_queue.end()) {
      return schedule_failure(
          "c15.common_schedule_unknown_selected_queue",
          "the selected schedule names an unknown queue",
          "/common_schedule/selected_full_schedule");
    }
    // For the witnessed alternative this historically named field carries
    // proj_T(S), not a claim about omitted non-target coordinates.  The
    // unwitnessed alternative instead carries the complete selected schedule.
    if (realization.structurally_witnessed_projection &&
        !contains(target_set, queue)) {
      return schedule_failure(
          "c15.common_schedule_projection_outside_targets",
          "a witnessed target projection cannot contain a non-target queue",
          "/common_schedule/selected_full_schedule");
    }
    const std::size_t canonical_position =
        realization.structurally_witnessed_projection
            ? target_position.at(queue)
            : catalog_entry->second;
    if (previous_canonical_position.has_value() &&
        *previous_canonical_position >= canonical_position) {
      return schedule_failure(
          "c15.common_schedule_noncanonical_selected_schedule",
          "selected queues must be duplicate-free and follow the exact "
          "target order for a projection or queue-catalog order for a full "
          "schedule",
          "/common_schedule/selected_full_schedule");
    }
    previous_canonical_position = canonical_position;
    selected.insert(queue);
    selected_position.emplace(queue, index);
    if (realization.selected_schedule_backlogs[index].is_zero()) {
      return schedule_failure(
          "c15.common_schedule_ineligible_selected_queue",
          "every selected queue must have positive recorded pre-service "
          "backlog",
          "/common_schedule/selected_schedule_backlogs");
    }
  }

  for (std::size_t index = 0U; index < target_count; ++index) {
    const auto departure = realization.joint_target_departures[index];
    if (departure > 1U) {
      return schedule_failure(
          "c15.common_schedule_nonbinary_departure",
          "joint target departures must be binary",
          "/common_schedule/joint_target_departures");
    }
    const auto selected_iterator =
        selected_position.find(ordered_targets[index]);
    const bool target_selected = selected_iterator != selected_position.end();
    if ((departure == 1U) != target_selected) {
      return schedule_failure(
          "c15.common_schedule_service_departure_mismatch",
          "each target departure must equal its common-schedule service "
          "indicator",
          "/common_schedule/joint_target_departures");
    }
    if (target_selected &&
        realization.selected_schedule_backlogs[selected_iterator->second] !=
            realization.current_target_backlogs[index]) {
      return schedule_failure(
          "c15.common_schedule_selected_backlog_mismatch",
          "a selected target's schedule backlog must equal its current target "
          "backlog",
          "/common_schedule/current_target_backlogs");
    }
    const BigNat service(departure);
    auto retained = checked_subtract(
        realization.current_target_backlogs[index], service);
    if (!retained || retained.value() !=
                         realization.retained_target_backlogs[index]) {
      return schedule_failure(
          "c15.common_schedule_retained_backlog_mismatch",
          "retained target backlog must equal current backlog minus actual "
          "departure exactly",
          "/common_schedule/retained_target_backlogs");
    }
  }

  return validate_schedule_feasibility(selected,
                                       problem_view.constraint_geometry());
}

}  // namespace mwperf::artifact::detail
