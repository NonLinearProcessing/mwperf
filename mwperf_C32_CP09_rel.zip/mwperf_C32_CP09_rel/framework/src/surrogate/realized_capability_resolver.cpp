#include "mwperf/surrogate/surrogate_artifact.hpp"

#include <optional>
#include <vector>

namespace mwperf {
namespace {

[[nodiscard]] RealizedFailedCapabilitiesV1
requirements_mismatch_report() {
  return RealizedFailedCapabilitiesV1{
      ProviderFailureV1{ProviderFailureKindV1::invariant_violation,
        "requirements_not_exactly_accepted",
        "the requested metric requirements do not exactly equal the sealed accepted requirements for a validated Built result"}};
}

[[nodiscard]] std::vector<MetricClauseIdV1> canonical_accepted_clause_ids(
    const MetricRequirements& accepted) {
  std::vector<MetricClauseIdV1> clause_ids;
  clause_ids.reserve(accepted.clauses().size());
  for (const MetricRequirementClause& clause : accepted.clauses()) {
    clause_ids.push_back(clause.origin.clause_id);
  }
  return clause_ids;
}

}  // namespace

RealizedCapabilityReport resolve_realized_metric_capabilities(
    const ValidatedSurrogateBuildResult& result,
    const MetricRequirements& requirements) {
  const ValidatedSurrogateBuildResultValueV1& terminal = result.value();

  if (const auto* unavailable =
          std::get_if<ValidatedUnavailableResultV1>(&terminal)) {
    return RealizedUnavailableCapabilitiesV1{unavailable->result.reasons};
  }
  if (const auto* failed = std::get_if<ValidatedFailedResultV1>(&terminal)) {
    return RealizedFailedCapabilitiesV1{failed->result.failure};
  }

  const auto& built = std::get<ValidatedBuiltResultV1>(terminal);
  const MetricRequirements& accepted = result.accepted_requirements();
  if (!equivalent_metric_requirements(requirements, accepted)) {
    return requirements_mismatch_report();
  }

  return RealizedBuiltCapabilitiesV1{
      built.artifact_, canonical_accepted_clause_ids(accepted)};
}

}  // namespace mwperf
