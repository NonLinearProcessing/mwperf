#include "mwperf/surrogate/build_outcome.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <exception>
#include <filesystem>
#include <limits>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

#if defined(__unix__) || defined(__APPLE__)
#include <dirent.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

#if defined(__linux__)
#include <elf.h>
#include <linux/audit.h>
#include <linux/close_range.h>
#include <linux/filter.h>
#include <linux/landlock.h>
#include <linux/seccomp.h>
#include <linux/unistd.h>
#include <sched.h>
#include <stddef.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#endif

#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/core/sha256.hpp"

namespace mwperf {
namespace {

constexpr std::string_view kRequestArgument = "--request";
constexpr std::string_view kResultArgument = "--result";
constexpr std::string_view kRequestPlaceholder = "{request_path}";
constexpr std::string_view kResultPlaceholder = "{result_path}";
constexpr std::string_view kRequestFileName = "request-v1.json";
constexpr std::string_view kResultFileName = "result-v1.json";
// Diagnostics are part of the scientific failure record.  Do not silently
// truncate them at an unrelated administrative size.  The only remaining
// bound is the remote file/process ceiling shared by the transport.
constexpr std::size_t kMaximumStderrExcerptBytes =
    kNonScientificByteCeiling;

struct ResolvedProviderExecutionControls final {
  std::optional<std::size_t> worker_count;
  std::chrono::milliseconds wall_time_limit;
};

[[nodiscard]] Diagnostic error(const DiagnosticCategory category,
                               std::string code, std::string message) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::nullopt, {}};
}

[[nodiscard]] ProviderExecutionOutcome failed(Diagnostic diagnostic) {
  return FailedProviderExecution{std::move(diagnostic)};
}

[[nodiscard]] bool portable_identifier(const std::string_view value) {
  if (value.empty()) {
    return false;
  }
  const auto ascii_alphanumeric = [](const char character) {
    return (character >= '0' && character <= '9') ||
           (character >= 'A' && character <= 'Z') ||
           (character >= 'a' && character <= 'z');
  };
  if (!ascii_alphanumeric(value.front())) {
    return false;
  }
  return std::all_of(value.begin() + 1, value.end(),
                     [&](const char character) {
                       return ascii_alphanumeric(character) ||
                              character == '.' || character == '_' ||
                              character == ':' || character == '+' ||
                              character == '-';
                     });
}

[[nodiscard]] bool contains_nul(const std::string_view value) {
  return value.find('\0') != std::string_view::npos;
}

[[nodiscard]] bool path_contains_nul(
    const std::filesystem::path& value) noexcept {
  const auto& native = value.native();
  return std::find(native.begin(), native.end(),
                   std::filesystem::path::value_type{}) != native.end();
}

[[nodiscard]] bool is_reserved_argument(const std::string_view value) {
  return value == kRequestArgument || value == kResultArgument ||
         value.starts_with("--request=") || value.starts_with("--result=") ||
         value.find(kRequestPlaceholder) != std::string_view::npos ||
         value.find(kResultPlaceholder) != std::string_view::npos;
}

[[nodiscard]] Result<ResolvedProviderExecutionControls>
resolve_provider_execution_controls(
    const RegisteredExecutableSpec& spec,
    const ProviderExecutionControlsV1& controls) {
  const auto maximum_wall_time =
      spec.maximum_wall_time_limit().value_or(spec.wall_time_limit());
  const auto wall_time =
      controls.wall_time_limit.value_or(spec.wall_time_limit());
  if (wall_time.count() <= 0 || wall_time > maximum_wall_time) {
    return Result<ResolvedProviderExecutionControls>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.invalid_provider_execution_timeout",
        "the requested provider timeout is outside the registered host "
        "ceiling"));
  }
  if (controls.worker_count.has_value()) {
    if (!spec.maximum_worker_count().has_value() ||
        *controls.worker_count == 0U ||
        *controls.worker_count > *spec.maximum_worker_count()) {
      return Result<ResolvedProviderExecutionControls>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.invalid_provider_worker_count",
          "the requested provider worker count is outside the registered "
          "host capability"));
    }
  }
  return Result<ResolvedProviderExecutionControls>::success(
      ResolvedProviderExecutionControls{controls.worker_count, wall_time});
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0U};
                     });
}

[[nodiscard]] bool portable_provision(
    const AccessProvision provision) noexcept {
  return provision == AccessProvision::portable_only ||
         provision == AccessProvision::portable_and_process_local;
}

[[nodiscard]] bool process_local_provision(
    const AccessProvision provision) noexcept {
  return provision == AccessProvision::process_local_only ||
         provision == AccessProvision::portable_and_process_local;
}

[[nodiscard]] bool portable_law_is_reconstructible(
    const PortableArrivalLawDescriptor& law) noexcept {
  if (law.version != 1U || law.canonical_data.empty() ||
      !nonzero_digest(law.payload_digest)) {
    return false;
  }
  switch (law.schema) {
    case PortableArrivalLawSchema::deterministic_trace_v1:
    case PortableArrivalLawSchema::periodic_global_phase_v1:
    case PortableArrivalLawSchema::periodic_source_delays_v1:
    case PortableArrivalLawSchema::independent_marked_renewal_v1:
    case PortableArrivalLawSchema::independent_private_markov_renewal_v1:
    case PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1:
    case PortableArrivalLawSchema::iid_independent_bernoulli_v1:
    case PortableArrivalLawSchema::iid_count_table_v1:
    case PortableArrivalLawSchema::iid_independent_poisson_v1:
    case PortableArrivalLawSchema::iid_mixed_poisson_v1:
      return true;
  }
  return false;
}

[[nodiscard]] bool exact_domain_contains(
    const ExactArgumentDomain& offered,
    const ExactArgumentDomain& required) {
  if (offered.lower > required.lower || offered.upper < required.upper) {
    return false;
  }
  if (offered.lower == required.lower && required.lower_inclusive &&
      !offered.lower_inclusive) {
    return false;
  }
  if (offered.upper == required.upper && required.upper_inclusive &&
      !offered.upper_inclusive) {
    return false;
  }
  return true;
}

[[nodiscard]] bool portable_moment_satisfies(
    const MomentCapability& capability,
    const ArrivalAssumptionV1& assumption) {
  return portable_provision(capability.provision) &&
         (!assumption.joint || capability.joint) &&
         (!assumption.phase_conditioned ||
          capability.conditioned_on_phase) &&
         (!assumption.moment_order.has_value() ||
          !capability.maximum_order.has_value() ||
          *capability.maximum_order >= *assumption.moment_order);
}

[[nodiscard]] bool portable_transform_satisfies(
    const PortableTransformDescriptor& descriptor,
    const ArrivalAssumptionV1& assumption) {
  const TransformCapability& capability = descriptor.capability;
  return descriptor.codec_version != 0U &&
         !descriptor.canonical_parameters.empty() &&
         portable_provision(capability.provision) &&
         (!assumption.transform_kind.has_value() ||
          capability.kind == *assumption.transform_kind) &&
         (!assumption.distribution_scope.has_value() ||
          capability.scope == *assumption.distribution_scope) &&
         (!assumption.phase_conditioned ||
          capability.phase_requirement ==
              PhaseArgumentRequirement::explicit_phase_required) &&
         (!assumption.argument_domain.has_value() ||
          exact_domain_contains(capability.domain,
                                *assumption.argument_domain));
}

// This is the same callback-free reconstructibility decision used by C16's
// local-builder preview gate.  An `any` request needs a live service only when
// none of these portable witnesses is present.
[[nodiscard]] bool arrival_prerequisite_has_portable_witness(
    const BuilderArrivalView& arrival,
    const ArrivalAssumptionV1& assumption) {
  if (assumption.use != ArrivalCapabilityUseV1::construction ||
      assumption.provision == CapabilityProvisionNeedV1::process_local) {
    return false;
  }
  const ArrivalCapabilities& capabilities = arrival.capabilities();
  const bool portable_iid_joint =
      arrival.iid_joint_table().has_value() &&
      !arrival.iid_joint_table()->empty() &&
      capabilities.exact_iid_joint_vector.has_value() &&
      capabilities.exact_iid_joint_vector->finite_support &&
      portable_provision(
          capabilities.exact_iid_joint_vector->provision);
  const bool portable_finite_rows =
      arrival.finite_phase().has_value() &&
      arrival.transition_rows().has_value() &&
      capabilities.finite_enumerated_predictive_phase ==
          CapabilityAvailability::available &&
      capabilities.finite_enumerated_transition_row ==
          CapabilityAvailability::available;
  const bool portable_recipe =
      portable_law_is_reconstructible(arrival.configured_law());
  const bool portable_factorized_iid =
      capabilities.exact_factorized_iid_generator.has_value() &&
      portable_provision(
          capabilities.exact_factorized_iid_generator->provision) &&
      arrival.binding().family ==
          ArrivalFamily::independent_marked_renewal &&
      arrival.configured_law().schema ==
          PortableArrivalLawSchema::independent_marked_renewal_v1 &&
      portable_recipe;
  const bool portable_schema4_iid_recipe =
      capabilities.exact_portable_iid_recipe.has_value() &&
      portable_provision(
          capabilities.exact_portable_iid_recipe->provision) &&
      portable_recipe;
  switch (assumption.kind) {
    case ArrivalNeedKindV1::target_intensity: {
      ArrivalAssumptionV1 order_one = assumption;
      order_one.moment_order = BigNat{1U};
      return arrival.moments().has_value() &&
             !arrival.moments()->empty() &&
             ((capabilities.exact_coordinate_moments.has_value() &&
               portable_moment_satisfies(
                   *capabilities.exact_coordinate_moments, order_one)) ||
              (capabilities.analytic_moments.has_value() &&
               portable_moment_satisfies(*capabilities.analytic_moments,
                                          order_one)));
    }
    case ArrivalNeedKindV1::arrival_moment: {
      const std::optional<MomentCapability>& exact =
          assumption.joint ? capabilities.exact_joint_moments
                           : capabilities.exact_coordinate_moments;
      return arrival.moments().has_value() &&
             !arrival.moments()->empty() &&
             ((exact.has_value() &&
               portable_moment_satisfies(*exact, assumption)) ||
              (capabilities.analytic_moments.has_value() &&
               portable_moment_satisfies(*capabilities.analytic_moments,
                                          assumption)));
    }
    case ArrivalNeedKindV1::full_common_batch:
      return portable_iid_joint || portable_finite_rows || portable_recipe;
    case ArrivalNeedKindV1::finite_support:
      return portable_iid_joint || portable_finite_rows;
    case ArrivalNeedKindV1::exact_iid_late:
      return portable_iid_joint || portable_factorized_iid ||
             portable_schema4_iid_recipe;
    case ArrivalNeedKindV1::predictive_phase:
      return portable_finite_rows || portable_recipe;
    case ArrivalNeedKindV1::sequential_law:
      return portable_finite_rows ||
             (arrival.replay_codec().has_value() &&
              arrival.replay_codec()->codec_version != 0U &&
              arrival.replay_codec()->requires_complete_initial_state &&
              arrival.replay_codec()->preserves_adjacent_temporal_order &&
              !arrival.replay_codec()->canonical_parameters.empty() &&
              capabilities.adjacent_batch_replay.has_value() &&
              portable_provision(
                  capabilities.adjacent_batch_replay->provision)) ||
             portable_recipe;
    case ArrivalNeedKindV1::entrance_labels:
      return portable_iid_joint || portable_finite_rows || portable_recipe;
    case ArrivalNeedKindV1::transform: {
      const auto matches =
          [&](const std::optional<PortableTransformDescriptor>& descriptor) {
            return descriptor.has_value() &&
                   portable_transform_satisfies(*descriptor, assumption);
          };
      return matches(arrival.analytic_transform()) ||
             matches(arrival.joint_distribution()) ||
             matches(arrival.coordinate_distributions());
    }
  }
  return false;
}

enum class ArrivalServiceRequirement : std::uint8_t {
  none,
  adjacent_replay,
  unsupported,
};

[[nodiscard]] ArrivalServiceRequirement required_arrival_service(
    const SurrogateBuildRequest& request) {
  ArrivalServiceRequirement result = ArrivalServiceRequirement::none;
  const BuilderArrivalView& arrival =
      request.framework_problem_view().configured_arrival();
  for (const ArrivalAssumptionV1& assumption :
       request.accepted_capability_contract()
           .construction_prerequisites.arrival) {
    const bool requires_process_local =
        assumption.provision == CapabilityProvisionNeedV1::process_local ||
        (assumption.provision == CapabilityProvisionNeedV1::any &&
         !arrival_prerequisite_has_portable_witness(arrival, assumption));
    if (!requires_process_local) {
      continue;
    }
    if (assumption.kind != ArrivalNeedKindV1::sequential_law &&
        assumption.kind != ArrivalNeedKindV1::entrance_labels) {
      return ArrivalServiceRequirement::unsupported;
    }
    result = ArrivalServiceRequirement::adjacent_replay;
  }
  return result;
}

[[nodiscard]] bool request_replay_contract_is_complete(
    const BuilderArrivalView& arrival) {
  const auto& capability = arrival.capabilities().adjacent_batch_replay;
  const auto& codec = arrival.replay_codec();
  if (!capability.has_value() || !codec.has_value() ||
      !process_local_provision(capability->provision) ||
      arrival.capabilities().sequential_normalized_sampler !=
          CapabilityAvailability::available ||
      codec->codec_version == 0U ||
      !codec->requires_complete_initial_state ||
      !codec->preserves_adjacent_temporal_order ||
      codec->canonical_parameters.empty()) {
    return false;
  }
  return capability->explicit_initial_state || capability->explicit_phase ||
         capability->normalized_initial_law ||
         capability->named_stationary_initialization;
}

[[nodiscard]] bool exact_service_instance_matches_request(
    const ResolvedInstance& instance,
    const FrameworkProblemView& problem) {
  if (instance.fingerprints() != problem.fingerprints().authored_inputs ||
      instance.queues().size() != problem.queues().size() ||
      instance.priority().size() != problem.priority_order().size() ||
      instance.timing() != problem.timing()) {
    return false;
  }
  const DerivedServiceIdentity& service = instance.service_identity();
  if (service.family != problem.applicability_key().service_family ||
      service.optimizer != problem.applicability_key().optimizer) {
    return false;
  }
  for (std::size_t ordinal = 0U; ordinal < instance.queues().size();
       ++ordinal) {
    auto index = instance.queues().index_at(ordinal);
    if (!index || problem.queues()[ordinal].dense_index != ordinal ||
        instance.queues().queue_id(index.value()) !=
            problem.queues()[ordinal].queue_id) {
      return false;
    }
  }
  for (std::size_t rank = 0U; rank < instance.priority().size(); ++rank) {
    const DenseQueueIndex index = instance.priority().queue_at_rank(rank);
    if (instance.queues().queue_id(index) != problem.priority_order()[rank]) {
      return false;
    }
  }
  return true;
}

struct ValidatedExecutionRoot final {
  std::filesystem::path path;
  std::uintmax_t device{0U};
  std::uintmax_t inode{0U};
};

[[nodiscard]] Result<ValidatedExecutionRoot> validate_execution_root(
    const std::filesystem::path& supplied_root) {
  if (supplied_root.empty() || !supplied_root.is_absolute()) {
    return Result<ValidatedExecutionRoot>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_execution_root",
        "the workspace execution root must be an explicit absolute path"));
  }
  const auto normalized = supplied_root.lexically_normal();
  std::error_code status_error;
  const auto status = std::filesystem::symlink_status(normalized, status_error);
  if (status_error || status.type() != std::filesystem::file_type::directory) {
    return Result<ValidatedExecutionRoot>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_execution_root",
        "the workspace execution root must be an existing directory"));
  }
  std::error_code canonical_error;
  const auto canonical = std::filesystem::canonical(normalized,
                                                     canonical_error);
  if (canonical_error || canonical != normalized) {
    return Result<ValidatedExecutionRoot>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_execution_root",
        "the workspace execution root must be canonical and contain no symlink component"));
  }
#if defined(__unix__) || defined(__APPLE__)
  const int descriptor = ::open(canonical.c_str(),
                                O_RDONLY | O_DIRECTORY | O_NOFOLLOW |
                                    O_CLOEXEC);
  struct stat attributes {};
  struct stat named_attributes {};
  if (descriptor < 0 || ::fstat(descriptor, &attributes) != 0 ||
      ::lstat(canonical.c_str(), &named_attributes) != 0 ||
      !S_ISDIR(attributes.st_mode) || !S_ISDIR(named_attributes.st_mode) ||
      attributes.st_dev != named_attributes.st_dev ||
      attributes.st_ino != named_attributes.st_ino ||
      ::faccessat(descriptor, ".", W_OK | X_OK, AT_EACCESS) != 0) {
    if (descriptor >= 0) {
      (void)::close(descriptor);
    }
    return Result<ValidatedExecutionRoot>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_execution_root",
        "the workspace execution root must be one stable writable and searchable directory"));
  }
  (void)::close(descriptor);
  return Result<ValidatedExecutionRoot>::success(
      ValidatedExecutionRoot{canonical,
                             static_cast<std::uintmax_t>(attributes.st_dev),
                             static_cast<std::uintmax_t>(attributes.st_ino)});
#else
  return Result<ValidatedExecutionRoot>::success(
      ValidatedExecutionRoot{canonical, 0U, 0U});
#endif
}

[[nodiscard]] Result<void> validate_executable_path(
    const std::filesystem::path& executable) {
  if (executable.empty() || !executable.is_absolute() ||
      path_contains_nul(executable)) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_executable_spec",
        "a registered executable path must be absolute and contain no NUL"));
  }
  const auto normalized = executable.lexically_normal();
  std::error_code canonical_error;
  const auto canonical = std::filesystem::canonical(normalized,
                                                     canonical_error);
  if (canonical_error || canonical != normalized) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_executable_spec",
        "a registered executable must exist at one canonical nonsymlink path"));
  }
  std::error_code status_error;
  const auto status = std::filesystem::symlink_status(canonical, status_error);
  if (status_error || status.type() != std::filesystem::file_type::regular) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_executable_spec",
        "a registered executable must be a regular file"));
  }
#if defined(__unix__) || defined(__APPLE__)
  struct stat attributes {};
  if (::lstat(canonical.c_str(), &attributes) != 0 ||
      !S_ISREG(attributes.st_mode) || (attributes.st_mode & 0111) == 0) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_executable_spec",
        "a registered executable must be a nonsymlink executable regular file"));
  }
#endif
  return Result<void>::success();
}

[[nodiscard]] std::size_t resolved_cap(
    const std::size_t core_cap, const std::size_t manifest_cap,
    const std::optional<std::size_t>& registration_cap) {
  return std::min(core_cap,
                  std::min(manifest_cap,
                           registration_cap.value_or(core_cap)));
}

[[nodiscard]] std::string escaped_stderr(
    const std::span<const std::byte> bytes) {
  constexpr char kHex[] = "0123456789abcdef";
  std::string rendered;
  rendered.reserve(bytes.size());
  for (const std::byte raw : bytes) {
    const auto value = std::to_integer<unsigned int>(raw);
    if (value == static_cast<unsigned int>('\\')) {
      rendered += "\\\\";
    } else if (value == static_cast<unsigned int>('\n')) {
      rendered += "\\n";
    } else if (value == static_cast<unsigned int>('\r')) {
      rendered += "\\r";
    } else if (value == static_cast<unsigned int>('\t')) {
      rendered += "\\t";
    } else if (value >= 0x20U && value <= 0x7eU) {
      rendered.push_back(static_cast<char>(value));
    } else {
      rendered += "\\x";
      rendered.push_back(kHex[(value >> 4U) & 0x0fU]);
      rendered.push_back(kHex[value & 0x0fU]);
    }
  }
  return rendered;
}

struct StderrCapture final {
  std::size_t bytes{0U};
  bool limit_exceeded{false};
  std::vector<std::byte> excerpt;
};

void attach_stderr(Diagnostic& diagnostic,
                   const StderrCapture& stderr_capture) {
  if (stderr_capture.bytes == 0U && stderr_capture.excerpt.empty()) {
    return;
  }
  diagnostic.notes.push_back("stderr_bytes=" +
                             std::to_string(stderr_capture.bytes));
  const auto digest = sha256(stderr_capture.excerpt);
  if (digest) {
    diagnostic.notes.push_back("stderr_excerpt_sha256=" +
                               digest.value().hex());
  }
  diagnostic.notes.push_back("stderr_excerpt=" +
                             escaped_stderr(stderr_capture.excerpt));
  if (stderr_capture.bytes > stderr_capture.excerpt.size()) {
    diagnostic.notes.push_back("stderr_excerpt_truncated=true");
  }
}

[[nodiscard]] ProviderExecutionOutcome failed_with_stderr(
    Diagnostic diagnostic, const StderrCapture& stderr_capture) {
  attach_stderr(diagnostic, stderr_capture);
  return failed(std::move(diagnostic));
}

#if defined(__unix__) || defined(__APPLE__)

class ScopedFd final {
 public:
  ScopedFd() = default;
  explicit ScopedFd(const int fd) noexcept : fd_(fd) {}
  ScopedFd(const ScopedFd&) = delete;
  ScopedFd& operator=(const ScopedFd&) = delete;
  ScopedFd(ScopedFd&& other) noexcept : fd_(std::exchange(other.fd_, -1)) {}
  ScopedFd& operator=(ScopedFd&& other) noexcept {
    if (this != &other) {
      reset();
      fd_ = std::exchange(other.fd_, -1);
    }
    return *this;
  }
  ~ScopedFd() { reset(); }

  [[nodiscard]] int get() const noexcept { return fd_; }
  [[nodiscard]] int release() noexcept { return std::exchange(fd_, -1); }
  void reset(const int replacement = -1) noexcept {
    if (fd_ >= 0) {
      (void)::close(fd_);
    }
    fd_ = replacement;
  }

 private:
  int fd_{-1};
};

[[nodiscard]] bool same_change_time(const struct stat& left,
                                    const struct stat& right) noexcept {
#if defined(__APPLE__)
  return left.st_ctimespec.tv_sec == right.st_ctimespec.tv_sec &&
         left.st_ctimespec.tv_nsec == right.st_ctimespec.tv_nsec;
#else
  return left.st_ctim.tv_sec == right.st_ctim.tv_sec &&
         left.st_ctim.tv_nsec == right.st_ctim.tv_nsec;
#endif
}

[[nodiscard]] bool same_modification_time(const struct stat& left,
                                          const struct stat& right) noexcept {
#if defined(__APPLE__)
  return left.st_mtimespec.tv_sec == right.st_mtimespec.tv_sec &&
         left.st_mtimespec.tv_nsec == right.st_mtimespec.tv_nsec;
#else
  return left.st_mtim.tv_sec == right.st_mtim.tv_sec &&
         left.st_mtim.tv_nsec == right.st_mtim.tv_nsec;
#endif
}

struct OpenedExecutable final {
  ScopedFd descriptor;
  ScopedFd inspection_descriptor;
  std::uintmax_t device;
  std::uintmax_t inode;
  struct stat identity {};
};

[[nodiscard]] Result<OpenedExecutable> open_registered_executable(
    const std::filesystem::path& path) {
  struct stat named_attributes {};
  if (::lstat(path.c_str(), &named_attributes) != 0 ||
      !S_ISREG(named_attributes.st_mode) ||
      (named_attributes.st_mode & 0111) == 0) {
    return Result<OpenedExecutable>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.invalid_executable_spec",
        "the registered executable path no longer names an executable regular file"));
  }
#if defined(__linux__)
  ScopedFd descriptor(::open(path.c_str(), O_PATH | O_NOFOLLOW | O_CLOEXEC));
  ScopedFd inspection_descriptor(::open(
      path.c_str(), O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC));
#else
  ScopedFd descriptor(::open(
      path.c_str(), O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC));
  ScopedFd inspection_descriptor(::dup(descriptor.get()));
#endif
  struct stat opened_attributes {};
  struct stat inspected_attributes {};
  if (descriptor.get() < 0 || inspection_descriptor.get() < 0 ||
      ::fstat(descriptor.get(), &opened_attributes) != 0 ||
      ::fstat(inspection_descriptor.get(), &inspected_attributes) != 0 ||
      !S_ISREG(opened_attributes.st_mode) ||
      !S_ISREG(inspected_attributes.st_mode) ||
      (opened_attributes.st_mode & 0111) == 0 ||
      opened_attributes.st_dev != named_attributes.st_dev ||
      opened_attributes.st_ino != named_attributes.st_ino ||
      opened_attributes.st_size != named_attributes.st_size ||
      !same_change_time(opened_attributes, named_attributes) ||
      inspected_attributes.st_dev != opened_attributes.st_dev ||
      inspected_attributes.st_ino != opened_attributes.st_ino ||
      inspected_attributes.st_size != opened_attributes.st_size ||
      !same_change_time(inspected_attributes, opened_attributes)) {
    return Result<OpenedExecutable>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.executable_identity_changed",
        "the registered executable changed while its launch identity was bound"));
  }
  return Result<OpenedExecutable>::success(OpenedExecutable{
      std::move(descriptor), std::move(inspection_descriptor),
      static_cast<std::uintmax_t>(opened_attributes.st_dev),
      static_cast<std::uintmax_t>(opened_attributes.st_ino),
      opened_attributes});
}

[[nodiscard]] bool opened_executable_is_stable(
    const OpenedExecutable& executable,
    const std::filesystem::path& registered_path) noexcept {
  struct stat path_attributes {};
  struct stat execution_attributes {};
  struct stat inspection_attributes {};
  if (::lstat(registered_path.c_str(), &path_attributes) != 0 ||
      ::fstat(executable.descriptor.get(), &execution_attributes) != 0 ||
      ::fstat(executable.inspection_descriptor.get(),
              &inspection_attributes) != 0) {
    return false;
  }
  const auto stable_against_identity = [&](const struct stat& attributes) {
    return S_ISREG(attributes.st_mode) &&
           (attributes.st_mode & 0111) != 0 &&
           attributes.st_dev == executable.identity.st_dev &&
           attributes.st_ino == executable.identity.st_ino &&
           attributes.st_size == executable.identity.st_size &&
           same_change_time(attributes, executable.identity) &&
           same_modification_time(attributes, executable.identity);
  };
  return stable_against_identity(path_attributes) &&
         stable_against_identity(execution_attributes) &&
         stable_against_identity(inspection_attributes);
}

[[nodiscard]] bool clear_directory_contents(const int directory_fd,
                                            const std::size_t depth = 0U) {
  constexpr std::size_t kMaximumCleanupDepth = 64U;
  if (directory_fd < 0 || depth > kMaximumCleanupDepth) {
    return false;
  }
  const int scan_fd = ::openat(directory_fd, ".",
                               O_RDONLY | O_DIRECTORY | O_NOFOLLOW |
                                   O_CLOEXEC);
  if (scan_fd < 0) {
    return false;
  }
  DIR* stream = ::fdopendir(scan_fd);
  if (stream == nullptr) {
    (void)::close(scan_fd);
    return false;
  }
  bool clean = true;
  errno = 0;
  while (struct dirent* entry = ::readdir(stream)) {
    const std::string_view name(entry->d_name);
    if (name == "." || name == "..") {
      errno = 0;
      continue;
    }
    struct stat attributes {};
    if (::fstatat(directory_fd, entry->d_name, &attributes,
                  AT_SYMLINK_NOFOLLOW) != 0) {
      clean = false;
      break;
    }
    if (S_ISDIR(attributes.st_mode)) {
      ScopedFd child(::openat(directory_fd, entry->d_name,
                              O_RDONLY | O_DIRECTORY | O_NOFOLLOW |
                                  O_CLOEXEC));
      if (child.get() < 0 ||
          !clear_directory_contents(child.get(), depth + 1U) ||
          ::unlinkat(directory_fd, entry->d_name, AT_REMOVEDIR) != 0) {
        clean = false;
        break;
      }
    } else if (::unlinkat(directory_fd, entry->d_name, 0) != 0) {
      clean = false;
      break;
    }
    errno = 0;
  }
  if (errno != 0) {
    clean = false;
  }
  if (::closedir(stream) != 0) {
    clean = false;
  }
  return clean;
}

class ScopedRunDirectory final {
 public:
  ScopedRunDirectory(std::filesystem::path path, std::string entry_name,
                     ScopedFd root_fd, ScopedFd directory_fd,
                     const std::uintmax_t device,
                     const std::uintmax_t inode)
      : path_(std::move(path)),
        entry_name_(std::move(entry_name)),
        root_fd_(std::move(root_fd)),
        directory_fd_(std::move(directory_fd)),
        device_(device),
        inode_(inode) {}
  ScopedRunDirectory(const ScopedRunDirectory&) = delete;
  ScopedRunDirectory& operator=(const ScopedRunDirectory&) = delete;
  ScopedRunDirectory(ScopedRunDirectory&& other) noexcept
      : path_(std::move(other.path_)),
        entry_name_(std::move(other.entry_name_)),
        root_fd_(std::move(other.root_fd_)),
        directory_fd_(std::move(other.directory_fd_)),
        device_(other.device_),
        inode_(other.inode_),
        active_(std::exchange(other.active_, false)) {}
  ScopedRunDirectory& operator=(ScopedRunDirectory&&) = delete;
  ~ScopedRunDirectory() { (void)clean(); }

  [[nodiscard]] const std::filesystem::path& path() const noexcept {
    return path_;
  }
  [[nodiscard]] int descriptor() const noexcept { return directory_fd_.get(); }
  [[nodiscard]] bool named_entry_is_stable() const noexcept {
    struct stat attributes {};
    return active_ && root_fd_.get() >= 0 &&
           ::fstatat(root_fd_.get(), entry_name_.c_str(), &attributes,
                     AT_SYMLINK_NOFOLLOW) == 0 &&
           S_ISDIR(attributes.st_mode) &&
           static_cast<std::uintmax_t>(attributes.st_dev) == device_ &&
           static_cast<std::uintmax_t>(attributes.st_ino) == inode_;
  }
  [[nodiscard]] bool clean() noexcept {
    if (!active_) {
      return true;
    }
    if (!clear_directory_contents(directory_fd_.get()) ||
        !named_entry_is_stable() ||
        ::unlinkat(root_fd_.get(), entry_name_.c_str(), AT_REMOVEDIR) != 0) {
      return false;
    }
    active_ = false;
    directory_fd_.reset();
    root_fd_.reset();
    return true;
  }

 private:
  std::filesystem::path path_;
  std::string entry_name_;
  ScopedFd root_fd_;
  ScopedFd directory_fd_;
  std::uintmax_t device_;
  std::uintmax_t inode_;
  bool active_{true};
};

[[nodiscard]] ProviderExecutionOutcome fail_after_cleanup(
    ScopedRunDirectory& run_directory, Diagnostic diagnostic,
    const StderrCapture& stderr_capture = {}) {
  attach_stderr(diagnostic, stderr_capture);
  if (run_directory.clean()) {
    return failed(std::move(diagnostic));
  }
  Diagnostic cleanup = error(
      DiagnosticCategory::internal, "c16.local_builder_cleanup_failed",
      "the identity-bound private execution directory could not be removed deterministically");
  cleanup.notes.push_back("prior_failure=" + diagnostic.code);
  for (auto& note : diagnostic.notes) {
    cleanup.notes.push_back(std::move(note));
  }
  return failed(std::move(cleanup));
}

struct Pipe final {
  ScopedFd read_end;
  ScopedFd write_end;
};

[[nodiscard]] bool set_descriptor_flag(const int descriptor,
                                       const int command,
                                       const int flag) {
  const int old_flags = ::fcntl(descriptor, command);
  return old_flags >= 0 &&
         ::fcntl(descriptor, command == F_GETFD ? F_SETFD : F_SETFL,
                 old_flags | flag) == 0;
}

[[nodiscard]] Result<Pipe> make_pipe(const bool nonblocking_read) {
  int descriptors[2]{-1, -1};
  if (::pipe(descriptors) != 0) {
    return Result<Pipe>::failure(error(
        DiagnosticCategory::internal, "c16.local_builder_pipe_failed",
        "the framework could not create a bounded process pipe"));
  }
  Pipe result{ScopedFd(descriptors[0]), ScopedFd(descriptors[1])};
  if (!set_descriptor_flag(result.read_end.get(), F_GETFD, FD_CLOEXEC) ||
      !set_descriptor_flag(result.write_end.get(), F_GETFD, FD_CLOEXEC) ||
      (nonblocking_read &&
       !set_descriptor_flag(result.read_end.get(), F_GETFL, O_NONBLOCK))) {
    return Result<Pipe>::failure(error(
        DiagnosticCategory::internal, "c16.local_builder_pipe_failed",
        "the framework could not secure a process pipe"));
  }
  return Result<Pipe>::success(std::move(result));
}

[[nodiscard]] Result<ScopedRunDirectory> make_run_directory(
    const ValidatedExecutionRoot& root) {
  ScopedFd root_fd(::open(root.path.c_str(),
                          O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC));
  struct stat root_attributes {};
  if (root_fd.get() < 0 || ::fstat(root_fd.get(), &root_attributes) != 0 ||
      !S_ISDIR(root_attributes.st_mode) ||
      static_cast<std::uintmax_t>(root_attributes.st_dev) != root.device ||
      static_cast<std::uintmax_t>(root_attributes.st_ino) != root.inode) {
    return Result<ScopedRunDirectory>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_execution_root",
        "the identity-bound workspace execution root changed before launch"));
  }
  static std::atomic<std::uint64_t> sequence{0U};
  constexpr std::size_t kMaximumAttempts = 1024U;
  for (std::size_t attempt = 0U; attempt < kMaximumAttempts; ++attempt) {
    const std::uint64_t serial = sequence.fetch_add(1U,
                                                    std::memory_order_relaxed);
    const auto name = ".mwperf-surrogate-build-v1-" +
                      std::to_string(static_cast<unsigned long long>(
                          ::getpid())) +
                      "-" + std::to_string(serial);
    const auto candidate = root.path / name;
    if (::mkdirat(root_fd.get(), name.c_str(), S_IRWXU) == 0) {
      ScopedFd directory_fd(::openat(
          root_fd.get(), name.c_str(),
          O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC));
      struct stat attributes {};
      if (directory_fd.get() < 0 ||
          ::fchmod(directory_fd.get(), S_IRWXU) != 0 ||
          ::fstat(directory_fd.get(), &attributes) != 0 ||
          !S_ISDIR(attributes.st_mode) ||
          (attributes.st_mode & 0777) != S_IRWXU) {
        (void)::unlinkat(root_fd.get(), name.c_str(), AT_REMOVEDIR);
        return Result<ScopedRunDirectory>::failure(error(
            DiagnosticCategory::internal,
            "c16.local_builder_workspace_failed",
            "the framework could not bind one exact private execution directory"));
      }
      return Result<ScopedRunDirectory>::success(ScopedRunDirectory(
          candidate, name, std::move(root_fd), std::move(directory_fd),
          static_cast<std::uintmax_t>(attributes.st_dev),
          static_cast<std::uintmax_t>(attributes.st_ino)));
    }
    if (errno != EEXIST) {
      return Result<ScopedRunDirectory>::failure(error(
          DiagnosticCategory::internal,
          "c16.local_builder_workspace_failed",
          "the framework could not create a unique execution directory"));
    }
  }
  return Result<ScopedRunDirectory>::failure(error(
      DiagnosticCategory::resource_limit,
      "c16.local_builder_workspace_exhausted",
      "the framework could not allocate a unique execution directory"));
}

[[nodiscard]] bool write_all(const int descriptor,
                             const std::span<const std::byte> bytes) {
  std::size_t offset = 0U;
  while (offset < bytes.size()) {
    const auto* first = reinterpret_cast<const char*>(bytes.data() + offset);
    const std::size_t remaining = bytes.size() - offset;
    const ssize_t written = ::write(descriptor, first, remaining);
    if (written < 0 && errno == EINTR) {
      continue;
    }
    if (written <= 0) {
      return false;
    }
    offset += static_cast<std::size_t>(written);
  }
  return true;
}

struct FileIdentity final {
  dev_t device;
  ino_t inode;
  off_t size;
};

[[nodiscard]] Result<FileIdentity> write_request_file(
    const int directory_fd, const std::string_view name,
    const std::span<const std::byte> bytes) {
  ScopedFd descriptor(
      ::openat(directory_fd, std::string(name).c_str(),
               O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC,
               S_IRUSR | S_IWUSR));
  if (descriptor.get() < 0 || ::fchmod(descriptor.get(), S_IRUSR) != 0 ||
      !write_all(descriptor.get(), bytes) ||
      ::fsync(descriptor.get()) != 0) {
    return Result<FileIdentity>::failure(error(
        DiagnosticCategory::internal, "c16.local_builder_request_write_failed",
        "the canonical request could not be published in the private execution directory"));
  }
  struct stat attributes {};
  if (::fstat(descriptor.get(), &attributes) != 0 ||
      !S_ISREG(attributes.st_mode) || attributes.st_nlink != 1 ||
      attributes.st_size < 0 ||
      static_cast<std::uintmax_t>(attributes.st_size) != bytes.size()) {
    return Result<FileIdentity>::failure(error(
        DiagnosticCategory::internal,
        "c16.local_builder_request_write_failed",
        "the canonical request file failed its publication integrity check"));
  }
  return Result<FileIdentity>::success(
      FileIdentity{attributes.st_dev, attributes.st_ino, attributes.st_size});
}

[[nodiscard]] Result<void> verify_request_file(
    const int directory_fd, const std::string_view name,
    const FileIdentity& identity,
    const std::span<const std::byte> expected) {
  const std::string stable_name(name);
  struct stat path_attributes {};
  if (::fstatat(directory_fd, stable_name.c_str(), &path_attributes,
                AT_SYMLINK_NOFOLLOW) != 0 ||
      !S_ISREG(path_attributes.st_mode) ||
      path_attributes.st_dev != identity.device ||
      path_attributes.st_ino != identity.inode ||
      path_attributes.st_size != identity.size ||
      path_attributes.st_nlink != 1) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_request_mutated",
        "the local builder replaced or mutated its immutable request file"));
  }
  ScopedFd descriptor(::openat(directory_fd, stable_name.c_str(),
                               O_RDONLY | O_NOFOLLOW | O_NONBLOCK |
                                   O_CLOEXEC));
  if (descriptor.get() < 0) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_request_mutated",
        "the immutable request file is no longer readable"));
  }
  struct stat opened_attributes {};
  if (::fstat(descriptor.get(), &opened_attributes) != 0 ||
      !S_ISREG(opened_attributes.st_mode) ||
      opened_attributes.st_dev != identity.device ||
      opened_attributes.st_ino != identity.inode ||
      opened_attributes.st_size != identity.size ||
      opened_attributes.st_nlink != 1) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_request_mutated",
        "the immutable request changed while it was opened"));
  }
  std::array<std::byte, 8192U> buffer{};
  std::size_t offset = 0U;
  for (;;) {
    const ssize_t count = ::read(descriptor.get(), buffer.data(),
                                 buffer.size());
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count < 0) {
      return Result<void>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.local_builder_request_mutated",
          "the immutable request file could not be revalidated"));
    }
    if (count == 0) {
      break;
    }
    const auto amount = static_cast<std::size_t>(count);
    if (offset > expected.size() || amount > expected.size() - offset ||
        !std::equal(buffer.begin(), buffer.begin() + count,
                    expected.begin() + static_cast<std::ptrdiff_t>(offset))) {
      return Result<void>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.local_builder_request_mutated",
          "the local builder changed canonical request bytes"));
    }
    offset += amount;
  }
  if (offset != expected.size()) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_request_mutated",
        "the local builder changed canonical request length"));
  }
  struct stat final_attributes {};
  if (::fstat(descriptor.get(), &final_attributes) != 0 ||
      final_attributes.st_dev != opened_attributes.st_dev ||
      final_attributes.st_ino != opened_attributes.st_ino ||
      final_attributes.st_size != opened_attributes.st_size ||
      final_attributes.st_nlink != 1) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_request_mutated",
        "the immutable request was not stable while being revalidated"));
  }
  return Result<void>::success();
}

enum class ChildFailureStage : int {
  setup = 1,
  sandbox = 2,
  execute = 3,
};

struct ChildFailure final {
  ChildFailureStage stage{ChildFailureStage::setup};
  int error_number{0};
};

enum class StaticBrokerViolation : std::uint8_t {
  none,
  forbidden_path_access,
  request_mutation,
  duplicate_result_open,
  repeated_execution,
};

enum class StaticPathAttestation : std::uint8_t {
  undecided,
  exact,
  capability_only,
};

struct StaticPathBroker;

void child_report_error_and_exit(const int descriptor,
                                 const ChildFailureStage stage,
                                 const int error_number) noexcept {
  const ChildFailure failure{stage, error_number};
  const auto* bytes = reinterpret_cast<const char*>(&failure);
  std::size_t written = 0U;
  while (written < sizeof(failure)) {
    const ssize_t count =
        ::write(descriptor, bytes + written, sizeof(failure) - written);
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count <= 0) {
      break;
    }
    written += static_cast<std::size_t>(count);
  }
  ::_exit(127);
}

#if defined(__linux__)

enum class LinuxSandboxBackend : std::uint8_t {
  landlock,
  static_seccomp_broker,
};

[[nodiscard]] bool pread_exact(const int descriptor, void* const output,
                               const std::size_t size,
                               const off_t offset) noexcept {
  auto* bytes = static_cast<std::byte*>(output);
  std::size_t received = 0U;
  while (received < size) {
    const ssize_t count = ::pread(
        descriptor, bytes + received, size - received,
        offset + static_cast<off_t>(received));
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count <= 0) {
      return false;
    }
    received += static_cast<std::size_t>(count);
  }
  return true;
}

template <typename ElfHeader, typename ProgramHeader>
[[nodiscard]] bool native_elf_has_no_interpreter(
    const int descriptor, const unsigned char expected_class,
    const std::uint16_t expected_machine) noexcept {
  ElfHeader header{};
  if (!pread_exact(descriptor, &header, sizeof(header), 0) ||
      std::memcmp(header.e_ident, ELFMAG, SELFMAG) != 0 ||
      header.e_ident[EI_CLASS] != expected_class ||
      header.e_ident[EI_DATA] != ELFDATA2LSB ||
      header.e_ident[EI_VERSION] != EV_CURRENT ||
      header.e_version != EV_CURRENT ||
      header.e_machine != expected_machine ||
      (header.e_type != ET_EXEC && header.e_type != ET_DYN) ||
      header.e_phentsize != sizeof(ProgramHeader) || header.e_phnum == 0U ||
      header.e_phnum == PN_XNUM || header.e_phnum > 1024U) {
    return false;
  }
  const auto table_offset = static_cast<std::uintmax_t>(header.e_phoff);
  const auto entry_size = static_cast<std::uintmax_t>(sizeof(ProgramHeader));
  const auto count = static_cast<std::uintmax_t>(header.e_phnum);
  if (table_offset > static_cast<std::uintmax_t>(
                         std::numeric_limits<off_t>::max()) ||
      count > (std::numeric_limits<std::uintmax_t>::max() - table_offset) /
                  entry_size ||
      table_offset + count * entry_size >
          static_cast<std::uintmax_t>(std::numeric_limits<off_t>::max())) {
    return false;
  }
  for (std::uintmax_t index = 0U; index < count; ++index) {
    ProgramHeader program{};
    const auto raw_offset = table_offset + index * entry_size;
    if (!pread_exact(descriptor, &program, sizeof(program),
                     static_cast<off_t>(raw_offset)) ||
        program.p_type == PT_INTERP) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool is_native_static_elf(const int descriptor) noexcept {
#if defined(__x86_64__) || defined(__aarch64__)
#if defined(__x86_64__)
  constexpr std::uint16_t kExpectedMachine = EM_X86_64;
#else
  constexpr std::uint16_t kExpectedMachine = EM_AARCH64;
#endif
  return native_elf_has_no_interpreter<Elf64_Ehdr, Elf64_Phdr>(
      descriptor, ELFCLASS64, kExpectedMachine);
#elif defined(__i386__)
  return native_elf_has_no_interpreter<Elf32_Ehdr, Elf32_Phdr>(
      descriptor, ELFCLASS32, EM_386);
#else
  (void)descriptor;
  return false;
#endif
}

[[nodiscard]] std::optional<LinuxSandboxBackend> select_linux_backend(
    const int executable_descriptor) noexcept {
  if (!is_native_static_elf(executable_descriptor)) {
    return std::nullopt;
  }
  errno = 0;
  const int abi = static_cast<int>(::syscall(
      SYS_landlock_create_ruleset, nullptr, 0,
      LANDLOCK_CREATE_RULESET_VERSION));
  if (abi >= 3) {
    return LinuxSandboxBackend::landlock;
  }
  return LinuxSandboxBackend::static_seccomp_broker;
}

[[nodiscard]] int add_landlock_path_rule(
    const int ruleset_descriptor, const int path_descriptor,
    const std::uint64_t allowed_access) noexcept {
  const struct landlock_path_beneath_attr attributes {
    allowed_access, path_descriptor
  };
  if (::syscall(SYS_landlock_add_rule, ruleset_descriptor,
                LANDLOCK_RULE_PATH_BENEATH, &attributes, 0) != 0) {
    return errno;
  }
  return 0;
}

[[nodiscard]] int apply_landlock_filesystem_policy(
    const int run_directory_fd, const int executable_fd) noexcept {
  const int abi = static_cast<int>(::syscall(
      SYS_landlock_create_ruleset, nullptr, 0,
      LANDLOCK_CREATE_RULESET_VERSION));
  if (abi < 0) {
    return errno;
  }
  if (abi < 3) {
    return EOPNOTSUPP;
  }

  constexpr std::uint64_t handled_fs =
      LANDLOCK_ACCESS_FS_EXECUTE | LANDLOCK_ACCESS_FS_WRITE_FILE |
      LANDLOCK_ACCESS_FS_READ_FILE | LANDLOCK_ACCESS_FS_READ_DIR |
      LANDLOCK_ACCESS_FS_REMOVE_DIR | LANDLOCK_ACCESS_FS_REMOVE_FILE |
      LANDLOCK_ACCESS_FS_MAKE_CHAR | LANDLOCK_ACCESS_FS_MAKE_DIR |
      LANDLOCK_ACCESS_FS_MAKE_REG | LANDLOCK_ACCESS_FS_MAKE_SOCK |
      LANDLOCK_ACCESS_FS_MAKE_FIFO | LANDLOCK_ACCESS_FS_MAKE_BLOCK |
      LANDLOCK_ACCESS_FS_MAKE_SYM | LANDLOCK_ACCESS_FS_REFER |
      LANDLOCK_ACCESS_FS_TRUNCATE;
  struct landlock_ruleset_attr ruleset_attributes {};
  ruleset_attributes.handled_access_fs = handled_fs;
  ScopedFd ruleset(static_cast<int>(::syscall(
      SYS_landlock_create_ruleset, &ruleset_attributes,
      sizeof(ruleset_attributes), 0)));
  if (ruleset.get() < 0) {
    return errno;
  }

  constexpr std::uint64_t kExecutableAccess =
      LANDLOCK_ACCESS_FS_EXECUTE | LANDLOCK_ACCESS_FS_READ_FILE;
  int rule_error = add_landlock_path_rule(
      ruleset.get(), executable_fd, kExecutableAccess);
  if (rule_error != 0) {
    return rule_error;
  }

  constexpr std::uint64_t kRunDirectoryAccess =
      LANDLOCK_ACCESS_FS_WRITE_FILE | LANDLOCK_ACCESS_FS_READ_FILE |
      LANDLOCK_ACCESS_FS_READ_DIR | LANDLOCK_ACCESS_FS_REMOVE_FILE |
      LANDLOCK_ACCESS_FS_MAKE_REG | LANDLOCK_ACCESS_FS_REFER |
      LANDLOCK_ACCESS_FS_TRUNCATE;
  rule_error = add_landlock_path_rule(
      ruleset.get(), run_directory_fd, kRunDirectoryAccess);
  if (rule_error != 0) {
    return rule_error;
  }
  if (::syscall(SYS_landlock_restrict_self, ruleset.get(), 0) != 0) {
    return errno;
  }
  return 0;
}

#define MWPERF_C16_DENY_SYSCALL(number)                                  \
  BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, number, 0, 1),                    \
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO |                     \
                                    (EPERM & SECCOMP_RET_DATA))

#define MWPERF_C16_NOTIFY_SYSCALL(number)                                \
  BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, number, 0, 1),                    \
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_USER_NOTIF)

#define MWPERF_C16_ALLOW_SYSCALL(number)                                 \
  BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, number, 0, 1),                    \
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW)

[[nodiscard]] int create_static_path_broker_listener() noexcept {
#if defined(__x86_64__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_X86_64;
#elif defined(__aarch64__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_AARCH64;
#elif defined(__i386__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_I386;
#else
  return -EOPNOTSUPP;
#endif
  const struct sock_filter filter[] = {
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   arch))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, kAuditArchitecture, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#ifdef SYS_execve
      MWPERF_C16_DENY_SYSCALL(SYS_execve),
#endif
#ifdef SYS_execveat
      MWPERF_C16_NOTIFY_SYSCALL(SYS_execveat),
#endif
#ifdef SYS_open
      MWPERF_C16_NOTIFY_SYSCALL(SYS_open),
#endif
#ifdef SYS_openat
      MWPERF_C16_NOTIFY_SYSCALL(SYS_openat),
#endif
#ifdef SYS_creat
      MWPERF_C16_NOTIFY_SYSCALL(SYS_creat),
#endif
#ifdef SYS_openat2
      MWPERF_C16_DENY_SYSCALL(SYS_openat2),
#endif
#ifdef SYS_access
      MWPERF_C16_DENY_SYSCALL(SYS_access),
#endif
#ifdef SYS_faccessat
      MWPERF_C16_DENY_SYSCALL(SYS_faccessat),
#endif
#ifdef SYS_faccessat2
      MWPERF_C16_DENY_SYSCALL(SYS_faccessat2),
#endif
#ifdef SYS_stat
      MWPERF_C16_DENY_SYSCALL(SYS_stat),
#endif
#ifdef SYS_lstat
      MWPERF_C16_DENY_SYSCALL(SYS_lstat),
#endif
#ifdef SYS_newfstatat
      MWPERF_C16_DENY_SYSCALL(SYS_newfstatat),
#endif
#ifdef SYS_statx
      MWPERF_C16_DENY_SYSCALL(SYS_statx),
#endif
#ifdef SYS_statfs
      MWPERF_C16_DENY_SYSCALL(SYS_statfs),
#endif
#ifdef SYS_readlink
      MWPERF_C16_DENY_SYSCALL(SYS_readlink),
#endif
#ifdef SYS_readlinkat
      MWPERF_C16_DENY_SYSCALL(SYS_readlinkat),
#endif
#ifdef SYS_getdents
      MWPERF_C16_DENY_SYSCALL(SYS_getdents),
#endif
#ifdef SYS_getdents64
      MWPERF_C16_DENY_SYSCALL(SYS_getdents64),
#endif
#ifdef SYS_chdir
      MWPERF_C16_DENY_SYSCALL(SYS_chdir),
#endif
#ifdef SYS_fchdir
      MWPERF_C16_DENY_SYSCALL(SYS_fchdir),
#endif
#ifdef SYS_mkdir
      MWPERF_C16_DENY_SYSCALL(SYS_mkdir),
#endif
#ifdef SYS_mkdirat
      MWPERF_C16_DENY_SYSCALL(SYS_mkdirat),
#endif
#ifdef SYS_rmdir
      MWPERF_C16_DENY_SYSCALL(SYS_rmdir),
#endif
#ifdef SYS_unlink
      MWPERF_C16_DENY_SYSCALL(SYS_unlink),
#endif
#ifdef SYS_unlinkat
      MWPERF_C16_DENY_SYSCALL(SYS_unlinkat),
#endif
#ifdef SYS_rename
      MWPERF_C16_DENY_SYSCALL(SYS_rename),
#endif
#ifdef SYS_renameat
      MWPERF_C16_DENY_SYSCALL(SYS_renameat),
#endif
#ifdef SYS_renameat2
      MWPERF_C16_DENY_SYSCALL(SYS_renameat2),
#endif
#ifdef SYS_link
      MWPERF_C16_DENY_SYSCALL(SYS_link),
#endif
#ifdef SYS_linkat
      MWPERF_C16_DENY_SYSCALL(SYS_linkat),
#endif
#ifdef SYS_symlink
      MWPERF_C16_DENY_SYSCALL(SYS_symlink),
#endif
#ifdef SYS_symlinkat
      MWPERF_C16_DENY_SYSCALL(SYS_symlinkat),
#endif
#ifdef SYS_mknod
      MWPERF_C16_DENY_SYSCALL(SYS_mknod),
#endif
#ifdef SYS_mknodat
      MWPERF_C16_DENY_SYSCALL(SYS_mknodat),
#endif
#ifdef SYS_truncate
      MWPERF_C16_DENY_SYSCALL(SYS_truncate),
#endif
#ifdef SYS_getxattr
      MWPERF_C16_DENY_SYSCALL(SYS_getxattr),
#endif
#ifdef SYS_lgetxattr
      MWPERF_C16_DENY_SYSCALL(SYS_lgetxattr),
#endif
#ifdef SYS_listxattr
      MWPERF_C16_DENY_SYSCALL(SYS_listxattr),
#endif
#ifdef SYS_llistxattr
      MWPERF_C16_DENY_SYSCALL(SYS_llistxattr),
#endif
#ifdef SYS_removexattr
      MWPERF_C16_DENY_SYSCALL(SYS_removexattr),
#endif
#ifdef SYS_lremovexattr
      MWPERF_C16_DENY_SYSCALL(SYS_lremovexattr),
#endif
#ifdef SYS_name_to_handle_at
      MWPERF_C16_DENY_SYSCALL(SYS_name_to_handle_at),
#endif
#ifdef SYS_inotify_init
      MWPERF_C16_DENY_SYSCALL(SYS_inotify_init),
#endif
#ifdef SYS_inotify_init1
      MWPERF_C16_DENY_SYSCALL(SYS_inotify_init1),
#endif
#ifdef SYS_inotify_add_watch
      MWPERF_C16_DENY_SYSCALL(SYS_inotify_add_watch),
#endif
#ifdef SYS_fanotify_init
      MWPERF_C16_DENY_SYSCALL(SYS_fanotify_init),
#endif
#ifdef SYS_fanotify_mark
      MWPERF_C16_DENY_SYSCALL(SYS_fanotify_mark),
#endif
#ifdef SYS_open_tree
      MWPERF_C16_DENY_SYSCALL(SYS_open_tree),
#endif
#ifdef SYS_move_mount
      MWPERF_C16_DENY_SYSCALL(SYS_move_mount),
#endif
#ifdef SYS_fsopen
      MWPERF_C16_DENY_SYSCALL(SYS_fsopen),
#endif
#ifdef SYS_fspick
      MWPERF_C16_DENY_SYSCALL(SYS_fspick),
#endif
#ifdef SYS_fsmount
      MWPERF_C16_DENY_SYSCALL(SYS_fsmount),
#endif
#ifdef SYS_mount_setattr
      MWPERF_C16_DENY_SYSCALL(SYS_mount_setattr),
#endif
#ifdef SYS_quotactl
      MWPERF_C16_DENY_SYSCALL(SYS_quotactl),
#endif
#ifdef SYS_acct
      MWPERF_C16_DENY_SYSCALL(SYS_acct),
#endif
#ifdef SYS_swapon
      MWPERF_C16_DENY_SYSCALL(SYS_swapon),
#endif
#ifdef SYS_swapoff
      MWPERF_C16_DENY_SYSCALL(SYS_swapoff),
#endif
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
  };
  const struct sock_fprog program {
    static_cast<unsigned short>(std::size(filter)),
        const_cast<struct sock_filter*>(filter)
  };
  const int listener = static_cast<int>(::syscall(
      SYS_seccomp, SECCOMP_SET_MODE_FILTER,
      SECCOMP_FILTER_FLAG_NEW_LISTENER, &program));
  return listener >= 0 ? listener : -errno;
}

[[nodiscard]] int create_exec_broker_listener() noexcept {
#if defined(__x86_64__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_X86_64;
#elif defined(__aarch64__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_AARCH64;
#elif defined(__i386__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_I386;
#else
  return -EOPNOTSUPP;
#endif
  const struct sock_filter filter[] = {
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   arch))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, kAuditArchitecture, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#ifdef SYS_execve
      MWPERF_C16_DENY_SYSCALL(SYS_execve),
#endif
#ifdef SYS_execveat
      MWPERF_C16_NOTIFY_SYSCALL(SYS_execveat),
#endif
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
  };
  const struct sock_fprog program {
    static_cast<unsigned short>(std::size(filter)),
        const_cast<struct sock_filter*>(filter)
  };
  const int listener = static_cast<int>(::syscall(
      SYS_seccomp, SECCOMP_SET_MODE_FILTER,
      SECCOMP_FILTER_FLAG_NEW_LISTENER, &program));
  return listener >= 0 ? listener : -errno;
}

[[nodiscard]] int apply_seccomp_process_and_network_policy() noexcept {
#if defined(__x86_64__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_X86_64;
#elif defined(__aarch64__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_AARCH64;
#elif defined(__i386__)
  constexpr std::uint32_t kAuditArchitecture = AUDIT_ARCH_I386;
#else
  return EOPNOTSUPP;
#endif
  const auto self_process = static_cast<std::uint32_t>(::getpid());
  constexpr std::uint32_t kRequiredThreadCloneFlags =
      CLONE_VM | CLONE_SIGHAND | CLONE_THREAD;
  constexpr std::uint32_t kCloneNamespaceFlags =
#ifdef CLONE_NEWTIME
      CLONE_NEWTIME |
#endif
#ifdef CLONE_NEWNS
      CLONE_NEWNS |
#endif
#ifdef CLONE_NEWCGROUP
      CLONE_NEWCGROUP |
#endif
#ifdef CLONE_NEWUTS
      CLONE_NEWUTS |
#endif
#ifdef CLONE_NEWIPC
      CLONE_NEWIPC |
#endif
#ifdef CLONE_NEWUSER
      CLONE_NEWUSER |
#endif
#ifdef CLONE_NEWPID
      CLONE_NEWPID |
#endif
#ifdef CLONE_NEWNET
      CLONE_NEWNET |
#endif
      0U;
  const struct sock_filter filter[] = {
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   arch))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, kAuditArchitecture, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#ifdef SYS_clone
      // Permit only same-process pthread-style creation: all three kernel
      // sharing flags are required and namespace creation is forbidden.
      // Every process-creating or namespace-creating clone remains EPERM.
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_clone, 0, 9),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   args[0]))),
      BPF_STMT(BPF_ALU | BPF_AND | BPF_K, kRequiredThreadCloneFlags),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, kRequiredThreadCloneFlags, 1, 0),
      BPF_STMT(BPF_RET | BPF_K,
               SECCOMP_RET_ERRNO | (EPERM & SECCOMP_RET_DATA)),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   args[0]))),
      BPF_STMT(BPF_ALU | BPF_AND | BPF_K, kCloneNamespaceFlags),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, 0U, 1, 0),
      BPF_STMT(BPF_RET | BPF_K,
               SECCOMP_RET_ERRNO | (EPERM & SECCOMP_RET_DATA)),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#endif
#ifdef SYS_clone3
      // Classic seccomp cannot inspect clone3's pointed-to flag structure.
      // Report it unavailable so libc uses the auditable clone fallback.
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_clone3, 0, 1),
      BPF_STMT(BPF_RET | BPF_K,
               SECCOMP_RET_ERRNO | (ENOSYS & SECCOMP_RET_DATA)),
#endif
#ifdef SYS_fork
      MWPERF_C16_DENY_SYSCALL(SYS_fork),
#endif
#ifdef SYS_vfork
      MWPERF_C16_DENY_SYSCALL(SYS_vfork),
#endif
#ifdef SYS_setsid
      MWPERF_C16_DENY_SYSCALL(SYS_setsid),
#endif
#ifdef SYS_setpgid
      MWPERF_C16_DENY_SYSCALL(SYS_setpgid),
#endif
#ifdef SYS_unshare
      MWPERF_C16_DENY_SYSCALL(SYS_unshare),
#endif
#ifdef SYS_setns
      MWPERF_C16_DENY_SYSCALL(SYS_setns),
#endif
#ifdef SYS_socket
      MWPERF_C16_DENY_SYSCALL(SYS_socket),
#endif
#ifdef SYS_socketpair
      MWPERF_C16_DENY_SYSCALL(SYS_socketpair),
#endif
#ifdef SYS_socketcall
      MWPERF_C16_DENY_SYSCALL(SYS_socketcall),
#endif
#ifdef SYS_connect
      MWPERF_C16_DENY_SYSCALL(SYS_connect),
#endif
#ifdef SYS_bind
      MWPERF_C16_DENY_SYSCALL(SYS_bind),
#endif
#ifdef SYS_listen
      MWPERF_C16_DENY_SYSCALL(SYS_listen),
#endif
#ifdef SYS_accept
      MWPERF_C16_DENY_SYSCALL(SYS_accept),
#endif
#ifdef SYS_accept4
      MWPERF_C16_DENY_SYSCALL(SYS_accept4),
#endif
#ifdef SYS_sendto
      MWPERF_C16_DENY_SYSCALL(SYS_sendto),
#endif
#ifdef SYS_sendmsg
      MWPERF_C16_DENY_SYSCALL(SYS_sendmsg),
#endif
#ifdef SYS_sendmmsg
      MWPERF_C16_DENY_SYSCALL(SYS_sendmmsg),
#endif
#ifdef SYS_recvfrom
      MWPERF_C16_DENY_SYSCALL(SYS_recvfrom),
#endif
#ifdef SYS_recvmsg
      MWPERF_C16_DENY_SYSCALL(SYS_recvmsg),
#endif
#ifdef SYS_recvmmsg
      MWPERF_C16_DENY_SYSCALL(SYS_recvmmsg),
#endif
#ifdef SYS_shutdown
      MWPERF_C16_DENY_SYSCALL(SYS_shutdown),
#endif
#ifdef SYS_shmget
      MWPERF_C16_DENY_SYSCALL(SYS_shmget),
#endif
#ifdef SYS_shmat
      MWPERF_C16_DENY_SYSCALL(SYS_shmat),
#endif
#ifdef SYS_shmdt
      MWPERF_C16_DENY_SYSCALL(SYS_shmdt),
#endif
#ifdef SYS_shmctl
      MWPERF_C16_DENY_SYSCALL(SYS_shmctl),
#endif
#ifdef SYS_msgget
      MWPERF_C16_DENY_SYSCALL(SYS_msgget),
#endif
#ifdef SYS_msgsnd
      MWPERF_C16_DENY_SYSCALL(SYS_msgsnd),
#endif
#ifdef SYS_msgrcv
      MWPERF_C16_DENY_SYSCALL(SYS_msgrcv),
#endif
#ifdef SYS_msgctl
      MWPERF_C16_DENY_SYSCALL(SYS_msgctl),
#endif
#ifdef SYS_semget
      MWPERF_C16_DENY_SYSCALL(SYS_semget),
#endif
#ifdef SYS_semop
      MWPERF_C16_DENY_SYSCALL(SYS_semop),
#endif
#ifdef SYS_semtimedop
      MWPERF_C16_DENY_SYSCALL(SYS_semtimedop),
#endif
#ifdef SYS_semctl
      MWPERF_C16_DENY_SYSCALL(SYS_semctl),
#endif
#ifdef SYS_mq_open
      MWPERF_C16_DENY_SYSCALL(SYS_mq_open),
#endif
#ifdef SYS_mq_unlink
      MWPERF_C16_DENY_SYSCALL(SYS_mq_unlink),
#endif
#ifdef SYS_mq_timedsend
      MWPERF_C16_DENY_SYSCALL(SYS_mq_timedsend),
#endif
#ifdef SYS_mq_timedreceive
      MWPERF_C16_DENY_SYSCALL(SYS_mq_timedreceive),
#endif
#ifdef SYS_mq_notify
      MWPERF_C16_DENY_SYSCALL(SYS_mq_notify),
#endif
#ifdef SYS_mq_getsetattr
      MWPERF_C16_DENY_SYSCALL(SYS_mq_getsetattr),
#endif
#ifdef SYS_ipc
      MWPERF_C16_DENY_SYSCALL(SYS_ipc),
#endif
#ifdef SYS_getrandom
      MWPERF_C16_DENY_SYSCALL(SYS_getrandom),
#endif
#ifdef SYS_perf_event_open
      MWPERF_C16_DENY_SYSCALL(SYS_perf_event_open),
#endif
#ifdef SYS_ptrace
      MWPERF_C16_DENY_SYSCALL(SYS_ptrace),
#endif
#ifdef SYS_process_vm_readv
      MWPERF_C16_DENY_SYSCALL(SYS_process_vm_readv),
#endif
#ifdef SYS_process_vm_writev
      MWPERF_C16_DENY_SYSCALL(SYS_process_vm_writev),
#endif
#ifdef SYS_pidfd_open
      MWPERF_C16_DENY_SYSCALL(SYS_pidfd_open),
#endif
#ifdef SYS_pidfd_getfd
      MWPERF_C16_DENY_SYSCALL(SYS_pidfd_getfd),
#endif
#ifdef SYS_pidfd_send_signal
      MWPERF_C16_DENY_SYSCALL(SYS_pidfd_send_signal),
#endif
#ifdef SYS_kill
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_kill, 0, 4),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   args[0]))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, self_process, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO |
                                      (EPERM & SECCOMP_RET_DATA)),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#endif
#ifdef SYS_tkill
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_tkill, 0, 4),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   args[0]))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, self_process, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO |
                                      (EPERM & SECCOMP_RET_DATA)),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#endif
#ifdef SYS_tgkill
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_tgkill, 0, 6),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   args[0]))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, self_process, 0, 2),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   args[1]))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, self_process, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO |
                                      (EPERM & SECCOMP_RET_DATA)),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#endif
#ifdef SYS_rt_sigqueueinfo
      MWPERF_C16_DENY_SYSCALL(SYS_rt_sigqueueinfo),
#endif
#ifdef SYS_rt_tgsigqueueinfo
      MWPERF_C16_DENY_SYSCALL(SYS_rt_tgsigqueueinfo),
#endif
#ifdef SYS_mount
      MWPERF_C16_DENY_SYSCALL(SYS_mount),
#endif
#ifdef SYS_umount2
      MWPERF_C16_DENY_SYSCALL(SYS_umount2),
#endif
#ifdef SYS_pivot_root
      MWPERF_C16_DENY_SYSCALL(SYS_pivot_root),
#endif
#ifdef SYS_chroot
      MWPERF_C16_DENY_SYSCALL(SYS_chroot),
#endif
#ifdef SYS_open_by_handle_at
      MWPERF_C16_DENY_SYSCALL(SYS_open_by_handle_at),
#endif
#ifdef SYS_memfd_create
      MWPERF_C16_DENY_SYSCALL(SYS_memfd_create),
#endif
#ifdef SYS_chmod
      MWPERF_C16_DENY_SYSCALL(SYS_chmod),
#endif
#ifdef SYS_fchmod
      MWPERF_C16_DENY_SYSCALL(SYS_fchmod),
#endif
#ifdef SYS_fchmodat
      MWPERF_C16_DENY_SYSCALL(SYS_fchmodat),
#endif
#ifdef SYS_fchmodat2
      MWPERF_C16_DENY_SYSCALL(SYS_fchmodat2),
#endif
#ifdef SYS_chown
      MWPERF_C16_DENY_SYSCALL(SYS_chown),
#endif
#ifdef SYS_fchown
      MWPERF_C16_DENY_SYSCALL(SYS_fchown),
#endif
#ifdef SYS_fchownat
      MWPERF_C16_DENY_SYSCALL(SYS_fchownat),
#endif
#ifdef SYS_lchown
      MWPERF_C16_DENY_SYSCALL(SYS_lchown),
#endif
#ifdef SYS_setxattr
      MWPERF_C16_DENY_SYSCALL(SYS_setxattr),
#endif
#ifdef SYS_lsetxattr
      MWPERF_C16_DENY_SYSCALL(SYS_lsetxattr),
#endif
#ifdef SYS_fsetxattr
      MWPERF_C16_DENY_SYSCALL(SYS_fsetxattr),
#endif
#ifdef SYS_utime
      MWPERF_C16_DENY_SYSCALL(SYS_utime),
#endif
#ifdef SYS_utimes
      MWPERF_C16_DENY_SYSCALL(SYS_utimes),
#endif
#ifdef SYS_futimesat
      MWPERF_C16_DENY_SYSCALL(SYS_futimesat),
#endif
#ifdef SYS_utimensat
      MWPERF_C16_DENY_SYSCALL(SYS_utimensat),
#endif
#ifdef SYS_setrlimit
      MWPERF_C16_DENY_SYSCALL(SYS_setrlimit),
#endif
#ifdef SYS_prlimit64
      MWPERF_C16_DENY_SYSCALL(SYS_prlimit64),
#endif
#ifdef SYS_bpf
      MWPERF_C16_DENY_SYSCALL(SYS_bpf),
#endif
#ifdef SYS_userfaultfd
      MWPERF_C16_DENY_SYSCALL(SYS_userfaultfd),
#endif
#ifdef SYS_io_uring_setup
      MWPERF_C16_DENY_SYSCALL(SYS_io_uring_setup),
#endif
#ifdef SYS_add_key
      MWPERF_C16_DENY_SYSCALL(SYS_add_key),
#endif
#ifdef SYS_request_key
      MWPERF_C16_DENY_SYSCALL(SYS_request_key),
#endif
#ifdef SYS_keyctl
      MWPERF_C16_DENY_SYSCALL(SYS_keyctl),
#endif
#ifdef SYS_syslog
      MWPERF_C16_DENY_SYSCALL(SYS_syslog),
#endif
#ifdef SYS_init_module
      MWPERF_C16_DENY_SYSCALL(SYS_init_module),
#endif
#ifdef SYS_finit_module
      MWPERF_C16_DENY_SYSCALL(SYS_finit_module),
#endif
#ifdef SYS_delete_module
      MWPERF_C16_DENY_SYSCALL(SYS_delete_module),
#endif
#ifdef SYS_kexec_load
      MWPERF_C16_DENY_SYSCALL(SYS_kexec_load),
#endif
#ifdef SYS_kexec_file_load
      MWPERF_C16_DENY_SYSCALL(SYS_kexec_file_load),
#endif
#ifdef SYS_reboot
      MWPERF_C16_DENY_SYSCALL(SYS_reboot),
#endif
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
  };
  const struct sock_fprog program {
    static_cast<unsigned short>(std::size(filter)),
        const_cast<struct sock_filter*>(filter)
  };
  if (::prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &program) != 0) {
    return errno;
  }

  // The first filter gives named high-risk syscalls precise diagnostics.  A
  // second, compositional filter closes the syscall namespace: a future or
  // omitted syscall is denied unless it is one of the small static-runtime,
  // descriptor-I/O, allocation, timing, or protocol operations below.
  const struct sock_filter allow_filter[] = {
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data,
                                                   arch))),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, kAuditArchitecture, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
               static_cast<std::uint32_t>(offsetof(struct seccomp_data, nr))),
#ifdef SYS_read
      MWPERF_C16_ALLOW_SYSCALL(SYS_read),
#endif
#ifdef SYS_write
      MWPERF_C16_ALLOW_SYSCALL(SYS_write),
#endif
#ifdef SYS_readv
      MWPERF_C16_ALLOW_SYSCALL(SYS_readv),
#endif
#ifdef SYS_writev
      MWPERF_C16_ALLOW_SYSCALL(SYS_writev),
#endif
#ifdef SYS_pread64
      MWPERF_C16_ALLOW_SYSCALL(SYS_pread64),
#endif
#ifdef SYS_pwrite64
      MWPERF_C16_ALLOW_SYSCALL(SYS_pwrite64),
#endif
#ifdef SYS_close
      MWPERF_C16_ALLOW_SYSCALL(SYS_close),
#endif
#ifdef SYS_lseek
      MWPERF_C16_ALLOW_SYSCALL(SYS_lseek),
#endif
#ifdef SYS_fstat
      MWPERF_C16_ALLOW_SYSCALL(SYS_fstat),
#endif
#ifdef SYS_mmap
      MWPERF_C16_ALLOW_SYSCALL(SYS_mmap),
#endif
#ifdef SYS_mmap2
      MWPERF_C16_ALLOW_SYSCALL(SYS_mmap2),
#endif
#ifdef SYS_mprotect
      MWPERF_C16_ALLOW_SYSCALL(SYS_mprotect),
#endif
#ifdef SYS_munmap
      MWPERF_C16_ALLOW_SYSCALL(SYS_munmap),
#endif
#ifdef SYS_mremap
      MWPERF_C16_ALLOW_SYSCALL(SYS_mremap),
#endif
#ifdef SYS_madvise
      MWPERF_C16_ALLOW_SYSCALL(SYS_madvise),
#endif
#ifdef SYS_brk
      MWPERF_C16_ALLOW_SYSCALL(SYS_brk),
#endif
#ifdef SYS_arch_prctl
      MWPERF_C16_ALLOW_SYSCALL(SYS_arch_prctl),
#endif
#ifdef SYS_clone
      MWPERF_C16_ALLOW_SYSCALL(SYS_clone),
#endif
#ifdef SYS_clone3
      // The preceding filter returns ENOSYS so libc falls back to the
      // flag-inspected clone path; this compositional allow does not grant it.
      MWPERF_C16_ALLOW_SYSCALL(SYS_clone3),
#endif
#ifdef SYS_set_tid_address
      MWPERF_C16_ALLOW_SYSCALL(SYS_set_tid_address),
#endif
#ifdef SYS_set_robust_list
      MWPERF_C16_ALLOW_SYSCALL(SYS_set_robust_list),
#endif
#ifdef SYS_rseq
      MWPERF_C16_ALLOW_SYSCALL(SYS_rseq),
#endif
#ifdef SYS_futex
      MWPERF_C16_ALLOW_SYSCALL(SYS_futex),
#endif
#ifdef SYS_futex_time64
      MWPERF_C16_ALLOW_SYSCALL(SYS_futex_time64),
#endif
#ifdef SYS_futex_waitv
      MWPERF_C16_ALLOW_SYSCALL(SYS_futex_waitv),
#endif
#ifdef SYS_clock_gettime
      MWPERF_C16_ALLOW_SYSCALL(SYS_clock_gettime),
#endif
#ifdef SYS_clock_gettime64
      MWPERF_C16_ALLOW_SYSCALL(SYS_clock_gettime64),
#endif
#ifdef SYS_clock_nanosleep
      MWPERF_C16_ALLOW_SYSCALL(SYS_clock_nanosleep),
#endif
#ifdef SYS_clock_nanosleep_time64
      MWPERF_C16_ALLOW_SYSCALL(SYS_clock_nanosleep_time64),
#endif
#ifdef SYS_nanosleep
      MWPERF_C16_ALLOW_SYSCALL(SYS_nanosleep),
#endif
#ifdef SYS_sched_yield
      MWPERF_C16_ALLOW_SYSCALL(SYS_sched_yield),
#endif
#ifdef SYS_getpid
      MWPERF_C16_ALLOW_SYSCALL(SYS_getpid),
#endif
#ifdef SYS_gettid
      MWPERF_C16_ALLOW_SYSCALL(SYS_gettid),
#endif
#ifdef SYS_kill
      MWPERF_C16_ALLOW_SYSCALL(SYS_kill),
#endif
#ifdef SYS_tkill
      MWPERF_C16_ALLOW_SYSCALL(SYS_tkill),
#endif
#ifdef SYS_tgkill
      MWPERF_C16_ALLOW_SYSCALL(SYS_tgkill),
#endif
#ifdef SYS_rt_sigaction
      MWPERF_C16_ALLOW_SYSCALL(SYS_rt_sigaction),
#endif
#ifdef SYS_rt_sigprocmask
      MWPERF_C16_ALLOW_SYSCALL(SYS_rt_sigprocmask),
#endif
#ifdef SYS_sigaltstack
      MWPERF_C16_ALLOW_SYSCALL(SYS_sigaltstack),
#endif
#ifdef SYS_rt_sigreturn
      MWPERF_C16_ALLOW_SYSCALL(SYS_rt_sigreturn),
#endif
#ifdef SYS_sigreturn
      MWPERF_C16_ALLOW_SYSCALL(SYS_sigreturn),
#endif
#ifdef SYS_restart_syscall
      MWPERF_C16_ALLOW_SYSCALL(SYS_restart_syscall),
#endif
#ifdef SYS_open
      MWPERF_C16_ALLOW_SYSCALL(SYS_open),
#endif
#ifdef SYS_openat
      MWPERF_C16_ALLOW_SYSCALL(SYS_openat),
#endif
#ifdef SYS_creat
      MWPERF_C16_ALLOW_SYSCALL(SYS_creat),
#endif
#ifdef SYS_execveat
      MWPERF_C16_ALLOW_SYSCALL(SYS_execveat),
#endif
#ifdef SYS_exit
      MWPERF_C16_ALLOW_SYSCALL(SYS_exit),
#endif
#ifdef SYS_exit_group
      MWPERF_C16_ALLOW_SYSCALL(SYS_exit_group),
#endif
      BPF_STMT(BPF_RET | BPF_K,
               SECCOMP_RET_ERRNO | (EPERM & SECCOMP_RET_DATA)),
  };
  const struct sock_fprog allow_program {
    static_cast<unsigned short>(std::size(allow_filter)),
        const_cast<struct sock_filter*>(allow_filter)
  };
  if (::prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &allow_program) != 0) {
    return errno;
  }
  return 0;
}

#undef MWPERF_C16_DENY_SYSCALL
#undef MWPERF_C16_NOTIFY_SYSCALL
#undef MWPERF_C16_ALLOW_SYSCALL

[[nodiscard]] int apply_child_resource_limits(
    const std::size_t result_cap) noexcept {
  if (::prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) {
    return errno;
  }
  struct rlimit file_limit {};
  if (::getrlimit(RLIMIT_FSIZE, &file_limit) != 0) {
    return errno;
  }
  const rlim_t requested = static_cast<rlim_t>(result_cap);
  if (static_cast<std::size_t>(requested) != result_cap) {
    return EOVERFLOW;
  }
  file_limit.rlim_cur =
      file_limit.rlim_max == RLIM_INFINITY
          ? requested
          : std::min(file_limit.rlim_max, requested);
  if (::setrlimit(RLIMIT_FSIZE, &file_limit) != 0) {
    return errno;
  }
  const struct rlimit core_limit {
    0, 0
  };
  if (::setrlimit(RLIMIT_CORE, &core_limit) != 0) {
    return errno;
  }
  return 0;
}

[[nodiscard]] int reset_child_signal_state() noexcept {
  struct sigaction disposition {};
  disposition.sa_handler = SIG_DFL;
  if (::sigemptyset(&disposition.sa_mask) != 0) {
    return errno;
  }
  for (int signal_number = 1; signal_number < NSIG; ++signal_number) {
    if (signal_number == SIGKILL || signal_number == SIGSTOP) {
      continue;
    }
    if (::sigaction(signal_number, &disposition, nullptr) != 0 &&
        errno != EINVAL) {
      return errno;
    }
  }
  sigset_t empty_mask;
  if (::sigemptyset(&empty_mask) != 0 ||
      ::sigprocmask(SIG_SETMASK, &empty_mask, nullptr) != 0) {
    return errno;
  }
  return 0;
}

[[nodiscard]] int close_ambient_descriptors_on_exec() noexcept {
#ifdef SYS_close_range
  if (::syscall(SYS_close_range, static_cast<unsigned int>(STDERR_FILENO + 1),
                std::numeric_limits<unsigned int>::max(),
                CLOSE_RANGE_CLOEXEC) == 0) {
    return 0;
  }
  return errno;
#else
  return EOPNOTSUPP;
#endif
}

constexpr std::uint32_t kStaticBrokerHandshakeMagic = 0x43313642U;

struct StaticBrokerHandshake final {
  std::uint32_t magic{kStaticBrokerHandshakeMagic};
  int error_number{0};
  bool descriptor_table_unshared{false};
};

[[nodiscard]] bool write_static_broker_handshake(
    const int descriptor, const StaticBrokerHandshake& handshake) noexcept {
  const auto* bytes = reinterpret_cast<const char*>(&handshake);
  std::size_t written = 0U;
  while (written < sizeof(handshake)) {
    const ssize_t count =
        ::write(descriptor, bytes + written, sizeof(handshake) - written);
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count <= 0) {
      return false;
    }
    written += static_cast<std::size_t>(count);
  }
  return true;
}

struct StaticBuilderChildArguments final {
  LinuxSandboxBackend backend{LinuxSandboxBackend::landlock};
  int run_directory_descriptor{-1};
  int executable_descriptor{-1};
  int null_input_descriptor{-1};
  int stdout_descriptor{-1};
  int stderr_descriptor{-1};
  int exec_error_descriptor{-1};
  int handshake_descriptor{-1};
  int listener_slot{-1};
  std::size_t result_cap{0U};
  char* const* arguments{nullptr};
};

[[nodiscard]] int static_builder_child_main(void* const opaque) noexcept {
  const auto& child =
      *static_cast<const StaticBuilderChildArguments*>(opaque);
  const int signal_error = reset_child_signal_state();
  if (signal_error != 0 || ::setpgid(0, 0) != 0 ||
      ::fchdir(child.run_directory_descriptor) != 0) {
    child_report_error_and_exit(
        child.exec_error_descriptor, ChildFailureStage::setup,
        signal_error != 0 ? signal_error : errno);
  }
  (void)::umask(S_IRWXG | S_IRWXO);
  const int resource_error = apply_child_resource_limits(child.result_cap);
  if (resource_error != 0) {
    child_report_error_and_exit(child.exec_error_descriptor,
                                ChildFailureStage::sandbox,
                                resource_error);
  }

  if (child.backend == LinuxSandboxBackend::landlock) {
    const int landlock_error = apply_landlock_filesystem_policy(
        child.run_directory_descriptor, child.executable_descriptor);
    if (landlock_error != 0) {
      child_report_error_and_exit(child.exec_error_descriptor,
                                  ChildFailureStage::sandbox,
                                  landlock_error);
    }
  }

  const int listener =
      child.backend == LinuxSandboxBackend::static_seccomp_broker
          ? create_static_path_broker_listener()
          : create_exec_broker_listener();
  int setup_error = listener < 0 ? -listener : 0;
  if (setup_error == 0 &&
      (::dup3(listener, child.listener_slot, O_CLOEXEC) < 0 ||
       ::close(listener) != 0)) {
    setup_error = errno;
    if (listener >= 0 && listener != child.listener_slot) {
      (void)::close(listener);
    }
  }

  bool unshared = false;
#ifdef SYS_close_range
  if (::syscall(SYS_close_range,
                static_cast<unsigned int>(STDERR_FILENO + 1),
                std::numeric_limits<unsigned int>::max(),
                CLOSE_RANGE_UNSHARE | CLOSE_RANGE_CLOEXEC) == 0) {
    unshared = true;
  } else if (setup_error == 0) {
    setup_error = errno;
  }
#else
  if (setup_error == 0) {
    setup_error = EOPNOTSUPP;
  }
#endif
  const StaticBrokerHandshake handshake{kStaticBrokerHandshakeMagic,
                                         setup_error, unshared};
  if (!write_static_broker_handshake(child.handshake_descriptor,
                                     handshake) ||
      setup_error != 0 || !unshared) {
    ::_exit(127);
  }

  (void)::close(child.listener_slot);
  if (::dup2(child.null_input_descriptor, STDIN_FILENO) < 0 ||
      ::dup2(child.stdout_descriptor, STDOUT_FILENO) < 0 ||
      ::dup2(child.stderr_descriptor, STDERR_FILENO) < 0) {
    child_report_error_and_exit(child.exec_error_descriptor,
                                ChildFailureStage::setup, errno);
  }
  const int descriptor_error = close_ambient_descriptors_on_exec();
  const int policy_error =
      descriptor_error == 0 ? apply_seccomp_process_and_network_policy() : 0;
  if (policy_error != 0 || descriptor_error != 0) {
    child_report_error_and_exit(
        child.exec_error_descriptor, ChildFailureStage::sandbox,
        policy_error != 0 ? policy_error : descriptor_error);
  }
  char* const empty_environment[]{nullptr};
  ::fexecve(child.executable_descriptor, child.arguments,
            empty_environment);
  child_report_error_and_exit(child.exec_error_descriptor,
                              ChildFailureStage::execute, errno);
  return 127;
}

struct StaticBrokerHandshakeObservation final {
  StaticBrokerHandshake handshake{};
  bool received{false};
  bool timed_out{false};
  bool child_reaped{false};
  int wait_status{0};
};

[[nodiscard]] StaticBrokerHandshakeObservation await_static_broker_handshake(
    const pid_t child, const int descriptor,
    const std::chrono::milliseconds wall_limit,
    const std::chrono::steady_clock::time_point start) noexcept {
  StaticBrokerHandshakeObservation observation;
  auto* bytes = reinterpret_cast<std::byte*>(&observation.handshake);
  std::size_t received = 0U;
  while (received < sizeof(observation.handshake)) {
    const ssize_t count = ::read(descriptor, bytes + received,
                                 sizeof(observation.handshake) - received);
    if (count > 0) {
      received += static_cast<std::size_t>(count);
      continue;
    }
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count < 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
      break;
    }

    const pid_t waited = ::waitpid(child, &observation.wait_status, WNOHANG);
    if (waited == child || (waited < 0 && errno == ECHILD)) {
      observation.child_reaped = true;
      break;
    }
    if (waited < 0 && errno != EINTR) {
      break;
    }
    const auto now = std::chrono::steady_clock::now();
    if (now - start >= wall_limit) {
      observation.timed_out = true;
      break;
    }
    const auto remaining =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            wall_limit - (now - start));
    const auto delay = std::max(std::chrono::milliseconds(0),
                                std::min(std::chrono::milliseconds(10),
                                         remaining));
    struct pollfd poll_descriptor {
      descriptor, POLLIN | POLLHUP, 0
    };
    int poll_result;
    do {
      poll_result = ::poll(&poll_descriptor, 1,
                           static_cast<int>(delay.count()));
    } while (poll_result < 0 && errno == EINTR);
    if (poll_result < 0) {
      break;
    }
  }
  observation.received = received == sizeof(observation.handshake);
  return observation;
}

[[nodiscard]] Result<ScopedFd> open_static_broker_request(
    const int directory_fd, const FileIdentity& identity) {
  ScopedFd descriptor(::openat(
      directory_fd, kRequestFileName.data(),
      O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC));
  struct stat attributes {};
  if (descriptor.get() < 0 || ::fstat(descriptor.get(), &attributes) != 0 ||
      !S_ISREG(attributes.st_mode) || attributes.st_nlink != 1 ||
      attributes.st_dev != identity.device ||
      attributes.st_ino != identity.inode ||
      attributes.st_size != identity.size ||
      (attributes.st_mode & 0777) != S_IRUSR) {
    return Result<ScopedFd>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_request_mutated",
        "the immutable request could not be bound to the static broker"));
  }
  return Result<ScopedFd>::success(std::move(descriptor));
}

struct StaticPathBroker final {
  pid_t child{-1};
  int directory_fd{-1};
  int executable_descriptor{-1};
  bool broker_paths{false};
  StaticPathAttestation path_attestation{StaticPathAttestation::undecided};
  ScopedFd listener;
  ScopedFd request_source;
  ScopedFd result_source;
  bool request_injected{false};
  bool result_injected{false};
  bool initial_exec_allowed{false};
  bool service_failed{false};
  int service_error{0};
  StaticBrokerViolation violation{StaticBrokerViolation::none};
};

[[nodiscard]] bool static_broker_read_flags(const int flags) noexcept {
  constexpr int kPermitted = O_CLOEXEC | O_NOCTTY | O_NONBLOCK |
                             O_NOFOLLOW | O_LARGEFILE;
  return (flags & O_ACCMODE) == O_RDONLY &&
         (flags & ~(O_ACCMODE | kPermitted)) == 0;
}

[[nodiscard]] bool static_broker_result_flags(const int flags) noexcept {
  constexpr int kRequired = O_WRONLY | O_CREAT | O_TRUNC;
  constexpr int kPermitted = kRequired | O_CLOEXEC | O_NOCTTY |
                             O_NONBLOCK | O_NOFOLLOW | O_LARGEFILE | O_EXCL;
  return (flags & kRequired) == kRequired &&
         (flags & O_ACCMODE) == O_WRONLY && (flags & ~kPermitted) == 0;
}

[[nodiscard]] bool send_static_broker_denial(
    const int listener, const std::uint64_t id) noexcept {
  struct seccomp_notif_resp response {};
  response.id = id;
  response.error = -EACCES;
  return ::ioctl(listener, SECCOMP_IOCTL_NOTIF_SEND, &response) == 0;
}

[[nodiscard]] bool continue_initial_broker_exec(
    const int listener, const std::uint64_t id) noexcept {
  struct seccomp_notif_resp response {};
  response.id = id;
  response.flags = SECCOMP_USER_NOTIF_FLAG_CONTINUE;
  return ::ioctl(listener, SECCOMP_IOCTL_NOTIF_SEND, &response) == 0;
}

void mark_static_broker_failure(StaticPathBroker& broker,
                                const int error_number) noexcept {
  broker.service_failed = true;
  broker.service_error = error_number == 0 ? EIO : error_number;
}

[[nodiscard]] bool static_broker_notification_is_valid(
    const StaticPathBroker& broker, const std::uint64_t id) noexcept {
  return ::ioctl(broker.listener.get(), SECCOMP_IOCTL_NOTIF_ID_VALID,
                 &id) == 0;
}

[[nodiscard]] bool read_static_broker_path(
    StaticPathBroker& broker, const std::uint64_t notification_id,
    const std::uint64_t remote_address,
    std::array<char, 64U>& path) noexcept {
  errno = 0;
  if (remote_address == 0U ||
      remote_address >
          static_cast<std::uint64_t>(
              std::numeric_limits<std::uintptr_t>::max()) ||
      !static_broker_notification_is_valid(broker, notification_id)) {
    return false;
  }
  path.fill('\0');
  const auto address = static_cast<std::uintptr_t>(remote_address);
  for (std::size_t offset = 0U; offset < path.size(); ++offset) {
    struct iovec local {
      &path[offset], 1U
    };
    struct iovec remote {
      reinterpret_cast<void*>(address + offset), 1U
    };
    ssize_t transferred;
    do {
      transferred = ::process_vm_readv(broker.child, &local, 1U, &remote,
                                       1U, 0U);
    } while (transferred < 0 && errno == EINTR);
    if (transferred != 1) {
      return false;
    }
    if (path[offset] == '\0') {
      return static_broker_notification_is_valid(broker,
                                                  notification_id);
    }
  }
  errno = ENAMETOOLONG;
  return false;
}

[[nodiscard]] bool static_broker_path_equals(
    const std::array<char, 64U>& path,
    const std::string_view expected) noexcept {
  return expected.size() + 1U <= path.size() &&
         std::memcmp(path.data(), expected.data(), expected.size()) == 0 &&
         path[expected.size()] == '\0';
}

void service_static_path_broker(StaticPathBroker& broker) noexcept {
  if (broker.service_failed || broker.violation != StaticBrokerViolation::none) {
    return;
  }
  struct seccomp_notif notification {};
  if (::ioctl(broker.listener.get(), SECCOMP_IOCTL_NOTIF_RECV,
              &notification) != 0) {
    if (errno != EAGAIN && errno != EWOULDBLOCK && errno != ENOENT &&
        errno != EINTR) {
      mark_static_broker_failure(broker, errno);
    }
    return;
  }
  if (notification.flags != 0U ||
      notification.pid != static_cast<__u32>(broker.child) ||
      !static_broker_notification_is_valid(broker, notification.id)) {
    const int validation_error = errno;
    (void)send_static_broker_denial(broker.listener.get(), notification.id);
    mark_static_broker_failure(broker, validation_error);
    return;
  }

#ifdef SYS_execveat
  if (notification.data.nr == SYS_execveat) {
    const bool exact_initial_exec =
        !broker.initial_exec_allowed &&
        notification.data.args[0] ==
            static_cast<std::uint64_t>(broker.executable_descriptor) &&
        notification.data.args[4] == static_cast<std::uint64_t>(AT_EMPTY_PATH);
    if (!exact_initial_exec) {
      broker.violation = broker.initial_exec_allowed
                             ? StaticBrokerViolation::repeated_execution
                             : StaticBrokerViolation::forbidden_path_access;
      if (!send_static_broker_denial(broker.listener.get(),
                                     notification.id) &&
          errno != ENOENT) {
        mark_static_broker_failure(broker, errno);
      }
      return;
    }
    if (!continue_initial_broker_exec(broker.listener.get(),
                                      notification.id)) {
      if (errno != ENOENT) {
        mark_static_broker_failure(broker, errno);
      }
      return;
    }
    broker.initial_exec_allowed = true;
    return;
  }
#endif
  if (!broker.broker_paths || !broker.initial_exec_allowed) {
    broker.violation = StaticBrokerViolation::forbidden_path_access;
    if (!send_static_broker_denial(broker.listener.get(), notification.id) &&
        errno != ENOENT) {
      mark_static_broker_failure(broker, errno);
    }
    return;
  }

  bool read_request = false;
  bool write_result = false;
  std::uint64_t path_address = 0U;
  int flags = 0;
#ifdef SYS_open
  if (notification.data.nr == SYS_open) {
    path_address = notification.data.args[0];
    if (notification.data.args[1] >
        static_cast<std::uint64_t>(std::numeric_limits<int>::max())) {
      broker.violation = StaticBrokerViolation::forbidden_path_access;
    } else {
      flags = static_cast<int>(notification.data.args[1]);
      read_request = static_broker_read_flags(flags);
      write_result = static_broker_result_flags(flags);
    }
  } else
#endif
#ifdef SYS_openat
      if (notification.data.nr == SYS_openat) {
    path_address = notification.data.args[1];
    const auto directory_argument =
        static_cast<std::uint32_t>(notification.data.args[0]);
    if (directory_argument != static_cast<std::uint32_t>(AT_FDCWD) ||
        notification.data.args[2] >
        static_cast<std::uint64_t>(std::numeric_limits<int>::max())) {
      broker.violation = StaticBrokerViolation::forbidden_path_access;
    } else {
      flags = static_cast<int>(notification.data.args[2]);
      read_request = static_broker_read_flags(flags);
      write_result = static_broker_result_flags(flags);
    }
  } else
#endif
#ifdef SYS_creat
      if (notification.data.nr == SYS_creat) {
    path_address = notification.data.args[0];
    write_result = notification.data.args[1] <= 0777U;
  } else
#endif
  {
    broker.violation = StaticBrokerViolation::forbidden_path_access;
  }

  std::array<char, 64U> requested_path{};
  bool path_was_read = false;
  if (broker.violation == StaticBrokerViolation::none &&
      broker.path_attestation != StaticPathAttestation::capability_only) {
    path_was_read = read_static_broker_path(
        broker, notification.id, path_address, requested_path);
    if (path_was_read) {
      broker.path_attestation = StaticPathAttestation::exact;
    } else if ((errno == EPERM || errno == EACCES || errno == ENOSYS) &&
               broker.path_attestation == StaticPathAttestation::undecided) {
      // Some otherwise supported Linux carriers deny every cross-memory read.
      // In that environment no child-supplied pathname is resolved or
      // continued.  This finite-state broker virtualizes only the already
      // authorized request and result capabilities via ADDFD; it does not
      // attest which spelling the child attempted.
      broker.path_attestation = StaticPathAttestation::capability_only;
    } else if (errno == EPERM || errno == EACCES || errno == ENOSYS) {
      // Never downgrade after successfully attesting an earlier pathname.
      mark_static_broker_failure(broker, errno);
    } else {
      broker.violation = StaticBrokerViolation::forbidden_path_access;
    }
  }

  if (broker.violation == StaticBrokerViolation::none &&
      !broker.service_failed &&
      broker.path_attestation == StaticPathAttestation::exact) {
    const bool exact_request_path =
        path_was_read &&
        static_broker_path_equals(requested_path, kRequestFileName);
    const bool exact_result_path =
        path_was_read &&
        static_broker_path_equals(requested_path, kResultFileName);
    if (write_result && broker.result_injected) {
      // The protocol owns exactly one result publication channel.  Preserve
      // the more specific duplicate-output classification even if a second
      // create names some other path.
    } else if (read_request && !exact_request_path) {
      broker.violation = StaticBrokerViolation::forbidden_path_access;
    } else if (write_result && exact_request_path) {
      broker.violation = StaticBrokerViolation::request_mutation;
    } else if (write_result && !exact_result_path) {
      broker.violation = StaticBrokerViolation::forbidden_path_access;
    }
  }

  int source_descriptor = -1;
  if (broker.violation == StaticBrokerViolation::none && read_request &&
      !broker.request_injected && !broker.result_injected) {
    source_descriptor = broker.request_source.get();
  } else if (broker.violation == StaticBrokerViolation::none &&
             write_result && broker.request_injected &&
             !broker.result_injected) {
    broker.result_source.reset(::openat(
        broker.directory_fd, kResultFileName.data(),
        O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC,
        S_IRUSR | S_IWUSR));
    struct stat attributes {};
    if (broker.result_source.get() < 0 ||
        ::fchmod(broker.result_source.get(), S_IRUSR | S_IWUSR) != 0 ||
        ::fstat(broker.result_source.get(), &attributes) != 0 ||
        !S_ISREG(attributes.st_mode) || attributes.st_nlink != 1 ||
        (attributes.st_mode & 0777) != (S_IRUSR | S_IWUSR)) {
      mark_static_broker_failure(broker, errno);
    } else {
      source_descriptor = broker.result_source.get();
    }
  } else if (write_result && broker.result_injected) {
    broker.violation = StaticBrokerViolation::duplicate_result_open;
  } else {
    broker.violation = StaticBrokerViolation::forbidden_path_access;
  }

  if (broker.service_failed ||
      broker.violation != StaticBrokerViolation::none) {
    if (!send_static_broker_denial(broker.listener.get(), notification.id) &&
        errno != ENOENT) {
      mark_static_broker_failure(broker, errno);
    }
    return;
  }

  struct seccomp_notif_addfd injected {};
  injected.id = notification.id;
  injected.flags = SECCOMP_ADDFD_FLAG_SEND;
  injected.srcfd = static_cast<__u32>(source_descriptor);
  injected.newfd_flags = O_CLOEXEC;
  const int child_descriptor = ::ioctl(
      broker.listener.get(), SECCOMP_IOCTL_NOTIF_ADDFD, &injected);
  if (child_descriptor < 0) {
    if (errno != ENOENT) {
      mark_static_broker_failure(broker, errno);
    }
    return;
  }
  if (read_request) {
    broker.request_injected = true;
  } else {
    broker.result_injected = true;
  }
}

#endif  // defined(__linux__)

struct ProcessObservation final {
  bool wait_failed{false};
  bool child_reaped{false};
  bool timed_out{false};
  bool stdout_nonempty{false};
  bool static_broker_failed{false};
  int static_broker_error{0};
  StaticBrokerViolation static_broker_violation{
      StaticBrokerViolation::none};
  bool static_broker_request_injected{false};
  bool static_broker_result_injected{false};
  bool static_broker_initial_exec_allowed{false};
  int wait_status{0};
  ChildFailure child_failure{};
  bool child_failure_reported{false};
  StderrCapture stderr_capture;
  std::chrono::nanoseconds elapsed{0};
};

void terminate_process_group(const pid_t child) noexcept {
  if (child <= 0) {
    return;
  }
  (void)::kill(-child, SIGKILL);
  (void)::kill(child, SIGKILL);
}

class ScopedChildProcess final {
 public:
  explicit ScopedChildProcess(const pid_t child) noexcept : child_(child) {}

  ScopedChildProcess(const ScopedChildProcess&) = delete;
  ScopedChildProcess& operator=(const ScopedChildProcess&) = delete;

  ~ScopedChildProcess() noexcept { terminate_and_reap(); }

  void release() noexcept { active_ = false; }
  void terminate_and_reap_now() noexcept { terminate_and_reap(); }

 private:
  void terminate_and_reap() noexcept {
    if (!active_ || child_ <= 0) {
      return;
    }

    int status = 0;
    pid_t waited;
    do {
      waited = ::waitpid(child_, &status, WNOHANG);
    } while (waited < 0 && errno == EINTR);
    if (waited == child_ || (waited < 0 && errno == ECHILD)) {
      active_ = false;
      return;
    }

    terminate_process_group(child_);
    do {
      waited = ::waitpid(child_, &status, 0);
    } while (waited < 0 && errno == EINTR);
    active_ = false;
  }

  pid_t child_{-1};
  bool active_{true};
};

void drain_stdout(const int descriptor, bool& nonempty, bool& closed) {
  if (descriptor < 0) {
    closed = true;
    return;
  }
  std::array<std::byte, 4096U> buffer{};
  for (;;) {
    const ssize_t count = ::read(descriptor, buffer.data(), buffer.size());
    if (count > 0) {
      nonempty = true;
      return;
    }
    if (count == 0) {
      closed = true;
    }
    if (count < 0 && errno == EINTR) {
      continue;
    }
    return;
  }
}

void drain_stderr(const int descriptor, const std::size_t cap,
                  StderrCapture& capture, bool& closed) {
  if (descriptor < 0) {
    closed = true;
    return;
  }
  std::array<std::byte, 4096U> buffer{};
  constexpr std::size_t kMaximumReadsPerObservation = 16U;
  std::size_t reads = 0U;
  for (;;) {
    const ssize_t count = ::read(descriptor, buffer.data(), buffer.size());
    if (count > 0) {
      const std::size_t amount = static_cast<std::size_t>(count);
      const std::size_t remaining =
          capture.bytes < cap ? cap - capture.bytes : 0U;
      const std::size_t accepted = std::min(amount, remaining);
      const std::size_t excerpt_remaining =
          capture.excerpt.size() < kMaximumStderrExcerptBytes
              ? kMaximumStderrExcerptBytes - capture.excerpt.size()
              : 0U;
      const std::size_t excerpt_amount = std::min(accepted,
                                                  excerpt_remaining);
      capture.excerpt.insert(capture.excerpt.end(), buffer.begin(),
                             buffer.begin() +
                                 static_cast<std::ptrdiff_t>(excerpt_amount));
      if (amount > remaining) {
        capture.bytes = cap == std::numeric_limits<std::size_t>::max()
                            ? cap
                            : cap + 1U;
        capture.limit_exceeded = true;
      } else {
        capture.bytes += amount;
      }
      if (capture.limit_exceeded || ++reads >= kMaximumReadsPerObservation) {
        return;
      }
      continue;
    }
    if (count == 0) {
      closed = true;
    }
    if (count < 0 && errno == EINTR) {
      continue;
    }
    return;
  }
}

void drain_exec_error(const int descriptor, ChildFailure& failure,
                      std::size_t& bytes_received, bool& closed) {
  if (descriptor < 0) {
    closed = true;
    return;
  }
  auto* output = reinterpret_cast<std::byte*>(&failure);
  while (bytes_received < sizeof(failure)) {
    const ssize_t count = ::read(descriptor, output + bytes_received,
                                 sizeof(failure) - bytes_received);
    if (count > 0) {
      bytes_received += static_cast<std::size_t>(count);
      continue;
    }
    if (count == 0) {
      closed = true;
    }
    if (count < 0 && errno == EINTR) {
      continue;
    }
    return;
  }
}

[[nodiscard]] ProcessObservation observe_process(
    const pid_t child, ScopedFd stdout_read, ScopedFd stderr_read,
    ScopedFd exec_error_read, const std::chrono::milliseconds wall_limit,
    const std::size_t stderr_cap,
    const std::chrono::steady_clock::time_point start,
    StaticPathBroker* const static_broker) {
  ProcessObservation observation;
  bool stdout_closed = false;
  bool stderr_closed = false;
  bool exec_error_closed = false;
  std::size_t exec_error_bytes = 0U;
  bool reaped = false;

  while (!reaped) {
    drain_stdout(stdout_read.get(), observation.stdout_nonempty,
                 stdout_closed);
    drain_stderr(stderr_read.get(), stderr_cap, observation.stderr_capture,
                 stderr_closed);
    drain_exec_error(exec_error_read.get(), observation.child_failure,
                     exec_error_bytes, exec_error_closed);
    if (stdout_closed) {
      stdout_read.reset();
    }
    if (stderr_closed) {
      stderr_read.reset();
    }
    if (exec_error_closed) {
      exec_error_read.reset();
    }

#if defined(__linux__)
    const bool broker_abort =
        static_broker != nullptr &&
        (static_broker->service_failed ||
         static_broker->violation != StaticBrokerViolation::none);
#else
    const bool broker_abort = false;
#endif

    if (observation.stdout_nonempty ||
        observation.stderr_capture.limit_exceeded || broker_abort) {
      terminate_process_group(child);
      for (;;) {
        const pid_t waited = ::waitpid(child, &observation.wait_status, 0);
        if (waited == child) {
          observation.child_reaped = true;
          reaped = true;
          break;
        }
        if (waited < 0 && errno == EINTR) {
          continue;
        }
        observation.wait_failed = true;
        reaped = true;
        break;
      }
      break;
    }

    const pid_t waited =
        ::waitpid(child, &observation.wait_status, WNOHANG);
    if (waited == child) {
      observation.child_reaped = true;
      reaped = true;
      break;
    }
    if (waited < 0 && errno != EINTR) {
      observation.child_reaped = errno == ECHILD;
      observation.wait_failed = true;
      terminate_process_group(child);
      reaped = true;
      break;
    }

    const auto now = std::chrono::steady_clock::now();
    if (now - start >= wall_limit) {
      observation.timed_out = true;
      terminate_process_group(child);
      for (;;) {
        const pid_t final_wait =
            ::waitpid(child, &observation.wait_status, 0);
        if (final_wait == child) {
          observation.child_reaped = true;
          break;
        }
        if (final_wait < 0 && errno == EINTR) {
          continue;
        }
        observation.wait_failed = true;
        break;
      }
      reaped = true;
      break;
    }

    int broker_descriptor = -1;
#if defined(__linux__)
    if (static_broker != nullptr) {
      broker_descriptor = static_broker->listener.get();
    }
#endif
    std::array<struct pollfd, 4U> descriptors{
        pollfd{stdout_read.get(), POLLIN | POLLHUP, 0},
        pollfd{stderr_read.get(), POLLIN | POLLHUP, 0},
        pollfd{exec_error_read.get(), POLLIN | POLLHUP, 0},
        pollfd{broker_descriptor, POLLIN | POLLHUP, 0}};
    constexpr auto kPollSlice = std::chrono::milliseconds(10);
    const auto remaining =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            wall_limit - (now - start));
    const auto delay = std::max(std::chrono::milliseconds(0),
                                std::min(kPollSlice, remaining));
    const int poll_delay = static_cast<int>(delay.count());
    int poll_result;
    do {
      poll_result = ::poll(descriptors.data(), descriptors.size(),
                           poll_delay);
    } while (poll_result < 0 && errno == EINTR);
    if (poll_result < 0) {
      observation.wait_failed = true;
      terminate_process_group(child);
      for (;;) {
        const pid_t final_wait =
            ::waitpid(child, &observation.wait_status, 0);
        if (final_wait == child) {
          observation.child_reaped = true;
          break;
        }
        if (final_wait < 0 && errno == ECHILD) {
          observation.child_reaped = true;
          break;
        }
        if (final_wait < 0 && errno != EINTR) {
          break;
        }
      }
      reaped = true;
    }
#if defined(__linux__)
    if (poll_result > 0 && static_broker != nullptr &&
        (descriptors[3].revents & POLLIN) != 0) {
      // SECCOMP_IOCTL_NOTIF_RECV may block even when the listener has
      // O_NONBLOCK.  Service it only after poll reports a pending
      // notification so an idle builder remains governed by the wall clock.
      service_static_path_broker(*static_broker);
    }
#endif
  }

  // The child is gone and its process group has been terminated.  Drain only
  // data already buffered in the three nonblocking pipes, then close them.
  drain_stdout(stdout_read.get(), observation.stdout_nonempty, stdout_closed);
  while (!stderr_closed &&
         !observation.stderr_capture.limit_exceeded) {
    const auto bytes_before = observation.stderr_capture.bytes;
    drain_stderr(stderr_read.get(), stderr_cap,
                 observation.stderr_capture, stderr_closed);
    if (!stderr_closed &&
        observation.stderr_capture.bytes == bytes_before) {
      break;
    }
  }
  drain_exec_error(exec_error_read.get(), observation.child_failure,
                   exec_error_bytes, exec_error_closed);
  if (exec_error_bytes != 0U && exec_error_bytes != sizeof(ChildFailure)) {
    observation.wait_failed = true;
  }
  observation.child_failure_reported =
      exec_error_bytes == sizeof(ChildFailure);
#if defined(__linux__)
  if (static_broker != nullptr) {
    observation.static_broker_failed = static_broker->service_failed;
    observation.static_broker_error = static_broker->service_error;
    observation.static_broker_violation = static_broker->violation;
    observation.static_broker_request_injected =
        static_broker->request_injected;
    observation.static_broker_result_injected =
        static_broker->result_injected;
    observation.static_broker_initial_exec_allowed =
        static_broker->initial_exec_allowed;
  }
#endif
  observation.elapsed = std::chrono::steady_clock::now() - start;
  return observation;
}

[[nodiscard]] Result<std::vector<std::byte>> read_result_file(
    const int directory_fd, const std::string_view name,
    const std::size_t cap) {
  const std::string stable_name(name);
  struct stat path_attributes {};
  if (::fstatat(directory_fd, stable_name.c_str(), &path_attributes,
                AT_SYMLINK_NOFOLLOW) != 0) {
    return Result<std::vector<std::byte>>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_missing_result",
        "the local builder did not publish its declared result file"));
  }
  if (!S_ISREG(path_attributes.st_mode) || path_attributes.st_nlink != 1) {
    return Result<std::vector<std::byte>>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_invalid_result_file",
        "the published result must be one nonsymlink regular file"));
  }
  if (path_attributes.st_size < 0 ||
      static_cast<std::uintmax_t>(path_attributes.st_size) > cap) {
    return Result<std::vector<std::byte>>::failure(error(
        DiagnosticCategory::resource_limit,
        "c16.local_builder_result_limit",
        "the published result exceeds the resolved result-byte cap"));
  }

  ScopedFd descriptor(::openat(directory_fd, stable_name.c_str(),
                               O_RDONLY | O_NOFOLLOW | O_NONBLOCK |
                                   O_CLOEXEC));
  if (descriptor.get() < 0) {
    return Result<std::vector<std::byte>>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_invalid_result_file",
        "the published result could not be opened safely"));
  }
  struct stat opened_attributes {};
  if (::fstat(descriptor.get(), &opened_attributes) != 0 ||
      !S_ISREG(opened_attributes.st_mode) || opened_attributes.st_nlink != 1 ||
      opened_attributes.st_dev != path_attributes.st_dev ||
      opened_attributes.st_ino != path_attributes.st_ino ||
      opened_attributes.st_nlink != path_attributes.st_nlink ||
      opened_attributes.st_size < 0 ||
      opened_attributes.st_size != path_attributes.st_size ||
      !same_modification_time(opened_attributes, path_attributes) ||
      !same_change_time(opened_attributes, path_attributes) ||
      static_cast<std::uintmax_t>(opened_attributes.st_size) > cap) {
    return Result<std::vector<std::byte>>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_invalid_result_file",
        "the published result changed while it was opened"));
  }

  std::vector<std::byte> result;
  result.reserve(static_cast<std::size_t>(opened_attributes.st_size));
  std::array<std::byte, 8192U> buffer{};
  for (;;) {
    const ssize_t count = ::read(descriptor.get(), buffer.data(),
                                 buffer.size());
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count < 0) {
      return Result<std::vector<std::byte>>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.local_builder_invalid_result_file",
          "the published result could not be read completely"));
    }
    if (count == 0) {
      break;
    }
    const std::size_t amount = static_cast<std::size_t>(count);
    if (amount > cap - std::min(cap, result.size())) {
      return Result<std::vector<std::byte>>::failure(error(
          DiagnosticCategory::resource_limit,
          "c16.local_builder_result_limit",
          "the published result exceeds the resolved result-byte cap"));
    }
    result.insert(result.end(), buffer.begin(),
                  buffer.begin() + static_cast<std::ptrdiff_t>(amount));
  }
  struct stat final_attributes {};
  if (::fstat(descriptor.get(), &final_attributes) != 0 ||
      final_attributes.st_dev != opened_attributes.st_dev ||
      final_attributes.st_ino != opened_attributes.st_ino ||
      final_attributes.st_nlink != opened_attributes.st_nlink ||
      final_attributes.st_size != opened_attributes.st_size ||
      !same_modification_time(final_attributes, opened_attributes) ||
      !same_change_time(final_attributes, opened_attributes) ||
      final_attributes.st_size < 0 ||
      static_cast<std::uintmax_t>(final_attributes.st_size) != result.size()) {
    return Result<std::vector<std::byte>>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.local_builder_unstable_result",
        "the published result was not stable while being captured"));
  }
  return Result<std::vector<std::byte>>::success(std::move(result));
}

[[nodiscard]] Result<void> validate_directory_contents(
    const int directory_fd, const std::string_view request_name,
    const std::string_view result_name) {
  std::size_t request_count = 0U;
  std::size_t result_count = 0U;
  const int scan_fd = ::openat(directory_fd, ".",
                               O_RDONLY | O_DIRECTORY | O_NOFOLLOW |
                                   O_CLOEXEC);
  if (scan_fd < 0) {
    return Result<void>::failure(error(
        DiagnosticCategory::internal,
        "c16.local_builder_workspace_inspection_failed",
        "the private execution directory could not be inspected"));
  }
  DIR* stream = ::fdopendir(scan_fd);
  if (stream == nullptr) {
    (void)::close(scan_fd);
    return Result<void>::failure(error(
        DiagnosticCategory::internal,
        "c16.local_builder_workspace_inspection_failed",
        "the private execution directory could not be inspected"));
  }
  bool unexpected = false;
  errno = 0;
  while (struct dirent* entry = ::readdir(stream)) {
    const std::string_view entry_name(entry->d_name);
    if (entry_name == "." || entry_name == "..") {
      errno = 0;
      continue;
    }
    if (entry_name == request_name) {
      ++request_count;
    } else if (entry_name == result_name) {
      ++result_count;
    } else {
      unexpected = true;
      break;
    }
    errno = 0;
  }
  const int iteration_error = errno;
  const bool close_failed = ::closedir(stream) != 0;
  if (iteration_error != 0 || close_failed) {
    return Result<void>::failure(error(
        DiagnosticCategory::internal,
        "c16.local_builder_workspace_inspection_failed",
        "the private execution directory could not be inspected"));
  }
  if (unexpected || request_count != 1U || result_count != 1U) {
    // An unexpected entry is itself additional output. Classify it before a
    // missing result so the diagnostic is independent of directory order
    // without scanning attacker-controlled entries after the first breach.
    const bool missing_result = !unexpected && result_count == 0U;
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        missing_result ? "c16.local_builder_missing_result"
                       : "c16.local_builder_duplicate_output",
        missing_result
            ? "the local builder did not publish one complete result"
            : "the local builder published duplicate result candidates"));
  }
  return Result<void>::success();
}

#endif  // defined(__unix__) || defined(__APPLE__)

}  // namespace

Result<void> validate_registered_executable_spec(
    const RegisteredExecutableSpec& spec) {
  if (!portable_identifier(spec.executable_id()) ||
      spec.argv_grammar_version() != 1U ||
      spec.wall_time_limit().count() <= 0 ||
      spec.wall_time_limit() > kNonScientificWallTimeCeiling ||
      (spec.maximum_wall_time_limit().has_value() &&
       (spec.maximum_wall_time_limit()->count() <= 0 ||
        *spec.maximum_wall_time_limit() < spec.wall_time_limit() ||
        *spec.maximum_wall_time_limit() >
            kNonScientificWallTimeCeiling)) ||
      (spec.maximum_worker_count().has_value() &&
       *spec.maximum_worker_count() == 0U) ||
      spec.maximum_stderr_bytes() == 0U ||
      (spec.maximum_request_bytes().has_value() &&
       (*spec.maximum_request_bytes() == 0U ||
        *spec.maximum_request_bytes() >
            kSurrogateBuildProtocolV1MaximumRequestBytes)) ||
      (spec.maximum_result_bytes().has_value() &&
       (*spec.maximum_result_bytes() == 0U ||
        *spec.maximum_result_bytes() >
            kSurrogateBuildProtocolV1MaximumResultBytes))) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation, "c16.invalid_executable_spec",
        "the registered executable identity, grammar, and explicit caps must satisfy protocol v1"));
  }
  for (const auto& argument : spec.fixed_arguments()) {
    if (contains_nul(argument) || is_reserved_argument(argument)) {
      return Result<void>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.invalid_executable_spec",
          "registered fixed arguments must be literal and may not replace reserved protocol tokens"));
    }
  }
  auto path_validation = validate_executable_path(spec.absolute_executable());
  if (!path_validation) {
    return path_validation;
  }
#if defined(__linux__)
  auto executable = open_registered_executable(spec.absolute_executable());
  if (!executable) {
    return Result<void>::failure(executable.error());
  }
  if (!is_native_static_elf(
          executable.value().inspection_descriptor.get())) {
    return Result<void>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.invalid_executable_spec",
        "a registered local builder must be a native static ELF with no interpreter"));
  }
#endif
  return Result<void>::success();
}

Result<DeterministicRng> BuildExecutionContext::make_construction_rng(
    const StageTag stage, const TypedLabel& target_or_group_identity,
    const BigNat& build_replication_or_probe_id) const {
  if (stage != StageTag::surrogate_build_input &&
      stage != StageTag::surrogate_build_context &&
      stage != StageTag::surrogate_build_probe &&
      stage != StageTag::surrogate_build_final) {
    return Result<DeterministicRng>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.invalid_construction_rng_stage",
        "construction RNG derivation accepts only the four surrogate-build stages"));
  }
  auto key = make_surrogate_build_instance_key(
      build_identity_, provider_identity_.provider_id,
      provider_identity_.provider_version, target_or_group_identity,
      build_replication_or_probe_id);
  if (!key) {
    return Result<DeterministicRng>::failure(key.error());
  }
  return Result<DeterministicRng>::success(derive_rng_stream(
      build_seed_.master_seed(), stage, key.value()));
}

Result<BuildExecutionContext> BuildExecutionContext::create(
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    std::filesystem::path workspace_execution_root,
    std::optional<BuilderArrivalServices> arrival_services,
    std::optional<ConstructionExactQueryServices> exact_query_services) {
  auto request_validation =
      artifact::detail::verify_request_bindings_v1(request, manifest);
  if (!request_validation) {
    return Result<BuildExecutionContext>::failure(
        request_validation.error());
  }
  const auto& manifest_value = manifest.value();
  if (manifest_value.transport_limits.maximum_request_bytes == 0U ||
      manifest_value.transport_limits.maximum_result_bytes == 0U ||
      manifest_value.transport_limits.maximum_request_bytes >
          kSurrogateBuildProtocolV1MaximumRequestBytes ||
      manifest_value.transport_limits.maximum_result_bytes >
          kSurrogateBuildProtocolV1MaximumResultBytes) {
    return Result<BuildExecutionContext>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.invalid_context_transport_limits",
        "the execution context requires validated protocol-v1 manifest transport caps"));
  }

  const bool in_process =
      request.classifications().producer_mode ==
      ProducerModeV1::in_process_builder;
  const auto arrival_requirement = required_arrival_service(request);
  if (arrival_requirement == ArrivalServiceRequirement::unsupported) {
    return Result<BuildExecutionContext>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.execution_context_arrival_service_unsupported",
        "the accepted process-local arrival prerequisite has no C16 provider service"));
  }
  const bool replay_required =
      in_process &&
      arrival_requirement == ArrivalServiceRequirement::adjacent_replay;
  if ((!in_process && arrival_services.has_value()) ||
      (replay_required != arrival_services.has_value())) {
    return Result<BuildExecutionContext>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.execution_context_arrival_service_shape",
        "arrival replay services must be present exactly for an accepted in-process replay prerequisite"));
  }
  std::optional<AdjacentReplayService> replay_service;
  if (arrival_services.has_value()) {
    // has_replay() is null-safe and is intentionally checked before the
    // reference-returning view_digest() accessor, so a moved-from C09 bundle
    // is rejected rather than dereferenced.
    if (!arrival_services->has_replay() ||
        !request_replay_contract_is_complete(
            request.framework_problem_view().configured_arrival())) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.execution_context_arrival_service_inactive",
          "the supplied C09 bundle has no live request-authorized adjacent replay service"));
    }
    if (arrival_services->view_digest() !=
        request.framework_problem_view().configured_arrival().digest()) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.execution_context_arrival_binding_mismatch",
          "the in-process arrival replay service does not match the exact build request"));
    }
    replay_service = arrival_services->replay_service();
    if (!replay_service.has_value()) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::internal,
          "c16.execution_context_arrival_service_inconsistent",
          "the validated C09 bundle did not yield its advertised replay service"));
    }
  }

  const auto& prerequisites =
      request.accepted_capability_contract().construction_prerequisites;
  const bool exact_required =
      in_process && prerequisites.required_optimizer_calls.has_value();
  if (exact_required != exact_query_services.has_value()) {
    return Result<BuildExecutionContext>::failure(error(
        DiagnosticCategory::input_validation,
        "c16.execution_context_exact_service_shape",
        "exact-query services must be present exactly for an accepted in-process optimizer-call prerequisite"));
  }
  if (exact_query_services.has_value()) {
    using ExactAccess = detail::ConstructionExactQueryBindingAccess;
    if (!ExactAccess::is_live(*exact_query_services)) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.execution_context_exact_service_inactive",
          "the exact-query service or its borrowed optimizer context is inactive"));
    }
    const ResolvedInstance* bound_instance =
        ExactAccess::bound_instance(*exact_query_services);
    if (bound_instance == nullptr ||
        exact_query_services->scope_token().build_identity() !=
            request.build_identity_digest() ||
        !exact_service_instance_matches_request(
            *bound_instance, request.framework_problem_view())) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.execution_context_exact_service_binding_mismatch",
          "the exact-query service token and resolved instance do not match the exact build request"));
    }
    const auto& grant = request.construction_budget().exact_optimizer_calls;
    if (grant.applicability != BudgetApplicabilityV1::applicable ||
        !grant.amount.has_value() ||
        ExactAccess::construction_subgrant(*exact_query_services) !=
            grant.amount) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.execution_context_exact_service_grant_mismatch",
          "the exact-query construction subgrant does not equal the request's optimizer-call grant"));
    }
    auto consumed = ExactAccess::calls_consumed(*exact_query_services);
    if (!consumed || !consumed.value().is_zero()) {
      return Result<BuildExecutionContext>::failure(error(
          DiagnosticCategory::input_validation,
          "c16.execution_context_exact_service_not_cold",
          "the exact-query service must have consumed zero calls when the execution context is created"));
    }
  }
  auto validated_root = validate_execution_root(workspace_execution_root);
  if (!validated_root) {
    return Result<BuildExecutionContext>::failure(validated_root.error());
  }
  auto root = std::move(validated_root).value();
  return Result<BuildExecutionContext>::success(BuildExecutionContext(
      manifest_value.provider, manifest_value.manifest_digest,
      request.request_digest(), request.build_identity_digest(),
      request.build_seed(),
      manifest_value.transport_limits, manifest_value.local_executable,
      std::move(root.path), root.device, root.inode, std::move(replay_service),
      std::move(exact_query_services)));
}

ProviderExecutionOutcome run_local_surrogate_builder(
    const RegisteredExecutableSpec& spec,
    const SurrogateBuildRequest& request,
    BuildExecutionContext& context,
    const ProviderExecutionControlsV1& controls) {
  try {
    auto spec_validation = validate_registered_executable_spec(spec);
    if (!spec_validation) {
      return failed(spec_validation.error());
    }
    if (!detail::is_registered_executable_spec_for_request(spec, request)) {
      return failed(error(
          DiagnosticCategory::input_validation,
          "c16.unregistered_executable_spec",
          "the executable spec is not the registered route for this request"));
    }
    auto resolved_controls =
        resolve_provider_execution_controls(spec, controls);
    if (!resolved_controls) {
      return failed(resolved_controls.error());
    }
    const std::chrono::milliseconds wall_time_limit =
        resolved_controls.value().wall_time_limit;
    const bool request_matches_context =
        request.provider_binding().provider == context.provider_identity_ &&
        request.request_digest() == context.request_digest_ &&
        request.build_identity_digest() == context.build_identity_ &&
        spec.provider_identity() == context.provider_identity_ &&
        spec.manifest_digest() == context.manifest_digest_;
    if (!request_matches_context || !context.local_executable_.has_value() ||
        request.classifications().producer_mode !=
            ProducerModeV1::local_executable_builder ||
        context.local_executable_->executable_id != spec.executable_id() ||
        context.local_executable_->argv_grammar_version !=
            spec.argv_grammar_version() ||
        context.local_executable_->fixed_argument_template !=
            std::vector<std::string>{"--request", "{request_path}",
                                     "--result", "{result_path}"}) {
      return failed(error(
          DiagnosticCategory::input_validation,
          "c16.local_builder_binding_mismatch",
          "the registered local executable, manifest, context, and request do not share one exact binding"));
    }
    if (!context.begin_local_execution()) {
      return failed(error(
          DiagnosticCategory::input_validation,
          "c16.local_builder_repeated_execution",
          "one build execution context permits at most one local launch"));
    }
    context.local_transport_accounting_ = LocalBuilderTransportAccountingV1{};

    const std::size_t request_cap = resolved_cap(
        kSurrogateBuildProtocolV1MaximumRequestBytes,
        context.manifest_transport_limits_.maximum_request_bytes,
        spec.maximum_request_bytes());
    const std::size_t result_cap = resolved_cap(
        kSurrogateBuildProtocolV1MaximumResultBytes,
        context.manifest_transport_limits_.maximum_result_bytes,
        spec.maximum_result_bytes());
    auto request_bytes = canonical_surrogate_build_request_bytes_v1(request);
    if (!request_bytes) {
      return failed(request_bytes.error());
    }
    context.local_transport_accounting_.request_bytes =
        request_bytes.value().size();
    if (request_bytes.value().size() > request_cap) {
      return failed(error(
          DiagnosticCategory::resource_limit,
          "c16.local_builder_request_limit",
          "the canonical build request exceeds the resolved request-byte cap"));
    }

#if !defined(__linux__)
  return failed(error(
      DiagnosticCategory::unavailable,
      "c16.local_builder_platform_unsupported",
      "this platform has no implemented filesystem, process, and network-contained direct runner"));
#else
  auto revalidated_root =
      validate_execution_root(context.workspace_execution_root_);
  if (!revalidated_root ||
      revalidated_root.value().path != context.workspace_execution_root_ ||
      revalidated_root.value().device !=
          context.workspace_execution_root_device_ ||
      revalidated_root.value().inode !=
          context.workspace_execution_root_inode_) {
    return failed(revalidated_root
                      ? error(DiagnosticCategory::input_validation,
                              "c16.invalid_execution_root",
                              "the execution root changed after context creation")
                      : revalidated_root.error());
  }
  auto executable = open_registered_executable(spec.absolute_executable());
  if (!executable) {
    return failed(executable.error());
  }
  const auto backend = select_linux_backend(
      executable.value().inspection_descriptor.get());
  if (!backend.has_value()) {
    return failed(error(
        DiagnosticCategory::unavailable,
        "c16.local_builder_sandbox_unavailable",
        "Landlock v3 is unavailable and the registered executable is not a native static ELF eligible for the seccomp broker"));
  }
  auto run_directory_result =
      make_run_directory(revalidated_root.value());
  if (!run_directory_result) {
    return failed(run_directory_result.error());
  }
  ScopedRunDirectory run_directory(std::move(run_directory_result).value());
  auto request_identity = write_request_file(run_directory.descriptor(),
                                             kRequestFileName,
                                             request_bytes.value());
  if (!request_identity) {
    return fail_after_cleanup(run_directory, request_identity.error());
  }

  auto stdout_pipe_result = make_pipe(true);
  auto stderr_pipe_result = make_pipe(true);
  auto exec_error_pipe_result = make_pipe(true);
  auto handshake_pipe_result = make_pipe(true);
  if (!stdout_pipe_result || !stderr_pipe_result ||
      !exec_error_pipe_result || !handshake_pipe_result) {
    return fail_after_cleanup(
        run_directory,
        !stdout_pipe_result
            ? stdout_pipe_result.error()
            : (!stderr_pipe_result ? stderr_pipe_result.error()
               : (!exec_error_pipe_result ? exec_error_pipe_result.error()
                                          : handshake_pipe_result.error())));
  }
  Pipe stdout_pipe = std::move(stdout_pipe_result.value());
  Pipe stderr_pipe = std::move(stderr_pipe_result.value());
  Pipe exec_error_pipe = std::move(exec_error_pipe_result.value());
  Pipe handshake_pipe = std::move(handshake_pipe_result.value());
  ScopedFd null_input(::open("/dev/null", O_RDONLY | O_CLOEXEC));
  if (null_input.get() < 0) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::internal,
              "c16.local_builder_launch_failed",
              "the framework could not create a closed child input channel"));
  }
  ScopedFd static_request_source;
  ScopedFd static_listener_slot;
  if (backend == LinuxSandboxBackend::static_seccomp_broker) {
    auto request_source = open_static_broker_request(
        run_directory.descriptor(), request_identity.value());
    if (!request_source) {
      return fail_after_cleanup(run_directory, request_source.error());
    }
    static_request_source = std::move(request_source).value();
  }
  static_listener_slot.reset(
      ::fcntl(null_input.get(), F_DUPFD_CLOEXEC, 64));
  if (static_listener_slot.get() < 64 ||
        static_listener_slot.get() == run_directory.descriptor() ||
        static_listener_slot.get() == executable.value().descriptor.get() ||
        static_listener_slot.get() ==
            executable.value().inspection_descriptor.get() ||
        static_listener_slot.get() == null_input.get() ||
        static_listener_slot.get() == stdout_pipe.write_end.get() ||
        static_listener_slot.get() == stderr_pipe.write_end.get() ||
        static_listener_slot.get() == exec_error_pipe.write_end.get() ||
      static_listener_slot.get() == handshake_pipe.write_end.get()) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::internal,
              "c16.local_builder_broker_failed",
              "the framework could not reserve the broker listener descriptor"));
  }

  std::vector<std::string> argument_storage;
  argument_storage.reserve(7U + spec.fixed_arguments().size());
  argument_storage.push_back(spec.absolute_executable().string());
  argument_storage.emplace_back(kRequestArgument);
  argument_storage.emplace_back(kRequestFileName);
  argument_storage.emplace_back(kResultArgument);
  argument_storage.emplace_back(kResultFileName);
  argument_storage.insert(argument_storage.end(),
                          spec.fixed_arguments().begin(),
                          spec.fixed_arguments().end());
  if (resolved_controls.value().worker_count.has_value()) {
    argument_storage.emplace_back("--workers");
    argument_storage.push_back(
        std::to_string(*resolved_controls.value().worker_count));
  }
  std::vector<char*> arguments;
  arguments.reserve(argument_storage.size() + 1U);
  for (auto& argument : argument_storage) {
    arguments.push_back(argument.data());
  }
  arguments.push_back(nullptr);

  if (!opened_executable_is_stable(executable.value(),
                                   spec.absolute_executable()) ||
      !is_native_static_elf(
          executable.value().inspection_descriptor.get())) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::input_validation,
              "c16.executable_identity_changed",
              "the registered executable changed after sandbox eligibility was established"));
  }
  if (!run_directory.named_entry_is_stable()) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::input_validation,
              "c16.local_builder_workspace_replaced",
              "the private execution directory changed before launch"));
  }
  const auto start = std::chrono::steady_clock::now();
  const int run_directory_descriptor = run_directory.descriptor();
  const int executable_descriptor = executable.value().descriptor.get();
  std::vector<std::byte> clone_stack;
  StaticBuilderChildArguments static_child_arguments;
  constexpr std::size_t kCloneStackBytes = 1024U * 1024U;
  clone_stack.resize(kCloneStackBytes);
  static_child_arguments = StaticBuilderChildArguments{
      *backend,
      run_directory_descriptor,
      executable_descriptor,
      null_input.get(),
      stdout_pipe.write_end.get(),
      stderr_pipe.write_end.get(),
      exec_error_pipe.write_end.get(),
      handshake_pipe.write_end.get(),
      static_listener_slot.get(),
      result_cap,
      arguments.data()};
  context.local_transport_accounting_.launch_attempted = true;
  const pid_t child = ::clone(static_builder_child_main,
                              clone_stack.data() + clone_stack.size(),
                              CLONE_FILES | SIGCHLD,
                              &static_child_arguments);
  if (child < 0) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::internal,
              "c16.local_builder_launch_failed",
              "the registered executable process could not be created"));
  }
  ScopedChildProcess child_guard(child);

  context.local_transport_accounting_.process_started = true;
  (void)::setpgid(child, child);
  std::optional<StaticPathBroker> static_broker;
  const auto handshake = await_static_broker_handshake(
      child, handshake_pipe.read_end.get(), wall_time_limit, start);
    if (handshake.child_reaped) {
      child_guard.release();
    }
    if (handshake.timed_out) {
      child_guard.terminate_and_reap_now();
      return fail_after_cleanup(
          run_directory,
          error(DiagnosticCategory::resource_limit,
                "c16.local_builder_timeout",
                "the local builder exceeded its wall-time cap during sandbox handoff"));
    }
    if (!handshake.received ||
        handshake.handshake.magic != kStaticBrokerHandshakeMagic ||
        handshake.handshake.error_number != 0 ||
        !handshake.handshake.descriptor_table_unshared ||
        handshake.child_reaped) {
      Diagnostic diagnostic = error(
          DiagnosticCategory::unavailable,
          "c16.local_builder_sandbox_unavailable",
          "the static seccomp broker could not complete its descriptor-safe handoff");
      if (handshake.received) {
        diagnostic.notes.push_back(
            "child_errno=" +
            std::to_string(handshake.handshake.error_number));
      }
      child_guard.terminate_and_reap_now();
      return fail_after_cleanup(run_directory, std::move(diagnostic));
    }
    struct seccomp_notif_sizes notification_sizes {};
    if (::syscall(SYS_seccomp, SECCOMP_GET_NOTIF_SIZES, 0,
                  &notification_sizes) != 0 ||
        notification_sizes.seccomp_notif > sizeof(struct seccomp_notif) ||
        notification_sizes.seccomp_notif_resp >
            sizeof(struct seccomp_notif_resp) ||
        !set_descriptor_flag(static_listener_slot.get(), F_GETFD,
                             FD_CLOEXEC) ||
        !set_descriptor_flag(static_listener_slot.get(), F_GETFL,
                             O_NONBLOCK)) {
      child_guard.terminate_and_reap_now();
      return fail_after_cleanup(
          run_directory,
          error(DiagnosticCategory::unavailable,
                "c16.local_builder_sandbox_unavailable",
                "the kernel seccomp notification ABI is not safely supported"));
    }
  static_broker.emplace(StaticPathBroker{
      child, run_directory.descriptor(), executable_descriptor,
      backend == LinuxSandboxBackend::static_seccomp_broker,
      StaticPathAttestation::undecided,
      ScopedFd(static_listener_slot.release()),
      std::move(static_request_source), ScopedFd{}, false, false, false,
      false, 0, StaticBrokerViolation::none});
  handshake_pipe.read_end.reset();
  handshake_pipe.write_end.reset();
  stdout_pipe.write_end.reset();
  stderr_pipe.write_end.reset();
  exec_error_pipe.write_end.reset();
  null_input.reset();
  auto observation = observe_process(
      child, std::move(stdout_pipe.read_end),
      std::move(stderr_pipe.read_end),
      std::move(exec_error_pipe.read_end), wall_time_limit,
      spec.maximum_stderr_bytes(), start,
      static_broker ? &*static_broker : nullptr);
  if (observation.child_reaped) {
    child_guard.release();
  }
  context.local_transport_accounting_.stderr_bytes =
      observation.stderr_capture.bytes;
  context.local_transport_accounting_.stdout_was_nonempty =
      observation.stdout_nonempty;
  context.local_transport_accounting_.elapsed_wall_time = observation.elapsed;

  if (observation.wait_failed) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::internal,
              "c16.local_builder_wait_failed",
              "the framework could not deterministically monitor and reap the local builder"),
        observation.stderr_capture);
  }
  if (observation.timed_out) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::resource_limit,
              "c16.local_builder_timeout",
              "the local builder exceeded its registered monotonic wall-time cap"),
        observation.stderr_capture);
  }
  if (observation.stderr_capture.limit_exceeded) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::resource_limit,
              "c16.local_builder_stderr_limit",
              "the local builder exceeded its registered stderr-byte cap"),
        observation.stderr_capture);
  }
  if (observation.stdout_nonempty) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::input_validation,
              "c16.local_builder_stdout_forbidden",
              "the local builder wrote to stdout, which is not a protocol channel"),
        observation.stderr_capture);
  }
  if (observation.static_broker_failed) {
    Diagnostic diagnostic = error(
        DiagnosticCategory::unavailable,
        "c16.local_builder_broker_failed",
        "the static seccomp broker could not mediate the protocol descriptors");
    diagnostic.notes.push_back(
        "broker_errno=" +
        std::to_string(observation.static_broker_error));
    return fail_after_cleanup(run_directory, std::move(diagnostic),
                              observation.stderr_capture);
  }
  if (observation.static_broker_violation !=
      StaticBrokerViolation::none) {
    const bool duplicate =
        observation.static_broker_violation ==
        StaticBrokerViolation::duplicate_result_open;
    const bool request_mutation =
        observation.static_broker_violation ==
        StaticBrokerViolation::request_mutation;
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::input_validation,
              duplicate
                  ? "c16.local_builder_duplicate_output"
                  : (request_mutation
                         ? "c16.local_builder_request_mutated"
                         : "c16.local_builder_forbidden_filesystem_access"),
              duplicate
                  ? "the local builder attempted to open more than one result channel"
                  : (request_mutation
                         ? "the local builder attempted to modify the immutable request channel"
                         : "the local builder attempted a path operation outside the one request and one result descriptor protocol")),
        observation.stderr_capture);
  }
  if (observation.child_failure_reported) {
    const bool sandbox_failure =
        observation.child_failure.stage == ChildFailureStage::sandbox;
    Diagnostic launch_failure = error(
        DiagnosticCategory::unavailable,
        sandbox_failure ? "c16.local_builder_sandbox_unavailable"
                        : "c16.local_builder_exec_failed",
        sandbox_failure
            ? "the required local-builder containment policy could not be installed"
            : "the identity-bound registered executable could not be invoked directly");
    launch_failure.notes.push_back(
        "child_errno=" +
        std::to_string(observation.child_failure.error_number));
    return fail_after_cleanup(
        run_directory, std::move(launch_failure),
        observation.stderr_capture);
  }
  if (WIFSIGNALED(observation.wait_status) &&
      WTERMSIG(observation.wait_status) == SIGXFSZ) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::resource_limit,
              "c16.local_builder_result_limit",
              "the local builder exceeded the resolved result-byte cap while publishing output"),
        observation.stderr_capture);
  }
  if (WIFSIGNALED(observation.wait_status)) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::unavailable,
              "c16.local_builder_signaled",
              "the local builder terminated by signal before completion"),
        observation.stderr_capture);
  }
  if (!WIFEXITED(observation.wait_status) ||
      WEXITSTATUS(observation.wait_status) != 0) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::unavailable,
              "c16.local_builder_nonzero_exit",
              "the local builder exited unsuccessfully before completion"),
        observation.stderr_capture);
  }
  if (static_broker && static_broker->broker_paths &&
      (!observation.static_broker_request_injected ||
       !observation.static_broker_result_injected)) {
    return fail_after_cleanup(
        run_directory,
        error(DiagnosticCategory::input_validation,
              observation.static_broker_request_injected
                  ? "c16.local_builder_missing_result"
                  : "c16.local_builder_forbidden_filesystem_access",
              observation.static_broker_request_injected
                  ? "the local builder did not open its single transactional result channel"
                  : "the local builder did not consume the immutable request before producing a result"),
        observation.stderr_capture);
  }

  auto directory_validation = validate_directory_contents(
      run_directory.descriptor(), kRequestFileName, kResultFileName);
  if (!directory_validation) {
    return fail_after_cleanup(run_directory, directory_validation.error(),
                              observation.stderr_capture);
  }
  auto immutable_request = verify_request_file(
      run_directory.descriptor(), kRequestFileName, request_identity.value(),
      request_bytes.value());
  if (!immutable_request) {
    return fail_after_cleanup(run_directory, immutable_request.error(),
                              observation.stderr_capture);
  }
  auto result_bytes = read_result_file(run_directory.descriptor(),
                                       kResultFileName, result_cap);
  if (!result_bytes) {
    return fail_after_cleanup(run_directory, result_bytes.error(),
                              observation.stderr_capture);
  }
  context.local_transport_accounting_.result_bytes =
      result_bytes.value().size();
  auto completed_bytes = std::move(result_bytes.value());
  if (!run_directory.clean()) {
    return failed_with_stderr(
        error(DiagnosticCategory::internal,
              "c16.local_builder_cleanup_failed",
              "the private execution directory could not be removed deterministically"),
        observation.stderr_capture);
  }
  return CompletedProviderExecution{std::move(completed_bytes)};
#endif
  } catch (const std::bad_alloc&) {
    return failed(error(
        DiagnosticCategory::resource_limit,
        "c16.local_builder_allocation_failure",
        "the bounded local-builder transport exhausted memory"));
  } catch (const std::exception&) {
    return failed(error(
        DiagnosticCategory::internal, "c16.local_builder_exception",
        "the local-builder transport raised a framework exception"));
  } catch (...) {
    return failed(error(
        DiagnosticCategory::internal, "c16.local_builder_unknown_exception",
        "the local-builder transport raised an unknown framework exception"));
  }
}

}  // namespace mwperf
