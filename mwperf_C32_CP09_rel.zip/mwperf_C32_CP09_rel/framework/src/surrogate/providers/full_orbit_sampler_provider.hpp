#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/provider.hpp"

namespace mwperf::detail {

// Internal C27.1 production-provider factory.  The registration remains
// inert until production_surrogate_registry() seals it.
[[nodiscard]] Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_provider_registration();

// Exposed only through this noninstalled header so contract tests can inspect
// the exact frozen manifest without acquiring a production registry seal.
[[nodiscard]] Result<SurrogateProviderManifestV1>
full_orbit_sampler_provider_manifest();

// The CP07.1 K-wide provider is the default C29 scientific contract under the
// same provider ID and executable identity.
[[nodiscard]] Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_k_wide_provider_registration();
[[nodiscard]] Result<SurrogateProviderManifestV1>
full_orbit_sampler_k_wide_provider_manifest();

// C30's observation-capable sibling is intentionally a new provider revision
// and parameter schema.  The released 1.2.0/schema-v2 route above remains the
// default when a configuration omits an exact provider version.
[[nodiscard]] Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_observation_provider_registration();
[[nodiscard]] Result<SurrogateProviderManifestV1>
full_orbit_sampler_observation_provider_manifest();

// C32/CP09 is an additive observation-only scientific route.  It keeps the
// released 1.2.0 and 1.3.0 provider identities byte-for-byte frozen while
// removing the construction-time response cutoff from weighted-ensemble
// sampling.  Projection cutoffs are authenticated provider parameters and
// are consumed only after the sparse observation has been collected.
[[nodiscard]] Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_cp09_provider_registration();
[[nodiscard]] Result<SurrogateProviderManifestV1>
full_orbit_sampler_cp09_provider_manifest();

// The hosted dispatch declaration remains separately inspectable from the
// registered scientific contract. Both retain protocol version 1 and the
// existing executable identity.
struct FullOrbitKWideHostedRouteV1 final {
  ProviderIdentityV1 provider;
  std::uint32_t parameter_schema_version;
  Digest256 parameter_schema_digest;
  // This authenticates the hosted dispatch declaration. It is deliberately
  // not a registered C15 scientific-contract projection.
  Digest256 hosted_route_binding_digest;
  std::string proposed_payload_tag;
  std::uint32_t proposed_payload_version;
  std::string native_result_tag;
  std::string executable_id;
  std::uint32_t request_protocol_version;
  std::uint32_t result_protocol_version;
  bool production_registration_deferred;

  friend bool operator==(const FullOrbitKWideHostedRouteV1&,
                         const FullOrbitKWideHostedRouteV1&) = default;
};

// The result protocol is a process-local dispatch fact rather than a field in
// SurrogateProviderManifestV1.  This independently sealed declaration is the
// cross-language binding for provider 1.3.0/schema-v3/result-v2.
struct FullOrbitObservationHostedRouteV2 final {
  ProviderIdentityV1 provider;
  std::uint32_t parameter_schema_version;
  Digest256 parameter_schema_digest;
  Digest256 hosted_route_binding_digest;
  std::string proposed_payload_tag;
  std::uint32_t proposed_payload_version;
  std::string native_result_tag;
  std::string executable_id;
  std::uint32_t request_protocol_version;
  std::uint32_t result_protocol_version;
  std::size_t maximum_observation_bytes;
  bool production_registration_deferred;

  friend bool operator==(const FullOrbitObservationHostedRouteV2&,
                         const FullOrbitObservationHostedRouteV2&) = default;
};

struct FullOrbitCp09HostedRouteV3 final {
  ProviderIdentityV1 provider;
  std::uint32_t parameter_schema_version;
  Digest256 parameter_schema_digest;
  Digest256 hosted_route_binding_digest;
  std::string empirical_profile_tag;
  std::uint32_t empirical_profile_version;
  std::string native_result_tag;
  std::string executable_id;
  std::uint32_t request_protocol_version;
  std::uint32_t result_protocol_version;
  std::size_t maximum_observation_bytes;
  bool production_registration_deferred;

  friend bool operator==(const FullOrbitCp09HostedRouteV3&,
                         const FullOrbitCp09HostedRouteV3&) = default;
};

// Narrow process-local projection view.  Diagnostics consume these values
// without learning the provider-private parser carrier or reparsing canonical
// JSON.  None of these values is permitted to seed sampler trajectories.
struct FullOrbitCp09AnalysisParametersV1 final {
  std::vector<BigNat> projection_cutoffs;
  BigNat warmup_slots;
  BigNat horizon_slots;
  BigNat replications;
  BigNat population_size;
  bool gap_telemetry_requested;

  friend bool operator==(const FullOrbitCp09AnalysisParametersV1&,
                         const FullOrbitCp09AnalysisParametersV1&) = default;
};

// Exact, provider-authenticated analytic law used by the finite-window
// Poisson innovation evaluator.  It is projected from the compiled portable
// recipe in authored mixture-state order; no tail table or truncation is
// introduced.  The operational bits and both digests bind the once-rounded
// sampler rates and its registered overshoot algorithm.
struct FullOrbitCp09PoissonComponentV1 final {
  ExactRational weight;
  ExactRational component_rate;
  std::uint64_t operational_rate_bits;

  friend bool operator==(const FullOrbitCp09PoissonComponentV1&,
                         const FullOrbitCp09PoissonComponentV1&) = default;
};

struct FullOrbitCp09PoissonTargetLawV1 final {
  std::string descriptor_id;
  std::uint32_t descriptor_version;
  std::vector<FullOrbitCp09PoissonComponentV1> components;
  Digest256 operational_parameter_digest;
  Digest256 descriptor_digest;

  friend bool operator==(const FullOrbitCp09PoissonTargetLawV1&,
                         const FullOrbitCp09PoissonTargetLawV1&) = default;
};

// This remains the narrow provider-owned preview used by the direct hosted
// route to bind K and admit the exact CP07.1 work budget.  The registered
// descriptor preview and dynamic-response materializer are separate seams
// below and add the complete C14/C16 framework contract.
struct FullOrbitKWideHostedPreviewV1 final {
  ProviderIdentityV1 provider;
  BigNat response_cutoff;
  BigNat maximum_exact_optimizer_calls;
  ConstructionPrerequisitesV1 construction_prerequisites;

  friend bool operator==(const FullOrbitKWideHostedPreviewV1&,
                         const FullOrbitKWideHostedPreviewV1&) = default;
};

[[nodiscard]] bool is_full_orbit_k_wide_provider(
    const ProviderIdentityV1& provider) noexcept;

[[nodiscard]] Result<FullOrbitKWideHostedRouteV1>
full_orbit_sampler_k_wide_hosted_route();

[[nodiscard]] bool is_full_orbit_observation_provider(
    const ProviderIdentityV1& provider) noexcept;

[[nodiscard]] Result<FullOrbitObservationHostedRouteV2>
full_orbit_sampler_observation_hosted_route();

[[nodiscard]] bool is_full_orbit_cp09_provider(
    const ProviderIdentityV1& provider) noexcept;

[[nodiscard]] Result<FullOrbitCp09HostedRouteV3>
full_orbit_sampler_cp09_hosted_route();

[[nodiscard]] Result<ValidatedParameterPayloadV1>
validate_full_orbit_k_wide_parameters(const SourceNode& source);

[[nodiscard]] Result<ValidatedParameterPayloadV1>
validate_full_orbit_observation_parameters(const SourceNode& source);

[[nodiscard]] Result<ValidatedParameterPayloadV1>
validate_full_orbit_cp09_parameters(const SourceNode& source);

[[nodiscard]] Result<FullOrbitCp09AnalysisParametersV1>
full_orbit_cp09_analysis_parameters(
    const ValidatedSurrogateParameters& parameters);

[[nodiscard]] Result<std::optional<FullOrbitCp09PoissonTargetLawV1>>
full_orbit_cp09_poisson_target_law(
    const CompiledArrivalLaw& compiled_arrival_law,
    DenseQueueIndex target);

// The resolved constant-response tail is authoritative.  The provider-local
// response_cutoff is only an equality-checked transport copy.
[[nodiscard]] Result<void> validate_full_orbit_k_wide_resolution_binding(
    const TailResolution& resolved_tail,
    const ValidatedParameterPayloadV1& parameters);

// Same invariant at the immutable ExecutionPlan boundary.  This overload is
// a no-op for every provider other than the explicit 1.2.0 K-wide route.
[[nodiscard]] Result<void> validate_full_orbit_k_wide_resolution_binding(
    const ProviderIdentityV1& provider,
    const ValidatedSurrogateParameters& parameters,
    const TailResolution& resolved_tail);

[[nodiscard]] Result<void> validate_full_orbit_observation_resolution_binding(
    const ProviderIdentityV1& provider,
    const ValidatedSurrogateParameters& parameters,
    const TailResolution& resolved_tail);

[[nodiscard]] Result<FullOrbitKWideHostedPreviewV1>
preview_full_orbit_k_wide_hosted_route(
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const TailResolution& resolved_tail,
    const ValidatedParameterPayloadV1& parameters);

[[nodiscard]] Result<PlugDescriptorPreview>
preview_full_orbit_k_wide_registered_route(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters);

[[nodiscard]] Result<PlugDescriptorPreview>
preview_full_orbit_observation_registered_route(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters);

[[nodiscard]] Result<PlugDescriptorPreview>
preview_full_orbit_cp09_registered_route(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters);

// Provider-private validation is invoked only after the generic observation
// codec has authenticated and semantically validated the sidecar.  It binds
// the route's emit flag, block plan, caps and exact target-arrival projection
// without participating in capability resolution or plug materialization.
[[nodiscard]] Result<void> validate_full_orbit_observation_envelope(
    const ObservationEnvelopeValidationContextV1& context,
    const ValidatedConstructionObservationBundleV1* observation);

[[nodiscard]] Result<void> validate_full_orbit_cp09_observation_envelope(
    const ObservationEnvelopeValidationContextV1& context,
    const ValidatedConstructionObservationBundleV1* observation);

// Keep the configured-law identity and the callback-free builder-view
// identity in their distinct digest domains.  The compact factorized-IID
// projection reseals only the latter while preserving the complete runtime
// ArrivalBinding.  This narrow seam is shared by the production observation
// hook and its focused contract regression.
[[nodiscard]] Result<void>
validate_full_orbit_observation_arrival_context(
    const FrameworkProblemView& problem,
    const ResolvedInstance& resolved_instance,
    const CompiledArrivalLaw& compiled_arrival_law);

// Noninstalled pure policy seam used by the production hook and focused
// contract tests. Built is a complete scientific terminal state; Unavailable
// and provider-authored Failed may retain a validated shorter replication
// prefix without fabricating completion.
[[nodiscard]] Result<void>
validate_full_orbit_observation_terminal_replication_policy(
    ProviderResultKindV2 declared_kind,
    const BigNat& requested_replications,
    std::size_t realized_replications,
    bool all_realized_replications_complete);

// Narrow shared helpers preserve the frozen Full Orbit metric clauses and
// scalar descriptor construction while allowing the K-wide provider to bind
// its sibling payload class and authored K+1 tail boundary.
[[nodiscard]] Result<MetricSupportManifest>
full_orbit_k_wide_metric_manifest_v1();
[[nodiscard]] Result<MetricSupportManifest>
specialize_full_orbit_metric_manifest_v1(
    const MetricSupportManifest& prototype, const QueueId& target);
[[nodiscard]] Result<PlugDescriptorCore>
make_full_orbit_scalar_descriptor_v1(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem,
    const MetricSupportManifest& concrete_metric_manifest,
    BigNat constant_tail_from);

}  // namespace mwperf::detail
