#include "surrogate/providers/full_orbit_sampler_provider.hpp"

#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/renewal.hpp"
#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "mwperf/diagnostics/observation_record.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf::detail {
namespace {

constexpr std::string_view kProviderId = "full_orbit_framework_sampler";
constexpr std::string_view kProviderVersion = "1.2.0";
constexpr std::string_view kObservationProviderVersion = "1.3.0";
constexpr std::string_view kCp09ProviderVersion = "1.4.0";
constexpr std::uint32_t kParameterSchemaVersion = 2U;
constexpr std::uint32_t kObservationParameterSchemaVersion = 3U;
constexpr std::uint32_t kCp09ParameterSchemaVersion = 4U;
constexpr std::string_view kExecutableId = "fofs.cp06.c27.local";
constexpr std::string_view kPayloadTag =
    "finite_prefix_constant_tail_response_v1";
constexpr std::string_view kNativeResultTag =
    "full_orbit_cp07_1_finite_prefix_transport_v1";
constexpr std::string_view kObservationNativeResultTag =
    "full_orbit_cp07_1_finite_prefix_transport_v2";
constexpr std::string_view kCp09NativeResultTag =
    "full_orbit_cp09_observation_transport_v3";
constexpr std::string_view kCp09EmpiricalProfileTag =
    "empirical_finite_window_response_v1";
constexpr std::string_view kObservationComponentName =
    "construction_observation_bundle_v1";

constexpr std::string_view kParameterSchema =
    R"({"schema_version":2,"required_members":["schema_version","warmup_slots","horizon_slots","replications","population_size","familywise_alpha","response_cutoff"],"warmup_horizon_relation":"0<=W<T","replications_relation":"R>0","population_size_relation":"P>0","response_cutoff_domain":"2<=K<=5","response_cutoff_authority":"resolved_constant_response_tail","familywise_alpha":"canonical_reduced_rational_strictly_between_zero_and_one"})";
constexpr std::string_view kParameterSchemaDigest =
    "6f013e3ce85414bddb975ba208b250a79803e780fbab913c7d6091e6640c0fc3";
constexpr std::string_view kHostedRouteBinding =
    R"({"projection_version":1,"provider_id":"full_orbit_framework_sampler","provider_version":"1.2.0","parameter_schema_version":2,"parameter_schema_digest":"6f013e3ce85414bddb975ba208b250a79803e780fbab913c7d6091e6640c0fc3","construction_method":"sampled_offline","producer_mode":"local_executable_builder","deployed_semantic_tag":"scalar_backlog_response","runtime_access_tag":"finite_parameter_analytic_family","proposed_payload_tag":"finite_prefix_constant_tail_response_v1","proposed_payload_version":1,"native_result_tag":"full_orbit_cp07_1_finite_prefix_transport_v1","supported_build_request_versions":[1],"required_build_report_schema_versions":[1],"executable_id":"fofs.cp06.c27.local","request_protocol_version":1,"result_protocol_version":1,"registration_status":"registered_dynamic_payload_step_2"})";
constexpr std::string_view kHostedRouteBindingDigest =
    "c01842f5aeb40a5513783d157e11c111e4d5e72a68651191f7fe79a54383df66";

constexpr std::string_view kObservationParameterSchema =
    R"({"schema_version":3,"required_members":["schema_version","warmup_slots","horizon_slots","replications","population_size","familywise_alpha","response_cutoff","emit_observation_record","reporting_block_boundaries","gap_telemetry","maximum_observation_rows_per_replication","maximum_observation_bytes"],"warmup_horizon_relation":"0<=W<T","replications_relation":"R>0","population_size_relation":"P>0","response_cutoff_domain":"2<=K<=5","response_cutoff_authority":"resolved_constant_response_tail","familywise_alpha":"canonical_reduced_rational_strictly_between_zero_and_one","emit_observation_record":"boolean","reporting_block_boundaries":"strictly_increasing_absolute_boundaries_starting_at_W_and_ending_at_T","gap_telemetry":["disabled","auto","required"],"maximum_observation_rows_per_replication":"positive_integer_at_most_1000000","maximum_observation_bytes":"positive_integer_at_most_25165824"})";
// Updated only when the closed schema string above deliberately changes.
constexpr std::string_view kObservationParameterSchemaDigest =
    "2aa621821b52b40389e3095d5d9009db1cfcf68869e7ed1857b05e1eaf381863";
constexpr std::string_view kObservationHostedRouteBinding =
    R"({"projection_version":2,"provider_id":"full_orbit_framework_sampler","provider_version":"1.3.0","parameter_schema_version":3,"parameter_schema_digest":"2aa621821b52b40389e3095d5d9009db1cfcf68869e7ed1857b05e1eaf381863","construction_method":"sampled_offline","producer_mode":"local_executable_builder","deployed_semantic_tag":"scalar_backlog_response","runtime_access_tag":"finite_parameter_analytic_family","proposed_payload_tag":"finite_prefix_constant_tail_response_v1","proposed_payload_version":1,"native_result_tag":"full_orbit_cp07_1_finite_prefix_transport_v2","observation_component_name":"construction_observation_bundle_v1","supported_build_request_versions":[1],"required_build_report_schema_versions":[1],"executable_id":"fofs.cp06.c27.local","request_protocol_version":1,"result_protocol_version":2,"maximum_observation_bytes":25165824,"registration_status":"registered_observation_route_step_1"})";
constexpr std::string_view kObservationHostedRouteBindingDigest =
    "e5312cc6c783eeaf1f473ddab4ca94c22c8ce9b935034aae88749349ec1ee515";

// Unlike the frozen CP07.1 schemas above, this declaration is the live CP09
// contract introduced by this checkpoint.  Its digest is computed from these
// exact bytes and then sealed into the provider manifest; no legacy digest is
// rewritten.  Projection cutoffs are deliberately absent from construction.
// The two maximum_* spellings remain in the authenticated schema-4 wire for
// compatibility with released configs.  CP09 r9 treats them as non-operative
// hints: actual sparse geometry, checked addressability and fallible
// allocation govern storage, and they are excluded from observation identity.
constexpr std::string_view kCp09ParameterSchema =
    R"({"schema_version":4,"required_members":["schema_version","construction","observation","projection"],"construction":{"required_members":["warmup_slots","horizon_slots","replications","population_size"],"warmup_horizon_relation":"0<=W<T","replications_relation":"R>0","population_size_relation":"P>0"},"observation":{"required_members":["emit","reporting_block_boundaries","gap_telemetry","maximum_rows_per_replication","maximum_bytes"],"emit":"must_be_true_for_raw_observed","reporting_block_boundaries":"strictly_increasing_absolute_boundaries_starting_at_W_and_ending_at_T","gap_telemetry":["disabled","auto","required"],"maximum_rows_per_replication":"positive_integer_compatibility_field_nonbinding","maximum_bytes":"positive_integer_compatibility_field_nonbinding"},"projection":{"required_members":["mode","cutoffs","deployment_cutoff","familywise_alpha"],"mode":["raw_observed"],"cutoffs":"strictly_increasing_unique_nonnegative_integer_array","deployment_cutoff":"null_for_raw_observed","familywise_alpha":"canonical_reduced_rational_strictly_between_zero_and_one"},"identity_partition":"construction_and_target_seed_trajectory;observation_controls_recording;projection_never_seeds_physics"})";
constexpr std::string_view kCp09HostedRouteBinding =
    R"({"projection_version":3,"provider_id":"full_orbit_framework_sampler","provider_version":"1.4.0","parameter_schema_version":4,"construction_method":"sampled_offline","producer_mode":"local_executable_builder","deployed_semantic_tag":"scalar_backlog_response","runtime_access_tag":"finite_parameter_analytic_family","empirical_profile_tag":"empirical_finite_window_response_v1","empirical_profile_version":1,"native_result_tag":"full_orbit_cp09_observation_transport_v3","observation_component_name":"construction_observation_bundle_v1","supported_build_request_versions":[1],"required_build_report_schema_versions":[1],"executable_id":"fofs.cp06.c27.local","request_protocol_version":1,"result_protocol_version":3,"maximum_observation_bytes":107374182400,"terminal_success":"observed","registration_status":"registered_cp09_observation_only"})";

constexpr std::uint64_t kMaximumHorizonSlots = 10'000'000U;
constexpr std::uint64_t kMaximumWarmupSlots = 9'999'999U;
constexpr std::uint64_t kMaximumReplications = 10'000U;
constexpr std::uint64_t kMaximumConstructionWork = 1'000'000'000U;
constexpr std::uint64_t kMaximumReportingBoundaries = 4096U;
constexpr std::uint64_t kMaximumObservationRowsPerReplication = 1'000'000U;
constexpr std::uint64_t kMaximumObservationBytes = 24U * 1024U * 1024U;
#if defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER)
constexpr std::uint64_t kObservationResultEnvelopeReserveBytes =
    8U * 1024U * 1024U;
constexpr std::uint64_t kObservationAccumulatorRowChargeBytes = 192U;
constexpr std::uint64_t kObservationAccumulatorBlockChargeBytes = 512U;
constexpr std::uint64_t kObservationAccumulatorReplicationChargeBytes = 256U;
constexpr std::uint64_t kMaximumObservationAccumulatorBytes =
    512U * 1024U * 1024U;
#endif  // defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER)

enum class FullOrbitGapTelemetryMode : std::uint8_t {
  disabled,
  automatic,
  required,
};

struct FullOrbitKWideParameters final {
  BigNat warmup_slots;
  BigNat horizon_slots;
  BigNat replications;
  BigNat population_size;
  BigNat response_cutoff;
  BigInt alpha_numerator;
  BigInt alpha_denominator;
};

struct FullOrbitObservationParameters final {
  BigNat warmup_slots;
  BigNat horizon_slots;
  BigNat replications;
  BigNat population_size;
  BigNat response_cutoff;
  BigInt alpha_numerator;
  BigInt alpha_denominator;
  bool emit_observation_record;
  std::vector<std::uint64_t> reporting_block_boundaries;
  FullOrbitGapTelemetryMode gap_telemetry;
  std::uint64_t maximum_observation_rows_per_replication;
  std::uint64_t maximum_observation_bytes;
};

enum class FullOrbitCp09ProjectionMode : std::uint8_t {
  raw_observed,
};

struct FullOrbitCp09Parameters final {
  BigNat warmup_slots;
  BigNat horizon_slots;
  BigNat replications;
  BigNat population_size;
  bool emit_observation;
  std::vector<std::uint64_t> reporting_block_boundaries;
  FullOrbitGapTelemetryMode gap_telemetry;
  std::uint64_t maximum_observation_rows_per_replication;
  std::uint64_t maximum_observation_bytes;
  FullOrbitCp09ProjectionMode projection_mode;
  std::vector<BigNat> projection_cutoffs;
  std::optional<BigNat> deployment_cutoff;
  BigInt alpha_numerator;
  BigInt alpha_denominator;
};

[[nodiscard]] Diagnostic route_error(
    std::string code, std::string message,
    std::optional<std::string> pointer = std::nullopt) {
  return {DiagnosticCategory::input_validation, std::move(code),
          std::move(message), std::move(pointer), std::nullopt, {}};
}

[[nodiscard]] Result<Digest256> digest_from_hex(
    const std::string_view text) {
  return Digest256::from_hex(std::string(text));
}

[[nodiscard]] Result<Digest256> digest_text(const std::string_view text) {
  return sha256(std::as_bytes(std::span(text.data(), text.size())));
}

[[nodiscard]] bool canonical_decimal_natural(const std::string_view text,
                                              const bool positive) {
  if (text.empty() || (text.size() > 1U && text.front() == '0')) return false;
  if (!std::all_of(text.begin(), text.end(), [](const char value) {
        return value >= '0' && value <= '9';
      })) {
    return false;
  }
  return !positive || text != "0";
}

[[nodiscard]] Result<BigNat> source_natural(const SourceNode* node,
                                            const std::string_view name,
                                            const bool positive) {
  if (node == nullptr || node->kind() != SourceNodeKind::number ||
      node->number_lexeme() == nullptr ||
      !canonical_decimal_natural(*node->number_lexeme(), positive)) {
    return Result<BigNat>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_natural",
        std::string(name) + " must be a canonical " +
            (positive ? "positive" : "nonnegative") + " integer",
        node == nullptr ? std::nullopt
                        : std::optional<std::string>(node->json_pointer())));
  }
  auto value = BigNat::from_big_int(BigInt(*node->number_lexeme()));
  if (!value) return Result<BigNat>::failure(value.error());
  return value;
}

[[nodiscard]] bool exact_keys(const SourceNode& node,
                              const std::span<const std::string_view> keys) {
  if (node.kind() != SourceNodeKind::object ||
      node.object_members().size() != keys.size()) {
    return false;
  }
  return std::all_of(keys.begin(), keys.end(), [&](const auto key) {
    return node.find(key) != nullptr;
  });
}

[[nodiscard]] Result<std::pair<BigInt, BigInt>> validate_alpha(
    const SourceNode* alpha) {
  static constexpr std::array<std::string_view, 3U> kAlphaKeys{
      "kind", "numerator", "denominator"};
  if (alpha == nullptr || !exact_keys(*alpha, kAlphaKeys)) {
    return Result<std::pair<BigInt, BigInt>>::failure(route_error(
        "c27_1.full_orbit_k_wide_alpha_shape",
        "familywise_alpha must be the closed rational object"));
  }
  const SourceNode* kind = alpha->find("kind");
  const SourceNode* numerator_node = alpha->find("numerator");
  const SourceNode* denominator_node = alpha->find("denominator");
  if (kind == nullptr || kind->kind() != SourceNodeKind::string ||
      kind->string_value() == nullptr || *kind->string_value() != "rational" ||
      numerator_node == nullptr ||
      numerator_node->kind() != SourceNodeKind::string ||
      numerator_node->string_value() == nullptr ||
      denominator_node == nullptr ||
      denominator_node->kind() != SourceNodeKind::string ||
      denominator_node->string_value() == nullptr ||
      !canonical_decimal_natural(*numerator_node->string_value(), true) ||
      !canonical_decimal_natural(*denominator_node->string_value(), true)) {
    return Result<std::pair<BigInt, BigInt>>::failure(route_error(
        "c27_1.full_orbit_k_wide_alpha_value",
        "familywise_alpha must use positive canonical decimal strings"));
  }
  BigInt numerator(*numerator_node->string_value());
  BigInt denominator(*denominator_node->string_value());
  BigInt left = numerator;
  BigInt right = denominator;
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  if (numerator >= denominator || left != 1) {
    return Result<std::pair<BigInt, BigInt>>::failure(route_error(
        "c27_1.full_orbit_k_wide_alpha_domain",
        "familywise_alpha must be reduced and strictly between zero and one"));
  }
  return Result<std::pair<BigInt, BigInt>>::success(
      {std::move(numerator), std::move(denominator)});
}

[[nodiscard]] const FullOrbitKWideParameters* typed_parameters(
    const ValidatedParameterPayloadV1& parameters) noexcept {
  return parameters.typed_value
             ? static_cast<const FullOrbitKWideParameters*>(
                   parameters.typed_value.get())
             : nullptr;
}

[[nodiscard]] Result<std::pair<BigInt, BigInt>> validate_cp09_alpha(
    const SourceNode* alpha) {
  static constexpr std::array<std::string_view, 2U> kAlphaKeys{
      "numerator", "denominator"};
  if (alpha == nullptr || !exact_keys(*alpha, kAlphaKeys)) {
    return Result<std::pair<BigInt, BigInt>>::failure(route_error(
        "c32.full_orbit_cp09_alpha_shape",
        "projection.familywise_alpha must contain exactly numerator and "
        "denominator"));
  }
  const SourceNode* numerator_node = alpha->find("numerator");
  const SourceNode* denominator_node = alpha->find("denominator");
  if (numerator_node == nullptr ||
      numerator_node->kind() != SourceNodeKind::string ||
      numerator_node->string_value() == nullptr ||
      denominator_node == nullptr ||
      denominator_node->kind() != SourceNodeKind::string ||
      denominator_node->string_value() == nullptr ||
      !canonical_decimal_natural(*numerator_node->string_value(), true) ||
      !canonical_decimal_natural(*denominator_node->string_value(), true)) {
    return Result<std::pair<BigInt, BigInt>>::failure(route_error(
        "c32.full_orbit_cp09_alpha_value",
        "projection.familywise_alpha must use positive canonical decimal "
        "strings"));
  }
  BigInt numerator(*numerator_node->string_value());
  BigInt denominator(*denominator_node->string_value());
  BigInt left = numerator;
  BigInt right = denominator;
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  if (numerator >= denominator || left != 1) {
    return Result<std::pair<BigInt, BigInt>>::failure(route_error(
        "c32.full_orbit_cp09_alpha_domain",
        "projection.familywise_alpha must be reduced and strictly between "
        "zero and one"));
  }
  return Result<std::pair<BigInt, BigInt>>::success(
      {std::move(numerator), std::move(denominator)});
}

[[nodiscard]] Result<std::vector<BigNat>> source_projection_cutoffs(
    const SourceNode* node) {
  if (node == nullptr || node->kind() != SourceNodeKind::array ||
      node->array_items().empty()) {
    return Result<std::vector<BigNat>>::failure(route_error(
        "c32.full_orbit_cp09_cutoff_shape",
        "projection.cutoffs must be a nonempty array of canonical "
        "nonnegative integers",
        node == nullptr
            ? std::nullopt
            : std::optional<std::string>(node->json_pointer())));
  }
  std::vector<BigNat> cutoffs;
  cutoffs.reserve(node->array_items().size());
  for (const SourceNode& item : node->array_items()) {
    auto cutoff = source_natural(&item, "projection cutoff", false);
    if (!cutoff) {
      return Result<std::vector<BigNat>>::failure(cutoff.error());
    }
    if (!cutoffs.empty() && cutoffs.back() >= cutoff.value()) {
      return Result<std::vector<BigNat>>::failure(route_error(
          "c32.full_orbit_cp09_cutoff_order",
          "projection.cutoffs must be strictly increasing and unique",
          std::string(item.json_pointer())));
    }
    cutoffs.push_back(std::move(cutoff).value());
  }
  return Result<std::vector<BigNat>>::success(std::move(cutoffs));
}

[[nodiscard]] Result<std::uint64_t> native_u64(
    const BigNat& value, const std::string_view name,
    const SourceNode* source = nullptr) {
  if (value > BigNat{std::numeric_limits<std::uint64_t>::max()}) {
    return Result<std::uint64_t>::failure(route_error(
        "c30.full_orbit_observation_parameter_range",
        std::string(name) + " exceeds the uint64 transport domain",
        source == nullptr
            ? std::nullopt
            : std::optional<std::string>(source->json_pointer())));
  }
  return Result<std::uint64_t>::success(
      value.value().convert_to<std::uint64_t>());
}

[[nodiscard]] Result<bool> source_boolean(const SourceNode* node,
                                          const std::string_view name) {
  if (node == nullptr || node->kind() != SourceNodeKind::boolean ||
      node->boolean_value() == nullptr) {
    return Result<bool>::failure(route_error(
        "c30.full_orbit_observation_parameter_boolean",
        std::string(name) + " must be a JSON boolean",
        node == nullptr
            ? std::nullopt
            : std::optional<std::string>(node->json_pointer())));
  }
  return Result<bool>::success(*node->boolean_value());
}

[[nodiscard]] Result<FullOrbitGapTelemetryMode> source_gap_mode(
    const SourceNode* node) {
  if (node == nullptr || node->kind() != SourceNodeKind::string ||
      node->string_value() == nullptr) {
    return Result<FullOrbitGapTelemetryMode>::failure(route_error(
        "c30.full_orbit_observation_gap_mode",
        "gap_telemetry must be one closed string mode",
        node == nullptr
            ? std::nullopt
            : std::optional<std::string>(node->json_pointer())));
  }
  if (*node->string_value() == "disabled") {
    return Result<FullOrbitGapTelemetryMode>::success(
        FullOrbitGapTelemetryMode::disabled);
  }
  if (*node->string_value() == "auto") {
    return Result<FullOrbitGapTelemetryMode>::success(
        FullOrbitGapTelemetryMode::automatic);
  }
  if (*node->string_value() == "required") {
    return Result<FullOrbitGapTelemetryMode>::success(
        FullOrbitGapTelemetryMode::required);
  }
  return Result<FullOrbitGapTelemetryMode>::failure(route_error(
      "c30.full_orbit_observation_gap_mode",
      "gap_telemetry must be disabled, auto or required",
      std::string(node->json_pointer())));
}

[[nodiscard]] std::string_view gap_mode_text(
    const FullOrbitGapTelemetryMode mode) noexcept {
  switch (mode) {
    case FullOrbitGapTelemetryMode::disabled:
      return "disabled";
    case FullOrbitGapTelemetryMode::automatic:
      return "auto";
    case FullOrbitGapTelemetryMode::required:
      return "required";
  }
  return "disabled";
}

[[nodiscard]] Result<std::vector<std::uint64_t>> source_boundaries(
    const SourceNode* node,
    const bool enforce_legacy_count_limit = true) {
  if (node == nullptr || node->kind() != SourceNodeKind::array ||
      node->array_items().size() < 2U ||
      (enforce_legacy_count_limit &&
       node->array_items().size() > kMaximumReportingBoundaries)) {
    return Result<std::vector<std::uint64_t>>::failure(route_error(
        "c30.full_orbit_observation_block_plan_shape",
        "reporting_block_boundaries must contain at least two absolute "
        "integer boundaries",
        node == nullptr
            ? std::nullopt
            : std::optional<std::string>(node->json_pointer())));
  }
  std::vector<std::uint64_t> boundaries;
  boundaries.reserve(node->array_items().size());
  for (const SourceNode& item : node->array_items()) {
    auto natural = source_natural(&item, "reporting_block_boundary", false);
    if (!natural) {
      return Result<std::vector<std::uint64_t>>::failure(natural.error());
    }
    auto native = native_u64(natural.value(), "reporting_block_boundary",
                             &item);
    if (!native) {
      return Result<std::vector<std::uint64_t>>::failure(native.error());
    }
    if (!boundaries.empty() && boundaries.back() >= native.value()) {
      return Result<std::vector<std::uint64_t>>::failure(route_error(
          "c30.full_orbit_observation_block_plan_order",
          "reporting_block_boundaries must be strictly increasing",
          std::string(item.json_pointer())));
    }
    boundaries.push_back(native.value());
  }
  return Result<std::vector<std::uint64_t>>::success(std::move(boundaries));
}

[[nodiscard]] Result<Digest256> domain_text_digest(
    const std::string_view domain, const std::string_view value) {
  return sha256_domain_separated(
      domain, std::as_bytes(std::span(value.data(), value.size())));
}

[[nodiscard]] Result<Digest256> observation_experiment_digest(
    const FrameworkProblemView& problem,
    const FullOrbitObservationParameters& parameters) {
  std::string preimage =
      "{\"problem_digest\":\"" + problem.canonical_digest().value().hex() +
      "\",\"warmup_boundary\":" +
      parameters.warmup_slots.to_decimal_string() +
      ",\"end_boundary\":" + parameters.horizon_slots.to_decimal_string() +
      ",\"reporting_block_boundaries\":[";
  for (std::size_t index = 0U;
       index < parameters.reporting_block_boundaries.size(); ++index) {
    if (index != 0U) preimage.push_back(',');
    preimage +=
        std::to_string(parameters.reporting_block_boundaries[index]);
  }
  preimage += "]}";
  return domain_text_digest(
      "mwperf.full_orbit.observation_experiment.v1", preimage);
}

[[nodiscard]] Result<Digest256> cp09_trajectory_identity_digest(
    const Digest256& physical_trajectory_digest,
    const FullOrbitCp09Parameters& parameters) {
  const std::string preimage =
      "{\"provider\":\"full_orbit_framework_sampler/1.4.0\","
      "\"physical_trajectory_digest\":\"" +
      physical_trajectory_digest.hex() +
      "\",\"warmup_slots\":" + parameters.warmup_slots.to_decimal_string() +
      ",\"horizon_slots\":" + parameters.horizon_slots.to_decimal_string() +
      ",\"replications\":" + parameters.replications.to_decimal_string() +
      ",\"population_size\":" +
      parameters.population_size.to_decimal_string() + "}";
  return domain_text_digest("mwperf.full_orbit.cp09.trajectory.v1", preimage);
}

[[nodiscard]] Result<Digest256> cp09_observation_policy_digest(
    const FullOrbitCp09Parameters& parameters) {
  std::string preimage =
      "{\"emit\":" +
      std::string(parameters.emit_observation ? "true" : "false") +
      ",\"reporting_block_boundaries\":[";
  for (std::size_t index = 0U;
       index < parameters.reporting_block_boundaries.size(); ++index) {
    if (index != 0U) preimage.push_back(',');
    preimage += std::to_string(parameters.reporting_block_boundaries[index]);
  }
  preimage += "],\"gap_telemetry\":\"";
  preimage += gap_mode_text(parameters.gap_telemetry);
  preimage += "\"}";
  return domain_text_digest("mwperf.full_orbit.cp09.observation_policy.v1",
                            preimage);
}

[[nodiscard]] Result<Digest256> cp09_projection_policy_digest(
    const FullOrbitCp09Parameters& parameters) {
  std::string preimage{"{\"mode\":\"raw_observed\",\"cutoffs\":["};
  for (std::size_t index = 0U;
       index < parameters.projection_cutoffs.size(); ++index) {
    if (index != 0U) preimage.push_back(',');
    preimage += parameters.projection_cutoffs[index].to_decimal_string();
  }
  preimage +=
      "],\"deployment_cutoff\":null,\"familywise_alpha\":{\"numerator\":\"" +
      parameters.alpha_numerator.convert_to<std::string>() +
      "\",\"denominator\":\"" +
      parameters.alpha_denominator.convert_to<std::string>() + "\"}}";
  return domain_text_digest("mwperf.full_orbit.cp09.projection_policy.v1",
                            preimage);
}

[[nodiscard]] Result<Digest256> cp09_experiment_digest(
    const Digest256& trajectory_identity_digest,
    const FullOrbitCp09Parameters& parameters) {
  auto observation = cp09_observation_policy_digest(parameters);
  if (!observation) return Result<Digest256>::failure(observation.error());
  return domain_text_digest(
      "mwperf.full_orbit.cp09.observation_experiment.v1",
      "{\"trajectory_identity_digest\":\"" +
          trajectory_identity_digest.hex() +
          "\",\"observation_policy_digest\":\"" +
          observation.value().hex() + "\"}");
}

[[nodiscard]] Result<Digest256> expected_cp09_seed_policy_digest(
    const SurrogateBuildRequest& request,
    const Digest256& trajectory_identity_digest) {
  const std::string preimage =
      "{\"rng_version\":" +
      std::to_string(request.build_seed().rng_version()) +
      ",\"master_seed\":\"" +
      std::to_string(request.build_seed().master_seed().value()) +
      "\",\"trajectory_identity_digest\":\"" +
      trajectory_identity_digest.hex() + "\"}";
  return domain_text_digest("mwperf.full_orbit.cp09.seed_policy.v1",
                            preimage);
}

[[nodiscard]] Result<Digest256> expected_slot_convention_digest() {
  return domain_text_digest(
      "mwperf.construction_observation.slot_convention.v1",
      "solve_primary_maxweight,observe_pre_service,apply_actual_service,"
      "classify_and_resample,allocate_child_lineage,"
      "apply_fresh_late_arrival,commit_post_slot_state,"
      "emit_committed_observation");
}

[[nodiscard]] Result<Digest256> expected_initial_law_digest() {
  return registered_empty_backlog_initial_law_digest_v1();
}

[[nodiscard]] Result<Digest256> expected_seed_policy_digest(
    const SurrogateBuildRequest& request) {
  const auto bytes = request.build_seed().canonical_bytes();
  return sha256_domain_separated(
      "mwperf.full_orbit.observation_seed_policy.v1", bytes);
}

[[nodiscard]] Result<Digest256> expected_scheduler_digest(
    const ResolvedInstance& instance) {
  return domain_text_digest(
      "mwperf.construction_observation.scheduler.v1",
      to_string(instance.service_identity().scheduler));
}

[[nodiscard]] Result<Digest256> expected_optimizer_digest(
    const ResolvedInstance& instance) {
  return domain_text_digest(
      "mwperf.construction_observation.optimizer.v1",
      to_string(instance.service_identity().optimizer));
}

[[nodiscard]] Result<Digest256> expected_primary_objective_digest() {
  return domain_text_digest(
      "mwperf.construction_observation.primary_objective.v1",
      "sum(maxweight_multiplier*backlog*binary_service)");
}

[[nodiscard]] Result<BigNat> resolved_response_cutoff(
    const TailResolution& resolved_tail) {
  const auto* constant =
      std::get_if<ConstantResponseTailResolution>(&resolved_tail);
  if (constant == nullptr || constant->cutoff < BigNat{2U} ||
      constant->cutoff > BigNat{5U}) {
    return Result<BigNat>::failure(route_error(
        "c27_1.full_orbit_k_wide_tail_resolution",
        "the K-wide Full Orbit route requires constant_response with "
        "2 <= cutoff <= 5",
        "/resolution/tail"));
  }
  return Result<BigNat>::success(constant->cutoff);
}

[[nodiscard]] bool not_applicable(
    const CountConstructionGrantV1& grant) noexcept {
  return grant.applicability == BudgetApplicabilityV1::not_applicable &&
         !grant.amount.has_value();
}

[[nodiscard]] bool supported_pair(
    const SchedulerConstraintPairV1& pair) noexcept {
  return pair == SchedulerConstraintPairV1{
                     ServiceFamily::crossbar_matching,
                     OptimizerId::hungarian_exact} ||
         pair == SchedulerConstraintPairV1{
                     ServiceFamily::nonoverlapping_intervals,
                     OptimizerId::weighted_interval_dp_exact} ||
         pair == SchedulerConstraintPairV1{
                     ServiceFamily::node_exclusive_matching,
                     OptimizerId::edmonds_blossom_exact} ||
         pair == SchedulerConstraintPairV1{
                     ServiceFamily::pairwise_conflicts,
                     OptimizerId::mwis_branch_memo_exact} ||
         pair == SchedulerConstraintPairV1{
                     ServiceFamily::resource_packing,
                     OptimizerId::binary_packing_memo_exact};
}

[[nodiscard]] Result<void> validate_geometry(
    const FrameworkProblemView& view) {
  if (view.queues().size() > 4096U) {
    return Result<void>::failure(route_error(
        "c27_1.full_orbit_geometry_limit",
        "Full Orbit supports at most 4096 configured queues"));
  }
  return std::visit(
      [&](const auto& geometry) -> Result<void> {
        using Geometry = std::decay_t<decltype(geometry)>;
        bool valid = true;
        if constexpr (std::is_same_v<Geometry,
                                     PortableCrossbarConstraintV1>) {
          valid = geometry.inputs.size() + geometry.outputs.size() <= 128U &&
                  geometry.edges.size() <= 4096U;
        } else if constexpr (std::is_same_v<Geometry,
                                            PortableNodeExclusiveConstraintV1>) {
          valid = geometry.vertices.size() <= 128U;
        }
        if (!valid) {
          return Result<void>::failure(route_error(
              "c27_1.full_orbit_geometry_limit",
              "the configured scheduler geometry exceeds a frozen Full "
              "Orbit scientific admissibility limit"));
        }
        return Result<void>::success();
      },
      view.constraint_geometry());
}

[[nodiscard]] bool portable_intervals_compatible(
    const PortableIntervalV1& left,
    const PortableIntervalV1& right) noexcept {
  // The interval scheduler uses half-open intervals, so exact endpoint
  // contact is compatible.
  return left.right <= right.left || right.right <= left.left;
}

[[nodiscard]] bool interval_star_component_supported(
    const PortableIntervalConstraintV1& geometry,
    const PortableIntervalV1& target,
    const PortableIntervalV1& hub) {
  if (&target != &hub && portable_intervals_compatible(target, hub)) {
    return false;
  }

  std::vector<const PortableIntervalV1*> leaves;
  leaves.reserve(geometry.intervals.size());
  for (const PortableIntervalV1& interval : geometry.intervals) {
    if (&interval != &hub &&
        !portable_intervals_compatible(interval, hub)) {
      leaves.push_back(&interval);
    }
  }
  if (&target != &hub &&
      std::find(leaves.begin(), leaves.end(), &target) == leaves.end()) {
    return false;
  }
  for (std::size_t left = 0U; left < leaves.size(); ++left) {
    for (std::size_t right = left + 1U; right < leaves.size(); ++right) {
      if (!portable_intervals_compatible(*leaves[left], *leaves[right])) {
        return false;
      }
    }
  }

  std::vector<QueueId> leaf_ids;
  leaf_ids.reserve(leaves.size());
  for (const PortableIntervalV1* leaf : leaves) {
    leaf_ids.push_back(leaf->queue);
  }
  std::sort(leaf_ids.begin(), leaf_ids.end());
  // An interval outside this star component must not couple to a leaf.  Such
  // a coupling would prevent the closed hub/leaf gap formula from cancelling
  // the rest of the optimum.
  for (const PortableIntervalV1* leaf : leaves) {
    for (const PortableIntervalV1& other : geometry.intervals) {
      if (&other == &hub ||
          std::binary_search(leaf_ids.begin(), leaf_ids.end(), other.queue)) {
        continue;
      }
      if (!portable_intervals_compatible(*leaf, other)) return false;
    }
  }
  return true;
}

[[nodiscard]] bool conflict_star_component_supported(
    const PortableConflictConstraintV1& geometry,
    const QueueId& target, const QueueId& hub) {
  std::vector<QueueId> leaves;
  leaves.reserve(geometry.queues.size());
  for (const PortableConflictPairV1& conflict : geometry.conflicts) {
    if (conflict.first == hub) {
      leaves.push_back(conflict.second);
    } else if (conflict.second == hub) {
      leaves.push_back(conflict.first);
    }
  }
  std::sort(leaves.begin(), leaves.end());
  leaves.erase(std::unique(leaves.begin(), leaves.end()), leaves.end());
  if (target != hub &&
      !std::binary_search(leaves.begin(), leaves.end(), target)) {
    return false;
  }
  for (const PortableConflictPairV1& conflict : geometry.conflicts) {
    const bool first_leaf =
        std::binary_search(leaves.begin(), leaves.end(), conflict.first);
    const bool second_leaf =
        std::binary_search(leaves.begin(), leaves.end(), conflict.second);
    if ((first_leaf && conflict.second != hub) ||
        (second_leaf && conflict.first != hub)) {
      return false;
    }
  }
  return true;
}

// Conservative admission predicate for the zero-additional-solve formulas
// frozen by C30.  False is safe: auto mode still emits occupation telemetry
// with a typed unavailable gap capability, while required mode is rejected
// before provider work begins.
[[nodiscard]] bool zero_solve_gap_probe_supported(
    const FrameworkProblemView& problem) {
  if (problem.target_selection().ordered_targets.size() != 1U) return false;
  const QueueId& target = problem.target_selection().ordered_targets.front();
  const auto queue = std::find_if(
      problem.queues().begin(), problem.queues().end(),
      [&](const PortableQueueEntryV1& entry) {
        return entry.queue_id == target && entry.selected_target;
      });
  if (queue == problem.queues().end()) return false;

  return std::visit(
      [&](const auto& geometry) -> bool {
        using Geometry = std::decay_t<decltype(geometry)>;
        if constexpr (std::same_as<Geometry,
                                   PortableCrossbarConstraintV1>) {
          const auto found = std::find_if(
              geometry.edges.begin(), geometry.edges.end(),
              [&](const PortableCrossbarEdgeV1& edge) {
                return edge.queue == target;
              });
          if (found == geometry.edges.end()) return false;
          if (geometry.edges.size() <= 1U) return true;
          const bool common_input = std::all_of(
              geometry.edges.begin(), geometry.edges.end(),
              [&](const PortableCrossbarEdgeV1& edge) {
                return edge.input == geometry.edges.front().input;
              });
          const bool common_output = std::all_of(
              geometry.edges.begin(), geometry.edges.end(),
              [&](const PortableCrossbarEdgeV1& edge) {
                return edge.output == geometry.edges.front().output;
              });
          return common_input || common_output;
        } else if constexpr (std::same_as<
                                 Geometry,
                                 PortableNodeExclusiveConstraintV1>) {
          const auto found = std::find_if(
              geometry.links.begin(), geometry.links.end(),
              [&](const PortableNodeExclusiveLinkV1& link) {
                return link.queue == target;
              });
          if (found == geometry.links.end()) return false;
          if (geometry.links.size() <= 1U) return true;
          const auto common_vertex = [&](const VertexId& vertex) {
            return std::all_of(
                geometry.links.begin(), geometry.links.end(),
                [&](const PortableNodeExclusiveLinkV1& link) {
                  return link.u == vertex || link.v == vertex;
                });
          };
          if (common_vertex(geometry.links.front().u) ||
              common_vertex(geometry.links.front().v)) {
            return true;
          }
          if (geometry.links.size() != 3U) return false;
          const auto share_vertex = [](const PortableNodeExclusiveLinkV1& a,
                                       const PortableNodeExclusiveLinkV1& b) {
            return a.u == b.u || a.u == b.v || a.v == b.u || a.v == b.v;
          };
          return share_vertex(geometry.links[0], geometry.links[1]) &&
                 share_vertex(geometry.links[0], geometry.links[2]) &&
                 share_vertex(geometry.links[1], geometry.links[2]);
        } else if constexpr (std::same_as<Geometry,
                                           PortableIntervalConstraintV1>) {
          const auto found = std::find_if(
              geometry.intervals.begin(), geometry.intervals.end(),
              [&](const PortableIntervalV1& interval) {
                return interval.queue == target;
              });
          if (found == geometry.intervals.end()) return false;
          if (interval_star_component_supported(geometry, *found, *found)) {
            return true;
          }
          std::vector<const PortableIntervalV1*> target_neighbors;
          for (const PortableIntervalV1& interval : geometry.intervals) {
            if (&interval != &*found &&
                !portable_intervals_compatible(interval, *found)) {
              target_neighbors.push_back(&interval);
            }
          }
          return target_neighbors.size() == 1U &&
                 interval_star_component_supported(
                     geometry, *found, *target_neighbors.front());
        } else if constexpr (std::same_as<Geometry,
                                           PortableConflictConstraintV1>) {
          if (std::find(geometry.queues.begin(), geometry.queues.end(),
                        target) == geometry.queues.end()) {
            return false;
          }
          if (conflict_star_component_supported(geometry, target, target)) {
            return true;
          }
          std::optional<QueueId> sole_neighbor;
          for (const PortableConflictPairV1& conflict : geometry.conflicts) {
            std::optional<QueueId> neighbor;
            if (conflict.first == target) neighbor = conflict.second;
            if (conflict.second == target) neighbor = conflict.first;
            if (!neighbor.has_value()) continue;
            if (sole_neighbor.has_value() && *sole_neighbor != *neighbor) {
              return false;
            }
            sole_neighbor = std::move(neighbor);
          }
          return sole_neighbor.has_value() &&
                 conflict_star_component_supported(
                     geometry, target, *sole_neighbor);
        } else {
          static_assert(std::same_as<Geometry, PortablePackingConstraintV1>);
          return false;
        }
      },
      problem.constraint_geometry());
}

#if defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER)
[[nodiscard]] bool selected_target_has_unit_multiplier(
    const FrameworkProblemView& problem) {
  if (problem.target_selection().ordered_targets.size() != 1U) return false;
  const QueueId& target = problem.target_selection().ordered_targets.front();
  const auto queue = std::find_if(
      problem.queues().begin(), problem.queues().end(),
      [&](const PortableQueueEntryV1& entry) {
        return entry.queue_id == target && entry.selected_target;
      });
  return queue != problem.queues().end() &&
         queue->maxweight_multiplier == ExactRational::one();
}

[[nodiscard]] Result<void> validate_observation_admission_bounds(
    const FullOrbitObservationParameters& parameters,
    const SurrogateProviderManifestV1& manifest,
    const std::optional<BigNat>& attainable_rows_per_replication =
        std::nullopt) {
  if (!parameters.emit_observation_record) {
    if (parameters.gap_telemetry != FullOrbitGapTelemetryMode::disabled) {
      return Result<void>::failure(route_error(
          "c30.full_orbit_observation_disabled_gap_mode",
          "diagnostics-off admission requires disabled gap telemetry"));
    }
    // The sampler's diagnostics-off specialization must allocate no
    // observation accumulator and perform no boundary/gap diagnostic work.
    return Result<void>::success();
  }

  // A supplied attainable-row bound identifies the schema-4 raw route.  Its
  // geometry has already been computed with checked arithmetic; CP09 must not
  // turn compatibility fields or conservative memory estimates into an
  // independent scientific admission policy.  Allocation and final transport
  // remain fallible and byte-bounded at the actual point of use.
  if (attainable_rows_per_replication.has_value()) {
    return Result<void>::success();
  }

  const ObservationParseLimitsV1 parser_limits =
      default_observation_parse_limits_v1();
  if (!std::in_range<std::uint64_t>(parser_limits.maximum_replications) ||
      !std::in_range<std::uint64_t>(parser_limits.maximum_total_blocks) ||
      !std::in_range<std::uint64_t>(
          parser_limits.maximum_total_level_rows) ||
      !std::in_range<std::uint64_t>(
          parser_limits.maximum_total_boundary_rows) ||
      !std::in_range<std::uint64_t>(
          parameters.reporting_block_boundaries.size())) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_native_limit_conversion",
        "an observation parser/admission limit exceeds the uint64 contract",
        std::nullopt));
  }
  const BigNat replication_limit{
      static_cast<std::uint64_t>(parser_limits.maximum_replications)};
  const BigNat block_limit{
      static_cast<std::uint64_t>(parser_limits.maximum_total_blocks)};
  const BigNat level_row_limit{
      static_cast<std::uint64_t>(parser_limits.maximum_total_level_rows)};
  const BigNat boundary_row_limit{
      static_cast<std::uint64_t>(parser_limits.maximum_total_boundary_rows)};
  const BigNat blocks_per_replication{
      static_cast<std::uint64_t>(
          parameters.reporting_block_boundaries.size() - 1U)};
  const BigNat total_blocks =
      parameters.replications * blocks_per_replication;
  BigNat admitted_rows_per_replication{
      parameters.maximum_observation_rows_per_replication};
  if (attainable_rows_per_replication.has_value() &&
      *attainable_rows_per_replication < admitted_rows_per_replication) {
    admitted_rows_per_replication = *attainable_rows_per_replication;
  }
  const BigNat total_row_capacity =
      parameters.replications * admitted_rows_per_replication;
  if (parameters.replications > replication_limit ||
      total_blocks > block_limit || total_row_capacity > level_row_limit ||
      total_row_capacity > boundary_row_limit) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_parser_cardinality_admission",
        "the requested replication, block or sparse-row capacity exceeds "
        "the framework observation parser's pre-DOM limits"));
  }

  const BigNat boundary_scans =
      parameters.replications * parameters.population_size *
      BigNat{static_cast<std::uint64_t>(
          parameters.reporting_block_boundaries.size())};
  auto measured_slots = checked_subtract(parameters.horizon_slots,
                                         parameters.warmup_slots);
  if (!measured_slots) return Result<void>::failure(measured_slots.error());
  const BigNat gap_evaluations =
      parameters.gap_telemetry == FullOrbitGapTelemetryMode::disabled
          ? BigNat{0U}
          : parameters.replications * parameters.population_size *
                measured_slots.value();
  const BigNat diagnostic_work_limit{kMaximumConstructionWork};
  if (boundary_scans > diagnostic_work_limit ||
      gap_evaluations > diagnostic_work_limit) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_diagnostic_work_admission",
        "checked boundary-scan or gap-evaluation work exceeds the frozen "
        "pre-execution diagnostic-work cap"));
  }

  const BigNat accumulator_bytes =
      total_row_capacity * BigNat{kObservationAccumulatorRowChargeBytes} +
      total_blocks * BigNat{kObservationAccumulatorBlockChargeBytes} +
      parameters.replications *
          BigNat{kObservationAccumulatorReplicationChargeBytes};
  if (accumulator_bytes > BigNat{kMaximumObservationAccumulatorBytes}) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_accumulator_memory_admission",
        "the conservatively charged observation accumulator/storage upper "
        "bound exceeds 512 MiB"));
  }

  const std::size_t manifest_result_cap =
      manifest.transport_limits.maximum_result_bytes;
  if (manifest_result_cap < kObservationResultEnvelopeReserveBytes ||
      parameters.maximum_observation_bytes >
          manifest_result_cap - kObservationResultEnvelopeReserveBytes ||
      parameters.maximum_observation_bytes > parser_limits.maximum_bytes) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_encoded_size_admission",
        "the requested observation byte cap plus the frozen result-envelope "
        "reserve exceeds a provider or framework transport cap"));
  }
  return Result<void>::success();
}

#endif  // defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER)

struct RouteObservationEnclosure final {
  ExactRational center;
  ExactRational radius;
};

[[nodiscard]] Result<RouteObservationEnclosure>
route_observation_enclosure(const ObservationScalarV1& scalar) {
  if (scalar.value.kind() != PortableScientificScalarKind::binary64 ||
      !scalar.enclosure.has_value() ||
      scalar.enclosure->absolute_error.kind() !=
          PortableScientificScalarKind::binary64) {
    return Result<RouteObservationEnclosure>::failure(route_error(
        "c30.full_orbit_observation_gap_scalar_contract",
        "the Full Orbit weighted observation hook requires an enclosed "
        "binary64 gap scalar"));
  }
  return Result<RouteObservationEnclosure>::success(
      {binary64_as_exact_rational(scalar.value),
       binary64_as_exact_rational(scalar.enclosure->absolute_error)});
}

[[nodiscard]] bool exact_zero(
    const RouteObservationEnclosure& value) noexcept {
  return value.center.is_zero() && value.radius.is_zero();
}

[[nodiscard]] bool enclosure_can_be_less_equal(
    const RouteObservationEnclosure& left,
    const RouteObservationEnclosure& right) {
  return left.center - left.radius <= right.center + right.radius;
}

[[nodiscard]] Result<void> validate_full_orbit_gap_magnitudes(
    const ConstructionObservationBundleV1& bundle) {
  for (const ConstructionObservationReplicationV1& replication :
       bundle.replications) {
    for (const ConstructionObservationBlockV1& block : replication.blocks) {
      for (const ExactLevelObservationV1& row : block.levels) {
        if (!row.gap.has_value()) {
          return Result<void>::failure(route_error(
              "c30.full_orbit_observation_gap_presence",
              "a certified Full Orbit gap probe requires one gap cell at "
              "every observed exact backlog level"));
        }
        const ObservationGapCellV1& gap = *row.gap;
        auto negative = route_observation_enclosure(gap.negative_mass);
        auto tie = route_observation_enclosure(gap.tie_mass);
        auto positive = route_observation_enclosure(gap.positive_mass);
        auto tied_served =
            route_observation_enclosure(gap.tied_and_served_mass);
        auto positive_magnitude =
            route_observation_enclosure(gap.positive_magnitude_mass);
        auto negative_magnitude =
            route_observation_enclosure(gap.negative_magnitude_mass);
        if (!negative || !tie || !positive || !tied_served ||
            !positive_magnitude || !negative_magnitude) {
          return Result<void>::failure(
              !negative            ? negative.error()
              : !tie               ? tie.error()
              : !positive          ? positive.error()
              : !tied_served       ? tied_served.error()
              : !positive_magnitude ? positive_magnitude.error()
                                    : negative_magnitude.error());
        }
        if ((exact_zero(positive.value()) &&
             !exact_zero(positive_magnitude.value())) ||
            (exact_zero(negative.value()) &&
             !exact_zero(negative_magnitude.value())) ||
            (exact_zero(tie.value()) &&
             !exact_zero(tied_served.value()))) {
          return Result<void>::failure(route_error(
              "c30.full_orbit_observation_gap_zero_cell_mismatch",
              "a zero sign/tie cell must have zero associated magnitude or "
              "tied-service mass"));
        }
        auto level =
            ExactRational::make(row.backlog_level.value(), BigInt{1});
        if (!level) return Result<void>::failure(level.error());
        const RouteObservationEnclosure positive_capacity{
            positive.value().center * level.value(),
            positive.value().radius * level.value()};
        // Pointwise G_+ <= N.  The negative magnitude has no corresponding
        // target-only upper bound because competing backlog can be larger
        // than N; its zero-sign implication above is the exact local check.
        if (!enclosure_can_be_less_equal(positive_magnitude.value(),
                                         positive_capacity)) {
          return Result<void>::failure(route_error(
              "c30.full_orbit_observation_positive_gap_magnitude_bound",
              "positive gap magnitude exceeds backlog level times positive "
              "gap mass"));
        }
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] ArrivalAssumptionV1 construction_iid_arrival() {
  return {ArrivalNeedKindV1::exact_iid_late,
          ArrivalCapabilityUseV1::construction,
          CapabilityProvisionNeedV1::portable,
          std::nullopt,
          true,
          false,
          std::nullopt,
          std::nullopt,
          std::nullopt};
}

}  // namespace

Result<void> validate_full_orbit_observation_terminal_replication_policy(
    const ProviderResultKindV2 declared_kind,
    const BigNat& requested_replications,
    const std::size_t realized_replications,
    const bool all_realized_replications_complete) {
  const BigNat realized{realized_replications};
  if (realized > requested_replications ||
      ((declared_kind == ProviderResultKindV2::built ||
        declared_kind == ProviderResultKindV2::observed) &&
       (realized != requested_replications ||
        !all_realized_replications_complete))) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_terminal_replication_policy",
        "a successful Built or Observed provider outcome requires exactly "
        "the requested number of complete observation replications; "
        "Unavailable and provider-authored Failed outcomes may retain only "
        "a bounded prefix"));
  }
  return Result<void>::success();
}

bool is_full_orbit_k_wide_provider(
    const ProviderIdentityV1& provider) noexcept {
  return provider.provider_id == kProviderId &&
         provider.provider_version == kProviderVersion;
}

bool is_full_orbit_observation_provider(
    const ProviderIdentityV1& provider) noexcept {
  return provider.provider_id == kProviderId &&
         provider.provider_version == kObservationProviderVersion;
}

bool is_full_orbit_cp09_provider(
    const ProviderIdentityV1& provider) noexcept {
  return provider.provider_id == kProviderId &&
         provider.provider_version == kCp09ProviderVersion;
}

Result<FullOrbitKWideHostedRouteV1>
full_orbit_sampler_k_wide_hosted_route() {
  auto actual_schema = digest_text(kParameterSchema);
  auto expected_schema = digest_from_hex(kParameterSchemaDigest);
  auto actual_contract = digest_text(kHostedRouteBinding);
  auto expected_contract = digest_from_hex(kHostedRouteBindingDigest);
  if (!actual_schema || !expected_schema || !actual_contract ||
      !expected_contract) {
    if (!actual_schema) {
      return Result<FullOrbitKWideHostedRouteV1>::failure(
          actual_schema.error());
    }
    if (!expected_schema) {
      return Result<FullOrbitKWideHostedRouteV1>::failure(
          expected_schema.error());
    }
    if (!actual_contract) {
      return Result<FullOrbitKWideHostedRouteV1>::failure(
          actual_contract.error());
    }
    if (!expected_contract) {
      return Result<FullOrbitKWideHostedRouteV1>::failure(
          expected_contract.error());
    }
  }
  if (actual_schema.value() != expected_schema.value() ||
      actual_contract.value() != expected_contract.value()) {
    return Result<FullOrbitKWideHostedRouteV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_contract_drift",
        "the hosted K-wide route declaration differs from its frozen "
        "schema or route-binding digest"));
  }
  return Result<FullOrbitKWideHostedRouteV1>::success({
      {std::string(kProviderId), std::string(kProviderVersion)},
      kParameterSchemaVersion,
      std::move(expected_schema).value(),
      std::move(expected_contract).value(),
      std::string(kPayloadTag),
      1U,
      std::string(kNativeResultTag),
      std::string(kExecutableId),
      1U,
      1U,
      false,
  });
}

Result<FullOrbitObservationHostedRouteV2>
full_orbit_sampler_observation_hosted_route() {
  auto actual_schema = digest_text(kObservationParameterSchema);
  auto expected_schema = digest_from_hex(kObservationParameterSchemaDigest);
  auto actual_contract = digest_text(kObservationHostedRouteBinding);
  auto expected_contract =
      digest_from_hex(kObservationHostedRouteBindingDigest);
  if (!actual_schema) {
    return Result<FullOrbitObservationHostedRouteV2>::failure(
        actual_schema.error());
  }
  if (!expected_schema) {
    return Result<FullOrbitObservationHostedRouteV2>::failure(
        expected_schema.error());
  }
  if (!actual_contract) {
    return Result<FullOrbitObservationHostedRouteV2>::failure(
        actual_contract.error());
  }
  if (!expected_contract) {
    return Result<FullOrbitObservationHostedRouteV2>::failure(
        expected_contract.error());
  }
  if (actual_schema.value() != expected_schema.value() ||
      actual_contract.value() != expected_contract.value()) {
    return Result<FullOrbitObservationHostedRouteV2>::failure(route_error(
        "c30.full_orbit_observation_contract_drift",
        "the observation-capable hosted route differs from its frozen "
        "schema or route-binding digest"));
  }
  return Result<FullOrbitObservationHostedRouteV2>::success({
      {std::string(kProviderId), std::string(kObservationProviderVersion)},
      kObservationParameterSchemaVersion,
      std::move(expected_schema).value(),
      std::move(expected_contract).value(),
      std::string(kPayloadTag),
      1U,
      std::string(kObservationNativeResultTag),
      std::string(kExecutableId),
      1U,
      2U,
      static_cast<std::size_t>(kMaximumObservationBytes),
      false,
  });
}

Result<FullOrbitCp09HostedRouteV3>
full_orbit_sampler_cp09_hosted_route() {
  auto schema_digest = digest_text(kCp09ParameterSchema);
  auto binding_digest = digest_text(kCp09HostedRouteBinding);
  if (!schema_digest) {
    return Result<FullOrbitCp09HostedRouteV3>::failure(
        schema_digest.error());
  }
  if (!binding_digest) {
    return Result<FullOrbitCp09HostedRouteV3>::failure(
        binding_digest.error());
  }
  return Result<FullOrbitCp09HostedRouteV3>::success({
      {std::string(kProviderId), std::string(kCp09ProviderVersion)},
      kCp09ParameterSchemaVersion,
      std::move(schema_digest).value(),
      std::move(binding_digest).value(),
      std::string(kCp09EmpiricalProfileTag),
      1U,
      std::string(kCp09NativeResultTag),
      std::string(kExecutableId),
      1U,
      3U,
      kNonScientificByteCeiling,
      false,
  });
}

Result<ValidatedParameterPayloadV1>
validate_full_orbit_k_wide_parameters(const SourceNode& source) {
  static constexpr std::array<std::string_view, 7U> kKeys{
      "schema_version", "warmup_slots", "horizon_slots", "replications",
      "population_size", "familywise_alpha", "response_cutoff"};
  if (!exact_keys(source, kKeys)) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_shape",
        "K-wide Full Orbit parameters must contain exactly the seven "
        "schema-v2 members",
        std::string(source.json_pointer())));
  }
  const SourceNode* schema = source.find("schema_version");
  if (schema == nullptr || schema->kind() != SourceNodeKind::number ||
      schema->number_lexeme() == nullptr || *schema->number_lexeme() != "2") {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_version",
        "K-wide Full Orbit parameter schema_version must equal 2"));
  }

  auto warmup = source_natural(source.find("warmup_slots"), "warmup_slots",
                               false);
  auto horizon = source_natural(source.find("horizon_slots"), "horizon_slots",
                                true);
  auto replications = source_natural(source.find("replications"),
                                     "replications", true);
  auto population = source_natural(source.find("population_size"),
                                   "population_size", true);
  auto cutoff = source_natural(source.find("response_cutoff"),
                               "response_cutoff", true);
  auto alpha = validate_alpha(source.find("familywise_alpha"));
  if (!warmup) {
    return Result<ValidatedParameterPayloadV1>::failure(warmup.error());
  }
  if (!horizon) {
    return Result<ValidatedParameterPayloadV1>::failure(horizon.error());
  }
  if (!replications) {
    return Result<ValidatedParameterPayloadV1>::failure(replications.error());
  }
  if (!population) {
    return Result<ValidatedParameterPayloadV1>::failure(population.error());
  }
  if (!cutoff) {
    return Result<ValidatedParameterPayloadV1>::failure(cutoff.error());
  }
  if (!alpha) {
    return Result<ValidatedParameterPayloadV1>::failure(alpha.error());
  }

  if (warmup.value() >= horizon.value() ||
      warmup.value() > BigNat{kMaximumWarmupSlots} ||
      horizon.value() > BigNat{kMaximumHorizonSlots} ||
      replications.value() > BigNat{kMaximumReplications}) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_domain",
        "K-wide Full Orbit requires 0 <= warmup_slots < horizon_slots and "
        "the frozen horizon/replication limits"));
  }
  if (cutoff.value() < BigNat{2U} || cutoff.value() > BigNat{5U}) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_cutoff_domain",
        "response_cutoff must be in the closed CP07.1 range 2 through 5",
        std::string(source.find("response_cutoff")->json_pointer())));
  }

  auto alpha_values = std::move(alpha).value();
  const auto& [numerator, denominator] = alpha_values;
  const std::string canonical =
      "{\"schema_version\":2,\"warmup_slots\":" +
      warmup.value().to_decimal_string() + ",\"horizon_slots\":" +
      horizon.value().to_decimal_string() + ",\"replications\":" +
      replications.value().to_decimal_string() + ",\"population_size\":" +
      population.value().to_decimal_string() +
      ",\"familywise_alpha\":{\"kind\":\"rational\",\"numerator\":\"" +
      numerator.convert_to<std::string>() + "\",\"denominator\":\"" +
      denominator.convert_to<std::string>() + "\"},\"response_cutoff\":" +
      cutoff.value().to_decimal_string() + "}";
  std::vector<std::byte> bytes(
      reinterpret_cast<const std::byte*>(canonical.data()),
      reinterpret_cast<const std::byte*>(canonical.data() + canonical.size()));
  auto typed = std::make_shared<const FullOrbitKWideParameters>(
      FullOrbitKWideParameters{
          std::move(warmup).value(), std::move(horizon).value(),
          std::move(replications).value(), std::move(population).value(),
          std::move(cutoff).value(), std::move(alpha_values.first),
          std::move(alpha_values.second)});
  return Result<ValidatedParameterPayloadV1>::success(
      {std::move(bytes), std::move(typed)});
}

Result<ValidatedParameterPayloadV1>
validate_full_orbit_observation_parameters(const SourceNode& source) {
  static constexpr std::array<std::string_view, 12U> kKeys{
      "schema_version",
      "warmup_slots",
      "horizon_slots",
      "replications",
      "population_size",
      "familywise_alpha",
      "response_cutoff",
      "emit_observation_record",
      "reporting_block_boundaries",
      "gap_telemetry",
      "maximum_observation_rows_per_replication",
      "maximum_observation_bytes"};
  if (!exact_keys(source, kKeys)) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_parameter_shape",
        "observation-capable Full Orbit parameters must contain exactly "
        "the twelve schema-v3 members",
        std::string(source.json_pointer())));
  }
  const SourceNode* schema = source.find("schema_version");
  if (schema == nullptr || schema->kind() != SourceNodeKind::number ||
      schema->number_lexeme() == nullptr || *schema->number_lexeme() != "3") {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_parameter_version",
        "observation-capable Full Orbit parameter schema_version must "
        "equal 3"));
  }

  auto warmup = source_natural(source.find("warmup_slots"), "warmup_slots",
                               false);
  auto horizon = source_natural(source.find("horizon_slots"),
                                "horizon_slots", true);
  auto replications = source_natural(source.find("replications"),
                                     "replications", true);
  auto population = source_natural(source.find("population_size"),
                                   "population_size", true);
  auto cutoff = source_natural(source.find("response_cutoff"),
                               "response_cutoff", true);
  auto alpha = validate_alpha(source.find("familywise_alpha"));
  auto emit = source_boolean(source.find("emit_observation_record"),
                             "emit_observation_record");
  auto boundaries =
      source_boundaries(source.find("reporting_block_boundaries"));
  auto gap_mode = source_gap_mode(source.find("gap_telemetry"));
  auto maximum_rows = source_natural(
      source.find("maximum_observation_rows_per_replication"),
      "maximum_observation_rows_per_replication", true);
  auto maximum_bytes = source_natural(
      source.find("maximum_observation_bytes"),
      "maximum_observation_bytes", true);
  if (!warmup) {
    return Result<ValidatedParameterPayloadV1>::failure(warmup.error());
  }
  if (!horizon) {
    return Result<ValidatedParameterPayloadV1>::failure(horizon.error());
  }
  if (!replications) {
    return Result<ValidatedParameterPayloadV1>::failure(replications.error());
  }
  if (!population) {
    return Result<ValidatedParameterPayloadV1>::failure(population.error());
  }
  if (!cutoff) {
    return Result<ValidatedParameterPayloadV1>::failure(cutoff.error());
  }
  if (!alpha) {
    return Result<ValidatedParameterPayloadV1>::failure(alpha.error());
  }
  if (!emit) {
    return Result<ValidatedParameterPayloadV1>::failure(emit.error());
  }
  if (!boundaries) {
    return Result<ValidatedParameterPayloadV1>::failure(boundaries.error());
  }
  if (!gap_mode) {
    return Result<ValidatedParameterPayloadV1>::failure(gap_mode.error());
  }
  if (!maximum_rows) {
    return Result<ValidatedParameterPayloadV1>::failure(
        maximum_rows.error());
  }
  if (!maximum_bytes) {
    return Result<ValidatedParameterPayloadV1>::failure(
        maximum_bytes.error());
  }

  if (warmup.value() >= horizon.value() ||
      warmup.value() > BigNat{kMaximumWarmupSlots} ||
      horizon.value() > BigNat{kMaximumHorizonSlots} ||
      replications.value() > BigNat{kMaximumReplications}) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_parameter_domain",
        "observation-capable Full Orbit requires 0 <= warmup_slots < "
        "horizon_slots and the frozen horizon/replication limits"));
  }
  if (cutoff.value() < BigNat{2U} || cutoff.value() > BigNat{5U}) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_cutoff_domain",
        "response_cutoff must remain in the deployed range 2 through 5",
        std::string(source.find("response_cutoff")->json_pointer())));
  }
  if (maximum_rows.value() >
          BigNat{kMaximumObservationRowsPerReplication} ||
      maximum_bytes.value() > BigNat{kMaximumObservationBytes}) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_cap_domain",
        "observation row and byte caps exceed the registered route limits"));
  }
  auto warmup_native = native_u64(warmup.value(), "warmup_slots",
                                  source.find("warmup_slots"));
  auto horizon_native = native_u64(horizon.value(), "horizon_slots",
                                   source.find("horizon_slots"));
  auto replications_native = native_u64(
      replications.value(), "replications", source.find("replications"));
  auto population_native = native_u64(
      population.value(), "population_size", source.find("population_size"));
  auto cutoff_native = native_u64(
      cutoff.value(), "response_cutoff", source.find("response_cutoff"));
  auto maximum_rows_native = native_u64(
      maximum_rows.value(), "maximum_observation_rows_per_replication",
      source.find("maximum_observation_rows_per_replication"));
  auto maximum_bytes_native = native_u64(
      maximum_bytes.value(), "maximum_observation_bytes",
      source.find("maximum_observation_bytes"));
  if (!warmup_native || !horizon_native || !replications_native ||
      !population_native || !cutoff_native || !maximum_rows_native ||
      !maximum_bytes_native) {
    return Result<ValidatedParameterPayloadV1>::failure(
        !warmup_native       ? warmup_native.error()
        : !horizon_native    ? horizon_native.error()
        : !replications_native ? replications_native.error()
        : !population_native ? population_native.error()
        : !cutoff_native     ? cutoff_native.error()
        : !maximum_rows_native ? maximum_rows_native.error()
                               : maximum_bytes_native.error());
  }
  if (boundaries.value().front() != warmup_native.value() ||
      boundaries.value().back() != horizon_native.value()) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_block_plan_window",
        "reporting_block_boundaries must start at warmup_slots and end at "
        "horizon_slots",
        std::string(
            source.find("reporting_block_boundaries")->json_pointer())));
  }
  if (!emit.value() &&
      gap_mode.value() != FullOrbitGapTelemetryMode::disabled) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c30.full_orbit_observation_disabled_gap_mode",
        "gap_telemetry must be disabled when observation emission is off",
        std::string(source.find("gap_telemetry")->json_pointer())));
  }

  auto alpha_values = std::move(alpha).value();
  const auto& [numerator, denominator] = alpha_values;
  std::string boundary_json{"["};
  for (std::size_t index = 0U; index < boundaries.value().size(); ++index) {
    if (index != 0U) boundary_json.push_back(',');
    boundary_json += std::to_string(boundaries.value()[index]);
  }
  boundary_json.push_back(']');
  const std::string canonical =
      "{\"schema_version\":3,\"warmup_slots\":" +
      warmup.value().to_decimal_string() + ",\"horizon_slots\":" +
      horizon.value().to_decimal_string() + ",\"replications\":" +
      replications.value().to_decimal_string() + ",\"population_size\":" +
      population.value().to_decimal_string() +
      ",\"familywise_alpha\":{\"kind\":\"rational\",\"numerator\":\"" +
      numerator.convert_to<std::string>() + "\",\"denominator\":\"" +
      denominator.convert_to<std::string>() +
      "\"},\"response_cutoff\":" + cutoff.value().to_decimal_string() +
      ",\"emit_observation_record\":" +
      (emit.value() ? "true" : "false") +
      ",\"reporting_block_boundaries\":" + boundary_json +
      ",\"gap_telemetry\":\"" +
      std::string(gap_mode_text(gap_mode.value())) +
      "\",\"maximum_observation_rows_per_replication\":" +
      maximum_rows.value().to_decimal_string() +
      ",\"maximum_observation_bytes\":" +
      maximum_bytes.value().to_decimal_string() + "}";
  std::vector<std::byte> bytes(
      reinterpret_cast<const std::byte*>(canonical.data()),
      reinterpret_cast<const std::byte*>(canonical.data() + canonical.size()));
  auto typed = std::make_shared<const FullOrbitObservationParameters>(
      FullOrbitObservationParameters{
          std::move(warmup).value(), std::move(horizon).value(),
          std::move(replications).value(), std::move(population).value(),
          std::move(cutoff).value(), std::move(alpha_values.first),
          std::move(alpha_values.second), emit.value(),
          std::move(boundaries).value(), gap_mode.value(),
          maximum_rows_native.value(), maximum_bytes_native.value()});
  return Result<ValidatedParameterPayloadV1>::success(
      {std::move(bytes), std::move(typed)});
}

Result<ValidatedParameterPayloadV1>
validate_full_orbit_cp09_parameters(const SourceNode& source) {
  static constexpr std::array<std::string_view, 4U> kRootKeys{
      "schema_version", "construction", "observation", "projection"};
  static constexpr std::array<std::string_view, 4U> kConstructionKeys{
      "warmup_slots", "horizon_slots", "replications", "population_size"};
  static constexpr std::array<std::string_view, 5U> kObservationKeys{
      "emit", "reporting_block_boundaries", "gap_telemetry",
      "maximum_rows_per_replication", "maximum_bytes"};
  static constexpr std::array<std::string_view, 4U> kProjectionKeys{
      "mode", "cutoffs", "deployment_cutoff", "familywise_alpha"};
  if (!exact_keys(source, kRootKeys)) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_parameter_shape",
        "CP09 parameters must contain exactly schema_version, construction, "
        "observation and projection",
        std::string(source.json_pointer())));
  }
  const SourceNode* schema = source.find("schema_version");
  const SourceNode* construction = source.find("construction");
  const SourceNode* observation = source.find("observation");
  const SourceNode* projection = source.find("projection");
  if (schema == nullptr || schema->kind() != SourceNodeKind::number ||
      schema->number_lexeme() == nullptr || *schema->number_lexeme() != "4") {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_parameter_version",
        "CP09 parameter schema_version must equal 4"));
  }
  if (construction == nullptr || !exact_keys(*construction, kConstructionKeys) ||
      observation == nullptr || !exact_keys(*observation, kObservationKeys) ||
      projection == nullptr || !exact_keys(*projection, kProjectionKeys)) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_parameter_section_shape",
        "each CP09 parameter section must use its exact closed member set"));
  }

  auto warmup = source_natural(construction->find("warmup_slots"),
                               "construction.warmup_slots", false);
  auto horizon = source_natural(construction->find("horizon_slots"),
                                "construction.horizon_slots", true);
  auto replications = source_natural(construction->find("replications"),
                                     "construction.replications", true);
  auto population = source_natural(construction->find("population_size"),
                                   "construction.population_size", true);
  auto emit = source_boolean(observation->find("emit"), "observation.emit");
  auto boundaries = source_boundaries(
      observation->find("reporting_block_boundaries"), false);
  auto gap_mode = source_gap_mode(observation->find("gap_telemetry"));
  auto maximum_rows = source_natural(
      observation->find("maximum_rows_per_replication"),
      "observation.maximum_rows_per_replication", true);
  auto maximum_bytes = source_natural(observation->find("maximum_bytes"),
                                      "observation.maximum_bytes", true);
  auto cutoffs = source_projection_cutoffs(projection->find("cutoffs"));
  auto alpha = validate_cp09_alpha(projection->find("familywise_alpha"));
  if (!warmup || !horizon || !replications || !population || !emit ||
      !boundaries || !gap_mode || !maximum_rows || !maximum_bytes ||
      !cutoffs || !alpha) {
    return Result<ValidatedParameterPayloadV1>::failure(
        !warmup          ? warmup.error()
        : !horizon       ? horizon.error()
        : !replications  ? replications.error()
        : !population    ? population.error()
        : !emit          ? emit.error()
        : !boundaries    ? boundaries.error()
        : !gap_mode      ? gap_mode.error()
        : !maximum_rows  ? maximum_rows.error()
        : !maximum_bytes ? maximum_bytes.error()
        : !cutoffs       ? cutoffs.error()
                         : alpha.error());
  }

  const SourceNode* mode = projection->find("mode");
  const SourceNode* deployment = projection->find("deployment_cutoff");
  if (mode == nullptr || mode->kind() != SourceNodeKind::string ||
      mode->string_value() == nullptr ||
      *mode->string_value() != "raw_observed") {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_projection_mode",
        "CP09 currently accepts only the cutoff-free raw_observed mode",
        mode == nullptr
            ? std::nullopt
            : std::optional<std::string>(mode->json_pointer())));
  }
  if (deployment == nullptr ||
      deployment->kind() != SourceNodeKind::null_value) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_deployment_cutoff",
        "deployment_cutoff must be null in raw_observed mode",
        deployment == nullptr
            ? std::nullopt
            : std::optional<std::string>(deployment->json_pointer())));
  }
  if (!emit.value()) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_observation_required",
        "raw_observed mode requires observation.emit=true",
        std::string(observation->find("emit")->json_pointer())));
  }
  if (warmup.value() >= horizon.value()) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_construction_domain",
        "CP09 requires 0 <= warmup_slots < horizon_slots"));
  }

  auto warmup_native = native_u64(warmup.value(), "warmup_slots",
                                  construction->find("warmup_slots"));
  auto horizon_native = native_u64(horizon.value(), "horizon_slots",
                                   construction->find("horizon_slots"));
  auto replications_native = native_u64(
      replications.value(), "replications",
      construction->find("replications"));
  auto population_native = native_u64(
      population.value(), "population_size",
      construction->find("population_size"));
  auto maximum_rows_native = native_u64(
      maximum_rows.value(), "maximum_rows_per_replication",
      observation->find("maximum_rows_per_replication"));
  auto maximum_bytes_native = native_u64(
      maximum_bytes.value(), "maximum_bytes",
      observation->find("maximum_bytes"));
  if (!warmup_native || !horizon_native || !replications_native ||
      !population_native || !maximum_rows_native || !maximum_bytes_native) {
    return Result<ValidatedParameterPayloadV1>::failure(
        !warmup_native       ? warmup_native.error()
        : !horizon_native    ? horizon_native.error()
        : !replications_native ? replications_native.error()
        : !population_native ? population_native.error()
        : !maximum_rows_native ? maximum_rows_native.error()
                               : maximum_bytes_native.error());
  }
  if (boundaries.value().front() != warmup_native.value() ||
      boundaries.value().back() != horizon_native.value()) {
    return Result<ValidatedParameterPayloadV1>::failure(route_error(
        "c32.full_orbit_cp09_block_plan_window",
        "observation.reporting_block_boundaries must start at warmup_slots "
        "and end at horizon_slots",
        std::string(observation->find("reporting_block_boundaries")
                        ->json_pointer())));
  }

  std::string boundary_json{"["};
  for (std::size_t index = 0U; index < boundaries.value().size(); ++index) {
    if (index != 0U) boundary_json.push_back(',');
    boundary_json += std::to_string(boundaries.value()[index]);
  }
  boundary_json.push_back(']');
  std::string cutoff_json{"["};
  for (std::size_t index = 0U; index < cutoffs.value().size(); ++index) {
    if (index != 0U) cutoff_json.push_back(',');
    cutoff_json += cutoffs.value()[index].to_decimal_string();
  }
  cutoff_json.push_back(']');
  auto alpha_values = std::move(alpha).value();
  const std::string canonical =
      "{\"schema_version\":4,\"construction\":{\"warmup_slots\":" +
      warmup.value().to_decimal_string() + ",\"horizon_slots\":" +
      horizon.value().to_decimal_string() + ",\"replications\":" +
      replications.value().to_decimal_string() + ",\"population_size\":" +
      population.value().to_decimal_string() +
      "},\"observation\":{\"emit\":true,\"reporting_block_boundaries\":" +
      boundary_json + ",\"gap_telemetry\":\"" +
      std::string(gap_mode_text(gap_mode.value())) +
      "\",\"maximum_rows_per_replication\":" +
      maximum_rows.value().to_decimal_string() +
      ",\"maximum_bytes\":" + maximum_bytes.value().to_decimal_string() +
      "},\"projection\":{\"mode\":\"raw_observed\",\"cutoffs\":" +
      cutoff_json +
      ",\"deployment_cutoff\":null,\"familywise_alpha\":{\"numerator\":\"" +
      alpha_values.first.convert_to<std::string>() +
      "\",\"denominator\":\"" +
      alpha_values.second.convert_to<std::string>() + "\"}}}";
  std::vector<std::byte> bytes(
      reinterpret_cast<const std::byte*>(canonical.data()),
      reinterpret_cast<const std::byte*>(canonical.data() + canonical.size()));
  auto typed = std::make_shared<const FullOrbitCp09Parameters>(
      FullOrbitCp09Parameters{
          std::move(warmup).value(), std::move(horizon).value(),
          std::move(replications).value(), std::move(population).value(),
          true, std::move(boundaries).value(), gap_mode.value(),
          maximum_rows_native.value(), maximum_bytes_native.value(),
          FullOrbitCp09ProjectionMode::raw_observed,
          std::move(cutoffs).value(), std::nullopt,
          std::move(alpha_values.first), std::move(alpha_values.second)});
  return Result<ValidatedParameterPayloadV1>::success(
      {std::move(bytes), std::move(typed)});
}

Result<FullOrbitCp09AnalysisParametersV1>
full_orbit_cp09_analysis_parameters(
    const ValidatedSurrogateParameters& parameters) {
  auto route = full_orbit_sampler_cp09_hosted_route();
  if (!route) {
    return Result<FullOrbitCp09AnalysisParametersV1>::failure(route.error());
  }
  if (parameters.provider() != route.value().provider ||
      parameters.parameter_schema_version() !=
          route.value().parameter_schema_version ||
      parameters.parameter_schema_digest() !=
          route.value().parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<FullOrbitCp09AnalysisParametersV1>::failure(route_error(
        "c32.full_orbit_cp09_analysis_parameter_binding",
        "analysis options require the exact validated CP09 parameter "
        "carrier"));
  }
  const auto* typed = static_cast<const FullOrbitCp09Parameters*>(
      parameters.typed_value_owner().get());
  return Result<FullOrbitCp09AnalysisParametersV1>::success(
      {typed->projection_cutoffs, typed->warmup_slots,
       typed->horizon_slots, typed->replications,
       typed->population_size,
       typed->gap_telemetry != FullOrbitGapTelemetryMode::disabled});
}

Result<void> validate_full_orbit_k_wide_resolution_binding(
    const TailResolution& resolved_tail,
    const ValidatedParameterPayloadV1& parameters) {
  const FullOrbitKWideParameters* typed = typed_parameters(parameters);
  if (typed == nullptr) {
    return Result<void>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_binding",
        "the K-wide route requires its immutable typed parameter carrier"));
  }
  auto cutoff = resolved_response_cutoff(resolved_tail);
  if (!cutoff) return Result<void>::failure(cutoff.error());
  if (cutoff.value() != typed->response_cutoff) {
    return Result<void>::failure(route_error(
        "c27_1.full_orbit_k_wide_cutoff_mismatch",
        "validated provider response_cutoff must equal the resolved "
        "constant-response tail cutoff",
        "/surrogate/parameters/response_cutoff"));
  }
  return Result<void>::success();
}

Result<void> validate_full_orbit_k_wide_resolution_binding(
    const ProviderIdentityV1& provider,
    const ValidatedSurrogateParameters& parameters,
    const TailResolution& resolved_tail) {
  if (!is_full_orbit_k_wide_provider(provider)) {
    return Result<void>::success();
  }
  auto route = full_orbit_sampler_k_wide_hosted_route();
  if (!route) return Result<void>::failure(route.error());
  if (parameters.provider() != route.value().provider ||
      parameters.parameter_schema_version() !=
          route.value().parameter_schema_version ||
      parameters.parameter_schema_digest() !=
          route.value().parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<void>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_binding",
        "the execution plan does not retain the exact K-wide provider "
        "identity and parameter schema"));
  }
  const auto* typed = static_cast<const FullOrbitKWideParameters*>(
      parameters.typed_value_owner().get());
  auto cutoff = resolved_response_cutoff(resolved_tail);
  if (!cutoff) return Result<void>::failure(cutoff.error());
  if (cutoff.value() != typed->response_cutoff) {
    return Result<void>::failure(route_error(
        "c27_1.full_orbit_k_wide_cutoff_mismatch",
        "the execution plan's provider response_cutoff differs from the "
        "resolved constant-response tail cutoff"));
  }
  return Result<void>::success();
}

Result<void> validate_full_orbit_observation_resolution_binding(
    const ProviderIdentityV1& provider,
    const ValidatedSurrogateParameters& parameters,
    const TailResolution& resolved_tail) {
  if (is_full_orbit_cp09_provider(provider)) {
    auto route = full_orbit_sampler_cp09_hosted_route();
    if (!route) return Result<void>::failure(route.error());
    if (parameters.provider() != route.value().provider ||
        parameters.parameter_schema_version() !=
            route.value().parameter_schema_version ||
        parameters.parameter_schema_digest() !=
            route.value().parameter_schema_digest ||
        !parameters.typed_value_owner()) {
      return Result<void>::failure(route_error(
          "c32.full_orbit_cp09_parameter_binding",
          "the execution plan does not retain the exact CP09 provider "
          "identity and parameter schema"));
    }
    const auto* typed = static_cast<const FullOrbitCp09Parameters*>(
        parameters.typed_value_owner().get());
    if (typed->projection_mode !=
            FullOrbitCp09ProjectionMode::raw_observed ||
        typed->deployment_cutoff.has_value()) {
      return Result<void>::failure(route_error(
          "c32.full_orbit_cp09_projection_binding",
          "raw CP09 parameters must not carry a deployment cutoff"));
    }
    // The analysis grammar still resolves a legacy tail for routes which
    // deploy a surrogate.  CP09 authenticates that input with the complete
    // request but intentionally gives it no construction authority: raw
    // sampling and every RNG address are cutoff-free.
    (void)resolved_tail;
    return Result<void>::success();
  }
  if (!is_full_orbit_observation_provider(provider)) {
    return Result<void>::success();
  }
  auto route = full_orbit_sampler_observation_hosted_route();
  if (!route) return Result<void>::failure(route.error());
  if (parameters.provider() != route.value().provider ||
      parameters.parameter_schema_version() !=
          route.value().parameter_schema_version ||
      parameters.parameter_schema_digest() !=
          route.value().parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_parameter_binding",
        "the execution plan does not retain the exact observation-capable "
        "provider identity and parameter schema"));
  }
  const auto* typed = static_cast<const FullOrbitObservationParameters*>(
      parameters.typed_value_owner().get());
  auto cutoff = resolved_response_cutoff(resolved_tail);
  if (!cutoff) return Result<void>::failure(cutoff.error());
  if (cutoff.value() != typed->response_cutoff) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_cutoff_mismatch",
        "the observation-capable provider response_cutoff differs from the "
        "resolved constant-response tail cutoff"));
  }
  return Result<void>::success();
}

Result<FullOrbitKWideHostedPreviewV1>
preview_full_orbit_k_wide_hosted_route(
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const TailResolution& resolved_tail,
    const ValidatedParameterPayloadV1& parameters) {
  auto route = full_orbit_sampler_k_wide_hosted_route();
  if (!route) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(route.error());
  }
  const FullOrbitKWideParameters* typed = typed_parameters(parameters);
  if (typed == nullptr) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_binding",
        "the hosted preview requires the K-wide typed parameter carrier"));
  }
  auto bound =
      validate_full_orbit_k_wide_resolution_binding(resolved_tail, parameters);
  if (!bound) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(bound.error());
  }
  auto cutoff = resolved_response_cutoff(resolved_tail);
  if (!cutoff) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(cutoff.error());
  }
  if (problem.target_selection().ordered_targets.size() != 1U ||
      problem.timing() != TimingConvention::early_service_late_admission ||
      !supported_pair(problem.applicability_key())) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_applicability",
        "the K-wide route requires one target and a supported exact "
        "scheduler under early-service/late-admission timing"));
  }
  auto geometry = validate_geometry(problem);
  if (!geometry) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(geometry.error());
  }

  // BigNat arithmetic is exact and cannot wrap.  Keeping the factors staged
  // makes the admitted bound visibly the required checked R*P*T product.
  const BigNat population_slots =
      typed->population_size * typed->horizon_slots;
  const BigNat maximum_exact_optimizer_calls =
      typed->replications * population_slots;
  const BigNat maximum_work{kMaximumConstructionWork};
  if (maximum_exact_optimizer_calls > maximum_work) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_work_limit",
        "checked R*P*T exceeds the frozen Full Orbit construction-work "
        "limit"));
  }
  if (budget.schema_version != 1U ||
      budget.exact_optimizer_calls.applicability !=
          BudgetApplicabilityV1::applicable ||
      !budget.exact_optimizer_calls.amount.has_value() ||
      *budget.exact_optimizer_calls.amount < maximum_exact_optimizer_calls ||
      *budget.exact_optimizer_calls.amount > maximum_work) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_insufficient_grant",
        "exact_optimizer_calls must be a bounded applicable grant covering "
        "checked R*P*T within the frozen work limit"));
  }
  if (!not_applicable(budget.optimizer_search_states) ||
      !not_applicable(budget.configured_generator_draws)) {
    return Result<FullOrbitKWideHostedPreviewV1>::failure(route_error(
        "c27_1.full_orbit_k_wide_nonapplicable_grant",
        "optimizer_search_states and configured_generator_draws must both "
        "be NotApplicable for CP07.1"));
  }

  return Result<FullOrbitKWideHostedPreviewV1>::success({
      route.value().provider,
      std::move(cutoff).value(),
      maximum_exact_optimizer_calls,
      {{construction_iid_arrival()}, std::nullopt, std::nullopt,
       std::nullopt},
  });
}

// The registered preview reuses descriptor helpers owned by the optional
// production-provider translation unit.  Keep its definition under the same
// feature gate so the always-built hosted route has no provider-OFF linkage.
#if defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER)
Result<PlugDescriptorPreview> preview_full_orbit_k_wide_registered_route(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters) {
  auto route = full_orbit_sampler_k_wide_hosted_route();
  if (!route) {
    return Result<PlugDescriptorPreview>::failure(route.error());
  }
  if (manifest.provider != route.value().provider ||
      manifest.parameter_schema_version !=
          route.value().parameter_schema_version ||
      manifest.parameter_schema_digest != route.value().parameter_schema_digest ||
      parameters.provider() != manifest.provider ||
      parameters.parameter_schema_version() !=
          manifest.parameter_schema_version ||
      parameters.parameter_schema_digest() != manifest.parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_binding",
        "validated parameters are not bound to the registered CP07.1 "
        "provider schema"));
  }
  const auto* typed = static_cast<const FullOrbitKWideParameters*>(
      parameters.typed_value_owner().get());
  if (typed == nullptr || typed->response_cutoff < BigNat{2U} ||
      typed->response_cutoff > BigNat{5U}) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c27_1.full_orbit_k_wide_parameter_binding",
        "the registered CP07.1 preview requires its immutable K-wide "
        "parameter carrier"));
  }
  if (problem.target_selection().ordered_targets.size() != 1U ||
      problem.timing() != TimingConvention::early_service_late_admission ||
      !supported_pair(problem.applicability_key())) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c27_1.full_orbit_k_wide_applicability",
        "the K-wide route requires one target and a supported exact "
        "scheduler under early-service/late-admission timing"));
  }
  auto geometry = validate_geometry(problem);
  if (!geometry) {
    return Result<PlugDescriptorPreview>::failure(geometry.error());
  }

  const BigNat maximum_exact_optimizer_calls =
      typed->replications *
      (typed->population_size * typed->horizon_slots);
  const BigNat maximum_work{kMaximumConstructionWork};
  if (maximum_exact_optimizer_calls > maximum_work) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c27_1.full_orbit_k_wide_work_limit",
        "checked R*P*T exceeds the frozen Full Orbit construction-work "
        "limit"));
  }
  if (budget.schema_version != 1U ||
      budget.exact_optimizer_calls.applicability !=
          BudgetApplicabilityV1::applicable ||
      !budget.exact_optimizer_calls.amount.has_value() ||
      *budget.exact_optimizer_calls.amount < maximum_exact_optimizer_calls ||
      *budget.exact_optimizer_calls.amount > maximum_work) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c27_1.full_orbit_k_wide_insufficient_grant",
        "exact_optimizer_calls must be a bounded applicable grant covering "
        "checked R*P*T within the frozen work limit"));
  }
  if (!not_applicable(budget.optimizer_search_states) ||
      !not_applicable(budget.configured_generator_draws)) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c27_1.full_orbit_k_wide_nonapplicable_grant",
        "optimizer_search_states and configured_generator_draws must both "
        "be NotApplicable for CP07.1"));
  }

  auto concrete_manifest = specialize_full_orbit_metric_manifest_v1(
      manifest.metric_clause_upper_envelope,
      problem.target_selection().ordered_targets.front());
  if (!concrete_manifest) {
    return Result<PlugDescriptorPreview>::failure(concrete_manifest.error());
  }
  auto core = make_full_orbit_scalar_descriptor_v1(
      manifest, problem, concrete_manifest.value(),
      typed->response_cutoff + BigNat{1U});
  if (!core) return Result<PlugDescriptorPreview>::failure(core.error());
  auto budget_digest = digest_construction_budget_v1(budget);
  if (!budget_digest) {
    return Result<PlugDescriptorPreview>::failure(budget_digest.error());
  }
  auto manifest_owner = std::make_shared<const MetricSupportManifest>(
      std::move(concrete_manifest).value());
  std::vector<QueueId> construction_targets;
  construction_targets.reserve(problem.queues().size());
  for (const auto& queue : problem.queues()) {
    construction_targets.push_back(queue.queue_id);
  }
  PlugDescriptorPreview preview{
      1U,
      std::move(core).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      std::move(construction_targets),
      {PointDeploymentPolicyV1::deploy_raw_point,
       CoefficientCompletionPolicyV1::require_complete_raw_points,
       ProjectionPolicyV1::not_applicable, RecodingPolicyV1::not_applicable,
       EvidenceRolePolicyV1::exact_manifest_roles},
      // R*P*T is the admitted upper bound and mandatory grant, not a
      // minimum successful-work prerequisite: the addressed optimizer cache
      // may make the actual call count smaller.  Keep the generic minimum
      // counters absent, exactly as in the hosted CP07.1 contract.
      {{construction_iid_arrival()}, std::nullopt, std::nullopt,
       std::nullopt},
      std::move(manifest_owner),
      problem.canonical_digest().value(),
      parameters.canonical_value_digest(),
      std::move(budget_digest).value(),
      manifest.manifest_digest};
  auto preview_digest = canonical_plug_descriptor_preview_digest_v1(preview);
  if (!preview_digest) {
    return Result<PlugDescriptorPreview>::failure(preview_digest.error());
  }
  preview.preview_digest = std::move(preview_digest).value();
  return Result<PlugDescriptorPreview>::success(std::move(preview));
}

Result<PlugDescriptorPreview> preview_full_orbit_observation_registered_route(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters) {
  auto route = full_orbit_sampler_observation_hosted_route();
  if (!route) {
    return Result<PlugDescriptorPreview>::failure(route.error());
  }
  if (manifest.provider != route.value().provider ||
      manifest.parameter_schema_version !=
          route.value().parameter_schema_version ||
      manifest.parameter_schema_digest !=
          route.value().parameter_schema_digest ||
      parameters.provider() != manifest.provider ||
      parameters.parameter_schema_version() !=
          manifest.parameter_schema_version ||
      parameters.parameter_schema_digest() !=
          manifest.parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_parameter_binding",
        "validated parameters are not bound to the registered "
        "observation-capable provider schema"));
  }
  const auto* typed = static_cast<const FullOrbitObservationParameters*>(
      parameters.typed_value_owner().get());
  if (typed->response_cutoff < BigNat{2U} ||
      typed->response_cutoff > BigNat{5U}) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_parameter_binding",
        "the observation-capable preview requires its immutable schema-v3 "
        "parameter carrier"));
  }
  if (problem.target_selection().ordered_targets.size() != 1U ||
      problem.timing() != TimingConvention::early_service_late_admission ||
      !supported_pair(problem.applicability_key())) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_applicability",
        "the observation-capable route requires one target and a supported "
        "exact scheduler under early-service/late-admission timing"));
  }
  auto geometry = validate_geometry(problem);
  if (!geometry) {
    return Result<PlugDescriptorPreview>::failure(geometry.error());
  }
  if (typed->emit_observation_record &&
      typed->gap_telemetry == FullOrbitGapTelemetryMode::required &&
      (!zero_solve_gap_probe_supported(problem) ||
       !selected_target_has_unit_multiplier(problem))) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_gap_required_unsupported_topology",
        "required gap telemetry is unavailable for this target geometry or "
        "MaxWeight multiplier; select auto or disable gap telemetry"));
  }
  auto observation_admission =
      validate_observation_admission_bounds(*typed, manifest);
  if (!observation_admission) {
    return Result<PlugDescriptorPreview>::failure(
        observation_admission.error());
  }
  const BigNat maximum_exact_optimizer_calls =
      typed->replications *
      (typed->population_size * typed->horizon_slots);
  const BigNat maximum_work{kMaximumConstructionWork};
  if (maximum_exact_optimizer_calls > maximum_work) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_work_limit",
        "checked R*P*T exceeds the frozen Full Orbit construction-work "
        "limit"));
  }
  if (budget.schema_version != 1U ||
      budget.exact_optimizer_calls.applicability !=
          BudgetApplicabilityV1::applicable ||
      !budget.exact_optimizer_calls.amount.has_value() ||
      *budget.exact_optimizer_calls.amount < maximum_exact_optimizer_calls ||
      *budget.exact_optimizer_calls.amount > maximum_work) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_insufficient_grant",
        "exact_optimizer_calls must cover checked R*P*T within the frozen "
        "work limit"));
  }
  if (!not_applicable(budget.optimizer_search_states) ||
      !not_applicable(budget.configured_generator_draws)) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c30.full_orbit_observation_nonapplicable_grant",
        "optimizer_search_states and configured_generator_draws must both "
        "be NotApplicable for the Full Orbit route"));
  }

  auto concrete_manifest = specialize_full_orbit_metric_manifest_v1(
      manifest.metric_clause_upper_envelope,
      problem.target_selection().ordered_targets.front());
  if (!concrete_manifest) {
    return Result<PlugDescriptorPreview>::failure(concrete_manifest.error());
  }
  auto core = make_full_orbit_scalar_descriptor_v1(
      manifest, problem, concrete_manifest.value(),
      typed->response_cutoff + BigNat{1U});
  if (!core) return Result<PlugDescriptorPreview>::failure(core.error());
  auto budget_digest = digest_construction_budget_v1(budget);
  if (!budget_digest) {
    return Result<PlugDescriptorPreview>::failure(budget_digest.error());
  }
  auto manifest_owner = std::make_shared<const MetricSupportManifest>(
      std::move(concrete_manifest).value());
  std::vector<QueueId> construction_targets;
  construction_targets.reserve(problem.queues().size());
  for (const auto& queue : problem.queues()) {
    construction_targets.push_back(queue.queue_id);
  }
  PlugDescriptorPreview preview{
      1U,
      std::move(core).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      std::move(construction_targets),
      {PointDeploymentPolicyV1::deploy_raw_point,
       CoefficientCompletionPolicyV1::require_complete_raw_points,
       ProjectionPolicyV1::not_applicable, RecodingPolicyV1::not_applicable,
       EvidenceRolePolicyV1::exact_manifest_roles},
      {{construction_iid_arrival()}, std::nullopt, std::nullopt,
       std::nullopt},
      std::move(manifest_owner),
      problem.canonical_digest().value(),
      parameters.canonical_value_digest(),
      std::move(budget_digest).value(),
      manifest.manifest_digest};
  auto preview_digest = canonical_plug_descriptor_preview_digest_v1(preview);
  if (!preview_digest) {
    return Result<PlugDescriptorPreview>::failure(preview_digest.error());
  }
  preview.preview_digest = std::move(preview_digest).value();
  return Result<PlugDescriptorPreview>::success(std::move(preview));
}

Result<PlugDescriptorPreview> preview_full_orbit_cp09_registered_route(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters) {
  auto route = full_orbit_sampler_cp09_hosted_route();
  if (!route) return Result<PlugDescriptorPreview>::failure(route.error());
  if (manifest.provider != route.value().provider ||
      manifest.parameter_schema_version !=
          route.value().parameter_schema_version ||
      manifest.parameter_schema_digest !=
          route.value().parameter_schema_digest ||
      parameters.provider() != manifest.provider ||
      parameters.parameter_schema_version() !=
          manifest.parameter_schema_version ||
      parameters.parameter_schema_digest() !=
          manifest.parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c32.full_orbit_cp09_parameter_binding",
        "validated parameters are not bound to the registered CP09 route"));
  }
  const auto* typed = static_cast<const FullOrbitCp09Parameters*>(
      parameters.typed_value_owner().get());
  if (typed->projection_mode != FullOrbitCp09ProjectionMode::raw_observed ||
      typed->deployment_cutoff.has_value() ||
      typed->projection_cutoffs.empty() || !typed->emit_observation) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c32.full_orbit_cp09_parameter_binding",
        "the CP09 preview requires a nonempty cutoff list and cutoff-free "
        "raw observation mode"));
  }
  if (problem.target_selection().ordered_targets.size() != 1U ||
      problem.timing() != TimingConvention::early_service_late_admission ||
      !supported_pair(problem.applicability_key())) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c32.full_orbit_cp09_applicability",
        "CP09 requires one target and a supported exact scheduler under "
        "early-service/late-admission timing"));
  }
  if (typed->gap_telemetry == FullOrbitGapTelemetryMode::required &&
      !selected_target_has_unit_multiplier(problem)) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c32.full_orbit_cp09_gap_required_unsupported_topology",
        "required exact gap telemetry needs a unit target MaxWeight "
        "multiplier"));
  }

  // Reuse the already reviewed allocation/work admission mathematics.  The
  // legacy cutoff and alpha members in this local carrier are not observed by
  // that routine and acquire no CP09 authority.
  const FullOrbitObservationParameters admission{
      typed->warmup_slots,
      typed->horizon_slots,
      typed->replications,
      typed->population_size,
      BigNat{2U},
      typed->alpha_numerator,
      typed->alpha_denominator,
      true,
      typed->reporting_block_boundaries,
      typed->gap_telemetry,
      typed->maximum_observation_rows_per_replication,
      typed->maximum_observation_bytes};
  auto measured_slots =
      checked_subtract(typed->horizon_slots, typed->warmup_slots);
  if (!measured_slots) {
    return Result<PlugDescriptorPreview>::failure(measured_slots.error());
  }
  const BigNat block_count{static_cast<std::uint64_t>(
      typed->reporting_block_boundaries.size() - 1U)};
  // Each particle can contribute at most one newly visited level per
  // measured slot.  Each block carries two boundary laws, each with at most P
  // distinct rows.  This attainable ceiling, rather than the authored safety
  // cap alone, is what the parser and accumulator can ever receive.
  const BigNat attainable_rows_per_replication =
      typed->population_size * measured_slots.value() +
      BigNat{2U} * typed->population_size * block_count;
  auto observation_admission =
      validate_observation_admission_bounds(
          admission, manifest, attainable_rows_per_replication);
  if (!observation_admission) {
    return Result<PlugDescriptorPreview>::failure(
        observation_admission.error());
  }
  const bool exact_opposite_face_gap =
      typed->gap_telemetry != FullOrbitGapTelemetryMode::disabled &&
      selected_target_has_unit_multiplier(problem) &&
      !zero_solve_gap_probe_supported(problem);
  const BigNat maximum_exact_optimizer_calls =
      typed->replications * typed->population_size *
      (typed->horizon_slots +
       (exact_opposite_face_gap ? measured_slots.value() : BigNat{0U}));
  if (budget.schema_version != 1U ||
      budget.exact_optimizer_calls.applicability !=
          BudgetApplicabilityV1::applicable ||
      !budget.exact_optimizer_calls.amount.has_value() ||
      *budget.exact_optimizer_calls.amount < maximum_exact_optimizer_calls) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c32.full_orbit_cp09_insufficient_grant",
        "exact_optimizer_calls must cover the checked physical-plus-gap "
        "bound"));
  }
  if (!not_applicable(budget.optimizer_search_states) ||
      !not_applicable(budget.configured_generator_draws)) {
    return Result<PlugDescriptorPreview>::failure(route_error(
        "c32.full_orbit_cp09_nonapplicable_grant",
        "optimizer_search_states and configured_generator_draws must both "
        "be NotApplicable for the hosted CP09 route"));
  }

  auto concrete_manifest = specialize_full_orbit_metric_manifest_v1(
      manifest.metric_clause_upper_envelope,
      problem.target_selection().ordered_targets.front());
  if (!concrete_manifest) {
    return Result<PlugDescriptorPreview>::failure(concrete_manifest.error());
  }
  // C14 still requires a scalar-response capability descriptor even though
  // provider-result-v3 can only return Observed.  Use its smallest legacy
  // neutral boundary, independent of every authored projection cutoff.  This
  // prevents K (including K=0) from acquiring planning or trajectory
  // authority while preserving the existing metric-contract vocabulary.
  auto core = make_full_orbit_scalar_descriptor_v1(
      manifest, problem, concrete_manifest.value(), BigNat{3U});
  if (!core) return Result<PlugDescriptorPreview>::failure(core.error());
  auto budget_digest = digest_construction_budget_v1(budget);
  if (!budget_digest) {
    return Result<PlugDescriptorPreview>::failure(budget_digest.error());
  }
  auto manifest_owner = std::make_shared<const MetricSupportManifest>(
      std::move(concrete_manifest).value());
  std::vector<QueueId> construction_targets;
  construction_targets.reserve(problem.queues().size());
  for (const auto& queue : problem.queues()) {
    construction_targets.push_back(queue.queue_id);
  }
  PlugDescriptorPreview preview{
      1U,
      std::move(core).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      std::move(construction_targets),
      {PointDeploymentPolicyV1::deploy_raw_point,
       CoefficientCompletionPolicyV1::require_complete_raw_points,
       ProjectionPolicyV1::not_applicable, RecodingPolicyV1::not_applicable,
       EvidenceRolePolicyV1::exact_manifest_roles},
      {{construction_iid_arrival()}, std::nullopt, std::nullopt,
       std::nullopt},
      std::move(manifest_owner),
      problem.canonical_digest().value(),
      parameters.canonical_value_digest(),
      std::move(budget_digest).value(),
      manifest.manifest_digest};
  auto preview_digest = canonical_plug_descriptor_preview_digest_v1(preview);
  if (!preview_digest) {
    return Result<PlugDescriptorPreview>::failure(preview_digest.error());
  }
  preview.preview_digest = std::move(preview_digest).value();
  return Result<PlugDescriptorPreview>::success(std::move(preview));
}
#endif

Result<void> validate_full_orbit_observation_arrival_context(
    const FrameworkProblemView& problem,
    const ResolvedInstance& resolved_instance,
    const CompiledArrivalLaw& compiled_arrival_law) {
  const ArrivalBinding& arrival =
      arrival_law_binding(compiled_arrival_law);
  const BuilderArrivalView& authenticated_arrival =
      problem.configured_arrival();
  auto catalog_digest =
      mwperf::detail::digest_queue_catalog(resolved_instance.queues());
  if (!catalog_digest) {
    return Result<void>::failure(catalog_digest.error());
  }
  if (authenticated_arrival.digest().value() !=
          problem.fingerprints().compiled_arrival ||
      arrival != authenticated_arrival.binding() ||
      arrival.catalog_digest != catalog_digest.value() ||
      arrival.queue_cardinality != resolved_instance.queues().size() ||
      arrival.timing != resolved_instance.timing()) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_arrival_context",
        "the compiled arrival law is not bound to the authenticated problem "
        "and resolved queue catalog"));
  }
  const ArrivalCapabilities& capabilities =
      authenticated_arrival.capabilities();
  const bool portable_exact_iid =
      (capabilities.exact_iid_joint_vector.has_value() &&
       capabilities.exact_iid_joint_vector->finite_support &&
       capabilities.exact_iid_joint_vector->provision ==
           AccessProvision::portable_only) ||
      (capabilities.exact_factorized_iid_generator.has_value() &&
       capabilities.exact_factorized_iid_generator->provision ==
           AccessProvision::portable_only) ||
      (capabilities.exact_portable_iid_recipe.has_value() &&
       capabilities.exact_portable_iid_recipe->provision ==
           AccessProvision::portable_only);
  if (!portable_exact_iid) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_exact_iid_recipe_missing",
        "the Full Orbit observation route requires an authenticated exact "
        "portable IID late-arrival representation"));
  }
  return Result<void>::success();
}

struct Cp09ExpectedTargetArrival final {
  TargetArrivalDescriptionV1 description;
  ExactRational mean;
  ExactRational second_moment;
  bool finite_exact_marginal;
};

[[nodiscard]] Result<std::pair<ExactRational, ExactRational>>
cp09_target_moments(const BuilderArrivalView& arrival,
                    const DenseQueueIndex target) {
  if (!arrival.moments().has_value()) {
    return Result<std::pair<ExactRational, ExactRational>>::failure(
        route_error("c32.full_orbit_cp09_target_moments_missing",
                    "the portable IID recipe has no exact target moments"));
  }
  const auto matches = [&](const ExactMomentDatum& datum,
                           const std::uint64_t order) {
    return datum.order == BigNat{order} && datum.coordinates.size() == 1U &&
           datum.coordinates.front() == target;
  };
  const auto& moments = *arrival.moments();
  const auto first = std::ranges::find_if(
      moments, [&](const ExactMomentDatum& datum) {
        return matches(datum, 1U);
      });
  const auto second = std::ranges::find_if(
      moments, [&](const ExactMomentDatum& datum) {
        return matches(datum, 2U);
      });
  if (first == moments.end() || second == moments.end() ||
      std::ranges::count_if(moments, [&](const ExactMomentDatum& datum) {
        return matches(datum, 1U);
      }) != 1 ||
      std::ranges::count_if(moments, [&](const ExactMomentDatum& datum) {
        return matches(datum, 2U);
      }) != 1) {
    return Result<std::pair<ExactRational, ExactRational>>::failure(
        route_error("c32.full_orbit_cp09_target_moments_ambiguous",
                    "the portable IID recipe must carry exactly one first "
                    "and second target moment"));
  }
  return Result<std::pair<ExactRational, ExactRational>>::success(
      {first->value, second->value});
}

[[nodiscard]] Result<ExactTargetArrivalMarginalV1>
cp09_joint_table_target_marginal(const BuilderArrivalView& arrival,
                                 const DenseQueueIndex target) {
  if (!arrival.iid_joint_table().has_value() ||
      arrival.iid_joint_table()->empty()) {
    return Result<ExactTargetArrivalMarginalV1>::failure(route_error(
        "c32.full_orbit_cp09_joint_table_missing",
        "the portable IID recipe has no finite joint count table"));
  }
  std::vector<ExactTargetArrivalAtomV1> atoms;
  for (const ExactJointBatchMass& outcome : *arrival.iid_joint_table()) {
    if (target.ordinal() >= outcome.dense_counts.size()) {
      return Result<ExactTargetArrivalMarginalV1>::failure(route_error(
          "c32.full_orbit_cp09_joint_table_target_range",
          "a portable IID outcome omits the selected target coordinate"));
    }
    const BigNat& count = outcome.dense_counts[target.ordinal()];
    const auto existing = std::ranges::find_if(
        atoms, [&](const ExactTargetArrivalAtomV1& atom) {
          return atom.batch_size == count;
        });
    if (existing == atoms.end()) {
      atoms.push_back({count, outcome.probability});
    } else {
      existing->probability = existing->probability + outcome.probability;
    }
  }
  std::ranges::sort(atoms, {}, &ExactTargetArrivalAtomV1::batch_size);
  return Result<ExactTargetArrivalMarginalV1>::success(
      {std::move(atoms)});
}

class Cp09PortableRecipeReader final {
 public:
  explicit Cp09PortableRecipeReader(const std::span<const std::byte> bytes)
      : bytes_(bytes) {}

  [[nodiscard]] bool read_u8(std::uint8_t& value) noexcept {
    if (offset_ == bytes_.size()) return false;
    value = std::to_integer<std::uint8_t>(bytes_[offset_++]);
    return true;
  }

  [[nodiscard]] bool read_u32(std::uint32_t& value) noexcept {
    if (bytes_.size() - offset_ < 4U) return false;
    value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
      value = static_cast<std::uint32_t>(
          (value << 8U) |
          std::to_integer<std::uint8_t>(bytes_[offset_ + index]));
    }
    offset_ += 4U;
    return true;
  }

  [[nodiscard]] bool read_u64(std::uint64_t& value) noexcept {
    if (bytes_.size() - offset_ < 8U) return false;
    value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
      value = (value << 8U) |
              std::to_integer<std::uint8_t>(bytes_[offset_ + index]);
    }
    offset_ += 8U;
    return true;
  }

  [[nodiscard]] bool read_bytes(std::span<const std::byte>& value) noexcept {
    std::uint64_t length = 0U;
    if (!read_u64(length) ||
        length > static_cast<std::uint64_t>(bytes_.size() - offset_)) {
      return false;
    }
    const std::size_t native_length = static_cast<std::size_t>(length);
    value = bytes_.subspan(offset_, native_length);
    offset_ += native_length;
    return true;
  }

  [[nodiscard]] bool read_string(std::string_view& value) noexcept {
    std::span<const std::byte> bytes;
    if (!read_bytes(bytes)) return false;
    value = std::string_view(
        reinterpret_cast<const char*>(bytes.data()), bytes.size());
    return true;
  }

  [[nodiscard]] bool read_rational_text(std::string_view& numerator,
                                        std::string_view& denominator) noexcept {
    return read_string(numerator) && read_string(denominator) &&
           !numerator.empty() && !denominator.empty();
  }

  [[nodiscard]] bool exhausted() const noexcept {
    return offset_ == bytes_.size();
  }

 private:
  std::span<const std::byte> bytes_;
  std::size_t offset_{0U};
};

void cp09_append_u32(std::vector<std::byte>& output,
                     const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void cp09_append_u64(std::vector<std::byte>& output,
                     const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void cp09_append_text(std::vector<std::byte>& output,
                      const std::string_view value) {
  cp09_append_u64(output, static_cast<std::uint64_t>(value.size()));
  output.insert(output.end(),
                reinterpret_cast<const std::byte*>(value.data()),
                reinterpret_cast<const std::byte*>(value.data() + value.size()));
}

void cp09_append_digest(std::vector<std::byte>& output,
                        const Digest256& digest) {
  const auto bytes = digest.bytes();
  output.insert(output.end(), bytes.begin(), bytes.end());
}

struct Cp09DecodedPoissonRecipe final {
  std::vector<ExactRational> weights;
  std::vector<ExactRational> component_rates;
  std::vector<std::uint64_t> operational_rate_bits;
};

[[nodiscard]] std::optional<ExactRational> cp09_decode_exact_rational(
    const std::string_view numerator, const std::string_view denominator) {
  try {
    auto value = ExactRational::make(BigInt(std::string(numerator)),
                                     BigInt(std::string(denominator)));
    if (!value || value.value().numerator_decimal() != numerator ||
        value.value().denominator_decimal() != denominator) {
      return std::nullopt;
    }
    return std::move(value).value();
  } catch (...) {
    return std::nullopt;
  }
}

[[nodiscard]] Result<Cp09DecodedPoissonRecipe>
cp09_decode_target_poisson_recipe(const BuilderArrivalView& arrival,
                                  const DenseQueueIndex target) {
  constexpr std::string_view kEnvelopeDomain =
      "mwperf.c09.compiled_arrival_with_normalized_rows.v1";
  constexpr std::string_view kIndependentDomain =
      "mwperf.c32.iid_independent_poisson.v1";
  constexpr std::string_view kMixedDomain =
      "mwperf.c32.iid_mixed_poisson.v1";
  const auto malformed = []() {
    return Result<Cp09DecodedPoissonRecipe>::failure(route_error(
        "c32.full_orbit_cp09_poisson_recipe_shape",
        "the portable Poisson recipe is not the canonical CP09 framed "
        "binary representation"));
  };

  Cp09PortableRecipeReader envelope(arrival.configured_law().canonical_data);
  std::string_view envelope_domain;
  std::span<const std::byte> child_bytes;
  std::uint64_t normalized_row_count = 0U;
  if (!envelope.read_string(envelope_domain) ||
      envelope_domain != kEnvelopeDomain ||
      !envelope.read_bytes(child_bytes) ||
      !envelope.read_u64(normalized_row_count) || normalized_row_count != 0U ||
      !envelope.exhausted()) {
    return malformed();
  }

  Cp09PortableRecipeReader child(child_bytes);
  std::string_view child_domain;
  std::uint32_t version = 0U;
  std::uint64_t queue_count = 0U;
  if (!child.read_string(child_domain) || !child.read_u32(version) ||
      version != 1U || !child.read_u64(queue_count) ||
      queue_count != arrival.binding().queue_cardinality ||
      target.ordinal() >= queue_count) {
    return malformed();
  }

  if (arrival.configured_law().schema ==
      PortableArrivalLawSchema::iid_independent_poisson_v1) {
    if (child_domain != kIndependentDomain) return malformed();
    std::optional<ExactRational> target_rate;
    std::uint64_t target_bits = 0U;
    for (std::uint64_t queue = 0U; queue < queue_count; ++queue) {
      std::string_view numerator;
      std::string_view denominator;
      std::uint64_t operational_bits = 0U;
      if (!child.read_rational_text(numerator, denominator) ||
          !child.read_u64(operational_bits)) {
        return malformed();
      }
      if (queue == target.ordinal()) {
        target_rate = cp09_decode_exact_rational(numerator, denominator);
        target_bits = operational_bits;
      }
    }
    if (!child.exhausted() || !target_rate.has_value() ||
        *target_rate < ExactRational::zero()) {
      return malformed();
    }
    return Result<Cp09DecodedPoissonRecipe>::success(
        {{ExactRational::one()}, {std::move(*target_rate)}, {target_bits}});
  }

  if (arrival.configured_law().schema !=
          PortableArrivalLawSchema::iid_mixed_poisson_v1 ||
      child_domain != kMixedDomain) {
    return malformed();
  }
  std::uint8_t scope = 0U;
  std::uint64_t state_count = 0U;
  if (!child.read_u8(scope) || scope > 1U || !child.read_u64(state_count) ||
      state_count == 0U || state_count > child_bytes.size()) {
    return malformed();
  }
  std::vector<ExactRational> weights;
  std::vector<ExactRational> multipliers;
  weights.reserve(static_cast<std::size_t>(state_count));
  multipliers.reserve(static_cast<std::size_t>(state_count));
  std::set<std::string, std::less<>> state_ids;
  ExactRational total_weight = ExactRational::zero();
  ExactRational weighted_multiplier = ExactRational::zero();
  for (std::uint64_t state = 0U; state < state_count; ++state) {
    std::string_view state_id;
    std::string_view weight_numerator;
    std::string_view weight_denominator;
    std::string_view multiplier_numerator;
    std::string_view multiplier_denominator;
    if (!child.read_string(state_id) || state_id.empty() ||
        !state_ids.emplace(state_id).second ||
        !child.read_rational_text(weight_numerator, weight_denominator) ||
        !child.read_rational_text(multiplier_numerator,
                                  multiplier_denominator)) {
      return malformed();
    }
    auto weight =
        cp09_decode_exact_rational(weight_numerator, weight_denominator);
    auto multiplier = cp09_decode_exact_rational(multiplier_numerator,
                                                  multiplier_denominator);
    if (!weight.has_value() || *weight < ExactRational::zero() ||
        !multiplier.has_value() ||
        *multiplier < ExactRational::zero()) {
      return malformed();
    }
    try {
      total_weight = total_weight + *weight;
      weighted_multiplier =
          weighted_multiplier + (*weight * *multiplier);
    } catch (...) {
      return Result<Cp09DecodedPoissonRecipe>::failure(route_error(
          "c32.full_orbit_cp09_poisson_recipe_arithmetic",
          "exact mixed-Poisson normalization exhausted arithmetic "
          "resources"));
    }
    weights.push_back(std::move(*weight));
    multipliers.push_back(std::move(*multiplier));
  }
  if (total_weight != ExactRational::one() ||
      weighted_multiplier != ExactRational::one()) {
    return malformed();
  }
  std::optional<ExactRational> target_base_rate;
  for (std::uint64_t queue = 0U; queue < queue_count; ++queue) {
    std::string_view numerator;
    std::string_view denominator;
    if (!child.read_rational_text(numerator, denominator)) return malformed();
    if (queue == target.ordinal()) {
      target_base_rate = cp09_decode_exact_rational(numerator, denominator);
    }
  }
  std::vector<std::uint64_t> bits;
  bits.reserve(static_cast<std::size_t>(state_count));
  for (std::uint64_t queue = 0U; queue < queue_count; ++queue) {
    for (std::uint64_t state = 0U; state < state_count; ++state) {
      std::uint64_t operational_bits = 0U;
      if (!child.read_u64(operational_bits)) return malformed();
      if (queue == target.ordinal()) bits.push_back(operational_bits);
    }
  }
  if (!child.exhausted() || bits.size() != state_count ||
      !target_base_rate.has_value() ||
      *target_base_rate < ExactRational::zero()) {
    return malformed();
  }
  std::vector<ExactRational> component_rates;
  component_rates.reserve(multipliers.size());
  try {
    for (const ExactRational& multiplier : multipliers) {
      component_rates.push_back(*target_base_rate * multiplier);
    }
  } catch (...) {
    return Result<Cp09DecodedPoissonRecipe>::failure(route_error(
        "c32.full_orbit_cp09_poisson_recipe_arithmetic",
        "exact target Poisson mixture projection exhausted arithmetic "
        "resources"));
  }
  return Result<Cp09DecodedPoissonRecipe>::success(
      {std::move(weights), std::move(component_rates), std::move(bits)});
}

[[nodiscard]] Result<Digest256> cp09_poisson_operational_parameter_digest(
    const DenseQueueIndex target,
    const std::span<const std::uint64_t> rate_bits) {
  if (!std::in_range<std::uint32_t>(target.ordinal())) {
    return Result<Digest256>::failure(route_error(
        "c32.full_orbit_cp09_poisson_target_range",
        "the selected target ordinal exceeds the registered descriptor "
        "coordinate domain"));
  }
  std::vector<std::byte> operational_preimage;
  cp09_append_u32(operational_preimage,
                  static_cast<std::uint32_t>(target.ordinal()));
  cp09_append_u64(operational_preimage,
                  static_cast<std::uint64_t>(rate_bits.size()));
  for (const std::uint64_t bits : rate_bits) {
    cp09_append_u64(operational_preimage, bits);
  }
  return sha256_domain_separated(
      "mwperf.cp09.target_arrival_operational_parameters.v1",
      operational_preimage);
}

[[nodiscard]] Result<Digest256> cp09_poisson_overshoot_descriptor_digest(
    const std::string_view descriptor_id, const BuilderArrivalView& arrival,
    const DenseQueueIndex target, const Digest256& operational_digest) {
  constexpr std::string_view kSamplerId =
      "mwperf.addressed_poisson.inversion_ptrs.v1";
  constexpr std::uint32_t kSamplerVersion = 1U;
  constexpr std::uint64_t kMaximumUniformWordsPerVariate =
      std::numeric_limits<std::uint64_t>::max();
  std::vector<std::byte> descriptor_preimage;
  cp09_append_text(descriptor_preimage, descriptor_id);
  cp09_append_digest(descriptor_preimage, arrival.binding().law_digest.value());
  cp09_append_u32(descriptor_preimage,
                  static_cast<std::uint32_t>(target.ordinal()));
  cp09_append_text(descriptor_preimage, kSamplerId);
  cp09_append_u32(descriptor_preimage, kSamplerVersion);
  cp09_append_u64(descriptor_preimage, kMaximumUniformWordsPerVariate);
  cp09_append_digest(descriptor_preimage, operational_digest);
  return sha256_domain_separated(
      "mwperf.cp09.target_arrival_overshoot_descriptor.v1",
      descriptor_preimage);
}

[[nodiscard]] Result<FullOrbitCp09PoissonTargetLawV1>
cp09_poisson_target_law(const BuilderArrivalView& arrival,
                        const DenseQueueIndex target) {
  const PortableArrivalLawSchema schema = arrival.configured_law().schema;
  const std::string_view descriptor_id =
      schema == PortableArrivalLawSchema::iid_independent_poisson_v1
          ? "iid_independent_poisson_overshoot_v1"
          : "iid_mixed_poisson_overshoot_v1";
  auto decoded = cp09_decode_target_poisson_recipe(arrival, target);
  if (!decoded) {
    return Result<FullOrbitCp09PoissonTargetLawV1>::failure(decoded.error());
  }
  if (decoded.value().weights.size() !=
          decoded.value().component_rates.size() ||
      decoded.value().weights.size() !=
          decoded.value().operational_rate_bits.size() ||
      decoded.value().weights.empty()) {
    return Result<FullOrbitCp09PoissonTargetLawV1>::failure(route_error(
        "c32.full_orbit_cp09_poisson_component_shape",
        "the exact and operational target Poisson components differ in "
        "cardinality"));
  }
  auto operational_digest = cp09_poisson_operational_parameter_digest(
      target, decoded.value().operational_rate_bits);
  if (!operational_digest) {
    return Result<FullOrbitCp09PoissonTargetLawV1>::failure(
        operational_digest.error());
  }
  auto descriptor_digest = cp09_poisson_overshoot_descriptor_digest(
      descriptor_id, arrival, target, operational_digest.value());
  if (!descriptor_digest) {
    return Result<FullOrbitCp09PoissonTargetLawV1>::failure(
        descriptor_digest.error());
  }
  std::vector<FullOrbitCp09PoissonComponentV1> components;
  components.reserve(decoded.value().weights.size());
  for (std::size_t index = 0U; index < decoded.value().weights.size();
       ++index) {
    components.push_back(
        {std::move(decoded.value().weights[index]),
         std::move(decoded.value().component_rates[index]),
         decoded.value().operational_rate_bits[index]});
  }
  return Result<FullOrbitCp09PoissonTargetLawV1>::success(
      {std::string(descriptor_id), 1U, std::move(components),
       std::move(operational_digest).value(),
       std::move(descriptor_digest).value()});
}

Result<std::optional<FullOrbitCp09PoissonTargetLawV1>>
full_orbit_cp09_poisson_target_law(
    const CompiledArrivalLaw& compiled_arrival_law,
    const DenseQueueIndex target) {
  const BuilderArrivalView arrival =
      builder_arrival_view(compiled_arrival_law);
  const PortableArrivalLawSchema schema = arrival.configured_law().schema;
  if (schema != PortableArrivalLawSchema::iid_independent_poisson_v1 &&
      schema != PortableArrivalLawSchema::iid_mixed_poisson_v1) {
    return Result<std::optional<FullOrbitCp09PoissonTargetLawV1>>::success(
        std::nullopt);
  }
  auto law = cp09_poisson_target_law(arrival, target);
  if (!law) {
    return Result<std::optional<FullOrbitCp09PoissonTargetLawV1>>::failure(
        law.error());
  }
  return Result<std::optional<FullOrbitCp09PoissonTargetLawV1>>::success(
      std::optional<FullOrbitCp09PoissonTargetLawV1>{
          std::move(law).value()});
}

[[nodiscard]] Result<Cp09ExpectedTargetArrival>
cp09_expected_target_arrival(const CompiledArrivalLaw& compiled,
                             const DenseQueueIndex target) {
  const BuilderArrivalView arrival = builder_arrival_view(compiled);
  const PortableArrivalLawSchema schema = arrival.configured_law().schema;
  if (schema == PortableArrivalLawSchema::independent_marked_renewal_v1 &&
      arrival.capabilities().exact_factorized_iid_generator.has_value()) {
    auto projected =
        project_exact_factorized_iid_target_pmf(compiled, target);
    if (!projected) {
      return Result<Cp09ExpectedTargetArrival>::failure(
          projected.error());
    }
    ExactTargetArrivalMarginalV1 marginal;
    marginal.atoms.reserve(projected.value().size());
    ExactRational mean = ExactRational::zero();
    ExactRational second_moment = ExactRational::zero();
    for (const ExactTargetIidBatchMass& atom : projected.value()) {
      auto count = ExactRational::make(atom.count.value(), BigInt{1});
      if (!count) {
        return Result<Cp09ExpectedTargetArrival>::failure(count.error());
      }
      marginal.atoms.push_back({atom.count, atom.probability});
      mean = mean + count.value() * atom.probability;
      second_moment = second_moment +
                      count.value() * count.value() * atom.probability;
    }
    return Result<Cp09ExpectedTargetArrival>::success(
        {std::move(marginal), std::move(mean),
         std::move(second_moment), true});
  }

  auto moments = cp09_target_moments(arrival, target);
  if (!moments) {
    return Result<Cp09ExpectedTargetArrival>::failure(moments.error());
  }
  const auto& [mean, second_moment] = moments.value();
  if (schema == PortableArrivalLawSchema::iid_independent_poisson_v1 ||
      schema == PortableArrivalLawSchema::iid_mixed_poisson_v1) {
    auto target_law = cp09_poisson_target_law(arrival, target);
    if (!target_law) {
      return Result<Cp09ExpectedTargetArrival>::failure(
          target_law.error());
    }
    return Result<Cp09ExpectedTargetArrival>::success(
        {TargetArrivalOvershootDescriptorV1{
             target_law.value().descriptor_id,
             target_law.value().descriptor_version,
             target_law.value().descriptor_digest},
         mean, second_moment, false});
  }

  if (arrival.iid_joint_table().has_value()) {
    auto marginal = cp09_joint_table_target_marginal(arrival, target);
    if (!marginal) {
      return Result<Cp09ExpectedTargetArrival>::failure(marginal.error());
    }
    return Result<Cp09ExpectedTargetArrival>::success(
        {std::move(marginal).value(), mean, second_moment, true});
  }
  if (schema == PortableArrivalLawSchema::iid_independent_bernoulli_v1) {
    if (mean < ExactRational::zero() || mean > ExactRational::one() ||
        second_moment != mean) {
      return Result<Cp09ExpectedTargetArrival>::failure(route_error(
          "c32.full_orbit_cp09_bernoulli_moment_contract",
          "a Bernoulli target recipe must have 0<=mean<=1 and E[A^2]=E[A]"));
    }
    std::vector<ExactTargetArrivalAtomV1> atoms;
    const ExactRational zero_probability = ExactRational::one() - mean;
    if (zero_probability.is_positive()) {
      atoms.push_back({BigNat{0U}, zero_probability});
    }
    if (mean.is_positive()) atoms.push_back({BigNat{1U}, mean});
    return Result<Cp09ExpectedTargetArrival>::success(
        {ExactTargetArrivalMarginalV1{std::move(atoms)}, mean,
         second_moment, true});
  }

  auto projected = project_exact_factorized_iid_target_pmf(compiled, target);
  if (!projected) {
    return Result<Cp09ExpectedTargetArrival>::failure(projected.error());
  }
  ExactTargetArrivalMarginalV1 marginal;
  marginal.atoms.reserve(projected.value().size());
  for (const ExactTargetIidBatchMass& atom : projected.value()) {
    marginal.atoms.push_back({atom.count, atom.probability});
  }
  return Result<Cp09ExpectedTargetArrival>::success(
      {std::move(marginal), mean, second_moment, true});
}

Result<void> validate_full_orbit_observation_envelope(
    const ObservationEnvelopeValidationContextV1& context,
    const ValidatedConstructionObservationBundleV1* observation) {
  auto route = full_orbit_sampler_observation_hosted_route();
  if (!route) return Result<void>::failure(route.error());
  if (context.envelope.protocol_version != 2U ||
      context.envelope.provider != route.value().provider ||
      context.request.provider_binding().provider != route.value().provider ||
      context.envelope.request_digest !=
          context.request.request_digest().value() ||
      context.parameters.provider() != route.value().provider ||
      context.parameters.parameter_schema_version() !=
          route.value().parameter_schema_version ||
      context.parameters.parameter_schema_digest() !=
          route.value().parameter_schema_digest ||
      !context.parameters.typed_value_owner() ||
      !std::equal(context.request.validated_parameters().begin(),
                  context.request.validated_parameters().end(),
                  context.parameters.canonical_value_bytes().begin(),
                  context.parameters.canonical_value_bytes().end())) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_context_binding",
        "the result, request and private parameters do not select one exact "
        "observation-capable Full Orbit route"));
  }
  const auto* parameters =
      static_cast<const FullOrbitObservationParameters*>(
          context.parameters.typed_value_owner().get());
  const bool has_observation = observation != nullptr;
  if (has_observation != context.observation_was_present) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_validation_order",
        "the semantic observation carrier does not match the presence "
        "captured before raw-sidecar validation"));
  }

  const auto& components =
      context.envelope.build_report.optional_component_digests;
  if (!parameters->emit_observation_record) {
    if (has_observation || !components.empty()) {
      return Result<void>::failure(route_error(
          "c30.full_orbit_observation_disabled_presence",
          "the route must omit both observation fields and component "
          "digests when emit_observation_record is false"));
    }
    return Result<void>::success();
  }
  if (!has_observation || components.size() != 1U ||
      components.front().component_name != kObservationComponentName ||
      components.front().component_digest != observation->digest()) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_component_binding",
        "every result branch must bind the authenticated observation digest "
        "through the sole canonical build-report component"));
  }

  const ConstructionObservationBundleV1& bundle = observation->value();
  const FrameworkProblemView& problem =
      context.request.framework_problem_view();
  const DerivedServiceIdentity service =
      context.resolved_instance.service_identity();
  if (context.resolved_instance.fingerprints() !=
          problem.fingerprints().authored_inputs ||
      problem.applicability_key() !=
          SchedulerConstraintPairV1{service.family, service.optimizer} ||
      context.resolved_instance.timing() != problem.timing()) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_problem_context",
        "the resolved instance differs from the authenticated framework "
        "problem used by the provider request"));
  }
  if (bundle.schema_version != 1U ||
      bundle.source_role != ObservationSourceRoleV1::weighted_ensemble ||
      bundle.scalar_representation !=
          ObservationScalarRepresentationV1::enclosed_binary64 ||
      bundle.bindings.request_digest !=
          context.request.request_digest().value() ||
      bundle.bindings.problem_digest != problem.canonical_digest().value() ||
      bundle.warmup_boundary !=
          parameters->warmup_slots.value().convert_to<std::uint64_t>() ||
      bundle.end_boundary !=
          parameters->horizon_slots.value().convert_to<std::uint64_t>() ||
      bundle.reporting_block_boundaries !=
          parameters->reporting_block_boundaries) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_bundle_binding",
        "the observation source, scalar contract, request/problem identity, "
        "window, block plan or replication cap differs from schema-v3 "
        "parameters"));
  }
  const bool all_replications_complete = std::all_of(
      bundle.replications.begin(), bundle.replications.end(),
      [&](const ConstructionObservationReplicationV1& replication) {
        return replication.completeness ==
                   ObservationCompletenessV1::complete &&
               replication.committed_through_boundary == bundle.end_boundary;
      });
  auto terminal_policy =
      validate_full_orbit_observation_terminal_replication_policy(
          context.declared_kind, parameters->replications,
          bundle.replications.size(), all_replications_complete);
  if (!terminal_policy) {
    return terminal_policy;
  }

  std::size_t maximum_rows =
      static_cast<std::size_t>(
          parameters->maximum_observation_rows_per_replication);
  for (const ConstructionObservationReplicationV1& replication :
       bundle.replications) {
    std::size_t realized_rows = 0U;
    for (const ConstructionObservationBlockV1& block : replication.blocks) {
      if (block.levels.size() > maximum_rows - realized_rows) {
        return Result<void>::failure(route_error(
            "c30.full_orbit_observation_row_cap",
            "a replication exceeds maximum_observation_rows_per_replication"));
      }
      realized_rows += block.levels.size();
      if (block.initial_boundary_law.rows.size() >
          maximum_rows - realized_rows) {
        return Result<void>::failure(route_error(
            "c30.full_orbit_observation_row_cap",
            "a replication exceeds maximum_observation_rows_per_replication"));
      }
      realized_rows += block.initial_boundary_law.rows.size();
      if (block.committed_boundary_law.rows.size() >
          maximum_rows - realized_rows) {
        return Result<void>::failure(route_error(
            "c30.full_orbit_observation_row_cap",
            "a replication exceeds maximum_observation_rows_per_replication"));
      }
      realized_rows += block.committed_boundary_law.rows.size();
    }
  }
  auto canonical_body =
      canonical_construction_observation_bundle_body_bytes_v1(bundle);
  if (!canonical_body) {
    return Result<void>::failure(canonical_body.error());
  }
  constexpr std::string_view kEnvelopePrefix =
      "{\"observation_bundle\":";
  constexpr std::string_view kEnvelopeSuffix =
      ",\"observation_bundle_digest\":\"";
  constexpr std::size_t kDigestAndCloseBytes = 64U + 2U;
  const std::size_t fixed_envelope_bytes =
      kEnvelopePrefix.size() + kEnvelopeSuffix.size() +
      kDigestAndCloseBytes;
  if (canonical_body.value().size() >
          parameters->maximum_observation_bytes ||
      fixed_envelope_bytes > parameters->maximum_observation_bytes ||
      canonical_body.value().size() >
          parameters->maximum_observation_bytes - fixed_envelope_bytes) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_byte_cap",
        "the canonical observation envelope exceeds "
        "maximum_observation_bytes"));
  }

  if (problem.target_selection().ordered_targets.size() != 1U) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_target_cardinality",
        "the observation-capable route requires exactly one selected target"));
  }
  const QueueId& target_id =
      problem.target_selection().ordered_targets.front();
  const auto target = std::find_if(
      problem.queues().begin(), problem.queues().end(),
      [&](const PortableQueueEntryV1& entry) {
        return entry.queue_id == target_id && entry.selected_target;
      });
  if (target == problem.queues().end()) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_target_binding",
        "the selected target is absent from the canonical problem queue "
        "projection"));
  }
  auto dense_target =
      context.resolved_instance.queues().index_at(target->dense_index);
  if (!dense_target ||
      context.resolved_instance.queues().queue_id(dense_target.value()) !=
          target_id ||
      !std::in_range<std::uint64_t>(target->dense_index) ||
      bundle.bindings.target.target_id != target_id ||
      bundle.bindings.target.target_index !=
          static_cast<std::uint64_t>(target->dense_index) ||
      bundle.bindings.target.maxweight_multiplier !=
          target->maxweight_multiplier) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_target_binding",
        "the observation target ID, dense index or MaxWeight multiplier "
        "differs from the authenticated framework problem"));
  }

  auto arrival_context = validate_full_orbit_observation_arrival_context(
      problem, context.resolved_instance, context.compiled_arrival_law);
  if (!arrival_context) return arrival_context;
  const ArrivalBinding& arrival =
      arrival_law_binding(context.compiled_arrival_law);
  auto projected = project_exact_factorized_iid_target_pmf(
      context.compiled_arrival_law, dense_target.value());
  if (!projected) return Result<void>::failure(projected.error());
  ExactTargetArrivalMarginalV1 expected_marginal;
  expected_marginal.atoms.reserve(projected.value().size());
  ExactRational expected_mean = ExactRational::zero();
  ExactRational expected_second = ExactRational::zero();
  for (const ExactTargetIidBatchMass& atom : projected.value()) {
    auto count = ExactRational::make(atom.count.value(), BigInt{1});
    if (!count) return Result<void>::failure(count.error());
    expected_marginal.atoms.push_back({atom.count, atom.probability});
    expected_mean = expected_mean + count.value() * atom.probability;
    expected_second =
        expected_second + count.value() * count.value() * atom.probability;
  }
  const auto* actual_marginal =
      std::get_if<ExactTargetArrivalMarginalV1>(
          &bundle.bindings.arrival.target_arrival);
  if (actual_marginal == nullptr || *actual_marginal != expected_marginal ||
      bundle.bindings.arrival.arrival_family_id !=
          to_string(context.compiled_arrival_law.family()) ||
      bundle.bindings.arrival.configured_law_digest !=
          arrival.law_digest.value() ||
      bundle.bindings.arrival.mean != expected_mean ||
      bundle.bindings.arrival.second_moment != expected_second) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_arrival_binding",
        "the observation's target arrival marginal, moments, family or law "
        "digest differs from the exact compiled-law projection"));
  }

  auto experiment = observation_experiment_digest(problem, *parameters);
  auto slot_convention = expected_slot_convention_digest();
  auto initial_law = expected_initial_law_digest();
  auto seed_policy = expected_seed_policy_digest(context.request);
  auto scheduler = expected_scheduler_digest(context.resolved_instance);
  auto optimizer = expected_optimizer_digest(context.resolved_instance);
  auto primary_objective = expected_primary_objective_digest();
  if (!experiment || !slot_convention || !initial_law || !seed_policy ||
      !scheduler || !optimizer || !primary_objective) {
    return Result<void>::failure(
        !experiment       ? experiment.error()
        : !slot_convention ? slot_convention.error()
        : !initial_law     ? initial_law.error()
        : !seed_policy     ? seed_policy.error()
        : !scheduler       ? scheduler.error()
        : !optimizer       ? optimizer.error()
                           : primary_objective.error());
  }
  if (bundle.bindings.experiment_digest != experiment.value() ||
      bundle.bindings.topology_digest != problem.fingerprints().constraint ||
      bundle.bindings.scheduler_digest != scheduler.value() ||
      bundle.bindings.optimizer_digest != optimizer.value() ||
      bundle.bindings.primary_objective_digest != primary_objective.value() ||
      bundle.bindings.priority_digest !=
          problem.fingerprints().tie_and_timing ||
      bundle.bindings.tie_policy_digest !=
          problem.fingerprints().tie_and_timing ||
      bundle.slot_convention.convention_digest != slot_convention.value() ||
      bundle.initialization.initial_law_id != "empty_backlog_v1" ||
      bundle.initialization.initial_law_digest != initial_law.value() ||
      bundle.rng.rng_abi_id != "full_orbit_we_address_v1" ||
      bundle.rng.rng_abi_version != context.request.build_seed().rng_version() ||
      bundle.rng.construction_seed_policy_digest != seed_policy.value()) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_scientific_binding",
        "the observation experiment, scheduler, objective, priority, slot, "
        "initialization or RNG binding differs from the registered route"));
  }

  const bool gap_geometry_supported =
      zero_solve_gap_probe_supported(problem);
  const bool unit_target =
      target->maxweight_multiplier == ExactRational::one();
  const bool gap_supported = gap_geometry_supported && unit_target;
  const auto& gap_capability = bundle.capabilities.certified_gap_probe;
  bool gap_capability_valid = false;
  switch (parameters->gap_telemetry) {
    case FullOrbitGapTelemetryMode::disabled:
      gap_capability_valid =
          !gap_capability.available &&
          gap_capability.unavailable_reason_code == "disabled_by_request";
      break;
    case FullOrbitGapTelemetryMode::automatic:
      gap_capability_valid =
          gap_supported
              ? gap_capability.available
              : (!gap_capability.available &&
                 gap_capability.unavailable_reason_code ==
                     (unit_target ? "unsupported_gap_topology"
                                  : "nonunit_target_multiplier"));
      break;
    case FullOrbitGapTelemetryMode::required:
      gap_capability_valid = gap_supported && gap_capability.available;
      break;
  }
  if (!bundle.capabilities.iid_fresh_arrivals.available ||
      !bundle.capabilities.finite_arrival_second_moment.available ||
      !bundle.capabilities.exact_target_arrival_marginal.available ||
      !bundle.capabilities.no_target_drops.available ||
      !bundle.capabilities.exact_primary_maxweight.available ||
      bundle.capabilities.unit_target_multiplier.available !=
          (target->maxweight_multiplier == ExactRational::one()) ||
      !gap_capability_valid) {
    return Result<void>::failure(route_error(
        "c30.full_orbit_observation_capability_binding",
        "observation capability flags differ from the exact Full Orbit "
        "construction and requested gap mode"));
  }
  if (gap_capability.available) {
    auto magnitudes = validate_full_orbit_gap_magnitudes(bundle);
    if (!magnitudes) return magnitudes;
  }
  return Result<void>::success();
}

Result<void> validate_full_orbit_cp09_observation_envelope(
    const ObservationEnvelopeValidationContextV1& context,
    const ValidatedConstructionObservationBundleV1* observation) {
  auto route = full_orbit_sampler_cp09_hosted_route();
  if (!route) return Result<void>::failure(route.error());
  if (context.envelope.protocol_version != 3U ||
      context.envelope.provider != route.value().provider ||
      context.request.provider_binding().provider != route.value().provider ||
      context.envelope.request_digest !=
          context.request.request_digest().value() ||
      context.parameters.provider() != route.value().provider ||
      context.parameters.parameter_schema_version() !=
          route.value().parameter_schema_version ||
      context.parameters.parameter_schema_digest() !=
          route.value().parameter_schema_digest ||
      !context.parameters.typed_value_owner() ||
      !std::equal(context.request.validated_parameters().begin(),
                  context.request.validated_parameters().end(),
                  context.parameters.canonical_value_bytes().begin(),
                  context.parameters.canonical_value_bytes().end())) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_context_binding",
        "the result, request and private parameters do not select one exact "
        "CP09 route"));
  }
  if (context.declared_kind == ProviderResultKindV2::built) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_built_forbidden",
        "the CP09 raw route cannot return a deployable Built artifact"));
  }
  const auto* parameters = static_cast<const FullOrbitCp09Parameters*>(
      context.parameters.typed_value_owner().get());
  const bool has_observation = observation != nullptr;
  if (has_observation != context.observation_was_present) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_validation_order",
        "the semantic observation carrier differs from the presence "
        "captured before raw-sidecar validation"));
  }
  if (!has_observation) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_component_binding",
        "every CP09 terminal branch must bind an authenticated observation"));
  }

  const ConstructionObservationBundleV1& bundle = observation->value();
  const FrameworkProblemView& problem =
      context.request.framework_problem_view();
  const DerivedServiceIdentity service =
      context.resolved_instance.service_identity();
  if (context.resolved_instance.fingerprints() !=
          problem.fingerprints().authored_inputs ||
      problem.applicability_key() !=
          SchedulerConstraintPairV1{service.family, service.optimizer} ||
      context.resolved_instance.timing() != problem.timing()) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_problem_context",
        "the resolved instance differs from the authenticated framework "
        "problem used by the CP09 request"));
  }
  auto physical_trajectory =
      canonical_physical_trajectory_digest_v1(problem);
  if (!physical_trajectory) {
    return Result<void>::failure(physical_trajectory.error());
  }
  auto trajectory_identity = cp09_trajectory_identity_digest(
      physical_trajectory.value(), *parameters);
  if (!trajectory_identity) {
    return Result<void>::failure(trajectory_identity.error());
  }
  auto observation_policy = cp09_observation_policy_digest(*parameters);
  auto projection_policy = cp09_projection_policy_digest(*parameters);
  if (!observation_policy || !projection_policy) {
    return Result<void>::failure(
        !observation_policy ? observation_policy.error()
                            : projection_policy.error());
  }
  const std::vector<ArtifactComponentDigestV1> expected_components{
      {std::string(kObservationComponentName), observation->digest()},
      {"cp09.observation_policy_v1", observation_policy.value()},
      {"cp09.projection_policy_v1", projection_policy.value()},
      {"cp09.trajectory_identity_v1", trajectory_identity.value()}};
  if (context.envelope.build_report.optional_component_digests !=
      expected_components) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_component_binding",
        "the CP09 build report must bind the observation, observation "
        "policy, projection policy and physical trajectory identities in "
        "canonical component-name order"));
  }
  if (bundle.schema_version != 1U ||
      bundle.source_role != ObservationSourceRoleV1::weighted_ensemble ||
      bundle.scalar_representation !=
          ObservationScalarRepresentationV1::enclosed_binary64 ||
      bundle.bindings.request_digest !=
          trajectory_identity.value() ||
      bundle.bindings.problem_digest != physical_trajectory.value() ||
      bundle.warmup_boundary !=
          parameters->warmup_slots.value().convert_to<std::uint64_t>() ||
      bundle.end_boundary !=
          parameters->horizon_slots.value().convert_to<std::uint64_t>() ||
      bundle.reporting_block_boundaries !=
          parameters->reporting_block_boundaries) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_bundle_binding",
        "the observation source, scalar contract, cutoff-free trajectory/"
        "problem identity, window or block plan differs from schema-4 "
        "parameters"));
  }
  const bool all_replications_complete = std::all_of(
      bundle.replications.begin(), bundle.replications.end(),
      [&](const ConstructionObservationReplicationV1& replication) {
        return replication.completeness ==
                   ObservationCompletenessV1::complete &&
               replication.committed_through_boundary == bundle.end_boundary;
      });
  auto terminal_policy =
      validate_full_orbit_observation_terminal_replication_policy(
          context.declared_kind, parameters->replications,
          bundle.replications.size(), all_replications_complete);
  if (!terminal_policy) return terminal_policy;

  if (problem.target_selection().ordered_targets.size() != 1U) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_target_cardinality",
        "the CP09 route requires exactly one selected target"));
  }
  const QueueId& target_id =
      problem.target_selection().ordered_targets.front();
  const auto target = std::find_if(
      problem.queues().begin(), problem.queues().end(),
      [&](const PortableQueueEntryV1& entry) {
        return entry.queue_id == target_id && entry.selected_target;
      });
  if (target == problem.queues().end()) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_target_binding",
        "the selected target is absent from the canonical problem queue "
        "projection"));
  }
  auto dense_target =
      context.resolved_instance.queues().index_at(target->dense_index);
  if (!dense_target ||
      context.resolved_instance.queues().queue_id(dense_target.value()) !=
          target_id ||
      !std::in_range<std::uint64_t>(target->dense_index) ||
      bundle.bindings.target.target_id != target_id ||
      bundle.bindings.target.target_index !=
          static_cast<std::uint64_t>(target->dense_index) ||
      bundle.bindings.target.maxweight_multiplier !=
          target->maxweight_multiplier) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_target_binding",
        "the observation target differs from the authenticated framework "
        "problem"));
  }

  auto arrival_context = validate_full_orbit_observation_arrival_context(
      problem, context.resolved_instance, context.compiled_arrival_law);
  if (!arrival_context) return arrival_context;
  const ArrivalBinding& arrival =
      arrival_law_binding(context.compiled_arrival_law);
  auto expected_arrival = cp09_expected_target_arrival(
      context.compiled_arrival_law, dense_target.value());
  if (!expected_arrival) {
    return Result<void>::failure(expected_arrival.error());
  }
  if (bundle.bindings.arrival.arrival_family_id !=
          to_string(context.compiled_arrival_law.family()) ||
      bundle.bindings.arrival.configured_law_digest !=
          arrival.law_digest.value() ||
      bundle.bindings.arrival.target_arrival !=
          expected_arrival.value().description ||
      bundle.bindings.arrival.mean != expected_arrival.value().mean ||
      bundle.bindings.arrival.second_moment !=
          expected_arrival.value().second_moment) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_arrival_binding",
        "the observation target arrival law, moments, family or law digest "
        "differs from the compiled portable recipe"));
  }

  auto experiment =
      cp09_experiment_digest(trajectory_identity.value(), *parameters);
  auto slot_convention = expected_slot_convention_digest();
  auto initial_law = expected_initial_law_digest();
  auto seed_policy = expected_cp09_seed_policy_digest(
      context.request, trajectory_identity.value());
  auto scheduler = expected_scheduler_digest(context.resolved_instance);
  auto optimizer = expected_optimizer_digest(context.resolved_instance);
  auto primary_objective = expected_primary_objective_digest();
  if (!experiment || !slot_convention || !initial_law || !seed_policy ||
      !scheduler || !optimizer || !primary_objective) {
    return Result<void>::failure(
        !experiment        ? experiment.error()
        : !slot_convention ? slot_convention.error()
        : !initial_law     ? initial_law.error()
        : !seed_policy     ? seed_policy.error()
        : !scheduler       ? scheduler.error()
        : !optimizer       ? optimizer.error()
                           : primary_objective.error());
  }
  if (bundle.bindings.experiment_digest != experiment.value() ||
      bundle.bindings.topology_digest != problem.fingerprints().constraint ||
      bundle.bindings.scheduler_digest != scheduler.value() ||
      bundle.bindings.optimizer_digest != optimizer.value() ||
      bundle.bindings.primary_objective_digest != primary_objective.value() ||
      bundle.bindings.priority_digest !=
          problem.fingerprints().tie_and_timing ||
      bundle.bindings.tie_policy_digest !=
          problem.fingerprints().tie_and_timing ||
      bundle.slot_convention.convention_digest != slot_convention.value() ||
      bundle.initialization.initial_law_id != "empty_backlog_v1" ||
      bundle.initialization.initial_law_digest != initial_law.value() ||
      bundle.rng.rng_abi_id != "full_orbit_we_address_v1" ||
      bundle.rng.rng_abi_version != context.request.build_seed().rng_version() ||
      bundle.rng.construction_seed_policy_digest != seed_policy.value()) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_scientific_binding",
        "the observation experiment, scheduler, objective, priority, slot, "
        "initialization or cutoff-free RNG binding differs from CP09"));
  }

  // CP09 retains the reviewed zero-additional-solve formulas, and every
  // other exact scheduler topology evaluates the opposite target face with
  // one additional call to that topology's existing exact optimizer.  Only
  // the nonunit target multiplier remains outside this gap contract.
  const bool gap_supported =
      target->maxweight_multiplier == ExactRational::one();
  const auto& gap_capability = bundle.capabilities.certified_gap_probe;
  bool gap_capability_valid = false;
  switch (parameters->gap_telemetry) {
    case FullOrbitGapTelemetryMode::disabled:
      gap_capability_valid =
          !gap_capability.available &&
          gap_capability.unavailable_reason_code == "disabled_by_request";
      break;
    case FullOrbitGapTelemetryMode::automatic:
      gap_capability_valid =
          gap_supported
              ? gap_capability.available
              : (!gap_capability.available &&
                 gap_capability.unavailable_reason_code ==
                     "nonunit_target_multiplier");
      break;
    case FullOrbitGapTelemetryMode::required:
      gap_capability_valid = gap_supported && gap_capability.available;
      break;
  }
  const auto& exact_marginal_capability =
      bundle.capabilities.exact_target_arrival_marginal;
  const bool marginal_capability_valid =
      expected_arrival.value().finite_exact_marginal
          ? exact_marginal_capability.available
          : (!exact_marginal_capability.available &&
             exact_marginal_capability.unavailable_reason_code ==
                 "infinite_support_overshoot_descriptor");
  if (!bundle.capabilities.iid_fresh_arrivals.available ||
      !bundle.capabilities.finite_arrival_second_moment.available ||
      !marginal_capability_valid ||
      !bundle.capabilities.no_target_drops.available ||
      !bundle.capabilities.exact_primary_maxweight.available ||
      bundle.capabilities.unit_target_multiplier.available !=
          (target->maxweight_multiplier == ExactRational::one()) ||
      !gap_capability_valid) {
    return Result<void>::failure(route_error(
        "c32.full_orbit_cp09_capability_binding",
        "observation capability flags differ from the CP09 construction, "
        "arrival representation or requested gap mode"));
  }
  if (gap_capability.available) {
    auto magnitudes = validate_full_orbit_gap_magnitudes(bundle);
    if (!magnitudes) return magnitudes;
  }
  return Result<void>::success();
}

}  // namespace mwperf::detail
