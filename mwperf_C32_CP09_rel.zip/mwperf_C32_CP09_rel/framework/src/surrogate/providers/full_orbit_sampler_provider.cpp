#include "surrogate/providers/full_orbit_sampler_provider.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/providers/full_orbit_sampler_config.hpp"
#include "surrogate/surrogate_registry_internal.hpp"

namespace mwperf::detail {
namespace {

constexpr std::string_view kProviderId = "full_orbit_framework_sampler";
constexpr std::string_view kProviderVersion = "1.1.0";
constexpr std::string_view kExecutableId = "fofs.cp06.c27.local";

constexpr std::string_view kParameterSchemaDigest =
    "ea241a505f234508856d61b5d858ef4340ad813a5cdc8d2a6018229a379a763c";
constexpr std::string_view kSourceBuildDigest =
    "5a4aba57db39858c86b1e909dea6981150315f23f05aaa79f0e1650cb08b22e7";
constexpr std::string_view kMetricManifestDigest =
    "c9f10ffdd30116d7743891ee8c7e051f03c1d0322f265f41e69c6b195157ece5";
constexpr std::string_view kScientificContractDigest =
    "4920a71e97a757cfcd998ab6ad012a23f31d69da917daa6ecfb715001f0bef7a";
constexpr std::string_view kProviderManifestDigest =
    "126c4f2654413c09a413c043111b8b16395f2b89419e6aea693ad1f75cc13ffa";
constexpr std::string_view kConformanceReportDigest =
    "b3055f32b72f102c5f6eadeb1aa6cc0a53acea25856e83884d0cf97152adece2";
constexpr std::string_view kKWideEvidenceSchemaId =
    "full_orbit_finite_prefix_evidence_v1";
constexpr std::string_view kKWideConformanceReportId =
    "fofs_cp07_1_provider_conformance_report_v1";
constexpr std::string_view kKWideConformanceDeclaration =
    R"({"schema_version":1,"schema_id":"full_orbit_finite_prefix_evidence_v1","provider_id":"full_orbit_framework_sampler","provider_version":"1.2.0","native_result":"full_orbit_cp07_1_finite_prefix_transport_v1","coordinates":"structural_zero_exact_1_through_k_constant_tail_from_k_plus_1","numeric_encoding":"canonical_binary64_bits","coverage":"simultaneous"})";
constexpr std::string_view kKWideConformanceReportDigest =
    "89cc4d4fbdcd516ae61cd97d7769fb2c49c5990d3576c44785c5b4a6d1fb0019";
constexpr std::string_view kKWideMetricManifestDigest =
    "6ce5d3524e5ff83fa4e36512b9fb74d5ca0aa4a607f13ac16b7849928de7d08f";
constexpr std::string_view kKWideScientificContractDigest =
    "a0cc1201e8009827b0ce5b0b14a3ba20ee62629569ac5fe97622d3bfb47bc157";
constexpr std::string_view kKWideProviderManifestDigest =
    "1c19fa77ce2744e92ccf220999cd0406e8a7ffac42e7769bfe5becd42a370658";
constexpr std::string_view kObservationConformanceReportId =
    "fofs_cp07_1_observation_provider_conformance_report_v1";
constexpr std::string_view kObservationConformanceDeclaration =
    R"({"schema_version":1,"schema_id":"full_orbit_finite_prefix_evidence_v1","provider_id":"full_orbit_framework_sampler","provider_version":"1.3.0","native_result":"full_orbit_cp07_1_finite_prefix_transport_v2","observation_component":"construction_observation_bundle_v1","coordinates":"structural_zero_exact_1_through_k_constant_tail_from_k_plus_1","numeric_encoding":"canonical_binary64_bits","coverage":"simultaneous"})";
constexpr std::string_view kObservationConformanceReportDigest =
    "2f9e08117da372f1ce966179232a5aaab9be8bad967e26d3b1d13860a7872840";
constexpr std::string_view kObservationScientificContractDigest =
    "7a3014e9944f09118e48f549335f3bcdc23f2958f8259af37736c08306999c14";
constexpr std::string_view kObservationProviderManifestDigest =
    "4f8fe7a1d430f9892b3fba5c6b8c569be47b14cfd6feb760da466046b3214f22";
constexpr std::string_view kCp09EvidenceSchemaId =
    "empirical_finite_window_response_v1";
constexpr std::string_view kCp09ConformanceReportId =
    "fofs_cp09_observation_provider_conformance_report_v1";
constexpr std::string_view kCp09ConformanceDeclaration =
    R"({"schema_version":1,"schema_id":"empirical_finite_window_response_v1","provider_id":"full_orbit_framework_sampler","provider_version":"1.4.0","native_result":"full_orbit_cp09_observation_transport_v3","observation_component":"construction_observation_bundle_v1","terminal_success":"observed","result_authority":"observation_only_no_surrogate","response_interpretation":"empirical_finite_window","tail_completion":"none","projection_cutoffs":"post_collection","poisson_overshoot":{"sampler_id":"mwperf.addressed_poisson.inversion_ptrs.v1","sampler_version":1,"maximum_uniform_words_per_variate":18446744073709551615},"numeric_encoding":"canonical_binary64_bits_with_outward_enclosure"})";
constexpr std::string_view kCp09SourceBuildDeclaration =
    "mwperf.c32.cp09.full_orbit_framework_sampler.source.v1";
// These values seal the additive CP09 contract.  They are intentionally
// independent of the released 1.2/1.3 identities above.
constexpr std::string_view kCp09SourceBuildDigest =
    "08ce40d8fe97628ba74bda1d272be77b99d586c550f1e6c383750413fd0aa353";
constexpr std::string_view kCp09ConformanceReportDigest =
    "521c7a61cdf6ccb712a349ebba6035133822d5ae78763b6ec38ffff0dec21a70";
constexpr std::string_view kCp09MetricManifestDigest =
    "cf2471b2ce580ab6a7b4e8b418612689c1c0417354d266d9f02a01bd85db8305";
constexpr std::string_view kCp09ScientificContractDigest =
    "fdb96d64420c33f7348c60e9d2ab86602d926e38bb0d6bd8c66e2a642def0e32";
constexpr std::uint64_t kMaximumHorizonSlots = 10'000'000U;
constexpr std::uint64_t kMaximumWarmupSlots = 9'999'999U;
constexpr std::uint64_t kMaximumReplications = 10'000U;
constexpr std::uint64_t kMaximumConstructionWork = 1'000'000'000U;

struct FullOrbitParameters final {
  BigNat warmup_slots;
  BigNat horizon_slots;
  BigNat replications;
  BigInt alpha_numerator;
  BigInt alpha_denominator;
};

[[nodiscard]] Diagnostic provider_error(std::string code,
                                        std::string message,
                                        std::optional<std::string> pointer =
                                            std::nullopt) {
  return {DiagnosticCategory::input_validation, std::move(code),
          std::move(message), std::move(pointer), std::nullopt, {}};
}

[[nodiscard]] Result<Digest256> digest_from_hex(
    const std::string_view text) {
  return Digest256::from_hex(std::string(text));
}

[[nodiscard]] Result<Digest256> text_digest(const std::string_view text) {
  return sha256(std::as_bytes(std::span(text.data(), text.size())));
}

[[nodiscard]] Result<Digest256> k_wide_conformance_declaration_digest() {
  constexpr std::string_view domain =
      "mwperf.fofs.provider_conformance_report";
  std::vector<std::byte> preimage;
  preimage.reserve(domain.size() + 1U + 4U +
                   kKWideConformanceDeclaration.size());
  const auto append = [&](const std::string_view value) {
    preimage.insert(
        preimage.end(),
        reinterpret_cast<const std::byte*>(value.data()),
        reinterpret_cast<const std::byte*>(value.data() + value.size()));
  };
  append(domain);
  preimage.push_back(std::byte{0x00});
  preimage.insert(preimage.end(),
                  {std::byte{0x00}, std::byte{0x00}, std::byte{0x00},
                   std::byte{0x01}});
  append(kKWideConformanceDeclaration);
  return sha256(preimage);
}

[[nodiscard]] Result<Digest256>
observation_conformance_declaration_digest() {
  constexpr std::string_view domain =
      "mwperf.fofs.provider_conformance_report";
  std::vector<std::byte> preimage;
  preimage.reserve(domain.size() + 1U + 4U +
                   kObservationConformanceDeclaration.size());
  const auto append = [&](const std::string_view value) {
    preimage.insert(
        preimage.end(),
        reinterpret_cast<const std::byte*>(value.data()),
        reinterpret_cast<const std::byte*>(value.data() + value.size()));
  };
  append(domain);
  preimage.push_back(std::byte{0x00});
  preimage.insert(preimage.end(),
                  {std::byte{0x00}, std::byte{0x00}, std::byte{0x00},
                   std::byte{0x01}});
  append(kObservationConformanceDeclaration);
  return sha256(preimage);
}

[[nodiscard]] Result<Digest256> cp09_conformance_declaration_digest() {
  constexpr std::string_view domain =
      "mwperf.fofs.provider_conformance_report";
  std::vector<std::byte> preimage;
  preimage.reserve(domain.size() + 1U + 4U +
                   kCp09ConformanceDeclaration.size());
  const auto append = [&](const std::string_view value) {
    preimage.insert(
        preimage.end(),
        reinterpret_cast<const std::byte*>(value.data()),
        reinterpret_cast<const std::byte*>(value.data() + value.size()));
  };
  append(domain);
  preimage.push_back(std::byte{0x00});
  preimage.insert(preimage.end(),
                  {std::byte{0x00}, std::byte{0x00}, std::byte{0x00},
                   std::byte{0x01}});
  append(kCp09ConformanceDeclaration);
  return sha256(preimage);
}

[[nodiscard]] Result<TypedLabel> text_label(const std::string_view value) {
  return TypedLabel::text(std::string(value));
}

[[nodiscard]] Result<QueueId> queue_id(const std::string_view value) {
  auto label = text_label(value);
  if (!label) return Result<QueueId>::failure(label.error());
  return Result<QueueId>::success(QueueId(std::move(label).value()));
}

[[nodiscard]] Result<ExactRational> rational(const std::string_view numerator,
                                             const std::string_view denominator) {
  return ExactRational::make(BigInt(std::string(numerator)),
                             BigInt(std::string(denominator)));
}

[[nodiscard]] ArrivalAssumptionV1 runtime_arrival(
    const ArrivalNeedKindV1 kind) {
  return {kind, ArrivalCapabilityUseV1::runtime,
          CapabilityProvisionNeedV1::any, std::nullopt, false, false,
          std::nullopt, std::nullopt, std::nullopt};
}

[[nodiscard]] ArrivalAssumptionV1 construction_iid_arrival() {
  return {ArrivalNeedKindV1::exact_iid_late,
          ArrivalCapabilityUseV1::construction,
          CapabilityProvisionNeedV1::portable,
          std::nullopt,
          true,
          false,
          std::nullopt,
          std::nullopt,
          std::nullopt};
}

[[nodiscard]] MetricSupportRoleRequirementV1 support_role(
    const MetricSupportRoleV1 role, const MetricTargetScopeV1 targets,
    const MetricResultScopeV1 result, const MetricEvidenceScopeV1 evidence,
    std::vector<MetricRoleRelationRequirementV1> role_relations = {},
    std::vector<InternalRelationRequirementV1> internal_relations = {}) {
  return {role, targets, result, evidence, std::move(role_relations),
          std::move(internal_relations)};
}

[[nodiscard]] std::vector<MetricSupportRoleRequirementV1>
production_support_roles() {
  using E = MetricEvidenceScopeV1;
  using I = InternalReferencePurposeV1;
  using K = MetricRoleRelationKindV1;
  using O = MetricResultScopeV1;
  using R = MetricSupportRoleV1;
  using T = MetricTargetScopeV1;

  return {
      support_role(R::deployed_payload, T::payload_targets, O::surrogate_law,
                   E::none),
      support_role(R::deployed_response, T::deployed_singleton_target,
                   O::surrogate_law, E::deployed_surrogate_law,
                   {{K::binding, R::deployed_payload},
                    {K::subject, R::nominal_response}}),
      support_role(R::raw_response, T::deployed_singleton_target,
                   O::proposal_raw, E::raw_static_proposal,
                   {{K::binding, R::deployed_payload},
                    {K::evidence, R::raw_response_bound_evidence}},
                   {{K::lineage_parent, I::coefficient_origin}}),
      support_role(R::nominal_response, T::deployed_singleton_target,
                   O::not_a_metric_result, E::nominal_static_proposal,
                   {{K::lineage_parent, R::raw_response}},
                   {{K::binding, I::completion_policy}}),
      support_role(
          R::raw_response_bound_evidence, T::deployed_singleton_target,
          O::not_a_metric_result, E::raw_static_proposal,
          {{K::subject, R::raw_response}},
          {{K::binding, I::evaluation_identity},
           {K::binding, I::proposal_identity},
           {K::subject, I::coefficient_origin}}),
      support_role(
          R::statistical_evidence, T::deployed_singleton_target,
          O::not_a_metric_result, E::raw_static_proposal, {},
          {{K::binding, I::evaluation_identity},
           {K::binding, I::sampling_bank},
           {K::binding, I::sampling_probe},
           {K::binding, I::coverage_family},
           {K::subject, I::estimand}}),
  };
}

[[nodiscard]] std::vector<MetricSupportRoleRequirementV1>
k_wide_support_roles() {
  using E = MetricEvidenceScopeV1;
  using I = InternalReferencePurposeV1;
  using K = MetricRoleRelationKindV1;
  using O = MetricResultScopeV1;
  using R = MetricSupportRoleV1;
  using T = MetricTargetScopeV1;

  return {
      support_role(R::deployed_payload, T::payload_targets, O::surrogate_law,
                   E::none),
      support_role(R::deployed_response, T::deployed_singleton_target,
                   O::surrogate_law, E::deployed_surrogate_law,
                   {{K::binding, R::deployed_payload},
                    {K::subject, R::raw_response}}),
      support_role(R::raw_response, T::deployed_singleton_target,
                   O::proposal_raw, E::raw_static_proposal,
                   {{K::binding, R::deployed_payload},
                    {K::evidence, R::raw_response_bound_evidence}},
                   {{K::lineage_parent, I::coefficient_origin}}),
      support_role(
          R::raw_response_bound_evidence, T::deployed_singleton_target,
          O::not_a_metric_result, E::raw_static_proposal,
          {{K::subject, R::raw_response}},
          {{K::binding, I::evaluation_identity},
           {K::binding, I::proposal_identity},
           {K::subject, I::coefficient_origin}}),
      support_role(
          R::statistical_evidence, T::deployed_singleton_target,
          O::not_a_metric_result, E::raw_static_proposal, {},
          {{K::binding, I::evaluation_identity},
           {K::binding, I::sampling_bank},
           {K::binding, I::sampling_probe},
           {K::binding, I::coverage_family},
           {K::subject, I::estimand}}),
  };
}

[[nodiscard]] Result<MetricSupportClauseV1> production_clause(
    std::string metric_id, const std::size_t authored_index,
    const MetricKindV1 kind, MetricParameterDomainV1 parameters,
    std::vector<MarkDescriptorV1> marks,
    std::vector<ArrivalAssumptionV1> arrivals,
    std::vector<HypothesisClaimV1> hypotheses) {
  auto target = queue_id("q0");
  if (!target) {
    return Result<MetricSupportClauseV1>::failure(target.error());
  }
  auto tolerance = rational("1", "1000000000000");
  if (!tolerance) {
    return Result<MetricSupportClauseV1>::failure(tolerance.error());
  }

  return Result<MetricSupportClauseV1>::success(MetricSupportClauseV1{
      {std::move(metric_id), authored_index},
      kind,
      std::move(parameters),
      {std::move(target).value()},
      TargetCouplingV1::scalar_target,
      {{StateFieldKindV1::target_backlog, FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      std::move(marks),
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::iid_late_arrival, false, std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon, std::nullopt},
      {PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      std::move(arrivals),
      std::move(hypotheses),
      SolverRegimeV1::analytic,
      AnalyticAccuracyV1{
          BigNat{128U},
          {{DeterministicToleranceKindV1::linear_residual_abs,
            std::move(tolerance).value()}}},
      {StructuralErrorFormV1::exact, MetricEvidenceScopeV1::none,
       ExactRational::zero()},
      MetricResultScopeV1::surrogate_law,
      {V0DeclarationKindV1::structural_witness_required,
       "fofs.scalar-backlog-response.v1", 1U},
      production_support_roles()});
}

[[nodiscard]] std::vector<MarkDescriptorV1> ordinary_marks() {
  return {{MetricMarkKindV1::target_backlog,
           MetricRevealStageV1::predecision,
           {"fofs.metric-mark", 1U},
           "fofs.cp06.metric-edge"},
          {MetricMarkKindV1::opportunity,
           MetricRevealStageV1::predecision,
           {"fofs.metric-mark", 1U},
          "fofs.cp06.metric-edge"}};
}

[[nodiscard]] std::vector<MarkDescriptorV1> deployed_marks() {
  auto marks = ordinary_marks();
  std::erase_if(marks, [](const MarkDescriptorV1& mark) {
    return mark.kind == MetricMarkKindV1::opportunity;
  });
  return marks;
}

[[nodiscard]] std::vector<ArrivalAssumptionV1> ordinary_arrivals() {
  return {runtime_arrival(ArrivalNeedKindV1::full_common_batch),
          runtime_arrival(ArrivalNeedKindV1::exact_iid_late)};
}

[[nodiscard]] std::vector<HypothesisClaimV1> ordinary_hypotheses() {
  return {{HypothesisKindV1::proper_stationary, std::nullopt, std::nullopt,
           std::nullopt},
          {HypothesisKindV1::invariant_selected, std::nullopt, std::nullopt,
           std::nullopt},
          {HypothesisKindV1::iid_late_arrival, std::nullopt, std::nullopt,
           std::nullopt}};
}

[[nodiscard]] Result<MetricSupportManifest> production_metric_manifest() {
  std::vector<MetricSupportClauseV1> clauses;
  clauses.reserve(6U);
  const auto append = [&](Result<MetricSupportClauseV1> clause)
      -> Result<void> {
    if (!clause) return Result<void>::failure(clause.error());
    clauses.push_back(std::move(clause).value());
    return Result<void>::success();
  };

  auto pi0 = append(production_clause(
      "fofs.iid.pi0.v1", 0U, MetricKindV1::stationary_empty_probability,
      ExactMetricParameterSetV1{
          {MetricRequestParametersV1{StationaryEmptyProbabilityParametersV1{}}}},
      ordinary_marks(), ordinary_arrivals(), ordinary_hypotheses()));
  if (!pi0) return Result<MetricSupportManifest>::failure(pi0.error());

  auto pmf = append(production_clause(
      "fofs.iid.pmf.v1", 1U, MetricKindV1::stationary_backlog_pmf,
      ExactMetricParameterSetV1{{
          MetricRequestParametersV1{StationaryBacklogPmfParametersV1{
              PmfThroughLevelV1{BigNat{0U}}}},
          MetricRequestParametersV1{StationaryBacklogPmfParametersV1{
              PmfThroughLevelV1{BigNat{1U}}}},
          MetricRequestParametersV1{StationaryBacklogPmfParametersV1{
              PmfThroughLevelV1{BigNat{2U}}}},
      }},
      ordinary_marks(), ordinary_arrivals(), ordinary_hypotheses()));
  if (!pmf) return Result<MetricSupportManifest>::failure(pmf.error());

  auto tail = append(production_clause(
      "fofs.iid.tail3.v1", 2U, MetricKindV1::stationary_backlog_tail,
      ExactMetricParameterSetV1{
          {MetricRequestParametersV1{StationaryBacklogTailParametersV1{
              BigNat{3U}}}}},
      ordinary_marks(), ordinary_arrivals(), ordinary_hypotheses()));
  if (!tail) return Result<MetricSupportManifest>::failure(tail.error());

  auto mean_hypotheses = ordinary_hypotheses();
  mean_hypotheses.push_back(
      {HypothesisKindV1::moment_finite, MomentVariableV1::backlog,
       BigNat{1U}, std::nullopt});
  auto mean = append(production_clause(
      "fofs.iid.mean.v1", 3U, MetricKindV1::stationary_backlog_moment,
      ExactMetricParameterSetV1{
          {MetricRequestParametersV1{StationaryBacklogMomentParametersV1{
              BigNat{1U}}}}},
      ordinary_marks(), ordinary_arrivals(), std::move(mean_hypotheses)));
  if (!mean) return Result<MetricSupportManifest>::failure(mean.error());

  auto sojourn_arrivals = ordinary_arrivals();
  sojourn_arrivals.push_back(
      runtime_arrival(ArrivalNeedKindV1::target_intensity));
  auto sojourn_hypotheses = ordinary_hypotheses();
  sojourn_hypotheses.insert(
      sojourn_hypotheses.end(),
      {{HypothesisKindV1::lossless, std::nullopt, std::nullopt, std::nullopt},
       {HypothesisKindV1::unit_packets, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::eventual_departure_or_accessible_class,
        std::nullopt, std::nullopt, std::nullopt},
       {HypothesisKindV1::positive_finite_intensity, std::nullopt,
        std::nullopt, std::nullopt},
       {HypothesisKindV1::moment_finite, MomentVariableV1::backlog,
        BigNat{1U}, std::nullopt},
       {HypothesisKindV1::little_law, std::nullopt, std::nullopt,
        std::nullopt}});
  auto sojourn = append(production_clause(
      "fofs.iid.sojourn.v1", 4U, MetricKindV1::mean_sojourn,
      ExactMetricParameterSetV1{
          {MetricRequestParametersV1{MeanSojournParametersV1{}}}},
      {{MetricMarkKindV1::target_backlog,
        MetricRevealStageV1::predecision,
        {"fofs.metric-mark", 1U},
        "fofs.cp06.metric-edge"}},
      std::move(sojourn_arrivals), std::move(sojourn_hypotheses)));
  if (!sojourn) {
    return Result<MetricSupportManifest>::failure(sojourn.error());
  }

  auto bcs_hypotheses = ordinary_hypotheses();
  bcs_hypotheses.push_back({HypothesisKindV1::positive_conditioning_mass,
                            std::nullopt, std::nullopt, std::nullopt});
  auto bcs = append(production_clause(
      "fofs.iid.bcs.v1", 5U,
      MetricKindV1::backlog_conditioned_service,
      ExactMetricParameterSetV1{{
          MetricRequestParametersV1{
              BacklogConditionedServiceParametersV1{{BigNat{0U}}}},
          MetricRequestParametersV1{
              BacklogConditionedServiceParametersV1{{BigNat{1U}}}},
          MetricRequestParametersV1{
              BacklogConditionedServiceParametersV1{{BigNat{2U}}}},
          MetricRequestParametersV1{BacklogConditionedServiceParametersV1{
              {BigNat{0U}, BigNat{1U}}}},
          MetricRequestParametersV1{BacklogConditionedServiceParametersV1{
              {BigNat{0U}, BigNat{2U}}}},
          MetricRequestParametersV1{BacklogConditionedServiceParametersV1{
              {BigNat{1U}, BigNat{2U}}}},
          MetricRequestParametersV1{BacklogConditionedServiceParametersV1{
              {BigNat{0U}, BigNat{1U}, BigNat{2U}}}},
      }},
      ordinary_marks(), ordinary_arrivals(), std::move(bcs_hypotheses)));
  if (!bcs) return Result<MetricSupportManifest>::failure(bcs.error());

  auto manifest = MetricSupportManifest::from_clauses(std::move(clauses));
  if (!manifest) return manifest;
  if (manifest.value().canonical_digest().hex() != kMetricManifestDigest) {
    return Result<MetricSupportManifest>::failure(provider_error(
        "c27_1.full_orbit_metric_manifest_drift",
        "the reconstructed CP06 metric-support manifest digest differs from "
        "the frozen provider contract"));
  }
  return manifest;
}

[[nodiscard]] std::vector<SchedulerConstraintPairV1> production_pairs() {
  return {{ServiceFamily::crossbar_matching, OptimizerId::hungarian_exact},
          {ServiceFamily::nonoverlapping_intervals,
           OptimizerId::weighted_interval_dp_exact},
          {ServiceFamily::node_exclusive_matching,
           OptimizerId::edmonds_blossom_exact},
          {ServiceFamily::pairwise_conflicts,
           OptimizerId::mwis_branch_memo_exact},
          {ServiceFamily::resource_packing,
           OptimizerId::binary_packing_memo_exact}};
}

[[nodiscard]] bool canonical_decimal_natural(const std::string_view text,
                                              const bool positive) {
  if (text.empty() || (text.size() > 1U && text.front() == '0')) return false;
  if (!std::all_of(text.begin(), text.end(), [](const char value) {
        return value >= '0' && value <= '9';
      })) {
    return false;
  }
  return !positive || text != "0";
}

[[nodiscard]] Result<BigNat> source_natural(const SourceNode* node,
                                            const std::string_view name,
                                            const bool positive) {
  if (node == nullptr || node->kind() != SourceNodeKind::number ||
      node->number_lexeme() == nullptr ||
      !canonical_decimal_natural(*node->number_lexeme(), positive)) {
    return Result<BigNat>::failure(provider_error(
        "c27_1.full_orbit_parameter_natural",
        std::string(name) + " must be a canonical nonnegative integer",
        node == nullptr ? std::nullopt
                        : std::optional<std::string>(node->json_pointer())));
  }
  auto value = BigNat::from_big_int(BigInt(*node->number_lexeme()));
  if (!value) return Result<BigNat>::failure(value.error());
  return value;
}

[[nodiscard]] bool exact_keys(const SourceNode& node,
                              const std::span<const std::string_view> keys) {
  if (node.kind() != SourceNodeKind::object ||
      node.object_members().size() != keys.size()) {
    return false;
  }
  return std::all_of(keys.begin(), keys.end(), [&](const auto key) {
    return node.find(key) != nullptr;
  });
}

[[nodiscard]] Result<ValidatedParameterPayloadV1> validate_parameters(
    const SourceNode& source) {
  static constexpr std::array<std::string_view, 5U> kKeys{
      "schema_version", "warmup_slots", "horizon_slots", "replications",
      "familywise_alpha"};
  static constexpr std::array<std::string_view, 3U> kAlphaKeys{
      "kind", "numerator", "denominator"};
  if (!exact_keys(source, kKeys)) {
    return Result<ValidatedParameterPayloadV1>::failure(provider_error(
        "c27_1.full_orbit_parameter_shape",
        "Full Orbit parameters must contain exactly the five CP06 members",
        std::string(source.json_pointer())));
  }
  const SourceNode* schema = source.find("schema_version");
  if (schema == nullptr || schema->kind() != SourceNodeKind::number ||
      schema->number_lexeme() == nullptr || *schema->number_lexeme() != "1") {
    return Result<ValidatedParameterPayloadV1>::failure(provider_error(
        "c27_1.full_orbit_parameter_version",
        "Full Orbit parameter schema_version must equal 1"));
  }
  auto warmup = source_natural(source.find("warmup_slots"), "warmup_slots",
                               false);
  auto horizon = source_natural(source.find("horizon_slots"), "horizon_slots",
                                true);
  auto replications = source_natural(source.find("replications"),
                                     "replications", true);
  if (!warmup) {
    return Result<ValidatedParameterPayloadV1>::failure(warmup.error());
  }
  if (!horizon) {
    return Result<ValidatedParameterPayloadV1>::failure(horizon.error());
  }
  if (!replications) {
    return Result<ValidatedParameterPayloadV1>::failure(
        replications.error());
  }
  if (warmup.value() >= horizon.value() ||
      warmup.value() > BigNat{kMaximumWarmupSlots} ||
      horizon.value() > BigNat{kMaximumHorizonSlots} ||
      replications.value() > BigNat{kMaximumReplications}) {
    return Result<ValidatedParameterPayloadV1>::failure(provider_error(
        "c27_1.full_orbit_parameter_domain",
        "Full Orbit requires 0 <= warmup_slots < horizon_slots and values "
        "within the frozen CP06 scientific limits"));
  }

  const SourceNode* alpha = source.find("familywise_alpha");
  if (alpha == nullptr || !exact_keys(*alpha, kAlphaKeys)) {
    return Result<ValidatedParameterPayloadV1>::failure(provider_error(
        "c27_1.full_orbit_alpha_shape",
        "familywise_alpha must be the closed rational object"));
  }
  const SourceNode* kind = alpha->find("kind");
  const SourceNode* numerator_node = alpha->find("numerator");
  const SourceNode* denominator_node = alpha->find("denominator");
  if (kind == nullptr || kind->kind() != SourceNodeKind::string ||
      kind->string_value() == nullptr || *kind->string_value() != "rational" ||
      numerator_node == nullptr ||
      numerator_node->kind() != SourceNodeKind::string ||
      numerator_node->string_value() == nullptr ||
      denominator_node == nullptr ||
      denominator_node->kind() != SourceNodeKind::string ||
      denominator_node->string_value() == nullptr ||
      !canonical_decimal_natural(*numerator_node->string_value(), true) ||
      !canonical_decimal_natural(*denominator_node->string_value(), true)) {
    return Result<ValidatedParameterPayloadV1>::failure(provider_error(
        "c27_1.full_orbit_alpha_value",
        "familywise_alpha must use positive canonical decimal strings"));
  }
  BigInt numerator(*numerator_node->string_value());
  BigInt denominator(*denominator_node->string_value());
  BigInt left = numerator;
  BigInt right = denominator;
  while (right != 0) {
    BigInt remainder = left % right;
    left = std::move(right);
    right = std::move(remainder);
  }
  if (numerator >= denominator || left != 1) {
    return Result<ValidatedParameterPayloadV1>::failure(provider_error(
        "c27_1.full_orbit_alpha_domain",
        "familywise_alpha must be reduced and strictly between zero and one"));
  }

  const std::string canonical =
      "{\"schema_version\":1,\"warmup_slots\":" +
      warmup.value().to_decimal_string() + ",\"horizon_slots\":" +
      horizon.value().to_decimal_string() + ",\"replications\":" +
      replications.value().to_decimal_string() +
      ",\"familywise_alpha\":{\"kind\":\"rational\",\"numerator\":\"" +
      *numerator_node->string_value() + "\",\"denominator\":\"" +
      *denominator_node->string_value() +
      "\"}}";
  std::vector<std::byte> bytes(
      reinterpret_cast<const std::byte*>(canonical.data()),
      reinterpret_cast<const std::byte*>(canonical.data() + canonical.size()));
  auto typed = std::make_shared<const FullOrbitParameters>(
      FullOrbitParameters{std::move(warmup).value(),
                          std::move(horizon).value(),
                          std::move(replications).value(),
                          std::move(numerator), std::move(denominator)});
  return Result<ValidatedParameterPayloadV1>::success(
      {std::move(bytes), std::move(typed)});
}

[[nodiscard]] bool metered_search_family(
    const SchedulerConstraintPairV1& pair) noexcept {
  return pair == SchedulerConstraintPairV1{
                     ServiceFamily::pairwise_conflicts,
                     OptimizerId::mwis_branch_memo_exact} ||
         pair == SchedulerConstraintPairV1{
                     ServiceFamily::resource_packing,
                     OptimizerId::binary_packing_memo_exact};
}

[[nodiscard]] Result<void> validate_geometry(const FrameworkProblemView& view) {
  if (view.queues().size() > 4096U) {
    return Result<void>::failure(provider_error(
        "c27_1.full_orbit_geometry_limit",
        "Full Orbit supports at most 4096 configured queues"));
  }
  return std::visit(
      [&](const auto& geometry) -> Result<void> {
        using Geometry = std::decay_t<decltype(geometry)>;
        bool valid = true;
        if constexpr (std::is_same_v<Geometry,
                                     PortableCrossbarConstraintV1>) {
          valid = geometry.inputs.size() + geometry.outputs.size() <= 128U &&
                  geometry.edges.size() <= 4096U;
        } else if constexpr (std::is_same_v<Geometry,
                                            PortableNodeExclusiveConstraintV1>) {
          valid = geometry.vertices.size() <= 128U;
        }
        if (!valid) {
          return Result<void>::failure(provider_error(
              "c27_1.full_orbit_geometry_limit",
              "the configured scheduler geometry exceeds a frozen CP06 "
              "scientific admissibility limit"));
        }
        return Result<void>::success();
      },
      view.constraint_geometry());
}

[[nodiscard]] Result<PlugDescriptorCore> production_descriptor(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem,
    const MetricSupportManifest& concrete_metric_manifest,
    BigNat constant_tail_from) {
  auto tolerance = rational("1", "1000000000000");
  if (!tolerance) {
    return Result<PlugDescriptorCore>::failure(tolerance.error());
  }
  PlugDescriptorCore descriptor{
      1U,
      manifest.provider,
      manifest.optimizer_constraint_applicability,
      manifest.payload_class,
      manifest.deployed_semantic_tag,
      manifest.runtime_access_tag,
      problem.target_selection().ordered_targets,
      TargetCouplingV1::scalar_target,
      {{StateFieldKindV1::target_backlog, FieldOwnershipV1::framework_exact,
        {"queue.big_nat", 1U}}},
      deployed_marks(),
      {{SelectionKindV1::stationary_unique}, {}, {}},
      {PayloadPhaseKindV1::phase_free,
       ConfiguredArrivalCompositionV1::iid_late_arrival, false, std::nullopt,
       FiniteHorizonCoverageKindV1::every_finite_horizon, std::nullopt},
      {TailRepresentationKindV1::constant_response,
       std::move(constant_tail_from), std::nullopt},
      {runtime_arrival(ArrivalNeedKindV1::target_intensity),
       runtime_arrival(ArrivalNeedKindV1::full_common_batch),
       runtime_arrival(ArrivalNeedKindV1::exact_iid_late)},
      {{HypothesisKindV1::proper_stationary, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::invariant_selected, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::lossless, std::nullopt, std::nullopt, std::nullopt},
       {HypothesisKindV1::unit_packets, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::eventual_departure_or_accessible_class,
        std::nullopt, std::nullopt, std::nullopt},
       {HypothesisKindV1::positive_finite_intensity, std::nullopt,
        std::nullopt, std::nullopt},
       {HypothesisKindV1::positive_conditioning_mass, std::nullopt,
        std::nullopt, std::nullopt},
       {HypothesisKindV1::moment_finite, MomentVariableV1::backlog,
        BigNat{1U}, std::nullopt},
       {HypothesisKindV1::little_law, std::nullopt, std::nullopt,
        std::nullopt},
       {HypothesisKindV1::iid_late_arrival, std::nullopt, std::nullopt,
        std::nullopt}},
      {V0DeclarationKindV1::structural_witness_required,
       "fofs.scalar-backlog-response.v1", 1U},
      {},
      {AnalyticAccuracyV1{
          BigNat{128U},
          {{DeterministicToleranceKindV1::linear_residual_abs,
            std::move(tolerance).value()}}}},
      {ConstructionResultScopeV1::surrogate_law,
       ConstructionErrorScopeV1::deployed_surrogate_law},
      concrete_metric_manifest.canonical_digest(),
      manifest.manifest_digest};
  auto digest = canonical_plug_descriptor_core_digest_v1(descriptor);
  if (!digest) return Result<PlugDescriptorCore>::failure(digest.error());
  descriptor.core_digest = std::move(digest).value();
  return Result<PlugDescriptorCore>::success(std::move(descriptor));
}

[[nodiscard]] Result<MetricSupportManifest> specialize_metric_manifest(
    const MetricSupportManifest& prototype, const QueueId& target) {
  std::vector<MetricSupportClauseV1> clauses(prototype.clauses().begin(),
                                             prototype.clauses().end());
  for (MetricSupportClauseV1& clause : clauses) {
    // The registered q0 manifest remains the frozen scientific prototype.
    // Every Full Orbit clause is explicitly scalar and scoped by its roles to
    // the deployed singleton target, so the preview binds that prototype to
    // the request's actual queue identity.
    clause.ordered_targets = {target};
    // The portable scalar response has already marginalized the sampled
    // scheduling opportunity.  Requiring a live C-minus opportunity decoder
    // would add a causal operation that this analytic runtime neither needs
    // nor owns.
    std::erase_if(clause.marks, [](const MarkDescriptorV1& mark) {
      return mark.kind == MetricMarkKindV1::opportunity;
    });
  }
  return MetricSupportManifest::from_clauses(std::move(clauses));
}

[[nodiscard]] Result<PlugDescriptorPreview> preview_descriptor(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem, const ConstructionBudget& budget,
    const ValidatedSurrogateParameters& parameters) {
  if (problem.target_selection().ordered_targets.size() != 1U) {
    return Result<PlugDescriptorPreview>::failure(provider_error(
        "c27_1.full_orbit_single_target_required",
        "Full Orbit CP06 requires exactly one deployed target"));
  }
  if (problem.timing() != TimingConvention::early_service_late_admission ||
      std::find(manifest.optimizer_constraint_applicability
                    .scheduler_optimizer_pairs.begin(),
                manifest.optimizer_constraint_applicability
                    .scheduler_optimizer_pairs.end(),
                problem.applicability_key()) ==
          manifest.optimizer_constraint_applicability
              .scheduler_optimizer_pairs.end()) {
    return Result<PlugDescriptorPreview>::failure(provider_error(
        "c27_1.full_orbit_applicability",
        "the configured scheduler/optimizer/timing tuple is outside CP06"));
  }
  auto geometry = validate_geometry(problem);
  if (!geometry) {
    return Result<PlugDescriptorPreview>::failure(geometry.error());
  }
  if (parameters.provider() != manifest.provider ||
      parameters.parameter_schema_version() !=
          manifest.parameter_schema_version ||
      parameters.parameter_schema_digest() != manifest.parameter_schema_digest ||
      !parameters.typed_value_owner()) {
    return Result<PlugDescriptorPreview>::failure(provider_error(
        "c27_1.full_orbit_parameter_binding",
        "validated parameters are not bound to the CP06 provider schema"));
  }
  const auto typed =
      std::static_pointer_cast<const FullOrbitParameters>(
          parameters.typed_value_owner());
  const BigNat sampled_slots = typed->horizon_slots * typed->replications;
  const BigNat generator_draws = typed->replications * BigNat{4U};
  const BigNat maximum_work{kMaximumConstructionWork};
  if (sampled_slots > maximum_work || generator_draws > maximum_work) {
    return Result<PlugDescriptorPreview>::failure(provider_error(
        "c27_1.full_orbit_work_limit",
        "the requested CP06 population exceeds a frozen scientific work "
        "limit"));
  }
  const auto valid_grant = [&](const CountConstructionGrantV1& grant,
                               const BigNat& required) {
    return grant.applicability == BudgetApplicabilityV1::applicable &&
           grant.amount.has_value() && *grant.amount >= required &&
           *grant.amount <= maximum_work;
  };
  if (!valid_grant(budget.exact_optimizer_calls, sampled_slots) ||
      !valid_grant(budget.configured_generator_draws, generator_draws)) {
    return Result<PlugDescriptorPreview>::failure(provider_error(
        "c27_1.full_orbit_insufficient_grant",
        "optimizer-call and generator-draw grants must cover the exact CP06 "
        "population"));
  }
  // Search-state use is diagnostic telemetry, not a scientific admission
  // condition.  An authored finite per-call ceiling is still transported for
  // a metered exact-search family, but this provider accepts the uncapped form
  // and never infers a cap from scenario dimensions.  Polynomial families do
  // not emit this counter, so an applicable grant would be an inconsistent
  // request and must fail at the framework boundary rather than later in CP06.
  if (!metered_search_family(problem.applicability_key()) &&
      (budget.optimizer_search_states.applicability !=
           BudgetApplicabilityV1::not_applicable ||
       budget.optimizer_search_states.amount.has_value())) {
    return Result<PlugDescriptorPreview>::failure(provider_error(
        "c27_1.full_orbit_search_not_applicable",
        "non-search exact optimizer routes must mark search states not "
        "applicable"));
  }

  auto concrete_manifest = specialize_metric_manifest(
      manifest.metric_clause_upper_envelope,
      problem.target_selection().ordered_targets.front());
  if (!concrete_manifest) {
    return Result<PlugDescriptorPreview>::failure(concrete_manifest.error());
  }
  auto core = production_descriptor(manifest, problem,
                                    concrete_manifest.value(), BigNat{3U});
  if (!core) return Result<PlugDescriptorPreview>::failure(core.error());
  auto budget_digest = digest_construction_budget_v1(budget);
  if (!budget_digest) {
    return Result<PlugDescriptorPreview>::failure(budget_digest.error());
  }
  auto manifest_owner = std::make_shared<const MetricSupportManifest>(
      std::move(concrete_manifest).value());
  std::vector<QueueId> construction_targets;
  construction_targets.reserve(problem.queues().size());
  for (const auto& queue : problem.queues()) {
    construction_targets.push_back(queue.queue_id);
  }
  PlugDescriptorPreview preview{
      1U,
      std::move(core).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      std::move(construction_targets),
      {PointDeploymentPolicyV1::deploy_nominal_point,
       CoefficientCompletionPolicyV1::declared_nominal_completion,
       ProjectionPolicyV1::not_applicable, RecodingPolicyV1::not_applicable,
       EvidenceRolePolicyV1::exact_manifest_roles},
      {{construction_iid_arrival()}, sampled_slots, generator_draws,
       std::nullopt},
      std::move(manifest_owner),
      problem.canonical_digest().value(),
      parameters.canonical_value_digest(),
      std::move(budget_digest).value(),
      manifest.manifest_digest};
  auto preview_digest = canonical_plug_descriptor_preview_digest_v1(preview);
  if (!preview_digest) {
    return Result<PlugDescriptorPreview>::failure(preview_digest.error());
  }
  preview.preview_digest = std::move(preview_digest).value();
  return Result<PlugDescriptorPreview>::success(std::move(preview));
}

[[nodiscard]] Result<RuntimeFieldIdV1> runtime_field_id(
    const std::string_view name) {
  auto value = text_label(name);
  if (!value) return Result<RuntimeFieldIdV1>::failure(value.error());
  return Result<RuntimeFieldIdV1>::success(
      RuntimeFieldIdV1(std::move(value).value()));
}

[[nodiscard]] Result<RuntimeMarkIdV1> runtime_mark_id(
    const std::string_view name) {
  auto value = text_label(name);
  if (!value) return Result<RuntimeMarkIdV1>::failure(value.error());
  return Result<RuntimeMarkIdV1>::success(
      RuntimeMarkIdV1(std::move(value).value()));
}

[[nodiscard]] Result<RuntimeDecoderIdV1> runtime_decoder_id(
    const std::string_view name) {
  auto value = text_label(name);
  if (!value) return Result<RuntimeDecoderIdV1>::failure(value.error());
  return Result<RuntimeDecoderIdV1>::success(
      RuntimeDecoderIdV1(std::move(value).value()));
}

[[nodiscard]] Result<PlugDescriptor> runtime_descriptor(
    const PlugDescriptorCore& core) {
  const bool finite_prefix =
      core.payload_class == PayloadClassV1{
          PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U} ||
      core.payload_class == PayloadClassV1{
          PayloadClassTagV1::empirical_finite_window_response_v1, 1U};
  const std::string runtime_prefix = finite_prefix ? "fofs.c29" : "fofs.cp06";
  const CodecIdentityV1 reduced_state_codec{
      finite_prefix ? "mwperf.c29.scalar-response-state"
                    : "mwperf.c27.closed-three-bin-state",
      1U};
  auto field_id = runtime_field_id(runtime_prefix + ".target-backlog");
  if (!field_id) return Result<PlugDescriptor>::failure(field_id.error());
  std::vector<RuntimeStateFieldV1> fields{{
      field_id.value(), core.state_fields.front(),
      RuntimeDomainKindV1::countable}};

  std::vector<RuntimeMarkDescriptorV1> marks;
  marks.reserve(core.marks.size());
  for (std::size_t index = 0U; index < core.marks.size(); ++index) {
    auto mark_id = runtime_mark_id(runtime_prefix + ".mark." +
                                   std::to_string(index));
    auto decoder_id = runtime_decoder_id(runtime_prefix + ".decoder." +
                                         std::to_string(index));
    if (!mark_id) return Result<PlugDescriptor>::failure(mark_id.error());
    if (!decoder_id) {
      return Result<PlugDescriptor>::failure(decoder_id.error());
    }
    const auto kind = core.marks[index].kind;
    marks.push_back({
        std::move(mark_id).value(),
        core.marks[index],
        std::move(decoder_id).value(),
        kind == MetricMarkKindV1::target_backlog
            ? MarkDecoderSourceV1::predecision_state
            : MarkDecoderSourceV1::c_minus_joint_output,
        kind == MetricMarkKindV1::target_backlog
            ? RuntimeDomainKindV1::countable
            : RuntimeDomainKindV1::finite,
        kind == MetricMarkKindV1::target_backlog
            ? reduced_state_codec
            : CodecIdentityV1{"fofs.metric-mark", 1U},
        kind == MetricMarkKindV1::target_backlog
            ? std::vector<RuntimeFieldIdV1>{field_id.value()}
            : std::vector<RuntimeFieldIdV1>{},
        {}});
  }

  PlugDescriptor descriptor{
      1U,
      core,
      std::move(fields),
      std::nullopt,
      std::nullopt,
      std::move(marks),
      std::nullopt,
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once,
      {{CertificateCategoryV1::validity, CertificateLevelV1::v0_shape,
        CodecIdentityV1{core.mandatory_v0.factor_schema_id,
                        core.mandatory_v0.factor_schema_version}}},
      std::nullopt,
      core.core_digest};
  auto digest = canonical_plug_descriptor_digest_v1(descriptor);
  if (!digest) return Result<PlugDescriptor>::failure(digest.error());
  descriptor.descriptor_digest = std::move(digest).value();
  return Result<PlugDescriptor>::success(std::move(descriptor));
}

[[nodiscard]] Result<RuntimePlugCandidateV1> materialize_three_bin(
    const PortablePlugPayload& payload,
    const ValidatedSurrogateArtifact& artifact,
    const AcceptedCapabilityContract&) {
  if (!std::holds_alternative<PortableThreeBinScalarResponseV1>(
          payload.value())) {
    return Result<RuntimePlugCandidateV1>::failure(provider_error(
        "c27_1.full_orbit_three_bin_payload_required",
        "the CP06 materializer accepts only a validated ThreeBin payload"));
  }
  const PlugDescriptorCore& core = artifact.value().deployed_descriptor;
  if (core.state_fields.size() != 1U ||
      core.state_fields.front().kind != StateFieldKindV1::target_backlog) {
    return Result<RuntimePlugCandidateV1>::failure(provider_error(
        "c27_1.full_orbit_three_bin_domain",
        "the CP06 ThreeBin runtime requires one exact target-backlog field"));
  }
  auto descriptor = runtime_descriptor(core);
  if (!descriptor) {
    return Result<RuntimePlugCandidateV1>::failure(descriptor.error());
  }
  KernelAccess access = FiniteParameterAnalyticFamilyAccess(
      {core.state_fields.front().codec,
       {std::string(kThreeBinServiceResponseCodecIdV1), 1U}},
      {std::string(kThreeBinResponseFamilyIdV1), 1U,
       {std::string(kThreeBinResponseParameterSchemaIdV1), 1U},
       core.state_fields.front().codec},
      [](const CanonicalRuntimeValueV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {{std::string(kThreeBinServiceResponseCodecIdV1), 1U},
             {std::byte{0x01}}});
      });
  SurrogatePlug plug =
      ScalarBacklogResponsePlugV1{payload, std::move(access)};
  return Result<RuntimePlugCandidateV1>::success(
      {std::move(descriptor).value(), std::move(plug)});
}

[[nodiscard]] Result<RuntimePlugCandidateV1>
materialize_finite_prefix_constant_tail(
    const PortablePlugPayload& payload,
    const ValidatedSurrogateArtifact& artifact,
    const AcceptedCapabilityContract&) {
  const auto* response =
      std::get_if<PortableFinitePrefixConstantTailResponseV1>(
          &payload.value());
  if (response == nullptr) {
    return Result<RuntimePlugCandidateV1>::failure(provider_error(
        "c27_1.full_orbit_k_wide_payload_required",
        "the CP07.1 materializer accepts only a validated finite-prefix "
        "constant-tail payload"));
  }
  const PlugDescriptorCore& core = artifact.value().deployed_descriptor;
  if (core.state_fields.size() != 1U ||
      core.state_fields.front().kind != StateFieldKindV1::target_backlog ||
      core.tail.kind != TailRepresentationKindV1::constant_response ||
      core.tail.boundary !=
          std::optional<BigNat>{response->constant_tail_from}) {
    return Result<RuntimePlugCandidateV1>::failure(provider_error(
        "c27_1.full_orbit_k_wide_domain",
        "the CP07.1 runtime requires one exact target-backlog field and "
        "the payload's K+1 constant-tail boundary"));
  }
  auto descriptor = runtime_descriptor(core);
  if (!descriptor) {
    return Result<RuntimePlugCandidateV1>::failure(descriptor.error());
  }
  KernelAccess access = FiniteParameterAnalyticFamilyAccess(
      {core.state_fields.front().codec,
       {std::string(kFinitePrefixConstantTailServiceResponseCodecIdV1), 1U}},
      {std::string(kFinitePrefixConstantTailResponseFamilyIdV1), 1U,
       {std::string(kFinitePrefixConstantTailResponseParameterSchemaIdV1),
        1U},
       core.state_fields.front().codec},
      [](const CanonicalRuntimeValueV1&) {
        return Result<CanonicalRuntimeValueV1>::success(
            {{std::string(
                  kFinitePrefixConstantTailServiceResponseCodecIdV1),
              1U},
             {std::byte{0x01}}});
      });
  SurrogatePlug plug =
      ScalarBacklogResponsePlugV1{payload, std::move(access)};
  return Result<RuntimePlugCandidateV1>::success(
      {std::move(descriptor).value(), std::move(plug)});
}

}  // namespace

Result<MetricSupportManifest> full_orbit_k_wide_metric_manifest_v1() {
  auto prototype = production_metric_manifest();
  if (!prototype) {
    return Result<MetricSupportManifest>::failure(prototype.error());
  }
  std::vector<MetricSupportClauseV1> clauses(
      prototype.value().clauses().begin(),
      prototype.value().clauses().end());
  for (auto& clause : clauses) {
    clause.payload_class = {
        PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U};
    clause.required_roles = k_wide_support_roles();
  }
  auto manifest = MetricSupportManifest::from_clauses(std::move(clauses));
  if (!manifest) {
    return manifest;
  }
  if (manifest.value().canonical_digest().hex() !=
      kKWideMetricManifestDigest) {
    return Result<MetricSupportManifest>::failure(provider_error(
        "c27_1.full_orbit_k_wide_metric_manifest_drift",
        "the reconstructed CP07.1 metric-support manifest differs from "
        "its frozen dynamic-response contract"));
  }
  return manifest;
}

[[nodiscard]] Result<MetricSupportManifest>
full_orbit_cp09_metric_manifest_v1() {
  auto compatibility = full_orbit_k_wide_metric_manifest_v1();
  if (!compatibility) return compatibility;
  std::vector<MetricSupportClauseV1> clauses(
      compatibility.value().clauses().begin(),
      compatibility.value().clauses().end());
  for (auto& clause : clauses) {
    clause.payload_class = {
        PayloadClassTagV1::empirical_finite_window_response_v1, 1U};
  }
  auto manifest = MetricSupportManifest::from_clauses(std::move(clauses));
  if (!manifest) return manifest;
  if (manifest.value().canonical_digest().hex() !=
      kCp09MetricManifestDigest) {
    return Result<MetricSupportManifest>::failure(provider_error(
        "c32.full_orbit_cp09_metric_manifest_drift",
        "the reconstructed CP09 empirical metric-support manifest differs "
        "from its sealed observation-only contract"));
  }
  return manifest;
}

Result<MetricSupportManifest> specialize_full_orbit_metric_manifest_v1(
    const MetricSupportManifest& prototype, const QueueId& target) {
  return specialize_metric_manifest(prototype, target);
}

Result<PlugDescriptorCore> make_full_orbit_scalar_descriptor_v1(
    const SurrogateProviderManifestV1& manifest,
    const FrameworkProblemView& problem,
    const MetricSupportManifest& concrete_metric_manifest,
    BigNat constant_tail_from) {
  return production_descriptor(manifest, problem, concrete_metric_manifest,
                               std::move(constant_tail_from));
}

Result<SurrogateProviderManifestV1> full_orbit_sampler_provider_manifest() {
  auto metric_manifest = production_metric_manifest();
  if (!metric_manifest) {
    return Result<SurrogateProviderManifestV1>::failure(
        metric_manifest.error());
  }
  auto source_build = digest_from_hex(kSourceBuildDigest);
  auto parameter_schema = digest_from_hex(kParameterSchemaDigest);
  auto report_digest = digest_from_hex(kConformanceReportDigest);
  auto expected_manifest = digest_from_hex(kProviderManifestDigest);
  auto report_id = text_label("fofs_cp06_provider_conformance_report_v1");
  if (!source_build) {
    return Result<SurrogateProviderManifestV1>::failure(source_build.error());
  }
  if (!parameter_schema) {
    return Result<SurrogateProviderManifestV1>::failure(
        parameter_schema.error());
  }
  if (!report_digest) {
    return Result<SurrogateProviderManifestV1>::failure(report_digest.error());
  }
  if (!expected_manifest) {
    return Result<SurrogateProviderManifestV1>::failure(
        expected_manifest.error());
  }
  if (!report_id) {
    return Result<SurrogateProviderManifestV1>::failure(report_id.error());
  }

  SurrogateProviderManifestV1 manifest{
      1U,
      {std::string(kProviderId), std::string(kProviderVersion)},
      true,
      std::move(source_build).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {PayloadClassTagV1::three_bin_scalar_response_v1, 1U},
      1U,
      std::move(parameter_schema).value(),
      {1U},
      {1U},
      {1U},
      {},
      {production_pairs(),
       {TimingConvention::early_service_late_admission}},
      {1U,
       1U,
       {TargetCouplingV1::scalar_target},
       {construction_iid_arrival(),
        runtime_arrival(ArrivalNeedKindV1::exact_iid_late),
        runtime_arrival(ArrivalNeedKindV1::full_common_batch),
        runtime_arrival(ArrivalNeedKindV1::target_intensity)}},
      std::move(metric_manifest).value(),
      {MetricSupportRoleV1::deployed_payload,
       MetricSupportRoleV1::deployed_response,
       MetricSupportRoleV1::raw_response,
       MetricSupportRoleV1::nominal_response,
       MetricSupportRoleV1::raw_response_bound_evidence,
       MetricSupportRoleV1::statistical_evidence},
      {{"full_orbit_window_evidence_v1", 1U, 1U << 20U}},
      {{"full_orbit_window_evidence_v1", 1U, 1U,
        std::move(report_id).value(), std::move(report_digest).value()}},
      {1U,
       {PointDeploymentPolicyV1::deploy_nominal_point},
       {CoefficientCompletionPolicyV1::declared_nominal_completion},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      LocalExecutableDeclarationV1{
          std::string(kExecutableId), 1U,
          {"--request", "{request_path}", "--result", "{result_path}"},
          true},
      {1U << 20U, 1U << 20U},
      std::move(expected_manifest).value()};
  auto digest = digest_provider_manifest_v1(manifest);
  if (!digest) {
    return Result<SurrogateProviderManifestV1>::failure(digest.error());
  }
  if (digest.value().hex() != kProviderManifestDigest) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c27_1.full_orbit_provider_manifest_drift",
        "the reconstructed CP06 provider manifest differs from its frozen "
        "digest"));
  }
  manifest.manifest_digest = std::move(digest).value();
  auto validated = validate_provider_manifest(manifest);
  if (!validated) {
    return Result<SurrogateProviderManifestV1>::failure(validated.error());
  }
  if (validated.value().scientific_contract_digest().value().hex() !=
      kScientificContractDigest) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c27_1.full_orbit_scientific_contract_drift",
        "the reconstructed CP06 scientific contract differs from its frozen "
        "digest"));
  }
  return Result<SurrogateProviderManifestV1>::success(std::move(manifest));
}

Result<SurrogateProviderManifestV1>
full_orbit_sampler_k_wide_provider_manifest() {
  auto route = full_orbit_sampler_k_wide_hosted_route();
  auto metric_manifest = full_orbit_k_wide_metric_manifest_v1();
  auto source_build = digest_from_hex(kSourceBuildDigest);
  auto report_digest = digest_from_hex(kKWideConformanceReportDigest);
  auto actual_report_digest = k_wide_conformance_declaration_digest();
  auto report_id = text_label(kKWideConformanceReportId);
  if (!route) {
    return Result<SurrogateProviderManifestV1>::failure(route.error());
  }
  if (!metric_manifest) {
    return Result<SurrogateProviderManifestV1>::failure(
        metric_manifest.error());
  }
  if (!source_build) {
    return Result<SurrogateProviderManifestV1>::failure(source_build.error());
  }
  if (!report_digest) {
    return Result<SurrogateProviderManifestV1>::failure(
        report_digest.error());
  }
  if (!actual_report_digest) {
    return Result<SurrogateProviderManifestV1>::failure(
        actual_report_digest.error());
  }
  if (actual_report_digest.value() != report_digest.value()) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c27_1.full_orbit_k_wide_conformance_declaration_drift",
        "the CP07.1 conformance declaration differs from its frozen "
        "domain-separated digest"));
  }
  if (!report_id) {
    return Result<SurrogateProviderManifestV1>::failure(report_id.error());
  }

  SurrogateProviderManifestV1 manifest{
      1U,
      route.value().provider,
      true,
      std::move(source_build).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U},
      route.value().parameter_schema_version,
      route.value().parameter_schema_digest,
      {1U},
      {1U},
      {1U},
      {},
      {production_pairs(),
       {TimingConvention::early_service_late_admission}},
      {1U,
       1U,
       {TargetCouplingV1::scalar_target},
       {construction_iid_arrival(),
        runtime_arrival(ArrivalNeedKindV1::exact_iid_late),
        runtime_arrival(ArrivalNeedKindV1::full_common_batch),
        runtime_arrival(ArrivalNeedKindV1::target_intensity)}},
      std::move(metric_manifest).value(),
      {MetricSupportRoleV1::deployed_payload,
       MetricSupportRoleV1::deployed_response,
       MetricSupportRoleV1::raw_response,
       MetricSupportRoleV1::raw_response_bound_evidence,
       MetricSupportRoleV1::statistical_evidence},
      {{std::string(kKWideEvidenceSchemaId), 1U, 1U << 20U}},
      {{std::string(kKWideEvidenceSchemaId), 1U, 1U,
        std::move(report_id).value(), std::move(report_digest).value()}},
      {1U,
       {PointDeploymentPolicyV1::deploy_raw_point},
       {CoefficientCompletionPolicyV1::require_complete_raw_points},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      LocalExecutableDeclarationV1{
          route.value().executable_id, 1U,
          {"--request", "{request_path}", "--result", "{result_path}"},
          true},
      {1U << 20U, 1U << 20U},
      route.value().hosted_route_binding_digest};
  auto digest = digest_provider_manifest_v1(manifest);
  if (!digest) {
    return Result<SurrogateProviderManifestV1>::failure(digest.error());
  }
  if (digest.value().hex() != kKWideProviderManifestDigest) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c27_1.full_orbit_k_wide_provider_manifest_drift",
        "the reconstructed CP07.1 provider manifest differs from its "
        "frozen digest"));
  }
  manifest.manifest_digest = std::move(digest).value();
  auto validated = validate_provider_manifest(manifest);
  if (!validated) {
    return Result<SurrogateProviderManifestV1>::failure(validated.error());
  }
  if (validated.value().scientific_contract_digest().value().hex() !=
      kKWideScientificContractDigest) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c27_1.full_orbit_k_wide_scientific_contract_drift",
        "the reconstructed CP07.1 scientific contract differs from its "
        "frozen digest"));
  }
  return Result<SurrogateProviderManifestV1>::success(std::move(manifest));
}

Result<SurrogateProviderManifestV1>
full_orbit_sampler_observation_provider_manifest() {
  auto route = full_orbit_sampler_observation_hosted_route();
  auto metric_manifest = full_orbit_k_wide_metric_manifest_v1();
  auto source_build = digest_from_hex(kSourceBuildDigest);
  auto report_digest = digest_from_hex(kObservationConformanceReportDigest);
  auto actual_report_digest = observation_conformance_declaration_digest();
  auto expected_manifest = digest_from_hex(kObservationProviderManifestDigest);
  auto report_id = text_label(kObservationConformanceReportId);
  if (!route) {
    return Result<SurrogateProviderManifestV1>::failure(route.error());
  }
  if (!metric_manifest) {
    return Result<SurrogateProviderManifestV1>::failure(
        metric_manifest.error());
  }
  if (!source_build) {
    return Result<SurrogateProviderManifestV1>::failure(source_build.error());
  }
  if (!report_digest) {
    return Result<SurrogateProviderManifestV1>::failure(
        report_digest.error());
  }
  if (!actual_report_digest) {
    return Result<SurrogateProviderManifestV1>::failure(
        actual_report_digest.error());
  }
  if (!expected_manifest) {
    return Result<SurrogateProviderManifestV1>::failure(
        expected_manifest.error());
  }
  if (actual_report_digest.value() != report_digest.value()) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c30.full_orbit_observation_conformance_declaration_drift",
        "the observation-capable conformance declaration differs from its "
        "frozen domain-separated digest"));
  }
  if (!report_id) {
    return Result<SurrogateProviderManifestV1>::failure(report_id.error());
  }

  SurrogateProviderManifestV1 manifest{
      1U,
      route.value().provider,
      false,
      std::move(source_build).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {PayloadClassTagV1::finite_prefix_constant_tail_response_v1, 1U},
      route.value().parameter_schema_version,
      route.value().parameter_schema_digest,
      {1U},
      {1U},
      {1U},
      {},
      {production_pairs(),
       {TimingConvention::early_service_late_admission}},
      {1U,
       1U,
       {TargetCouplingV1::scalar_target},
       {construction_iid_arrival(),
        runtime_arrival(ArrivalNeedKindV1::exact_iid_late),
        runtime_arrival(ArrivalNeedKindV1::full_common_batch),
        runtime_arrival(ArrivalNeedKindV1::target_intensity)}},
      std::move(metric_manifest).value(),
      {MetricSupportRoleV1::deployed_payload,
       MetricSupportRoleV1::deployed_response,
       MetricSupportRoleV1::raw_response,
       MetricSupportRoleV1::raw_response_bound_evidence,
       MetricSupportRoleV1::statistical_evidence},
      {{std::string(kKWideEvidenceSchemaId), 1U, 1U << 20U}},
      {{std::string(kKWideEvidenceSchemaId), 1U, 1U,
        std::move(report_id).value(), std::move(report_digest).value()}},
      {1U,
       {PointDeploymentPolicyV1::deploy_raw_point},
       {CoefficientCompletionPolicyV1::require_complete_raw_points},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      LocalExecutableDeclarationV1{
          route.value().executable_id, 1U,
          {"--request", "{request_path}", "--result", "{result_path}"},
          true},
      {1U << 20U, 32U * 1024U * 1024U},
      expected_manifest.value()};
  auto digest = digest_provider_manifest_v1(manifest);
  if (!digest) {
    return Result<SurrogateProviderManifestV1>::failure(digest.error());
  }
  if (digest.value() != expected_manifest.value()) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c30.full_orbit_observation_provider_manifest_drift",
        "the reconstructed observation-capable provider manifest differs "
        "from its frozen digest"));
  }
  manifest.manifest_digest = std::move(digest).value();
  auto validated = validate_provider_manifest(manifest);
  if (!validated) {
    return Result<SurrogateProviderManifestV1>::failure(validated.error());
  }
  if (validated.value().scientific_contract_digest().value().hex() !=
      kObservationScientificContractDigest) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c30.full_orbit_observation_scientific_contract_drift",
        "the reconstructed observation-capable scientific contract differs "
        "from its frozen digest"));
  }
  return Result<SurrogateProviderManifestV1>::success(std::move(manifest));
}

Result<SurrogateProviderManifestV1>
full_orbit_sampler_cp09_provider_manifest() {
  auto route = full_orbit_sampler_cp09_hosted_route();
  auto metric_manifest = full_orbit_cp09_metric_manifest_v1();
  auto source_build = text_digest(kCp09SourceBuildDeclaration);
  auto report_digest = cp09_conformance_declaration_digest();
  auto expected_source = digest_from_hex(kCp09SourceBuildDigest);
  auto expected_report = digest_from_hex(kCp09ConformanceReportDigest);
  auto report_id = text_label(kCp09ConformanceReportId);
  if (!route) {
    return Result<SurrogateProviderManifestV1>::failure(route.error());
  }
  if (!metric_manifest) {
    return Result<SurrogateProviderManifestV1>::failure(
        metric_manifest.error());
  }
  if (!source_build) {
    return Result<SurrogateProviderManifestV1>::failure(source_build.error());
  }
  if (!report_digest) {
    return Result<SurrogateProviderManifestV1>::failure(
        report_digest.error());
  }
  if (!expected_source) {
    return Result<SurrogateProviderManifestV1>::failure(
        expected_source.error());
  }
  if (!expected_report) {
    return Result<SurrogateProviderManifestV1>::failure(
        expected_report.error());
  }
  if (source_build.value() != expected_source.value()) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c32.full_orbit_cp09_source_identity_drift",
        "the CP09 source declaration differs from its frozen digest"));
  }
  if (report_digest.value() != expected_report.value()) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c32.full_orbit_cp09_conformance_declaration_drift",
        "the CP09 conformance declaration differs from its frozen "
        "domain-separated digest"));
  }
  if (!report_id) {
    return Result<SurrogateProviderManifestV1>::failure(report_id.error());
  }

  // C14 still supplies the compatibility-only scalar metric ceiling used to
  // plan the request.  The authoritative role/policy sets below deliberately
  // exclude deployment: result-v3's only success is Observed and cannot
  // acquire surrogate-artifact or V0 authority.
  SurrogateProviderManifestV1 manifest{
      1U,
      route.value().provider,
      false,
      std::move(source_build).value(),
      ConstructionMethodV1::sampled_offline,
      ProducerModeV1::local_executable_builder,
      SemanticTagV1::scalar_backlog_response,
      RuntimeAccessTagV1::finite_parameter_analytic_family,
      {PayloadClassTagV1::empirical_finite_window_response_v1, 1U},
      route.value().parameter_schema_version,
      route.value().parameter_schema_digest,
      {1U},
      {1U},
      {1U},
      {{"observation_poisson_rejection_rounds_v1", BigNat{0U}},
       {"observation_poisson_variates_v1", BigNat{0U}},
       {"observation_rng_draws_available_v1", BigNat{0U}}},
      {production_pairs(),
       {TimingConvention::early_service_late_admission}},
      {1U,
       1U,
       {TargetCouplingV1::scalar_target},
       {construction_iid_arrival(),
        runtime_arrival(ArrivalNeedKindV1::exact_iid_late),
        runtime_arrival(ArrivalNeedKindV1::full_common_batch),
        runtime_arrival(ArrivalNeedKindV1::target_intensity)}},
      std::move(metric_manifest).value(),
      {MetricSupportRoleV1::raw_response_bound_evidence,
       MetricSupportRoleV1::statistical_evidence,
       MetricSupportRoleV1::compression_evidence},
      {{std::string(kCp09EvidenceSchemaId), 1U,
        kNonScientificByteCeiling}},
      {{std::string(kCp09EvidenceSchemaId), 1U, 1U,
        std::move(report_id).value(), std::move(report_digest).value()}},
      {1U,
       {PointDeploymentPolicyV1::not_applicable},
       {CoefficientCompletionPolicyV1::not_applicable},
       {ProjectionPolicyV1::not_applicable},
       {RecodingPolicyV1::not_applicable},
       {EvidenceRolePolicyV1::exact_manifest_roles},
       {},
       {}},
      LocalExecutableDeclarationV1{
          route.value().executable_id, 1U,
          {"--request", "{request_path}", "--result", "{result_path}"},
          true},
      {kSurrogateBuildProtocolV1MaximumRequestBytes,
       kSurrogateBuildProtocolV1MaximumResultBytes},
      expected_source.value()};
  auto digest = digest_provider_manifest_v1(manifest);
  if (!digest) {
    return Result<SurrogateProviderManifestV1>::failure(digest.error());
  }
  // Transport limits are operational rather than scientific.  Seal their
  // current declaration at construction time instead of freezing a byte
  // quota into source as a second identity authority.
  manifest.manifest_digest = std::move(digest).value();
  auto validated = validate_provider_manifest(manifest);
  if (!validated) {
    return Result<SurrogateProviderManifestV1>::failure(validated.error());
  }
  if (validated.value().scientific_contract_digest().value().hex() !=
      kCp09ScientificContractDigest) {
    return Result<SurrogateProviderManifestV1>::failure(provider_error(
        "c32.full_orbit_cp09_scientific_contract_drift",
        "the reconstructed CP09 scientific contract differs from its frozen "
        "digest"));
  }
  return Result<SurrogateProviderManifestV1>::success(std::move(manifest));
}

Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_provider_registration() {
  auto manifest = full_orbit_sampler_provider_manifest();
  if (!manifest) {
    return Result<SurrogateProviderRegistrationV1>::failure(manifest.error());
  }
  const SurrogateProviderManifestV1 manifest_value = manifest.value();
  auto executable = SurrogateRegistryAssembler::executable_spec(
      manifest_value.provider, manifest_value.manifest_digest,
      std::string(kExecutableId),
      std::filesystem::path(
          surrogate::providers::config::kExecutablePath),
      1U, {"--host-contract", "c27-local-v1"},
      std::chrono::milliseconds{3'600'000}, 4096U, 16U * 1024U * 1024U,
      32U * 1024U * 1024U, 64U,
      kNonScientificWallTimeCeiling);
  if (!executable) {
    return Result<SurrogateProviderRegistrationV1>::failure(
        executable.error());
  }

  DescriptorPreviewerV1 previewer =
      [manifest_value](const FrameworkProblemView& problem,
                       const MetricRequirements&, const ConstructionBudget& budget,
                       const ValidatedSurrogateParameters& parameters) {
        return preview_descriptor(manifest_value, problem, budget, parameters);
      };
  SurrogateProviderRegistrationV1 registration{
      std::move(manifest).value(),
      validate_parameters,
      std::move(previewer),
      LocalExecutableBuilderV1{std::move(executable).value()},
      materialize_three_bin,
      std::nullopt};
  return Result<SurrogateProviderRegistrationV1>::success(
      std::move(registration));
}

Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_k_wide_provider_registration() {
  auto manifest = full_orbit_sampler_k_wide_provider_manifest();
  if (!manifest) {
    return Result<SurrogateProviderRegistrationV1>::failure(manifest.error());
  }
  const SurrogateProviderManifestV1 manifest_value = manifest.value();
  auto route = full_orbit_sampler_k_wide_hosted_route();
  if (!route) {
    return Result<SurrogateProviderRegistrationV1>::failure(route.error());
  }
  auto executable = SurrogateRegistryAssembler::executable_spec(
      manifest_value.provider, manifest_value.manifest_digest,
      route.value().executable_id,
      std::filesystem::path(
          surrogate::providers::config::kExecutablePath),
      1U, {"--host-contract", "c27-local-v1"},
      std::chrono::milliseconds{3'600'000}, 4096U,
      16U * 1024U * 1024U, 32U * 1024U * 1024U, 64U,
      kNonScientificWallTimeCeiling);
  if (!executable) {
    return Result<SurrogateProviderRegistrationV1>::failure(
        executable.error());
  }

  DescriptorPreviewerV1 previewer =
      [manifest_value](const FrameworkProblemView& problem,
                       const MetricRequirements&,
                       const ConstructionBudget& budget,
                       const ValidatedSurrogateParameters& parameters) {
        return preview_full_orbit_k_wide_registered_route(
            manifest_value, problem, budget, parameters);
      };
  SurrogateProviderRegistrationV1 registration{
      std::move(manifest).value(),
      validate_full_orbit_k_wide_parameters,
      std::move(previewer),
      LocalExecutableBuilderV1{std::move(executable).value()},
      materialize_finite_prefix_constant_tail,
      std::nullopt};
  return Result<SurrogateProviderRegistrationV1>::success(
      std::move(registration));
}

Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_observation_provider_registration() {
  auto manifest = full_orbit_sampler_observation_provider_manifest();
  if (!manifest) {
    return Result<SurrogateProviderRegistrationV1>::failure(manifest.error());
  }
  const SurrogateProviderManifestV1 manifest_value = manifest.value();
  auto route = full_orbit_sampler_observation_hosted_route();
  if (!route) {
    return Result<SurrogateProviderRegistrationV1>::failure(route.error());
  }
  auto executable = SurrogateRegistryAssembler::executable_spec(
      manifest_value.provider, manifest_value.manifest_digest,
      route.value().executable_id,
      std::filesystem::path(
          surrogate::providers::config::kExecutablePath),
      1U, {"--host-contract", "c30-local-v2"},
      std::chrono::milliseconds{3'600'000}, 4096U,
      16U * 1024U * 1024U, 32U * 1024U * 1024U, 64U,
      kNonScientificWallTimeCeiling);
  if (!executable) {
    return Result<SurrogateProviderRegistrationV1>::failure(
        executable.error());
  }

  DescriptorPreviewerV1 previewer =
      [manifest_value](const FrameworkProblemView& problem,
                       const MetricRequirements&,
                       const ConstructionBudget& budget,
                       const ValidatedSurrogateParameters& parameters) {
        return preview_full_orbit_observation_registered_route(
            manifest_value, problem, budget, parameters);
      };
  ObservationEnvelopeValidatorV1 observation_validator =
      validate_full_orbit_observation_envelope;
  SurrogateProviderRegistrationV1 registration{
      std::move(manifest).value(),
      validate_full_orbit_observation_parameters,
      std::move(previewer),
      LocalExecutableBuilderV1{std::move(executable).value()},
      materialize_finite_prefix_constant_tail,
      std::nullopt,
      2U,
      std::move(observation_validator)};
  return Result<SurrogateProviderRegistrationV1>::success(
      std::move(registration));
}

Result<SurrogateProviderRegistrationV1>
full_orbit_sampler_cp09_provider_registration() {
  auto manifest = full_orbit_sampler_cp09_provider_manifest();
  if (!manifest) {
    return Result<SurrogateProviderRegistrationV1>::failure(manifest.error());
  }
  const SurrogateProviderManifestV1 manifest_value = manifest.value();
  auto route = full_orbit_sampler_cp09_hosted_route();
  if (!route) {
    return Result<SurrogateProviderRegistrationV1>::failure(route.error());
  }
  auto executable = SurrogateRegistryAssembler::executable_spec(
      manifest_value.provider, manifest_value.manifest_digest,
      route.value().executable_id,
      std::filesystem::path(
          surrogate::providers::config::kExecutablePath),
      1U, {"--host-contract", "c32-local-v3"},
      kNonScientificWallTimeCeiling,
      kSurrogateBuildProtocolV1MaximumResultBytes,
      kSurrogateBuildProtocolV1MaximumRequestBytes,
      kSurrogateBuildProtocolV1MaximumResultBytes,
      std::numeric_limits<std::size_t>::max(),
      kNonScientificWallTimeCeiling);
  if (!executable) {
    return Result<SurrogateProviderRegistrationV1>::failure(
        executable.error());
  }
  DescriptorPreviewerV1 previewer =
      [manifest_value](const FrameworkProblemView& problem,
                       const MetricRequirements&,
                       const ConstructionBudget& budget,
                       const ValidatedSurrogateParameters& parameters) {
        return preview_full_orbit_cp09_registered_route(
            manifest_value, problem, budget, parameters);
      };
  ObservationEnvelopeValidatorV1 observation_validator =
      validate_full_orbit_cp09_observation_envelope;
  SurrogateProviderRegistrationV1 registration{
      std::move(manifest).value(),
      validate_full_orbit_cp09_parameters,
      std::move(previewer),
      LocalExecutableBuilderV1{std::move(executable).value()},
      materialize_finite_prefix_constant_tail,
      std::nullopt,
      3U,
      std::move(observation_validator)};
  return Result<SurrogateProviderRegistrationV1>::success(
      std::move(registration));
}

}  // namespace mwperf::detail
