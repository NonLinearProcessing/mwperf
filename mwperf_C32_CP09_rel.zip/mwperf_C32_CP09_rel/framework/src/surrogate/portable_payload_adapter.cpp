#include "mwperf/surrogate/portable_payload_adapter.hpp"

#include <algorithm>
#include <array>
#include <concepts>
#include <cstddef>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic adapter_invariant(std::string message) {
  return Diagnostic{DiagnosticCategory::internal,
                    "c15.portable_adapter_validated_artifact_invariant",
                    std::move(message), std::nullopt, std::nullopt, {}};
}

// The adapter changes only representation.  An already-exact rational is
// copied verbatim; a binary64 value is replaced by its identical exact dyadic
// value.  In either case the output scalar has the rational wire alternative.
[[nodiscard]] PortableScientificScalar rationalized_scalar(
    const PortableScientificScalar& value) {
  if (value.kind() == PortableScientificScalarKind::rational) {
    return PortableScientificScalar::rational(value.rational_value());
  }
  return PortableScientificScalar::rational(
      binary64_as_exact_rational(value));
}

[[nodiscard]] ExactRational exact_value(
    const PortableScientificScalar& value) {
  if (value.kind() == PortableScientificScalarKind::rational) {
    return value.rational_value();
  }
  return binary64_as_exact_rational(value);
}

void rationalize(std::vector<PortableScientificScalar>& values) {
  for (auto& value : values) {
    value = rationalized_scalar(value);
  }
}

void rationalize(PortableValueV1& value) {
  std::visit(
      [](auto& active) {
        using Active = std::remove_cvref_t<decltype(active)>;
        if constexpr (std::same_as<Active, PortableScientificScalar>) {
          active = rationalized_scalar(active);
        } else {
          rationalize(active);
        }
      },
      value);
}

void rationalize(NamedPortableValueV1& value) {
  rationalize(value.value);
}

void rationalize(FiniteParameterAnalyticDataV1& payload) {
  for (auto& parameter : payload.parameters) {
    rationalize(parameter);
  }
  for (auto& table : payload.tables) {
    rationalize(table);
  }
  for (auto& coordinate : payload.mathematical_domain) {
    coordinate.lower = rationalized_scalar(coordinate.lower);
    coordinate.upper = rationalized_scalar(coordinate.upper);
  }
}

void rationalize(FiniteLawAtomV1& atom) {
  atom.probability = rationalized_scalar(atom.probability);
}

void rationalize(std::vector<FiniteLawRowV1>& rows) {
  for (auto& row : rows) {
    for (auto& atom : row.atoms) {
      rationalize(atom);
    }
  }
}

void rationalize(std::vector<ExplicitOrderedWordV1>& words) {
  for (auto& word : words) {
    word.probability = rationalized_scalar(word.probability);
  }
}

void rationalize(FinitePredictiveStoppingTablesV1& tables) {
  rationalize(tables.continuation_rows);
  rationalize(tables.stop_or_event_rows);
  rationalize(tables.terminal_or_exit_rows);
}

void rationalize(
    std::variant<std::vector<ExplicitOrderedWordV1>,
                 FinitePredictiveStoppingTablesV1>& representation) {
  std::visit([](auto& active) { rationalize(active); }, representation);
}

void rationalize(FiniteLawTableAlternativeV1& table) {
  std::visit(
      [](auto& active) {
        using Active = std::remove_cvref_t<decltype(active)>;
        if constexpr (std::same_as<Active, StationaryMarkedEdgeTableV1>) {
          rationalize(active.joint_edge_rows);
        } else if constexpr (std::same_as<Active,
                                          StagedOpportunityFluxTableV1>) {
          rationalize(active.opportunity_rows);
          rationalize(active.successor_mark_rows);
        } else if constexpr (std::same_as<Active,
                                          TemporalContinuationTableV1>) {
          rationalize(active.continuation_rows);
        } else if constexpr (std::same_as<Active, StoppedPathTableV1>) {
          rationalize(active.representation);
          active.nonhit_or_nontermination_probability = rationalized_scalar(
              active.nonhit_or_nontermination_probability);
        } else if constexpr (std::same_as<Active,
                                          RomrResidenceWordTableV1>) {
          rationalize(active.representation);
          active.nontermination_probability =
              rationalized_scalar(active.nontermination_probability);
        } else {
          static_assert(
              std::same_as<Active, CoupledCommonScheduleTableV1>);
          rationalize(active.common_joint_rows);
        }
      },
      table);
}

void rationalize(FiniteLawTablesV1& payload) {
  for (auto& entry : payload.state_dictionary) {
    rationalize(entry.coordinates);
  }
  for (auto& entry : payload.mark_dictionary) {
    rationalize(entry.coordinates);
  }
  rationalize(payload.table);
}

void rationalize(RegisteredRuntimeRecipeV1& payload) {
  for (auto& parameter : payload.parameters) {
    rationalize(parameter);
  }
}

void rationalize(CoefficientIdentificationV1& identification) {
  identification.proposal_conditioning.observed_nonnegative_value =
      rationalized_scalar(
          identification.proposal_conditioning.observed_nonnegative_value);
  if (identification.raw_point.has_value()) {
    identification.raw_point =
        rationalized_scalar(*identification.raw_point);
  }
}

void rationalize(ResponseCoefficientTripleV1& coefficients) {
  for (auto& coefficient : coefficients) {
    coefficient.value = rationalized_scalar(coefficient.value);
  }
}

void rationalize(ThreeBinScalarResponseV1& response) {
  for (auto& identification : response.raw_response.identifications) {
    rationalize(identification);
  }
  if (response.nominal_response.has_value()) {
    rationalize(response.nominal_response->coefficients);
  }
  if (response.projection_center.has_value()) {
    rationalize(response.projection_center->mean_vector);
  }
  if (response.projected_mean.has_value()) {
    rationalize(response.projected_mean->mean_vector);
  }
  if (response.recoded_response.has_value()) {
    rationalize(response.recoded_response->coefficients);
  }
  for (auto& envelope : response.raw_envelopes) {
    rationalize(envelope.lower);
    rationalize(envelope.upper);
  }
}

void rationalize(FinitePrefixCoefficientIdentificationV1& identification) {
  identification.pooled_unserved_mass =
      rationalized_scalar(identification.pooled_unserved_mass);
  identification.pooled_served_mass =
      rationalized_scalar(identification.pooled_served_mass);
  identification.raw_point = rationalized_scalar(identification.raw_point);
}

void rationalize(FinitePrefixRawResponseEnvelopeV1& envelope) {
  rationalize(envelope.lower);
  rationalize(envelope.upper);
  envelope.concentration_radius_lower =
      rationalized_scalar(envelope.concentration_radius_lower);
  envelope.concentration_radius_upper =
      rationalized_scalar(envelope.concentration_radius_upper);
  envelope.floating_point_enclosure =
      rationalized_scalar(envelope.floating_point_enclosure);
}

void rationalize(FinitePrefixConstantTailResponseV1& response) {
  for (auto& identification : response.raw_response.identifications) {
    rationalize(identification);
  }
  for (auto& envelope : response.raw_envelopes) {
    rationalize(envelope);
  }
}

[[nodiscard]] bool has_binary64_sampler_scalars(
    const FinitePrefixConstantTailResponseV1& response) {
  const auto binary64 = [](const PortableScientificScalar& value) {
    return value.kind() == PortableScientificScalarKind::binary64;
  };
  for (const auto& identification : response.raw_response.identifications) {
    if (!binary64(identification.pooled_unserved_mass) ||
        !binary64(identification.pooled_served_mass) ||
        !binary64(identification.raw_point)) {
      return false;
    }
  }
  for (const auto& envelope : response.raw_envelopes) {
    if (!std::all_of(envelope.lower.begin(), envelope.lower.end(), binary64) ||
        !std::all_of(envelope.upper.begin(), envelope.upper.end(), binary64) ||
        !binary64(envelope.concentration_radius_lower) ||
        !binary64(envelope.concentration_radius_upper) ||
        !binary64(envelope.floating_point_enclosure)) {
      return false;
    }
  }
  return true;
}

void rationalize(ResponseEnvelopeEvidenceV1& payload) {
  rationalize(payload.lower_response);
  rationalize(payload.upper_response);
}

void rationalize(DirectMetricPayloadV1& payload) {
  for (auto& value : payload.values) {
    rationalize(value.value);
  }
}

[[nodiscard]] std::size_t coefficient_index(
    const ThreeBinCoefficientV1 bin) noexcept {
  switch (bin) {
    case ThreeBinCoefficientV1::one:
      return 0U;
    case ThreeBinCoefficientV1::two:
      return 1U;
    case ThreeBinCoefficientV1::tail_from_three:
      return 2U;
  }
  return 3U;
}

[[nodiscard]] Result<std::array<ExactRational, 3U>> ordered_coefficients(
    const ResponseCoefficientTripleV1& coefficients) {
  std::array<ExactRational, 3U> result{ExactRational::zero(),
                                      ExactRational::zero(),
                                      ExactRational::zero()};
  std::array<bool, 3U> seen{false, false, false};
  for (const auto& coefficient : coefficients) {
    const std::size_t index = coefficient_index(coefficient.bin);
    if (index >= result.size() || seen[index]) {
      return Result<std::array<ExactRational, 3U>>::failure(
          adapter_invariant(
              "the validated deployed response has a duplicate or unknown "
              "three-bin coefficient"));
    }
    result[index] = exact_value(coefficient.value);
    seen[index] = true;
  }
  if (!seen[0U] || !seen[1U] || !seen[2U]) {
    return Result<std::array<ExactRational, 3U>>::failure(
        adapter_invariant(
            "the validated deployed response does not cover all three "
            "protocol-defined backlog bins"));
  }
  return Result<std::array<ExactRational, 3U>>::success(std::move(result));
}

[[nodiscard]] Result<std::array<ExactRational, 3U>> raw_coefficients(
    const RawResponseProductV1& product) {
  std::array<ExactRational, 3U> result{ExactRational::zero(),
                                      ExactRational::zero(),
                                      ExactRational::zero()};
  std::array<bool, 3U> seen{false, false, false};
  for (const auto& identification : product.identifications) {
    const std::size_t index =
        coefficient_index(identification.target_bin_binding);
    if (index >= result.size() || seen[index] ||
        !identification.raw_point.has_value()) {
      return Result<std::array<ExactRational, 3U>>::failure(
          adapter_invariant(
              "the validated deployed raw response is not one complete "
              "point-valued three-bin product"));
    }
    result[index] = exact_value(*identification.raw_point);
    seen[index] = true;
  }
  if (!seen[0U] || !seen[1U] || !seen[2U]) {
    return Result<std::array<ExactRational, 3U>>::failure(
        adapter_invariant(
            "the validated deployed raw response does not cover all three "
            "protocol-defined backlog bins"));
  }
  return Result<std::array<ExactRational, 3U>>::success(std::move(result));
}

[[nodiscard]] Result<std::array<ExactRational, 3U>>
selected_response_coefficients(const ThreeBinScalarResponseV1& response) {
  return std::visit(
      [&response](const auto& selected)
          -> Result<std::array<ExactRational, 3U>> {
        using Selected = std::remove_cvref_t<decltype(selected)>;
        if constexpr (std::same_as<Selected, RawResponseProductId>) {
          if (selected != response.raw_response.product_id) {
            return Result<std::array<ExactRational, 3U>>::failure(
                adapter_invariant(
                    "the deployed raw response identity is not the raw "
                    "product retained by the validated response row"));
          }
          return raw_coefficients(response.raw_response);
        } else if constexpr (std::same_as<Selected,
                                          NominalResponseProductId>) {
          if (!response.nominal_response.has_value() ||
              selected != response.nominal_response->product_id) {
            return Result<std::array<ExactRational, 3U>>::failure(
                adapter_invariant(
                    "the deployed nominal response identity is not retained "
                    "by the validated response row"));
          }
          return ordered_coefficients(response.nominal_response->coefficients);
        } else {
          static_assert(std::same_as<Selected, RecodedResponseProductId>);
          if (!response.recoded_response.has_value() ||
              selected != response.recoded_response->product_id) {
            return Result<std::array<ExactRational, 3U>>::failure(
                adapter_invariant(
                    "the deployed recoded response identity is not retained "
                    "by the validated response row"));
          }
          return ordered_coefficients(response.recoded_response->coefficients);
        }
      },
      response.deployed_response_product_id);
}

struct FinitePrefixCoefficients final {
  std::vector<ExactRational> service_by_level;
  BigNat constant_tail_from;
  ExactRational constant_tail_service;
};

[[nodiscard]] Result<FinitePrefixCoefficients>
finite_prefix_coefficients(
    const FinitePrefixConstantTailResponseV1& response) {
  auto cutoff = checked_index(response.response_cutoff, 6U);
  if (!cutoff || cutoff.value() < 2U || cutoff.value() > 5U ||
      response.raw_response.response_cutoff != response.response_cutoff ||
      response.deployed_response_product_id !=
          response.raw_response.product_id ||
      response.raw_response.identifications.size() != cutoff.value() + 2U) {
    return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
        "the validated finite-prefix response has inconsistent cutoff, "
        "product, or coordinate cardinality"));
  }

  const BigNat tail_from = response.response_cutoff + BigNat{1U};
  std::vector<ExactRational> prefix(cutoff.value() + 1U,
                                    ExactRational::zero());
  std::vector<bool> seen(cutoff.value() + 2U, false);
  std::optional<ExactRational> tail;
  for (std::size_t ordinal = 0U;
       ordinal < response.raw_response.identifications.size(); ++ordinal) {
    const auto& identification =
        response.raw_response.identifications[ordinal];
    const ExactRational point = exact_value(identification.raw_point);
    if (!point.is_nonnegative() || point > ExactRational::one()) {
      return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
          "the validated finite-prefix response contains a coefficient "
          "outside [0,1]"));
    }

    const auto& coordinate = identification.coordinate;
    const bool ordered_coordinate =
        (ordinal == 0U &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::structural_level_zero &&
         coordinate.level_or_tail_from.is_zero()) ||
        (ordinal > 0U && ordinal <= cutoff.value() &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::exact_level &&
         coordinate.level_or_tail_from == BigNat{ordinal}) ||
        (ordinal == cutoff.value() + 1U &&
         coordinate.kind ==
             FinitePrefixResponseCoordinateKindV1::constant_tail &&
         coordinate.level_or_tail_from == tail_from);
    if (!ordered_coordinate) {
      return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
          "the validated finite-prefix response coordinates are not in "
          "canonical zero, exact-level, constant-tail order"));
    }
    switch (coordinate.kind) {
      case FinitePrefixResponseCoordinateKindV1::structural_level_zero:
        if (!coordinate.level_or_tail_from.is_zero() || seen[0U] ||
            !point.is_zero()) {
          return Result<FinitePrefixCoefficients>::failure(
              adapter_invariant(
                  "the validated finite-prefix response has an invalid or "
                  "duplicate structural level-zero coefficient"));
        }
        prefix[0U] = point;
        seen[0U] = true;
        break;
      case FinitePrefixResponseCoordinateKindV1::exact_level: {
        auto level = checked_index(coordinate.level_or_tail_from,
                                   cutoff.value() + 1U);
        if (!level || level.value() == 0U || seen[level.value()]) {
          return Result<FinitePrefixCoefficients>::failure(
              adapter_invariant(
                  "the validated finite-prefix response has a duplicate or "
                  "nonconsecutive exact-level coefficient"));
        }
        prefix[level.value()] = point;
        seen[level.value()] = true;
        break;
      }
      case FinitePrefixResponseCoordinateKindV1::constant_tail:
        if (coordinate.level_or_tail_from != tail_from ||
            seen[cutoff.value() + 1U]) {
          return Result<FinitePrefixCoefficients>::failure(
              adapter_invariant(
                  "the validated finite-prefix response has an invalid or "
                  "duplicate constant-tail coefficient"));
        }
        tail = point;
        seen[cutoff.value() + 1U] = true;
        break;
    }
  }
  if (std::any_of(seen.begin(), seen.end(),
                  [](const bool value) { return !value; }) ||
      !tail.has_value()) {
    return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
        "the validated finite-prefix response does not cover structural "
        "zero, every exact level, and one constant tail"));
  }

  if (response.raw_envelopes.size() != 1U) {
    return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
        "the validated finite-prefix response must retain exactly one "
        "simultaneous raw envelope"));
  }
  const auto& envelope = response.raw_envelopes.front();
  if (envelope.response_cutoff != response.response_cutoff ||
      envelope.source_product != response.raw_response.product_id ||
      envelope.covered_coordinates.size() != seen.size() ||
      envelope.lower.size() != seen.size() ||
      envelope.upper.size() != seen.size()) {
    return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
        "the validated finite-prefix envelope has inconsistent cutoff, "
        "source product, or vector cardinality"));
  }
  for (std::size_t ordinal = 0U; ordinal < seen.size(); ++ordinal) {
    const ExactRational lower = exact_value(envelope.lower[ordinal]);
    const ExactRational upper = exact_value(envelope.upper[ordinal]);
    const ExactRational point = exact_value(
        response.raw_response.identifications[ordinal].raw_point);
    if (envelope.covered_coordinates[ordinal] !=
            response.raw_response.identifications[ordinal].coordinate ||
        !lower.is_nonnegative() || upper > ExactRational::one() ||
        upper < lower || point < lower || point > upper) {
      return Result<FinitePrefixCoefficients>::failure(adapter_invariant(
          "the validated finite-prefix envelope does not contain its "
          "ordered nominal coefficient in [0,1]"));
    }
  }
  return Result<FinitePrefixCoefficients>::success(
      {std::move(prefix), tail_from, std::move(*tail)});
}

[[nodiscard]] PortablePayloadContextV1 portable_context(
    const ValidatedSurrogateArtifact& validated_artifact) {
  const SurrogateArtifactV1& artifact = validated_artifact.value();
  const ArtifactValidationBindingsV1& bindings =
      validated_artifact.validation_bindings();
  return PortablePayloadContextV1{
      artifact.payload_class,
      artifact.deployed_semantic,
      artifact.runtime_access,
      bindings.build_identity_digest,
      bindings.request_digest,
      bindings.framework_problem_view_digest,
      artifact.deployed_descriptor.deployed_targets,
      artifact.payload_identity,
      artifact.payload_digest,
      artifact.structural_manifest_echo,
      artifact.realized_metric_bindings,
      artifact.family_evidence,
      artifact.scoped_evidence};
}

}  // namespace

Result<PortablePlugPayload> adapt_portable_payload(
    const ValidatedSurrogateArtifact& artifact) {
  const SurrogateArtifactV1& source = artifact.value();
  const PortablePayloadContextV1 context = portable_context(artifact);

  if (const auto* payload =
          std::get_if<ThreeBinScalarResponseV1>(&source.payload)) {
    ThreeBinScalarResponseV1 normalized = *payload;
    rationalize(normalized);
    auto coefficients = selected_response_coefficients(normalized);
    if (!coefficients) {
      return Result<PortablePlugPayload>::failure(coefficients.error());
    }
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableThreeBinScalarResponseV1{
            context, normalized.deployed_target,
            std::move(coefficients).value(),
            normalized.deployed_response_product_id, std::move(normalized)}));
  }

  if (const auto* payload =
          std::get_if<FinitePrefixConstantTailResponseV1>(&source.payload)) {
    // C15 already enforces this at the wire boundary, but retain the same
    // closed representation check here before conversion.  A trusted test
    // seam or future caller must not be able to substitute an equal rational
    // value for sampler-authored binary64 bits and thereby erase wire
    // identity at C16.
    if (!has_binary64_sampler_scalars(*payload)) {
      return Result<PortablePlugPayload>::failure(adapter_invariant(
          "the finite-prefix sampler record must retain binary64 bits for "
          "every mass, coefficient, interval, radius, and enclosure"));
    }
    FinitePrefixConstantTailResponseV1 normalized = *payload;
    rationalize(normalized);
    auto coefficients = finite_prefix_coefficients(normalized);
    if (!coefficients) {
      return Result<PortablePlugPayload>::failure(coefficients.error());
    }
    auto values = std::move(coefficients).value();
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableFinitePrefixConstantTailResponseV1{
            context, normalized.deployed_target, normalized.response_cutoff,
            std::move(values.service_by_level),
            std::move(values.constant_tail_from),
            std::move(values.constant_tail_service),
            normalized.deployed_response_product_id,
            std::move(normalized)}));
  }

  if (const auto* payload =
          std::get_if<FiniteParameterAnalyticDataV1>(&source.payload)) {
    FiniteParameterAnalyticDataV1 normalized = *payload;
    rationalize(normalized);
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableFiniteParameterAnalyticDataV1{context,
                                              std::move(normalized)}));
  }

  if (const auto* payload = std::get_if<FiniteLawTablesV1>(&source.payload)) {
    FiniteLawTablesV1 normalized = *payload;
    rationalize(normalized);
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableFiniteLawTablesV1{context, std::move(normalized)}));
  }

  if (const auto* payload =
          std::get_if<RegisteredRuntimeRecipeV1>(&source.payload)) {
    RegisteredRuntimeRecipeV1 normalized = *payload;
    rationalize(normalized);
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableRegisteredRuntimeRecipeV1{context, std::move(normalized)}));
  }

  if (const auto* payload =
          std::get_if<ResponseEnvelopeEvidenceV1>(&source.payload)) {
    ResponseEnvelopeEvidenceV1 normalized = *payload;
    rationalize(normalized);
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableResponseEnvelopeEvidenceV1{context, std::move(normalized)}));
  }

  if (const auto* payload =
          std::get_if<DirectMetricPayloadV1>(&source.payload)) {
    DirectMetricPayloadV1 normalized = *payload;
    rationalize(normalized);
    return Result<PortablePlugPayload>::success(PortablePlugPayload(
        PortableDirectMetricPayloadV1{context, std::move(normalized)}));
  }

  return Result<PortablePlugPayload>::failure(adapter_invariant(
      "the validated artifact contains an unknown payload alternative"));
}

}  // namespace mwperf
