#pragma once

#include <span>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/finite_prefix_constant_tail_response.hpp"

namespace mwperf {
struct FamilyEvidenceEnvelopeV1;
}

namespace mwperf::artifact::detail {

// Shared intrinsic shape authority for production C15 validation and focused
// protocol tests.  Contextual request/provider/evidence identities are checked
// by validate_surrogate_build_result after this shape has been accepted.
[[nodiscard]] Result<void> validate_finite_prefix_constant_tail_shape_v1(
    const FinitePrefixConstantTailResponseV1& response,
    const BigNat& expected_response_cutoff,
    const BigNat& descriptor_tail_from);

[[nodiscard]] Result<void>
validate_finite_prefix_constant_tail_family_evidence_v1(
    const FinitePrefixConstantTailResponseV1& response,
    std::span<const FamilyEvidenceEnvelopeV1> family_evidence);

}  // namespace mwperf::artifact::detail
