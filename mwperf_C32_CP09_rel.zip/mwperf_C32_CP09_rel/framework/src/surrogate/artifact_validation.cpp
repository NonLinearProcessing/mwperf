#include "mwperf/surrogate/surrogate_artifact.hpp"

#include "mwperf/surrogate/detail/request_binding_validation.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

#include "metrics/plug_descriptor_core_validation_detail.hpp"
#include "artifact_auxiliary_validation.hpp"
#include "artifact_object_graph_validation.hpp"
#include "family_evidence_validation.hpp"
#include "finite_prefix_constant_tail_validation.hpp"
#include "non_table_payload_validation.hpp"
#include "payload_wire.hpp"

namespace mwperf {
namespace {

using artifact::detail::OrderedJson;

constexpr std::uint32_t kProtocolVersion = 1U;

template <typename Enum>
[[nodiscard]] std::string_view enum_text(Enum value);
template <typename T>
[[nodiscard]] Result<T> fail(std::string code, std::string message,
                             std::optional<std::string> path = std::nullopt);
[[nodiscard]] Result<void> require_wire_fields(
    const OrderedJson& object, std::span<const std::string_view> fields,
    const std::string& path);
[[nodiscard]] Result<void> require_wire_fields(
    const OrderedJson& object, std::span<const std::string_view> required,
    std::span<const std::string_view> optional, const std::string& path);
template <std::size_t N>
[[nodiscard]] Result<void> require_wire_fields(
    const OrderedJson& object, const std::array<std::string_view, N>& fields,
    const std::string& path);
[[nodiscard]] Result<std::string> required_string(const OrderedJson& value,
                                                  std::string path,
                                                  bool token = false);
[[nodiscard]] Result<std::uint32_t> required_u32(const OrderedJson& value,
                                                 std::string path);
[[nodiscard]] Result<std::uint32_t> required_version_one(
    const OrderedJson& value, std::string path, std::string_view record_name);
[[nodiscard]] OrderedJson encode_provider(const ProviderIdentityV1& value);
[[nodiscard]] Result<ProviderIdentityV1> decode_provider(
    const OrderedJson& value, const std::string& path);
[[nodiscard]] OrderedJson encode_scalar_array(
    const std::vector<PortableScientificScalar>& values);
[[nodiscard]] Result<std::vector<PortableScientificScalar>>
decode_scalar_array(const OrderedJson& value, const std::string& path);
template <typename Value, typename Encode>
[[nodiscard]] OrderedJson encode_vector(const std::vector<Value>& values,
                                        Encode&& encode);
template <typename Value, typename Decode>
[[nodiscard]] Result<std::vector<Value>> decode_vector(
    const OrderedJson& value, const std::string& path, Decode&& decode);
template <typename StrongIdType>
[[nodiscard]] OrderedJson encode_strong_id(const StrongIdType& value);
template <typename StrongIdType>
[[nodiscard]] Result<StrongIdType> decode_strong_id(
    const OrderedJson& value, const std::string& path);
template <typename Enum>
[[nodiscard]] Result<Enum> decode_enum(const OrderedJson& value,
                                       const std::string& path,
                                       std::span<const Enum> domain);
template <typename T, typename Decode>
[[nodiscard]] Result<std::optional<T>> decode_optional_member(
    const OrderedJson& object, std::string_view field,
    const std::string& path, Decode&& decode);
[[nodiscard]] OrderedJson encode_analytic(
    const FiniteParameterAnalyticDataV1& value);
[[nodiscard]] Result<FiniteParameterAnalyticDataV1> decode_analytic(
    const OrderedJson& value, const std::string& path);
[[nodiscard]] OrderedJson encode_runtime_recipe(
    const RegisteredRuntimeRecipeV1& value);
[[nodiscard]] Result<RegisteredRuntimeRecipeV1> decode_runtime_recipe(
    const OrderedJson& value, const std::string& path);
[[nodiscard]] OrderedJson encode_three_bin(
    const ThreeBinScalarResponseV1& value);
[[nodiscard]] Result<ThreeBinScalarResponseV1> decode_three_bin(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access);
[[nodiscard]] OrderedJson encode_finite_prefix_constant_tail(
    const FinitePrefixConstantTailResponseV1& value);
[[nodiscard]] Result<FinitePrefixConstantTailResponseV1>
decode_finite_prefix_constant_tail(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access);
[[nodiscard]] OrderedJson encode_finite_tables(const FiniteLawTablesV1& value);
[[nodiscard]] Result<FiniteLawTablesV1> decode_finite_tables(
    const OrderedJson& value, const std::string& path);
[[nodiscard]] OrderedJson encode_deployed_id(
    const DeployedResponseProductIdV1& value);
[[nodiscard]] Result<DeployedResponseProductIdV1> decode_deployed_id(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access);

template <>
[[nodiscard]] std::string_view enum_text<StateFieldKindV1>(
    const StateFieldKindV1 value) {
  switch (value) {
    case StateFieldKindV1::target_backlog: return "target_backlog";
    case StateFieldKindV1::configured_arrival_predictive_phase: return "configured_arrival_predictive_phase";
    case StateFieldKindV1::surrogate_phase: return "surrogate_phase";
    case StateFieldKindV1::controller_memory: return "controller_memory";
    case StateFieldKindV1::resource_coordinate: return "resource_coordinate";
    case StateFieldKindV1::local_margin: return "local_margin";
    case StateFieldKindV1::event_state: return "event_state";
    case StateFieldKindV1::entrance_label_state: return "entrance_label_state";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<DirectMetricValidityBasisV1>(
    const DirectMetricValidityBasisV1 value) {
  switch (value) {
    case DirectMetricValidityBasisV1::exact_closed_form:
      return "exact_closed_form";
    case DirectMetricValidityBasisV1::exact_finite_enumeration:
      return "exact_finite_enumeration";
    case DirectMetricValidityBasisV1::certified_bound:
      return "certified_bound";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<FieldOwnershipV1>(
    const FieldOwnershipV1 value) {
  switch (value) {
    case FieldOwnershipV1::framework_exact: return "framework_exact";
    case FieldOwnershipV1::surrogate_owned: return "surrogate_owned";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<MetricRevealStageV1>(
    const MetricRevealStageV1 value) {
  switch (value) {
    case MetricRevealStageV1::predecision: return "predecision";
    case MetricRevealStageV1::decision: return "decision";
    case MetricRevealStageV1::arrival: return "arrival";
    case MetricRevealStageV1::postarrival: return "postarrival";
    case MetricRevealStageV1::completed_edge: return "completed_edge";
    case MetricRevealStageV1::entrance_label: return "entrance_label";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<MetricMarkKindV1>(
    const MetricMarkKindV1 value) {
  switch (value) {
    case MetricMarkKindV1::target_backlog: return "target_backlog";
    case MetricMarkKindV1::predictive_phase: return "predictive_phase";
    case MetricMarkKindV1::opportunity: return "opportunity";
    case MetricMarkKindV1::actual_departure: return "actual_departure";
    case MetricMarkKindV1::arrival_batch: return "arrival_batch";
    case MetricMarkKindV1::successor_backlog: return "successor_backlog";
    case MetricMarkKindV1::schedule_projection: return "schedule_projection";
    case MetricMarkKindV1::full_schedule: return "full_schedule";
    case MetricMarkKindV1::edge_increment: return "edge_increment";
    case MetricMarkKindV1::event_indicator: return "event_indicator";
    case MetricMarkKindV1::predicate: return "predicate";
    case MetricMarkKindV1::predicate_start: return "predicate_start";
    case MetricMarkKindV1::active_component: return "active_component";
    case MetricMarkKindV1::within_batch_rank: return "within_batch_rank";
    case MetricMarkKindV1::batch_size: return "batch_size";
    case MetricMarkKindV1::class_label: return "class_label";
    case MetricMarkKindV1::phase_label: return "phase_label";
    case MetricMarkKindV1::counterfactual_permission: return "counterfactual_permission";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<SelectionKindV1>(
    const SelectionKindV1 value) {
  switch (value) {
    case SelectionKindV1::transient_initial: return "transient_initial";
    case SelectionKindV1::stationary_unique: return "stationary_unique";
    case SelectionKindV1::stationary_class: return "stationary_class";
    case SelectionKindV1::stationary_mixture: return "stationary_mixture";
    case SelectionKindV1::fixed_point_unique: return "fixed_point_unique";
    case SelectionKindV1::fixed_point_id: return "fixed_point_id";
    case SelectionKindV1::prescribed_entrance: return "prescribed_entrance";
    case SelectionKindV1::event_palm: return "event_palm";
    case SelectionKindV1::start_palm: return "start_palm";
    case SelectionKindV1::admission_palm: return "admission_palm";
    case SelectionKindV1::threshold_crossing_palm: return "threshold_crossing_palm";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<MetricResultScopeV1>(
    const MetricResultScopeV1 value) {
  switch (value) {
    case MetricResultScopeV1::not_a_metric_result: return "not_a_metric_result";
    case MetricResultScopeV1::surrogate_law: return "surrogate_law";
    case MetricResultScopeV1::proposal_raw: return "proposal_raw";
    case MetricResultScopeV1::response_envelope: return "response_envelope";
    case MetricResultScopeV1::physical_bound: return "physical_bound";
  }
  return {};
}

[[nodiscard]] OrderedJson encode_codec(const CodecIdentityV1& value) {
  return OrderedJson{{"id", value.id}, {"version", value.version}};
}

[[nodiscard]] Result<CodecIdentityV1> decode_codec(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"id", "version"}, path);
  if (!shape) return Result<CodecIdentityV1>::failure(shape.error());
  auto id = required_string(value.at("id"), path + "/id", true);
  auto version = required_u32(value.at("version"), path + "/version");
  if (!id) return Result<CodecIdentityV1>::failure(id.error());
  if (!version) return Result<CodecIdentityV1>::failure(version.error());
  return Result<CodecIdentityV1>::success(
      CodecIdentityV1{std::move(id).value(), std::move(version).value()});
}

[[nodiscard]] OrderedJson encode_state_field(
    const StateFieldDescriptorV1& value) {
  return OrderedJson{{"kind", std::string(enum_text(value.kind))},
                     {"ownership", std::string(enum_text(value.ownership))},
                     {"codec", encode_codec(value.codec)}};
}

[[nodiscard]] Result<StateFieldDescriptorV1> decode_state_field(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 3U>{"kind", "ownership", "codec"},
      path);
  if (!shape) return Result<StateFieldDescriptorV1>::failure(shape.error());
  constexpr std::array kinds{
      StateFieldKindV1::target_backlog,
      StateFieldKindV1::configured_arrival_predictive_phase,
      StateFieldKindV1::surrogate_phase, StateFieldKindV1::controller_memory,
      StateFieldKindV1::resource_coordinate, StateFieldKindV1::local_margin,
      StateFieldKindV1::event_state, StateFieldKindV1::entrance_label_state};
  constexpr std::array ownerships{FieldOwnershipV1::framework_exact,
                                  FieldOwnershipV1::surrogate_owned};
  auto kind = decode_enum(value.at("kind"), path + "/kind",
                          std::span<const StateFieldKindV1>(kinds));
  auto ownership = decode_enum(value.at("ownership"), path + "/ownership",
                               std::span<const FieldOwnershipV1>(ownerships));
  auto codec = decode_codec(value.at("codec"), path + "/codec");
  if (!kind) return Result<StateFieldDescriptorV1>::failure(kind.error());
  if (!ownership) return Result<StateFieldDescriptorV1>::failure(ownership.error());
  if (!codec) return Result<StateFieldDescriptorV1>::failure(codec.error());
  return Result<StateFieldDescriptorV1>::success(StateFieldDescriptorV1{
      std::move(kind).value(), std::move(ownership).value(),
      std::move(codec).value()});
}

[[nodiscard]] OrderedJson encode_mark_descriptor(const MarkDescriptorV1& value) {
  return OrderedJson{{"kind", std::string(enum_text(value.kind))},
                     {"reveal_stage", std::string(enum_text(value.reveal_stage))},
                     {"codec", encode_codec(value.codec)},
                     {"common_realization_group", value.common_realization_group}};
}

[[nodiscard]] Result<MarkDescriptorV1> decode_mark_descriptor(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 4U>{"kind", "reveal_stage", "codec",
                                              "common_realization_group"}, path);
  if (!shape) return Result<MarkDescriptorV1>::failure(shape.error());
  constexpr std::array kinds{
      MetricMarkKindV1::target_backlog, MetricMarkKindV1::predictive_phase,
      MetricMarkKindV1::opportunity, MetricMarkKindV1::actual_departure,
      MetricMarkKindV1::arrival_batch, MetricMarkKindV1::successor_backlog,
      MetricMarkKindV1::schedule_projection, MetricMarkKindV1::full_schedule,
      MetricMarkKindV1::edge_increment, MetricMarkKindV1::event_indicator,
      MetricMarkKindV1::predicate, MetricMarkKindV1::predicate_start,
      MetricMarkKindV1::active_component, MetricMarkKindV1::within_batch_rank,
      MetricMarkKindV1::batch_size, MetricMarkKindV1::class_label,
      MetricMarkKindV1::phase_label,
      MetricMarkKindV1::counterfactual_permission};
  constexpr std::array stages{
      MetricRevealStageV1::predecision, MetricRevealStageV1::decision,
      MetricRevealStageV1::arrival, MetricRevealStageV1::postarrival,
      MetricRevealStageV1::completed_edge,
      MetricRevealStageV1::entrance_label};
  auto kind = decode_enum(value.at("kind"), path + "/kind",
                          std::span<const MetricMarkKindV1>(kinds));
  auto stage = decode_enum(value.at("reveal_stage"), path + "/reveal_stage",
                           std::span<const MetricRevealStageV1>(stages));
  auto codec = decode_codec(value.at("codec"), path + "/codec");
  if (!value.at("common_realization_group").is_string()) {
    return fail<MarkDescriptorV1>("artifact_wire_expected_string",
                                  "common realization group must be a string",
                                  path + "/common_realization_group");
  }
  if (!kind) return Result<MarkDescriptorV1>::failure(kind.error());
  if (!stage) return Result<MarkDescriptorV1>::failure(stage.error());
  if (!codec) return Result<MarkDescriptorV1>::failure(codec.error());
  return Result<MarkDescriptorV1>::success(MarkDescriptorV1{
      std::move(kind).value(), std::move(stage).value(),
      std::move(codec).value(),
      value.at("common_realization_group").get<std::string>()});
}

[[nodiscard]] OrderedJson encode_named_value(const NamedPortableValueV1& value) {
  OrderedJson encoded;
  std::string kind;
  if (const auto* scalar = std::get_if<PortableScientificScalar>(&value.value)) {
    kind = "scalar";
    encoded = artifact::detail::wire::encode_scalar(*scalar);
  } else {
    kind = "vector";
    encoded = encode_scalar_array(
        std::get<std::vector<PortableScientificScalar>>(value.value));
  }
  return OrderedJson{{"name", value.name}, {"kind", kind},
                     {"value", std::move(encoded)}};
}

[[nodiscard]] Result<NamedPortableValueV1> decode_named_value(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 3U>{"name", "kind", "value"}, path);
  if (!shape) return Result<NamedPortableValueV1>::failure(shape.error());
  auto name = required_string(value.at("name"), path + "/name", true);
  auto kind = required_string(value.at("kind"), path + "/kind", true);
  if (!name) return Result<NamedPortableValueV1>::failure(name.error());
  if (!kind) return Result<NamedPortableValueV1>::failure(kind.error());
  if (kind.value() == "scalar") {
    auto scalar = artifact::detail::wire::decode_scalar(value.at("value"), path + "/value");
    if (!scalar) return Result<NamedPortableValueV1>::failure(scalar.error());
    return Result<NamedPortableValueV1>::success(
        NamedPortableValueV1{std::move(name).value(), std::move(scalar).value()});
  }
  if (kind.value() == "vector") {
    auto values = decode_scalar_array(value.at("value"), path + "/value");
    if (!values) return Result<NamedPortableValueV1>::failure(values.error());
    return Result<NamedPortableValueV1>::success(
        NamedPortableValueV1{std::move(name).value(), std::move(values).value()});
  }
  return fail<NamedPortableValueV1>("artifact_wire_value_kind",
                                    "unknown portable-value kind",
                                    path + "/kind");
}

[[nodiscard]] OrderedJson encode_domain(const PortableDomainV1& value) {
  return OrderedJson{{"coordinate_name", value.coordinate_name},
                     {"lower", artifact::detail::wire::encode_scalar(value.lower)},
                     {"upper", artifact::detail::wire::encode_scalar(value.upper)},
                     {"lower_closed", value.lower_closed},
                     {"upper_closed", value.upper_closed}};
}

[[nodiscard]] Result<PortableDomainV1> decode_domain(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(value,
      std::array<std::string_view,5U>{"coordinate_name","lower","upper","lower_closed","upper_closed"}, path);
  if (!shape) return Result<PortableDomainV1>::failure(shape.error());
  auto name = required_string(value.at("coordinate_name"), path + "/coordinate_name", true);
  auto lower = artifact::detail::wire::decode_scalar(value.at("lower"), path + "/lower");
  auto upper = artifact::detail::wire::decode_scalar(value.at("upper"), path + "/upper");
  if (!value.at("lower_closed").is_boolean() || !value.at("upper_closed").is_boolean()) {
    return fail<PortableDomainV1>("artifact_wire_expected_boolean", "domain endpoint flags must be booleans", path);
  }
  if (!name) return Result<PortableDomainV1>::failure(name.error());
  if (!lower) return Result<PortableDomainV1>::failure(lower.error());
  if (!upper) return Result<PortableDomainV1>::failure(upper.error());
  return Result<PortableDomainV1>::success(PortableDomainV1{
      std::move(name).value(), std::move(lower).value(),
      std::move(upper).value(), value.at("lower_closed").get<bool>(),
      value.at("upper_closed").get<bool>()});
}

}  // namespace
}  // namespace mwperf

namespace mwperf {
namespace {

template <>
[[nodiscard]] std::string_view enum_text<ArrivalNeedKindV1>(
    const ArrivalNeedKindV1 value) {
  switch (value) {
    case ArrivalNeedKindV1::target_intensity: return "target_intensity";
    case ArrivalNeedKindV1::arrival_moment: return "arrival_moment";
    case ArrivalNeedKindV1::full_common_batch: return "full_common_batch";
    case ArrivalNeedKindV1::predictive_phase: return "predictive_phase";
    case ArrivalNeedKindV1::sequential_law: return "sequential_law";
    case ArrivalNeedKindV1::entrance_labels: return "entrance_labels";
    case ArrivalNeedKindV1::finite_support: return "finite_support";
    case ArrivalNeedKindV1::transform: return "transform";
    case ArrivalNeedKindV1::exact_iid_late: return "exact_iid_late";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<ArrivalCapabilityUseV1>(
    const ArrivalCapabilityUseV1 value) {
  switch (value) {
    case ArrivalCapabilityUseV1::runtime: return "runtime";
    case ArrivalCapabilityUseV1::construction: return "construction";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<CapabilityProvisionNeedV1>(
    const CapabilityProvisionNeedV1 value) {
  switch (value) {
    case CapabilityProvisionNeedV1::any: return "any";
    case CapabilityProvisionNeedV1::portable: return "portable";
    case CapabilityProvisionNeedV1::process_local: return "process_local";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<TransformKind>(
    const TransformKind value) {
  switch (value) {
    case TransformKind::exact_pmf: return "exact_pmf";
    case TransformKind::exact_pgf: return "exact_pgf";
    case TransformKind::closed_transform: return "closed_transform";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<DistributionScope>(
    const DistributionScope value) {
  switch (value) {
    case DistributionScope::joint_vector: return "joint_vector";
    case DistributionScope::per_coordinate: return "per_coordinate";
  }
  return {};
}

template <>
[[nodiscard]] std::string_view enum_text<MetricEvidenceScopeV1>(
    const MetricEvidenceScopeV1 value) {
  switch (value) {
    case MetricEvidenceScopeV1::none: return "none";
    case MetricEvidenceScopeV1::raw_static_proposal:
      return "raw_static_proposal";
    case MetricEvidenceScopeV1::nominal_static_proposal:
      return "nominal_static_proposal";
    case MetricEvidenceScopeV1::projection_center: return "projection_center";
    case MetricEvidenceScopeV1::projected_surrogate_mean:
      return "projected_surrogate_mean";
    case MetricEvidenceScopeV1::recoded_static_proposal:
      return "recoded_static_proposal";
    case MetricEvidenceScopeV1::optimizer_interval_raw:
      return "optimizer_interval_raw";
    case MetricEvidenceScopeV1::deployed_surrogate_law:
      return "deployed_surrogate_law";
    case MetricEvidenceScopeV1::numerical_result: return "numerical_result";
    case MetricEvidenceScopeV1::validity_or_lift: return "validity_or_lift";
    case MetricEvidenceScopeV1::physical_system: return "physical_system";
  }
  return {};
}

[[nodiscard]] OrderedJson encode_metric_clause_id(
    const MetricClauseIdV1& value) {
  return OrderedJson{{"metric_id", value.metric_id},
                     {"authored_index", std::to_string(value.authored_index)}};
}

[[nodiscard]] Result<MetricClauseIdV1> decode_metric_clause_id(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"metric_id", "authored_index"},
      path);
  if (!shape) return Result<MetricClauseIdV1>::failure(shape.error());
  auto metric_id = required_string(value.at("metric_id"), path + "/metric_id", true);
  auto index = artifact::detail::wire::decode_big_nat(
      value.at("authored_index"), path + "/authored_index");
  if (!metric_id) return Result<MetricClauseIdV1>::failure(metric_id.error());
  if (!index) return Result<MetricClauseIdV1>::failure(index.error());
  if (index.value().value() > BigInt(std::numeric_limits<std::size_t>::max())) {
    return fail<MetricClauseIdV1>("artifact_wire_size_overflow",
                                  "authored metric index exceeds size_t",
                                  path + "/authored_index");
  }
  return Result<MetricClauseIdV1>::success(MetricClauseIdV1{
      std::move(metric_id).value(),
      index.value().value().convert_to<std::size_t>()});
}

[[nodiscard]] OrderedJson encode_portable_value(const PortableValueV1& value) {
  if (const auto* scalar = std::get_if<PortableScientificScalar>(&value)) {
    return OrderedJson{{"kind", "scalar"},
                       {"value", artifact::detail::wire::encode_scalar(*scalar)}};
  }
  return OrderedJson{
      {"kind", "vector"},
      {"value", encode_scalar_array(
                    std::get<std::vector<PortableScientificScalar>>(value))}};
}

[[nodiscard]] Result<PortableValueV1> decode_portable_value(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"kind", "value"}, path);
  if (!shape) return Result<PortableValueV1>::failure(shape.error());
  auto kind = required_string(value.at("kind"), path + "/kind", true);
  if (!kind) return Result<PortableValueV1>::failure(kind.error());
  if (kind.value() == "scalar") {
    auto scalar = artifact::detail::wire::decode_scalar(value.at("value"),
                                                         path + "/value");
    if (!scalar) return Result<PortableValueV1>::failure(scalar.error());
    return Result<PortableValueV1>::success(std::move(scalar).value());
  }
  if (kind.value() == "vector") {
    auto scalars = decode_scalar_array(value.at("value"), path + "/value");
    if (!scalars) return Result<PortableValueV1>::failure(scalars.error());
    return Result<PortableValueV1>::success(std::move(scalars).value());
  }
  return fail<PortableValueV1>("artifact_wire_value_kind",
                               "unknown portable-value kind", path + "/kind");
}

[[nodiscard]] OrderedJson encode_exact_argument_domain(
    const ExactArgumentDomain& value) {
  return OrderedJson{
      {"lower", artifact::detail::wire::encode_scalar(
                    PortableScientificScalar::rational(value.lower))},
      {"upper", artifact::detail::wire::encode_scalar(
                    PortableScientificScalar::rational(value.upper))},
      {"lower_inclusive", value.lower_inclusive},
      {"upper_inclusive", value.upper_inclusive}};
}

[[nodiscard]] Result<ExactArgumentDomain> decode_exact_argument_domain(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value,
      std::array<std::string_view, 4U>{"lower", "upper", "lower_inclusive",
                                       "upper_inclusive"},
      path);
  if (!shape) return Result<ExactArgumentDomain>::failure(shape.error());
  auto lower = artifact::detail::wire::decode_scalar(value.at("lower"),
                                                      path + "/lower");
  auto upper = artifact::detail::wire::decode_scalar(value.at("upper"),
                                                      path + "/upper");
  if (!lower) return Result<ExactArgumentDomain>::failure(lower.error());
  if (!upper) return Result<ExactArgumentDomain>::failure(upper.error());
  if (lower.value().kind() != PortableScientificScalarKind::rational ||
      upper.value().kind() != PortableScientificScalarKind::rational) {
    return fail<ExactArgumentDomain>(
        "artifact_wire_exact_domain_rational",
        "exact argument-domain endpoints must use rational encoding", path);
  }
  if (!value.at("lower_inclusive").is_boolean() ||
      !value.at("upper_inclusive").is_boolean()) {
    return fail<ExactArgumentDomain>("artifact_wire_expected_boolean",
                                     "domain closure flags must be booleans",
                                     path);
  }
  return Result<ExactArgumentDomain>::success(ExactArgumentDomain{
      lower.value().rational_value(), upper.value().rational_value(),
      value.at("lower_inclusive").get<bool>(),
      value.at("upper_inclusive").get<bool>()});
}

[[nodiscard]] OrderedJson encode_arrival_assumption(
    const ArrivalAssumptionV1& value) {
  OrderedJson result{{"kind", std::string(enum_text(value.kind))},
                     {"use", std::string(enum_text(value.use))},
                     {"provision", std::string(enum_text(value.provision))}};
  if (value.moment_order.has_value()) {
    result["moment_order"] =
        artifact::detail::wire::encode_big_nat(*value.moment_order);
  }
  result["joint"] = value.joint;
  result["phase_conditioned"] = value.phase_conditioned;
  if (value.transform_kind.has_value()) {
    result["transform_kind"] = std::string(enum_text(*value.transform_kind));
  }
  if (value.distribution_scope.has_value()) {
    result["distribution_scope"] =
        std::string(enum_text(*value.distribution_scope));
  }
  if (value.argument_domain.has_value()) {
    result["argument_domain"] =
        encode_exact_argument_domain(*value.argument_domain);
  }
  return result;
}

[[nodiscard]] Result<ArrivalAssumptionV1> decode_arrival_assumption(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 5U> required{
      "kind", "use", "provision", "joint", "phase_conditioned"};
  const std::array<std::string_view, 4U> optional{
      "moment_order", "transform_kind", "distribution_scope",
      "argument_domain"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<ArrivalAssumptionV1>::failure(shape.error());
  constexpr std::array kinds{
      ArrivalNeedKindV1::target_intensity, ArrivalNeedKindV1::arrival_moment,
      ArrivalNeedKindV1::full_common_batch, ArrivalNeedKindV1::predictive_phase,
      ArrivalNeedKindV1::sequential_law, ArrivalNeedKindV1::entrance_labels,
      ArrivalNeedKindV1::finite_support, ArrivalNeedKindV1::transform,
      ArrivalNeedKindV1::exact_iid_late};
  constexpr std::array uses{ArrivalCapabilityUseV1::runtime,
                            ArrivalCapabilityUseV1::construction};
  constexpr std::array provisions{CapabilityProvisionNeedV1::any,
                                  CapabilityProvisionNeedV1::portable,
                                  CapabilityProvisionNeedV1::process_local};
  constexpr std::array transforms{TransformKind::exact_pmf,
                                  TransformKind::exact_pgf,
                                  TransformKind::closed_transform};
  constexpr std::array scopes{DistributionScope::joint_vector,
                              DistributionScope::per_coordinate};
  auto kind = decode_enum(value.at("kind"), path + "/kind",
                          std::span<const ArrivalNeedKindV1>(kinds));
  auto use = decode_enum(value.at("use"), path + "/use",
                         std::span<const ArrivalCapabilityUseV1>(uses));
  auto provision = decode_enum(
      value.at("provision"), path + "/provision",
      std::span<const CapabilityProvisionNeedV1>(provisions));
  auto moment = decode_optional_member<BigNat>(
      value, "moment_order", path, artifact::detail::wire::decode_big_nat);
  auto transform = decode_optional_member<TransformKind>(
      value, "transform_kind", path,
      [&transforms](const OrderedJson& item, const std::string& item_path) {
        return decode_enum(item, item_path,
                           std::span<const TransformKind>(transforms));
      });
  auto scope = decode_optional_member<DistributionScope>(
      value, "distribution_scope", path,
      [&scopes](const OrderedJson& item, const std::string& item_path) {
        return decode_enum(item, item_path,
                           std::span<const DistributionScope>(scopes));
      });
  auto domain = decode_optional_member<ExactArgumentDomain>(
      value, "argument_domain", path, decode_exact_argument_domain);
  if (!value.at("joint").is_boolean() ||
      !value.at("phase_conditioned").is_boolean()) {
    return fail<ArrivalAssumptionV1>("artifact_wire_expected_boolean",
                                     "arrival assumption flags must be booleans",
                                     path);
  }
  if (!kind) return Result<ArrivalAssumptionV1>::failure(kind.error());
  if (!use) return Result<ArrivalAssumptionV1>::failure(use.error());
  if (!provision) return Result<ArrivalAssumptionV1>::failure(provision.error());
  if (!moment) return Result<ArrivalAssumptionV1>::failure(moment.error());
  if (!transform) return Result<ArrivalAssumptionV1>::failure(transform.error());
  if (!scope) return Result<ArrivalAssumptionV1>::failure(scope.error());
  if (!domain) return Result<ArrivalAssumptionV1>::failure(domain.error());
  return Result<ArrivalAssumptionV1>::success(ArrivalAssumptionV1{
      std::move(kind).value(), std::move(use).value(),
      std::move(provision).value(), std::move(moment).value(),
      value.at("joint").get<bool>(), value.at("phase_conditioned").get<bool>(),
      std::move(transform).value(), std::move(scope).value(),
      std::move(domain).value()});
}

[[nodiscard]] OrderedJson encode_direct_value(const DirectMetricValueV1& value) {
  return OrderedJson{
      {"value_id", artifact::detail::wire::encode_artifact_object_reference(value.value_id)},
      {"metric_clause_id", encode_metric_clause_id(value.metric_clause_id)},
      {"ordered_targets", encode_vector(value.ordered_targets, [](const QueueId& id) { return encode_strong_id(id); })},
      {"value", encode_portable_value(value.value)},
      {"request_digest", artifact::detail::wire::encode_digest(value.request_digest)},
      {"normalized_metric_request_digest", artifact::detail::wire::encode_digest(value.normalized_metric_request_digest)},
      {"target_selection_digest", artifact::detail::wire::encode_digest(value.target_selection_digest)},
      {"configured_arrival_digest", artifact::detail::wire::encode_digest(value.configured_arrival_digest)},
      {"accepted_contract_digest", artifact::detail::wire::encode_digest(value.accepted_contract_digest)},
      {"selection_assumptions", encode_vector(value.selection_assumptions, [](const SelectionKindV1 item) { return OrderedJson(std::string(enum_text(item))); })},
      {"arrival_assumptions", encode_vector(value.arrival_assumptions, encode_arrival_assumption)},
      {"result_scope", std::string(enum_text(value.result_scope))},
      {"validity_basis", std::string(enum_text(value.validity_basis))},
      {"evidence_ids", encode_vector(value.evidence_ids, artifact::detail::wire::encode_artifact_object_reference)}};
}

[[nodiscard]] Result<DirectMetricValueV1> decode_direct_value(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 14U> fields{
      "value_id", "metric_clause_id", "ordered_targets", "value",
      "request_digest", "normalized_metric_request_digest",
      "target_selection_digest", "configured_arrival_digest",
      "accepted_contract_digest", "selection_assumptions",
      "arrival_assumptions", "result_scope", "validity_basis", "evidence_ids"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<DirectMetricValueV1>::failure(shape.error());
  constexpr std::array selections{
      SelectionKindV1::transient_initial, SelectionKindV1::stationary_unique,
      SelectionKindV1::stationary_class, SelectionKindV1::stationary_mixture,
      SelectionKindV1::fixed_point_unique, SelectionKindV1::fixed_point_id,
      SelectionKindV1::prescribed_entrance, SelectionKindV1::event_palm,
      SelectionKindV1::start_palm, SelectionKindV1::admission_palm,
      SelectionKindV1::threshold_crossing_palm};
  constexpr std::array scopes{
      MetricResultScopeV1::not_a_metric_result,
      MetricResultScopeV1::surrogate_law, MetricResultScopeV1::proposal_raw,
      MetricResultScopeV1::response_envelope,
      MetricResultScopeV1::physical_bound};
  constexpr std::array bases{DirectMetricValidityBasisV1::exact_closed_form,
                             DirectMetricValidityBasisV1::exact_finite_enumeration,
                             DirectMetricValidityBasisV1::certified_bound};
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("value_id"), path + "/value_id");
  auto clause = decode_metric_clause_id(value.at("metric_clause_id"), path + "/metric_clause_id");
  auto targets = decode_vector<QueueId>(value.at("ordered_targets"), path + "/ordered_targets", decode_strong_id<QueueId>);
  auto decoded_value = decode_portable_value(value.at("value"), path + "/value");
  auto request = artifact::detail::wire::decode_digest(value.at("request_digest"), path + "/request_digest");
  auto normalized = artifact::detail::wire::decode_digest(value.at("normalized_metric_request_digest"), path + "/normalized_metric_request_digest");
  auto selection_digest = artifact::detail::wire::decode_digest(value.at("target_selection_digest"), path + "/target_selection_digest");
  auto arrival = artifact::detail::wire::decode_digest(value.at("configured_arrival_digest"), path + "/configured_arrival_digest");
  auto contract = artifact::detail::wire::decode_digest(value.at("accepted_contract_digest"), path + "/accepted_contract_digest");
  auto selection = decode_vector<SelectionKindV1>(value.at("selection_assumptions"), path + "/selection_assumptions", [&selections](const OrderedJson& item, const std::string& item_path) { return decode_enum(item, item_path, std::span<const SelectionKindV1>(selections)); });
  auto assumptions = decode_vector<ArrivalAssumptionV1>(value.at("arrival_assumptions"), path + "/arrival_assumptions", decode_arrival_assumption);
  auto scope = decode_enum(value.at("result_scope"), path + "/result_scope", std::span<const MetricResultScopeV1>(scopes));
  auto basis = decode_enum(value.at("validity_basis"), path + "/validity_basis", std::span<const DirectMetricValidityBasisV1>(bases));
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(value.at("evidence_ids"), path + "/evidence_ids", artifact::detail::wire::decode_artifact_object_reference);
  if (!id) return Result<DirectMetricValueV1>::failure(id.error());
  if (!clause) return Result<DirectMetricValueV1>::failure(clause.error());
  if (!targets) return Result<DirectMetricValueV1>::failure(targets.error());
  if (!decoded_value) return Result<DirectMetricValueV1>::failure(decoded_value.error());
  if (!request) return Result<DirectMetricValueV1>::failure(request.error());
  if (!normalized) return Result<DirectMetricValueV1>::failure(normalized.error());
  if (!selection_digest) return Result<DirectMetricValueV1>::failure(selection_digest.error());
  if (!arrival) return Result<DirectMetricValueV1>::failure(arrival.error());
  if (!contract) return Result<DirectMetricValueV1>::failure(contract.error());
  if (!selection) return Result<DirectMetricValueV1>::failure(selection.error());
  if (!assumptions) return Result<DirectMetricValueV1>::failure(assumptions.error());
  if (!scope) return Result<DirectMetricValueV1>::failure(scope.error());
  if (!basis) return Result<DirectMetricValueV1>::failure(basis.error());
  if (!evidence) return Result<DirectMetricValueV1>::failure(evidence.error());
  return Result<DirectMetricValueV1>::success(DirectMetricValueV1{
      std::move(id).value(), std::move(clause).value(), std::move(targets).value(),
      std::move(decoded_value).value(), std::move(request).value(),
      std::move(normalized).value(), std::move(selection_digest).value(),
      std::move(arrival).value(), std::move(contract).value(),
      std::move(selection).value(), std::move(assumptions).value(),
      std::move(scope).value(), std::move(basis).value(),
      std::move(evidence).value()});
}

[[nodiscard]] OrderedJson encode_direct_payload(const DirectMetricPayloadV1& value) {
  return OrderedJson{{"payload_version", value.payload_version},
                     {"values", encode_vector(value.values, encode_direct_value)}};
}

[[nodiscard]] Result<DirectMetricPayloadV1> decode_direct_payload(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(value, std::array<std::string_view, 2U>{"payload_version", "values"}, path);
  if (!shape) return Result<DirectMetricPayloadV1>::failure(shape.error());
  auto version = required_version_one(value.at("payload_version"), path + "/payload_version", "direct metric payload");
  auto values = decode_vector<DirectMetricValueV1>(value.at("values"), path + "/values", decode_direct_value);
  if (!version) return Result<DirectMetricPayloadV1>::failure(version.error());
  if (!values) return Result<DirectMetricPayloadV1>::failure(values.error());
  return Result<DirectMetricPayloadV1>::success(DirectMetricPayloadV1{
      std::move(version).value(), std::move(values).value()});
}

[[nodiscard]] OrderedJson encode_response_envelope_payload(
    const ResponseEnvelopeEvidenceV1& value) {
  OrderedJson result{
      {"payload_version", value.payload_version},
      {"ordered_deployed_targets", encode_vector(value.ordered_deployed_targets, [](const QueueId& id) { return encode_strong_id(id); })},
      {"result_scope", std::string(enum_text(value.result_scope))},
      {"evidence_scope", std::string(enum_text(value.evidence_scope))},
      {"lower_response", encode_three_bin(value.lower_response)},
      {"upper_response", encode_three_bin(value.upper_response)},
      {"lower_response_product", encode_deployed_id(value.lower_response_product)},
      {"upper_response_product", encode_deployed_id(value.upper_response_product)},
      {"comparison_domain_id", artifact::detail::wire::encode_artifact_object_reference(value.comparison_domain_id)},
      {"typed_evidence_components", encode_vector(value.typed_evidence_components, artifact::detail::wire::encode_artifact_object_reference)},
      {"authorizes_point_product", value.authorizes_point_product}};
  if (value.authorized_point_product.has_value()) {
    result["authorized_point_product"] = encode_deployed_id(*value.authorized_point_product);
  }
  return result;
}

[[nodiscard]] Result<ResponseEnvelopeEvidenceV1> decode_response_envelope_payload(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 11U> required{
      "payload_version", "ordered_deployed_targets", "result_scope",
      "evidence_scope", "lower_response", "upper_response",
      "lower_response_product", "upper_response_product",
      "comparison_domain_id", "typed_evidence_components",
      "authorizes_point_product"};
  const std::array<std::string_view, 1U> optional{"authorized_point_product"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<ResponseEnvelopeEvidenceV1>::failure(shape.error());
  constexpr std::array result_scopes{
      MetricResultScopeV1::not_a_metric_result,
      MetricResultScopeV1::surrogate_law, MetricResultScopeV1::proposal_raw,
      MetricResultScopeV1::response_envelope,
      MetricResultScopeV1::physical_bound};
  constexpr std::array evidence_scopes{
      MetricEvidenceScopeV1::none, MetricEvidenceScopeV1::raw_static_proposal,
      MetricEvidenceScopeV1::nominal_static_proposal,
      MetricEvidenceScopeV1::projection_center,
      MetricEvidenceScopeV1::projected_surrogate_mean,
      MetricEvidenceScopeV1::recoded_static_proposal,
      MetricEvidenceScopeV1::optimizer_interval_raw,
      MetricEvidenceScopeV1::deployed_surrogate_law,
      MetricEvidenceScopeV1::numerical_result,
      MetricEvidenceScopeV1::validity_or_lift,
      MetricEvidenceScopeV1::physical_system};
  auto version = required_version_one(value.at("payload_version"), path + "/payload_version", "response envelope payload");
  auto targets = decode_vector<QueueId>(value.at("ordered_deployed_targets"), path + "/ordered_deployed_targets", decode_strong_id<QueueId>);
  auto result_scope = decode_enum(value.at("result_scope"), path + "/result_scope", std::span<const MetricResultScopeV1>(result_scopes));
  auto evidence_scope = decode_enum(value.at("evidence_scope"), path + "/evidence_scope", std::span<const MetricEvidenceScopeV1>(evidence_scopes));
  auto lower = decode_three_bin(value.at("lower_response"), path + "/lower_response", access);
  auto upper = decode_three_bin(value.at("upper_response"), path + "/upper_response", access);
  auto lower_id = decode_deployed_id(value.at("lower_response_product"), path + "/lower_response_product", access);
  auto upper_id = decode_deployed_id(value.at("upper_response_product"), path + "/upper_response_product", access);
  auto domain = artifact::detail::wire::decode_artifact_object_reference(value.at("comparison_domain_id"), path + "/comparison_domain_id");
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(value.at("typed_evidence_components"), path + "/typed_evidence_components", artifact::detail::wire::decode_artifact_object_reference);
  if (!value.at("authorizes_point_product").is_boolean()) return fail<ResponseEnvelopeEvidenceV1>("artifact_wire_expected_boolean", "point authorization must be boolean", path + "/authorizes_point_product");
  auto point = decode_optional_member<DeployedResponseProductIdV1>(
      value, "authorized_point_product", path,
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_deployed_id(item, item_path, access);
      });
  if (!version) return Result<ResponseEnvelopeEvidenceV1>::failure(version.error());
  if (!targets) return Result<ResponseEnvelopeEvidenceV1>::failure(targets.error());
  if (!result_scope) return Result<ResponseEnvelopeEvidenceV1>::failure(result_scope.error());
  if (!evidence_scope) return Result<ResponseEnvelopeEvidenceV1>::failure(evidence_scope.error());
  if (!lower) return Result<ResponseEnvelopeEvidenceV1>::failure(lower.error());
  if (!upper) return Result<ResponseEnvelopeEvidenceV1>::failure(upper.error());
  if (!lower_id) return Result<ResponseEnvelopeEvidenceV1>::failure(lower_id.error());
  if (!upper_id) return Result<ResponseEnvelopeEvidenceV1>::failure(upper_id.error());
  if (!domain) return Result<ResponseEnvelopeEvidenceV1>::failure(domain.error());
  if (!evidence) return Result<ResponseEnvelopeEvidenceV1>::failure(evidence.error());
  if (!point) return Result<ResponseEnvelopeEvidenceV1>::failure(point.error());
  return Result<ResponseEnvelopeEvidenceV1>::success(ResponseEnvelopeEvidenceV1{
      std::move(version).value(), std::move(targets).value(),
      std::move(result_scope).value(), std::move(evidence_scope).value(),
      std::move(lower).value(), std::move(upper).value(),
      std::move(lower_id).value(), std::move(upper_id).value(),
      std::move(domain).value(), std::move(evidence).value(),
      value.at("authorizes_point_product").get<bool>(),
      std::move(point).value()});
}

[[nodiscard]] std::string_view payload_tag(const ArtifactPayloadV1& payload) {
  switch (payload.index()) {
    case 0U: return "three_bin_scalar_response_v1";
    case 1U: return "finite_parameter_analytic_data_v1";
    case 2U: return "finite_law_tables_v1";
    case 3U: return "registered_runtime_recipe_v1";
    case 4U: return "response_envelope_evidence_v1";
    case 5U: return "direct_metric_payload_v1";
    case 6U: return "finite_prefix_constant_tail_response_v1";
  }
  return {};
}

}  // namespace

namespace artifact::detail::wire {

OrderedJson encode_payload_wire_v1(const ArtifactPayloadV1& payload) {
  OrderedJson body = std::visit(
      [](const auto& value) -> OrderedJson {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::same_as<T, ThreeBinScalarResponseV1>) {
          return encode_three_bin(value);
        } else if constexpr (std::same_as<T, FiniteParameterAnalyticDataV1>) {
          return encode_analytic(value);
        } else if constexpr (std::same_as<T, FiniteLawTablesV1>) {
          return encode_finite_tables(value);
        } else if constexpr (std::same_as<T, RegisteredRuntimeRecipeV1>) {
          return encode_runtime_recipe(value);
        } else if constexpr (std::same_as<T, ResponseEnvelopeEvidenceV1>) {
          return encode_response_envelope_payload(value);
        } else if constexpr (std::same_as<T, DirectMetricPayloadV1>) {
          return encode_direct_payload(value);
        } else {
          return encode_finite_prefix_constant_tail(value);
        }
      },
      payload);
  return OrderedJson{{"payload_tag", std::string(payload_tag(payload))},
                     {"body", std::move(body)}};
}

Result<ArtifactPayloadV1> decode_payload_wire_v1(
    const OrderedJson& payload, const PayloadWireAccess& access,
    std::string path) {
  auto shape = require_wire_fields(
      payload, std::array<std::string_view, 2U>{"payload_tag", "body"}, path);
  if (!shape) return Result<ArtifactPayloadV1>::failure(shape.error());
  auto tag = required_string(payload.at("payload_tag"), path + "/payload_tag", true);
  if (!tag) return Result<ArtifactPayloadV1>::failure(tag.error());
  const auto& body = payload.at("body");
#define MWPERF_PAYLOAD_BRANCH(TAG, TYPE, DECODE_CALL)                  \
  if (tag.value() == TAG) {                                           \
    auto decoded = DECODE_CALL;                                       \
    if (!decoded) return Result<ArtifactPayloadV1>::failure(decoded.error()); \
    return Result<ArtifactPayloadV1>::success(                         \
        ArtifactPayloadV1(std::in_place_type<TYPE>,                    \
                          std::move(decoded).value()));                \
  }
  MWPERF_PAYLOAD_BRANCH("three_bin_scalar_response_v1",
                        ThreeBinScalarResponseV1,
                        decode_three_bin(body, path + "/body", access))
  MWPERF_PAYLOAD_BRANCH("finite_parameter_analytic_data_v1",
                        FiniteParameterAnalyticDataV1,
                        decode_analytic(body, path + "/body"))
  MWPERF_PAYLOAD_BRANCH("finite_law_tables_v1", FiniteLawTablesV1,
                        decode_finite_tables(body, path + "/body"))
  MWPERF_PAYLOAD_BRANCH("registered_runtime_recipe_v1",
                        RegisteredRuntimeRecipeV1,
                        decode_runtime_recipe(body, path + "/body"))
  MWPERF_PAYLOAD_BRANCH("response_envelope_evidence_v1",
                        ResponseEnvelopeEvidenceV1,
                        decode_response_envelope_payload(
                            body, path + "/body", access))
  MWPERF_PAYLOAD_BRANCH("direct_metric_payload_v1", DirectMetricPayloadV1,
                        decode_direct_payload(body, path + "/body"))
  MWPERF_PAYLOAD_BRANCH(
      "finite_prefix_constant_tail_response_v1",
      FinitePrefixConstantTailResponseV1,
      decode_finite_prefix_constant_tail(body, path + "/body", access))
#undef MWPERF_PAYLOAD_BRANCH
  return fail<ArtifactPayloadV1>("artifact_wire_unknown_payload_tag",
                                 "unknown closed v1 payload tag",
                                 path + "/payload_tag");
}

}  // namespace artifact::detail::wire
}  // namespace mwperf

namespace mwperf {
namespace {

[[nodiscard]] OrderedJson encode_analytic(
    const FiniteParameterAnalyticDataV1& value) {
  return OrderedJson{
      {"payload_version", value.payload_version},
      {"registered_family_id", value.registered_family_id},
      {"registered_family_version", value.registered_family_version},
      {"parameter_schema_id", value.parameter_schema_id},
      {"parameter_schema_version", value.parameter_schema_version},
      {"domain_schema_id", value.domain_schema_id},
      {"domain_schema_version", value.domain_schema_version},
      {"registered_provider", encode_provider(value.registered_provider)},
      {"ordered_deployed_targets",
       encode_vector(value.ordered_deployed_targets,
                     [](const QueueId& id) { return encode_strong_id(id); })},
      {"parameters", encode_vector(value.parameters, encode_named_value)},
      {"tables", encode_vector(value.tables, encode_named_value)},
      {"mathematical_domain",
       encode_vector(value.mathematical_domain, encode_domain)},
      {"state_and_phase_binding",
       encode_vector(value.state_and_phase_binding, encode_state_field)},
      {"transform_or_response_identities",
       encode_vector(value.transform_or_response_identities,
                     artifact::detail::wire::encode_artifact_object_reference)}};
}

[[nodiscard]] Result<FiniteParameterAnalyticDataV1> decode_analytic(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 14U> fields{
      "payload_version", "registered_family_id", "registered_family_version",
      "parameter_schema_id", "parameter_schema_version", "domain_schema_id",
      "domain_schema_version", "registered_provider",
      "ordered_deployed_targets", "parameters", "tables",
      "mathematical_domain", "state_and_phase_binding",
      "transform_or_response_identities"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<FiniteParameterAnalyticDataV1>::failure(shape.error());
  auto payload_version = required_u32(value.at("payload_version"), path + "/payload_version");
  auto family_id = required_string(value.at("registered_family_id"), path + "/registered_family_id", true);
  auto family_version = required_u32(value.at("registered_family_version"), path + "/registered_family_version");
  auto parameter_schema_id = required_string(value.at("parameter_schema_id"), path + "/parameter_schema_id", true);
  auto parameter_schema_version = required_u32(value.at("parameter_schema_version"), path + "/parameter_schema_version");
  auto domain_schema_id = required_string(value.at("domain_schema_id"), path + "/domain_schema_id", true);
  auto domain_schema_version = required_u32(value.at("domain_schema_version"), path + "/domain_schema_version");
  auto provider = decode_provider(value.at("registered_provider"), path + "/registered_provider");
  auto targets = decode_vector<QueueId>(value.at("ordered_deployed_targets"), path + "/ordered_deployed_targets", decode_strong_id<QueueId>);
  auto parameters = decode_vector<NamedPortableValueV1>(value.at("parameters"), path + "/parameters", decode_named_value);
  auto tables = decode_vector<NamedPortableValueV1>(value.at("tables"), path + "/tables", decode_named_value);
  auto domain = decode_vector<PortableDomainV1>(value.at("mathematical_domain"), path + "/mathematical_domain", decode_domain);
  auto state = decode_vector<StateFieldDescriptorV1>(value.at("state_and_phase_binding"), path + "/state_and_phase_binding", decode_state_field);
  auto identities = decode_vector<ArtifactObjectReferenceV1>(value.at("transform_or_response_identities"), path + "/transform_or_response_identities", artifact::detail::wire::decode_artifact_object_reference);
  if (!payload_version) return Result<FiniteParameterAnalyticDataV1>::failure(payload_version.error());
  if (payload_version.value() != kProtocolVersion) return fail<FiniteParameterAnalyticDataV1>("artifact_wire_unsupported_version", "finite analytic payload version must equal one", path + "/payload_version");
  if (!family_id) return Result<FiniteParameterAnalyticDataV1>::failure(family_id.error());
  if (!family_version) return Result<FiniteParameterAnalyticDataV1>::failure(family_version.error());
  if (!parameter_schema_id) return Result<FiniteParameterAnalyticDataV1>::failure(parameter_schema_id.error());
  if (!parameter_schema_version) return Result<FiniteParameterAnalyticDataV1>::failure(parameter_schema_version.error());
  if (!domain_schema_id) return Result<FiniteParameterAnalyticDataV1>::failure(domain_schema_id.error());
  if (!domain_schema_version) return Result<FiniteParameterAnalyticDataV1>::failure(domain_schema_version.error());
  if (!provider) return Result<FiniteParameterAnalyticDataV1>::failure(provider.error());
  if (!targets) return Result<FiniteParameterAnalyticDataV1>::failure(targets.error());
  if (!parameters) return Result<FiniteParameterAnalyticDataV1>::failure(parameters.error());
  if (!tables) return Result<FiniteParameterAnalyticDataV1>::failure(tables.error());
  if (!domain) return Result<FiniteParameterAnalyticDataV1>::failure(domain.error());
  if (!state) return Result<FiniteParameterAnalyticDataV1>::failure(state.error());
  if (!identities) return Result<FiniteParameterAnalyticDataV1>::failure(identities.error());
  return Result<FiniteParameterAnalyticDataV1>::success(
      FiniteParameterAnalyticDataV1{
          std::move(payload_version).value(), std::move(family_id).value(),
          std::move(family_version).value(),
          std::move(parameter_schema_id).value(),
          std::move(parameter_schema_version).value(),
          std::move(domain_schema_id).value(),
          std::move(domain_schema_version).value(), std::move(provider).value(),
          std::move(targets).value(), std::move(parameters).value(),
          std::move(tables).value(), std::move(domain).value(),
          std::move(state).value(), std::move(identities).value()});
}

[[nodiscard]] OrderedJson encode_runtime_recipe(
    const RegisteredRuntimeRecipeV1& value) {
  return OrderedJson{
      {"payload_version", value.payload_version},
      {"registered_recipe_id", value.registered_recipe_id},
      {"registered_recipe_version", value.registered_recipe_version},
      {"parameter_schema_id", value.parameter_schema_id},
      {"parameter_schema_version", value.parameter_schema_version},
      {"state_codec_schema_id", value.state_codec_schema_id},
      {"state_codec_schema_version", value.state_codec_schema_version},
      {"mark_codec_schema_id", value.mark_codec_schema_id},
      {"mark_codec_schema_version", value.mark_codec_schema_version},
      {"registered_provider", encode_provider(value.registered_provider)},
      {"ordered_deployed_targets", encode_vector(value.ordered_deployed_targets, [](const QueueId& id) { return encode_strong_id(id); })},
      {"parameters", encode_vector(value.parameters, encode_named_value)},
      {"state_codecs", encode_vector(value.state_codecs, encode_state_field)},
      {"mark_codecs", encode_vector(value.mark_codecs, encode_mark_descriptor)}};
}

[[nodiscard]] Result<RegisteredRuntimeRecipeV1> decode_runtime_recipe(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 14U> fields{
      "payload_version", "registered_recipe_id", "registered_recipe_version",
      "parameter_schema_id", "parameter_schema_version",
      "state_codec_schema_id", "state_codec_schema_version",
      "mark_codec_schema_id", "mark_codec_schema_version",
      "registered_provider", "ordered_deployed_targets", "parameters",
      "state_codecs", "mark_codecs"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<RegisteredRuntimeRecipeV1>::failure(shape.error());
  auto payload_version = required_u32(value.at("payload_version"), path + "/payload_version");
  auto recipe_id = required_string(value.at("registered_recipe_id"), path + "/registered_recipe_id", true);
  auto recipe_version = required_u32(value.at("registered_recipe_version"), path + "/registered_recipe_version");
  auto parameter_schema_id = required_string(value.at("parameter_schema_id"), path + "/parameter_schema_id", true);
  auto parameter_schema_version = required_u32(value.at("parameter_schema_version"), path + "/parameter_schema_version");
  auto state_schema_id = required_string(value.at("state_codec_schema_id"), path + "/state_codec_schema_id", true);
  auto state_schema_version = required_u32(value.at("state_codec_schema_version"), path + "/state_codec_schema_version");
  auto mark_schema_id = required_string(value.at("mark_codec_schema_id"), path + "/mark_codec_schema_id", true);
  auto mark_schema_version = required_u32(value.at("mark_codec_schema_version"), path + "/mark_codec_schema_version");
  auto provider = decode_provider(value.at("registered_provider"), path + "/registered_provider");
  auto targets = decode_vector<QueueId>(value.at("ordered_deployed_targets"), path + "/ordered_deployed_targets", decode_strong_id<QueueId>);
  auto parameters = decode_vector<NamedPortableValueV1>(value.at("parameters"), path + "/parameters", decode_named_value);
  auto state = decode_vector<StateFieldDescriptorV1>(value.at("state_codecs"), path + "/state_codecs", decode_state_field);
  auto marks = decode_vector<MarkDescriptorV1>(value.at("mark_codecs"), path + "/mark_codecs", decode_mark_descriptor);
  if (!payload_version) return Result<RegisteredRuntimeRecipeV1>::failure(payload_version.error());
  if (payload_version.value() != kProtocolVersion) return fail<RegisteredRuntimeRecipeV1>("artifact_wire_unsupported_version", "runtime recipe payload version must equal one", path + "/payload_version");
  if (!recipe_id) return Result<RegisteredRuntimeRecipeV1>::failure(recipe_id.error());
  if (!recipe_version) return Result<RegisteredRuntimeRecipeV1>::failure(recipe_version.error());
  if (!parameter_schema_id) return Result<RegisteredRuntimeRecipeV1>::failure(parameter_schema_id.error());
  if (!parameter_schema_version) return Result<RegisteredRuntimeRecipeV1>::failure(parameter_schema_version.error());
  if (!state_schema_id) return Result<RegisteredRuntimeRecipeV1>::failure(state_schema_id.error());
  if (!state_schema_version) return Result<RegisteredRuntimeRecipeV1>::failure(state_schema_version.error());
  if (!mark_schema_id) return Result<RegisteredRuntimeRecipeV1>::failure(mark_schema_id.error());
  if (!mark_schema_version) return Result<RegisteredRuntimeRecipeV1>::failure(mark_schema_version.error());
  if (!provider) return Result<RegisteredRuntimeRecipeV1>::failure(provider.error());
  if (!targets) return Result<RegisteredRuntimeRecipeV1>::failure(targets.error());
  if (!parameters) return Result<RegisteredRuntimeRecipeV1>::failure(parameters.error());
  if (!state) return Result<RegisteredRuntimeRecipeV1>::failure(state.error());
  if (!marks) return Result<RegisteredRuntimeRecipeV1>::failure(marks.error());
  return Result<RegisteredRuntimeRecipeV1>::success(RegisteredRuntimeRecipeV1{
      std::move(payload_version).value(), std::move(recipe_id).value(),
      std::move(recipe_version).value(), std::move(parameter_schema_id).value(),
      std::move(parameter_schema_version).value(), std::move(state_schema_id).value(),
      std::move(state_schema_version).value(), std::move(mark_schema_id).value(),
      std::move(mark_schema_version).value(), std::move(provider).value(),
      std::move(targets).value(), std::move(parameters).value(),
      std::move(state).value(), std::move(marks).value()});
}

[[nodiscard]] OrderedJson encode_dictionary_entry(
    const PortableFiniteDictionaryEntryV1& value) {
  return OrderedJson{{"id", artifact::detail::wire::encode_typed_label(value.id)},
                     {"coordinates", encode_scalar_array(value.coordinates)}};
}

[[nodiscard]] Result<PortableFiniteDictionaryEntryV1> decode_dictionary_entry(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(value, std::array<std::string_view, 2U>{"id", "coordinates"}, path);
  if (!shape) return Result<PortableFiniteDictionaryEntryV1>::failure(shape.error());
  auto id = artifact::detail::wire::decode_typed_label(value.at("id"), path + "/id");
  auto coordinates = decode_scalar_array(value.at("coordinates"), path + "/coordinates");
  if (!id) return Result<PortableFiniteDictionaryEntryV1>::failure(id.error());
  if (!coordinates) return Result<PortableFiniteDictionaryEntryV1>::failure(coordinates.error());
  return Result<PortableFiniteDictionaryEntryV1>::success(
      PortableFiniteDictionaryEntryV1{std::move(id).value(),
                                      std::move(coordinates).value()});
}

}  // namespace
}  // namespace mwperf

namespace mwperf {
namespace {

using artifact::detail::OrderedJson;

[[nodiscard]] Diagnostic artifact_error(
    std::string code, std::string message,
    std::optional<std::string> path = std::nullopt,
    DiagnosticCategory category = DiagnosticCategory::input_validation) {
  return Diagnostic{.category = category,
                    .code = std::move(code),
                    .message = std::move(message),
                    .authored_path = std::nullopt,
                    .json_pointer = std::move(path),
                    .notes = {}};
}

template <typename T>
[[nodiscard]] Result<T> fail(std::string code, std::string message,
                             std::optional<std::string> path) {
  return Result<T>::failure(
      artifact_error(std::move(code), std::move(message), std::move(path)));
}

[[nodiscard]] Result<void> require_wire_fields(
    const OrderedJson& object, std::span<const std::string_view> fields,
    const std::string& path) {
  if (!object.is_object()) {
    return Result<void>::failure(artifact_error(
        "artifact_wire_expected_object", "expected a JSON object", path));
  }
  if (object.size() != fields.size()) {
    return Result<void>::failure(artifact_error(
        "artifact_wire_closed_object",
        "object has a missing, duplicate, or unknown version-1 field", path));
  }
  for (const auto field : fields) {
    if (!object.contains(std::string(field))) {
      return Result<void>::failure(artifact_error(
          "artifact_wire_missing_field",
          "required version-1 field is absent", path + "/" +
                                                   std::string(field)));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> require_wire_fields(
    const OrderedJson& object, std::span<const std::string_view> required,
    std::span<const std::string_view> optional, const std::string& path) {
  if (!object.is_object()) {
    return Result<void>::failure(artifact_error(
        "artifact_wire_expected_object", "expected a JSON object", path));
  }
  for (const auto field : required) {
    if (!object.contains(std::string(field))) {
      return Result<void>::failure(artifact_error(
          "artifact_wire_missing_field", "required version-1 field is absent",
          path + "/" + std::string(field)));
    }
  }
  for (auto iterator = object.begin(); iterator != object.end(); ++iterator) {
    const std::string_view name(iterator.key());
    const bool known_required =
        std::find(required.begin(), required.end(), name) != required.end();
    const bool known_optional =
        std::find(optional.begin(), optional.end(), name) != optional.end();
    if (!known_required && !known_optional) {
      return Result<void>::failure(artifact_error(
          "artifact_wire_closed_object", "unknown version-1 field", path + "/" + iterator.key()));
    }
  }
  return Result<void>::success();
}

template <std::size_t N>
[[nodiscard]] Result<void> require_wire_fields(
    const OrderedJson& object, const std::array<std::string_view, N>& fields,
    const std::string& path) {
  return require_wire_fields(object, std::span<const std::string_view>(fields),
                             path);
}

[[nodiscard]] bool closed_ascii_token(std::string_view value) {
  if (value.empty()) {
    return false;
  }
  return std::all_of(value.begin(), value.end(), [](const char character) {
    const auto byte = static_cast<unsigned char>(character);
    return (byte >= static_cast<unsigned char>('a') &&
            byte <= static_cast<unsigned char>('z')) ||
           (byte >= static_cast<unsigned char>('0') &&
            byte <= static_cast<unsigned char>('9')) ||
           character == '_' || character == '.' || character == '-' ||
           character == ':';
  });
}

[[nodiscard]] Result<std::string> required_string(const OrderedJson& value,
                                                  std::string path,
                                                  bool token) {
  if (!value.is_string()) {
    return fail<std::string>("artifact_wire_expected_string",
                             "expected a JSON string", std::move(path));
  }
  std::string result = value.get<std::string>();
  if (result.empty() || (token && !closed_ascii_token(result))) {
    return fail<std::string>(
        "artifact_wire_string_domain",
        token ? "expected a nonempty closed ASCII token"
              : "expected a nonempty UTF-8 string",
        std::move(path));
  }
  return Result<std::string>::success(std::move(result));
}

[[nodiscard]] Result<std::uint32_t> required_u32(const OrderedJson& value,
                                                 std::string path) {
  if (!value.is_number_unsigned()) {
    return fail<std::uint32_t>("artifact_wire_expected_u32",
                               "expected an unsigned 32-bit integer",
                               std::move(path));
  }
  const auto raw = value.get<std::uint64_t>();
  if (raw > std::numeric_limits<std::uint32_t>::max()) {
    return fail<std::uint32_t>("artifact_wire_u32_overflow",
                               "integer exceeds the unsigned 32-bit domain",
                               std::move(path));
  }
  return Result<std::uint32_t>::success(static_cast<std::uint32_t>(raw));
}

[[nodiscard]] Result<std::uint32_t> required_version_one(
    const OrderedJson& value, std::string path, std::string_view record_name) {
  auto version = required_u32(value, path);
  if (!version) return version;
  if (version.value() != kProtocolVersion) {
    return fail<std::uint32_t>(
        "artifact_wire_unsupported_version",
        std::string(record_name) + " version must equal one", std::move(path));
  }
  return version;
}

[[nodiscard]] OrderedJson encode_provider(const ProviderIdentityV1& value) {
  return OrderedJson{{"provider_id", value.provider_id},
                     {"provider_version", value.provider_version}};
}

[[nodiscard]] Result<ProviderIdentityV1> decode_provider(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"provider_id",
                                              "provider_version"},
      path);
  if (!shape) {
    return Result<ProviderIdentityV1>::failure(shape.error());
  }
  auto id = required_string(value.at("provider_id"), path + "/provider_id",
                            true);
  auto version = required_string(value.at("provider_version"),
                                 path + "/provider_version", true);
  if (!id) {
    return Result<ProviderIdentityV1>::failure(id.error());
  }
  if (!version) {
    return Result<ProviderIdentityV1>::failure(version.error());
  }
  return Result<ProviderIdentityV1>::success(
      ProviderIdentityV1{std::move(id).value(), std::move(version).value()});
}

[[nodiscard]] OrderedJson encode_scalar_array(
    const std::vector<PortableScientificScalar>& values) {
  OrderedJson result = OrderedJson::array();
  for (const auto& value : values) {
    result.push_back(artifact::detail::wire::encode_scalar(value));
  }
  return result;
}

[[nodiscard]] Result<std::vector<PortableScientificScalar>>
decode_scalar_array(const OrderedJson& value, const std::string& path) {
  if (!value.is_array()) {
    return fail<std::vector<PortableScientificScalar>>(
        "artifact_wire_expected_array", "expected a JSON array", path);
  }
  std::vector<PortableScientificScalar> result;
  result.reserve(value.size());
  for (std::size_t index = 0U; index < value.size(); ++index) {
    auto decoded = artifact::detail::wire::decode_scalar(
        value.at(index), path + "/" + std::to_string(index));
    if (!decoded) {
      return Result<std::vector<PortableScientificScalar>>::failure(
          decoded.error());
    }
    result.push_back(std::move(decoded).value());
  }
  return Result<std::vector<PortableScientificScalar>>::success(
      std::move(result));
}

template <typename Value, typename Encode>
[[nodiscard]] OrderedJson encode_vector(const std::vector<Value>& values,
                                        Encode&& encode) {
  OrderedJson result = OrderedJson::array();
  for (const auto& value : values) {
    result.push_back(encode(value));
  }
  return result;
}

template <typename Value, typename Decode>
[[nodiscard]] Result<std::vector<Value>> decode_vector(
    const OrderedJson& value, const std::string& path, Decode&& decode) {
  if (!value.is_array()) {
    return fail<std::vector<Value>>("artifact_wire_expected_array",
                                    "expected a JSON array", path);
  }
  std::vector<Value> result;
  result.reserve(value.size());
  for (std::size_t index = 0U; index < value.size(); ++index) {
    auto decoded = decode(value.at(index), path + "/" +
                                             std::to_string(index));
    if (!decoded) {
      return Result<std::vector<Value>>::failure(decoded.error());
    }
    result.push_back(std::move(decoded).value());
  }
  return Result<std::vector<Value>>::success(std::move(result));
}

template <typename StrongIdType>
[[nodiscard]] OrderedJson encode_strong_id(const StrongIdType& value) {
  return artifact::detail::wire::encode_typed_label(value.label());
}

template <typename StrongIdType>
[[nodiscard]] Result<StrongIdType> decode_strong_id(const OrderedJson& value,
                                                    const std::string& path) {
  auto label = artifact::detail::wire::decode_typed_label(value, path);
  if (!label) {
    return Result<StrongIdType>::failure(label.error());
  }
  return Result<StrongIdType>::success(
      StrongIdType(std::move(label).value()));
}

[[nodiscard]] std::vector<std::byte> json_bytes(const OrderedJson& value) {
  const std::string text = value.dump();
  std::vector<std::byte> bytes;
  bytes.reserve(text.size());
  for (const char character : text) {
    bytes.push_back(std::byte{static_cast<unsigned char>(character)});
  }
  return bytes;
}

[[nodiscard]] Result<Digest256> json_digest(std::string_view domain,
                                            const OrderedJson& value) {
  const auto bytes = json_bytes(value);
  return sha256_domain_separated(domain, bytes);
}

}  // namespace

namespace artifact::detail::wire {

OrderedJson encode_typed_label(const TypedLabel& value) {
  if (value.is_numeric()) {
    return OrderedJson{{"kind", "numeric"},
                       {"value", value.numeric_value()->to_decimal_string()}};
  }
  return OrderedJson{{"kind", "text"}, {"value", *value.text_value()}};
}

Result<TypedLabel> decode_typed_label(const OrderedJson& value,
                                     std::string path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"kind", "value"}, path);
  if (!shape) {
    return Result<TypedLabel>::failure(shape.error());
  }
  auto kind = required_string(value.at("kind"), path + "/kind", true);
  auto text = required_string(value.at("value"), path + "/value");
  if (!kind) {
    return Result<TypedLabel>::failure(kind.error());
  }
  if (!text) {
    return Result<TypedLabel>::failure(text.error());
  }
  if (kind.value() == "numeric") {
    auto parsed = parse_exact_nonnegative_integer(
        JsonNumber(std::move(text).value()), BoundPolicy::unbounded());
    if (!parsed) {
      return Result<TypedLabel>::failure(parsed.error());
    }
    return Result<TypedLabel>::success(
        TypedLabel::numeric(std::move(parsed).value()));
  }
  if (kind.value() != "text") {
    return fail<TypedLabel>("artifact_wire_label_kind",
                            "unknown typed-label kind", path + "/kind");
  }
  return TypedLabel::text(std::move(text).value());
}

OrderedJson encode_digest(const Digest256& value) { return value.hex(); }

Result<Digest256> decode_digest(const OrderedJson& value, std::string path) {
  auto text = required_string(value, path, true);
  if (!text) {
    return Result<Digest256>::failure(text.error());
  }
  auto digest = Digest256::from_hex(text.value());
  if (!digest) {
    return fail<Digest256>("artifact_wire_digest",
                           "expected a lowercase 64-digit SHA-256 digest",
                           std::move(path));
  }
  return digest;
}

OrderedJson encode_big_nat(const BigNat& value) {
  return value.to_decimal_string();
}

Result<BigNat> decode_big_nat(const OrderedJson& value, std::string path) {
  auto text = required_string(value, path);
  if (!text) {
    return Result<BigNat>::failure(text.error());
  }
  auto result = parse_exact_nonnegative_integer(
      JsonNumber(std::move(text).value()), BoundPolicy::unbounded());
  if (!result) {
    return fail<BigNat>("artifact_wire_big_nat",
                        "expected a canonical nonnegative decimal integer",
                        std::move(path));
  }
  return result;
}

OrderedJson encode_scalar(const PortableScientificScalar& value) {
  if (value.kind() == PortableScientificScalarKind::rational) {
    const auto& rational = value.rational_value();
    return OrderedJson{{"kind", "rational"},
                       {"numerator", rational.numerator_decimal()},
                       {"denominator", rational.denominator_decimal()}};
  }
  return OrderedJson{{"kind", "binary64"},
                     {"bits", value.binary64_encoding()}};
}

Result<PortableScientificScalar> decode_scalar(const OrderedJson& value,
                                               std::string path) {
  if (!value.is_object() || !value.contains("kind") ||
      !value.at("kind").is_string()) {
    return fail<PortableScientificScalar>(
        "artifact_wire_scalar_shape", "invalid scientific scalar object",
        std::move(path));
  }
  const std::string kind = value.at("kind").get<std::string>();
  if (kind == "rational") {
    auto shape = require_wire_fields(
        value,
        std::array<std::string_view, 3U>{"kind", "numerator",
                                         "denominator"},
        path);
    if (!shape || !value.at("numerator").is_string() ||
        !value.at("denominator").is_string()) {
      return fail<PortableScientificScalar>(
          "artifact_wire_rational_shape",
          "rational scalar requires canonical numerator and denominator",
          std::move(path));
    }
    return PortableScientificScalar::parse_rational(
        value.at("numerator").get<std::string>(),
        value.at("denominator").get<std::string>());
  }
  if (kind == "binary64") {
    auto shape = require_wire_fields(
        value, std::array<std::string_view, 2U>{"kind", "bits"}, path);
    if (!shape || !value.at("bits").is_string()) {
      return fail<PortableScientificScalar>(
          "artifact_wire_binary64_shape",
          "binary64 scalar requires one canonical bits string",
          std::move(path));
    }
    return PortableScientificScalar::parse_binary64(
        value.at("bits").get<std::string>());
  }
  return fail<PortableScientificScalar>("artifact_wire_scalar_kind",
                                        "unknown scientific scalar kind",
                                        std::move(path));
}

OrderedJson encode_artifact_object_reference(
    const ArtifactObjectReferenceV1& value) {
  return OrderedJson{{"object_id", encode_typed_label(value.object_id)},
                     {"object_digest", encode_digest(value.object_digest)}};
}

Result<ArtifactObjectReferenceV1> decode_artifact_object_reference(
    const OrderedJson& value, std::string path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"object_id", "object_digest"},
      path);
  if (!shape) {
    return Result<ArtifactObjectReferenceV1>::failure(shape.error());
  }
  auto id = decode_typed_label(value.at("object_id"), path + "/object_id");
  auto digest = decode_digest(value.at("object_digest"),
                              path + "/object_digest");
  if (!id) {
    return Result<ArtifactObjectReferenceV1>::failure(id.error());
  }
  if (!digest) {
    return Result<ArtifactObjectReferenceV1>::failure(digest.error());
  }
  return Result<ArtifactObjectReferenceV1>::success(
      ArtifactObjectReferenceV1{std::move(id).value(),
                                std::move(digest).value()});
}

}  // namespace artifact::detail::wire

}  // namespace mwperf

namespace mwperf {
namespace {

template <typename Enum>
[[nodiscard]] std::string_view enum_text(Enum value);

#define MWPERF_ENUM_TEXT_BEGIN(TYPE)                                      \
  template <>                                                            \
  [[nodiscard]] std::string_view enum_text<TYPE>(const TYPE value) {     \
    switch (value) {
#define MWPERF_ENUM_TEXT_CASE(VALUE, TEXT) \
  case VALUE:                              \
    return TEXT;
#define MWPERF_ENUM_TEXT_END() \
  }                            \
  return {};                   \
  }

MWPERF_ENUM_TEXT_BEGIN(ThreeBinCoefficientV1)
  MWPERF_ENUM_TEXT_CASE(ThreeBinCoefficientV1::one, "one")
  MWPERF_ENUM_TEXT_CASE(ThreeBinCoefficientV1::two, "two")
  MWPERF_ENUM_TEXT_CASE(ThreeBinCoefficientV1::tail_from_three,
                        "tail_from_three")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(FinitePrefixResponseCoordinateKindV1)
  MWPERF_ENUM_TEXT_CASE(
      FinitePrefixResponseCoordinateKindV1::structural_level_zero,
      "structural_level_zero")
  MWPERF_ENUM_TEXT_CASE(FinitePrefixResponseCoordinateKindV1::exact_level,
                        "exact_level")
  MWPERF_ENUM_TEXT_CASE(FinitePrefixResponseCoordinateKindV1::constant_tail,
                        "constant_tail")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(ProposalConditioningSourceV1)
  MWPERF_ENUM_TEXT_CASE(ProposalConditioningSourceV1::exact_population,
                        "exact_population")
  MWPERF_ENUM_TEXT_CASE(ProposalConditioningSourceV1::empirical_average,
                        "empirical_average")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(PopulationConditioningStatusV1)
  MWPERF_ENUM_TEXT_CASE(PopulationConditioningStatusV1::proved_positive,
                        "proved_positive")
  MWPERF_ENUM_TEXT_CASE(PopulationConditioningStatusV1::proved_zero,
                        "proved_zero")
  MWPERF_ENUM_TEXT_CASE(
      PopulationConditioningStatusV1::positive_with_confidence,
      "positive_with_confidence")
  MWPERF_ENUM_TEXT_CASE(PopulationConditioningStatusV1::unresolved,
                        "unresolved")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(RawValueStatusV1)
  MWPERF_ENUM_TEXT_CASE(RawValueStatusV1::exact_point, "exact_point")
  MWPERF_ENUM_TEXT_CASE(RawValueStatusV1::interval_only, "interval_only")
  MWPERF_ENUM_TEXT_CASE(RawValueStatusV1::absent, "absent")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(ResponseProductStageV1)
  MWPERF_ENUM_TEXT_CASE(ResponseProductStageV1::raw_response, "raw_response")
  MWPERF_ENUM_TEXT_CASE(ResponseProductStageV1::nominal_response,
                        "nominal_response")
  MWPERF_ENUM_TEXT_CASE(ResponseProductStageV1::projection_center,
                        "projection_center")
  MWPERF_ENUM_TEXT_CASE(ResponseProductStageV1::projected_mean,
                        "projected_mean")
  MWPERF_ENUM_TEXT_CASE(ResponseProductStageV1::recoded_response,
                        "recoded_response")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(ProjectionCenterSourceKindV1)
  MWPERF_ENUM_TEXT_CASE(ProjectionCenterSourceKindV1::decoded_raw_response,
                        "decoded_raw_response")
  MWPERF_ENUM_TEXT_CASE(ProjectionCenterSourceKindV1::synthetic_snapshot_mean,
                        "synthetic_snapshot_mean")
  MWPERF_ENUM_TEXT_CASE(ProjectionCenterSourceKindV1::explicit_fallback,
                        "explicit_fallback")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(ProductDerivationKindV1)
  MWPERF_ENUM_TEXT_CASE(ProductDerivationKindV1::nominal_completion,
                        "nominal_completion")
  MWPERF_ENUM_TEXT_CASE(ProductDerivationKindV1::admissibility_projection,
                        "admissibility_projection")
  MWPERF_ENUM_TEXT_CASE(ProductDerivationKindV1::identity_recoding,
                        "identity_recoding")
  MWPERF_ENUM_TEXT_CASE(ProductDerivationKindV1::mean_inversion_recoding,
                        "mean_inversion_recoding")
  MWPERF_ENUM_TEXT_CASE(ProductDerivationKindV1::endpoint_completion,
                        "endpoint_completion")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(RawEnvelopeScopeV1)
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeScopeV1::proposal_raw, "proposal_raw")
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeScopeV1::optimizer_interval_raw,
                        "optimizer_interval_raw")
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeScopeV1::deterministic_quadrature_raw,
                        "deterministic_quadrature_raw")
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeScopeV1::physical_response_bound,
                        "physical_response_bound")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(RawEnvelopeCoverageV1)
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeCoverageV1::deterministic,
                        "deterministic")
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeCoverageV1::marginal, "marginal")
  MWPERF_ENUM_TEXT_CASE(RawEnvelopeCoverageV1::simultaneous, "simultaneous")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(PopulationConditioningPremiseV1)
  MWPERF_ENUM_TEXT_CASE(PopulationConditioningPremiseV1::unconditional,
                        "unconditional")
  MWPERF_ENUM_TEXT_CASE(
      PopulationConditioningPremiseV1::conditional_on_population_positivity,
      "conditional_on_population_positivity")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(FiniteTableStorageV1)
  MWPERF_ENUM_TEXT_CASE(FiniteTableStorageV1::dense, "dense")
  MWPERF_ENUM_TEXT_CASE(FiniteTableStorageV1::sparse, "sparse")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(FiniteRowConditioningStageV1)
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::stationary_edge,
                        "stationary_edge")
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::prearrival, "prearrival")
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::postarrival,
                        "postarrival")
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::one_slot_current,
                        "one_slot_current")
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::stopped_continuation,
                        "stopped_continuation")
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::residence_continuation,
                        "residence_continuation")
  MWPERF_ENUM_TEXT_CASE(FiniteRowConditioningStageV1::common_schedule,
                        "common_schedule")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(SemanticTagV1)
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::scalar_backlog_response,
                        "scalar_backlog_response")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::stationary_marked_edge,
                        "stationary_marked_edge")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::staged_opportunity_flux_law,
                        "staged_opportunity_flux_law")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::temporal_one_slot_continuation,
                        "temporal_one_slot_continuation")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::romr_residence_word_law,
                        "romr_residence_word_law")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::stopped_path_law, "stopped_path_law")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::coupled_target_schedule_law,
                        "coupled_target_schedule_law")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::direct_metric_decoder,
                        "direct_metric_decoder")
  MWPERF_ENUM_TEXT_CASE(SemanticTagV1::response_envelope_law,
                        "response_envelope_law")
MWPERF_ENUM_TEXT_END()
MWPERF_ENUM_TEXT_BEGIN(RuntimeAccessTagV1)
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::finite_enumerated_row,
                        "finite_enumerated_row")
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::sparse_row, "sparse_row")
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::normalized_conditional_sampler,
                        "normalized_conditional_sampler")
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::analytic_transform,
                        "analytic_transform")
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::finite_parameter_analytic_family,
                        "finite_parameter_analytic_family")
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::procedural_residence_generator,
                        "procedural_residence_generator")
  MWPERF_ENUM_TEXT_CASE(RuntimeAccessTagV1::direct_metric_decoder,
                        "direct_metric_decoder")
MWPERF_ENUM_TEXT_END()

#undef MWPERF_ENUM_TEXT_BEGIN
#undef MWPERF_ENUM_TEXT_CASE
#undef MWPERF_ENUM_TEXT_END

template <typename Enum>
[[nodiscard]] Result<Enum> decode_enum(const OrderedJson& value,
                                       const std::string& path,
                                       std::span<const Enum> domain) {
  auto text = required_string(value, path, true);
  if (!text) {
    return Result<Enum>::failure(text.error());
  }
  for (const Enum candidate : domain) {
    if (enum_text(candidate) == text.value()) {
      return Result<Enum>::success(candidate);
    }
  }
  return fail<Enum>("artifact_wire_enum", "unknown closed enumeration value",
                    path);
}

template <typename T, typename Decode>
[[nodiscard]] Result<std::optional<T>> decode_optional_member(
    const OrderedJson& object, const std::string_view field,
    const std::string& path, Decode&& decode) {
  const std::string name(field);
  if (!object.contains(name)) {
    return Result<std::optional<T>>::success(std::nullopt);
  }
  if (object.at(name).is_null()) {
    return fail<std::optional<T>>(
        "artifact_wire_null_optional",
        "optional version-1 members are omitted, never encoded as null",
        path + "/" + name);
  }
  auto decoded = decode(object.at(name), path + "/" + name);
  if (!decoded) {
    return Result<std::optional<T>>::failure(decoded.error());
  }
  return Result<std::optional<T>>::success(
      std::optional<T>(std::move(decoded).value()));
}

[[nodiscard]] OrderedJson encode_conformance(
    const ProviderConformanceReportRef& value) {
  using artifact::detail::wire::encode_digest;
  using artifact::detail::wire::encode_typed_label;
  return OrderedJson{
      {"report_schema_version", value.report_schema_version},
      {"report_id", encode_typed_label(value.report_id)},
      {"report_digest", encode_digest(value.report_digest)},
      {"provider", encode_provider(value.provider)},
      {"provider_scientific_contract_digest",
       encode_digest(value.provider_scientific_contract_digest)},
      {"family_evidence_schema_id", value.family_evidence_schema_id},
      {"family_evidence_schema_version",
       value.family_evidence_schema_version}};
}

[[nodiscard]] Result<ProviderConformanceReportRef> decode_conformance(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 7U> fields{
      "report_schema_version", "report_id", "report_digest", "provider",
      "provider_scientific_contract_digest", "family_evidence_schema_id",
      "family_evidence_schema_version"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) {
    return Result<ProviderConformanceReportRef>::failure(shape.error());
  }
  auto report_version = required_u32(value.at("report_schema_version"),
                                     path + "/report_schema_version");
  auto id = artifact::detail::wire::decode_typed_label(
      value.at("report_id"), path + "/report_id");
  auto digest = artifact::detail::wire::decode_digest(
      value.at("report_digest"), path + "/report_digest");
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto scientific = artifact::detail::wire::decode_digest(
      value.at("provider_scientific_contract_digest"),
      path + "/provider_scientific_contract_digest");
  auto schema = required_string(value.at("family_evidence_schema_id"),
                                path + "/family_evidence_schema_id", true);
  auto schema_version = required_u32(
      value.at("family_evidence_schema_version"),
      path + "/family_evidence_schema_version");
  if (!report_version) return Result<ProviderConformanceReportRef>::failure(report_version.error());
  if (report_version.value() != kProtocolVersion) return fail<ProviderConformanceReportRef>("artifact_wire_unsupported_version", "provider conformance report reference version must equal one", path + "/report_schema_version");
  if (!id) return Result<ProviderConformanceReportRef>::failure(id.error());
  if (!digest) return Result<ProviderConformanceReportRef>::failure(digest.error());
  if (!provider) return Result<ProviderConformanceReportRef>::failure(provider.error());
  if (!scientific) return Result<ProviderConformanceReportRef>::failure(scientific.error());
  if (!schema) return Result<ProviderConformanceReportRef>::failure(schema.error());
  if (!schema_version) return Result<ProviderConformanceReportRef>::failure(schema_version.error());
  return Result<ProviderConformanceReportRef>::success(
      ProviderConformanceReportRef{
          std::move(report_version).value(), std::move(id).value(),
          std::move(digest).value(), std::move(provider).value(),
          std::move(scientific).value(), std::move(schema).value(),
          std::move(schema_version).value()});
}

template <ResponseProductStageV1 Stage>
[[nodiscard]] OrderedJson encode_product_id(
    const TypedResponseProductIdV1<Stage>& value) {
  return OrderedJson{
      {"stage", std::string(enum_text(Stage))},
      {"identity", artifact::detail::wire::encode_artifact_object_reference(
                       value.identity())}};
}

template <ResponseProductStageV1 Stage>
[[nodiscard]] Result<ArtifactObjectReferenceV1> decode_product_identity(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 2U>{"stage", "identity"}, path);
  if (!shape) {
    return Result<ArtifactObjectReferenceV1>::failure(shape.error());
  }
  auto stage = required_string(value.at("stage"), path + "/stage", true);
  if (!stage) {
    return Result<ArtifactObjectReferenceV1>::failure(stage.error());
  }
  if (stage.value() != enum_text(Stage)) {
    return fail<ArtifactObjectReferenceV1>(
        "artifact_wire_product_stage",
        "typed response-product wire stage does not match its field", path);
  }
  return artifact::detail::wire::decode_artifact_object_reference(
      value.at("identity"), path + "/identity");
}

template <ResponseProductStageV1 Stage>
[[nodiscard]] Result<TypedResponseProductIdV1<Stage>> decode_product_id(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  auto identity = decode_product_identity<Stage>(value, path);
  if (!identity) {
    return Result<TypedResponseProductIdV1<Stage>>::failure(identity.error());
  }
  if constexpr (Stage == ResponseProductStageV1::raw_response) {
    return Result<TypedResponseProductIdV1<Stage>>::success(
        access.raw_product_id(std::move(identity).value()));
  } else if constexpr (Stage == ResponseProductStageV1::nominal_response) {
    return Result<TypedResponseProductIdV1<Stage>>::success(
        access.nominal_product_id(std::move(identity).value()));
  } else if constexpr (Stage == ResponseProductStageV1::projection_center) {
    return Result<TypedResponseProductIdV1<Stage>>::success(
        access.projection_center_product_id(std::move(identity).value()));
  } else if constexpr (Stage == ResponseProductStageV1::projected_mean) {
    return Result<TypedResponseProductIdV1<Stage>>::success(
        access.projected_mean_product_id(std::move(identity).value()));
  } else {
    return Result<TypedResponseProductIdV1<Stage>>::success(
        access.recoded_product_id(std::move(identity).value()));
  }
}

[[nodiscard]] OrderedJson encode_conditioning(
    const ProposalConditioningMeasureV1& value) {
  OrderedJson result{
      {"source", std::string(enum_text(value.source))},
      {"observed_nonnegative_value",
       artifact::detail::wire::encode_scalar(
           value.observed_nonnegative_value)}};
  if (value.frozen_evaluation_id.has_value()) {
    result["frozen_evaluation_id"] =
        artifact::detail::wire::encode_typed_label(*value.frozen_evaluation_id);
  }
  return result;
}

[[nodiscard]] Result<ProposalConditioningMeasureV1> decode_conditioning(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 2U> required{
      "source", "observed_nonnegative_value"};
  const std::array<std::string_view, 1U> optional{"frozen_evaluation_id"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<ProposalConditioningMeasureV1>::failure(shape.error());
  constexpr std::array sources{ProposalConditioningSourceV1::exact_population,
                               ProposalConditioningSourceV1::empirical_average};
  auto source = decode_enum(value.at("source"), path + "/source",
                            std::span<const ProposalConditioningSourceV1>(sources));
  auto observed = artifact::detail::wire::decode_scalar(
      value.at("observed_nonnegative_value"),
      path + "/observed_nonnegative_value");
  auto frozen = decode_optional_member<TypedLabel>(
      value, "frozen_evaluation_id", path,
      artifact::detail::wire::decode_typed_label);
  if (!source) return Result<ProposalConditioningMeasureV1>::failure(source.error());
  if (!observed) return Result<ProposalConditioningMeasureV1>::failure(observed.error());
  if (!frozen) return Result<ProposalConditioningMeasureV1>::failure(frozen.error());
  return Result<ProposalConditioningMeasureV1>::success(
      ProposalConditioningMeasureV1{std::move(source).value(),
                                    std::move(observed).value(),
                                    std::move(frozen).value()});
}

[[nodiscard]] OrderedJson encode_identification(
    const CoefficientIdentificationV1& value) {
  using artifact::detail::wire::encode_artifact_object_reference;
  OrderedJson result{
      {"coefficient_id", encode_artifact_object_reference(value.coefficient_id)},
      {"proposal_conditioning", encode_conditioning(value.proposal_conditioning)},
      {"coefficient_status",
       OrderedJson{{"population_conditioning_status",
                    std::string(enum_text(
                        value.coefficient_status.population_conditioning_status))},
                   {"raw_value_status",
                    std::string(enum_text(
                        value.coefficient_status.raw_value_status))}}}};
  if (value.raw_point.has_value()) {
    result["raw_point"] = artifact::detail::wire::encode_scalar(*value.raw_point);
  }
  result["family_evidence_envelope_ids"] =
      encode_vector(value.family_evidence_envelope_ids,
                    encode_artifact_object_reference);
  result["provider_conformance_report_ref"] =
      encode_conformance(value.provider_conformance_report_ref);
  if (value.completion_policy_id.has_value()) {
    result["completion_policy_id"] =
        encode_artifact_object_reference(*value.completion_policy_id);
  }
  result["target_bin_binding"] = std::string(enum_text(value.target_bin_binding));
  return result;
}

[[nodiscard]] Result<CoefficientIdentificationV1> decode_identification(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 6U> required{
      "coefficient_id", "proposal_conditioning", "coefficient_status",
      "family_evidence_envelope_ids", "provider_conformance_report_ref",
      "target_bin_binding"};
  const std::array<std::string_view, 2U> optional{
      "raw_point", "completion_policy_id"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<CoefficientIdentificationV1>::failure(shape.error());
  auto status_shape = require_wire_fields(
      value.at("coefficient_status"),
      std::array<std::string_view, 2U>{"population_conditioning_status",
                                      "raw_value_status"},
      path + "/coefficient_status");
  if (!status_shape) return Result<CoefficientIdentificationV1>::failure(status_shape.error());
  constexpr std::array population{
      PopulationConditioningStatusV1::proved_positive,
      PopulationConditioningStatusV1::proved_zero,
      PopulationConditioningStatusV1::positive_with_confidence,
      PopulationConditioningStatusV1::unresolved};
  constexpr std::array raw_status{RawValueStatusV1::exact_point,
                                  RawValueStatusV1::interval_only,
                                  RawValueStatusV1::absent};
  constexpr std::array bins{ThreeBinCoefficientV1::one,
                            ThreeBinCoefficientV1::two,
                            ThreeBinCoefficientV1::tail_from_three};
  auto id = artifact::detail::wire::decode_artifact_object_reference(
      value.at("coefficient_id"), path + "/coefficient_id");
  auto conditioning = decode_conditioning(value.at("proposal_conditioning"),
                                          path + "/proposal_conditioning");
  auto population_status = decode_enum(
      value.at("coefficient_status").at("population_conditioning_status"),
      path + "/coefficient_status/population_conditioning_status",
      std::span<const PopulationConditioningStatusV1>(population));
  auto raw_value_status = decode_enum(
      value.at("coefficient_status").at("raw_value_status"),
      path + "/coefficient_status/raw_value_status",
      std::span<const RawValueStatusV1>(raw_status));
  auto raw_point = decode_optional_member<PortableScientificScalar>(
      value, "raw_point", path,
      artifact::detail::wire::decode_scalar);
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(
      value.at("family_evidence_envelope_ids"),
      path + "/family_evidence_envelope_ids",
      artifact::detail::wire::decode_artifact_object_reference);
  auto conformance = decode_conformance(
      value.at("provider_conformance_report_ref"),
      path + "/provider_conformance_report_ref");
  auto completion = decode_optional_member<ArtifactObjectReferenceV1>(
      value, "completion_policy_id", path,
      artifact::detail::wire::decode_artifact_object_reference);
  auto bin = decode_enum(value.at("target_bin_binding"),
                         path + "/target_bin_binding",
                         std::span<const ThreeBinCoefficientV1>(bins));
  if (!id) return Result<CoefficientIdentificationV1>::failure(id.error());
  if (!conditioning) return Result<CoefficientIdentificationV1>::failure(conditioning.error());
  if (!population_status) return Result<CoefficientIdentificationV1>::failure(population_status.error());
  if (!raw_value_status) return Result<CoefficientIdentificationV1>::failure(raw_value_status.error());
  if (!raw_point) return Result<CoefficientIdentificationV1>::failure(raw_point.error());
  if (!evidence) return Result<CoefficientIdentificationV1>::failure(evidence.error());
  if (!conformance) return Result<CoefficientIdentificationV1>::failure(conformance.error());
  if (!completion) return Result<CoefficientIdentificationV1>::failure(completion.error());
  if (!bin) return Result<CoefficientIdentificationV1>::failure(bin.error());
  return Result<CoefficientIdentificationV1>::success(
      CoefficientIdentificationV1{
          std::move(id).value(), std::move(conditioning).value(),
          CoefficientStatusV1{std::move(population_status).value(),
                              std::move(raw_value_status).value()},
          std::move(raw_point).value(), std::move(evidence).value(),
          std::move(conformance).value(), std::move(completion).value(),
          std::move(bin).value()});
}

[[nodiscard]] OrderedJson encode_coefficient(const ResponseCoefficientV1& value) {
  return OrderedJson{
      {"bin", std::string(enum_text(value.bin))},
      {"value", artifact::detail::wire::encode_scalar(value.value)},
      {"origin_coefficient_id",
       artifact::detail::wire::encode_artifact_object_reference(
           value.origin_coefficient_id)}};
}

[[nodiscard]] Result<ResponseCoefficientV1> decode_coefficient(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value,
      std::array<std::string_view, 3U>{"bin", "value",
                                       "origin_coefficient_id"},
      path);
  if (!shape) return Result<ResponseCoefficientV1>::failure(shape.error());
  constexpr std::array bins{ThreeBinCoefficientV1::one,
                            ThreeBinCoefficientV1::two,
                            ThreeBinCoefficientV1::tail_from_three};
  auto bin = decode_enum(value.at("bin"), path + "/bin",
                         std::span<const ThreeBinCoefficientV1>(bins));
  auto scalar = artifact::detail::wire::decode_scalar(value.at("value"),
                                                       path + "/value");
  auto origin = artifact::detail::wire::decode_artifact_object_reference(
      value.at("origin_coefficient_id"), path + "/origin_coefficient_id");
  if (!bin) return Result<ResponseCoefficientV1>::failure(bin.error());
  if (!scalar) return Result<ResponseCoefficientV1>::failure(scalar.error());
  if (!origin) return Result<ResponseCoefficientV1>::failure(origin.error());
  return Result<ResponseCoefficientV1>::success(
      ResponseCoefficientV1{std::move(bin).value(), std::move(scalar).value(),
                            std::move(origin).value()});
}

[[nodiscard]] OrderedJson encode_coefficients(
    const ResponseCoefficientTripleV1& values) {
  OrderedJson result = OrderedJson::array();
  for (const auto& value : values) result.push_back(encode_coefficient(value));
  return result;
}

[[nodiscard]] Result<ResponseCoefficientTripleV1> decode_coefficients(
    const OrderedJson& value, const std::string& path) {
  if (!value.is_array() || value.size() != 3U) {
    return fail<ResponseCoefficientTripleV1>(
        "artifact_wire_three_bin_count",
        "three-bin coefficient array must contain exactly three entries",
        path);
  }
  auto one = decode_coefficient(value.at(0U), path + "/0");
  auto two = decode_coefficient(value.at(1U), path + "/1");
  auto tail = decode_coefficient(value.at(2U), path + "/2");
  if (!one) return Result<ResponseCoefficientTripleV1>::failure(one.error());
  if (!two) return Result<ResponseCoefficientTripleV1>::failure(two.error());
  if (!tail) return Result<ResponseCoefficientTripleV1>::failure(tail.error());
  return Result<ResponseCoefficientTripleV1>::success(
      ResponseCoefficientTripleV1{std::move(one).value(),
                                  std::move(two).value(),
                                  std::move(tail).value()});
}

}  // namespace
}  // namespace mwperf

namespace mwperf {
namespace {

[[nodiscard]] OrderedJson encode_raw_product(const RawResponseProductV1& value) {
  OrderedJson identifications = OrderedJson::array();
  for (const auto& item : value.identifications) {
    identifications.push_back(encode_identification(item));
  }
  return OrderedJson{
      {"product_id", encode_product_id(value.product_id)},
      {"provider", encode_provider(value.provider)},
      {"request_digest", artifact::detail::wire::encode_digest(value.request_digest)},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"configured_arrival_binding",
       artifact::detail::wire::encode_digest(value.configured_arrival_binding)},
      {"proposal_law_digest",
       artifact::detail::wire::encode_digest(value.proposal_law_digest)},
      {"identifications", std::move(identifications)}};
}

[[nodiscard]] Result<RawResponseProductV1> decode_raw_product(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 7U> fields{
      "product_id", "provider", "request_digest", "deployed_target",
      "configured_arrival_binding", "proposal_law_digest", "identifications"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<RawResponseProductV1>::failure(shape.error());
  auto product_id = decode_product_id<ResponseProductStageV1::raw_response>(
      value.at("product_id"), path + "/product_id", access);
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto request = artifact::detail::wire::decode_digest(
      value.at("request_digest"), path + "/request_digest");
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"),
                                          path + "/deployed_target");
  auto arrival = artifact::detail::wire::decode_digest(
      value.at("configured_arrival_binding"),
      path + "/configured_arrival_binding");
  auto proposal = artifact::detail::wire::decode_digest(
      value.at("proposal_law_digest"), path + "/proposal_law_digest");
  if (!value.at("identifications").is_array() ||
      value.at("identifications").size() != 3U) {
    return fail<RawResponseProductV1>(
        "artifact_wire_three_identifications",
        "raw response requires exactly three ordered identifications",
        path + "/identifications");
  }
  auto one = decode_identification(value.at("identifications").at(0U),
                                   path + "/identifications/0");
  auto two = decode_identification(value.at("identifications").at(1U),
                                   path + "/identifications/1");
  auto tail = decode_identification(value.at("identifications").at(2U),
                                    path + "/identifications/2");
  if (!product_id) return Result<RawResponseProductV1>::failure(product_id.error());
  if (!provider) return Result<RawResponseProductV1>::failure(provider.error());
  if (!request) return Result<RawResponseProductV1>::failure(request.error());
  if (!target) return Result<RawResponseProductV1>::failure(target.error());
  if (!arrival) return Result<RawResponseProductV1>::failure(arrival.error());
  if (!proposal) return Result<RawResponseProductV1>::failure(proposal.error());
  if (!one) return Result<RawResponseProductV1>::failure(one.error());
  if (!two) return Result<RawResponseProductV1>::failure(two.error());
  if (!tail) return Result<RawResponseProductV1>::failure(tail.error());
  return Result<RawResponseProductV1>::success(RawResponseProductV1{
      std::move(product_id).value(), std::move(provider).value(),
      std::move(request).value(), std::move(target).value(),
      std::move(arrival).value(), std::move(proposal).value(),
      {std::move(one).value(), std::move(two).value(),
       std::move(tail).value()}});
}

[[nodiscard]] OrderedJson encode_nominal_product(
    const NominalResponseProductV1& value) {
  using artifact::detail::wire::encode_artifact_object_reference;
  OrderedJson result{
      {"product_id", encode_product_id(value.product_id)},
      {"provider", encode_provider(value.provider)},
      {"request_digest", artifact::detail::wire::encode_digest(value.request_digest)},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"coefficients", encode_coefficients(value.coefficients)},
      {"raw_parent", encode_product_id(value.raw_parent)}};
  if (value.completion_policy_id.has_value()) {
    result["completion_policy_id"] =
        encode_artifact_object_reference(*value.completion_policy_id);
  }
  if (value.derivation_certificate_id.has_value()) {
    result["derivation_certificate_id"] =
        encode_artifact_object_reference(*value.derivation_certificate_id);
  }
  return result;
}

[[nodiscard]] Result<NominalResponseProductV1> decode_nominal_product(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 6U> required{
      "product_id", "provider", "request_digest", "deployed_target",
      "coefficients", "raw_parent"};
  const std::array<std::string_view, 2U> optional{
      "completion_policy_id", "derivation_certificate_id"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<NominalResponseProductV1>::failure(shape.error());
  auto product_id = decode_product_id<ResponseProductStageV1::nominal_response>(
      value.at("product_id"), path + "/product_id", access);
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto request = artifact::detail::wire::decode_digest(
      value.at("request_digest"), path + "/request_digest");
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"),
                                          path + "/deployed_target");
  auto coefficients = decode_coefficients(value.at("coefficients"),
                                          path + "/coefficients");
  auto raw_parent = decode_product_id<ResponseProductStageV1::raw_response>(
      value.at("raw_parent"), path + "/raw_parent", access);
  auto completion = decode_optional_member<ArtifactObjectReferenceV1>(
      value, "completion_policy_id", path,
      artifact::detail::wire::decode_artifact_object_reference);
  auto certificate = decode_optional_member<ArtifactObjectReferenceV1>(
      value, "derivation_certificate_id", path,
      artifact::detail::wire::decode_artifact_object_reference);
  if (!product_id) return Result<NominalResponseProductV1>::failure(product_id.error());
  if (!provider) return Result<NominalResponseProductV1>::failure(provider.error());
  if (!request) return Result<NominalResponseProductV1>::failure(request.error());
  if (!target) return Result<NominalResponseProductV1>::failure(target.error());
  if (!coefficients) return Result<NominalResponseProductV1>::failure(coefficients.error());
  if (!raw_parent) return Result<NominalResponseProductV1>::failure(raw_parent.error());
  if (!completion) return Result<NominalResponseProductV1>::failure(completion.error());
  if (!certificate) return Result<NominalResponseProductV1>::failure(certificate.error());
  return Result<NominalResponseProductV1>::success(NominalResponseProductV1{
      std::move(product_id).value(), std::move(provider).value(),
      std::move(request).value(), std::move(target).value(),
      std::move(coefficients).value(), std::move(raw_parent).value(),
      std::move(completion).value(), std::move(certificate).value()});
}

[[nodiscard]] OrderedJson encode_projection_center(
    const ProjectionCenterProductV1& value) {
  OrderedJson result{
      {"product_id", encode_product_id(value.product_id)},
      {"provider", encode_provider(value.provider)},
      {"request_digest", artifact::detail::wire::encode_digest(value.request_digest)},
      {"ordered_construction_targets",
       encode_vector(value.ordered_construction_targets,
                     [](const QueueId& id) { return encode_strong_id(id); })},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"source_kind", std::string(enum_text(value.source_kind))},
      {"mean_vector", encode_scalar_array(value.mean_vector)},
      {"response_source",
       std::visit([](const auto& id) { return encode_product_id(id); },
                  value.response_source)}};
  if (value.completion_policy_id.has_value()) {
    result["completion_policy_id"] =
        artifact::detail::wire::encode_artifact_object_reference(
            *value.completion_policy_id);
  }
  return result;
}

[[nodiscard]] Result<ProjectionCenterProductV1> decode_projection_center(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 8U> required{
      "product_id", "provider", "request_digest",
      "ordered_construction_targets", "deployed_target", "source_kind",
      "mean_vector", "response_source"};
  const std::array<std::string_view, 1U> optional{"completion_policy_id"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<ProjectionCenterProductV1>::failure(shape.error());
  auto product_id = decode_product_id<ResponseProductStageV1::projection_center>(
      value.at("product_id"), path + "/product_id", access);
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto request = artifact::detail::wire::decode_digest(value.at("request_digest"), path + "/request_digest");
  auto targets = decode_vector<QueueId>(
      value.at("ordered_construction_targets"),
      path + "/ordered_construction_targets", decode_strong_id<QueueId>);
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"), path + "/deployed_target");
  constexpr std::array source_kinds{
      ProjectionCenterSourceKindV1::decoded_raw_response,
      ProjectionCenterSourceKindV1::synthetic_snapshot_mean,
      ProjectionCenterSourceKindV1::explicit_fallback};
  auto source_kind = decode_enum(
      value.at("source_kind"), path + "/source_kind",
      std::span<const ProjectionCenterSourceKindV1>(source_kinds));
  auto mean = decode_scalar_array(value.at("mean_vector"), path + "/mean_vector");
  if (!value.at("response_source").is_object() ||
      !value.at("response_source").contains("stage") ||
      !value.at("response_source").at("stage").is_string()) {
    return fail<ProjectionCenterProductV1>("artifact_wire_product_stage",
                                           "invalid response source stage",
                                           path + "/response_source");
  }
  const std::string stage = value.at("response_source").at("stage").get<std::string>();
  std::optional<std::variant<RawResponseProductId, NominalResponseProductId>> source;
  Diagnostic source_error = artifact_error("artifact_wire_product_stage",
                                           "invalid projection-center source stage",
                                           path + "/response_source/stage");
  if (stage == "raw_response") {
    auto decoded = decode_product_id<ResponseProductStageV1::raw_response>(value.at("response_source"), path + "/response_source", access);
    if (decoded) source = std::move(decoded).value(); else source_error = decoded.error();
  } else if (stage == "nominal_response") {
    auto decoded = decode_product_id<ResponseProductStageV1::nominal_response>(value.at("response_source"), path + "/response_source", access);
    if (decoded) source = std::move(decoded).value(); else source_error = decoded.error();
  }
  auto completion = decode_optional_member<ArtifactObjectReferenceV1>(
      value, "completion_policy_id", path,
      artifact::detail::wire::decode_artifact_object_reference);
  if (!product_id) return Result<ProjectionCenterProductV1>::failure(product_id.error());
  if (!provider) return Result<ProjectionCenterProductV1>::failure(provider.error());
  if (!request) return Result<ProjectionCenterProductV1>::failure(request.error());
  if (!targets) return Result<ProjectionCenterProductV1>::failure(targets.error());
  if (!target) return Result<ProjectionCenterProductV1>::failure(target.error());
  if (!source_kind) return Result<ProjectionCenterProductV1>::failure(source_kind.error());
  if (!mean) return Result<ProjectionCenterProductV1>::failure(mean.error());
  if (!source) return Result<ProjectionCenterProductV1>::failure(source_error);
  if (!completion) return Result<ProjectionCenterProductV1>::failure(completion.error());
  return Result<ProjectionCenterProductV1>::success(ProjectionCenterProductV1{
      std::move(product_id).value(), std::move(provider).value(),
      std::move(request).value(), std::move(targets).value(),
      std::move(target).value(), std::move(source_kind).value(),
      std::move(mean).value(), std::move(*source),
      std::move(completion).value()});
}

[[nodiscard]] OrderedJson encode_projected_mean(
    const ProjectedMeanProductV1& value) {
  using artifact::detail::wire::encode_artifact_object_reference;
  OrderedJson result{
      {"product_id", encode_product_id(value.product_id)},
      {"provider", encode_provider(value.provider)},
      {"request_digest", artifact::detail::wire::encode_digest(value.request_digest)},
      {"ordered_construction_targets",
       encode_vector(value.ordered_construction_targets,
                     [](const QueueId& id) { return encode_strong_id(id); })},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"mean_vector", encode_scalar_array(value.mean_vector)},
      {"center_parent", encode_product_id(value.center_parent)},
      {"projection_policy_id",
       encode_artifact_object_reference(value.projection_policy_id)}};
  if (value.derivation_certificate_id.has_value()) {
    result["derivation_certificate_id"] =
        encode_artifact_object_reference(*value.derivation_certificate_id);
  }
  return result;
}

[[nodiscard]] Result<ProjectedMeanProductV1> decode_projected_mean(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 8U> required{
      "product_id", "provider", "request_digest",
      "ordered_construction_targets", "deployed_target", "mean_vector",
      "center_parent", "projection_policy_id"};
  const std::array<std::string_view, 1U> optional{"derivation_certificate_id"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<ProjectedMeanProductV1>::failure(shape.error());
  auto product_id = decode_product_id<ResponseProductStageV1::projected_mean>(value.at("product_id"), path + "/product_id", access);
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto request = artifact::detail::wire::decode_digest(value.at("request_digest"), path + "/request_digest");
  auto targets = decode_vector<QueueId>(value.at("ordered_construction_targets"), path + "/ordered_construction_targets", decode_strong_id<QueueId>);
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"), path + "/deployed_target");
  auto mean = decode_scalar_array(value.at("mean_vector"), path + "/mean_vector");
  auto parent = decode_product_id<ResponseProductStageV1::projection_center>(value.at("center_parent"), path + "/center_parent", access);
  auto policy = artifact::detail::wire::decode_artifact_object_reference(value.at("projection_policy_id"), path + "/projection_policy_id");
  auto certificate = decode_optional_member<ArtifactObjectReferenceV1>(value, "derivation_certificate_id", path, artifact::detail::wire::decode_artifact_object_reference);
  if (!product_id) return Result<ProjectedMeanProductV1>::failure(product_id.error());
  if (!provider) return Result<ProjectedMeanProductV1>::failure(provider.error());
  if (!request) return Result<ProjectedMeanProductV1>::failure(request.error());
  if (!targets) return Result<ProjectedMeanProductV1>::failure(targets.error());
  if (!target) return Result<ProjectedMeanProductV1>::failure(target.error());
  if (!mean) return Result<ProjectedMeanProductV1>::failure(mean.error());
  if (!parent) return Result<ProjectedMeanProductV1>::failure(parent.error());
  if (!policy) return Result<ProjectedMeanProductV1>::failure(policy.error());
  if (!certificate) return Result<ProjectedMeanProductV1>::failure(certificate.error());
  return Result<ProjectedMeanProductV1>::success(ProjectedMeanProductV1{
      std::move(product_id).value(), std::move(provider).value(),
      std::move(request).value(), std::move(targets).value(),
      std::move(target).value(), std::move(mean).value(),
      std::move(parent).value(), std::move(policy).value(),
      std::move(certificate).value()});
}

[[nodiscard]] OrderedJson encode_recoded_product(
    const RecodedResponseProductV1& value) {
  using artifact::detail::wire::encode_artifact_object_reference;
  OrderedJson result{
      {"product_id", encode_product_id(value.product_id)},
      {"provider", encode_provider(value.provider)},
      {"request_digest", artifact::detail::wire::encode_digest(value.request_digest)},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"coefficients", encode_coefficients(value.coefficients)},
      {"derivation_kind", std::string(enum_text(value.derivation_kind))}};
  if (value.projected_mean_parent.has_value()) {
    result["projected_mean_parent"] = encode_product_id(*value.projected_mean_parent);
  }
  if (const auto* raw =
          std::get_if<RawResponseProductId>(&value.reference_response_parent)) {
    result["reference_response_parent"] = encode_product_id(*raw);
  } else if (const auto* nominal = std::get_if<NominalResponseProductId>(
                 &value.reference_response_parent)) {
    result["reference_response_parent"] = encode_product_id(*nominal);
  }
  if (value.completion_policy_id.has_value()) {
    result["completion_policy_id"] =
        encode_artifact_object_reference(*value.completion_policy_id);
  }
  result["recoding_policy_id"] =
      encode_artifact_object_reference(value.recoding_policy_id);
  if (value.derivation_certificate_id.has_value()) {
    result["derivation_certificate_id"] =
        encode_artifact_object_reference(*value.derivation_certificate_id);
  }
  return result;
}

[[nodiscard]] Result<RecodedResponseProductV1> decode_recoded_product(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 7U> required{
      "product_id", "provider", "request_digest", "deployed_target",
      "coefficients", "derivation_kind", "recoding_policy_id"};
  const std::array<std::string_view, 4U> optional{
      "projected_mean_parent", "reference_response_parent",
      "completion_policy_id", "derivation_certificate_id"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<RecodedResponseProductV1>::failure(shape.error());
  auto product_id = decode_product_id<ResponseProductStageV1::recoded_response>(value.at("product_id"), path + "/product_id", access);
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto request = artifact::detail::wire::decode_digest(value.at("request_digest"), path + "/request_digest");
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"), path + "/deployed_target");
  auto coefficients = decode_coefficients(value.at("coefficients"), path + "/coefficients");
  constexpr std::array kinds{ProductDerivationKindV1::nominal_completion,
                             ProductDerivationKindV1::admissibility_projection,
                             ProductDerivationKindV1::identity_recoding,
                             ProductDerivationKindV1::mean_inversion_recoding,
                             ProductDerivationKindV1::endpoint_completion};
  auto kind = decode_enum(value.at("derivation_kind"), path + "/derivation_kind",
                          std::span<const ProductDerivationKindV1>(kinds));
  auto mean_parent = decode_optional_member<ProjectedMeanProductId>(
      value, "projected_mean_parent", path,
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_product_id<ResponseProductStageV1::projected_mean>(
            item, item_path, access);
      });
  std::variant<std::monostate, RawResponseProductId, NominalResponseProductId> reference;
  if (value.contains("reference_response_parent")) {
    if (value.at("reference_response_parent").is_null()) {
      return fail<RecodedResponseProductV1>("artifact_wire_null_optional", "optional version-1 members are omitted, never encoded as null", path + "/reference_response_parent");
    }
    if (!value.at("reference_response_parent").is_object() ||
        !value.at("reference_response_parent").contains("stage") ||
        !value.at("reference_response_parent").at("stage").is_string()) {
      return fail<RecodedResponseProductV1>("artifact_wire_product_stage", "invalid recoding reference response", path + "/reference_response_parent");
    }
    const std::string stage = value.at("reference_response_parent").at("stage").get<std::string>();
    if (stage == "raw_response") {
      auto decoded = decode_product_id<ResponseProductStageV1::raw_response>(value.at("reference_response_parent"), path + "/reference_response_parent", access);
      if (!decoded) return Result<RecodedResponseProductV1>::failure(decoded.error());
      reference = std::move(decoded).value();
    } else if (stage == "nominal_response") {
      auto decoded = decode_product_id<ResponseProductStageV1::nominal_response>(value.at("reference_response_parent"), path + "/reference_response_parent", access);
      if (!decoded) return Result<RecodedResponseProductV1>::failure(decoded.error());
      reference = std::move(decoded).value();
    } else {
      return fail<RecodedResponseProductV1>("artifact_wire_product_stage", "recoding reference must be raw or nominal", path + "/reference_response_parent/stage");
    }
  }
  auto completion = decode_optional_member<ArtifactObjectReferenceV1>(value, "completion_policy_id", path, artifact::detail::wire::decode_artifact_object_reference);
  auto policy = artifact::detail::wire::decode_artifact_object_reference(value.at("recoding_policy_id"), path + "/recoding_policy_id");
  auto certificate = decode_optional_member<ArtifactObjectReferenceV1>(value, "derivation_certificate_id", path, artifact::detail::wire::decode_artifact_object_reference);
  if (!product_id) return Result<RecodedResponseProductV1>::failure(product_id.error());
  if (!provider) return Result<RecodedResponseProductV1>::failure(provider.error());
  if (!request) return Result<RecodedResponseProductV1>::failure(request.error());
  if (!target) return Result<RecodedResponseProductV1>::failure(target.error());
  if (!coefficients) return Result<RecodedResponseProductV1>::failure(coefficients.error());
  if (!kind) return Result<RecodedResponseProductV1>::failure(kind.error());
  if (!mean_parent) return Result<RecodedResponseProductV1>::failure(mean_parent.error());
  if (!completion) return Result<RecodedResponseProductV1>::failure(completion.error());
  if (!policy) return Result<RecodedResponseProductV1>::failure(policy.error());
  if (!certificate) return Result<RecodedResponseProductV1>::failure(certificate.error());
  return Result<RecodedResponseProductV1>::success(RecodedResponseProductV1{
      std::move(product_id).value(), std::move(provider).value(),
      std::move(request).value(), std::move(target).value(),
      std::move(coefficients).value(), std::move(kind).value(),
      std::move(mean_parent).value(), std::move(reference),
      std::move(completion).value(), std::move(policy).value(),
      std::move(certificate).value()});
}

[[nodiscard]] OrderedJson encode_deployed_id(const DeployedResponseProductIdV1& value) {
  return std::visit([](const auto& id) { return encode_product_id(id); }, value);
}

[[nodiscard]] Result<DeployedResponseProductIdV1> decode_deployed_id(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  if (!value.is_object() || !value.contains("stage") || !value.at("stage").is_string()) {
    return fail<DeployedResponseProductIdV1>("artifact_wire_product_stage", "invalid deployed response-product ID", path);
  }
  const std::string stage = value.at("stage").get<std::string>();
  if (stage == "raw_response") {
    auto decoded = decode_product_id<ResponseProductStageV1::raw_response>(value, path, access);
    if (!decoded) return Result<DeployedResponseProductIdV1>::failure(decoded.error());
    return Result<DeployedResponseProductIdV1>::success(std::move(decoded).value());
  }
  if (stage == "nominal_response") {
    auto decoded = decode_product_id<ResponseProductStageV1::nominal_response>(value, path, access);
    if (!decoded) return Result<DeployedResponseProductIdV1>::failure(decoded.error());
    return Result<DeployedResponseProductIdV1>::success(std::move(decoded).value());
  }
  if (stage == "recoded_response") {
    auto decoded = decode_product_id<ResponseProductStageV1::recoded_response>(value, path, access);
    if (!decoded) return Result<DeployedResponseProductIdV1>::failure(decoded.error());
    return Result<DeployedResponseProductIdV1>::success(std::move(decoded).value());
  }
  return fail<DeployedResponseProductIdV1>("artifact_wire_deployed_stage", "mean-stage and unknown products are not deployable", path + "/stage");
}

[[nodiscard]] OrderedJson encode_raw_envelope(const RawResponseEnvelopeV1& value) {
  OrderedJson result{
      {"envelope_id", artifact::detail::wire::encode_artifact_object_reference(value.envelope_id)},
      {"source_product", encode_product_id(value.source_product)},
      {"construction_law_digest", artifact::detail::wire::encode_digest(value.construction_law_digest)},
      {"covered_bins", encode_vector(value.covered_bins, [](const auto bin) { return OrderedJson(std::string(enum_text(bin))); })},
      {"lower", encode_scalar_array(value.lower)},
      {"upper", encode_scalar_array(value.upper)},
      {"certification_method", value.certification_method},
      {"coverage", std::string(enum_text(value.coverage))},
      {"population_conditioning_premise", std::string(enum_text(value.population_conditioning_premise))}};
  if (value.frozen_evaluation_id.has_value()) {
    result["frozen_evaluation_id"] = artifact::detail::wire::encode_typed_label(*value.frozen_evaluation_id);
  }
  if (value.sample_size.has_value()) {
    result["sample_size"] = artifact::detail::wire::encode_big_nat(*value.sample_size);
  }
  result["scope"] = std::string(enum_text(value.scope));
  result["family_evidence_envelope_ids"] = encode_vector(
      value.family_evidence_envelope_ids,
      artifact::detail::wire::encode_artifact_object_reference);
  return result;
}

[[nodiscard]] Result<RawResponseEnvelopeV1> decode_raw_envelope(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 11U> required{
      "envelope_id", "source_product", "construction_law_digest",
      "covered_bins", "lower", "upper", "certification_method", "coverage",
      "population_conditioning_premise", "scope",
      "family_evidence_envelope_ids"};
  const std::array<std::string_view, 2U> optional{
      "frozen_evaluation_id", "sample_size"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<RawResponseEnvelopeV1>::failure(shape.error());
  constexpr std::array bins{ThreeBinCoefficientV1::one, ThreeBinCoefficientV1::two, ThreeBinCoefficientV1::tail_from_three};
  constexpr std::array coverages{RawEnvelopeCoverageV1::deterministic, RawEnvelopeCoverageV1::marginal, RawEnvelopeCoverageV1::simultaneous};
  constexpr std::array premises{PopulationConditioningPremiseV1::unconditional, PopulationConditioningPremiseV1::conditional_on_population_positivity};
  constexpr std::array scopes{RawEnvelopeScopeV1::proposal_raw, RawEnvelopeScopeV1::optimizer_interval_raw, RawEnvelopeScopeV1::deterministic_quadrature_raw, RawEnvelopeScopeV1::physical_response_bound};
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("envelope_id"), path + "/envelope_id");
  auto source = decode_product_id<ResponseProductStageV1::raw_response>(value.at("source_product"), path + "/source_product", access);
  auto law = artifact::detail::wire::decode_digest(value.at("construction_law_digest"), path + "/construction_law_digest");
  auto covered = decode_vector<ThreeBinCoefficientV1>(value.at("covered_bins"), path + "/covered_bins", [&bins](const OrderedJson& item, const std::string& item_path) { return decode_enum(item, item_path, std::span<const ThreeBinCoefficientV1>(bins)); });
  auto lower = decode_scalar_array(value.at("lower"), path + "/lower");
  auto upper = decode_scalar_array(value.at("upper"), path + "/upper");
  auto method = required_string(value.at("certification_method"), path + "/certification_method", true);
  auto coverage = decode_enum(value.at("coverage"), path + "/coverage", std::span<const RawEnvelopeCoverageV1>(coverages));
  auto premise = decode_enum(value.at("population_conditioning_premise"), path + "/population_conditioning_premise", std::span<const PopulationConditioningPremiseV1>(premises));
  auto frozen = decode_optional_member<TypedLabel>(value, "frozen_evaluation_id", path, artifact::detail::wire::decode_typed_label);
  auto sample = decode_optional_member<BigNat>(value, "sample_size", path, artifact::detail::wire::decode_big_nat);
  auto scope = decode_enum(value.at("scope"), path + "/scope", std::span<const RawEnvelopeScopeV1>(scopes));
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(value.at("family_evidence_envelope_ids"), path + "/family_evidence_envelope_ids", artifact::detail::wire::decode_artifact_object_reference);
  if (!id) return Result<RawResponseEnvelopeV1>::failure(id.error());
  if (!source) return Result<RawResponseEnvelopeV1>::failure(source.error());
  if (!law) return Result<RawResponseEnvelopeV1>::failure(law.error());
  if (!covered) return Result<RawResponseEnvelopeV1>::failure(covered.error());
  if (!lower) return Result<RawResponseEnvelopeV1>::failure(lower.error());
  if (!upper) return Result<RawResponseEnvelopeV1>::failure(upper.error());
  if (!method) return Result<RawResponseEnvelopeV1>::failure(method.error());
  if (!coverage) return Result<RawResponseEnvelopeV1>::failure(coverage.error());
  if (!premise) return Result<RawResponseEnvelopeV1>::failure(premise.error());
  if (!frozen) return Result<RawResponseEnvelopeV1>::failure(frozen.error());
  if (!sample) return Result<RawResponseEnvelopeV1>::failure(sample.error());
  if (!scope) return Result<RawResponseEnvelopeV1>::failure(scope.error());
  if (!evidence) return Result<RawResponseEnvelopeV1>::failure(evidence.error());
  return Result<RawResponseEnvelopeV1>::success(RawResponseEnvelopeV1{
      std::move(id).value(), std::move(source).value(), std::move(law).value(),
      std::move(covered).value(), std::move(lower).value(),
      std::move(upper).value(), std::move(method).value(),
      std::move(coverage).value(), std::move(premise).value(),
      std::move(frozen).value(), std::move(sample).value(),
      std::move(scope).value(), std::move(evidence).value()});
}

[[nodiscard]] OrderedJson encode_three_bin(const ThreeBinScalarResponseV1& value) {
  OrderedJson result{
      {"payload_version", value.payload_version},
      {"response_row_id", artifact::detail::wire::encode_artifact_object_reference(value.response_row_id)},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"configured_arrival_binding", artifact::detail::wire::encode_digest(value.configured_arrival_binding)},
      {"raw_response", encode_raw_product(value.raw_response)}};
  if (value.nominal_response.has_value()) {
    result["nominal_response"] = encode_nominal_product(*value.nominal_response);
  }
  if (value.projection_center.has_value()) {
    result["projection_center"] = encode_projection_center(*value.projection_center);
  }
  if (value.projected_mean.has_value()) {
    result["projected_mean"] = encode_projected_mean(*value.projected_mean);
  }
  if (value.recoded_response.has_value()) {
    result["recoded_response"] = encode_recoded_product(*value.recoded_response);
  }
  result["deployed_response_product_id"] =
      encode_deployed_id(value.deployed_response_product_id);
  result["raw_envelopes"] =
      encode_vector(value.raw_envelopes, encode_raw_envelope);
  return result;
}

[[nodiscard]] Result<ThreeBinScalarResponseV1> decode_three_bin(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 7U> required{
      "payload_version", "response_row_id", "deployed_target",
      "configured_arrival_binding", "raw_response",
      "deployed_response_product_id", "raw_envelopes"};
  const std::array<std::string_view, 4U> optional{
      "nominal_response", "projection_center", "projected_mean",
      "recoded_response"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<ThreeBinScalarResponseV1>::failure(shape.error());
  auto version = required_u32(value.at("payload_version"), path + "/payload_version");
  auto row_id = artifact::detail::wire::decode_artifact_object_reference(
      value.at("response_row_id"), path + "/response_row_id");
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"), path + "/deployed_target");
  auto arrival = artifact::detail::wire::decode_digest(value.at("configured_arrival_binding"), path + "/configured_arrival_binding");
  auto raw = decode_raw_product(value.at("raw_response"), path + "/raw_response", access);
  auto nominal = decode_optional_member<NominalResponseProductV1>(
      value, "nominal_response", path,
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_nominal_product(item, item_path, access);
      });
  auto center = decode_optional_member<ProjectionCenterProductV1>(
      value, "projection_center", path,
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_projection_center(item, item_path, access);
      });
  auto projected = decode_optional_member<ProjectedMeanProductV1>(
      value, "projected_mean", path,
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_projected_mean(item, item_path, access);
      });
  auto recoded = decode_optional_member<RecodedResponseProductV1>(
      value, "recoded_response", path,
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_recoded_product(item, item_path, access);
      });
  auto deployed = decode_deployed_id(value.at("deployed_response_product_id"), path + "/deployed_response_product_id", access);
  auto envelopes = decode_vector<RawResponseEnvelopeV1>(
      value.at("raw_envelopes"), path + "/raw_envelopes",
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_raw_envelope(item, item_path, access);
      });
  if (!version) return Result<ThreeBinScalarResponseV1>::failure(version.error());
  if (version.value() != kProtocolVersion) return fail<ThreeBinScalarResponseV1>("artifact_wire_unsupported_version", "three-bin payload version must equal one", path + "/payload_version");
  if (!row_id) return Result<ThreeBinScalarResponseV1>::failure(row_id.error());
  if (!target) return Result<ThreeBinScalarResponseV1>::failure(target.error());
  if (!arrival) return Result<ThreeBinScalarResponseV1>::failure(arrival.error());
  if (!raw) return Result<ThreeBinScalarResponseV1>::failure(raw.error());
  if (!nominal) return Result<ThreeBinScalarResponseV1>::failure(nominal.error());
  if (!center) return Result<ThreeBinScalarResponseV1>::failure(center.error());
  if (!projected) return Result<ThreeBinScalarResponseV1>::failure(projected.error());
  if (!recoded) return Result<ThreeBinScalarResponseV1>::failure(recoded.error());
  if (!deployed) return Result<ThreeBinScalarResponseV1>::failure(deployed.error());
  if (!envelopes) return Result<ThreeBinScalarResponseV1>::failure(envelopes.error());
  return Result<ThreeBinScalarResponseV1>::success(ThreeBinScalarResponseV1{
      std::move(version).value(), std::move(row_id).value(),
      std::move(target).value(),
      std::move(arrival).value(), std::move(raw).value(),
      std::move(nominal).value(), std::move(center).value(),
      std::move(projected).value(), std::move(recoded).value(),
      std::move(deployed).value(), std::move(envelopes).value()});
}

[[nodiscard]] OrderedJson encode_finite_prefix_coordinate(
    const FinitePrefixResponseCoordinateV1& value) {
  OrderedJson result{{"kind", std::string(enum_text(value.kind))}};
  if (value.kind ==
      FinitePrefixResponseCoordinateKindV1::constant_tail) {
    result["tail_from"] =
        artifact::detail::wire::encode_big_nat(value.level_or_tail_from);
  } else {
    result["level"] =
        artifact::detail::wire::encode_big_nat(value.level_or_tail_from);
  }
  return result;
}

[[nodiscard]] Result<FinitePrefixResponseCoordinateV1>
decode_finite_prefix_coordinate(const OrderedJson& value,
                                const std::string& path) {
  if (!value.is_object() || !value.contains("kind") ||
      !value.at("kind").is_string()) {
    return fail<FinitePrefixResponseCoordinateV1>(
        "artifact_wire_finite_prefix_coordinate_shape",
        "finite-prefix coordinate requires one closed kind", path);
  }
  constexpr std::array kinds{
      FinitePrefixResponseCoordinateKindV1::structural_level_zero,
      FinitePrefixResponseCoordinateKindV1::exact_level,
      FinitePrefixResponseCoordinateKindV1::constant_tail};
  auto kind = decode_enum(
      value.at("kind"), path + "/kind",
      std::span<const FinitePrefixResponseCoordinateKindV1>(kinds));
  if (!kind) {
    return Result<FinitePrefixResponseCoordinateV1>::failure(kind.error());
  }
  const bool tail = kind.value() ==
                    FinitePrefixResponseCoordinateKindV1::constant_tail;
  static constexpr std::array<std::string_view, 2U> kTailFields{
      "kind", "tail_from"};
  static constexpr std::array<std::string_view, 2U> kLevelFields{
      "kind", "level"};
  auto shape = require_wire_fields(
      value,
      tail ? std::span<const std::string_view>(kTailFields)
           : std::span<const std::string_view>(kLevelFields),
      path);
  if (!shape) {
    return Result<FinitePrefixResponseCoordinateV1>::failure(shape.error());
  }
  auto coordinate = artifact::detail::wire::decode_big_nat(
      value.at(tail ? "tail_from" : "level"),
      path + (tail ? "/tail_from" : "/level"));
  if (!coordinate) {
    return Result<FinitePrefixResponseCoordinateV1>::failure(
        coordinate.error());
  }
  return Result<FinitePrefixResponseCoordinateV1>::success(
      {std::move(kind).value(), std::move(coordinate).value()});
}

[[nodiscard]] OrderedJson encode_finite_prefix_identification(
    const FinitePrefixCoefficientIdentificationV1& value) {
  return OrderedJson{
      {"coefficient_id",
       artifact::detail::wire::encode_artifact_object_reference(
           value.coefficient_id)},
      {"coordinate", encode_finite_prefix_coordinate(value.coordinate)},
      {"pooled_mass",
       OrderedJson{
           {"unserved", artifact::detail::wire::encode_scalar(
                              value.pooled_unserved_mass)},
           {"served", artifact::detail::wire::encode_scalar(
                            value.pooled_served_mass)}}},
      {"raw_point", artifact::detail::wire::encode_scalar(value.raw_point)},
      {"family_evidence_envelope_ids",
       encode_vector(value.family_evidence_envelope_ids,
                     artifact::detail::wire::
                         encode_artifact_object_reference)},
      {"provider_conformance_report_ref",
       encode_conformance(value.provider_conformance_report_ref)}};
}

[[nodiscard]] Result<FinitePrefixCoefficientIdentificationV1>
decode_finite_prefix_identification(const OrderedJson& value,
                                    const std::string& path) {
  const std::array<std::string_view, 6U> fields{
      "coefficient_id", "coordinate", "pooled_mass", "raw_point",
      "family_evidence_envelope_ids", "provider_conformance_report_ref"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) {
    return Result<FinitePrefixCoefficientIdentificationV1>::failure(
        shape.error());
  }
  auto mass_shape = require_wire_fields(
      value.at("pooled_mass"),
      std::array<std::string_view, 2U>{"unserved", "served"},
      path + "/pooled_mass");
  if (!mass_shape) {
    return Result<FinitePrefixCoefficientIdentificationV1>::failure(
        mass_shape.error());
  }
  auto id = artifact::detail::wire::decode_artifact_object_reference(
      value.at("coefficient_id"), path + "/coefficient_id");
  auto coordinate = decode_finite_prefix_coordinate(
      value.at("coordinate"), path + "/coordinate");
  auto unserved = artifact::detail::wire::decode_scalar(
      value.at("pooled_mass").at("unserved"),
      path + "/pooled_mass/unserved");
  auto served = artifact::detail::wire::decode_scalar(
      value.at("pooled_mass").at("served"),
      path + "/pooled_mass/served");
  auto point = artifact::detail::wire::decode_scalar(
      value.at("raw_point"), path + "/raw_point");
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(
      value.at("family_evidence_envelope_ids"),
      path + "/family_evidence_envelope_ids",
      artifact::detail::wire::decode_artifact_object_reference);
  auto conformance = decode_conformance(
      value.at("provider_conformance_report_ref"),
      path + "/provider_conformance_report_ref");
  if (!id) return Result<FinitePrefixCoefficientIdentificationV1>::failure(id.error());
  if (!coordinate) return Result<FinitePrefixCoefficientIdentificationV1>::failure(coordinate.error());
  if (!unserved) return Result<FinitePrefixCoefficientIdentificationV1>::failure(unserved.error());
  if (!served) return Result<FinitePrefixCoefficientIdentificationV1>::failure(served.error());
  if (!point) return Result<FinitePrefixCoefficientIdentificationV1>::failure(point.error());
  if (!evidence) return Result<FinitePrefixCoefficientIdentificationV1>::failure(evidence.error());
  if (!conformance) return Result<FinitePrefixCoefficientIdentificationV1>::failure(conformance.error());
  return Result<FinitePrefixCoefficientIdentificationV1>::success({
      std::move(id).value(), std::move(coordinate).value(),
      std::move(unserved).value(), std::move(served).value(),
      std::move(point).value(), std::move(evidence).value(),
      std::move(conformance).value()});
}

[[nodiscard]] OrderedJson encode_finite_prefix_raw_product(
    const FinitePrefixRawResponseProductV1& value) {
  return OrderedJson{
      {"product_id", encode_product_id(value.product_id)},
      {"provider", encode_provider(value.provider)},
      {"request_digest",
       artifact::detail::wire::encode_digest(value.request_digest)},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"configured_arrival_binding",
       artifact::detail::wire::encode_digest(
           value.configured_arrival_binding)},
      {"proposal_law_digest",
       artifact::detail::wire::encode_digest(value.proposal_law_digest)},
      {"response_cutoff",
       artifact::detail::wire::encode_big_nat(value.response_cutoff)},
      {"ensemble_count",
       artifact::detail::wire::encode_big_nat(value.ensemble_count)},
      {"window_length",
       artifact::detail::wire::encode_big_nat(value.window_length)},
      {"identifications",
       encode_vector(value.identifications,
                     encode_finite_prefix_identification)}};
}

[[nodiscard]] Result<FinitePrefixRawResponseProductV1>
decode_finite_prefix_raw_product(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 10U> fields{
      "product_id", "provider", "request_digest", "deployed_target",
      "configured_arrival_binding", "proposal_law_digest",
      "response_cutoff", "ensemble_count", "window_length",
      "identifications"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) {
    return Result<FinitePrefixRawResponseProductV1>::failure(shape.error());
  }
  auto product = decode_product_id<ResponseProductStageV1::raw_response>(
      value.at("product_id"), path + "/product_id", access);
  auto provider = decode_provider(value.at("provider"), path + "/provider");
  auto request = artifact::detail::wire::decode_digest(
      value.at("request_digest"), path + "/request_digest");
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"),
                                          path + "/deployed_target");
  auto arrival = artifact::detail::wire::decode_digest(
      value.at("configured_arrival_binding"),
      path + "/configured_arrival_binding");
  auto proposal = artifact::detail::wire::decode_digest(
      value.at("proposal_law_digest"), path + "/proposal_law_digest");
  auto cutoff = artifact::detail::wire::decode_big_nat(
      value.at("response_cutoff"), path + "/response_cutoff");
  auto ensembles = artifact::detail::wire::decode_big_nat(
      value.at("ensemble_count"), path + "/ensemble_count");
  auto window = artifact::detail::wire::decode_big_nat(
      value.at("window_length"), path + "/window_length");
  auto identifications =
      decode_vector<FinitePrefixCoefficientIdentificationV1>(
          value.at("identifications"), path + "/identifications",
          decode_finite_prefix_identification);
  if (!product) return Result<FinitePrefixRawResponseProductV1>::failure(product.error());
  if (!provider) return Result<FinitePrefixRawResponseProductV1>::failure(provider.error());
  if (!request) return Result<FinitePrefixRawResponseProductV1>::failure(request.error());
  if (!target) return Result<FinitePrefixRawResponseProductV1>::failure(target.error());
  if (!arrival) return Result<FinitePrefixRawResponseProductV1>::failure(arrival.error());
  if (!proposal) return Result<FinitePrefixRawResponseProductV1>::failure(proposal.error());
  if (!cutoff) return Result<FinitePrefixRawResponseProductV1>::failure(cutoff.error());
  if (!ensembles) return Result<FinitePrefixRawResponseProductV1>::failure(ensembles.error());
  if (!window) return Result<FinitePrefixRawResponseProductV1>::failure(window.error());
  if (!identifications) return Result<FinitePrefixRawResponseProductV1>::failure(identifications.error());
  return Result<FinitePrefixRawResponseProductV1>::success({
      std::move(product).value(), std::move(provider).value(),
      std::move(request).value(), std::move(target).value(),
      std::move(arrival).value(), std::move(proposal).value(),
      std::move(cutoff).value(), std::move(ensembles).value(),
      std::move(window).value(), std::move(identifications).value()});
}

[[nodiscard]] OrderedJson encode_finite_prefix_raw_envelope(
    const FinitePrefixRawResponseEnvelopeV1& value) {
  return OrderedJson{
      {"envelope_id",
       artifact::detail::wire::encode_artifact_object_reference(
           value.envelope_id)},
      {"source_product", encode_product_id(value.source_product)},
      {"construction_law_digest",
       artifact::detail::wire::encode_digest(
           value.construction_law_digest)},
      {"response_cutoff",
       artifact::detail::wire::encode_big_nat(value.response_cutoff)},
      {"covered_coordinates",
       encode_vector(value.covered_coordinates,
                     encode_finite_prefix_coordinate)},
      {"lower", encode_scalar_array(value.lower)},
      {"upper", encode_scalar_array(value.upper)},
      {"concentration_radius",
       OrderedJson{
           {"lower", artifact::detail::wire::encode_scalar(
                         value.concentration_radius_lower)},
           {"upper", artifact::detail::wire::encode_scalar(
                         value.concentration_radius_upper)}}},
      {"floating_point_enclosure",
       artifact::detail::wire::encode_scalar(
           value.floating_point_enclosure)},
      {"certification_method", value.certification_method},
      {"coverage", std::string(enum_text(value.coverage))},
      {"population_conditioning_premise",
       std::string(enum_text(value.population_conditioning_premise))},
      {"frozen_evaluation_id",
       artifact::detail::wire::encode_typed_label(
           value.frozen_evaluation_id)},
      {"sample_size",
       artifact::detail::wire::encode_big_nat(value.sample_size)},
      {"scope", std::string(enum_text(value.scope))},
      {"family_evidence_envelope_ids",
       encode_vector(value.family_evidence_envelope_ids,
                     artifact::detail::wire::
                         encode_artifact_object_reference)}};
}

[[nodiscard]] Result<FinitePrefixRawResponseEnvelopeV1>
decode_finite_prefix_raw_envelope(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 16U> fields{
      "envelope_id", "source_product", "construction_law_digest",
      "response_cutoff", "covered_coordinates", "lower", "upper",
      "concentration_radius", "floating_point_enclosure",
      "certification_method", "coverage",
      "population_conditioning_premise", "frozen_evaluation_id",
      "sample_size", "scope", "family_evidence_envelope_ids"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) {
    return Result<FinitePrefixRawResponseEnvelopeV1>::failure(shape.error());
  }
  auto radius_shape = require_wire_fields(
      value.at("concentration_radius"),
      std::array<std::string_view, 2U>{"lower", "upper"},
      path + "/concentration_radius");
  if (!radius_shape) {
    return Result<FinitePrefixRawResponseEnvelopeV1>::failure(
        radius_shape.error());
  }
  constexpr std::array coverages{
      RawEnvelopeCoverageV1::deterministic,
      RawEnvelopeCoverageV1::marginal,
      RawEnvelopeCoverageV1::simultaneous};
  constexpr std::array premises{
      PopulationConditioningPremiseV1::unconditional,
      PopulationConditioningPremiseV1::conditional_on_population_positivity};
  constexpr std::array scopes{
      RawEnvelopeScopeV1::proposal_raw,
      RawEnvelopeScopeV1::optimizer_interval_raw,
      RawEnvelopeScopeV1::deterministic_quadrature_raw,
      RawEnvelopeScopeV1::physical_response_bound};
  auto id = artifact::detail::wire::decode_artifact_object_reference(
      value.at("envelope_id"), path + "/envelope_id");
  auto source = decode_product_id<ResponseProductStageV1::raw_response>(
      value.at("source_product"), path + "/source_product", access);
  auto law = artifact::detail::wire::decode_digest(
      value.at("construction_law_digest"),
      path + "/construction_law_digest");
  auto cutoff = artifact::detail::wire::decode_big_nat(
      value.at("response_cutoff"), path + "/response_cutoff");
  auto coordinates = decode_vector<FinitePrefixResponseCoordinateV1>(
      value.at("covered_coordinates"), path + "/covered_coordinates",
      decode_finite_prefix_coordinate);
  auto lower = decode_scalar_array(value.at("lower"), path + "/lower");
  auto upper = decode_scalar_array(value.at("upper"), path + "/upper");
  auto radius_lower = artifact::detail::wire::decode_scalar(
      value.at("concentration_radius").at("lower"),
      path + "/concentration_radius/lower");
  auto radius_upper = artifact::detail::wire::decode_scalar(
      value.at("concentration_radius").at("upper"),
      path + "/concentration_radius/upper");
  auto enclosure = artifact::detail::wire::decode_scalar(
      value.at("floating_point_enclosure"),
      path + "/floating_point_enclosure");
  auto method = required_string(value.at("certification_method"),
                                path + "/certification_method", true);
  auto coverage = decode_enum(
      value.at("coverage"), path + "/coverage",
      std::span<const RawEnvelopeCoverageV1>(coverages));
  auto premise = decode_enum(
      value.at("population_conditioning_premise"),
      path + "/population_conditioning_premise",
      std::span<const PopulationConditioningPremiseV1>(premises));
  auto evaluation = artifact::detail::wire::decode_typed_label(
      value.at("frozen_evaluation_id"), path + "/frozen_evaluation_id");
  auto sample = artifact::detail::wire::decode_big_nat(
      value.at("sample_size"), path + "/sample_size");
  auto scope = decode_enum(
      value.at("scope"), path + "/scope",
      std::span<const RawEnvelopeScopeV1>(scopes));
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(
      value.at("family_evidence_envelope_ids"),
      path + "/family_evidence_envelope_ids",
      artifact::detail::wire::decode_artifact_object_reference);
  if (!id) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(id.error());
  if (!source) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(source.error());
  if (!law) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(law.error());
  if (!cutoff) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(cutoff.error());
  if (!coordinates) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(coordinates.error());
  if (!lower) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(lower.error());
  if (!upper) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(upper.error());
  if (!radius_lower) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(radius_lower.error());
  if (!radius_upper) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(radius_upper.error());
  if (!enclosure) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(enclosure.error());
  if (!method) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(method.error());
  if (!coverage) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(coverage.error());
  if (!premise) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(premise.error());
  if (!evaluation) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(evaluation.error());
  if (!sample) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(sample.error());
  if (!scope) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(scope.error());
  if (!evidence) return Result<FinitePrefixRawResponseEnvelopeV1>::failure(evidence.error());
  return Result<FinitePrefixRawResponseEnvelopeV1>::success({
      std::move(id).value(), std::move(source).value(),
      std::move(law).value(), std::move(cutoff).value(),
      std::move(coordinates).value(), std::move(lower).value(),
      std::move(upper).value(), std::move(radius_lower).value(),
      std::move(radius_upper).value(), std::move(enclosure).value(),
      std::move(method).value(), std::move(coverage).value(),
      std::move(premise).value(), std::move(evaluation).value(),
      std::move(sample).value(), std::move(scope).value(),
      std::move(evidence).value()});
}

[[nodiscard]] OrderedJson encode_finite_prefix_constant_tail(
    const FinitePrefixConstantTailResponseV1& value) {
  return OrderedJson{
      {"payload_version", value.payload_version},
      {"response_row_id",
       artifact::detail::wire::encode_artifact_object_reference(
           value.response_row_id)},
      {"deployed_target", encode_strong_id(value.deployed_target)},
      {"configured_arrival_binding",
       artifact::detail::wire::encode_digest(
           value.configured_arrival_binding)},
      {"response_cutoff",
       artifact::detail::wire::encode_big_nat(value.response_cutoff)},
      {"raw_response", encode_finite_prefix_raw_product(value.raw_response)},
      {"deployed_response_product_id",
       encode_product_id(value.deployed_response_product_id)},
      {"raw_envelopes",
       encode_vector(value.raw_envelopes,
                     encode_finite_prefix_raw_envelope)}};
}

[[nodiscard]] Result<FinitePrefixConstantTailResponseV1>
decode_finite_prefix_constant_tail(
    const OrderedJson& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  const std::array<std::string_view, 8U> fields{
      "payload_version", "response_row_id", "deployed_target",
      "configured_arrival_binding", "response_cutoff", "raw_response",
      "deployed_response_product_id", "raw_envelopes"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) {
    return Result<FinitePrefixConstantTailResponseV1>::failure(shape.error());
  }
  auto version = required_version_one(value.at("payload_version"),
                                      path + "/payload_version",
                                      "finite-prefix constant-tail payload");
  auto row = artifact::detail::wire::decode_artifact_object_reference(
      value.at("response_row_id"), path + "/response_row_id");
  auto target = decode_strong_id<QueueId>(value.at("deployed_target"),
                                          path + "/deployed_target");
  auto arrival = artifact::detail::wire::decode_digest(
      value.at("configured_arrival_binding"),
      path + "/configured_arrival_binding");
  auto cutoff = artifact::detail::wire::decode_big_nat(
      value.at("response_cutoff"), path + "/response_cutoff");
  auto raw = decode_finite_prefix_raw_product(
      value.at("raw_response"), path + "/raw_response", access);
  auto deployed = decode_product_id<ResponseProductStageV1::raw_response>(
      value.at("deployed_response_product_id"),
      path + "/deployed_response_product_id", access);
  auto envelopes = decode_vector<FinitePrefixRawResponseEnvelopeV1>(
      value.at("raw_envelopes"), path + "/raw_envelopes",
      [&access](const OrderedJson& item, const std::string& item_path) {
        return decode_finite_prefix_raw_envelope(item, item_path, access);
      });
  if (!version) return Result<FinitePrefixConstantTailResponseV1>::failure(version.error());
  if (!row) return Result<FinitePrefixConstantTailResponseV1>::failure(row.error());
  if (!target) return Result<FinitePrefixConstantTailResponseV1>::failure(target.error());
  if (!arrival) return Result<FinitePrefixConstantTailResponseV1>::failure(arrival.error());
  if (!cutoff) return Result<FinitePrefixConstantTailResponseV1>::failure(cutoff.error());
  if (!raw) return Result<FinitePrefixConstantTailResponseV1>::failure(raw.error());
  if (!deployed) return Result<FinitePrefixConstantTailResponseV1>::failure(deployed.error());
  if (!envelopes) return Result<FinitePrefixConstantTailResponseV1>::failure(envelopes.error());
  return Result<FinitePrefixConstantTailResponseV1>::success({
      std::move(version).value(), std::move(row).value(),
      std::move(target).value(), std::move(arrival).value(),
      std::move(cutoff).value(), std::move(raw).value(),
      std::move(deployed).value(), std::move(envelopes).value()});
}

}  // namespace
}  // namespace mwperf

namespace mwperf {
namespace {

[[nodiscard]] OrderedJson encode_schedule(
    const CommonScheduleRealizationV1& value) {
  OrderedJson departures = OrderedJson::array();
  for (const auto departure : value.joint_target_departures) {
    departures.push_back(departure);
  }
  OrderedJson result{
      {"selected_full_schedule",
       encode_vector(value.selected_full_schedule,
                     [](const QueueId& id) { return encode_strong_id(id); })},
      {"selected_schedule_backlogs",
       encode_vector(value.selected_schedule_backlogs,
                     artifact::detail::wire::encode_big_nat)},
      {"current_target_backlogs",
       encode_vector(value.current_target_backlogs,
                     artifact::detail::wire::encode_big_nat)},
      {"retained_target_backlogs",
       encode_vector(value.retained_target_backlogs,
                     artifact::detail::wire::encode_big_nat)},
      {"joint_target_departures", std::move(departures)},
      {"structurally_witnessed_projection",
       value.structurally_witnessed_projection}};
  if (value.projection_witness.has_value()) {
    result["projection_witness"] =
        artifact::detail::wire::encode_artifact_object_reference(
            *value.projection_witness);
  }
  return result;
}

[[nodiscard]] Result<CommonScheduleRealizationV1> decode_schedule(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 6U> required{
          "selected_full_schedule", "selected_schedule_backlogs",
          "current_target_backlogs",
          "retained_target_backlogs",
          "joint_target_departures", "structurally_witnessed_projection",
      };
  const std::array<std::string_view, 1U> optional{"projection_witness"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<CommonScheduleRealizationV1>::failure(shape.error());
  auto selected = decode_vector<QueueId>(
      value.at("selected_full_schedule"), path + "/selected_full_schedule",
      decode_strong_id<QueueId>);
  auto selected_backlogs = decode_vector<BigNat>(
      value.at("selected_schedule_backlogs"),
      path + "/selected_schedule_backlogs",
      artifact::detail::wire::decode_big_nat);
  auto current = decode_vector<BigNat>(
      value.at("current_target_backlogs"),
      path + "/current_target_backlogs",
      artifact::detail::wire::decode_big_nat);
  auto backlog = decode_vector<BigNat>(
      value.at("retained_target_backlogs"),
      path + "/retained_target_backlogs",
      artifact::detail::wire::decode_big_nat);
  if (!value.at("joint_target_departures").is_array()) {
    return fail<CommonScheduleRealizationV1>(
        "artifact_wire_expected_array", "departures must be an array",
        path + "/joint_target_departures");
  }
  std::vector<std::uint8_t> departures;
  departures.reserve(value.at("joint_target_departures").size());
  for (std::size_t index = 0U;
       index < value.at("joint_target_departures").size(); ++index) {
    const auto& item = value.at("joint_target_departures").at(index);
    if (!item.is_number_unsigned() || item.get<std::uint64_t>() > 1U) {
      return fail<CommonScheduleRealizationV1>(
          "artifact_wire_departure_bit", "departure must be zero or one",
          path + "/joint_target_departures/" + std::to_string(index));
    }
    departures.push_back(static_cast<std::uint8_t>(item.get<std::uint64_t>()));
  }
  if (!value.at("structurally_witnessed_projection").is_boolean()) {
    return fail<CommonScheduleRealizationV1>(
        "artifact_wire_expected_boolean", "projection flag must be boolean",
        path + "/structurally_witnessed_projection");
  }
  auto witness = decode_optional_member<ArtifactObjectReferenceV1>(
      value, "projection_witness", path,
      artifact::detail::wire::decode_artifact_object_reference);
  if (!selected) return Result<CommonScheduleRealizationV1>::failure(selected.error());
  if (!selected_backlogs) return Result<CommonScheduleRealizationV1>::failure(selected_backlogs.error());
  if (!current) return Result<CommonScheduleRealizationV1>::failure(current.error());
  if (!backlog) return Result<CommonScheduleRealizationV1>::failure(backlog.error());
  if (!witness) return Result<CommonScheduleRealizationV1>::failure(witness.error());
  return Result<CommonScheduleRealizationV1>::success(
      CommonScheduleRealizationV1{
          std::move(selected).value(), std::move(selected_backlogs).value(),
          std::move(current).value(),
          std::move(backlog).value(),
          std::move(departures),
          value.at("structurally_witnessed_projection").get<bool>(),
          std::move(witness).value()});
}

[[nodiscard]] OrderedJson encode_finite_atom(const FiniteLawAtomV1& value) {
  OrderedJson result{
      {"successor_state_id",
       artifact::detail::wire::encode_typed_label(value.successor_state_id)},
      {"ordered_mark_ids",
       encode_vector(value.ordered_mark_ids,
                     artifact::detail::wire::encode_typed_label)},
      {"probability", artifact::detail::wire::encode_scalar(value.probability)}};
  if (value.common_schedule.has_value()) {
    result["common_schedule"] = encode_schedule(*value.common_schedule);
  }
  return result;
}

[[nodiscard]] Result<FiniteLawAtomV1> decode_finite_atom(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view, 3U> required{
      "successor_state_id", "ordered_mark_ids", "probability"};
  const std::array<std::string_view, 1U> optional{"common_schedule"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<FiniteLawAtomV1>::failure(shape.error());
  auto successor = artifact::detail::wire::decode_typed_label(
      value.at("successor_state_id"), path + "/successor_state_id");
  auto marks = decode_vector<TypedLabel>(
      value.at("ordered_mark_ids"), path + "/ordered_mark_ids",
      artifact::detail::wire::decode_typed_label);
  auto probability = artifact::detail::wire::decode_scalar(
      value.at("probability"), path + "/probability");
  auto schedule = decode_optional_member<CommonScheduleRealizationV1>(
      value, "common_schedule", path, decode_schedule);
  if (!successor) return Result<FiniteLawAtomV1>::failure(successor.error());
  if (!marks) return Result<FiniteLawAtomV1>::failure(marks.error());
  if (!probability) return Result<FiniteLawAtomV1>::failure(probability.error());
  if (!schedule) return Result<FiniteLawAtomV1>::failure(schedule.error());
  return Result<FiniteLawAtomV1>::success(FiniteLawAtomV1{
      std::move(successor).value(), std::move(marks).value(),
      std::move(probability).value(), std::move(schedule).value()});
}

[[nodiscard]] OrderedJson encode_finite_row(const FiniteLawRowV1& value) {
  return OrderedJson{
      {"row_id", artifact::detail::wire::encode_typed_label(value.row_id)},
      {"conditioning_state_id",
       artifact::detail::wire::encode_typed_label(value.conditioning_state_id)},
      {"conditioning_stage", std::string(enum_text(value.conditioning_stage))},
      {"atoms", encode_vector(value.atoms, encode_finite_atom)}};
}

[[nodiscard]] Result<FiniteLawRowV1> decode_finite_row(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(
      value, std::array<std::string_view, 4U>{"row_id", "conditioning_state_id",
                                              "conditioning_stage", "atoms"},
      path);
  if (!shape) return Result<FiniteLawRowV1>::failure(shape.error());
  constexpr std::array stages{
      FiniteRowConditioningStageV1::stationary_edge,
      FiniteRowConditioningStageV1::prearrival,
      FiniteRowConditioningStageV1::postarrival,
      FiniteRowConditioningStageV1::one_slot_current,
      FiniteRowConditioningStageV1::stopped_continuation,
      FiniteRowConditioningStageV1::residence_continuation,
      FiniteRowConditioningStageV1::common_schedule};
  auto row_id = artifact::detail::wire::decode_typed_label(
      value.at("row_id"), path + "/row_id");
  auto state = artifact::detail::wire::decode_typed_label(
      value.at("conditioning_state_id"), path + "/conditioning_state_id");
  auto stage = decode_enum(
      value.at("conditioning_stage"), path + "/conditioning_stage",
      std::span<const FiniteRowConditioningStageV1>(stages));
  auto atoms = decode_vector<FiniteLawAtomV1>(value.at("atoms"), path + "/atoms",
                                              decode_finite_atom);
  if (!row_id) return Result<FiniteLawRowV1>::failure(row_id.error());
  if (!state) return Result<FiniteLawRowV1>::failure(state.error());
  if (!stage) return Result<FiniteLawRowV1>::failure(stage.error());
  if (!atoms) return Result<FiniteLawRowV1>::failure(atoms.error());
  return Result<FiniteLawRowV1>::success(FiniteLawRowV1{
      std::move(row_id).value(), std::move(state).value(),
      std::move(stage).value(), std::move(atoms).value()});
}

[[nodiscard]] OrderedJson encode_word(const ExplicitOrderedWordV1& value) {
  return OrderedJson{
      {"entrance_state_id",
       artifact::detail::wire::encode_typed_label(value.entrance_state_id)},
      {"duration", artifact::detail::wire::encode_big_nat(value.duration)},
      {"ordered_mark_ids", encode_vector(value.ordered_mark_ids,
                                           artifact::detail::wire::encode_typed_label)},
      {"terminal_id", artifact::detail::wire::encode_typed_label(value.terminal_id)},
      {"successor_entry_id", artifact::detail::wire::encode_typed_label(value.successor_entry_id)},
      {"probability", artifact::detail::wire::encode_scalar(value.probability)}};
}

[[nodiscard]] Result<ExplicitOrderedWordV1> decode_word(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(value,
      std::array<std::string_view,6U>{"entrance_state_id","duration","ordered_mark_ids","terminal_id","successor_entry_id","probability"}, path);
  if (!shape) return Result<ExplicitOrderedWordV1>::failure(shape.error());
  auto entrance = artifact::detail::wire::decode_typed_label(value.at("entrance_state_id"), path + "/entrance_state_id");
  auto duration = artifact::detail::wire::decode_big_nat(value.at("duration"), path + "/duration");
  auto marks = decode_vector<TypedLabel>(value.at("ordered_mark_ids"), path + "/ordered_mark_ids", artifact::detail::wire::decode_typed_label);
  auto terminal = artifact::detail::wire::decode_typed_label(value.at("terminal_id"), path + "/terminal_id");
  auto successor = artifact::detail::wire::decode_typed_label(value.at("successor_entry_id"), path + "/successor_entry_id");
  auto probability = artifact::detail::wire::decode_scalar(value.at("probability"), path + "/probability");
  if (!entrance) return Result<ExplicitOrderedWordV1>::failure(entrance.error());
  if (!duration) return Result<ExplicitOrderedWordV1>::failure(duration.error());
  if (!marks) return Result<ExplicitOrderedWordV1>::failure(marks.error());
  if (!terminal) return Result<ExplicitOrderedWordV1>::failure(terminal.error());
  if (!successor) return Result<ExplicitOrderedWordV1>::failure(successor.error());
  if (!probability) return Result<ExplicitOrderedWordV1>::failure(probability.error());
  return Result<ExplicitOrderedWordV1>::success(ExplicitOrderedWordV1{
      std::move(entrance).value(), std::move(duration).value(),
      std::move(marks).value(), std::move(terminal).value(),
      std::move(successor).value(), std::move(probability).value()});
}

[[nodiscard]] OrderedJson encode_predictive(
    const FinitePredictiveStoppingTablesV1& value) {
  return OrderedJson{
      {"continuation_rows", encode_vector(value.continuation_rows, encode_finite_row)},
      {"stop_or_event_rows", encode_vector(value.stop_or_event_rows, encode_finite_row)},
      {"terminal_or_exit_rows", encode_vector(value.terminal_or_exit_rows, encode_finite_row)}};
}

[[nodiscard]] Result<FinitePredictiveStoppingTablesV1> decode_predictive(
    const OrderedJson& value, const std::string& path) {
  auto shape = require_wire_fields(value,
      std::array<std::string_view,3U>{"continuation_rows","stop_or_event_rows","terminal_or_exit_rows"}, path);
  if (!shape) return Result<FinitePredictiveStoppingTablesV1>::failure(shape.error());
  auto continuation = decode_vector<FiniteLawRowV1>(value.at("continuation_rows"), path + "/continuation_rows", decode_finite_row);
  auto event = decode_vector<FiniteLawRowV1>(value.at("stop_or_event_rows"), path + "/stop_or_event_rows", decode_finite_row);
  auto terminal = decode_vector<FiniteLawRowV1>(value.at("terminal_or_exit_rows"), path + "/terminal_or_exit_rows", decode_finite_row);
  if (!continuation) return Result<FinitePredictiveStoppingTablesV1>::failure(continuation.error());
  if (!event) return Result<FinitePredictiveStoppingTablesV1>::failure(event.error());
  if (!terminal) return Result<FinitePredictiveStoppingTablesV1>::failure(terminal.error());
  return Result<FinitePredictiveStoppingTablesV1>::success(
      FinitePredictiveStoppingTablesV1{std::move(continuation).value(),
                                      std::move(event).value(),
                                      std::move(terminal).value()});
}

[[nodiscard]] OrderedJson encode_stopping_representation(
    const std::variant<std::vector<ExplicitOrderedWordV1>,
                       FinitePredictiveStoppingTablesV1>& value) {
  if (const auto* words = std::get_if<std::vector<ExplicitOrderedWordV1>>(&value)) {
    return OrderedJson{{"kind", "explicit_words"},
                       {"words", encode_vector(*words, encode_word)}};
  }
  return OrderedJson{{"kind", "finite_predictive"},
                     {"tables", encode_predictive(
                                    std::get<FinitePredictiveStoppingTablesV1>(value))}};
}

[[nodiscard]] Result<std::variant<std::vector<ExplicitOrderedWordV1>,
                                  FinitePredictiveStoppingTablesV1>>
decode_stopping_representation(const OrderedJson& value,
                               const std::string& path) {
  if (!value.is_object() || !value.contains("kind") ||
      !value.at("kind").is_string()) {
    return fail<std::variant<std::vector<ExplicitOrderedWordV1>,
                             FinitePredictiveStoppingTablesV1>>(
        "artifact_wire_stopping_representation",
        "invalid stopping representation", path);
  }
  const std::string kind = value.at("kind").get<std::string>();
  if (kind == "explicit_words") {
    auto shape = require_wire_fields(value, std::array<std::string_view,2U>{"kind","words"}, path);
    if (!shape) return Result<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>::failure(shape.error());
    auto words = decode_vector<ExplicitOrderedWordV1>(value.at("words"), path + "/words", decode_word);
    if (!words) return Result<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>::failure(words.error());
    return Result<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>::success(std::move(words).value());
  }
  if (kind == "finite_predictive") {
    auto shape = require_wire_fields(value, std::array<std::string_view,2U>{"kind","tables"}, path);
    if (!shape) return Result<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>::failure(shape.error());
    auto tables = decode_predictive(value.at("tables"), path + "/tables");
    if (!tables) return Result<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>::failure(tables.error());
    return Result<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>::success(std::move(tables).value());
  }
  return fail<std::variant<std::vector<ExplicitOrderedWordV1>, FinitePredictiveStoppingTablesV1>>(
      "artifact_wire_stopping_representation",
      "unknown stopping representation", path + "/kind");
}

}  // namespace
}  // namespace mwperf

namespace mwperf {
namespace {

[[nodiscard]] Result<FiniteTableStorageV1> decode_storage(
    const OrderedJson& value, const std::string& path) {
  constexpr std::array domain{FiniteTableStorageV1::dense,
                              FiniteTableStorageV1::sparse};
  return decode_enum(value, path,
                     std::span<const FiniteTableStorageV1>(domain));
}

[[nodiscard]] OrderedJson encode_reveal_stages(
    const std::vector<MetricRevealStageV1>& values) {
  return encode_vector(values, [](const auto value) {
    return OrderedJson(std::string(enum_text(value)));
  });
}

[[nodiscard]] Result<std::vector<MetricRevealStageV1>> decode_reveal_stages(
    const OrderedJson& value, const std::string& path) {
  constexpr std::array domain{
      MetricRevealStageV1::predecision, MetricRevealStageV1::decision,
      MetricRevealStageV1::arrival, MetricRevealStageV1::postarrival,
      MetricRevealStageV1::completed_edge,
      MetricRevealStageV1::entrance_label};
  return decode_vector<MetricRevealStageV1>(
      value, path, [&domain](const OrderedJson& item,
                            const std::string& item_path) {
        return decode_enum(item, item_path,
                           std::span<const MetricRevealStageV1>(domain));
      });
}

[[nodiscard]] OrderedJson encode_stationary_table(
    const StationaryMarkedEdgeTableV1& value) {
  return OrderedJson{
      {"table_tag", "stationary_marked_edge"},
      {"table_schema_version", value.table_schema_version},
      {"law_id", artifact::detail::wire::encode_artifact_object_reference(value.law_id)},
      {"storage", std::string(enum_text(value.storage))},
      {"joint_edge_rows", encode_vector(value.joint_edge_rows, encode_finite_row)},
      {"target_backlog_codec", encode_codec(value.target_backlog_codec)},
      {"exact_input_phase_codec", encode_codec(value.exact_input_phase_codec)},
      {"actual_departure_mark_codec", encode_codec(value.actual_departure_mark_codec)},
      {"retained_mark_codec", encode_codec(value.retained_mark_codec)},
      {"conditioning_binding", artifact::detail::wire::encode_digest(value.conditioning_binding)}};
}

[[nodiscard]] Result<StationaryMarkedEdgeTableV1> decode_stationary_table(
    const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,10U> fields{"table_tag","table_schema_version","law_id","storage","joint_edge_rows","target_backlog_codec","exact_input_phase_codec","actual_departure_mark_codec","retained_mark_codec","conditioning_binding"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<StationaryMarkedEdgeTableV1>::failure(shape.error());
  auto tag = required_string(value.at("table_tag"), path + "/table_tag", true);
  auto version = required_version_one(value.at("table_schema_version"), path + "/table_schema_version", "finite-law table");
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("law_id"), path + "/law_id");
  auto storage = decode_storage(value.at("storage"), path + "/storage");
  auto rows = decode_vector<FiniteLawRowV1>(value.at("joint_edge_rows"), path + "/joint_edge_rows", decode_finite_row);
  auto backlog = decode_codec(value.at("target_backlog_codec"), path + "/target_backlog_codec");
  auto phase = decode_codec(value.at("exact_input_phase_codec"), path + "/exact_input_phase_codec");
  auto departure = decode_codec(value.at("actual_departure_mark_codec"), path + "/actual_departure_mark_codec");
  auto retained = decode_codec(value.at("retained_mark_codec"), path + "/retained_mark_codec");
  auto binding = artifact::detail::wire::decode_digest(value.at("conditioning_binding"), path + "/conditioning_binding");
  if (!tag || tag.value() != "stationary_marked_edge") return fail<StationaryMarkedEdgeTableV1>("artifact_wire_table_tag", "wrong finite-table subtag", path + "/table_tag");
  if (!version) return Result<StationaryMarkedEdgeTableV1>::failure(version.error());
  if (!id) return Result<StationaryMarkedEdgeTableV1>::failure(id.error());
  if (!storage) return Result<StationaryMarkedEdgeTableV1>::failure(storage.error());
  if (!rows) return Result<StationaryMarkedEdgeTableV1>::failure(rows.error());
  if (!backlog) return Result<StationaryMarkedEdgeTableV1>::failure(backlog.error());
  if (!phase) return Result<StationaryMarkedEdgeTableV1>::failure(phase.error());
  if (!departure) return Result<StationaryMarkedEdgeTableV1>::failure(departure.error());
  if (!retained) return Result<StationaryMarkedEdgeTableV1>::failure(retained.error());
  if (!binding) return Result<StationaryMarkedEdgeTableV1>::failure(binding.error());
  return Result<StationaryMarkedEdgeTableV1>::success(StationaryMarkedEdgeTableV1{
      std::move(version).value(), std::move(id).value(), std::move(storage).value(),
      std::move(rows).value(), std::move(backlog).value(), std::move(phase).value(),
      std::move(departure).value(), std::move(retained).value(), std::move(binding).value()});
}

[[nodiscard]] OrderedJson encode_staged_table(const StagedOpportunityFluxTableV1& value) {
  return OrderedJson{
      {"table_tag", "staged_opportunity_flux"},
      {"table_schema_version", value.table_schema_version},
      {"law_id", artifact::detail::wire::encode_artifact_object_reference(value.law_id)},
      {"storage", std::string(enum_text(value.storage))},
      {"prearrival_state_domain", encode_vector(value.prearrival_state_domain, artifact::detail::wire::encode_typed_label)},
      {"postarrival_state_domain", encode_vector(value.postarrival_state_domain, artifact::detail::wire::encode_typed_label)},
      {"opportunity_rows", encode_vector(value.opportunity_rows, encode_finite_row)},
      {"successor_mark_rows", encode_vector(value.successor_mark_rows, encode_finite_row)},
      {"configured_arrival_reference", artifact::detail::wire::encode_digest(value.configured_arrival_reference)},
      {"configured_innovation_codec", encode_codec(value.configured_innovation_codec)},
      {"deterministic_update_descriptor", artifact::detail::wire::encode_artifact_object_reference(value.deterministic_update_descriptor)},
      {"retained_coordinate_descriptor", artifact::detail::wire::encode_artifact_object_reference(value.retained_coordinate_descriptor)},
      {"reveal_order", encode_reveal_stages(value.reveal_order)}};
}

[[nodiscard]] Result<StagedOpportunityFluxTableV1> decode_staged_table(const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,13U> fields{"table_tag","table_schema_version","law_id","storage","prearrival_state_domain","postarrival_state_domain","opportunity_rows","successor_mark_rows","configured_arrival_reference","configured_innovation_codec","deterministic_update_descriptor","retained_coordinate_descriptor","reveal_order"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<StagedOpportunityFluxTableV1>::failure(shape.error());
  auto tag = required_string(value.at("table_tag"), path + "/table_tag", true);
  auto version = required_version_one(value.at("table_schema_version"), path + "/table_schema_version", "finite-law table");
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("law_id"), path + "/law_id");
  auto storage = decode_storage(value.at("storage"), path + "/storage");
  auto pre = decode_vector<TypedLabel>(value.at("prearrival_state_domain"), path + "/prearrival_state_domain", artifact::detail::wire::decode_typed_label);
  auto post = decode_vector<TypedLabel>(value.at("postarrival_state_domain"), path + "/postarrival_state_domain", artifact::detail::wire::decode_typed_label);
  auto opportunity = decode_vector<FiniteLawRowV1>(value.at("opportunity_rows"), path + "/opportunity_rows", decode_finite_row);
  auto successor = decode_vector<FiniteLawRowV1>(value.at("successor_mark_rows"), path + "/successor_mark_rows", decode_finite_row);
  auto arrival = artifact::detail::wire::decode_digest(value.at("configured_arrival_reference"), path + "/configured_arrival_reference");
  auto innovation = decode_codec(value.at("configured_innovation_codec"), path + "/configured_innovation_codec");
  auto update = artifact::detail::wire::decode_artifact_object_reference(value.at("deterministic_update_descriptor"), path + "/deterministic_update_descriptor");
  auto retained = artifact::detail::wire::decode_artifact_object_reference(value.at("retained_coordinate_descriptor"), path + "/retained_coordinate_descriptor");
  auto reveal = decode_reveal_stages(value.at("reveal_order"), path + "/reveal_order");
  if (!tag || tag.value() != "staged_opportunity_flux") return fail<StagedOpportunityFluxTableV1>("artifact_wire_table_tag", "wrong finite-table subtag", path + "/table_tag");
  if (!version) return Result<StagedOpportunityFluxTableV1>::failure(version.error());
  if (!id) return Result<StagedOpportunityFluxTableV1>::failure(id.error());
  if (!storage) return Result<StagedOpportunityFluxTableV1>::failure(storage.error());
  if (!pre) return Result<StagedOpportunityFluxTableV1>::failure(pre.error());
  if (!post) return Result<StagedOpportunityFluxTableV1>::failure(post.error());
  if (!opportunity) return Result<StagedOpportunityFluxTableV1>::failure(opportunity.error());
  if (!successor) return Result<StagedOpportunityFluxTableV1>::failure(successor.error());
  if (!arrival) return Result<StagedOpportunityFluxTableV1>::failure(arrival.error());
  if (!innovation) return Result<StagedOpportunityFluxTableV1>::failure(innovation.error());
  if (!update) return Result<StagedOpportunityFluxTableV1>::failure(update.error());
  if (!retained) return Result<StagedOpportunityFluxTableV1>::failure(retained.error());
  if (!reveal) return Result<StagedOpportunityFluxTableV1>::failure(reveal.error());
  return Result<StagedOpportunityFluxTableV1>::success(StagedOpportunityFluxTableV1{
      std::move(version).value(), std::move(id).value(), std::move(storage).value(),
      std::move(pre).value(), std::move(post).value(), std::move(opportunity).value(),
      std::move(successor).value(), std::move(arrival).value(),
      std::move(innovation).value(), std::move(update).value(),
      std::move(retained).value(),
      std::move(reveal).value()});
}

[[nodiscard]] OrderedJson encode_temporal_table(const TemporalContinuationTableV1& value) {
  OrderedJson result{
      {"table_tag", "temporal_one_slot_continuation"},
      {"table_schema_version", value.table_schema_version},
      {"law_id", artifact::detail::wire::encode_artifact_object_reference(value.law_id)},
      {"storage", std::string(enum_text(value.storage))},
      {"continuation_rows", encode_vector(value.continuation_rows, encode_finite_row)},
      {"causal_reveal_order", encode_reveal_stages(value.causal_reveal_order)},
      {"arrival_phase_codec", encode_codec(value.arrival_phase_codec)}};
  if (value.controller_coordinate_codec.has_value()) {
    result["controller_coordinate_codec"] =
        encode_codec(*value.controller_coordinate_codec);
  }
  return result;
}

[[nodiscard]] Result<TemporalContinuationTableV1> decode_temporal_table(const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,7U> required{"table_tag","table_schema_version","law_id","storage","continuation_rows","causal_reveal_order","arrival_phase_codec"};
  const std::array<std::string_view,1U> optional{"controller_coordinate_codec"};
  auto shape = require_wire_fields(value, required, optional, path);
  if (!shape) return Result<TemporalContinuationTableV1>::failure(shape.error());
  auto tag = required_string(value.at("table_tag"), path + "/table_tag", true);
  auto version = required_version_one(value.at("table_schema_version"), path + "/table_schema_version", "finite-law table");
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("law_id"), path + "/law_id");
  auto storage = decode_storage(value.at("storage"), path + "/storage");
  auto rows = decode_vector<FiniteLawRowV1>(value.at("continuation_rows"), path + "/continuation_rows", decode_finite_row);
  auto reveal = decode_reveal_stages(value.at("causal_reveal_order"), path + "/causal_reveal_order");
  auto phase = decode_codec(value.at("arrival_phase_codec"), path + "/arrival_phase_codec");
  auto controller = decode_optional_member<CodecIdentityV1>(value, "controller_coordinate_codec", path, decode_codec);
  if (!tag || tag.value() != "temporal_one_slot_continuation") return fail<TemporalContinuationTableV1>("artifact_wire_table_tag", "wrong finite-table subtag", path + "/table_tag");
  if (!version) return Result<TemporalContinuationTableV1>::failure(version.error());
  if (!id) return Result<TemporalContinuationTableV1>::failure(id.error());
  if (!storage) return Result<TemporalContinuationTableV1>::failure(storage.error());
  if (!rows) return Result<TemporalContinuationTableV1>::failure(rows.error());
  if (!reveal) return Result<TemporalContinuationTableV1>::failure(reveal.error());
  if (!phase) return Result<TemporalContinuationTableV1>::failure(phase.error());
  if (!controller) return Result<TemporalContinuationTableV1>::failure(controller.error());
  return Result<TemporalContinuationTableV1>::success(TemporalContinuationTableV1{
      std::move(version).value(), std::move(id).value(), std::move(storage).value(),
      std::move(rows).value(), std::move(reveal).value(), std::move(phase).value(),
      std::move(controller).value()});
}

[[nodiscard]] OrderedJson encode_stopped_table(const StoppedPathTableV1& value) {
  return OrderedJson{
      {"table_tag", "stopped_path"}, {"table_schema_version", value.table_schema_version},
      {"law_id", artifact::detail::wire::encode_artifact_object_reference(value.law_id)},
      {"stop_rule_id", value.stop_rule_id},
      {"entrance_state_domain", encode_vector(value.entrance_state_domain, artifact::detail::wire::encode_typed_label)},
      {"stopped_state_domain", encode_vector(value.stopped_state_domain, artifact::detail::wire::encode_typed_label)},
      {"stopped_mark_domain", encode_vector(value.stopped_mark_domain, artifact::detail::wire::encode_typed_label)},
      {"accepted_defective_hitting_law", value.accepted_defective_hitting_law},
      {"representation", encode_stopping_representation(value.representation)},
      {"nonhit_or_nontermination_probability", artifact::detail::wire::encode_scalar(value.nonhit_or_nontermination_probability)},
      {"completion_absorption_tail_evidence", encode_vector(value.completion_absorption_tail_evidence, artifact::detail::wire::encode_artifact_object_reference)}};
}

[[nodiscard]] Result<StoppedPathTableV1> decode_stopped_table(const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,11U> fields{"table_tag","table_schema_version","law_id","stop_rule_id","entrance_state_domain","stopped_state_domain","stopped_mark_domain","accepted_defective_hitting_law","representation","nonhit_or_nontermination_probability","completion_absorption_tail_evidence"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<StoppedPathTableV1>::failure(shape.error());
  auto tag = required_string(value.at("table_tag"), path + "/table_tag", true);
  auto version = required_version_one(value.at("table_schema_version"), path + "/table_schema_version", "finite-law table");
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("law_id"), path + "/law_id");
  auto rule = required_string(value.at("stop_rule_id"), path + "/stop_rule_id", true);
  auto entrance = decode_vector<TypedLabel>(value.at("entrance_state_domain"), path + "/entrance_state_domain", artifact::detail::wire::decode_typed_label);
  auto states = decode_vector<TypedLabel>(value.at("stopped_state_domain"), path + "/stopped_state_domain", artifact::detail::wire::decode_typed_label);
  auto marks = decode_vector<TypedLabel>(value.at("stopped_mark_domain"), path + "/stopped_mark_domain", artifact::detail::wire::decode_typed_label);
  if (!value.at("accepted_defective_hitting_law").is_boolean()) return fail<StoppedPathTableV1>("artifact_wire_expected_boolean", "defective-law flag must be boolean", path + "/accepted_defective_hitting_law");
  auto representation = decode_stopping_representation(value.at("representation"), path + "/representation");
  auto nonhit = artifact::detail::wire::decode_scalar(value.at("nonhit_or_nontermination_probability"), path + "/nonhit_or_nontermination_probability");
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(value.at("completion_absorption_tail_evidence"), path + "/completion_absorption_tail_evidence", artifact::detail::wire::decode_artifact_object_reference);
  if (!tag || tag.value() != "stopped_path") return fail<StoppedPathTableV1>("artifact_wire_table_tag", "wrong finite-table subtag", path + "/table_tag");
  if (!version) return Result<StoppedPathTableV1>::failure(version.error());
  if (!id) return Result<StoppedPathTableV1>::failure(id.error());
  if (!rule) return Result<StoppedPathTableV1>::failure(rule.error());
  if (!entrance) return Result<StoppedPathTableV1>::failure(entrance.error());
  if (!states) return Result<StoppedPathTableV1>::failure(states.error());
  if (!marks) return Result<StoppedPathTableV1>::failure(marks.error());
  if (!representation) return Result<StoppedPathTableV1>::failure(representation.error());
  if (!nonhit) return Result<StoppedPathTableV1>::failure(nonhit.error());
  if (!evidence) return Result<StoppedPathTableV1>::failure(evidence.error());
  return Result<StoppedPathTableV1>::success(StoppedPathTableV1{
      std::move(version).value(), std::move(id).value(), std::move(rule).value(),
      std::move(entrance).value(), std::move(states).value(), std::move(marks).value(),
      value.at("accepted_defective_hitting_law").get<bool>(),
      std::move(representation).value(), std::move(nonhit).value(),
      std::move(evidence).value()});
}

[[nodiscard]] OrderedJson encode_residence_table(const RomrResidenceWordTableV1& value) {
  return OrderedJson{
      {"table_tag", "romr_residence_word"}, {"table_schema_version", value.table_schema_version},
      {"law_id", artifact::detail::wire::encode_artifact_object_reference(value.law_id)},
      {"event_rule_id", value.event_rule_id},
      {"entrance_state_domain", encode_vector(value.entrance_state_domain, artifact::detail::wire::encode_typed_label)},
      {"residence_state_domain", encode_vector(value.residence_state_domain, artifact::detail::wire::encode_typed_label)},
      {"residence_mark_domain", encode_vector(value.residence_mark_domain, artifact::detail::wire::encode_typed_label)},
      {"representation", encode_stopping_representation(value.representation)},
      {"nontermination_probability", artifact::detail::wire::encode_scalar(value.nontermination_probability)},
      {"complete_mass_termination_evidence", encode_vector(value.complete_mass_termination_evidence, artifact::detail::wire::encode_artifact_object_reference)}};
}

[[nodiscard]] Result<RomrResidenceWordTableV1> decode_residence_table(const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,10U> fields{"table_tag","table_schema_version","law_id","event_rule_id","entrance_state_domain","residence_state_domain","residence_mark_domain","representation","nontermination_probability","complete_mass_termination_evidence"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<RomrResidenceWordTableV1>::failure(shape.error());
  auto tag = required_string(value.at("table_tag"), path + "/table_tag", true);
  auto version = required_version_one(value.at("table_schema_version"), path + "/table_schema_version", "finite-law table");
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("law_id"), path + "/law_id");
  auto rule = required_string(value.at("event_rule_id"), path + "/event_rule_id", true);
  auto entrance = decode_vector<TypedLabel>(value.at("entrance_state_domain"), path + "/entrance_state_domain", artifact::detail::wire::decode_typed_label);
  auto states = decode_vector<TypedLabel>(value.at("residence_state_domain"), path + "/residence_state_domain", artifact::detail::wire::decode_typed_label);
  auto marks = decode_vector<TypedLabel>(value.at("residence_mark_domain"), path + "/residence_mark_domain", artifact::detail::wire::decode_typed_label);
  auto representation = decode_stopping_representation(value.at("representation"), path + "/representation");
  auto nontermination = artifact::detail::wire::decode_scalar(value.at("nontermination_probability"), path + "/nontermination_probability");
  auto evidence = decode_vector<ArtifactObjectReferenceV1>(value.at("complete_mass_termination_evidence"), path + "/complete_mass_termination_evidence", artifact::detail::wire::decode_artifact_object_reference);
  if (!tag || tag.value() != "romr_residence_word") return fail<RomrResidenceWordTableV1>("artifact_wire_table_tag", "wrong finite-table subtag", path + "/table_tag");
  if (!version) return Result<RomrResidenceWordTableV1>::failure(version.error());
  if (!id) return Result<RomrResidenceWordTableV1>::failure(id.error());
  if (!rule) return Result<RomrResidenceWordTableV1>::failure(rule.error());
  if (!entrance) return Result<RomrResidenceWordTableV1>::failure(entrance.error());
  if (!states) return Result<RomrResidenceWordTableV1>::failure(states.error());
  if (!marks) return Result<RomrResidenceWordTableV1>::failure(marks.error());
  if (!representation) return Result<RomrResidenceWordTableV1>::failure(representation.error());
  if (!nontermination) return Result<RomrResidenceWordTableV1>::failure(nontermination.error());
  if (!evidence) return Result<RomrResidenceWordTableV1>::failure(evidence.error());
  return Result<RomrResidenceWordTableV1>::success(RomrResidenceWordTableV1{
      std::move(version).value(), std::move(id).value(), std::move(rule).value(),
      std::move(entrance).value(), std::move(states).value(), std::move(marks).value(),
      std::move(representation).value(), std::move(nontermination).value(),
      std::move(evidence).value()});
}

[[nodiscard]] OrderedJson encode_coupled_table(const CoupledCommonScheduleTableV1& value) {
  return OrderedJson{
      {"table_tag", "coupled_common_schedule"}, {"table_schema_version", value.table_schema_version},
      {"law_id", artifact::detail::wire::encode_artifact_object_reference(value.law_id)},
      {"storage", std::string(enum_text(value.storage))},
      {"common_joint_rows", encode_vector(value.common_joint_rows, encode_finite_row)},
      {"constraint_geometry_digest", artifact::detail::wire::encode_digest(value.constraint_geometry_digest)},
      {"tie_phase_arrival_binding", artifact::detail::wire::encode_digest(value.tie_phase_arrival_binding)}};
}

[[nodiscard]] Result<CoupledCommonScheduleTableV1> decode_coupled_table(const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,7U> fields{"table_tag","table_schema_version","law_id","storage","common_joint_rows","constraint_geometry_digest","tie_phase_arrival_binding"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<CoupledCommonScheduleTableV1>::failure(shape.error());
  auto tag = required_string(value.at("table_tag"), path + "/table_tag", true);
  auto version = required_version_one(value.at("table_schema_version"), path + "/table_schema_version", "finite-law table");
  auto id = artifact::detail::wire::decode_artifact_object_reference(value.at("law_id"), path + "/law_id");
  auto storage = decode_storage(value.at("storage"), path + "/storage");
  auto rows = decode_vector<FiniteLawRowV1>(value.at("common_joint_rows"), path + "/common_joint_rows", decode_finite_row);
  auto geometry = artifact::detail::wire::decode_digest(value.at("constraint_geometry_digest"), path + "/constraint_geometry_digest");
  auto binding = artifact::detail::wire::decode_digest(value.at("tie_phase_arrival_binding"), path + "/tie_phase_arrival_binding");
  if (!tag || tag.value() != "coupled_common_schedule") return fail<CoupledCommonScheduleTableV1>("artifact_wire_table_tag", "wrong finite-table subtag", path + "/table_tag");
  if (!version) return Result<CoupledCommonScheduleTableV1>::failure(version.error());
  if (!id) return Result<CoupledCommonScheduleTableV1>::failure(id.error());
  if (!storage) return Result<CoupledCommonScheduleTableV1>::failure(storage.error());
  if (!rows) return Result<CoupledCommonScheduleTableV1>::failure(rows.error());
  if (!geometry) return Result<CoupledCommonScheduleTableV1>::failure(geometry.error());
  if (!binding) return Result<CoupledCommonScheduleTableV1>::failure(binding.error());
  return Result<CoupledCommonScheduleTableV1>::success(CoupledCommonScheduleTableV1{
      std::move(version).value(), std::move(id).value(), std::move(storage).value(),
      std::move(rows).value(), std::move(geometry).value(), std::move(binding).value()});
}

[[nodiscard]] OrderedJson encode_table(const FiniteLawTableAlternativeV1& value) {
  return std::visit([](const auto& table) -> OrderedJson {
    using T = std::decay_t<decltype(table)>;
    if constexpr (std::same_as<T, StationaryMarkedEdgeTableV1>) return encode_stationary_table(table);
    else if constexpr (std::same_as<T, StagedOpportunityFluxTableV1>) return encode_staged_table(table);
    else if constexpr (std::same_as<T, TemporalContinuationTableV1>) return encode_temporal_table(table);
    else if constexpr (std::same_as<T, StoppedPathTableV1>) return encode_stopped_table(table);
    else if constexpr (std::same_as<T, RomrResidenceWordTableV1>) return encode_residence_table(table);
    else return encode_coupled_table(table);
  }, value);
}

[[nodiscard]] Result<FiniteLawTableAlternativeV1> decode_table(const OrderedJson& value, const std::string& path) {
  if (!value.is_object() || !value.contains("table_tag") || !value.at("table_tag").is_string()) {
    return fail<FiniteLawTableAlternativeV1>("artifact_wire_table_tag", "finite-law table requires a closed subtag", path);
  }
  const std::string tag = value.at("table_tag").get<std::string>();
#define MWPERF_DECODE_TABLE(TAG, TYPE, FUNCTION)                           \
  if (tag == TAG) {                                                       \
    auto decoded = FUNCTION(value, path);                                 \
    if (!decoded) return Result<FiniteLawTableAlternativeV1>::failure(decoded.error()); \
    return Result<FiniteLawTableAlternativeV1>::success(std::move(decoded).value()); \
  }
  MWPERF_DECODE_TABLE("stationary_marked_edge", StationaryMarkedEdgeTableV1, decode_stationary_table)
  MWPERF_DECODE_TABLE("staged_opportunity_flux", StagedOpportunityFluxTableV1, decode_staged_table)
  MWPERF_DECODE_TABLE("temporal_one_slot_continuation", TemporalContinuationTableV1, decode_temporal_table)
  MWPERF_DECODE_TABLE("stopped_path", StoppedPathTableV1, decode_stopped_table)
  MWPERF_DECODE_TABLE("romr_residence_word", RomrResidenceWordTableV1, decode_residence_table)
  MWPERF_DECODE_TABLE("coupled_common_schedule", CoupledCommonScheduleTableV1, decode_coupled_table)
#undef MWPERF_DECODE_TABLE
  return fail<FiniteLawTableAlternativeV1>("artifact_wire_table_tag", "unknown finite-law table subtag", path + "/table_tag");
}

[[nodiscard]] OrderedJson encode_finite_tables(const FiniteLawTablesV1& value) {
  return OrderedJson{
      {"payload_version", value.payload_version},
      {"ordered_deployed_targets", encode_vector(value.ordered_deployed_targets, [](const QueueId& id) { return encode_strong_id(id); })},
      {"semantic", std::string(enum_text(value.semantic))},
      {"runtime_access", std::string(enum_text(value.runtime_access))},
      {"configured_arrival_binding", artifact::detail::wire::encode_digest(value.configured_arrival_binding)},
      {"selection_binding", artifact::detail::wire::encode_digest(value.selection_binding)},
      {"state_dictionary", encode_vector(value.state_dictionary, encode_dictionary_entry)},
      {"mark_dictionary", encode_vector(value.mark_dictionary, encode_dictionary_entry)},
      {"table", encode_table(value.table)}};
}

[[nodiscard]] Result<FiniteLawTablesV1> decode_finite_tables(const OrderedJson& value, const std::string& path) {
  const std::array<std::string_view,9U> fields{"payload_version","ordered_deployed_targets","semantic","runtime_access","configured_arrival_binding","selection_binding","state_dictionary","mark_dictionary","table"};
  auto shape = require_wire_fields(value, fields, path);
  if (!shape) return Result<FiniteLawTablesV1>::failure(shape.error());
  constexpr std::array semantics{SemanticTagV1::scalar_backlog_response, SemanticTagV1::stationary_marked_edge, SemanticTagV1::staged_opportunity_flux_law, SemanticTagV1::temporal_one_slot_continuation, SemanticTagV1::romr_residence_word_law, SemanticTagV1::stopped_path_law, SemanticTagV1::coupled_target_schedule_law, SemanticTagV1::direct_metric_decoder, SemanticTagV1::response_envelope_law};
  constexpr std::array accesses{RuntimeAccessTagV1::finite_enumerated_row, RuntimeAccessTagV1::sparse_row, RuntimeAccessTagV1::normalized_conditional_sampler, RuntimeAccessTagV1::analytic_transform, RuntimeAccessTagV1::finite_parameter_analytic_family, RuntimeAccessTagV1::procedural_residence_generator, RuntimeAccessTagV1::direct_metric_decoder};
  auto version = required_u32(value.at("payload_version"), path + "/payload_version");
  auto targets = decode_vector<QueueId>(value.at("ordered_deployed_targets"), path + "/ordered_deployed_targets", decode_strong_id<QueueId>);
  auto semantic = decode_enum(value.at("semantic"), path + "/semantic", std::span<const SemanticTagV1>(semantics));
  auto access = decode_enum(value.at("runtime_access"), path + "/runtime_access", std::span<const RuntimeAccessTagV1>(accesses));
  auto arrival = artifact::detail::wire::decode_digest(value.at("configured_arrival_binding"), path + "/configured_arrival_binding");
  auto selection = artifact::detail::wire::decode_digest(value.at("selection_binding"), path + "/selection_binding");
  auto states = decode_vector<PortableFiniteDictionaryEntryV1>(value.at("state_dictionary"), path + "/state_dictionary", decode_dictionary_entry);
  auto marks = decode_vector<PortableFiniteDictionaryEntryV1>(value.at("mark_dictionary"), path + "/mark_dictionary", decode_dictionary_entry);
  auto table = decode_table(value.at("table"), path + "/table");
  if (!version) return Result<FiniteLawTablesV1>::failure(version.error());
  if (version.value() != kProtocolVersion) return fail<FiniteLawTablesV1>("artifact_wire_unsupported_version", "finite-law payload version must equal one", path + "/payload_version");
  if (!targets) return Result<FiniteLawTablesV1>::failure(targets.error());
  if (!semantic) return Result<FiniteLawTablesV1>::failure(semantic.error());
  if (!access) return Result<FiniteLawTablesV1>::failure(access.error());
  if (!arrival) return Result<FiniteLawTablesV1>::failure(arrival.error());
  if (!selection) return Result<FiniteLawTablesV1>::failure(selection.error());
  if (!states) return Result<FiniteLawTablesV1>::failure(states.error());
  if (!marks) return Result<FiniteLawTablesV1>::failure(marks.error());
  if (!table) return Result<FiniteLawTablesV1>::failure(table.error());
  return Result<FiniteLawTablesV1>::success(FiniteLawTablesV1{
      std::move(version).value(), std::move(targets).value(), std::move(semantic).value(),
      std::move(access).value(), std::move(arrival).value(), std::move(selection).value(),
      std::move(states).value(), std::move(marks).value(), std::move(table).value()});
}

}  // namespace
}  // namespace mwperf

namespace mwperf {
namespace {

[[nodiscard]] OrderedJson encode_common_work_counter(
    const CommonWorkCounterV1& value) {
  const std::string_view applicability =
      value.applicability == WorkCounterApplicabilityV1::applicable
          ? std::string_view("applicable")
          : std::string_view("not_applicable");
  return OrderedJson{
      {"applicability", applicability},
      {"used", artifact::detail::wire::encode_big_nat(value.used)}};
}

[[nodiscard]] OrderedJson encode_component_digest_value(
    const ArtifactComponentDigestV1& value) {
  return OrderedJson{
      {"component_name", value.component_name},
      {"component_digest",
       artifact::detail::wire::encode_digest(value.component_digest)}};
}

[[nodiscard]] OrderedJson encode_named_portable_value(
    const NamedPortableValueV1& value) {
  return OrderedJson{{"name", value.name},
                     {"value", encode_portable_value(value.value)}};
}

[[nodiscard]] OrderedJson encode_common_build_report_value(
    const CommonBuildReportV1& value, const bool omit_report_digest) {
  OrderedJson result{
      {"report_schema_version", value.report_schema_version},
      {"report_id",
       artifact::detail::wire::encode_typed_label(value.report_id)}};
  if (!omit_report_digest) {
    result["report_digest"] =
        artifact::detail::wire::encode_digest(value.report_digest);
  }
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["construction_budget_digest"] =
      artifact::detail::wire::encode_digest(value.construction_budget_digest);
  result["optimizer_calls"] =
      encode_common_work_counter(value.optimizer_calls);
  result["optimizer_search_states"] =
      encode_common_work_counter(value.optimizer_search_states);
  result["configured_generator_draws"] =
      encode_common_work_counter(value.configured_generator_draws);
  result["optional_component_digests"] = encode_vector(
      value.optional_component_digests, encode_component_digest_value);
  result["optional_method_counters"] = encode_vector(
      value.optional_method_counters, encode_named_portable_value);
  return result;
}

[[nodiscard]] bool is_late_bound_evidence_backlink_field(
    const std::string_view field) {
  static constexpr std::array<std::string_view, 7U> kFields{
      "family_evidence_envelope_ids",
      "derivation_certificate_id",
      "typed_evidence_components",
      "evidence_ids",
      "completion_absorption_tail_evidence",
      "complete_mass_termination_evidence",
      "projection_witness"};
  return std::find(kFields.begin(), kFields.end(), field) != kFields.end();
}

void project_late_bound_evidence_backlinks(OrderedJson& value) {
  if (value.is_object()) {
    for (auto iterator = value.begin(); iterator != value.end(); ++iterator) {
      if (is_late_bound_evidence_backlink_field(iterator.key())) {
        auto erase_reference_digest = [](OrderedJson& reference) {
          if (reference.is_object() && reference.contains("object_id") &&
              reference.contains("object_digest")) {
            reference.erase("object_digest");
          }
        };
        if (iterator.value().is_array()) {
          for (auto& reference : iterator.value()) {
            erase_reference_digest(reference);
          }
        } else {
          erase_reference_digest(iterator.value());
        }
      }
      project_late_bound_evidence_backlinks(iterator.value());
    }
  } else if (value.is_array()) {
    for (auto& item : value) {
      project_late_bound_evidence_backlinks(item);
    }
  }
}

template <typename Product, typename Encode>
[[nodiscard]] Result<Digest256> product_digest(
    const Product& product, const std::string_view domain, Encode&& encode) {
  OrderedJson value = encode(product);
  project_late_bound_evidence_backlinks(value);
  // Evidence/certificate backlinks retain their stable object IDs but omit
  // their later-issued digest seals.  F-C15-06 resolves the complete supplied
  // references after those evidence objects have been sealed.  Ordinary
  // content, policy and parent-lineage identities remain fully bound.
  auto& identity = value.at("product_id").at("identity");
  identity.erase("object_digest");
  return json_digest(domain, value);
}

template <typename T>
[[nodiscard]] bool vector_contains(const std::vector<T>& values,
                                   const T& sought) {
  return std::find(values.begin(), values.end(), sought) != values.end();
}

[[nodiscard]] bool payload_access_compatible(
    const PayloadClassTagV1 payload, const SemanticTagV1 semantic,
    const RuntimeAccessTagV1 access) {
  const bool finite_law =
      semantic == SemanticTagV1::stationary_marked_edge ||
      semantic == SemanticTagV1::staged_opportunity_flux_law ||
      semantic == SemanticTagV1::temporal_one_slot_continuation ||
      semantic == SemanticTagV1::romr_residence_word_law ||
      semantic == SemanticTagV1::stopped_path_law ||
      semantic == SemanticTagV1::coupled_target_schedule_law;
  switch (payload) {
    case PayloadClassTagV1::three_bin_scalar_response_v1:
      return semantic == SemanticTagV1::scalar_backlog_response &&
             access ==
                 RuntimeAccessTagV1::finite_parameter_analytic_family;
    case PayloadClassTagV1::finite_parameter_analytic_data_v1:
      return finite_law &&
             (access == RuntimeAccessTagV1::analytic_transform ||
              access ==
                  RuntimeAccessTagV1::finite_parameter_analytic_family);
    case PayloadClassTagV1::finite_law_tables_v1:
      return finite_law &&
             (access == RuntimeAccessTagV1::finite_enumerated_row ||
              access == RuntimeAccessTagV1::sparse_row);
    case PayloadClassTagV1::registered_runtime_recipe_v1:
      return finite_law &&
             (access ==
                  RuntimeAccessTagV1::normalized_conditional_sampler ||
              access ==
                  RuntimeAccessTagV1::procedural_residence_generator);
    case PayloadClassTagV1::response_envelope_evidence_v1:
      return semantic == SemanticTagV1::response_envelope_law &&
             (access == RuntimeAccessTagV1::finite_parameter_analytic_family ||
              access == RuntimeAccessTagV1::analytic_transform);
    case PayloadClassTagV1::direct_metric_payload_v1:
      return semantic == SemanticTagV1::direct_metric_decoder &&
             access == RuntimeAccessTagV1::direct_metric_decoder;
    case PayloadClassTagV1::finite_prefix_constant_tail_response_v1:
      return semantic == SemanticTagV1::scalar_backlog_response &&
             access == RuntimeAccessTagV1::finite_parameter_analytic_family;
    case PayloadClassTagV1::empirical_finite_window_response_v1:
      return semantic == SemanticTagV1::scalar_backlog_response &&
             access == RuntimeAccessTagV1::finite_parameter_analytic_family;
  }
  return false;
}

[[nodiscard]] std::vector<QueueId> payload_targets(
    const ArtifactPayloadV1& payload) {
  return std::visit(
      [](const auto& value) -> std::vector<QueueId> {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::same_as<T, ThreeBinScalarResponseV1> ||
                      std::same_as<
                          T, FinitePrefixConstantTailResponseV1>) {
          return {value.deployed_target};
        } else if constexpr (
            std::same_as<T, FiniteParameterAnalyticDataV1> ||
            std::same_as<T, FiniteLawTablesV1> ||
            std::same_as<T, RegisteredRuntimeRecipeV1> ||
            std::same_as<T, ResponseEnvelopeEvidenceV1>) {
          return value.ordered_deployed_targets;
        } else {
          std::vector<QueueId> result;
          for (const auto& direct : value.values) {
            for (const auto& target : direct.ordered_targets) {
              if (!vector_contains(result, target)) result.push_back(target);
            }
          }
          return result;
        }
      },
      payload);
}

[[nodiscard]] std::optional<SemanticTagV1> finite_table_semantic(
    const FiniteLawTableAlternativeV1& table) {
  switch (table.index()) {
    case 0U: return SemanticTagV1::stationary_marked_edge;
    case 1U: return SemanticTagV1::staged_opportunity_flux_law;
    case 2U: return SemanticTagV1::temporal_one_slot_continuation;
    case 3U: return SemanticTagV1::stopped_path_law;
    case 4U: return SemanticTagV1::romr_residence_word_law;
    case 5U: return SemanticTagV1::coupled_target_schedule_law;
  }
  return std::nullopt;
}

[[nodiscard]] bool result_scope_covered(
    const ConstructionResultScopeV1 available,
    const MetricResultScopeV1 required) {
  switch (available) {
    case ConstructionResultScopeV1::not_applicable:
      return false;
    case ConstructionResultScopeV1::not_a_metric_result:
      return required == MetricResultScopeV1::not_a_metric_result;
    case ConstructionResultScopeV1::surrogate_law:
      return required == MetricResultScopeV1::not_a_metric_result ||
             required == MetricResultScopeV1::surrogate_law;
    case ConstructionResultScopeV1::proposal_raw:
      return required == MetricResultScopeV1::not_a_metric_result ||
             required == MetricResultScopeV1::proposal_raw;
    case ConstructionResultScopeV1::response_envelope:
      return required == MetricResultScopeV1::not_a_metric_result ||
             required == MetricResultScopeV1::response_envelope;
    case ConstructionResultScopeV1::physical_bound:
      return required == MetricResultScopeV1::not_a_metric_result ||
             required == MetricResultScopeV1::response_envelope ||
             required == MetricResultScopeV1::physical_bound;
  }
  return false;
}

[[nodiscard]] MetricEvidenceScopeV1 construction_evidence_scope(
    const ConstructionErrorScopeV1 scope) {
  switch (scope) {
    case ConstructionErrorScopeV1::none:
      return MetricEvidenceScopeV1::none;
    case ConstructionErrorScopeV1::raw_static_proposal:
      return MetricEvidenceScopeV1::raw_static_proposal;
    case ConstructionErrorScopeV1::nominal_static_proposal:
      return MetricEvidenceScopeV1::nominal_static_proposal;
    case ConstructionErrorScopeV1::projection_center:
      return MetricEvidenceScopeV1::projection_center;
    case ConstructionErrorScopeV1::projected_surrogate_mean:
      return MetricEvidenceScopeV1::projected_surrogate_mean;
    case ConstructionErrorScopeV1::recoded_static_proposal:
      return MetricEvidenceScopeV1::recoded_static_proposal;
    case ConstructionErrorScopeV1::optimizer_interval_raw:
      return MetricEvidenceScopeV1::optimizer_interval_raw;
    case ConstructionErrorScopeV1::deployed_surrogate_law:
      return MetricEvidenceScopeV1::deployed_surrogate_law;
    case ConstructionErrorScopeV1::numerical_result:
      return MetricEvidenceScopeV1::numerical_result;
    case ConstructionErrorScopeV1::validity_or_lift:
      return MetricEvidenceScopeV1::validity_or_lift;
    case ConstructionErrorScopeV1::physical_system:
      return MetricEvidenceScopeV1::physical_system;
  }
  return MetricEvidenceScopeV1::none;
}

[[nodiscard]] bool evidence_scope_covered(
    const MetricEvidenceScopeV1 available,
    const MetricEvidenceScopeV1 required) {
  // Evidence scopes are categories, not a numerical lattice.  `none` is the
  // only universally satisfied request; every authored non-none scope must
  // equal the descriptor's explicitly advertised construction-error scope.
  return required == MetricEvidenceScopeV1::none || available == required;
}

[[nodiscard]] int coupling_rank(const TargetCouplingV1 value) {
  switch (value) {
    case TargetCouplingV1::scalar_target: return 0;
    case TargetCouplingV1::common_schedule_projection: return 1;
    case TargetCouplingV1::full_schedule_identity: return 2;
  }
  return -1;
}

[[nodiscard]] bool coupling_satisfies(const TargetCouplingV1 offered,
                                      const TargetCouplingV1 required) {
  return coupling_rank(offered) >= coupling_rank(required);
}

[[nodiscard]] bool argument_domain_contains(
    const ExactArgumentDomain& offered, const ExactArgumentDomain& required) {
  if (offered.lower > required.lower || offered.upper < required.upper) {
    return false;
  }
  if (offered.lower == required.lower && required.lower_inclusive &&
      !offered.lower_inclusive) {
    return false;
  }
  if (offered.upper == required.upper && required.upper_inclusive &&
      !offered.upper_inclusive) {
    return false;
  }
  return true;
}

[[nodiscard]] bool assumption_satisfies(
    const ArrivalAssumptionV1& offered,
    const ArrivalAssumptionV1& required) {
  if (offered.kind != required.kind || offered.use != required.use ||
      (required.joint && !offered.joint) ||
      (required.phase_conditioned && !offered.phase_conditioned)) {
    return false;
  }
  if (required.provision != CapabilityProvisionNeedV1::any &&
      offered.provision != required.provision) {
    return false;
  }
  if (required.moment_order.has_value() &&
      (!offered.moment_order.has_value() ||
       *offered.moment_order < *required.moment_order)) {
    return false;
  }
  if (required.transform_kind.has_value() &&
      offered.transform_kind != required.transform_kind) {
    return false;
  }
  if (required.distribution_scope.has_value() &&
      offered.distribution_scope != required.distribution_scope) {
    return false;
  }
  return !required.argument_domain.has_value() ||
         (offered.argument_domain.has_value() &&
          argument_domain_contains(*offered.argument_domain,
                                   *required.argument_domain));
}

[[nodiscard]] bool assumptions_cover(
    const std::vector<ArrivalAssumptionV1>& offered,
    const std::vector<ArrivalAssumptionV1>& required) {
  return std::all_of(
      required.begin(), required.end(),
      [&offered](const ArrivalAssumptionV1& item) {
        return std::any_of(
            offered.begin(), offered.end(),
            [&item](const ArrivalAssumptionV1& candidate) {
              return assumption_satisfies(candidate, item);
            });
      });
}

[[nodiscard]] bool hypothesis_satisfies(
    const HypothesisClaimV1& offered, const HypothesisClaimV1& required) {
  return offered.kind == required.kind &&
         offered.variable == required.variable &&
         offered.convention_or_class == required.convention_or_class &&
         (!required.order.has_value() ||
          (offered.order.has_value() && *offered.order >= *required.order));
}

[[nodiscard]] bool tolerances_cover(
    const std::vector<DeterministicToleranceV1>& offered,
    const std::vector<DeterministicToleranceV1>& required) {
  return std::all_of(
      required.begin(), required.end(),
      [&offered](const DeterministicToleranceV1& item) {
        return std::any_of(
            offered.begin(), offered.end(),
            [&item](const DeterministicToleranceV1& candidate) {
              return candidate.kind == item.kind &&
                     candidate.maximum_absolute_error <=
                         item.maximum_absolute_error;
            });
      });
}

[[nodiscard]] bool valid_monte_carlo_contract(
    const MonteCarloAccuracyV1& value) {
  switch (value.interval) {
    case StatisticalIntervalKindV1::exact_binomial:
      return value.estimand ==
                 StatisticalEstimandKindV1::binary_proportion &&
             value.almost_sure_lower == ExactRational::zero() &&
             value.almost_sure_upper == ExactRational::one();
    case StatisticalIntervalKindV1::hoeffding:
      return (value.estimand ==
                  StatisticalEstimandKindV1::bounded_iid ||
              value.estimand ==
                  StatisticalEstimandKindV1::binary_proportion) &&
             value.almost_sure_lower.has_value() &&
             value.almost_sure_upper.has_value() &&
             *value.almost_sure_lower <= *value.almost_sure_upper;
    case StatisticalIntervalKindV1::none:
      return value.estimand == StatisticalEstimandKindV1::
                                   point_with_variance_diagnostics;
  }
  return false;
}

[[nodiscard]] bool accuracy_satisfies(const AccuracyContractV1& offered,
                                      const AccuracyContractV1& required) {
  if (offered.index() != required.index()) return false;
  return std::visit(
      [&offered](const auto& expected) {
        using T = std::decay_t<decltype(expected)>;
        const auto* actual = std::get_if<T>(&offered);
        if (actual == nullptr) return false;
        if constexpr (std::same_as<T, EnumeratedAccuracyV1>) {
          return tolerances_cover(actual->tolerances, expected.tolerances);
        } else if constexpr (std::same_as<T, AnalyticAccuracyV1>) {
          return actual->precision_bits >= expected.precision_bits &&
                 tolerances_cover(actual->tolerances, expected.tolerances);
        } else if constexpr (std::same_as<T, MonteCarloAccuracyV1>) {
          return valid_monte_carlo_contract(*actual) &&
                 valid_monte_carlo_contract(expected) &&
                 actual->replications >= expected.replications &&
                 actual->confidence_level >= expected.confidence_level &&
                 actual->interval == expected.interval &&
                 actual->estimand == expected.estimand &&
                 (!expected.almost_sure_lower.has_value() ||
                  (actual->almost_sure_lower.has_value() &&
                   *actual->almost_sure_lower <=
                       *expected.almost_sure_lower)) &&
                 (!expected.almost_sure_upper.has_value() ||
                  (actual->almost_sure_upper.has_value() &&
                   *actual->almost_sure_upper >=
                       *expected.almost_sure_upper));
        } else {
          static_assert(std::same_as<T, DirectExactAccuracyV1>);
          return true;
        }
      },
      required);
}

[[nodiscard]] bool accuracy_supports(
    const std::vector<AccuracyContractV1>& offered,
    const AccuracyContractV1& required) {
  return std::any_of(offered.begin(), offered.end(),
                     [&required](const AccuracyContractV1& candidate) {
                       return accuracy_satisfies(candidate, required);
                     });
}

[[nodiscard]] bool phase_support_envelops(const PhaseSupportV1& offered,
                                          const PhaseSupportV1& required) {
  if (offered.payload_phase != required.payload_phase ||
      offered.arrival_composition != required.arrival_composition ||
      (required.retains_configured_predictive_phase &&
       !offered.retains_configured_predictive_phase) ||
      (required.predictive_phase_codec.has_value() &&
       offered.predictive_phase_codec != required.predictive_phase_codec)) {
    return false;
  }
  if (required.finite_horizon_coverage ==
      FiniteHorizonCoverageKindV1::none) {
    return true;
  }
  if (offered.finite_horizon_coverage ==
      FiniteHorizonCoverageKindV1::every_finite_horizon) {
    return true;
  }
  return offered.finite_horizon_coverage ==
             FiniteHorizonCoverageKindV1::bounded &&
         required.finite_horizon_coverage ==
             FiniteHorizonCoverageKindV1::bounded &&
         offered.maximum_finite_horizon.has_value() &&
         required.maximum_finite_horizon.has_value() &&
         *offered.maximum_finite_horizon >=
             *required.maximum_finite_horizon;
}

[[nodiscard]] bool exact_procedural_romr_source_v1(
    const MetricSupportClauseV1& clause) {
  return clause.semantic == SemanticTagV1::romr_residence_word_law &&
         clause.runtime_access ==
             RuntimeAccessTagV1::procedural_residence_generator &&
         (clause.solver_route == SolverRegimeV1::enumerated ||
          clause.solver_route == SolverRegimeV1::analytic) &&
         clause.error_promise.form == StructuralErrorFormV1::exact &&
         (!clause.error_promise.maximum_error.has_value() ||
          clause.error_promise.maximum_error->is_zero());
}

[[nodiscard]] bool metric_kind_supports_semantic_v1(
    const MetricSupportClauseV1& clause) {
  const MetricKindV1 kind = clause.metric_kind;
  const SemanticTagV1 semantic = clause.semantic;
  const SolverRegimeV1 solver_route = clause.solver_route;
  const TargetCouplingV1 target_coupling = clause.target_coupling;
  // C14's requirement compiler is the sole source of this closed map.  In
  // particular, a direct result is a solver route rather than a shortcut for
  // relabelling one of the eight mathematical-law routes.
  if (semantic == SemanticTagV1::direct_metric_decoder ||
      solver_route == SolverRegimeV1::direct) {
    return semantic == SemanticTagV1::direct_metric_decoder &&
           solver_route == SolverRegimeV1::direct;
  }
  if (semantic == SemanticTagV1::response_envelope_law) {
    // C15's one narrow envelope route reuses the exact-point response
    // requirement for backlog-conditioned service without changing C14's
    // route compiler.  All role, scope, evidence and physical-transfer gates
    // remain independently mandatory below.
    return kind == MetricKindV1::backlog_conditioned_service &&
           solver_route == SolverRegimeV1::analytic &&
           target_coupling == TargetCouplingV1::scalar_target;
  }
  if (solver_route == SolverRegimeV1::monte_carlo) {
    if (kind == MetricKindV1::backlog_conditioned_service) {
      return semantic == SemanticTagV1::scalar_backlog_response ||
             semantic == SemanticTagV1::stationary_marked_edge ||
             semantic == SemanticTagV1::staged_opportunity_flux_law ||
             semantic == SemanticTagV1::temporal_one_slot_continuation ||
             semantic == SemanticTagV1::coupled_target_schedule_law;
    }
    if (kind == MetricKindV1::stationary_edge_reward) {
      return semantic == SemanticTagV1::stationary_marked_edge ||
             semantic == SemanticTagV1::temporal_one_slot_continuation ||
             semantic == SemanticTagV1::coupled_target_schedule_law;
    }
    return false;
  }

  const auto is_one_of = [semantic](
                             const std::initializer_list<SemanticTagV1> set) {
    return std::find(set.begin(), set.end(), semantic) != set.end();
  };
  // C20/C21 release an exact, V0-audited procedural residence-word law as a
  // source for selected invariant, stationary-edge, finite-cylinder,
  // pushforward-count and stopped-path views.  Mirror C14's
  // exact_procedural_romr_source gate here: this is not a general semantic
  // relabelling and remains unavailable to finite-table, sampled, inexact or
  // direct carriers.
  const bool exact_procedural_romr =
      exact_procedural_romr_source_v1(clause);
  switch (kind) {
    case MetricKindV1::stationary_throughput:
    case MetricKindV1::mean_sojourn:
      return is_one_of({SemanticTagV1::scalar_backlog_response,
                        SemanticTagV1::stationary_marked_edge,
                        SemanticTagV1::staged_opportunity_flux_law,
                        SemanticTagV1::temporal_one_slot_continuation,
                        SemanticTagV1::coupled_target_schedule_law});
    case MetricKindV1::mean_event_gap:
    case MetricKindV1::mean_binary_run:
      return is_one_of({SemanticTagV1::scalar_backlog_response,
                        SemanticTagV1::stationary_marked_edge,
                        SemanticTagV1::staged_opportunity_flux_law,
                        SemanticTagV1::temporal_one_slot_continuation,
                        SemanticTagV1::coupled_target_schedule_law}) ||
             exact_procedural_romr;
    case MetricKindV1::stationary_empty_probability:
    case MetricKindV1::stationary_backlog_pmf:
    case MetricKindV1::stationary_backlog_pgf:
    case MetricKindV1::stationary_backlog_moment:
    case MetricKindV1::stationary_backlog_quantile:
    case MetricKindV1::stationary_backlog_tail:
      return is_one_of({SemanticTagV1::scalar_backlog_response,
                        SemanticTagV1::stationary_marked_edge,
                        SemanticTagV1::temporal_one_slot_continuation,
                        SemanticTagV1::coupled_target_schedule_law}) ||
             exact_procedural_romr;
    case MetricKindV1::backlog_conditioned_service:
      return is_one_of({SemanticTagV1::scalar_backlog_response,
                        SemanticTagV1::stationary_marked_edge,
                        SemanticTagV1::staged_opportunity_flux_law,
                        SemanticTagV1::temporal_one_slot_continuation,
                        SemanticTagV1::coupled_target_schedule_law});
    case MetricKindV1::stationary_edge_reward:
      return is_one_of({SemanticTagV1::stationary_marked_edge,
                        SemanticTagV1::temporal_one_slot_continuation,
                        SemanticTagV1::coupled_target_schedule_law});
    case MetricKindV1::service_persistence:
    case MetricKindV1::service_autocovariance:
    case MetricKindV1::service_spectrum:
    case MetricKindV1::transient_backlog_law:
      return semantic == SemanticTagV1::temporal_one_slot_continuation ||
             exact_procedural_romr;
    case MetricKindV1::lagged_cross_queue_covariance:
    case MetricKindV1::ordered_schedule_sequence:
      return semantic == SemanticTagV1::temporal_one_slot_continuation;
    case MetricKindV1::service_window_count:
      return semantic == SemanticTagV1::temporal_one_slot_continuation ||
             semantic == SemanticTagV1::romr_residence_word_law;
    case MetricKindV1::event_gap_distribution:
    case MetricKindV1::binary_run_distribution:
    case MetricKindV1::counterfactual_opportunity_gap:
      return semantic == SemanticTagV1::romr_residence_word_law;
    case MetricKindV1::first_hit:
    case MetricKindV1::threshold_excursion:
    case MetricKindV1::fifo_delay:
    case MetricKindV1::fifo_delay_conditioned:
    case MetricKindV1::joint_delay:
      return semantic == SemanticTagV1::stopped_path_law ||
             exact_procedural_romr;
    case MetricKindV1::joint_backlog_covariance:
    case MetricKindV1::joint_backlog_event:
      return target_coupling != TargetCouplingV1::scalar_target &&
             is_one_of({SemanticTagV1::scalar_backlog_response,
                        SemanticTagV1::stationary_marked_edge,
                        SemanticTagV1::temporal_one_slot_continuation,
                        SemanticTagV1::coupled_target_schedule_law});
  }
  return false;
}

[[nodiscard]] bool solver_access_route_v1(
    const MetricSupportClauseV1& clause) {
  const MetricKindV1 kind = clause.metric_kind;
  const SolverRegimeV1 solver = clause.solver_route;
  const RuntimeAccessTagV1 access = clause.runtime_access;
  if (exact_procedural_romr_source_v1(clause) &&
      metric_kind_supports_semantic_v1(clause)) {
    // The V0-audited complete-word source is itself the exact finite
    // enumerator for its derived temporal/stopped views.  Requiring the
    // generic analytic procedural regime here would contradict C14's
    // released exact ROMR route.
    return true;
  }
  const bool ordinary_match = [&] {
    switch (access) {
      case RuntimeAccessTagV1::finite_enumerated_row:
      case RuntimeAccessTagV1::sparse_row:
        return solver == SolverRegimeV1::enumerated;
      case RuntimeAccessTagV1::analytic_transform:
      case RuntimeAccessTagV1::finite_parameter_analytic_family:
      case RuntimeAccessTagV1::procedural_residence_generator:
        return solver == SolverRegimeV1::analytic;
      case RuntimeAccessTagV1::normalized_conditional_sampler:
        return solver == SolverRegimeV1::monte_carlo;
      case RuntimeAccessTagV1::direct_metric_decoder:
        return solver == SolverRegimeV1::direct;
    }
    return false;
  }();
  if (!ordinary_match ||
      access != RuntimeAccessTagV1::procedural_residence_generator) {
    return ordinary_match;
  }
  switch (kind) {
    case MetricKindV1::event_gap_distribution:
    case MetricKindV1::binary_run_distribution:
    case MetricKindV1::first_hit:
    case MetricKindV1::threshold_excursion:
    case MetricKindV1::fifo_delay:
    case MetricKindV1::fifo_delay_conditioned:
    case MetricKindV1::counterfactual_opportunity_gap:
    case MetricKindV1::joint_delay:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] bool response_all_raw_points(
    const ThreeBinScalarResponseV1& response) {
  return std::all_of(
      response.raw_response.identifications.begin(),
      response.raw_response.identifications.end(),
      [](const CoefficientIdentificationV1& value) {
        return value.coefficient_status.raw_value_status ==
                   RawValueStatusV1::exact_point &&
               value.raw_point.has_value();
      });
}

[[nodiscard]] bool response_has_family_backed_absence_v1(
    const ThreeBinScalarResponseV1& response) {
  return std::any_of(
      response.raw_response.identifications.begin(),
      response.raw_response.identifications.end(),
      [](const CoefficientIdentificationV1& identification) {
        // F05 establishes only that the payload carries a family-backed
        // absence candidate.  F06 resolves whether that candidate is the
        // exact-population proved-zero proof required by the raw-bound role.
        return identification.coefficient_status.raw_value_status ==
                   RawValueStatusV1::absent &&
               !identification.family_evidence_envelope_ids.empty();
      });
}

[[nodiscard]] bool response_has_role(
    const ThreeBinScalarResponseV1& response,
    const MetricSupportRoleV1 role) {
  switch (role) {
    case MetricSupportRoleV1::deployed_payload:
      return true;
    case MetricSupportRoleV1::deployed_response:
      return !std::holds_alternative<RawResponseProductId>(
                 response.deployed_response_product_id) ||
             response_all_raw_points(response);
    case MetricSupportRoleV1::raw_response:
      return true;
    case MetricSupportRoleV1::nominal_response:
      return response.nominal_response.has_value();
    case MetricSupportRoleV1::projection_center:
      return response.projection_center.has_value();
    case MetricSupportRoleV1::projected_mean:
      return response.projected_mean.has_value();
    case MetricSupportRoleV1::recoded_response:
      return response.recoded_response.has_value();
    case MetricSupportRoleV1::raw_response_bound_evidence:
      // An interval-only origin requires a retained numerical envelope.  An
      // absent origin has no number to bound and can instead expose only a
      // family-backed absence proof; F-C15-06 resolves that proof's exact
      // coefficient/report/raw-parent/provenance ledger.
      return !response.raw_envelopes.empty() ||
             response_has_family_backed_absence_v1(response);
    default:
      return false;
  }
}

[[nodiscard]] bool payload_has_role(
    const ArtifactPayloadV1& payload, const MetricSupportClauseV1& clause,
    const MetricSupportRoleRequirementV1& requirement,
    const PlugDescriptorCore& descriptor) {
  const auto role = requirement.role;
  if (role == MetricSupportRoleV1::deployed_payload) return true;
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&payload)) {
    if (role == MetricSupportRoleV1::raw_response_bound_evidence &&
        response->raw_envelopes.empty() &&
        !response_has_family_backed_absence_v1(*response)) {
      return false;
    }
    if (!response_has_role(*response, role)) {
      // Three-bin payloads cannot manufacture a temporal/common law, a
      // direct value, or an envelope merely because a similarly shaped ID is
      // present in diagnostics.
      if (role == MetricSupportRoleV1::response_order_evidence) return false;
    } else if (role != MetricSupportRoleV1::deployed_response) {
      return true;
    } else {
      const MetricSupportRoleV1 selected_role = std::visit(
          [](const auto& selected) {
            using T = std::decay_t<decltype(selected)>;
            if constexpr (std::same_as<T, RawResponseProductId>) {
              return MetricSupportRoleV1::raw_response;
            } else if constexpr (std::same_as<T,
                                                NominalResponseProductId>) {
              return MetricSupportRoleV1::nominal_response;
            } else {
              return MetricSupportRoleV1::recoded_response;
            }
          },
          response->deployed_response_product_id);
      return std::any_of(
          requirement.role_relations.begin(),
          requirement.role_relations.end(),
          [selected_role](const MetricRoleRelationRequirementV1& relation) {
            return relation.relation ==
                       MetricRoleRelationKindV1::subject &&
                   relation.other_role == selected_role;
          });
    }
  }
  if (const auto* response =
          std::get_if<FinitePrefixConstantTailResponseV1>(&payload)) {
    if (role == MetricSupportRoleV1::raw_response) return true;
    if (role == MetricSupportRoleV1::raw_response_bound_evidence) {
      return response->raw_envelopes.size() == 1U;
    }
    if (role == MetricSupportRoleV1::deployed_response) {
      return response->deployed_response_product_id ==
                 response->raw_response.product_id &&
             std::any_of(
                 requirement.role_relations.begin(),
                 requirement.role_relations.end(),
                 [](const MetricRoleRelationRequirementV1& relation) {
                   return relation.relation ==
                              MetricRoleRelationKindV1::subject &&
                          relation.other_role ==
                              MetricSupportRoleV1::raw_response;
                 });
    }
  }
  if (const auto* envelope =
          std::get_if<ResponseEnvelopeEvidenceV1>(&payload)) {
    if (role == MetricSupportRoleV1::deployed_response) return false;
    if (role == MetricSupportRoleV1::raw_response) return true;
    if (role == MetricSupportRoleV1::nominal_response) {
      return envelope->lower_response.nominal_response.has_value() ||
             envelope->upper_response.nominal_response.has_value();
    }
    if (role == MetricSupportRoleV1::projection_center) {
      return envelope->lower_response.projection_center.has_value() ||
             envelope->upper_response.projection_center.has_value();
    }
    if (role == MetricSupportRoleV1::projected_mean) {
      return envelope->lower_response.projected_mean.has_value() ||
             envelope->upper_response.projected_mean.has_value();
    }
    if (role == MetricSupportRoleV1::recoded_response) {
      return envelope->lower_response.recoded_response.has_value() ||
             envelope->upper_response.recoded_response.has_value();
    }
    if (role == MetricSupportRoleV1::response_envelope) return true;
    if (role == MetricSupportRoleV1::raw_response_bound_evidence) {
      return !envelope->typed_evidence_components.empty() ||
             !envelope->lower_response.raw_envelopes.empty() ||
             !envelope->upper_response.raw_envelopes.empty() ||
             response_has_family_backed_absence_v1(
                 envelope->lower_response) ||
             response_has_family_backed_absence_v1(
                 envelope->upper_response);
    }
    if (role == MetricSupportRoleV1::response_order_evidence) {
      return !envelope->typed_evidence_components.empty();
    }
  }
  if (const auto* direct = std::get_if<DirectMetricPayloadV1>(&payload)) {
    if (role == MetricSupportRoleV1::direct_metric_value) {
      return std::any_of(
          direct->values.begin(), direct->values.end(),
          [&clause](const DirectMetricValueV1& value) {
            return value.metric_clause_id == clause.clause_id &&
                   value.ordered_targets == clause.ordered_targets &&
                   value.result_scope == clause.result_scope;
          });
    }
  }
  const auto law_role = [&]() -> std::optional<MetricSupportRoleV1> {
    switch (descriptor.semantic) {
      case SemanticTagV1::stationary_marked_edge:
        return MetricSupportRoleV1::stationary_marked_edge_law;
      case SemanticTagV1::staged_opportunity_flux_law:
        return MetricSupportRoleV1::staged_opportunity_flux_law;
      case SemanticTagV1::temporal_one_slot_continuation:
        return MetricSupportRoleV1::temporal_continuation_law;
      case SemanticTagV1::romr_residence_word_law:
        return MetricSupportRoleV1::residence_word_law;
      case SemanticTagV1::stopped_path_law:
        return MetricSupportRoleV1::stopped_path_law;
      case SemanticTagV1::coupled_target_schedule_law:
        return MetricSupportRoleV1::coupled_schedule_law;
      default:
        return std::nullopt;
    }
  }();
  if (law_role.has_value() && role == *law_role &&
      (std::holds_alternative<FiniteLawTablesV1>(payload) ||
       std::holds_alternative<FiniteParameterAnalyticDataV1>(payload) ||
       std::holds_alternative<RegisteredRuntimeRecipeV1>(payload))) {
    return true;
  }

  // These evidence alternatives are carried in the enclosing artifact rather
  // than inside a reusable payload.  F05 admits them only when the descriptor
  // structurally declares a nonpromoted route; F06 must resolve their exact
  // typed objects and purpose ledgers.
  switch (role) {
    case MetricSupportRoleV1::raw_response_bound_evidence:
    case MetricSupportRoleV1::response_order_evidence:
    case MetricSupportRoleV1::optimizer_evidence:
    case MetricSupportRoleV1::statistical_evidence:
    case MetricSupportRoleV1::numerical_evidence:
    case MetricSupportRoleV1::calibration_evidence:
    case MetricSupportRoleV1::compression_evidence:
      return requirement.evidence_scope != MetricEvidenceScopeV1::none;
    case MetricSupportRoleV1::stability_certificate:
      return std::any_of(
          descriptor.hypothesis_claims.begin(),
          descriptor.hypothesis_claims.end(),
          [](const HypothesisClaimV1& value) {
            return value.kind == HypothesisKindV1::stable ||
                   value.kind == HypothesisKindV1::proper_stationary ||
                   value.kind == HypothesisKindV1::recurrent;
          });
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return descriptor.mandatory_v0.kind ==
                 V0DeclarationKindV1::structural_witness_required ||
             std::any_of(
                 descriptor.optional_reported_evidence.begin(),
                 descriptor.optional_reported_evidence.end(),
                 [](const OptionalReportedEvidenceV1& value) {
                   return value.kind ==
                              OptionalReportedEvidenceKindV1::
                                  v1_fibre_realizability ||
                          value.kind ==
                              OptionalReportedEvidenceKindV1::v2_dynamic_lift;
                 });
    case MetricSupportRoleV1::physical_transfer_evidence:
      return std::any_of(
          descriptor.optional_reported_evidence.begin(),
          descriptor.optional_reported_evidence.end(),
          [](const OptionalReportedEvidenceV1& value) {
            return value.kind ==
                   OptionalReportedEvidenceKindV1::physical_fidelity;
          });
    default:
      return false;
  }
}

}  // namespace

PayloadClassV1 artifact_payload_class_v1(
    const ArtifactPayloadV1& payload) noexcept {
  return PayloadClassV1{static_cast<PayloadClassTagV1>(payload.index()),
                        kProtocolVersion};
}

Result<std::vector<std::byte>> canonical_artifact_payload_bytes_v1(
    const ArtifactPayloadV1& payload) {
  return Result<std::vector<std::byte>>::success(
      json_bytes(artifact::detail::wire::encode_payload_wire_v1(payload)));
}

Result<Digest256> canonical_artifact_payload_digest_v1(
    const ArtifactPayloadV1& payload) {
  OrderedJson value = artifact::detail::wire::encode_payload_wire_v1(payload);
  project_late_bound_evidence_backlinks(value);
  return json_digest("mwperf.surrogate_artifact_payload.v1", value);
}

Result<std::vector<std::byte>> canonical_common_build_report_bytes_v1(
    const CommonBuildReportV1& report, const bool omit_report_digest) {
  return Result<std::vector<std::byte>>::success(json_bytes(
      encode_common_build_report_value(report, omit_report_digest)));
}

Result<Digest256> canonical_common_build_report_digest_v1(
    const CommonBuildReportV1& report) {
  auto bytes = canonical_common_build_report_bytes_v1(report, true);
  if (!bytes) return Result<Digest256>::failure(bytes.error());
  return sha256_domain_separated("mwperf.surrogate_build_report.v1",
                                 bytes.value());
}

Result<Digest256> canonical_raw_response_product_digest_v1(
    const RawResponseProductV1& product) {
  return product_digest(product, "mwperf.raw_response_product.v1",
                        encode_raw_product);
}

Result<Digest256> canonical_finite_prefix_raw_response_product_digest_v1(
    const FinitePrefixRawResponseProductV1& product) {
  return product_digest(product,
                        "mwperf.finite_prefix_raw_response_product.v1",
                        encode_finite_prefix_raw_product);
}

Result<Digest256> canonical_nominal_response_product_digest_v1(
    const NominalResponseProductV1& product) {
  return product_digest(product, "mwperf.nominal_response_product.v1",
                        encode_nominal_product);
}

Result<Digest256> canonical_projection_center_product_digest_v1(
    const ProjectionCenterProductV1& product) {
  return product_digest(product, "mwperf.projection_center_product.v1",
                        encode_projection_center);
}

Result<Digest256> canonical_projected_mean_product_digest_v1(
    const ProjectedMeanProductV1& product) {
  return product_digest(product, "mwperf.projected_mean_product.v1",
                        encode_projected_mean);
}

Result<Digest256> canonical_recoded_response_product_digest_v1(
    const RecodedResponseProductV1& product) {
  return product_digest(product, "mwperf.recoded_response_product.v1",
                        encode_recoded_product);
}

Result<Digest256> canonical_three_bin_response_row_digest_v1(
    const ThreeBinScalarResponseV1& response) {
  OrderedJson value = encode_three_bin(response);
  project_late_bound_evidence_backlinks(value);
  value.at("response_row_id").erase("object_digest");
  return json_digest("mwperf.three_bin_response_row.v1", value);
}

Result<Digest256>
canonical_finite_prefix_constant_tail_response_row_digest_v1(
    const FinitePrefixConstantTailResponseV1& response) {
  OrderedJson value = encode_finite_prefix_constant_tail(response);
  project_late_bound_evidence_backlinks(value);
  value.at("response_row_id").erase("object_digest");
  return json_digest("mwperf.finite_prefix_constant_tail_response_row.v1",
                     value);
}

Result<Digest256>
canonical_finite_prefix_coefficient_identification_digest_v1(
    const FinitePrefixCoefficientIdentificationV1& identification) {
  OrderedJson value = encode_finite_prefix_identification(identification);
  project_late_bound_evidence_backlinks(value);
  value.at("coefficient_id").erase("object_digest");
  return json_digest("mwperf.finite_prefix_coefficient_identification.v1",
                     value);
}

Result<Digest256> canonical_finite_prefix_raw_response_envelope_digest_v1(
    const FinitePrefixRawResponseEnvelopeV1& envelope) {
  OrderedJson value = encode_finite_prefix_raw_envelope(envelope);
  project_late_bound_evidence_backlinks(value);
  value.at("envelope_id").erase("object_digest");
  return json_digest("mwperf.finite_prefix_raw_response_envelope.v1",
                     value);
}

const ArtifactObjectReferenceV1& deployed_response_product_identity_v1(
    const DeployedResponseProductIdV1& product) noexcept {
  return std::visit(
      [](const auto& value) -> const ArtifactObjectReferenceV1& {
        return value.identity();
      },
      product);
}

namespace artifact::detail {

Result<Digest256> coefficient_identification_digest_v1(
    const CoefficientIdentificationV1& identification) {
  OrderedJson value = encode_identification(identification);
  project_late_bound_evidence_backlinks(value);
  value.at("coefficient_id").erase("object_digest");
  return json_digest("mwperf.coefficient_identification.v1", value);
}

Result<Digest256> raw_response_envelope_digest_v1(
    const RawResponseEnvelopeV1& envelope) {
  OrderedJson value = encode_raw_envelope(envelope);
  project_late_bound_evidence_backlinks(value);
  value.at("envelope_id").erase("object_digest");
  return json_digest("mwperf.raw_response_envelope.v1", value);
}

Result<Digest256> finite_law_table_digest_v1(
    const FiniteLawTableAlternativeV1& table) {
  OrderedJson value = encode_table(table);
  project_late_bound_evidence_backlinks(value);
  value.at("law_id").erase("object_digest");
  return json_digest("mwperf.finite_law_table.v1", value);
}

Result<Digest256> direct_metric_value_digest_v1(
    const DirectMetricValueV1& direct_value) {
  OrderedJson value = encode_direct_value(direct_value);
  project_late_bound_evidence_backlinks(value);
  value.at("value_id").erase("object_digest");
  return json_digest("mwperf.direct_metric_value.v1", value);
}

Result<Digest256> family_evidence_body_digest_v1(
    const std::span<const std::byte> canonical_body) {
  return sha256_domain_separated("mwperf.family_evidence_body.v1",
                                 canonical_body);
}

Result<Digest256> family_evidence_envelope_digest_v1(
    const FamilyEvidenceEnvelopeV1& evidence) {
  auto hex_bytes = [](const std::span<const std::byte> bytes) {
    static constexpr char kHex[] = "0123456789abcdef";
    std::string encoded;
    encoded.reserve(bytes.size() * 2U);
    for (const std::byte value : bytes) {
      const auto byte = std::to_integer<unsigned int>(value);
      encoded.push_back(kHex[(byte >> 4U) & 0x0fU]);
      encoded.push_back(kHex[byte & 0x0fU]);
    }
    return encoded;
  };
  OrderedJson value{
      {"envelope_version", evidence.envelope_version},
      {"evidence_id", artifact::detail::wire::encode_artifact_object_reference(
                          evidence.evidence_id)},
      {"family_evidence_schema_id", evidence.family_evidence_schema_id},
      {"family_evidence_schema_version",
       evidence.family_evidence_schema_version},
      {"provider_conformance_report_ref",
       encode_conformance(evidence.provider_conformance_report_ref)},
      {"provider", encode_provider(evidence.provider)},
      {"provider_scientific_contract_digest",
       artifact::detail::wire::encode_digest(
           evidence.provider_scientific_contract_digest)},
      {"request_digest",
       artifact::detail::wire::encode_digest(evidence.request_digest)},
      {"payload_digest",
       artifact::detail::wire::encode_digest(evidence.payload_digest)},
      {"subject_references",
       encode_vector(evidence.subject_references,
                     artifact::detail::wire::encode_artifact_object_reference)},
      {"parent_references",
       encode_vector(evidence.parent_references,
                     artifact::detail::wire::encode_artifact_object_reference)},
      {"construction_target_scope",
       encode_vector(evidence.construction_target_scope,
                     [](const QueueId& target) {
                       return encode_strong_id(target);
                     })},
      {"evidence_scope_tag", std::string(enum_text(evidence.evidence_scope_tag))},
      {"canonical_family_body", hex_bytes(evidence.canonical_family_body)},
      {"canonical_family_body_digest",
       artifact::detail::wire::encode_digest(
           evidence.canonical_family_body_digest)}};
  value.at("evidence_id").erase("object_digest");
  return json_digest("mwperf.family_evidence_envelope.v1", value);
}

Result<Digest256> scoped_artifact_evidence_digest_v1(
    const ScopedArtifactEvidenceV1& evidence) {
  OrderedJson internal = OrderedJson::array();
  for (const auto& relation : evidence.internal_references) {
    internal.push_back(OrderedJson{
        {"relation", static_cast<std::uint8_t>(relation.relation)},
        {"purpose", static_cast<std::uint8_t>(relation.purpose)},
        {"referenced_object",
         artifact::detail::wire::encode_artifact_object_reference(
             relation.referenced_object)}});
  }
  OrderedJson value{
      {"evidence_id", artifact::detail::wire::encode_artifact_object_reference(
                          evidence.evidence_id)},
      {"reference_kind", static_cast<std::uint8_t>(evidence.reference_kind)},
      {"ordered_targets",
       encode_vector(evidence.ordered_targets, [](const QueueId& target) {
         return encode_strong_id(target);
       })},
      {"result_scope", std::string(enum_text(evidence.result_scope))},
      {"evidence_scope", std::string(enum_text(evidence.evidence_scope))},
      {"subject_references",
       encode_vector(evidence.subject_references,
                     artifact::detail::wire::encode_artifact_object_reference)},
      {"parent_references",
       encode_vector(evidence.parent_references,
                     artifact::detail::wire::encode_artifact_object_reference)},
      {"family_envelope_ids",
       encode_vector(evidence.family_envelope_ids,
                     artifact::detail::wire::encode_artifact_object_reference)},
      {"internal_references", std::move(internal)}};
  value.at("evidence_id").erase("object_digest");
  return json_digest("mwperf.scoped_artifact_evidence.v1", value);
}

Result<Digest256> coupled_tie_phase_arrival_binding_v1(
    const FrameworkProblemView& problem_view) {
  if (problem_view.schema_version() != kProtocolVersion) {
    return fail<Digest256>(
        "c15.coupled_binding_problem_view_version",
        "coupled tie/phase/arrival binding requires framework problem view version one");
  }
  const auto& fingerprints = problem_view.fingerprints();
  const OrderedJson value{
      {"tie_and_timing_fingerprint",
       artifact::detail::wire::encode_digest(fingerprints.tie_and_timing)},
      {"target_selection_fingerprint",
       artifact::detail::wire::encode_digest(fingerprints.target_selection)},
      {"compiled_arrival_fingerprint",
       artifact::detail::wire::encode_digest(fingerprints.compiled_arrival)}};
  return json_digest("mwperf.coupled_tie_phase_arrival_binding.v1", value);
}

}  // namespace artifact::detail

Result<ValidatedMetricSupportManifest> validate_metric_support_manifest(
    const MetricSupportManifest& manifest, const ArtifactPayload& payload,
    const PlugDescriptorCore& descriptor) {
  if (descriptor.schema_version != kProtocolVersion) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.unsupported_descriptor_version",
        "plug descriptor schema version must equal one",
        "/deployed_descriptor/schema_version");
  }
  if (!detail::is_valid_plug_descriptor_core_shape_v1(descriptor)) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.invalid_descriptor_shape",
        "plug descriptor core is not a valid closed canonical C14 shape",
        "/deployed_descriptor");
  }
  const auto payload_class = artifact_payload_class_v1(payload);
  if (payload_class.version != kProtocolVersion ||
      descriptor.payload_class != payload_class) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.payload_class_mismatch",
        "payload alternative and descriptor payload class differ",
        "/deployed_descriptor/payload_class");
  }
  if (!payload_access_compatible(descriptor.payload_class.tag,
                                 descriptor.semantic,
                                 descriptor.runtime_access)) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.incompatible_payload_access",
        "payload, semantic and runtime-access tuple is not a closed v1 tuple",
        "/deployed_descriptor/runtime_access");
  }
  const auto descriptor_digest =
      canonical_plug_descriptor_core_digest_v1(descriptor);
  if (!descriptor_digest || descriptor_digest.value() != descriptor.core_digest) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.descriptor_digest_mismatch",
        "deployed descriptor does not match its canonical digest",
        "/deployed_descriptor/core_digest");
  }
  if (descriptor.metric_support_manifest_digest !=
      manifest.canonical_digest()) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.manifest_digest_mismatch",
        "descriptor does not bind the supplied structural manifest",
        "/deployed_descriptor/metric_support_manifest_digest");
  }
  std::vector<MetricSupportClauseV1> copied_clauses(
      manifest.clauses().begin(), manifest.clauses().end());
  auto reconstructed =
      MetricSupportManifest::from_clauses(std::move(copied_clauses));
  if (!reconstructed || reconstructed.value() != manifest ||
      reconstructed.value().canonical_digest() !=
          manifest.canonical_digest()) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.noncanonical_structural_manifest",
        "structural manifest is not its exact canonical v1 value",
        "/structural_manifest");
  }

  const auto targets = payload_targets(payload);
  if (targets != descriptor.deployed_targets) {
    return fail<ValidatedMetricSupportManifest>(
        "c15.payload_target_mismatch",
        "payload target identities/order differ from the descriptor",
        "/payload/ordered_deployed_targets");
  }
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&payload)) {
    (void)response;
    if (targets.size() != 1U ||
        descriptor.target_coupling != TargetCouplingV1::scalar_target ||
        descriptor.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
        descriptor.tail.kind != TailRepresentationKindV1::constant_response ||
        !descriptor.tail.boundary.has_value() ||
        descriptor.tail.boundary->value() != BigInt{3}) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.three_bin_descriptor_mismatch",
          "three-bin response requires singleton scalar, phase-free, constant-tail descriptor",
          "/deployed_descriptor");
    }
  }
  if (const auto* response =
          std::get_if<FinitePrefixConstantTailResponseV1>(&payload)) {
    if (targets.size() != 1U ||
        descriptor.target_coupling != TargetCouplingV1::scalar_target ||
        descriptor.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
        descriptor.tail.kind != TailRepresentationKindV1::constant_response ||
        !descriptor.tail.boundary.has_value() ||
        descriptor.tail.boundary->value() !=
            response->response_cutoff.value() + 1) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.finite_prefix_descriptor_mismatch",
          "finite-prefix response requires singleton scalar, phase-free, "
          "constant-tail descriptor with boundary K+1",
          "/deployed_descriptor");
    }
  }
  if (const auto* tables = std::get_if<FiniteLawTablesV1>(&payload)) {
    const auto semantic = finite_table_semantic(tables->table);
    if (!semantic || *semantic != tables->semantic ||
        tables->semantic != descriptor.semantic ||
        tables->runtime_access != descriptor.runtime_access) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.finite_table_semantic_mismatch",
          "finite-table subtag, semantic and access must agree exactly",
          "/payload/table");
    }
    if (tables->semantic == SemanticTagV1::coupled_target_schedule_law &&
        (targets.size() < 2U || descriptor.target_coupling ==
                                    TargetCouplingV1::scalar_target)) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.coupled_table_target_mismatch",
          "coupled schedule table requires an ordered multi-target coupled descriptor",
          "/deployed_descriptor/target_coupling");
    }
  }

  const auto available_evidence =
      construction_evidence_scope(descriptor.construction_scope.error_scope);
  for (std::size_t index = 0U; index < manifest.clauses().size(); ++index) {
    const auto& clause = manifest.clauses()[index];
    const std::string path =
        "/structural_manifest/clauses/" + std::to_string(index);
    if (!metric_kind_supports_semantic_v1(clause) ||
        !solver_access_route_v1(clause)) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.metric_semantic_route_mismatch",
          "metric kind, solver route, coupling and semantic do not form a released C14 route",
          path + "/semantic");
    }
    if (const auto* envelope =
            std::get_if<ResponseEnvelopeEvidenceV1>(&payload)) {
      const auto has_role = [&](const MetricSupportRoleV1 role) {
        return std::any_of(
            clause.required_roles.begin(), clause.required_roles.end(),
            [role](const MetricSupportRoleRequirementV1& requirement) {
              return requirement.role == role;
            });
      };
      const bool envelope_scope =
          clause.result_scope == MetricResultScopeV1::response_envelope ||
          clause.result_scope == MetricResultScopeV1::physical_bound;
      if (clause.metric_kind !=
              MetricKindV1::backlog_conditioned_service ||
          clause.target_coupling != TargetCouplingV1::scalar_target ||
          clause.ordered_targets.size() != 1U ||
          clause.solver_route != SolverRegimeV1::analytic ||
          (clause.runtime_access !=
               RuntimeAccessTagV1::finite_parameter_analytic_family &&
           clause.runtime_access != RuntimeAccessTagV1::analytic_transform) ||
          !envelope_scope || clause.result_scope != envelope->result_scope ||
          !has_role(MetricSupportRoleV1::deployed_payload) ||
          !has_role(MetricSupportRoleV1::response_envelope) ||
          !has_role(MetricSupportRoleV1::raw_response) ||
          !has_role(MetricSupportRoleV1::raw_response_bound_evidence) ||
          !has_role(MetricSupportRoleV1::response_order_evidence) ||
          (clause.result_scope == MetricResultScopeV1::physical_bound &&
           !has_role(MetricSupportRoleV1::physical_transfer_evidence))) {
        return fail<ValidatedMetricSupportManifest>(
            "c15.response_envelope_route_mismatch",
            "response-envelope payload requires the one closed scalar backlog-conditioned analytic route and its exact bound/order/transfer role floor",
            path);
      }
    }
    if (clause.payload_class != descriptor.payload_class ||
        clause.semantic != descriptor.semantic ||
        clause.runtime_access != descriptor.runtime_access ||
        !coupling_satisfies(descriptor.target_coupling,
                            clause.target_coupling)) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.manifest_route_mismatch",
          "manifest clause changes the descriptor payload/semantic/access/coupling route",
          path);
    }
    const bool targets_covered =
        clause.target_coupling == TargetCouplingV1::scalar_target
            ? clause.ordered_targets.size() == 1U &&
                  vector_contains(descriptor.deployed_targets,
                                  clause.ordered_targets.front())
            : clause.ordered_targets == descriptor.deployed_targets;
    if (!targets_covered) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.manifest_target_mismatch",
          "manifest clause target is not a deployed descriptor target",
          path + "/ordered_targets");
    }
    if (!std::all_of(clause.state_fields.begin(), clause.state_fields.end(),
                     [&descriptor](const StateFieldDescriptorV1& field) {
                       return vector_contains(descriptor.state_fields, field);
                     }) ||
        !std::all_of(clause.marks.begin(), clause.marks.end(),
                     [&descriptor](const MarkDescriptorV1& mark) {
                       return vector_contains(descriptor.marks, mark);
                     }) ||
        !std::all_of(clause.selection_domain.kinds.begin(),
                     clause.selection_domain.kinds.end(),
                     [&descriptor](const SelectionKindV1 selection) {
                       return vector_contains(descriptor.selection.kinds,
                                              selection);
                     }) ||
        !std::all_of(
            clause.selection_domain.named_classes.begin(),
            clause.selection_domain.named_classes.end(),
            [&descriptor](const TypedLabel& value) {
              return vector_contains(descriptor.selection.named_classes,
                                     value);
            }) ||
        !std::all_of(
            clause.selection_domain.named_fixed_points.begin(),
            clause.selection_domain.named_fixed_points.end(),
            [&descriptor](const TypedLabel& value) {
              return vector_contains(
                  descriptor.selection.named_fixed_points, value);
            }) ||
        !assumptions_cover(descriptor.arrival_assumptions,
                           clause.arrival_assumptions) ||
        !std::all_of(clause.hypotheses.begin(), clause.hypotheses.end(),
                     [&descriptor](const HypothesisClaimV1& hypothesis) {
                       return std::any_of(
                           descriptor.hypothesis_claims.begin(),
                           descriptor.hypothesis_claims.end(),
                           [&hypothesis](const HypothesisClaimV1& offered) {
                             return hypothesis_satisfies(offered,
                                                         hypothesis);
                           });
                     }) ||
        !accuracy_supports(descriptor.accuracy_support,
                           clause.requested_accuracy) ||
        clause.mandatory_v0 != descriptor.mandatory_v0) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.manifest_descriptor_ceiling",
          "manifest clause exceeds a state/mark/selection/arrival/hypothesis/accuracy/V0 descriptor ceiling",
          path);
    }
    if (!result_scope_covered(descriptor.construction_scope.result_scope,
                              clause.result_scope) ||
        !evidence_scope_covered(available_evidence,
                                clause.error_promise.scope)) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.manifest_scope_promotion",
          "manifest result or evidence scope exceeds the descriptor construction scope",
          path + "/result_scope");
    }
    if (!phase_support_envelops(descriptor.phase, clause.phase_domain)) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.manifest_phase_mismatch",
          "manifest payload phase differs from the deployed descriptor",
          path + "/phase_domain");
    }
    if (clause.result_scope == MetricResultScopeV1::physical_bound &&
        std::none_of(
            clause.required_roles.begin(), clause.required_roles.end(),
            [](const MetricSupportRoleRequirementV1& requirement) {
              return requirement.role ==
                     MetricSupportRoleV1::physical_transfer_evidence;
            })) {
      return fail<ValidatedMetricSupportManifest>(
          "c15.physical_scope_without_transfer",
          "physical-bound clause requires an explicit physical-transfer evidence role",
          path + "/required_roles");
    }
    for (std::size_t role_index = 0U;
         role_index < clause.required_roles.size(); ++role_index) {
      if (!payload_has_role(payload, clause,
                            clause.required_roles[role_index], descriptor)) {
        return fail<ValidatedMetricSupportManifest>(
            "c15.payload_role_unavailable",
            "the selected payload cannot structurally realize a required metric role",
            path + "/required_roles/" + std::to_string(role_index));
      }
    }
  }
  return Result<ValidatedMetricSupportManifest>::success(
      ValidatedMetricSupportManifest(manifest));
}

namespace {

[[nodiscard]] const ResultEnvelopeV1& result_envelope_v1(
    const SurrogateBuildResult& result) {
  return std::visit(
      [](const auto& branch) -> const ResultEnvelopeV1& {
        return branch.envelope;
      },
      result);
}

[[nodiscard]] bool response_versions_are_v1(
    const ThreeBinScalarResponseV1& response) {
  return response.payload_version == kProtocolVersion &&
         std::all_of(
             response.raw_response.identifications.begin(),
             response.raw_response.identifications.end(),
             [](const CoefficientIdentificationV1& identification) {
               return identification.provider_conformance_report_ref
                          .report_schema_version == kProtocolVersion;
             });
}

[[nodiscard]] Result<void> validate_result_version_preflight_v1(
    const SurrogateBuildResult& result) {
  const auto& envelope = result_envelope_v1(result);
  if (envelope.protocol_version != kProtocolVersion) {
    return fail<void>("c15.result_protocol_version",
                      "result protocol version must equal one",
                      "/result/envelope/protocol_version");
  }

  const auto* built = std::get_if<BuiltSurrogateResultV1>(&result);
  if (built == nullptr) return Result<void>::success();
  const auto& artifact = built->artifact;
  const bool payload_versions_closed = std::visit(
      [](const auto& payload) {
        using Payload = std::decay_t<decltype(payload)>;
        if (payload.payload_version != kProtocolVersion) return false;
        if constexpr (std::same_as<Payload, ThreeBinScalarResponseV1>) {
          return response_versions_are_v1(payload);
        } else if constexpr (std::same_as<
                                 Payload,
                                 FinitePrefixConstantTailResponseV1>) {
          return std::all_of(
              payload.raw_response.identifications.begin(),
              payload.raw_response.identifications.end(),
              [](const FinitePrefixCoefficientIdentificationV1& value) {
                return value.provider_conformance_report_ref
                           .report_schema_version == kProtocolVersion;
              });
        } else if constexpr (std::same_as<Payload, FiniteLawTablesV1>) {
          return std::visit(
              [](const auto& table) {
                return table.table_schema_version == kProtocolVersion;
              },
              payload.table);
        } else if constexpr (
            std::same_as<Payload, ResponseEnvelopeEvidenceV1>) {
          return response_versions_are_v1(payload.lower_response) &&
                 response_versions_are_v1(payload.upper_response);
        } else {
          return true;
        }
      },
      artifact.payload);
  const bool family_versions_closed = std::all_of(
      artifact.family_evidence.begin(), artifact.family_evidence.end(),
      [](const FamilyEvidenceEnvelopeV1& evidence) {
        return evidence.envelope_version == kProtocolVersion &&
               evidence.provider_conformance_report_ref
                       .report_schema_version == kProtocolVersion;
      });
  const bool diagnostic_versions_closed = std::all_of(
      artifact.diagnostic_components.begin(),
      artifact.diagnostic_components.end(),
      [](const ArtifactDiagnosticComponentV1& diagnostic) {
        return diagnostic.diagnostic_schema_version == kProtocolVersion;
      });
  if (artifact.artifact_protocol_version != kProtocolVersion ||
      artifact.payload_class.version != kProtocolVersion ||
      artifact.structural_manifest_echo.schema_version != kProtocolVersion ||
      artifact.deployed_descriptor.schema_version != kProtocolVersion ||
      artifact.deployed_descriptor.payload_class.version != kProtocolVersion ||
      !payload_versions_closed || !family_versions_closed ||
      !diagnostic_versions_closed) {
    return fail<void>(
        "c15.built_version",
        "built artifact and every C15-owned nested schema must use closed version one",
        "/result/artifact");
  }
  return Result<void>::success();
}

[[nodiscard]] ExactRational exact_scalar_value(
    const PortableScientificScalar& value) {
  return value.kind() == PortableScientificScalarKind::rational
             ? value.rational_value()
             : binary64_as_exact_rational(value);
}

[[nodiscard]] bool scalar_is_nonnegative(
    const PortableScientificScalar& value) {
  return exact_scalar_value(value).is_nonnegative();
}

[[nodiscard]] bool scalar_is_probability(
    const PortableScientificScalar& value) {
  const ExactRational exact = exact_scalar_value(value);
  return exact.is_nonnegative() && exact <= ExactRational::one();
}

[[nodiscard]] bool portable_value_is_nonnegative(
    const PortableValueV1& value) {
  return std::visit(
      [](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, PortableScientificScalar>) {
          return scalar_is_nonnegative(active);
        } else {
          return std::all_of(active.begin(), active.end(),
                             scalar_is_nonnegative);
        }
      },
      value);
}

[[nodiscard]] bool portable_value_is_nonempty(
    const PortableValueV1& value) {
  return std::visit(
      [](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, PortableScientificScalar>) {
          return true;
        } else {
          return !active.empty();
        }
      },
      value);
}

[[nodiscard]] bool digest_is_nonzero_v1(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

template <typename T>
[[nodiscard]] bool duplicate_free(const std::vector<T>& values) {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    for (std::size_t right = left + 1U; right < values.size(); ++right) {
      if (values[left] == values[right]) return false;
    }
  }
  return true;
}

[[nodiscard]] bool closed_enum_v1(const ThreeBinCoefficientV1 value) {
  switch (value) {
    case ThreeBinCoefficientV1::one:
    case ThreeBinCoefficientV1::two:
    case ThreeBinCoefficientV1::tail_from_three: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(const ProposalConditioningSourceV1 value) {
  switch (value) {
    case ProposalConditioningSourceV1::exact_population:
    case ProposalConditioningSourceV1::empirical_average: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(
    const PopulationConditioningStatusV1 value) {
  switch (value) {
    case PopulationConditioningStatusV1::proved_positive:
    case PopulationConditioningStatusV1::proved_zero:
    case PopulationConditioningStatusV1::positive_with_confidence:
    case PopulationConditioningStatusV1::unresolved: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(const RawValueStatusV1 value) {
  switch (value) {
    case RawValueStatusV1::exact_point:
    case RawValueStatusV1::interval_only:
    case RawValueStatusV1::absent: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(const ProjectionCenterSourceKindV1 value) {
  switch (value) {
    case ProjectionCenterSourceKindV1::decoded_raw_response:
    case ProjectionCenterSourceKindV1::synthetic_snapshot_mean:
    case ProjectionCenterSourceKindV1::explicit_fallback: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(const ProductDerivationKindV1 value) {
  switch (value) {
    case ProductDerivationKindV1::nominal_completion:
    case ProductDerivationKindV1::admissibility_projection:
    case ProductDerivationKindV1::identity_recoding:
    case ProductDerivationKindV1::mean_inversion_recoding:
    case ProductDerivationKindV1::endpoint_completion: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(const RawEnvelopeScopeV1 value) {
  switch (value) {
    case RawEnvelopeScopeV1::proposal_raw:
    case RawEnvelopeScopeV1::optimizer_interval_raw:
    case RawEnvelopeScopeV1::deterministic_quadrature_raw:
    case RawEnvelopeScopeV1::physical_response_bound: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(const RawEnvelopeCoverageV1 value) {
  switch (value) {
    case RawEnvelopeCoverageV1::deterministic:
    case RawEnvelopeCoverageV1::marginal:
    case RawEnvelopeCoverageV1::simultaneous: return true;
  }
  return false;
}

[[nodiscard]] bool closed_enum_v1(
    const PopulationConditioningPremiseV1 value) {
  switch (value) {
    case PopulationConditioningPremiseV1::unconditional:
    case PopulationConditioningPremiseV1::
        conditional_on_population_positivity: return true;
  }
  return false;
}

[[nodiscard]] const FamilyEvidenceEnvelopeV1* find_family_evidence_v1(
    const SurrogateArtifactV1& artifact,
    const ArtifactObjectReferenceV1& identity) {
  const auto iterator = std::find_if(
      artifact.family_evidence.begin(), artifact.family_evidence.end(),
      [&identity](const FamilyEvidenceEnvelopeV1& evidence) {
        return evidence.evidence_id == identity;
      });
  return iterator == artifact.family_evidence.end() ? nullptr : &*iterator;
}

[[nodiscard]] MetricEvidenceScopeV1 evidence_scope_for_raw_envelope_v1(
    const RawEnvelopeScopeV1 scope) {
  switch (scope) {
    case RawEnvelopeScopeV1::proposal_raw:
    case RawEnvelopeScopeV1::deterministic_quadrature_raw:
      return MetricEvidenceScopeV1::raw_static_proposal;
    case RawEnvelopeScopeV1::optimizer_interval_raw:
      return MetricEvidenceScopeV1::optimizer_interval_raw;
    case RawEnvelopeScopeV1::physical_response_bound:
      return MetricEvidenceScopeV1::physical_system;
  }
  return MetricEvidenceScopeV1::none;
}

[[nodiscard]] Result<void> validate_coefficient_conformance_reference_v1(
    const ProviderConformanceReportRef& reference,
    const ValidatedProviderManifest& validated_manifest,
    const std::string& path) {
  const auto& manifest = validated_manifest.value();
  const auto matches_schema = [&](const FamilyEvidenceSchemaV1& schema) {
    return schema.schema_id == reference.family_evidence_schema_id &&
           schema.schema_version == reference.family_evidence_schema_version;
  };
  const auto matches_anchor =
      [&](const FamilyEvidenceConformanceReportAnchorV1& anchor) {
        return anchor.family_evidence_schema_id ==
                   reference.family_evidence_schema_id &&
               anchor.family_evidence_schema_version ==
                   reference.family_evidence_schema_version;
      };
  const auto schema = std::find_if(
      manifest.allowed_family_evidence_schemas.begin(),
      manifest.allowed_family_evidence_schemas.end(), matches_schema);
  const auto anchor = std::find_if(
      manifest.family_evidence_conformance_report_anchors.begin(),
      manifest.family_evidence_conformance_report_anchors.end(),
      matches_anchor);
  if (schema == manifest.allowed_family_evidence_schemas.end() ||
      std::count_if(manifest.allowed_family_evidence_schemas.begin(),
                    manifest.allowed_family_evidence_schemas.end(),
                    matches_schema) != 1 ||
      anchor == manifest.family_evidence_conformance_report_anchors.end() ||
      std::count_if(
          manifest.family_evidence_conformance_report_anchors.begin(),
          manifest.family_evidence_conformance_report_anchors.end(),
          matches_anchor) != 1 ||
      reference.report_schema_version != kProtocolVersion ||
      reference.report_schema_version != anchor->report_schema_version ||
      reference.report_id != anchor->report_id ||
      reference.report_digest != anchor->report_digest ||
      reference.provider != manifest.provider ||
      reference.provider_scientific_contract_digest !=
          validated_manifest.scientific_contract_digest().value()) {
    return fail<void>(
        "c15.coefficient_conformance_reference_mismatch",
        "coefficient conformance reference does not exactly match its trusted full-manifest family-schema anchor",
        path);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_raw_envelope_v1(
    const RawResponseEnvelopeV1& envelope,
    const RawResponseProductV1& raw, const SurrogateArtifactV1& artifact,
    const std::string& path) {
  auto digest = artifact::detail::raw_response_envelope_digest_v1(envelope);
  if (!digest || digest.value() != envelope.envelope_id.object_digest ||
      envelope.source_product != raw.product_id ||
      envelope.construction_law_digest != raw.proposal_law_digest ||
      !closed_enum_v1(envelope.coverage) ||
      !closed_enum_v1(envelope.population_conditioning_premise) ||
      !closed_enum_v1(envelope.scope) ||
      envelope.covered_bins.empty() ||
      envelope.covered_bins.size() != envelope.lower.size() ||
      envelope.lower.size() != envelope.upper.size() ||
      !duplicate_free(envelope.covered_bins) ||
      envelope.certification_method.empty() ||
      envelope.family_evidence_envelope_ids.empty() ||
      !duplicate_free(envelope.family_evidence_envelope_ids) ||
      !std::is_sorted(envelope.family_evidence_envelope_ids.begin(),
                      envelope.family_evidence_envelope_ids.end())) {
    return fail<void>("c15.raw_envelope_shape",
                      "raw envelope has a stale identity or mismatched source/domain cardinality",
                      path);
  }
  for (std::size_t index = 0U; index < envelope.covered_bins.size(); ++index) {
    const auto bin_rank =
        static_cast<std::size_t>(envelope.covered_bins[index]);
    if (!closed_enum_v1(envelope.covered_bins[index]) ||
        bin_rank >= raw.identifications.size() ||
        raw.identifications[bin_rank]
                .coefficient_status.raw_value_status ==
            RawValueStatusV1::absent ||
        (index != 0U &&
         static_cast<std::uint8_t>(envelope.covered_bins[index - 1U]) >=
             static_cast<std::uint8_t>(envelope.covered_bins[index])) ||
        !scalar_is_probability(envelope.lower[index]) ||
        !scalar_is_probability(envelope.upper[index]) ||
        exact_scalar_value(envelope.lower[index]) >
            exact_scalar_value(envelope.upper[index])) {
      return fail<void>("c15.raw_envelope_domain",
                        "raw envelope bins must be canonical non-absent origins and bounds must be ordered in [0,1]",
                        path + "/lower/" + std::to_string(index));
    }
    const auto& identification = raw.identifications[bin_rank];
    if (identification.raw_point.has_value()) {
      const auto point = exact_scalar_value(*identification.raw_point);
      if (point < exact_scalar_value(envelope.lower[index]) ||
          exact_scalar_value(envelope.upper[index]) < point) {
        return fail<void>(
            "c15.raw_envelope_excludes_exact_point",
            "raw envelope bounds must contain the retained exact raw point",
            path + "/lower/" + std::to_string(index));
      }
    }
    if (identification.coefficient_status.population_conditioning_status ==
            PopulationConditioningStatusV1::unresolved &&
        identification.coefficient_status.raw_value_status ==
            RawValueStatusV1::interval_only &&
        envelope.population_conditioning_premise !=
            PopulationConditioningPremiseV1::
                conditional_on_population_positivity) {
      return fail<void>(
          "c15.unresolved_raw_envelope_premise",
          "every raw envelope covering an unresolved interval-only origin must be conditional on population positivity",
          path + "/population_conditioning_premise");
    }
  }
  if (envelope.sample_size.has_value() && envelope.sample_size->is_zero()) {
    return fail<void>("c15.raw_envelope_sample_size",
                      "present envelope sample size must be positive",
                      path + "/sample_size");
  }
  if (envelope.frozen_evaluation_id.has_value() !=
          envelope.sample_size.has_value() ||
      ((envelope.coverage == RawEnvelopeCoverageV1::marginal ||
        envelope.coverage == RawEnvelopeCoverageV1::simultaneous) &&
       !envelope.frozen_evaluation_id.has_value())) {
    return fail<void>("c15.raw_envelope_evaluation_binding",
                      "a raw envelope's frozen evaluation and sample size must be present together",
                      path);
  }
  for (const auto& evidence_id : envelope.family_evidence_envelope_ids) {
    const auto* evidence = find_family_evidence_v1(artifact, evidence_id);
    if (evidence == nullptr ||
        evidence->evidence_scope_tag !=
            evidence_scope_for_raw_envelope_v1(envelope.scope) ||
        !vector_contains(evidence->parent_references,
                         raw.product_id.identity())) {
      return fail<void>("c15.raw_envelope_family_reference",
                        "raw envelope family evidence does not carry the matching scope and raw lineage parent",
                        path + "/family_evidence_envelope_ids");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_identification_v1(
    const CoefficientIdentificationV1& identification,
    const ThreeBinCoefficientV1 expected_bin,
    const ThreeBinScalarResponseV1& response,
    const SurrogateArtifactV1& artifact,
    const ValidatedProviderManifest& manifest, const std::string& path) {
  auto digest = artifact::detail::coefficient_identification_digest_v1(
      identification);
  if (!digest || digest.value() != identification.coefficient_id.object_digest ||
      !closed_enum_v1(expected_bin) ||
      identification.target_bin_binding != expected_bin ||
      !closed_enum_v1(identification.target_bin_binding) ||
      !closed_enum_v1(identification.proposal_conditioning.source) ||
      !closed_enum_v1(
          identification.coefficient_status.population_conditioning_status) ||
      !closed_enum_v1(identification.coefficient_status.raw_value_status) ||
      !scalar_is_nonnegative(
          identification.proposal_conditioning.observed_nonnegative_value) ||
      !duplicate_free(identification.family_evidence_envelope_ids) ||
      !std::is_sorted(identification.family_evidence_envelope_ids.begin(),
                      identification.family_evidence_envelope_ids.end())) {
    return fail<void>("c15.coefficient_identity_or_domain",
                      "coefficient identification has a stale identity, bin, or nonnegative observation",
                      path);
  }
  auto conformance = validate_coefficient_conformance_reference_v1(
      identification.provider_conformance_report_ref, manifest,
      path + "/provider_conformance_report_ref");
  if (!conformance) return conformance;
  for (const auto& evidence_id :
       identification.family_evidence_envelope_ids) {
    const auto* evidence = find_family_evidence_v1(artifact, evidence_id);
    if (evidence == nullptr ||
        evidence->provider_conformance_report_ref !=
            identification.provider_conformance_report_ref ||
        !vector_contains(evidence->subject_references,
                         identification.coefficient_id)) {
      return fail<void>("c15.coefficient_family_reference",
                        "coefficient family evidence does not bind the identification and conformance report",
                        path + "/family_evidence_envelope_ids");
    }
  }

  const auto source = identification.proposal_conditioning.source;
  const auto population =
      identification.coefficient_status.population_conditioning_status;
  const auto raw = identification.coefficient_status.raw_value_status;
  const bool has_point = identification.raw_point.has_value();
  const bool has_frozen_evaluation =
      identification.proposal_conditioning.frozen_evaluation_id.has_value();
  if ((source == ProposalConditioningSourceV1::empirical_average) !=
      has_frozen_evaluation) {
    return fail<void>(
        "c15.coefficient_frozen_evaluation_binding",
        "empirical conditioning requires one frozen evaluation and exact-population conditioning forbids it",
        path + "/proposal_conditioning/frozen_evaluation_id");
  }
  const bool exact_point =
      source == ProposalConditioningSourceV1::exact_population &&
      population == PopulationConditioningStatusV1::proved_positive &&
      raw == RawValueStatusV1::exact_point && has_point &&
      scalar_is_probability(*identification.raw_point);
  const bool exact_interval =
      source == ProposalConditioningSourceV1::exact_population &&
      population == PopulationConditioningStatusV1::proved_positive &&
      raw == RawValueStatusV1::interval_only && !has_point;
  const bool empirical_interval =
      source == ProposalConditioningSourceV1::empirical_average &&
      population ==
          PopulationConditioningStatusV1::positive_with_confidence &&
      raw == RawValueStatusV1::interval_only && !has_point &&
      identification.proposal_conditioning.frozen_evaluation_id.has_value();
  const bool unresolved_interval =
      population == PopulationConditioningStatusV1::unresolved &&
      raw == RawValueStatusV1::interval_only && !has_point;
  const bool proved_zero_absent =
      source == ProposalConditioningSourceV1::exact_population &&
      population == PopulationConditioningStatusV1::proved_zero &&
      raw == RawValueStatusV1::absent && !has_point;
  const bool unresolved_absent =
      population == PopulationConditioningStatusV1::unresolved &&
      raw == RawValueStatusV1::absent && !has_point;
  if (!(exact_point || exact_interval || empirical_interval ||
        unresolved_interval || proved_zero_absent || unresolved_absent)) {
    return fail<void>("c15.coefficient_status_combination",
                      "coefficient source/status/value-presence combination is not one of the six closed v1 cases",
                      path + "/coefficient_status");
  }
  if (raw == RawValueStatusV1::interval_only) {
    const bool has_matching_envelope = std::any_of(
        response.raw_envelopes.begin(), response.raw_envelopes.end(),
        [&](const RawResponseEnvelopeV1& envelope) {
          return vector_contains(envelope.covered_bins, expected_bin) &&
                 !identification.family_evidence_envelope_ids.empty() &&
                 std::all_of(
                     identification.family_evidence_envelope_ids.begin(),
                     identification.family_evidence_envelope_ids.end(),
                     [&](const ArtifactObjectReferenceV1& evidence_id) {
                       return vector_contains(
                                  envelope.family_evidence_envelope_ids,
                                  evidence_id) &&
                              find_family_evidence_v1(artifact, evidence_id) !=
                                  nullptr;
                     }) &&
                 (!unresolved_interval ||
                  envelope.population_conditioning_premise ==
                      PopulationConditioningPremiseV1::
                          conditional_on_population_positivity) &&
                 (source != ProposalConditioningSourceV1::empirical_average ||
                  (envelope.frozen_evaluation_id ==
                       identification.proposal_conditioning
                           .frozen_evaluation_id &&
                   envelope.coverage !=
                       RawEnvelopeCoverageV1::deterministic));
        });
    if (!has_matching_envelope) {
      return fail<void>("c15.interval_without_bound_evidence",
                        "interval-only coefficient lacks a matching scoped raw envelope and family evidence",
                        path + "/family_evidence_envelope_ids");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool coefficients_match_origins_v1(
    const ResponseCoefficientTripleV1& coefficients,
    const RawResponseProductV1& raw) {
  for (std::size_t index = 0U; index < coefficients.size(); ++index) {
    if (static_cast<std::uint8_t>(coefficients[index].bin) != index ||
        coefficients[index].origin_coefficient_id !=
            raw.identifications[index].coefficient_id ||
        !scalar_is_probability(coefficients[index].value)) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] Result<void> validate_three_bin_v1(
    const ThreeBinScalarResponseV1& response,
    const SurrogateArtifactV1& artifact, const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& contract,
    const std::string& path,
    const bool enforce_deployment_policies = true) {
  const auto& raw = response.raw_response;
  const auto& provider = manifest.value().provider;
  // The compact factorized Full Orbit route binds its scientific response to
  // the canonical configured law.  Archived expanded CP05/early-CP06
  // requests and other v1 ThreeBin fixture providers keep their historical
  // compiled-view binding.
  const bool compact_full_orbit =
      provider.provider_id == "full_orbit_framework_sampler" &&
      request.framework_problem_view()
          .configured_arrival()
          .capabilities()
          .exact_factorized_iid_generator.has_value();
  const Digest256& arrival =
      compact_full_orbit
          ? request.framework_problem_view()
                .configured_arrival()
                .binding()
                .law_digest
                .value()
          : request.framework_problem_view().fingerprints().compiled_arrival;
  auto raw_digest = canonical_raw_response_product_digest_v1(raw);
  auto row_digest = canonical_three_bin_response_row_digest_v1(response);
  if (response.payload_version != kProtocolVersion ||
      response.deployed_target !=
          request.framework_problem_view().target_selection().ordered_targets.front() ||
      response.configured_arrival_binding != arrival ||
      raw.provider != provider ||
      raw.request_digest != request.request_digest().value() ||
      raw.deployed_target != response.deployed_target ||
      raw.configured_arrival_binding != arrival ||
      raw.identifications.size() != 3U ||
      !raw_digest ||
      raw_digest.value() != raw.product_id.identity().object_digest ||
      !row_digest ||
      row_digest.value() != response.response_row_id.object_digest) {
    return fail<void>("c15.three_bin_binding",
                      "three-bin row or raw product has a stale request/provider/target/arrival/content identity",
                      path);
  }
  for (std::size_t index = 0U; index < raw.identifications.size(); ++index) {
    auto identification = validate_identification_v1(
        raw.identifications[index],
        static_cast<ThreeBinCoefficientV1>(index), response, artifact,
        manifest, path + "/raw_response/identifications/" +
                      std::to_string(index));
    if (!identification) return identification;
  }
  if (!duplicate_free(response.raw_envelopes)) {
    return fail<void>("c15.raw_envelope_duplicate",
                      "raw envelope records must be unique",
                      path + "/raw_envelopes");
  }
  if (!std::is_sorted(
          response.raw_envelopes.begin(), response.raw_envelopes.end(),
          [](const RawResponseEnvelopeV1& left,
             const RawResponseEnvelopeV1& right) {
            return left.envelope_id < right.envelope_id;
          })) {
    return fail<void>("c15.raw_envelope_order",
                      "raw envelope records must be canonically ordered by identity",
                      path + "/raw_envelopes");
  }
  std::vector<ArtifactObjectReferenceV1> envelope_ids;
  for (std::size_t index = 0U; index < response.raw_envelopes.size(); ++index) {
    auto envelope = validate_raw_envelope_v1(
        response.raw_envelopes[index], raw, artifact,
        path + "/raw_envelopes/" + std::to_string(index));
    if (!envelope) return envelope;
    if (vector_contains(envelope_ids,
                        response.raw_envelopes[index].envelope_id)) {
      return fail<void>("c15.raw_envelope_identity_duplicate",
                        "raw envelope identities must be unique",
                        path + "/raw_envelopes/" + std::to_string(index) +
                            "/envelope_id");
    }
    envelope_ids.push_back(response.raw_envelopes[index].envelope_id);
  }
  for (const auto bin : {ThreeBinCoefficientV1::one,
                         ThreeBinCoefficientV1::two,
                         ThreeBinCoefficientV1::tail_from_three}) {
    const auto covering = std::count_if(
        response.raw_envelopes.begin(), response.raw_envelopes.end(),
        [bin](const RawResponseEnvelopeV1& envelope) {
          return vector_contains(envelope.covered_bins, bin);
        });
    const auto& identification =
        raw.identifications[static_cast<std::size_t>(bin)];
    const bool interval =
        identification.coefficient_status.raw_value_status ==
        RawValueStatusV1::interval_only;
    if (interval && covering == 0) {
      return fail<void>(
          "c15.raw_envelope_missing_coverage",
          "each interval-only coefficient must have at least one independently valid matching raw envelope",
          path + "/raw_envelopes");
    }
  }

  const std::vector<QueueId> construction_targets(
      contract.construction_target_scope().begin(),
      contract.construction_target_scope().end());
  const bool has_missing_origin = std::any_of(
      raw.identifications.begin(), raw.identifications.end(),
      [](const CoefficientIdentificationV1& item) {
        return item.coefficient_status.population_conditioning_status ==
                   PopulationConditioningStatusV1::proved_zero ||
               item.coefficient_status.population_conditioning_status ==
                   PopulationConditioningStatusV1::unresolved;
      });
  const bool has_nonpoint_origin = std::any_of(
      raw.identifications.begin(), raw.identifications.end(),
      [](const CoefficientIdentificationV1& item) {
        return item.coefficient_status.raw_value_status !=
               RawValueStatusV1::exact_point;
      });
  const bool raw_is_point_product = response_all_raw_points(response);
  if (response.nominal_response.has_value()) {
    const auto& nominal = *response.nominal_response;
    auto digest = canonical_nominal_response_product_digest_v1(nominal);
    if (!digest || digest.value() != nominal.product_id.identity().object_digest ||
        nominal.provider != provider ||
        nominal.request_digest != request.request_digest().value() ||
        nominal.deployed_target != response.deployed_target ||
        nominal.raw_parent != raw.product_id ||
        !coefficients_match_origins_v1(nominal.coefficients, raw) ||
        (has_nonpoint_origin && !nominal.completion_policy_id.has_value()) ||
        (enforce_deployment_policies &&
         (contract.policies().coefficient_completion ==
              CoefficientCompletionPolicyV1::declared_nominal_completion ||
          contract.policies().coefficient_completion ==
              CoefficientCompletionPolicyV1::
                  authorized_endpoint_completion) &&
         !nominal.completion_policy_id.has_value()) ||
        (enforce_deployment_policies &&
         nominal.completion_policy_id.has_value() &&
         contract.policies().coefficient_completion ==
             CoefficientCompletionPolicyV1::not_applicable)) {
      return fail<void>("c15.nominal_product_binding",
                        "nominal response product has an invalid identity, parent, coefficients, or completion lineage",
                        path + "/nominal_response");
    }
  }
  if (response.projection_center.has_value()) {
    const auto& center = *response.projection_center;
    auto digest = canonical_projection_center_product_digest_v1(center);
    const bool source_exists = std::visit(
        [&](const auto& source) {
          using Source = std::decay_t<decltype(source)>;
          if constexpr (std::same_as<Source, RawResponseProductId>) {
            return source == raw.product_id;
          } else {
            return response.nominal_response.has_value() &&
                   source == response.nominal_response->product_id;
          }
        },
        center.response_source);
    if (!digest || digest.value() != center.product_id.identity().object_digest ||
        !closed_enum_v1(center.source_kind) ||
        center.provider != provider ||
        center.request_digest != request.request_digest().value() ||
        center.ordered_construction_targets != construction_targets ||
        center.deployed_target != response.deployed_target || !source_exists ||
        (center.source_kind ==
             ProjectionCenterSourceKindV1::decoded_raw_response &&
         (!std::holds_alternative<RawResponseProductId>(
              center.response_source) ||
          !raw_is_point_product)) ||
        (center.source_kind ==
             ProjectionCenterSourceKindV1::explicit_fallback &&
         !center.completion_policy_id.has_value()) ||
        (has_missing_origin && !center.completion_policy_id.has_value()) ||
        (enforce_deployment_policies &&
         center.completion_policy_id.has_value() &&
         contract.policies().coefficient_completion ==
             CoefficientCompletionPolicyV1::not_applicable) ||
        center.mean_vector.size() != construction_targets.size() ||
        !std::all_of(center.mean_vector.begin(), center.mean_vector.end(),
                     scalar_is_probability)) {
      return fail<void>("c15.projection_center_binding",
                        "projection-center product has an invalid identity, source, target closure, or mean domain",
                        path + "/projection_center");
    }
  }
  if (response.projected_mean.has_value()) {
    const auto& mean = *response.projected_mean;
    auto digest = canonical_projected_mean_product_digest_v1(mean);
    if (!response.projection_center.has_value() || !digest ||
        digest.value() != mean.product_id.identity().object_digest ||
        mean.provider != provider ||
        mean.request_digest != request.request_digest().value() ||
        mean.ordered_construction_targets != construction_targets ||
        mean.deployed_target != response.deployed_target ||
        mean.center_parent != response.projection_center->product_id ||
        mean.mean_vector.size() != construction_targets.size() ||
        !std::all_of(mean.mean_vector.begin(), mean.mean_vector.end(),
                     scalar_is_probability)) {
      return fail<void>("c15.projected_mean_binding",
                        "projected-mean product has an invalid identity, center parent, target closure, or mean domain",
                        path + "/projected_mean");
    }
  }
  if (response.recoded_response.has_value()) {
    const auto& recoded = *response.recoded_response;
    auto digest = canonical_recoded_response_product_digest_v1(recoded);
    const bool mean_parent =
        !recoded.projected_mean_parent.has_value() ||
        (response.projected_mean.has_value() &&
         *recoded.projected_mean_parent ==
             response.projected_mean->product_id);
    const bool reference_parent = std::visit(
        [&](const auto& parent) {
          using Parent = std::decay_t<decltype(parent)>;
          if constexpr (std::same_as<Parent, std::monostate>) {
            return true;
          } else if constexpr (std::same_as<Parent, RawResponseProductId>) {
            return parent == raw.product_id && raw_is_point_product;
          } else {
            return response.nominal_response.has_value() &&
                   parent == response.nominal_response->product_id;
          }
        },
        recoded.reference_response_parent);
    const bool has_reference_parent =
        !std::holds_alternative<std::monostate>(
            recoded.reference_response_parent);
    const bool derivation_shape = [&] {
      switch (recoded.derivation_kind) {
        case ProductDerivationKindV1::identity_recoding:
          return (!enforce_deployment_policies ||
                  contract.policies().recoding == RecodingPolicyV1::identity) &&
                 !recoded.projected_mean_parent.has_value() &&
                 has_reference_parent &&
                 !recoded.completion_policy_id.has_value();
        case ProductDerivationKindV1::mean_inversion_recoding:
          return (!enforce_deployment_policies ||
                  contract.policies().recoding ==
                      RecodingPolicyV1::mean_inversion) &&
                 recoded.projected_mean_parent.has_value() &&
                 has_reference_parent &&
                 !recoded.completion_policy_id.has_value();
        case ProductDerivationKindV1::endpoint_completion:
          return (!enforce_deployment_policies ||
                  (contract.policies().recoding ==
                       RecodingPolicyV1::mean_inversion &&
                   contract.policies().coefficient_completion ==
                       CoefficientCompletionPolicyV1::
                           authorized_endpoint_completion)) &&
                 recoded.completion_policy_id.has_value() &&
                 !recoded.projected_mean_parent.has_value() &&
                 !has_reference_parent;
        case ProductDerivationKindV1::nominal_completion:
        case ProductDerivationKindV1::admissibility_projection: return false;
      }
      return false;
    }();
    if (!digest ||
        digest.value() != recoded.product_id.identity().object_digest ||
        !closed_enum_v1(recoded.derivation_kind) ||
        recoded.provider != provider ||
        recoded.request_digest != request.request_digest().value() ||
        recoded.deployed_target != response.deployed_target ||
        !coefficients_match_origins_v1(recoded.coefficients, raw) ||
        !mean_parent || !reference_parent || !derivation_shape ||
        (enforce_deployment_policies &&
         recoded.completion_policy_id.has_value() &&
         contract.policies().coefficient_completion ==
             CoefficientCompletionPolicyV1::not_applicable)) {
      return fail<void>("c15.recoded_product_binding",
                        "recoded response product has an invalid identity, coefficients, derivation, or parent lineage",
                        path + "/recoded_response");
    }
  }

  const auto& deployed =
      deployed_response_product_identity_v1(
          response.deployed_response_product_id);
  const bool deployed_exists = std::visit(
      [&](const auto& selected) {
        using Selected = std::decay_t<decltype(selected)>;
        if constexpr (std::same_as<Selected, RawResponseProductId>) {
          return selected == raw.product_id && response_all_raw_points(response) &&
                 (!enforce_deployment_policies ||
                  contract.policies().point_deployment ==
                      PointDeploymentPolicyV1::deploy_raw_point);
        } else if constexpr (std::same_as<Selected,
                                          NominalResponseProductId>) {
          return response.nominal_response.has_value() &&
                 selected == response.nominal_response->product_id &&
                 (!enforce_deployment_policies ||
                  contract.policies().point_deployment ==
                      PointDeploymentPolicyV1::deploy_nominal_point);
        } else {
          return response.recoded_response.has_value() &&
                 selected == response.recoded_response->product_id &&
                 (!enforce_deployment_policies ||
                  contract.policies().point_deployment ==
                      PointDeploymentPolicyV1::deploy_recoded_point);
        }
      },
      response.deployed_response_product_id);
  const bool completion_policy_shape = !enforce_deployment_policies || [&] {
    switch (contract.policies().coefficient_completion) {
      case CoefficientCompletionPolicyV1::not_applicable:
        return !has_nonpoint_origin &&
               std::all_of(raw.identifications.begin(),
                           raw.identifications.end(),
                           [](const CoefficientIdentificationV1& item) {
                             return !item.completion_policy_id.has_value();
                           });
      case CoefficientCompletionPolicyV1::require_complete_raw_points:
        return !has_nonpoint_origin && response_all_raw_points(response);
      case CoefficientCompletionPolicyV1::declared_nominal_completion:
        return response.nominal_response.has_value() &&
               (!has_nonpoint_origin ||
                response.nominal_response->completion_policy_id.has_value());
      case CoefficientCompletionPolicyV1::authorized_endpoint_completion:
        return response.recoded_response.has_value() &&
               response.recoded_response->completion_policy_id.has_value();
    }
    return false;
  }();
  const bool projection_policy_shape =
      !enforce_deployment_policies ||
      (contract.policies().projection == ProjectionPolicyV1::not_applicable
          ? !response.projection_center.has_value() &&
                !response.projected_mean.has_value()
          : response.projection_center.has_value() &&
                response.projected_mean.has_value());
  const bool recoding_policy_shape =
      !enforce_deployment_policies ||
      (contract.policies().recoding == RecodingPolicyV1::not_applicable
          ? !response.recoded_response.has_value()
          : response.recoded_response.has_value());
  if (!deployed_exists || !completion_policy_shape ||
      !projection_policy_shape || !recoding_policy_shape ||
      deployed.object_id == response.response_row_id.object_id) {
    return fail<void>("c15.deployed_response_product",
                      "selected response stages are absent, non-point, policy-inconsistent, or alias the row identity",
                      path + "/deployed_response_product_id");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_finite_prefix_constant_tail_v1(
    const FinitePrefixConstantTailResponseV1& response,
    const SurrogateArtifactV1& artifact, const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& contract, const std::string& path) {
  const auto& descriptor = contract.descriptor_core();
  if (descriptor.target_coupling != TargetCouplingV1::scalar_target ||
      descriptor.phase.payload_phase != PayloadPhaseKindV1::phase_free ||
      descriptor.tail.kind != TailRepresentationKindV1::constant_response ||
      !descriptor.tail.boundary.has_value()) {
    return fail<void>(
        "c15.finite_prefix_descriptor_mismatch",
        "finite-prefix response requires a singleton phase-free scalar "
        "constant-tail descriptor",
        "/result/artifact/deployed_descriptor");
  }
  auto descriptor_tail =
      BigNat::from_big_int(descriptor.tail.boundary->value());
  if (!descriptor_tail) return Result<void>::failure(descriptor_tail.error());
  auto shape = artifact::detail::
      validate_finite_prefix_constant_tail_shape_v1(
          response, response.response_cutoff, descriptor_tail.value());
  if (!shape) return shape;

  const auto& raw = response.raw_response;
  const auto& provider = manifest.value().provider;
  const bool compact_full_orbit =
      provider.provider_id == "full_orbit_framework_sampler" &&
      request.framework_problem_view()
          .configured_arrival()
          .capabilities()
          .exact_factorized_iid_generator.has_value();
  const Digest256& arrival =
      compact_full_orbit
          ? request.framework_problem_view()
                .configured_arrival()
                .binding()
                .law_digest
                .value()
          : request.framework_problem_view().fingerprints().compiled_arrival;
  auto raw_digest =
      canonical_finite_prefix_raw_response_product_digest_v1(raw);
  auto row_digest =
      canonical_finite_prefix_constant_tail_response_row_digest_v1(response);
  if (response.deployed_target !=
          request.framework_problem_view()
              .target_selection()
              .ordered_targets.front() ||
      response.configured_arrival_binding != arrival ||
      raw.provider != provider ||
      raw.request_digest != request.request_digest().value() ||
      raw.deployed_target != response.deployed_target ||
      raw.configured_arrival_binding != arrival || !raw_digest ||
      raw_digest.value() != raw.product_id.identity().object_digest ||
      !row_digest ||
      row_digest.value() != response.response_row_id.object_digest ||
      response.response_row_id.object_id ==
          raw.product_id.identity().object_id) {
    return fail<void>(
        "c15.finite_prefix_binding",
        "finite-prefix row or raw product has a stale request, provider, "
        "target, arrival or content identity",
        path);
  }

  if (artifact.family_evidence.size() != 1U) {
    return fail<void>(
        "c15.finite_prefix_family_count",
        "the complete dynamic response requires exactly one family "
        "evidence envelope",
        "/result/artifact/family_evidence");
  }
  const auto& family = artifact.family_evidence.front();
  std::vector<ArtifactObjectReferenceV1> expected_subjects;
  expected_subjects.reserve(raw.identifications.size() + 2U);
  for (std::size_t index = 0U; index < raw.identifications.size(); ++index) {
    const auto& coefficient = raw.identifications[index];
    auto coefficient_digest =
        canonical_finite_prefix_coefficient_identification_digest_v1(
            coefficient);
    auto conformance = validate_coefficient_conformance_reference_v1(
        coefficient.provider_conformance_report_ref, manifest,
        path + "/raw_response/identifications/" +
            std::to_string(index) +
            "/provider_conformance_report_ref");
    if (!coefficient_digest ||
        coefficient_digest.value() != coefficient.coefficient_id.object_digest ||
        !conformance ||
        coefficient.provider_conformance_report_ref !=
            family.provider_conformance_report_ref ||
        coefficient.family_evidence_envelope_ids !=
            std::vector<ArtifactObjectReferenceV1>{family.evidence_id}) {
      if (!conformance) return conformance;
      return fail<void>(
          "c15.finite_prefix_coefficient_binding",
          "dynamic coefficient identity, conformance or family binding is "
          "stale",
          path + "/raw_response/identifications/" +
              std::to_string(index));
    }
    expected_subjects.push_back(coefficient.coefficient_id);
  }

  const auto& envelope = response.raw_envelopes.front();
  auto envelope_digest =
      canonical_finite_prefix_raw_response_envelope_digest_v1(envelope);
  if (!envelope_digest ||
      envelope_digest.value() != envelope.envelope_id.object_digest) {
    return fail<void>("c15.finite_prefix_envelope_identity",
                      "dynamic raw envelope has a stale content identity",
                      path + "/raw_envelopes/0/envelope_id");
  }
  expected_subjects.push_back(envelope.envelope_id);
  expected_subjects.push_back(raw.product_id.identity());
  std::sort(expected_subjects.begin(), expected_subjects.end());
  if (family.subject_references != expected_subjects ||
      family.parent_references !=
          std::vector<ArtifactObjectReferenceV1>{raw.product_id.identity()} ||
      family.evidence_scope_tag !=
          MetricEvidenceScopeV1::raw_static_proposal) {
    return fail<void>(
        "c15.finite_prefix_family_ledger",
        "dynamic family evidence must bind every coefficient and envelope "
        "to the exact raw parent",
        "/result/artifact/family_evidence/0");
  }
  auto family_body = artifact::detail::
      validate_finite_prefix_constant_tail_family_evidence_v1(
          response, artifact.family_evidence);
  if (!family_body) return family_body;

  if (contract.policies().point_deployment !=
          PointDeploymentPolicyV1::deploy_raw_point ||
      contract.policies().coefficient_completion !=
          CoefficientCompletionPolicyV1::require_complete_raw_points ||
      contract.policies().projection != ProjectionPolicyV1::not_applicable ||
      contract.policies().recoding != RecodingPolicyV1::not_applicable) {
    return fail<void>(
        "c15.finite_prefix_deployment_policy",
        "the complete dynamic Built response must deploy its raw point "
        "product without completion, projection or recoding",
        path + "/deployed_response_product_id");
  }
  return Result<void>::success();
}

[[nodiscard]] const PortableFiniteDictionaryEntryV1* dictionary_entry_v1(
    const std::vector<PortableFiniteDictionaryEntryV1>& dictionary,
    const TypedLabel& id) {
  const auto iterator = std::find_if(
      dictionary.begin(), dictionary.end(),
      [&id](const PortableFiniteDictionaryEntryV1& entry) {
        return entry.id == id;
      });
  return iterator == dictionary.end() ? nullptr : &*iterator;
}

[[nodiscard]] bool dictionary_is_canonical_v1(
    const std::vector<PortableFiniteDictionaryEntryV1>& dictionary) {
  if (dictionary.empty()) return false;
  for (std::size_t index = 0U; index < dictionary.size(); ++index) {
    if (index != 0U && !(dictionary[index - 1U].id < dictionary[index].id)) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] std::vector<TypedLabel> dictionary_ids_v1(
    const std::vector<PortableFiniteDictionaryEntryV1>& dictionary) {
  std::vector<TypedLabel> result;
  result.reserve(dictionary.size());
  for (const auto& entry : dictionary) result.push_back(entry.id);
  return result;
}

[[nodiscard]] bool dictionary_has_arity_v1(
    const std::vector<PortableFiniteDictionaryEntryV1>& dictionary,
    const std::size_t arity) {
  return arity != 0U &&
         std::all_of(dictionary.begin(), dictionary.end(),
                     [arity](const PortableFiniteDictionaryEntryV1& entry) {
                       return entry.coordinates.size() == arity;
                     });
}

[[nodiscard]] bool rows_cover_domain_v1(
    const std::vector<FiniteLawRowV1>& rows,
    const std::vector<TypedLabel>& domain) {
  std::vector<TypedLabel> conditioning;
  conditioning.reserve(rows.size());
  for (const auto& row : rows) conditioning.push_back(row.conditioning_state_id);
  std::sort(conditioning.begin(), conditioning.end());
  return conditioning == domain;
}

[[nodiscard]] const StateFieldDescriptorV1* state_field_v1(
    const PlugDescriptorCore& descriptor, const StateFieldKindV1 kind) {
  const auto found = std::find_if(
      descriptor.state_fields.begin(), descriptor.state_fields.end(),
      [kind](const StateFieldDescriptorV1& field) {
        return field.kind == kind;
      });
  return found == descriptor.state_fields.end() ? nullptr : &*found;
}

[[nodiscard]] const MarkDescriptorV1* mark_field_v1(
    const PlugDescriptorCore& descriptor, const MetricMarkKindV1 kind) {
  const auto found = std::find_if(
      descriptor.marks.begin(), descriptor.marks.end(),
      [kind](const MarkDescriptorV1& mark) { return mark.kind == kind; });
  return found == descriptor.marks.end() ? nullptr : &*found;
}

// A coupled schedule carries N_T and D_T as vector-valued descriptor fields.
// PortableFiniteDictionaryEntryV1 already stores a flat scalar coordinate
// vector, so version one expands those two fields in the exact authored target
// order while every other descriptor field continues to occupy one scalar.
// Keeping this layout local to the coupled table avoids changing the released
// public carrier while making the dictionary, row, and realization one
// mathematical object rather than three independently checked claims.
struct CoupledDictionaryLayoutV1 final {
  std::size_t target_backlog_offset;
  std::size_t state_arity;
  std::size_t actual_departure_offset;
  std::size_t mark_arity;
};

[[nodiscard]] Result<CoupledDictionaryLayoutV1>
coupled_dictionary_layout_v1(const PlugDescriptorCore& descriptor,
                             const std::size_t target_count,
                             const std::string& path) {
  if (target_count == 0U) {
    return fail<CoupledDictionaryLayoutV1>(
        "c15.coupled_dictionary_descriptor_shape",
        "a coupled dictionary requires a nonempty ordered target vector",
        path);
  }

  std::optional<std::size_t> backlog_offset;
  std::size_t state_arity = 0U;
  for (const auto& field : descriptor.state_fields) {
    if (field.kind == StateFieldKindV1::target_backlog) {
      if (backlog_offset.has_value() ||
          target_count > std::numeric_limits<std::size_t>::max() -
                             state_arity) {
        return fail<CoupledDictionaryLayoutV1>(
            "c15.coupled_dictionary_descriptor_shape",
            "a coupled dictionary requires exactly one bounded target-backlog field",
            path + "/state_fields");
      }
      backlog_offset = state_arity;
      state_arity += target_count;
    } else {
      if (state_arity == std::numeric_limits<std::size_t>::max()) {
        return fail<CoupledDictionaryLayoutV1>(
            "c15.coupled_dictionary_descriptor_shape",
            "coupled state-coordinate arity overflows size_t",
            path + "/state_fields");
      }
      ++state_arity;
    }
  }

  std::optional<std::size_t> departure_offset;
  std::size_t mark_arity = 0U;
  for (const auto& mark : descriptor.marks) {
    if (mark.kind == MetricMarkKindV1::actual_departure) {
      if (departure_offset.has_value() ||
          target_count >
              std::numeric_limits<std::size_t>::max() - mark_arity) {
        return fail<CoupledDictionaryLayoutV1>(
            "c15.coupled_dictionary_descriptor_shape",
            "a coupled dictionary requires exactly one bounded actual-departure mark",
            path + "/marks");
      }
      departure_offset = mark_arity;
      mark_arity += target_count;
    } else {
      if (mark_arity == std::numeric_limits<std::size_t>::max()) {
        return fail<CoupledDictionaryLayoutV1>(
            "c15.coupled_dictionary_descriptor_shape",
            "coupled mark-coordinate arity overflows size_t", path + "/marks");
      }
      ++mark_arity;
    }
  }

  if (!backlog_offset.has_value() || !departure_offset.has_value()) {
    return fail<CoupledDictionaryLayoutV1>(
        "c15.coupled_dictionary_descriptor_shape",
        "a coupled schedule requires target-backlog state and actual-departure mark fields",
        path);
  }
  return Result<CoupledDictionaryLayoutV1>::success(
      {*backlog_offset, state_arity, *departure_offset, mark_arity});
}

[[nodiscard]] bool scalar_exactly_equals_big_nat_v1(
    const PortableScientificScalar& scalar, const BigNat& expected) {
  const ExactRational exact = exact_scalar_value(scalar);
  return exact.denominator() == 1 && exact.numerator() == expected.value();
}

[[nodiscard]] Result<void> validate_coupled_dictionary_bindings_v1(
    const std::vector<FiniteLawRowV1>& rows,
    const FiniteLawTablesV1& payload,
    const CoupledDictionaryLayoutV1& layout, const std::string& path) {
  for (std::size_t row_index = 0U; row_index < rows.size(); ++row_index) {
    const auto& row = rows[row_index];
    const auto* current = dictionary_entry_v1(payload.state_dictionary,
                                              row.conditioning_state_id);
    if (current == nullptr || current->coordinates.size() != layout.state_arity) {
      return fail<void>(
          "c15.coupled_dictionary_binding_invariant",
          "validated coupled row lost its conditioning-state dictionary binding",
          path + "/" + std::to_string(row_index));
    }
    for (std::size_t atom_index = 0U; atom_index < row.atoms.size();
         ++atom_index) {
      const auto& atom = row.atoms[atom_index];
      const std::string atom_path = path + "/" +
                                    std::to_string(row_index) + "/atoms/" +
                                    std::to_string(atom_index);
      if (!atom.common_schedule.has_value() ||
          atom.ordered_mark_ids.size() != 1U) {
        return fail<void>(
            "c15.coupled_dictionary_binding_invariant",
            "validated coupled atom lost its common schedule or mark tuple",
            atom_path);
      }
      const auto& schedule = *atom.common_schedule;
      const auto* successor = dictionary_entry_v1(
          payload.state_dictionary, atom.successor_state_id);
      const auto* mark = dictionary_entry_v1(payload.mark_dictionary,
                                             atom.ordered_mark_ids.front());
      if (successor == nullptr ||
          successor->coordinates.size() != layout.state_arity ||
          mark == nullptr || mark->coordinates.size() != layout.mark_arity) {
        return fail<void>(
            "c15.coupled_dictionary_binding_invariant",
            "validated coupled atom lost a successor-state or mark dictionary binding",
            atom_path);
      }

      for (std::size_t target = 0U;
           target < payload.ordered_deployed_targets.size(); ++target) {
        if (!scalar_exactly_equals_big_nat_v1(
                current->coordinates[layout.target_backlog_offset + target],
                schedule.current_target_backlogs[target])) {
          return fail<void>(
              "c15.coupled_current_backlog_dictionary_mismatch",
              "the conditioning state's ordered target-backlog coordinates must equal the common-schedule current backlog exactly",
              atom_path + "/common_schedule/current_target_backlogs/" +
                  std::to_string(target));
        }
        if (!scalar_exactly_equals_big_nat_v1(
                successor->coordinates[layout.target_backlog_offset + target],
                schedule.retained_target_backlogs[target])) {
          return fail<void>(
              "c15.coupled_retained_backlog_dictionary_mismatch",
              "the successor state's ordered target-backlog coordinates must equal the common-schedule retained backlog exactly",
              atom_path + "/common_schedule/retained_target_backlogs/" +
                  std::to_string(target));
        }
        if (!scalar_exactly_equals_big_nat_v1(
                mark->coordinates[layout.actual_departure_offset + target],
                BigNat{schedule.joint_target_departures[target]})) {
          return fail<void>(
              "c15.coupled_departure_dictionary_mismatch",
              "the mark's ordered actual-departure coordinates must equal the common-schedule joint departures exactly",
              atom_path + "/common_schedule/joint_target_departures/" +
                  std::to_string(target));
        }
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool reveal_order_covers_descriptor_v1(
    const std::vector<MetricRevealStageV1>& reveal_order,
    const PlugDescriptorCore& descriptor) {
  return std::all_of(
      descriptor.marks.begin(), descriptor.marks.end(),
      [&reveal_order](const MarkDescriptorV1& mark) {
        return mark.reveal_stage == MetricRevealStageV1::entrance_label ||
               vector_contains(reveal_order, mark.reveal_stage);
      });
}

[[nodiscard]] bool finite_storage_is_closed_v1(
    const FiniteTableStorageV1 storage) {
  switch (storage) {
    case FiniteTableStorageV1::dense:
    case FiniteTableStorageV1::sparse: return true;
  }
  return false;
}

[[nodiscard]] bool reveal_order_is_canonical_v1(
    const std::vector<MetricRevealStageV1>& stages) {
  if (stages.empty()) return false;
  for (std::size_t index = 0U; index < stages.size(); ++index) {
    if (stages[index] == MetricRevealStageV1::entrance_label ||
        static_cast<std::uint8_t>(stages[index]) >
            static_cast<std::uint8_t>(MetricRevealStageV1::completed_edge) ||
        (index != 0U &&
         static_cast<std::uint8_t>(stages[index - 1U]) >=
             static_cast<std::uint8_t>(stages[index]))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool rows_follow_domains_v1(
    const std::vector<FiniteLawRowV1>& rows,
    const std::vector<TypedLabel>& conditioning_domain,
    const std::vector<TypedLabel>& successor_domain) {
  return std::all_of(
      rows.begin(), rows.end(), [&](const FiniteLawRowV1& row) {
        return vector_contains(conditioning_domain,
                               row.conditioning_state_id) &&
               std::all_of(
                   row.atoms.begin(), row.atoms.end(),
                   [&](const FiniteLawAtomV1& atom) {
                     return vector_contains(successor_domain,
                                            atom.successor_state_id);
                   });
      });
}

[[nodiscard]] Result<void> validate_law_atom_v1(
    const FiniteLawAtomV1& atom, const FiniteLawTablesV1& payload,
    const bool common_schedule_required, const FrameworkProblemView& view,
    const std::size_t expected_mark_count, const std::string& path) {
  if (dictionary_entry_v1(payload.state_dictionary,
                          atom.successor_state_id) == nullptr ||
      !scalar_is_probability(atom.probability) ||
      atom.ordered_mark_ids.size() != expected_mark_count ||
      std::any_of(atom.ordered_mark_ids.begin(), atom.ordered_mark_ids.end(),
                  [&payload](const TypedLabel& mark) {
                    return dictionary_entry_v1(payload.mark_dictionary,
                                               mark) == nullptr;
                  }) ||
      atom.common_schedule.has_value() != common_schedule_required) {
    return fail<void>("c15.finite_atom_shape",
                      "finite-law atom has an undeclared state/mark, wrong mark cardinality, invalid probability, or wrong common-schedule shape",
                      path);
  }
  if (atom.common_schedule.has_value()) {
    auto common = artifact::detail::validate_common_schedule_realization_v1(
        *atom.common_schedule, payload.ordered_deployed_targets, view);
    if (!common) return common;
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_normalized_rows_v1(
    const std::vector<FiniteLawRowV1>& rows,
    const FiniteRowConditioningStageV1 expected_stage,
    const FiniteLawTablesV1& payload, const bool common_schedule_required,
    const FrameworkProblemView& view, const std::string& path,
    const bool require_normalized = true,
    const bool allow_empty = false,
    const std::size_t expected_mark_count = 1U) {
  if (rows.empty() && !allow_empty) {
    return fail<void>("c15.finite_rows_empty",
                      "finite-law row collection must not be empty", path);
  }
  std::vector<TypedLabel> row_ids;
  std::vector<TypedLabel> conditioning_ids;
  for (std::size_t index = 0U; index < rows.size(); ++index) {
    const auto& row = rows[index];
    const std::string row_path = path + "/" + std::to_string(index);
    if (row.conditioning_stage != expected_stage || row.atoms.empty() ||
        dictionary_entry_v1(payload.state_dictionary,
                            row.conditioning_state_id) == nullptr ||
        (index != 0U && !(rows[index - 1U].row_id < row.row_id)) ||
        vector_contains(row_ids, row.row_id) ||
        vector_contains(conditioning_ids, row.conditioning_state_id)) {
      return fail<void>("c15.finite_row_key",
                        "finite-law row has a wrong stage, duplicate key, empty atom list, or undeclared conditioning state",
                        row_path);
    }
    row_ids.push_back(row.row_id);
    conditioning_ids.push_back(row.conditioning_state_id);
    ExactRational mass = ExactRational::zero();
    for (std::size_t atom_index = 0U; atom_index < row.atoms.size();
         ++atom_index) {
      if (atom_index != 0U &&
          encode_finite_atom(row.atoms[atom_index - 1U]).dump() >=
              encode_finite_atom(row.atoms[atom_index]).dump()) {
        return fail<void>(
            "c15.finite_atom_order",
            "finite-law atoms must be unique and in canonical wire order",
            row_path + "/atoms/" + std::to_string(atom_index));
      }
      auto atom = validate_law_atom_v1(
          row.atoms[atom_index], payload, common_schedule_required, view,
          expected_mark_count,
          row_path + "/atoms/" + std::to_string(atom_index));
      if (!atom) return atom;
      mass = mass + exact_scalar_value(row.atoms[atom_index].probability);
    }
    if (require_normalized && mass != ExactRational::one()) {
      return fail<void>("c15.finite_row_mass",
                        "normalized finite-law row probability mass must equal one exactly",
                        row_path + "/atoms");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_predictive_stopping_v1(
    const FinitePredictiveStoppingTablesV1& predictive,
    const FiniteRowConditioningStageV1 expected_stage,
    const FiniteLawTablesV1& payload, const FrameworkProblemView& view,
    const std::string& path) {
  auto continuation = validate_normalized_rows_v1(
      predictive.continuation_rows, expected_stage, payload, false, view,
      path + "/continuation_rows", false, true);
  if (!continuation) return continuation;
  auto stop = validate_normalized_rows_v1(
      predictive.stop_or_event_rows, expected_stage, payload, false, view,
      path + "/stop_or_event_rows", false, true);
  if (!stop) return stop;
  auto terminal = validate_normalized_rows_v1(
      predictive.terminal_or_exit_rows, expected_stage, payload, false, view,
      path + "/terminal_or_exit_rows", true, false, 0U);
  if (!terminal) return terminal;

  std::vector<TypedLabel> row_ids;
  const auto collect_row_ids = [&](const std::vector<FiniteLawRowV1>& rows) {
    for (const auto& row : rows) row_ids.push_back(row.row_id);
  };
  collect_row_ids(predictive.continuation_rows);
  collect_row_ids(predictive.stop_or_event_rows);
  collect_row_ids(predictive.terminal_or_exit_rows);
  std::sort(row_ids.begin(), row_ids.end());
  if (std::adjacent_find(row_ids.begin(), row_ids.end()) != row_ids.end()) {
    return fail<void>("c15.predictive_row_id_collision",
                      "predictive subkernel and terminal row identities must be globally unique",
                      path);
  }

  std::vector<TypedLabel> conditioning;
  for (const auto& row : predictive.continuation_rows) {
    if (!vector_contains(conditioning, row.conditioning_state_id)) {
      conditioning.push_back(row.conditioning_state_id);
    }
  }
  for (const auto& row : predictive.stop_or_event_rows) {
    if (!vector_contains(conditioning, row.conditioning_state_id)) {
      conditioning.push_back(row.conditioning_state_id);
    }
  }
  for (const auto& state : conditioning) {
    ExactRational mass = ExactRational::zero();
    const auto add_rows = [&](const std::vector<FiniteLawRowV1>& rows) {
      for (const auto& row : rows) {
        if (row.conditioning_state_id == state) {
          for (const auto& atom : row.atoms) {
            mass = mass + exact_scalar_value(atom.probability);
          }
        }
      }
    };
    add_rows(predictive.continuation_rows);
    add_rows(predictive.stop_or_event_rows);
    if (mass != ExactRational::one()) {
      return fail<void>("c15.predictive_subkernel_mass",
                        "continuation plus stop/event mass must equal one for each conditioning state",
                        path);
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool labels_are_subset_v1(
    const std::vector<TypedLabel>& values,
    const std::vector<PortableFiniteDictionaryEntryV1>& dictionary) {
  return !values.empty() && duplicate_free(values) &&
         std::is_sorted(values.begin(), values.end()) &&
         std::all_of(values.begin(), values.end(),
                     [&dictionary](const TypedLabel& id) {
                       return dictionary_entry_v1(dictionary, id) != nullptr;
                     });
}

[[nodiscard]] Result<void> validate_explicit_words_v1(
    const std::vector<ExplicitOrderedWordV1>& words,
    const std::vector<TypedLabel>& entrance_domain,
    const std::vector<TypedLabel>& state_domain,
    const std::vector<TypedLabel>& mark_domain,
    const PortableScientificScalar& nontermination,
    const std::string& path) {
  if (words.empty()) {
    return fail<void>("c15.explicit_word_empty",
                      "explicit word representation must contain at least one word",
                      path);
  }
  for (std::size_t index = 0U; index < words.size(); ++index) {
    const auto& word = words[index];
    if ((index != 0U &&
         encode_word(words[index - 1U]).dump() >=
             encode_word(word).dump()) ||
        word.duration.is_zero() ||
        !vector_contains(entrance_domain, word.entrance_state_id) ||
        !vector_contains(state_domain, word.terminal_id) ||
        !vector_contains(entrance_domain, word.successor_entry_id) ||
        !std::all_of(word.ordered_mark_ids.begin(),
                     word.ordered_mark_ids.end(),
                     [&mark_domain](const TypedLabel& mark) {
                       return vector_contains(mark_domain, mark);
                     }) ||
        word.duration.value() !=
            BigInt{word.ordered_mark_ids.size()} ||
        !scalar_is_probability(word.probability)) {
      return fail<void>("c15.explicit_word_shape",
                        "explicit word has an invalid domain reference, duration, or probability",
                        path + "/" + std::to_string(index));
    }
  }
  const ExactRational escaped = exact_scalar_value(nontermination);
  for (const auto& entrance : entrance_domain) {
    ExactRational mass = escaped;
    for (const auto& word : words) {
      if (word.entrance_state_id == entrance) {
        mass = mass + exact_scalar_value(word.probability);
      }
    }
    if (mass != ExactRational::one()) {
      return fail<void>("c15.explicit_word_mass",
                        "completed word mass plus explicit nontermination must equal one per entrance",
                        path);
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool predictive_rows_follow_local_domains_v1(
    const FinitePredictiveStoppingTablesV1& predictive,
    const std::vector<TypedLabel>& entrance_domain,
    const std::vector<TypedLabel>& state_domain,
    const std::vector<TypedLabel>& mark_domain) {
  std::vector<TypedLabel> active;
  for (const auto& row : predictive.continuation_rows) {
    if (!vector_contains(active, row.conditioning_state_id)) {
      active.push_back(row.conditioning_state_id);
    }
  }
  for (const auto& row : predictive.stop_or_event_rows) {
    if (!vector_contains(active, row.conditioning_state_id)) {
      active.push_back(row.conditioning_state_id);
    }
  }
  std::sort(active.begin(), active.end());
  std::vector<TypedLabel> terminal;
  for (const auto& row : predictive.terminal_or_exit_rows) {
    terminal.push_back(row.conditioning_state_id);
  }
  std::sort(terminal.begin(), terminal.end());
  if (terminal.empty() ||
      std::adjacent_find(terminal.begin(), terminal.end()) != terminal.end()) {
    return false;
  }
  std::vector<TypedLabel> expected_active;
  for (const auto& state : state_domain) {
    if (!vector_contains(terminal, state)) expected_active.push_back(state);
  }
  if (active != expected_active ||
      !std::all_of(terminal.begin(), terminal.end(),
                   [&state_domain](const TypedLabel& id) {
                     return vector_contains(state_domain, id);
                   }) ||
      !std::all_of(entrance_domain.begin(), entrance_domain.end(),
                   [&active](const TypedLabel& id) {
                     return vector_contains(active, id);
                   })) {
    return false;
  }
  const auto marks_are_local = [&](const FiniteLawAtomV1& atom) {
    return std::all_of(atom.ordered_mark_ids.begin(),
                       atom.ordered_mark_ids.end(),
                       [&mark_domain](const TypedLabel& mark) {
                         return vector_contains(mark_domain, mark);
                       });
  };
  const bool continuation_local = std::all_of(
      predictive.continuation_rows.begin(),
      predictive.continuation_rows.end(),
      [&](const FiniteLawRowV1& row) {
        return vector_contains(active, row.conditioning_state_id) &&
               std::all_of(row.atoms.begin(), row.atoms.end(),
                           [&](const FiniteLawAtomV1& atom) {
                             return vector_contains(
                                        active, atom.successor_state_id) &&
                                    marks_are_local(atom);
                           });
      });
  std::vector<TypedLabel> reached_terminal;
  const bool stop_local = std::all_of(
      predictive.stop_or_event_rows.begin(),
      predictive.stop_or_event_rows.end(),
      [&](const FiniteLawRowV1& row) {
        if (!vector_contains(active, row.conditioning_state_id)) return false;
        return std::all_of(row.atoms.begin(), row.atoms.end(),
                           [&](const FiniteLawAtomV1& atom) {
                             if (!vector_contains(terminal,
                                                  atom.successor_state_id) ||
                                 !marks_are_local(atom)) {
                               return false;
                             }
                             if (!vector_contains(reached_terminal,
                                                  atom.successor_state_id)) {
                               reached_terminal.push_back(
                                   atom.successor_state_id);
                             }
                             return true;
                           });
      });
  std::sort(reached_terminal.begin(), reached_terminal.end());
  const bool terminal_local = std::all_of(
      predictive.terminal_or_exit_rows.begin(),
      predictive.terminal_or_exit_rows.end(),
      [&](const FiniteLawRowV1& row) {
        return std::all_of(row.atoms.begin(), row.atoms.end(),
                           [&](const FiniteLawAtomV1& atom) {
                             return vector_contains(
                                        entrance_domain,
                                        atom.successor_state_id) &&
                                    marks_are_local(atom);
                           });
      });
  return continuation_local && stop_local && terminal_local &&
         reached_terminal == terminal;
}

[[nodiscard]] bool accepted_stopped_law_may_be_defective_v1(
    const AcceptedCapabilityContract& contract) {
  return std::all_of(
      contract.structural_manifest().clauses().begin(),
      contract.structural_manifest().clauses().end(),
      [&](const MetricSupportClauseV1& accepted_clause) {
        const auto requirement = std::find_if(
            contract.requirements().clauses().begin(),
            contract.requirements().clauses().end(),
            [&](const MetricRequirementClause& clause) {
              return clause.origin.clause_id == accepted_clause.clause_id;
            });
        if (requirement == contract.requirements().clauses().end()) {
          return false;
        }
        return std::any_of(
            requirement->route_alternatives.begin(),
            requirement->route_alternatives.end(),
            [](const MetricRouteAlternativeV1& route) {
              const auto* stopped =
                  std::get_if<StoppedPathRequirementV1>(
                      &route.semantic.law);
              return stopped != nullptr && stopped->may_be_defective;
            });
      });
}

[[nodiscard]] Result<void> validate_finite_tables_v1(
    const FiniteLawTablesV1& payload, const FrameworkProblemView& view,
    const PlugDescriptorCore& descriptor,
    const AcceptedCapabilityContract& contract, const std::string& path) {
  const bool storage_is_closed = std::visit(
      [](const auto& table) {
        if constexpr (requires { table.storage; }) {
          return finite_storage_is_closed_v1(table.storage);
        } else {
          return true;
        }
      },
      payload.table);
  const auto expected_semantic = finite_table_semantic(payload.table);
  const bool storage_matches_access = std::visit(
      [&](const auto& table) {
        if constexpr (requires { table.storage; }) {
          return (table.storage == FiniteTableStorageV1::dense &&
                  payload.runtime_access ==
                      RuntimeAccessTagV1::finite_enumerated_row) ||
                 (table.storage == FiniteTableStorageV1::sparse &&
                  payload.runtime_access == RuntimeAccessTagV1::sparse_row);
        } else {
          return payload.runtime_access ==
                     RuntimeAccessTagV1::finite_enumerated_row ||
                 payload.runtime_access == RuntimeAccessTagV1::sparse_row;
        }
      },
      payload.table);
  if (payload.payload_version != kProtocolVersion ||
      payload.ordered_deployed_targets != descriptor.deployed_targets ||
      !expected_semantic.has_value() ||
      payload.semantic != *expected_semantic ||
      payload.semantic != descriptor.semantic ||
      payload.runtime_access != descriptor.runtime_access ||
      !storage_is_closed || !storage_matches_access ||
      !dictionary_is_canonical_v1(payload.state_dictionary) ||
      !dictionary_is_canonical_v1(payload.mark_dictionary) ||
      payload.configured_arrival_binding !=
          view.fingerprints().compiled_arrival ||
      payload.selection_binding != view.fingerprints().target_selection) {
    return fail<void>("c15.finite_table_payload_binding",
                      "finite-table dictionaries or arrival/selection bindings are invalid",
                      path);
  }
  const bool staged_table =
      std::holds_alternative<StagedOpportunityFluxTableV1>(payload.table);
  const bool coupled_table =
      std::holds_alternative<CoupledCommonScheduleTableV1>(payload.table);
  std::optional<CoupledDictionaryLayoutV1> coupled_layout;
  std::size_t expected_state_arity = descriptor.state_fields.size();
  std::size_t expected_mark_arity = descriptor.marks.size();
  if (coupled_table) {
    auto layout = coupled_dictionary_layout_v1(
        descriptor, payload.ordered_deployed_targets.size(),
        path + "/descriptor");
    if (!layout) {
      return Result<void>::failure(layout.error());
    }
    coupled_layout = layout.value();
    expected_state_arity = layout.value().state_arity;
    expected_mark_arity = layout.value().mark_arity;
  }
  if (!dictionary_has_arity_v1(payload.mark_dictionary,
                               expected_mark_arity) ||
      (!staged_table &&
       !dictionary_has_arity_v1(payload.state_dictionary,
                                expected_state_arity))) {
    return fail<void>(
        "c15.finite_dictionary_descriptor_shape",
        "finite state/mark dictionary coordinate arities do not exactly match the inherited descriptor fields and coupled target-vector widths",
        path);
  }
  const auto law_digest =
      artifact::detail::finite_law_table_digest_v1(payload.table);
  const ArtifactObjectReferenceV1 law_id = std::visit(
      [](const auto& table) -> ArtifactObjectReferenceV1 {
        return table.law_id;
      },
      payload.table);
  const std::uint32_t table_version = std::visit(
      [](const auto& table) { return table.table_schema_version; },
      payload.table);
  if (table_version != kProtocolVersion || !law_digest ||
      law_digest.value() != law_id.object_digest) {
    return fail<void>("c15.finite_table_law_identity",
                      "finite-law subtable version or content-bound law identity is invalid",
                      path + "/table/law_id");
  }

  return std::visit(
      [&](const auto& table) -> Result<void> {
        using Table = std::decay_t<decltype(table)>;
        if constexpr (std::same_as<Table, StationaryMarkedEdgeTableV1>) {
          const auto* backlog =
              state_field_v1(descriptor, StateFieldKindV1::target_backlog);
          const auto* phase = state_field_v1(
              descriptor,
              StateFieldKindV1::configured_arrival_predictive_phase);
          const auto* departure =
              mark_field_v1(descriptor, MetricMarkKindV1::actual_departure);
          const auto* retained =
              mark_field_v1(descriptor, MetricMarkKindV1::successor_backlog);
          if (backlog == nullptr || departure == nullptr ||
              retained == nullptr ||
              table.target_backlog_codec != backlog->codec ||
              table.actual_departure_mark_codec != departure->codec ||
              table.retained_mark_codec != retained->codec ||
              (phase != nullptr &&
               table.exact_input_phase_codec != phase->codec) ||
              (descriptor.phase.retains_configured_predictive_phase &&
               phase == nullptr) ||
              table.target_backlog_codec.id.empty() ||
              table.target_backlog_codec.version == 0U ||
              table.exact_input_phase_codec.id.empty() ||
              table.exact_input_phase_codec.version == 0U ||
              table.actual_departure_mark_codec.id.empty() ||
              table.actual_departure_mark_codec.version == 0U ||
              table.retained_mark_codec.id.empty() ||
              table.retained_mark_codec.version == 0U ||
              table.conditioning_binding != payload.selection_binding ||
              !rows_cover_domain_v1(
                  table.joint_edge_rows,
                  dictionary_ids_v1(payload.state_dictionary))) {
            return fail<void>("c15.stationary_table_binding",
                              "stationary marked-edge codecs or conditioning binding are invalid",
                              path + "/table");
          }
          return validate_normalized_rows_v1(
              table.joint_edge_rows,
              FiniteRowConditioningStageV1::stationary_edge, payload,
              false, view, path + "/table/joint_edge_rows");
        } else if constexpr (
            std::same_as<Table, StagedOpportunityFluxTableV1>) {
          const auto state_ids = dictionary_ids_v1(payload.state_dictionary);
          std::vector<TypedLabel> staged_domains =
              table.prearrival_state_domain;
          staged_domains.insert(staged_domains.end(),
                                table.postarrival_state_domain.begin(),
                                table.postarrival_state_domain.end());
          std::sort(staged_domains.begin(), staged_domains.end());
          const auto* innovation =
              mark_field_v1(descriptor, MetricMarkKindV1::arrival_batch);
          if (!labels_are_subset_v1(table.prearrival_state_domain,
                                    payload.state_dictionary) ||
              !labels_are_subset_v1(table.postarrival_state_domain,
                                    payload.state_dictionary) ||
              std::any_of(table.prearrival_state_domain.begin(),
                          table.prearrival_state_domain.end(),
                          [&table](const TypedLabel& id) {
                            return vector_contains(table.postarrival_state_domain,
                                                   id);
                          }) ||
              table.configured_arrival_reference !=
                  payload.configured_arrival_binding ||
              staged_domains != state_ids || innovation == nullptr ||
              table.configured_innovation_codec != innovation->codec ||
              table.configured_innovation_codec.id.empty() ||
              table.configured_innovation_codec.version == 0U ||
              table.deterministic_update_descriptor.object_id ==
                  table.retained_coordinate_descriptor.object_id ||
              table.deterministic_update_descriptor.object_id ==
                  table.law_id.object_id ||
              table.retained_coordinate_descriptor.object_id ==
                  table.law_id.object_id ||
              !reveal_order_is_canonical_v1(table.reveal_order) ||
              !reveal_order_covers_descriptor_v1(table.reveal_order,
                                                  descriptor) ||
              table.reveal_order.front() !=
                  MetricRevealStageV1::predecision ||
              !vector_contains(table.reveal_order,
                               MetricRevealStageV1::arrival) ||
              table.reveal_order.back() !=
                  MetricRevealStageV1::completed_edge) {
            return fail<void>("c15.staged_table_domains",
                              "staged table has invalid disjoint domains, configured arrival/innovation, or reveal order",
                              path + "/table");
          }
          const std::size_t base_arity = descriptor.state_fields.size();
          const bool arities = std::all_of(
                                   table.prearrival_state_domain.begin(),
                                   table.prearrival_state_domain.end(),
                                   [&](const TypedLabel& id) {
                                     return dictionary_entry_v1(
                                                payload.state_dictionary, id)
                                                ->coordinates.size() ==
                                            base_arity;
                                   }) &&
                               std::all_of(
                                   table.postarrival_state_domain.begin(),
                                   table.postarrival_state_domain.end(),
                                   [&](const TypedLabel& id) {
                                     return dictionary_entry_v1(
                                                payload.state_dictionary, id)
                                                ->coordinates.size() ==
                                            base_arity + 1U;
                                   });
          if (!arities) {
            return fail<void>("c15.staged_innovation_arity",
                              "postarrival states must append exactly one configured innovation coordinate to the common prearrival arity",
                              path + "/table/postarrival_state_domain");
          }
          auto opportunities = validate_normalized_rows_v1(
              table.opportunity_rows,
              FiniteRowConditioningStageV1::prearrival, payload, false,
              view, path + "/table/opportunity_rows");
          if (!opportunities) return opportunities;
          auto successors = validate_normalized_rows_v1(
              table.successor_mark_rows,
              FiniteRowConditioningStageV1::postarrival, payload, false,
              view, path + "/table/successor_mark_rows");
          if (!successors) return successors;
          if (!rows_follow_domains_v1(
                  table.opportunity_rows, table.prearrival_state_domain,
                  table.postarrival_state_domain) ||
              !rows_follow_domains_v1(
                  table.successor_mark_rows,
                  table.postarrival_state_domain,
                  table.prearrival_state_domain) ||
              !rows_cover_domain_v1(table.opportunity_rows,
                                    table.prearrival_state_domain) ||
              !rows_cover_domain_v1(table.successor_mark_rows,
                                    table.postarrival_state_domain)) {
            return fail<void>(
                "c15.staged_row_domain",
                "staged rows must map prearrival states to postarrival states and postarrival states back to the next prearrival domain",
                path + "/table");
          }
          return Result<void>::success();
        } else if constexpr (
            std::same_as<Table, TemporalContinuationTableV1>) {
          const auto* phase = state_field_v1(
              descriptor,
              StateFieldKindV1::configured_arrival_predictive_phase);
          const auto* controller =
              state_field_v1(descriptor, StateFieldKindV1::controller_memory);
          if (!reveal_order_is_canonical_v1(table.causal_reveal_order) ||
              !reveal_order_covers_descriptor_v1(
                  table.causal_reveal_order, descriptor) ||
              table.arrival_phase_codec.id.empty() ||
              table.arrival_phase_codec.version == 0U ||
              (phase != nullptr &&
               table.arrival_phase_codec != phase->codec) ||
              (descriptor.phase.retains_configured_predictive_phase &&
               phase == nullptr) ||
              table.controller_coordinate_codec.has_value() !=
                  (controller != nullptr) ||
              (table.controller_coordinate_codec.has_value() &&
               (table.controller_coordinate_codec->id.empty() ||
                table.controller_coordinate_codec->version == 0U ||
                *table.controller_coordinate_codec != controller->codec)) ||
              !rows_cover_domain_v1(
                  table.continuation_rows,
                  dictionary_ids_v1(payload.state_dictionary))) {
            return fail<void>("c15.temporal_table_binding",
                              "temporal continuation requires closed reveal and coordinate codecs",
                              path + "/table");
          }
          return validate_normalized_rows_v1(
              table.continuation_rows,
              FiniteRowConditioningStageV1::one_slot_current, payload,
              false, view, path + "/table/continuation_rows");
        } else if constexpr (std::same_as<Table, StoppedPathTableV1>) {
          if (table.stop_rule_id.empty() ||
              !labels_are_subset_v1(table.entrance_state_domain,
                                    payload.state_dictionary) ||
              !labels_are_subset_v1(table.stopped_state_domain,
                                    payload.state_dictionary) ||
              !labels_are_subset_v1(table.stopped_mark_domain,
                                    payload.mark_dictionary) ||
              table.stopped_state_domain !=
                  dictionary_ids_v1(payload.state_dictionary) ||
              table.stopped_mark_domain !=
                  dictionary_ids_v1(payload.mark_dictionary) ||
              !duplicate_free(table.completion_absorption_tail_evidence) ||
              !std::is_sorted(
                  table.completion_absorption_tail_evidence.begin(),
                  table.completion_absorption_tail_evidence.end()) ||
              !scalar_is_probability(
                  table.nonhit_or_nontermination_probability) ||
              (table.accepted_defective_hitting_law &&
               table.completion_absorption_tail_evidence.empty()) ||
              (!table.accepted_defective_hitting_law &&
               !exact_scalar_value(
                    table.nonhit_or_nontermination_probability)
                    .is_zero()) ||
              (table.accepted_defective_hitting_law &&
               !accepted_stopped_law_may_be_defective_v1(contract)) ||
              (table.accepted_defective_hitting_law &&
               std::any_of(descriptor.hypothesis_claims.begin(),
                           descriptor.hypothesis_claims.end(),
                           [](const HypothesisClaimV1& hypothesis) {
                             return hypothesis.kind ==
                                    HypothesisKindV1::nondefective;
                           }))) {
            return fail<void>("c15.stopped_table_shape",
                              "stopped table domains or defective-law contract are invalid",
                              path + "/table");
          }
          return std::visit(
              [&](const auto& representation) -> Result<void> {
                using Representation =
                    std::decay_t<decltype(representation)>;
                if constexpr (std::same_as<
                                  Representation,
                                  std::vector<ExplicitOrderedWordV1>>) {
                  return validate_explicit_words_v1(
                      representation, table.entrance_state_domain,
                      table.stopped_state_domain, table.stopped_mark_domain,
                      table.nonhit_or_nontermination_probability,
                      path + "/table/representation/words");
                } else {
                  auto predictive = validate_predictive_stopping_v1(
                      representation,
                      FiniteRowConditioningStageV1::stopped_continuation,
                      payload, view, path + "/table/representation");
                  if (!predictive) return predictive;
                  if (!predictive_rows_follow_local_domains_v1(
                          representation, table.entrance_state_domain,
                          table.stopped_state_domain,
                          table.stopped_mark_domain)) {
                    return fail<void>(
                        "c15.stopped_predictive_domain",
                        "stopped predictive rows do not respect entrance, stopped-state, mark, terminal and reentry domains",
                        path + "/table/representation");
                  }
                  return Result<void>::success();
                }
              },
              table.representation);
        } else if constexpr (
            std::same_as<Table, RomrResidenceWordTableV1>) {
          if (table.event_rule_id.empty() ||
              !labels_are_subset_v1(table.entrance_state_domain,
                                    payload.state_dictionary) ||
              !labels_are_subset_v1(table.residence_state_domain,
                                    payload.state_dictionary) ||
              !labels_are_subset_v1(table.residence_mark_domain,
                                    payload.mark_dictionary) ||
              table.residence_state_domain !=
                  dictionary_ids_v1(payload.state_dictionary) ||
              table.residence_mark_domain !=
                  dictionary_ids_v1(payload.mark_dictionary) ||
              !duplicate_free(table.complete_mass_termination_evidence) ||
              !std::is_sorted(
                  table.complete_mass_termination_evidence.begin(),
                  table.complete_mass_termination_evidence.end()) ||
              !scalar_is_probability(table.nontermination_probability) ||
              !exact_scalar_value(table.nontermination_probability).is_zero() ||
              table.complete_mass_termination_evidence.empty()) {
            return fail<void>("c15.residence_table_shape",
                              "ROMR residence table requires valid domains, complete-mass evidence, and zero explicit nontermination",
                              path + "/table");
          }
          return std::visit(
              [&](const auto& representation) -> Result<void> {
                using Representation =
                    std::decay_t<decltype(representation)>;
                if constexpr (std::same_as<
                                  Representation,
                                  std::vector<ExplicitOrderedWordV1>>) {
                  return validate_explicit_words_v1(
                      representation, table.entrance_state_domain,
                      table.residence_state_domain,
                      table.residence_mark_domain,
                      table.nontermination_probability,
                      path + "/table/representation/words");
                } else {
                  auto predictive = validate_predictive_stopping_v1(
                      representation,
                      FiniteRowConditioningStageV1::residence_continuation,
                      payload, view, path + "/table/representation");
                  if (!predictive) return predictive;
                  if (!predictive_rows_follow_local_domains_v1(
                          representation, table.entrance_state_domain,
                          table.residence_state_domain,
                          table.residence_mark_domain)) {
                    return fail<void>(
                        "c15.residence_predictive_domain",
                        "residence predictive rows do not respect entrance, residence-state, mark, terminal and reentry domains",
                        path + "/table/representation");
                  }
                  return Result<void>::success();
                }
              },
              table.representation);
        } else {
          auto binding =
              artifact::detail::coupled_tie_phase_arrival_binding_v1(view);
          if (table.constraint_geometry_digest !=
                  view.fingerprints().constraint ||
              !binding || table.tie_phase_arrival_binding != binding.value()) {
            return fail<void>("c15.coupled_table_binding",
                              "coupled schedule table has stale constraint or tie/phase/arrival binding",
                              path + "/table");
          }
          const bool accepted_full_schedule = std::any_of(
              contract.structural_manifest().clauses().begin(),
              contract.structural_manifest().clauses().end(),
              [](const MetricSupportClauseV1& clause) {
                return clause.semantic ==
                           SemanticTagV1::coupled_target_schedule_law &&
                       clause.target_coupling ==
                           TargetCouplingV1::full_schedule_identity;
              });
          if (accepted_full_schedule &&
              std::any_of(
                  table.common_joint_rows.begin(),
                  table.common_joint_rows.end(),
                  [](const FiniteLawRowV1& row) {
                    return std::any_of(
                        row.atoms.begin(), row.atoms.end(),
                        [](const FiniteLawAtomV1& atom) {
                          return !atom.common_schedule.has_value() ||
                                 atom.common_schedule
                                     ->structurally_witnessed_projection;
                        });
                  })) {
            return fail<void>(
                "c15.coupled_full_schedule_projection",
                "a full-schedule accepted contract requires every atom to carry the complete unwitnessed catalog schedule",
                path + "/table/common_joint_rows");
          }
          if (!rows_cover_domain_v1(
                  table.common_joint_rows,
                  dictionary_ids_v1(payload.state_dictionary))) {
            return fail<void>(
                "c15.coupled_table_incomplete_domain",
                "coupled table must carry one conditional row for every declared current state",
                path + "/table/common_joint_rows");
          }
          auto normalized = validate_normalized_rows_v1(
              table.common_joint_rows,
              FiniteRowConditioningStageV1::common_schedule, payload, true,
              view, path + "/table/common_joint_rows");
          if (!normalized) return normalized;
          if (!coupled_layout.has_value()) {
            return fail<void>(
                "c15.coupled_dictionary_binding_invariant",
                "coupled validation lost its checked dictionary layout",
                path + "/table/common_joint_rows");
          }
          return validate_coupled_dictionary_bindings_v1(
              table.common_joint_rows, payload, *coupled_layout,
              path + "/table/common_joint_rows");
        }
      },
      payload.table);
}

[[nodiscard]] std::optional<ArtifactReferenceKindV1>
reference_kind_for_role_v1(const MetricSupportRoleV1 role) {
  switch (role) {
    case MetricSupportRoleV1::deployed_payload:
      return ArtifactReferenceKindV1::artifact_payload;
    case MetricSupportRoleV1::deployed_response: return std::nullopt;
    case MetricSupportRoleV1::raw_response:
      return ArtifactReferenceKindV1::raw_response_product;
    case MetricSupportRoleV1::nominal_response:
      return ArtifactReferenceKindV1::nominal_response_product;
    case MetricSupportRoleV1::projection_center:
      return ArtifactReferenceKindV1::projection_center_product;
    case MetricSupportRoleV1::projected_mean:
      return ArtifactReferenceKindV1::projected_mean_product;
    case MetricSupportRoleV1::recoded_response:
      return ArtifactReferenceKindV1::recoded_response_product;
    case MetricSupportRoleV1::stationary_marked_edge_law:
      return ArtifactReferenceKindV1::stationary_marked_edge_law;
    case MetricSupportRoleV1::staged_opportunity_flux_law:
      return ArtifactReferenceKindV1::staged_opportunity_flux_law;
    case MetricSupportRoleV1::temporal_continuation_law:
      return ArtifactReferenceKindV1::temporal_continuation_law;
    case MetricSupportRoleV1::residence_word_law:
      return ArtifactReferenceKindV1::residence_word_law;
    case MetricSupportRoleV1::stopped_path_law:
      return ArtifactReferenceKindV1::stopped_path_law;
    case MetricSupportRoleV1::coupled_schedule_law:
      return ArtifactReferenceKindV1::coupled_schedule_law;
    case MetricSupportRoleV1::direct_metric_value:
      return ArtifactReferenceKindV1::direct_metric_value;
    case MetricSupportRoleV1::response_envelope:
      return ArtifactReferenceKindV1::response_envelope;
    case MetricSupportRoleV1::raw_response_bound_evidence:
      return ArtifactReferenceKindV1::raw_response_bound_evidence;
    case MetricSupportRoleV1::response_order_evidence:
      return ArtifactReferenceKindV1::response_order_evidence;
    case MetricSupportRoleV1::optimizer_evidence:
      return ArtifactReferenceKindV1::optimizer_evidence;
    case MetricSupportRoleV1::statistical_evidence:
      return ArtifactReferenceKindV1::statistical_evidence;
    case MetricSupportRoleV1::numerical_evidence:
      return ArtifactReferenceKindV1::numerical_evidence;
    case MetricSupportRoleV1::calibration_evidence:
      return ArtifactReferenceKindV1::calibration_evidence;
    case MetricSupportRoleV1::compression_evidence:
      return ArtifactReferenceKindV1::compression_evidence;
    case MetricSupportRoleV1::stability_certificate:
      return ArtifactReferenceKindV1::stability_certificate;
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return ArtifactReferenceKindV1::reported_validity_or_lift_evidence;
    case MetricSupportRoleV1::physical_transfer_evidence:
      return ArtifactReferenceKindV1::physical_transfer_evidence;
  }
  return std::nullopt;
}

[[nodiscard]] bool role_is_scoped_evidence_v1(
    const MetricSupportRoleV1 role) {
  return metric_support_role_rank_v1(role) >=
         metric_support_role_rank_v1(
             MetricSupportRoleV1::raw_response_bound_evidence);
}

[[nodiscard]] bool selected_response_subject_matches_v1(
    const DeployedResponseReferenceV1& realized,
    const ThreeBinScalarResponseV1& response) {
  return std::visit(
      [&](const auto& selected) {
        using Selected = std::decay_t<decltype(selected)>;
        return std::visit(
            [&](const auto& deployed) {
              using Deployed = std::decay_t<decltype(deployed)>;
              if constexpr (std::same_as<Selected, RawResponseProductRef> &&
                            std::same_as<Deployed, RawResponseProductId>) {
                return selected.identity == deployed.identity() &&
                       selected.value_form ==
                           ResponseProductValueFormV1::exact_point &&
                       response_all_raw_points(response);
              } else if constexpr (
                  std::same_as<Selected, NominalResponseProductRef> &&
                  std::same_as<Deployed, NominalResponseProductId>) {
                return selected.identity == deployed.identity();
              } else if constexpr (
                  std::same_as<Selected, RecodedResponseProductRef> &&
                  std::same_as<Deployed, RecodedResponseProductId>) {
                return selected.identity == deployed.identity();
              } else {
                return false;
              }
            },
            response.deployed_response_product_id);
      },
      realized.selected_product);
}

[[nodiscard]] bool selected_response_subject_matches_v1(
    const DeployedResponseReferenceV1& realized,
    const FinitePrefixConstantTailResponseV1& response) {
  const auto* selected =
      std::get_if<RawResponseProductRef>(&realized.selected_product);
  return selected != nullptr &&
         selected->identity ==
             response.deployed_response_product_id.identity() &&
         selected->identity == response.raw_response.product_id.identity() &&
         selected->value_form == ResponseProductValueFormV1::exact_point;
}

[[nodiscard]] bool payload_owns_role_subject_v1(
    const MetricClauseIdV1& clause_id, const MetricSupportRoleV1 role,
    const ArtifactObjectReferenceV1& subject,
    const SurrogateArtifactV1& artifact,
    const artifact::detail::ValidatedArtifactObjectGraphV1& graph) {
  const auto response_owns_product =
      [&](const ThreeBinScalarResponseV1& response) {
        switch (role) {
          case MetricSupportRoleV1::raw_response:
            return subject == response.raw_response.product_id.identity();
          case MetricSupportRoleV1::nominal_response:
            return response.nominal_response.has_value() &&
                   subject ==
                       response.nominal_response->product_id.identity();
          case MetricSupportRoleV1::projection_center:
            return response.projection_center.has_value() &&
                   subject ==
                       response.projection_center->product_id.identity();
          case MetricSupportRoleV1::projected_mean:
            return response.projected_mean.has_value() &&
                   subject == response.projected_mean->product_id.identity();
          case MetricSupportRoleV1::recoded_response:
            return response.recoded_response.has_value() &&
                   subject == response.recoded_response->product_id.identity();
          default: return false;
        }
      };
  if (role == MetricSupportRoleV1::deployed_payload) {
    return subject == artifact.payload_identity;
  }
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact.payload)) {
    if (response_owns_product(*response)) return true;
  }
  if (const auto* response =
          std::get_if<FinitePrefixConstantTailResponseV1>(
              &artifact.payload)) {
    if (role == MetricSupportRoleV1::raw_response) {
      return subject == response->raw_response.product_id.identity();
    }
  }
  if (const auto* envelope =
          std::get_if<ResponseEnvelopeEvidenceV1>(&artifact.payload)) {
    // Envelope ledgers retain both complete stage lineages.  Their typed
    // products may realize product roles, but neither ledger grants the
    // deployed_response role: the primary result remains the envelope.
    if (response_owns_product(envelope->lower_response) ||
        response_owns_product(envelope->upper_response)) {
      return true;
    }
  }
  if (const auto* tables =
          std::get_if<FiniteLawTablesV1>(&artifact.payload)) {
    const auto* law_id = std::visit(
        [](const auto& table) -> const ArtifactObjectReferenceV1* {
          return &table.law_id;
        },
        tables->table);
    if (role >= MetricSupportRoleV1::stationary_marked_edge_law &&
        role <= MetricSupportRoleV1::coupled_schedule_law) {
      return subject == *law_id;
    }
  }
  if (const auto* analytic =
          std::get_if<FiniteParameterAnalyticDataV1>(&artifact.payload)) {
    if (role >= MetricSupportRoleV1::stationary_marked_edge_law &&
        role <= MetricSupportRoleV1::coupled_schedule_law) {
      return vector_contains(analytic->transform_or_response_identities,
                             subject);
    }
  }
  if (std::holds_alternative<RegisteredRuntimeRecipeV1>(artifact.payload) &&
      role >= MetricSupportRoleV1::stationary_marked_edge_law &&
      role <= MetricSupportRoleV1::coupled_schedule_law) {
    return subject == artifact.payload_identity;
  }
  if (const auto* direct =
          std::get_if<DirectMetricPayloadV1>(&artifact.payload)) {
    if (role == MetricSupportRoleV1::direct_metric_value) {
      return std::any_of(
          direct->values.begin(), direct->values.end(),
          [&clause_id, &subject](const DirectMetricValueV1& value) {
            return value.metric_clause_id == clause_id &&
                   value.value_id == subject;
          });
    }
  }
  if (role == MetricSupportRoleV1::response_envelope &&
      std::holds_alternative<ResponseEnvelopeEvidenceV1>(artifact.payload)) {
    return subject == artifact.payload_identity;
  }
  const auto kind = reference_kind_for_role_v1(role);
  return role_is_scoped_evidence_v1(role) && kind.has_value() &&
         graph.resolves_as(subject, *kind);
}

[[nodiscard]] const ThreeBinScalarResponseV1*
response_ledger_owning_raw_subject_v1(
    const ArtifactObjectReferenceV1& subject,
    const SurrogateArtifactV1& artifact) {
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact.payload)) {
    return subject == response->raw_response.product_id.identity() ? response
                                                                   : nullptr;
  }
  if (const auto* envelope =
          std::get_if<ResponseEnvelopeEvidenceV1>(&artifact.payload)) {
    if (subject == envelope->lower_response.raw_response.product_id.identity()) {
      return &envelope->lower_response;
    }
    if (subject == envelope->upper_response.raw_response.product_id.identity()) {
      return &envelope->upper_response;
    }
  }
  return nullptr;
}

[[nodiscard]] std::vector<ArtifactObjectReferenceV1>
scoped_relation_projection_v1(const RealizedReferenceCoreV1& core,
                              const MetricRoleRelationKindV1 relation) {
  std::vector<ArtifactObjectReferenceV1> result;
  for (const auto& item : core.role_relations) {
    if (item.relation == relation) result.push_back(item.referenced_object);
  }
  for (const auto& item : core.internal_relations) {
    if (item.relation == relation) result.push_back(item.referenced_object);
  }
  std::sort(result.begin(), result.end());
  result.erase(std::unique(result.begin(), result.end()), result.end());
  return result;
}

[[nodiscard]] std::vector<ArtifactObjectReferenceV1>
internal_relation_projection_v1(
    const RealizedReferenceCoreV1& core,
    const MetricRoleRelationKindV1 relation,
    const InternalReferencePurposeV1 purpose) {
  std::vector<ArtifactObjectReferenceV1> result;
  for (const auto& item : core.internal_relations) {
    if (item.relation == relation && item.purpose == purpose) {
      result.push_back(item.referenced_object);
    }
  }
  std::sort(result.begin(), result.end());
  return result;
}

[[nodiscard]] bool has_one_exact_internal_reference_v1(
    const RealizedReferenceCoreV1& core,
    const MetricRoleRelationKindV1 relation,
    const InternalReferencePurposeV1 purpose,
    const ArtifactObjectReferenceV1& expected) {
  return internal_relation_projection_v1(core, relation, purpose) ==
         std::vector<ArtifactObjectReferenceV1>{expected};
}

[[nodiscard]] bool has_one_internal_reference_with_digest_v1(
    const RealizedReferenceCoreV1& core,
    const MetricRoleRelationKindV1 relation,
    const InternalReferencePurposeV1 purpose, const Digest256& expected) {
  const auto references =
      internal_relation_projection_v1(core, relation, purpose);
  return references.size() == 1U &&
         references.front().object_digest == expected;
}

[[nodiscard]] std::vector<ArtifactObjectReferenceV1>
role_relation_projection_v1(const RealizedReferenceCoreV1& core,
                            const MetricRoleRelationKindV1 relation) {
  std::vector<ArtifactObjectReferenceV1> result;
  for (const auto& item : core.role_relations) {
    if (item.relation == relation) result.push_back(item.referenced_object);
  }
  std::sort(result.begin(), result.end());
  return result;
}

[[nodiscard]] std::vector<const ThreeBinScalarResponseV1*>
response_ledgers_v1(const SurrogateArtifactV1& artifact) {
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact.payload)) {
    return {response};
  }
  if (const auto* envelope =
          std::get_if<ResponseEnvelopeEvidenceV1>(&artifact.payload)) {
    return {&envelope->lower_response, &envelope->upper_response};
  }
  return {};
}

[[nodiscard]] bool is_same_ledger_coefficient_v1(
    const ThreeBinScalarResponseV1& response,
    const ArtifactObjectReferenceV1& identity) {
  return std::any_of(
      response.raw_response.identifications.begin(),
      response.raw_response.identifications.end(),
      [&identity](const CoefficientIdentificationV1& coefficient) {
        return coefficient.coefficient_id == identity;
      });
}

[[nodiscard]] Result<void> validate_realized_owner_links_v1(
    const RealizedMetricBindingsV1& bindings,
    const SurrogateArtifactV1& artifact, const SurrogateBuildRequest& request,
    const AcceptedCapabilityContract& contract) {
  const auto responses = response_ledgers_v1(artifact);
  const auto fail_owner = [](const std::string& message) {
    return fail<void>(
        "c15.realized_owner_reference_mismatch", message,
        "/result/artifact/realized_metric_bindings/bindings");
  };

  for (const auto& binding : bindings.bindings()) {
    const auto role = binding.key.role;
    const auto& subject = realized_reference_subject_v1(binding.reference);
    const auto& core = realized_reference_core_v1(binding.reference);

    if (role == MetricSupportRoleV1::raw_response) {
      const ThreeBinScalarResponseV1* owner = nullptr;
      for (const auto* response : responses) {
        if (response->raw_response.product_id.identity() == subject) {
          owner = response;
          break;
        }
      }
      const auto origins = internal_relation_projection_v1(
          core, MetricRoleRelationKindV1::lineage_parent,
          InternalReferencePurposeV1::coefficient_origin);
      const auto* finite_prefix =
          std::get_if<FinitePrefixConstantTailResponseV1>(
              &artifact.payload);
      const bool finite_prefix_owner =
          owner == nullptr && finite_prefix != nullptr &&
          finite_prefix->raw_response.product_id.identity() == subject &&
          origins.size() == 1U &&
          std::any_of(
              finite_prefix->raw_response.identifications.begin(),
              finite_prefix->raw_response.identifications.end(),
              [&](const FinitePrefixCoefficientIdentificationV1& value) {
                return value.coefficient_id == origins.front();
              });
      if (!finite_prefix_owner &&
          (owner == nullptr || origins.size() != 1U ||
           !is_same_ledger_coefficient_v1(*owner, origins.front()))) {
        return fail_owner(
            "raw-response coefficient-origin relation must name one identification in the same retained response ledger");
      }
    }

    if (role == MetricSupportRoleV1::nominal_response) {
      const ThreeBinScalarResponseV1* owner = nullptr;
      const NominalResponseProductV1* nominal = nullptr;
      for (const auto* response : responses) {
        if (response->nominal_response.has_value() &&
            response->nominal_response->product_id.identity() == subject) {
          owner = response;
          nominal = &*response->nominal_response;
          break;
        }
      }
      if (owner == nullptr || nominal == nullptr ||
          !nominal->completion_policy_id.has_value() ||
          !has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::completion_policy,
              *nominal->completion_policy_id)) {
        return fail_owner(
            "nominal-response completion-policy relation must equal its exact payload-owned policy identity");
      }
      if (contract.policies().coefficient_completion ==
          CoefficientCompletionPolicyV1::declared_nominal_completion) {
        if (role_relation_projection_v1(
                core, MetricRoleRelationKindV1::lineage_parent) !=
            std::vector<ArtifactObjectReferenceV1>{
                nominal->raw_parent.identity()}) {
          return fail_owner(
              "declared nominal completion must name its exact raw-product parent");
        }
      } else if (contract.policies().coefficient_completion ==
                 CoefficientCompletionPolicyV1::
                     authorized_endpoint_completion) {
        const auto sources = internal_relation_projection_v1(
            core, MetricRoleRelationKindV1::lineage_parent,
            InternalReferencePurposeV1::completion_source);
        if (!role_relation_projection_v1(
                 core, MetricRoleRelationKindV1::lineage_parent)
                 .empty() ||
            sources.size() != 1U ||
            !is_same_ledger_coefficient_v1(*owner, sources.front())) {
          return fail_owner(
              "endpoint nominal completion must name one exact same-ledger coefficient source and no substituted product parent");
        }
      }
    }

    if (role == MetricSupportRoleV1::projection_center) {
      const ProjectionCenterProductV1* center = nullptr;
      for (const auto* response : responses) {
        if (response->projection_center.has_value() &&
            response->projection_center->product_id.identity() == subject) {
          center = &*response->projection_center;
          break;
        }
      }
      if (center == nullptr) {
        return fail_owner("projection-center subject has no retained owner");
      }
      const ArtifactObjectReferenceV1 source = std::visit(
          [](const auto& value) { return value.identity(); },
          center->response_source);
      if (!has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::lineage_parent,
              InternalReferencePurposeV1::projection_source, source)) {
        return fail_owner(
            "projection-center source relation must equal its exact retained response source");
      }
    }

    if (role == MetricSupportRoleV1::projected_mean) {
      const ProjectedMeanProductV1* mean = nullptr;
      for (const auto* response : responses) {
        if (response->projected_mean.has_value() &&
            response->projected_mean->product_id.identity() == subject) {
          mean = &*response->projected_mean;
          break;
        }
      }
      if (mean == nullptr ||
          role_relation_projection_v1(
              core, MetricRoleRelationKindV1::lineage_parent) !=
              std::vector<ArtifactObjectReferenceV1>{
                  mean->center_parent.identity()} ||
          !has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::projection_policy,
              mean->projection_policy_id)) {
        return fail_owner(
            "projected-mean parent and projection-policy relations must equal the exact payload-owned fields");
      }
    }

    if (role == MetricSupportRoleV1::recoded_response) {
      const ThreeBinScalarResponseV1* owner = nullptr;
      const RecodedResponseProductV1* recoded = nullptr;
      for (const auto* response : responses) {
        if (response->recoded_response.has_value() &&
            response->recoded_response->product_id.identity() == subject) {
          owner = response;
          recoded = &*response->recoded_response;
          break;
        }
      }
      std::vector<ArtifactObjectReferenceV1> expected_parents;
      if (recoded != nullptr && recoded->projected_mean_parent.has_value()) {
        expected_parents.push_back(
            recoded->projected_mean_parent->identity());
      }
      if (recoded != nullptr) {
        std::visit(
            [&](const auto& parent) {
              using Parent = std::decay_t<decltype(parent)>;
              if constexpr (!std::same_as<Parent, std::monostate>) {
                expected_parents.push_back(parent.identity());
              }
            },
            recoded->reference_response_parent);
      }
      std::sort(expected_parents.begin(), expected_parents.end());
      if (owner == nullptr || recoded == nullptr ||
          role_relation_projection_v1(
              core, MetricRoleRelationKindV1::lineage_parent) !=
              expected_parents ||
          !has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::recoding_policy,
              recoded->recoding_policy_id)) {
        return fail_owner(
            "recoded-response parents and recoding-policy relation must equal its exact payload-owned fields");
      }
      const auto completion_sources = internal_relation_projection_v1(
          core, MetricRoleRelationKindV1::lineage_parent,
          InternalReferencePurposeV1::completion_source);
      if ((recoded->derivation_kind ==
               ProductDerivationKindV1::endpoint_completion &&
           (completion_sources.size() != 1U ||
            !is_same_ledger_coefficient_v1(*owner,
                                           completion_sources.front()))) ||
          (recoded->derivation_kind !=
               ProductDerivationKindV1::endpoint_completion &&
           !completion_sources.empty())) {
        return fail_owner(
            "recoded completion-source relation does not match its exact interior or endpoint derivation form");
      }
    }

    if (role >= MetricSupportRoleV1::stationary_marked_edge_law &&
        role <= MetricSupportRoleV1::coupled_schedule_law) {
      if (role == MetricSupportRoleV1::staged_opportunity_flux_law) {
        const auto* finite =
            std::get_if<FiniteLawTablesV1>(&artifact.payload);
        const auto* staged =
            finite == nullptr
                ? nullptr
                : std::get_if<StagedOpportunityFluxTableV1>(&finite->table);
        if (staged != nullptr &&
            !has_one_exact_internal_reference_v1(
                core, MetricRoleRelationKindV1::binding,
                InternalReferencePurposeV1::stage_law,
                staged->deterministic_update_descriptor)) {
          return fail_owner(
              "staged law must bind its exact deterministic-update descriptor as the stage-law identity");
        }
      }
      for (const auto& relation : core.internal_relations) {
        if (relation.purpose ==
                InternalReferencePurposeV1::configured_arrival_binding &&
            relation.referenced_object.object_digest !=
                request.framework_problem_view()
                    .fingerprints()
                    .compiled_arrival) {
          return fail_owner(
              "law configured-arrival relation carries a stale request fingerprint");
        }
        if (relation.purpose == InternalReferencePurposeV1::selection_binding &&
            relation.referenced_object.object_digest !=
                request.framework_problem_view()
                    .fingerprints()
                    .target_selection) {
          return fail_owner(
              "law selection relation carries a stale request fingerprint");
        }
      }
    }

    if (role == MetricSupportRoleV1::direct_metric_value) {
      const auto* direct = std::get_if<DirectMetricPayloadV1>(&artifact.payload);
      const DirectMetricValueV1* value = nullptr;
      if (direct != nullptr) {
        const auto found = std::find_if(
            direct->values.begin(), direct->values.end(),
            [&](const DirectMetricValueV1& candidate) {
              return candidate.metric_clause_id == binding.key.clause_id &&
                     candidate.value_id == subject;
            });
        if (found != direct->values.end()) value = &*found;
      }
      if (value == nullptr ||
          !has_one_internal_reference_with_digest_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::normalized_request,
              value->normalized_metric_request_digest) ||
          !has_one_internal_reference_with_digest_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::selection_binding,
              value->target_selection_digest) ||
          !has_one_internal_reference_with_digest_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::configured_arrival_binding,
              value->configured_arrival_digest)) {
        return fail_owner(
            "direct metric value must bind its exact clause-local normalized request, selection and arrival digests");
      }
      std::vector<ArtifactObjectReferenceV1> evidence;
      for (const auto& relation : core.role_relations) {
        if (relation.relation == MetricRoleRelationKindV1::evidence) {
          evidence.push_back(relation.referenced_object);
        }
      }
      std::sort(evidence.begin(), evidence.end());
      if (evidence != value->evidence_ids) {
        return fail_owner(
            "direct metric evidence IDs must exactly equal its realized validity/transfer role subjects");
      }
    }

    if (role == MetricSupportRoleV1::response_envelope) {
      const auto* envelope =
          std::get_if<ResponseEnvelopeEvidenceV1>(&artifact.payload);
      if (envelope == nullptr ||
          !has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::lineage_parent,
              InternalReferencePurposeV1::lower_response_product,
              deployed_response_product_identity_v1(
                  envelope->lower_response_product)) ||
          !has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::lineage_parent,
              InternalReferencePurposeV1::upper_response_product,
              deployed_response_product_identity_v1(
                  envelope->upper_response_product))) {
        return fail_owner(
            "response-envelope lineage must name its exact lower and upper selected products");
      }
      // The object-graph stage validates the union across every same-clause
      // envelope role: scoped raw-bound/order/physical subjects exactly equal
      // typed_evidence_components, while a direct raw envelope occurs once or
      // twice only through exact lower/upper full-ledger aliasing.
    }

    if (role == MetricSupportRoleV1::optimizer_evidence) {
      const auto evaluations = internal_relation_projection_v1(
          core, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::evaluation_identity);
      const ArtifactObjectReferenceV1 report_identity{
          artifact.build_report_echo.report_id,
          artifact.build_report_echo.report_digest};
      if (!has_one_internal_reference_with_digest_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::constraint_identity,
              request.framework_problem_view().fingerprints().constraint) ||
          !has_one_exact_internal_reference_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::call_report_identity,
              report_identity) ||
          evaluations.size() != 1U ||
          !artifact.provenance.final_evaluation_id.has_value() ||
          evaluations.front().object_id !=
              *artifact.provenance.final_evaluation_id) {
        return fail_owner(
            "optimizer evidence must bind the exact constraint fingerprint, build report, and final evaluation provenance");
      }
    }

    if (role == MetricSupportRoleV1::statistical_evidence) {
      const auto banks = internal_relation_projection_v1(
          core, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::sampling_bank);
      const auto evaluations = internal_relation_projection_v1(
          core, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::evaluation_identity);
      if (banks.size() != 1U || evaluations.size() != 1U ||
          !artifact.provenance.frozen_input_bank_id.has_value() ||
          !artifact.provenance.final_evaluation_id.has_value() ||
          banks.front().object_id !=
              *artifact.provenance.frozen_input_bank_id ||
          evaluations.front().object_id !=
              *artifact.provenance.final_evaluation_id) {
        return fail_owner(
            "statistical evidence must bind the exact frozen input bank and final evaluation provenance");
      }
    }

    if (role == MetricSupportRoleV1::calibration_evidence) {
      const auto banks = internal_relation_projection_v1(
          core, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::sampling_bank);
      if (!banks.empty() &&
          (banks.size() != 1U ||
           !artifact.provenance.frozen_input_bank_id.has_value() ||
           banks.front().object_id !=
               *artifact.provenance.frozen_input_bank_id)) {
        return fail_owner(
            "calibration sampling-bank input must equal the frozen input-bank provenance identity");
      }
    }

    if (role ==
        MetricSupportRoleV1::reported_validity_or_lift_evidence) {
      if (!has_one_internal_reference_with_digest_v1(
              core, MetricRoleRelationKindV1::binding,
              InternalReferencePurposeV1::timing_binding,
              request.framework_problem_view()
                  .fingerprints()
                  .tie_and_timing)) {
        return fail_owner(
            "reported validity/lift evidence must bind the exact request tie-and-timing fingerprint");
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_realized_bindings_against_graph_v1(
    const RealizedMetricBindingsV1& bindings,
    const SurrogateArtifactV1& artifact,
    const artifact::detail::ValidatedArtifactObjectGraphV1& graph) {
  for (const auto& binding : bindings.bindings()) {
    const auto role = binding.key.role;
    const auto& subject = realized_reference_subject_v1(binding.reference);
    const auto& core = realized_reference_core_v1(binding.reference);
    const auto kind = reference_kind_for_role_v1(role);
    if (role == MetricSupportRoleV1::deployed_response) {
      const auto* deployed =
          std::get_if<DeployedResponseReferenceV1>(&binding.reference);
      const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact.payload);
      const auto* finite_prefix =
          std::get_if<FinitePrefixConstantTailResponseV1>(
              &artifact.payload);
      const bool matches =
          deployed != nullptr &&
          ((response != nullptr &&
            selected_response_subject_matches_v1(*deployed, *response)) ||
           (finite_prefix != nullptr &&
            selected_response_subject_matches_v1(*deployed,
                                                 *finite_prefix)));
      if (!matches) {
        return fail<void>(
            "c15.realized_deployed_response_mismatch",
            "deployed-response binding does not name the payload's exact selected point product",
            "/result/artifact/realized_metric_bindings/bindings");
      }
    } else if (!kind.has_value() || !graph.resolves_as(subject, *kind) ||
               !payload_owns_role_subject_v1(binding.key.clause_id, role,
                                             subject, artifact, graph)) {
      return fail<void>(
          "c15.realized_subject_resolution",
          "realized binding subject does not resolve to the exact payload-owned object kind required by its role",
          "/result/artifact/realized_metric_bindings/bindings");
    }

    if (role != MetricSupportRoleV1::deployed_response) {
      const auto* metadata = graph.find_exact(subject);
      const bool runtime_law_alias =
          std::holds_alternative<RegisteredRuntimeRecipeV1>(
              artifact.payload) &&
          role >= MetricSupportRoleV1::stationary_marked_edge_law &&
          role <= MetricSupportRoleV1::coupled_schedule_law &&
          subject == artifact.payload_identity;
      if (metadata == nullptr ||
          metadata->ordered_targets != core.ordered_targets ||
          (role != MetricSupportRoleV1::deployed_payload &&
           !runtime_law_alias &&
           (metadata->result_scope != core.result_scope ||
            metadata->evidence_scope != core.evidence_scope))) {
        return fail<void>(
            "c15.realized_subject_scope_mismatch",
            "realized subject metadata does not preserve the exact C14 target, result, and evidence scopes",
            "/result/artifact/realized_metric_bindings/bindings");
      }
    }

    for (const auto& relation : core.role_relations) {
      if (graph.find_exact(relation.referenced_object) == nullptr) {
        return fail<void>(
            "c15.realized_role_relation_unresolved",
            "realized role relation does not resolve to an exact artifact object",
            "/result/artifact/realized_metric_bindings/bindings");
      }
    }
    for (const auto& relation : core.internal_relations) {
      if (!graph.has_internal_relation(subject, relation.relation,
                                       relation.purpose,
                                       relation.referenced_object)) {
        return fail<void>(
            "c15.realized_internal_relation_unresolved",
            "realized purpose-tagged internal relation was not admitted by the validated object graph",
            "/result/artifact/realized_metric_bindings/bindings");
      }
    }

    if (role == MetricSupportRoleV1::raw_response) {
      const auto* response =
          response_ledger_owning_raw_subject_v1(subject, artifact);
      const auto* finite_prefix =
          std::get_if<FinitePrefixConstantTailResponseV1>(
              &artifact.payload);
      const bool finite_prefix_raw =
          finite_prefix != nullptr &&
          finite_prefix->raw_response.product_id.identity() == subject;
      const auto* raw =
          std::get_if<RawResponseProductReferenceV1>(&binding.reference);
      const auto expected =
          finite_prefix_raw ||
                  (response != nullptr && response_all_raw_points(*response))
              ? ResponseProductValueFormV1::exact_point
              : ResponseProductValueFormV1::interval_only;
      if ((!finite_prefix_raw && response == nullptr) || raw == nullptr ||
          raw->product.value_form != expected) {
        return fail<void>(
            "c15.realized_raw_value_form",
            "raw-response realized value form differs from the validated coefficient ledger",
            "/result/artifact/realized_metric_bindings/bindings");
      }
    }

    if (!role_is_scoped_evidence_v1(role)) continue;
    const auto scoped = std::find_if(
        artifact.scoped_evidence.begin(), artifact.scoped_evidence.end(),
        [&subject](const ScopedArtifactEvidenceV1& evidence) {
          return evidence.evidence_id == subject;
        });
    // Raw-response envelopes are the one closed non-scoped representation of
    // raw_response_bound_evidence.  The graph admits this branch only after
    // proving its exact source/coefficient/proposal/evaluation/family ledger.
    if (scoped == artifact.scoped_evidence.end() &&
        role == MetricSupportRoleV1::raw_response_bound_evidence) {
      const auto* metadata = graph.find_exact(subject);
      if (metadata != nullptr &&
          metadata->object_class ==
              artifact::detail::ArtifactObjectClassV1::
                  raw_response_envelope) {
        continue;
      }
    }
    if (scoped == artifact.scoped_evidence.end() ||
        scoped->reference_kind != *kind ||
        scoped->ordered_targets != core.ordered_targets ||
        scoped->result_scope != core.result_scope ||
        scoped->evidence_scope != core.evidence_scope ||
        scoped->internal_references != core.internal_relations ||
        scoped->subject_references != scoped_relation_projection_v1(
                                           core,
                                           MetricRoleRelationKindV1::subject) ||
        scoped->parent_references != scoped_relation_projection_v1(
                                          core,
                                          MetricRoleRelationKindV1::lineage_parent)) {
      return fail<void>(
          "c15.scoped_evidence_realized_core_mismatch",
          "scoped evidence does not exactly repeat its realized role scopes, subjects, parents, and purpose-tagged internal references",
          "/result/artifact/scoped_evidence");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] std::optional<MetricSupportRoleV1>
evidence_role_for_kind_v1(const ArtifactReferenceKindV1 kind) {
  switch (kind) {
    case ArtifactReferenceKindV1::raw_response_bound_evidence:
      return MetricSupportRoleV1::raw_response_bound_evidence;
    case ArtifactReferenceKindV1::response_order_evidence:
      return MetricSupportRoleV1::response_order_evidence;
    case ArtifactReferenceKindV1::optimizer_evidence:
      return MetricSupportRoleV1::optimizer_evidence;
    case ArtifactReferenceKindV1::statistical_evidence:
      return MetricSupportRoleV1::statistical_evidence;
    case ArtifactReferenceKindV1::numerical_evidence:
      return MetricSupportRoleV1::numerical_evidence;
    case ArtifactReferenceKindV1::calibration_evidence:
      return MetricSupportRoleV1::calibration_evidence;
    case ArtifactReferenceKindV1::compression_evidence:
      return MetricSupportRoleV1::compression_evidence;
    case ArtifactReferenceKindV1::stability_certificate:
      return MetricSupportRoleV1::stability_certificate;
    case ArtifactReferenceKindV1::reported_validity_or_lift_evidence:
      return MetricSupportRoleV1::reported_validity_or_lift_evidence;
    case ArtifactReferenceKindV1::physical_transfer_evidence:
      return MetricSupportRoleV1::physical_transfer_evidence;
    default: return std::nullopt;
  }
}

[[nodiscard]] std::optional<std::vector<QueueId>> targets_for_scope_v1(
    const MetricTargetScopeV1 scope, const MetricSupportClauseV1& clause,
    const std::vector<QueueId>& payload_targets,
    const AcceptedCapabilityContract& contract) {
  switch (scope) {
    case MetricTargetScopeV1::payload_targets: return payload_targets;
    case MetricTargetScopeV1::deployed_singleton_target:
      if (payload_targets.size() != 1U) return std::nullopt;
      return std::vector<QueueId>{payload_targets.front()};
    case MetricTargetScopeV1::ordered_metric_targets:
    case MetricTargetScopeV1::exact_request_targets:
      return clause.ordered_targets;
    case MetricTargetScopeV1::ordered_construction_targets:
      return std::vector<QueueId>(contract.construction_target_scope().begin(),
                                  contract.construction_target_scope().end());
  }
  return std::nullopt;
}

[[nodiscard]] Result<void> validate_scoped_evidence_contract_v1(
    const SurrogateArtifactV1& artifact,
    const MetricSupportManifest& manifest,
    const AcceptedCapabilityContract& contract,
    const std::vector<QueueId>& payload_targets) {
  for (const auto& evidence : artifact.scoped_evidence) {
    const auto role = evidence_role_for_kind_v1(evidence.reference_kind);
    const bool matched = role.has_value() && std::any_of(
        manifest.clauses().begin(), manifest.clauses().end(),
        [&](const MetricSupportClauseV1& clause) {
          return std::any_of(
              clause.required_roles.begin(), clause.required_roles.end(),
              [&](const MetricSupportRoleRequirementV1& requirement) {
                if (requirement.role != *role ||
                    requirement.result_scope != evidence.result_scope ||
                    requirement.evidence_scope != evidence.evidence_scope) {
                  return false;
                }
                const auto expected = targets_for_scope_v1(
                    requirement.target_scope, clause, payload_targets,
                    contract);
                return expected.has_value() &&
                       *expected == evidence.ordered_targets;
              });
        });
    if (!matched) {
      return fail<void>(
          "c15.scoped_evidence_not_accepted",
          "every scoped evidence object must exactly realize an accepted role kind, target expansion, result scope, and evidence scope",
          "/result/artifact/scoped_evidence");
    }
  }
  return Result<void>::success();
}

template <typename T, typename Name>
[[nodiscard]] bool strictly_ordered_unique_by(const std::vector<T>& values,
                                              Name&& name) {
  for (std::size_t index = 0U; index < values.size(); ++index) {
    if (name(values[index]).empty()) return false;
    if (index != 0U && !(name(values[index - 1U]) < name(values[index]))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] Result<void> validate_work_counter_v1(
    const CommonWorkCounterV1& counter,
    const CountConstructionGrantV1& grant, const std::string& path) {
  const auto expected =
      grant.applicability == BudgetApplicabilityV1::applicable
          ? WorkCounterApplicabilityV1::applicable
          : WorkCounterApplicabilityV1::not_applicable;
  if (counter.applicability != expected) {
    return fail<void>("c15.report_counter_applicability",
                      "report counter applicability differs from its exact budget grant",
                      path + "/applicability");
  }
  if (expected == WorkCounterApplicabilityV1::not_applicable) {
    if (grant.amount.has_value() || !counter.used.is_zero()) {
      return fail<void>("c15.report_nonapplicable_counter",
                        "a non-applicable counter has no grant and must report zero use",
                        path);
    }
    return Result<void>::success();
  }
  if (!grant.amount.has_value() || counter.used > *grant.amount) {
    return fail<void>("c15.report_budget_exceeded",
                      "an applicable common work counter exceeds its granted amount",
                      path + "/used");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_common_build_report_impl_v1(
    const CommonBuildReportV1& report, const SurrogateBuildRequest& request) {
  if (report.report_schema_version != request.required_build_report_schema() ||
      report.report_schema_version != kProtocolVersion) {
    return fail<void>("c15.report_schema_version",
                      "common build-report schema does not equal the requested v1 schema",
                      "/result/envelope/build_report/report_schema_version");
  }
  if (report.request_digest != request.request_digest().value()) {
    return fail<void>("c15.report_request_digest",
                      "common build report is not bound to this request",
                      "/result/envelope/build_report/request_digest");
  }
  auto budget_digest =
      digest_construction_budget_v1(request.construction_budget());
  if (!budget_digest ||
      report.construction_budget_digest != budget_digest.value()) {
    return fail<void>("c15.report_budget_digest",
                      "common build report is not bound to the exact construction budget",
                      "/result/envelope/build_report/construction_budget_digest");
  }
  auto report_digest = canonical_common_build_report_digest_v1(report);
  if (!report_digest || report.report_digest != report_digest.value()) {
    return fail<void>("c15.report_digest",
                      "common build report does not match its canonical seal",
                      "/result/envelope/build_report/report_digest");
  }
  const auto& budget = request.construction_budget();
  auto optimizer = validate_work_counter_v1(
      report.optimizer_calls, budget.exact_optimizer_calls,
      "/result/envelope/build_report/optimizer_calls");
  if (!optimizer) return optimizer;
  auto search = validate_work_counter_v1(
      report.optimizer_search_states, budget.optimizer_search_states,
      "/result/envelope/build_report/optimizer_search_states");
  if (!search) return search;
  auto draws = validate_work_counter_v1(
      report.configured_generator_draws,
      budget.configured_generator_draws,
      "/result/envelope/build_report/configured_generator_draws");
  if (!draws) return draws;

  if (!strictly_ordered_unique_by(
          report.optional_component_digests,
          [](const ArtifactComponentDigestV1& item) -> const std::string& {
            return item.component_name;
          }) ||
      std::any_of(report.optional_component_digests.begin(),
                  report.optional_component_digests.end(),
                  [](const ArtifactComponentDigestV1& item) {
                    return !digest_is_nonzero_v1(item.component_digest);
                  })) {
    return fail<void>("c15.report_component_order",
                      "optional component digests require nonempty unique canonical names and nonzero digests",
                      "/result/envelope/build_report/optional_component_digests");
  }
  if (!strictly_ordered_unique_by(
          report.optional_method_counters,
          [](const NamedPortableValueV1& item) -> const std::string& {
            return item.name;
          }) ||
      !std::all_of(report.optional_method_counters.begin(),
                   report.optional_method_counters.end(),
                   [](const NamedPortableValueV1& item) {
                     return portable_value_is_nonempty(item.value) &&
                            portable_value_is_nonnegative(item.value);
                   })) {
    return fail<void>("c15.report_method_counter",
                      "optional method counters require canonical unique names and nonnegative finite values",
                      "/result/envelope/build_report/optional_method_counters");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_request_and_envelope_v1(
    const ResultEnvelopeV1& envelope, const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateBuildReport& validated_report) {
  if (envelope.protocol_version != kProtocolVersion) {
    return fail<void>("c15.result_protocol_version",
                      "result protocol version must equal one",
                      "/result/envelope/protocol_version");
  }
  auto request_integrity =
      artifact::detail::verify_request_bindings_v1(request, manifest);
  if (!request_integrity) {
    return Result<void>::failure(request_integrity.error());
  }

  const auto& snapshot = request.accepted_capability_contract();
  const std::vector<QueueId> accepted_scope(
      accepted_contract.construction_target_scope().begin(),
      accepted_contract.construction_target_scope().end());
  const auto& classifications = request.classifications();
  if (request.provider_binding().provider != accepted_contract.provider() ||
      snapshot.structural_metric_support_manifest !=
          accepted_contract.structural_manifest() ||
      snapshot.accepted_contract_digest !=
          accepted_contract.contract_digest() ||
      snapshot.normalized_metric_requirements_digest !=
          accepted_contract.requirements_digest() ||
      snapshot.construction_target_scope != accepted_scope ||
      snapshot.construction_prerequisites !=
          accepted_contract.construction_prerequisites() ||
      snapshot.accepted_provider_policies != accepted_contract.policies() ||
      classifications.construction_method !=
          accepted_contract.construction_method() ||
      classifications.producer_mode != accepted_contract.producer_mode() ||
      classifications.proposed_payload_tag !=
          accepted_contract.payload_class().tag ||
      classifications.proposed_semantic_tag != accepted_contract.semantic() ||
      classifications.proposed_access_tag !=
          accepted_contract.runtime_access()) {
    return fail<void>("c15.accepted_contract_snapshot_mismatch",
                      "request accepted-capability snapshot is not the supplied immutable contract",
                      "/request/accepted_capability_contract");
  }
  auto parameter_digest =
      digest_surrogate_parameter_values_v1(request.validated_parameters());
  auto budget_digest =
      digest_construction_budget_v1(request.construction_budget());
  auto requirements_digest =
      canonical_metric_requirements_digest(accepted_contract.requirements());
  auto arrival_digest = canonical_arrival_capabilities_digest_v1(
      request.framework_problem_view().configured_arrival().capabilities());
  if (!parameter_digest || !budget_digest || !requirements_digest ||
      !arrival_digest ||
      parameter_digest.value() != accepted_contract.parameter_digest() ||
      budget_digest.value() != accepted_contract.budget_digest() ||
      requirements_digest.value() != accepted_contract.requirements_digest() ||
      arrival_digest.value() !=
          accepted_contract.arrival_capabilities_digest() ||
      request.framework_problem_view().configured_arrival().capabilities() !=
          accepted_contract.arrival_capabilities()) {
    return fail<void>("c15.accepted_contract_input_digest_mismatch",
                      "request parameters, budget, requirements, or arrival view differ from the supplied accepted contract",
                      "/accepted_contract");
  }
  auto accepted_core_digest = canonical_plug_descriptor_core_digest_v1(
      accepted_contract.descriptor_core());
  auto manifest_owner = std::make_shared<const MetricSupportManifest>(
      accepted_contract.structural_manifest());
  PlugDescriptorPreview reconstructed_preview{
      accepted_contract.schema_version(),
      accepted_contract.descriptor_core(),
      accepted_contract.construction_method(),
      accepted_contract.producer_mode(),
      accepted_scope,
      accepted_contract.policies(),
      accepted_contract.construction_prerequisites(),
      std::move(manifest_owner),
      request.framework_problem_view().canonical_digest().value(),
      accepted_contract.parameter_digest(),
      accepted_contract.budget_digest(),
      accepted_contract.preview_digest()};
  auto preview_digest =
      canonical_plug_descriptor_preview_digest_v1(reconstructed_preview);
  if (!accepted_core_digest ||
      accepted_core_digest.value() !=
          accepted_contract.descriptor_core().core_digest ||
      accepted_contract.descriptor_core().provider !=
          accepted_contract.provider() ||
      accepted_contract.descriptor_core().metric_support_manifest_digest !=
          accepted_contract.structural_manifest().canonical_digest() ||
      !preview_digest ||
      preview_digest.value() != accepted_contract.preview_digest()) {
    return fail<void>("c15.accepted_preview_binding_mismatch",
                      "accepted descriptor/preview was not produced from this exact problem view and contract",
                      "/accepted_contract/preview_digest");
  }
  const auto& provider_value = manifest.value();
  if (accepted_contract.schema_version() != kProtocolVersion ||
      accepted_contract.provider() != provider_value.provider ||
      accepted_contract.construction_method() !=
          provider_value.construction_method ||
      accepted_contract.producer_mode() != provider_value.producer_mode ||
      accepted_contract.payload_class() != provider_value.payload_class ||
      accepted_contract.semantic() != provider_value.deployed_semantic_tag ||
      accepted_contract.runtime_access() != provider_value.runtime_access_tag) {
    return fail<void>("c15.accepted_contract_provider_mismatch",
                      "supplied accepted contract does not select this validated provider tuple",
                      "/accepted_contract");
  }
  if (envelope.provider != accepted_contract.provider() ||
      envelope.request_digest != request.request_digest().value()) {
    return fail<void>("c15.result_envelope_binding",
                      "result provider or request digest differs from the validated request",
                      "/result/envelope");
  }
  const CommonBuildReportV1& trusted = validated_report.value();
  auto trusted_shape =
      artifact::detail::validate_common_build_report_v1(trusted, request);
  if (!trusted_shape) return trusted_shape;
  if (envelope.build_report != trusted) {
    return fail<void>("c15.report_echo_mismatch",
                      "result build-report echo differs from the trusted validated report",
                      "/result/envelope/build_report");
  }
  return Result<void>::success();
}

[[nodiscard]] bool unavailable_requires_clause(
    const UnavailableReasonKindV1 kind) {
  return kind == UnavailableReasonKindV1::coefficient_proved_zero ||
         kind == UnavailableReasonKindV1::coefficient_unresolved ||
         kind == UnavailableReasonKindV1::interval_only_without_authorized_point ||
         kind == UnavailableReasonKindV1::required_evidence_unavailable ||
         kind == UnavailableReasonKindV1::realized_capability_narrower_than_accepted;
}

[[nodiscard]] bool unavailable_requires_subject(
    const UnavailableReasonKindV1 kind) {
  return kind == UnavailableReasonKindV1::coefficient_proved_zero ||
         kind == UnavailableReasonKindV1::coefficient_unresolved ||
         kind == UnavailableReasonKindV1::interval_only_without_authorized_point;
}

[[nodiscard]] Result<void> validate_unavailable_v1(
    const std::vector<UnavailableReasonV1>& reasons,
    const std::optional<StrongestTruthfulAlternativeV1>&
        strongest_truthful_alternative,
    const AcceptedCapabilityContract& contract) {
  if (reasons.empty()) {
    return fail<void>("c15.unavailable_empty_reasons",
                      "Unavailable must carry at least one typed reason",
                      "/result/reasons");
  }
  bool has_global_reason = false;
  std::vector<MetricClauseIdV1> covered;
  for (std::size_t index = 0U; index < reasons.size(); ++index) {
    const auto& reason = reasons[index];
    const std::string path = "/result/reasons/" + std::to_string(index);
    if (std::find(reasons.begin(),
                  reasons.begin() + static_cast<std::ptrdiff_t>(index),
                  reason) !=
        reasons.begin() + static_cast<std::ptrdiff_t>(index)) {
      return fail<void>("c15.unavailable_duplicate_reason",
                        "Unavailable must not repeat an identical typed reason record",
                        path);
    }
    const auto rank = static_cast<std::uint8_t>(reason.kind);
    if (rank > static_cast<std::uint8_t>(
                   UnavailableReasonKindV1::realized_capability_narrower_than_accepted) ||
        reason.code.empty() || reason.message.empty() ||
        (unavailable_requires_clause(reason.kind) &&
         !reason.metric_clause_id.has_value()) ||
        (unavailable_requires_subject(reason.kind) &&
         !reason.subject.has_value())) {
      return fail<void>("c15.unavailable_reason_shape",
                        "Unavailable reason has an invalid closed kind or missing required fields",
                        path);
    }
    if (!reason.metric_clause_id.has_value()) {
      has_global_reason = true;
    } else {
      const bool known = std::any_of(
          contract.requirements().clauses().begin(),
          contract.requirements().clauses().end(),
          [&reason](const MetricRequirementClause& clause) {
            return clause.origin.clause_id == *reason.metric_clause_id;
          });
      if (!known) {
        return fail<void>("c15.unavailable_clause_reference",
                          "Unavailable reason names an unknown metric clause",
                          path + "/metric_clause_id");
      }
      if (!vector_contains(covered, *reason.metric_clause_id)) {
        covered.push_back(*reason.metric_clause_id);
      }
    }
  }
  if (!has_global_reason &&
      covered.size() != contract.requirements().clauses().size()) {
    return fail<void>("c15.unavailable_incomplete_reasons",
                      "Unavailable reasons do not cover every accepted metric clause",
                      "/result/reasons");
  }
  if (strongest_truthful_alternative.has_value()) {
    const auto& alternative = *strongest_truthful_alternative;
    const bool closed_payload_class =
        !alternative.payload_class.has_value() ||
        (alternative.payload_class->version == kProtocolVersion &&
         static_cast<std::uint8_t>(alternative.payload_class->tag) <=
             static_cast<std::uint8_t>(
             PayloadClassTagV1::empirical_finite_window_response_v1));
    if (alternative.description.empty() ||
        !closed_payload_class ||
        (alternative.result_scope.has_value() &&
         static_cast<std::uint8_t>(*alternative.result_scope) >
             static_cast<std::uint8_t>(MetricResultScopeV1::physical_bound))) {
      return fail<void>("c15.unavailable_alternative_shape",
                        "strongest truthful alternative has an invalid closed shape",
                        "/result/strongest_truthful_alternative");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_failed_v1(
    const ProviderFailureV1& failure) {
  if (static_cast<std::uint8_t>(failure.kind) >
          static_cast<std::uint8_t>(
              ProviderFailureKindV1::provider_internal_error) ||
      failure.code.empty() || failure.message.empty()) {
    return fail<void>("c15.provider_failure_shape",
                      "provider-authored Failed result has an invalid closed shape",
                      "/result/failure");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_built_artifact_v1(
    const BuiltSurrogateResultV1& built, const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateBuildReport& validated_report) {
  const auto& artifact = built.artifact;
  const auto& provider = manifest.value();
  const Digest256& scientific_digest =
      manifest.scientific_contract_digest().value();
  const auto payload_class = artifact_payload_class_v1(artifact.payload);
  const auto targets = payload_targets(artifact.payload);
  const std::uint32_t payload_version = std::visit(
      [](const auto& payload) { return payload.payload_version; },
      artifact.payload);

  if (artifact.artifact_protocol_version != kProtocolVersion ||
      payload_version != kProtocolVersion ||
      artifact.payload_class.version != kProtocolVersion) {
    return fail<void>("c15.built_version",
                      "built artifact and selected payload must use closed version one",
                      "/result/artifact/artifact_protocol_version");
  }
  if (artifact.request_digest != request.request_digest().value() ||
      artifact.provider != provider.provider ||
      artifact.provider_scientific_contract_digest != scientific_digest ||
      artifact.construction_method != accepted_contract.construction_method() ||
      artifact.producer_mode != accepted_contract.producer_mode() ||
      artifact.deployed_semantic != accepted_contract.semantic() ||
      artifact.runtime_access != accepted_contract.runtime_access() ||
      artifact.payload_class != accepted_contract.payload_class() ||
      artifact.payload_class != payload_class) {
    return fail<void>("c15.built_classification_binding",
                      "built artifact classifications do not exactly equal the accepted provider tuple",
                      "/result/artifact");
  }
  auto payload_digest = canonical_artifact_payload_digest_v1(artifact.payload);
  if (!payload_digest || artifact.payload_digest != payload_digest.value() ||
      artifact.payload_identity.object_digest != artifact.payload_digest) {
    return fail<void>("c15.payload_digest",
                      "built payload or payload identity does not match its canonical digest",
                      "/result/artifact/payload_digest");
  }
  if (artifact.build_report_echo != validated_report.value() ||
      artifact.build_report_echo != built.envelope.build_report) {
    return fail<void>("c15.artifact_report_echo",
                      "built artifact report echo differs from the validated result report",
                      "/result/artifact/build_report_echo");
  }
  const std::vector<QueueId> selected_targets(
      request.framework_problem_view().target_selection().ordered_targets.begin(),
      request.framework_problem_view().target_selection().ordered_targets.end());
  if (targets.empty() || !duplicate_free(targets) ||
      targets != selected_targets ||
      artifact.deployed_descriptor.deployed_targets != targets) {
    return fail<void>("c15.built_target_binding",
                      "payload targets must equal the exact accepted ordered target selection",
                      "/result/artifact/payload/ordered_deployed_targets");
  }
  if (payload_class.tag == PayloadClassTagV1::three_bin_scalar_response_v1 &&
      targets.size() != 1U) {
    return fail<void>("c15.three_bin_target_count",
                      "three-bin scalar payload requires exactly one deployed target",
                      "/result/artifact/payload/deployed_target");
  }
  if (payload_class.tag ==
          PayloadClassTagV1::finite_prefix_constant_tail_response_v1 &&
      targets.size() != 1U) {
    return fail<void>(
        "c15.finite_prefix_target_count",
        "finite-prefix constant-tail payload requires exactly one deployed "
        "target",
        "/result/artifact/payload/deployed_target");
  }
  if (!std::all_of(targets.begin(), targets.end(),
                   [&accepted_contract](const QueueId& target) {
                     return std::find(
                                accepted_contract.construction_target_scope().begin(),
                                accepted_contract.construction_target_scope().end(),
                                target) !=
                            accepted_contract.construction_target_scope().end();
                   })) {
    return fail<void>("c15.construction_scope_missing_target",
                      "accepted construction scope omits a deployed payload target",
                      "/accepted_contract/construction_target_scope");
  }
  if (artifact.deployed_descriptor != accepted_contract.descriptor_core()) {
    return fail<void>("c15.descriptor_echo_mismatch",
                      "built deployed descriptor differs from the exact accepted descriptor",
                      "/result/artifact/deployed_descriptor");
  }

  const auto& accepted_manifest = accepted_contract.structural_manifest();
  const auto& view = request.framework_problem_view();
  const auto pair = std::find(
      artifact.deployed_descriptor.applicability.scheduler_optimizer_pairs.begin(),
      artifact.deployed_descriptor.applicability.scheduler_optimizer_pairs.end(),
      view.applicability_key());
  const auto timing = std::find(
      artifact.deployed_descriptor.applicability.timing_conventions.begin(),
      artifact.deployed_descriptor.applicability.timing_conventions.end(),
      view.timing());
  if (pair == artifact.deployed_descriptor.applicability
                  .scheduler_optimizer_pairs.end() ||
      timing == artifact.deployed_descriptor.applicability
                    .timing_conventions.end()) {
    return fail<void>(
        "c15.built_applicability_mismatch",
        "accepted artifact descriptor does not admit the request's exact scheduler/optimizer pair and timing",
        "/result/artifact/deployed_descriptor/applicability");
  }

  auto family = artifact::detail::validate_family_evidence_ledger_v1(
      artifact.family_evidence, artifact.provider,
      artifact.provider_scientific_contract_digest, artifact.request_digest,
      artifact.payload_digest, accepted_contract.construction_target_scope(),
      manifest, accepted_manifest);
  if (!family) return family;

  auto non_table = artifact::detail::validate_non_table_payload_v1(
      artifact.payload, artifact, request, manifest, accepted_contract);
  if (!non_table) return non_table;

  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact.payload)) {
    auto selected = validate_three_bin_v1(
        *response, artifact, request, manifest, accepted_contract,
        "/result/artifact/payload/body");
    if (!selected) return selected;
  } else if (const auto* response =
                 std::get_if<FinitePrefixConstantTailResponseV1>(
                     &artifact.payload)) {
    auto selected = validate_finite_prefix_constant_tail_v1(
        *response, artifact, request, manifest, accepted_contract,
        "/result/artifact/payload/body");
    if (!selected) return selected;
  } else if (const auto* tables =
                 std::get_if<FiniteLawTablesV1>(&artifact.payload)) {
    auto selected = validate_finite_tables_v1(
        *tables, view, artifact.deployed_descriptor, accepted_contract,
        "/result/artifact/payload/body");
    if (!selected) return selected;
  } else if (const auto* envelope =
                 std::get_if<ResponseEnvelopeEvidenceV1>(
                     &artifact.payload)) {
    auto lower = validate_three_bin_v1(
        envelope->lower_response, artifact, request, manifest,
        accepted_contract,
        "/result/artifact/payload/body/lower_response", false);
    if (!lower) return lower;
    auto upper = validate_three_bin_v1(
        envelope->upper_response, artifact, request, manifest,
        accepted_contract,
        "/result/artifact/payload/body/upper_response", false);
    if (!upper) return upper;
  }

  // verify_request_bindings_v1 already applies the authoritative private C15
  // provider-upper-envelope relation to the request snapshot.  Stage 2 above
  // then proves that snapshot is exactly the supplied immutable contract, so
  // stage 7 does not duplicate the private narrowing predicate here.
  auto manifest_bytes =
      canonical_metric_support_manifest_bytes_v1(accepted_manifest);
  if (!manifest_bytes ||
      artifact.structural_manifest_echo.schema_version != kProtocolVersion ||
      artifact.structural_manifest_echo.manifest_digest !=
          accepted_manifest.canonical_digest() ||
      artifact.structural_manifest_echo.canonical_manifest_bytes !=
          manifest_bytes.value()) {
    return fail<void>("c15.manifest_echo_mismatch",
                      "built structural-manifest echo is not byte/semantic exact",
                      "/result/artifact/structural_manifest_echo");
  }
  auto structural = validate_metric_support_manifest(
      accepted_manifest, artifact.payload, artifact.deployed_descriptor);
  if (!structural) return Result<void>::failure(structural.error());

  if (artifact.realized_metric_bindings.request_digest !=
          artifact.request_digest ||
      artifact.realized_metric_bindings.payload_digest !=
          artifact.payload_digest) {
    return fail<void>(
        "c15.realized_binding_context_mismatch",
        "realized metric bindings do not name this exact request and payload",
        "/result/artifact/realized_metric_bindings");
  }
  RealizedBindingValidationContextV1 binding_context{
      RealizedBindingTargetContextV1{
          targets,
          targets.size() == 1U
              ? std::optional<QueueId>{targets.front()}
              : std::nullopt,
          std::vector<QueueId>(
              accepted_contract.construction_target_scope().begin(),
              accepted_contract.construction_target_scope().end())},
      accepted_contract.policies()};
  auto realized = validate_realized_metric_bindings_v1(
      accepted_manifest, binding_context,
      artifact.realized_metric_bindings.bindings);
  if (!realized) {
    return Result<void>::failure(realized.error());
  }
  auto graph = artifact::detail::validate_artifact_object_graph_v1(artifact);
  if (!graph) {
    return Result<void>::failure(graph.error());
  }
  auto resolved = validate_realized_bindings_against_graph_v1(
      realized.value(), artifact, graph.value());
  if (!resolved) return resolved;
  auto owner_links = validate_realized_owner_links_v1(
      realized.value(), artifact, request, accepted_contract);
  if (!owner_links) return owner_links;
  auto scoped_contract = validate_scoped_evidence_contract_v1(
      artifact, accepted_manifest, accepted_contract, targets);
  if (!scoped_contract) return scoped_contract;

  auto auxiliary = artifact::detail::validate_artifact_auxiliary_ledgers_v1(
      artifact.scoped_evidence, artifact.family_evidence,
      artifact.diagnostic_components, artifact.provenance,
      accepted_contract.construction_target_scope(), accepted_manifest);
  if (!auxiliary) return auxiliary;
  for (const auto& reported : validated_report.value().optional_component_digests) {
    const auto provenance = std::find_if(
        artifact.provenance.component_digests.begin(),
        artifact.provenance.component_digests.end(),
        [&reported](const ArtifactComponentDigestV1& component) {
          return component.component_name == reported.component_name;
        });
    if (provenance != artifact.provenance.component_digests.end() &&
        provenance->component_digest != reported.component_digest) {
      return fail<void>(
          "c15.provenance_report_component_mismatch",
          "same-named build-report and provenance components must carry one exact digest",
          "/result/artifact/provenance/component_digests");
    }
  }
  return Result<void>::success();
}

}  // namespace

Result<void> artifact::detail::validate_common_build_report_v1(
    const CommonBuildReportV1& report,
    const SurrogateBuildRequest& request) {
  return validate_common_build_report_impl_v1(report, request);
}

Result<ValidatedSurrogateBuildResult> validate_surrogate_build_result(
    const SurrogateBuildResult& result, const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateBuildReport& validated_build_report) {
  // Stage 1 is deliberately independent of request/report identity.  A
  // direct in-memory caller receives the same closed-version ordering as the
  // bounded wire parser: unsupported outer or Built-owned schema versions
  // fail before any stale request, contract, or accounting echo is examined.
  auto versions = validate_result_version_preflight_v1(result);
  if (!versions) {
    return Result<ValidatedSurrogateBuildResult>::failure(versions.error());
  }
  const ResultEnvelopeV1& envelope = result_envelope_v1(result);
  auto common = validate_request_and_envelope_v1(
      envelope, request, manifest, accepted_contract,
      validated_build_report);
  if (!common) {
    return Result<ValidatedSurrogateBuildResult>::failure(common.error());
  }

  if (const auto* unavailable =
          std::get_if<UnavailableSurrogateResultV1>(&result)) {
    auto shape = validate_unavailable_v1(
        unavailable->reasons, unavailable->strongest_truthful_alternative,
        accepted_contract);
    if (!shape) {
      return Result<ValidatedSurrogateBuildResult>::failure(shape.error());
    }
    return Result<ValidatedSurrogateBuildResult>::success(
        ValidatedSurrogateBuildResult(
            ValidatedUnavailableResultV1{*unavailable},
            accepted_contract.requirements()));
  }
  if (const auto* failed = std::get_if<FailedSurrogateResultV1>(&result)) {
    auto shape = validate_failed_v1(failed->failure);
    if (!shape) {
      return Result<ValidatedSurrogateBuildResult>::failure(shape.error());
    }
    return Result<ValidatedSurrogateBuildResult>::success(
        ValidatedSurrogateBuildResult(ValidatedFailedResultV1{*failed},
                                      accepted_contract.requirements()));
  }

  const auto& built = std::get<BuiltSurrogateResultV1>(result);
  auto artifact = validate_built_artifact_v1(
      built, request, manifest, accepted_contract, validated_build_report);
  if (!artifact) {
    return Result<ValidatedSurrogateBuildResult>::failure(artifact.error());
  }
  auto analysis_selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          request.framework_problem_view().analysis_selection());
  if (!analysis_selection_digest) {
    return Result<ValidatedSurrogateBuildResult>::failure(
        analysis_selection_digest.error());
  }
  ArtifactValidationBindingsV1 validation_bindings{
      request.build_identity_digest().digest(),
      request.request_digest().value(),
      request.provider_binding().provider,
      request.provider_binding().parameter_schema_version,
      request.provider_binding().provider_scientific_contract_digest.value(),
      request.classifications().construction_method,
      request.classifications().producer_mode,
      request.classifications().proposed_semantic_tag,
      request.classifications().proposed_access_tag,
      accepted_contract.payload_class(),
      request.framework_problem_view().canonical_digest().value(),
      std::move(analysis_selection_digest).value(),
      accepted_contract.contract_digest(),
      accepted_contract.requirements_digest(),
      accepted_contract.arrival_capabilities_digest(),
      accepted_contract.preview_digest(),
      accepted_contract.parameter_digest(),
      accepted_contract.budget_digest(),
      accepted_contract.structural_manifest().canonical_digest()};
  return Result<ValidatedSurrogateBuildResult>::success(
      ValidatedSurrogateBuildResult(
          ValidatedBuiltResultV1(ValidatedSurrogateArtifact(
              built.artifact, std::move(validation_bindings))),
          accepted_contract.requirements()));
}

Result<ValidatedSurrogateBuildResult> validate_surrogate_build_result_v2(
    const ResultEnvelopeV2& envelope,
    const SurrogateBuildResultBranchV2& branch,
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateBuildReport& validated_build_report) {
  if (envelope.protocol_version != 2U) {
    return fail<ValidatedSurrogateBuildResult>(
        "c30.result_protocol_version",
        "provider-result-v2 validation requires envelope protocol version two",
        "/result/envelope/protocol_version");
  }

  // Artifact, payload, terminal-reason and failure semantics remain exactly
  // v1.  Adapt only the already independently validated outer envelope to the
  // released v1 branch validator; no observation field enters capability
  // resolution or artifact validation.
  const ResultEnvelopeV1 legacy_envelope{
      1U, envelope.request_digest, envelope.provider, envelope.build_report};
  SurrogateBuildResultV1 legacy_result = std::visit(
      [&](const auto& active) -> SurrogateBuildResultV1 {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, BuiltSurrogateResultBodyV2>) {
          return BuiltSurrogateResultV1{legacy_envelope, active.artifact};
        } else if constexpr (std::same_as<
                                 Active,
                                 UnavailableSurrogateResultBodyV2>) {
          return UnavailableSurrogateResultV1{
              legacy_envelope, active.reasons,
              active.strongest_truthful_alternative};
        } else {
          static_assert(std::same_as<Active, FailedSurrogateResultBodyV2>);
          return FailedSurrogateResultV1{legacy_envelope, active.failure};
        }
      },
      branch);
  return validate_surrogate_build_result(
      legacy_result, request, manifest, accepted_contract,
      validated_build_report);
}

Result<void> validate_surrogate_build_terminal_v3(
    const SurrogateBuildResultBranchV3& branch,
    const AcceptedCapabilityContract& accepted_contract) {
  return std::visit(
      [&accepted_contract](const auto& active) -> Result<void> {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active,
                                   ObservedSurrogateResultBodyV3>) {
          return Result<void>::success();
        } else if constexpr (std::same_as<
                                 Active,
                                 UnavailableSurrogateResultBodyV2>) {
          return validate_unavailable_v1(
              active.reasons, active.strongest_truthful_alternative,
              accepted_contract);
        } else {
          static_assert(std::same_as<Active, FailedSurrogateResultBodyV2>);
          return validate_failed_v1(active.failure);
        }
      },
      branch);
}

}  // namespace mwperf
