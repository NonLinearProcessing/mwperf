#pragma once

#include <cstdint>
#include <span>
#include <vector>

#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf::artifact::detail {

// Private F-C15-06 object classes.  Several content-bound objects (for
// example coefficient identifications and response rows) intentionally have
// no C14 symbolic metric role.  Keeping them in this closed internal ledger
// still makes cross-kind ID aliasing and lineage resolution decidable.
enum class ArtifactObjectClassV1 : std::uint8_t {
  artifact_payload,
  response_row,
  coefficient_identification,
  raw_response_product,
  nominal_response_product,
  projection_center_product,
  projected_mean_product,
  recoded_response_product,
  stationary_marked_edge_law,
  staged_opportunity_flux_law,
  temporal_continuation_law,
  residence_word_law,
  stopped_path_law,
  coupled_schedule_law,
  direct_metric_value,
  response_envelope,
  raw_response_envelope,
  family_evidence,
  scoped_evidence,
  analytic_transform_or_response,
  completion_policy,
  projection_policy,
  recoding_policy,
  finite_descriptor,
  comparison_domain,
  purpose_bound_leaf,
};

struct ArtifactObjectMetadataV1 final {
  ArtifactObjectReferenceV1 identity;
  ArtifactObjectClassV1 object_class;
  std::vector<ArtifactReferenceKindV1> compatible_reference_kinds;
  std::vector<QueueId> ordered_targets;
  MetricResultScopeV1 result_scope;
  MetricEvidenceScopeV1 evidence_scope;
  bool evidence_object;

  friend bool operator==(const ArtifactObjectMetadataV1&,
                         const ArtifactObjectMetadataV1&) = default;
};

struct ArtifactObjectInternalRelationV1 final {
  ArtifactObjectReferenceV1 owner;
  MetricRoleRelationKindV1 relation;
  InternalReferencePurposeV1 purpose;
  ArtifactObjectReferenceV1 referenced_object;

  friend bool operator==(const ArtifactObjectInternalRelationV1&,
                         const ArtifactObjectInternalRelationV1&) = default;
};

// A copied index is returned rather than pointers into the untrusted artifact,
// so later F-C15-06 stages can query it without extending any public API or
// relying on vector-address stability.
struct ValidatedArtifactObjectGraphV1 final {
  std::vector<ArtifactObjectMetadataV1> objects;
  std::vector<ArtifactObjectInternalRelationV1> internal_relations;

  [[nodiscard]] const ArtifactObjectMetadataV1* find_exact(
      const ArtifactObjectReferenceV1& identity) const noexcept;
  [[nodiscard]] bool resolves_as(
      const ArtifactObjectReferenceV1& identity,
      ArtifactReferenceKindV1 reference_kind) const noexcept;
  [[nodiscard]] bool is_evidence(
      const ArtifactObjectReferenceV1& identity) const noexcept;
  [[nodiscard]] bool has_internal_relation(
      const ArtifactObjectReferenceV1& owner,
      MetricRoleRelationKindV1 relation,
      InternalReferencePurposeV1 purpose,
      const ArtifactObjectReferenceV1& referenced_object) const noexcept;
};

// Context-free structural stage of F-C15-06.  Request/provider mathematics is
// deliberately absent: the caller separately checks request bindings and C14
// role semantics.  This routine owns content-object enumeration, exact
// reference resolution and the artifact-local lineage DAG.
[[nodiscard]] Result<ValidatedArtifactObjectGraphV1>
validate_artifact_object_graph_v1(const SurrogateArtifactV1& artifact);

}  // namespace mwperf::artifact::detail
