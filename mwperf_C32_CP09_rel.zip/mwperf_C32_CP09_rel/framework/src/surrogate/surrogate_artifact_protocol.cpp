#include "mwperf/surrogate/surrogate_artifact.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <initializer_list>
#include <limits>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <type_traits>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>

#include <nlohmann/json.hpp>

#include "mwperf/math/portable_scientific_scalar.hpp"
#include "payload_wire.hpp"

namespace mwperf {
namespace {

using Json = nlohmann::ordered_json;

[[nodiscard]] Diagnostic parse_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::optional<std::string> pointer = std::nullopt) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::move(pointer), {}};
}

template <typename T>
[[nodiscard]] Result<T> parse_failure(
    const DiagnosticCategory category, std::string code, std::string message,
    std::optional<std::string> pointer = std::nullopt) {
  return Result<T>::failure(parse_diagnostic(
      category, std::move(code), std::move(message), std::move(pointer)));
}

[[nodiscard]] std::optional<std::size_t> first_invalid_utf8(
    const ByteSpan bytes) noexcept {
  std::size_t offset = 0U;
  while (offset < bytes.size()) {
    const auto first = std::to_integer<unsigned char>(bytes[offset]);
    if (first <= 0x7fU) {
      ++offset;
      continue;
    }

    std::size_t continuation_count = 0U;
    std::uint32_t code_point = 0U;
    std::uint32_t minimum = 0U;
    if (first >= 0xc2U && first <= 0xdfU) {
      continuation_count = 1U;
      code_point = static_cast<std::uint32_t>(first & 0x1fU);
      minimum = 0x80U;
    } else if (first >= 0xe0U && first <= 0xefU) {
      continuation_count = 2U;
      code_point = static_cast<std::uint32_t>(first & 0x0fU);
      minimum = 0x800U;
    } else if (first >= 0xf0U && first <= 0xf4U) {
      continuation_count = 3U;
      code_point = static_cast<std::uint32_t>(first & 0x07U);
      minimum = 0x10000U;
    } else {
      return offset;
    }

    if (continuation_count > bytes.size() - offset - 1U) {
      return offset;
    }
    for (std::size_t index = 1U; index <= continuation_count; ++index) {
      const auto continuation =
          std::to_integer<unsigned char>(bytes[offset + index]);
      if ((continuation & 0xc0U) != 0x80U) {
        return offset + index;
      }
      code_point = (code_point << 6U) |
                   static_cast<std::uint32_t>(continuation & 0x3fU);
    }
    if (code_point < minimum || code_point > 0x10ffffU ||
        (code_point >= 0xd800U && code_point <= 0xdfffU)) {
      return offset;
    }
    offset += continuation_count + 1U;
  }
  return std::nullopt;
}

// A first SAX pass enforces limits and duplicate rejection before a DOM is
// built.  nlohmann's ordinary DOM parser intentionally keeps the last value
// for a duplicate key, so performing this pass is part of the protocol rather
// than an optimization.
class BoundedSaxPreflight final : public nlohmann::json_sax<Json> {
 public:
  explicit BoundedSaxPreflight(
      const ArtifactParseLimits& limits,
      const ObservationParseLimitsV1* observation_limits = nullptr)
      : limits_(limits), observation_limits_(observation_limits) {}

  [[nodiscard]] bool null() override {
    return scalar_value(DecodedNodeBytes);
  }

  [[nodiscard]] bool boolean(bool /*unused*/) override {
    return scalar_value(DecodedNodeBytes);
  }

  [[nodiscard]] bool number_integer(number_integer_t /*unused*/) override {
    return scalar_value(DecodedNodeBytes);
  }

  [[nodiscard]] bool number_unsigned(number_unsigned_t /*unused*/) override {
    return scalar_value(DecodedNodeBytes);
  }

  [[nodiscard]] bool number_float(number_float_t /*unused*/,
                                  const string_t& /*unused*/) override {
    return reject(DiagnosticCategory::input_validation,
                  "artifact_parse_decimal_number_forbidden",
                  "decimal JSON numbers are not part of the closed v1 "
                  "artifact wire grammar");
  }

  [[nodiscard]] bool string(string_t& value) override {
    const bool observation = value_is_observation();
    if (!check_string(value, observation)) {
      return false;
    }
    if (!scalar_value(DecodedNodeBytes + DecodedStringBytes)) {
      return false;
    }
    // During the second pass the DOM string, the typed decoded value and,
    // for byte/scalar grammars, one bounded conversion buffer can coexist.
    // Charging three copies makes the protocol limit conservative without
    // depending on a particular JSON/STL allocator ABI.
    return charge(value.size(), observation) &&
           charge(value.size(), observation) &&
           charge(value.size(), observation);
  }

  [[nodiscard]] bool binary(binary_t& /*unused*/) override {
    return reject(DiagnosticCategory::input_validation,
                  "artifact_parse_binary_value_forbidden",
                  "a binary value is not valid JSON in the v1 artifact "
                  "wire grammar");
  }

  [[nodiscard]] bool start_object(std::size_t /*elements*/) override {
    const FrameScope scope = child_scope();
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= limits_.maximum_nesting_depth) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_nesting_limit",
                    "the artifact JSON exceeds the configured nesting "
                    "depth limit");
    }
    if (scope == FrameScope::observation && observation_limits_ != nullptr &&
        observation_depth_ == observation_limits_->maximum_nesting_depth) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_nesting_limit",
                    "the embedded observation JSON exceeds its configured "
                    "nesting-depth cap");
    }
    if (!charge(DecodedNodeBytes + DecodedContainerBytes,
                scope == FrameScope::observation)) {
      return false;
    }
    frames_.push_back(
        Frame{FrameKind::object, scope, ObservationArrayRole::generic, {}, {}});
    if (scope == FrameScope::observation) ++observation_depth_;
    return true;
  }

  [[nodiscard]] bool key(string_t& value) override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject(DiagnosticCategory::input_validation,
                    "artifact_parse_invalid_json",
                    "an object key appeared outside a JSON object");
    }
    const bool observation =
        frames_.back().scope == FrameScope::observation;
    if (!check_string(value, observation)) {
      return false;
    }
    if (object_entries_ == limits_.maximum_object_entries) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_object_entries_limit",
                    "the artifact JSON exceeds the configured cumulative "
                    "object-entry limit");
    }
    ++object_entries_;
    if (observation && observation_limits_ != nullptr) {
      if (observation_object_entries_ ==
          observation_limits_->maximum_object_entries) {
        return reject(DiagnosticCategory::resource_limit,
                      "observation_parse_object_entries_limit",
                      "the embedded observation JSON exceeds its configured "
                      "object-entry cap");
      }
      ++observation_object_entries_;
    }

    Frame& frame = frames_.back();
    if (frame.keys.contains(value)) {
      return reject(DiagnosticCategory::input_validation,
                    "artifact_parse_duplicate_key",
                    "the artifact JSON contains a duplicate decoded object "
                    "key");
    }
    if (!charge(DecodedStringBytes + DecodedHashEntryBytes, observation) ||
        !charge(value.size(), observation)) {
      return false;
    }
    frame.keys.insert(value);
    frame.pending_key = value;
    return true;
  }

  [[nodiscard]] bool end_object() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject(DiagnosticCategory::input_validation,
                    "artifact_parse_invalid_json",
                    "the artifact JSON has an unmatched object terminator");
    }
    if (frames_.back().scope == FrameScope::observation) {
      --observation_depth_;
    }
    frames_.pop_back();
    return true;
  }

  [[nodiscard]] bool start_array(std::size_t /*elements*/) override {
    const FrameScope scope = child_scope();
    const ObservationArrayRole role = pending_observation_array_role(scope);
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= limits_.maximum_nesting_depth) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_nesting_limit",
                    "the artifact JSON exceeds the configured nesting "
                    "depth limit");
    }
    if (scope == FrameScope::observation && observation_limits_ != nullptr &&
        observation_depth_ == observation_limits_->maximum_nesting_depth) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_nesting_limit",
                    "the embedded observation JSON exceeds its configured "
                    "nesting-depth cap");
    }
    if (!charge(DecodedNodeBytes + DecodedContainerBytes,
                scope == FrameScope::observation)) {
      return false;
    }
    frames_.push_back(Frame{FrameKind::array, scope, role, {}, {}});
    if (scope == FrameScope::observation) ++observation_depth_;
    return true;
  }

  [[nodiscard]] bool end_array() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::array) {
      return reject(DiagnosticCategory::input_validation,
                    "artifact_parse_invalid_json",
                    "the artifact JSON has an unmatched array terminator");
    }
    if (frames_.back().scope == FrameScope::observation) {
      --observation_depth_;
    }
    frames_.pop_back();
    return true;
  }

  [[nodiscard]] bool parse_error(std::size_t /*position*/,
                                 const std::string& /*last_token*/,
                                 const nlohmann::detail::exception& error)
      override {
    if (!diagnostic_.has_value()) {
      diagnostic_ = parse_diagnostic(
          DiagnosticCategory::input_validation, "artifact_parse_invalid_json",
          std::string("invalid v1 artifact JSON: ") + error.what());
    }
    return false;
  }

  [[nodiscard]] const std::optional<Diagnostic>& diagnostic() const noexcept {
    return diagnostic_;
  }

 private:
  // These constants intentionally overestimate the dynamic bookkeeping of a
  // decoded JSON node.  The allocation limit is a safety envelope, not a
  // byte-exact allocator ABI and therefore remains stable across STL/JSON
  // implementations.
  static constexpr std::size_t DecodedNodeBytes = 64U;
  static constexpr std::size_t DecodedContainerBytes = 32U;
  static constexpr std::size_t DecodedStringBytes = 32U;
  static constexpr std::size_t DecodedHashEntryBytes = 64U;

  enum class FrameKind : std::uint8_t { object, array };
  enum class FrameScope : std::uint8_t {
    root,
    envelope,
    observation,
    other,
  };
  enum class ObservationArrayRole : std::uint8_t {
    generic,
    replications,
    blocks,
    levels,
    boundary_rows,
    arrival_atoms,
    reporting_boundaries,
  };
  struct Frame final {
    FrameKind kind;
    FrameScope scope;
    ObservationArrayRole observation_array_role;
    std::unordered_set<std::string> keys;
    std::string pending_key;
  };

  [[nodiscard]] bool reject(const DiagnosticCategory category,
                            std::string code, std::string message) {
    if (!diagnostic_.has_value()) {
      diagnostic_ = parse_diagnostic(category, std::move(code),
                                     std::move(message));
    }
    return false;
  }

  [[nodiscard]] bool check_string(const std::string_view value,
                                  const bool observation) {
    if (value.size() > limits_.maximum_string_bytes) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_string_limit",
                    "the artifact JSON contains a decoded string exceeding "
                    "the configured length limit");
    }
    if (observation && observation_limits_ != nullptr &&
        value.size() > observation_limits_->maximum_string_bytes) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_string_limit",
                    "an embedded observation JSON string exceeds its "
                    "configured length cap");
    }
    return true;
  }

  [[nodiscard]] bool charge(const std::size_t amount,
                            const bool observation = false) {
    // Embedded observation nodes coexist with the outer DOM while the
    // diagnostics codec performs its bounded standalone subparse. Charge a
    // second copy to the outer simultaneous-allocation envelope, while the
    // observation-specific counter continues to describe one standalone
    // decode. V1 calls have no observation limits and retain their original
    // accounting exactly.
    const bool duplicated = observation && observation_limits_ != nullptr;
    if (duplicated && amount > std::numeric_limits<std::size_t>::max() / 2U) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_allocation_limit",
                    "embedded observation allocation charging overflowed");
    }
    const std::size_t outer_amount = duplicated ? amount * 2U : amount;
    if (outer_amount > limits_.maximum_total_decoded_allocation_bytes ||
        decoded_allocation_bytes_ >
            limits_.maximum_total_decoded_allocation_bytes - outer_amount) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_allocation_limit",
                    "the artifact JSON exceeds the configured decoded "
                    "allocation limit");
    }
    decoded_allocation_bytes_ += outer_amount;
    if (observation && observation_limits_ != nullptr) {
      if (amount >
              observation_limits_->maximum_total_decoded_allocation_bytes ||
          observation_decoded_allocation_bytes_ >
              observation_limits_->maximum_total_decoded_allocation_bytes -
                  amount) {
        return reject(DiagnosticCategory::resource_limit,
                      "observation_parse_allocation_limit",
                      "the embedded observation JSON exceeds its configured "
                      "decoded-allocation cap");
      }
      observation_decoded_allocation_bytes_ += amount;
    }
    return true;
  }

  [[nodiscard]] FrameScope child_scope() const noexcept {
    if (frames_.empty()) return FrameScope::root;
    const Frame& parent = frames_.back();
    if (parent.scope == FrameScope::observation) {
      return FrameScope::observation;
    }
    if (parent.kind != FrameKind::object) return FrameScope::other;
    if (parent.scope == FrameScope::root &&
        parent.pending_key == "envelope") {
      return FrameScope::envelope;
    }
    if (parent.scope == FrameScope::envelope &&
        (parent.pending_key == "observation_bundle" ||
         parent.pending_key == "observation_bundle_digest")) {
      return FrameScope::observation;
    }
    return FrameScope::other;
  }

  [[nodiscard]] bool value_is_observation() const noexcept {
    // A scalar has no child frame of its own.  Resolve its scope from the
    // parent's pending member just as start_object/start_array do, otherwise
    // a malformed scalar in observation_bundle could evade the tighter
    // pre-DOM string/scalar/allocation caps until typed decoding.
    return child_scope() == FrameScope::observation;
  }

  [[nodiscard]] ObservationArrayRole pending_observation_array_role(
      const FrameScope scope) const noexcept {
    if (scope != FrameScope::observation || frames_.empty() ||
        frames_.back().kind != FrameKind::object) {
      return ObservationArrayRole::generic;
    }
    const std::string_view key = frames_.back().pending_key;
    if (key == "replications") return ObservationArrayRole::replications;
    if (key == "blocks") return ObservationArrayRole::blocks;
    if (key == "levels") return ObservationArrayRole::levels;
    if (key == "rows") return ObservationArrayRole::boundary_rows;
    if (key == "atoms") return ObservationArrayRole::arrival_atoms;
    if (key == "reporting_block_boundaries") {
      return ObservationArrayRole::reporting_boundaries;
    }
    return ObservationArrayRole::generic;
  }

  [[nodiscard]] bool increment_observation_role(
      const ObservationArrayRole role) {
    if (observation_limits_ == nullptr ||
        role == ObservationArrayRole::generic) {
      return true;
    }
    std::size_t* counter = nullptr;
    std::size_t limit = 0U;
    std::string_view code;
    std::string_view name;
    switch (role) {
      case ObservationArrayRole::generic:
        return true;
      case ObservationArrayRole::replications:
        counter = &observation_replications_;
        limit = observation_limits_->maximum_replications;
        code = "observation_parse_replication_limit";
        name = "replication";
        break;
      case ObservationArrayRole::blocks:
        counter = &observation_blocks_;
        limit = observation_limits_->maximum_total_blocks;
        code = "observation_parse_block_limit";
        name = "block";
        break;
      case ObservationArrayRole::levels:
        counter = &observation_level_rows_;
        limit = observation_limits_->maximum_total_level_rows;
        code = "observation_parse_level_row_limit";
        name = "exact-level row";
        break;
      case ObservationArrayRole::boundary_rows:
        counter = &observation_boundary_rows_;
        limit = observation_limits_->maximum_total_boundary_rows;
        code = "observation_parse_boundary_row_limit";
        name = "boundary row";
        break;
      case ObservationArrayRole::arrival_atoms:
        counter = &observation_arrival_atoms_;
        limit = observation_limits_->maximum_arrival_atoms;
        code = "observation_parse_arrival_atom_limit";
        name = "arrival atom";
        break;
      case ObservationArrayRole::reporting_boundaries:
        counter = &observation_reporting_boundaries_;
        limit = observation_limits_->maximum_reporting_boundaries;
        code = "observation_parse_reporting_boundary_limit";
        name = "reporting boundary";
        break;
    }
    if (*counter == limit) {
      return reject(DiagnosticCategory::resource_limit, std::string(code),
                    "the embedded observation JSON exceeds its configured " +
                        std::string(name) + " cap");
    }
    ++*counter;
    return true;
  }

  [[nodiscard]] bool begin_value() {
    if (!frames_.empty() && frames_.back().kind == FrameKind::array) {
      if (array_entries_ == limits_.maximum_array_entries) {
        return reject(DiagnosticCategory::resource_limit,
                      "artifact_parse_array_entries_limit",
                      "the artifact JSON exceeds the configured cumulative "
                      "array-entry limit");
      }
      ++array_entries_;
      if (frames_.back().scope == FrameScope::observation &&
          observation_limits_ != nullptr) {
        if (observation_array_entries_ ==
            observation_limits_->maximum_array_entries) {
          return reject(DiagnosticCategory::resource_limit,
                        "observation_parse_array_entries_limit",
                        "the embedded observation JSON exceeds its "
                        "configured cumulative array-entry cap");
        }
        ++observation_array_entries_;
        if (!increment_observation_role(
                frames_.back().observation_array_role)) {
          return false;
        }
      }
    }
    return true;
  }

  [[nodiscard]] bool scalar_value(const std::size_t allocation) {
    if (!begin_value()) {
      return false;
    }
    if (scalar_count_ == limits_.maximum_scalar_count) {
      return reject(DiagnosticCategory::resource_limit,
                    "artifact_parse_scalar_limit",
                    "the artifact JSON exceeds the configured scalar-count "
                    "limit");
    }
    ++scalar_count_;
    const bool observation = value_is_observation();
    if (observation && observation_limits_ != nullptr) {
      if (observation_scalar_count_ ==
          observation_limits_->maximum_scalar_count) {
        return reject(DiagnosticCategory::resource_limit,
                      "observation_parse_scalar_limit",
                      "the embedded observation JSON exceeds its configured "
                      "scalar-count cap");
      }
      ++observation_scalar_count_;
    }
    return charge(allocation, observation);
  }

  const ArtifactParseLimits& limits_;
  const ObservationParseLimitsV1* observation_limits_;
  std::vector<Frame> frames_;
  std::size_t object_entries_{0U};
  std::size_t array_entries_{0U};
  std::size_t scalar_count_{0U};
  std::size_t decoded_allocation_bytes_{0U};
  std::size_t observation_depth_{0U};
  std::size_t observation_object_entries_{0U};
  std::size_t observation_array_entries_{0U};
  std::size_t observation_scalar_count_{0U};
  std::size_t observation_decoded_allocation_bytes_{0U};
  std::size_t observation_replications_{0U};
  std::size_t observation_blocks_{0U};
  std::size_t observation_level_rows_{0U};
  std::size_t observation_boundary_rows_{0U};
  std::size_t observation_arrival_atoms_{0U};
  std::size_t observation_reporting_boundaries_{0U};
  std::optional<Diagnostic> diagnostic_;
};

class DecodeError final : public std::exception {
 public:
  explicit DecodeError(Diagnostic diagnostic)
      : diagnostic_(std::move(diagnostic)) {}

  [[nodiscard]] const char* what() const noexcept override {
    return "bounded surrogate artifact wire decode failed";
  }
  [[nodiscard]] const Diagnostic& diagnostic() const noexcept {
    return diagnostic_;
  }

 private:
  Diagnostic diagnostic_;
};

[[noreturn]] void decode_fail(std::string code, std::string message,
                              std::string pointer) {
  throw DecodeError(parse_diagnostic(DiagnosticCategory::input_validation,
                                     std::move(code), std::move(message),
                                     std::move(pointer)));
}

template <typename T>
[[nodiscard]] T take_or_decode_fail(Result<T> result) {
  if (!result) {
    throw DecodeError(result.error());
  }
  return std::move(result).value();
}

[[nodiscard]] std::string pointer_token(const std::string_view value) {
  std::string escaped;
  escaped.reserve(value.size());
  for (const char character : value) {
    if (character == '~') {
      escaped += "~0";
    } else if (character == '/') {
      escaped += "~1";
    } else {
      escaped.push_back(character);
    }
  }
  return escaped;
}

[[nodiscard]] std::string child_pointer(const std::string_view parent,
                                        const std::string_view child) {
  std::string result(parent);
  result.push_back('/');
  result += pointer_token(child);
  return result;
}

[[nodiscard]] std::string index_pointer(const std::string_view parent,
                                        const std::size_t index) {
  std::string result(parent);
  result.push_back('/');
  result += std::to_string(index);
  return result;
}

[[nodiscard]] bool name_in(const std::string_view name,
                           const std::initializer_list<std::string_view>
                               candidates) noexcept {
  return std::ranges::find(candidates, name) != candidates.end();
}

void require_object_shape(
    const Json& value, const std::string_view path,
    const std::initializer_list<std::string_view> required,
    const std::initializer_list<std::string_view> optional = {}) {
  if (!value.is_object()) {
    decode_fail("artifact_wire_expected_object",
                "the v1 artifact wire field must be an object",
                std::string(path));
  }
  for (auto iterator = value.begin(); iterator != value.end(); ++iterator) {
    if (!name_in(iterator.key(), required) &&
        !name_in(iterator.key(), optional)) {
      decode_fail("artifact_wire_unknown_field",
                  "unknown field in the closed v1 artifact wire object",
                  child_pointer(path, iterator.key()));
    }
  }
  for (const std::string_view name : required) {
    if (!value.contains(std::string(name))) {
      decode_fail("artifact_wire_missing_field",
                  "required field is absent from the closed v1 artifact "
                  "wire object",
                  child_pointer(path, name));
    }
  }
}

[[nodiscard]] const Json& required_member(const Json& value,
                                          const std::string_view name,
                                          const std::string_view path) {
  const auto iterator = value.find(std::string(name));
  if (iterator == value.end()) {
    decode_fail("artifact_wire_missing_field",
                "required field is absent from the closed v1 artifact wire "
                "object",
                child_pointer(path, name));
  }
  return *iterator;
}

[[nodiscard]] std::string decode_string(const Json& value,
                                        const std::string_view path) {
  if (!value.is_string()) {
    decode_fail("artifact_wire_expected_string",
                "the v1 artifact wire field must be a string",
                std::string(path));
  }
  return value.get<std::string>();
}

[[nodiscard]] bool decode_bool(const Json& value,
                               const std::string_view path) {
  if (!value.is_boolean()) {
    decode_fail("artifact_wire_expected_boolean",
                "the v1 artifact wire field must be a boolean",
                std::string(path));
  }
  return value.get<bool>();
}

[[nodiscard]] std::uint32_t decode_u32(const Json& value,
                                       const std::string_view path) {
  if (!value.is_number_unsigned()) {
    decode_fail("artifact_wire_expected_u32",
                "the v1 artifact wire field must be an unsigned JSON "
                "integer",
                std::string(path));
  }
  const std::uint64_t decoded = value.get<std::uint64_t>();
  if (decoded > std::numeric_limits<std::uint32_t>::max()) {
    decode_fail("artifact_wire_u32_out_of_range",
                "the v1 artifact wire integer exceeds uint32 range",
                std::string(path));
  }
  return static_cast<std::uint32_t>(decoded);
}

[[nodiscard]] std::size_t decode_size_decimal(const Json& value,
                                              const std::string_view path) {
  const std::string encoded = decode_string(value, path);
  if (encoded.empty() || (encoded.size() > 1U && encoded.front() == '0')) {
    decode_fail("artifact_wire_noncanonical_size",
                "a size value must be a canonical nonnegative decimal "
                "string",
                std::string(path));
  }
  std::uint64_t decoded = 0U;
  const auto conversion = std::from_chars(
      encoded.data(), encoded.data() + encoded.size(), decoded, 10);
  if (conversion.ec != std::errc{} ||
      conversion.ptr != encoded.data() + encoded.size() ||
      decoded > std::numeric_limits<std::size_t>::max()) {
    decode_fail("artifact_wire_size_out_of_range",
                "a size value is outside the canonical platform-neutral "
                "range",
                std::string(path));
  }
  return static_cast<std::size_t>(decoded);
}

[[nodiscard]] std::vector<std::byte> decode_hex_bytes(
    const Json& value, const std::string_view path) {
  const std::string encoded = decode_string(value, path);
  if ((encoded.size() % 2U) != 0U) {
    decode_fail("artifact_wire_hex_width",
                "a canonical byte string must contain an even number of "
                "lowercase hexadecimal digits",
                std::string(path));
  }
  std::vector<std::byte> decoded;
  decoded.reserve(encoded.size() / 2U);
  const auto nibble = [](const char character) -> std::optional<unsigned int> {
    if (character >= '0' && character <= '9') {
      return static_cast<unsigned int>(character - '0');
    }
    if (character >= 'a' && character <= 'f') {
      return 10U + static_cast<unsigned int>(character - 'a');
    }
    return std::nullopt;
  };
  for (std::size_t index = 0U; index < encoded.size(); index += 2U) {
    const std::optional<unsigned int> high = nibble(encoded[index]);
    const std::optional<unsigned int> low = nibble(encoded[index + 1U]);
    if (!high.has_value() || !low.has_value()) {
      decode_fail("artifact_wire_hex_encoding",
                  "a canonical byte string must use lowercase hexadecimal",
                  std::string(path));
    }
    decoded.push_back(static_cast<std::byte>((*high << 4U) | *low));
  }
  return decoded;
}

[[nodiscard]] Json encode_hex_bytes(const std::span<const std::byte> bytes) {
  constexpr std::array<char, 16U> digits{
      '0', '1', '2', '3', '4', '5', '6', '7',
      '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
  if (bytes.size() > std::numeric_limits<std::size_t>::max() / 2U) {
    throw std::overflow_error(
        "byte-string size overflow in canonical artifact encoder");
  }
  std::string encoded;
  encoded.reserve(bytes.size() * 2U);
  for (const std::byte byte : bytes) {
    const auto value = std::to_integer<unsigned int>(byte);
    encoded.push_back(digits[(value >> 4U) & 0x0fU]);
    encoded.push_back(digits[value & 0x0fU]);
  }
  return Json(std::move(encoded));
}

template <typename T, typename Decode>
[[nodiscard]] std::vector<T> decode_array(const Json& value,
                                          const std::string_view path,
                                          Decode decode) {
  if (!value.is_array()) {
    decode_fail("artifact_wire_expected_array",
                "the v1 artifact wire field must be an array",
                std::string(path));
  }
  std::vector<T> result;
  result.reserve(value.size());
  for (std::size_t index = 0U; index < value.size(); ++index) {
    result.push_back(decode(value[index], index_pointer(path, index)));
  }
  return result;
}

template <typename T, typename Encode>
[[nodiscard]] Json encode_array(const std::span<const T> values,
                                Encode encode) {
  Json result = Json::array();
  for (const T& value : values) {
    result.push_back(encode(value));
  }
  return result;
}

template <typename T, typename Encode>
[[nodiscard]] Json encode_array(const std::vector<T>& values, Encode encode) {
  return encode_array<T>(std::span<const T>(values), std::move(encode));
}

template <typename Enum, std::size_t Size>
using EnumSpellings = std::array<std::pair<Enum, std::string_view>, Size>;

template <typename Enum, std::size_t Size>
[[nodiscard]] Json encode_enum(const Enum value,
                               const EnumSpellings<Enum, Size>& spellings) {
  const auto iterator = std::ranges::find_if(
      spellings, [value](const auto& entry) { return entry.first == value; });
  if (iterator == spellings.end()) {
    throw std::invalid_argument("invalid enum value in artifact encoder");
  }
  return Json(std::string(iterator->second));
}

template <typename Enum, std::size_t Size>
[[nodiscard]] Enum decode_enum(const Json& value,
                               const std::string_view path,
                               const EnumSpellings<Enum, Size>& spellings) {
  const std::string encoded = decode_string(value, path);
  const auto iterator = std::ranges::find_if(
      spellings,
      [&encoded](const auto& entry) { return entry.second == encoded; });
  if (iterator == spellings.end()) {
    decode_fail("artifact_wire_unknown_enum",
                "unknown value for a closed v1 artifact enum",
                std::string(path));
  }
  return iterator->first;
}

#define MWPERF_ENUM_ENTRY(Type, Name) std::pair{Type::Name, #Name}

constexpr EnumSpellings<ConstructionMethodV1, 5U> kConstructionMethods{{
    MWPERF_ENUM_ENTRY(ConstructionMethodV1, closed_form),
    MWPERF_ENUM_ENTRY(ConstructionMethodV1, engineered_deterministic),
    MWPERF_ENUM_ENTRY(ConstructionMethodV1, engineered_hybrid),
    MWPERF_ENUM_ENTRY(ConstructionMethodV1, sampled_offline),
    MWPERF_ENUM_ENTRY(ConstructionMethodV1, precomputed),
}};
constexpr EnumSpellings<ProducerModeV1, 3U> kProducerModes{{
    MWPERF_ENUM_ENTRY(ProducerModeV1, inline_immediate),
    MWPERF_ENUM_ENTRY(ProducerModeV1, in_process_builder),
    MWPERF_ENUM_ENTRY(ProducerModeV1, local_executable_builder),
}};
constexpr EnumSpellings<SemanticTagV1, 9U> kSemanticTags{{
    MWPERF_ENUM_ENTRY(SemanticTagV1, scalar_backlog_response),
    MWPERF_ENUM_ENTRY(SemanticTagV1, stationary_marked_edge),
    MWPERF_ENUM_ENTRY(SemanticTagV1, staged_opportunity_flux_law),
    MWPERF_ENUM_ENTRY(SemanticTagV1, temporal_one_slot_continuation),
    MWPERF_ENUM_ENTRY(SemanticTagV1, romr_residence_word_law),
    MWPERF_ENUM_ENTRY(SemanticTagV1, stopped_path_law),
    MWPERF_ENUM_ENTRY(SemanticTagV1, coupled_target_schedule_law),
    MWPERF_ENUM_ENTRY(SemanticTagV1, direct_metric_decoder),
    MWPERF_ENUM_ENTRY(SemanticTagV1, response_envelope_law),
}};
constexpr EnumSpellings<RuntimeAccessTagV1, 7U> kRuntimeAccessTags{{
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, finite_enumerated_row),
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, sparse_row),
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, normalized_conditional_sampler),
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, analytic_transform),
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, finite_parameter_analytic_family),
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, procedural_residence_generator),
    MWPERF_ENUM_ENTRY(RuntimeAccessTagV1, direct_metric_decoder),
}};
constexpr EnumSpellings<PayloadClassTagV1, 8U> kPayloadClassTags{{
    MWPERF_ENUM_ENTRY(PayloadClassTagV1, three_bin_scalar_response_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1, finite_parameter_analytic_data_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1, finite_law_tables_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1, registered_runtime_recipe_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1, response_envelope_evidence_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1, direct_metric_payload_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1,
                      finite_prefix_constant_tail_response_v1),
    MWPERF_ENUM_ENTRY(PayloadClassTagV1,
                      empirical_finite_window_response_v1),
}};
constexpr EnumSpellings<TargetCouplingV1, 3U> kTargetCouplings{{
    MWPERF_ENUM_ENTRY(TargetCouplingV1, scalar_target),
    MWPERF_ENUM_ENTRY(TargetCouplingV1, common_schedule_projection),
    MWPERF_ENUM_ENTRY(TargetCouplingV1, full_schedule_identity),
}};
constexpr EnumSpellings<ServiceFamily, 5U> kServiceFamilies{{
    MWPERF_ENUM_ENTRY(ServiceFamily, crossbar_matching),
    MWPERF_ENUM_ENTRY(ServiceFamily, nonoverlapping_intervals),
    MWPERF_ENUM_ENTRY(ServiceFamily, node_exclusive_matching),
    MWPERF_ENUM_ENTRY(ServiceFamily, pairwise_conflicts),
    MWPERF_ENUM_ENTRY(ServiceFamily, resource_packing),
}};
constexpr EnumSpellings<OptimizerId, 5U> kOptimizerIds{{
    MWPERF_ENUM_ENTRY(OptimizerId, hungarian_exact),
    MWPERF_ENUM_ENTRY(OptimizerId, weighted_interval_dp_exact),
    MWPERF_ENUM_ENTRY(OptimizerId, edmonds_blossom_exact),
    MWPERF_ENUM_ENTRY(OptimizerId, mwis_branch_memo_exact),
    MWPERF_ENUM_ENTRY(OptimizerId, binary_packing_memo_exact),
}};
constexpr EnumSpellings<TimingConvention, 1U> kTimingConventions{{
    MWPERF_ENUM_ENTRY(TimingConvention, early_service_late_admission),
}};
constexpr EnumSpellings<StateFieldKindV1, 8U> kStateFieldKinds{{
    MWPERF_ENUM_ENTRY(StateFieldKindV1, target_backlog),
    MWPERF_ENUM_ENTRY(StateFieldKindV1,
                      configured_arrival_predictive_phase),
    MWPERF_ENUM_ENTRY(StateFieldKindV1, surrogate_phase),
    MWPERF_ENUM_ENTRY(StateFieldKindV1, controller_memory),
    MWPERF_ENUM_ENTRY(StateFieldKindV1, resource_coordinate),
    MWPERF_ENUM_ENTRY(StateFieldKindV1, local_margin),
    MWPERF_ENUM_ENTRY(StateFieldKindV1, event_state),
    MWPERF_ENUM_ENTRY(StateFieldKindV1, entrance_label_state),
}};
constexpr EnumSpellings<FieldOwnershipV1, 2U> kFieldOwnerships{{
    MWPERF_ENUM_ENTRY(FieldOwnershipV1, framework_exact),
    MWPERF_ENUM_ENTRY(FieldOwnershipV1, surrogate_owned),
}};
constexpr EnumSpellings<MetricMarkKindV1, 18U> kMetricMarkKinds{{
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, target_backlog),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, predictive_phase),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, opportunity),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, actual_departure),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, arrival_batch),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, successor_backlog),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, schedule_projection),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, full_schedule),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, edge_increment),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, event_indicator),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, predicate),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, predicate_start),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, active_component),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, within_batch_rank),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, batch_size),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, class_label),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, phase_label),
    MWPERF_ENUM_ENTRY(MetricMarkKindV1, counterfactual_permission),
}};
constexpr EnumSpellings<MetricRevealStageV1, 6U> kMetricRevealStages{{
    MWPERF_ENUM_ENTRY(MetricRevealStageV1, predecision),
    MWPERF_ENUM_ENTRY(MetricRevealStageV1, decision),
    MWPERF_ENUM_ENTRY(MetricRevealStageV1, arrival),
    MWPERF_ENUM_ENTRY(MetricRevealStageV1, postarrival),
    MWPERF_ENUM_ENTRY(MetricRevealStageV1, completed_edge),
    MWPERF_ENUM_ENTRY(MetricRevealStageV1, entrance_label),
}};
constexpr EnumSpellings<SelectionKindV1, 11U> kSelectionKinds{{
    MWPERF_ENUM_ENTRY(SelectionKindV1, transient_initial),
    MWPERF_ENUM_ENTRY(SelectionKindV1, stationary_unique),
    MWPERF_ENUM_ENTRY(SelectionKindV1, stationary_class),
    MWPERF_ENUM_ENTRY(SelectionKindV1, stationary_mixture),
    MWPERF_ENUM_ENTRY(SelectionKindV1, fixed_point_unique),
    MWPERF_ENUM_ENTRY(SelectionKindV1, fixed_point_id),
    MWPERF_ENUM_ENTRY(SelectionKindV1, prescribed_entrance),
    MWPERF_ENUM_ENTRY(SelectionKindV1, event_palm),
    MWPERF_ENUM_ENTRY(SelectionKindV1, start_palm),
    MWPERF_ENUM_ENTRY(SelectionKindV1, admission_palm),
    MWPERF_ENUM_ENTRY(SelectionKindV1, threshold_crossing_palm),
}};
constexpr EnumSpellings<PayloadPhaseKindV1, 2U> kPayloadPhaseKinds{{
    MWPERF_ENUM_ENTRY(PayloadPhaseKindV1, phase_free),
    MWPERF_ENUM_ENTRY(PayloadPhaseKindV1, predictive_phase_indexed),
}};
constexpr EnumSpellings<ConfiguredArrivalCompositionV1, 4U>
    kArrivalCompositions{{
        MWPERF_ENUM_ENTRY(ConfiguredArrivalCompositionV1,
                          no_arrival_composition),
        MWPERF_ENUM_ENTRY(ConfiguredArrivalCompositionV1, iid_late_arrival),
        MWPERF_ENUM_ENTRY(ConfiguredArrivalCompositionV1,
                          finite_enumerated_predictive_phase),
        MWPERF_ENUM_ENTRY(ConfiguredArrivalCompositionV1,
                          sequential_predictive_phase),
    }};
constexpr EnumSpellings<FiniteHorizonCoverageKindV1, 3U>
    kFiniteHorizonCoverages{{
        MWPERF_ENUM_ENTRY(FiniteHorizonCoverageKindV1, none),
        MWPERF_ENUM_ENTRY(FiniteHorizonCoverageKindV1, bounded),
        MWPERF_ENUM_ENTRY(FiniteHorizonCoverageKindV1,
                          every_finite_horizon),
    }};
constexpr EnumSpellings<TailRepresentationKindV1, 5U>
    kTailRepresentationKinds{{
        MWPERF_ENUM_ENTRY(TailRepresentationKindV1, none),
        MWPERF_ENUM_ENTRY(TailRepresentationKindV1, finite_closed),
        MWPERF_ENUM_ENTRY(TailRepresentationKindV1, constant_response),
        MWPERF_ENUM_ENTRY(TailRepresentationKindV1, certified_truncation),
        MWPERF_ENUM_ENTRY(TailRepresentationKindV1, exact_unbounded),
    }};
constexpr EnumSpellings<ArrivalNeedKindV1, 9U> kArrivalNeedKinds{{
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, target_intensity),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, arrival_moment),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, full_common_batch),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, predictive_phase),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, sequential_law),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, entrance_labels),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, finite_support),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, transform),
    MWPERF_ENUM_ENTRY(ArrivalNeedKindV1, exact_iid_late),
}};
constexpr EnumSpellings<ArrivalCapabilityUseV1, 2U> kArrivalUses{{
    MWPERF_ENUM_ENTRY(ArrivalCapabilityUseV1, runtime),
    MWPERF_ENUM_ENTRY(ArrivalCapabilityUseV1, construction),
}};
constexpr EnumSpellings<CapabilityProvisionNeedV1, 3U> kProvisionNeeds{{
    MWPERF_ENUM_ENTRY(CapabilityProvisionNeedV1, any),
    MWPERF_ENUM_ENTRY(CapabilityProvisionNeedV1, portable),
    MWPERF_ENUM_ENTRY(CapabilityProvisionNeedV1, process_local),
}};
constexpr EnumSpellings<TransformKind, 3U> kTransformKinds{{
    MWPERF_ENUM_ENTRY(TransformKind, exact_pmf),
    MWPERF_ENUM_ENTRY(TransformKind, exact_pgf),
    MWPERF_ENUM_ENTRY(TransformKind, closed_transform),
}};
constexpr EnumSpellings<DistributionScope, 2U> kDistributionScopes{{
    MWPERF_ENUM_ENTRY(DistributionScope, joint_vector),
    MWPERF_ENUM_ENTRY(DistributionScope, per_coordinate),
}};
constexpr EnumSpellings<HypothesisKindV1, 24U> kHypothesisKinds{{
    MWPERF_ENUM_ENTRY(HypothesisKindV1, proper_stationary),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, invariant_selected),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, stable),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, recurrent),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, lossless),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, unit_packets),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, fifo),
    MWPERF_ENUM_ENTRY(HypothesisKindV1,
                      eventual_departure_or_accessible_class),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, positive_finite_intensity),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, positive_event_intensity),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, positive_start_intensity),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, positive_conditioning_mass),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, moment_finite),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, reward_integrable),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, little_law),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, finite_start_component),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, absorption),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, nondefective),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, common_schedule),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, predictive_phase),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, iid_late_arrival),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, counterfactual_empty_convention),
    MWPERF_ENUM_ENTRY(HypothesisKindV1,
                      counterfactual_no_controller_mutation),
    MWPERF_ENUM_ENTRY(HypothesisKindV1, c21_suspension_inversion),
}};
constexpr EnumSpellings<MomentVariableV1, 8U> kMomentVariables{{
    MWPERF_ENUM_ENTRY(MomentVariableV1, arrival),
    MWPERF_ENUM_ENTRY(MomentVariableV1, backlog),
    MWPERF_ENUM_ENTRY(MomentVariableV1, departure),
    MWPERF_ENUM_ENTRY(MomentVariableV1, edge_reward),
    MWPERF_ENUM_ENTRY(MomentVariableV1, fifo_delay),
    MWPERF_ENUM_ENTRY(MomentVariableV1, event_gap),
    MWPERF_ENUM_ENTRY(MomentVariableV1, binary_run),
    MWPERF_ENUM_ENTRY(MomentVariableV1, stopped_time),
}};
constexpr EnumSpellings<DeterministicToleranceKindV1, 4U>
    kToleranceKinds{{
        MWPERF_ENUM_ENTRY(DeterministicToleranceKindV1,
                          linear_residual_abs),
        MWPERF_ENUM_ENTRY(DeterministicToleranceKindV1, integration_abs),
        MWPERF_ENUM_ENTRY(DeterministicToleranceKindV1, tail_abs),
        MWPERF_ENUM_ENTRY(DeterministicToleranceKindV1, fixed_point_abs),
    }};
constexpr EnumSpellings<StatisticalIntervalKindV1, 3U>
    kStatisticalIntervals{{
        MWPERF_ENUM_ENTRY(StatisticalIntervalKindV1, exact_binomial),
        MWPERF_ENUM_ENTRY(StatisticalIntervalKindV1, hoeffding),
        MWPERF_ENUM_ENTRY(StatisticalIntervalKindV1, none),
    }};
constexpr EnumSpellings<StatisticalEstimandKindV1, 3U>
    kStatisticalEstimands{{
        MWPERF_ENUM_ENTRY(StatisticalEstimandKindV1, binary_proportion),
        MWPERF_ENUM_ENTRY(StatisticalEstimandKindV1, bounded_iid),
        MWPERF_ENUM_ENTRY(StatisticalEstimandKindV1,
                          point_with_variance_diagnostics),
    }};
constexpr EnumSpellings<V0DeclarationKindV1, 2U> kV0Kinds{{
    MWPERF_ENUM_ENTRY(V0DeclarationKindV1, absent),
    MWPERF_ENUM_ENTRY(V0DeclarationKindV1, structural_witness_required),
}};
constexpr EnumSpellings<OptionalReportedEvidenceKindV1, 4U>
    kOptionalEvidenceKinds{{
        MWPERF_ENUM_ENTRY(OptionalReportedEvidenceKindV1,
                          v1_fibre_realizability),
        MWPERF_ENUM_ENTRY(OptionalReportedEvidenceKindV1, v2_dynamic_lift),
        MWPERF_ENUM_ENTRY(OptionalReportedEvidenceKindV1, physical_fidelity),
        MWPERF_ENUM_ENTRY(OptionalReportedEvidenceKindV1,
                          empirical_validation),
    }};
constexpr EnumSpellings<ConstructionResultScopeV1, 6U>
    kConstructionResultScopes{{
        MWPERF_ENUM_ENTRY(ConstructionResultScopeV1, not_applicable),
        MWPERF_ENUM_ENTRY(ConstructionResultScopeV1, not_a_metric_result),
        MWPERF_ENUM_ENTRY(ConstructionResultScopeV1, surrogate_law),
        MWPERF_ENUM_ENTRY(ConstructionResultScopeV1, proposal_raw),
        MWPERF_ENUM_ENTRY(ConstructionResultScopeV1, response_envelope),
        MWPERF_ENUM_ENTRY(ConstructionResultScopeV1, physical_bound),
    }};
constexpr EnumSpellings<ConstructionErrorScopeV1, 11U>
    kConstructionErrorScopes{{
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, none),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, raw_static_proposal),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, nominal_static_proposal),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, projection_center),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1,
                          projected_surrogate_mean),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, recoded_static_proposal),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, optimizer_interval_raw),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1,
                          deployed_surrogate_law),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, numerical_result),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, validity_or_lift),
        MWPERF_ENUM_ENTRY(ConstructionErrorScopeV1, physical_system),
    }};
constexpr EnumSpellings<MetricSupportRoleV1, 25U> kMetricSupportRoles{{
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, deployed_payload),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, deployed_response),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, raw_response),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, nominal_response),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, projection_center),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, projected_mean),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, recoded_response),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, stationary_marked_edge_law),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, staged_opportunity_flux_law),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, temporal_continuation_law),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, residence_word_law),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, stopped_path_law),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, coupled_schedule_law),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, direct_metric_value),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, response_envelope),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, raw_response_bound_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, response_order_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, optimizer_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, statistical_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, numerical_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, calibration_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, compression_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, stability_certificate),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1,
                      reported_validity_or_lift_evidence),
    MWPERF_ENUM_ENTRY(MetricSupportRoleV1, physical_transfer_evidence),
}};
constexpr EnumSpellings<MetricTargetScopeV1, 5U> kMetricTargetScopes{{
    MWPERF_ENUM_ENTRY(MetricTargetScopeV1, payload_targets),
    MWPERF_ENUM_ENTRY(MetricTargetScopeV1, deployed_singleton_target),
    MWPERF_ENUM_ENTRY(MetricTargetScopeV1, ordered_metric_targets),
    MWPERF_ENUM_ENTRY(MetricTargetScopeV1, ordered_construction_targets),
    MWPERF_ENUM_ENTRY(MetricTargetScopeV1, exact_request_targets),
}};
constexpr EnumSpellings<MetricResultScopeV1, 5U> kMetricResultScopes{{
    MWPERF_ENUM_ENTRY(MetricResultScopeV1, not_a_metric_result),
    MWPERF_ENUM_ENTRY(MetricResultScopeV1, surrogate_law),
    MWPERF_ENUM_ENTRY(MetricResultScopeV1, proposal_raw),
    MWPERF_ENUM_ENTRY(MetricResultScopeV1, response_envelope),
    MWPERF_ENUM_ENTRY(MetricResultScopeV1, physical_bound),
}};
constexpr EnumSpellings<MetricEvidenceScopeV1, 11U> kMetricEvidenceScopes{{
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, none),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, raw_static_proposal),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, nominal_static_proposal),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, projection_center),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, projected_surrogate_mean),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, recoded_static_proposal),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, optimizer_interval_raw),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, deployed_surrogate_law),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, numerical_result),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, validity_or_lift),
    MWPERF_ENUM_ENTRY(MetricEvidenceScopeV1, physical_system),
}};
constexpr EnumSpellings<MetricRoleRelationKindV1, 4U> kRelationKinds{{
    MWPERF_ENUM_ENTRY(MetricRoleRelationKindV1, lineage_parent),
    MWPERF_ENUM_ENTRY(MetricRoleRelationKindV1, binding),
    MWPERF_ENUM_ENTRY(MetricRoleRelationKindV1, evidence),
    MWPERF_ENUM_ENTRY(MetricRoleRelationKindV1, subject),
}};
constexpr EnumSpellings<InternalReferencePurposeV1, 63U> kInternalPurposes{{
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, artifact_payload),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, coefficient_origin),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, completion_source),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, completion_policy),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, projection_source),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, projection_policy),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, recoding_policy),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, state_codec),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, mark_codec),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1,
                      configured_arrival_binding),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, selection_binding),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, initial_binding),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, stage_law),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, reveal_order),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, entrance),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, one_slot_continuation),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, adapted_positive_stop),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, word),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, terminal),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, reentry),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, killed_projection),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, projected_schedule),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1,
                      feasibility_domain_codec),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, full_schedule),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, normalized_request),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, validity_basis),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, lower_response_product),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, upper_response_product),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, comparison_domain),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, evaluation_identity),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, proposal_identity),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, exact_population),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, solver_identity),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, constraint_identity),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, call_report_identity),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1,
                      certified_product_or_envelope),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, estimand),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, sampling_bank),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, sampling_probe),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, coverage_family),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1,
                      algorithm_tolerance_policy),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, residual_or_enclosure),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, representation_domain),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, calibration_source),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, calibration_rule),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, compression_source),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, compression_destination),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, compression_rule),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, deployed_law),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, law_or_result),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, state_domain),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, class_domain),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, stability_statement),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, coordinate_codec),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, timing_binding),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, validity_witness),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, physical_model),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, physical_metric),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, transfer_theorem),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, transfer_assumption),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, transfer_direction),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, surrogate_source),
    MWPERF_ENUM_ENTRY(InternalReferencePurposeV1, error_object),
}};
constexpr EnumSpellings<ArtifactReferenceKindV1, 24U> kReferenceKinds{{
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, artifact_payload),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, raw_response_product),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, nominal_response_product),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, projection_center_product),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, projected_mean_product),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, recoded_response_product),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, stationary_marked_edge_law),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1,
                      staged_opportunity_flux_law),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, temporal_continuation_law),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, residence_word_law),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, stopped_path_law),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, coupled_schedule_law),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, direct_metric_value),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, response_envelope),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1,
                      raw_response_bound_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, response_order_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, optimizer_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, statistical_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, numerical_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, calibration_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, compression_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1, stability_certificate),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1,
                      reported_validity_or_lift_evidence),
    MWPERF_ENUM_ENTRY(ArtifactReferenceKindV1,
                      physical_transfer_evidence),
}};
constexpr EnumSpellings<ResponseProductValueFormV1, 2U> kResponseForms{{
    MWPERF_ENUM_ENTRY(ResponseProductValueFormV1, exact_point),
    MWPERF_ENUM_ENTRY(ResponseProductValueFormV1, interval_only),
}};
constexpr EnumSpellings<WorkCounterApplicabilityV1, 2U>
    kWorkCounterApplicabilities{{
        MWPERF_ENUM_ENTRY(WorkCounterApplicabilityV1, not_applicable),
        MWPERF_ENUM_ENTRY(WorkCounterApplicabilityV1, applicable),
    }};
constexpr EnumSpellings<StageTag, 14U> kStageTags{{
    MWPERF_ENUM_ENTRY(StageTag, initial_joint_atom),
    MWPERF_ENUM_ENTRY(StageTag, prearrival_closure),
    MWPERF_ENUM_ENTRY(StageTag, tie_resolution),
    MWPERF_ENUM_ENTRY(StageTag, configured_arrival),
    MWPERF_ENUM_ENTRY(StageTag, postarrival_closure),
    MWPERF_ENUM_ENTRY(StageTag, controller_post),
    MWPERF_ENUM_ENTRY(StageTag, generic_sampling),
    MWPERF_ENUM_ENTRY(StageTag, importance_proposal),
    MWPERF_ENUM_ENTRY(StageTag, training),
    MWPERF_ENUM_ENTRY(StageTag, solver_sampling),
    MWPERF_ENUM_ENTRY(StageTag, surrogate_build_input),
    MWPERF_ENUM_ENTRY(StageTag, surrogate_build_context),
    MWPERF_ENUM_ENTRY(StageTag, surrogate_build_probe),
    MWPERF_ENUM_ENTRY(StageTag, surrogate_build_final),
}};
constexpr EnumSpellings<ArtifactDiagnosticScopeV1, 9U>
    kArtifactDiagnosticScopes{{
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1,
                          construction_integration),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1,
                          input_bank_initialization),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1,
                          optimizer_certification),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1,
                          coefficient_sampling),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1, compression),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1, projection),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1, recoding),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1, solver),
        MWPERF_ENUM_ENTRY(ArtifactDiagnosticScopeV1, physical_fidelity),
    }};
constexpr EnumSpellings<UnavailableReasonKindV1, 8U> kUnavailableKinds{{
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1,
                      inapplicable_target_structure),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1, coefficient_proved_zero),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1, coefficient_unresolved),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1,
                      interval_only_without_authorized_point),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1,
                      unmet_construction_assumption),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1,
                      construction_domain_unavailable),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1,
                      required_evidence_unavailable),
    MWPERF_ENUM_ENTRY(UnavailableReasonKindV1,
                      realized_capability_narrower_than_accepted),
}};
constexpr EnumSpellings<ProviderFailureKindV1, 4U> kFailureKinds{{
    MWPERF_ENUM_ENTRY(ProviderFailureKindV1, construction_failure),
    MWPERF_ENUM_ENTRY(ProviderFailureKindV1, resource_exhausted),
    MWPERF_ENUM_ENTRY(ProviderFailureKindV1, invariant_violation),
    MWPERF_ENUM_ENTRY(ProviderFailureKindV1, provider_internal_error),
}};

#undef MWPERF_ENUM_ENTRY

[[nodiscard]] Json encode_provider(const ProviderIdentityV1& value) {
  Json result = Json::object();
  result["provider_id"] = value.provider_id;
  result["provider_version"] = value.provider_version;
  return result;
}

[[nodiscard]] ProviderIdentityV1 decode_provider(const Json& value,
                                                 const std::string& path) {
  require_object_shape(value, path, {"provider_id", "provider_version"});
  return ProviderIdentityV1{
      decode_string(required_member(value, "provider_id", path),
                    child_pointer(path, "provider_id")),
      decode_string(required_member(value, "provider_version", path),
                    child_pointer(path, "provider_version"))};
}

template <StrongIdDomainName Domain>
[[nodiscard]] Json encode_strong_id(const StrongId<Domain>& value) {
  return artifact::detail::wire::encode_typed_label(value.label());
}

template <StrongIdDomainName Domain>
[[nodiscard]] StrongId<Domain> decode_strong_id(const Json& value,
                                                const std::string& path) {
  return StrongId<Domain>(take_or_decode_fail(
      artifact::detail::wire::decode_typed_label(value, path)));
}

void require_version_one(std::uint32_t version, const std::string& path,
                         std::string_view record_name);

[[nodiscard]] Json encode_payload_class(const PayloadClassV1& value) {
  Json result = Json::object();
  result["tag"] = encode_enum(value.tag, kPayloadClassTags);
  result["version"] = value.version;
  return result;
}

[[nodiscard]] PayloadClassV1 decode_payload_class(const Json& value,
                                                  const std::string& path) {
  require_object_shape(value, path, {"tag", "version"});
  const std::uint32_t version = decode_u32(
      required_member(value, "version", path), child_pointer(path, "version"));
  require_version_one(version, child_pointer(path, "version"),
                      "payload class");
  return PayloadClassV1{
      decode_enum(required_member(value, "tag", path),
                  child_pointer(path, "tag"), kPayloadClassTags),
      version};
}

[[nodiscard]] Json encode_codec(const CodecIdentityV1& value) {
  Json result = Json::object();
  result["id"] = value.id;
  result["version"] = value.version;
  return result;
}

[[nodiscard]] CodecIdentityV1 decode_codec(const Json& value,
                                           const std::string& path) {
  require_object_shape(value, path, {"id", "version"});
  return CodecIdentityV1{
      decode_string(required_member(value, "id", path),
                    child_pointer(path, "id")),
      decode_u32(required_member(value, "version", path),
                 child_pointer(path, "version"))};
}

[[nodiscard]] Json encode_exact_rational(const ExactRational& value) {
  return artifact::detail::wire::encode_scalar(
      PortableScientificScalar::rational(value));
}

[[nodiscard]] ExactRational decode_exact_rational(const Json& value,
                                                  const std::string& path) {
  PortableScientificScalar decoded = take_or_decode_fail(
      artifact::detail::wire::decode_scalar(value, path));
  if (decoded.kind() != PortableScientificScalarKind::rational) {
    decode_fail("artifact_wire_expected_exact_rational",
                "this v1 artifact wire field requires the rational scalar "
                "alternative",
                path);
  }
  return decoded.rational_value();
}

[[nodiscard]] Json encode_exact_argument_domain(
    const ExactArgumentDomain& value) {
  Json result = Json::object();
  result["lower"] = encode_exact_rational(value.lower);
  result["upper"] = encode_exact_rational(value.upper);
  result["lower_inclusive"] = value.lower_inclusive;
  result["upper_inclusive"] = value.upper_inclusive;
  return result;
}

[[nodiscard]] ExactArgumentDomain decode_exact_argument_domain(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"lower", "upper", "lower_inclusive", "upper_inclusive"});
  return ExactArgumentDomain{
      decode_exact_rational(required_member(value, "lower", path),
                            child_pointer(path, "lower")),
      decode_exact_rational(required_member(value, "upper", path),
                            child_pointer(path, "upper")),
      decode_bool(required_member(value, "lower_inclusive", path),
                  child_pointer(path, "lower_inclusive")),
      decode_bool(required_member(value, "upper_inclusive", path),
                  child_pointer(path, "upper_inclusive"))};
}

[[nodiscard]] Json encode_scheduler_pair(
    const SchedulerConstraintPairV1& value) {
  Json result = Json::object();
  result["service_family"] = encode_enum(value.service_family,
                                           kServiceFamilies);
  result["optimizer"] = encode_enum(value.optimizer, kOptimizerIds);
  return result;
}

[[nodiscard]] SchedulerConstraintPairV1 decode_scheduler_pair(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"service_family", "optimizer"});
  return SchedulerConstraintPairV1{
      decode_enum(required_member(value, "service_family", path),
                  child_pointer(path, "service_family"), kServiceFamilies),
      decode_enum(required_member(value, "optimizer", path),
                  child_pointer(path, "optimizer"), kOptimizerIds)};
}

[[nodiscard]] Json encode_applicability(
    const SchedulerConstraintApplicabilityV1& value) {
  Json result = Json::object();
  result["scheduler_optimizer_pairs"] = encode_array(
      value.scheduler_optimizer_pairs, encode_scheduler_pair);
  result["timing_conventions"] = encode_array<TimingConvention>(
      value.timing_conventions,
      [](const TimingConvention item) {
        return encode_enum(item, kTimingConventions);
      });
  return result;
}

[[nodiscard]] SchedulerConstraintApplicabilityV1 decode_applicability(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path, {"scheduler_optimizer_pairs", "timing_conventions"});
  return SchedulerConstraintApplicabilityV1{
      decode_array<SchedulerConstraintPairV1>(
          required_member(value, "scheduler_optimizer_pairs", path),
          child_pointer(path, "scheduler_optimizer_pairs"),
          decode_scheduler_pair),
      decode_array<TimingConvention>(
          required_member(value, "timing_conventions", path),
          child_pointer(path, "timing_conventions"),
          [](const Json& item, const std::string& item_path) {
            return decode_enum(item, item_path, kTimingConventions);
          })};
}

[[nodiscard]] Json encode_state_field(const StateFieldDescriptorV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kStateFieldKinds);
  result["ownership"] = encode_enum(value.ownership, kFieldOwnerships);
  result["codec"] = encode_codec(value.codec);
  return result;
}

[[nodiscard]] StateFieldDescriptorV1 decode_state_field(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"kind", "ownership", "codec"});
  return StateFieldDescriptorV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kStateFieldKinds),
      decode_enum(required_member(value, "ownership", path),
                  child_pointer(path, "ownership"), kFieldOwnerships),
      decode_codec(required_member(value, "codec", path),
                   child_pointer(path, "codec"))};
}

[[nodiscard]] Json encode_mark(const MarkDescriptorV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kMetricMarkKinds);
  result["reveal_stage"] = encode_enum(value.reveal_stage,
                                         kMetricRevealStages);
  result["codec"] = encode_codec(value.codec);
  result["common_realization_group"] = value.common_realization_group;
  return result;
}

[[nodiscard]] MarkDescriptorV1 decode_mark(const Json& value,
                                           const std::string& path) {
  require_object_shape(
      value, path,
      {"kind", "reveal_stage", "codec", "common_realization_group"});
  return MarkDescriptorV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kMetricMarkKinds),
      decode_enum(required_member(value, "reveal_stage", path),
                  child_pointer(path, "reveal_stage"), kMetricRevealStages),
      decode_codec(required_member(value, "codec", path),
                   child_pointer(path, "codec")),
      decode_string(required_member(value, "common_realization_group", path),
                    child_pointer(path, "common_realization_group"))};
}

[[nodiscard]] Json encode_selection(const SelectionSupportV1& value) {
  Json result = Json::object();
  result["kinds"] = encode_array<SelectionKindV1>(
      value.kinds, [](const SelectionKindV1 item) {
        return encode_enum(item, kSelectionKinds);
      });
  result["named_classes"] = encode_array<TypedLabel>(
      value.named_classes, artifact::detail::wire::encode_typed_label);
  result["named_fixed_points"] = encode_array<TypedLabel>(
      value.named_fixed_points, artifact::detail::wire::encode_typed_label);
  return result;
}

[[nodiscard]] SelectionSupportV1 decode_selection(const Json& value,
                                                  const std::string& path) {
  require_object_shape(
      value, path, {"kinds", "named_classes", "named_fixed_points"});
  return SelectionSupportV1{
      decode_array<SelectionKindV1>(
          required_member(value, "kinds", path), child_pointer(path, "kinds"),
          [](const Json& item, const std::string& item_path) {
            return decode_enum(item, item_path, kSelectionKinds);
          }),
      decode_array<TypedLabel>(
          required_member(value, "named_classes", path),
          child_pointer(path, "named_classes"),
          [](const Json& item, const std::string& item_path) {
            return take_or_decode_fail(
                artifact::detail::wire::decode_typed_label(item, item_path));
          }),
      decode_array<TypedLabel>(
          required_member(value, "named_fixed_points", path),
          child_pointer(path, "named_fixed_points"),
          [](const Json& item, const std::string& item_path) {
            return take_or_decode_fail(
                artifact::detail::wire::decode_typed_label(item, item_path));
          })};
}

[[nodiscard]] Json encode_phase(const PhaseSupportV1& value) {
  Json result = Json::object();
  result["payload_phase"] = encode_enum(value.payload_phase,
                                          kPayloadPhaseKinds);
  result["arrival_composition"] = encode_enum(value.arrival_composition,
                                                kArrivalCompositions);
  result["retains_configured_predictive_phase"] =
      value.retains_configured_predictive_phase;
  if (value.predictive_phase_codec.has_value()) {
    result["predictive_phase_codec"] =
        encode_codec(*value.predictive_phase_codec);
  }
  result["finite_horizon_coverage"] = encode_enum(
      value.finite_horizon_coverage, kFiniteHorizonCoverages);
  if (value.maximum_finite_horizon.has_value()) {
    result["maximum_finite_horizon"] =
        artifact::detail::wire::encode_big_nat(
            *value.maximum_finite_horizon);
  }
  return result;
}

[[nodiscard]] PhaseSupportV1 decode_phase(const Json& value,
                                          const std::string& path) {
  require_object_shape(
      value, path,
      {"payload_phase", "arrival_composition",
       "retains_configured_predictive_phase", "finite_horizon_coverage"},
      {"predictive_phase_codec", "maximum_finite_horizon"});
  std::optional<CodecIdentityV1> codec;
  if (value.contains("predictive_phase_codec")) {
    codec = decode_codec(required_member(value, "predictive_phase_codec", path),
                         child_pointer(path, "predictive_phase_codec"));
  }
  std::optional<BigNat> horizon;
  if (value.contains("maximum_finite_horizon")) {
    const std::string member_path =
        child_pointer(path, "maximum_finite_horizon");
    horizon = take_or_decode_fail(artifact::detail::wire::decode_big_nat(
        required_member(value, "maximum_finite_horizon", path), member_path));
  }
  return PhaseSupportV1{
      decode_enum(required_member(value, "payload_phase", path),
                  child_pointer(path, "payload_phase"), kPayloadPhaseKinds),
      decode_enum(required_member(value, "arrival_composition", path),
                  child_pointer(path, "arrival_composition"),
                  kArrivalCompositions),
      decode_bool(required_member(value,
                                  "retains_configured_predictive_phase", path),
                  child_pointer(path,
                                "retains_configured_predictive_phase")),
      std::move(codec),
      decode_enum(required_member(value, "finite_horizon_coverage", path),
                  child_pointer(path, "finite_horizon_coverage"),
                  kFiniteHorizonCoverages),
      std::move(horizon)};
}

[[nodiscard]] Json encode_tail(const TailSupportV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kTailRepresentationKinds);
  if (value.boundary.has_value()) {
    result["boundary"] =
        artifact::detail::wire::encode_big_nat(*value.boundary);
  }
  if (value.certified_tail_mass.has_value()) {
    result["certified_tail_mass"] =
        encode_exact_rational(*value.certified_tail_mass);
  }
  return result;
}

[[nodiscard]] TailSupportV1 decode_tail(const Json& value,
                                        const std::string& path) {
  require_object_shape(value, path, {"kind"},
                       {"boundary", "certified_tail_mass"});
  std::optional<BigNat> boundary;
  if (value.contains("boundary")) {
    const std::string member_path = child_pointer(path, "boundary");
    boundary = take_or_decode_fail(artifact::detail::wire::decode_big_nat(
        required_member(value, "boundary", path), member_path));
  }
  std::optional<ExactRational> tail_mass;
  if (value.contains("certified_tail_mass")) {
    tail_mass = decode_exact_rational(
        required_member(value, "certified_tail_mass", path),
        child_pointer(path, "certified_tail_mass"));
  }
  return TailSupportV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kTailRepresentationKinds),
      std::move(boundary), std::move(tail_mass)};
}

[[nodiscard]] Json encode_arrival_assumption(
    const ArrivalAssumptionV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kArrivalNeedKinds);
  result["use"] = encode_enum(value.use, kArrivalUses);
  result["provision"] = encode_enum(value.provision, kProvisionNeeds);
  if (value.moment_order.has_value()) {
    result["moment_order"] =
        artifact::detail::wire::encode_big_nat(*value.moment_order);
  }
  result["joint"] = value.joint;
  result["phase_conditioned"] = value.phase_conditioned;
  if (value.transform_kind.has_value()) {
    result["transform_kind"] =
        encode_enum(*value.transform_kind, kTransformKinds);
  }
  if (value.distribution_scope.has_value()) {
    result["distribution_scope"] =
        encode_enum(*value.distribution_scope, kDistributionScopes);
  }
  if (value.argument_domain.has_value()) {
    result["argument_domain"] =
        encode_exact_argument_domain(*value.argument_domain);
  }
  return result;
}

[[nodiscard]] ArrivalAssumptionV1 decode_arrival_assumption(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"kind", "use", "provision", "joint", "phase_conditioned"},
      {"moment_order", "transform_kind", "distribution_scope",
       "argument_domain"});
  std::optional<BigNat> moment;
  if (value.contains("moment_order")) {
    const std::string member_path = child_pointer(path, "moment_order");
    moment = take_or_decode_fail(artifact::detail::wire::decode_big_nat(
        required_member(value, "moment_order", path), member_path));
  }
  std::optional<TransformKind> transform;
  if (value.contains("transform_kind")) {
    transform = decode_enum(required_member(value, "transform_kind", path),
                            child_pointer(path, "transform_kind"),
                            kTransformKinds);
  }
  std::optional<DistributionScope> scope;
  if (value.contains("distribution_scope")) {
    scope = decode_enum(required_member(value, "distribution_scope", path),
                        child_pointer(path, "distribution_scope"),
                        kDistributionScopes);
  }
  std::optional<ExactArgumentDomain> domain;
  if (value.contains("argument_domain")) {
    domain = decode_exact_argument_domain(
        required_member(value, "argument_domain", path),
        child_pointer(path, "argument_domain"));
  }
  return ArrivalAssumptionV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kArrivalNeedKinds),
      decode_enum(required_member(value, "use", path),
                  child_pointer(path, "use"), kArrivalUses),
      decode_enum(required_member(value, "provision", path),
                  child_pointer(path, "provision"), kProvisionNeeds),
      std::move(moment),
      decode_bool(required_member(value, "joint", path),
                  child_pointer(path, "joint")),
      decode_bool(required_member(value, "phase_conditioned", path),
                  child_pointer(path, "phase_conditioned")),
      transform, scope, std::move(domain)};
}

[[nodiscard]] Json encode_hypothesis(const HypothesisClaimV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kHypothesisKinds);
  if (value.variable.has_value()) {
    result["variable"] = encode_enum(*value.variable, kMomentVariables);
  }
  if (value.order.has_value()) {
    result["order"] =
        artifact::detail::wire::encode_big_nat(*value.order);
  }
  if (value.convention_or_class.has_value()) {
    result["convention_or_class"] =
        artifact::detail::wire::encode_typed_label(
            *value.convention_or_class);
  }
  return result;
}

[[nodiscard]] HypothesisClaimV1 decode_hypothesis(const Json& value,
                                                  const std::string& path) {
  require_object_shape(value, path, {"kind"},
                       {"variable", "order", "convention_or_class"});
  std::optional<MomentVariableV1> variable;
  if (value.contains("variable")) {
    variable = decode_enum(required_member(value, "variable", path),
                           child_pointer(path, "variable"), kMomentVariables);
  }
  std::optional<BigNat> order;
  if (value.contains("order")) {
    const std::string member_path = child_pointer(path, "order");
    order = take_or_decode_fail(artifact::detail::wire::decode_big_nat(
        required_member(value, "order", path), member_path));
  }
  std::optional<TypedLabel> convention;
  if (value.contains("convention_or_class")) {
    const std::string member_path =
        child_pointer(path, "convention_or_class");
    convention = take_or_decode_fail(
        artifact::detail::wire::decode_typed_label(
            required_member(value, "convention_or_class", path), member_path));
  }
  return HypothesisClaimV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kHypothesisKinds),
      variable, std::move(order), std::move(convention)};
}

[[nodiscard]] Json encode_tolerance(const DeterministicToleranceV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kToleranceKinds);
  result["maximum_absolute_error"] =
      encode_exact_rational(value.maximum_absolute_error);
  return result;
}

[[nodiscard]] DeterministicToleranceV1 decode_tolerance(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"kind", "maximum_absolute_error"});
  return DeterministicToleranceV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kToleranceKinds),
      decode_exact_rational(required_member(value, "maximum_absolute_error",
                                            path),
                            child_pointer(path, "maximum_absolute_error"))};
}

[[nodiscard]] Json encode_accuracy(const AccuracyContractV1& value) {
  Json result = Json::object();
  std::visit(
      [&result](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        Json body = Json::object();
        if constexpr (std::same_as<Active, EnumeratedAccuracyV1>) {
          result["tag"] = "enumerated";
          body["tolerances"] =
              encode_array(active.tolerances, encode_tolerance);
        } else if constexpr (std::same_as<Active, AnalyticAccuracyV1>) {
          result["tag"] = "analytic";
          body["precision_bits"] =
              artifact::detail::wire::encode_big_nat(active.precision_bits);
          body["tolerances"] =
              encode_array(active.tolerances, encode_tolerance);
        } else if constexpr (std::same_as<Active, MonteCarloAccuracyV1>) {
          result["tag"] = "monte_carlo";
          body["replications"] =
              artifact::detail::wire::encode_big_nat(active.replications);
          body["confidence_level"] =
              encode_exact_rational(active.confidence_level);
          body["interval"] = encode_enum(active.interval,
                                           kStatisticalIntervals);
          body["estimand"] = encode_enum(active.estimand,
                                           kStatisticalEstimands);
          if (active.almost_sure_lower.has_value()) {
            body["almost_sure_lower"] =
                encode_exact_rational(*active.almost_sure_lower);
          }
          if (active.almost_sure_upper.has_value()) {
            body["almost_sure_upper"] =
                encode_exact_rational(*active.almost_sure_upper);
          }
        } else {
          static_assert(std::same_as<Active, DirectExactAccuracyV1>);
          result["tag"] = "direct_exact";
        }
        result["value"] = std::move(body);
      },
      value);
  return result;
}

[[nodiscard]] AccuracyContractV1 decode_accuracy(const Json& value,
                                                 const std::string& path) {
  require_object_shape(value, path, {"tag", "value"});
  const std::string tag = decode_string(required_member(value, "tag", path),
                                        child_pointer(path, "tag"));
  const Json& body = required_member(value, "value", path);
  const std::string body_path = child_pointer(path, "value");
  if (tag == "enumerated") {
    require_object_shape(body, body_path, {"tolerances"});
    return EnumeratedAccuracyV1{decode_array<DeterministicToleranceV1>(
        required_member(body, "tolerances", body_path),
        child_pointer(body_path, "tolerances"), decode_tolerance)};
  }
  if (tag == "analytic") {
    require_object_shape(body, body_path, {"precision_bits", "tolerances"});
    const std::string precision_path =
        child_pointer(body_path, "precision_bits");
    return AnalyticAccuracyV1{
        take_or_decode_fail(artifact::detail::wire::decode_big_nat(
            required_member(body, "precision_bits", body_path),
            precision_path)),
        decode_array<DeterministicToleranceV1>(
            required_member(body, "tolerances", body_path),
            child_pointer(body_path, "tolerances"), decode_tolerance)};
  }
  if (tag == "monte_carlo") {
    require_object_shape(
        body, body_path,
        {"replications", "confidence_level", "interval", "estimand"},
        {"almost_sure_lower", "almost_sure_upper"});
    std::optional<ExactRational> lower;
    if (body.contains("almost_sure_lower")) {
      lower = decode_exact_rational(
          required_member(body, "almost_sure_lower", body_path),
          child_pointer(body_path, "almost_sure_lower"));
    }
    std::optional<ExactRational> upper;
    if (body.contains("almost_sure_upper")) {
      upper = decode_exact_rational(
          required_member(body, "almost_sure_upper", body_path),
          child_pointer(body_path, "almost_sure_upper"));
    }
    const std::string replications_path =
        child_pointer(body_path, "replications");
    return MonteCarloAccuracyV1{
        take_or_decode_fail(artifact::detail::wire::decode_big_nat(
            required_member(body, "replications", body_path),
            replications_path)),
        decode_exact_rational(
            required_member(body, "confidence_level", body_path),
            child_pointer(body_path, "confidence_level")),
        decode_enum(required_member(body, "interval", body_path),
                    child_pointer(body_path, "interval"),
                    kStatisticalIntervals),
        decode_enum(required_member(body, "estimand", body_path),
                    child_pointer(body_path, "estimand"),
                    kStatisticalEstimands),
        std::move(lower), std::move(upper)};
  }
  if (tag == "direct_exact") {
    require_object_shape(body, body_path, {});
    return DirectExactAccuracyV1{};
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown accuracy alternative in the closed v1 artifact wire",
              child_pointer(path, "tag"));
}

[[nodiscard]] Json encode_v0(const V0DeclarationV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kV0Kinds);
  result["factor_schema_id"] = value.factor_schema_id;
  result["factor_schema_version"] = value.factor_schema_version;
  return result;
}

[[nodiscard]] V0DeclarationV1 decode_v0(const Json& value,
                                        const std::string& path) {
  require_object_shape(
      value, path, {"kind", "factor_schema_id", "factor_schema_version"});
  return V0DeclarationV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kV0Kinds),
      decode_string(required_member(value, "factor_schema_id", path),
                    child_pointer(path, "factor_schema_id")),
      decode_u32(required_member(value, "factor_schema_version", path),
                 child_pointer(path, "factor_schema_version"))};
}

[[nodiscard]] Json encode_optional_evidence(
    const OptionalReportedEvidenceV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kOptionalEvidenceKinds);
  result["witness_schema_id"] = value.witness_schema_id;
  result["witness_schema_version"] = value.witness_schema_version;
  return result;
}

[[nodiscard]] OptionalReportedEvidenceV1 decode_optional_evidence(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path, {"kind", "witness_schema_id", "witness_schema_version"});
  return OptionalReportedEvidenceV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kOptionalEvidenceKinds),
      decode_string(required_member(value, "witness_schema_id", path),
                    child_pointer(path, "witness_schema_id")),
      decode_u32(required_member(value, "witness_schema_version", path),
                 child_pointer(path, "witness_schema_version"))};
}

[[nodiscard]] Json encode_construction_scope(
    const ConstructionScopeClaimV1& value) {
  Json result = Json::object();
  result["result_scope"] =
      encode_enum(value.result_scope, kConstructionResultScopes);
  result["error_scope"] =
      encode_enum(value.error_scope, kConstructionErrorScopes);
  return result;
}

[[nodiscard]] ConstructionScopeClaimV1 decode_construction_scope(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"result_scope", "error_scope"});
  return ConstructionScopeClaimV1{
      decode_enum(required_member(value, "result_scope", path),
                  child_pointer(path, "result_scope"),
                  kConstructionResultScopes),
      decode_enum(required_member(value, "error_scope", path),
                  child_pointer(path, "error_scope"),
                  kConstructionErrorScopes)};
}

[[nodiscard]] Json encode_descriptor(const PlugDescriptorCore& value) {
  Json result = Json::object();
  result["schema_version"] = value.schema_version;
  result["provider"] = encode_provider(value.provider);
  result["applicability"] = encode_applicability(value.applicability);
  result["payload_class"] = encode_payload_class(value.payload_class);
  result["semantic"] = encode_enum(value.semantic, kSemanticTags);
  result["runtime_access"] =
      encode_enum(value.runtime_access, kRuntimeAccessTags);
  result["deployed_targets"] = encode_array<QueueId>(
      value.deployed_targets,
      [](const QueueId& target) { return encode_strong_id(target); });
  result["target_coupling"] =
      encode_enum(value.target_coupling, kTargetCouplings);
  result["state_fields"] =
      encode_array(value.state_fields, encode_state_field);
  result["marks"] = encode_array(value.marks, encode_mark);
  result["selection"] = encode_selection(value.selection);
  result["phase"] = encode_phase(value.phase);
  result["tail"] = encode_tail(value.tail);
  result["arrival_assumptions"] =
      encode_array(value.arrival_assumptions, encode_arrival_assumption);
  result["hypothesis_claims"] =
      encode_array(value.hypothesis_claims, encode_hypothesis);
  result["mandatory_v0"] = encode_v0(value.mandatory_v0);
  result["optional_reported_evidence"] = encode_array(
      value.optional_reported_evidence, encode_optional_evidence);
  result["accuracy_support"] =
      encode_array(value.accuracy_support, encode_accuracy);
  result["construction_scope"] =
      encode_construction_scope(value.construction_scope);
  result["metric_support_manifest_digest"] =
      artifact::detail::wire::encode_digest(
          value.metric_support_manifest_digest);
  result["core_digest"] =
      artifact::detail::wire::encode_digest(value.core_digest);
  return result;
}

[[nodiscard]] PlugDescriptorCore decode_descriptor(const Json& value,
                                                   const std::string& path) {
  require_object_shape(
      value, path,
      {"schema_version", "provider", "applicability", "payload_class",
       "semantic", "runtime_access", "deployed_targets", "target_coupling",
       "state_fields", "marks", "selection", "phase", "tail",
       "arrival_assumptions", "hypothesis_claims", "mandatory_v0",
       "optional_reported_evidence", "accuracy_support",
       "construction_scope", "metric_support_manifest_digest",
       "core_digest"});
  const auto digest_member = [&value, &path](const std::string_view name) {
    const std::string member_path = child_pointer(path, name);
    return take_or_decode_fail(artifact::detail::wire::decode_digest(
        required_member(value, name, path), member_path));
  };
  return PlugDescriptorCore{
      decode_u32(required_member(value, "schema_version", path),
                 child_pointer(path, "schema_version")),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      decode_applicability(required_member(value, "applicability", path),
                           child_pointer(path, "applicability")),
      decode_payload_class(required_member(value, "payload_class", path),
                           child_pointer(path, "payload_class")),
      decode_enum(required_member(value, "semantic", path),
                  child_pointer(path, "semantic"), kSemanticTags),
      decode_enum(required_member(value, "runtime_access", path),
                  child_pointer(path, "runtime_access"), kRuntimeAccessTags),
      decode_array<QueueId>(
          required_member(value, "deployed_targets", path),
          child_pointer(path, "deployed_targets"),
          [](const Json& item, const std::string& item_path) {
            return decode_strong_id<"queue">(item, item_path);
          }),
      decode_enum(required_member(value, "target_coupling", path),
                  child_pointer(path, "target_coupling"), kTargetCouplings),
      decode_array<StateFieldDescriptorV1>(
          required_member(value, "state_fields", path),
          child_pointer(path, "state_fields"), decode_state_field),
      decode_array<MarkDescriptorV1>(
          required_member(value, "marks", path), child_pointer(path, "marks"),
          decode_mark),
      decode_selection(required_member(value, "selection", path),
                       child_pointer(path, "selection")),
      decode_phase(required_member(value, "phase", path),
                   child_pointer(path, "phase")),
      decode_tail(required_member(value, "tail", path),
                  child_pointer(path, "tail")),
      decode_array<ArrivalAssumptionV1>(
          required_member(value, "arrival_assumptions", path),
          child_pointer(path, "arrival_assumptions"),
          decode_arrival_assumption),
      decode_array<HypothesisClaimV1>(
          required_member(value, "hypothesis_claims", path),
          child_pointer(path, "hypothesis_claims"), decode_hypothesis),
      decode_v0(required_member(value, "mandatory_v0", path),
                child_pointer(path, "mandatory_v0")),
      decode_array<OptionalReportedEvidenceV1>(
          required_member(value, "optional_reported_evidence", path),
          child_pointer(path, "optional_reported_evidence"),
          decode_optional_evidence),
      decode_array<AccuracyContractV1>(
          required_member(value, "accuracy_support", path),
          child_pointer(path, "accuracy_support"), decode_accuracy),
      decode_construction_scope(
          required_member(value, "construction_scope", path),
          child_pointer(path, "construction_scope")),
      digest_member("metric_support_manifest_digest"),
      digest_member("core_digest")};
}

[[nodiscard]] Json encode_metric_role_key(const MetricRoleKeyV1& value) {
  Json result = Json::object();
  Json clause = Json::object();
  clause["metric_id"] = value.clause_id.metric_id;
  clause["authored_index"] = std::to_string(value.clause_id.authored_index);
  result["clause_id"] = std::move(clause);
  result["role"] = encode_enum(value.role, kMetricSupportRoles);
  return result;
}

[[nodiscard]] MetricRoleKeyV1 decode_metric_role_key(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"clause_id", "role"});
  const Json& clause = required_member(value, "clause_id", path);
  const std::string clause_path = child_pointer(path, "clause_id");
  require_object_shape(clause, clause_path, {"metric_id", "authored_index"});
  return MetricRoleKeyV1{
      MetricClauseIdV1{
          decode_string(required_member(clause, "metric_id", clause_path),
                        child_pointer(clause_path, "metric_id")),
          decode_size_decimal(
              required_member(clause, "authored_index", clause_path),
              child_pointer(clause_path, "authored_index"))},
      decode_enum(required_member(value, "role", path),
                  child_pointer(path, "role"), kMetricSupportRoles)};
}

[[nodiscard]] Json encode_role_relation(const RealizedRoleRelationV1& value) {
  Json result = Json::object();
  result["relation"] = encode_enum(value.relation, kRelationKinds);
  result["key"] = encode_metric_role_key(value.key);
  result["referenced_object"] =
      artifact::detail::wire::encode_artifact_object_reference(
          value.referenced_object);
  return result;
}

[[nodiscard]] RealizedRoleRelationV1 decode_role_relation(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"relation", "key", "referenced_object"});
  const std::string reference_path =
      child_pointer(path, "referenced_object");
  return RealizedRoleRelationV1{
      decode_enum(required_member(value, "relation", path),
                  child_pointer(path, "relation"), kRelationKinds),
      decode_metric_role_key(required_member(value, "key", path),
                             child_pointer(path, "key")),
      take_or_decode_fail(
          artifact::detail::wire::decode_artifact_object_reference(
              required_member(value, "referenced_object", path),
              reference_path))};
}

[[nodiscard]] Json encode_internal_relation(
    const RealizedInternalReferenceV1& value) {
  Json result = Json::object();
  result["relation"] = encode_enum(value.relation, kRelationKinds);
  result["purpose"] = encode_enum(value.purpose, kInternalPurposes);
  result["referenced_object"] =
      artifact::detail::wire::encode_artifact_object_reference(
          value.referenced_object);
  return result;
}

[[nodiscard]] RealizedInternalReferenceV1 decode_internal_relation(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"relation", "purpose", "referenced_object"});
  const std::string reference_path =
      child_pointer(path, "referenced_object");
  return RealizedInternalReferenceV1{
      decode_enum(required_member(value, "relation", path),
                  child_pointer(path, "relation"), kRelationKinds),
      decode_enum(required_member(value, "purpose", path),
                  child_pointer(path, "purpose"), kInternalPurposes),
      take_or_decode_fail(
          artifact::detail::wire::decode_artifact_object_reference(
              required_member(value, "referenced_object", path),
              reference_path))};
}

[[nodiscard]] Json encode_reference_core(const RealizedReferenceCoreV1& value) {
  Json result = Json::object();
  result["ordered_targets"] = encode_array<QueueId>(
      value.ordered_targets,
      [](const QueueId& target) { return encode_strong_id(target); });
  result["target_scope"] =
      encode_enum(value.target_scope, kMetricTargetScopes);
  result["result_scope"] =
      encode_enum(value.result_scope, kMetricResultScopes);
  result["evidence_scope"] =
      encode_enum(value.evidence_scope, kMetricEvidenceScopes);
  result["role_relations"] =
      encode_array(value.role_relations, encode_role_relation);
  result["internal_relations"] =
      encode_array(value.internal_relations, encode_internal_relation);
  return result;
}

[[nodiscard]] RealizedReferenceCoreV1 decode_reference_core(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"ordered_targets", "target_scope", "result_scope", "evidence_scope",
       "role_relations", "internal_relations"});
  return RealizedReferenceCoreV1{
      decode_array<QueueId>(
          required_member(value, "ordered_targets", path),
          child_pointer(path, "ordered_targets"),
          [](const Json& item, const std::string& item_path) {
            return decode_strong_id<"queue">(item, item_path);
          }),
      decode_enum(required_member(value, "target_scope", path),
                  child_pointer(path, "target_scope"), kMetricTargetScopes),
      decode_enum(required_member(value, "result_scope", path),
                  child_pointer(path, "result_scope"), kMetricResultScopes),
      decode_enum(required_member(value, "evidence_scope", path),
                  child_pointer(path, "evidence_scope"),
                  kMetricEvidenceScopes),
      decode_array<RealizedRoleRelationV1>(
          required_member(value, "role_relations", path),
          child_pointer(path, "role_relations"), decode_role_relation),
      decode_array<RealizedInternalReferenceV1>(
          required_member(value, "internal_relations", path),
          child_pointer(path, "internal_relations"),
          decode_internal_relation)};
}

[[nodiscard]] Json encode_deployed_response_subject(
    const DeployedResponseProductReferenceV1& value) {
  Json result = Json::object();
  std::visit(
      [&result](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, RawResponseProductRef>) {
          result["stage"] = "raw_response";
          result["identity"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.identity);
          result["value_form"] = encode_enum(active.value_form,
                                               kResponseForms);
        } else if constexpr (std::same_as<Active,
                                          NominalResponseProductRef>) {
          result["stage"] = "nominal_response";
          result["identity"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.identity);
        } else {
          static_assert(std::same_as<Active, RecodedResponseProductRef>);
          result["stage"] = "recoded_response";
          result["identity"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.identity);
        }
      },
      value);
  return result;
}

[[nodiscard]] DeployedResponseProductReferenceV1
decode_deployed_response_subject(const Json& value,
                                 const std::string& path) {
  require_object_shape(value, path, {"stage", "identity"}, {"value_form"});
  const std::string stage = decode_string(required_member(value, "stage", path),
                                          child_pointer(path, "stage"));
  const std::string identity_path = child_pointer(path, "identity");
  ArtifactObjectReferenceV1 identity = take_or_decode_fail(
      artifact::detail::wire::decode_artifact_object_reference(
          required_member(value, "identity", path), identity_path));
  if (stage == "raw_response") {
    if (!value.contains("value_form")) {
      decode_fail("artifact_wire_missing_field",
                  "a raw deployed-response reference requires value_form",
                  child_pointer(path, "value_form"));
    }
    return RawResponseProductRef{
        std::move(identity),
        decode_enum(required_member(value, "value_form", path),
                    child_pointer(path, "value_form"), kResponseForms)};
  }
  if (value.contains("value_form")) {
    decode_fail("artifact_wire_union_field_forbidden",
                "value_form is valid only for a raw response reference",
                child_pointer(path, "value_form"));
  }
  if (stage == "nominal_response") {
    return NominalResponseProductRef{std::move(identity)};
  }
  if (stage == "recoded_response") {
    return RecodedResponseProductRef{std::move(identity)};
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown deployed-response stage in the closed v1 wire",
              child_pointer(path, "stage"));
}

[[nodiscard]] Json encode_raw_response_reference_subject(
    const RawResponseProductRef& value) {
  Json result = Json::object();
  result["identity"] =
      artifact::detail::wire::encode_artifact_object_reference(value.identity);
  result["value_form"] = encode_enum(value.value_form, kResponseForms);
  return result;
}

[[nodiscard]] RawResponseProductRef decode_raw_response_reference_subject(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"identity", "value_form"});
  const std::string identity_path = child_pointer(path, "identity");
  return RawResponseProductRef{
      take_or_decode_fail(
          artifact::detail::wire::decode_artifact_object_reference(
              required_member(value, "identity", path), identity_path)),
      decode_enum(required_member(value, "value_form", path),
                  child_pointer(path, "value_form"), kResponseForms)};
}

[[nodiscard]] Json encode_realized_reference(
    const RealizedReferenceV1& value) {
  Json result = Json::object();
  result["tag"] =
      encode_enum(realized_reference_role_v1(value), kMetricSupportRoles);
  result["core"] = encode_reference_core(realized_reference_core_v1(value));
  std::visit(
      [&result](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active,
                                  DeployedPayloadReferenceV1>) {
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.payload.identity);
        } else if constexpr (std::same_as<Active,
                                         DeployedResponseReferenceV1>) {
          result["subject"] =
              encode_deployed_response_subject(active.selected_product);
        } else if constexpr (std::same_as<Active,
                                         RawResponseProductReferenceV1>) {
          result["subject"] =
              encode_raw_response_reference_subject(active.product);
        } else if constexpr (
            std::same_as<Active, NominalResponseProductReferenceV1> ||
            std::same_as<Active, ProjectionCenterProductReferenceV1> ||
            std::same_as<Active, ProjectedMeanProductReferenceV1> ||
            std::same_as<Active, RecodedResponseProductReferenceV1>) {
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.product.identity);
        } else if constexpr (
            std::same_as<Active, StationaryMarkedEdgeLawReferenceV1> ||
            std::same_as<Active, StagedOpportunityFluxLawReferenceV1> ||
            std::same_as<Active, TemporalContinuationLawReferenceV1> ||
            std::same_as<Active, ResidenceWordLawReferenceV1> ||
            std::same_as<Active, StoppedPathLawReferenceV1> ||
            std::same_as<Active, CoupledScheduleLawReferenceV1>) {
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.law.identity);
        } else if constexpr (std::same_as<Active,
                                         DirectMetricValueReferenceV1>) {
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.value.identity);
        } else if constexpr (std::same_as<Active,
                                         ResponseEnvelopeReferenceV1>) {
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.envelope.identity);
        } else if constexpr (
            std::same_as<Active, RawResponseBoundEvidenceReferenceV1> ||
            std::same_as<Active, ResponseOrderEvidenceReferenceV1> ||
            std::same_as<Active, OptimizerEvidenceReferenceV1> ||
            std::same_as<Active, StatisticalEvidenceReferenceV1> ||
            std::same_as<Active, NumericalEvidenceReferenceV1> ||
            std::same_as<Active, CalibrationEvidenceReferenceV1> ||
            std::same_as<Active, CompressionEvidenceReferenceV1> ||
            std::same_as<Active,
                         ReportedValidityOrLiftEvidenceReferenceV1> ||
            std::same_as<Active, PhysicalTransferEvidenceReferenceV1>) {
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.evidence.identity);
        } else {
          static_assert(std::same_as<Active,
                                     StabilityCertificateReferenceV1>);
          result["subject"] =
              artifact::detail::wire::encode_artifact_object_reference(
                  active.certificate.identity);
        }
      },
      value);
  return result;
}

[[nodiscard]] RealizedReferenceV1 decode_realized_reference(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"tag", "core", "subject"});
  const MetricSupportRoleV1 tag = decode_enum(
      required_member(value, "tag", path), child_pointer(path, "tag"),
      kMetricSupportRoles);
  RealizedReferenceCoreV1 core = decode_reference_core(
      required_member(value, "core", path), child_pointer(path, "core"));
  const Json& subject_json = required_member(value, "subject", path);
  const std::string subject_path = child_pointer(path, "subject");
  if (tag == MetricSupportRoleV1::deployed_response) {
    return DeployedResponseReferenceV1{
        std::move(core),
        decode_deployed_response_subject(subject_json, subject_path)};
  }
  if (tag == MetricSupportRoleV1::raw_response) {
    return RawResponseProductReferenceV1{
        std::move(core),
        decode_raw_response_reference_subject(subject_json, subject_path)};
  }
  ArtifactObjectReferenceV1 identity = take_or_decode_fail(
      artifact::detail::wire::decode_artifact_object_reference(
          subject_json, subject_path));
  switch (tag) {
    case MetricSupportRoleV1::deployed_payload:
      return DeployedPayloadReferenceV1{
          std::move(core), ArtifactPayloadRef{std::move(identity)}};
    case MetricSupportRoleV1::deployed_response:
    case MetricSupportRoleV1::raw_response:
      break;
    case MetricSupportRoleV1::nominal_response:
      return NominalResponseProductReferenceV1{
          std::move(core), NominalResponseProductRef{std::move(identity)}};
    case MetricSupportRoleV1::projection_center:
      return ProjectionCenterProductReferenceV1{
          std::move(core), ProjectionCenterProductRef{std::move(identity)}};
    case MetricSupportRoleV1::projected_mean:
      return ProjectedMeanProductReferenceV1{
          std::move(core), ProjectedMeanProductRef{std::move(identity)}};
    case MetricSupportRoleV1::recoded_response:
      return RecodedResponseProductReferenceV1{
          std::move(core), RecodedResponseProductRef{std::move(identity)}};
    case MetricSupportRoleV1::stationary_marked_edge_law:
      return StationaryMarkedEdgeLawReferenceV1{
          std::move(core), StationaryMarkedEdgeLawRef{std::move(identity)}};
    case MetricSupportRoleV1::staged_opportunity_flux_law:
      return StagedOpportunityFluxLawReferenceV1{
          std::move(core), StagedOpportunityFluxLawRef{std::move(identity)}};
    case MetricSupportRoleV1::temporal_continuation_law:
      return TemporalContinuationLawReferenceV1{
          std::move(core), TemporalContinuationLawRef{std::move(identity)}};
    case MetricSupportRoleV1::residence_word_law:
      return ResidenceWordLawReferenceV1{
          std::move(core), ResidenceWordLawRef{std::move(identity)}};
    case MetricSupportRoleV1::stopped_path_law:
      return StoppedPathLawReferenceV1{
          std::move(core), StoppedPathLawRef{std::move(identity)}};
    case MetricSupportRoleV1::coupled_schedule_law:
      return CoupledScheduleLawReferenceV1{
          std::move(core), CoupledScheduleLawRef{std::move(identity)}};
    case MetricSupportRoleV1::direct_metric_value:
      return DirectMetricValueReferenceV1{
          std::move(core), DirectMetricValueRef{std::move(identity)}};
    case MetricSupportRoleV1::response_envelope:
      return ResponseEnvelopeReferenceV1{
          std::move(core), ResponseEnvelopeRef{std::move(identity)}};
    case MetricSupportRoleV1::raw_response_bound_evidence:
      return RawResponseBoundEvidenceReferenceV1{
          std::move(core), RawResponseBoundEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::response_order_evidence:
      return ResponseOrderEvidenceReferenceV1{
          std::move(core), ResponseOrderEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::optimizer_evidence:
      return OptimizerEvidenceReferenceV1{
          std::move(core), OptimizerEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::statistical_evidence:
      return StatisticalEvidenceReferenceV1{
          std::move(core), StatisticalEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::numerical_evidence:
      return NumericalEvidenceReferenceV1{
          std::move(core), NumericalEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::calibration_evidence:
      return CalibrationEvidenceReferenceV1{
          std::move(core), CalibrationEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::compression_evidence:
      return CompressionEvidenceReferenceV1{
          std::move(core), CompressionEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::stability_certificate:
      return StabilityCertificateReferenceV1{
          std::move(core), StabilityCertificateRef{std::move(identity)}};
    case MetricSupportRoleV1::reported_validity_or_lift_evidence:
      return ReportedValidityOrLiftEvidenceReferenceV1{
          std::move(core),
          ReportedValidityOrLiftEvidenceRef{std::move(identity)}};
    case MetricSupportRoleV1::physical_transfer_evidence:
      return PhysicalTransferEvidenceReferenceV1{
          std::move(core), PhysicalTransferEvidenceRef{std::move(identity)}};
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "the realized-reference tag is not a closed v1 alternative",
              child_pointer(path, "tag"));
}

[[nodiscard]] Json encode_realized_binding(
    const RealizedMetricBindingV1& value) {
  Json result = Json::object();
  result["key"] = encode_metric_role_key(value.key);
  result["reference"] = encode_realized_reference(value.reference);
  return result;
}

[[nodiscard]] RealizedMetricBindingV1 decode_realized_binding(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"key", "reference"});
  return RealizedMetricBindingV1{
      decode_metric_role_key(required_member(value, "key", path),
                             child_pointer(path, "key")),
      decode_realized_reference(required_member(value, "reference", path),
                                child_pointer(path, "reference"))};
}

void require_version_one(const std::uint32_t version,
                         const std::string& path,
                         const std::string_view record_name) {
  if (version != 1U) {
    decode_fail("artifact_wire_unsupported_version",
                std::string(record_name) +
                    " has an unsupported version in the closed v1 wire",
                path);
  }
}

[[nodiscard]] Json encode_portable_value(const PortableValueV1& value) {
  Json result = Json::object();
  std::visit(
      [&result](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, PortableScientificScalar>) {
          result["tag"] = "scalar";
          result["value"] = artifact::detail::wire::encode_scalar(active);
        } else {
          static_assert(
              std::same_as<Active, std::vector<PortableScientificScalar>>);
          result["tag"] = "vector";
          result["value"] = encode_array<PortableScientificScalar>(
              active, artifact::detail::wire::encode_scalar);
        }
      },
      value);
  return result;
}

[[nodiscard]] PortableValueV1 decode_portable_value(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"tag", "value"});
  const std::string tag = decode_string(required_member(value, "tag", path),
                                        child_pointer(path, "tag"));
  const Json& body = required_member(value, "value", path);
  const std::string body_path = child_pointer(path, "value");
  if (tag == "scalar") {
    return take_or_decode_fail(
        artifact::detail::wire::decode_scalar(body, body_path));
  }
  if (tag == "vector") {
    return decode_array<PortableScientificScalar>(
        body, body_path,
        [](const Json& item, const std::string& item_path) {
          return take_or_decode_fail(
              artifact::detail::wire::decode_scalar(item, item_path));
        });
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown portable-value alternative in the closed v1 wire",
              child_pointer(path, "tag"));
}

[[nodiscard]] Json encode_named_value(const NamedPortableValueV1& value) {
  Json result = Json::object();
  result["name"] = value.name;
  result["value"] = encode_portable_value(value.value);
  return result;
}

[[nodiscard]] NamedPortableValueV1 decode_named_value(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"name", "value"});
  return NamedPortableValueV1{
      decode_string(required_member(value, "name", path),
                    child_pointer(path, "name")),
      decode_portable_value(required_member(value, "value", path),
                            child_pointer(path, "value"))};
}

[[nodiscard]] Json encode_component_digest(
    const ArtifactComponentDigestV1& value) {
  Json result = Json::object();
  result["component_name"] = value.component_name;
  result["component_digest"] =
      artifact::detail::wire::encode_digest(value.component_digest);
  return result;
}

[[nodiscard]] ArtifactComponentDigestV1 decode_component_digest(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"component_name", "component_digest"});
  const std::string digest_path = child_pointer(path, "component_digest");
  return ArtifactComponentDigestV1{
      decode_string(required_member(value, "component_name", path),
                    child_pointer(path, "component_name")),
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "component_digest", path), digest_path))};
}

[[nodiscard]] Json encode_seed_stream_count(
    const SeedStreamCountV1& value) {
  Json result = Json::object();
  result["stage"] = encode_enum(value.stage, kStageTags);
  result["stream_instance_id"] =
      artifact::detail::wire::encode_typed_label(value.stream_instance_id);
  result["draw_count"] =
      artifact::detail::wire::encode_big_nat(value.draw_count);
  return result;
}

[[nodiscard]] SeedStreamCountV1 decode_seed_stream_count(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"stage", "stream_instance_id", "draw_count"});
  const std::string stream_path = child_pointer(path, "stream_instance_id");
  const std::string count_path = child_pointer(path, "draw_count");
  return SeedStreamCountV1{
      decode_enum(required_member(value, "stage", path),
                  child_pointer(path, "stage"), kStageTags),
      take_or_decode_fail(artifact::detail::wire::decode_typed_label(
          required_member(value, "stream_instance_id", path), stream_path)),
      take_or_decode_fail(artifact::detail::wire::decode_big_nat(
          required_member(value, "draw_count", path), count_path))};
}

[[nodiscard]] Json encode_work_counter(const CommonWorkCounterV1& value) {
  Json result = Json::object();
  result["applicability"] =
      encode_enum(value.applicability, kWorkCounterApplicabilities);
  result["used"] = artifact::detail::wire::encode_big_nat(value.used);
  return result;
}

[[nodiscard]] CommonWorkCounterV1 decode_work_counter(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"applicability", "used"});
  const std::string used_path = child_pointer(path, "used");
  return CommonWorkCounterV1{
      decode_enum(required_member(value, "applicability", path),
                  child_pointer(path, "applicability"),
                  kWorkCounterApplicabilities),
      take_or_decode_fail(artifact::detail::wire::decode_big_nat(
          required_member(value, "used", path), used_path))};
}

[[nodiscard]] Json encode_build_report(const CommonBuildReportV1& value) {
  Json result = Json::object();
  result["report_schema_version"] = value.report_schema_version;
  result["report_id"] =
      artifact::detail::wire::encode_typed_label(value.report_id);
  result["report_digest"] =
      artifact::detail::wire::encode_digest(value.report_digest);
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["construction_budget_digest"] =
      artifact::detail::wire::encode_digest(value.construction_budget_digest);
  result["optimizer_calls"] = encode_work_counter(value.optimizer_calls);
  result["optimizer_search_states"] =
      encode_work_counter(value.optimizer_search_states);
  result["configured_generator_draws"] =
      encode_work_counter(value.configured_generator_draws);
  result["optional_component_digests"] =
      encode_array(value.optional_component_digests, encode_component_digest);
  result["optional_method_counters"] =
      encode_array(value.optional_method_counters, encode_named_value);
  return result;
}

[[nodiscard]] CommonBuildReportV1 decode_build_report(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"report_schema_version", "report_id", "report_digest",
       "request_digest", "construction_budget_digest", "optimizer_calls",
       "optimizer_search_states", "configured_generator_draws",
       "optional_component_digests", "optional_method_counters"});
  const std::uint32_t version = decode_u32(
      required_member(value, "report_schema_version", path),
      child_pointer(path, "report_schema_version"));
  require_version_one(version, child_pointer(path, "report_schema_version"),
                      "common build report");
  const auto digest_member = [&value, &path](const std::string_view name) {
    const std::string member_path = child_pointer(path, name);
    return take_or_decode_fail(artifact::detail::wire::decode_digest(
        required_member(value, name, path), member_path));
  };
  const std::string report_id_path = child_pointer(path, "report_id");
  return CommonBuildReportV1{
      version,
      take_or_decode_fail(artifact::detail::wire::decode_typed_label(
          required_member(value, "report_id", path), report_id_path)),
      digest_member("report_digest"),
      digest_member("request_digest"),
      digest_member("construction_budget_digest"),
      decode_work_counter(required_member(value, "optimizer_calls", path),
                          child_pointer(path, "optimizer_calls")),
      decode_work_counter(
          required_member(value, "optimizer_search_states", path),
          child_pointer(path, "optimizer_search_states")),
      decode_work_counter(
          required_member(value, "configured_generator_draws", path),
          child_pointer(path, "configured_generator_draws")),
      decode_array<ArtifactComponentDigestV1>(
          required_member(value, "optional_component_digests", path),
          child_pointer(path, "optional_component_digests"),
          decode_component_digest),
      decode_array<NamedPortableValueV1>(
          required_member(value, "optional_method_counters", path),
          child_pointer(path, "optional_method_counters"),
          decode_named_value)};
}

[[nodiscard]] Json encode_conformance_report(
    const ProviderConformanceReportRef& value) {
  Json result = Json::object();
  result["report_schema_version"] = value.report_schema_version;
  result["report_id"] =
      artifact::detail::wire::encode_typed_label(value.report_id);
  result["report_digest"] =
      artifact::detail::wire::encode_digest(value.report_digest);
  result["provider"] = encode_provider(value.provider);
  result["provider_scientific_contract_digest"] =
      artifact::detail::wire::encode_digest(
          value.provider_scientific_contract_digest);
  result["family_evidence_schema_id"] = value.family_evidence_schema_id;
  result["family_evidence_schema_version"] =
      value.family_evidence_schema_version;
  return result;
}

[[nodiscard]] ProviderConformanceReportRef decode_conformance_report(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"report_schema_version", "report_id", "report_digest", "provider",
       "provider_scientific_contract_digest", "family_evidence_schema_id",
       "family_evidence_schema_version"});
  const std::uint32_t version = decode_u32(
      required_member(value, "report_schema_version", path),
      child_pointer(path, "report_schema_version"));
  require_version_one(version, child_pointer(path, "report_schema_version"),
                      "provider conformance report reference");
  const std::string report_id_path = child_pointer(path, "report_id");
  const std::string report_digest_path = child_pointer(path, "report_digest");
  const std::string contract_path =
      child_pointer(path, "provider_scientific_contract_digest");
  return ProviderConformanceReportRef{
      version,
      take_or_decode_fail(artifact::detail::wire::decode_typed_label(
          required_member(value, "report_id", path), report_id_path)),
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "report_digest", path), report_digest_path)),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "provider_scientific_contract_digest", path),
          contract_path)),
      decode_string(required_member(value, "family_evidence_schema_id", path),
                    child_pointer(path, "family_evidence_schema_id")),
      decode_u32(required_member(value, "family_evidence_schema_version", path),
                 child_pointer(path, "family_evidence_schema_version"))};
}

[[nodiscard]] Json encode_family_evidence(
    const FamilyEvidenceEnvelopeV1& value) {
  Json result = Json::object();
  result["envelope_version"] = value.envelope_version;
  result["evidence_id"] =
      artifact::detail::wire::encode_artifact_object_reference(
          value.evidence_id);
  result["family_evidence_schema_id"] = value.family_evidence_schema_id;
  result["family_evidence_schema_version"] =
      value.family_evidence_schema_version;
  result["provider_conformance_report_ref"] =
      encode_conformance_report(value.provider_conformance_report_ref);
  result["provider"] = encode_provider(value.provider);
  result["provider_scientific_contract_digest"] =
      artifact::detail::wire::encode_digest(
          value.provider_scientific_contract_digest);
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["payload_digest"] =
      artifact::detail::wire::encode_digest(value.payload_digest);
  result["subject_references"] =
      encode_array<ArtifactObjectReferenceV1>(
          value.subject_references,
          artifact::detail::wire::encode_artifact_object_reference);
  result["parent_references"] = encode_array<ArtifactObjectReferenceV1>(
      value.parent_references,
      artifact::detail::wire::encode_artifact_object_reference);
  result["construction_target_scope"] = encode_array<QueueId>(
      value.construction_target_scope,
      [](const QueueId& target) { return encode_strong_id(target); });
  result["evidence_scope_tag"] =
      encode_enum(value.evidence_scope_tag, kMetricEvidenceScopes);
  result["canonical_family_body"] =
      encode_hex_bytes(value.canonical_family_body);
  result["canonical_family_body_digest"] =
      artifact::detail::wire::encode_digest(
          value.canonical_family_body_digest);
  return result;
}

[[nodiscard]] FamilyEvidenceEnvelopeV1 decode_family_evidence(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"envelope_version", "evidence_id", "family_evidence_schema_id",
       "family_evidence_schema_version", "provider_conformance_report_ref",
       "provider", "provider_scientific_contract_digest", "request_digest",
       "payload_digest", "subject_references", "parent_references",
       "construction_target_scope", "evidence_scope_tag",
       "canonical_family_body", "canonical_family_body_digest"});
  const std::uint32_t version = decode_u32(
      required_member(value, "envelope_version", path),
      child_pointer(path, "envelope_version"));
  require_version_one(version, child_pointer(path, "envelope_version"),
                      "family evidence envelope");
  const auto object_reference_member =
      [&value, &path](const std::string_view name) {
        const std::string member_path = child_pointer(path, name);
        return take_or_decode_fail(
            artifact::detail::wire::decode_artifact_object_reference(
                required_member(value, name, path), member_path));
      };
  const auto digest_member = [&value, &path](const std::string_view name) {
    const std::string member_path = child_pointer(path, name);
    return take_or_decode_fail(artifact::detail::wire::decode_digest(
        required_member(value, name, path), member_path));
  };
  const auto decode_reference = [](const Json& item,
                                   const std::string& item_path) {
    return take_or_decode_fail(
        artifact::detail::wire::decode_artifact_object_reference(item,
                                                                  item_path));
  };
  return FamilyEvidenceEnvelopeV1{
      version,
      object_reference_member("evidence_id"),
      decode_string(required_member(value, "family_evidence_schema_id", path),
                    child_pointer(path, "family_evidence_schema_id")),
      decode_u32(required_member(value, "family_evidence_schema_version", path),
                 child_pointer(path, "family_evidence_schema_version")),
      decode_conformance_report(
          required_member(value, "provider_conformance_report_ref", path),
          child_pointer(path, "provider_conformance_report_ref")),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      digest_member("provider_scientific_contract_digest"),
      digest_member("request_digest"),
      digest_member("payload_digest"),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "subject_references", path),
          child_pointer(path, "subject_references"), decode_reference),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "parent_references", path),
          child_pointer(path, "parent_references"), decode_reference),
      decode_array<QueueId>(
          required_member(value, "construction_target_scope", path),
          child_pointer(path, "construction_target_scope"),
          [](const Json& item, const std::string& item_path) {
            return decode_strong_id<"queue">(item, item_path);
          }),
      decode_enum(required_member(value, "evidence_scope_tag", path),
                  child_pointer(path, "evidence_scope_tag"),
                  kMetricEvidenceScopes),
      decode_hex_bytes(required_member(value, "canonical_family_body", path),
                       child_pointer(path, "canonical_family_body")),
      digest_member("canonical_family_body_digest")};
}

[[nodiscard]] Json encode_scoped_evidence(
    const ScopedArtifactEvidenceV1& value) {
  Json result = Json::object();
  result["evidence_id"] =
      artifact::detail::wire::encode_artifact_object_reference(
          value.evidence_id);
  result["reference_kind"] =
      encode_enum(value.reference_kind, kReferenceKinds);
  result["ordered_targets"] = encode_array<QueueId>(
      value.ordered_targets,
      [](const QueueId& target) { return encode_strong_id(target); });
  result["result_scope"] =
      encode_enum(value.result_scope, kMetricResultScopes);
  result["evidence_scope"] =
      encode_enum(value.evidence_scope, kMetricEvidenceScopes);
  result["subject_references"] =
      encode_array<ArtifactObjectReferenceV1>(
          value.subject_references,
          artifact::detail::wire::encode_artifact_object_reference);
  result["parent_references"] = encode_array<ArtifactObjectReferenceV1>(
      value.parent_references,
      artifact::detail::wire::encode_artifact_object_reference);
  result["family_envelope_ids"] = encode_array<ArtifactObjectReferenceV1>(
      value.family_envelope_ids,
      artifact::detail::wire::encode_artifact_object_reference);
  result["internal_references"] =
      encode_array(value.internal_references, encode_internal_relation);
  return result;
}

[[nodiscard]] ScopedArtifactEvidenceV1 decode_scoped_evidence(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"evidence_id", "reference_kind", "ordered_targets", "result_scope",
       "evidence_scope", "subject_references", "parent_references",
       "family_envelope_ids", "internal_references"});
  const auto decode_reference = [](const Json& item,
                                   const std::string& item_path) {
    return take_or_decode_fail(
        artifact::detail::wire::decode_artifact_object_reference(item,
                                                                  item_path));
  };
  const std::string evidence_id_path = child_pointer(path, "evidence_id");
  return ScopedArtifactEvidenceV1{
      take_or_decode_fail(
          artifact::detail::wire::decode_artifact_object_reference(
              required_member(value, "evidence_id", path),
              evidence_id_path)),
      decode_enum(required_member(value, "reference_kind", path),
                  child_pointer(path, "reference_kind"), kReferenceKinds),
      decode_array<QueueId>(
          required_member(value, "ordered_targets", path),
          child_pointer(path, "ordered_targets"),
          [](const Json& item, const std::string& item_path) {
            return decode_strong_id<"queue">(item, item_path);
          }),
      decode_enum(required_member(value, "result_scope", path),
                  child_pointer(path, "result_scope"), kMetricResultScopes),
      decode_enum(required_member(value, "evidence_scope", path),
                  child_pointer(path, "evidence_scope"),
                  kMetricEvidenceScopes),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "subject_references", path),
          child_pointer(path, "subject_references"), decode_reference),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "parent_references", path),
          child_pointer(path, "parent_references"), decode_reference),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "family_envelope_ids", path),
          child_pointer(path, "family_envelope_ids"), decode_reference),
      decode_array<RealizedInternalReferenceV1>(
          required_member(value, "internal_references", path),
          child_pointer(path, "internal_references"),
          decode_internal_relation)};
}

[[nodiscard]] Json encode_diagnostic_component(
    const ArtifactDiagnosticComponentV1& value) {
  const auto encode_reference = [](const ArtifactObjectReferenceV1& item) {
    return artifact::detail::wire::encode_artifact_object_reference(item);
  };
  Json result = Json::object();
  result["diagnostic_schema_version"] = value.diagnostic_schema_version;
  result["diagnostic_id"] =
      artifact::detail::wire::encode_typed_label(value.diagnostic_id);
  result["scope"] = encode_enum(value.scope, kArtifactDiagnosticScopes);
  result["code"] = value.code;
  result["message"] = value.message;
  result["subject_references"] =
      encode_array(value.subject_references, encode_reference);
  result["evidence_references"] =
      encode_array(value.evidence_references, encode_reference);
  return result;
}

[[nodiscard]] ArtifactDiagnosticComponentV1 decode_diagnostic_component(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"diagnostic_schema_version", "diagnostic_id", "scope", "code",
       "message", "subject_references", "evidence_references"});
  const std::uint32_t version = decode_u32(
      required_member(value, "diagnostic_schema_version", path),
      child_pointer(path, "diagnostic_schema_version"));
  require_version_one(version,
                      child_pointer(path, "diagnostic_schema_version"),
                      "artifact diagnostic component");
  const auto decode_reference = [](const Json& item,
                                   const std::string& item_path) {
    return take_or_decode_fail(
        artifact::detail::wire::decode_artifact_object_reference(
            item, item_path));
  };
  const std::string id_path = child_pointer(path, "diagnostic_id");
  return ArtifactDiagnosticComponentV1{
      version,
      take_or_decode_fail(artifact::detail::wire::decode_typed_label(
          required_member(value, "diagnostic_id", path), id_path)),
      decode_enum(required_member(value, "scope", path),
                  child_pointer(path, "scope"), kArtifactDiagnosticScopes),
      decode_string(required_member(value, "code", path),
                    child_pointer(path, "code")),
      decode_string(required_member(value, "message", path),
                    child_pointer(path, "message")),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "subject_references", path),
          child_pointer(path, "subject_references"), decode_reference),
      decode_array<ArtifactObjectReferenceV1>(
          required_member(value, "evidence_references", path),
          child_pointer(path, "evidence_references"), decode_reference)};
}

[[nodiscard]] Json encode_provenance(const ArtifactProvenanceV1& value) {
  Json result = Json::object();
  if (value.source_document_id.has_value()) {
    result["source_document_id"] = *value.source_document_id;
  }
  if (value.source_revision_id.has_value()) {
    result["source_revision_id"] = *value.source_revision_id;
  }
  if (value.provider_source_digest.has_value()) {
    result["provider_source_digest"] =
        artifact::detail::wire::encode_digest(*value.provider_source_digest);
  }
  if (value.provider_build_digest.has_value()) {
    result["provider_build_digest"] =
        artifact::detail::wire::encode_digest(*value.provider_build_digest);
  }
  if (value.compiler_identity.has_value()) {
    result["compiler_identity"] = *value.compiler_identity;
  }
  result["component_digests"] =
      encode_array(value.component_digests, encode_component_digest);
  result["method_decisions"] = value.method_decisions;
  result["seed_stream_counts"] =
      encode_array(value.seed_stream_counts, encode_seed_stream_count);
  if (value.frozen_input_bank_id.has_value()) {
    result["frozen_input_bank_id"] =
        artifact::detail::wire::encode_typed_label(
            *value.frozen_input_bank_id);
  }
  if (value.proposal_id.has_value()) {
    result["proposal_id"] =
        artifact::detail::wire::encode_typed_label(*value.proposal_id);
  }
  if (value.final_evaluation_id.has_value()) {
    result["final_evaluation_id"] =
        artifact::detail::wire::encode_typed_label(
            *value.final_evaluation_id);
  }
  return result;
}

[[nodiscard]] ArtifactProvenanceV1 decode_provenance(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"component_digests", "method_decisions", "seed_stream_counts"},
      {"source_document_id", "source_revision_id", "provider_source_digest",
       "provider_build_digest", "compiler_identity", "frozen_input_bank_id",
       "proposal_id", "final_evaluation_id"});
  const auto optional_string = [&value, &path](const std::string_view name)
      -> std::optional<std::string> {
    if (!value.contains(std::string(name))) {
      return std::nullopt;
    }
    return decode_string(required_member(value, name, path),
                         child_pointer(path, name));
  };
  const auto optional_digest = [&value, &path](const std::string_view name)
      -> std::optional<Digest256> {
    if (!value.contains(std::string(name))) {
      return std::nullopt;
    }
    const std::string member_path = child_pointer(path, name);
    return take_or_decode_fail(artifact::detail::wire::decode_digest(
        required_member(value, name, path), member_path));
  };
  const auto optional_label = [&value, &path](const std::string_view name)
      -> std::optional<TypedLabel> {
    if (!value.contains(std::string(name))) {
      return std::nullopt;
    }
    const std::string member_path = child_pointer(path, name);
    return take_or_decode_fail(artifact::detail::wire::decode_typed_label(
        required_member(value, name, path), member_path));
  };
  return ArtifactProvenanceV1{
      optional_string("source_document_id"),
      optional_string("source_revision_id"),
      optional_digest("provider_source_digest"),
      optional_digest("provider_build_digest"),
      optional_string("compiler_identity"),
      decode_array<ArtifactComponentDigestV1>(
          required_member(value, "component_digests", path),
          child_pointer(path, "component_digests"), decode_component_digest),
      decode_array<std::string>(
          required_member(value, "method_decisions", path),
          child_pointer(path, "method_decisions"),
          [](const Json& item, const std::string& item_path) {
            return decode_string(item, item_path);
          }),
      decode_array<SeedStreamCountV1>(
          required_member(value, "seed_stream_counts", path),
          child_pointer(path, "seed_stream_counts"),
          decode_seed_stream_count),
      optional_label("frozen_input_bank_id"), optional_label("proposal_id"),
      optional_label("final_evaluation_id")};
}

[[nodiscard]] Json encode_manifest_echo(
    const MetricSupportManifestEchoV1& value) {
  Json result = Json::object();
  result["schema_version"] = value.schema_version;
  result["canonical_manifest_bytes"] =
      encode_hex_bytes(value.canonical_manifest_bytes);
  result["manifest_digest"] =
      artifact::detail::wire::encode_digest(value.manifest_digest);
  return result;
}

[[nodiscard]] MetricSupportManifestEchoV1 decode_manifest_echo(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"schema_version", "canonical_manifest_bytes", "manifest_digest"});
  const std::uint32_t version = decode_u32(
      required_member(value, "schema_version", path),
      child_pointer(path, "schema_version"));
  require_version_one(version, child_pointer(path, "schema_version"),
                      "structural metric-manifest echo");
  const std::string digest_path = child_pointer(path, "manifest_digest");
  return MetricSupportManifestEchoV1{
      version,
      decode_hex_bytes(required_member(value, "canonical_manifest_bytes", path),
                       child_pointer(path, "canonical_manifest_bytes")),
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "manifest_digest", path), digest_path))};
}

[[nodiscard]] Json encode_bound_bindings(
    const BoundRealizedMetricBindingsV1& value) {
  Json result = Json::object();
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["payload_digest"] =
      artifact::detail::wire::encode_digest(value.payload_digest);
  result["bindings"] =
      encode_array(value.bindings, encode_realized_binding);
  return result;
}

[[nodiscard]] BoundRealizedMetricBindingsV1 decode_bound_bindings(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"request_digest", "payload_digest", "bindings"});
  const std::string request_path = child_pointer(path, "request_digest");
  const std::string payload_path = child_pointer(path, "payload_digest");
  return BoundRealizedMetricBindingsV1{
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "request_digest", path), request_path)),
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "payload_digest", path), payload_path)),
      decode_array<RealizedMetricBindingV1>(
          required_member(value, "bindings", path),
          child_pointer(path, "bindings"), decode_realized_binding)};
}

[[nodiscard]] Json encode_artifact(const SurrogateArtifactV1& value) {
  Json result = Json::object();
  result["artifact_protocol_version"] = value.artifact_protocol_version;
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["provider"] = encode_provider(value.provider);
  result["provider_scientific_contract_digest"] =
      artifact::detail::wire::encode_digest(
          value.provider_scientific_contract_digest);
  result["construction_method"] =
      encode_enum(value.construction_method, kConstructionMethods);
  result["producer_mode"] = encode_enum(value.producer_mode, kProducerModes);
  result["deployed_semantic"] =
      encode_enum(value.deployed_semantic, kSemanticTags);
  result["runtime_access"] =
      encode_enum(value.runtime_access, kRuntimeAccessTags);
  result["payload_class"] = encode_payload_class(value.payload_class);
  result["payload_identity"] =
      artifact::detail::wire::encode_artifact_object_reference(
          value.payload_identity);
  result["payload"] =
      artifact::detail::wire::encode_payload_wire_v1(value.payload);
  result["payload_digest"] =
      artifact::detail::wire::encode_digest(value.payload_digest);
  result["structural_manifest_echo"] =
      encode_manifest_echo(value.structural_manifest_echo);
  result["realized_metric_bindings"] =
      encode_bound_bindings(value.realized_metric_bindings);
  result["deployed_descriptor"] =
      encode_descriptor(value.deployed_descriptor);
  result["build_report_echo"] =
      encode_build_report(value.build_report_echo);
  result["family_evidence"] =
      encode_array(value.family_evidence, encode_family_evidence);
  result["scoped_evidence"] =
      encode_array(value.scoped_evidence, encode_scoped_evidence);
  result["diagnostic_components"] =
      encode_array(value.diagnostic_components, encode_diagnostic_component);
  result["provenance"] = encode_provenance(value.provenance);
  return result;
}

[[nodiscard]] SurrogateArtifactV1 decode_artifact(
    const Json& value, const std::string& path,
    const artifact::detail::PayloadWireAccess& access) {
  require_object_shape(
      value, path,
      {"artifact_protocol_version", "request_digest", "provider",
       "provider_scientific_contract_digest", "construction_method",
       "producer_mode", "deployed_semantic", "runtime_access",
       "payload_class", "payload_identity", "payload", "payload_digest",
       "structural_manifest_echo", "realized_metric_bindings",
       "deployed_descriptor", "build_report_echo", "family_evidence",
       "scoped_evidence", "diagnostic_components", "provenance"});
  const std::uint32_t version = decode_u32(
      required_member(value, "artifact_protocol_version", path),
      child_pointer(path, "artifact_protocol_version"));
  require_version_one(version,
                      child_pointer(path, "artifact_protocol_version"),
                      "surrogate artifact");
  const auto digest_member = [&value, &path](const std::string_view name) {
    const std::string member_path = child_pointer(path, name);
    return take_or_decode_fail(artifact::detail::wire::decode_digest(
        required_member(value, name, path), member_path));
  };
  const std::string payload_identity_path =
      child_pointer(path, "payload_identity");
  PayloadClassV1 payload_class = decode_payload_class(
      required_member(value, "payload_class", path),
      child_pointer(path, "payload_class"));
  require_version_one(payload_class.version,
                      child_pointer(child_pointer(path, "payload_class"),
                                    "version"),
                      "artifact payload class");
  PlugDescriptorCore descriptor = decode_descriptor(
      required_member(value, "deployed_descriptor", path),
      child_pointer(path, "deployed_descriptor"));
  require_version_one(
      descriptor.schema_version,
      child_pointer(child_pointer(path, "deployed_descriptor"),
                    "schema_version"),
      "deployed plug descriptor core");
  ArtifactPayloadV1 payload =
      take_or_decode_fail(artifact::detail::wire::decode_payload_wire_v1(
          required_member(value, "payload", path), access,
          child_pointer(path, "payload")));
  const PayloadClassV1 decoded_payload_class =
      artifact_payload_class_v1(payload);
  require_version_one(
      decoded_payload_class.version,
      child_pointer(child_pointer(child_pointer(path, "payload"), "body"),
                    "payload_version"),
      "artifact payload");
  return SurrogateArtifactV1{
      version,
      digest_member("request_digest"),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      digest_member("provider_scientific_contract_digest"),
      decode_enum(required_member(value, "construction_method", path),
                  child_pointer(path, "construction_method"),
                  kConstructionMethods),
      decode_enum(required_member(value, "producer_mode", path),
                  child_pointer(path, "producer_mode"), kProducerModes),
      decode_enum(required_member(value, "deployed_semantic", path),
                  child_pointer(path, "deployed_semantic"), kSemanticTags),
      decode_enum(required_member(value, "runtime_access", path),
                  child_pointer(path, "runtime_access"), kRuntimeAccessTags),
      std::move(payload_class),
      take_or_decode_fail(
          artifact::detail::wire::decode_artifact_object_reference(
              required_member(value, "payload_identity", path),
              payload_identity_path)),
      std::move(payload),
      digest_member("payload_digest"),
      decode_manifest_echo(
          required_member(value, "structural_manifest_echo", path),
          child_pointer(path, "structural_manifest_echo")),
      decode_bound_bindings(
          required_member(value, "realized_metric_bindings", path),
          child_pointer(path, "realized_metric_bindings")),
      std::move(descriptor),
      decode_build_report(required_member(value, "build_report_echo", path),
                          child_pointer(path, "build_report_echo")),
      decode_array<FamilyEvidenceEnvelopeV1>(
          required_member(value, "family_evidence", path),
          child_pointer(path, "family_evidence"), decode_family_evidence),
      decode_array<ScopedArtifactEvidenceV1>(
          required_member(value, "scoped_evidence", path),
          child_pointer(path, "scoped_evidence"), decode_scoped_evidence),
      decode_array<ArtifactDiagnosticComponentV1>(
          required_member(value, "diagnostic_components", path),
          child_pointer(path, "diagnostic_components"),
          decode_diagnostic_component),
      decode_provenance(required_member(value, "provenance", path),
                        child_pointer(path, "provenance"))};
}

[[nodiscard]] Json encode_result_envelope(const ResultEnvelopeV1& value) {
  Json result = Json::object();
  result["protocol_version"] = value.protocol_version;
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["provider"] = encode_provider(value.provider);
  result["build_report"] = encode_build_report(value.build_report);
  return result;
}

[[nodiscard]] ResultEnvelopeV1 decode_result_envelope(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"protocol_version", "request_digest", "provider",
                        "build_report"});
  const std::uint32_t version = decode_u32(
      required_member(value, "protocol_version", path),
      child_pointer(path, "protocol_version"));
  require_version_one(version, child_pointer(path, "protocol_version"),
                      "surrogate build result envelope");
  const std::string digest_path = child_pointer(path, "request_digest");
  return ResultEnvelopeV1{
      version,
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "request_digest", path), digest_path)),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      decode_build_report(required_member(value, "build_report", path),
                          child_pointer(path, "build_report"))};
}

[[nodiscard]] Json encode_observation_envelope(
    const ConstructionObservationEnvelopeV1& value) {
  auto encoded = canonical_construction_observation_envelope_bytes_v1(value);
  if (!encoded) throw DecodeError(encoded.error());
  const char* const begin =
      reinterpret_cast<const char*>(encoded.value().data());
  const char* const end = begin + encoded.value().size();
  return Json::parse(begin, end, nullptr, true, false);
}

[[nodiscard]] ConstructionObservationEnvelopeV1 decode_observation_envelope(
    const Json& envelope, const ObservationParseLimitsV1& limits) {
  constexpr std::string_view kBundlePrefix =
      "{\"observation_bundle\":";
  constexpr std::string_view kDigestPrefix =
      ",\"observation_bundle_digest\":";
  constexpr std::string_view kEnvelopeSuffix = "}";
  std::string bundle_text =
      required_member(envelope, "observation_bundle", "/envelope")
          .dump(-1, ' ', false, Json::error_handler_t::strict);
  std::string digest_text =
      required_member(envelope, "observation_bundle_digest", "/envelope")
          .dump(-1, ' ', false, Json::error_handler_t::strict);
  std::size_t encoded_size = kBundlePrefix.size();
  const auto admit = [&](const std::size_t amount) {
    if (amount > limits.maximum_bytes ||
        encoded_size > limits.maximum_bytes - amount) {
      throw DecodeError(parse_diagnostic(
          DiagnosticCategory::resource_limit,
          "observation_parse_input_bytes_limit",
          "the embedded observation envelope exceeds the configured byte cap",
          "/envelope"));
    }
    encoded_size += amount;
  };
  admit(bundle_text.size());
  admit(kDigestPrefix.size());
  admit(digest_text.size());
  admit(kEnvelopeSuffix.size());

  std::string text;
  text.reserve(encoded_size);
  text.append(kBundlePrefix);
  text.append(bundle_text);
  text.append(kDigestPrefix);
  text.append(digest_text);
  text.append(kEnvelopeSuffix);
  // Do not retain a second proportional observation carrier while the
  // standalone bounded parser owns its DOM and typed decode.
  std::string{}.swap(bundle_text);
  std::string{}.swap(digest_text);
  const auto* const begin = reinterpret_cast<const std::byte*>(text.data());
  return take_or_decode_fail(parse_construction_observation_envelope_v1(
      ObservationByteSpan{begin, text.size()}, limits));
}

[[nodiscard]] Json encode_result_envelope_v2(const ResultEnvelopeV2& value) {
  Json result = Json::object();
  result["protocol_version"] = value.protocol_version;
  result["request_digest"] =
      artifact::detail::wire::encode_digest(value.request_digest);
  result["provider"] = encode_provider(value.provider);
  result["build_report"] = encode_build_report(value.build_report);
  if (value.observation.has_value()) {
    const Json observation = encode_observation_envelope(*value.observation);
    result["observation_bundle"] = observation.at("observation_bundle");
    result["observation_bundle_digest"] =
        observation.at("observation_bundle_digest");
  }
  return result;
}

[[nodiscard]] ResultEnvelopeV2 decode_result_envelope_v2(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& observation_limits) {
  require_object_shape(value, path,
                       {"protocol_version", "request_digest", "provider",
                        "build_report"},
                       {"observation_bundle", "observation_bundle_digest"});
  const bool has_bundle = value.contains("observation_bundle");
  const bool has_digest = value.contains("observation_bundle_digest");
  if (has_bundle != has_digest) {
    decode_fail("artifact_wire_observation_pair_incomplete",
                "provider-result v2 requires observation_bundle and "
                "observation_bundle_digest to be both present or both absent",
                path);
  }
  const std::uint32_t version = decode_u32(
      required_member(value, "protocol_version", path),
      child_pointer(path, "protocol_version"));
  if (version != 2U) {
    decode_fail("artifact_wire_unsupported_version",
                "provider-result v2 envelope protocol_version must equal two",
                child_pointer(path, "protocol_version"));
  }
  const std::string digest_path = child_pointer(path, "request_digest");
  std::optional<ConstructionObservationEnvelopeV1> observation;
  if (has_bundle) {
    observation = decode_observation_envelope(value, observation_limits);
  }
  return ResultEnvelopeV2{
      version,
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "request_digest", path), digest_path)),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      decode_build_report(required_member(value, "build_report", path),
                          child_pointer(path, "build_report")),
      std::move(observation)};
}

[[nodiscard]] ResultEnvelopeV3 decode_result_envelope_v3(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& observation_limits) {
  require_object_shape(value, path,
                       {"protocol_version", "request_digest", "provider",
                        "build_report"},
                       {"observation_bundle", "observation_bundle_digest"});
  const bool has_bundle = value.contains("observation_bundle");
  const bool has_digest = value.contains("observation_bundle_digest");
  if (has_bundle != has_digest) {
    decode_fail("artifact_wire_observation_pair_incomplete",
                "provider-result v3 requires observation_bundle and "
                "observation_bundle_digest to be both present or both absent",
                path);
  }
  const std::uint32_t version = decode_u32(
      required_member(value, "protocol_version", path),
      child_pointer(path, "protocol_version"));
  if (version != 3U) {
    decode_fail("artifact_wire_unsupported_version",
                "provider-result v3 envelope protocol_version must equal three",
                child_pointer(path, "protocol_version"));
  }
  std::optional<ConstructionObservationEnvelopeV1> observation;
  if (has_bundle) {
    observation = decode_observation_envelope(value, observation_limits);
  }
  return ResultEnvelopeV3{
      version,
      take_or_decode_fail(artifact::detail::wire::decode_digest(
          required_member(value, "request_digest", path),
          child_pointer(path, "request_digest"))),
      decode_provider(required_member(value, "provider", path),
                      child_pointer(path, "provider")),
      decode_build_report(required_member(value, "build_report", path),
                          child_pointer(path, "build_report")),
      std::move(observation)};
}

[[nodiscard]] Json encode_unavailable_reason(
    const UnavailableReasonV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kUnavailableKinds);
  result["code"] = value.code;
  result["message"] = value.message;
  if (value.metric_clause_id.has_value()) {
    Json clause = Json::object();
    clause["metric_id"] = value.metric_clause_id->metric_id;
    clause["authored_index"] =
        std::to_string(value.metric_clause_id->authored_index);
    result["metric_clause_id"] = std::move(clause);
  }
  if (value.subject.has_value()) {
    result["subject"] =
        artifact::detail::wire::encode_artifact_object_reference(
            *value.subject);
  }
  return result;
}

[[nodiscard]] UnavailableReasonV1 decode_unavailable_reason(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"kind", "code", "message"},
                       {"metric_clause_id", "subject"});
  std::optional<MetricClauseIdV1> clause;
  if (value.contains("metric_clause_id")) {
    const Json& clause_json = required_member(value, "metric_clause_id", path);
    const std::string clause_path = child_pointer(path, "metric_clause_id");
    require_object_shape(clause_json, clause_path,
                         {"metric_id", "authored_index"});
    clause = MetricClauseIdV1{
        decode_string(required_member(clause_json, "metric_id", clause_path),
                      child_pointer(clause_path, "metric_id")),
        decode_size_decimal(
            required_member(clause_json, "authored_index", clause_path),
            child_pointer(clause_path, "authored_index"))};
  }
  std::optional<ArtifactObjectReferenceV1> subject;
  if (value.contains("subject")) {
    const std::string member_path = child_pointer(path, "subject");
    subject = take_or_decode_fail(
        artifact::detail::wire::decode_artifact_object_reference(
            required_member(value, "subject", path), member_path));
  }
  return UnavailableReasonV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kUnavailableKinds),
      decode_string(required_member(value, "code", path),
                    child_pointer(path, "code")),
      decode_string(required_member(value, "message", path),
                    child_pointer(path, "message")),
      std::move(clause), std::move(subject)};
}

[[nodiscard]] Json encode_truthful_alternative(
    const StrongestTruthfulAlternativeV1& value) {
  Json result = Json::object();
  result["description"] = value.description;
  if (value.payload_class.has_value()) {
    result["payload_class"] = encode_payload_class(*value.payload_class);
  }
  if (value.result_scope.has_value()) {
    result["result_scope"] =
        encode_enum(*value.result_scope, kMetricResultScopes);
  }
  return result;
}

[[nodiscard]] StrongestTruthfulAlternativeV1 decode_truthful_alternative(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"description"},
                       {"payload_class", "result_scope"});
  std::optional<PayloadClassV1> payload;
  if (value.contains("payload_class")) {
    payload = decode_payload_class(required_member(value, "payload_class", path),
                                   child_pointer(path, "payload_class"));
    require_version_one(
        payload->version,
        child_pointer(child_pointer(path, "payload_class"), "version"),
        "strongest-alternative payload class");
  }
  std::optional<MetricResultScopeV1> scope;
  if (value.contains("result_scope")) {
    scope = decode_enum(required_member(value, "result_scope", path),
                        child_pointer(path, "result_scope"),
                        kMetricResultScopes);
  }
  return StrongestTruthfulAlternativeV1{
      decode_string(required_member(value, "description", path),
                    child_pointer(path, "description")),
      std::move(payload), scope};
}

[[nodiscard]] Json encode_failure(const ProviderFailureV1& value) {
  Json result = Json::object();
  result["kind"] = encode_enum(value.kind, kFailureKinds);
  result["code"] = value.code;
  result["message"] = value.message;
  return result;
}

[[nodiscard]] ProviderFailureV1 decode_failure(const Json& value,
                                               const std::string& path) {
  require_object_shape(value, path, {"kind", "code", "message"});
  return ProviderFailureV1{
      decode_enum(required_member(value, "kind", path),
                  child_pointer(path, "kind"), kFailureKinds),
      decode_string(required_member(value, "code", path),
                    child_pointer(path, "code")),
      decode_string(required_member(value, "message", path),
                    child_pointer(path, "message"))};
}

[[nodiscard]] Json encode_result(const SurrogateBuildResultV1& value) {
  Json result = Json::object();
  std::visit(
      [&result](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, BuiltSurrogateResultV1>) {
          result["kind"] = "built";
          result["envelope"] = encode_result_envelope(active.envelope);
          result["artifact"] = encode_artifact(active.artifact);
        } else if constexpr (std::same_as<Active,
                                         UnavailableSurrogateResultV1>) {
          result["kind"] = "unavailable";
          result["envelope"] = encode_result_envelope(active.envelope);
          result["reasons"] =
              encode_array(active.reasons, encode_unavailable_reason);
          if (active.strongest_truthful_alternative.has_value()) {
            result["strongest_truthful_alternative"] =
                encode_truthful_alternative(
                    *active.strongest_truthful_alternative);
          }
        } else {
          static_assert(std::same_as<Active, FailedSurrogateResultV1>);
          result["kind"] = "failed";
          result["envelope"] = encode_result_envelope(active.envelope);
          result["failure"] = encode_failure(active.failure);
        }
      },
      value);
  return result;
}

[[nodiscard]] SurrogateBuildResultV1 decode_result(
    const Json& value,
    const artifact::detail::PayloadWireAccess& access) {
  if (!value.is_object()) {
    decode_fail("artifact_wire_expected_object",
                "the v1 surrogate build result must be a JSON object", "");
  }
  const Json& kind_value = required_member(value, "kind", "");
  const std::string kind = decode_string(kind_value, "/kind");
  if (kind == "built") {
    require_object_shape(value, "", {"kind", "envelope", "artifact"});
    return BuiltSurrogateResultV1{
        decode_result_envelope(required_member(value, "envelope", ""),
                               "/envelope"),
        decode_artifact(required_member(value, "artifact", ""),
                        "/artifact", access)};
  }
  if (kind == "unavailable") {
    require_object_shape(
        value, "", {"kind", "envelope", "reasons"},
        {"strongest_truthful_alternative"});
    std::optional<StrongestTruthfulAlternativeV1> alternative;
    if (value.contains("strongest_truthful_alternative")) {
      alternative = decode_truthful_alternative(
          required_member(value, "strongest_truthful_alternative", ""),
          "/strongest_truthful_alternative");
    }
    return UnavailableSurrogateResultV1{
        decode_result_envelope(required_member(value, "envelope", ""),
                               "/envelope"),
        decode_array<UnavailableReasonV1>(
            required_member(value, "reasons", ""), "/reasons",
            decode_unavailable_reason),
        std::move(alternative)};
  }
  if (kind == "failed") {
    require_object_shape(value, "", {"kind", "envelope", "failure"});
    return FailedSurrogateResultV1{
        decode_result_envelope(required_member(value, "envelope", ""),
                               "/envelope"),
        decode_failure(required_member(value, "failure", ""), "/failure")};
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown surrogate-build-result branch in the closed v1 wire",
              "/kind");
}

[[nodiscard]] Json encode_result_v2(const SurrogateBuildResultV2& value) {
  Json result = Json::object();
  std::visit(
      [&result](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, BuiltSurrogateResultV2>) {
          result["kind"] = "built";
          result["envelope"] = encode_result_envelope_v2(active.envelope);
          result["artifact"] = encode_artifact(active.artifact);
        } else if constexpr (std::same_as<Active,
                                         UnavailableSurrogateResultV2>) {
          result["kind"] = "unavailable";
          result["envelope"] = encode_result_envelope_v2(active.envelope);
          result["reasons"] =
              encode_array(active.reasons, encode_unavailable_reason);
          if (active.strongest_truthful_alternative.has_value()) {
            result["strongest_truthful_alternative"] =
                encode_truthful_alternative(
                    *active.strongest_truthful_alternative);
          }
        } else {
          static_assert(std::same_as<Active, FailedSurrogateResultV2>);
          result["kind"] = "failed";
          result["envelope"] = encode_result_envelope_v2(active.envelope);
          result["failure"] = encode_failure(active.failure);
        }
      },
      value);
  return result;
}

[[nodiscard]] ProviderResultKindV2 decode_result_kind_v2(
    const Json& value) {
  if (!value.is_object()) {
    decode_fail("artifact_wire_expected_object",
                "the v2 surrogate build result must be a JSON object", "");
  }
  const std::string kind =
      decode_string(required_member(value, "kind", ""), "/kind");
  if (kind == "built") return ProviderResultKindV2::built;
  if (kind == "unavailable") return ProviderResultKindV2::unavailable;
  if (kind == "failed") return ProviderResultKindV2::failed;
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown surrogate-build-result branch in the closed v2 wire",
              "/kind");
}

[[nodiscard]] SurrogateBuildResultBranchV2 decode_result_branch_v2(
    const Json& value, const ProviderResultKindV2 kind,
    const artifact::detail::PayloadWireAccess& access) {
  switch (kind) {
    case ProviderResultKindV2::built:
      require_object_shape(value, "", {"kind", "envelope", "artifact"});
      return BuiltSurrogateResultBodyV2{
          decode_artifact(required_member(value, "artifact", ""),
                          "/artifact", access)};
    case ProviderResultKindV2::unavailable: {
      require_object_shape(value, "", {"kind", "envelope", "reasons"},
                           {"strongest_truthful_alternative"});
      std::optional<StrongestTruthfulAlternativeV1> alternative;
      if (value.contains("strongest_truthful_alternative")) {
        alternative = decode_truthful_alternative(
            required_member(value, "strongest_truthful_alternative", ""),
            "/strongest_truthful_alternative");
      }
      return UnavailableSurrogateResultBodyV2{
          decode_array<UnavailableReasonV1>(
              required_member(value, "reasons", ""), "/reasons",
              decode_unavailable_reason),
          std::move(alternative)};
    }
    case ProviderResultKindV2::failed:
      require_object_shape(value, "", {"kind", "envelope", "failure"});
      return FailedSurrogateResultBodyV2{
          decode_failure(required_member(value, "failure", ""),
                         "/failure")};
    case ProviderResultKindV2::observed:
      break;
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown surrogate-build-result branch in the closed v2 wire",
              "/kind");
}

[[nodiscard]] ProviderResultKindV2 decode_result_kind_v3(
    const Json& value) {
  if (!value.is_object()) {
    decode_fail("artifact_wire_expected_object",
                "the v3 provider result must be a JSON object", "");
  }
  const std::string kind =
      decode_string(required_member(value, "kind", ""), "/kind");
  if (kind == "observed") return ProviderResultKindV2::observed;
  if (kind == "unavailable") return ProviderResultKindV2::unavailable;
  if (kind == "failed") return ProviderResultKindV2::failed;
  decode_fail("artifact_wire_unknown_union_tag",
              "unknown provider-result branch in the closed v3 wire",
              "/kind");
}

[[nodiscard]] SurrogateBuildResultBranchV3 decode_result_branch_v3(
    const Json& value, const ProviderResultKindV2 kind) {
  switch (kind) {
    case ProviderResultKindV2::observed:
      require_object_shape(value, "", {"kind", "envelope"});
      return ObservedSurrogateResultBodyV3{};
    case ProviderResultKindV2::unavailable: {
      require_object_shape(value, "", {"kind", "envelope", "reasons"},
                           {"strongest_truthful_alternative"});
      std::optional<StrongestTruthfulAlternativeV1> alternative;
      if (value.contains("strongest_truthful_alternative")) {
        alternative = decode_truthful_alternative(
            required_member(value, "strongest_truthful_alternative", ""),
            "/strongest_truthful_alternative");
      }
      return UnavailableSurrogateResultBodyV2{
          decode_array<UnavailableReasonV1>(
              required_member(value, "reasons", ""), "/reasons",
              decode_unavailable_reason),
          std::move(alternative)};
    }
    case ProviderResultKindV2::failed:
      require_object_shape(value, "", {"kind", "envelope", "failure"});
      return FailedSurrogateResultBodyV2{
          decode_failure(required_member(value, "failure", ""),
                         "/failure")};
    case ProviderResultKindV2::built:
      break;
  }
  decode_fail("artifact_wire_unknown_union_tag",
              "provider-result v3 does not admit a Built artifact branch",
              "/kind");
}

[[nodiscard]] Json encode_result_frame_v3(
    const ResultEnvelopeV3& envelope,
    const SurrogateBuildResultBranchV3& branch) {
  Json result = Json::object();
  std::visit(
      [&](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active,
                                   ObservedSurrogateResultBodyV3>) {
          result["kind"] = "observed";
          result["envelope"] = encode_result_envelope_v2(envelope);
        } else if constexpr (std::same_as<
                                 Active,
                                 UnavailableSurrogateResultBodyV2>) {
          result["kind"] = "unavailable";
          result["envelope"] = encode_result_envelope_v2(envelope);
          result["reasons"] =
              encode_array(active.reasons, encode_unavailable_reason);
          if (active.strongest_truthful_alternative.has_value()) {
            result["strongest_truthful_alternative"] =
                encode_truthful_alternative(
                    *active.strongest_truthful_alternative);
          }
        } else {
          static_assert(std::same_as<Active, FailedSurrogateResultBodyV2>);
          result["kind"] = "failed";
          result["envelope"] = encode_result_envelope_v2(envelope);
          result["failure"] = encode_failure(active.failure);
        }
      },
      branch);
  return result;
}

[[nodiscard]] Json encode_result_frame_v2(
    const ResultEnvelopeV2& envelope,
    const SurrogateBuildResultBranchV2& branch) {
  Json result = Json::object();
  std::visit(
      [&](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, BuiltSurrogateResultBodyV2>) {
          result["kind"] = "built";
          result["envelope"] = encode_result_envelope_v2(envelope);
          result["artifact"] = encode_artifact(active.artifact);
        } else if constexpr (std::same_as<
                                 Active,
                                 UnavailableSurrogateResultBodyV2>) {
          result["kind"] = "unavailable";
          result["envelope"] = encode_result_envelope_v2(envelope);
          result["reasons"] =
              encode_array(active.reasons, encode_unavailable_reason);
          if (active.strongest_truthful_alternative.has_value()) {
            result["strongest_truthful_alternative"] =
                encode_truthful_alternative(
                    *active.strongest_truthful_alternative);
          }
        } else {
          static_assert(std::same_as<Active, FailedSurrogateResultBodyV2>);
          result["kind"] = "failed";
          result["envelope"] = encode_result_envelope_v2(envelope);
          result["failure"] = encode_failure(active.failure);
        }
      },
      branch);
  return result;
}

}  // namespace

namespace artifact::detail {

Result<std::vector<std::byte>> canonical_surrogate_build_result_bytes_v1(
    const SurrogateBuildResultV1& result) {
  try {
    const std::string encoded = encode_result(result).dump(
        -1, ' ', false, Json::error_handler_t::strict);
    std::vector<std::byte> bytes;
    bytes.reserve(encoded.size());
    for (const char character : encoded) {
      bytes.push_back(
          static_cast<std::byte>(static_cast<unsigned char>(character)));
    }
    return Result<std::vector<std::byte>>::success(std::move(bytes));
  } catch (const std::bad_alloc&) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "artifact_wire_encode_allocation_failure",
        "allocation failed while encoding the canonical v1 artifact wire");
  } catch (const std::length_error&) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "artifact_wire_encode_length_failure",
        "a canonical v1 artifact wire container exceeded its size range");
  } catch (const nlohmann::json::exception& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation, "artifact_wire_encode_json",
        std::string("the v1 artifact value could not be encoded: ") +
            error.what());
  } catch (const std::invalid_argument& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation,
        "artifact_wire_encode_invalid_value",
        std::string("the v1 artifact value is not encodable: ") +
            error.what());
  } catch (const std::out_of_range& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation,
        "artifact_wire_encode_out_of_range",
        std::string("the v1 artifact value is out of range: ") +
            error.what());
  } catch (const std::overflow_error& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "artifact_wire_encode_overflow",
        std::string("size arithmetic overflowed while encoding the v1 "
                    "artifact value: ") +
            error.what());
  } catch (const std::exception& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal, "artifact_wire_encode_exception",
        std::string("unexpected exception while encoding the v1 artifact "
                    "wire: ") +
            error.what());
  } catch (...) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal,
        "artifact_wire_encode_unknown_exception",
        "unknown exception while encoding the canonical v1 artifact wire");
  }
}

Result<std::vector<std::byte>> canonical_surrogate_build_result_bytes_v2(
    const SurrogateBuildResultV2& result) {
  try {
    const std::string encoded = encode_result_v2(result).dump(
        -1, ' ', false, Json::error_handler_t::strict);
    std::vector<std::byte> bytes;
    bytes.reserve(encoded.size());
    for (const char character : encoded) {
      bytes.push_back(
          static_cast<std::byte>(static_cast<unsigned char>(character)));
    }
    return Result<std::vector<std::byte>>::success(std::move(bytes));
  } catch (const DecodeError& error) {
    return Result<std::vector<std::byte>>::failure(error.diagnostic());
  } catch (const std::bad_alloc&) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "artifact_wire_v2_encode_allocation_failure",
        "allocation failed while encoding canonical provider-result v2");
  } catch (const std::length_error&) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "artifact_wire_v2_encode_length_failure",
        "a canonical provider-result-v2 container exceeded its size range");
  } catch (const nlohmann::json::exception& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation,
        "artifact_wire_v2_encode_json",
        std::string("provider-result v2 could not be encoded: ") +
            error.what());
  } catch (const std::exception& error) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation,
        "artifact_wire_v2_encode_value",
        std::string("provider-result v2 is not encodable: ") +
            error.what());
  } catch (...) {
    return parse_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal,
        "artifact_wire_v2_encode_unknown_exception",
        "an unknown exception occurred while encoding provider-result v2");
  }
}

}  // namespace artifact::detail

Result<SurrogateBuildResult> parse_surrogate_build_result(
    const ByteSpan bytes, const ArtifactParseLimits& limits) {
  try {
    if (bytes.size() > limits.maximum_bytes) {
      return parse_failure<SurrogateBuildResult>(
          DiagnosticCategory::resource_limit,
          "artifact_parse_input_bytes_limit",
          "the completed result exceeds the parser's configured hard byte "
          "limit");
    }
    if (bytes.empty()) {
      return parse_failure<SurrogateBuildResult>(
          DiagnosticCategory::input_validation, "artifact_parse_empty_input",
          "the completed result is empty");
    }
    if (bytes.size() >= 3U &&
        std::to_integer<unsigned char>(bytes[0]) == 0xefU &&
        std::to_integer<unsigned char>(bytes[1]) == 0xbbU &&
        std::to_integer<unsigned char>(bytes[2]) == 0xbfU) {
      return parse_failure<SurrogateBuildResult>(
          DiagnosticCategory::input_validation,
          "artifact_parse_utf8_bom_forbidden",
          "the canonical v1 artifact wire must not begin with a UTF-8 BOM");
    }
    if (const std::optional<std::size_t> invalid = first_invalid_utf8(bytes);
        invalid.has_value()) {
      return parse_failure<SurrogateBuildResult>(
          DiagnosticCategory::input_validation,
          "artifact_parse_invalid_utf8",
          "the completed result is not valid canonical UTF-8", std::nullopt);
    }

    const char* const begin = reinterpret_cast<const char*>(bytes.data());
    const char* const end = begin + bytes.size();
    BoundedSaxPreflight preflight(limits);
    const bool preflight_ok = Json::sax_parse(
        begin, end, &preflight, Json::input_format_t::json, true);
    if (!preflight_ok) {
      if (preflight.diagnostic().has_value()) {
        return Result<SurrogateBuildResult>::failure(
            *preflight.diagnostic());
      }
      return parse_failure<SurrogateBuildResult>(
          DiagnosticCategory::input_validation,
          "artifact_parse_invalid_json",
          "the completed result is not closed, strict v1 JSON");
    }

    const Json document = Json::parse(begin, end, nullptr, true, false);
    const artifact::detail::PayloadWireAccess payload_wire_access;
    SurrogateBuildResult decoded =
        decode_result(document, payload_wire_access);
    Result<std::vector<std::byte>> canonical =
        artifact::detail::canonical_surrogate_build_result_bytes_v1(decoded);
    if (!canonical) {
      return Result<SurrogateBuildResult>::failure(canonical.error());
    }
    if (canonical.value().size() != bytes.size() ||
        !std::equal(canonical.value().begin(), canonical.value().end(),
                    bytes.begin())) {
      return parse_failure<SurrogateBuildResult>(
          DiagnosticCategory::input_validation,
          "artifact_parse_noncanonical_json",
          "the completed result is valid JSON but is not the exact canonical "
          "v1 artifact wire encoding");
    }
    return Result<SurrogateBuildResult>::success(std::move(decoded));
  } catch (const DecodeError& error) {
    return Result<SurrogateBuildResult>::failure(error.diagnostic());
  } catch (const std::bad_alloc&) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::resource_limit,
        "artifact_parse_allocation_failure",
        "allocation failed while parsing the bounded v1 artifact wire");
  } catch (const std::length_error&) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::resource_limit, "artifact_parse_length_failure",
        "a decoded v1 artifact container exceeded its size range");
  } catch (const nlohmann::json::exception& error) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::input_validation, "artifact_parse_json_exception",
        std::string("the completed result is not valid closed v1 JSON: ") +
            error.what());
  } catch (const std::invalid_argument& error) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::input_validation,
        "artifact_parse_invalid_argument",
        std::string("the completed result contains an invalid v1 value: ") +
            error.what());
  } catch (const std::out_of_range& error) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::input_validation, "artifact_parse_out_of_range",
        std::string("the completed result contains an out-of-range v1 value: ") +
            error.what());
  } catch (const std::overflow_error& error) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::resource_limit, "artifact_parse_overflow",
        std::string("size or exact-number arithmetic overflowed while parsing "
                    "the v1 artifact wire: ") +
            error.what());
  } catch (const std::exception& error) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::internal, "artifact_parse_exception",
        std::string("unexpected exception while parsing the v1 artifact "
                    "wire: ") +
            error.what());
  } catch (...) {
    return parse_failure<SurrogateBuildResult>(
        DiagnosticCategory::internal,
        "artifact_parse_unknown_exception",
        "unknown exception while parsing the bounded v1 artifact wire");
  }
}

Result<SurrogateBuildResultV2> assemble_surrogate_build_result_v2(
    ParsedSurrogateResultFrameV2 frame) {
  auto* decoded =
      std::get_if<SurrogateBuildResultBranchV2>(
          &frame.branch_decode_outcome);
  if (decoded == nullptr) {
    const auto& failure =
        std::get<SurrogateResultBranchDecodeFailureV2>(
            frame.branch_decode_outcome);
    return Result<SurrogateBuildResultV2>::failure(failure.diagnostic);
  }
  switch (frame.declared_kind) {
    case ProviderResultKindV2::built:
      if (auto* built = std::get_if<BuiltSurrogateResultBodyV2>(decoded)) {
        return Result<SurrogateBuildResultV2>::success(
            BuiltSurrogateResultV2{std::move(frame.envelope),
                                   std::move(built->artifact)});
      }
      break;
    case ProviderResultKindV2::unavailable:
      if (auto* unavailable =
              std::get_if<UnavailableSurrogateResultBodyV2>(decoded)) {
        return Result<SurrogateBuildResultV2>::success(
            UnavailableSurrogateResultV2{
                std::move(frame.envelope), std::move(unavailable->reasons),
                std::move(unavailable->strongest_truthful_alternative)});
      }
      break;
    case ProviderResultKindV2::failed:
      if (auto* failed = std::get_if<FailedSurrogateResultBodyV2>(decoded)) {
        return Result<SurrogateBuildResultV2>::success(
            FailedSurrogateResultV2{std::move(frame.envelope),
                                    std::move(failed->failure)});
      }
      break;
    case ProviderResultKindV2::observed:
      break;
  }
  return parse_failure<SurrogateBuildResultV2>(
      DiagnosticCategory::internal,
      "artifact_v2_frame_branch_kind_mismatch",
      "the staged provider-result-v2 branch differs from its declared kind");
}

Result<ParsedSurrogateResultFrameV2> parse_surrogate_build_result_v2(
    const ByteSpan bytes, const ArtifactParseLimits& artifact_limits,
    const ObservationParseLimitsV1& observation_limits) {
  try {
    if (bytes.size() > artifact_limits.maximum_bytes) {
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::resource_limit,
          "artifact_v2_parse_input_bytes_limit",
          "provider-result v2 exceeds the configured hard byte limit");
    }
    if (bytes.empty()) {
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::input_validation,
          "artifact_v2_parse_empty_input",
          "provider-result v2 is empty");
    }
    if (bytes.size() >= 3U &&
        std::to_integer<unsigned char>(bytes[0]) == 0xefU &&
        std::to_integer<unsigned char>(bytes[1]) == 0xbbU &&
        std::to_integer<unsigned char>(bytes[2]) == 0xbfU) {
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::input_validation,
          "artifact_v2_parse_utf8_bom_forbidden",
          "canonical provider-result v2 must not begin with a UTF-8 BOM");
    }
    if (first_invalid_utf8(bytes).has_value()) {
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::input_validation,
          "artifact_v2_parse_invalid_utf8",
          "provider-result v2 is not valid canonical UTF-8");
    }

    const char* const begin = reinterpret_cast<const char*>(bytes.data());
    const char* const end = begin + bytes.size();
    // One initial SAX pass applies both the outer artifact limits and the
    // embedded observation's tighter cardinality/allocation limits before
    // either DOM is constructed.  The later diagnostics-only subparse still
    // supplies the standalone codec's duplicate/canonical checks.
    BoundedSaxPreflight preflight(artifact_limits, &observation_limits);
    const bool preflight_ok = Json::sax_parse(
        begin, end, &preflight, Json::input_format_t::json, true);
    if (!preflight_ok) {
      if (preflight.diagnostic().has_value()) {
        return Result<ParsedSurrogateResultFrameV2>::failure(
            *preflight.diagnostic());
      }
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::input_validation,
          "artifact_v2_parse_invalid_json",
          "provider-result v2 is not strict JSON");
    }

    const Json document = Json::parse(begin, end, nullptr, true, false);
    const ProviderResultKindV2 kind = decode_result_kind_v2(document);
    // The closed root vocabulary is part of the common frame, not the
    // terminal branch body.  Reject an unknown or cross-branch root member
    // before decoding (and therefore before retaining) the observation.
    // Branch members themselves remain optional at this stage so a missing
    // or malformed allowed branch body can still produce a staged
    // branch-decode failure with the validated common envelope intact.
    switch (kind) {
      case ProviderResultKindV2::built:
        require_object_shape(document, "", {"kind"},
                             {"envelope", "artifact"});
        break;
      case ProviderResultKindV2::unavailable:
        require_object_shape(
            document, "", {"kind"},
            {"envelope", "reasons", "strongest_truthful_alternative"});
        break;
      case ProviderResultKindV2::failed:
        require_object_shape(document, "", {"kind"},
                             {"envelope", "failure"});
        break;
      case ProviderResultKindV2::observed:
        decode_fail("artifact_wire_unknown_union_tag",
                    "provider-result v2 does not admit Observed", "/kind");
    }
    if (document.size() < 2U) {
      decode_fail("artifact_wire_missing_field",
                  "provider-result v2 lacks its common envelope",
                  "/envelope");
    }
    auto iterator = document.begin();
    if (iterator.key() != "kind" || (++iterator).key() != "envelope") {
      decode_fail("artifact_v2_noncanonical_root_order",
                  "provider-result v2 must place kind and envelope first in "
                  "canonical member order",
                  "");
    }
    const Json& envelope_json = required_member(document, "envelope", "");
    ResultEnvelopeV2 envelope = decode_result_envelope_v2(
        envelope_json, "/envelope", observation_limits);

    // Even if the branch is malformed, only a byte-canonical common envelope
    // may survive.  The complete valid-branch check below covers the root and
    // branch member order as well.
    const std::string canonical_envelope =
        encode_result_envelope_v2(envelope).dump(
            -1, ' ', false, Json::error_handler_t::strict);
    if (canonical_envelope != envelope_json.dump(
                                  -1, ' ', false,
                                  Json::error_handler_t::strict)) {
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::input_validation,
          "artifact_v2_parse_noncanonical_envelope",
          "provider-result v2 has a noncanonical common envelope");
    }
    const std::string compact_document = document.dump(
        -1, ' ', false, Json::error_handler_t::strict);
    if (compact_document.size() != bytes.size() ||
        !std::equal(compact_document.begin(), compact_document.end(), begin)) {
      return parse_failure<ParsedSurrogateResultFrameV2>(
          DiagnosticCategory::input_validation,
          "artifact_v2_parse_noncanonical_json",
          "provider-result v2 is valid JSON but not compact canonical JSON");
    }

    // Neither the successful branch union nor its first Built alternative is
    // default-constructible.  Construct the outer staged outcome directly in
    // the branch that supplies its value instead of manufacturing a sentinel
    // state merely to assign over it later.
    SurrogateResultBranchDecodeOutcomeV2 branch_outcome =
        [&]() -> SurrogateResultBranchDecodeOutcomeV2 {
      try {
        const artifact::detail::PayloadWireAccess payload_wire_access;
        SurrogateBuildResultBranchV2 branch =
            decode_result_branch_v2(document, kind, payload_wire_access);
        const std::string canonical =
            encode_result_frame_v2(envelope, branch).dump(
                -1, ' ', false, Json::error_handler_t::strict);
        if (canonical.size() != bytes.size() ||
            !std::equal(canonical.begin(), canonical.end(), begin)) {
          decode_fail(
              "artifact_v2_parse_noncanonical_branch",
              "the provider-result-v2 branch does not use its fixed "
              "canonical member order and typed encoding",
              "");
        }
        return SurrogateResultBranchDecodeOutcomeV2{
            std::in_place_type<SurrogateBuildResultBranchV2>,
            std::move(branch)};
      } catch (const DecodeError& error) {
        return SurrogateResultBranchDecodeOutcomeV2{
            std::in_place_type<SurrogateResultBranchDecodeFailureV2>,
            SurrogateResultBranchDecodeFailureV2{error.diagnostic()}};
      }
    }();

    return Result<ParsedSurrogateResultFrameV2>::success(
        ParsedSurrogateResultFrameV2{
            std::move(envelope), kind, std::move(branch_outcome)});
  } catch (const DecodeError& error) {
    return Result<ParsedSurrogateResultFrameV2>::failure(error.diagnostic());
  } catch (const std::bad_alloc&) {
    return parse_failure<ParsedSurrogateResultFrameV2>(
        DiagnosticCategory::resource_limit,
        "artifact_v2_parse_allocation_failure",
        "allocation failed while parsing bounded provider-result v2");
  } catch (const std::length_error&) {
    return parse_failure<ParsedSurrogateResultFrameV2>(
        DiagnosticCategory::resource_limit,
        "artifact_v2_parse_length_failure",
        "a provider-result-v2 container exceeded its size range");
  } catch (const nlohmann::json::exception& error) {
    return parse_failure<ParsedSurrogateResultFrameV2>(
        DiagnosticCategory::input_validation,
        "artifact_v2_parse_json_exception",
        std::string("provider-result v2 contains invalid JSON: ") +
            error.what());
  } catch (const std::overflow_error& error) {
    return parse_failure<ParsedSurrogateResultFrameV2>(
        DiagnosticCategory::resource_limit,
        "artifact_v2_parse_overflow",
        std::string("size arithmetic overflowed while parsing "
                    "provider-result v2: ") +
            error.what());
  } catch (const std::exception& error) {
    return parse_failure<ParsedSurrogateResultFrameV2>(
        DiagnosticCategory::internal,
        "artifact_v2_parse_exception",
        std::string("unexpected provider-result-v2 parse exception: ") +
            error.what());
  } catch (...) {
    return parse_failure<ParsedSurrogateResultFrameV2>(
        DiagnosticCategory::internal,
        "artifact_v2_parse_unknown_exception",
        "an unknown exception occurred while parsing provider-result v2");
  }
}

Result<ParsedSurrogateResultFrameV3> parse_surrogate_build_result_v3(
    const ByteSpan bytes, const ArtifactParseLimits& artifact_limits,
    const ObservationParseLimitsV1& observation_limits) {
  try {
    if (bytes.size() > artifact_limits.maximum_bytes) {
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::resource_limit,
          "artifact_v3_parse_input_bytes_limit",
          "provider-result v3 exceeds the configured hard byte limit");
    }
    if (bytes.empty()) {
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::input_validation,
          "artifact_v3_parse_empty_input", "provider-result v3 is empty");
    }
    if (bytes.size() >= 3U &&
        std::to_integer<unsigned char>(bytes[0]) == 0xefU &&
        std::to_integer<unsigned char>(bytes[1]) == 0xbbU &&
        std::to_integer<unsigned char>(bytes[2]) == 0xbfU) {
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::input_validation,
          "artifact_v3_parse_utf8_bom_forbidden",
          "canonical provider-result v3 must not begin with a UTF-8 BOM");
    }
    if (first_invalid_utf8(bytes).has_value()) {
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::input_validation,
          "artifact_v3_parse_invalid_utf8",
          "provider-result v3 is not valid canonical UTF-8");
    }

    const char* const begin = reinterpret_cast<const char*>(bytes.data());
    const char* const end = begin + bytes.size();
    BoundedSaxPreflight preflight(artifact_limits, &observation_limits);
    const bool preflight_ok = Json::sax_parse(
        begin, end, &preflight, Json::input_format_t::json, true);
    if (!preflight_ok) {
      if (preflight.diagnostic().has_value()) {
        return Result<ParsedSurrogateResultFrameV3>::failure(
            *preflight.diagnostic());
      }
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::input_validation,
          "artifact_v3_parse_invalid_json",
          "provider-result v3 is not strict JSON");
    }

    const Json document = Json::parse(begin, end, nullptr, true, false);
    const ProviderResultKindV2 kind = decode_result_kind_v3(document);
    switch (kind) {
      case ProviderResultKindV2::observed:
        require_object_shape(document, "", {"kind"}, {"envelope"});
        break;
      case ProviderResultKindV2::unavailable:
        require_object_shape(
            document, "", {"kind"},
            {"envelope", "reasons", "strongest_truthful_alternative"});
        break;
      case ProviderResultKindV2::failed:
        require_object_shape(document, "", {"kind"},
                             {"envelope", "failure"});
        break;
      case ProviderResultKindV2::built:
        decode_fail("artifact_wire_unknown_union_tag",
                    "provider-result v3 does not admit Built", "/kind");
    }
    if (document.size() < 2U) {
      decode_fail("artifact_wire_missing_field",
                  "provider-result v3 lacks its common envelope",
                  "/envelope");
    }
    auto iterator = document.begin();
    if (iterator.key() != "kind" || (++iterator).key() != "envelope") {
      decode_fail("artifact_v3_noncanonical_root_order",
                  "provider-result v3 must place kind and envelope first in "
                  "canonical member order",
                  "");
    }
    const Json& envelope_json = required_member(document, "envelope", "");
    ResultEnvelopeV3 envelope = decode_result_envelope_v3(
        envelope_json, "/envelope", observation_limits);
    const std::string canonical_envelope =
        encode_result_envelope_v2(envelope).dump(
            -1, ' ', false, Json::error_handler_t::strict);
    if (canonical_envelope != envelope_json.dump(
                                  -1, ' ', false,
                                  Json::error_handler_t::strict)) {
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::input_validation,
          "artifact_v3_parse_noncanonical_envelope",
          "provider-result v3 has a noncanonical common envelope");
    }
    const std::string compact_document = document.dump(
        -1, ' ', false, Json::error_handler_t::strict);
    if (compact_document.size() != bytes.size() ||
        !std::equal(compact_document.begin(), compact_document.end(), begin)) {
      return parse_failure<ParsedSurrogateResultFrameV3>(
          DiagnosticCategory::input_validation,
          "artifact_v3_parse_noncanonical_json",
          "provider-result v3 is valid JSON but not compact canonical JSON");
    }

    SurrogateResultBranchDecodeOutcomeV3 branch_outcome =
        [&]() -> SurrogateResultBranchDecodeOutcomeV3 {
      try {
        SurrogateBuildResultBranchV3 branch =
            decode_result_branch_v3(document, kind);
        const std::string canonical = encode_result_frame_v3(envelope, branch)
                                          .dump(-1, ' ', false,
                                                Json::error_handler_t::strict);
        if (canonical.size() != bytes.size() ||
            !std::equal(canonical.begin(), canonical.end(), begin)) {
          decode_fail(
              "artifact_v3_parse_noncanonical_branch",
              "the provider-result-v3 branch does not use its fixed "
              "canonical member order and typed encoding",
              "");
        }
        return SurrogateResultBranchDecodeOutcomeV3{
            std::in_place_type<SurrogateBuildResultBranchV3>,
            std::move(branch)};
      } catch (const DecodeError& error) {
        return SurrogateResultBranchDecodeOutcomeV3{
            std::in_place_type<SurrogateResultBranchDecodeFailureV3>,
            SurrogateResultBranchDecodeFailureV3{error.diagnostic()}};
      }
    }();
    return Result<ParsedSurrogateResultFrameV3>::success(
        ParsedSurrogateResultFrameV3{
            std::move(envelope), kind, std::move(branch_outcome)});
  } catch (const DecodeError& error) {
    return Result<ParsedSurrogateResultFrameV3>::failure(error.diagnostic());
  } catch (const std::bad_alloc&) {
    return parse_failure<ParsedSurrogateResultFrameV3>(
        DiagnosticCategory::resource_limit,
        "artifact_v3_parse_allocation_failure",
        "allocation failed while parsing bounded provider-result v3");
  } catch (const std::length_error&) {
    return parse_failure<ParsedSurrogateResultFrameV3>(
        DiagnosticCategory::resource_limit,
        "artifact_v3_parse_length_failure",
        "a provider-result-v3 container exceeded its size range");
  } catch (const nlohmann::json::exception& error) {
    return parse_failure<ParsedSurrogateResultFrameV3>(
        DiagnosticCategory::input_validation,
        "artifact_v3_parse_json_exception",
        std::string("provider-result v3 contains invalid JSON: ") +
            error.what());
  } catch (const std::overflow_error& error) {
    return parse_failure<ParsedSurrogateResultFrameV3>(
        DiagnosticCategory::resource_limit,
        "artifact_v3_parse_overflow",
        std::string("size arithmetic overflowed while parsing provider-result "
                    "v3: ") +
            error.what());
  } catch (const std::exception& error) {
    return parse_failure<ParsedSurrogateResultFrameV3>(
        DiagnosticCategory::internal,
        "artifact_v3_parse_exception",
        std::string("unexpected provider-result-v3 parse exception: ") +
            error.what());
  } catch (...) {
    return parse_failure<ParsedSurrogateResultFrameV3>(
        DiagnosticCategory::internal,
        "artifact_v3_parse_unknown_exception",
        "an unknown exception occurred while parsing provider-result v3");
  }
}

}  // namespace mwperf
