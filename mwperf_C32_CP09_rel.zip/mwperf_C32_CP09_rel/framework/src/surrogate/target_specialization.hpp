#pragma once

#include <algorithm>
#include <cstddef>
#include <span>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"

namespace mwperf::detail {

[[nodiscard]] inline bool is_full_orbit_1_1(
    const ProviderIdentityV1& provider) noexcept {
  return provider.provider_id == "full_orbit_framework_sampler" &&
         provider.provider_version == "1.1.0";
}

// The released Full Orbit scalar-response envelopes are frozen with q0 as a
// prototype while their clauses and roles declare a deployed-singleton
// target.  CP06 (1.1), CP07.1 K-wide (1.2), and the additive observation
// route (1.3), and CP09's observation-only compatibility ceiling (1.4) share
// that manifest specialization contract.  Keep this
// predicate separate from is_full_orbit_1_1: the latter also gates CP06-only
// execution behavior.
[[nodiscard]] inline bool supports_full_orbit_scalar_manifest_specialization(
    const ProviderIdentityV1& provider) noexcept {
  return provider.provider_id == "full_orbit_framework_sampler" &&
         (provider.provider_version == "1.1.0" ||
          provider.provider_version == "1.2.0" ||
          provider.provider_version == "1.3.0" ||
          provider.provider_version == "1.4.0");
}

// Permit only the frozen target-prototype axis to be bound at preview time.
// Every other provider retains literal target equality.
[[nodiscard]] inline bool metric_targets_are_narrowing(
    const MetricSupportClauseV1& subset,
    const MetricSupportClauseV1& ceiling,
    const ProviderIdentityV1& provider,
    const std::span<const QueueId> deployed_targets) noexcept {
  if (!supports_full_orbit_scalar_manifest_specialization(provider)) {
    return subset.ordered_targets == ceiling.ordered_targets;
  }
  if (
      subset.target_coupling != TargetCouplingV1::scalar_target ||
      ceiling.target_coupling != TargetCouplingV1::scalar_target ||
      subset.ordered_targets.size() != 1U ||
      ceiling.ordered_targets.size() != 1U || deployed_targets.size() != 1U ||
      subset.ordered_targets.front() != deployed_targets.front()) {
    return false;
  }
  if (subset.ordered_targets == ceiling.ordered_targets) {
    return true;
  }
  const TypedLabel& prototype = ceiling.ordered_targets.front().label();
  if (!prototype.is_text() || *prototype.text_value() != "q0") {
    return false;
  }
  return std::any_of(
      ceiling.required_roles.begin(), ceiling.required_roles.end(),
      [](const MetricSupportRoleRequirementV1& role) {
        return role.target_scope ==
               MetricTargetScopeV1::deployed_singleton_target;
      });
}

// The Full Orbit scalar-response upper envelopes unnecessarily list an
// opportunity mark.  The deployed ThreeBin and finite-prefix constant-tail
// payloads are direct backlog-to-service responses and have no causal C-minus
// operation.  Permit their concrete contracts to remove exactly that unused
// mark; no other provider, version, or mark mutation is accepted.
[[nodiscard]] inline bool metric_marks_are_narrowing(
    const MetricSupportClauseV1& subset,
    const MetricSupportClauseV1& ceiling,
    const ProviderIdentityV1& provider) {
  if (subset.marks == ceiling.marks) {
    return true;
  }
  if (!supports_full_orbit_scalar_manifest_specialization(provider) ||
      subset.semantic != SemanticTagV1::scalar_backlog_response ||
      ceiling.semantic != SemanticTagV1::scalar_backlog_response) {
    return false;
  }
  std::vector<MarkDescriptorV1> narrowed;
  narrowed.reserve(ceiling.marks.size());
  std::size_t removed = 0U;
  for (const MarkDescriptorV1& mark : ceiling.marks) {
    if (mark.kind == MetricMarkKindV1::opportunity) {
      ++removed;
    } else {
      narrowed.push_back(mark);
    }
  }
  return removed == 1U && subset.marks == narrowed;
}

}  // namespace mwperf::detail
