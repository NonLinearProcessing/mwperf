#pragma once

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/surrogate/surrogate_registry.hpp"

namespace mwperf {

namespace detail {
class SurrogateRegistryAssembler;
}

// Dependency-injected registry values are intentionally confined to this
// noninstalled header.  Production exposes only F-C16-01.
class SurrogateRegistry final {
 public:
  SurrogateRegistry(const SurrogateRegistry&) noexcept = default;
  SurrogateRegistry(SurrogateRegistry&& other) noexcept
      : providers_(other.providers_) {}
  SurrogateRegistry& operator=(const SurrogateRegistry&) noexcept = default;
  SurrogateRegistry& operator=(SurrogateRegistry&& other) noexcept {
    if (this != &other) providers_ = other.providers_;
    return *this;
  }

  [[nodiscard]] std::span<const SurrogateProvider> providers() const noexcept {
    return *providers_;
  }

 private:
  explicit SurrogateRegistry(
      std::shared_ptr<const std::vector<SurrogateProvider>> providers)
      : providers_(std::move(providers)) {}

  std::shared_ptr<const std::vector<SurrogateProvider>> providers_;
  friend class detail::SurrogateRegistryAssembler;
};

namespace detail {

class C16ProviderRegistryMint final {
 public:
  C16ProviderRegistryMint() = delete;
  [[nodiscard]] static SurrogateProvider mint(
      ValidatedProviderManifest manifest,
      ParameterValidatorV1 parameter_validator,
      DescriptorPreviewerV1 previewer, ProviderProducerV1 producer,
      RuntimePlugMaterializerV1 materializer,
      std::optional<FrameworkActivationRegistrationV1> framework_activation,
      std::uint32_t result_protocol_version,
      std::optional<ObservationEnvelopeValidatorV1>
          observation_envelope_validator,
      const void* registry_provenance);
};

class C16ExecutableSpecMint final {
 public:
  C16ExecutableSpecMint() = delete;
  [[nodiscard]] static RegisteredExecutableSpec mint(
      ProviderIdentityV1 provider_identity, Digest256 manifest_digest,
      std::string executable_id, std::filesystem::path absolute_executable,
      std::uint32_t argv_grammar_version,
      std::vector<std::string> fixed_arguments,
      std::chrono::milliseconds wall_time_limit,
      std::size_t maximum_stderr_bytes,
      std::optional<std::size_t> maximum_request_bytes,
      std::optional<std::size_t> maximum_result_bytes,
      std::optional<std::size_t> maximum_worker_count,
      std::optional<std::chrono::milliseconds> maximum_wall_time_limit);
};

[[nodiscard]] const Result<SurrogateRegistry>& production_surrogate_registry();

// This noninstalled assembler exists only for deterministic production-table
// construction and isolated registry tests.  `assemble` deliberately creates
// inert, unsealed handles; only production_surrogate_registry may request the
// private sealed path.
class SurrogateRegistryAssembler final {
 public:
  SurrogateRegistryAssembler() = delete;
  [[nodiscard]] static Result<SurrogateRegistry> assemble(
      std::vector<SurrogateProviderRegistrationV1> registrations);

  [[nodiscard]] static Result<RegisteredExecutableSpec> executable_spec(
      ProviderIdentityV1 provider_identity, Digest256 manifest_digest,
      std::string executable_id, std::filesystem::path absolute_executable,
      std::uint32_t argv_grammar_version,
      std::vector<std::string> fixed_arguments,
      std::chrono::milliseconds wall_time_limit,
      std::size_t maximum_stderr_bytes,
      std::optional<std::size_t> maximum_request_bytes = std::nullopt,
      std::optional<std::size_t> maximum_result_bytes = std::nullopt,
      std::optional<std::size_t> maximum_worker_count = std::nullopt,
      std::optional<std::chrono::milliseconds> maximum_wall_time_limit =
          std::nullopt);

 private:
  [[nodiscard]] static Result<SurrogateRegistry> assemble_static(
      std::vector<SurrogateProviderRegistrationV1> registrations);
  [[nodiscard]] static Result<SurrogateRegistry> assemble_impl(
      std::vector<SurrogateProviderRegistrationV1> registrations,
      const void* registry_provenance);

  friend const Result<SurrogateRegistry>& production_surrogate_registry();
};

[[nodiscard]] Result<SurrogateProvider> lookup_in_surrogate_registry(
    const SurrogateRegistry& registry, const SurrogateId& id,
    const std::optional<SurrogateVersion>& version);

}  // namespace detail
}  // namespace mwperf
