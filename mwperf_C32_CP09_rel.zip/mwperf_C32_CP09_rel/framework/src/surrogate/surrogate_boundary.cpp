#include "mwperf/surrogate/plug_contract.hpp"

#include "mwperf/surrogate/audited_consumer_seam.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <functional>
#include <new>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#include "metrics/plug_descriptor_core_validation_detail.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "target_specialization.hpp"

namespace mwperf {
#if defined(MWPERF_C16_TEST_SEAMS)
namespace testing {
[[nodiscard]] Result<void> validate_c16_operation_carriers_for_test(
    const PlugDescriptor& descriptor, const SurrogatePlug& plug);
}  // namespace testing
#endif
namespace {

constexpr std::uint32_t kC16RuntimeDescriptorSchemaV1 = 1U;

[[nodiscard]] Diagnostic boundary_error(std::string code,
                                        std::string message,
                                        std::string pointer = {}) {
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    pointer.empty()
                        ? std::optional<std::string>{}
                        : std::optional<std::string>{std::move(pointer)},
                    {}};
}

class C16Encoder final {
 public:
  void byte(std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void boolean(bool value) { byte(value ? 1U : 0U); }
  void u32(std::uint32_t value) {
    for (unsigned shift = 32U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  void u64(std::uint64_t value) {
    for (unsigned shift = 64U; shift != 0U; shift -= 8U) {
      byte(static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }
  void count(std::size_t value) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
    u64(static_cast<std::uint64_t>(value));
  }
  template <typename Enum>
    requires std::is_enum_v<Enum>
  void enumeration(Enum value) {
    using Underlying = std::underlying_type_t<Enum>;
    using Unsigned = std::make_unsigned_t<Underlying>;
    u64(static_cast<std::uint64_t>(static_cast<Unsigned>(value)));
  }
  void raw(std::span<const std::byte> value) {
    count(value.size());
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }
  void raw_u8(std::span<const std::uint8_t> value) {
    count(value.size());
    for (std::uint8_t byte_value : value) byte(byte_value);
  }
  void digest(const Digest256& value) { raw(value.bytes()); }
  void codec(const CodecIdentityV1& value) {
    count(value.id.size());
    for (char character : value.id) {
      byte(static_cast<std::uint8_t>(static_cast<unsigned char>(character)));
    }
    u32(value.version);
  }
  template <StrongIdDomainName Domain>
  void id(const StrongId<Domain>& value) {
    raw_u8(value.canonical_bytes());
  }
  [[nodiscard]] std::span<const std::byte> bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] bool valid_codec(const CodecIdentityV1& codec) noexcept {
  return !codec.id.empty() && codec.version != 0U;
}

[[nodiscard]] bool valid_domain(RuntimeDomainKindV1 domain) noexcept {
  switch (domain) {
    case RuntimeDomainKindV1::finite:
    case RuntimeDomainKindV1::countable:
    case RuntimeDomainKindV1::standard_borel_procedural:
      return true;
  }
  return false;
}

[[nodiscard]] bool ownership_matches_field_kind(
    StateFieldKindV1 kind, FieldOwnershipV1 ownership) noexcept {
  switch (kind) {
    case StateFieldKindV1::target_backlog:
    case StateFieldKindV1::configured_arrival_predictive_phase:
    case StateFieldKindV1::controller_memory:
    case StateFieldKindV1::resource_coordinate:
    case StateFieldKindV1::local_margin:
      return ownership == FieldOwnershipV1::framework_exact;
    case StateFieldKindV1::surrogate_phase:
    case StateFieldKindV1::event_state:
    case StateFieldKindV1::entrance_label_state:
      return ownership == FieldOwnershipV1::surrogate_owned;
  }
  return false;
}

[[nodiscard]] bool valid_mark_source(MarkDecoderSourceV1 source) noexcept {
  switch (source) {
    case MarkDecoderSourceV1::predecision_state:
    case MarkDecoderSourceV1::c_minus_joint_output:
    case MarkDecoderSourceV1::decision_schedule:
    case MarkDecoderSourceV1::configured_arrival:
    case MarkDecoderSourceV1::c_plus_joint_output:
    case MarkDecoderSourceV1::postarrival_state:
    case MarkDecoderSourceV1::completed_edge:
    case MarkDecoderSourceV1::entrance_realization:
      return true;
  }
  return false;
}

[[nodiscard]] std::optional<unsigned> within_slot_stage(
    MetricRevealStageV1 stage) noexcept {
  switch (stage) {
    case MetricRevealStageV1::predecision:
      return 0U;
    case MetricRevealStageV1::decision:
      return 1U;
    case MetricRevealStageV1::arrival:
      return 2U;
    case MetricRevealStageV1::postarrival:
      return 3U;
    case MetricRevealStageV1::completed_edge:
      return 4U;
    case MetricRevealStageV1::entrance_label:
      return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] std::optional<unsigned> source_stage(
    MarkDecoderSourceV1 source) noexcept {
  switch (source) {
    case MarkDecoderSourceV1::predecision_state:
    case MarkDecoderSourceV1::c_minus_joint_output:
      return 0U;
    case MarkDecoderSourceV1::decision_schedule:
      return 1U;
    case MarkDecoderSourceV1::configured_arrival:
      return 2U;
    case MarkDecoderSourceV1::c_plus_joint_output:
    case MarkDecoderSourceV1::postarrival_state:
      return 3U;
    case MarkDecoderSourceV1::completed_edge:
      return 4U;
    case MarkDecoderSourceV1::entrance_realization:
      return std::nullopt;
  }
  return std::nullopt;
}

template <typename Id>
[[nodiscard]] std::string stable_key(const Id& value) {
  const auto bytes = value.canonical_bytes();
  return std::string(reinterpret_cast<const char*>(bytes.data()),
                     bytes.size());
}

[[nodiscard]] bool temporal_semantic(SemanticTagV1 semantic) noexcept {
  return semantic == SemanticTagV1::temporal_one_slot_continuation ||
         semantic == SemanticTagV1::romr_residence_word_law ||
         semantic == SemanticTagV1::stopped_path_law;
}

[[nodiscard]] bool transition_access(
    RuntimeAccessTagV1 access) noexcept {
  return access == RuntimeAccessTagV1::finite_enumerated_row ||
         access == RuntimeAccessTagV1::sparse_row ||
         access == RuntimeAccessTagV1::normalized_conditional_sampler;
}

[[nodiscard]] bool valid_operation_identity(
    const RuntimeOperationIdentityV1& identity) noexcept {
  return !identity.operation_id.canonical_bytes().empty() &&
         identity.operation_version == 1U;
}

[[nodiscard]] bool certificate_level_valid(CertificateLevelV1 level) {
  switch (level) {
    case CertificateLevelV1::declaration:
    case CertificateLevelV1::v0_shape:
    case CertificateLevelV1::v1_witness:
    case CertificateLevelV1::v2_witness:
      return true;
  }
  return false;
}

[[nodiscard]] bool event_kind_valid(EventContractKindV1 kind) noexcept {
  switch (kind) {
    case EventContractKindV1::one_slot_continuation:
    case EventContractKindV1::romr_residence:
    case EventContractKindV1::stopped_path:
      return true;
  }
  return false;
}

[[nodiscard]] bool event_filtration_valid(EventFiltrationV1 value) noexcept {
  switch (value) {
    case EventFiltrationV1::generated_slot_natural_filtration:
      return true;
  }
  return false;
}

template <typename Value, typename Key>
[[nodiscard]] bool strictly_ordered_unique(const std::vector<Value>& values,
                                           Key key) {
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (!(key(values[index - 1U]) < key(values[index]))) return false;
  }
  return true;
}

[[nodiscard]] bool exact_mark_source_for_kind(
    const RuntimeMarkDescriptorV1& mark) noexcept {
  const MarkDecoderSourceV1 source = mark.decoder_source;
  if (mark.c14_mark.reveal_stage == MetricRevealStageV1::entrance_label) {
    return source == MarkDecoderSourceV1::entrance_realization;
  }
  switch (mark.c14_mark.kind) {
    case MetricMarkKindV1::target_backlog:
      return source == MarkDecoderSourceV1::predecision_state;
    case MetricMarkKindV1::predictive_phase:
      return mark.c14_mark.reveal_stage == MetricRevealStageV1::predecision
                 ? source == MarkDecoderSourceV1::predecision_state
                 : source == MarkDecoderSourceV1::postarrival_state;
    case MetricMarkKindV1::opportunity:
      return source == MarkDecoderSourceV1::c_minus_joint_output;
    case MetricMarkKindV1::actual_departure:
    case MetricMarkKindV1::schedule_projection:
    case MetricMarkKindV1::full_schedule:
      return source == MarkDecoderSourceV1::decision_schedule;
    case MetricMarkKindV1::arrival_batch:
      return source == MarkDecoderSourceV1::configured_arrival;
    case MetricMarkKindV1::successor_backlog:
      return source == MarkDecoderSourceV1::postarrival_state;
    case MetricMarkKindV1::within_batch_rank:
    case MetricMarkKindV1::batch_size:
    case MetricMarkKindV1::class_label:
    case MetricMarkKindV1::phase_label:
      return false;
    case MetricMarkKindV1::edge_increment:
    case MetricMarkKindV1::event_indicator:
    case MetricMarkKindV1::predicate:
    case MetricMarkKindV1::predicate_start:
    case MetricMarkKindV1::active_component:
    case MetricMarkKindV1::counterfactual_permission:
      return source == MarkDecoderSourceV1::completed_edge ||
             source == MarkDecoderSourceV1::c_minus_joint_output ||
             source == MarkDecoderSourceV1::c_plus_joint_output;
  }
  return false;
}

}  // namespace

CPlusCallbackV1 CPlusOperationV1::guard_output_fields(
    const CPlusOperationSchemaV1& schema, CPlusCallbackV1 callback) {
  if (!callback) return {};

  const std::vector<RuntimeFieldIdV1> writable_fields =
      schema.writable_unresolved_fields;
  return [callback = std::move(callback), writable_fields](
             const CPlusInputV1& input,
             DeterministicRng& rng) mutable -> Result<CPlusOutputV1> {
    Result<CPlusOutputV1> output = callback(input, rng);
    if (!output) return output;

    const std::vector<RuntimeFieldPatchV1>& patch =
        output.value().unresolved_patch;
    for (std::size_t index = 0U; index < patch.size(); ++index) {
      bool declared_writable = false;
      for (const RuntimeFieldIdV1& field : writable_fields) {
        if (patch[index].field == field) {
          declared_writable = true;
          break;
        }
      }
      if (!declared_writable) {
        return Result<CPlusOutputV1>::failure(boundary_error(
            "c16.c_plus_patch_field_not_writable",
            "C-plus returned a field patch outside its declared unresolved "
            "write set",
            "/c_plus/output/unresolved_patch/" + std::to_string(index) +
                "/field"));
      }
      for (std::size_t prior = 0U; prior < index; ++prior) {
        if (patch[prior].field == patch[index].field) {
          return Result<CPlusOutputV1>::failure(boundary_error(
              "c16.c_plus_duplicate_field_patch",
              "C-plus returned more than one patch for the same unresolved "
              "field",
              "/c_plus/output/unresolved_patch/" + std::to_string(index) +
                  "/field"));
        }
      }
    }
    return output;
  };
}

EnumerateCPlusExactLawV1 CPlusOperationV1::guard_enumerated_output_fields(
    const CPlusOperationSchemaV1& schema,
    EnumerateCPlusExactLawV1 enumerator) {
  if (!enumerator) return {};

  const std::vector<RuntimeFieldIdV1> writable_fields =
      schema.writable_unresolved_fields;
  return [enumerator = std::move(enumerator), writable_fields](
             const CPlusInputV1& input) mutable
      -> Result<std::vector<EnumeratedCPlusAtomV1>> {
    auto row = enumerator(input);
    if (!row) return row;

    for (std::size_t atom = 0U; atom < row.value().size(); ++atom) {
      const std::vector<RuntimeFieldPatchV1>& patch =
          row.value()[atom].output.unresolved_patch;
      for (std::size_t index = 0U; index < patch.size(); ++index) {
        bool declared_writable = false;
        for (const RuntimeFieldIdV1& field : writable_fields) {
          if (patch[index].field == field) {
            declared_writable = true;
            break;
          }
        }
        if (!declared_writable) {
          return Result<std::vector<EnumeratedCPlusAtomV1>>::failure(
              boundary_error(
                  "c16.c_plus_patch_field_not_writable",
                  "C-plus returned a field patch outside its declared "
                  "unresolved write set",
                  "/c_plus/exact_row/" + std::to_string(atom) +
                      "/output/unresolved_patch/" + std::to_string(index) +
                      "/field"));
        }
        for (std::size_t prior = 0U; prior < index; ++prior) {
          if (patch[prior].field == patch[index].field) {
            return Result<std::vector<EnumeratedCPlusAtomV1>>::failure(
                boundary_error(
                    "c16.c_plus_duplicate_field_patch",
                    "C-plus returned more than one patch for the same "
                    "unresolved field",
                    "/c_plus/exact_row/" + std::to_string(atom) +
                        "/output/unresolved_patch/" +
                        std::to_string(index) + "/field"));
          }
        }
      }
    }
    return row;
  };
}

Result<Digest256> canonical_plug_descriptor_digest_v1(
    const PlugDescriptor& descriptor) {
  C16Encoder encoder;
  encoder.u32(descriptor.schema_version);
  encoder.digest(descriptor.core.core_digest);
  encoder.count(descriptor.state_fields.size());
  for (const RuntimeStateFieldV1& field : descriptor.state_fields) {
    encoder.id(field.id);
    encoder.enumeration(field.c14_field.kind);
    encoder.enumeration(field.c14_field.ownership);
    encoder.codec(field.c14_field.codec);
    encoder.enumeration(field.domain);
  }
  encoder.boolean(descriptor.c_minus.has_value());
  if (descriptor.c_minus.has_value()) {
    encoder.id(descriptor.c_minus->operation_id);
    encoder.u32(descriptor.c_minus->schema_version);
    encoder.codec(descriptor.c_minus->predecision_state_codec);
    encoder.codec(descriptor.c_minus->opportunity_codec);
    encoder.count(descriptor.c_minus->read_fields.size());
    for (const RuntimeFieldIdV1& id : descriptor.c_minus->read_fields) {
      encoder.id(id);
    }
    encoder.count(descriptor.c_minus->jointly_emitted_marks.size());
    for (const RuntimeMarkIdV1& id :
         descriptor.c_minus->jointly_emitted_marks) {
      encoder.id(id);
    }
  }
  encoder.boolean(descriptor.c_plus.has_value());
  if (descriptor.c_plus.has_value()) {
    encoder.id(descriptor.c_plus->operation_id);
    encoder.u32(descriptor.c_plus->schema_version);
    encoder.codec(descriptor.c_plus->prearrival_state_codec);
    encoder.codec(descriptor.c_plus->opportunity_codec);
    encoder.codec(descriptor.c_plus->decision_codec);
    encoder.codec(descriptor.c_plus->configured_arrival_codec);
    encoder.codec(descriptor.c_plus->patch_codec);
    encoder.count(descriptor.c_plus->writable_unresolved_fields.size());
    for (const RuntimeFieldIdV1& id :
         descriptor.c_plus->writable_unresolved_fields) {
      encoder.id(id);
    }
    encoder.count(descriptor.c_plus->read_marks.size());
    for (const RuntimeMarkIdV1& id : descriptor.c_plus->read_marks) {
      encoder.id(id);
    }
    encoder.count(descriptor.c_plus->jointly_emitted_marks.size());
    for (const RuntimeMarkIdV1& id :
         descriptor.c_plus->jointly_emitted_marks) {
      encoder.id(id);
    }
  }
  encoder.count(descriptor.marks.size());
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    encoder.id(mark.id);
    encoder.enumeration(mark.c14_mark.kind);
    encoder.enumeration(mark.c14_mark.reveal_stage);
    encoder.codec(mark.c14_mark.codec);
    encoder.count(mark.c14_mark.common_realization_group.size());
    for (char character : mark.c14_mark.common_realization_group) {
      encoder.byte(static_cast<std::uint8_t>(
          static_cast<unsigned char>(character)));
    }
    encoder.id(mark.decoder_id);
    encoder.enumeration(mark.decoder_source);
    encoder.enumeration(mark.domain);
    encoder.codec(mark.decoder_input_codec);
    encoder.count(mark.field_dependencies.size());
    for (const RuntimeFieldIdV1& field : mark.field_dependencies) {
      encoder.id(field);
    }
    encoder.count(mark.dependencies.size());
    for (const RuntimeMarkDependencyV1& dependency : mark.dependencies) {
      encoder.id(dependency.mark);
    }
  }
  encoder.boolean(descriptor.event_contract.has_value());
  if (descriptor.event_contract.has_value()) {
    const TemporalEventContractV1& event = *descriptor.event_contract;
    encoder.enumeration(event.kind);
    const std::array<const RuntimeOperationIdentityV1*, 6U> operations{
        &event.event_generator_operation,
        &event.entry_initializer_operation,
        &event.stopping_indicator_operation,
        &event.terminal_reentry_operation,
        &event.predecision_projection_operation,
        &event.completed_edge_projection_operation};
    for (const RuntimeOperationIdentityV1* operation : operations) {
      encoder.id(operation->operation_id);
      encoder.u32(operation->operation_version);
    }
    encoder.enumeration(event.stopping_filtration);
    encoder.codec(event.continuation_space);
    encoder.codec(event.entrance_space);
    encoder.codec(event.terminal_space);
    encoder.codec(event.reentry_space);
    encoder.codec(event.stopping_indicator);
    encoder.codec(event.predecision_projection);
    encoder.codec(event.completed_edge_projection);
    encoder.boolean(event.stopping_rule_adapted);
    encoder.boolean(event.first_stop_strictly_positive);
    encoder.boolean(event.terminal_reentry_exact);
    encoder.boolean(event.defective_hitting_law);
    encoder.count(event.stopping_false_value.size());
    for (const std::byte value : event.stopping_false_value) {
      encoder.byte(std::to_integer<std::uint8_t>(value));
    }
    encoder.count(event.stopping_true_value.size());
    for (const std::byte value : event.stopping_true_value) {
      encoder.byte(std::to_integer<std::uint8_t>(value));
    }
    encoder.count(event.residence_local_reset_fields.size());
    for (const RuntimeFieldIdV1& field :
         event.residence_local_reset_fields) {
      encoder.id(field);
    }
  }
  encoder.enumeration(descriptor.configured_arrival_ownership);
  encoder.count(descriptor.certificates.size());
  for (const RuntimeCertificateClaimV1& certificate :
       descriptor.certificates) {
    encoder.enumeration(certificate.category);
    encoder.enumeration(certificate.level);
    encoder.boolean(certificate.witness_schema.has_value());
    if (certificate.witness_schema.has_value()) {
      encoder.codec(*certificate.witness_schema);
    }
  }
  encoder.boolean(descriptor.transition_state_schema.has_value());
  if (descriptor.transition_state_schema.has_value()) {
    const TransitionStateSchemaV1& transition =
        *descriptor.transition_state_schema;
    encoder.codec(transition.conditioning_state_codec);
    encoder.codec(transition.successor_state_codec);
    encoder.count(transition.ordered_fields.size());
    for (const RuntimeFieldIdV1& field : transition.ordered_fields) {
      encoder.id(field);
    }
  }
  return sha256_domain_separated("mwperf.c16.plug-descriptor.v1",
                                 encoder.bytes());
}

Result<void> validate_plug_descriptor_v1(const PlugDescriptor& descriptor) {
  if (descriptor.schema_version != kC16RuntimeDescriptorSchemaV1) {
    return Result<void>::failure(boundary_error(
        "c16.unsupported_descriptor_version",
        "the runtime plug descriptor must use schema version 1",
        "/descriptor/schema_version"));
  }
  if (!detail::is_valid_plug_descriptor_core_shape_v1(descriptor.core)) {
    return Result<void>::failure(boundary_error(
        "c16.invalid_c14_descriptor_core",
        "the runtime descriptor does not contain a valid C14 core",
        "/descriptor/core"));
  }
  auto core_digest =
      canonical_plug_descriptor_core_digest_v1(descriptor.core);
  if (!core_digest || core_digest.value() != descriptor.core.core_digest) {
    return Result<void>::failure(boundary_error(
        "c16.descriptor_core_digest_mismatch",
        "the embedded C14 descriptor digest is not canonical",
        "/descriptor/core/core_digest"));
  }
  if (descriptor.state_fields.size() != descriptor.core.state_fields.size()) {
    return Result<void>::failure(boundary_error(
        "c16.state_field_projection_mismatch",
        "every C14 state field requires exactly one stable C16 field ID",
        "/descriptor/state_fields"));
  }

  std::unordered_map<std::string, const RuntimeStateFieldV1*> fields;
  for (std::size_t index = 0U; index < descriptor.state_fields.size();
       ++index) {
    const RuntimeStateFieldV1& field = descriptor.state_fields[index];
    if (field.c14_field != descriptor.core.state_fields[index] ||
        !valid_domain(field.domain)) {
      return Result<void>::failure(boundary_error(
          "c16.state_field_projection_mismatch",
          "C16 field metadata must preserve the corresponding C14 field",
          "/descriptor/state_fields"));
    }
    if (!ownership_matches_field_kind(field.c14_field.kind,
                                      field.c14_field.ownership)) {
      return Result<void>::failure(boundary_error(
          "c16.state_field_ownership_mismatch",
          "exact framework coordinates must be framework-owned and unresolved surrogate coordinates must be surrogate-owned",
          "/descriptor/state_fields"));
    }
    if (!fields.emplace(stable_key(field.id), &field).second) {
      return Result<void>::failure(boundary_error(
          "c16.duplicate_runtime_field_id",
          "runtime state-field IDs must be unique",
          "/descriptor/state_fields"));
    }
  }

  const bool requires_transition_schema =
      transition_access(descriptor.core.runtime_access);
  if (descriptor.transition_state_schema.has_value() !=
      requires_transition_schema) {
    return Result<void>::failure(boundary_error(
        "c16.transition_state_schema_presence_mismatch",
        "finite, sparse, and conditional-sampler access require exactly one aggregate transition-state schema, and other access kinds forbid it",
        "/descriptor/transition_state_schema"));
  }
  if (descriptor.transition_state_schema.has_value()) {
    const TransitionStateSchemaV1& transition =
        *descriptor.transition_state_schema;
    if (!valid_codec(transition.conditioning_state_codec) ||
        !valid_codec(transition.successor_state_codec) ||
        transition.ordered_fields.size() != descriptor.state_fields.size()) {
      return Result<void>::failure(boundary_error(
          "c16.invalid_transition_state_schema",
          "the aggregate transition schema requires complete conditioning/successor codecs and every state coordinate exactly once",
          "/descriptor/transition_state_schema"));
    }
    for (std::size_t index = 0U;
         index < descriptor.state_fields.size(); ++index) {
      if (transition.ordered_fields[index] !=
          descriptor.state_fields[index].id) {
        return Result<void>::failure(boundary_error(
            "c16.transition_state_field_order_mismatch",
            "the aggregate transition schema must preserve the exact unique descriptor state-field order",
            "/descriptor/transition_state_schema/ordered_fields"));
      }
    }
  }

  std::unordered_map<std::string, std::size_t> marks;
  std::unordered_map<std::string, bool> realization_domains;
  if (descriptor.marks.size() != descriptor.core.marks.size()) {
    return Result<void>::failure(boundary_error(
        "c16.mark_projection_mismatch",
        "every C14 mark requires exactly one stable C16 mark ID",
        "/descriptor/marks"));
  }
  for (std::size_t index = 0U; index < descriptor.marks.size(); ++index) {
    const RuntimeMarkDescriptorV1& mark = descriptor.marks[index];
    if (mark.c14_mark != descriptor.core.marks[index] ||
        !valid_mark_source(mark.decoder_source) || !valid_domain(mark.domain) ||
        !valid_codec(mark.decoder_input_codec)) {
      return Result<void>::failure(boundary_error(
          "c16.mark_projection_mismatch",
          "C16 mark metadata must preserve the C14 mark and declare a stable decoder domain",
          "/descriptor/marks"));
    }
    if (!marks.emplace(stable_key(mark.id), index).second) {
      return Result<void>::failure(boundary_error(
          "c16.duplicate_runtime_mark_id",
          "runtime mark IDs must be unique", "/descriptor/marks"));
    }
    if (!exact_mark_source_for_kind(mark)) {
      return Result<void>::failure(boundary_error(
          "c16.mark_decoder_source_mismatch",
          "each framework mark kind must be owned by its exact causal decoder",
          "/descriptor/marks/decoder_source"));
    }
    if (mark.c14_mark.reveal_stage == MetricRevealStageV1::entrance_label) {
      if (mark.decoder_source != MarkDecoderSourceV1::entrance_realization) {
        return Result<void>::failure(boundary_error(
            "c16.late_or_fabricated_palm_label",
            "an entrance label must be decoded from the entrance realization",
            "/descriptor/marks"));
      }
    } else {
      const auto reveal = within_slot_stage(mark.c14_mark.reveal_stage);
      const auto source = source_stage(mark.decoder_source);
      if (!reveal.has_value() || !source.has_value() || *source > *reveal) {
        return Result<void>::failure(boundary_error(
            "c16.future_to_past_mark_decoder",
            "a mark decoder cannot use a source revealed after its declared availability",
            "/descriptor/marks"));
      }
    }
    if (!mark.c14_mark.common_realization_group.empty()) {
      const bool entrance =
          mark.decoder_source == MarkDecoderSourceV1::entrance_realization;
      auto [group, inserted] = realization_domains.emplace(
          mark.c14_mark.common_realization_group, entrance);
      if (!inserted && group->second != entrance) {
        return Result<void>::failure(boundary_error(
            "c16.common_realization_domain_mismatch",
            "one common-realization group cannot mix an entrance realization with an ordinary generated slot",
            "/descriptor/marks/common_realization_group"));
      }
    }
  }

  const auto require_field = [&](const RuntimeFieldIdV1& id) {
    return fields.contains(stable_key(id));
  };
  if (descriptor.c_minus.has_value()) {
    if (descriptor.c_minus->schema_version !=
            kC16RuntimeDescriptorSchemaV1 ||
        !valid_codec(descriptor.c_minus->predecision_state_codec) ||
        !valid_codec(descriptor.c_minus->opportunity_codec) ||
        !strictly_ordered_unique(
            descriptor.c_minus->read_fields,
            [](const RuntimeFieldIdV1& id) { return stable_key(id); }) ||
        !strictly_ordered_unique(
            descriptor.c_minus->jointly_emitted_marks,
            [](const RuntimeMarkIdV1& id) { return stable_key(id); })) {
      return Result<void>::failure(boundary_error(
          "c16.invalid_c_minus_schema",
          "C-minus requires typed state/opportunity codecs and canonical field/mark sets",
          "/descriptor/c_minus"));
    }
    std::unordered_set<std::string> reads;
    for (const RuntimeFieldIdV1& id : descriptor.c_minus->read_fields) {
      if (!require_field(id) || !reads.insert(stable_key(id)).second) {
        return Result<void>::failure(boundary_error(
            "c16.invalid_c_minus_field",
            "C-minus read fields must be declared and duplicate-free",
            "/descriptor/c_minus/read_fields"));
      }
    }
    std::unordered_set<std::string> emitted;
    for (const RuntimeMarkIdV1& id :
         descriptor.c_minus->jointly_emitted_marks) {
      const auto found = marks.find(stable_key(id));
      if (found == marks.end() || !emitted.insert(stable_key(id)).second ||
          descriptor.marks[found->second].decoder_source !=
              MarkDecoderSourceV1::c_minus_joint_output) {
        return Result<void>::failure(boundary_error(
            "c16.invalid_c_minus_mark",
            "C-minus emitted marks must be declared and duplicate-free",
            "/descriptor/c_minus/jointly_emitted_marks"));
      }
    }
  }
  if (descriptor.c_plus.has_value()) {
    if (descriptor.c_plus->schema_version !=
            kC16RuntimeDescriptorSchemaV1 ||
        !valid_codec(descriptor.c_plus->prearrival_state_codec) ||
        !valid_codec(descriptor.c_plus->opportunity_codec) ||
        !valid_codec(descriptor.c_plus->decision_codec) ||
        !valid_codec(descriptor.c_plus->configured_arrival_codec) ||
        !valid_codec(descriptor.c_plus->patch_codec) ||
        !strictly_ordered_unique(
            descriptor.c_plus->writable_unresolved_fields,
            [](const RuntimeFieldIdV1& id) { return stable_key(id); }) ||
        !strictly_ordered_unique(
            descriptor.c_plus->read_marks,
            [](const RuntimeMarkIdV1& id) { return stable_key(id); }) ||
        !strictly_ordered_unique(
            descriptor.c_plus->jointly_emitted_marks,
            [](const RuntimeMarkIdV1& id) { return stable_key(id); })) {
      return Result<void>::failure(boundary_error(
          "c16.invalid_c_plus_schema",
          "C-plus requires typed input/patch codecs and canonical field/mark sets",
          "/descriptor/c_plus"));
    }
    std::unordered_set<std::string> writes;
    for (const RuntimeFieldIdV1& id :
         descriptor.c_plus->writable_unresolved_fields) {
      const auto found = fields.find(stable_key(id));
      if (found == fields.end() || !writes.insert(stable_key(id)).second ||
          found->second->c14_field.ownership !=
              FieldOwnershipV1::surrogate_owned ||
          (found->second->c14_field.kind != StateFieldKindV1::surrogate_phase &&
           found->second->c14_field.kind != StateFieldKindV1::event_state &&
           found->second->c14_field.kind !=
               StateFieldKindV1::entrance_label_state)) {
        return Result<void>::failure(boundary_error(
            "c16.c_plus_exact_coordinate_write",
            "C-plus may write only declared unresolved surrogate fields",
            "/descriptor/c_plus/writable_unresolved_fields"));
      }
    }
    std::unordered_set<std::string> read_marks;
    for (const RuntimeMarkIdV1& id : descriptor.c_plus->read_marks) {
      const auto found = marks.find(stable_key(id));
      if (found == marks.end() ||
          !read_marks.insert(stable_key(id)).second ||
          descriptor.marks[found->second].decoder_source ==
              MarkDecoderSourceV1::c_plus_joint_output ||
          descriptor.marks[found->second].decoder_source ==
              MarkDecoderSourceV1::postarrival_state ||
          descriptor.marks[found->second].decoder_source ==
              MarkDecoderSourceV1::completed_edge) {
        return Result<void>::failure(boundary_error(
            "c16.invalid_c_plus_mark",
            "C-plus may read only canonical marks available no later than the configured arrival draw",
            "/descriptor/c_plus/read_marks"));
      }
    }
    std::unordered_set<std::string> emitted;
    for (const RuntimeMarkIdV1& id :
         descriptor.c_plus->jointly_emitted_marks) {
      const auto found = marks.find(stable_key(id));
      if (found == marks.end() || !emitted.insert(stable_key(id)).second ||
          descriptor.marks[found->second].decoder_source !=
              MarkDecoderSourceV1::c_plus_joint_output) {
        return Result<void>::failure(boundary_error(
            "c16.invalid_c_plus_emitted_mark",
            "C-plus emitted marks must be declared as C-plus joint outputs",
            "/descriptor/c_plus/jointly_emitted_marks"));
      }
    }
  }

  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    const bool c_minus_owned =
        mark.decoder_source == MarkDecoderSourceV1::c_minus_joint_output;
    const bool c_plus_owned =
        mark.decoder_source == MarkDecoderSourceV1::c_plus_joint_output;
    if ((c_minus_owned &&
         (!descriptor.c_minus.has_value() ||
          !std::binary_search(
              descriptor.c_minus->jointly_emitted_marks.begin(),
              descriptor.c_minus->jointly_emitted_marks.end(), mark.id,
              [](const RuntimeMarkIdV1& left,
                 const RuntimeMarkIdV1& right) {
                return stable_key(left) < stable_key(right);
              }))) ||
        (c_plus_owned &&
         (!descriptor.c_plus.has_value() ||
          !std::binary_search(
              descriptor.c_plus->jointly_emitted_marks.begin(),
              descriptor.c_plus->jointly_emitted_marks.end(), mark.id,
              [](const RuntimeMarkIdV1& left,
                 const RuntimeMarkIdV1& right) {
                return stable_key(left) < stable_key(right);
              })))) {
      return Result<void>::failure(boundary_error(
          "c16.unowned_joint_mark",
          "each surrogate-random mark must be emitted by the exact declared causal operation",
          "/descriptor/marks"));
    }
  }

  std::vector<std::vector<std::size_t>> dependency_graph(
      descriptor.marks.size());
  for (std::size_t index = 0U; index < descriptor.marks.size(); ++index) {
    if (!strictly_ordered_unique(
            descriptor.marks[index].field_dependencies,
            [](const RuntimeFieldIdV1& id) { return stable_key(id); }) ||
        !strictly_ordered_unique(
            descriptor.marks[index].dependencies,
            [](const RuntimeMarkDependencyV1& dependency) {
              return stable_key(dependency.mark);
            })) {
      return Result<void>::failure(boundary_error(
          "c16.noncanonical_mark_dependencies",
          "mark field and mark dependency sets must be strictly ordered and duplicate-free",
          "/descriptor/marks/dependencies"));
    }
    for (const RuntimeFieldIdV1& dependency :
         descriptor.marks[index].field_dependencies) {
      if (!require_field(dependency)) {
        return Result<void>::failure(boundary_error(
            "c16.missing_mark_field_dependency",
            "every mark field dependency must name a declared state field",
            "/descriptor/marks/field_dependencies"));
      }
    }
    const auto target_stage =
        within_slot_stage(descriptor.marks[index].c14_mark.reveal_stage);
    for (const RuntimeMarkDependencyV1& dependency :
         descriptor.marks[index].dependencies) {
      const auto found = marks.find(stable_key(dependency.mark));
      if (found == marks.end()) {
        return Result<void>::failure(boundary_error(
            "c16.missing_mark_dependency",
            "every mark dependency must name a declared mark",
            "/descriptor/marks/dependencies"));
      }
      const auto dependency_stage = within_slot_stage(
          descriptor.marks[found->second].c14_mark.reveal_stage);
      // Entrance labels precede every within-slot stage.  An entrance label
      // may therefore feed any later decoder, while the converse would read
      // an unrevealed slot value at the Palm/event boundary.
      if ((!target_stage.has_value() && dependency_stage.has_value()) ||
          (target_stage.has_value() && dependency_stage.has_value() &&
           *dependency_stage > *target_stage)) {
        return Result<void>::failure(boundary_error(
            "c16.future_to_past_mark_dependency",
            "mark dependencies cannot flow from a later causal stage",
            "/descriptor/marks/dependencies"));
      }
      dependency_graph[index].push_back(found->second);
    }
  }
  std::vector<std::uint8_t> visit(descriptor.marks.size(), 0U);
  std::function<bool(std::size_t)> cyclic = [&](std::size_t node) {
    if (visit[node] == 1U) return true;
    if (visit[node] == 2U) return false;
    visit[node] = 1U;
    for (std::size_t dependency : dependency_graph[node]) {
      if (cyclic(dependency)) return true;
    }
    visit[node] = 2U;
    return false;
  };
  for (std::size_t index = 0U; index < descriptor.marks.size(); ++index) {
    if (cyclic(index)) {
      return Result<void>::failure(boundary_error(
          "c16.cyclic_mark_dependency",
          "the mark-decoder dependency graph must be acyclic",
          "/descriptor/marks/dependencies"));
    }
  }

  if (temporal_semantic(descriptor.core.semantic) !=
      descriptor.event_contract.has_value()) {
    return Result<void>::failure(boundary_error(
        "c16.temporal_event_contract_mismatch",
        "temporal, residence, and stopped semantics require one complete event contract",
        "/descriptor/event_contract"));
  }
  if (descriptor.event_contract.has_value()) {
    const TemporalEventContractV1& event = *descriptor.event_contract;
    const EventContractKindV1 expected =
        descriptor.core.semantic ==
                SemanticTagV1::temporal_one_slot_continuation
            ? EventContractKindV1::one_slot_continuation
            : (descriptor.core.semantic ==
                       SemanticTagV1::romr_residence_word_law
                   ? EventContractKindV1::romr_residence
                   : EventContractKindV1::stopped_path);
    const std::array<const CodecIdentityV1*, 7U> codecs{
        &event.continuation_space, &event.entrance_space,
        &event.terminal_space, &event.reentry_space,
        &event.stopping_indicator, &event.predecision_projection,
        &event.completed_edge_projection};
    const std::array<const RuntimeOperationIdentityV1*, 6U> operations{
        &event.event_generator_operation,
        &event.entry_initializer_operation,
        &event.stopping_indicator_operation,
        &event.terminal_reentry_operation,
        &event.predecision_projection_operation,
        &event.completed_edge_projection_operation};
    std::unordered_set<std::string> operation_ids;
    const bool operations_valid =
        std::all_of(operations.begin(), operations.end(),
                    [&](const RuntimeOperationIdentityV1* operation) {
                      return valid_operation_identity(*operation) &&
                             operation_ids
                                 .insert(stable_key(operation->operation_id))
                                 .second;
                    });
    const bool reset_fields_valid =
        strictly_ordered_unique(
            event.residence_local_reset_fields,
            [](const RuntimeFieldIdV1& id) { return stable_key(id); }) &&
        std::ranges::all_of(
            event.residence_local_reset_fields,
            [&](const RuntimeFieldIdV1& id) {
              const auto found = fields.find(stable_key(id));
              return found != fields.end() &&
                     found->second->c14_field.ownership ==
                         FieldOwnershipV1::surrogate_owned;
            });
    if (!event_kind_valid(event.kind) || event.kind != expected ||
        !event_filtration_valid(event.stopping_filtration) ||
        !operations_valid ||
        !std::all_of(codecs.begin(), codecs.end(),
                     [](const CodecIdentityV1* codec) {
                       return valid_codec(*codec);
                     }) ||
        !event.stopping_rule_adapted ||
        !event.first_stop_strictly_positive ||
        !event.terminal_reentry_exact ||
        event.stopping_false_value.empty() ||
        event.stopping_true_value.empty() ||
        event.stopping_false_value == event.stopping_true_value ||
        !reset_fields_valid ||
        event.entrance_space != event.reentry_space ||
        (event.kind != EventContractKindV1::stopped_path &&
         event.defective_hitting_law)) {
      return Result<void>::failure(boundary_error(
          "c16.incomplete_temporal_event_contract",
          "event semantics require six distinct version-1 operations, matched entry/reentry spaces, adapted positive stopping, and both slot projections",
          "/descriptor/event_contract"));
    }
  }

  // Bind every mark decoder to the exact carrier schema when that source has
  // a typed aggregate carrier.  Descriptor-only deterministic projections
  // remain valid where C16 has no separate aggregate codec authority.
  for (const RuntimeMarkDescriptorV1& mark : descriptor.marks) {
    const CodecIdentityV1* expected_input = nullptr;
    switch (mark.decoder_source) {
      case MarkDecoderSourceV1::predecision_state:
        if (descriptor.c_minus.has_value()) {
          expected_input = &descriptor.c_minus->predecision_state_codec;
        }
        break;
      case MarkDecoderSourceV1::c_minus_joint_output:
        if (descriptor.c_minus.has_value()) {
          expected_input = &descriptor.c_minus->opportunity_codec;
        }
        break;
      case MarkDecoderSourceV1::decision_schedule:
        if (descriptor.c_plus.has_value()) {
          expected_input = &descriptor.c_plus->decision_codec;
        }
        break;
      case MarkDecoderSourceV1::configured_arrival:
        if (descriptor.c_plus.has_value()) {
          expected_input = &descriptor.c_plus->configured_arrival_codec;
        }
        break;
      case MarkDecoderSourceV1::c_plus_joint_output:
        if (descriptor.c_plus.has_value()) {
          expected_input = &descriptor.c_plus->patch_codec;
        }
        break;
      case MarkDecoderSourceV1::completed_edge:
        if (descriptor.event_contract.has_value()) {
          expected_input =
              &descriptor.event_contract->completed_edge_projection;
        }
        break;
      case MarkDecoderSourceV1::entrance_realization:
        if (descriptor.event_contract.has_value()) {
          expected_input = &descriptor.event_contract->entrance_space;
        }
        break;
      case MarkDecoderSourceV1::postarrival_state:
        break;
    }
    if (expected_input != nullptr && mark.decoder_input_codec != *expected_input) {
      return Result<void>::failure(boundary_error(
          "c16.mark_decoder_input_codec_mismatch",
          "a mark decoder's input codec must equal its exact causal carrier schema",
          "/descriptor/marks/decoder_input_codec"));
    }
  }

  if (descriptor.core.semantic ==
          SemanticTagV1::coupled_target_schedule_law &&
      descriptor.core.target_coupling == TargetCouplingV1::scalar_target) {
    return Result<void>::failure(boundary_error(
        "c16.coupled_schedule_declared_scalar",
        "a coupled schedule law must retain one common schedule projection",
        "/descriptor/core/target_coupling"));
  }
  const bool has_schedule_projection = std::any_of(
      descriptor.marks.begin(), descriptor.marks.end(),
      [](const RuntimeMarkDescriptorV1& mark) {
        return mark.c14_mark.kind == MetricMarkKindV1::schedule_projection;
      });
  const bool has_full_schedule = std::any_of(
      descriptor.marks.begin(), descriptor.marks.end(),
      [](const RuntimeMarkDescriptorV1& mark) {
        return mark.c14_mark.kind == MetricMarkKindV1::full_schedule;
      });
  if (descriptor.core.semantic ==
          SemanticTagV1::coupled_target_schedule_law &&
      !has_schedule_projection && !has_full_schedule) {
    return Result<void>::failure(boundary_error(
        "c16.coupled_schedule_mark_missing",
        "a coupled schedule law must retain one common feasible schedule identity or projection",
        "/descriptor/marks"));
  }
  if (descriptor.core.target_coupling ==
          TargetCouplingV1::full_schedule_identity &&
      !has_full_schedule) {
    return Result<void>::failure(boundary_error(
        "c16.full_schedule_identity_mark_missing",
        "full-schedule target coupling requires an actual full-schedule identity mark",
        "/descriptor/marks"));
  }
  if (descriptor.core.deployed_targets.size() > 1U &&
      descriptor.core.target_coupling == TargetCouplingV1::scalar_target) {
    return Result<void>::failure(boundary_error(
        "c16.multitarget_scalar_coupling",
        "multiple deployed targets require a common feasible schedule coupling",
        "/descriptor/core/target_coupling"));
  }
  if (descriptor.configured_arrival_ownership !=
      ConfiguredArrivalOwnershipV1::framework_external_exactly_once) {
    return Result<void>::failure(boundary_error(
        "c16.invalid_configured_arrival_ownership",
        "the configured arrival kernel remains framework-owned and external",
        "/descriptor/configured_arrival_ownership"));
  }

  if (!strictly_ordered_unique(
          descriptor.certificates,
          [](const RuntimeCertificateClaimV1& certificate) {
            return static_cast<std::uint8_t>(certificate.category);
          })) {
    return Result<void>::failure(boundary_error(
        "c16.noncanonical_certificate_order",
        "independent certificate categories must be canonical and unique",
        "/descriptor/certificates"));
  }
  const auto c14_evidence = [&](OptionalReportedEvidenceKindV1 kind)
      -> const OptionalReportedEvidenceV1* {
    const auto found = std::find_if(
        descriptor.core.optional_reported_evidence.begin(),
        descriptor.core.optional_reported_evidence.end(),
        [kind](const OptionalReportedEvidenceV1& value) {
          return value.kind == kind;
        });
    return found == descriptor.core.optional_reported_evidence.end()
               ? nullptr
               : &*found;
  };
  if (c14_evidence(OptionalReportedEvidenceKindV1::v2_dynamic_lift) !=
          nullptr &&
      c14_evidence(OptionalReportedEvidenceKindV1::v1_fibre_realizability) ==
          nullptr) {
    return Result<void>::failure(boundary_error(
        "c16.v2_without_explicit_v1",
        "a dynamic V2 lift must retain, not infer, its separate V1 fibre-realizability witness",
        "/descriptor/core/optional_reported_evidence"));
  }
  bool has_v0 = false;
  std::unordered_set<std::uint8_t> certificate_categories;
  for (const RuntimeCertificateClaimV1& certificate :
       descriptor.certificates) {
    const auto category = static_cast<std::uint8_t>(certificate.category);
    if (category >
            static_cast<std::uint8_t>(CertificateCategoryV1::provenance) ||
        !certificate_categories.insert(category).second ||
        !certificate_level_valid(certificate.level) ||
        (certificate.witness_schema.has_value() &&
         !valid_codec(*certificate.witness_schema))) {
      return Result<void>::failure(boundary_error(
          "c16.invalid_independent_certificate_shape",
          "certificate categories must be unique and V1/V2 claims require their own witness schema",
          "/descriptor/certificates"));
    }
    const OptionalReportedEvidenceV1* evidence = nullptr;
    CertificateCategoryV1 required_category = certificate.category;
    switch (certificate.level) {
      case CertificateLevelV1::v0_shape: {
        has_v0 = true;
        const CodecIdentityV1 expected{
            descriptor.core.mandatory_v0.factor_schema_id,
            descriptor.core.mandatory_v0.factor_schema_version};
        if (descriptor.core.mandatory_v0.kind !=
                V0DeclarationKindV1::structural_witness_required ||
            certificate.category != CertificateCategoryV1::validity ||
            !certificate.witness_schema.has_value() ||
            *certificate.witness_schema != expected) {
          return Result<void>::failure(boundary_error(
              "c16.v0_certificate_core_mismatch",
              "a V0 runtime claim must exactly project the C14 mandatory factor schema",
              "/descriptor/certificates"));
        }
        break;
      }
      case CertificateLevelV1::v1_witness:
        evidence = c14_evidence(
            OptionalReportedEvidenceKindV1::v1_fibre_realizability);
        required_category = CertificateCategoryV1::geometry;
        break;
      case CertificateLevelV1::v2_witness:
        evidence = c14_evidence(
            OptionalReportedEvidenceKindV1::v2_dynamic_lift);
        required_category = CertificateCategoryV1::lift;
        break;
      case CertificateLevelV1::declaration:
        if (certificate.witness_schema.has_value()) {
          if (certificate.category == CertificateCategoryV1::fidelity) {
            evidence = c14_evidence(
                OptionalReportedEvidenceKindV1::physical_fidelity);
          } else if (certificate.category ==
                     CertificateCategoryV1::validation) {
            evidence = c14_evidence(
                OptionalReportedEvidenceKindV1::empirical_validation);
          } else {
            return Result<void>::failure(boundary_error(
                "c16.unbound_certificate_witness",
                "a declaration witness must project physical-fidelity or empirical-validation evidence from C14",
                "/descriptor/certificates"));
          }
        }
        break;
    }
    if (certificate.level == CertificateLevelV1::v1_witness ||
        certificate.level == CertificateLevelV1::v2_witness) {
      if (!certificate.witness_schema.has_value() || evidence == nullptr ||
          certificate.category != required_category) {
        return Result<void>::failure(boundary_error(
            "c16.certificate_core_evidence_mismatch",
            "V1 and V2 claims require the corresponding C14 witness declaration and category",
            "/descriptor/certificates"));
      }
    }
    if (evidence != nullptr) {
      const CodecIdentityV1 expected{evidence->witness_schema_id,
                                     evidence->witness_schema_version};
      if (!certificate.witness_schema.has_value() ||
          *certificate.witness_schema != expected) {
        return Result<void>::failure(boundary_error(
            "c16.certificate_witness_schema_mismatch",
            "a runtime certificate witness must exactly match its C14 evidence schema",
            "/descriptor/certificates"));
      }
    }
  }
  const bool runtime_v1 = std::any_of(
      descriptor.certificates.begin(), descriptor.certificates.end(),
      [](const RuntimeCertificateClaimV1& certificate) {
        return certificate.level == CertificateLevelV1::v1_witness;
      });
  const bool runtime_v2 = std::any_of(
      descriptor.certificates.begin(), descriptor.certificates.end(),
      [](const RuntimeCertificateClaimV1& certificate) {
        return certificate.level == CertificateLevelV1::v2_witness;
      });
  if (runtime_v2 && !runtime_v1) {
    return Result<void>::failure(boundary_error(
        "c16.v2_without_explicit_v1",
        "a runtime V2 lift must retain its independent V1 geometry claim",
        "/descriptor/certificates"));
  }
  if (descriptor.core.mandatory_v0.kind ==
          V0DeclarationKindV1::structural_witness_required &&
      !has_v0) {
    return Result<void>::failure(boundary_error(
        "c16.missing_v0_certificate_projection",
        "a mandatory C14 V0 factor requires an explicit matching runtime validity claim",
        "/descriptor/certificates"));
  }
  for (const OptionalReportedEvidenceV1& evidence :
       descriptor.core.optional_reported_evidence) {
    CertificateCategoryV1 category;
    CertificateLevelV1 level;
    switch (evidence.kind) {
      case OptionalReportedEvidenceKindV1::v1_fibre_realizability:
        category = CertificateCategoryV1::geometry;
        level = CertificateLevelV1::v1_witness;
        break;
      case OptionalReportedEvidenceKindV1::v2_dynamic_lift:
        category = CertificateCategoryV1::lift;
        level = CertificateLevelV1::v2_witness;
        break;
      case OptionalReportedEvidenceKindV1::physical_fidelity:
        category = CertificateCategoryV1::fidelity;
        level = CertificateLevelV1::declaration;
        break;
      case OptionalReportedEvidenceKindV1::empirical_validation:
        category = CertificateCategoryV1::validation;
        level = CertificateLevelV1::declaration;
        break;
    }
    const CodecIdentityV1 expected{evidence.witness_schema_id,
                                   evidence.witness_schema_version};
    const bool projected = std::any_of(
        descriptor.certificates.begin(), descriptor.certificates.end(),
        [&](const RuntimeCertificateClaimV1& certificate) {
          return certificate.category == category &&
                 certificate.level == level &&
                 certificate.witness_schema ==
                     std::optional<CodecIdentityV1>{expected};
        });
    if (!projected) {
      return Result<void>::failure(boundary_error(
          "c16.missing_runtime_certificate_projection",
          "every C14 optional evidence declaration must retain its independent runtime certificate field",
          "/descriptor/certificates"));
    }
  }
  auto digest = canonical_plug_descriptor_digest_v1(descriptor);
  if (!digest || digest.value() != descriptor.descriptor_digest) {
    return Result<void>::failure(boundary_error(
        "c16.runtime_descriptor_digest_mismatch",
        "the runtime descriptor digest does not bind its complete truth shape",
        "/descriptor/descriptor_digest"));
  }
  return Result<void>::success();
}

SemanticTagV1 semantic_tag_v1(const SurrogatePlug& plug) noexcept {
  return std::visit(
      [](const auto& alternative) noexcept {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::is_same_v<Alternative,
                                     ScalarBacklogResponsePlugV1>) {
          return SemanticTagV1::scalar_backlog_response;
        } else if constexpr (std::is_same_v<
                                 Alternative, StationaryMarkedEdgePlugV1>) {
          return SemanticTagV1::stationary_marked_edge;
        } else if constexpr (std::is_same_v<
                                 Alternative, StagedOpportunityFluxPlugV1>) {
          return SemanticTagV1::staged_opportunity_flux_law;
        } else if constexpr (std::is_same_v<
                                 Alternative,
                                 TemporalOneSlotContinuationPlugV1>) {
          return SemanticTagV1::temporal_one_slot_continuation;
        } else if constexpr (std::is_same_v<Alternative,
                                            RomrResidenceWordPlugV1>) {
          return SemanticTagV1::romr_residence_word_law;
        } else if constexpr (std::is_same_v<Alternative,
                                            StoppedPathPlugV1>) {
          return SemanticTagV1::stopped_path_law;
        } else if constexpr (std::is_same_v<
                                 Alternative, CoupledTargetSchedulePlugV1>) {
          return SemanticTagV1::coupled_target_schedule_law;
        } else if constexpr (std::is_same_v<Alternative,
                                            DirectMetricDecoderPlugV1>) {
          return SemanticTagV1::direct_metric_decoder;
        } else {
          static_assert(std::is_same_v<Alternative, ResponseEnvelopePlugV1>);
          return SemanticTagV1::response_envelope_law;
        }
      },
      plug);
}

const KernelAccess& kernel_access_v1(const SurrogatePlug& plug) noexcept {
  return std::visit(
      [](const auto& alternative) -> const KernelAccess& {
        return alternative.access;
      },
      plug);
}

const PortablePlugPayload& portable_source_v1(
    const SurrogatePlug& plug) noexcept {
  return std::visit(
      [](const auto& alternative) -> const PortablePlugPayload& {
        return alternative.source;
      },
      plug);
}

const CausalSurrogateOperationsV1* causal_operations_v1(
    const SurrogatePlug& plug) noexcept {
  return std::visit(
      [](const auto& alternative) noexcept
          -> const CausalSurrogateOperationsV1* {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::is_same_v<Alternative,
                                     StationaryMarkedEdgePlugV1> ||
                      std::is_same_v<Alternative,
                                     StagedOpportunityFluxPlugV1> ||
                      std::is_same_v<
                          Alternative,
                          TemporalOneSlotContinuationPlugV1> ||
                      std::is_same_v<Alternative,
                                     RomrResidenceWordPlugV1> ||
                      std::is_same_v<Alternative, StoppedPathPlugV1> ||
                      std::is_same_v<Alternative,
                                     CoupledTargetSchedulePlugV1>) {
          return &alternative.operations;
        } else {
          return nullptr;
        }
      },
      plug);
}

}  // namespace mwperf
namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> fail(std::string code, std::string message,
                             const DiagnosticCategory category =
                                 DiagnosticCategory::input_validation) {
  return Result<T>::failure(Diagnostic{category, std::move(code),
                                       std::move(message), std::nullopt,
                                       std::nullopt, {}});
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::ranges::any_of(digest.bytes(), [](const std::byte value) {
    return value != std::byte{0};
  });
}

// Keep the helper name translation-unit-unique: the C16 release catalog owns
// one surrogate_boundary.cpp, so this implementation is deliberately safe to
// fold into that file without colliding with its descriptor-side codec check.
[[nodiscard]] bool valid_seam_codec(const CodecIdentityV1& codec) noexcept {
  return !codec.id.empty() && codec.version != 0U;
}

[[nodiscard]] bool complete_binding_shape(
    const AuditedFrameworkBindingsV1& binding) noexcept {
  return nonzero_digest(binding.problem_fingerprints.authored_inputs.model) &&
         nonzero_digest(binding.problem_fingerprints.authored_inputs.analysis) &&
         nonzero_digest(binding.problem_fingerprints.authored_inputs.combined) &&
         nonzero_digest(binding.problem_fingerprints.resolved_instance) &&
         nonzero_digest(binding.problem_fingerprints.constraint) &&
         nonzero_digest(binding.problem_fingerprints.target_selection) &&
         nonzero_digest(binding.problem_fingerprints.tie_and_timing) &&
         nonzero_digest(binding.problem_fingerprints.compiled_arrival) &&
         nonzero_digest(binding.problem_view_digest.value()) &&
         nonzero_digest(binding.exact_state_schema_digest) &&
         nonzero_digest(binding.reduced_state_schema_digest) &&
         nonzero_digest(binding.descriptor_digest) &&
         nonzero_digest(binding.access_digest) &&
         nonzero_digest(binding.accepted_contract_digest) &&
         nonzero_digest(binding.normalized_metric_requirements_digest) &&
         nonzero_digest(binding.ordered_target_digest) &&
         nonzero_digest(binding.selection_digest) &&
         nonzero_digest(binding.build_request_digest);
}

[[nodiscard]] Result<void> verify_instance_binding(
    const ResolvedInstance& instance,
    const AuditedFrameworkBindingsV1& bindings,
    const TargetSelection& target_selection,
    const CodecIdentityV1& reduced_state_codec,
    const bool has_seal) {
  if (!has_seal || !complete_binding_shape(bindings)) {
    return fail<void>(
        "c16.invalid_audited_framework_seal",
        "the audited framework carrier is moved-from or has incomplete "
        "immutable bindings",
        DiagnosticCategory::internal);
  }
  if (!valid_seam_codec(reduced_state_codec)) {
    return fail<void>(
        "c16.invalid_reduced_state_codec",
        "the audited framework has no complete reduced-state codec",
        DiagnosticCategory::internal);
  }

  if (instance.fingerprints() !=
      bindings.problem_fingerprints.authored_inputs) {
    return fail<void>(
        "c16.audited_instance_input_mismatch",
        "the supplied resolved instance has different authored input "
        "fingerprints from the audited framework");
  }

  auto arrival = detail::CompiledArrivalAccess::get(instance.arrival());
  if (!arrival) {
    return Result<void>::failure(arrival.error());
  }
  auto projected = build_framework_problem_view_matching_arrival_projection(
      instance, *arrival.value(), target_selection,
      bindings.problem_fingerprints.compiled_arrival);
  if (!projected) {
    return Result<void>::failure(projected.error());
  }
  if (projected.value().fingerprints() !=
          bindings.problem_fingerprints ||
      projected.value().canonical_digest() !=
          bindings.problem_view_digest) {
    return fail<void>(
        "c16.audited_instance_binding_mismatch",
        "the supplied instance does not match the audited resolved-instance, "
        "arrival, timing, target, selection, or exact-state input binding");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> verify_configured_selection(
    const ResolvedInstance& instance, const SelectionSpec& selection) {
  if (!instance.analysis_spec().context) {
    return fail<void>(
        "c16.analysis_context_missing",
        "the supplied resolved instance has no immutable analysis context",
        DiagnosticCategory::internal);
  }
  try {
    AnalysisSpec candidate = instance.analysis_spec();
    auto context =
        std::make_shared<AnalysisContext>(*instance.analysis_spec().context);
    context->selection = selection;
    candidate.context = std::move(context);

    const CanonicalInputPair canonical =
        canonicalize_authored_inputs(instance.authored_model(), candidate);
    const InputFingerprintBundle candidate_fingerprints =
        fingerprint_inputs(canonical);
    if (candidate_fingerprints.analysis !=
            instance.fingerprints().analysis ||
        candidate_fingerprints.combined !=
            instance.fingerprints().combined) {
      return fail<void>(
          "c16.selection_binding_mismatch",
          "the supplied selection is not the exact configured selection of "
          "the resolved instance");
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return fail<void>(
        "c16.selection_binding_allocation_failure",
        "validating the configured selection exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<void>(
        "c16.selection_binding_validation_failure",
        "validating the configured selection raised an implementation "
        "exception",
        DiagnosticCategory::internal);
  } catch (...) {
    return fail<void>(
        "c16.selection_binding_unknown_failure",
        "validating the configured selection raised an unknown exception",
        DiagnosticCategory::internal);
  }
}

[[nodiscard]] MetricSelectionRegimeV1 selection_regime(
    const SelectionSpec& selection) noexcept {
  if (std::holds_alternative<TransientSelection>(selection)) {
    return MetricSelectionRegimeV1::transient;
  }
  if (std::holds_alternative<StationaryUniqueSelection>(selection)) {
    return MetricSelectionRegimeV1::stationary_unique;
  }
  if (std::holds_alternative<StationaryClassSelection>(selection)) {
    return MetricSelectionRegimeV1::stationary_class;
  }
  if (std::holds_alternative<StationaryMixtureSelection>(selection)) {
    return MetricSelectionRegimeV1::stationary_mixture;
  }
  const auto& fixed = std::get<FixedPointSelection>(selection);
  return std::holds_alternative<FixedPointUniqueSelection>(fixed)
             ? MetricSelectionRegimeV1::fixed_point_unique
             : MetricSelectionRegimeV1::fixed_point_id;
}

[[nodiscard]] SelectionKindV1 analysis_selection_kind(
    const SelectionSpec& selection) noexcept {
  switch (selection_regime(selection)) {
    case MetricSelectionRegimeV1::transient:
      return SelectionKindV1::transient_initial;
    case MetricSelectionRegimeV1::stationary_unique:
      return SelectionKindV1::stationary_unique;
    case MetricSelectionRegimeV1::stationary_class:
      return SelectionKindV1::stationary_class;
    case MetricSelectionRegimeV1::stationary_mixture:
      return SelectionKindV1::stationary_mixture;
    case MetricSelectionRegimeV1::fixed_point_unique:
      return SelectionKindV1::fixed_point_unique;
    case MetricSelectionRegimeV1::fixed_point_id:
      return SelectionKindV1::fixed_point_id;
  }
  return SelectionKindV1::transient_initial;
}

[[nodiscard]] bool valid_selection_support(
    const SelectionSupportV1& support) {
  const auto valid_kind = [](const SelectionKindV1 kind) {
    return static_cast<std::uint8_t>(kind) <=
           static_cast<std::uint8_t>(
               SelectionKindV1::threshold_crossing_palm);
  };
  return !support.kinds.empty() &&
         std::ranges::all_of(support.kinds, valid_kind) &&
         std::ranges::is_sorted(support.kinds) &&
         std::adjacent_find(support.kinds.begin(), support.kinds.end()) ==
             support.kinds.end() &&
         std::ranges::is_sorted(support.named_classes) &&
         std::adjacent_find(support.named_classes.begin(),
                            support.named_classes.end()) ==
             support.named_classes.end() &&
         std::ranges::is_sorted(support.named_fixed_points) &&
         std::adjacent_find(support.named_fixed_points.begin(),
                            support.named_fixed_points.end()) ==
             support.named_fixed_points.end();
}

[[nodiscard]] bool selection_is_supported(
    const SelectionSpec& selection, const SelectionSupportV1& support) {
  const auto has_kind = [&](const SelectionKindV1 kind) {
    return std::ranges::find(support.kinds, kind) != support.kinds.end();
  };
  const auto has_class = [&](const TypedLabel& id) {
    return std::ranges::find(support.named_classes, id) !=
           support.named_classes.end();
  };
  const auto has_fixed_point = [&](const TypedLabel& id) {
    return std::ranges::find(support.named_fixed_points, id) !=
           support.named_fixed_points.end();
  };

  return std::visit(
      [&](const auto& typed) {
        using Selection = std::remove_cvref_t<decltype(typed)>;
        if constexpr (std::is_same_v<Selection, TransientSelection>) {
          return has_kind(SelectionKindV1::transient_initial);
        } else if constexpr (
            std::is_same_v<Selection, StationaryUniqueSelection>) {
          return has_kind(SelectionKindV1::stationary_unique);
        } else if constexpr (
            std::is_same_v<Selection, StationaryClassSelection>) {
          return has_kind(SelectionKindV1::stationary_class) &&
                 has_class(typed.class_id);
        } else if constexpr (
            std::is_same_v<Selection, StationaryMixtureSelection>) {
          return has_kind(SelectionKindV1::stationary_mixture) &&
                 std::ranges::all_of(
                     typed.components, [&](const auto& component) {
                       return has_class(component.class_id);
                     });
        } else {
          return std::visit(
              [&](const auto& fixed) {
                using Fixed = std::remove_cvref_t<decltype(fixed)>;
                if constexpr (std::is_same_v<
                                  Fixed, FixedPointUniqueSelection>) {
                  return has_kind(SelectionKindV1::fixed_point_unique);
                } else {
                  return has_kind(SelectionKindV1::fixed_point_id) &&
                         has_fixed_point(fixed.solution_id);
                }
              },
              typed);
        }
      },
      selection);
}

[[nodiscard]] Result<ExactRational> exact_candidate_mass(
    const ProbabilityMass& mass) {
  if (mass.kind() != ProbabilityMassKindV1::exact_rational) {
    return fail<ExactRational>(
        "c16.inexact_reduced_initial_mass",
        "alpha0 candidate masses must remain exact rationals",
        DiagnosticCategory::internal);
  }
  const ExactRational value = mass.exact_value();
  if (!value.is_positive() || value > ExactRational::one() ||
      !mass.structural_support()) {
    return fail<ExactRational>(
        "c16.invalid_reduced_initial_mass",
        "an alpha0 candidate and final support atom must have a strictly "
        "positive exact mass at most one",
        DiagnosticCategory::internal);
  }
  return Result<ExactRational>::success(value);
}

[[nodiscard]] Result<void> validate_reduced_law_fields(
    const CodecIdentityV1& state_codec,
    const Digest256& exact_state_schema_digest,
    const Digest256& reduced_state_schema_digest,
    const Digest256& selection_digest,
    const SelectionSupportV1& selection_support,
    const std::span<const ReducedInitialAtomV1> atoms,
    const bool has_framework_seal) {
  if (!valid_seam_codec(state_codec) ||
      !nonzero_digest(exact_state_schema_digest) ||
      !nonzero_digest(reduced_state_schema_digest) ||
      !nonzero_digest(selection_digest) ||
      !valid_selection_support(selection_support) || !has_framework_seal) {
    return fail<void>(
        "c16.invalid_reduced_initial_law_binding",
        "a reduced initial law requires its framework seal, exact/reduced "
        "state schemas, canonical selection support, codec, and selection "
        "identity",
        DiagnosticCategory::internal);
  }
  if (atoms.empty()) {
    return fail<void>("c16.empty_reduced_initial_law",
                      "a reduced initial law must contain at least one joint "
                      "state atom",
                      DiagnosticCategory::internal);
  }

  ExactRational total = ExactRational::zero();
  for (std::size_t index = 0U; index < atoms.size(); ++index) {
    const ReducedInitialAtomV1& atom = atoms[index];
    if (atom.state.codec != state_codec) {
      return fail<void>(
          "c16.reduced_initial_state_codec_mismatch",
          "every joint reduced-state atom must use the law's exact codec",
          DiagnosticCategory::internal);
    }
    auto mass = exact_candidate_mass(atom.mass);
    if (!mass) {
      return Result<void>::failure(mass.error());
    }
    for (std::size_t previous = 0U; previous < index; ++previous) {
      if (atoms[previous].state == atom.state) {
        return fail<void>(
            "c16.duplicate_reduced_initial_state",
            "a reduced initial law must coalesce identical complete joint "
            "states without reconstructing marginals",
            DiagnosticCategory::internal);
      }
    }
    total = total + mass.value();
  }
  if (total != ExactRational::one()) {
    return fail<void>(
        "c16.reduced_initial_mass_not_one",
        "the exact masses of the complete reduced initial law must sum to "
        "one",
        DiagnosticCategory::internal);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> verify_direct_domain(
    const AuditedFrameworkBindingsV1& framework_bindings,
    const bool framework_has_seal, const bool access_has_seal,
    const bool seals_match,
    const AuditedFrameworkBindingsV1& access_bindings,
    const DirectMetricRequestDomainV1& domain,
    const bool has_decoder, const bool has_result_validator,
    const MetricRequest& request) {
  if (!framework_has_seal || !access_has_seal || !seals_match) {
    return fail<void>(
        "c16.direct_access_seal_mismatch",
        "direct metric access was not issued by the supplied audited "
        "framework");
  }
  if (framework_bindings != access_bindings) {
    return fail<void>(
        "c16.direct_access_framework_binding_mismatch",
        "sealed direct access has different resolved-instance, descriptor, "
        "access, contract, target, selection, or build-request identities");
  }
  if (!complete_binding_shape(framework_bindings)) {
    return fail<void>(
        "c16.invalid_audited_framework_binding",
        "the audited framework carries incomplete immutable identities",
        DiagnosticCategory::internal);
  }
  if (domain.normalized_metric_request_digest !=
          framework_bindings.normalized_metric_requirements_digest ||
      domain.ordered_target_digest !=
          framework_bindings.ordered_target_digest ||
      domain.selection_digest != framework_bindings.selection_digest ||
      !framework_bindings.direct_metric_decoder_domain.has_value() ||
      domain.metric_domain !=
          *framework_bindings.direct_metric_decoder_domain) {
    return fail<void>(
        "c16.direct_access_domain_binding_mismatch",
        "the sealed decoder domain does not match the framework's accepted "
        "decoder key/parameters, requirements, target, and selection "
        "identities");
  }
  if (!nonzero_digest(domain.normalized_metric_request_digest) ||
      !nonzero_digest(domain.canonical_request_domain_digest) ||
      !nonzero_digest(domain.ordered_target_digest) ||
      !nonzero_digest(domain.selection_digest) ||
      domain.metric_domain.decoder_key.canonical_bytes().empty() ||
      !valid_seam_codec(domain.result_codec)) {
    return fail<void>(
        "c16.invalid_direct_access_domain",
        "the sealed direct decoder has an incomplete request domain or "
        "result codec",
        DiagnosticCategory::internal);
  }

  const MetricRequestHeader& header = metric_request_header(request);
  if (!header.context) {
    return fail<void>(
        "c16.direct_request_context_missing",
        "a direct metric request must retain its immutable analysis context");
  }
  if (header.ordered_targets != domain.ordered_targets ||
      header.selection_regime != domain.selection_regime ||
      header.solver_regime != MetricSolverRegimeV1::direct ||
      selection_regime(header.context->selection) !=
          domain.selection_regime ||
      metric_request_parameters(request) !=
          domain.metric_domain.exact_parameters) {
    return fail<void>(
        "c16.direct_request_domain_mismatch",
        "the metric request is outside the decoder's exact typed parameter, "
        "target, or selection domain");
  }

  auto ordered_target_digest =
      artifact::detail::canonical_ordered_metric_targets_digest_v1(
          header.ordered_targets);
  if (!ordered_target_digest) {
    return Result<void>::failure(ordered_target_digest.error());
  }
  if (ordered_target_digest.value() != domain.ordered_target_digest ||
      ordered_target_digest.value() !=
          framework_bindings.ordered_target_digest) {
    return fail<void>(
        "c16.direct_request_ordered_target_digest_mismatch",
        "the direct request's canonical ordered targets differ from the "
        "sealed execution domain");
  }
  auto analysis_selection_digest =
      artifact::detail::canonical_analysis_selection_digest_v1(
          header.context->selection);
  if (!analysis_selection_digest) {
    return Result<void>::failure(analysis_selection_digest.error());
  }
  if (analysis_selection_digest.value() != domain.selection_digest ||
      analysis_selection_digest.value() != framework_bindings.selection_digest) {
    return fail<void>(
        "c16.direct_request_selection_digest_mismatch",
        "the direct request's exact analysis selection differs from the "
        "sealed selection domain");
  }

  const MetricRequirements normalized = requirements_for_metric(request);
  auto digest = canonical_metric_requirements_digest(normalized);
  if (!digest) {
    return Result<void>::failure(digest.error());
  }
  if (digest.value() != domain.canonical_request_domain_digest) {
    return fail<void>(
        "c16.direct_request_digest_mismatch",
        "the canonical metric request digest is outside the sealed decoder "
        "domain");
  }
  if (!has_decoder || !has_result_validator) {
    return fail<void>(
        "c16.sealed_direct_decoder_incomplete",
        "sealed direct metric access requires both its decoder and canonical "
        "result-byte validator",
        DiagnosticCategory::internal);
  }
  return Result<void>::success();
}

}  // namespace

Result<void> validate_reduced_initial_law_v1(const ReducedInitialLaw& law) {
  try {
    return validate_reduced_law_fields(
        law.state_codec(), law.exact_state_schema_digest(),
        law.reduced_state_schema_digest(), law.selection_digest(),
        law.selection_support(), law.atoms(), static_cast<bool>(law.seal_));
  } catch (const std::bad_alloc&) {
    return fail<void>("c16.reduced_initial_law_allocation_failure",
                      "validating the reduced initial law exhausted memory",
                      DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<void>(
        "c16.reduced_initial_law_validation_failure",
        "validating the reduced initial law raised an implementation "
        "exception",
        DiagnosticCategory::internal);
  } catch (...) {
    return fail<void>(
        "c16.reduced_initial_law_unknown_failure",
        "validating the reduced initial law raised an unknown exception",
        DiagnosticCategory::internal);
  }
}

Result<ReducedInitialLaw> construct_reduced_initial_law(
    const ResolvedInstance& instance,
    const AuditedCompiledFramework& framework,
    const SelectionSpec& selection,
    std::optional<InitialPhysicalLaw> physical_initializer) {
  const bool transient =
      std::holds_alternative<TransientSelection>(selection);
  if (transient && !physical_initializer.has_value()) {
    return fail<ReducedInitialLaw>(
        "c16.transient_initializer_required",
        "a transient reduced initialization requires the exact configured "
        "C09 physical initial law");
  }
  if (!transient && physical_initializer.has_value()) {
    return fail<ReducedInitialLaw>(
        "c16.nontransient_initializer_forbidden",
        "stationary and fixed-point selections must not carry a transient "
        "physical initializer");
  }

  auto instance_valid = verify_instance_binding(
      instance, framework.bindings_, framework.target_selection_,
      framework.reduced_state_codec_, static_cast<bool>(framework.seal_));
  if (!instance_valid) {
    return Result<ReducedInitialLaw>::failure(instance_valid.error());
  }
  auto selection_valid = verify_configured_selection(instance, selection);
  if (!selection_valid) {
    return Result<ReducedInitialLaw>::failure(selection_valid.error());
  }
  if (!valid_selection_support(framework.selection_support_) ||
      !selection_is_supported(selection, framework.selection_support_)) {
    return fail<ReducedInitialLaw>(
        "c16.initial_selection_not_supported",
        "the exact configured selection is outside the audited framework's "
        "sealed canonical SelectionSupportV1 domain");
  }

  const SelectionKindV1 configured_kind = analysis_selection_kind(selection);
  if (configured_kind == SelectionKindV1::stationary_unique &&
      framework.selection_support_.named_classes.size() > 1U) {
    return fail<ReducedInitialLaw>(
        "c16.stationary_uniqueness_contradicted",
        "a stationary-unique selection cannot use a sealed domain that advertises multiple named stationary classes");
  }
  if (configured_kind == SelectionKindV1::fixed_point_unique &&
      framework.selection_support_.named_fixed_points.size() > 1U) {
    return fail<ReducedInitialLaw>(
        "c16.fixed_point_uniqueness_contradicted",
        "a fixed-point-unique selection cannot use a sealed domain that advertises multiple named fixed points");
  }
  if (framework.initial_selection_authority_.configured_kind !=
      configured_kind) {
    return fail<ReducedInitialLaw>(
        "c16.initial_selection_authority_mismatch",
        "the sealed initial-law authority belongs to a different configured "
        "selection kind");
  }
  const bool requires_uniqueness_evidence =
      configured_kind == SelectionKindV1::stationary_unique ||
      configured_kind == SelectionKindV1::fixed_point_unique;
  if (requires_uniqueness_evidence &&
      (!framework.initial_selection_authority_.uniqueness_evidence_digest
            .has_value() ||
       !nonzero_digest(*framework.initial_selection_authority_
                            .uniqueness_evidence_digest))) {
    return fail<ReducedInitialLaw>(
        "c16.initial_selection_evidence_missing",
        "a unique stationary or fixed-point initialization requires its own "
        "sealed nonzero uniqueness-evidence identity");
  }
  if (!requires_uniqueness_evidence &&
      framework.initial_selection_authority_.uniqueness_evidence_digest
          .has_value()) {
    return fail<ReducedInitialLaw>(
        "c16.initial_selection_authority_mismatch",
        "an explicit transient, class, mixture, or fixed-point selection "
        "must not borrow uniqueness evidence");
  }

  if (transient) {
    if (!instance.initial_law().has_value()) {
      return fail<ReducedInitialLaw>(
          "c16.instance_initial_law_missing",
          "the transient resolved instance has no bound C09 initial-law "
          "product",
          DiagnosticCategory::internal);
    }
    auto configured =
        detail::CompiledInitialLawAccess::get(*instance.initial_law());
    if (!configured) {
      return Result<ReducedInitialLaw>::failure(configured.error());
    }
    if (!physical_initializer->shares_origin_with(*configured.value()) ||
        physical_initializer->arrival_binding() !=
            configured.value()->arrival_binding()) {
      return fail<ReducedInitialLaw>(
          "c16.initializer_origin_mismatch",
          "the supplied physical initializer is not the exact C09 product "
          "owned by this resolved instance");
    }
  }

  if (!framework.initial_mapper_ || !framework.exact_state_schema_validator_ ||
      !framework.reduced_state_domain_validator_ ||
      (transient && !framework.physical_atom_projection_validator_)) {
    return fail<ReducedInitialLaw>(
        "c16.sealed_initial_operations_incomplete",
        "the audited framework requires alpha0 and a reduced-state domain "
        "validator, plus a physical projection validator for transient "
        "initialization",
        DiagnosticCategory::internal);
  }
  try {
    auto exact_state_valid = framework.exact_state_schema_validator_(
        instance, framework.bindings_.exact_state_schema_digest);
    if (!exact_state_valid) {
      return Result<ReducedInitialLaw>::failure(exact_state_valid.error());
    }
    auto mapped = framework.initial_mapper_(selection, physical_initializer);
    if (!mapped) {
      return Result<ReducedInitialLaw>::failure(mapped.error());
    }
    ReducedInitialLawCandidateV1 candidate = std::move(mapped).value();
    if (candidate.state_codec != framework.reduced_state_codec_ ||
        candidate.exact_state_schema_digest !=
            framework.bindings_.exact_state_schema_digest ||
        candidate.reduced_state_schema_digest !=
            framework.bindings_.reduced_state_schema_digest ||
        candidate.selection_digest != framework.bindings_.selection_digest ||
        candidate.selection_support != framework.selection_support_) {
      return fail<ReducedInitialLaw>(
          "c16.reduced_initial_output_binding_mismatch",
          "alpha0 returned a candidate for another exact/reduced state "
          "schema, codec, selection, or SelectionSupportV1 domain",
          DiagnosticCategory::internal);
    }
    if (candidate.atoms.empty()) {
      return fail<ReducedInitialLaw>(
          "c16.empty_reduced_initial_candidate",
          "alpha0 must return at least one complete joint reduced-state "
          "candidate atom",
          DiagnosticCategory::internal);
    }

    struct AccumulatedAtom final {
      ReducedStateV1 state;
      ExactRational mass;
    };
    std::vector<AccumulatedAtom> accumulated;
    accumulated.reserve(candidate.atoms.size());

    const std::span<const InitialPhysicalAtom> physical_atoms =
        transient ? physical_initializer->atoms()
                  : std::span<const InitialPhysicalAtom>{};
    std::vector<ExactRational> conditional_totals;
    std::vector<bool> ordinal_seen;
    if (transient) {
      if (physical_atoms.empty()) {
        return fail<ReducedInitialLaw>(
            "c16.empty_physical_initial_law",
            "the exact C09 transient initializer has no complete joint atom",
            DiagnosticCategory::internal);
      }
      conditional_totals.assign(physical_atoms.size(),
                                ExactRational::zero());
      ordinal_seen.assign(physical_atoms.size(), false);

      ExactRational physical_total = ExactRational::zero();
      for (const InitialPhysicalAtom& atom : physical_atoms) {
        if (!atom.probability.is_positive() ||
            atom.probability > ExactRational::one()) {
          return fail<ReducedInitialLaw>(
              "c16.invalid_physical_initial_mass",
              "every coalesced C09 support atom must have a strictly "
              "positive exact mass at most one",
              DiagnosticCategory::internal);
        }
        physical_total = physical_total + atom.probability;
      }
      if (physical_total != ExactRational::one()) {
        return fail<ReducedInitialLaw>(
            "c16.physical_initial_mass_not_one",
            "the sealed C09 complete joint initializer is not exactly "
            "normalized",
            DiagnosticCategory::internal);
      }
    }

    ExactRational stationary_total = ExactRational::zero();
    for (const ReducedInitialCandidateAtomV1& atom : candidate.atoms) {
      if (atom.state.codec != candidate.state_codec) {
        return fail<ReducedInitialLaw>(
            "c16.reduced_initial_state_codec_mismatch",
            "every alpha0 state must use the sealed reduced-state codec",
            DiagnosticCategory::internal);
      }
      auto mass = exact_candidate_mass(atom.conditional_mass);
      if (!mass) {
        return Result<ReducedInitialLaw>::failure(mass.error());
      }
      auto state_valid = framework.reduced_state_domain_validator_(atom.state);
      if (!state_valid) {
        return Result<ReducedInitialLaw>::failure(state_valid.error());
      }

      ExactRational effective_mass = mass.value();
      if (transient) {
        if (!atom.physical_atom_ordinal.has_value() ||
            *atom.physical_atom_ordinal >= physical_atoms.size()) {
          return fail<ReducedInitialLaw>(
              "c16.physical_atom_ordinal_invalid",
              "each transient alpha0 atom must name one in-range coalesced "
              "C09 physical-atom ordinal",
              DiagnosticCategory::internal);
        }
        const std::size_t ordinal = *atom.physical_atom_ordinal;
        auto projection_valid =
            framework.physical_atom_projection_validator_(
                ordinal, physical_atoms[ordinal], atom.state);
        if (!projection_valid) {
          return Result<ReducedInitialLaw>::failure(
              projection_valid.error());
        }
        ordinal_seen[ordinal] = true;
        conditional_totals[ordinal] =
            conditional_totals[ordinal] + mass.value();
        effective_mass = physical_atoms[ordinal].probability * mass.value();
      } else {
        if (atom.physical_atom_ordinal.has_value()) {
          return fail<ReducedInitialLaw>(
              "c16.stationary_physical_atom_ordinal_forbidden",
              "a stationary or fixed-point alpha0 candidate cannot cite a "
              "transient physical-atom ordinal",
              DiagnosticCategory::internal);
        }
        stationary_total = stationary_total + mass.value();
      }

      const auto existing = std::ranges::find_if(
          accumulated, [&](const AccumulatedAtom& value) {
            return value.state == atom.state;
          });
      if (existing == accumulated.end()) {
        accumulated.push_back(
            AccumulatedAtom{atom.state, std::move(effective_mass)});
      } else {
        existing->mass = existing->mass + effective_mass;
      }
    }

    if (transient) {
      for (std::size_t ordinal = 0U; ordinal < physical_atoms.size();
           ++ordinal) {
        if (!ordinal_seen[ordinal] ||
            conditional_totals[ordinal] != ExactRational::one()) {
          return fail<ReducedInitialLaw>(
              "c16.physical_atom_pushforward_incomplete",
              "alpha0 must provide an exactly normalized conditional "
              "reduced-state law for every coalesced C09 physical atom",
              DiagnosticCategory::internal);
        }
      }
    } else if (stationary_total != ExactRational::one()) {
      return fail<ReducedInitialLaw>(
          "c16.reduced_initial_mass_not_one",
          "the selected stationary or fixed-point alpha0 law must be exactly "
          "normalized",
          DiagnosticCategory::internal);
    }

    std::vector<ReducedInitialAtomV1> atoms;
    atoms.reserve(accumulated.size());
    for (AccumulatedAtom& atom : accumulated) {
      auto mass = ProbabilityMass::exact_rational(
          atom.mass, atom.mass.is_positive());
      if (!mass) {
        return Result<ReducedInitialLaw>::failure(mass.error());
      }
      atoms.push_back(ReducedInitialAtomV1{
          std::move(atom.state), std::move(mass).value()});
    }
    auto law_valid = validate_reduced_law_fields(
        framework.reduced_state_codec_,
        framework.bindings_.exact_state_schema_digest,
        framework.bindings_.reduced_state_schema_digest,
        framework.bindings_.selection_digest,
        framework.selection_support_, atoms,
        static_cast<bool>(framework.seal_));
    if (!law_valid) {
      return Result<ReducedInitialLaw>::failure(law_valid.error());
    }
    return Result<ReducedInitialLaw>::success(ReducedInitialLaw(
        framework.reduced_state_codec_,
        framework.bindings_.exact_state_schema_digest,
        framework.bindings_.reduced_state_schema_digest,
        framework.bindings_.selection_digest, framework.selection_support_,
        std::move(atoms), framework.seal_));
  } catch (const std::bad_alloc&) {
    return fail<ReducedInitialLaw>(
        "c16.initial_mapper_allocation_failure",
        "the sealed alpha0 operation exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ReducedInitialLaw>(
        "c16.initial_mapper_exception",
        "the sealed alpha0 operation raised an implementation exception",
        DiagnosticCategory::internal);
  } catch (...) {
    return fail<ReducedInitialLaw>(
        "c16.initial_mapper_unknown_exception",
        "the sealed alpha0 operation raised an unknown exception",
        DiagnosticCategory::internal);
  }
}

Result<MetricValue> execute_direct_metric_decoder(
    const AuditedCompiledFramework& framework,
    const DirectMetricAccess& access,
    const MetricRequest& request) {
  try {
    auto domain_valid = verify_direct_domain(
        framework.bindings_, static_cast<bool>(framework.seal_),
        static_cast<bool>(access.seal_),
        framework.seal_.get() == access.seal_.get(),
        access.framework_bindings_, access.domain_,
        static_cast<bool>(access.decoder_),
        static_cast<bool>(access.result_validator_), request);
    if (!domain_valid) {
      return Result<MetricValue>::failure(domain_valid.error());
    }

    // Exactly one invocation occurs, and only after every seal and domain
    // check above has succeeded.
    auto decoded = access.decoder_(request);
    if (!decoded) {
      return Result<MetricValue>::failure(decoded.error());
    }
    if (decoded.value().codec != access.domain_.result_codec ||
        !valid_seam_codec(decoded.value().codec)) {
      return fail<MetricValue>(
          "c16.direct_metric_result_type_mismatch",
          "the direct decoder returned a value outside its sealed result "
          "codec",
          DiagnosticCategory::internal);
    }
    auto result_valid = access.result_validator_(
        access.domain_.metric_domain.decoder_key, decoded.value().codec,
        decoded.value().canonical_value);
    if (!result_valid) {
      return Result<MetricValue>::failure(result_valid.error());
    }
    return decoded;
  } catch (const std::bad_alloc&) {
    return fail<MetricValue>(
        "c16.direct_metric_decoder_allocation_failure",
        "direct metric decoding exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<MetricValue>(
        "c16.direct_metric_decoder_exception",
        "the sealed direct metric decoder raised an implementation exception",
        DiagnosticCategory::internal);
  } catch (...) {
    return fail<MetricValue>(
        "c16.direct_metric_decoder_unknown_exception",
        "the sealed direct metric decoder raised an unknown exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace mwperf

#include <exception>

#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "mwperf/surrogate/plug_preview.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_registry.hpp"

namespace mwperf {
namespace {

[[nodiscard]] FailedProviderExecution execution_failure(
    std::string code, std::string message) {
  return FailedProviderExecution{Diagnostic{
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::nullopt, std::nullopt, {}}};
}

[[nodiscard]] const PortablePayloadContextV1& payload_context(
    const PortablePlugPayload& payload) {
  return std::visit(
      [](const auto& value) -> const PortablePayloadContextV1& {
        return value.context;
      },
      payload.value());
}

[[nodiscard]] const ResultEnvelopeV1& result_envelope(
    const SurrogateBuildResult& result) {
  return std::visit(
      [](const auto& value) -> const ResultEnvelopeV1& {
        return value.envelope;
      },
      result);
}

template <typename T>
[[nodiscard]] bool contains_exact(std::span<const T> values,
                                  const T& wanted) {
  return std::find(values.begin(), values.end(), wanted) != values.end();
}

template <typename T>
[[nodiscard]] bool contains_exact(const std::vector<T>& values,
                                  const T& wanted) {
  return std::find(values.begin(), values.end(), wanted) != values.end();
}

[[nodiscard]] bool applicability_contains(
    const SchedulerConstraintApplicabilityV1& applicability,
    const SchedulerConstraintPairV1& pair, TimingConvention timing) {
  return contains_exact(applicability.scheduler_optimizer_pairs, pair) &&
         contains_exact(applicability.timing_conventions, timing);
}

[[nodiscard]] bool parameter_domain_is_subset(
    const MetricParameterDomainV1& subset,
    const MetricParameterDomainV1& ceiling) {
  const auto* subset_set = std::get_if<ExactMetricParameterSetV1>(&subset);
  const auto* ceiling_set = std::get_if<ExactMetricParameterSetV1>(&ceiling);
  if (subset_set != nullptr || ceiling_set != nullptr) {
    if (subset_set == nullptr || ceiling_set == nullptr) return false;
    return std::all_of(
        subset_set->values.begin(), subset_set->values.end(),
        [&](const MetricRequestParametersV1& value) {
          return contains_exact(ceiling_set->values, value);
        });
  }
  return subset == ceiling;
}

[[nodiscard]] bool clause_is_narrowing(
    const MetricSupportClauseV1& subset,
    const MetricSupportClauseV1& ceiling,
    const ProviderIdentityV1& provider,
    const std::span<const QueueId> deployed_targets) {
  return subset.clause_id == ceiling.clause_id &&
         subset.metric_kind == ceiling.metric_kind &&
         parameter_domain_is_subset(subset.parameter_domain,
                                    ceiling.parameter_domain) &&
         detail::metric_targets_are_narrowing(subset, ceiling, provider,
                                              deployed_targets) &&
         subset.target_coupling == ceiling.target_coupling &&
         subset.state_fields == ceiling.state_fields &&
         detail::metric_marks_are_narrowing(subset, ceiling, provider) &&
         subset.selection_domain == ceiling.selection_domain &&
         subset.phase_domain == ceiling.phase_domain &&
         subset.payload_class == ceiling.payload_class &&
         subset.semantic == ceiling.semantic &&
         subset.runtime_access == ceiling.runtime_access &&
         subset.arrival_assumptions == ceiling.arrival_assumptions &&
         subset.hypotheses == ceiling.hypotheses &&
         subset.solver_route == ceiling.solver_route &&
         subset.requested_accuracy == ceiling.requested_accuracy &&
         subset.error_promise == ceiling.error_promise &&
         subset.result_scope == ceiling.result_scope &&
         subset.mandatory_v0 == ceiling.mandatory_v0 &&
         subset.required_roles == ceiling.required_roles;
}

[[nodiscard]] bool manifest_is_subset(
    const MetricSupportManifest& subset,
    const MetricSupportManifest& ceiling,
    const ProviderIdentityV1& provider,
    const std::span<const QueueId> deployed_targets) {
  return std::all_of(
      subset.clauses().begin(), subset.clauses().end(),
      [&](const MetricSupportClauseV1& clause) {
        return std::any_of(
            ceiling.clauses().begin(), ceiling.clauses().end(),
            [&](const MetricSupportClauseV1& upper) {
              return clause_is_narrowing(clause, upper, provider,
                                         deployed_targets);
            });
      });
}

[[nodiscard]] bool preview_policies_allowed(
    const PreviewPoliciesV1& policies,
    const ScientificConstructionPolicySchemaV1& schema) {
  return contains_exact(schema.point_deployment, policies.point_deployment) &&
         contains_exact(schema.coefficient_completion,
                        policies.coefficient_completion) &&
         contains_exact(schema.projection, policies.projection) &&
         contains_exact(schema.recoding, policies.recoding) &&
         contains_exact(schema.evidence_roles, policies.evidence_roles);
}

// CP09/result-v3 cannot return a deployable artifact.  Its registered policy
// schema is therefore nondeployment-only.  C14 nevertheless needs this exact
// legacy tuple to construct the compatibility descriptor consumed by the
// planner.  Admit it only for the frozen 1.4 identity; the result-v3 boundary
// still makes Observed the sole successful terminal.
[[nodiscard]] bool cp09_compatibility_preview_policies(
    const SurrogateProviderManifestV1& manifest,
    const PreviewPoliciesV1& policies) {
  return manifest.provider.provider_id ==
             "full_orbit_framework_sampler" &&
         manifest.provider.provider_version == "1.4.0" &&
         manifest.parameter_schema_version == 4U &&
         manifest.payload_class ==
             PayloadClassV1{
                 PayloadClassTagV1::empirical_finite_window_response_v1,
                 1U} &&
         manifest.scientific_construction_policy_schema.point_deployment ==
             std::vector<PointDeploymentPolicyV1>{
                 PointDeploymentPolicyV1::not_applicable} &&
         policies.point_deployment ==
             PointDeploymentPolicyV1::deploy_raw_point &&
         policies.coefficient_completion ==
             CoefficientCompletionPolicyV1::require_complete_raw_points &&
         policies.projection == ProjectionPolicyV1::not_applicable &&
         policies.recoding == RecodingPolicyV1::not_applicable &&
         policies.evidence_roles ==
             EvidenceRolePolicyV1::exact_manifest_roles;
}

[[nodiscard]] bool grant_covers(
    const CountConstructionGrantV1& grant,
    const std::optional<BigNat>& required) {
  return !required.has_value() ||
         (grant.applicability == BudgetApplicabilityV1::applicable &&
          grant.amount.has_value() && *grant.amount >= *required);
}

[[nodiscard]] bool portable_provision(AccessProvision provision) noexcept {
  return provision == AccessProvision::portable_only ||
         provision == AccessProvision::portable_and_process_local;
}

[[nodiscard]] bool portable_law_is_reconstructible(
    const PortableArrivalLawDescriptor& law) noexcept {
  if (law.version != 1U || law.canonical_data.empty() ||
      !nonzero_digest(law.payload_digest)) {
    return false;
  }
  switch (law.schema) {
    case PortableArrivalLawSchema::deterministic_trace_v1:
    case PortableArrivalLawSchema::periodic_global_phase_v1:
    case PortableArrivalLawSchema::periodic_source_delays_v1:
    case PortableArrivalLawSchema::independent_marked_renewal_v1:
    case PortableArrivalLawSchema::independent_private_markov_renewal_v1:
    case PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1:
    case PortableArrivalLawSchema::iid_independent_bernoulli_v1:
    case PortableArrivalLawSchema::iid_count_table_v1:
    case PortableArrivalLawSchema::iid_independent_poisson_v1:
    case PortableArrivalLawSchema::iid_mixed_poisson_v1:
      return true;
  }
  return false;
}

// A local executable receives only the callback-free C09 construction view.
// Prove that view carries at least one complete portable reconstruction route
// before consulting provider code.  Per-prerequisite checks below then prove
// that the particular construction inputs selected by the preview are covered
// by portable data rather than by a process-local service.
[[nodiscard]] bool local_arrival_is_reconstructible(
    const BuilderArrivalView& arrival) noexcept {
  const ArrivalCapabilities& capabilities = arrival.capabilities();
  const bool portable_iid_table =
      arrival.iid_joint_table().has_value() &&
      !arrival.iid_joint_table()->empty() &&
      capabilities.exact_iid_joint_vector.has_value() &&
      capabilities.exact_iid_joint_vector->finite_support &&
      portable_provision(capabilities.exact_iid_joint_vector->provision);
  const bool portable_finite_rows =
      arrival.finite_phase().has_value() &&
      !arrival.finite_phase()->canonical_states.empty() &&
      arrival.finite_phase()->codec_version != 0U &&
      arrival.transition_rows().has_value() &&
      !arrival.transition_rows()->canonical_rows.empty() &&
      arrival.transition_rows()->codec_version ==
          arrival.finite_phase()->codec_version &&
      capabilities.finite_enumerated_predictive_phase ==
          CapabilityAvailability::available &&
      capabilities.finite_enumerated_transition_row ==
          CapabilityAvailability::available;
  return portable_iid_table || portable_finite_rows ||
         portable_law_is_reconstructible(arrival.configured_law());
}

[[nodiscard]] bool exact_domain_contains(
    const ExactArgumentDomain& offered,
    const ExactArgumentDomain& required) {
  if (offered.lower > required.lower || offered.upper < required.upper) {
    return false;
  }
  if (offered.lower == required.lower && required.lower_inclusive &&
      !offered.lower_inclusive) {
    return false;
  }
  if (offered.upper == required.upper && required.upper_inclusive &&
      !offered.upper_inclusive) {
    return false;
  }
  return true;
}

[[nodiscard]] bool portable_moment_satisfies(
    const MomentCapability& capability,
    const ArrivalAssumptionV1& assumption) {
  return portable_provision(capability.provision) &&
         (!assumption.joint || capability.joint) &&
         (!assumption.phase_conditioned ||
          capability.conditioned_on_phase) &&
         (!assumption.moment_order.has_value() ||
          !capability.maximum_order.has_value() ||
          *capability.maximum_order >= *assumption.moment_order);
}

[[nodiscard]] bool portable_transform_satisfies(
    const PortableTransformDescriptor& descriptor,
    const ArrivalAssumptionV1& assumption) {
  const TransformCapability& capability = descriptor.capability;
  return descriptor.codec_version != 0U &&
         !descriptor.canonical_parameters.empty() &&
         portable_provision(capability.provision) &&
         (!assumption.transform_kind.has_value() ||
          capability.kind == *assumption.transform_kind) &&
         (!assumption.distribution_scope.has_value() ||
          capability.scope == *assumption.distribution_scope) &&
         (!assumption.phase_conditioned ||
          capability.phase_requirement ==
              PhaseArgumentRequirement::explicit_phase_required) &&
         (!assumption.argument_domain.has_value() ||
          exact_domain_contains(capability.domain,
                                *assumption.argument_domain));
}

[[nodiscard]] bool local_arrival_prerequisite_is_portable(
    const BuilderArrivalView& arrival, const ArrivalAssumptionV1& assumption) {
  if (assumption.use != ArrivalCapabilityUseV1::construction ||
      assumption.provision == CapabilityProvisionNeedV1::process_local) {
    return false;
  }
  const ArrivalCapabilities& capabilities = arrival.capabilities();
  const bool portable_iid_joint =
      arrival.iid_joint_table().has_value() &&
      !arrival.iid_joint_table()->empty() &&
      capabilities.exact_iid_joint_vector.has_value() &&
      capabilities.exact_iid_joint_vector->finite_support &&
      portable_provision(
          capabilities.exact_iid_joint_vector->provision);
  const bool portable_finite_rows =
      arrival.finite_phase().has_value() &&
      arrival.transition_rows().has_value() &&
      capabilities.finite_enumerated_predictive_phase ==
          CapabilityAvailability::available &&
      capabilities.finite_enumerated_transition_row ==
          CapabilityAvailability::available;
  const bool portable_recipe =
      portable_law_is_reconstructible(arrival.configured_law());
  const bool portable_factorized_iid =
      capabilities.exact_factorized_iid_generator.has_value() &&
      portable_provision(
          capabilities.exact_factorized_iid_generator->provision) &&
      arrival.binding().family ==
          ArrivalFamily::independent_marked_renewal &&
      arrival.configured_law().schema ==
          PortableArrivalLawSchema::independent_marked_renewal_v1 &&
      portable_recipe;
  const bool portable_schema4_iid_recipe =
      capabilities.exact_portable_iid_recipe.has_value() &&
      portable_provision(
          capabilities.exact_portable_iid_recipe->provision) &&
      portable_recipe;
  switch (assumption.kind) {
    case ArrivalNeedKindV1::target_intensity: {
      ArrivalAssumptionV1 order_one = assumption;
      order_one.moment_order = BigNat{1U};
      return arrival.moments().has_value() &&
             !arrival.moments()->empty() &&
             ((capabilities.exact_coordinate_moments.has_value() &&
               portable_moment_satisfies(
                   *capabilities.exact_coordinate_moments, order_one)) ||
              (capabilities.analytic_moments.has_value() &&
               portable_moment_satisfies(*capabilities.analytic_moments,
                                          order_one)));
    }
    case ArrivalNeedKindV1::arrival_moment: {
      const std::optional<MomentCapability>& exact =
          assumption.joint ? capabilities.exact_joint_moments
                           : capabilities.exact_coordinate_moments;
      return arrival.moments().has_value() &&
             !arrival.moments()->empty() &&
             ((exact.has_value() &&
               portable_moment_satisfies(*exact, assumption)) ||
              (capabilities.analytic_moments.has_value() &&
               portable_moment_satisfies(*capabilities.analytic_moments,
                                          assumption)));
    }
    case ArrivalNeedKindV1::full_common_batch:
      return portable_iid_joint || portable_finite_rows || portable_recipe;
    case ArrivalNeedKindV1::finite_support:
      return portable_iid_joint || portable_finite_rows;
    case ArrivalNeedKindV1::exact_iid_late:
      return portable_iid_joint || portable_factorized_iid ||
             portable_schema4_iid_recipe;
    case ArrivalNeedKindV1::predictive_phase:
      return portable_finite_rows || portable_recipe;
    case ArrivalNeedKindV1::sequential_law:
      return portable_finite_rows ||
             (arrival.replay_codec().has_value() &&
              arrival.replay_codec()->codec_version != 0U &&
              arrival.replay_codec()->requires_complete_initial_state &&
              arrival.replay_codec()->preserves_adjacent_temporal_order &&
              !arrival.replay_codec()->canonical_parameters.empty() &&
              capabilities.adjacent_batch_replay.has_value() &&
              portable_provision(
                  capabilities.adjacent_batch_replay->provision)) ||
             portable_recipe;
    case ArrivalNeedKindV1::entrance_labels:
      return portable_iid_joint || portable_finite_rows || portable_recipe;
    case ArrivalNeedKindV1::transform: {
      const auto matches = [&](const std::optional<PortableTransformDescriptor>&
                                   descriptor) {
        return descriptor.has_value() &&
               portable_transform_satisfies(*descriptor, assumption);
      };
      return matches(arrival.analytic_transform()) ||
             matches(arrival.joint_distribution()) ||
             matches(arrival.coordinate_distributions());
    }
  }
  return false;
}

[[nodiscard]] bool contains_codec(
    const std::vector<RuntimeStateFieldV1>& fields,
    const CodecIdentityV1& codec) {
  return std::any_of(fields.begin(), fields.end(),
                     [&](const RuntimeStateFieldV1& field) {
                       return field.c14_field.codec == codec;
                     });
}

[[nodiscard]] Result<void> validate_operation_carriers(
    const PlugDescriptor& descriptor, const SurrogatePlug& plug) {
  const CausalSurrogateOperationsV1* operations = causal_operations_v1(plug);
  if (operations == nullptr) {
    if (descriptor.c_minus.has_value() || descriptor.c_plus.has_value() ||
        descriptor.event_contract.has_value()) {
      return Result<void>::failure(boundary_error(
          "c16.operations_on_noncausal_semantic",
          "this semantic alternative cannot carry causal or temporal operations",
          "/plug/operations"));
    }
    return Result<void>::success();
  }
  if (operations->c_minus.has_value() != descriptor.c_minus.has_value() ||
      operations->c_plus.has_value() != descriptor.c_plus.has_value() ||
      operations->event.has_value() != descriptor.event_contract.has_value()) {
    return Result<void>::failure(boundary_error(
        "c16.operation_presence_mismatch",
        "the causal and temporal operation carriers must exactly match descriptor presence",
        "/plug/operations"));
  }
  if (operations->c_minus.has_value() &&
      ((!operations->c_minus->has_operation() &&
        !operations->c_minus->has_exact_enumerator()) ||
       operations->c_minus->schema() != *descriptor.c_minus)) {
    return Result<void>::failure(boundary_error(
        "c16.c_minus_carrier_mismatch",
        "the C-minus carrier must contain one operation with the exact declared typed schema",
        "/plug/operations/c_minus"));
  }
  if (operations->c_plus.has_value() &&
      ((!operations->c_plus->has_operation() &&
        !operations->c_plus->has_exact_enumerator()) ||
       operations->c_plus->schema() != *descriptor.c_plus)) {
    return Result<void>::failure(boundary_error(
        "c16.c_plus_carrier_mismatch",
        "the C-plus carrier must contain one operation with the exact declared typed schema",
        "/plug/operations/c_plus"));
  }
  if (operations->event.has_value()) {
    const TemporalEventContractV1& contract = *descriptor.event_contract;
    const TemporalEventOperationsV1& event = *operations->event;
    const EventEntryInitializerSchemaV1 expected_entry{
        contract.entry_initializer_operation, contract.entrance_space,
        contract.continuation_space};
    const EventStoppingIndicatorSchemaV1 expected_stopping{
        contract.stopping_indicator_operation, contract.stopping_filtration,
        contract.continuation_space, contract.stopping_indicator};
    const EventTerminalReentrySchemaV1 expected_terminal{
        contract.terminal_reentry_operation, contract.terminal_space,
        contract.continuation_space,
        contract.reentry_space};
    const EventPredecisionProjectionSchemaV1 expected_predecision{
        contract.predecision_projection_operation, contract.entrance_space,
        contract.continuation_space, contract.predecision_projection};
    const EventCompletedEdgeProjectionSchemaV1 expected_completed_edge{
        contract.completed_edge_projection_operation,
        contract.predecision_projection, contract.continuation_space,
        contract.completed_edge_projection};
    if (!event.entry_initializer.has_operation() ||
        !event.stopping_indicator.has_operation() ||
        !event.terminal_reentry.has_operation() ||
        !event.predecision_projection.has_operation() ||
        !event.completed_edge_projection.has_operation() ||
        event.entry_initializer.schema() != expected_entry ||
        event.stopping_indicator.schema() != expected_stopping ||
        event.terminal_reentry.schema() != expected_terminal ||
        event.predecision_projection.schema() != expected_predecision ||
        event.completed_edge_projection.schema() != expected_completed_edge) {
      return Result<void>::failure(boundary_error(
          "c16.event_operation_carrier_mismatch",
          "all five temporal event operations must be present and exactly bind their declared identities, spaces, and filtration",
          "/plug/operations/event"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<BigNat> method_counter_value(
    const NamedPortableValueV1& counter) {
  const auto* scalar = std::get_if<PortableScientificScalar>(&counter.value);
  if (scalar == nullptr) {
    return Result<BigNat>::failure(boundary_error(
        "c16.method_counter_not_scalar",
        "a required provider method counter must be one scalar",
        "/result/envelope/build_report/optional_method_counters"));
  }
  const ExactRational exact =
      scalar->kind() == PortableScientificScalarKind::rational
          ? scalar->rational_value()
          : binary64_as_exact_rational(*scalar);
  if (!exact.is_nonnegative() || exact.denominator() != 1) {
    return Result<BigNat>::failure(boundary_error(
        "c16.method_counter_not_natural",
        "a required provider method counter must be an exact nonnegative integer",
        "/result/envelope/build_report/optional_method_counters"));
  }
  return BigNat::from_big_int(exact.numerator());
}

[[nodiscard]] Result<void> require_common_minimum(
    const CommonWorkCounterV1& counter,
    const std::optional<BigNat>& required, std::string name) {
  if (!required.has_value()) return Result<void>::success();
  if (counter.applicability != WorkCounterApplicabilityV1::applicable ||
      counter.used < *required) {
    return Result<void>::failure(boundary_error(
        "c16.required_work_underreported",
        "the applicable " + name +
            " counter is below the request-bound accepted minimum",
        "/result/envelope/build_report"));
  }
  return Result<void>::success();
}

}  // namespace

#if defined(MWPERF_C16_TEST_SEAMS)
namespace testing {

Result<void> validate_c16_operation_carriers_for_test(
    const PlugDescriptor& descriptor, const SurrogatePlug& plug) {
  return validate_operation_carriers(descriptor, plug);
}

}  // namespace testing
#endif

Result<ValidatedSurrogateParameters> validate_surrogate_parameters(
    const SurrogateProvider& provider, const SourceNode& parameters) {
  if (!provider.is_statically_registered()) {
    return Result<ValidatedSurrogateParameters>::failure(boundary_error(
        "c16.unregistered_provider_handle",
        "parameter validation requires a provider selected from the immutable production registry",
        "/surrogate/provider"));
  }
  if (parameters.kind() != SourceNodeKind::object) {
    return Result<ValidatedSurrogateParameters>::failure(boundary_error(
        "c16.parameters_not_object",
        "surrogate parameters must be a source-preserving JSON object",
        std::string(parameters.json_pointer())));
  }
  try {
    ParameterValidatorV1 validator = provider.parameter_validator();
    auto validated = validator(parameters);
    if (!validated) {
      return Result<ValidatedSurrogateParameters>::failure(validated.error());
    }
    if (!validated.value().typed_value) {
      return Result<ValidatedSurrogateParameters>::failure(boundary_error(
          "c16.missing_typed_parameter_value",
          "the provider parameter schema must publish one immutable typed value",
          std::string(parameters.json_pointer())));
    }
    ValidatedParameterPayloadV1 value = std::move(validated).value();
    auto digest =
        digest_surrogate_parameter_values_v1(value.canonical_bytes);
    if (!digest) {
      return Result<ValidatedSurrogateParameters>::failure(digest.error());
    }
    const auto& manifest = provider.manifest().value();
    return Result<ValidatedSurrogateParameters>::success(
        ValidatedSurrogateParameters(
            manifest.provider, manifest.parameter_schema_version,
            manifest.parameter_schema_digest,
            std::move(value.canonical_bytes), std::move(digest).value(),
            std::move(value.typed_value)));
  } catch (const std::bad_alloc&) {
    return Result<ValidatedSurrogateParameters>::failure(boundary_error(
        "c16.parameter_validation_allocation_failure",
        "provider parameter validation exhausted memory"));
  } catch (const std::exception&) {
    return Result<ValidatedSurrogateParameters>::failure(boundary_error(
        "c16.parameter_validator_exception",
        "provider parameter validation raised an exception"));
  } catch (...) {
    return Result<ValidatedSurrogateParameters>::failure(boundary_error(
        "c16.parameter_validator_unknown_exception",
        "provider parameter validation raised an unknown exception"));
  }
}

Result<PlugDescriptorPreview> preview_surrogate_descriptor(
    const SurrogateProvider& provider, const FrameworkProblemView& problem,
    const MetricRequirements& requirements,
    const RepresentationBudget& representation_budget,
    const ValidatedSurrogateParameters& parameters) {
  if (!provider.is_statically_registered()) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.unregistered_provider_handle",
        "descriptor preview requires a provider selected from the immutable production registry",
        "/surrogate/provider"));
  }
  const auto& manifest = provider.manifest().value();
  if (parameters.provider() != manifest.provider ||
      parameters.parameter_schema_version() !=
          manifest.parameter_schema_version ||
      parameters.parameter_schema_digest() != manifest.parameter_schema_digest) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.foreign_validated_parameters",
        "validated parameters do not originate from this exact provider schema",
        "/surrogate/parameters"));
  }
  auto parameter_digest = digest_surrogate_parameter_values_v1(
      parameters.canonical_value_bytes());
  if (!parameter_digest ||
      parameter_digest.value() != parameters.canonical_value_digest()) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.parameter_digest_mismatch",
        "validated parameter bytes do not match their immutable digest",
        "/surrogate/parameters"));
  }
  auto budget_digest =
      digest_construction_budget_v1(representation_budget);
  if (!budget_digest) {
    return Result<PlugDescriptorPreview>::failure(budget_digest.error());
  }
  if (manifest.producer_mode == ProducerModeV1::local_executable_builder &&
      (!manifest.local_executable.has_value() ||
       !manifest.local_executable->externally_reconstructible_arrival ||
       !local_arrival_is_reconstructible(problem.configured_arrival()))) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.local_builder_arrival_not_reconstructible",
        "this arrival construction input requires the in-process builder route",
        "/framework_problem_view/configured_arrival"));
  }

  try {
    DescriptorPreviewerV1 previewer = provider.previewer();
    auto preview = previewer(problem, requirements, representation_budget,
                             parameters);
    if (!preview) return preview;
    PlugDescriptorPreview& value = preview.value();
    if (value.schema_version != 1U || value.core.provider != manifest.provider ||
        value.core.semantic != manifest.deployed_semantic_tag ||
        value.core.runtime_access != manifest.runtime_access_tag ||
        value.core.payload_class != manifest.payload_class ||
        value.construction_method != manifest.construction_method ||
        value.producer_mode != manifest.producer_mode ||
        value.problem_view_digest != problem.canonical_digest().value() ||
        value.parameter_digest != parameters.canonical_value_digest() ||
        value.budget_digest != budget_digest.value() ||
        !value.metric_support_manifest ||
        !detail::is_valid_plug_descriptor_core_shape_v1(value.core)) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.invalid_provider_preview_binding",
          "the provider preview changed a registered axis or immutable input binding",
          "/preview"));
    }
    auto core_digest = canonical_plug_descriptor_core_digest_v1(value.core);
    auto preview_digest =
        canonical_plug_descriptor_preview_digest_v1(value);
    if (!core_digest || core_digest.value() != value.core.core_digest ||
        !preview_digest || preview_digest.value() != value.preview_digest) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.noncanonical_provider_preview",
          "the provider preview and embedded descriptor must carry canonical digests",
        "/preview/preview_digest"));
    }
    std::vector<MetricSupportClauseV1> clauses(
        value.metric_support_manifest->clauses().begin(),
        value.metric_support_manifest->clauses().end());
    auto rebuilt = MetricSupportManifest::from_clauses(std::move(clauses));
    if (!rebuilt ||
        !(rebuilt.value() == *value.metric_support_manifest) ||
        rebuilt.value().canonical_digest() !=
            value.metric_support_manifest->canonical_digest() ||
        value.core.metric_support_manifest_digest !=
            value.metric_support_manifest->canonical_digest() ||
        !manifest_is_subset(*value.metric_support_manifest,
                            manifest.metric_clause_upper_envelope,
                            manifest.provider,
                            problem.target_selection().ordered_targets)) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.preview_manifest_outside_registration",
          "the preview manifest must be canonical, core-bound, and a narrowing of the registered upper envelope",
          "/preview/metric_support_manifest"));
    }
    if (value.metric_support_manifest->clauses().size() !=
            requirements.clauses().size() ||
        !std::all_of(
            requirements.clauses().begin(), requirements.clauses().end(),
            [&](const MetricRequirementClause& requirement) {
              return std::any_of(
                  value.metric_support_manifest->clauses().begin(),
                  value.metric_support_manifest->clauses().end(),
                  [&](const MetricSupportClauseV1& clause) {
                    return clause.clause_id == requirement.origin.clause_id;
                  });
            })) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.preview_requirement_set_mismatch",
          "the preview must contain exactly one structural clause for each requested metric clause",
          "/preview/metric_support_manifest"));
    }
    const auto& prerequisite =
        manifest.target_and_arrival_scientific_prerequisites;
    const auto targets = problem.target_selection().ordered_targets;
    if (!applicability_contains(manifest.optimizer_constraint_applicability,
                                problem.applicability_key(),
                                problem.timing()) ||
        !applicability_contains(value.core.applicability,
                                problem.applicability_key(),
                                problem.timing()) ||
        value.core.deployed_targets != targets || targets.size() <
            prerequisite.minimum_deployed_targets ||
        targets.size() > prerequisite.maximum_deployed_targets ||
        !contains_exact(prerequisite.permitted_target_couplings,
                        value.core.target_coupling)) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.preview_problem_domain_mismatch",
          "the preview must retain the exact problem applicability, ordered targets, and registered coupling domain",
          "/preview/core"));
    }
    const bool applicability_narrowing =
        std::all_of(
            value.core.applicability.scheduler_optimizer_pairs.begin(),
            value.core.applicability.scheduler_optimizer_pairs.end(),
            [&](const SchedulerConstraintPairV1& pair) {
              return contains_exact(
                  manifest.optimizer_constraint_applicability
                      .scheduler_optimizer_pairs,
                  pair);
            }) &&
        std::all_of(
            value.core.applicability.timing_conventions.begin(),
            value.core.applicability.timing_conventions.end(),
            [&](TimingConvention timing) {
              return contains_exact(
                  manifest.optimizer_constraint_applicability
                      .timing_conventions,
                  timing);
            });
    if (!applicability_narrowing ||
        (!preview_policies_allowed(
             value.policies,
             manifest.scientific_construction_policy_schema) &&
         !cp09_compatibility_preview_policies(manifest, value.policies))) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.preview_registration_ceiling_mismatch",
          "preview applicability and policies must remain inside the registered scientific contract",
          "/preview"));
    }
    std::unordered_set<std::string> scope;
    for (const QueueId& target : value.construction_target_scope) {
      const bool is_problem_queue = std::any_of(
          problem.queues().begin(), problem.queues().end(),
          [&](const PortableQueueEntryV1& queue) {
            return queue.queue_id == target;
          });
      if (!is_problem_queue || !scope.insert(stable_key(target)).second) {
        return Result<PlugDescriptorPreview>::failure(boundary_error(
            "c16.invalid_construction_target_scope",
            "construction target scope must be a duplicate-free subset of the problem queue catalog",
            "/preview/construction_target_scope"));
      }
    }
    if (value.construction_target_scope.empty() ||
        !std::all_of(targets.begin(), targets.end(),
                     [&](const QueueId& target) {
                       return scope.contains(stable_key(target));
                     })) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.incomplete_construction_target_scope",
          "construction target scope must contain every deployed target",
          "/preview/construction_target_scope"));
    }
    std::optional<BigNat> required_search_states;
    if (!artifact::detail::checked_required_optimizer_search_states_v1(
            value.construction_prerequisites, required_search_states)) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.preview_prerequisite_arithmetic_failure",
          "computing the preview's total optimizer search-state requirement "
          "failed",
          "/preview/construction_prerequisites"));
    }
    const auto assumption_allowed = [&](const ArrivalAssumptionV1& assumption) {
      return contains_exact(prerequisite.arrival_assumptions, assumption);
    };
    if (!std::all_of(value.core.arrival_assumptions.begin(),
                     value.core.arrival_assumptions.end(),
                     assumption_allowed) ||
        !std::all_of(value.construction_prerequisites.arrival.begin(),
                     value.construction_prerequisites.arrival.end(),
                     [&](const ArrivalAssumptionV1& assumption) {
                       return assumption.use ==
                                  ArrivalCapabilityUseV1::construction &&
                              assumption_allowed(assumption);
                     }) ||
        !grant_covers(representation_budget.exact_optimizer_calls,
                      value.construction_prerequisites
                          .required_optimizer_calls) ||
        !grant_covers(representation_budget.optimizer_search_states,
                      required_search_states) ||
        !grant_covers(representation_budget.configured_generator_draws,
                      value.construction_prerequisites
                          .required_generator_draws)) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.preview_prerequisite_mismatch",
          "preview arrival and work prerequisites must be registered construction requirements covered by the budget",
          "/preview/construction_prerequisites"));
    }
    if (manifest.producer_mode ==
            ProducerModeV1::local_executable_builder &&
        !std::all_of(
            value.construction_prerequisites.arrival.begin(),
            value.construction_prerequisites.arrival.end(),
            [&](const ArrivalAssumptionV1& assumption) {
              return local_arrival_prerequisite_is_portable(
                  problem.configured_arrival(), assumption);
            })) {
      return Result<PlugDescriptorPreview>::failure(boundary_error(
          "c16.local_builder_arrival_not_reconstructible",
          "the selected construction needs process-local arrival access; use an in-process builder",
          "/preview/construction_prerequisites/arrival"));
    }
    return preview;
  } catch (const std::bad_alloc&) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.preview_allocation_failure",
        "provider preview construction exhausted memory"));
  } catch (const std::exception&) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.preview_exception",
        "provider preview construction raised an exception"));
  } catch (...) {
    return Result<PlugDescriptorPreview>::failure(boundary_error(
        "c16.preview_unknown_exception",
        "provider preview construction raised an unknown exception"));
  }
}

ProviderExecutionOutcome execute_surrogate_provider(
    const SurrogateProvider& provider, const SurrogateBuildRequest& request,
    BuildExecutionContext& context,
    const ProviderExecutionControlsV1& controls) {
  if (!provider.is_statically_registered()) {
    return execution_failure(
        "c16.unregistered_provider_handle",
        "provider execution requires a provider selected from the immutable production registry");
  }
  auto bindings =
      artifact::detail::verify_request_bindings_v1(request,
                                                   provider.manifest());
  if (!bindings) return execution_failure(bindings.error().code,
                                           bindings.error().message);
  if (context.provider_identity() != provider.identity() ||
      context.manifest_digest() !=
          provider.manifest().value().manifest_digest ||
      context.request_digest() != request.request_digest() ||
      context.build_identity() != request.build_identity_digest()) {
    return execution_failure(
        "c16.foreign_build_execution_context",
        "the build execution context does not belong to this exact request");
  }
  if (const ConstructionExactQueryServices* exact =
          context.exact_query_services();
      exact != nullptr) {
    auto consumed =
        detail::ConstructionExactQueryBindingAccess::calls_consumed(*exact);
    if (!consumed || !consumed.value().is_zero()) {
      return execution_failure(
          "c16.execution_context_exact_service_not_cold",
          "provider dispatch requires an active exact-query service with zero pre-dispatch calls");
    }
  }
  if (!context.begin_provider_execution()) {
    return execution_failure(
        "c16.repeated_provider_execution",
        "one build execution context may dispatch its bound provider only once");
  }
  try {
    ProviderProducerV1 producer = provider.producer();
    ProviderExecutionOutcome outcome = std::visit(
        [&](const auto& route) -> ProviderExecutionOutcome {
          using Route = std::decay_t<decltype(route)>;
          if constexpr (std::is_same_v<Route, InlineImmediateProducerV1>) {
            return route.invoke(request);
          } else if constexpr (std::is_same_v<Route, InProcessBuilderV1>) {
            return route.invoke(request, context);
          } else {
            return run_local_surrogate_builder(route.executable, request,
                                               context, controls);
          }
        },
        producer);
    if (auto* completed =
            std::get_if<CompletedProviderExecution>(&outcome)) {
      const std::size_t maximum = std::min(
          kSurrogateBuildProtocolV1MaximumResultBytes,
          provider.manifest().value().transport_limits.maximum_result_bytes);
      if (completed->bytes.size() > maximum) {
        return execution_failure(
            "c16.provider_result_too_large",
            "the completed provider bytes exceed the effective result cap");
      }
    }
    return outcome;
  } catch (const std::bad_alloc&) {
    return execution_failure("c16.provider_execution_allocation_failure",
                             "provider execution exhausted memory");
  } catch (const std::exception&) {
    return execution_failure("c16.provider_execution_exception",
                             "provider execution raised an exception");
  } catch (...) {
    return execution_failure("c16.provider_execution_unknown_exception",
                             "provider execution raised an unknown exception");
  }
}

Result<ValidatedSurrogatePlug> materialize_and_validate_surrogate_plug(
    const PortablePlugPayload& payload,
    const ValidatedSurrogateArtifact& artifact,
    const AcceptedCapabilityContract& accepted_contract) {
  const SurrogateArtifactV1& source = artifact.value();
  const ArtifactValidationBindingsV1& bindings =
      artifact.validation_bindings();
  const PortablePayloadContextV1& context = payload_context(payload);
  std::optional<Digest256> accepted_selection_digest;
  for (const MetricRequirementClause& clause :
       accepted_contract.requirements().clauses()) {
    if (!clause.origin.context) {
      return Result<ValidatedSurrogatePlug>::failure(boundary_error(
          "c16.accepted_selection_context_missing",
          "every accepted metric clause must retain its immutable analysis selection context",
          "/materialization/accepted_contract/requirements"));
    }
    auto digest = artifact::detail::canonical_analysis_selection_digest_v1(
        clause.origin.context->selection);
    if (!digest) {
      return Result<ValidatedSurrogatePlug>::failure(digest.error());
    }
    if (accepted_selection_digest.has_value() &&
        *accepted_selection_digest != digest.value()) {
      return Result<ValidatedSurrogatePlug>::failure(boundary_error(
          "c16.inconsistent_accepted_selection_context",
          "accepted metric clauses do not share one exact analysis selection",
          "/materialization/accepted_contract/requirements"));
    }
    accepted_selection_digest = std::move(digest).value();
  }
  if (!accepted_selection_digest.has_value() ||
      bindings.analysis_selection_digest != *accepted_selection_digest) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.analysis_selection_binding_mismatch",
        "the C15 artifact lineage and accepted contract must bind one exact analysis selection",
        "/materialization/analysis_selection"));
  }
  if (bindings.accepted_contract_digest !=
          accepted_contract.contract_digest() ||
      bindings.requirements_digest !=
          accepted_contract.requirements_digest() ||
      bindings.arrival_capabilities_digest !=
          accepted_contract.arrival_capabilities_digest() ||
      bindings.preview_digest != accepted_contract.preview_digest() ||
      bindings.parameter_digest != accepted_contract.parameter_digest() ||
      bindings.budget_digest != accepted_contract.budget_digest() ||
      bindings.structural_manifest_digest !=
          accepted_contract.structural_manifest().canonical_digest() ||
      bindings.provider != accepted_contract.provider() ||
      bindings.construction_method !=
          accepted_contract.construction_method() ||
      bindings.producer_mode != accepted_contract.producer_mode() ||
      bindings.semantic != accepted_contract.semantic() ||
      bindings.runtime_access != accepted_contract.runtime_access() ||
      bindings.payload_class != accepted_contract.payload_class() ||
      bindings.request_digest != source.request_digest ||
      context.build_identity_digest != bindings.build_identity_digest ||
      context.request_digest != bindings.request_digest ||
      context.framework_problem_view_digest !=
          bindings.framework_problem_view_digest ||
      source.deployed_descriptor != accepted_contract.descriptor_core() ||
      context.payload_class != source.payload_class ||
      context.semantic != source.deployed_semantic ||
      context.runtime_access != source.runtime_access ||
      context.ordered_deployed_targets !=
          source.deployed_descriptor.deployed_targets ||
      context.payload_identity != source.payload_identity ||
      context.payload_digest != source.payload_digest ||
      context.structural_manifest_echo != source.structural_manifest_echo ||
      context.realized_metric_bindings != source.realized_metric_bindings ||
      context.family_evidence != source.family_evidence ||
      context.scoped_evidence != source.scoped_evidence) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.materialization_binding_mismatch",
        "portable payload, validated artifact, and accepted contract do not share one exact payload, evidence, and scientific lineage",
        "/materialization"));
  }

  auto authoritative_payload = adapt_portable_payload(artifact);
  if (!authoritative_payload) {
    return Result<ValidatedSurrogatePlug>::failure(
        authoritative_payload.error());
  }
  if (authoritative_payload.value().value() != payload.value()) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.portable_payload_body_mismatch",
        "the supplied portable payload body must equal C15's exact "
        "adaptation of the validated artifact",
        "/materialization/payload"));
  }

  if (const auto* response =
          std::get_if<PortableThreeBinScalarResponseV1>(&payload.value())) {
    if (context.ordered_deployed_targets.size() != 1U ||
        response->deployed_target != context.ordered_deployed_targets.front() ||
        context.semantic != SemanticTagV1::scalar_backlog_response ||
        context.runtime_access !=
            RuntimeAccessTagV1::finite_parameter_analytic_family) {
      return Result<ValidatedSurrogatePlug>::failure(boundary_error(
          "c16.invalid_three_bin_runtime_tuple",
          "a three-bin response is a phase-free singleton scalar response with finite-parameter analytic access",
          "/materialization/payload"));
    }
  }
  if (const auto* response =
          std::get_if<PortableFinitePrefixConstantTailResponseV1>(
              &payload.value())) {
    if (context.ordered_deployed_targets.size() != 1U ||
        response->deployed_target != context.ordered_deployed_targets.front() ||
        context.semantic != SemanticTagV1::scalar_backlog_response ||
        context.runtime_access !=
            RuntimeAccessTagV1::finite_parameter_analytic_family ||
        response->service_by_level.size() < 3U ||
        response->service_by_level.size() > 6U ||
        response->constant_tail_from != response->response_cutoff + BigNat{1U} ||
        response->service_by_level.size() !=
            static_cast<std::size_t>(
                response->response_cutoff.value().convert_to<unsigned>()) +
                1U ||
        source.deployed_descriptor.tail.kind !=
            TailRepresentationKindV1::constant_response ||
        source.deployed_descriptor.tail.boundary !=
            std::optional<BigNat>{response->constant_tail_from}) {
      return Result<ValidatedSurrogatePlug>::failure(boundary_error(
          "c16.invalid_finite_prefix_constant_tail_runtime_tuple",
          "a finite-prefix constant-tail response is a phase-free singleton "
          "scalar response with one exact level vector and its K+1 tail",
          "/materialization/payload"));
    }
  }

  auto id = SurrogateId::parse(source.provider.provider_id);
  auto version = SurrogateVersion::parse(source.provider.provider_version);
  if (!id) return Result<ValidatedSurrogatePlug>::failure(id.error());
  if (!version) return Result<ValidatedSurrogatePlug>::failure(version.error());
  auto provider = lookup_surrogate_provider(
      id.value(), std::optional<SurrogateVersion>{version.value()});
  if (!provider) {
    return Result<ValidatedSurrogatePlug>::failure(provider.error());
  }
  if (!provider.value().is_statically_registered()) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.unregistered_provider_handle",
        "runtime materialization requires a provider selected from the immutable production registry",
        "/materialization/provider"));
  }
  const ValidatedProviderManifest& current_manifest =
      provider.value().manifest();
  if (current_manifest.value().provider != bindings.provider ||
      current_manifest.value().parameter_schema_version !=
          bindings.parameter_schema_version ||
      current_manifest.scientific_contract_digest().value() !=
          bindings.provider_scientific_contract_digest ||
      current_manifest.value().construction_method !=
          bindings.construction_method ||
      current_manifest.value().producer_mode != bindings.producer_mode ||
      current_manifest.value().deployed_semantic_tag != bindings.semantic ||
      current_manifest.value().runtime_access_tag != bindings.runtime_access ||
      current_manifest.value().payload_class != bindings.payload_class) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.current_provider_contract_mismatch",
        "the currently registered provider version differs from the scientific contract validated by C15",
        "/materialization/provider"));
  }
  try {
    RuntimePlugMaterializerV1 materializer =
        provider.value().materializer();
    auto candidate = materializer(payload, artifact, accepted_contract);
    if (!candidate) {
      return Result<ValidatedSurrogatePlug>::failure(candidate.error());
    }
    RuntimePlugCandidateV1 value = std::move(candidate).value();
    if (value.descriptor.core != source.deployed_descriptor ||
        semantic_tag_v1(value.plug) != source.deployed_semantic ||
        runtime_access_tag_v1(kernel_access_v1(value.plug)) !=
            source.runtime_access ||
        portable_source_v1(value.plug).value() != payload.value()) {
      return Result<ValidatedSurrogatePlug>::failure(boundary_error(
          "c16.runtime_adapter_changed_artifact",
          "the registered runtime adapter changed the validated semantic, access, descriptor, or portable payload",
          "/materialization/adapter"));
    }
    auto descriptor = validate_plug_descriptor_v1(value.descriptor);
    if (!descriptor) {
      return Result<ValidatedSurrogatePlug>::failure(descriptor.error());
    }
    auto operations = validate_operation_carriers(value.descriptor,
                                                  value.plug);
    if (!operations) {
      return Result<ValidatedSurrogatePlug>::failure(operations.error());
    }
    return Result<ValidatedSurrogatePlug>::success(ValidatedSurrogatePlug(
        std::move(value.descriptor), std::move(value.plug), bindings,
        accepted_contract.contract_digest(),
        accepted_contract.structural_manifest()));
  } catch (const std::bad_alloc&) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.materialization_allocation_failure",
        "runtime plug materialization exhausted memory"));
  } catch (const std::exception&) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.materializer_exception",
        "the registered runtime materializer raised an exception"));
  } catch (...) {
    return Result<ValidatedSurrogatePlug>::failure(boundary_error(
        "c16.materializer_unknown_exception",
        "the registered runtime materializer raised an unknown exception"));
  }
}

Result<KernelAccess> validate_kernel_access(
    const ValidatedSurrogatePlug& plug) {
  auto descriptor_shape = validate_plug_descriptor_v1(plug.descriptor());
  if (!descriptor_shape) {
    return Result<KernelAccess>::failure(descriptor_shape.error());
  }
  auto operations = validate_operation_carriers(plug.descriptor(),
                                                plug.plug_);
  if (!operations) {
    return Result<KernelAccess>::failure(operations.error());
  }
  const KernelAccess& access = kernel_access_v1(plug.plug_);
  auto access_shape = validate_kernel_access_shape_v1(access);
  if (!access_shape) {
    return Result<KernelAccess>::failure(access_shape.error());
  }
  if (runtime_access_tag_v1(access) != plug.descriptor().core.runtime_access) {
    return Result<KernelAccess>::failure(boundary_error(
        "c16.kernel_access_tag_mismatch",
        "the active kernel access alternative differs from the descriptor tag",
        "/plug/access"));
  }
  const PortablePlugPayloadValueV1& source =
      portable_source_v1(plug.plug_).value();
  const auto marks_match = [&](std::span<const CodecIdentityV1> codecs) {
    if (codecs.size() != plug.descriptor().marks.size()) return false;
    for (std::size_t index = 0U; index < codecs.size(); ++index) {
      if (codecs[index] !=
          plug.descriptor().marks[index].c14_mark.codec) {
        return false;
      }
    }
    return true;
  };
  auto cross_binding = std::visit(
      [&](const auto& active) -> Result<void> {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::is_same_v<Active, FiniteEnumeratedRowAccess> ||
                      std::is_same_v<Active, SparseRowAccess> ||
                      std::is_same_v<
                          Active, NormalizedConditionalSamplerAccess>) {
          const TransitionKernelAccessShapeV1& shape = active.shape();
          if (!plug.descriptor().transition_state_schema.has_value() ||
              shape.conditioning_state_codec !=
                  plug.descriptor()
                      .transition_state_schema->conditioning_state_codec ||
              shape.successor_state_codec !=
                  plug.descriptor()
                      .transition_state_schema->successor_state_codec ||
              !marks_match(shape.ordered_mark_codecs)) {
            return Result<void>::failure(boundary_error(
                "c16.transition_access_descriptor_mismatch",
                "row and sampler conditioning, successor, and mark codecs must exactly equal the declared aggregate transition shape",
                "/plug/access/shape"));
          }
          const bool temporal = plug.descriptor().event_contract.has_value();
          if (shape.event_generator_identity.has_value() != temporal ||
              (temporal &&
               (shape.event_generator_identity->operation_version != 1U ||
                shape.event_generator_identity->operation_id.label() !=
                    plug.descriptor()
                        .event_contract->event_generator_operation
                        .operation_id.label() ||
                shape.event_generator_identity->operation_version !=
                    plug.descriptor()
                        .event_contract->event_generator_operation
                        .operation_version))) {
            return Result<void>::failure(boundary_error(
                "c16.transition_event_generator_identity_mismatch",
                "a temporal row or sampler must bind exactly one version-1 event-generator identity, and a non-temporal row must not claim one",
                "/plug/access/shape/event_generator_identity"));
          }
        } else if constexpr (std::is_same_v<Active,
                                            AnalyticTransformAccess>) {
          if (plug.descriptor().state_fields.empty() ||
              !contains_codec(plug.descriptor().state_fields,
                              active.shape().argument_codec) ||
              (!plug.descriptor().marks.empty() &&
               std::none_of(
                   plug.descriptor().marks.begin(),
                   plug.descriptor().marks.end(),
                   [&](const RuntimeMarkDescriptorV1& mark) {
                     return mark.c14_mark.codec ==
                            active.shape().result_codec;
                   }))) {
            return Result<void>::failure(boundary_error(
                "c16.transform_codec_descriptor_mismatch",
                "analytic transform arguments must use a declared state codec and marked results must use a declared output codec",
                "/plug/access/shape"));
          }
          std::vector<RuntimeDecoderIdV1> accepted_decoders;
          for (const RuntimeMarkDescriptorV1& mark :
               plug.descriptor().marks) {
            if (mark.c14_mark.codec == active.shape().result_codec) {
              accepted_decoders.push_back(mark.decoder_id);
            }
          }
          std::sort(accepted_decoders.begin(), accepted_decoders.end());
          accepted_decoders.erase(
              std::unique(accepted_decoders.begin(),
                          accepted_decoders.end()),
              accepted_decoders.end());
          if (!std::equal(accepted_decoders.begin(),
                          accepted_decoders.end(),
                          active.decoder_ids().begin(),
                          active.decoder_ids().end())) {
            return Result<void>::failure(boundary_error(
                "c16.transform_decoder_domain_mismatch",
                "analytic transform decoder identities must exactly equal the descriptor's closed decoder set for the result codec",
                "/plug/access/decoder_ids"));
          }
        } else if constexpr (
            std::is_same_v<Active,
                           FiniteParameterAnalyticFamilyAccess>) {
          const auto backlog = std::find_if(
              plug.descriptor().state_fields.begin(),
              plug.descriptor().state_fields.end(),
              [](const RuntimeStateFieldV1& field) {
                return field.c14_field.kind ==
                       StateFieldKindV1::target_backlog;
              });
          if (backlog == plug.descriptor().state_fields.end() ||
              active.shape().argument_codec != backlog->c14_field.codec ||
              active.family().domain_schema != active.shape().argument_codec) {
            return Result<void>::failure(boundary_error(
                "c16.analytic_family_domain_mismatch",
                "finite-family access must use the declared target-backlog domain",
                "/plug/access/shape"));
          }
          if (std::holds_alternative<PortableThreeBinScalarResponseV1>(
                  source)) {
            const CodecIdentityV1 response_codec{
                std::string(kThreeBinServiceResponseCodecIdV1), 1U};
            if (active.family().family_id !=
                    kThreeBinResponseFamilyIdV1 ||
                active.family().family_version != 1U ||
                active.family().parameter_schema !=
                    CodecIdentityV1{
                        std::string(kThreeBinResponseParameterSchemaIdV1),
                        1U} ||
                active.shape().response_codec != response_codec) {
              return Result<void>::failure(boundary_error(
                  "c16.three_bin_family_schema_mismatch",
                  "three-bin access must expose the fixed backlog-to-service-response family schema",
                  "/plug/access/family"));
            }
          } else if (std::holds_alternative<
                         PortableFinitePrefixConstantTailResponseV1>(source)) {
            const CodecIdentityV1 response_codec{
                std::string(
                    kFinitePrefixConstantTailServiceResponseCodecIdV1),
                1U};
            if (active.family().family_id !=
                    kFinitePrefixConstantTailResponseFamilyIdV1 ||
                active.family().family_version != 1U ||
                active.family().parameter_schema !=
                    CodecIdentityV1{
                        std::string(
                            kFinitePrefixConstantTailResponseParameterSchemaIdV1),
                        1U} ||
                active.shape().response_codec != response_codec) {
              return Result<void>::failure(boundary_error(
                  "c16.finite_prefix_constant_tail_family_schema_mismatch",
                  "finite-prefix constant-tail access must expose the "
                  "registered backlog-to-service-response family schema",
                  "/plug/access/family"));
            }
          } else if (const auto* analytic =
                         std::get_if<PortableFiniteParameterAnalyticDataV1>(
                             &source)) {
            const auto& record = analytic->normalized_record;
            const CodecIdentityV1 parameter_schema{
                record.parameter_schema_id,
                record.parameter_schema_version};
            const CodecIdentityV1 domain_schema{record.domain_schema_id,
                                                record.domain_schema_version};
            const CodecIdentityV1 response_schema{
                record.registered_family_id + ".response",
                record.registered_family_version};
            if (active.family().family_id != record.registered_family_id ||
                active.family().family_version !=
                    record.registered_family_version ||
                active.family().parameter_schema != parameter_schema ||
                active.family().domain_schema != domain_schema ||
                active.shape().response_codec != response_schema) {
              return Result<void>::failure(boundary_error(
                  "c16.registered_analytic_family_mismatch",
                  "analytic family identity and codecs must exactly match the validated portable family payload",
                  "/plug/access/family"));
            }
          } else {
            return Result<void>::failure(boundary_error(
                "c16.analytic_family_payload_mismatch",
                "finite-family access requires three-bin or registered analytic-family payload data",
                "/plug/access"));
          }
        } else if constexpr (
            std::is_same_v<Active,
                           ProceduralResidenceGeneratorAccess>) {
          if (!plug.descriptor().event_contract.has_value() ||
              (plug.descriptor().core.semantic !=
                   SemanticTagV1::romr_residence_word_law &&
               plug.descriptor().core.semantic !=
                   SemanticTagV1::stopped_path_law)) {
            return Result<void>::failure(boundary_error(
                "c16.residence_access_without_event_semantics",
                "procedural residence access requires declared residence or stopped-event semantics",
                "/plug/access"));
          }
          const TemporalEventContractV1& event =
              *plug.descriptor().event_contract;
          const ResidenceGeneratorAccessShapeV1& shape = active.shape();
          if (shape.entrance_state_codec != event.entrance_space ||
              shape.continuation_state_codec != event.continuation_space ||
              shape.terminal_state_codec != event.terminal_space ||
              shape.reentry_state_codec != event.reentry_space ||
              !marks_match(shape.ordered_mark_codecs) ||
              active.operation_identity().operation_id.label() !=
                  event.event_generator_operation.operation_id.label() ||
              active.operation_identity().operation_version !=
                  event.event_generator_operation.operation_version ||
              active.operation_identity().event_schema !=
                  event.stopping_indicator) {
            return Result<void>::failure(boundary_error(
                "c16.residence_event_cross_binding_mismatch",
                "residence generator identity, boundary spaces, event schema, and marks must match the event descriptor",
                "/plug/access"));
          }
        } else {
          static_assert(std::is_same_v<Active, RawDirectDecoderAccess>);
          if (plug.descriptor().core.semantic !=
                  SemanticTagV1::direct_metric_decoder ||
              !std::holds_alternative<PortableDirectMetricPayloadV1>(
                  source)) {
            return Result<void>::failure(boundary_error(
                "c16.raw_direct_access_semantic_mismatch",
                "raw direct access is valid only for a validated direct-metric payload",
                "/plug/access"));
          }
          const auto& domain = active.domain();
          const auto& values =
              std::get<PortableDirectMetricPayloadV1>(source)
                  .normalized_record.values;
          const auto& clauses =
              plug.accepted_structural_manifest_.clauses();
          if (values.size() != 1U || clauses.size() != 1U) {
            return Result<void>::failure(boundary_error(
                "c16.direct_decoder_domain_not_singleton",
                "one raw direct decoder exposes exactly one accepted metric value and clause domain",
                "/plug/access/domain"));
          }
          bool all_values_bound = true;
          for (const DirectMetricValueV1& value : values) {
            const auto clause = std::find_if(
                clauses.begin(), clauses.end(),
                [&](const MetricSupportClauseV1& candidate) {
                  return candidate.clause_id == value.metric_clause_id;
                });
            if (clause ==
                    clauses.end() ||
                clause->ordered_targets != value.ordered_targets ||
                clause->parameter_domain !=
                    MetricParameterDomainV1{domain.metric_domain}) {
              all_values_bound = false;
              break;
            }
            auto ordered_target_digest =
                artifact::detail::canonical_ordered_metric_targets_digest_v1(
                    value.ordered_targets);
            if (!ordered_target_digest) {
              return Result<void>::failure(ordered_target_digest.error());
            }
            if (value.normalized_metric_request_digest !=
                    domain.canonical_request_domain_digest ||
                value.request_digest != domain.build_request_digest ||
                value.target_selection_digest !=
                    domain.target_selection_digest ||
                ordered_target_digest.value() !=
                    domain.ordered_target_digest ||
                value.configured_arrival_digest !=
                    domain.configured_arrival_digest ||
                value.accepted_contract_digest !=
                    domain.accepted_contract_digest) {
              all_values_bound = false;
              break;
            }
          }
          if (!all_values_bound ||
              domain.build_request_digest !=
                  plug.artifact_bindings_.request_digest ||
              domain.selection_digest !=
                  plug.artifact_bindings_.analysis_selection_digest ||
              domain.accepted_contract_digest !=
                  plug.accepted_contract_digest_ ||
              domain.request_codec !=
                  CodecIdentityV1{"mwperf.c16.direct_metric_request", 1U} ||
              domain.result_codec !=
                  CodecIdentityV1{"mwperf.c16.direct_metric_value", 1U}) {
            return Result<void>::failure(boundary_error(
                "c16.direct_decoder_payload_domain_mismatch",
                "every direct payload value must bind the accepted decoder parameters, exact C15 build request, target-selection, ordered targets, analysis selection, configured arrival, accepted contract, and fixed request/result codecs",
                "/plug/access/domain"));
          }
        }
        return Result<void>::success();
      },
      access);
  if (!cross_binding) {
    return Result<KernelAccess>::failure(cross_binding.error());
  }
  return Result<KernelAccess>::success(access);
}

Result<ValidatedSurrogateBuildReport> validate_surrogate_build_report(
    const SurrogateBuildResult& result,
    const SurrogateBuildRequest& request,
    const ConstructionBudget& budget) {
  if (budget != request.construction_budget()) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.foreign_construction_budget",
        "build-report validation requires the exact request-bound budget",
        "/construction_budget"));
  }
  const ResultEnvelopeV1& envelope = result_envelope(result);
  if (envelope.request_digest != request.request_digest().value() ||
      envelope.provider != request.provider_binding().provider) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.build_report_result_binding_mismatch",
        "the parsed result envelope does not belong to the supplied request",
        "/result/envelope"));
  }
  auto id = SurrogateId::parse(envelope.provider.provider_id);
  auto version = SurrogateVersion::parse(envelope.provider.provider_version);
  if (!id) return Result<ValidatedSurrogateBuildReport>::failure(id.error());
  if (!version) {
    return Result<ValidatedSurrogateBuildReport>::failure(version.error());
  }
  auto provider = lookup_surrogate_provider(
      id.value(), std::optional<SurrogateVersion>{version.value()});
  if (!provider) {
    return Result<ValidatedSurrogateBuildReport>::failure(provider.error());
  }
  auto request_binding = artifact::detail::verify_request_bindings_v1(
      request, provider.value().manifest());
  if (!request_binding) {
    return Result<ValidatedSurrogateBuildReport>::failure(
        request_binding.error());
  }
  auto common = artifact::detail::validate_common_build_report_v1(
      envelope.build_report, request);
  if (!common) {
    return Result<ValidatedSurrogateBuildReport>::failure(common.error());
  }
  // Unavailable and failed scientific outcomes may terminate before the
  // accepted construction method performs its successful-build minimum work.
  // Their applicable counters remain fully checked against the request budget
  // above, but successful-construction lower bounds apply only to Built.
  if (!std::holds_alternative<BuiltSurrogateResultV1>(result)) {
    return Result<ValidatedSurrogateBuildReport>::success(
        ValidatedSurrogateBuildReport(envelope.build_report));
  }
  const ConstructionPrerequisitesV1& required =
      request.accepted_capability_contract().construction_prerequisites;
  auto optimizer = require_common_minimum(
      envelope.build_report.optimizer_calls,
      required.required_optimizer_calls, "optimizer-call");
  if (!optimizer) {
    return Result<ValidatedSurrogateBuildReport>::failure(optimizer.error());
  }
  std::optional<BigNat> minimum_search_states;
  try {
    if (required.required_search_states_per_call.has_value()) {
      minimum_search_states =
          *required.required_search_states_per_call *
          envelope.build_report.optimizer_calls.used;
    }
  } catch (const std::exception&) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.work_counter_arithmetic_failure",
        "computing the exact per-call optimizer search-state minimum failed",
        "/result/envelope/build_report/optimizer_search_states"));
  } catch (...) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.work_counter_arithmetic_failure",
        "computing the exact per-call optimizer search-state minimum failed",
        "/result/envelope/build_report/optimizer_search_states"));
  }
  auto states = require_common_minimum(
      envelope.build_report.optimizer_search_states,
      minimum_search_states, "optimizer-search-state");
  if (!states) {
    return Result<ValidatedSurrogateBuildReport>::failure(states.error());
  }
  auto draws = require_common_minimum(
      envelope.build_report.configured_generator_draws,
      required.required_generator_draws,
      "configured-generator-draw");
  if (!draws) {
    return Result<ValidatedSurrogateBuildReport>::failure(draws.error());
  }
  for (const RequiredMethodCounterV1& required_counter :
       provider.value().manifest().value().required_method_counters) {
    const auto found = std::lower_bound(
        envelope.build_report.optional_method_counters.begin(),
        envelope.build_report.optional_method_counters.end(),
        required_counter.name,
        [](const NamedPortableValueV1& value, const std::string& name) {
          return value.name < name;
        });
    if (found == envelope.build_report.optional_method_counters.end() ||
        found->name != required_counter.name) {
      return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
          "c16.required_method_counter_missing",
          "the provider build report omitted a manifest-required method counter",
          "/result/envelope/build_report/optional_method_counters"));
    }
    auto value = method_counter_value(*found);
    if (!value) {
      return Result<ValidatedSurrogateBuildReport>::failure(value.error());
    }
    if (value.value() < required_counter.minimum_used) {
      return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
          "c16.required_method_counter_underreported",
          "a required provider method counter is below its manifest-bound minimum",
          "/result/envelope/build_report/optional_method_counters"));
    }
  }
  return Result<ValidatedSurrogateBuildReport>::success(
      ValidatedSurrogateBuildReport(envelope.build_report));
}

Result<ValidatedSurrogateBuildReport> validate_surrogate_build_report_v2(
    const ResultEnvelopeV2& envelope, const ProviderResultKindV2 kind,
    const SurrogateBuildRequest& request,
    const ConstructionBudget& budget) {
  if (envelope.protocol_version != 2U) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c30.result_protocol_version",
        "provider-result-v2 report validation requires protocol version two",
        "/result/envelope/protocol_version"));
  }
  if (budget != request.construction_budget()) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.foreign_construction_budget",
        "build-report validation requires the exact request-bound budget",
        "/construction_budget"));
  }
  if (envelope.request_digest != request.request_digest().value() ||
      envelope.provider != request.provider_binding().provider) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.build_report_result_binding_mismatch",
        "the parsed result envelope does not belong to the supplied request",
        "/result/envelope"));
  }
  auto id = SurrogateId::parse(envelope.provider.provider_id);
  auto version = SurrogateVersion::parse(envelope.provider.provider_version);
  if (!id) return Result<ValidatedSurrogateBuildReport>::failure(id.error());
  if (!version) {
    return Result<ValidatedSurrogateBuildReport>::failure(version.error());
  }
  auto provider = lookup_surrogate_provider(
      id.value(), std::optional<SurrogateVersion>{version.value()});
  if (!provider) {
    return Result<ValidatedSurrogateBuildReport>::failure(provider.error());
  }
  if (provider.value().result_protocol_version() != 2U) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c30.provider_result_protocol_mismatch",
        "the selected provider registration does not authorize result protocol two",
        "/result/envelope/protocol_version"));
  }
  auto request_binding = artifact::detail::verify_request_bindings_v1(
      request, provider.value().manifest());
  if (!request_binding) {
    return Result<ValidatedSurrogateBuildReport>::failure(
        request_binding.error());
  }
  auto common = artifact::detail::validate_common_build_report_v1(
      envelope.build_report, request);
  if (!common) {
    return Result<ValidatedSurrogateBuildReport>::failure(common.error());
  }
  if (kind != ProviderResultKindV2::built) {
    return Result<ValidatedSurrogateBuildReport>::success(
        ValidatedSurrogateBuildReport(envelope.build_report));
  }

  const ConstructionPrerequisitesV1& required =
      request.accepted_capability_contract().construction_prerequisites;
  auto optimizer = require_common_minimum(
      envelope.build_report.optimizer_calls,
      required.required_optimizer_calls, "optimizer-call");
  if (!optimizer) {
    return Result<ValidatedSurrogateBuildReport>::failure(optimizer.error());
  }
  std::optional<BigNat> minimum_search_states;
  try {
    if (required.required_search_states_per_call.has_value()) {
      minimum_search_states =
          *required.required_search_states_per_call *
          envelope.build_report.optimizer_calls.used;
    }
  } catch (const std::exception&) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.work_counter_arithmetic_failure",
        "computing the exact per-call optimizer search-state minimum failed",
        "/result/envelope/build_report/optimizer_search_states"));
  } catch (...) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.work_counter_arithmetic_failure",
        "computing the exact per-call optimizer search-state minimum failed",
        "/result/envelope/build_report/optimizer_search_states"));
  }
  auto states = require_common_minimum(
      envelope.build_report.optimizer_search_states,
      minimum_search_states, "optimizer-search-state");
  if (!states) {
    return Result<ValidatedSurrogateBuildReport>::failure(states.error());
  }
  auto draws = require_common_minimum(
      envelope.build_report.configured_generator_draws,
      required.required_generator_draws, "configured-generator-draw");
  if (!draws) {
    return Result<ValidatedSurrogateBuildReport>::failure(draws.error());
  }
  for (const RequiredMethodCounterV1& required_counter :
       provider.value().manifest().value().required_method_counters) {
    const auto found = std::lower_bound(
        envelope.build_report.optional_method_counters.begin(),
        envelope.build_report.optional_method_counters.end(),
        required_counter.name,
        [](const NamedPortableValueV1& value, const std::string& name) {
          return value.name < name;
        });
    if (found == envelope.build_report.optional_method_counters.end() ||
        found->name != required_counter.name) {
      return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
          "c16.required_method_counter_missing",
          "the provider build report omitted a manifest-required method counter",
          "/result/envelope/build_report/optional_method_counters"));
    }
    auto value = method_counter_value(*found);
    if (!value) {
      return Result<ValidatedSurrogateBuildReport>::failure(value.error());
    }
    if (value.value() < required_counter.minimum_used) {
      return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
          "c16.required_method_counter_underreported",
          "a required provider method counter is below its manifest-bound minimum",
          "/result/envelope/build_report/optional_method_counters"));
    }
  }
  return Result<ValidatedSurrogateBuildReport>::success(
      ValidatedSurrogateBuildReport(envelope.build_report));
}

Result<ValidatedSurrogateBuildReport> validate_surrogate_build_report_v3(
    const ResultEnvelopeV3& envelope, const ProviderResultKindV2 kind,
    const SurrogateBuildRequest& request,
    const ConstructionBudget& budget) {
  if (envelope.protocol_version != 3U) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c32.result_protocol_version",
        "provider-result-v3 report validation requires protocol version "
        "three",
        "/result/envelope/protocol_version"));
  }
  if (kind == ProviderResultKindV2::built) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c32.result_v3_built_forbidden",
        "provider-result v3 has no deployable Built branch",
        "/result/kind"));
  }
  if (budget != request.construction_budget()) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.foreign_construction_budget",
        "build-report validation requires the exact request-bound budget",
        "/construction_budget"));
  }
  if (envelope.request_digest != request.request_digest().value() ||
      envelope.provider != request.provider_binding().provider) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.build_report_result_binding_mismatch",
        "the parsed result envelope does not belong to the supplied request",
        "/result/envelope"));
  }
  auto id = SurrogateId::parse(envelope.provider.provider_id);
  auto version = SurrogateVersion::parse(envelope.provider.provider_version);
  if (!id) return Result<ValidatedSurrogateBuildReport>::failure(id.error());
  if (!version) {
    return Result<ValidatedSurrogateBuildReport>::failure(version.error());
  }
  auto provider = lookup_surrogate_provider(
      id.value(), std::optional<SurrogateVersion>{version.value()});
  if (!provider) {
    return Result<ValidatedSurrogateBuildReport>::failure(provider.error());
  }
  if (provider.value().result_protocol_version() != 3U) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c32.provider_result_protocol_mismatch",
        "the selected provider registration does not authorize result "
        "protocol three",
        "/result/envelope/protocol_version"));
  }
  auto request_binding = artifact::detail::verify_request_bindings_v1(
      request, provider.value().manifest());
  if (!request_binding) {
    return Result<ValidatedSurrogateBuildReport>::failure(
        request_binding.error());
  }
  auto common = artifact::detail::validate_common_build_report_v1(
      envelope.build_report, request);
  if (!common) {
    return Result<ValidatedSurrogateBuildReport>::failure(common.error());
  }
  // Unavailable and Failed may retain a bounded partial observation.  The
  // Observed terminal is successful construction and must satisfy the same
  // minimum-work contract formerly reserved for Built artifacts.
  if (kind != ProviderResultKindV2::observed) {
    return Result<ValidatedSurrogateBuildReport>::success(
        ValidatedSurrogateBuildReport(envelope.build_report));
  }

  const ConstructionPrerequisitesV1& required =
      request.accepted_capability_contract().construction_prerequisites;
  auto optimizer = require_common_minimum(
      envelope.build_report.optimizer_calls,
      required.required_optimizer_calls, "optimizer-call");
  if (!optimizer) {
    return Result<ValidatedSurrogateBuildReport>::failure(optimizer.error());
  }
  std::optional<BigNat> minimum_search_states;
  try {
    if (required.required_search_states_per_call.has_value()) {
      minimum_search_states =
          *required.required_search_states_per_call *
          envelope.build_report.optimizer_calls.used;
    }
  } catch (const std::exception&) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.work_counter_arithmetic_failure",
        "computing the exact per-call optimizer search-state minimum failed",
        "/result/envelope/build_report/optimizer_search_states"));
  } catch (...) {
    return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
        "c16.work_counter_arithmetic_failure",
        "computing the exact per-call optimizer search-state minimum failed",
        "/result/envelope/build_report/optimizer_search_states"));
  }
  auto states = require_common_minimum(
      envelope.build_report.optimizer_search_states,
      minimum_search_states, "optimizer-search-state");
  if (!states) {
    return Result<ValidatedSurrogateBuildReport>::failure(states.error());
  }
  auto draws = require_common_minimum(
      envelope.build_report.configured_generator_draws,
      required.required_generator_draws, "configured-generator-draw");
  if (!draws) {
    return Result<ValidatedSurrogateBuildReport>::failure(draws.error());
  }
  for (const RequiredMethodCounterV1& required_counter :
       provider.value().manifest().value().required_method_counters) {
    const auto found = std::lower_bound(
        envelope.build_report.optional_method_counters.begin(),
        envelope.build_report.optional_method_counters.end(),
        required_counter.name,
        [](const NamedPortableValueV1& value, const std::string& name) {
          return value.name < name;
        });
    if (found == envelope.build_report.optional_method_counters.end() ||
        found->name != required_counter.name) {
      return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
          "c16.required_method_counter_missing",
          "the provider build report omitted a manifest-required method "
          "counter",
          "/result/envelope/build_report/optional_method_counters"));
    }
    auto value = method_counter_value(*found);
    if (!value) {
      return Result<ValidatedSurrogateBuildReport>::failure(value.error());
    }
    if (value.value() < required_counter.minimum_used) {
      return Result<ValidatedSurrogateBuildReport>::failure(boundary_error(
          "c16.required_method_counter_underreported",
          "a required provider method counter is below its manifest-bound "
          "minimum",
          "/result/envelope/build_report/optional_method_counters"));
    }
  }
  return Result<ValidatedSurrogateBuildReport>::success(
      ValidatedSurrogateBuildReport(envelope.build_report));
}

}  // namespace mwperf
