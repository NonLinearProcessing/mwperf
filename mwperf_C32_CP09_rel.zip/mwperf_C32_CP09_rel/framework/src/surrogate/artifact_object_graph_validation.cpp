#include "artifact_object_graph_validation.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

namespace mwperf::artifact::detail {
namespace {

template <typename T>
[[nodiscard]] Result<T> failure(std::string code, std::string message,
                                std::optional<std::string> path =
                                    std::nullopt) {
  return Result<T>::failure(
      Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), std::nullopt, std::move(path), {}});
}

[[nodiscard]] bool contains_kind(
    const std::span<const ArtifactReferenceKindV1> kinds,
    const ArtifactReferenceKindV1 sought) {
  return std::find(kinds.begin(), kinds.end(), sought) != kinds.end();
}

[[nodiscard]] bool contains_reference(
    const std::span<const ArtifactObjectReferenceV1> references,
    const ArtifactObjectReferenceV1& sought) {
  return std::find(references.begin(), references.end(), sought) !=
         references.end();
}

[[nodiscard]] bool contains_target(
    const std::span<const QueueId> targets, const QueueId& sought) {
  return std::find(targets.begin(), targets.end(), sought) != targets.end();
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

[[nodiscard]] std::optional<ArtifactReferenceKindV1> law_kind_for_semantic(
    const SemanticTagV1 semantic) noexcept {
  switch (semantic) {
    case SemanticTagV1::stationary_marked_edge:
      return ArtifactReferenceKindV1::stationary_marked_edge_law;
    case SemanticTagV1::staged_opportunity_flux_law:
      return ArtifactReferenceKindV1::staged_opportunity_flux_law;
    case SemanticTagV1::temporal_one_slot_continuation:
      return ArtifactReferenceKindV1::temporal_continuation_law;
    case SemanticTagV1::romr_residence_word_law:
      return ArtifactReferenceKindV1::residence_word_law;
    case SemanticTagV1::stopped_path_law:
      return ArtifactReferenceKindV1::stopped_path_law;
    case SemanticTagV1::coupled_target_schedule_law:
      return ArtifactReferenceKindV1::coupled_schedule_law;
    case SemanticTagV1::scalar_backlog_response:
    case SemanticTagV1::direct_metric_decoder:
    case SemanticTagV1::response_envelope_law: return std::nullopt;
  }
  return std::nullopt;
}

[[nodiscard]] MetricEvidenceScopeV1 raw_envelope_evidence_scope(
    const RawEnvelopeScopeV1 scope) noexcept {
  switch (scope) {
    case RawEnvelopeScopeV1::proposal_raw:
    case RawEnvelopeScopeV1::deterministic_quadrature_raw:
      return MetricEvidenceScopeV1::raw_static_proposal;
    case RawEnvelopeScopeV1::optimizer_interval_raw:
      return MetricEvidenceScopeV1::optimizer_interval_raw;
    case RawEnvelopeScopeV1::physical_response_bound:
      return MetricEvidenceScopeV1::physical_system;
  }
  return MetricEvidenceScopeV1::none;
}

[[nodiscard]] ArtifactReferenceKindV1 law_kind_for_table(
    const FiniteLawTableAlternativeV1& table) noexcept {
  return std::visit(
      [](const auto& value) {
        using Table = std::decay_t<decltype(value)>;
        if constexpr (std::same_as<Table, StationaryMarkedEdgeTableV1>) {
          return ArtifactReferenceKindV1::stationary_marked_edge_law;
        } else if constexpr (
            std::same_as<Table, StagedOpportunityFluxTableV1>) {
          return ArtifactReferenceKindV1::staged_opportunity_flux_law;
        } else if constexpr (
            std::same_as<Table, TemporalContinuationTableV1>) {
          return ArtifactReferenceKindV1::temporal_continuation_law;
        } else if constexpr (std::same_as<Table, StoppedPathTableV1>) {
          return ArtifactReferenceKindV1::stopped_path_law;
        } else if constexpr (std::same_as<Table, RomrResidenceWordTableV1>) {
          return ArtifactReferenceKindV1::residence_word_law;
        } else {
          return ArtifactReferenceKindV1::coupled_schedule_law;
        }
      },
      table);
}

[[nodiscard]] ArtifactObjectClassV1 object_class_for_table(
    const FiniteLawTableAlternativeV1& table) noexcept {
  return std::visit(
      [](const auto& value) {
        using Table = std::decay_t<decltype(value)>;
        if constexpr (std::same_as<Table, StationaryMarkedEdgeTableV1>) {
          return ArtifactObjectClassV1::stationary_marked_edge_law;
        } else if constexpr (
            std::same_as<Table, StagedOpportunityFluxTableV1>) {
          return ArtifactObjectClassV1::staged_opportunity_flux_law;
        } else if constexpr (
            std::same_as<Table, TemporalContinuationTableV1>) {
          return ArtifactObjectClassV1::temporal_continuation_law;
        } else if constexpr (std::same_as<Table, StoppedPathTableV1>) {
          return ArtifactObjectClassV1::stopped_path_law;
        } else if constexpr (std::same_as<Table, RomrResidenceWordTableV1>) {
          return ArtifactObjectClassV1::residence_word_law;
        } else {
          return ArtifactObjectClassV1::coupled_schedule_law;
        }
      },
      table);
}

[[nodiscard]] const ArtifactObjectReferenceV1& table_identity(
    const FiniteLawTableAlternativeV1& table) noexcept {
  return std::visit(
      [](const auto& value) -> const ArtifactObjectReferenceV1& {
        return value.law_id;
      },
      table);
}

[[nodiscard]] bool product_class(const ArtifactObjectClassV1 value) noexcept {
  return value == ArtifactObjectClassV1::raw_response_product ||
         value == ArtifactObjectClassV1::nominal_response_product ||
         value == ArtifactObjectClassV1::projection_center_product ||
         value == ArtifactObjectClassV1::projected_mean_product ||
         value == ArtifactObjectClassV1::recoded_response_product;
}

[[nodiscard]] bool law_or_result_class(
    const ArtifactObjectClassV1 value) noexcept {
  return value == ArtifactObjectClassV1::artifact_payload ||
         value == ArtifactObjectClassV1::response_row ||
         product_class(value) ||
         value == ArtifactObjectClassV1::stationary_marked_edge_law ||
         value == ArtifactObjectClassV1::staged_opportunity_flux_law ||
         value == ArtifactObjectClassV1::temporal_continuation_law ||
         value == ArtifactObjectClassV1::residence_word_law ||
         value == ArtifactObjectClassV1::stopped_path_law ||
         value == ArtifactObjectClassV1::coupled_schedule_law ||
         value == ArtifactObjectClassV1::direct_metric_value ||
         value == ArtifactObjectClassV1::analytic_transform_or_response;
}

[[nodiscard]] ArtifactReferenceKindV1 realized_reference_kind(
    const RealizedReferenceV1& reference) noexcept {
  return std::visit(
      [](const auto& value) {
        using Reference = std::decay_t<decltype(value)>;
        if constexpr (std::same_as<Reference, DeployedPayloadReferenceV1>) {
          return ArtifactReferenceKindV1::artifact_payload;
        } else if constexpr (
            std::same_as<Reference, DeployedResponseReferenceV1>) {
          return std::visit(
              [](const auto& product) {
                using Product = std::decay_t<decltype(product)>;
                if constexpr (std::same_as<Product, RawResponseProductRef>) {
                  return ArtifactReferenceKindV1::raw_response_product;
                } else if constexpr (
                    std::same_as<Product, NominalResponseProductRef>) {
                  return ArtifactReferenceKindV1::nominal_response_product;
                } else {
                  return ArtifactReferenceKindV1::recoded_response_product;
                }
              },
              value.selected_product);
        } else if constexpr (
            std::same_as<Reference, RawResponseProductReferenceV1>) {
          return ArtifactReferenceKindV1::raw_response_product;
        } else if constexpr (
            std::same_as<Reference, NominalResponseProductReferenceV1>) {
          return ArtifactReferenceKindV1::nominal_response_product;
        } else if constexpr (
            std::same_as<Reference, ProjectionCenterProductReferenceV1>) {
          return ArtifactReferenceKindV1::projection_center_product;
        } else if constexpr (
            std::same_as<Reference, ProjectedMeanProductReferenceV1>) {
          return ArtifactReferenceKindV1::projected_mean_product;
        } else if constexpr (
            std::same_as<Reference, RecodedResponseProductReferenceV1>) {
          return ArtifactReferenceKindV1::recoded_response_product;
        } else if constexpr (
            std::same_as<Reference, StationaryMarkedEdgeLawReferenceV1>) {
          return ArtifactReferenceKindV1::stationary_marked_edge_law;
        } else if constexpr (
            std::same_as<Reference, StagedOpportunityFluxLawReferenceV1>) {
          return ArtifactReferenceKindV1::staged_opportunity_flux_law;
        } else if constexpr (
            std::same_as<Reference, TemporalContinuationLawReferenceV1>) {
          return ArtifactReferenceKindV1::temporal_continuation_law;
        } else if constexpr (
            std::same_as<Reference, ResidenceWordLawReferenceV1>) {
          return ArtifactReferenceKindV1::residence_word_law;
        } else if constexpr (
            std::same_as<Reference, StoppedPathLawReferenceV1>) {
          return ArtifactReferenceKindV1::stopped_path_law;
        } else if constexpr (
            std::same_as<Reference, CoupledScheduleLawReferenceV1>) {
          return ArtifactReferenceKindV1::coupled_schedule_law;
        } else if constexpr (
            std::same_as<Reference, DirectMetricValueReferenceV1>) {
          return ArtifactReferenceKindV1::direct_metric_value;
        } else if constexpr (
            std::same_as<Reference, ResponseEnvelopeReferenceV1>) {
          return ArtifactReferenceKindV1::response_envelope;
        } else if constexpr (
            std::same_as<Reference, RawResponseBoundEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::raw_response_bound_evidence;
        } else if constexpr (
            std::same_as<Reference, ResponseOrderEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::response_order_evidence;
        } else if constexpr (
            std::same_as<Reference, OptimizerEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::optimizer_evidence;
        } else if constexpr (
            std::same_as<Reference, StatisticalEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::statistical_evidence;
        } else if constexpr (
            std::same_as<Reference, NumericalEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::numerical_evidence;
        } else if constexpr (
            std::same_as<Reference, CalibrationEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::calibration_evidence;
        } else if constexpr (
            std::same_as<Reference, CompressionEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::compression_evidence;
        } else if constexpr (
            std::same_as<Reference, StabilityCertificateReferenceV1>) {
          return ArtifactReferenceKindV1::stability_certificate;
        } else if constexpr (
            std::same_as<Reference,
                         ReportedValidityOrLiftEvidenceReferenceV1>) {
          return ArtifactReferenceKindV1::reported_validity_or_lift_evidence;
        } else {
          return ArtifactReferenceKindV1::physical_transfer_evidence;
        }
      },
      reference);
}

struct DeferredReference final {
  enum class Requirement : std::uint8_t {
    any,
    evidence,
    family_evidence,
    scoped_evidence,
    coefficient,
    raw_product,
    nominal_product,
    projection_center,
    projected_mean,
    recoded_product,
    product,
    comparison_domain,
  };

  ArtifactObjectReferenceV1 identity;
  Requirement requirement;
  std::string path;
};

struct ParentEdge final {
  ArtifactObjectReferenceV1 child;
  ArtifactObjectReferenceV1 parent;
  std::string path;
};

struct PurposeLeaf final {
  ArtifactObjectReferenceV1 identity;
  InternalReferencePurposeV1 purpose;
};

class GraphBuilder final {
 public:
  explicit GraphBuilder(const SurrogateArtifactV1& artifact)
      : artifact_(artifact) {}

  [[nodiscard]] Result<ValidatedArtifactObjectGraphV1> build();

 private:
  [[nodiscard]] Result<void> add_object(
      const ArtifactObjectReferenceV1& identity,
      ArtifactObjectClassV1 object_class,
      std::vector<ArtifactReferenceKindV1> compatible_kinds,
      std::vector<QueueId> ordered_targets, MetricResultScopeV1 result_scope,
      MetricEvidenceScopeV1 evidence_scope, bool evidence_object,
      const std::string& path);
  [[nodiscard]] Result<void> add_leaf(
      const ArtifactObjectReferenceV1& identity,
      ArtifactObjectClassV1 object_class, const std::string& path);
  [[nodiscard]] Result<void> add_diagnostic_id(const TypedLabel& identity,
                                               const std::string& path);
  void defer(const ArtifactObjectReferenceV1& identity,
             DeferredReference::Requirement requirement, std::string path);
  void add_parent(const ArtifactObjectReferenceV1& child,
                  const ArtifactObjectReferenceV1& parent,
                  std::string path);

  [[nodiscard]] Result<void> enumerate_payload();
  [[nodiscard]] Result<void> enumerate_three_bin(
      const ThreeBinScalarResponseV1& response, const std::string& path);
  [[nodiscard]] Result<void> enumerate_finite_prefix(
      const FinitePrefixConstantTailResponseV1& response,
      const std::string& path);
  [[nodiscard]] Result<void> enumerate_finite_table(
      const FiniteLawTablesV1& payload, const std::string& path);
  [[nodiscard]] Result<void> enumerate_family_and_auxiliary();
  [[nodiscard]] Result<void> enumerate_internal_relations();
  [[nodiscard]] Result<void> validate_realized_raw_envelope_binding(
      const RealizedMetricBindingV1& binding, std::size_t binding_index) const;
  [[nodiscard]] Result<void> resolve_deferred_references() const;
  [[nodiscard]] Result<void> validate_family_links() const;
  [[nodiscard]] Result<void> validate_response_envelope_links() const;
  [[nodiscard]] Result<void> validate_raw_bound_scoped_links() const;
  [[nodiscard]] Result<void> validate_empirical_provenance_links() const;
  [[nodiscard]] Result<void> validate_parent_dag() const;
  [[nodiscard]] Result<void> validate_evidence_dependency_dag() const;

  [[nodiscard]] const ArtifactObjectMetadataV1* find_exact(
      const ArtifactObjectReferenceV1& identity) const noexcept;
  [[nodiscard]] Result<void> add_purpose_reference(
      const ArtifactObjectReferenceV1& owner,
      const RealizedInternalReferenceV1& relation,
      const std::string& path);
  [[nodiscard]] bool purpose_accepts(
      InternalReferencePurposeV1 purpose,
      const ArtifactObjectMetadataV1& object) const noexcept;
  [[nodiscard]] bool purpose_may_declare_leaf(
      InternalReferencePurposeV1 purpose) const noexcept;

  const SurrogateArtifactV1& artifact_;
  ValidatedArtifactObjectGraphV1 graph_;
  std::vector<TypedLabel> diagnostic_ids_;
  std::vector<DeferredReference> deferred_;
  std::vector<ParentEdge> parents_;
  std::vector<ParentEdge> evidence_dependencies_;
  std::vector<PurposeLeaf> purpose_leaves_;
};

}  // namespace

const ArtifactObjectMetadataV1* ValidatedArtifactObjectGraphV1::find_exact(
    const ArtifactObjectReferenceV1& identity) const noexcept {
  const auto iterator = std::find_if(
      objects.begin(), objects.end(), [&identity](const auto& object) {
        return object.identity == identity;
      });
  return iterator == objects.end() ? nullptr : &*iterator;
}

bool ValidatedArtifactObjectGraphV1::resolves_as(
    const ArtifactObjectReferenceV1& identity,
    const ArtifactReferenceKindV1 reference_kind) const noexcept {
  const auto* object = find_exact(identity);
  return object != nullptr &&
         contains_kind(object->compatible_reference_kinds, reference_kind);
}

bool ValidatedArtifactObjectGraphV1::is_evidence(
    const ArtifactObjectReferenceV1& identity) const noexcept {
  const auto* object = find_exact(identity);
  return object != nullptr && object->evidence_object;
}

bool ValidatedArtifactObjectGraphV1::has_internal_relation(
    const ArtifactObjectReferenceV1& owner,
    const MetricRoleRelationKindV1 relation,
    const InternalReferencePurposeV1 purpose,
    const ArtifactObjectReferenceV1& referenced_object) const noexcept {
  return std::find(internal_relations.begin(), internal_relations.end(),
                   ArtifactObjectInternalRelationV1{
                       owner, relation, purpose, referenced_object}) !=
         internal_relations.end();
}

Result<ValidatedArtifactObjectGraphV1> validate_artifact_object_graph_v1(
    const SurrogateArtifactV1& artifact) {
  return GraphBuilder(artifact).build();
}

Result<void> GraphBuilder::add_object(
    const ArtifactObjectReferenceV1& identity,
    const ArtifactObjectClassV1 object_class,
    std::vector<ArtifactReferenceKindV1> compatible_kinds,
    std::vector<QueueId> ordered_targets,
    const MetricResultScopeV1 result_scope,
    const MetricEvidenceScopeV1 evidence_scope, const bool evidence_object,
    const std::string& path) {
  if (!nonzero_digest(identity.object_digest)) {
    return failure<void>(
        "c15.object_graph_empty_identity",
        "every artifact object requires a nonzero content digest",
        path);
  }
  if (std::find(diagnostic_ids_.begin(), diagnostic_ids_.end(),
                identity.object_id) != diagnostic_ids_.end()) {
    return failure<void>(
        "c15.object_graph_cross_kind_collision",
        "an artifact object ID collides with a diagnostic component ID", path);
  }
  std::sort(compatible_kinds.begin(), compatible_kinds.end(),
            [](const auto left, const auto right) {
              return static_cast<std::uint8_t>(left) <
                     static_cast<std::uint8_t>(right);
            });
  compatible_kinds.erase(
      std::unique(compatible_kinds.begin(), compatible_kinds.end()),
      compatible_kinds.end());

  const auto same_id = std::find_if(
      graph_.objects.begin(), graph_.objects.end(),
      [&identity](const ArtifactObjectMetadataV1& object) {
        return object.identity.object_id == identity.object_id;
      });
  if (same_id == graph_.objects.end()) {
    graph_.objects.push_back(ArtifactObjectMetadataV1{
        identity, object_class, std::move(compatible_kinds),
        std::move(ordered_targets), result_scope, evidence_scope,
        evidence_object});
    return Result<void>::success();
  }
  if (same_id->identity != identity || same_id->object_class != object_class ||
      same_id->compatible_reference_kinds != compatible_kinds ||
      same_id->ordered_targets != ordered_targets ||
      same_id->result_scope != result_scope ||
      same_id->evidence_scope != evidence_scope ||
      same_id->evidence_object != evidence_object) {
    return failure<void>(
        "c15.object_graph_cross_kind_collision",
        "one object ID cannot carry different digests, semantic kinds, targets, or scopes",
        path);
  }
  // Exact aliases are permitted only because a response envelope may use the
  // same immutable lower and upper response ledger.  Other duplicate record
  // constraints are owned by their closed ledger validators.
  return Result<void>::success();
}

Result<void> GraphBuilder::add_leaf(
    const ArtifactObjectReferenceV1& identity,
    const ArtifactObjectClassV1 object_class, const std::string& path) {
  return add_object(identity, object_class, {}, {},
                    MetricResultScopeV1::not_a_metric_result,
                    MetricEvidenceScopeV1::none, false, path);
}

Result<void> GraphBuilder::add_diagnostic_id(const TypedLabel& identity,
                                             const std::string& path) {
  if (std::find(diagnostic_ids_.begin(), diagnostic_ids_.end(), identity) !=
          diagnostic_ids_.end() ||
      std::any_of(graph_.objects.begin(), graph_.objects.end(),
                  [&identity](const ArtifactObjectMetadataV1& object) {
                    return object.identity.object_id == identity;
                  })) {
    return failure<void>(
        "c15.object_graph_diagnostic_id_collision",
        "diagnostic IDs must be nonempty and disjoint from every content-object ID",
        path);
  }
  diagnostic_ids_.push_back(identity);
  return Result<void>::success();
}

void GraphBuilder::defer(const ArtifactObjectReferenceV1& identity,
                         const DeferredReference::Requirement requirement,
                         std::string path) {
  deferred_.push_back(
      DeferredReference{identity, requirement, std::move(path)});
}

void GraphBuilder::add_parent(const ArtifactObjectReferenceV1& child,
                              const ArtifactObjectReferenceV1& parent,
                              std::string path) {
  parents_.push_back(ParentEdge{child, parent, std::move(path)});
}

const ArtifactObjectMetadataV1* GraphBuilder::find_exact(
    const ArtifactObjectReferenceV1& identity) const noexcept {
  const auto iterator = std::find_if(
      graph_.objects.begin(), graph_.objects.end(),
      [&identity](const ArtifactObjectMetadataV1& object) {
        return object.identity == identity;
      });
  return iterator == graph_.objects.end() ? nullptr : &*iterator;
}

Result<void> GraphBuilder::enumerate_three_bin(
    const ThreeBinScalarResponseV1& response, const std::string& path) {
  const std::vector<QueueId> targets{response.deployed_target};
  auto added = add_object(
      response.response_row_id, ArtifactObjectClassV1::response_row, {},
      targets, MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::deployed_surrogate_law, false,
      path + "/response_row_id");
  if (!added) return added;

  const auto& raw = response.raw_response;
  added = add_object(
      raw.product_id.identity(), ArtifactObjectClassV1::raw_response_product,
      {ArtifactReferenceKindV1::raw_response_product}, targets,
      MetricResultScopeV1::proposal_raw,
      MetricEvidenceScopeV1::raw_static_proposal, false,
      path + "/raw_response/product_id");
  if (!added) return added;
  for (std::size_t index = 0U; index < raw.identifications.size(); ++index) {
    const auto& identification = raw.identifications[index];
    const std::string item_path = path + "/raw_response/identifications/" +
                                  std::to_string(index);
    added = add_object(
        identification.coefficient_id,
        ArtifactObjectClassV1::coefficient_identification, {}, targets,
        MetricResultScopeV1::proposal_raw,
        MetricEvidenceScopeV1::raw_static_proposal, false,
        item_path + "/coefficient_id");
    if (!added) return added;
    add_parent(raw.product_id.identity(), identification.coefficient_id,
               item_path + "/coefficient_id");
    for (std::size_t evidence_index = 0U;
         evidence_index < identification.family_evidence_envelope_ids.size();
         ++evidence_index) {
      defer(identification.family_evidence_envelope_ids[evidence_index],
            DeferredReference::Requirement::family_evidence,
            item_path + "/family_evidence_envelope_ids/" +
                std::to_string(evidence_index));
    }
    if (identification.completion_policy_id.has_value()) {
      added = add_leaf(*identification.completion_policy_id,
                       ArtifactObjectClassV1::completion_policy,
                       item_path + "/completion_policy_id");
      if (!added) return added;
    }
  }

  if (response.nominal_response.has_value()) {
    const auto& nominal = *response.nominal_response;
    added = add_object(
        nominal.product_id.identity(),
        ArtifactObjectClassV1::nominal_response_product,
        {ArtifactReferenceKindV1::nominal_response_product}, targets,
        MetricResultScopeV1::not_a_metric_result,
        MetricEvidenceScopeV1::nominal_static_proposal, false,
        path + "/nominal_response/product_id");
    if (!added) return added;
    defer(nominal.raw_parent.identity(),
          DeferredReference::Requirement::raw_product,
          path + "/nominal_response/raw_parent");
    add_parent(nominal.product_id.identity(), nominal.raw_parent.identity(),
               path + "/nominal_response/raw_parent");
    for (std::size_t index = 0U; index < nominal.coefficients.size(); ++index) {
      defer(nominal.coefficients[index].origin_coefficient_id,
            DeferredReference::Requirement::coefficient,
            path + "/nominal_response/coefficients/" +
                std::to_string(index) + "/origin_coefficient_id");
    }
    if (nominal.completion_policy_id.has_value()) {
      added = add_leaf(*nominal.completion_policy_id,
                       ArtifactObjectClassV1::completion_policy,
                       path + "/nominal_response/completion_policy_id");
      if (!added) return added;
    }
    if (nominal.derivation_certificate_id.has_value()) {
      defer(*nominal.derivation_certificate_id,
            DeferredReference::Requirement::evidence,
            path + "/nominal_response/derivation_certificate_id");
    }
  }

  if (response.projection_center.has_value()) {
    const auto& center = *response.projection_center;
    added = add_object(
        center.product_id.identity(),
        ArtifactObjectClassV1::projection_center_product,
        {ArtifactReferenceKindV1::projection_center_product},
        center.ordered_construction_targets,
        MetricResultScopeV1::not_a_metric_result,
        MetricEvidenceScopeV1::projection_center, false,
        path + "/projection_center/product_id");
    if (!added) return added;
    const ArtifactObjectReferenceV1 source = std::visit(
        [](const auto& value) {
          return value.identity();
        },
        center.response_source);
    defer(source,
          std::holds_alternative<RawResponseProductId>(center.response_source)
              ? DeferredReference::Requirement::raw_product
              : DeferredReference::Requirement::nominal_product,
          path + "/projection_center/response_source");
    add_parent(center.product_id.identity(), source,
               path + "/projection_center/response_source");
    if (center.completion_policy_id.has_value()) {
      added = add_leaf(*center.completion_policy_id,
                       ArtifactObjectClassV1::completion_policy,
                       path + "/projection_center/completion_policy_id");
      if (!added) return added;
    }
  }

  if (response.projected_mean.has_value()) {
    const auto& mean = *response.projected_mean;
    added = add_object(
        mean.product_id.identity(),
        ArtifactObjectClassV1::projected_mean_product,
        {ArtifactReferenceKindV1::projected_mean_product},
        mean.ordered_construction_targets,
        MetricResultScopeV1::not_a_metric_result,
        MetricEvidenceScopeV1::projected_surrogate_mean, false,
        path + "/projected_mean/product_id");
    if (!added) return added;
    defer(mean.center_parent.identity(),
          DeferredReference::Requirement::projection_center,
          path + "/projected_mean/center_parent");
    add_parent(mean.product_id.identity(), mean.center_parent.identity(),
               path + "/projected_mean/center_parent");
    added = add_leaf(mean.projection_policy_id,
                     ArtifactObjectClassV1::projection_policy,
                     path + "/projected_mean/projection_policy_id");
    if (!added) return added;
    if (mean.derivation_certificate_id.has_value()) {
      defer(*mean.derivation_certificate_id,
            DeferredReference::Requirement::evidence,
            path + "/projected_mean/derivation_certificate_id");
    }
  }

  if (response.recoded_response.has_value()) {
    const auto& recoded = *response.recoded_response;
    added = add_object(
        recoded.product_id.identity(),
        ArtifactObjectClassV1::recoded_response_product,
        {ArtifactReferenceKindV1::recoded_response_product}, targets,
        MetricResultScopeV1::not_a_metric_result,
        MetricEvidenceScopeV1::recoded_static_proposal, false,
        path + "/recoded_response/product_id");
    if (!added) return added;
    for (std::size_t index = 0U; index < recoded.coefficients.size(); ++index) {
      defer(recoded.coefficients[index].origin_coefficient_id,
            DeferredReference::Requirement::coefficient,
            path + "/recoded_response/coefficients/" +
                std::to_string(index) + "/origin_coefficient_id");
    }
    if (recoded.projected_mean_parent.has_value()) {
      defer(recoded.projected_mean_parent->identity(),
            DeferredReference::Requirement::projected_mean,
            path + "/recoded_response/projected_mean_parent");
      add_parent(recoded.product_id.identity(),
                 recoded.projected_mean_parent->identity(),
                 path + "/recoded_response/projected_mean_parent");
    }
    std::visit(
        [&](const auto& parent) {
          using Parent = std::decay_t<decltype(parent)>;
          if constexpr (std::same_as<Parent, RawResponseProductId>) {
            defer(parent.identity(), DeferredReference::Requirement::raw_product,
                  path + "/recoded_response/reference_response_parent");
            add_parent(recoded.product_id.identity(), parent.identity(),
                       path +
                           "/recoded_response/reference_response_parent");
          } else if constexpr (std::same_as<Parent,
                                                NominalResponseProductId>) {
            defer(parent.identity(),
                  DeferredReference::Requirement::nominal_product,
                  path + "/recoded_response/reference_response_parent");
            add_parent(recoded.product_id.identity(), parent.identity(),
                       path +
                           "/recoded_response/reference_response_parent");
          }
        },
        recoded.reference_response_parent);
    if (recoded.completion_policy_id.has_value()) {
      added = add_leaf(*recoded.completion_policy_id,
                       ArtifactObjectClassV1::completion_policy,
                       path + "/recoded_response/completion_policy_id");
      if (!added) return added;
    }
    added = add_leaf(recoded.recoding_policy_id,
                     ArtifactObjectClassV1::recoding_policy,
                     path + "/recoded_response/recoding_policy_id");
    if (!added) return added;
    if (recoded.derivation_certificate_id.has_value()) {
      defer(*recoded.derivation_certificate_id,
            DeferredReference::Requirement::evidence,
            path + "/recoded_response/derivation_certificate_id");
    }
  }

  std::visit(
      [&](const auto& deployed) {
        using Product = std::decay_t<decltype(deployed)>;
        if constexpr (std::same_as<Product, RawResponseProductId>) {
          defer(deployed.identity(), DeferredReference::Requirement::raw_product,
                path + "/deployed_response_product_id");
        } else if constexpr (std::same_as<Product,
                                          NominalResponseProductId>) {
          defer(deployed.identity(),
                DeferredReference::Requirement::nominal_product,
                path + "/deployed_response_product_id");
        } else {
          defer(deployed.identity(),
                DeferredReference::Requirement::recoded_product,
                path + "/deployed_response_product_id");
        }
      },
      response.deployed_response_product_id);

  for (std::size_t index = 0U; index < response.raw_envelopes.size(); ++index) {
    const auto& envelope = response.raw_envelopes[index];
    const std::string item_path =
        path + "/raw_envelopes/" + std::to_string(index);
    added = add_object(
        envelope.envelope_id, ArtifactObjectClassV1::raw_response_envelope,
        {ArtifactReferenceKindV1::raw_response_bound_evidence}, targets,
        MetricResultScopeV1::not_a_metric_result,
        raw_envelope_evidence_scope(envelope.scope), true,
        item_path + "/envelope_id");
    if (!added) return added;
    defer(envelope.source_product.identity(),
          DeferredReference::Requirement::raw_product,
          item_path + "/source_product");
    add_parent(envelope.envelope_id, envelope.source_product.identity(),
               item_path + "/source_product");
    for (std::size_t evidence_index = 0U;
         evidence_index < envelope.family_evidence_envelope_ids.size();
         ++evidence_index) {
      defer(envelope.family_evidence_envelope_ids[evidence_index],
            DeferredReference::Requirement::family_evidence,
            item_path + "/family_evidence_envelope_ids/" +
                std::to_string(evidence_index));
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::enumerate_finite_prefix(
    const FinitePrefixConstantTailResponseV1& response,
    const std::string& path) {
  const std::vector<QueueId> targets{response.deployed_target};
  auto added = add_object(
      response.response_row_id, ArtifactObjectClassV1::response_row, {},
      targets, MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::deployed_surrogate_law, false,
      path + "/response_row_id");
  if (!added) return added;

  const auto& raw = response.raw_response;
  added = add_object(
      raw.product_id.identity(), ArtifactObjectClassV1::raw_response_product,
      {ArtifactReferenceKindV1::raw_response_product}, targets,
      MetricResultScopeV1::proposal_raw,
      MetricEvidenceScopeV1::raw_static_proposal, false,
      path + "/raw_response/product_id");
  if (!added) return added;
  for (std::size_t index = 0U; index < raw.identifications.size(); ++index) {
    const auto& coefficient = raw.identifications[index];
    const std::string item_path =
        path + "/raw_response/identifications/" + std::to_string(index);
    added = add_object(
        coefficient.coefficient_id,
        ArtifactObjectClassV1::coefficient_identification, {}, targets,
        MetricResultScopeV1::proposal_raw,
        MetricEvidenceScopeV1::raw_static_proposal, false,
        item_path + "/coefficient_id");
    if (!added) return added;
    add_parent(raw.product_id.identity(), coefficient.coefficient_id,
               item_path + "/coefficient_id");
    for (std::size_t evidence_index = 0U;
         evidence_index < coefficient.family_evidence_envelope_ids.size();
         ++evidence_index) {
      defer(coefficient.family_evidence_envelope_ids[evidence_index],
            DeferredReference::Requirement::family_evidence,
            item_path + "/family_evidence_envelope_ids/" +
                std::to_string(evidence_index));
    }
  }
  defer(response.deployed_response_product_id.identity(),
        DeferredReference::Requirement::raw_product,
        path + "/deployed_response_product_id");

  for (std::size_t index = 0U; index < response.raw_envelopes.size(); ++index) {
    const auto& envelope = response.raw_envelopes[index];
    const std::string item_path =
        path + "/raw_envelopes/" + std::to_string(index);
    added = add_object(
        envelope.envelope_id, ArtifactObjectClassV1::raw_response_envelope,
        {ArtifactReferenceKindV1::raw_response_bound_evidence}, targets,
        MetricResultScopeV1::not_a_metric_result,
        raw_envelope_evidence_scope(envelope.scope), true,
        item_path + "/envelope_id");
    if (!added) return added;
    defer(envelope.source_product.identity(),
          DeferredReference::Requirement::raw_product,
          item_path + "/source_product");
    add_parent(envelope.envelope_id, envelope.source_product.identity(),
               item_path + "/source_product");
    for (std::size_t evidence_index = 0U;
         evidence_index < envelope.family_evidence_envelope_ids.size();
         ++evidence_index) {
      defer(envelope.family_evidence_envelope_ids[evidence_index],
            DeferredReference::Requirement::family_evidence,
            item_path + "/family_evidence_envelope_ids/" +
                std::to_string(evidence_index));
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::enumerate_finite_table(
    const FiniteLawTablesV1& payload, const std::string& path) {
  const auto& identity = table_identity(payload.table);
  auto added = add_object(
      identity, object_class_for_table(payload.table),
      {law_kind_for_table(payload.table)}, payload.ordered_deployed_targets,
      MetricResultScopeV1::surrogate_law,
      MetricEvidenceScopeV1::deployed_surrogate_law, false,
      path + "/table/law_id");
  if (!added) return added;

  const auto scan_rows = [&](const std::span<const FiniteLawRowV1> rows,
                             const std::string& rows_path) {
    for (std::size_t row_index = 0U; row_index < rows.size(); ++row_index) {
      for (std::size_t atom_index = 0U;
           atom_index < rows[row_index].atoms.size(); ++atom_index) {
        const auto& schedule = rows[row_index].atoms[atom_index].common_schedule;
        if (schedule.has_value() && schedule->projection_witness.has_value()) {
          defer(*schedule->projection_witness,
                DeferredReference::Requirement::evidence,
                rows_path + "/" + std::to_string(row_index) + "/atoms/" +
                    std::to_string(atom_index) +
                    "/common_schedule/projection_witness");
        }
      }
    }
  };
  const auto scan_predictive = [&](
                                   const FinitePredictiveStoppingTablesV1& rows,
                                   const std::string& rows_path) {
    scan_rows(rows.continuation_rows, rows_path + "/continuation_rows");
    scan_rows(rows.stop_or_event_rows, rows_path + "/stop_or_event_rows");
    scan_rows(rows.terminal_or_exit_rows,
              rows_path + "/terminal_or_exit_rows");
  };

  return std::visit(
      [&](const auto& table) -> Result<void> {
        using Table = std::decay_t<decltype(table)>;
        if constexpr (std::same_as<Table, StationaryMarkedEdgeTableV1>) {
          scan_rows(table.joint_edge_rows, path + "/table/joint_edge_rows");
        } else if constexpr (
            std::same_as<Table, StagedOpportunityFluxTableV1>) {
          added = add_leaf(table.deterministic_update_descriptor,
                           ArtifactObjectClassV1::finite_descriptor,
                           path +
                               "/table/deterministic_update_descriptor");
          if (!added) return added;
          added = add_leaf(table.retained_coordinate_descriptor,
                           ArtifactObjectClassV1::finite_descriptor,
                           path +
                               "/table/retained_coordinate_descriptor");
          if (!added) return added;
          scan_rows(table.opportunity_rows,
                    path + "/table/opportunity_rows");
          scan_rows(table.successor_mark_rows,
                    path + "/table/successor_mark_rows");
        } else if constexpr (
            std::same_as<Table, TemporalContinuationTableV1>) {
          scan_rows(table.continuation_rows,
                    path + "/table/continuation_rows");
        } else if constexpr (std::same_as<Table, StoppedPathTableV1>) {
          if (const auto* predictive =
                  std::get_if<FinitePredictiveStoppingTablesV1>(
                      &table.representation)) {
            scan_predictive(*predictive, path + "/table/representation");
          }
          for (std::size_t index = 0U;
               index < table.completion_absorption_tail_evidence.size();
               ++index) {
            defer(table.completion_absorption_tail_evidence[index],
                  DeferredReference::Requirement::evidence,
                  path +
                      "/table/completion_absorption_tail_evidence/" +
                      std::to_string(index));
          }
        } else if constexpr (std::same_as<Table,
                                          RomrResidenceWordTableV1>) {
          if (const auto* predictive =
                  std::get_if<FinitePredictiveStoppingTablesV1>(
                      &table.representation)) {
            scan_predictive(*predictive, path + "/table/representation");
          }
          for (std::size_t index = 0U;
               index < table.complete_mass_termination_evidence.size();
               ++index) {
            defer(table.complete_mass_termination_evidence[index],
                  DeferredReference::Requirement::evidence,
                  path + "/table/complete_mass_termination_evidence/" +
                      std::to_string(index));
          }
        } else {
          scan_rows(table.common_joint_rows,
                    path + "/table/common_joint_rows");
        }
        return Result<void>::success();
      },
      payload.table);
}

Result<void> GraphBuilder::enumerate_payload() {
  std::vector<ArtifactReferenceKindV1> payload_kinds{
      ArtifactReferenceKindV1::artifact_payload};
  if (std::holds_alternative<ResponseEnvelopeEvidenceV1>(artifact_.payload)) {
    payload_kinds.push_back(ArtifactReferenceKindV1::response_envelope);
  } else if (std::holds_alternative<RegisteredRuntimeRecipeV1>(
                 artifact_.payload)) {
    const auto law_kind = law_kind_for_semantic(artifact_.deployed_semantic);
    if (law_kind.has_value()) payload_kinds.push_back(*law_kind);
  }

  const auto payload_targets = std::visit(
      [](const auto& payload) {
        using Payload = std::decay_t<decltype(payload)>;
        if constexpr (std::same_as<Payload, ThreeBinScalarResponseV1> ||
                      std::same_as<
                          Payload, FinitePrefixConstantTailResponseV1>) {
          return std::vector<QueueId>{payload.deployed_target};
        } else if constexpr (std::same_as<Payload, DirectMetricPayloadV1>) {
          std::vector<QueueId> targets;
          for (const auto& value : payload.values) {
            for (const auto& target : value.ordered_targets) {
              if (!contains_target(targets, target)) targets.push_back(target);
            }
          }
          return targets;
        } else {
          return payload.ordered_deployed_targets;
        }
      },
      artifact_.payload);
  const auto payload_scope =
      std::holds_alternative<ResponseEnvelopeEvidenceV1>(artifact_.payload)
          ? std::get<ResponseEnvelopeEvidenceV1>(artifact_.payload).result_scope
          : MetricResultScopeV1::surrogate_law;
  const auto payload_evidence_scope =
      std::holds_alternative<ResponseEnvelopeEvidenceV1>(artifact_.payload)
          ? std::get<ResponseEnvelopeEvidenceV1>(artifact_.payload)
                .evidence_scope
          : MetricEvidenceScopeV1::none;
  auto added = add_object(
      artifact_.payload_identity, ArtifactObjectClassV1::artifact_payload,
      std::move(payload_kinds), payload_targets, payload_scope,
      payload_evidence_scope, false, "/payload_identity");
  if (!added) return added;

  return std::visit(
      [&](const auto& payload) -> Result<void> {
        using Payload = std::decay_t<decltype(payload)>;
        if constexpr (std::same_as<Payload, ThreeBinScalarResponseV1>) {
          return enumerate_three_bin(payload, "/payload");
        } else if constexpr (std::same_as<
                                 Payload,
                                 FinitePrefixConstantTailResponseV1>) {
          return enumerate_finite_prefix(payload, "/payload");
        } else if constexpr (
            std::same_as<Payload, FiniteParameterAnalyticDataV1>) {
          const auto law_kind =
              law_kind_for_semantic(artifact_.deployed_semantic);
          for (std::size_t index = 0U;
               index < payload.transform_or_response_identities.size();
               ++index) {
            std::vector<ArtifactReferenceKindV1> kinds;
            if (law_kind.has_value()) kinds.push_back(*law_kind);
            added = add_object(
                payload.transform_or_response_identities[index],
                ArtifactObjectClassV1::analytic_transform_or_response,
                std::move(kinds), payload.ordered_deployed_targets,
                MetricResultScopeV1::surrogate_law,
                MetricEvidenceScopeV1::deployed_surrogate_law, false,
                "/payload/transform_or_response_identities/" +
                    std::to_string(index));
            if (!added) return added;
          }
          return Result<void>::success();
        } else if constexpr (std::same_as<Payload, FiniteLawTablesV1>) {
          return enumerate_finite_table(payload, "/payload");
        } else if constexpr (
            std::same_as<Payload, RegisteredRuntimeRecipeV1>) {
          return Result<void>::success();
        } else if constexpr (
            std::same_as<Payload, ResponseEnvelopeEvidenceV1>) {
          auto lower = enumerate_three_bin(payload.lower_response,
                                           "/payload/lower_response");
          if (!lower) return lower;
          auto upper = enumerate_three_bin(payload.upper_response,
                                           "/payload/upper_response");
          if (!upper) return upper;
          std::visit(
              [&](const auto& product) {
                using Product = std::decay_t<decltype(product)>;
                if constexpr (std::same_as<Product, RawResponseProductId>) {
                  defer(product.identity(),
                        DeferredReference::Requirement::raw_product,
                        "/payload/lower_response_product");
                } else if constexpr (
                    std::same_as<Product, NominalResponseProductId>) {
                  defer(product.identity(),
                        DeferredReference::Requirement::nominal_product,
                        "/payload/lower_response_product");
                } else {
                  defer(product.identity(),
                        DeferredReference::Requirement::recoded_product,
                        "/payload/lower_response_product");
                }
              },
              payload.lower_response_product);
          std::visit(
              [&](const auto& product) {
                using Product = std::decay_t<decltype(product)>;
                if constexpr (std::same_as<Product, RawResponseProductId>) {
                  defer(product.identity(),
                        DeferredReference::Requirement::raw_product,
                        "/payload/upper_response_product");
                } else if constexpr (
                    std::same_as<Product, NominalResponseProductId>) {
                  defer(product.identity(),
                        DeferredReference::Requirement::nominal_product,
                        "/payload/upper_response_product");
                } else {
                  defer(product.identity(),
                        DeferredReference::Requirement::recoded_product,
                        "/payload/upper_response_product");
                }
              },
              payload.upper_response_product);
          added = add_leaf(payload.comparison_domain_id,
                           ArtifactObjectClassV1::comparison_domain,
                           "/payload/comparison_domain_id");
          if (!added) return added;
          for (std::size_t index = 0U;
               index < payload.typed_evidence_components.size(); ++index) {
            defer(payload.typed_evidence_components[index],
                  DeferredReference::Requirement::scoped_evidence,
                  "/payload/typed_evidence_components/" +
                      std::to_string(index));
          }
          if (payload.authorized_point_product.has_value()) {
            std::visit(
                [&](const auto& product) {
                  using Product = std::decay_t<decltype(product)>;
                  if constexpr (std::same_as<Product,
                                             RawResponseProductId>) {
                    defer(product.identity(),
                          DeferredReference::Requirement::raw_product,
                          "/payload/authorized_point_product");
                  } else if constexpr (
                      std::same_as<Product, NominalResponseProductId>) {
                    defer(product.identity(),
                          DeferredReference::Requirement::nominal_product,
                          "/payload/authorized_point_product");
                  } else {
                    defer(product.identity(),
                          DeferredReference::Requirement::recoded_product,
                          "/payload/authorized_point_product");
                  }
                },
                *payload.authorized_point_product);
          }
          return Result<void>::success();
        } else {
          for (std::size_t index = 0U; index < payload.values.size(); ++index) {
            const auto& value = payload.values[index];
            added = add_object(
                value.value_id, ArtifactObjectClassV1::direct_metric_value,
                {ArtifactReferenceKindV1::direct_metric_value},
                value.ordered_targets, value.result_scope,
                MetricEvidenceScopeV1::deployed_surrogate_law, false,
                "/payload/values/" + std::to_string(index) + "/value_id");
            if (!added) return added;
            for (std::size_t evidence_index = 0U;
                 evidence_index < value.evidence_ids.size();
                 ++evidence_index) {
              defer(value.evidence_ids[evidence_index],
                    DeferredReference::Requirement::evidence,
                    "/payload/values/" + std::to_string(index) +
                        "/evidence_ids/" +
                        std::to_string(evidence_index));
            }
          }
          return Result<void>::success();
        }
      },
      artifact_.payload);
}

Result<void> GraphBuilder::enumerate_family_and_auxiliary() {
  for (std::size_t index = 0U; index < artifact_.family_evidence.size();
       ++index) {
    const auto& evidence = artifact_.family_evidence[index];
    const std::string path =
        "/family_evidence/" + std::to_string(index);
    auto added = add_object(
        evidence.evidence_id, ArtifactObjectClassV1::family_evidence, {},
        evidence.construction_target_scope,
        MetricResultScopeV1::not_a_metric_result,
        evidence.evidence_scope_tag, true, path + "/evidence_id");
    if (!added) return added;
  }
  for (std::size_t index = 0U; index < artifact_.scoped_evidence.size();
       ++index) {
    const auto& evidence = artifact_.scoped_evidence[index];
    const std::string path =
        "/scoped_evidence/" + std::to_string(index);
    if (static_cast<std::uint8_t>(evidence.reference_kind) >
        static_cast<std::uint8_t>(
            ArtifactReferenceKindV1::physical_transfer_evidence)) {
      return failure<void>("c15.object_graph_unknown_reference_kind",
                           "scoped evidence uses an unknown reference kind",
                           path + "/reference_kind");
    }
    auto added = add_object(
        evidence.evidence_id, ArtifactObjectClassV1::scoped_evidence,
        {evidence.reference_kind}, evidence.ordered_targets,
        evidence.result_scope, evidence.evidence_scope, true,
        path + "/evidence_id");
    if (!added) return added;
  }
  for (std::size_t index = 0U; index < artifact_.diagnostic_components.size();
       ++index) {
    auto added = add_diagnostic_id(
        artifact_.diagnostic_components[index].diagnostic_id,
        "/diagnostic_components/" + std::to_string(index) +
            "/diagnostic_id");
    if (!added) return added;
  }

  // Resolve only after all owned evidence objects have been registered.  This
  // makes a forward reference legal but never lets an arbitrary subject or
  // evidence reference manufacture its own target object.
  for (std::size_t index = 0U; index < artifact_.family_evidence.size();
       ++index) {
    const auto& evidence = artifact_.family_evidence[index];
    const std::string path =
        "/family_evidence/" + std::to_string(index);
    for (std::size_t item = 0U; item < evidence.subject_references.size();
         ++item) {
      defer(evidence.subject_references[item],
            DeferredReference::Requirement::any,
            path + "/subject_references/" + std::to_string(item));
      evidence_dependencies_.push_back(
          {evidence.evidence_id, evidence.subject_references[item],
           path + "/subject_references/" + std::to_string(item)});
    }
    for (std::size_t item = 0U; item < evidence.parent_references.size();
         ++item) {
      defer(evidence.parent_references[item],
            DeferredReference::Requirement::any,
            path + "/parent_references/" + std::to_string(item));
      add_parent(evidence.evidence_id, evidence.parent_references[item],
                 path + "/parent_references/" + std::to_string(item));
      evidence_dependencies_.push_back(
          {evidence.evidence_id, evidence.parent_references[item],
           path + "/parent_references/" + std::to_string(item)});
    }
    // payload_digest is the digest component of this exact artifact-owned
    // payload identity and remains a full dependency in the family envelope.
    evidence_dependencies_.push_back(
        {evidence.evidence_id, artifact_.payload_identity,
         path + "/payload_digest"});
  }
  for (std::size_t index = 0U; index < artifact_.scoped_evidence.size();
       ++index) {
    const auto& evidence = artifact_.scoped_evidence[index];
    const std::string path =
        "/scoped_evidence/" + std::to_string(index);
    for (std::size_t item = 0U; item < evidence.subject_references.size();
         ++item) {
      defer(evidence.subject_references[item],
            DeferredReference::Requirement::any,
            path + "/subject_references/" + std::to_string(item));
      evidence_dependencies_.push_back(
          {evidence.evidence_id, evidence.subject_references[item],
           path + "/subject_references/" + std::to_string(item)});
    }
    for (std::size_t item = 0U; item < evidence.parent_references.size();
         ++item) {
      defer(evidence.parent_references[item],
            DeferredReference::Requirement::any,
            path + "/parent_references/" + std::to_string(item));
      add_parent(evidence.evidence_id, evidence.parent_references[item],
                 path + "/parent_references/" + std::to_string(item));
      evidence_dependencies_.push_back(
          {evidence.evidence_id, evidence.parent_references[item],
           path + "/parent_references/" + std::to_string(item)});
    }
    for (std::size_t item = 0U; item < evidence.family_envelope_ids.size();
         ++item) {
      defer(evidence.family_envelope_ids[item],
            DeferredReference::Requirement::family_evidence,
            path + "/family_envelope_ids/" + std::to_string(item));
      evidence_dependencies_.push_back(
          {evidence.evidence_id, evidence.family_envelope_ids[item],
           path + "/family_envelope_ids/" + std::to_string(item)});
    }
  }
  for (std::size_t index = 0U; index < artifact_.diagnostic_components.size();
       ++index) {
    const auto& diagnostic = artifact_.diagnostic_components[index];
    const std::string path =
        "/diagnostic_components/" + std::to_string(index);
    for (std::size_t item = 0U; item < diagnostic.subject_references.size();
         ++item) {
      defer(diagnostic.subject_references[item],
            DeferredReference::Requirement::any,
            path + "/subject_references/" + std::to_string(item));
    }
    for (std::size_t item = 0U; item < diagnostic.evidence_references.size();
         ++item) {
      defer(diagnostic.evidence_references[item],
            DeferredReference::Requirement::evidence,
            path + "/evidence_references/" + std::to_string(item));
    }
  }
  return Result<void>::success();
}

bool GraphBuilder::purpose_may_declare_leaf(
    const InternalReferencePurposeV1 purpose) const noexcept {
  switch (purpose) {
    case InternalReferencePurposeV1::artifact_payload:
    case InternalReferencePurposeV1::coefficient_origin:
    case InternalReferencePurposeV1::completion_source:
    case InternalReferencePurposeV1::completion_policy:
    case InternalReferencePurposeV1::projection_source:
    case InternalReferencePurposeV1::projection_policy:
    case InternalReferencePurposeV1::recoding_policy:
    case InternalReferencePurposeV1::stage_law:
    case InternalReferencePurposeV1::lower_response_product:
    case InternalReferencePurposeV1::upper_response_product:
    case InternalReferencePurposeV1::comparison_domain:
    case InternalReferencePurposeV1::validity_witness:
    case InternalReferencePurposeV1::coverage_family:
    case InternalReferencePurposeV1::certified_product_or_envelope:
    case InternalReferencePurposeV1::deployed_law:
    case InternalReferencePurposeV1::law_or_result:
    case InternalReferencePurposeV1::surrogate_source:
    case InternalReferencePurposeV1::estimand:
    case InternalReferencePurposeV1::calibration_source:
    case InternalReferencePurposeV1::compression_source:
    case InternalReferencePurposeV1::compression_destination:
    case InternalReferencePurposeV1::error_object: return false;
    default: return true;
  }
}

bool GraphBuilder::purpose_accepts(
    const InternalReferencePurposeV1 purpose,
    const ArtifactObjectMetadataV1& object) const noexcept {
  switch (purpose) {
    case InternalReferencePurposeV1::artifact_payload:
      return object.object_class == ArtifactObjectClassV1::artifact_payload;
    case InternalReferencePurposeV1::coefficient_origin:
      return object.object_class ==
             ArtifactObjectClassV1::coefficient_identification;
    case InternalReferencePurposeV1::completion_source:
      return object.object_class ==
                 ArtifactObjectClassV1::coefficient_identification ||
             product_class(object.object_class);
    case InternalReferencePurposeV1::completion_policy:
      return object.object_class == ArtifactObjectClassV1::completion_policy;
    case InternalReferencePurposeV1::projection_source:
      return product_class(object.object_class);
    case InternalReferencePurposeV1::projection_policy:
      return object.object_class == ArtifactObjectClassV1::projection_policy;
    case InternalReferencePurposeV1::recoding_policy:
      return object.object_class == ArtifactObjectClassV1::recoding_policy;
    case InternalReferencePurposeV1::stage_law:
      return object.object_class == ArtifactObjectClassV1::finite_descriptor ||
             (object.object_class == ArtifactObjectClassV1::artifact_payload &&
              contains_kind(
                  object.compatible_reference_kinds,
                  ArtifactReferenceKindV1::staged_opportunity_flux_law));
    case InternalReferencePurposeV1::deployed_law:
    case InternalReferencePurposeV1::law_or_result:
    case InternalReferencePurposeV1::surrogate_source:
      return law_or_result_class(object.object_class);
    case InternalReferencePurposeV1::estimand:
    case InternalReferencePurposeV1::calibration_source:
    case InternalReferencePurposeV1::compression_destination:
      return product_class(object.object_class);
    case InternalReferencePurposeV1::compression_source:
      return product_class(object.object_class) ||
             object.object_class ==
                 ArtifactObjectClassV1::coefficient_identification;
    case InternalReferencePurposeV1::lower_response_product:
    case InternalReferencePurposeV1::upper_response_product:
      return object.object_class == ArtifactObjectClassV1::raw_response_product ||
             object.object_class ==
                 ArtifactObjectClassV1::nominal_response_product ||
             object.object_class ==
                 ArtifactObjectClassV1::recoded_response_product;
    case InternalReferencePurposeV1::comparison_domain:
      return object.object_class == ArtifactObjectClassV1::comparison_domain;
    case InternalReferencePurposeV1::validity_witness:
    case InternalReferencePurposeV1::error_object:
      return object.evidence_object;
    case InternalReferencePurposeV1::coverage_family:
      return object.object_class == ArtifactObjectClassV1::family_evidence;
    case InternalReferencePurposeV1::certified_product_or_envelope:
      return product_class(object.object_class) ||
             object.object_class ==
                 ArtifactObjectClassV1::raw_response_envelope ||
             (object.object_class == ArtifactObjectClassV1::artifact_payload &&
              contains_kind(object.compatible_reference_kinds,
                            ArtifactReferenceKindV1::response_envelope));
    default:
      // Every purpose not mapped to a concrete payload/evidence object above
      // denotes a sealed, purpose-specific external anchor.  It may be
      // introduced only through add_purpose_reference as a bodyless leaf;
      // accepting an arbitrary already-owned payload/product/evidence object
      // here would permit a cross-kind alias to masquerade as (for example)
      // a codec, solver, schedule, or configured-arrival identity.
      return object.object_class == ArtifactObjectClassV1::purpose_bound_leaf;
  }
}

Result<void> GraphBuilder::add_purpose_reference(
    const ArtifactObjectReferenceV1& owner,
    const RealizedInternalReferenceV1& relation, const std::string& path) {
  if (static_cast<std::uint8_t>(relation.relation) >
          static_cast<std::uint8_t>(MetricRoleRelationKindV1::subject) ||
      internal_reference_purpose_bit_v1(relation.purpose) == 0U) {
    return failure<void>(
        "c15.object_graph_unknown_internal_relation",
        "artifact object graph received an unknown internal relation or purpose",
        path);
  }
  const auto* referenced = find_exact(relation.referenced_object);
  if (purpose_may_declare_leaf(relation.purpose)) {
    const auto prior = std::find_if(
        purpose_leaves_.begin(), purpose_leaves_.end(),
        [&relation](const PurposeLeaf& leaf) {
          return leaf.identity == relation.referenced_object;
        });
    if (referenced != nullptr &&
        referenced->object_class ==
            ArtifactObjectClassV1::purpose_bound_leaf &&
        (prior == purpose_leaves_.end() ||
         prior->purpose != relation.purpose)) {
      return failure<void>(
          "c15.object_graph_leaf_purpose_collision",
          "one bodyless internal object cannot be declared under two semantic purposes",
          path + "/referenced_object");
    }
    if (referenced == nullptr) {
      if (prior != purpose_leaves_.end() &&
          prior->purpose != relation.purpose) {
        return failure<void>(
            "c15.object_graph_leaf_purpose_collision",
            "one bodyless internal object cannot be declared under two semantic purposes",
            path + "/referenced_object");
      }
      auto added = add_leaf(relation.referenced_object,
                            ArtifactObjectClassV1::purpose_bound_leaf,
                            path + "/referenced_object");
      if (!added) return added;
      if (prior == purpose_leaves_.end()) {
        purpose_leaves_.push_back(
            PurposeLeaf{relation.referenced_object, relation.purpose});
      }
      referenced = find_exact(relation.referenced_object);
    }
  }
  if (referenced == nullptr || !purpose_accepts(relation.purpose, *referenced)) {
    return failure<void>(
        "c15.object_graph_internal_reference_kind",
        "internal relation does not resolve to the exact object kind required by its purpose",
        path + "/referenced_object");
  }
  graph_.internal_relations.push_back(ArtifactObjectInternalRelationV1{
      owner, relation.relation, relation.purpose,
      relation.referenced_object});
  if (relation.relation == MetricRoleRelationKindV1::lineage_parent) {
    add_parent(owner, relation.referenced_object,
               path + "/referenced_object");
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_realized_raw_envelope_binding(
    const RealizedMetricBindingV1& binding,
    const std::size_t binding_index) const {
  const auto& envelope_identity = realized_reference_subject_v1(
      binding.reference);
  if (const auto* response =
          std::get_if<FinitePrefixConstantTailResponseV1>(
              &artifact_.payload)) {
    const auto envelope_iterator = std::find_if(
        response->raw_envelopes.begin(), response->raw_envelopes.end(),
        [&](const FinitePrefixRawResponseEnvelopeV1& envelope) {
          return envelope.envelope_id == envelope_identity;
        });
    const std::string path =
        "/realized_metric_bindings/bindings/" +
        std::to_string(binding_index) + "/reference";
    if (envelope_iterator == response->raw_envelopes.end() ||
        std::count_if(
            response->raw_envelopes.begin(), response->raw_envelopes.end(),
            [&](const FinitePrefixRawResponseEnvelopeV1& envelope) {
              return envelope.envelope_id == envelope_identity;
            }) != 1) {
      return failure<void>(
          "c15.object_graph_finite_prefix_envelope_subject",
          "realized dynamic raw-bound envelope must resolve exactly once",
          path);
    }
    const auto& envelope = *envelope_iterator;
    const auto& raw = response->raw_response;
    const auto& core = realized_reference_core_v1(binding.reference);
    if (envelope.source_product != raw.product_id ||
        envelope.construction_law_digest != raw.proposal_law_digest ||
        core.ordered_targets !=
            std::vector<QueueId>{response->deployed_target} ||
        core.target_scope !=
            MetricTargetScopeV1::deployed_singleton_target ||
        core.result_scope != MetricResultScopeV1::not_a_metric_result ||
        core.evidence_scope != raw_envelope_evidence_scope(envelope.scope)) {
      return failure<void>(
          "c15.object_graph_finite_prefix_envelope_scope",
          "dynamic raw-envelope realized core differs from its exact "
          "source, target or C14 scope",
          path + "/core");
    }
    const auto raw_subjects = std::count_if(
        core.role_relations.begin(), core.role_relations.end(),
        [&](const RealizedRoleRelationV1& relation) {
          return relation.relation == MetricRoleRelationKindV1::subject &&
                 relation.key ==
                     MetricRoleKeyV1{binding.key.clause_id,
                                     MetricSupportRoleV1::raw_response} &&
                 relation.referenced_object == raw.product_id.identity();
        });
    std::vector<ArtifactObjectReferenceV1> origins;
    const ArtifactObjectReferenceV1* evaluation = nullptr;
    const ArtifactObjectReferenceV1* proposal = nullptr;
    for (const auto& relation : core.internal_relations) {
      if (relation.relation == MetricRoleRelationKindV1::subject &&
          relation.purpose == InternalReferencePurposeV1::coefficient_origin) {
        origins.push_back(relation.referenced_object);
      }
      if (relation.relation == MetricRoleRelationKindV1::binding &&
          relation.purpose == InternalReferencePurposeV1::evaluation_identity) {
        if (evaluation != nullptr) {
          return failure<void>(
              "c15.object_graph_finite_prefix_envelope_evaluation",
              "dynamic raw envelope must name exactly one evaluation", path);
        }
        evaluation = &relation.referenced_object;
      }
      if (relation.relation == MetricRoleRelationKindV1::binding &&
          relation.purpose == InternalReferencePurposeV1::proposal_identity) {
        if (proposal != nullptr) {
          return failure<void>(
              "c15.object_graph_finite_prefix_envelope_proposal",
              "dynamic raw envelope must name exactly one proposal", path);
        }
        proposal = &relation.referenced_object;
      }
    }
    const bool known_origin =
        origins.size() == 1U &&
        std::any_of(
            raw.identifications.begin(), raw.identifications.end(),
            [&](const FinitePrefixCoefficientIdentificationV1& value) {
              return value.coefficient_id == origins.front();
            });
    const MetricRoleKeyV1 raw_key{binding.key.clause_id,
                                  MetricSupportRoleV1::raw_response};
    const auto raw_binding = std::find_if(
        artifact_.realized_metric_bindings.bindings.begin(),
        artifact_.realized_metric_bindings.bindings.end(),
        [&](const RealizedMetricBindingV1& candidate) {
          return candidate.key == raw_key;
        });
    const auto raw_origins =
        raw_binding == artifact_.realized_metric_bindings.bindings.end()
            ? std::vector<ArtifactObjectReferenceV1>{}
            : [&] {
                std::vector<ArtifactObjectReferenceV1> result;
                for (const auto& relation :
                     realized_reference_core_v1(raw_binding->reference)
                         .internal_relations) {
                  if (relation.relation ==
                          MetricRoleRelationKindV1::lineage_parent &&
                      relation.purpose ==
                          InternalReferencePurposeV1::coefficient_origin) {
                    result.push_back(relation.referenced_object);
                  }
                }
                std::sort(result.begin(), result.end());
                return result;
              }();
    std::sort(origins.begin(), origins.end());
    if (raw_subjects != 1 || !known_origin || raw_origins != origins ||
        evaluation == nullptr || proposal == nullptr ||
        !artifact_.provenance.final_evaluation_id.has_value() ||
        !artifact_.provenance.proposal_id.has_value() ||
        evaluation->object_id != *artifact_.provenance.final_evaluation_id ||
        evaluation->object_id != envelope.frozen_evaluation_id ||
        proposal->object_id != *artifact_.provenance.proposal_id ||
        proposal->object_digest != envelope.construction_law_digest) {
      return failure<void>(
          "c15.object_graph_finite_prefix_envelope_binding",
          "dynamic raw envelope must bind one same-ledger coefficient plus "
          "the exact evaluation and proposal identities",
          path + "/core");
    }
    for (const auto& family_id : envelope.family_evidence_envelope_ids) {
      const auto family = std::find_if(
          artifact_.family_evidence.begin(), artifact_.family_evidence.end(),
          [&](const FamilyEvidenceEnvelopeV1& candidate) {
            return candidate.evidence_id == family_id;
          });
      if (family == artifact_.family_evidence.end() ||
          !contains_reference(family->subject_references,
                              envelope.envelope_id) ||
          !contains_reference(family->parent_references,
                              raw.product_id.identity()) ||
          !contains_reference(family->subject_references, origins.front()) ||
          family->evidence_scope_tag != core.evidence_scope) {
        return failure<void>(
            "c15.object_graph_finite_prefix_envelope_family",
            "dynamic raw envelope family evidence does not bind its raw "
            "parent, envelope and selected coefficient",
            path);
      }
    }
    return Result<void>::success();
  }
  const ThreeBinScalarResponseV1* bound_response = nullptr;
  const RawResponseEnvelopeV1* bound_envelope = nullptr;
  std::size_t envelope_match_count = 0U;
  bool exact_envelope_ledger_alias = false;
  const auto find_in_response = [&](const ThreeBinScalarResponseV1& response) {
    const auto iterator = std::find_if(
        response.raw_envelopes.begin(), response.raw_envelopes.end(),
        [&](const RawResponseEnvelopeV1& envelope) {
          return envelope.envelope_id == envelope_identity;
        });
    if (iterator != response.raw_envelopes.end()) {
      ++envelope_match_count;
      if (bound_envelope == nullptr) {
        bound_response = &response;
        bound_envelope = &*iterator;
      }
    }
  };
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact_.payload)) {
    find_in_response(*response);
  } else if (const auto* outer =
                 std::get_if<ResponseEnvelopeEvidenceV1>(
                     &artifact_.payload)) {
    find_in_response(outer->lower_response);
    find_in_response(outer->upper_response);
    exact_envelope_ledger_alias =
        outer->lower_response == outer->upper_response;
  }
  const std::string path =
      "/realized_metric_bindings/bindings/" +
      std::to_string(binding_index) + "/reference";
  const bool unique_owner =
      envelope_match_count == 1U ||
      (envelope_match_count == 2U && exact_envelope_ledger_alias);
  if (bound_response == nullptr || bound_envelope == nullptr ||
      !unique_owner) {
    return failure<void>(
        "c15.object_graph_raw_envelope_subject",
        "realized raw-bound envelope must resolve in one retained response ledger or an exact lower/upper ledger alias",
        path);
  }
  const auto& raw = bound_response->raw_response;
  const auto& core = realized_reference_core_v1(binding.reference);
  if (bound_envelope->source_product != raw.product_id ||
      bound_envelope->construction_law_digest != raw.proposal_law_digest ||
      core.ordered_targets !=
          std::vector<QueueId>{bound_response->deployed_target} ||
      core.target_scope != MetricTargetScopeV1::deployed_singleton_target ||
      core.result_scope != MetricResultScopeV1::not_a_metric_result ||
      core.evidence_scope !=
          raw_envelope_evidence_scope(bound_envelope->scope)) {
    return failure<void>(
        "c15.object_graph_raw_envelope_core_scope",
        "raw-envelope realized core differs from its exact source, target or mapped C14 scope",
        path + "/core");
  }

  const auto raw_subject_count = std::count_if(
      core.role_relations.begin(), core.role_relations.end(),
      [&](const RealizedRoleRelationV1& relation) {
        return relation.relation == MetricRoleRelationKindV1::subject &&
               relation.key ==
                   MetricRoleKeyV1{binding.key.clause_id,
                                   MetricSupportRoleV1::raw_response} &&
               relation.referenced_object == raw.product_id.identity();
      });
  if (raw_subject_count != 1) {
    return failure<void>(
        "c15.object_graph_raw_envelope_source_relation",
        "raw-envelope role must carry one exact C14 raw-response subject relation",
        path + "/core/role_relations");
  }

  std::vector<ArtifactObjectReferenceV1> expected_coefficients;
  for (const auto bin : bound_envelope->covered_bins) {
    const auto rank = static_cast<std::size_t>(bin);
    if (rank >= raw.identifications.size()) {
      return failure<void>("c15.object_graph_raw_envelope_bin",
                           "raw envelope names an unknown coefficient bin",
                           path);
    }
    expected_coefficients.push_back(raw.identifications[rank].coefficient_id);
  }
  std::sort(expected_coefficients.begin(), expected_coefficients.end());
  std::vector<ArtifactObjectReferenceV1> actual_coefficients;
  const ArtifactObjectReferenceV1* evaluation = nullptr;
  const ArtifactObjectReferenceV1* proposal = nullptr;
  std::size_t evaluation_count = 0U;
  std::size_t proposal_count = 0U;
  for (const auto& relation : core.internal_relations) {
    if (relation.relation == MetricRoleRelationKindV1::subject &&
        relation.purpose == InternalReferencePurposeV1::coefficient_origin) {
      actual_coefficients.push_back(relation.referenced_object);
    }
    if (relation.relation == MetricRoleRelationKindV1::binding &&
        relation.purpose == InternalReferencePurposeV1::evaluation_identity) {
      ++evaluation_count;
      evaluation = &relation.referenced_object;
    }
    if (relation.relation == MetricRoleRelationKindV1::binding &&
        relation.purpose == InternalReferencePurposeV1::proposal_identity) {
      ++proposal_count;
      proposal = &relation.referenced_object;
    }
  }
  std::sort(actual_coefficients.begin(), actual_coefficients.end());
  const MetricRoleKeyV1 raw_key{binding.key.clause_id,
                                MetricSupportRoleV1::raw_response};
  const auto raw_binding = std::find_if(
      artifact_.realized_metric_bindings.bindings.begin(),
      artifact_.realized_metric_bindings.bindings.end(),
      [&raw_key](const RealizedMetricBindingV1& candidate) {
        return candidate.key == raw_key;
      });
  std::vector<ArtifactObjectReferenceV1> raw_origins;
  if (raw_binding != artifact_.realized_metric_bindings.bindings.end()) {
    for (const auto& relation :
         realized_reference_core_v1(raw_binding->reference)
             .internal_relations) {
      if (relation.relation ==
              MetricRoleRelationKindV1::lineage_parent &&
          relation.purpose ==
              InternalReferencePurposeV1::coefficient_origin) {
        raw_origins.push_back(relation.referenced_object);
      }
    }
  }
  if (actual_coefficients.size() != 1U ||
      !std::binary_search(expected_coefficients.begin(),
                          expected_coefficients.end(),
                          actual_coefficients.front()) ||
      raw_origins != actual_coefficients ||
      evaluation_count != 1U || proposal_count != 1U ||
      evaluation == nullptr || proposal == nullptr ||
      !artifact_.provenance.final_evaluation_id.has_value() ||
      !artifact_.provenance.proposal_id.has_value() ||
      evaluation->object_id != *artifact_.provenance.final_evaluation_id ||
      (bound_envelope->frozen_evaluation_id.has_value() &&
       evaluation->object_id != *bound_envelope->frozen_evaluation_id) ||
      proposal->object_id != *artifact_.provenance.proposal_id ||
      proposal->object_digest != bound_envelope->construction_law_digest) {
    return failure<void>(
        "c15.object_graph_raw_envelope_internal_binding",
        "raw-envelope core must name the same one covered coefficient origin as its raw role and preserve provenance-bound evaluation/proposal identities",
        path + "/core/internal_relations");
  }

  if (bound_envelope->family_evidence_envelope_ids.empty()) {
    return failure<void>(
        "c15.object_graph_raw_envelope_family_required",
        "a realized raw-envelope bound requires family evidence coverage",
        path);
  }
  for (const auto& family_id :
       bound_envelope->family_evidence_envelope_ids) {
    const auto family = std::find_if(
        artifact_.family_evidence.begin(), artifact_.family_evidence.end(),
        [&family_id](const FamilyEvidenceEnvelopeV1& evidence) {
          return evidence.evidence_id == family_id;
        });
    bool exact_family = family != artifact_.family_evidence.end() &&
                        family->evidence_scope_tag == core.evidence_scope &&
                        contains_target(family->construction_target_scope,
                                        bound_response->deployed_target) &&
                        contains_reference(family->subject_references,
                                           bound_envelope->envelope_id) &&
                        contains_reference(family->parent_references,
                                           raw.product_id.identity());
    for (const auto bin : bound_envelope->covered_bins) {
      const auto& coefficient =
          raw.identifications[static_cast<std::size_t>(bin)];
      exact_family =
          exact_family &&
          contains_reference(family->subject_references,
                             coefficient.coefficient_id) &&
          contains_reference(coefficient.family_evidence_envelope_ids,
                             family_id) &&
          family->provider_conformance_report_ref ==
              coefficient.provider_conformance_report_ref;
    }
    if (!exact_family) {
      return failure<void>(
          "c15.object_graph_raw_envelope_family_binding",
          "realized raw-envelope family evidence must bind its envelope, covered coefficients, raw parent, scope, report and target",
          path);
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::enumerate_internal_relations() {
  for (std::size_t index = 0U; index < artifact_.scoped_evidence.size();
       ++index) {
    const auto& evidence = artifact_.scoped_evidence[index];
    const std::string base =
        "/scoped_evidence/" + std::to_string(index) +
        "/internal_references/";
    for (std::size_t relation_index = 0U;
         relation_index < evidence.internal_references.size();
         ++relation_index) {
      const auto& relation = evidence.internal_references[relation_index];
      auto added = add_purpose_reference(
          evidence.evidence_id, relation,
          base + std::to_string(relation_index));
      if (!added) return added;
      evidence_dependencies_.push_back(
          {evidence.evidence_id, relation.referenced_object,
           base + std::to_string(relation_index) + "/referenced_object"});
      if (relation.relation == MetricRoleRelationKindV1::subject &&
          !contains_reference(evidence.subject_references,
                              relation.referenced_object)) {
        return failure<void>(
            "c15.object_graph_scoped_subject_ledger_mismatch",
            "a scoped evidence subject relation must occur in its exact subject ledger",
            base + std::to_string(relation_index));
      }
      if (relation.relation == MetricRoleRelationKindV1::lineage_parent &&
          !contains_reference(evidence.parent_references,
                              relation.referenced_object)) {
        return failure<void>(
            "c15.object_graph_scoped_parent_ledger_mismatch",
            "a scoped evidence lineage relation must occur in its exact parent ledger",
            base + std::to_string(relation_index));
      }
    }
  }

  for (std::size_t index = 0U;
       index < artifact_.realized_metric_bindings.bindings.size(); ++index) {
    const auto& binding = artifact_.realized_metric_bindings.bindings[index];
    const auto& owner = realized_reference_subject_v1(binding.reference);
    const auto* subject_metadata = find_exact(owner);
    if (subject_metadata == nullptr ||
        !contains_kind(subject_metadata->compatible_reference_kinds,
                       realized_reference_kind(binding.reference))) {
      return failure<void>(
          "c15.object_graph_realized_reference_kind",
          "realized metric reference does not resolve to the exact object kind carried by its typed alternative",
          "/realized_metric_bindings/bindings/" + std::to_string(index) +
              "/reference");
    }
    if (const auto* response_envelope =
            std::get_if<ResponseEnvelopeEvidenceV1>(&artifact_.payload);
        response_envelope != nullptr &&
        std::holds_alternative<RawResponseProductReferenceV1>(
            binding.reference)) {
      const std::size_t occurrence_count =
          static_cast<std::size_t>(
              response_envelope->lower_response.raw_response.product_id
                  .identity() == owner) +
          static_cast<std::size_t>(
              response_envelope->upper_response.raw_response.product_id
                  .identity() == owner);
      const bool exact_alias =
          response_envelope->lower_response ==
          response_envelope->upper_response;
      if (occurrence_count != 1U &&
          !(occurrence_count == 2U && exact_alias)) {
        return failure<void>(
            "c15.object_graph_nested_raw_subject_ambiguous",
            "a realized raw-response role in an envelope must resolve to one retained ledger or an exact lower/upper ledger alias",
            "/realized_metric_bindings/bindings/" +
                std::to_string(index) + "/reference");
      }
    }
    defer(owner, DeferredReference::Requirement::any,
          "/realized_metric_bindings/bindings/" + std::to_string(index) +
              "/reference/subject");
    const auto& core = realized_reference_core_v1(binding.reference);
    if (binding.key.role == MetricSupportRoleV1::compression_evidence) {
      const MetricRoleKeyV1 recoded_key{
          binding.key.clause_id, MetricSupportRoleV1::recoded_response};
      const auto recoded = std::find_if(
          artifact_.realized_metric_bindings.bindings.begin(),
          artifact_.realized_metric_bindings.bindings.end(),
          [&recoded_key](const RealizedMetricBindingV1& candidate) {
            return candidate.key == recoded_key;
          });
      std::vector<ArtifactObjectReferenceV1> exact_sources;
      if (recoded != artifact_.realized_metric_bindings.bindings.end()) {
        const auto& recoded_core =
            realized_reference_core_v1(recoded->reference);
        for (const auto& relation : recoded_core.role_relations) {
          if (relation.relation ==
              MetricRoleRelationKindV1::lineage_parent) {
            exact_sources.push_back(relation.referenced_object);
          }
        }
        for (const auto& relation : recoded_core.internal_relations) {
          if (relation.relation ==
                  MetricRoleRelationKindV1::lineage_parent &&
              relation.purpose ==
                  InternalReferencePurposeV1::completion_source) {
            exact_sources.push_back(relation.referenced_object);
          }
        }
      }
      std::sort(exact_sources.begin(), exact_sources.end());
      exact_sources.erase(
          std::unique(exact_sources.begin(), exact_sources.end()),
          exact_sources.end());
      const auto compression_source_count =
          static_cast<std::size_t>(std::count_if(
              core.internal_relations.begin(), core.internal_relations.end(),
              [](const RealizedInternalReferenceV1& relation) {
                return relation.relation ==
                           MetricRoleRelationKindV1::subject &&
                       relation.purpose ==
                           InternalReferencePurposeV1::compression_source;
              }));
      const auto exact_source_count = static_cast<std::size_t>(std::count_if(
          core.internal_relations.begin(), core.internal_relations.end(),
          [&exact_sources](const RealizedInternalReferenceV1& relation) {
            return relation.relation == MetricRoleRelationKindV1::subject &&
                   relation.purpose ==
                       InternalReferencePurposeV1::compression_source &&
                   std::binary_search(exact_sources.begin(),
                                      exact_sources.end(),
                                      relation.referenced_object);
      }));
      if (recoded == artifact_.realized_metric_bindings.bindings.end() ||
          compression_source_count != 1U || exact_source_count != 1U) {
        return failure<void>(
            "c15.object_graph_compression_source",
            "compression evidence source must equal an exact role-lineage parent or coefficient completion source of the same-clause recoded product",
            "/realized_metric_bindings/bindings/" +
                std::to_string(index) +
                "/reference/core/internal_relations");
      }
    }
    if (binding.key.role ==
        MetricSupportRoleV1::staged_opportunity_flux_law) {
      const auto* finite =
          std::get_if<FiniteLawTablesV1>(&artifact_.payload);
      const auto* staged =
          finite == nullptr
              ? nullptr
              : std::get_if<StagedOpportunityFluxTableV1>(&finite->table);
      const ArtifactObjectReferenceV1* expected_stage_law =
          staged == nullptr ? nullptr
                            : &staged->deterministic_update_descriptor;
      if (expected_stage_law == nullptr &&
          std::holds_alternative<RegisteredRuntimeRecipeV1>(
              artifact_.payload)) {
        // For a statically registered runtime recipe the digest-sealed
        // payload is the deterministic stage-law body.  There is no separate
        // finite-table update descriptor to bind.
        expected_stage_law = &artifact_.payload_identity;
      }
      const auto stage_law_count =
          expected_stage_law == nullptr
              ? 0U
              : static_cast<std::size_t>(std::count_if(
                    core.internal_relations.begin(),
                    core.internal_relations.end(),
                    [expected_stage_law](
                        const RealizedInternalReferenceV1& relation) {
                      return relation.relation ==
                                 MetricRoleRelationKindV1::binding &&
                             relation.purpose ==
                                 InternalReferencePurposeV1::stage_law &&
                             relation.referenced_object ==
                                 *expected_stage_law;
                    }));
      if (stage_law_count != 1U) {
        return failure<void>(
            "c15.object_graph_staged_law_descriptor",
            "staged-opportunity law must bind its exact deterministic-update descriptor or registered recipe payload",
            "/realized_metric_bindings/bindings/" +
                std::to_string(index) +
                "/reference/core/internal_relations");
      }
    }
    if (std::holds_alternative<RawResponseBoundEvidenceReferenceV1>(
            binding.reference) &&
        subject_metadata->object_class ==
            ArtifactObjectClassV1::raw_response_envelope) {
      auto envelope_binding =
          validate_realized_raw_envelope_binding(binding, index);
      if (!envelope_binding) return envelope_binding;
    }
    if (subject_metadata->object_class ==
        ArtifactObjectClassV1::scoped_evidence) {
      const auto scoped = std::find_if(
          artifact_.scoped_evidence.begin(), artifact_.scoped_evidence.end(),
          [&owner](const ScopedArtifactEvidenceV1& evidence) {
            return evidence.evidence_id == owner;
          });
      if (scoped == artifact_.scoped_evidence.end() ||
          core.internal_relations != scoped->internal_references) {
        return failure<void>(
            "c15.object_graph_scoped_internal_ledger_mismatch",
            "a realized scoped-evidence reference must use the exact internal relation ledger sealed by that evidence object",
            "/realized_metric_bindings/bindings/" +
                std::to_string(index) +
                "/reference/core/internal_relations");
      }
      for (const auto& relation : core.role_relations) {
        if (relation.relation == MetricRoleRelationKindV1::subject &&
            !contains_reference(scoped->subject_references,
                                relation.referenced_object)) {
          return failure<void>(
              "c15.object_graph_scoped_role_subject_mismatch",
              "realized subject relations must be present in the sealed scoped-evidence subject ledger",
              "/realized_metric_bindings/bindings/" +
                  std::to_string(index) +
                  "/reference/core/role_relations");
        }
        if (relation.relation ==
                MetricRoleRelationKindV1::lineage_parent &&
            !contains_reference(scoped->parent_references,
                                relation.referenced_object)) {
          return failure<void>(
              "c15.object_graph_scoped_role_parent_mismatch",
              "realized lineage relations must be present in the sealed scoped-evidence parent ledger",
              "/realized_metric_bindings/bindings/" +
                  std::to_string(index) +
                  "/reference/core/role_relations");
        }
      }
    }
    for (std::size_t relation_index = 0U;
         relation_index < core.role_relations.size(); ++relation_index) {
      const auto& relation = core.role_relations[relation_index];
      defer(relation.referenced_object, DeferredReference::Requirement::any,
            "/realized_metric_bindings/bindings/" +
                std::to_string(index) + "/reference/core/role_relations/" +
                std::to_string(relation_index) + "/referenced_object");
      if (relation.relation == MetricRoleRelationKindV1::lineage_parent) {
        add_parent(
            owner, relation.referenced_object,
            "/realized_metric_bindings/bindings/" +
                std::to_string(index) + "/reference/core/role_relations/" +
                std::to_string(relation_index) + "/referenced_object");
      }
    }
    for (std::size_t relation_index = 0U;
         relation_index < core.internal_relations.size(); ++relation_index) {
      auto added = add_purpose_reference(
          owner, core.internal_relations[relation_index],
          "/realized_metric_bindings/bindings/" +
              std::to_string(index) +
              "/reference/core/internal_relations/" +
              std::to_string(relation_index));
      if (!added) return added;
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::resolve_deferred_references() const {
  for (const auto& reference : deferred_) {
    const auto* object = find_exact(reference.identity);
    if (object == nullptr) {
      return failure<void>(
          "c15.object_graph_dangling_reference",
          "artifact reference does not resolve to an exact object identity in this artifact",
          reference.path);
    }
    bool compatible = false;
    switch (reference.requirement) {
      case DeferredReference::Requirement::any: compatible = true; break;
      case DeferredReference::Requirement::evidence:
        compatible = object->evidence_object;
        break;
      case DeferredReference::Requirement::family_evidence:
        compatible =
            object->object_class == ArtifactObjectClassV1::family_evidence;
        break;
      case DeferredReference::Requirement::scoped_evidence:
        compatible =
            object->object_class == ArtifactObjectClassV1::scoped_evidence;
        break;
      case DeferredReference::Requirement::coefficient:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::coefficient_identification;
        break;
      case DeferredReference::Requirement::raw_product:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::raw_response_product;
        break;
      case DeferredReference::Requirement::nominal_product:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::nominal_response_product;
        break;
      case DeferredReference::Requirement::projection_center:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::projection_center_product;
        break;
      case DeferredReference::Requirement::projected_mean:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::projected_mean_product;
        break;
      case DeferredReference::Requirement::recoded_product:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::recoded_response_product;
        break;
      case DeferredReference::Requirement::product:
        compatible = product_class(object->object_class);
        break;
      case DeferredReference::Requirement::comparison_domain:
        compatible = object->object_class ==
                     ArtifactObjectClassV1::comparison_domain;
        break;
    }
    if (!compatible) {
      return failure<void>(
          "c15.object_graph_reference_kind",
          "artifact reference resolves to an object of the wrong semantic kind",
          reference.path);
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_family_links() const {
  const auto find_family = [&](const ArtifactObjectReferenceV1& identity)
      -> const FamilyEvidenceEnvelopeV1* {
    const auto iterator = std::find_if(
        artifact_.family_evidence.begin(), artifact_.family_evidence.end(),
        [&identity](const FamilyEvidenceEnvelopeV1& family) {
          return family.evidence_id == identity;
        });
    return iterator == artifact_.family_evidence.end() ? nullptr : &*iterator;
  };
  const auto scope_covers = [](const std::span<const QueueId> scope,
                               const std::span<const QueueId> targets) {
    return std::all_of(targets.begin(), targets.end(),
                       [scope](const QueueId& target) {
                         return contains_target(scope, target);
                       });
  };
  const auto validate_response = [&](
                                     const ThreeBinScalarResponseV1& response,
                                     const std::string& path) -> Result<void> {
    const auto& raw = response.raw_response;
    for (std::size_t coefficient_index = 0U;
         coefficient_index < raw.identifications.size();
         ++coefficient_index) {
      const auto& coefficient = raw.identifications[coefficient_index];
      for (std::size_t evidence_index = 0U;
           evidence_index < coefficient.family_evidence_envelope_ids.size();
           ++evidence_index) {
        const auto* family =
            find_family(coefficient.family_evidence_envelope_ids[evidence_index]);
        if (family == nullptr ||
            !contains_reference(family->subject_references,
                                coefficient.coefficient_id) ||
            !contains_reference(family->parent_references,
                                raw.product_id.identity()) ||
            !scope_covers(family->construction_target_scope,
                          std::span<const QueueId>(&response.deployed_target,
                                                   1U))) {
          return failure<void>(
              "c15.object_graph_coefficient_family_lineage",
              "coefficient family evidence must subject the covered coefficient, parent the raw product, and cover its target",
              path + "/raw_response/identifications/" +
                  std::to_string(coefficient_index) +
                  "/family_evidence_envelope_ids/" +
                  std::to_string(evidence_index));
        }
      }
    }
    for (std::size_t envelope_index = 0U;
         envelope_index < response.raw_envelopes.size(); ++envelope_index) {
      const auto& envelope = response.raw_envelopes[envelope_index];
      for (std::size_t evidence_index = 0U;
           evidence_index < envelope.family_evidence_envelope_ids.size();
           ++evidence_index) {
        const auto* family =
            find_family(envelope.family_evidence_envelope_ids[evidence_index]);
        bool covers_coefficients = family != nullptr;
        if (family != nullptr) {
          for (const auto bin : envelope.covered_bins) {
            const auto rank = static_cast<std::size_t>(bin);
            if (rank >= raw.identifications.size()) {
              covers_coefficients = false;
              break;
            }
            const auto& coefficient = raw.identifications[rank];
            if (!contains_reference(
                    family->subject_references,
                    coefficient.coefficient_id) ||
                !contains_reference(
                    coefficient.family_evidence_envelope_ids,
                    family->evidence_id) ||
                family->provider_conformance_report_ref !=
                    coefficient.provider_conformance_report_ref) {
              covers_coefficients = false;
              break;
            }
          }
        }
        if (family == nullptr || !covers_coefficients ||
            !contains_reference(family->subject_references,
                                envelope.envelope_id) ||
            !contains_reference(family->parent_references,
                                raw.product_id.identity()) ||
            family->evidence_scope_tag !=
                raw_envelope_evidence_scope(envelope.scope) ||
            !scope_covers(family->construction_target_scope,
                          std::span<const QueueId>(&response.deployed_target,
                                                   1U))) {
          return failure<void>(
              "c15.object_graph_raw_envelope_family_coverage",
              "raw-envelope family evidence must reciprocally bind the envelope and every named coefficient/report, parent the raw product, and preserve target/evidence scope",
              path + "/raw_envelopes/" +
                  std::to_string(envelope_index) +
                  "/family_evidence_envelope_ids/" +
                  std::to_string(evidence_index));
        }
      }
    }
    return Result<void>::success();
  };
  const auto validate_finite_prefix = [&]() -> Result<void> {
    const auto* response =
        std::get_if<FinitePrefixConstantTailResponseV1>(&artifact_.payload);
    if (response == nullptr) return Result<void>::success();
    const auto& raw = response->raw_response;
    for (std::size_t index = 0U; index < raw.identifications.size(); ++index) {
      const auto& coefficient = raw.identifications[index];
      for (std::size_t evidence_index = 0U;
           evidence_index < coefficient.family_evidence_envelope_ids.size();
           ++evidence_index) {
        const auto* family = find_family(
            coefficient.family_evidence_envelope_ids[evidence_index]);
        if (family == nullptr ||
            !contains_reference(family->subject_references,
                                coefficient.coefficient_id) ||
            !contains_reference(family->parent_references,
                                raw.product_id.identity()) ||
            !scope_covers(
                family->construction_target_scope,
                std::span<const QueueId>(&response->deployed_target, 1U))) {
          return failure<void>(
              "c15.object_graph_finite_prefix_coefficient_family_lineage",
              "dynamic coefficient family evidence must subject the "
              "coefficient, parent the raw product and cover its target",
              "/payload/raw_response/identifications/" +
                  std::to_string(index) +
                  "/family_evidence_envelope_ids/" +
                  std::to_string(evidence_index));
        }
      }
    }
    for (std::size_t envelope_index = 0U;
         envelope_index < response->raw_envelopes.size(); ++envelope_index) {
      const auto& envelope = response->raw_envelopes[envelope_index];
      for (std::size_t evidence_index = 0U;
           evidence_index < envelope.family_evidence_envelope_ids.size();
           ++evidence_index) {
        const auto* family =
            find_family(envelope.family_evidence_envelope_ids[evidence_index]);
        bool covers = family != nullptr &&
                      envelope.covered_coordinates.size() ==
                          raw.identifications.size();
        for (std::size_t coordinate_index = 0U;
             covers && coordinate_index < envelope.covered_coordinates.size();
             ++coordinate_index) {
          const auto& coefficient = raw.identifications[coordinate_index];
          covers = envelope.covered_coordinates[coordinate_index] ==
                       coefficient.coordinate &&
                   contains_reference(family->subject_references,
                                      coefficient.coefficient_id) &&
                   contains_reference(
                       coefficient.family_evidence_envelope_ids,
                       family->evidence_id) &&
                   family->provider_conformance_report_ref ==
                       coefficient.provider_conformance_report_ref;
        }
        if (family == nullptr || !covers ||
            !contains_reference(family->subject_references,
                                envelope.envelope_id) ||
            !contains_reference(family->parent_references,
                                raw.product_id.identity()) ||
            family->evidence_scope_tag !=
                raw_envelope_evidence_scope(envelope.scope) ||
            !scope_covers(
                family->construction_target_scope,
                std::span<const QueueId>(&response->deployed_target, 1U))) {
          return failure<void>(
              "c15.object_graph_finite_prefix_envelope_family_coverage",
              "dynamic raw-envelope family evidence must reciprocally bind "
              "the full ordered coefficient family and exact raw parent",
              "/payload/raw_envelopes/" +
                  std::to_string(envelope_index) +
                  "/family_evidence_envelope_ids/" +
                  std::to_string(evidence_index));
        }
      }
    }
    return Result<void>::success();
  };

  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact_.payload)) {
    auto checked = validate_response(*response, "/payload");
    if (!checked) return checked;
  } else if (std::holds_alternative<
                 FinitePrefixConstantTailResponseV1>(artifact_.payload)) {
    auto checked = validate_finite_prefix();
    if (!checked) return checked;
  } else if (const auto* envelope =
                 std::get_if<ResponseEnvelopeEvidenceV1>(
                     &artifact_.payload)) {
    auto checked =
        validate_response(envelope->lower_response, "/payload/lower_response");
    if (!checked) return checked;
    checked =
        validate_response(envelope->upper_response, "/payload/upper_response");
    if (!checked) return checked;
  }

  for (std::size_t index = 0U; index < artifact_.scoped_evidence.size();
       ++index) {
    const auto& scoped = artifact_.scoped_evidence[index];
    for (std::size_t family_index = 0U;
         family_index < scoped.family_envelope_ids.size(); ++family_index) {
      const auto* family =
          find_family(scoped.family_envelope_ids[family_index]);
      const bool common_subject =
          family != nullptr &&
          std::any_of(scoped.subject_references.begin(),
                      scoped.subject_references.end(),
                      [family](const ArtifactObjectReferenceV1& subject) {
                        return contains_reference(family->subject_references,
                                                  subject);
                      });
      if (family == nullptr || !common_subject ||
          family->evidence_scope_tag != scoped.evidence_scope ||
          !scope_covers(family->construction_target_scope,
                        scoped.ordered_targets)) {
        return failure<void>(
            "c15.object_graph_scoped_family_scope",
            "scoped and family evidence must share an exact subject and preserve target/evidence scope",
            "/scoped_evidence/" + std::to_string(index) +
                "/family_envelope_ids/" + std::to_string(family_index));
      }
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_response_envelope_links() const {
  const auto* envelope =
      std::get_if<ResponseEnvelopeEvidenceV1>(&artifact_.payload);
  if (envelope == nullptr) return Result<void>::success();
  const auto& lower = deployed_response_product_identity_v1(
      envelope->lower_response_product);
  const auto& upper = deployed_response_product_identity_v1(
      envelope->upper_response_product);
  const auto scoped_for = [&](const ArtifactObjectReferenceV1& identity)
      -> const ScopedArtifactEvidenceV1* {
    const auto iterator = std::find_if(
        artifact_.scoped_evidence.begin(), artifact_.scoped_evidence.end(),
        [&identity](const ScopedArtifactEvidenceV1& evidence) {
          return evidence.evidence_id == identity;
        });
    return iterator == artifact_.scoped_evidence.end() ? nullptr : &*iterator;
  };
  const auto has_relation = [](
                                const ScopedArtifactEvidenceV1& evidence,
                                const MetricRoleRelationKindV1 relation,
                                const InternalReferencePurposeV1 purpose,
                                const ArtifactObjectReferenceV1* identity) {
    return std::any_of(
        evidence.internal_references.begin(),
        evidence.internal_references.end(),
        [&](const RealizedInternalReferenceV1& item) {
          return item.relation == relation && item.purpose == purpose &&
                 (identity == nullptr ||
                  item.referenced_object == *identity);
        });
  };
  bool has_order = false;
  bool has_physical = false;
  bool has_raw_bound =
      !envelope->lower_response.raw_envelopes.empty() ||
      !envelope->upper_response.raw_envelopes.empty();
  for (std::size_t index = 0U;
       index < envelope->typed_evidence_components.size(); ++index) {
    const auto* evidence = scoped_for(envelope->typed_evidence_components[index]);
    const bool permitted_kind =
        evidence != nullptr &&
        (evidence->reference_kind ==
             ArtifactReferenceKindV1::raw_response_bound_evidence ||
         evidence->reference_kind ==
             ArtifactReferenceKindV1::response_order_evidence ||
         evidence->reference_kind ==
             ArtifactReferenceKindV1::physical_transfer_evidence);
    if (!permitted_kind ||
        evidence->ordered_targets != envelope->ordered_deployed_targets) {
      return failure<void>(
          "c15.object_graph_response_envelope_evidence_binding",
          "each typed envelope component must be scoped raw-bound, response-order or physical-transfer evidence under the exact envelope target order",
          "/payload/typed_evidence_components/" + std::to_string(index));
    }
    if (evidence->reference_kind ==
        ArtifactReferenceKindV1::response_order_evidence) {
      const bool lower_named = has_relation(
          *evidence, MetricRoleRelationKindV1::subject,
          InternalReferencePurposeV1::lower_response_product, &lower);
      const bool upper_named = has_relation(
          *evidence, MetricRoleRelationKindV1::subject,
          InternalReferencePurposeV1::upper_response_product, &upper);
      const bool domain_named = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::comparison_domain,
          &envelope->comparison_domain_id);
      const bool direction_named = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::transfer_direction, nullptr);
      const bool validity_named = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::validity_basis, nullptr);
      if (evidence->result_scope !=
              MetricResultScopeV1::not_a_metric_result ||
          evidence->evidence_scope !=
              MetricEvidenceScopeV1::deployed_surrogate_law ||
          !lower_named || !upper_named || !domain_named || !direction_named ||
          !validity_named) {
        return failure<void>(
            "c15.object_graph_response_order_relation",
            "response-order evidence must carry the exact C14 lower/upper subjects and comparison/direction/validity bindings",
            "/payload/typed_evidence_components/" +
                std::to_string(index));
      }
      has_order = true;
    }
    if (evidence->reference_kind ==
        ArtifactReferenceKindV1::physical_transfer_evidence) {
      const bool theorem = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::transfer_theorem, nullptr);
      const bool assumption = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::transfer_assumption, nullptr);
      const bool direction = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::transfer_direction, nullptr);
      const bool error = has_relation(
          *evidence, MetricRoleRelationKindV1::evidence,
          InternalReferencePurposeV1::error_object, nullptr);
      const bool source = has_relation(
          *evidence, MetricRoleRelationKindV1::subject,
          InternalReferencePurposeV1::surrogate_source,
          &artifact_.payload_identity);
      const bool model = has_relation(
          *evidence, MetricRoleRelationKindV1::subject,
          InternalReferencePurposeV1::physical_model, nullptr);
      const bool metric = has_relation(
          *evidence, MetricRoleRelationKindV1::subject,
          InternalReferencePurposeV1::physical_metric, nullptr);
      if (evidence->result_scope != MetricResultScopeV1::physical_bound ||
          evidence->evidence_scope !=
              MetricEvidenceScopeV1::physical_system ||
          !theorem || !assumption || !direction || !error || !source ||
          !model || !metric) {
        return failure<void>(
            "c15.object_graph_physical_transfer_relation",
            "physical-transfer evidence must retain its exact physical scope and complete C14 theorem/assumption/direction/error/source/model/metric ledger",
            "/payload/typed_evidence_components/" +
                std::to_string(index));
      }
      has_physical = true;
    }
    if (evidence->reference_kind ==
        ArtifactReferenceKindV1::raw_response_bound_evidence) {
      const auto& lower_raw =
          envelope->lower_response.raw_response.product_id.identity();
      const auto& upper_raw =
          envelope->upper_response.raw_response.product_id.identity();
      const bool raw_named =
          contains_reference(evidence->subject_references, lower_raw) ||
          contains_reference(evidence->subject_references, upper_raw);
      const bool coefficient_named = std::any_of(
          evidence->internal_references.begin(),
          evidence->internal_references.end(),
          [](const RealizedInternalReferenceV1& relation) {
            return relation.relation == MetricRoleRelationKindV1::subject &&
                   relation.purpose ==
                       InternalReferencePurposeV1::coefficient_origin;
          });
      const bool evaluation_named = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::evaluation_identity, nullptr);
      const bool proposal_named = has_relation(
          *evidence, MetricRoleRelationKindV1::binding,
          InternalReferencePurposeV1::proposal_identity, nullptr);
      const bool raw_scope =
          evidence->result_scope ==
              MetricResultScopeV1::not_a_metric_result &&
          (evidence->evidence_scope ==
               MetricEvidenceScopeV1::raw_static_proposal ||
           evidence->evidence_scope ==
               MetricEvidenceScopeV1::optimizer_interval_raw);
      if (!raw_scope || !raw_named || !coefficient_named ||
          !evaluation_named || !proposal_named) {
        return failure<void>(
            "c15.object_graph_raw_bound_relation",
            "raw-bound evidence must carry the exact raw/coefficient subjects and evaluation/proposal bindings",
            "/payload/typed_evidence_components/" +
                std::to_string(index));
      }
      has_raw_bound = true;
    }
  }

  std::vector<ArtifactObjectReferenceV1> realized_scoped_components;
  bool has_envelope_binding = false;
  const auto nested_raw_envelope_count =
      [&](const ArtifactObjectReferenceV1& identity) {
        const auto count_in = [&](const ThreeBinScalarResponseV1& response) {
          return static_cast<std::size_t>(std::count_if(
              response.raw_envelopes.begin(), response.raw_envelopes.end(),
              [&identity](const RawResponseEnvelopeV1& candidate) {
                return candidate.envelope_id == identity;
              }));
        };
        return count_in(envelope->lower_response) +
               count_in(envelope->upper_response);
      };
  const auto uniquely_owned_or_aliased = [&](const std::size_t count) {
    return count == 1U ||
           (count == 2U &&
            envelope->lower_response == envelope->upper_response);
  };
  for (const auto& binding : artifact_.realized_metric_bindings.bindings) {
    if (binding.key.role != MetricSupportRoleV1::response_envelope ||
        realized_reference_subject_v1(binding.reference) !=
            artifact_.payload_identity) {
      continue;
    }
    has_envelope_binding = true;
    for (const auto& relation :
         realized_reference_core_v1(binding.reference).role_relations) {
      if (relation.relation != MetricRoleRelationKindV1::evidence) continue;
      const auto* metadata = find_exact(relation.referenced_object);
      if (metadata != nullptr &&
          metadata->object_class == ArtifactObjectClassV1::scoped_evidence) {
        if (!contains_reference(envelope->typed_evidence_components,
                                relation.referenced_object)) {
          return failure<void>(
              "c15.object_graph_response_envelope_component_missing",
              "every scoped same-clause response-envelope evidence subject must occur in typed_evidence_components",
              "/payload/typed_evidence_components");
        }
        if (!contains_reference(realized_scoped_components,
                                relation.referenced_object)) {
          realized_scoped_components.push_back(relation.referenced_object);
        }
      } else if (
          relation.key.role ==
              MetricSupportRoleV1::raw_response_bound_evidence &&
          metadata != nullptr &&
          metadata->object_class ==
              ArtifactObjectClassV1::raw_response_envelope &&
          uniquely_owned_or_aliased(
              nested_raw_envelope_count(relation.referenced_object))) {
        // The direct raw-envelope alternative remains in its retained lower
        // or upper ledger and is intentionally not duplicated in the scoped
        // typed-component vector.
      } else {
        return failure<void>(
            "c15.object_graph_response_envelope_evidence_subject",
            "a response-envelope evidence relation must resolve to one listed scoped component or one direct raw envelope retained in a unique or exactly aliased ledger",
            "/realized_metric_bindings/bindings");
      }
    }
  }
  if (!has_envelope_binding ||
      std::any_of(
          envelope->typed_evidence_components.begin(),
          envelope->typed_evidence_components.end(),
          [&](const ArtifactObjectReferenceV1& identity) {
            return !contains_reference(realized_scoped_components, identity);
          })) {
    return failure<void>(
        "c15.object_graph_response_envelope_component_unbound",
        "typed_evidence_components must equal scoped evidence subjects used by same-clause realized response-envelope bindings",
        "/payload/typed_evidence_components");
  }
  if (!has_order) {
    return failure<void>(
        "c15.object_graph_response_order_evidence_required",
        "response envelope requires an exact response-order evidence component",
        "/payload/typed_evidence_components");
  }
  if (!has_raw_bound) {
    return failure<void>(
        "c15.object_graph_raw_bound_evidence_required",
        "response envelope requires a resolved local raw-response bound",
        "/payload/typed_evidence_components");
  }
  if ((envelope->result_scope == MetricResultScopeV1::physical_bound ||
       envelope->evidence_scope == MetricEvidenceScopeV1::physical_system) &&
      !has_physical) {
    return failure<void>(
        "c15.object_graph_physical_transfer_evidence_required",
        "a physical response envelope requires a distinct physical-transfer evidence component",
        "/payload/typed_evidence_components");
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_raw_bound_scoped_links() const {
  std::vector<const ThreeBinScalarResponseV1*> responses;
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact_.payload)) {
    responses.push_back(response);
  } else if (const auto* envelope =
                 std::get_if<ResponseEnvelopeEvidenceV1>(
                     &artifact_.payload)) {
    responses.push_back(&envelope->lower_response);
    responses.push_back(&envelope->upper_response);
  }
  for (std::size_t index = 0U; index < artifact_.scoped_evidence.size();
       ++index) {
    const auto& evidence = artifact_.scoped_evidence[index];
    if (evidence.reference_kind !=
        ArtifactReferenceKindV1::raw_response_bound_evidence) {
      continue;
    }
    const std::string path =
        "/scoped_evidence/" + std::to_string(index);
    const ThreeBinScalarResponseV1* bound_response = nullptr;
    std::size_t raw_ledger_match_count = 0U;
    for (const auto* response : responses) {
      if (contains_reference(
              evidence.subject_references,
              response->raw_response.product_id.identity())) {
        ++raw_ledger_match_count;
        bound_response = response;
      }
    }
    const auto* response_envelope =
        std::get_if<ResponseEnvelopeEvidenceV1>(&artifact_.payload);
    const bool exact_alias =
        response_envelope != nullptr &&
        response_envelope->lower_response ==
            response_envelope->upper_response;
    if (bound_response == nullptr ||
        (raw_ledger_match_count != 1U &&
         !(raw_ledger_match_count == 2U && exact_alias)) ||
        evidence.ordered_targets !=
            std::vector<QueueId>{bound_response->deployed_target} ||
        evidence.result_scope != MetricResultScopeV1::not_a_metric_result ||
        (evidence.evidence_scope !=
             MetricEvidenceScopeV1::raw_static_proposal &&
         evidence.evidence_scope !=
             MetricEvidenceScopeV1::optimizer_interval_raw)) {
      return failure<void>(
          "c15.object_graph_raw_bound_product_scope",
          "raw-bound evidence must subject a raw product from one retained ledger or an exact lower/upper alias under its singleton target and closed C14 scope",
          path);
    }

    const CoefficientIdentificationV1* bound_coefficient = nullptr;
    std::size_t coefficient_count = 0U;
    std::size_t evaluation_count = 0U;
    std::size_t proposal_count = 0U;
    const ArtifactObjectReferenceV1* evaluation = nullptr;
    const ArtifactObjectReferenceV1* proposal = nullptr;
    for (const auto& relation : evidence.internal_references) {
      if (relation.relation == MetricRoleRelationKindV1::subject &&
          relation.purpose ==
              InternalReferencePurposeV1::coefficient_origin) {
        ++coefficient_count;
        const auto coefficient = std::find_if(
            bound_response->raw_response.identifications.begin(),
            bound_response->raw_response.identifications.end(),
            [&](const CoefficientIdentificationV1& coefficient) {
              return coefficient.coefficient_id ==
                     relation.referenced_object;
            });
        if (coefficient ==
            bound_response->raw_response.identifications.end()) {
          return failure<void>(
              "c15.object_graph_raw_bound_coefficient",
              "raw-bound coefficient subject is not an identification in its exact raw product",
              path + "/internal_references");
        }
        bound_coefficient = &*coefficient;
      }
      if (relation.relation == MetricRoleRelationKindV1::binding &&
          relation.purpose ==
              InternalReferencePurposeV1::evaluation_identity) {
        ++evaluation_count;
        evaluation = &relation.referenced_object;
      }
      if (relation.relation == MetricRoleRelationKindV1::binding &&
          relation.purpose == InternalReferencePurposeV1::proposal_identity) {
        ++proposal_count;
        proposal = &relation.referenced_object;
      }
    }
    if (coefficient_count != 1U || bound_coefficient == nullptr) {
      return failure<void>(
          "c15.object_graph_raw_bound_coefficient",
          "raw-bound evidence must name exactly one coefficient identification in its retained raw product",
          path + "/internal_references");
    }

    std::vector<const RawResponseEnvelopeV1*> retained_envelopes;
    for (const auto& envelope : bound_response->raw_envelopes) {
      const bool covers_coefficient =
          std::find(envelope.covered_bins.begin(),
                    envelope.covered_bins.end(),
                    bound_coefficient->target_bin_binding) !=
          envelope.covered_bins.end();
      const bool same_family_scope = std::all_of(
          envelope.family_evidence_envelope_ids.begin(),
          envelope.family_evidence_envelope_ids.end(),
          [&](const ArtifactObjectReferenceV1& family) {
            return contains_reference(evidence.family_envelope_ids, family);
          });
      if (covers_coefficient &&
          envelope.source_product ==
              bound_response->raw_response.product_id &&
          raw_envelope_evidence_scope(envelope.scope) ==
              evidence.evidence_scope &&
          same_family_scope) {
        retained_envelopes.push_back(&envelope);
      }
    }

    const bool proved_zero_absence =
        bound_coefficient->coefficient_status
                .population_conditioning_status ==
            PopulationConditioningStatusV1::proved_zero &&
        bound_coefficient->coefficient_status.raw_value_status ==
            RawValueStatusV1::absent;
    const bool raw_absence =
        bound_coefficient->coefficient_status.raw_value_status ==
        RawValueStatusV1::absent;
    if (raw_absence && !proved_zero_absence) {
      return failure<void>(
          "c15.object_graph_raw_bound_absence_proof",
          "only exact-population proved-zero absence can fulfill a raw-bound evidence role",
          path);
    }
    if (proved_zero_absence) {
      if (!retained_envelopes.empty() ||
          bound_coefficient->family_evidence_envelope_ids.empty() ||
          evidence.family_envelope_ids !=
              bound_coefficient->family_evidence_envelope_ids) {
        return failure<void>(
            "c15.object_graph_raw_bound_absence_proof",
            "proved-zero absence evidence must carry no numerical envelope and must exactly repeat the coefficient's nonempty family-proof identities",
            path);
      }
      for (const auto& family_id : evidence.family_envelope_ids) {
        const auto family = std::find_if(
            artifact_.family_evidence.begin(), artifact_.family_evidence.end(),
            [&family_id](const FamilyEvidenceEnvelopeV1& candidate) {
              return candidate.evidence_id == family_id;
            });
        if (family == artifact_.family_evidence.end() ||
            family->provider_conformance_report_ref !=
                bound_coefficient->provider_conformance_report_ref ||
            !contains_reference(family->subject_references,
                                bound_coefficient->coefficient_id) ||
            !contains_reference(
                family->parent_references,
                bound_response->raw_response.product_id.identity()) ||
            family->evidence_scope_tag != evidence.evidence_scope) {
          return failure<void>(
              "c15.object_graph_raw_bound_absence_family",
              "absence proof family evidence must bind the exact coefficient, conformance report, raw parent and evidence scope",
              path + "/family_envelope_ids");
        }
      }
    } else if (retained_envelopes.empty()) {
      return failure<void>(
          "c15.object_graph_raw_bound_envelope_required",
          "a non-absent raw-bound role must resolve a retained numerical envelope covering its exact coefficient and scope",
          path + "/subject_references");
    }

    if (evaluation_count != 1U || proposal_count != 1U ||
        evaluation == nullptr || proposal == nullptr ||
        !artifact_.provenance.final_evaluation_id.has_value() ||
        !artifact_.provenance.proposal_id.has_value() ||
        evaluation->object_id != *artifact_.provenance.final_evaluation_id ||
        proposal->object_id != *artifact_.provenance.proposal_id ||
        proposal->object_digest !=
            bound_response->raw_response.proposal_law_digest ||
        (!proved_zero_absence && std::any_of(
            retained_envelopes.begin(), retained_envelopes.end(),
            [evaluation](const RawResponseEnvelopeV1* envelope) {
              return envelope->frozen_evaluation_id.has_value() &&
                     *envelope->frozen_evaluation_id !=
                         evaluation->object_id;
            }))) {
      return failure<void>(
          "c15.object_graph_raw_bound_provenance",
          "raw-bound evidence requires exact coefficient, final-evaluation and proposal identities bound to artifact provenance",
          path + "/internal_references");
    }
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_empirical_provenance_links() const {
  std::vector<TypedLabel> frozen_evaluations;
  const auto collect = [&](const ThreeBinScalarResponseV1& response) {
    for (const auto& coefficient : response.raw_response.identifications) {
      if (coefficient.proposal_conditioning.source ==
              ProposalConditioningSourceV1::empirical_average &&
          coefficient.proposal_conditioning.frozen_evaluation_id.has_value()) {
        frozen_evaluations.push_back(
            *coefficient.proposal_conditioning.frozen_evaluation_id);
      }
    }
    for (const auto& envelope : response.raw_envelopes) {
      if (envelope.frozen_evaluation_id.has_value()) {
        frozen_evaluations.push_back(*envelope.frozen_evaluation_id);
      }
    }
  };
  if (const auto* response =
          std::get_if<ThreeBinScalarResponseV1>(&artifact_.payload)) {
    collect(*response);
  } else if (const auto* response =
                 std::get_if<FinitePrefixConstantTailResponseV1>(
                     &artifact_.payload)) {
    for (const auto& envelope : response->raw_envelopes) {
      frozen_evaluations.push_back(envelope.frozen_evaluation_id);
    }
  } else if (const auto* envelope =
                 std::get_if<ResponseEnvelopeEvidenceV1>(
                     &artifact_.payload)) {
    collect(envelope->lower_response);
    collect(envelope->upper_response);
  }
  if (frozen_evaluations.empty()) return Result<void>::success();
  if (!artifact_.provenance.proposal_id.has_value() ||
      !artifact_.provenance.final_evaluation_id.has_value() ||
      std::any_of(frozen_evaluations.begin(), frozen_evaluations.end(),
                  [&](const TypedLabel& identity) {
                    return identity !=
                           *artifact_.provenance.final_evaluation_id;
                  })) {
    return failure<void>(
        "c15.object_graph_empirical_provenance_binding",
        "empirical response evidence requires one proposal identity and one exact shared final-evaluation identity in provenance",
        "/provenance");
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_parent_dag() const {
  for (const auto& edge : parents_) {
    if (edge.child == edge.parent) {
      return failure<void>("c15.object_graph_self_parent",
                           "an artifact object cannot be its own lineage parent",
                           edge.path);
    }
    if (find_exact(edge.child) == nullptr || find_exact(edge.parent) == nullptr) {
      return failure<void>("c15.object_graph_dangling_parent",
                           "every lineage edge must resolve both exact endpoints",
                           edge.path);
    }
  }
  const auto index_of = [&](const ArtifactObjectReferenceV1& identity) {
    const auto iterator = std::find_if(
        graph_.objects.begin(), graph_.objects.end(),
        [&identity](const ArtifactObjectMetadataV1& object) {
          return object.identity == identity;
        });
    return static_cast<std::size_t>(
        std::distance(graph_.objects.begin(), iterator));
  };
  std::vector<std::vector<std::size_t>> outgoing(graph_.objects.size());
  std::vector<std::size_t> indegree(graph_.objects.size(), 0U);
  for (const auto& edge : parents_) {
    const std::size_t child = index_of(edge.child);
    const std::size_t parent = index_of(edge.parent);
    outgoing[child].push_back(parent);
    ++indegree[parent];
  }
  std::vector<std::size_t> ready;
  ready.reserve(graph_.objects.size());
  for (std::size_t index = 0U; index < indegree.size(); ++index) {
    if (indegree[index] == 0U) ready.push_back(index);
  }
  std::size_t visited = 0U;
  while (!ready.empty()) {
    const std::size_t node = ready.back();
    ready.pop_back();
    ++visited;
    for (const std::size_t parent : outgoing[node]) {
      --indegree[parent];
      if (indegree[parent] == 0U) ready.push_back(parent);
    }
  }
  if (visited != graph_.objects.size()) {
    return failure<void>(
        "c15.object_graph_lineage_cycle",
        "artifact product/evidence lineage must form an acyclic graph",
        "/realized_metric_bindings");
  }
  return Result<void>::success();
}

Result<void> GraphBuilder::validate_evidence_dependency_dag() const {
  const auto index_of = [&](const ArtifactObjectReferenceV1& identity) {
    const auto iterator = std::find_if(
        graph_.objects.begin(), graph_.objects.end(),
        [&identity](const ArtifactObjectMetadataV1& object) {
          return object.identity == identity;
        });
    return static_cast<std::size_t>(
        std::distance(graph_.objects.begin(), iterator));
  };
  std::vector<std::vector<std::size_t>> outgoing(graph_.objects.size());
  std::vector<std::size_t> indegree(graph_.objects.size(), 0U);
  std::size_t evidence_count = 0U;
  for (std::size_t index = 0U; index < graph_.objects.size(); ++index) {
    if (graph_.objects[index].evidence_object) ++evidence_count;
  }
  for (const auto& edge : evidence_dependencies_) {
    const auto* child = find_exact(edge.child);
    const auto* dependency = find_exact(edge.parent);
    if (child == nullptr || dependency == nullptr ||
        !child->evidence_object || !dependency->evidence_object) {
      continue;
    }
    const std::size_t child_index = index_of(edge.child);
    const std::size_t dependency_index = index_of(edge.parent);
    outgoing[child_index].push_back(dependency_index);
    ++indegree[dependency_index];
  }
  std::vector<std::size_t> ready;
  ready.reserve(evidence_count);
  for (std::size_t index = 0U; index < graph_.objects.size(); ++index) {
    if (graph_.objects[index].evidence_object && indegree[index] == 0U) {
      ready.push_back(index);
    }
  }
  std::size_t visited = 0U;
  while (!ready.empty()) {
    const std::size_t node = ready.back();
    ready.pop_back();
    ++visited;
    for (const std::size_t dependency : outgoing[node]) {
      --indegree[dependency];
      if (indegree[dependency] == 0U) ready.push_back(dependency);
    }
  }
  if (visited != evidence_count) {
    return failure<void>(
        "c15.object_graph_evidence_digest_cycle",
        "full-digest family/scoped evidence dependencies must be acyclic",
        "/family_evidence");
  }
  return Result<void>::success();
}

Result<ValidatedArtifactObjectGraphV1> GraphBuilder::build() {
  auto stage = enumerate_payload();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = enumerate_family_and_auxiliary();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = enumerate_internal_relations();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = resolve_deferred_references();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = validate_family_links();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = validate_response_envelope_links();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = validate_raw_bound_scoped_links();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = validate_empirical_provenance_links();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = validate_evidence_dependency_dag();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  stage = validate_parent_dag();
  if (!stage) {
    return Result<ValidatedArtifactObjectGraphV1>::failure(stage.error());
  }
  std::sort(graph_.objects.begin(), graph_.objects.end(),
            [](const ArtifactObjectMetadataV1& left,
               const ArtifactObjectMetadataV1& right) {
              return left.identity < right.identity;
            });
  return Result<ValidatedArtifactObjectGraphV1>::success(std::move(graph_));
}

}  // namespace mwperf::artifact::detail
