#pragma once

#include <span>

#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf::artifact::detail {

// Private, noncatalog portion of F-C15-06.  It validates only the generic
// family-evidence envelope and treats the provider-owned body as bounded
// canonical data.  Resolution of its subject and parent references against
// the complete artifact object ledger remains the responsibility of F-C15-06.
[[nodiscard]] Result<void> validate_family_evidence_ledger_v1(
    std::span<const FamilyEvidenceEnvelopeV1> ledger,
    const ProviderIdentityV1& expected_provider,
    const Digest256& expected_scientific_contract_digest,
    const Digest256& expected_request_digest,
    const Digest256& expected_payload_digest,
    std::span<const QueueId> accepted_construction_target_scope,
    const ValidatedProviderManifest& validated_full_manifest,
    const MetricSupportManifest& accepted_structural_manifest);

}  // namespace mwperf::artifact::detail
