#include "surrogate/surrogate_registry_internal.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <exception>
#include <limits>
#include <memory>
#include <new>
#include <string>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/sampling/estimators.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/kernel_access.hpp"

#if defined(MWPERF_C16_TEST_SEAMS)
#include "tests/support/c16_test_providers.hpp"
#endif

#if defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER) && \
    !defined(MWPERF_C16_TEST_SEAMS)
#include "surrogate/providers/full_orbit_sampler_provider.hpp"
#endif

namespace mwperf {

struct SurrogateProvider::State final {
  ValidatedProviderManifest manifest;
  ParameterValidatorV1 parameter_validator;
  DescriptorPreviewerV1 previewer;
  ProviderProducerV1 producer;
  RuntimePlugMaterializerV1 materializer;
  std::optional<FrameworkActivationRegistrationV1> framework_activation;
  std::uint32_t result_protocol_version;
  std::optional<ObservationEnvelopeValidatorV1>
      observation_envelope_validator;
};

namespace {

[[nodiscard]] const void* production_registry_provenance_seal() noexcept {
  // The address is translation-unit-private and has static storage duration.
  // Dependency-injected registries receive nullptr and cannot authorize any
  // provider callback merely by reproducing registered data.
  static const unsigned char seal = 0U;
  return &seal;
}

[[nodiscard]] Diagnostic registry_error(std::string code,
                                        std::string message) {
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    std::nullopt,
                    {}};
}

[[nodiscard]] bool producer_matches(ProducerModeV1 mode,
                                    const ProviderProducerV1& producer) {
  switch (mode) {
    case ProducerModeV1::inline_immediate:
      return std::holds_alternative<InlineImmediateProducerV1>(producer);
    case ProducerModeV1::in_process_builder:
      return std::holds_alternative<InProcessBuilderV1>(producer);
    case ProducerModeV1::local_executable_builder:
      return std::holds_alternative<LocalExecutableBuilderV1>(producer);
  }
  return false;
}

[[nodiscard]] bool producer_callable(const ProviderProducerV1& producer) {
  return std::visit(
      [](const auto& route) {
        using Route = std::decay_t<decltype(route)>;
        if constexpr (std::is_same_v<Route, InlineImmediateProducerV1> ||
                      std::is_same_v<Route, InProcessBuilderV1>) {
          return static_cast<bool>(route.invoke);
        } else {
          return static_cast<bool>(
              validate_registered_executable_spec(route.executable));
        }
      },
      producer);
}

[[nodiscard]] bool valid_native_bound(
    const std::optional<BigNat>& bound) noexcept {
  return !bound.has_value() ||
         (!bound->is_zero() &&
          bound->bit_length() <= std::numeric_limits<std::size_t>::digits);
}

[[nodiscard]] std::optional<std::size_t> native_bound(
    const std::optional<BigNat>& bound) {
  if (!bound.has_value() || !valid_native_bound(bound)) {
    return std::nullopt;
  }
  return bound->value().convert_to<std::size_t>();
}

[[nodiscard]] bool realized_count_within(
    const std::size_t count, const std::optional<BigNat>& bound) {
  const std::optional<std::size_t> native = native_bound(bound);
  return native.has_value() && count <= *native;
}

[[nodiscard]] std::optional<std::size_t> transition_row_atom_bound(
    const KernelAccess& access) noexcept {
  return std::visit(
      [](const auto& alternative) -> std::optional<std::size_t> {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::is_same_v<Alternative,
                                     FiniteEnumeratedRowAccess> ||
                      std::is_same_v<Alternative, SparseRowAccess>) {
          return alternative.shape().maximum_row_atoms;
        }
        return std::nullopt;
      },
      access);
}

[[nodiscard]] std::optional<std::size_t> residence_slot_bound(
    const KernelAccess& access) noexcept {
  return std::visit(
      [](const auto& alternative) -> std::optional<std::size_t> {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::is_same_v<Alternative,
                                     ProceduralResidenceGeneratorAccess>) {
          return alternative.shape().maximum_residence_slots;
        }
        return std::nullopt;
      },
      access);
}

[[nodiscard]] bool exact_backlog_only_sampler_shape(
    const PlugDescriptorCore& core) noexcept {
  return core.payload_class.tag ==
             PayloadClassTagV1::registered_runtime_recipe_v1 &&
         core.payload_class.version == 1U &&
         core.semantic == SemanticTagV1::staged_opportunity_flux_law &&
         core.runtime_access ==
             RuntimeAccessTagV1::normalized_conditional_sampler &&
         core.target_coupling == TargetCouplingV1::scalar_target &&
         core.deployed_targets.size() == 1U &&
         core.phase.payload_phase == PayloadPhaseKindV1::phase_free &&
         core.phase.arrival_composition ==
             ConfiguredArrivalCompositionV1::iid_late_arrival &&
         !core.phase.retains_configured_predictive_phase &&
         !core.phase.predictive_phase_codec.has_value() &&
         core.state_fields.size() == 1U &&
         core.state_fields.front().kind ==
             StateFieldKindV1::target_backlog &&
         core.state_fields.front().ownership ==
             FieldOwnershipV1::framework_exact;
}

[[nodiscard]] std::optional<StageTag> sampler_stage_for(
    const ConditionalSamplerContractV1& contract) noexcept {
  switch (contract.dependence) {
    case ConditionalSampleDependenceV1::iid_proposal:
      return StageTag::importance_proposal;
    case ConditionalSampleDependenceV1::iid_cold_replications:
    case ConditionalSampleDependenceV1::correlated_trace:
      break;
    default:
      return std::nullopt;
  }
  switch (contract.reveal_stage) {
    case ConditionalSamplerRevealStageV1::prearrival_residual:
      return StageTag::prearrival_closure;
    case ConditionalSamplerRevealStageV1::postarrival_residual:
      return StageTag::postarrival_closure;
    case ConditionalSamplerRevealStageV1::generic_row_residual:
      return StageTag::generic_sampling;
  }
  return std::nullopt;
}

[[nodiscard]] bool valid_reward_premises(
    const ConditionalRewardPremisesV1& premises) noexcept {
  if (premises.almost_sure_lower.has_value() !=
      premises.almost_sure_upper.has_value()) {
    return false;
  }
  return !premises.almost_sure_lower.has_value() ||
         (*premises.almost_sure_lower <= *premises.almost_sure_upper &&
          std::isfinite(premises.almost_sure_lower->to_long_double()) &&
          std::isfinite(premises.almost_sure_upper->to_long_double()));
}

[[nodiscard]] bool valid_conditional_procedure_registration(
    const FrameworkActivationCapabilitiesV1& capabilities) noexcept {
  const bool has_sampler = capabilities.supplies_single_conditioning_state;
  if (has_sampler !=
          capabilities.conditional_sampler_rng_stage.has_value() ||
      has_sampler !=
          capabilities.conditional_sampler_dependence.has_value() ||
      has_sampler !=
          capabilities.conditional_estimator_procedure.has_value() ||
      capabilities.supplies_conditional_reward_decoder !=
          capabilities.conditional_reward_premises.has_value()) {
    return false;
  }
  if (!has_sampler) {
    return !capabilities.supplies_conditional_reward_decoder;
  }

  const StageTag stage = *capabilities.conditional_sampler_rng_stage;
  const ConditionalSampleDependenceV1 dependence =
      *capabilities.conditional_sampler_dependence;
  const ConditionalEstimatorProcedureV1 procedure =
      *capabilities.conditional_estimator_procedure;
  const bool proposal =
      dependence == ConditionalSampleDependenceV1::iid_proposal;
  const bool direct =
      dependence == ConditionalSampleDependenceV1::iid_cold_replications ||
      dependence == ConditionalSampleDependenceV1::correlated_trace;
  const bool importance = procedure ==
                          ConditionalEstimatorProcedureV1::
                              self_normalized_importance;
  const bool row = procedure ==
                   ConditionalEstimatorProcedureV1::conditional_empirical_row;
  const bool reward = procedure ==
                      ConditionalEstimatorProcedureV1::conditional_reward_mean;
  const bool direct_stage = stage == StageTag::prearrival_closure ||
                            stage == StageTag::postarrival_closure ||
                            stage == StageTag::generic_sampling;
  if ((!proposal && !direct) || (!importance && !row && !reward) ||
      (proposal != importance) ||
      (proposal ? stage != StageTag::importance_proposal : !direct_stage) ||
      (row ? capabilities.supplies_conditional_reward_decoder
           : !capabilities.supplies_conditional_reward_decoder)) {
    return false;
  }
  return !capabilities.conditional_reward_premises.has_value() ||
         valid_reward_premises(
             *capabilities.conditional_reward_premises);
}

}  // namespace

SurrogateProvider detail::C16ProviderRegistryMint::mint(
    ValidatedProviderManifest manifest,
    ParameterValidatorV1 parameter_validator,
    DescriptorPreviewerV1 previewer, ProviderProducerV1 producer,
    RuntimePlugMaterializerV1 materializer,
    std::optional<FrameworkActivationRegistrationV1> framework_activation,
    const std::uint32_t result_protocol_version,
    std::optional<ObservationEnvelopeValidatorV1>
        observation_envelope_validator,
    const void* registry_provenance) {
  auto state = std::make_shared<SurrogateProvider::State>(
      SurrogateProvider::State{std::move(manifest),
                               std::move(parameter_validator),
                               std::move(previewer), std::move(producer),
                               std::move(materializer),
                               std::move(framework_activation),
                               result_protocol_version,
                               std::move(observation_envelope_validator)});
  return SurrogateProvider(std::move(state), registry_provenance);
}

RegisteredExecutableSpec detail::C16ExecutableSpecMint::mint(
    ProviderIdentityV1 provider_identity, Digest256 manifest_digest,
    std::string executable_id,
    std::filesystem::path absolute_executable,
    const std::uint32_t argv_grammar_version,
    std::vector<std::string> fixed_arguments,
    const std::chrono::milliseconds wall_time_limit,
    const std::size_t maximum_stderr_bytes,
    std::optional<std::size_t> maximum_request_bytes,
    std::optional<std::size_t> maximum_result_bytes,
    std::optional<std::size_t> maximum_worker_count,
    std::optional<std::chrono::milliseconds> maximum_wall_time_limit) {
  return RegisteredExecutableSpec(
      std::move(provider_identity), std::move(manifest_digest),
      std::move(executable_id), std::move(absolute_executable),
      argv_grammar_version, std::move(fixed_arguments), wall_time_limit,
      maximum_stderr_bytes, maximum_request_bytes, maximum_result_bytes,
      maximum_worker_count, maximum_wall_time_limit);
}

bool SurrogateProvider::is_statically_registered() const noexcept {
  return state_ != nullptr &&
         registry_provenance_ == production_registry_provenance_seal();
}

const ValidatedProviderManifest& SurrogateProvider::manifest() const noexcept {
  return state_->manifest;
}

const ProviderIdentityV1& SurrogateProvider::identity() const noexcept {
  return state_->manifest.value().provider;
}

bool SurrogateProvider::is_default() const noexcept {
  return state_->manifest.value().default_selection;
}

const RegisteredExecutableSpec* SurrogateProvider::registered_executable()
    const noexcept {
  const auto* local =
      std::get_if<LocalExecutableBuilderV1>(&state_->producer);
  return local == nullptr ? nullptr : &local->executable;
}

bool SurrogateProvider::has_framework_activation_factory() const noexcept {
  return state_ != nullptr && state_->framework_activation.has_value() &&
         static_cast<bool>(state_->framework_activation->activate);
}

std::optional<FrameworkActivationCapabilitiesV1>
SurrogateProvider::framework_activation_capabilities() const {
  if (!has_framework_activation_factory()) return std::nullopt;
  return state_->framework_activation->capabilities;
}

std::uint32_t SurrogateProvider::result_protocol_version() const noexcept {
  return state_ == nullptr ? 0U : state_->result_protocol_version;
}

const ParameterValidatorV1& SurrogateProvider::parameter_validator()
    const noexcept {
  return state_->parameter_validator;
}

const DescriptorPreviewerV1& SurrogateProvider::previewer() const noexcept {
  return state_->previewer;
}

const ProviderProducerV1& SurrogateProvider::producer() const noexcept {
  return state_->producer;
}

const RuntimePlugMaterializerV1& SurrogateProvider::materializer()
    const noexcept {
  return state_->materializer;
}

const std::optional<FrameworkActivationRegistrationV1>&
SurrogateProvider::framework_activation() const noexcept {
  return state_->framework_activation;
}

const std::optional<ObservationEnvelopeValidatorV1>&
SurrogateProvider::observation_envelope_validator() const noexcept {
  return state_->observation_envelope_validator;
}

Result<void> validate_registered_observation_envelope(
    const SurrogateProvider& provider,
    const ObservationEnvelopeValidationContextV1& context,
    const ValidatedConstructionObservationBundleV1* observation) {
  if (!provider.is_statically_registered()) {
    return Result<void>::failure(registry_error(
        "c30.unregistered_observation_validator",
        "observation validation requires a provider selected from the immutable static registry"));
  }
  if ((provider.result_protocol_version() != 2U &&
       provider.result_protocol_version() != 3U) ||
      provider.identity() != context.envelope.provider ||
      provider.identity() != context.request.provider_binding().provider) {
    return Result<void>::failure(registry_error(
        "c30.observation_validator_protocol_mismatch",
        "an observation envelope may be validated only for the exact "
        "registered observation-bearing route selected by the request and "
        "envelope"));
  }
  const auto& validator = provider.observation_envelope_validator();
  if (!validator.has_value() || !*validator) {
    return Result<void>::failure(registry_error(
        "c30.observation_validator_unavailable",
        "the selected provider-result-v2 route has no observation-envelope validator"));
  }
  try {
    return (*validator)(context, observation);
  } catch (const std::bad_alloc&) {
    return Result<void>::failure(registry_error(
        "c30.observation_validator_allocation_failure",
        "the registered observation-envelope validator exhausted memory"));
  } catch (const std::exception&) {
    return Result<void>::failure(registry_error(
        "c30.observation_validator_exception",
        "the registered observation-envelope validator raised an exception"));
  } catch (...) {
    return Result<void>::failure(registry_error(
        "c30.observation_validator_unknown_exception",
        "the registered observation-envelope validator raised a nonstandard exception"));
  }
}

Result<RuntimeFrameworkActivationV1>
activate_registered_surrogate_framework(
    const SurrogateProvider& provider,
    const RuntimeFrameworkActivationContextV1& context) {
  const auto fail = [](std::string code, std::string message) {
    return Result<RuntimeFrameworkActivationV1>::failure(
        registry_error(std::move(code), std::move(message)));
  };
  if (!provider.is_statically_registered()) {
    return fail(
        "c27.unregistered_framework_activation",
        "framework activation requires a provider selected from the immutable static registry");
  }
  const auto& registration = provider.framework_activation();
  if (!registration.has_value() || !registration->activate) {
    return fail(
        "c27.framework_activation_unavailable",
        "the selected provider has no registered exact framework activation recipe");
  }
  const FrameworkActivationCapabilitiesV1& declared =
      registration->capabilities;
  const ArtifactValidationBindingsV1& artifact_bindings =
      context.artifact.validation_bindings();
  if (provider.identity() != artifact_bindings.provider ||
      provider.identity() != context.accepted_contract.provider() ||
      context.build_identity.digest() !=
          artifact_bindings.build_identity_digest ||
      context.final_request_identity != artifact_bindings.request_digest ||
      context.problem_view.canonical_digest().value() !=
          artifact_bindings.framework_problem_view_digest ||
      context.descriptor.descriptor_digest !=
          context.framework_binding_context.descriptor_digest ||
      context.accepted_contract.contract_digest() !=
          context.framework_binding_context.accepted_contract_digest ||
      context.accepted_contract.requirements_digest() !=
          context.framework_binding_context
              .normalized_metric_requirements_digest ||
      context.problem_view.fingerprints() !=
          context.framework_binding_context.problem_fingerprints ||
      context.problem_view.canonical_digest() !=
          context.framework_binding_context.problem_view_digest ||
      context.final_request_identity !=
          context.framework_binding_context.build_request_digest) {
    return fail(
        "c27.framework_activation_binding_mismatch",
        "the framework activation context is not bound to the selected provider, validated artifact, contract, problem view, descriptor, or request");
  }
  if (runtime_access_tag_v1(context.kernel_access) !=
      context.descriptor.core.runtime_access) {
    return fail(
        "c27.framework_activation_access_mismatch",
        "the framework activation context carries a kernel-access alternative other than the validated descriptor route");
  }
  const auto* raw_sampler =
      std::get_if<NormalizedConditionalSamplerAccess>(&context.kernel_access);
  const bool declared_sampler =
      declared.conditional_sampler_dependence.has_value();
  if ((raw_sampler != nullptr) != declared_sampler) {
    return fail(
        "c27.framework_activation_sampler_procedure_mismatch",
        "the validated runtime access does not match the callback-free conditional-sampler procedure declaration");
  }
  if (raw_sampler != nullptr) {
    const std::optional<StageTag> realized_stage =
        raw_sampler->contract().has_value()
            ? sampler_stage_for(*raw_sampler->contract())
            : std::nullopt;
    const bool importance =
        declared.conditional_estimator_procedure ==
        ConditionalEstimatorProcedureV1::self_normalized_importance;
    if (!raw_sampler->contract().has_value() ||
        raw_sampler->contract()->dependence !=
            *declared.conditional_sampler_dependence ||
        realized_stage != declared.conditional_sampler_rng_stage ||
        (importance &&
         (!raw_sampler->ratio_contract().has_value() ||
          !raw_sampler->has_ratio_operation()))) {
      return fail(
          "c27.framework_activation_sampler_procedure_mismatch",
          "the validated sampler changed the registered dependence, RNG stage, estimator procedure, or required importance-ratio authority");
    }
  }
  try {
    // Invoke a cold copy just as C16 does for materializers.  A mutable
    // process-local recipe therefore cannot leak state between analyses.
    RuntimeFrameworkActivationFactoryV1 activation = registration->activate;
    auto activated = activation(context);
    if (!activated) return activated;
    RuntimeFrameworkActivationV1 value = std::move(activated).value();
    const bool has_finite_domain =
        !value.finite_backend_domain_states.empty();
    if (has_finite_domain != declared.supplies_finite_backend_domain ||
        value.exact_closed_boundary_proven !=
            declared.proves_exact_closed_boundary ||
        value.single_conditioning_state.has_value() !=
            declared.supplies_single_conditioning_state ||
        static_cast<bool>(value.direct_metric_activation) !=
            declared.supplies_direct_factor ||
        !value.conditional_reward_decoders.empty() !=
            declared.supplies_conditional_reward_decoder) {
      return fail(
          "c27.framework_activation_capability_mismatch",
          "the activated framework inputs do not match the callback-free capabilities declared by the registry");
    }
    if (value.direct_metric_activation &&
        value.direct_metric_activation.use_count() != 1U) {
      return fail(
          "c27.framework_activation_direct_recipe_not_unique",
          "the activated direct causal-factor recipe must have unique request-local ownership");
    }
    if (value.exact_closed_boundary_proven && !has_finite_domain) {
      return fail(
          "c27.framework_activation_closed_domain_missing",
          "a finite boundary-closure declaration requires one nonempty "
          "finite backend domain");
    }
    if (!value.causal_program || !value.framework_seed) {
      return fail(
          "c27.framework_activation_required_input_missing",
          "the provider-owned activation must supply exact causal-program and framework-seed carriers");
    }
    if ((declared.supplies_finite_backend_domain &&
         !realized_count_within(value.finite_backend_domain_states.size(),
                                declared.maximum_finite_backend_states)) ||
        (!declared.supplies_finite_backend_domain &&
         declared.maximum_finite_backend_states.has_value())) {
      return fail(
          "c27.framework_activation_backend_state_bound_mismatch",
          "the realized finite backend domain exceeds or contradicts its callback-free registered state bound");
    }
    if (value.causal_program->finite_event_domain_states.has_value() !=
        declared.supplies_finite_event_domain) {
      return fail(
          "c27.framework_activation_capability_mismatch",
          "the activated causal program's finite event-entry domain does not match the callback-free capability declared by the registry");
    }
    if (declared.supplies_finite_event_domain &&
        (!value.causal_program->finite_event_domain_states.has_value() ||
         !value.causal_program->maximum_residence_slots.has_value() ||
         !realized_count_within(
             value.causal_program->finite_event_domain_states->size(),
             declared.maximum_finite_event_states))) {
      return fail(
          "c27.framework_activation_event_state_bound_mismatch",
          "the realized finite event-entry domain exceeds its callback-free registered state bound");
    }
    const std::optional<std::size_t> declared_row_atoms =
        native_bound(declared.maximum_row_atoms);
    const std::optional<std::size_t> access_row_atoms =
        transition_row_atom_bound(context.kernel_access);
    if (access_row_atoms.has_value() &&
        (!declared_row_atoms.has_value() ||
         *access_row_atoms > *declared_row_atoms)) {
      return fail(
          "c27.framework_activation_row_atom_bound_mismatch",
          "the validated row-access shape exceeds or lacks its callback-free registered atom bound");
    }
    const std::optional<std::size_t> declared_residence_slots =
        native_bound(declared.maximum_residence_slots);
    const std::optional<std::size_t> access_residence_slots =
        residence_slot_bound(context.kernel_access);
    if ((value.causal_program->maximum_residence_slots.has_value() ||
         access_residence_slots.has_value()) &&
        (!declared_residence_slots.has_value() ||
         (value.causal_program->maximum_residence_slots.has_value() &&
          *value.causal_program->maximum_residence_slots >
              *declared_residence_slots) ||
         (access_residence_slots.has_value() &&
          *access_residence_slots > *declared_residence_slots))) {
      return fail(
          "c27.framework_activation_residence_bound_mismatch",
          "the activated causal program or residence access changed the callback-free registered residence-slot bound");
    }
    const AuditedFrameworkBindingsV1 expected_bindings =
        context.framework_binding_context.bind_state_schema(
            value.exact_state_schema);
    if (value.framework_seed->bindings != expected_bindings ||
        value.framework_seed->target_selection !=
            context.problem_view.target_selection() ||
        value.framework_seed->reduced_state_codec !=
            value.exact_state_schema.reduced_state_codec ||
        value.framework_seed->selection_support !=
            context.descriptor.core.selection) {
      return fail(
          "c27.framework_activation_output_binding_mismatch",
          "the activated state schema or framework seed changed an immutable C16/C17 binding");
    }
    if (!value.exact_state_schema.validate_domain) {
      return fail(
          "c27.framework_activation_domain_validator_missing",
          "the activated exact state schema must carry its deterministic reduced-domain validator");
    }
    for (std::size_t index = 0U;
         index < value.finite_backend_domain_states.size(); ++index) {
      auto domain = value.exact_state_schema.validate_domain(
          value.finite_backend_domain_states[index]);
      if (!domain) {
        return Result<RuntimeFrameworkActivationV1>::failure(domain.error());
      }
      for (std::size_t prior = 0U; prior < index; ++prior) {
        if (value.finite_backend_domain_states[prior] ==
            value.finite_backend_domain_states[index]) {
          return fail(
              "c27.framework_activation_duplicate_backend_state",
              "the provider-owned finite backend domain contains a duplicate exact reduced state");
        }
      }
    }
    if (value.single_conditioning_state.has_value()) {
      const RuntimeFrameworkActivationV1::
          SingleConditioningStateBindingV1& binding =
              *value.single_conditioning_state;
      auto domain = value.exact_state_schema.validate_domain(
          binding.state);
      if (!domain) {
        return Result<RuntimeFrameworkActivationV1>::failure(domain.error());
      }
      const std::span<const ResolvedMetricContractV1> contracts =
          context.accepted_contract.metric_contracts();
      const std::span<const MetricRequirementClause> requirements =
          context.accepted_contract.requirements().clauses();
      const BacklogConditionedServiceParametersV1* conditioned =
          requirements.size() == 1U
              ? std::get_if<BacklogConditionedServiceParametersV1>(
                    &requirements.front().origin.parameters)
              : nullptr;
      const bool exact_point_route =
          requirements.size() == 1U &&
          std::any_of(
              requirements.front().route_alternatives.begin(),
              requirements.front().route_alternatives.end(),
              [&](const MetricRouteAlternativeV1& route) {
                const auto* point =
                    std::get_if<ExactPointResponseRequirementV1>(
                        &route.semantic.law);
                return route.access.backend_route ==
                           BackendRouteKindV1::
                               conditional_reward_monte_carlo &&
                       route.access.runtime_access ==
                           RuntimeAccessTagV1::
                               normalized_conditional_sampler &&
                       point != nullptr && conditioned != nullptr &&
                       point->represented_levels == conditioned->levels &&
                       point->require_positive_stationary_conditioning_mass &&
                       point->permit_declared_off_support_convention;
              });
      if (contracts.size() != 1U || requirements.size() != 1U ||
          contracts.front().clause_id != binding.accepted_clause_id ||
          contracts.front().support_clause_digest !=
              binding.support_clause_digest ||
          contracts.front().semantic !=
              SemanticTagV1::staged_opportunity_flux_law ||
          contracts.front().backend_route !=
              BackendRouteKindV1::conditional_reward_monte_carlo ||
          contracts.front().runtime_access !=
              RuntimeAccessTagV1::normalized_conditional_sampler ||
          contracts.front().solver_regime != SolverRegimeV1::monte_carlo ||
          contracts.front().target_coupling !=
              TargetCouplingV1::scalar_target ||
          contracts.front().ordered_targets.size() != 1U ||
          requirements.front().origin.clause_id !=
              binding.accepted_clause_id ||
          requirements.front().origin.kind !=
              MetricKindV1::backlog_conditioned_service ||
          conditioned == nullptr || conditioned->levels.size() != 1U ||
          !exact_point_route ||
          requirements.front().origin.wire_coupling !=
              MetricTargetCouplingV1::scalar_singleton ||
          requirements.front().origin.ordered_targets.size() != 1U ||
          requirements.front().origin.ordered_targets !=
              contracts.front().ordered_targets ||
          binding.normalized_metric_request_digest !=
              context.accepted_contract.requirements_digest() ||
          !exact_backlog_only_sampler_shape(context.descriptor.core)) {
        return fail(
            "c27.framework_activation_conditioning_binding_mismatch",
            "the provider-owned conditioning state is not bound to the one exact accepted staged-flux backlog-response clause and normalized metric request");
      }
      if (!value.exact_state_schema.decode) {
        return fail(
            "c27.framework_activation_state_decoder_missing",
            "the registered C24 conditioning state requires the exact state-schema decoder");
      }
      auto decoded = value.exact_state_schema.decode(binding.state);
      if (!decoded) {
        return Result<RuntimeFrameworkActivationV1>::failure(
            decoded.error());
      }
      if (decoded.value().backlog.size() != 1U ||
          decoded.value().backlog.target_at_target_ordinal(0U).ordinal() !=
              contracts.front().ordered_targets.front().dense_index.ordinal() ||
          decoded.value().backlog.value_at_target_ordinal(0U) !=
              conditioned->levels.front() ||
          decoded.value().boundary_index != BigNat{0U} ||
          decoded.value().resources.has_value() ||
          !decoded.value().margins.empty() ||
          decoded.value().controller.has_value() ||
          !decoded.value().unresolved_fields.empty()) {
        return fail(
            "c27.framework_activation_conditioning_state_mismatch",
            "the registered C24 conditioning state is not exactly the sole requested target backlog level");
      }
      if (declared.supplies_conditional_reward_decoder &&
          (value.conditional_reward_decoders.size() != 1U ||
           value.conditional_reward_decoders.front().accepted_clause_id !=
               binding.accepted_clause_id ||
           value.conditional_reward_decoders.front().support_clause_digest !=
               binding.support_clause_digest ||
           value.conditional_reward_decoders.front()
                   .normalized_metric_request_digest !=
               binding.normalized_metric_request_digest)) {
        return fail(
            "c27.framework_activation_conditioning_decoder_mismatch",
            "the single conditioning state and conditional-reward decoder must carry the same exact clause, support, and normalized request identities");
      }
    }
    for (std::size_t index = 0U;
         index < value.conditional_reward_decoders.size(); ++index) {
      const RuntimeFrameworkActivationV1::ConditionalRewardDecoderBindingV1&
          binding = value.conditional_reward_decoders[index];
      if (!binding.decoder) {
        return fail(
            "c27.framework_activation_reward_decoder_invalid",
            "a conditional reward decoder requires nonempty exact clause, request, decoder, and callable bindings");
      }
      const ConditionalRewardPremisesV1& premises =
          *declared.conditional_reward_premises;
      const bool direct_reward =
          declared.conditional_estimator_procedure ==
          ConditionalEstimatorProcedureV1::conditional_reward_mean;
      if (binding.decoder->binary_indicator != premises.binary_indicator ||
          binding.decoder->almost_sure_lower !=
              premises.almost_sure_lower ||
          binding.decoder->almost_sure_upper !=
              premises.almost_sure_upper ||
          (direct_reward &&
           binding.decoder->integrability !=
               StationaryRewardIntegrabilityV1::finite_absolute)) {
        return fail(
            "c27.framework_activation_reward_premise_mismatch",
            "the activated conditional reward decoder changed its registered binary, exact-range, or finite-integrability premises");
      }
      for (std::size_t prior = 0U; prior < index; ++prior) {
        const auto& existing = value.conditional_reward_decoders[prior];
        if (existing.accepted_clause_id == binding.accepted_clause_id &&
            existing.support_clause_digest == binding.support_clause_digest &&
            existing.normalized_metric_request_digest ==
                binding.normalized_metric_request_digest) {
          return fail(
              "c27.framework_activation_reward_decoder_duplicate",
              "the provider-owned activation contains a duplicate exact conditional-reward decoder binding");
        }
      }
    }
    return Result<RuntimeFrameworkActivationV1>::success(std::move(value));
  } catch (const std::bad_alloc&) {
    return fail("c27.framework_activation_allocation_failure",
                "the provider-owned framework activation recipe exhausted memory");
  } catch (const std::exception&) {
    return fail("c27.framework_activation_exception",
                "the provider-owned framework activation recipe raised an exception");
  } catch (...) {
    return fail("c27.framework_activation_unknown_exception",
                "the provider-owned framework activation recipe raised an unknown exception");
  }
}

Result<SurrogateRegistry> detail::SurrogateRegistryAssembler::assemble(
    std::vector<SurrogateProviderRegistrationV1> registrations) {
  return assemble_impl(std::move(registrations), nullptr);
}

Result<SurrogateRegistry> detail::SurrogateRegistryAssembler::assemble_static(
    std::vector<SurrogateProviderRegistrationV1> registrations) {
  return assemble_impl(std::move(registrations),
                       production_registry_provenance_seal());
}

Result<SurrogateRegistry> detail::SurrogateRegistryAssembler::assemble_impl(
    std::vector<SurrogateProviderRegistrationV1> registrations,
    const void* registry_provenance) {
  try {
    std::sort(registrations.begin(), registrations.end(),
              [](const SurrogateProviderRegistrationV1& left,
                 const SurrogateProviderRegistrationV1& right) {
                return std::tie(left.manifest.provider.provider_id,
                                left.manifest.provider.provider_version) <
                       std::tie(right.manifest.provider.provider_id,
                                right.manifest.provider.provider_version);
              });

    auto providers = std::make_shared<std::vector<SurrogateProvider>>();
    providers->reserve(registrations.size());
    std::string previous_id;
    std::string previous_version;
    std::string default_id;
    bool have_previous = false;
    bool have_default_for_id = false;

    for (SurrogateProviderRegistrationV1& registration : registrations) {
      const ProviderIdentityV1& raw_identity = registration.manifest.provider;
      if (have_previous && raw_identity.provider_id == previous_id &&
          raw_identity.provider_version == previous_version) {
        return Result<SurrogateRegistry>::failure(registry_error(
            "c16.duplicate_provider_version",
            "the static surrogate registry contains a duplicate exact ID/version key"));
      }
      if (!have_previous || raw_identity.provider_id != previous_id) {
        default_id = raw_identity.provider_id;
        have_default_for_id = false;
      }
      if (registration.manifest.default_selection) {
        if (have_default_for_id && default_id == raw_identity.provider_id) {
          return Result<SurrogateRegistry>::failure(registry_error(
              "c16.multiple_default_provider_versions",
              "one surrogate ID cannot have more than one explicit default version"));
        }
        have_default_for_id = true;
      }

      auto typed_identity =
          surrogate_identity_from_provider_identity_v1(raw_identity);
      if (!typed_identity) {
        return Result<SurrogateRegistry>::failure(typed_identity.error());
      }
      auto manifest = validate_provider_manifest(registration.manifest);
      if (!manifest) {
        return Result<SurrogateRegistry>::failure(manifest.error());
      }
      if (!registration.parameter_validator || !registration.previewer ||
          !registration.materializer ||
          !producer_matches(registration.manifest.producer_mode,
                            registration.producer) ||
          !producer_callable(registration.producer)) {
        return Result<SurrogateRegistry>::failure(registry_error(
            "c16.invalid_provider_callback_shape",
            "a provider registration requires exactly the callbacks and transport named by its producer mode"));
      }
      const bool valid_result_protocol_registration =
          (registration.result_protocol_version == 1U &&
           !registration.observation_envelope_validator.has_value()) ||
          ((registration.result_protocol_version == 2U ||
            registration.result_protocol_version == 3U) &&
           registration.observation_envelope_validator.has_value() &&
           static_cast<bool>(*registration.observation_envelope_validator));
      if (!valid_result_protocol_registration) {
        return Result<SurrogateRegistry>::failure(registry_error(
            "c30.invalid_provider_result_protocol_registration",
            "a provider registration must select result protocol one without "
            "an observation hook or an observation-bearing result protocol "
            "with exactly one live observation hook"));
      }
      if (registration.framework_activation.has_value()) {
        const FrameworkActivationRegistrationV1& activation =
            *registration.framework_activation;
        const FrameworkActivationCapabilitiesV1& capabilities =
            activation.capabilities;
        const bool valid_declared_bounds =
            valid_native_bound(capabilities.maximum_finite_backend_states) &&
            valid_native_bound(capabilities.maximum_finite_event_states) &&
            valid_native_bound(capabilities.maximum_row_atoms) &&
            valid_native_bound(capabilities.maximum_residence_slots) &&
            (capabilities.maximum_finite_backend_states.has_value() ==
             capabilities.supplies_finite_backend_domain) &&
            (capabilities.maximum_finite_event_states.has_value() ==
             capabilities.supplies_finite_event_domain) &&
            (capabilities.maximum_direct_factor_optimizer_calls.has_value() ==
             capabilities.supplies_direct_factor) &&
            (!capabilities.supplies_finite_event_domain ||
             (capabilities.maximum_row_atoms.has_value() &&
              capabilities.maximum_residence_slots.has_value())) &&
            ((registration.manifest.runtime_access_tag !=
                  RuntimeAccessTagV1::finite_enumerated_row &&
              registration.manifest.runtime_access_tag !=
                  RuntimeAccessTagV1::sparse_row) ||
             capabilities.maximum_row_atoms.has_value()) &&
            (registration.manifest.runtime_access_tag !=
                     RuntimeAccessTagV1::procedural_residence_generator ||
             capabilities.maximum_residence_slots.has_value());
        if (!activation.activate ||
            !valid_declared_bounds ||
            (capabilities.proves_exact_closed_boundary &&
             !capabilities.supplies_finite_backend_domain) ||
            !valid_conditional_procedure_registration(capabilities)) {
          return Result<SurrogateRegistry>::failure(registry_error(
              "c16.invalid_framework_activation_registration",
              "a framework activation recipe requires one callable, valid positive callback-free native bounds, a direct-factor optimizer bound (where zero is valid) exactly with a direct recipe, no finite-domain bound without its matching domain declaration, no boundary-closure declaration without a finite backend domain, and a complete typed conditional-sampler stage/dependence/procedure/reward-premise declaration"));
        }
      }
      if (registration.manifest.producer_mode ==
          ProducerModeV1::local_executable_builder) {
        const auto& local =
            std::get<LocalExecutableBuilderV1>(registration.producer)
                .executable;
        if (!registration.manifest.local_executable.has_value() ||
            registration.manifest.local_executable->executable_id !=
                local.executable_id() ||
            registration.manifest.local_executable->argv_grammar_version !=
                local.argv_grammar_version() ||
            local.provider_identity() != registration.manifest.provider ||
            local.manifest_digest() != registration.manifest.manifest_digest) {
          return Result<SurrogateRegistry>::failure(registry_error(
              "c16.local_executable_registration_mismatch",
              "the executable route must exactly match the validated manifest declaration"));
        }
      } else if (registration.manifest.local_executable.has_value()) {
        return Result<SurrogateRegistry>::failure(registry_error(
            "c16.unexpected_local_executable_registration",
            "only a local-executable producer may carry executable metadata"));
      }
      providers->push_back(C16ProviderRegistryMint::mint(
          std::move(manifest).value(),
          std::move(registration.parameter_validator),
          std::move(registration.previewer),
          std::move(registration.producer),
          std::move(registration.materializer),
          std::move(registration.framework_activation),
          registration.result_protocol_version,
          std::move(registration.observation_envelope_validator),
          registry_provenance));

      previous_id = raw_identity.provider_id;
      previous_version = raw_identity.provider_version;
      have_previous = true;
    }
    return Result<SurrogateRegistry>::success(
        SurrogateRegistry(std::move(providers)));
  } catch (const std::bad_alloc&) {
    return Result<SurrogateRegistry>::failure(registry_error(
        "c16.registry_allocation_failure",
        "assembling the static surrogate registry exhausted memory"));
  } catch (const std::exception&) {
    return Result<SurrogateRegistry>::failure(registry_error(
        "c16.registry_construction_failure",
        "assembling the static surrogate registry failed"));
  } catch (...) {
    return Result<SurrogateRegistry>::failure(registry_error(
        "c16.registry_unknown_failure",
        "assembling the static surrogate registry raised an unknown exception"));
  }
}

Result<RegisteredExecutableSpec>
detail::SurrogateRegistryAssembler::executable_spec(
    ProviderIdentityV1 provider_identity, Digest256 manifest_digest,
    std::string executable_id,
    std::filesystem::path absolute_executable,
    std::uint32_t argv_grammar_version,
    std::vector<std::string> fixed_arguments,
    std::chrono::milliseconds wall_time_limit,
    std::size_t maximum_stderr_bytes,
    std::optional<std::size_t> maximum_request_bytes,
    std::optional<std::size_t> maximum_result_bytes,
    std::optional<std::size_t> maximum_worker_count,
    std::optional<std::chrono::milliseconds> maximum_wall_time_limit) {
  RegisteredExecutableSpec spec = C16ExecutableSpecMint::mint(
      std::move(provider_identity), std::move(manifest_digest),
      std::move(executable_id), std::move(absolute_executable),
      argv_grammar_version, std::move(fixed_arguments), wall_time_limit,
      maximum_stderr_bytes, maximum_request_bytes, maximum_result_bytes,
      maximum_worker_count, maximum_wall_time_limit);
  auto valid = validate_registered_executable_spec(spec);
  if (!valid) {
    return Result<RegisteredExecutableSpec>::failure(valid.error());
  }
  return Result<RegisteredExecutableSpec>::success(std::move(spec));
}

Result<SurrogateProvider> detail::lookup_in_surrogate_registry(
    const SurrogateRegistry& registry, const SurrogateId& id,
    const std::optional<SurrogateVersion>& version) {
  const auto providers = registry.providers();
  const auto first = std::lower_bound(
      providers.begin(), providers.end(), id.value(),
      [](const SurrogateProvider& provider, const std::string& sought) {
        return provider.identity().provider_id < sought;
      });
  const auto last = std::upper_bound(
      first, providers.end(), id.value(),
      [](const std::string& sought, const SurrogateProvider& provider) {
        return sought < provider.identity().provider_id;
      });
  if (first == last) {
    return Result<SurrogateProvider>::failure(registry_error(
        "c16.unknown_surrogate_id",
        "no statically registered surrogate has the requested exact ID"));
  }
  if (version.has_value()) {
    const auto found = std::lower_bound(
        first, last, version->value(),
        [](const SurrogateProvider& provider, const std::string& sought) {
          return provider.identity().provider_version < sought;
        });
    if (found == last ||
        found->identity().provider_version != version->value()) {
      return Result<SurrogateProvider>::failure(registry_error(
          "c16.unknown_surrogate_version",
          "the requested surrogate ID has no exact registered version match"));
    }
    return Result<SurrogateProvider>::success(*found);
  }
  const auto found = std::find_if(first, last,
                                  [](const SurrogateProvider& provider) {
                                    return provider.is_default();
                                  });
  if (found == last) {
    return Result<SurrogateProvider>::failure(registry_error(
        "c16.no_default_surrogate_version",
        "version omission requires one explicitly registered default"));
  }
  return Result<SurrogateProvider>::success(*found);
}

const Result<SurrogateRegistry>& detail::production_surrogate_registry() {
  static const Result<SurrogateRegistry> registry = [] {
#if defined(MWPERF_C16_TEST_SEAMS)
    return SurrogateRegistryAssembler::assemble_static(
        testing::c16_test_provider_registrations());
#elif defined(MWPERF_ENABLE_FULL_ORBIT_SAMPLER)
    auto full_orbit_k_wide =
        full_orbit_sampler_k_wide_provider_registration();
    if (!full_orbit_k_wide) {
      return Result<SurrogateRegistry>::failure(
          full_orbit_k_wide.error());
    }
    auto full_orbit_observation =
        full_orbit_sampler_observation_provider_registration();
    if (!full_orbit_observation) {
      return Result<SurrogateRegistry>::failure(
          full_orbit_observation.error());
    }
    auto full_orbit_cp09 =
        full_orbit_sampler_cp09_provider_registration();
    if (!full_orbit_cp09) {
      return Result<SurrogateRegistry>::failure(full_orbit_cp09.error());
    }
    std::vector<SurrogateProviderRegistrationV1> registrations;
    registrations.push_back(std::move(full_orbit_k_wide).value());
    registrations.push_back(std::move(full_orbit_observation).value());
    registrations.push_back(std::move(full_orbit_cp09).value());
    return SurrogateRegistryAssembler::assemble_static(
        std::move(registrations));
#else
    // C16 certifies the framework boundary, not any real family compiler.
    // Concrete provider registration remains a separately reviewed release.
    return SurrogateRegistryAssembler::assemble_static({});
#endif
  }();
  return registry;
}

Result<SurrogateProvider> lookup_surrogate_provider(
    const SurrogateId& id, const std::optional<SurrogateVersion>& version) {
  const auto& registry = detail::production_surrogate_registry();
  if (!registry) {
    return Result<SurrogateProvider>::failure(registry.error());
  }
  return detail::lookup_in_surrogate_registry(registry.value(), id, version);
}

bool detail::is_registered_executable_spec_for_request(
    const RegisteredExecutableSpec& spec,
    const SurrogateBuildRequest& request) noexcept {
  try {
  auto id = SurrogateId::parse(request.provider_binding().provider.provider_id);
  auto version = SurrogateVersion::parse(
      request.provider_binding().provider.provider_version);
  if (!id || !version) return false;
  auto provider = lookup_surrogate_provider(
      id.value(), std::optional<SurrogateVersion>{version.value()});
  if (!provider) return false;
  const RegisteredExecutableSpec* registered =
      provider.value().registered_executable();
  return registered != nullptr && *registered == spec;
  } catch (...) {
    return false;
  }
}

}  // namespace mwperf
