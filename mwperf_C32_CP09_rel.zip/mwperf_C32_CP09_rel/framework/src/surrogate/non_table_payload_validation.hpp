#pragma once

#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf::artifact::detail {

// Private, noncatalog portion of F-C15-06.  This validates the four closed
// payload alternatives which are neither the common three-bin response nor a
// finite-law table.  Three-bin recursion and whole-artifact object-ledger
// resolution remain with F-C15-06; finite-law validation has its own locked
// stage in artifact_validation.cpp.
[[nodiscard]] Result<void> validate_non_table_payload_v1(
    const ArtifactPayloadV1& payload, const SurrogateArtifactV1& artifact,
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& validated_full_manifest,
    const AcceptedCapabilityContract& accepted_contract);

}  // namespace mwperf::artifact::detail
