#include "non_table_payload_validation.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"

namespace mwperf::artifact::detail {
namespace {

constexpr std::uint32_t kProtocolVersion = 1U;

template <typename T>
[[nodiscard]] Result<T> failure(
    std::string code, std::string message,
    std::optional<std::string> path = std::nullopt) {
  return Result<T>::failure(
      Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), std::nullopt, std::move(path), {}});
}

[[nodiscard]] ExactRational exact_value(
    const PortableScientificScalar& value) {
  return value.kind() == PortableScientificScalarKind::rational
             ? value.rational_value()
             : binary64_as_exact_rational(value);
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

template <typename T>
[[nodiscard]] bool duplicate_free(const std::span<const T> values) {
  for (std::size_t left = 0U; left < values.size(); ++left) {
    if (std::find(values.begin() + static_cast<std::ptrdiff_t>(left + 1U),
                  values.end(), values[left]) != values.end()) {
      return false;
    }
  }
  return true;
}

template <typename T>
[[nodiscard]] bool strictly_ordered_unique(const std::span<const T> values) {
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (!(values[index - 1U] < values[index])) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool distinct_object_ids(
    const std::span<const ArtifactObjectReferenceV1> references) {
  for (std::size_t left = 0U; left < references.size(); ++left) {
    if (std::any_of(
            references.begin() + static_cast<std::ptrdiff_t>(left + 1U),
            references.end(),
            [&references, left](const ArtifactObjectReferenceV1& right) {
              return references[left].object_id == right.object_id;
            })) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool portable_value_has_closed_shape(
    const PortableValueV1& value) {
  return std::visit(
      [](const auto& active) {
        using Active = std::decay_t<decltype(active)>;
        if constexpr (std::same_as<Active, PortableScientificScalar>) {
          return true;
        } else {
          return !active.empty();
        }
      },
      value);
}

[[nodiscard]] bool named_values_are_canonical(
    const std::span<const NamedPortableValueV1> values) {
  for (std::size_t index = 0U; index < values.size(); ++index) {
    if (values[index].name.empty() ||
        !portable_value_has_closed_shape(values[index].value) ||
        (index != 0U &&
         !(values[index - 1U].name < values[index].name))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool references_are_canonical(
    const std::span<const ArtifactObjectReferenceV1> references,
    const bool require_nonempty) {
  if ((require_nonempty && references.empty()) ||
      !strictly_ordered_unique(references) ||
      !distinct_object_ids(references) ||
      !std::all_of(references.begin(), references.end(),
                   [](const ArtifactObjectReferenceV1& reference) {
                     return nonzero_digest(reference.object_digest);
                   })) {
    return false;
  }
  return true;
}

[[nodiscard]] bool domain_is_canonical(
    const std::span<const PortableDomainV1> domain) {
  if (domain.empty()) {
    return false;
  }
  for (std::size_t index = 0U; index < domain.size(); ++index) {
    const PortableDomainV1& coordinate = domain[index];
    const ExactRational lower = exact_value(coordinate.lower);
    const ExactRational upper = exact_value(coordinate.upper);
    if (coordinate.coordinate_name.empty() || lower > upper ||
        (lower == upper &&
         (!coordinate.lower_closed || !coordinate.upper_closed)) ||
        (index != 0U &&
         !(domain[index - 1U].coordinate_name <
           coordinate.coordinate_name))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool payload_targets_match_context(
    const std::span<const QueueId> targets,
    const SurrogateBuildRequest& request,
    const AcceptedCapabilityContract& contract) {
  const auto accepted =
      request.framework_problem_view().target_selection().ordered_targets;
  return !targets.empty() && duplicate_free(targets) &&
         std::equal(targets.begin(), targets.end(), accepted.begin(),
                    accepted.end()) &&
         targets.size() == accepted.size() &&
         std::equal(targets.begin(), targets.end(),
                    contract.descriptor_core().deployed_targets.begin(),
                    contract.descriptor_core().deployed_targets.end()) &&
         targets.size() ==
             contract.descriptor_core().deployed_targets.size();
}

[[nodiscard]] Result<void> validate_analytic_payload(
    const FiniteParameterAnalyticDataV1& payload,
    const SurrogateArtifactV1& artifact,
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& contract) {
  constexpr std::string_view path = "/result/artifact/payload/body";
  const RegisteredAnalyticFamilyContractV1 key{
      payload.registered_family_id, payload.registered_family_version,
      payload.parameter_schema_id, payload.parameter_schema_version,
      payload.domain_schema_id, payload.domain_schema_version};
  const auto& registry = manifest.value()
                             .scientific_construction_policy_schema
                             .registered_analytic_families;
  if (payload.payload_version != kProtocolVersion ||
      payload.registered_provider != manifest.value().provider ||
      payload.registered_provider != contract.provider() ||
      !payload_targets_match_context(payload.ordered_deployed_targets,
                                     request, contract)) {
    return failure<void>(
        "c15.analytic_payload_binding",
        "finite analytic payload has a stale version, provider, or exact "
        "ordered target binding",
        std::string(path));
  }
  if (std::find(registry.begin(), registry.end(), key) == registry.end()) {
    return failure<void>(
        "c15.analytic_family_not_registered",
        "finite analytic family and all of its schema versions must equal "
        "one allowlisted manifest entry",
        std::string(path) + "/registered_family_id");
  }
  if (!named_values_are_canonical(payload.parameters) ||
      !named_values_are_canonical(payload.tables)) {
    return failure<void>(
        "c15.analytic_named_value_shape",
        "analytic parameter and table maps require strict name order, "
        "unique nonempty names, and nonempty vector values",
        std::string(path));
  }
  for (const NamedPortableValueV1& parameter : payload.parameters) {
    if (std::any_of(payload.tables.begin(), payload.tables.end(),
                    [&parameter](const NamedPortableValueV1& table) {
                      return table.name == parameter.name;
                    })) {
      return failure<void>(
          "c15.analytic_named_value_collision",
          "an analytic name cannot denote both a parameter and a table",
          std::string(path) + "/parameters");
    }
  }
  if (!domain_is_canonical(payload.mathematical_domain)) {
    return failure<void>(
        "c15.analytic_domain_shape",
        "analytic domain coordinates require strict unique name order and "
        "nonempty closed-shape intervals",
        std::string(path) + "/mathematical_domain");
  }
  if (payload.state_and_phase_binding !=
          contract.descriptor_core().state_fields ||
      !references_are_canonical(payload.transform_or_response_identities,
                                true)) {
    return failure<void>(
        "c15.analytic_descriptor_or_identity_binding",
        "analytic state/phase codecs must equal the accepted descriptor and "
        "transform/response identities must be a canonical nonempty set",
        std::string(path));
  }
  if (std::any_of(
          payload.transform_or_response_identities.begin(),
          payload.transform_or_response_identities.end(),
          [&artifact](const ArtifactObjectReferenceV1& identity) {
            return identity.object_id == artifact.payload_identity.object_id;
          })) {
    return failure<void>(
        "c15.analytic_identity_collision",
        "an analytic transform/response object cannot reuse the enclosing "
        "payload object ID",
        std::string(path) + "/transform_or_response_identities");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_runtime_payload(
    const RegisteredRuntimeRecipeV1& payload,
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& contract) {
  constexpr std::string_view path = "/result/artifact/payload/body";
  const RegisteredRuntimeRecipeContractV1 key{
      payload.registered_recipe_id, payload.registered_recipe_version,
      payload.parameter_schema_id, payload.parameter_schema_version,
      payload.state_codec_schema_id, payload.state_codec_schema_version,
      payload.mark_codec_schema_id, payload.mark_codec_schema_version};
  const auto& registry = manifest.value()
                             .scientific_construction_policy_schema
                             .registered_runtime_recipes;
  if (payload.payload_version != kProtocolVersion ||
      payload.registered_provider != manifest.value().provider ||
      payload.registered_provider != contract.provider() ||
      !payload_targets_match_context(payload.ordered_deployed_targets,
                                     request, contract)) {
    return failure<void>(
        "c15.runtime_recipe_binding",
        "runtime recipe payload has a stale version, provider, or exact "
        "ordered target binding",
        std::string(path));
  }
  if (std::find(registry.begin(), registry.end(), key) == registry.end()) {
    return failure<void>(
        "c15.runtime_recipe_not_registered",
        "runtime recipe and all of its parameter/codec schema versions must "
        "equal one allowlisted manifest entry",
        std::string(path) + "/registered_recipe_id");
  }
  if (!named_values_are_canonical(payload.parameters)) {
    return failure<void>(
        "c15.runtime_recipe_parameter_shape",
        "runtime recipe parameters require strict unique nonempty names and "
        "nonempty vector values",
        std::string(path) + "/parameters");
  }
  if (payload.state_codecs != contract.descriptor_core().state_fields ||
      payload.mark_codecs != contract.descriptor_core().marks) {
    return failure<void>(
        "c15.runtime_recipe_codec_binding",
        "runtime recipe state and mark codecs must equal the complete "
        "accepted descriptor bindings",
        std::string(path));
  }
  return Result<void>::success();
}

[[nodiscard]] std::optional<std::vector<ExactRational>> point_product_values(
    const ThreeBinScalarResponseV1& response,
    const DeployedResponseProductIdV1& selected) {
  return std::visit(
      [&response](const auto& product)
          -> std::optional<std::vector<ExactRational>> {
        using Product = std::decay_t<decltype(product)>;
        std::vector<ExactRational> values;
        values.reserve(3U);
        if constexpr (std::same_as<Product, RawResponseProductId>) {
          if (product != response.raw_response.product_id) {
            return std::nullopt;
          }
          for (std::size_t index = 0U;
               index < response.raw_response.identifications.size();
               ++index) {
            const CoefficientIdentificationV1& identification =
                response.raw_response.identifications[index];
            if (identification.target_bin_binding !=
                    static_cast<ThreeBinCoefficientV1>(index) ||
                identification.coefficient_status.raw_value_status !=
                    RawValueStatusV1::exact_point ||
                !identification.raw_point.has_value()) {
              return std::nullopt;
            }
            values.push_back(exact_value(*identification.raw_point));
          }
        } else {
          const ResponseCoefficientTripleV1* coefficients = nullptr;
          if constexpr (std::same_as<Product, NominalResponseProductId>) {
            if (!response.nominal_response.has_value() ||
                product != response.nominal_response->product_id) {
              return std::nullopt;
            }
            coefficients = &response.nominal_response->coefficients;
          } else {
            if (!response.recoded_response.has_value() ||
                product != response.recoded_response->product_id) {
              return std::nullopt;
            }
            coefficients = &response.recoded_response->coefficients;
          }
          for (std::size_t index = 0U; index < coefficients->size(); ++index) {
            if ((*coefficients)[index].bin !=
                static_cast<ThreeBinCoefficientV1>(index)) {
              return std::nullopt;
            }
            values.push_back(exact_value((*coefficients)[index].value));
          }
        }
        if (!std::all_of(values.begin(), values.end(),
                         [](const ExactRational& value) {
                           return value.is_nonnegative() &&
                                  value <= ExactRational::one();
                         })) {
          return std::nullopt;
        }
        return values;
      },
      selected);
}

[[nodiscard]] bool envelope_scope_is_accepted(
    const ResponseEnvelopeEvidenceV1& payload,
    const MetricSupportManifest& manifest) {
  return std::any_of(
      manifest.clauses().begin(), manifest.clauses().end(),
      [&payload](const MetricSupportClauseV1& clause) {
        return std::any_of(
            clause.required_roles.begin(), clause.required_roles.end(),
            [&payload](const MetricSupportRoleRequirementV1& role) {
              return role.role == MetricSupportRoleV1::response_envelope &&
                     role.target_scope ==
                         MetricTargetScopeV1::deployed_singleton_target &&
                     role.result_scope == payload.result_scope &&
                     role.evidence_scope == payload.evidence_scope;
            });
      });
}

[[nodiscard]] Result<void> validate_response_envelope_payload(
    const ResponseEnvelopeEvidenceV1& payload,
    const SurrogateArtifactV1& artifact,
    const SurrogateBuildRequest& request,
    const AcceptedCapabilityContract& contract) {
  constexpr std::string_view path = "/result/artifact/payload/body";
  if (payload.payload_version != kProtocolVersion ||
      payload.ordered_deployed_targets.size() != 1U ||
      !payload_targets_match_context(payload.ordered_deployed_targets,
                                     request, contract) ||
      payload.lower_response.deployed_target !=
          payload.ordered_deployed_targets.front() ||
      payload.upper_response.deployed_target !=
          payload.ordered_deployed_targets.front()) {
    return failure<void>(
        "c15.response_envelope_target_binding",
        "response-envelope payload and both retained scalar ledgers must bind "
        "the exact singleton target",
        std::string(path));
  }
  if ((payload.result_scope != MetricResultScopeV1::response_envelope &&
       payload.result_scope != MetricResultScopeV1::physical_bound) ||
      payload.evidence_scope == MetricEvidenceScopeV1::none ||
      !envelope_scope_is_accepted(payload, contract.structural_manifest())) {
    return failure<void>(
        "c15.response_envelope_scope_promotion",
        "response-envelope result/evidence scope must equal an accepted "
        "singleton response-envelope role without promotion",
        std::string(path));
  }
  if (payload.lower_response_product !=
          payload.lower_response.deployed_response_product_id ||
      payload.upper_response_product !=
          payload.upper_response.deployed_response_product_id) {
    return failure<void>(
        "c15.response_envelope_product_binding",
        "lower and upper product selectors must equal the selected products "
        "in their retained response ledgers",
        std::string(path));
  }
  const auto lower = point_product_values(payload.lower_response,
                                          payload.lower_response_product);
  const auto upper = point_product_values(payload.upper_response,
                                          payload.upper_response_product);
  if (!lower.has_value() || !upper.has_value() ||
      lower->size() != upper->size() ||
      !std::equal(lower->begin(), lower->end(), upper->begin(), upper->end(),
                  [](const ExactRational& low, const ExactRational& high) {
                    return low <= high;
                  })) {
    return failure<void>(
        "c15.response_envelope_order",
        "response-envelope selectors must name complete point products whose "
        "three exact coefficient bounds are ordered",
        std::string(path));
  }
  if (!nonzero_digest(payload.comparison_domain_id.object_digest) ||
      !references_are_canonical(payload.typed_evidence_components, true) ||
      payload.comparison_domain_id.object_id ==
          artifact.payload_identity.object_id ||
      std::any_of(
          payload.typed_evidence_components.begin(),
          payload.typed_evidence_components.end(),
          [&payload, &artifact](const ArtifactObjectReferenceV1& evidence) {
            return evidence.object_id == payload.comparison_domain_id.object_id ||
                   evidence.object_id == artifact.payload_identity.object_id;
          })) {
    return failure<void>(
        "c15.response_envelope_evidence_shape",
        "response-envelope comparison domain and typed evidence require "
        "distinct, canonical, content-bearing object identities",
        std::string(path));
  }
  if (payload.authorizes_point_product !=
      payload.authorized_point_product.has_value()) {
    return failure<void>(
        "c15.response_envelope_point_authorization_shape",
        "point authorization boolean and optional typed product must have "
        "identical presence",
        std::string(path) + "/authorized_point_product");
  }
  if (payload.authorized_point_product.has_value()) {
    auto authorized = point_product_values(
        payload.lower_response, *payload.authorized_point_product);
    if (!authorized.has_value()) {
      authorized = point_product_values(payload.upper_response,
                                        *payload.authorized_point_product);
    }
    if (!authorized.has_value() || authorized->size() != lower->size() ||
        !std::equal(
            lower->begin(), lower->end(), authorized->begin(),
            authorized->end(), [](const ExactRational& low,
                                  const ExactRational& point) {
              return low <= point;
            }) ||
        !std::equal(
            authorized->begin(), authorized->end(), upper->begin(),
            upper->end(), [](const ExactRational& point,
                             const ExactRational& high) {
              return point <= high;
            })) {
      return failure<void>(
          "c15.response_envelope_point_authorization_binding",
          "an authorized point must name a retained point product inside all "
          "three exact envelope bounds",
          std::string(path) + "/authorized_point_product");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool direct_role_is_declared(
    const MetricSupportClauseV1& clause) {
  return std::any_of(
      clause.required_roles.begin(), clause.required_roles.end(),
      [&clause](const MetricSupportRoleRequirementV1& role) {
        return role.role == MetricSupportRoleV1::direct_metric_value &&
               role.target_scope == MetricTargetScopeV1::exact_request_targets &&
               role.result_scope == clause.result_scope &&
               role.evidence_scope ==
                   MetricEvidenceScopeV1::deployed_surrogate_law;
      });
}

[[nodiscard]] Result<void> validate_direct_payload(
    const DirectMetricPayloadV1& payload,
    const SurrogateArtifactV1& artifact,
    const SurrogateBuildRequest& request,
    const AcceptedCapabilityContract& contract) {
  constexpr std::string_view path = "/result/artifact/payload/body/values";
  const auto& clauses = contract.structural_manifest().clauses();
  auto requirements_digest =
      canonical_metric_requirements_digest(contract.requirements());
  if (!requirements_digest) {
    return Result<void>::failure(requirements_digest.error());
  }
  if (payload.payload_version != kProtocolVersion || payload.values.empty() ||
      payload.values.size() != clauses.size()) {
    return failure<void>(
        "c15.direct_payload_clause_cardinality",
        "direct payload requires exactly one value for every accepted "
        "structural metric clause",
        std::string(path));
  }

  std::vector<ArtifactObjectReferenceV1> value_identities;
  value_identities.reserve(payload.values.size());
  for (std::size_t index = 0U; index < payload.values.size(); ++index) {
    const DirectMetricValueV1& value = payload.values[index];
    const MetricSupportClauseV1& clause = clauses[index];
    const std::string value_path =
        std::string(path) + "/" + std::to_string(index);
    if (value.metric_clause_id != clause.clause_id ||
        (index != 0U &&
         !(payload.values[index - 1U].metric_clause_id <
           value.metric_clause_id)) ||
        value.ordered_targets != clause.ordered_targets ||
        value.ordered_targets.empty() ||
        !duplicate_free<QueueId>(value.ordered_targets) ||
        value.selection_assumptions != clause.selection_domain.kinds ||
        value.arrival_assumptions != clause.arrival_assumptions ||
        value.result_scope != clause.result_scope ||
        value.result_scope == MetricResultScopeV1::not_a_metric_result ||
        !direct_role_is_declared(clause)) {
      return failure<void>(
          "c15.direct_value_clause_binding",
          "direct value order, target/selection/arrival domain, scope and "
          "role must exactly equal its accepted structural clause",
          value_path);
    }
    if (!portable_value_has_closed_shape(value.value) ||
        static_cast<std::uint8_t>(value.validity_basis) >
            static_cast<std::uint8_t>(
                DirectMetricValidityBasisV1::certified_bound) ||
        !references_are_canonical(value.evidence_ids, true)) {
      return failure<void>(
          "c15.direct_value_domain_or_evidence",
          "direct values require a closed nonempty value, a closed validity "
          "basis, and canonical nonempty validity evidence",
          value_path);
    }
    if (value.request_digest != request.request_digest().value() ||
        value.normalized_metric_request_digest !=
            requirements_digest.value() ||
        value.target_selection_digest !=
            request.framework_problem_view().fingerprints().target_selection ||
        value.configured_arrival_digest !=
            request.framework_problem_view().fingerprints().compiled_arrival ||
        value.accepted_contract_digest != contract.contract_digest()) {
      return failure<void>(
          "c15.direct_value_context_binding",
          "direct value must bind the exact final request, normalized metric "
          "request, target selection, configured arrival and accepted contract",
          value_path);
    }
    auto value_digest = direct_metric_value_digest_v1(value);
    if (!value_digest ||
        value_digest.value() != value.value_id.object_digest ||
        !nonzero_digest(value.value_id.object_digest) ||
        value.value_id.object_id == artifact.payload_identity.object_id ||
        std::any_of(
            value.evidence_ids.begin(), value.evidence_ids.end(),
            [&value, &artifact](const ArtifactObjectReferenceV1& evidence) {
              return evidence.object_id == value.value_id.object_id ||
                     evidence.object_id ==
                         artifact.payload_identity.object_id;
            })) {
      return failure<void>(
          "c15.direct_value_identity",
          "direct value identity must seal its full content and remain "
          "distinct from payload and evidence object IDs",
          value_path + "/value_id");
    }
    value_identities.push_back(value.value_id);
  }
  if (!duplicate_free<ArtifactObjectReferenceV1>(value_identities) ||
      !distinct_object_ids(value_identities)) {
    return failure<void>(
        "c15.direct_value_duplicate_identity",
        "distinct direct metric clauses cannot reuse one direct-value "
        "identity",
        std::string(path));
  }
  return Result<void>::success();
}

}  // namespace

Result<void> validate_non_table_payload_v1(
    const ArtifactPayloadV1& payload, const SurrogateArtifactV1& artifact,
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& validated_full_manifest,
    const AcceptedCapabilityContract& accepted_contract) {
  if (artifact.payload != payload) {
    return failure<void>(
        "c15.payload_validation_context_mismatch",
        "non-table payload validation must receive the enclosing artifact's "
        "exact active payload",
        "/result/artifact/payload");
  }
  auto digest = canonical_artifact_payload_digest_v1(payload);
  if (!digest || digest.value() != artifact.payload_digest ||
      artifact.payload_identity.object_digest != artifact.payload_digest) {
    return failure<void>(
        "c15.payload_validation_identity_mismatch",
        "non-table payload validation requires the exact canonical enclosing "
        "payload identity",
        "/result/artifact/payload_digest");
  }

  if (const auto* analytic =
          std::get_if<FiniteParameterAnalyticDataV1>(&payload)) {
    return validate_analytic_payload(*analytic, artifact, request,
                                     validated_full_manifest,
                                     accepted_contract);
  }
  if (const auto* runtime =
          std::get_if<RegisteredRuntimeRecipeV1>(&payload)) {
    return validate_runtime_payload(*runtime, request,
                                    validated_full_manifest,
                                    accepted_contract);
  }
  if (const auto* envelope =
          std::get_if<ResponseEnvelopeEvidenceV1>(&payload)) {
    return validate_response_envelope_payload(*envelope, artifact, request,
                                              accepted_contract);
  }
  if (const auto* direct = std::get_if<DirectMetricPayloadV1>(&payload)) {
    return validate_direct_payload(*direct, artifact, request,
                                   accepted_contract);
  }
  return Result<void>::success();
}

}  // namespace mwperf::artifact::detail
