#include "finite_prefix_constant_tail_validation.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <nlohmann/json.hpp>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

#include "payload_wire.hpp"

namespace mwperf::artifact::detail {
namespace {

using Json = nlohmann::ordered_json;

template <typename T>
[[nodiscard]] Result<T> failure(
    std::string code, std::string message,
    std::optional<std::string> path = std::nullopt) {
  return Result<T>::failure(
      Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), std::nullopt, std::move(path), {}});
}

[[nodiscard]] bool binary64(const PortableScientificScalar& value) noexcept {
  return value.kind() == PortableScientificScalarKind::binary64;
}

[[nodiscard]] ExactRational exact(const PortableScientificScalar& value) {
  return binary64_as_exact_rational(value);
}

[[nodiscard]] bool binary64_probability(
    const PortableScientificScalar& value) {
  if (!binary64(value)) return false;
  const ExactRational decoded = exact(value);
  return decoded.is_nonnegative() && decoded <= ExactRational::one();
}

[[nodiscard]] bool binary64_nonnegative(
    const PortableScientificScalar& value) {
  return binary64(value) && exact(value).is_nonnegative();
}

[[nodiscard]] FinitePrefixResponseCoordinateV1 expected_coordinate(
    const std::size_t index, const std::size_t cutoff) {
  if (index == 0U) {
    return {FinitePrefixResponseCoordinateKindV1::structural_level_zero,
            BigNat{0U}};
  }
  if (index <= cutoff) {
    return {FinitePrefixResponseCoordinateKindV1::exact_level,
            BigNat{static_cast<std::uint64_t>(index)}};
  }
  return {FinitePrefixResponseCoordinateKindV1::constant_tail,
          BigNat{static_cast<std::uint64_t>(cutoff + 1U)}};
}

template <std::size_t Size>
[[nodiscard]] bool exact_keys(
    const Json& value, const std::array<std::string_view, Size>& expected) {
  if (!value.is_object() || value.size() != expected.size()) return false;
  return std::all_of(expected.begin(), expected.end(),
                     [&](const std::string_view key) {
                       return value.contains(std::string(key));
                     });
}

[[nodiscard]] bool scalar_equals(const Json& value,
                                 const PortableScientificScalar& expected,
                                 const std::string& path) {
  auto decoded = wire::decode_scalar(value, path);
  return decoded && decoded.value() == expected && binary64(decoded.value());
}

[[nodiscard]] bool natural_equals(const Json& value, const BigNat& expected,
                                  const std::string& path) {
  auto decoded = wire::decode_big_nat(value, path);
  return decoded && decoded.value() == expected;
}

}  // namespace

Result<void> validate_finite_prefix_constant_tail_shape_v1(
    const FinitePrefixConstantTailResponseV1& response,
    const BigNat& expected_response_cutoff,
    const BigNat& descriptor_tail_from) {
  if (expected_response_cutoff < BigNat{2U} ||
      expected_response_cutoff > BigNat{5U} ||
      response.response_cutoff != expected_response_cutoff ||
      descriptor_tail_from != expected_response_cutoff + BigNat{1U}) {
    return failure<void>(
        "c15.finite_prefix_cutoff_binding",
        "provider, payload and descriptor must agree on one supported "
        "finite-prefix cutoff and tail boundary",
        "/result/artifact/payload/body/response_cutoff");
  }

  const std::size_t cutoff =
      expected_response_cutoff.value().convert_to<std::size_t>();
  const std::size_t coordinate_count = cutoff + 2U;
  const auto& raw = response.raw_response;
  if (response.payload_version != 1U ||
      raw.response_cutoff != expected_response_cutoff ||
      raw.deployed_target != response.deployed_target ||
      raw.configured_arrival_binding != response.configured_arrival_binding ||
      raw.ensemble_count.is_zero() || raw.window_length.is_zero() ||
      raw.identifications.size() != coordinate_count ||
      response.deployed_response_product_id != raw.product_id) {
    return failure<void>(
        "c15.finite_prefix_raw_binding",
        "finite-prefix payload must deploy one complete raw product with "
        "matching target, arrival, cutoff, ensemble and window shape",
        "/result/artifact/payload/body/raw_response");
  }

  std::vector<FinitePrefixResponseCoordinateV1> coordinates;
  coordinates.reserve(coordinate_count);
  std::vector<ArtifactObjectReferenceV1> coefficient_ids;
  coefficient_ids.reserve(coordinate_count);
  std::optional<ArtifactObjectReferenceV1> family_id;
  for (std::size_t index = 0U; index < coordinate_count; ++index) {
    const auto& identification = raw.identifications[index];
    const auto expected = expected_coordinate(index, cutoff);
    if (identification.coordinate != expected ||
        !binary64_nonnegative(identification.pooled_unserved_mass) ||
        !binary64_nonnegative(identification.pooled_served_mass) ||
        !binary64_probability(identification.raw_point) ||
        identification.family_evidence_envelope_ids.size() != 1U) {
      return failure<void>(
          "c15.finite_prefix_identification_shape",
          "finite-prefix identifications must be complete ordered binary64 "
          "coordinates with one family-evidence reference",
          "/result/artifact/payload/body/raw_response/identifications/" +
              std::to_string(index));
    }
    if (index == 0U && identification.raw_point.binary64_bits() != 0U) {
      return failure<void>(
          "c15.finite_prefix_structural_zero",
          "the structural level-zero service coefficient must be canonical "
          "positive zero bits",
          "/result/artifact/payload/body/raw_response/identifications/0/"
          "raw_point");
    }
    if (!family_id.has_value()) {
      family_id = identification.family_evidence_envelope_ids.front();
    } else if (*family_id !=
               identification.family_evidence_envelope_ids.front()) {
      return failure<void>(
          "c15.finite_prefix_family_identity",
          "every dynamic coefficient must cite the same one family "
          "evidence envelope",
          "/result/artifact/payload/body/raw_response/identifications/" +
              std::to_string(index) + "/family_evidence_envelope_ids");
    }
    if (std::find(coefficient_ids.begin(), coefficient_ids.end(),
                  identification.coefficient_id) != coefficient_ids.end()) {
      return failure<void>(
          "c15.finite_prefix_coefficient_identity_duplicate",
          "dynamic coefficient identities must be unique",
          "/result/artifact/payload/body/raw_response/identifications/" +
              std::to_string(index) + "/coefficient_id");
    }
    coefficient_ids.push_back(identification.coefficient_id);
    coordinates.push_back(identification.coordinate);
  }

  if (response.raw_envelopes.size() != 1U) {
    return failure<void>(
        "c15.finite_prefix_envelope_count",
        "a complete CP07.1 Built response requires exactly one simultaneous "
        "raw envelope",
        "/result/artifact/payload/body/raw_envelopes");
  }
  const auto& envelope = response.raw_envelopes.front();
  if (envelope.source_product != raw.product_id ||
      envelope.construction_law_digest != raw.proposal_law_digest ||
      envelope.response_cutoff != expected_response_cutoff ||
      envelope.covered_coordinates != coordinates ||
      envelope.lower.size() != coordinate_count ||
      envelope.upper.size() != coordinate_count ||
      envelope.certification_method.empty() ||
      envelope.coverage != RawEnvelopeCoverageV1::simultaneous ||
      envelope.population_conditioning_premise !=
          PopulationConditioningPremiseV1::
              conditional_on_population_positivity ||
      envelope.sample_size != raw.ensemble_count ||
      envelope.scope != RawEnvelopeScopeV1::proposal_raw ||
      envelope.family_evidence_envelope_ids.size() != 1U ||
      !family_id.has_value() ||
      envelope.family_evidence_envelope_ids.front() != *family_id) {
    return failure<void>(
        "c15.finite_prefix_envelope_binding",
        "the dynamic raw envelope must cover the complete ordered response "
        "and preserve its cutoff, source, construction, sample and family "
        "bindings",
        "/result/artifact/payload/body/raw_envelopes/0");
  }
  if (!binary64_nonnegative(envelope.concentration_radius_lower) ||
      !binary64_nonnegative(envelope.concentration_radius_upper) ||
      exact(envelope.concentration_radius_lower) >
          exact(envelope.concentration_radius_upper) ||
      !binary64_nonnegative(envelope.floating_point_enclosure)) {
    return failure<void>(
        "c15.finite_prefix_enclosure_domain",
        "the concentration-radius enclosure and floating-point enclosure "
        "must be ordered nonnegative binary64 values",
        "/result/artifact/payload/body/raw_envelopes/0/"
        "concentration_radius");
  }
  for (std::size_t index = 0U; index < coordinate_count; ++index) {
    if (!binary64_probability(envelope.lower[index]) ||
        !binary64_probability(envelope.upper[index]) ||
        exact(envelope.lower[index]) > exact(envelope.upper[index]) ||
        exact(raw.identifications[index].raw_point) <
            exact(envelope.lower[index]) ||
        exact(envelope.upper[index]) <
            exact(raw.identifications[index].raw_point)) {
      return failure<void>(
          "c15.finite_prefix_interval_domain",
          "each binary64 coefficient interval must be ordered in [0,1] "
          "and contain its nominal point",
          "/result/artifact/payload/body/raw_envelopes/0/lower/" +
              std::to_string(index));
    }
    if (index == 0U &&
        (envelope.lower[index].binary64_bits() != 0U ||
         envelope.upper[index].binary64_bits() != 0U)) {
      return failure<void>(
          "c15.finite_prefix_structural_zero_interval",
          "the structural level-zero interval must be canonical [0,0] bits",
          "/result/artifact/payload/body/raw_envelopes/0/lower/0");
    }
  }
  return Result<void>::success();
}

Result<void> validate_finite_prefix_constant_tail_family_evidence_v1(
    const FinitePrefixConstantTailResponseV1& response,
    const std::span<const FamilyEvidenceEnvelopeV1> family_evidence) {
  if (response.raw_envelopes.size() != 1U ||
      response.raw_response.identifications.empty() ||
      family_evidence.size() != 1U ||
      family_evidence.front().family_evidence_schema_id !=
          "full_orbit_finite_prefix_evidence_v1" ||
      family_evidence.front().family_evidence_schema_version != 1U) {
    return failure<void>(
        "c15.finite_prefix_family_schema",
        "the dynamic response requires exactly one version-1 Full Orbit "
        "finite-prefix family envelope",
        "/result/artifact/family_evidence");
  }
  const auto& family = family_evidence.front();
  const auto& raw = response.raw_response;
  const auto& envelope = response.raw_envelopes.front();
  auto proposal_digest = sha256_domain_separated(
      "mwperf.fofs.cp07_1.proposal_law.v1",
      family.canonical_family_body);
  if (envelope.family_evidence_envelope_ids !=
          std::vector<ArtifactObjectReferenceV1>{family.evidence_id} ||
      !proposal_digest || proposal_digest.value() != raw.proposal_law_digest ||
      std::any_of(
          raw.identifications.begin(), raw.identifications.end(),
          [&](const FinitePrefixCoefficientIdentificationV1& coefficient) {
            return coefficient.family_evidence_envelope_ids !=
                   std::vector<ArtifactObjectReferenceV1>{family.evidence_id};
          })) {
    return failure<void>(
        "c15.finite_prefix_family_reference",
        "the raw product and envelope must cite the one retained family "
        "evidence identity and exact family-body proposal law",
        "/result/artifact/family_evidence/0/evidence_id");
  }

  try {
    const char* begin = reinterpret_cast<const char*>(
        family.canonical_family_body.data());
    const char* end = begin + family.canonical_family_body.size();
    const Json body = Json::parse(begin, end, nullptr, true, false);
    static constexpr std::array<std::string_view, 9U> kBodyFields{
        "concentration_radius", "ensemble_count",
        "floating_point_enclosure", "masses", "response",
        "response_cutoff", "schema_id", "schema_version",
        "window_length"};
    static constexpr std::array<std::string_view, 3U> kCurveFields{
        "levels", "response_cutoff", "tail"};
    static constexpr std::array<std::string_view, 3U> kMassFields{
        "level", "served", "unserved"};
    static constexpr std::array<std::string_view, 3U> kTailMassFields{
        "served", "tail_from", "unserved"};
    static constexpr std::array<std::string_view, 3U> kResponseFields{
        "interval", "level", "point"};
    static constexpr std::array<std::string_view, 3U> kTailResponseFields{
        "interval", "point", "tail_from"};
    static constexpr std::array<std::string_view, 2U> kIntervalFields{
        "lower", "upper"};
    if (!exact_keys(body, kBodyFields) ||
        !body.at("schema_id").is_string() ||
        body.at("schema_id").get<std::string>() !=
            "full_orbit_finite_prefix_evidence_v1" ||
        !body.at("schema_version").is_number_unsigned() ||
        body.at("schema_version").get<std::uint64_t>() != 1U ||
        !natural_equals(body.at("response_cutoff"), response.response_cutoff,
                        "/canonical_family_body/response_cutoff") ||
        !natural_equals(body.at("ensemble_count"), raw.ensemble_count,
                        "/canonical_family_body/ensemble_count") ||
        !natural_equals(body.at("window_length"), raw.window_length,
                        "/canonical_family_body/window_length") ||
        !exact_keys(body.at("concentration_radius"), kIntervalFields) ||
        !scalar_equals(body.at("concentration_radius").at("lower"),
                       envelope.concentration_radius_lower,
                       "/canonical_family_body/concentration_radius/lower") ||
        !scalar_equals(body.at("concentration_radius").at("upper"),
                       envelope.concentration_radius_upper,
                       "/canonical_family_body/concentration_radius/upper") ||
        !scalar_equals(body.at("floating_point_enclosure"),
                       envelope.floating_point_enclosure,
                       "/canonical_family_body/floating_point_enclosure") ||
        !exact_keys(body.at("masses"), kCurveFields) ||
        !exact_keys(body.at("response"), kCurveFields) ||
        !natural_equals(body.at("masses").at("response_cutoff"),
                        response.response_cutoff,
                        "/canonical_family_body/masses/response_cutoff") ||
        !natural_equals(body.at("response").at("response_cutoff"),
                        response.response_cutoff,
                        "/canonical_family_body/response/response_cutoff") ||
        !body.at("masses").at("levels").is_array() ||
        !body.at("response").at("levels").is_array() ||
        body.at("masses").at("levels").size() + 1U !=
            raw.identifications.size() ||
        body.at("response").at("levels").size() + 1U !=
            raw.identifications.size()) {
      return failure<void>(
          "c15.finite_prefix_family_body_binding",
          "finite-prefix family body header, schema, cutoff, ensemble, "
          "window, radius or vector length differs from the payload",
          "/result/artifact/family_evidence/0/canonical_family_body");
    }

    const std::size_t finite_count = raw.identifications.size() - 1U;
    for (std::size_t index = 0U; index < finite_count; ++index) {
      const auto& mass = body.at("masses").at("levels").at(index);
      const auto& response_value =
          body.at("response").at("levels").at(index);
      const auto& coefficient = raw.identifications[index];
      if (!exact_keys(mass, kMassFields) ||
          !exact_keys(response_value, kResponseFields) ||
          !exact_keys(response_value.at("interval"), kIntervalFields) ||
          !natural_equals(mass.at("level"),
                          coefficient.coordinate.level_or_tail_from,
                          "/canonical_family_body/masses/levels/" +
                              std::to_string(index) + "/level") ||
          !natural_equals(response_value.at("level"),
                          coefficient.coordinate.level_or_tail_from,
                          "/canonical_family_body/response/levels/" +
                              std::to_string(index) + "/level") ||
          !scalar_equals(mass.at("unserved"),
                         coefficient.pooled_unserved_mass,
                         "/canonical_family_body/masses/levels/" +
                             std::to_string(index) + "/unserved") ||
          !scalar_equals(mass.at("served"), coefficient.pooled_served_mass,
                         "/canonical_family_body/masses/levels/" +
                             std::to_string(index) + "/served") ||
          !scalar_equals(response_value.at("point"), coefficient.raw_point,
                         "/canonical_family_body/response/levels/" +
                             std::to_string(index) + "/point") ||
          !scalar_equals(response_value.at("interval").at("lower"),
                         envelope.lower[index],
                         "/canonical_family_body/response/levels/" +
                             std::to_string(index) + "/interval/lower") ||
          !scalar_equals(response_value.at("interval").at("upper"),
                         envelope.upper[index],
                         "/canonical_family_body/response/levels/" +
                             std::to_string(index) + "/interval/upper")) {
        return failure<void>(
            "c15.finite_prefix_family_body_coordinate",
            "finite-prefix family level differs from the bit-exact payload "
            "mass, point, interval or coordinate",
            "/result/artifact/family_evidence/0/canonical_family_body");
      }
    }

    const std::size_t tail_index = raw.identifications.size() - 1U;
    const auto& tail_coefficient = raw.identifications[tail_index];
    const auto& tail_mass = body.at("masses").at("tail");
    const auto& tail_response = body.at("response").at("tail");
    if (!exact_keys(tail_mass, kTailMassFields) ||
        !exact_keys(tail_response, kTailResponseFields) ||
        !exact_keys(tail_response.at("interval"), kIntervalFields) ||
        !natural_equals(tail_mass.at("tail_from"),
                        tail_coefficient.coordinate.level_or_tail_from,
                        "/canonical_family_body/masses/tail/tail_from") ||
        !natural_equals(tail_response.at("tail_from"),
                        tail_coefficient.coordinate.level_or_tail_from,
                        "/canonical_family_body/response/tail/tail_from") ||
        !scalar_equals(tail_mass.at("unserved"),
                       tail_coefficient.pooled_unserved_mass,
                       "/canonical_family_body/masses/tail/unserved") ||
        !scalar_equals(tail_mass.at("served"),
                       tail_coefficient.pooled_served_mass,
                       "/canonical_family_body/masses/tail/served") ||
        !scalar_equals(tail_response.at("point"),
                       tail_coefficient.raw_point,
                       "/canonical_family_body/response/tail/point") ||
        !scalar_equals(tail_response.at("interval").at("lower"),
                       envelope.lower[tail_index],
                       "/canonical_family_body/response/tail/interval/lower") ||
        !scalar_equals(tail_response.at("interval").at("upper"),
                       envelope.upper[tail_index],
                       "/canonical_family_body/response/tail/interval/upper")) {
      return failure<void>(
          "c15.finite_prefix_family_body_tail",
          "finite-prefix family tail differs from the bit-exact payload "
          "mass, point, interval or tail boundary",
          "/result/artifact/family_evidence/0/canonical_family_body");
    }
    return Result<void>::success();
  } catch (const nlohmann::json::exception& error) {
    return failure<void>(
        "c15.finite_prefix_family_body_json",
        std::string("finite-prefix family body could not be decoded: ") +
            error.what(),
        "/result/artifact/family_evidence/0/canonical_family_body");
  }
}

}  // namespace mwperf::artifact::detail
