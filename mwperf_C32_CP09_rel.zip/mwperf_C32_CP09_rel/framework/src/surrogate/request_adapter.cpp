#include "mwperf/surrogate/surrogate_build_protocol.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include <nlohmann/json.hpp>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/surrogate/detail/request_binding_validation.hpp"
#include "target_specialization.hpp"

namespace mwperf {
namespace {

using Json = nlohmann::ordered_json;

constexpr std::uint32_t kProtocolVersion = 1U;

[[nodiscard]] Diagnostic error(std::string code, std::string message,
                               std::string pointer = {}) {
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    pointer.empty()
                        ? std::optional<std::string>{}
                        : std::optional<std::string>{std::move(pointer)},
                    {}};
}

[[nodiscard]] bool portable_identifier(const std::string_view value) {
  if (value.empty()) {
    return false;
  }
  const auto ascii_alnum = [](const char character) {
    return (character >= '0' && character <= '9') ||
           (character >= 'A' && character <= 'Z') ||
           (character >= 'a' && character <= 'z');
  };
  if (!ascii_alnum(value.front())) {
    return false;
  }
  return std::all_of(value.begin(), value.end(), [ascii_alnum](const char character) {
    return ascii_alnum(character) || character == '.' || character == '_' ||
           character == ':' || character == '+' || character == '-';
  });
}

[[nodiscard]] bool reserved_method_counter_name(
    const std::string_view value) {
  static constexpr std::array<std::string_view, 10U> kReserved{
      "optimizer_calls",
      "optimizer_search_states",
      "configured_generator_draws",
      "request_bytes",
      "result_bytes",
      "stderr_bytes",
      "elapsed_wall_time",
      "wall_time",
      "wall_time_ms",
      "wall_time_ns"};
  return std::find(kReserved.begin(), kReserved.end(), value) !=
         kReserved.end();
}

[[nodiscard]] bool nonzero_digest(const Digest256& digest) {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) { return value != std::byte{0}; });
}

[[nodiscard]] Digest256 zero_digest() {
  const std::array<std::byte, Digest256::kSize> bytes{};
  return Digest256::from_bytes(bytes).value();
}

[[nodiscard]] std::string bytes_to_hex(const std::span<const std::byte> bytes) {
  static constexpr std::array<char, 16U> kHex{
      '0', '1', '2', '3', '4', '5', '6', '7',
      '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
  std::string encoded;
  encoded.reserve(bytes.size() * 2U);
  for (const std::byte byte : bytes) {
    const auto value = std::to_integer<unsigned int>(byte);
    encoded.push_back(kHex[(value >> 4U) & 0x0fU]);
    encoded.push_back(kHex[value & 0x0fU]);
  }
  return encoded;
}

[[nodiscard]] std::vector<std::byte> json_bytes(const Json& value) {
  const std::string text = value.dump(
      -1, ' ', false, nlohmann::json::error_handler_t::strict);
  std::vector<std::byte> bytes;
  bytes.reserve(text.size());
  for (const char character : text) {
    bytes.push_back(
        static_cast<std::byte>(static_cast<unsigned char>(character)));
  }
  return bytes;
}

[[nodiscard]] Result<Json> parse_canonical_json(
    const std::span<const std::byte> bytes, const std::string_view pointer) {
  if (bytes.empty()) {
    return Result<Json>::failure(error(
        "c15.noncanonical_json", "canonical JSON value must not be empty",
        std::string(pointer)));
  }
  std::string text;
  text.reserve(bytes.size());
  for (const std::byte byte : bytes) {
    text.push_back(static_cast<char>(std::to_integer<unsigned char>(byte)));
  }
  try {
    Json parsed = Json::parse(text, nullptr, true, true);
    if (parsed.dump(-1, ' ', false,
                    nlohmann::json::error_handler_t::strict) != text) {
      return Result<Json>::failure(error(
          "c15.noncanonical_json",
          "value is valid JSON but is not the canonical compact encoding",
          std::string(pointer)));
    }
    return Result<Json>::success(std::move(parsed));
  } catch (const nlohmann::json::exception&) {
    return Result<Json>::failure(error(
        "c15.invalid_json", "value is not closed canonical UTF-8 JSON",
        std::string(pointer)));
  }
}

// nlohmann::ordered_json stores integers in fixed-width native types.  CP09
// projection cutoffs are mathematical coordinates, not allocation indices,
// and therefore intentionally admit canonical integers wider than uint64.
// Validate those values without rounding by replacing only lexically valid
// large integer tokens with collision-free strings for the DOM round trip,
// then restoring the original tokens before the canonical-byte comparison.
[[nodiscard]] Result<std::string> canonical_json_fragment_text(
    const std::span<const std::byte> bytes, const std::string_view pointer) {
  auto native = parse_canonical_json(bytes, pointer);
  if (native) {
    std::string text;
    text.reserve(bytes.size());
    for (const std::byte byte : bytes) {
      text.push_back(
          static_cast<char>(std::to_integer<unsigned char>(byte)));
    }
    return Result<std::string>::success(std::move(text));
  }
  Diagnostic native_error = native.error();

  std::string text;
  text.reserve(bytes.size());
  for (const std::byte byte : bytes) {
    text.push_back(static_cast<char>(std::to_integer<unsigned char>(byte)));
  }
  std::string marker_prefix{"__mwperf_raw_integer_"};
  while (text.find(marker_prefix) != std::string::npos) {
    marker_prefix.push_back('_');
  }
  struct Replacement final {
    std::string marker;
    std::string lexeme;
  };
  std::vector<Replacement> replacements;
  std::string rewritten;
  rewritten.reserve(text.size());
  for (std::size_t index = 0U; index < text.size();) {
    if (text[index] == '"') {
      const std::size_t begin = index++;
      bool escaped = false;
      while (index < text.size()) {
        const char current = text[index++];
        if (escaped) {
          escaped = false;
        } else if (current == '\\') {
          escaped = true;
        } else if (current == '"') {
          break;
        }
      }
      rewritten.append(text, begin, index - begin);
      continue;
    }
    if (text[index] != '-' &&
        !(text[index] >= '0' && text[index] <= '9')) {
      rewritten.push_back(text[index++]);
      continue;
    }
    const std::size_t begin = index++;
    while (index < text.size()) {
      const char current = text[index];
      if ((current >= '0' && current <= '9') || current == '.' ||
          current == 'e' || current == 'E' || current == '+' ||
          current == '-') {
        ++index;
      } else {
        break;
      }
    }
    const std::string_view token{text.data() + begin, index - begin};
    const std::size_t digits_begin = token.starts_with('-') ? 1U : 0U;
    const bool all_digits = digits_begin < token.size() &&
        std::all_of(token.begin() + static_cast<std::ptrdiff_t>(digits_begin),
                    token.end(), [](const char value) {
                      return value >= '0' && value <= '9';
                    });
    const bool canonical_integer =
        all_digits &&
        ((token.size() - digits_begin == 1U && token[digits_begin] == '0') ||
         (token[digits_begin] >= '1' && token[digits_begin] <= '9')) &&
        !(digits_begin == 1U && token.size() == 2U && token[1U] == '0');
    // Nineteen decimal digits always cover uint64 parsing except for a small
    // suffix of the 20-digit range.  Replacing all 19+-digit canonical
    // integers is harmless and keeps this validator independent of locale and
    // native conversion routines.
    if (canonical_integer && token.size() - digits_begin >= 19U) {
      Replacement replacement{
          marker_prefix + std::to_string(replacements.size()) + "__",
          std::string(token)};
      rewritten += Json(replacement.marker).dump();
      replacements.push_back(std::move(replacement));
    } else {
      rewritten.append(token);
    }
  }
  if (replacements.empty()) {
    return Result<std::string>::failure(std::move(native_error));
  }
  try {
    Json parsed = Json::parse(rewritten, nullptr, true, true);
    std::string restored = parsed.dump(
        -1, ' ', false, nlohmann::json::error_handler_t::strict);
    for (const auto& replacement : replacements) {
      const std::string encoded_marker = Json(replacement.marker).dump();
      const std::size_t found = restored.find(encoded_marker);
      if (found == std::string::npos ||
          restored.find(encoded_marker, found + encoded_marker.size()) !=
              std::string::npos) {
        return Result<std::string>::failure(error(
            "c15.invalid_json",
            "canonical arbitrary-precision integer marker is ambiguous",
            std::string(pointer)));
      }
      restored.replace(found, encoded_marker.size(), replacement.lexeme);
    }
    if (restored != text) {
      return Result<std::string>::failure(error(
          "c15.noncanonical_json",
          "value is valid JSON but is not the canonical compact encoding",
          std::string(pointer)));
    }
    return Result<std::string>::success(std::move(text));
  } catch (const nlohmann::json::exception&) {
    return Result<std::string>::failure(error(
        "c15.invalid_json", "value is not closed canonical UTF-8 JSON",
        std::string(pointer)));
  }
}

[[nodiscard]] Result<std::vector<std::byte>> json_bytes_with_raw_value(
    Json object, const std::string_view member, const std::string_view raw,
    const std::string_view pointer) {
  for (std::uint32_t suffix = 0U; suffix < 100U; ++suffix) {
    const std::string marker =
        "__mwperf_internal_raw_json_value_" + std::to_string(suffix) + "__";
    if (raw.find(marker) != std::string_view::npos) continue;
    object[std::string(member)] = marker;
    std::string encoded = object.dump(
        -1, ' ', false, nlohmann::json::error_handler_t::strict);
    const std::string encoded_marker = Json(marker).dump();
    const std::size_t found = encoded.find(encoded_marker);
    if (found == std::string::npos ||
        encoded.find(encoded_marker, found + encoded_marker.size()) !=
            std::string::npos) {
      continue;
    }
    encoded.replace(found, encoded_marker.size(), raw);
    std::vector<std::byte> result;
    result.reserve(encoded.size());
    for (const char character : encoded) {
      result.push_back(
          static_cast<std::byte>(static_cast<unsigned char>(character)));
    }
    return Result<std::vector<std::byte>>::success(std::move(result));
  }
  return Result<std::vector<std::byte>>::failure(error(
      "c15.raw_json_marker_collision",
      "could not embed the canonical arbitrary-precision JSON value",
      std::string(pointer)));
}

[[nodiscard]] Json natural_json(const BigNat& value) {
  return value.to_decimal_string();
}

[[nodiscard]] Json rational_json(const ExactRational& value) {
  return Json{{"kind", "rational"},
              {"numerator", value.numerator_decimal()},
              {"denominator", value.denominator_decimal()}};
}

[[nodiscard]] Json typed_label_json(const TypedLabel& value) {
  if (const auto* numeric = value.numeric_value(); numeric != nullptr) {
    return Json{{"kind", "numeric"}, {"value", numeric->to_decimal_string()}};
  }
  return Json{{"kind", "text"}, {"value", *value.text_value()}};
}

template <StrongIdDomainName Domain>
[[nodiscard]] Json strong_id_json(const StrongId<Domain>& value) {
  return typed_label_json(value.label());
}

template <typename Enum>
[[nodiscard]] std::optional<std::string_view> token(Enum) = delete;

#define MWPERF_C15_ENUM_TOKEN(TYPE, ...)                                      \
  [[nodiscard]] std::optional<std::string_view> token(const TYPE value) {     \
    switch (value) { __VA_ARGS__ }                                            \
    return std::nullopt;                                                       \
  }
#define MWPERF_C15_ENUM_CASE(VALUE) case VALUE: return #VALUE + sizeof(#VALUE) - sizeof(#VALUE)

// Spellings are deliberately written out rather than derived from C++ names.
MWPERF_C15_ENUM_TOKEN(ConstructionMethodV1,
  case ConstructionMethodV1::closed_form: return "closed_form";
  case ConstructionMethodV1::engineered_deterministic: return "engineered_deterministic";
  case ConstructionMethodV1::engineered_hybrid: return "engineered_hybrid";
  case ConstructionMethodV1::sampled_offline: return "sampled_offline";
  case ConstructionMethodV1::precomputed: return "precomputed";)
MWPERF_C15_ENUM_TOKEN(ProducerModeV1,
  case ProducerModeV1::inline_immediate: return "inline_immediate";
  case ProducerModeV1::in_process_builder: return "in_process_builder";
  case ProducerModeV1::local_executable_builder: return "local_executable_builder";)
MWPERF_C15_ENUM_TOKEN(SemanticTagV1,
  case SemanticTagV1::scalar_backlog_response: return "scalar_backlog_response";
  case SemanticTagV1::stationary_marked_edge: return "stationary_marked_edge";
  case SemanticTagV1::staged_opportunity_flux_law: return "staged_opportunity_flux_law";
  case SemanticTagV1::temporal_one_slot_continuation: return "temporal_one_slot_continuation";
  case SemanticTagV1::romr_residence_word_law: return "romr_residence_word_law";
  case SemanticTagV1::stopped_path_law: return "stopped_path_law";
  case SemanticTagV1::coupled_target_schedule_law: return "coupled_target_schedule_law";
  case SemanticTagV1::direct_metric_decoder: return "direct_metric_decoder";
  case SemanticTagV1::response_envelope_law: return "response_envelope_law";)
MWPERF_C15_ENUM_TOKEN(RuntimeAccessTagV1,
  case RuntimeAccessTagV1::finite_enumerated_row: return "finite_enumerated_row";
  case RuntimeAccessTagV1::sparse_row: return "sparse_row";
  case RuntimeAccessTagV1::normalized_conditional_sampler: return "normalized_conditional_sampler";
  case RuntimeAccessTagV1::analytic_transform: return "analytic_transform";
  case RuntimeAccessTagV1::finite_parameter_analytic_family: return "finite_parameter_analytic_family";
  case RuntimeAccessTagV1::procedural_residence_generator: return "procedural_residence_generator";
  case RuntimeAccessTagV1::direct_metric_decoder: return "direct_metric_decoder";)
MWPERF_C15_ENUM_TOKEN(PayloadClassTagV1,
  case PayloadClassTagV1::three_bin_scalar_response_v1: return "three_bin_scalar_response_v1";
  case PayloadClassTagV1::finite_parameter_analytic_data_v1: return "finite_parameter_analytic_data_v1";
  case PayloadClassTagV1::finite_law_tables_v1: return "finite_law_tables_v1";
  case PayloadClassTagV1::registered_runtime_recipe_v1: return "registered_runtime_recipe_v1";
  case PayloadClassTagV1::response_envelope_evidence_v1: return "response_envelope_evidence_v1";
  case PayloadClassTagV1::direct_metric_payload_v1: return "direct_metric_payload_v1";
  case PayloadClassTagV1::finite_prefix_constant_tail_response_v1: return "finite_prefix_constant_tail_response_v1";
  case PayloadClassTagV1::empirical_finite_window_response_v1: return "empirical_finite_window_response_v1";)
MWPERF_C15_ENUM_TOKEN(TargetCouplingV1,
  case TargetCouplingV1::scalar_target: return "scalar_target";
  case TargetCouplingV1::common_schedule_projection: return "common_schedule_projection";
  case TargetCouplingV1::full_schedule_identity: return "full_schedule_identity";)
MWPERF_C15_ENUM_TOKEN(PointDeploymentPolicyV1,
  case PointDeploymentPolicyV1::not_applicable: return "not_applicable";
  case PointDeploymentPolicyV1::deploy_raw_point: return "deploy_raw_point";
  case PointDeploymentPolicyV1::deploy_nominal_point: return "deploy_nominal_point";
  case PointDeploymentPolicyV1::deploy_recoded_point: return "deploy_recoded_point";)
MWPERF_C15_ENUM_TOKEN(CoefficientCompletionPolicyV1,
  case CoefficientCompletionPolicyV1::not_applicable: return "not_applicable";
  case CoefficientCompletionPolicyV1::require_complete_raw_points: return "require_complete_raw_points";
  case CoefficientCompletionPolicyV1::declared_nominal_completion: return "declared_nominal_completion";
  case CoefficientCompletionPolicyV1::authorized_endpoint_completion: return "authorized_endpoint_completion";)
MWPERF_C15_ENUM_TOKEN(ProjectionPolicyV1,
  case ProjectionPolicyV1::not_applicable: return "not_applicable";
  case ProjectionPolicyV1::identity: return "identity";
  case ProjectionPolicyV1::convex_feasible_mean: return "convex_feasible_mean";)
MWPERF_C15_ENUM_TOKEN(RecodingPolicyV1,
  case RecodingPolicyV1::not_applicable: return "not_applicable";
  case RecodingPolicyV1::identity: return "identity";
  case RecodingPolicyV1::mean_inversion: return "mean_inversion";)
MWPERF_C15_ENUM_TOKEN(EvidenceRolePolicyV1,
  case EvidenceRolePolicyV1::not_applicable: return "not_applicable";
  case EvidenceRolePolicyV1::exact_manifest_roles: return "exact_manifest_roles";)
MWPERF_C15_ENUM_TOKEN(ServiceFamily,
  case ServiceFamily::crossbar_matching: return "crossbar_matching";
  case ServiceFamily::nonoverlapping_intervals: return "nonoverlapping_intervals";
  case ServiceFamily::node_exclusive_matching: return "node_exclusive_matching";
  case ServiceFamily::pairwise_conflicts: return "pairwise_conflicts";
  case ServiceFamily::resource_packing: return "resource_packing";)
MWPERF_C15_ENUM_TOKEN(OptimizerId,
  case OptimizerId::hungarian_exact: return "hungarian_exact";
  case OptimizerId::weighted_interval_dp_exact: return "weighted_interval_dp_exact";
  case OptimizerId::edmonds_blossom_exact: return "edmonds_blossom_exact";
  case OptimizerId::mwis_branch_memo_exact: return "mwis_branch_memo_exact";
  case OptimizerId::binary_packing_memo_exact: return "binary_packing_memo_exact";)
MWPERF_C15_ENUM_TOKEN(TimingConvention,
  case TimingConvention::early_service_late_admission: return "early_service_late_admission";)
MWPERF_C15_ENUM_TOKEN(ArrivalNeedKindV1,
  case ArrivalNeedKindV1::target_intensity: return "target_intensity";
  case ArrivalNeedKindV1::arrival_moment: return "arrival_moment";
  case ArrivalNeedKindV1::full_common_batch: return "full_common_batch";
  case ArrivalNeedKindV1::predictive_phase: return "predictive_phase";
  case ArrivalNeedKindV1::sequential_law: return "sequential_law";
  case ArrivalNeedKindV1::entrance_labels: return "entrance_labels";
  case ArrivalNeedKindV1::finite_support: return "finite_support";
  case ArrivalNeedKindV1::transform: return "transform";
  case ArrivalNeedKindV1::exact_iid_late: return "exact_iid_late";)
MWPERF_C15_ENUM_TOKEN(ArrivalCapabilityUseV1,
  case ArrivalCapabilityUseV1::runtime: return "runtime";
  case ArrivalCapabilityUseV1::construction: return "construction";)
MWPERF_C15_ENUM_TOKEN(CapabilityProvisionNeedV1,
  case CapabilityProvisionNeedV1::any: return "any";
  case CapabilityProvisionNeedV1::portable: return "portable";
  case CapabilityProvisionNeedV1::process_local: return "process_local";)
MWPERF_C15_ENUM_TOKEN(TransformKind,
  case TransformKind::exact_pmf: return "exact_pmf";
  case TransformKind::exact_pgf: return "exact_pgf";
  case TransformKind::closed_transform: return "closed_transform";)
MWPERF_C15_ENUM_TOKEN(DistributionScope,
  case DistributionScope::joint_vector: return "joint_vector";
  case DistributionScope::per_coordinate: return "per_coordinate";)
MWPERF_C15_ENUM_TOKEN(MetricSupportRoleV1,
  case MetricSupportRoleV1::deployed_payload: return "deployed_payload";
  case MetricSupportRoleV1::deployed_response: return "deployed_response";
  case MetricSupportRoleV1::raw_response: return "raw_response";
  case MetricSupportRoleV1::nominal_response: return "nominal_response";
  case MetricSupportRoleV1::projection_center: return "projection_center";
  case MetricSupportRoleV1::projected_mean: return "projected_mean";
  case MetricSupportRoleV1::recoded_response: return "recoded_response";
  case MetricSupportRoleV1::stationary_marked_edge_law: return "stationary_marked_edge_law";
  case MetricSupportRoleV1::staged_opportunity_flux_law: return "staged_opportunity_flux_law";
  case MetricSupportRoleV1::temporal_continuation_law: return "temporal_continuation_law";
  case MetricSupportRoleV1::residence_word_law: return "residence_word_law";
  case MetricSupportRoleV1::stopped_path_law: return "stopped_path_law";
  case MetricSupportRoleV1::coupled_schedule_law: return "coupled_schedule_law";
  case MetricSupportRoleV1::direct_metric_value: return "direct_metric_value";
  case MetricSupportRoleV1::response_envelope: return "response_envelope";
  case MetricSupportRoleV1::raw_response_bound_evidence: return "raw_response_bound_evidence";
  case MetricSupportRoleV1::response_order_evidence: return "response_order_evidence";
  case MetricSupportRoleV1::optimizer_evidence: return "optimizer_evidence";
  case MetricSupportRoleV1::statistical_evidence: return "statistical_evidence";
  case MetricSupportRoleV1::numerical_evidence: return "numerical_evidence";
  case MetricSupportRoleV1::calibration_evidence: return "calibration_evidence";
  case MetricSupportRoleV1::compression_evidence: return "compression_evidence";
  case MetricSupportRoleV1::stability_certificate: return "stability_certificate";
  case MetricSupportRoleV1::reported_validity_or_lift_evidence: return "reported_validity_or_lift_evidence";
  case MetricSupportRoleV1::physical_transfer_evidence: return "physical_transfer_evidence";)
MWPERF_C15_ENUM_TOKEN(BudgetApplicabilityV1,
  case BudgetApplicabilityV1::not_applicable: return "not_applicable";
  case BudgetApplicabilityV1::applicable: return "applicable";)

#undef MWPERF_C15_ENUM_CASE
#undef MWPERF_C15_ENUM_TOKEN

template <typename Enum>
[[nodiscard]] Result<std::string> required_token(
    const Enum value, const std::string_view pointer) {
  const auto encoded = token(value);
  if (!encoded.has_value()) {
    return Result<std::string>::failure(error(
        "c15.unknown_enum", "unknown closed version-1 enum value",
        std::string(pointer)));
  }
  return Result<std::string>::success(std::string(*encoded));
}

template <typename Enum>
[[nodiscard]] bool valid_enum(const Enum value) {
  return token(value).has_value();
}

[[nodiscard]] Json arrival_assumption_json(const ArrivalAssumptionV1& value) {
  Json object{{"kind", std::string(*token(value.kind))},
              {"use", std::string(*token(value.use))},
              {"provision", std::string(*token(value.provision))},
              {"moment_order", value.moment_order.has_value()
                                   ? natural_json(*value.moment_order)
                                   : Json(nullptr)},
              {"joint", value.joint},
              {"phase_conditioned", value.phase_conditioned}};
  object["transform_kind"] = value.transform_kind.has_value()
                                 ? Json(std::string(*token(*value.transform_kind)))
                                 : Json(nullptr);
  object["distribution_scope"] =
      value.distribution_scope.has_value()
          ? Json(std::string(*token(*value.distribution_scope)))
          : Json(nullptr);
  if (value.argument_domain.has_value()) {
    object["argument_domain"] =
        Json{{"lower", rational_json(value.argument_domain->lower)},
             {"upper", rational_json(value.argument_domain->upper)},
             {"lower_inclusive", value.argument_domain->lower_inclusive},
             {"upper_inclusive", value.argument_domain->upper_inclusive}};
  } else {
    object["argument_domain"] = nullptr;
  }
  return object;
}

[[nodiscard]] Result<Json> c14_manifest_capsule_json(
    const MetricSupportManifest& manifest) {
  auto bytes = canonical_metric_support_manifest_bytes_v1(manifest);
  if (!bytes) {
    return Result<Json>::failure(bytes.error());
  }
  return Result<Json>::success(Json{
      {"schema_version", 1U},
      {"canonical_manifest_bytes", bytes_to_hex(bytes.value())},
      {"manifest_digest", manifest.canonical_digest().hex()}});
}

[[nodiscard]] Json policies_json(const PreviewPoliciesV1& value) {
  return Json{{"point_product_deployment",
               std::string(*token(value.point_deployment))},
              {"coefficient_completion",
               std::string(*token(value.coefficient_completion))},
              {"projection", std::string(*token(value.projection))},
              {"recoding", std::string(*token(value.recoding))},
              {"evidence_role_fulfillment",
               std::string(*token(value.evidence_roles))}};
}

[[nodiscard]] Json applicability_json(
    const SchedulerConstraintApplicabilityV1& value) {
  Json pairs = Json::array();
  for (const auto& pair : value.scheduler_optimizer_pairs) {
    pairs.push_back(Json{{"service_family", std::string(*token(pair.service_family))},
                         {"optimizer", std::string(*token(pair.optimizer))}});
  }
  Json timings = Json::array();
  for (const auto timing : value.timing_conventions) {
    timings.push_back(std::string(*token(timing)));
  }
  return Json{{"scheduler_optimizer_pairs", std::move(pairs)},
              {"timing_conventions", std::move(timings)}};
}

[[nodiscard]] Result<Json> scientific_projection_json(
    const ProviderScientificContractProjectionV1& value) {
  auto manifest = c14_manifest_capsule_json(value.metric_clause_upper_envelope);
  if (!manifest) {
    return Result<Json>::failure(manifest.error());
  }
  Json arrival = Json::array();
  for (const auto& assumption :
       value.target_and_arrival_scientific_prerequisites.arrival_assumptions) {
    arrival.push_back(arrival_assumption_json(assumption));
  }
  Json couplings = Json::array();
  for (const auto coupling : value.target_and_arrival_scientific_prerequisites
                                 .permitted_target_couplings) {
    couplings.push_back(std::string(*token(coupling)));
  }
  Json roles = Json::array();
  for (const auto role : value.allowed_metric_support_roles) {
    roles.push_back(std::string(*token(role)));
  }
  Json evidence = Json::array();
  for (const auto& schema : value.allowed_family_evidence_schemas) {
    evidence.push_back(Json{{"schema_id", schema.schema_id},
                            {"schema_version", schema.schema_version},
                            {"maximum_canonical_body_bytes",
                             std::to_string(schema.maximum_canonical_body_bytes)}});
  }
  const auto& policies = value.scientific_construction_policy_schema;
  const auto enum_array = [](const auto& values) {
    Json array = Json::array();
    for (const auto item : values) {
      array.push_back(std::string(*token(item)));
    }
    return array;
  };
  Json supported_request = Json::array();
  for (const auto version : value.supported_build_request_versions) {
    supported_request.push_back(version);
  }
  Json supported_artifact = Json::array();
  for (const auto version : value.supported_artifact_versions) {
    supported_artifact.push_back(version);
  }
  Json report_versions = Json::array();
  for (const auto version : value.required_build_report_schema_versions) {
    report_versions.push_back(version);
  }
  Json required_method_counters = Json::array();
  for (const auto& counter : value.required_method_counters) {
    required_method_counters.push_back(
        Json{{"name", counter.name},
             {"minimum_used", to_string(counter.minimum_used)}});
  }
  Json analytic_families = Json::array();
  for (const auto& family : policies.registered_analytic_families) {
    analytic_families.push_back(Json{
        {"family_id", family.family_id},
        {"family_version", family.family_version},
        {"parameter_schema_id", family.parameter_schema_id},
        {"parameter_schema_version", family.parameter_schema_version},
        {"domain_schema_id", family.domain_schema_id},
        {"domain_schema_version", family.domain_schema_version}});
  }
  Json runtime_recipes = Json::array();
  for (const auto& recipe : policies.registered_runtime_recipes) {
    runtime_recipes.push_back(Json{
        {"recipe_id", recipe.recipe_id},
        {"recipe_version", recipe.recipe_version},
        {"parameter_schema_id", recipe.parameter_schema_id},
        {"parameter_schema_version", recipe.parameter_schema_version},
        {"state_codec_schema_id", recipe.state_codec_schema_id},
        {"state_codec_schema_version", recipe.state_codec_schema_version},
        {"mark_codec_schema_id", recipe.mark_codec_schema_id},
        {"mark_codec_schema_version", recipe.mark_codec_schema_version}});
  }
  return Result<Json>::success(Json{
      {"projection_version", value.projection_version},
      {"provider_id", value.provider.provider_id},
      {"provider_version", value.provider.provider_version},
      {"parameter_schema_version", value.parameter_schema_version},
      {"parameter_schema_digest", value.parameter_schema_digest.hex()},
      {"construction_method", std::string(*token(value.construction_method))},
      {"deployed_semantic_tag", std::string(*token(value.deployed_semantic_tag))},
      {"runtime_access_tag", std::string(*token(value.runtime_access_tag))},
      {"payload_tag", std::string(*token(value.payload_class.tag))},
      {"payload_version", value.payload_class.version},
      {"supported_build_request_versions", std::move(supported_request)},
      {"supported_artifact_versions", std::move(supported_artifact)},
      {"required_build_report_schema_versions", std::move(report_versions)},
      {"required_method_counters", std::move(required_method_counters)},
      {"optimizer_constraint_applicability",
       applicability_json(value.optimizer_constraint_applicability)},
      {"target_and_arrival_scientific_prerequisites",
       Json{{"minimum_deployed_targets",
             std::to_string(value.target_and_arrival_scientific_prerequisites
                                .minimum_deployed_targets)},
            {"maximum_deployed_targets",
             std::to_string(value.target_and_arrival_scientific_prerequisites
                                .maximum_deployed_targets)},
            {"permitted_target_couplings", std::move(couplings)},
            {"arrival_assumptions", std::move(arrival)}}},
      {"metric_clause_upper_envelope", std::move(manifest.value())},
      {"allowed_metric_support_roles", std::move(roles)},
      {"allowed_family_evidence_schema_ids", std::move(evidence)},
      {"scientific_construction_policy_schema",
       Json{{"schema_version", policies.schema_version},
            {"point_product_deployment", enum_array(policies.point_deployment)},
            {"coefficient_completion", enum_array(policies.coefficient_completion)},
            {"projection", enum_array(policies.projection)},
            {"recoding", enum_array(policies.recoding)},
            {"evidence_role_fulfillment", enum_array(policies.evidence_roles)},
            {"registered_analytic_families", std::move(analytic_families)},
            {"registered_runtime_recipes", std::move(runtime_recipes)}}}});
}

[[nodiscard]] Result<Json> provider_manifest_json(
    const SurrogateProviderManifestV1& value, const bool include_digest) {
  ProviderScientificContractProjectionV1 projection{
      1U,
      value.provider,
      value.parameter_schema_version,
      value.parameter_schema_digest,
      value.construction_method,
      value.deployed_semantic_tag,
      value.runtime_access_tag,
      value.payload_class,
      value.supported_build_request_versions,
      value.supported_artifact_versions,
      value.required_build_report_schema_versions,
      value.required_method_counters,
      value.optimizer_constraint_applicability,
      value.target_and_arrival_scientific_prerequisites,
      value.metric_clause_upper_envelope,
      value.allowed_metric_support_roles,
      value.allowed_family_evidence_schemas,
      value.scientific_construction_policy_schema};
  auto scientific = scientific_projection_json(projection);
  if (!scientific) {
    return Result<Json>::failure(scientific.error());
  }
  Json conformance_anchors = Json::array();
  for (const auto& anchor :
       value.family_evidence_conformance_report_anchors) {
    conformance_anchors.push_back(Json{
        {"family_evidence_schema_id", anchor.family_evidence_schema_id},
        {"family_evidence_schema_version",
         anchor.family_evidence_schema_version},
        {"report_schema_version", anchor.report_schema_version},
        {"report_id", typed_label_json(anchor.report_id)},
        {"report_digest", anchor.report_digest.hex()}});
  }
  Json object{{"manifest_schema_version", value.manifest_schema_version},
              {"provider_id", value.provider.provider_id},
              {"provider_version", value.provider.provider_version},
              {"default_selection", value.default_selection},
              {"source_build_identity", value.source_build_identity.hex()},
              {"scientific_contract", std::move(scientific.value())},
              {"family_evidence_conformance_report_anchors",
               std::move(conformance_anchors)},
              {"producer_mode", std::string(*token(value.producer_mode))}};
  if (value.local_executable.has_value()) {
    Json arguments = Json::array();
    for (const auto& argument : value.local_executable->fixed_argument_template) {
      arguments.push_back(argument);
    }
    object["local_executable"] =
        Json{{"executable_id", value.local_executable->executable_id},
             {"argv_grammar_version",
              value.local_executable->argv_grammar_version},
             {"fixed_argument_template", std::move(arguments)},
             {"externally_reconstructible_arrival",
              value.local_executable->externally_reconstructible_arrival}};
  } else {
    object["local_executable"] = nullptr;
  }
  object["transport_limits"] =
      Json{{"maximum_request_bytes",
            std::to_string(value.transport_limits.maximum_request_bytes)},
           {"maximum_result_bytes",
            std::to_string(value.transport_limits.maximum_result_bytes)}};
  if (include_digest) {
    object["manifest_digest"] = value.manifest_digest.hex();
  }
  return Result<Json>::success(std::move(object));
}

template <typename T>
[[nodiscard]] bool strict_sorted_unique(const std::vector<T>& values) {
  return std::adjacent_find(values.begin(), values.end(),
                            [](const T& left, const T& right) {
                              return !(left < right);
                            }) == values.end();
}

[[nodiscard]] bool strict_family_evidence_schema_key_order(
    const std::vector<FamilyEvidenceSchemaV1>& values) {
  return std::adjacent_find(
             values.begin(), values.end(),
             [](const FamilyEvidenceSchemaV1& left,
                const FamilyEvidenceSchemaV1& right) {
               return left.schema_id > right.schema_id ||
                      (left.schema_id == right.schema_id &&
                       left.schema_version >= right.schema_version);
             }) == values.end();
}

[[nodiscard]] bool strict_conformance_anchor_key_order(
    const std::vector<FamilyEvidenceConformanceReportAnchorV1>& values) {
  return std::adjacent_find(
             values.begin(), values.end(),
             [](const FamilyEvidenceConformanceReportAnchorV1& left,
                const FamilyEvidenceConformanceReportAnchorV1& right) {
               return left.family_evidence_schema_id >
                          right.family_evidence_schema_id ||
                      (left.family_evidence_schema_id ==
                           right.family_evidence_schema_id &&
                       left.family_evidence_schema_version >=
                           right.family_evidence_schema_version);
             }) == values.end();
}

template <typename Enum>
[[nodiscard]] bool strict_enum_sorted_unique(const std::vector<Enum>& values) {
  if (!std::all_of(values.begin(), values.end(),
                   [](const Enum value) { return valid_enum(value); })) {
    return false;
  }
  return std::adjacent_find(values.begin(), values.end(),
                            [](const Enum left, const Enum right) {
                              return static_cast<std::underlying_type_t<Enum>>(left) >=
                                     static_cast<std::underlying_type_t<Enum>>(right);
                            }) == values.end();
}

[[nodiscard]] bool valid_pair(const SchedulerConstraintPairV1& pair) {
  switch (pair.service_family) {
    case ServiceFamily::crossbar_matching:
      return pair.optimizer == OptimizerId::hungarian_exact;
    case ServiceFamily::nonoverlapping_intervals:
      return pair.optimizer == OptimizerId::weighted_interval_dp_exact;
    case ServiceFamily::node_exclusive_matching:
      return pair.optimizer == OptimizerId::edmonds_blossom_exact;
    case ServiceFamily::pairwise_conflicts:
      return pair.optimizer == OptimizerId::mwis_branch_memo_exact;
    case ServiceFamily::resource_packing:
      return pair.optimizer == OptimizerId::binary_packing_memo_exact;
  }
  return false;
}

[[nodiscard]] bool payload_access_compatible(
    const PayloadClassTagV1 payload, const SemanticTagV1 semantic,
    const RuntimeAccessTagV1 access) {
  const bool finite_law_semantic =
      semantic == SemanticTagV1::stationary_marked_edge ||
      semantic == SemanticTagV1::staged_opportunity_flux_law ||
      semantic == SemanticTagV1::temporal_one_slot_continuation ||
      semantic == SemanticTagV1::romr_residence_word_law ||
      semantic == SemanticTagV1::stopped_path_law ||
      semantic == SemanticTagV1::coupled_target_schedule_law;
  switch (payload) {
    case PayloadClassTagV1::three_bin_scalar_response_v1:
      return semantic == SemanticTagV1::scalar_backlog_response &&
             access == RuntimeAccessTagV1::finite_parameter_analytic_family;
    case PayloadClassTagV1::finite_parameter_analytic_data_v1:
      return finite_law_semantic &&
             (access == RuntimeAccessTagV1::analytic_transform ||
              access ==
                  RuntimeAccessTagV1::finite_parameter_analytic_family);
    case PayloadClassTagV1::finite_law_tables_v1:
      return finite_law_semantic &&
             (access == RuntimeAccessTagV1::finite_enumerated_row ||
              access == RuntimeAccessTagV1::sparse_row);
    case PayloadClassTagV1::registered_runtime_recipe_v1:
      return finite_law_semantic &&
             (access ==
                  RuntimeAccessTagV1::normalized_conditional_sampler ||
              access ==
                  RuntimeAccessTagV1::procedural_residence_generator);
    case PayloadClassTagV1::response_envelope_evidence_v1:
      return semantic == SemanticTagV1::response_envelope_law &&
             (access == RuntimeAccessTagV1::finite_parameter_analytic_family ||
              access == RuntimeAccessTagV1::analytic_transform);
    case PayloadClassTagV1::direct_metric_payload_v1:
      return semantic == SemanticTagV1::direct_metric_decoder &&
             access == RuntimeAccessTagV1::direct_metric_decoder;
    case PayloadClassTagV1::finite_prefix_constant_tail_response_v1:
      return semantic == SemanticTagV1::scalar_backlog_response &&
             access == RuntimeAccessTagV1::finite_parameter_analytic_family;
    case PayloadClassTagV1::empirical_finite_window_response_v1:
      return semantic == SemanticTagV1::scalar_backlog_response &&
             access == RuntimeAccessTagV1::finite_parameter_analytic_family;
  }
  return false;
}

[[nodiscard]] bool method_mode_compatible(const ConstructionMethodV1 method,
                                           const ProducerModeV1 mode) {
  if (method == ConstructionMethodV1::precomputed) {
    return mode == ProducerModeV1::inline_immediate;
  }
  if (mode == ProducerModeV1::inline_immediate) {
    return method == ConstructionMethodV1::closed_form;
  }
  return true;
}

[[nodiscard]] bool contains_version_one(
    const std::vector<std::uint32_t>& values) {
  return values.size() == 1U && values.front() == 1U;
}

[[nodiscard]] bool policy_schema_valid(
    const ScientificConstructionPolicySchemaV1& value) {
  if (!(value.schema_version == 1U && !value.point_deployment.empty() &&
         !value.coefficient_completion.empty() && !value.projection.empty() &&
         !value.recoding.empty() && !value.evidence_roles.empty() &&
         strict_enum_sorted_unique(value.point_deployment) &&
         strict_enum_sorted_unique(value.coefficient_completion) &&
         strict_enum_sorted_unique(value.projection) &&
         strict_enum_sorted_unique(value.recoding) &&
         strict_enum_sorted_unique(value.evidence_roles) &&
         strict_sorted_unique(value.registered_analytic_families) &&
         strict_sorted_unique(value.registered_runtime_recipes))) {
    return false;
  }
  for (const auto& family : value.registered_analytic_families) {
    if (!portable_identifier(family.family_id) || family.family_version == 0U ||
        !portable_identifier(family.parameter_schema_id) ||
        family.parameter_schema_version == 0U ||
        !portable_identifier(family.domain_schema_id) ||
        family.domain_schema_version == 0U) {
      return false;
    }
  }
  for (const auto& recipe : value.registered_runtime_recipes) {
    if (!portable_identifier(recipe.recipe_id) || recipe.recipe_version == 0U ||
        !portable_identifier(recipe.parameter_schema_id) ||
        recipe.parameter_schema_version == 0U ||
        !portable_identifier(recipe.state_codec_schema_id) ||
        recipe.state_codec_schema_version == 0U ||
        !portable_identifier(recipe.mark_codec_schema_id) ||
        recipe.mark_codec_schema_version == 0U) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool executable_declaration_valid(
    const LocalExecutableDeclarationV1& value) {
  if (!portable_identifier(value.executable_id) ||
      value.argv_grammar_version != 1U ||
      !value.externally_reconstructible_arrival ||
      value.fixed_argument_template !=
          std::vector<std::string>{"--request", "{request_path}",
                                   "--result", "{result_path}"}) {
    return false;
  }
  return true;
}

[[nodiscard]] bool role_is_used(const MetricSupportManifest& manifest,
                                const MetricSupportRoleV1 role) {
  for (const auto& clause : manifest.clauses()) {
    for (const auto& requirement : clause.required_roles) {
      if (requirement.role == role) {
        return true;
      }
    }
  }
  return false;
}

[[nodiscard]] bool is_cp09_observation_only_identity(
    const ProviderIdentityV1& provider) noexcept {
  return provider.provider_id == "full_orbit_framework_sampler" &&
         provider.provider_version == "1.4.0";
}

// Provider 1.4/result-v3 retains a C14 scalar-response ceiling solely so the
// released planner can describe the requested metric coordinates.  Its
// authoritative C15 role and policy sets are observation/evidence-only: an
// Observed terminal never grants a deployable payload or response.
[[nodiscard]] bool cp09_observation_only_authority_shape(
    const SurrogateProviderManifestV1& manifest) {
  return is_cp09_observation_only_identity(manifest.provider) &&
         manifest.parameter_schema_version == 4U &&
         manifest.payload_class ==
             PayloadClassV1{
                 PayloadClassTagV1::empirical_finite_window_response_v1,
                 1U} &&
         manifest.allowed_metric_support_roles ==
             std::vector<MetricSupportRoleV1>{
                 MetricSupportRoleV1::raw_response_bound_evidence,
                 MetricSupportRoleV1::statistical_evidence,
                 MetricSupportRoleV1::compression_evidence} &&
         manifest.allowed_family_evidence_schemas.size() == 1U &&
         manifest.allowed_family_evidence_schemas.front().schema_id ==
             "empirical_finite_window_response_v1" &&
         manifest.allowed_family_evidence_schemas.front().schema_version ==
             1U &&
         manifest.scientific_construction_policy_schema.point_deployment ==
             std::vector<PointDeploymentPolicyV1>{
                 PointDeploymentPolicyV1::not_applicable} &&
         manifest.scientific_construction_policy_schema
                 .coefficient_completion ==
             std::vector<CoefficientCompletionPolicyV1>{
                 CoefficientCompletionPolicyV1::not_applicable} &&
         manifest.scientific_construction_policy_schema.projection ==
             std::vector<ProjectionPolicyV1>{
                 ProjectionPolicyV1::not_applicable} &&
         manifest.scientific_construction_policy_schema.recoding ==
             std::vector<RecodingPolicyV1>{
                 RecodingPolicyV1::not_applicable} &&
         manifest.scientific_construction_policy_schema.evidence_roles ==
             std::vector<EvidenceRolePolicyV1>{
                 EvidenceRolePolicyV1::exact_manifest_roles};
}

[[nodiscard]] bool cp09_compatibility_policies(
    const SurrogateProviderManifestV1& manifest,
    const PreviewPoliciesV1& policies) {
  return cp09_observation_only_authority_shape(manifest) &&
         policies.point_deployment ==
             PointDeploymentPolicyV1::deploy_raw_point &&
         policies.coefficient_completion ==
             CoefficientCompletionPolicyV1::require_complete_raw_points &&
         policies.projection == ProjectionPolicyV1::not_applicable &&
         policies.recoding == RecodingPolicyV1::not_applicable &&
         policies.evidence_roles ==
             EvidenceRolePolicyV1::exact_manifest_roles;
}

[[nodiscard]] ProviderScientificContractProjectionV1 make_projection(
    const SurrogateProviderManifestV1& value) {
  return ProviderScientificContractProjectionV1{
      1U,
      value.provider,
      value.parameter_schema_version,
      value.parameter_schema_digest,
      value.construction_method,
      value.deployed_semantic_tag,
      value.runtime_access_tag,
      value.payload_class,
      value.supported_build_request_versions,
      value.supported_artifact_versions,
      value.required_build_report_schema_versions,
      value.required_method_counters,
      value.optimizer_constraint_applicability,
      value.target_and_arrival_scientific_prerequisites,
      value.metric_clause_upper_envelope,
      value.allowed_metric_support_roles,
      value.allowed_family_evidence_schemas,
      value.scientific_construction_policy_schema};
}

[[nodiscard]] std::optional<std::string_view> token(
    const PortableArrivalLawSchema value) {
  switch (value) {
    case PortableArrivalLawSchema::deterministic_trace_v1:
      return "deterministic_trace_v1";
    case PortableArrivalLawSchema::periodic_global_phase_v1:
      return "periodic_global_phase_v1";
    case PortableArrivalLawSchema::periodic_source_delays_v1:
      return "periodic_source_delays_v1";
    case PortableArrivalLawSchema::independent_marked_renewal_v1:
      return "independent_marked_renewal_v1";
    case PortableArrivalLawSchema::independent_private_markov_renewal_v1:
      return "independent_private_markov_renewal_v1";
    case PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1:
      return "shared_joint_round_markov_renewal_v1";
    case PortableArrivalLawSchema::iid_independent_bernoulli_v1:
      return "iid_independent_bernoulli_v1";
    case PortableArrivalLawSchema::iid_count_table_v1:
      return "iid_count_table_v1";
    case PortableArrivalLawSchema::iid_independent_poisson_v1:
      return "iid_independent_poisson_v1";
    case PortableArrivalLawSchema::iid_mixed_poisson_v1:
      return "iid_mixed_poisson_v1";
  }
  return std::nullopt;
}

[[nodiscard]] std::optional<std::string_view> token(const ArrivalFamily value) {
  switch (value) {
    case ArrivalFamily::deterministic_trace: return "deterministic_trace";
    case ArrivalFamily::periodic_global_phase: return "periodic_global_phase";
    case ArrivalFamily::periodic_source_delays: return "periodic_source_delays";
    case ArrivalFamily::independent_marked_renewal: return "independent_marked_renewal";
    case ArrivalFamily::independent_private_markov_renewal: return "independent_private_markov_renewal";
    case ArrivalFamily::shared_joint_round_markov_renewal: return "shared_joint_round_markov_renewal";
    case ArrivalFamily::iid_independent_bernoulli: return "iid_independent_bernoulli";
    case ArrivalFamily::iid_count_table: return "iid_count_table";
    case ArrivalFamily::iid_independent_poisson: return "iid_independent_poisson";
    case ArrivalFamily::iid_mixed_poisson: return "iid_mixed_poisson";
  }
  return std::nullopt;
}

[[nodiscard]] std::string capability_availability_token(
    const CapabilityAvailability value) {
  return value == CapabilityAvailability::available ? "available" :
         value == CapabilityAvailability::unavailable ? "unavailable" :
                                                        "unknown";
}

[[nodiscard]] std::string access_provision_token(const AccessProvision value) {
  switch (value) {
    case AccessProvision::portable_only: return "portable_only";
    case AccessProvision::process_local_only: return "process_local_only";
    case AccessProvision::portable_and_process_local: return "portable_and_process_local";
  }
  return "unknown";
}

[[nodiscard]] std::string phase_argument_token(
    const PhaseArgumentRequirement value) {
  switch (value) {
    case PhaseArgumentRequirement::phase_free: return "phase_free";
    case PhaseArgumentRequirement::explicit_phase_required: return "explicit_phase_required";
  }
  return "unknown";
}

[[nodiscard]] Json argument_domain_json(const ExactArgumentDomain& value) {
  return Json{{"lower", rational_json(value.lower)},
              {"upper", rational_json(value.upper)},
              {"lower_inclusive", value.lower_inclusive},
              {"upper_inclusive", value.upper_inclusive}};
}

[[nodiscard]] Json transform_capability_json(const TransformCapability& value) {
  return Json{{"kind", std::string(*token(value.kind))},
              {"scope", std::string(*token(value.scope))},
              {"domain", argument_domain_json(value.domain)},
              {"phase_requirement", phase_argument_token(value.phase_requirement)},
              {"provision", access_provision_token(value.provision)}};
}

[[nodiscard]] Json moment_capability_json(const MomentCapability& value) {
  return Json{{"maximum_order", value.maximum_order.has_value()
                                   ? natural_json(*value.maximum_order)
                                   : Json(nullptr)},
              {"joint", value.joint},
              {"conditioned_on_phase", value.conditioned_on_phase},
              {"provision", access_provision_token(value.provision)}};
}

[[nodiscard]] Json arrival_capabilities_json(const ArrivalCapabilities& value) {
  Json object{
      {"version", value.version},
      {"exact_positive_support", capability_availability_token(value.exact_positive_support)},
      {"sequential_normalized_sampler", capability_availability_token(value.sequential_normalized_sampler)},
      {"finite_enumerated_predictive_phase", capability_availability_token(value.finite_enumerated_predictive_phase)},
      {"finite_enumerated_transition_row", capability_availability_token(value.finite_enumerated_transition_row)}};
  object["analytic_transform"] = value.analytic_transform.has_value()
                                      ? transform_capability_json(*value.analytic_transform)
                                      : Json(nullptr);
  object["analytic_moments"] = value.analytic_moments.has_value()
                                   ? moment_capability_json(*value.analytic_moments)
                                   : Json(nullptr);
  switch (value.stationary_phase_law) {
    case StationaryPhaseLawStatus::unavailable: object["stationary_phase_law"] = "unavailable"; break;
    case StationaryPhaseLawStatus::supplied: object["stationary_phase_law"] = "supplied"; break;
    case StationaryPhaseLawStatus::selected: object["stationary_phase_law"] = "selected"; break;
    case StationaryPhaseLawStatus::proved_unique: object["stationary_phase_law"] = "proved_unique"; break;
    default: object["stationary_phase_law"] = "unknown"; break;
  }
  if (value.exact_iid_joint_vector.has_value()) {
    object["exact_iid_joint_vector"] = Json{
        {"finite_support", value.exact_iid_joint_vector->finite_support},
        {"provision", access_provision_token(value.exact_iid_joint_vector->provision)}};
  } else {
    object["exact_iid_joint_vector"] = nullptr;
  }
  object["exact_joint_moments"] = value.exact_joint_moments.has_value()
                                       ? moment_capability_json(*value.exact_joint_moments)
                                       : Json(nullptr);
  object["exact_coordinate_moments"] = value.exact_coordinate_moments.has_value()
                                            ? moment_capability_json(*value.exact_coordinate_moments)
                                            : Json(nullptr);
  object["exact_covariance"] = capability_availability_token(value.exact_covariance);
  object["exact_cross_moments"] = capability_availability_token(value.exact_cross_moments);
  object["exact_joint_distribution"] = value.exact_joint_distribution.has_value()
                                            ? transform_capability_json(*value.exact_joint_distribution)
                                            : Json(nullptr);
  object["exact_coordinate_distributions"] = value.exact_coordinate_distributions.has_value()
                                                  ? transform_capability_json(*value.exact_coordinate_distributions)
                                                  : Json(nullptr);
  if (value.adjacent_batch_replay.has_value()) {
    const auto& replay = *value.adjacent_batch_replay;
    object["adjacent_batch_replay"] = Json{
        {"explicit_initial_state", replay.explicit_initial_state},
        {"explicit_phase", replay.explicit_phase},
        {"normalized_initial_law", replay.normalized_initial_law},
        {"named_stationary_initialization", replay.named_stationary_initialization},
        {"provision", access_provision_token(replay.provision)}};
  } else {
    object["adjacent_batch_replay"] = nullptr;
  }
  if (value.unit_cube_transform.has_value()) {
    const auto& cube = *value.unit_cube_transform;
    std::string boundary = "unknown";
    if (cube.boundary == UnitCubeBoundary::left_closed_right_open) {
      boundary = "left_closed_right_open";
    }
    std::string inverse = "unknown";
    if (cube.inverse_cdf ==
        InverseCdfConvention::first_cumulative_mass_strictly_greater) {
      inverse = "first_cumulative_mass_strictly_greater";
    }
    object["unit_cube_transform"] = Json{
        {"dimension", natural_json(cube.dimension)},
        {"boundary", boundary},
        {"inverse_cdf", inverse},
        {"phase_requirement", phase_argument_token(cube.phase_requirement)},
        {"provision", access_provision_token(cube.provision)}};
  } else {
    object["unit_cube_transform"] = nullptr;
  }
  if (value.exact_factorized_iid_generator.has_value()) {
    object["exact_factorized_iid_generator"] = Json{
        {"provision", access_provision_token(
                          value.exact_factorized_iid_generator->provision)}};
  }
  if (value.exact_portable_iid_recipe.has_value()) {
    object["exact_portable_iid_recipe"] = Json{
        {"provision", access_provision_token(
                          value.exact_portable_iid_recipe->provision)}};
  }
  return object;
}

[[nodiscard]] Json arrival_binding_json(const ArrivalBinding& value) {
  return Json{{"family", std::string(*token(value.family))},
              {"timing", std::string(*token(value.timing))},
              {"queue_cardinality", std::to_string(value.queue_cardinality)},
              {"law_digest", value.law_digest.value().hex()},
              {"catalog_digest", value.catalog_digest.value().hex()}};
}

[[nodiscard]] Json moment_data_json(const ExactMomentDatum& value) {
  Json coordinates = Json::array();
  for (const auto coordinate : value.coordinates) {
    coordinates.push_back(std::to_string(coordinate.ordinal()));
  }
  return Json{{"coordinates", std::move(coordinates)},
              {"order", natural_json(value.order)},
              {"value", rational_json(value.value)}};
}

[[nodiscard]] Json transform_descriptor_json(
    const PortableTransformDescriptor& value) {
  return Json{{"capability", transform_capability_json(value.capability)},
              {"codec_version", value.codec_version},
              {"canonical_parameters", bytes_to_hex(value.canonical_parameters)}};
}

[[nodiscard]] Json builder_arrival_view_json(const BuilderArrivalView& value) {
  Json support = Json::array();
  for (const auto byte : value.positive_support().bytes()) {
    support.push_back(byte != 0U);
  }
  const auto& law = value.configured_law();
  Json object{
      {"version", value.version()},
      {"binding", arrival_binding_json(value.binding())},
      {"view_digest", value.digest().value().hex()},
      {"capabilities", arrival_capabilities_json(value.capabilities())},
      {"positive_support", std::move(support)},
      {"configured_law",
       Json{{"schema", std::string(*token(law.schema))},
            {"version", law.version},
            {"canonical_data", bytes_to_hex(law.canonical_data)},
            {"payload_digest", law.payload_digest.hex()}}}};
  if (value.iid_joint_table().has_value()) {
    Json table = Json::array();
    for (const auto& atom : *value.iid_joint_table()) {
      Json counts = Json::array();
      for (const auto& count : atom.dense_counts) {
        counts.push_back(natural_json(count));
      }
      table.push_back(Json{{"dense_counts", std::move(counts)},
                           {"probability", rational_json(atom.probability)}});
    }
    object["iid_joint_table"] = std::move(table);
  } else {
    object["iid_joint_table"] = nullptr;
  }
  const auto encode_moments = [](const auto& optional_values) {
    if (!optional_values.has_value()) {
      return Json(nullptr);
    }
    Json values = Json::array();
    for (const auto& datum : *optional_values) {
      values.push_back(moment_data_json(datum));
    }
    return values;
  };
  object["moments"] = encode_moments(value.moments());
  object["covariances"] = encode_moments(value.covariances());
  object["analytic_transform"] = value.analytic_transform().has_value()
                                      ? transform_descriptor_json(*value.analytic_transform())
                                      : Json(nullptr);
  object["joint_distribution"] = value.joint_distribution().has_value()
                                      ? transform_descriptor_json(*value.joint_distribution())
                                      : Json(nullptr);
  object["coordinate_distributions"] = value.coordinate_distributions().has_value()
                                            ? transform_descriptor_json(*value.coordinate_distributions())
                                            : Json(nullptr);
  if (value.replay_codec().has_value()) {
    const auto& replay = *value.replay_codec();
    object["replay_codec"] = Json{
        {"codec_version", replay.codec_version},
        {"requires_complete_initial_state", replay.requires_complete_initial_state},
        {"preserves_adjacent_temporal_order", replay.preserves_adjacent_temporal_order},
        {"canonical_parameters", bytes_to_hex(replay.canonical_parameters)}};
  } else {
    object["replay_codec"] = nullptr;
  }
  if (value.unit_cube().has_value()) {
    const auto& cube = *value.unit_cube();
    Json order = Json::array();
    for (const auto& coordinate : cube.coordinate_order) {
      order.push_back(Json{{"ordinal", std::to_string(coordinate.ordinal)},
                           {"role", coordinate.role}});
    }
    object["unit_cube"] = Json{
        {"capability", Json{{"dimension", natural_json(cube.capability.dimension)},
                             {"boundary", "left_closed_right_open"},
                             {"inverse_cdf", "first_cumulative_mass_strictly_greater"},
                             {"phase_requirement", phase_argument_token(cube.capability.phase_requirement)},
                             {"provision", access_provision_token(cube.capability.provision)}}},
        {"coordinate_order", std::move(order)},
        {"codec_version", cube.codec_version},
        {"canonical_parameters", bytes_to_hex(cube.canonical_parameters)}};
  } else {
    object["unit_cube"] = nullptr;
  }
  if (value.finite_phase().has_value()) {
    Json states = Json::array();
    for (const auto& state : value.finite_phase()->canonical_states) {
      states.push_back(bytes_to_hex(std::as_bytes(std::span(state))));
    }
    object["finite_phase"] = Json{
        {"codec_version", value.finite_phase()->codec_version},
        {"canonical_states", std::move(states)},
        {"row_clock_semantics",
         value.finite_phase()->row_clock_semantics ==
                 ArrivalRowClockSemanticsV1::
                     finite_phase_time_homogeneous
             ? "finite_phase_time_homogeneous"
             : "authored_slot_conditioned"}};
  } else {
    object["finite_phase"] = nullptr;
  }
  object["transition_rows"] = value.transition_rows().has_value()
      ? Json{{"codec_version", value.transition_rows()->codec_version},
             {"canonical_rows", bytes_to_hex(value.transition_rows()->canonical_rows)}}
      : Json(nullptr);
  if (value.stationary_phase_law().has_value()) {
    const auto& law_value = *value.stationary_phase_law();
    Json states = Json::array();
    for (const auto& state : law_value.canonical_states) {
      states.push_back(bytes_to_hex(std::as_bytes(std::span(state))));
    }
    Json probabilities = Json::array();
    for (const auto& probability : law_value.probabilities.normalized_weights()) {
      probabilities.push_back(rational_json(probability));
    }
    object["stationary_phase_law"] = Json{
        {"law_id", law_value.law_id},
        {"codec_version", law_value.codec_version},
        {"canonical_states", std::move(states)},
        {"probabilities", std::move(probabilities)}};
  } else {
    object["stationary_phase_law"] = nullptr;
  }
  return object;
}

[[nodiscard]] Json target_selection_json(const TargetSelection& value) {
  Json targets = Json::array();
  for (const auto& target : value.ordered_targets) {
    targets.push_back(strong_id_json(target));
  }
  return Json{{"schema_version", value.schema_version},
              {"ordered_targets", std::move(targets)},
              {"construction_group_binding",
               strong_id_json(value.construction_group_binding)}};
}

[[nodiscard]] Json constraint_geometry_json(
    const PortableConstraintGeometryV1& value) {
  return std::visit(
      [](const auto& geometry) -> Json {
        using Geometry = std::decay_t<decltype(geometry)>;
        if constexpr (std::is_same_v<Geometry,
                                     PortableCrossbarConstraintV1>) {
          Json inputs = Json::array();
          Json outputs = Json::array();
          Json edges = Json::array();
          for (const auto& item : geometry.inputs) inputs.push_back(strong_id_json(item));
          for (const auto& item : geometry.outputs) outputs.push_back(strong_id_json(item));
          for (const auto& edge : geometry.edges) {
            edges.push_back(Json{{"queue", strong_id_json(edge.queue)},
                                 {"input", strong_id_json(edge.input)},
                                 {"output", strong_id_json(edge.output)}});
          }
          return Json{{"tag", "crossbar_matching"},
                      {"inputs", std::move(inputs)},
                      {"outputs", std::move(outputs)},
                      {"edges", std::move(edges)}};
        } else if constexpr (std::is_same_v<Geometry,
                                            PortableIntervalConstraintV1>) {
          Json intervals = Json::array();
          for (const auto& interval : geometry.intervals) {
            intervals.push_back(Json{{"queue", strong_id_json(interval.queue)},
                                     {"left", rational_json(interval.left)},
                                     {"right", rational_json(interval.right)}});
          }
          return Json{{"tag", "nonoverlapping_intervals"},
                      {"intervals", std::move(intervals)}};
        } else if constexpr (std::is_same_v<Geometry,
                                            PortableNodeExclusiveConstraintV1>) {
          Json vertices = Json::array();
          Json links = Json::array();
          for (const auto& vertex : geometry.vertices) vertices.push_back(strong_id_json(vertex));
          for (const auto& link : geometry.links) {
            links.push_back(Json{{"queue", strong_id_json(link.queue)},
                                 {"u", strong_id_json(link.u)},
                                 {"v", strong_id_json(link.v)}});
          }
          return Json{{"tag", "node_exclusive_matching"},
                      {"vertices", std::move(vertices)},
                      {"links", std::move(links)}};
        } else if constexpr (std::is_same_v<Geometry,
                                            PortableConflictConstraintV1>) {
          Json queues = Json::array();
          Json conflicts = Json::array();
          for (const auto& queue : geometry.queues) queues.push_back(strong_id_json(queue));
          for (const auto& pair : geometry.conflicts) {
            conflicts.push_back(Json{{"first", strong_id_json(pair.first)},
                                     {"second", strong_id_json(pair.second)}});
          }
          return Json{{"tag", "pairwise_conflicts"},
                      {"queues", std::move(queues)},
                      {"conflicts", std::move(conflicts)}};
        } else {
          Json resources = Json::array();
          Json capacity = Json::array();
          Json demands = Json::array();
          for (const auto& resource : geometry.resources) resources.push_back(strong_id_json(resource));
          for (const auto& amount : geometry.capacity) capacity.push_back(natural_json(amount));
          for (const auto& row : geometry.demands) {
            Json demand = Json::array();
            for (const auto& amount : row.demand) demand.push_back(natural_json(amount));
            demands.push_back(Json{{"queue", strong_id_json(row.queue)},
                                   {"demand", std::move(demand)}});
          }
          return Json{{"tag", "resource_packing"},
                      {"resources", std::move(resources)},
                      {"capacity", std::move(capacity)},
                      {"demands", std::move(demands)}};
        }
      },
      value);
}

[[nodiscard]] std::string initial_state_token(
    const PortableInitialArrivalStateKindV1 value) {
  switch (value) {
    case PortableInitialArrivalStateKindV1::trace_origin: return "trace_origin";
    case PortableInitialArrivalStateKindV1::global_periodic_origin: return "global_periodic_origin";
    case PortableInitialArrivalStateKindV1::source_delay_origin: return "source_delay_origin";
    case PortableInitialArrivalStateKindV1::renewal_origin: return "renewal_origin";
    case PortableInitialArrivalStateKindV1::private_markov_states: return "private_markov_states";
    case PortableInitialArrivalStateKindV1::shared_round_state: return "shared_round_state";
  }
  return "unknown";
}

[[nodiscard]] Json initial_law_json(
    const std::optional<PortableInitialPredictiveLawV1>& value) {
  if (!value.has_value()) {
    return nullptr;
  }
  Json atoms = Json::array();
  for (const auto& atom : value->atoms) {
    Json backlog = Json::array();
    for (const auto& level : atom.dense_backlog) backlog.push_back(natural_json(level));
    Json coordinates = Json::array();
    for (const auto& coordinate : atom.arrival_state.coordinates) {
      coordinates.push_back(Json{{"source_id", coordinate.source_id},
                                 {"state", coordinate.state}});
    }
    atoms.push_back(Json{
        {"probability", rational_json(atom.probability)},
        {"dense_backlog", std::move(backlog)},
        {"arrival_state",
         Json{{"kind", initial_state_token(atom.arrival_state.kind)},
              {"coordinates", std::move(coordinates)}}},
        {"controller_state", bytes_to_hex(atom.canonical_controller_state)},
        {"static_context", bytes_to_hex(atom.canonical_static_context)},
        {"surrogate_initial", bytes_to_hex(atom.canonical_surrogate_initial)}});
  }
  return Json{{"schema_version", value->schema_version},
              {"atoms", std::move(atoms)}};
}

[[nodiscard]] Json analysis_selection_json(
    const PortableAnalysisSelectionV1& value) {
  return std::visit(
      [](const auto& selection) -> Json {
        using Selection = std::decay_t<decltype(selection)>;
        if constexpr (std::is_same_v<Selection,
                                     PortableTransientSelectionV1>) {
          return Json{{"tag", "transient"}};
        } else if constexpr (std::is_same_v<
                                 Selection,
                                 PortableStationaryUniqueSelectionV1>) {
          return Json{{"tag", "stationary_unique"}};
        } else if constexpr (std::is_same_v<
                                 Selection,
                                 PortableStationaryClassSelectionV1>) {
          return Json{{"tag", "stationary_class"},
                      {"class_id", typed_label_json(selection.class_id)}};
        } else if constexpr (std::is_same_v<
                                 Selection,
                                 PortableStationaryMixtureSelectionV1>) {
          Json components = Json::array();
          for (const auto& component : selection.components) {
            components.push_back(
                Json{{"class_id", typed_label_json(component.class_id)},
                     {"probability", rational_json(component.probability)}});
          }
          return Json{{"tag", "stationary_mixture"},
                      {"components", std::move(components)}};
        } else if constexpr (std::is_same_v<
                                 Selection,
                                 PortableFixedPointUniqueSelectionV1>) {
          return Json{{"tag", "fixed_point_unique"}};
        } else {
          return Json{{"tag", "fixed_point_id"},
                      {"solution_id", typed_label_json(selection.solution_id)}};
        }
      },
      value);
}

[[nodiscard]] Result<Json> framework_problem_view_json(
    const FrameworkProblemView& value, const bool include_digest) {
  Json queues = Json::array();
  for (const auto& entry : value.queues()) {
    queues.push_back(Json{{"queue_id", strong_id_json(entry.queue_id)},
                          {"dense_index", std::to_string(entry.dense_index)},
                          {"maxweight_multiplier", rational_json(entry.maxweight_multiplier)},
                          {"selected_target", entry.selected_target},
                          {"individually_serviceable", entry.individually_serviceable},
                          {"positive_arrival_support", entry.positive_arrival_support}});
  }
  Json priority = Json::array();
  for (const auto& queue : value.priority_order()) {
    priority.push_back(strong_id_json(queue));
  }
  const auto& fingerprints = value.fingerprints();
  const auto& applicability = value.applicability_key();
  const auto& units = value.units_and_encodings();
  Json object{
      {"schema_version", value.schema_version()},
      {"physical_model_fingerprint", fingerprints.authored_inputs.model.hex()},
      {"analysis_fingerprint", fingerprints.authored_inputs.analysis.hex()},
      {"combined_input_fingerprint", fingerprints.authored_inputs.combined.hex()},
      {"resolved_instance_fingerprint", fingerprints.resolved_instance.hex()},
      {"constraint_fingerprint", fingerprints.constraint.hex()},
      {"target_selection_fingerprint", fingerprints.target_selection.hex()},
      {"tie_timing_fingerprint", fingerprints.tie_and_timing.hex()},
      {"compiled_arrival_fingerprint", fingerprints.compiled_arrival.hex()},
      {"ordered_queue_catalog", std::move(queues)},
      {"target_selection", target_selection_json(value.target_selection())},
      {"optimizer_constraint_applicability_key",
       Json{{"service_family", std::string(*token(applicability.service_family))},
            {"optimizer", std::string(*token(applicability.optimizer))}}},
      {"constraint_geometry", constraint_geometry_json(value.constraint_geometry())},
      {"priority_order", std::move(priority)},
      {"timing_convention", std::string(*token(value.timing()))},
      {"configured_arrival", builder_arrival_view_json(value.configured_arrival())},
      {"analysis_selection", analysis_selection_json(value.analysis_selection())},
      {"initial_predictive_state_law", initial_law_json(value.initial_predictive_law())},
      {"units_and_encodings",
       Json{{"schema_version", units.schema_version},
            {"backlog_unit", units.backlog_unit},
            {"service_unit", units.service_unit},
            {"time_unit", units.time_unit},
            {"integer_encoding", "canonical_decimal_string"},
            {"scientific_scalar_encoding", "rational_or_binary64_bits"},
            {"unit_packet_service", units.unit_packet_service},
            {"queue_capacity", units.queue_capacity.has_value()
                                   ? natural_json(*units.queue_capacity)
                                   : Json(nullptr)}}}};
  if (include_digest) {
    object["canonical_digest"] = value.canonical_digest().value().hex();
  }
  return Result<Json>::success(std::move(object));
}

[[nodiscard]] Json physical_trajectory_projection_json(
    const FrameworkProblemView& value) {
  Json queues = Json::array();
  for (const auto& entry : value.queues()) {
    queues.push_back(
        Json{{"queue_id", strong_id_json(entry.queue_id)},
             {"dense_index", std::to_string(entry.dense_index)},
             {"maxweight_multiplier",
              rational_json(entry.maxweight_multiplier)},
             {"selected_target", entry.selected_target},
             {"individually_serviceable", entry.individually_serviceable},
             {"positive_arrival_support", entry.positive_arrival_support}});
  }
  Json targets = Json::array();
  for (const auto& target : value.target_selection().ordered_targets) {
    targets.push_back(strong_id_json(target));
  }
  Json priority = Json::array();
  for (const auto& queue : value.priority_order()) {
    priority.push_back(strong_id_json(queue));
  }
  const auto& applicability = value.applicability_key();
  const auto& units = value.units_and_encodings();
  return Json{
      {"trajectory_schema_version", 1U},
      {"ordered_queue_catalog", std::move(queues)},
      {"ordered_targets", std::move(targets)},
      {"optimizer_constraint_applicability_key",
       Json{{"service_family",
             std::string(*token(applicability.service_family))},
            {"optimizer", std::string(*token(applicability.optimizer))}}},
      {"constraint_geometry",
       constraint_geometry_json(value.constraint_geometry())},
      {"priority_order", std::move(priority)},
      {"timing_convention", std::string(*token(value.timing()))},
      {"configured_arrival",
       builder_arrival_view_json(value.configured_arrival())},
      {"initial_predictive_state_law",
       initial_law_json(value.initial_predictive_law())},
      {"units_and_encodings",
       Json{{"schema_version", units.schema_version},
            {"backlog_unit", units.backlog_unit},
            {"service_unit", units.service_unit},
            {"time_unit", units.time_unit},
            {"integer_encoding", "canonical_decimal_string"},
            {"scientific_scalar_encoding", "rational_or_binary64_bits"},
            {"unit_packet_service", units.unit_packet_service},
            {"queue_capacity", units.queue_capacity.has_value()
                                   ? natural_json(*units.queue_capacity)
                                   : Json(nullptr)}}}};
}

[[nodiscard]] Result<Digest256> hash_json_versioned(
    const std::string_view domain, const Json& value) {
  const auto json = json_bytes(value);
  std::vector<std::byte> framed{
      std::byte{0}, std::byte{0}, std::byte{0}, std::byte{1}};
  framed.insert(framed.end(), json.begin(), json.end());
  return sha256_domain_separated(domain, framed);
}

[[nodiscard]] Result<Digest256> hash_view_without_digest(
    const FrameworkProblemView& value) {
  auto encoded = framework_problem_view_json(value, false);
  if (!encoded) return Result<Digest256>::failure(encoded.error());
  return hash_json_versioned("mwperf.framework_problem_view", encoded.value());
}

[[nodiscard]] PortableConstraintGeometryV1 project_constraint_geometry(
    const ConstraintDescriptor& descriptor, const QueueCatalog& queues) {
  return std::visit(
      [&queues](const auto& geometry) -> PortableConstraintGeometryV1 {
        using Geometry = std::decay_t<decltype(geometry)>;
        if constexpr (std::is_same_v<Geometry, ResolvedCrossbarConstraint>) {
          PortableCrossbarConstraintV1 result;
          for (const auto& input : geometry.inputs) result.inputs.push_back(input.id);
          for (const auto& output : geometry.outputs) result.outputs.push_back(output.id);
          for (const auto& edge : geometry.edges) {
            result.edges.push_back(PortableCrossbarEdgeV1{
                queues.queue_id(edge.queue), geometry.inputs.at(edge.input.ordinal()).id,
                geometry.outputs.at(edge.output.ordinal()).id});
          }
          return result;
        } else if constexpr (std::is_same_v<Geometry, ResolvedIntervalConstraint>) {
          PortableIntervalConstraintV1 result;
          for (const auto& interval : geometry.intervals) {
            result.intervals.push_back(PortableIntervalV1{
                queues.queue_id(interval.queue), interval.left, interval.right});
          }
          return result;
        } else if constexpr (std::is_same_v<Geometry, ResolvedNodeExclusiveConstraint>) {
          PortableNodeExclusiveConstraintV1 result;
          for (const auto& vertex : geometry.vertices) result.vertices.push_back(vertex.id);
          for (const auto& link : geometry.links) {
            result.links.push_back(PortableNodeExclusiveLinkV1{
                queues.queue_id(link.queue), geometry.vertices.at(link.u.ordinal()).id,
                geometry.vertices.at(link.v.ordinal()).id});
          }
          return result;
        } else if constexpr (std::is_same_v<Geometry, ResolvedConflictConstraint>) {
          PortableConflictConstraintV1 result;
          for (const auto& entry : queues.entries()) result.queues.push_back(entry.id);
          for (const auto& pair : geometry.conflicts) {
            result.conflicts.push_back(PortableConflictPairV1{
                queues.queue_id(pair.first), queues.queue_id(pair.second)});
          }
          return result;
        } else {
          PortablePackingConstraintV1 result;
          for (const auto& resource : geometry.resources) result.resources.push_back(resource.id);
          result.capacity = geometry.capacity;
          for (const auto& row : geometry.demands) {
            result.demands.push_back(
                PortablePackingDemandV1{queues.queue_id(row.queue), row.demand});
          }
          return result;
        }
      },
      descriptor.value());
}

[[nodiscard]] PortableInitialArrivalStateV1 project_initial_state(
    const ArrivalInitialState& value) {
  return std::visit(
      [](const auto& state) -> PortableInitialArrivalStateV1 {
        using State = std::decay_t<decltype(state)>;
        if constexpr (std::is_same_v<State, TraceOrigin>) {
          return {PortableInitialArrivalStateKindV1::trace_origin, {}};
        } else if constexpr (std::is_same_v<State, GlobalPeriodicOrigin>) {
          return {PortableInitialArrivalStateKindV1::global_periodic_origin, {}};
        } else if constexpr (std::is_same_v<State, SourceDelayOrigin>) {
          return {PortableInitialArrivalStateKindV1::source_delay_origin, {}};
        } else if constexpr (std::is_same_v<State, RenewalOrigin>) {
          return {PortableInitialArrivalStateKindV1::renewal_origin, {}};
        } else if constexpr (std::is_same_v<State, PrivateMarkovStates>) {
          PortableInitialArrivalStateV1 result{
              PortableInitialArrivalStateKindV1::private_markov_states, {}};
          for (const auto& coordinate : state.states) {
            result.coordinates.push_back(
                PortableInitialArrivalCoordinateV1{coordinate.source_id,
                                                    coordinate.state});
          }
          return result;
        } else {
          return {PortableInitialArrivalStateKindV1::shared_round_state,
                  {PortableInitialArrivalCoordinateV1{"", state.state}}};
        }
      },
      value);
}

[[nodiscard]] Result<Json> source_node_json(const SourceNode& node) {
  switch (node.kind()) {
    case SourceNodeKind::null_value:
      return Result<Json>::success(nullptr);
    case SourceNodeKind::boolean:
      return Result<Json>::success(*node.boolean_value());
    case SourceNodeKind::number: {
      auto parsed = parse_decimal_rational(NumericLexeme(*node.number_lexeme()));
      if (!parsed) return Result<Json>::failure(parsed.error());
      return Result<Json>::success(rational_json(parsed.value()));
    }
    case SourceNodeKind::string:
      return Result<Json>::success(*node.string_value());
    case SourceNodeKind::array: {
      Json result = Json::array();
      for (const auto& item : node.array_items()) {
        auto encoded = source_node_json(item);
        if (!encoded) return Result<Json>::failure(encoded.error());
        result.push_back(std::move(encoded.value()));
      }
      return Result<Json>::success(std::move(result));
    }
    case SourceNodeKind::object: {
      std::vector<const SourceObjectMember*> members;
      for (const auto& member : node.object_members()) members.push_back(&member);
      std::sort(members.begin(), members.end(), [](const auto* left, const auto* right) {
        return left->key < right->key;
      });
      Json result = Json::object();
      for (const auto* member : members) {
        auto encoded = source_node_json(member->value);
        if (!encoded) return Result<Json>::failure(encoded.error());
        result[member->key] = std::move(encoded.value());
      }
      return Result<Json>::success(std::move(result));
    }
  }
  return Result<Json>::failure(error("c15.invalid_source_node",
                                     "unknown source-node alternative"));
}

[[nodiscard]] Result<std::vector<std::byte>> source_node_bytes(
    const SourceNode& node) {
  auto encoded = source_node_json(node);
  if (!encoded) return Result<std::vector<std::byte>>::failure(encoded.error());
  return Result<std::vector<std::byte>>::success(json_bytes(encoded.value()));
}

[[nodiscard]] Result<PortableAnalysisSelectionV1> project_analysis_selection(
    const SelectionSpec& value) {
  return std::visit(
      [](const auto& selection) -> Result<PortableAnalysisSelectionV1> {
        using Selection = std::decay_t<decltype(selection)>;
        if constexpr (std::is_same_v<Selection, TransientSelection>) {
          return Result<PortableAnalysisSelectionV1>::success(
              PortableTransientSelectionV1{});
        } else if constexpr (std::is_same_v<Selection,
                                            StationaryUniqueSelection>) {
          return Result<PortableAnalysisSelectionV1>::success(
              PortableStationaryUniqueSelectionV1{});
        } else if constexpr (std::is_same_v<Selection,
                                            StationaryClassSelection>) {
          return Result<PortableAnalysisSelectionV1>::success(
              PortableStationaryClassSelectionV1{selection.class_id});
        } else if constexpr (std::is_same_v<Selection,
                                            StationaryMixtureSelection>) {
          std::set<TypedLabel> unique_classes;
          std::vector<AuthoredProbability> probabilities;
          probabilities.reserve(selection.components.size());
          for (const auto& component : selection.components) {
            if (!unique_classes.insert(component.class_id).second) {
              return Result<PortableAnalysisSelectionV1>::failure(error(
                  "c15.stationary_mixture_duplicate_class",
                  "stationary mixture class identifiers must be unique",
                  "/analysis_selection/components"));
            }
            probabilities.push_back(component.probability);
          }
          auto normalized = validate_and_normalize_pmf(
              probabilities, physical_pmf_tolerance());
          if (!normalized) {
            return Result<PortableAnalysisSelectionV1>::failure(
                normalized.error());
          }
          PortableStationaryMixtureSelectionV1 result;
          result.components.reserve(selection.components.size());
          for (std::size_t index = 0U; index < selection.components.size();
               ++index) {
            const auto& component = selection.components[index];
            result.components.push_back(PortableStationaryMixtureComponentV1{
                component.class_id,
                normalized.value().normalized_weights()[index]});
          }
          return Result<PortableAnalysisSelectionV1>::success(
              std::move(result));
        } else {
          return std::visit(
              [](const auto& fixed)
                  -> Result<PortableAnalysisSelectionV1> {
                using Fixed = std::decay_t<decltype(fixed)>;
                if constexpr (std::is_same_v<Fixed,
                                             FixedPointUniqueSelection>) {
                  return Result<PortableAnalysisSelectionV1>::success(
                      PortableFixedPointUniqueSelectionV1{});
                } else {
                  return Result<PortableAnalysisSelectionV1>::success(
                      PortableFixedPointIdSelectionV1{fixed.solution_id});
                }
              },
              selection);
        }
      },
      value);
}

[[nodiscard]] Result<std::optional<PortableInitialPredictiveLawV1>>
project_initial_law(const ResolvedInstance& instance,
                    const CompiledArrivalLaw& supplied_arrival) {
  if (!instance.initial_law().has_value()) {
    return Result<std::optional<PortableInitialPredictiveLawV1>>::success(
        std::nullopt);
  }
  auto compiled = compile_initial_physical_law(instance.initial_law()->law(),
                                               supplied_arrival);
  if (!compiled) {
    return Result<std::optional<PortableInitialPredictiveLawV1>>::failure(
        compiled.error());
  }
  PortableInitialPredictiveLawV1 result{1U, {}};
  result.atoms.reserve(compiled.value().atoms().size());
  for (const auto& atom : compiled.value().atoms()) {
    auto controller = source_node_bytes(atom.controller_state);
    auto context = source_node_bytes(atom.static_context);
    auto surrogate = source_node_bytes(atom.surrogate_initial);
    if (!controller) {
      return Result<std::optional<PortableInitialPredictiveLawV1>>::failure(
          controller.error());
    }
    if (!context) {
      return Result<std::optional<PortableInitialPredictiveLawV1>>::failure(
          context.error());
    }
    if (!surrogate) {
      return Result<std::optional<PortableInitialPredictiveLawV1>>::failure(
          surrogate.error());
    }
    result.atoms.push_back(PortableInitialLawAtomV1{
        atom.probability, atom.backlog,
        project_initial_state(atom.arrival_state), std::move(controller.value()),
        std::move(context.value()), std::move(surrogate.value())});
  }
  return Result<std::optional<PortableInitialPredictiveLawV1>>::success(
      std::move(result));
}

[[nodiscard]] std::optional<BigNat> resolved_queue_capacity(
    const ResolvedInstance& instance) {
  return std::visit(
      [](const auto& switch_config) -> std::optional<BigNat> {
        using Switch = std::decay_t<decltype(switch_config)>;
        if constexpr (std::is_same_v<Switch, GeneralizedSwitchConfig>) {
          return switch_config.queue_capacity.value;
        } else {
          return switch_config.voq_capacity.value;
        }
      },
      instance.authored_model().switch_config);
}

[[nodiscard]] bool valid_count_grant(const CountConstructionGrantV1& value) {
  if (!valid_enum(value.applicability)) return false;
  return (value.applicability == BudgetApplicabilityV1::applicable) ==
         value.amount.has_value();
}

[[nodiscard]] bool valid_tolerance_grant(
    const ToleranceConstructionGrantV1& value) {
  if (!valid_enum(value.applicability)) return false;
  if ((value.applicability == BudgetApplicabilityV1::applicable) !=
      value.amount.has_value()) {
    return false;
  }
  return !value.amount.has_value() || value.amount->is_nonnegative();
}

[[nodiscard]] bool valid_budget(const ConstructionBudget& value) {
  return value.schema_version == 1U &&
         valid_count_grant(value.exact_optimizer_calls) &&
         valid_count_grant(value.optimizer_search_states) &&
         valid_count_grant(value.configured_generator_draws) &&
         valid_tolerance_grant(value.linear_residual_abs) &&
         valid_tolerance_grant(value.integration_abs) &&
         valid_tolerance_grant(value.tail_abs) &&
         valid_tolerance_grant(value.fixed_point_abs);
}

[[nodiscard]] Json count_grant_json(const CountConstructionGrantV1& value) {
  return Json{{"applicability", std::string(*token(value.applicability))},
              {"amount", value.amount.has_value() ? natural_json(*value.amount)
                                                   : Json(nullptr)}};
}

[[nodiscard]] Json tolerance_grant_json(
    const ToleranceConstructionGrantV1& value) {
  return Json{{"applicability", std::string(*token(value.applicability))},
              {"amount", value.amount.has_value()
                             ? rational_json(*value.amount)
                             : Json(nullptr)}};
}

[[nodiscard]] Json construction_budget_json(const ConstructionBudget& value) {
  return Json{{"schema_version", value.schema_version},
              {"exact_optimizer_calls", count_grant_json(value.exact_optimizer_calls)},
              {"optimizer_search_states", count_grant_json(value.optimizer_search_states)},
              {"configured_generator_draws", count_grant_json(value.configured_generator_draws)},
              {"linear_residual_abs", tolerance_grant_json(value.linear_residual_abs)},
              {"integration_abs", tolerance_grant_json(value.integration_abs)},
              {"tail_abs", tolerance_grant_json(value.tail_abs)},
              {"fixed_point_abs", tolerance_grant_json(value.fixed_point_abs)}};
}

[[nodiscard]] Json provider_binding_json(const BuildProviderBindingV1& value) {
  return Json{{"provider_id", value.provider.provider_id},
              {"provider_version", value.provider.provider_version},
              {"parameter_schema_version", value.parameter_schema_version},
              {"provider_scientific_contract_digest",
               value.provider_scientific_contract_digest.value().hex()}};
}

[[nodiscard]] Json request_classifications_json(
    const RequestClassificationsV1& value) {
  return Json{{"construction_method", std::string(*token(value.construction_method))},
              {"producer_mode", std::string(*token(value.producer_mode))},
              {"proposed_semantic_tag", std::string(*token(value.proposed_semantic_tag))},
              {"proposed_access_tag", std::string(*token(value.proposed_access_tag))},
              {"proposed_payload_tag", std::string(*token(value.proposed_payload_tag))}};
}

[[nodiscard]] Json identity_classifications_json(
    const BuildIdentityClassificationsV1& value) {
  return Json{{"construction_method", std::string(*token(value.construction_method))},
              {"producer_mode", std::string(*token(value.producer_mode))},
              {"deployed_semantic_tag", std::string(*token(value.deployed_semantic_tag))},
              {"runtime_access_tag", std::string(*token(value.runtime_access_tag))},
              {"payload_tag", std::string(*token(value.payload_tag))},
              {"payload_version", value.payload_version}};
}

[[nodiscard]] Result<Json> accepted_contract_json(
    const AcceptedCapabilityContractSnapshotV1& value) {
  auto manifest = c14_manifest_capsule_json(
      value.structural_metric_support_manifest);
  if (!manifest) return Result<Json>::failure(manifest.error());
  Json targets = Json::array();
  for (const auto& target : value.construction_target_scope) {
    targets.push_back(strong_id_json(target));
  }
  Json arrival = Json::array();
  for (const auto& assumption : value.construction_prerequisites.arrival) {
    arrival.push_back(arrival_assumption_json(assumption));
  }
  const auto optional_count = [](const std::optional<BigNat>& count) {
    return count.has_value() ? Json(to_string(*count)) : Json(nullptr);
  };
  // This is C15's frozen v1 wire object.  The snapshot's two derived C14
  // digest echoes are process-local conveniences for later direct providers;
  // adding them here would silently change every C15 build/request identity.
  return Result<Json>::success(Json{
      {"structural_metric_support_manifest", std::move(manifest.value())},
      {"construction_target_scope", std::move(targets)},
      {"construction_prerequisites",
       Json{{"arrival", std::move(arrival)},
            {"required_optimizer_calls",
             optional_count(value.construction_prerequisites
                                .required_optimizer_calls)},
            {"required_generator_draws",
             optional_count(value.construction_prerequisites
                                .required_generator_draws)},
            {"required_search_states_per_call",
             optional_count(value.construction_prerequisites
                                .required_search_states_per_call)}}},
      {"accepted_provider_policies", policies_json(value.accepted_provider_policies)}});
}

[[nodiscard]] Json build_subject_json(const BuildSubjectV1& value) {
  Json targets = Json::array();
  for (const auto& target : value.ordered_deployed_targets) {
    targets.push_back(strong_id_json(target));
  }
  return Json{{"subject_version", value.subject_version},
              {"ordered_deployed_targets", std::move(targets)},
              {"construction_group_binding",
               strong_id_json(value.construction_group_binding)}};
}

[[nodiscard]] Result<Json> build_identity_json_with_parameters(
    const BuildIdentityV1& value, Json parameters) {
  auto problem = framework_problem_view_json(value.framework_problem_view, true);
  if (!problem) return Result<Json>::failure(problem.error());
  auto contract = accepted_contract_json(value.accepted_capability_contract);
  if (!contract) return Result<Json>::failure(contract.error());
  if (!valid_budget(value.construction_budget)) {
    return Result<Json>::failure(error(
        "c15.invalid_construction_budget",
        "build identity contains a malformed construction budget",
        "/construction_budget"));
  }
  return Result<Json>::success(Json{
      {"build_identity_version", value.build_identity_version},
      {"provider_binding", provider_binding_json(value.provider_binding)},
      {"classifications", identity_classifications_json(value.classifications)},
      {"framework_problem_view", std::move(problem.value())},
      {"accepted_capability_contract", std::move(contract.value())},
      {"validated_parameter_values", std::move(parameters)},
      {"construction_budget", construction_budget_json(value.construction_budget)},
      {"build_subject", build_subject_json(value.build_subject)},
      {"build_request_protocol_version", value.build_request_protocol_version},
      {"artifact_protocol_version", value.artifact_protocol_version},
      {"required_build_report_schema", value.required_build_report_schema}});
}

[[nodiscard]] Result<Json> build_identity_json(const BuildIdentityV1& value) {
  auto parameters = parse_canonical_json(value.validated_parameter_values,
                                         "/validated_parameter_values");
  if (!parameters) return Result<Json>::failure(parameters.error());
  return build_identity_json_with_parameters(value,
                                             std::move(parameters).value());
}

[[nodiscard]] Result<Json> request_json_with_parameters(
    const SurrogateBuildRequest& value, const bool include_request_digest,
    Json parameters) {
  auto problem = framework_problem_view_json(value.framework_problem_view(), true);
  if (!problem) return Result<Json>::failure(problem.error());
  auto contract = accepted_contract_json(value.accepted_capability_contract());
  if (!contract) return Result<Json>::failure(contract.error());
  if (!valid_budget(value.construction_budget())) {
    return Result<Json>::failure(error(
        "c15.invalid_construction_budget",
        "request contains a malformed construction budget",
        "/construction_budget"));
  }
  Json object{
      {"protocol_version", value.protocol_version()},
      {"build_identity_digest", value.build_identity_digest().digest().hex()}};
  if (include_request_digest) {
    object["request_digest"] = value.request_digest().value().hex();
  }
  object["provider_binding"] = provider_binding_json(value.provider_binding());
  object["classifications"] = request_classifications_json(value.classifications());
  object["framework_problem_view"] = std::move(problem.value());
  object["accepted_capability_contract"] = std::move(contract.value());
  object["validated_parameters"] = std::move(parameters);
  object["construction_budget"] = construction_budget_json(value.construction_budget());
  object["build_seed"] = Json{
      {"rng_version", value.build_seed().rng_version()},
      {"master_seed", std::to_string(value.build_seed().master_seed().value())},
      {"build_identity_digest",
       value.build_seed().build_identity_digest().digest().hex()}};
  object["required_build_report_schema"] = value.required_build_report_schema();
  return Result<Json>::success(std::move(object));
}

[[nodiscard]] Result<Json> request_json(const SurrogateBuildRequest& value,
                                        const bool include_request_digest) {
  auto parameters = parse_canonical_json(value.validated_parameters(),
                                         "/validated_parameters");
  if (!parameters) return Result<Json>::failure(parameters.error());
  return request_json_with_parameters(value, include_request_digest,
                                      std::move(parameters).value());
}

[[nodiscard]] Result<std::vector<std::byte>> build_identity_bytes(
    const BuildIdentityV1& value) {
  if (auto encoded = build_identity_json(value); encoded) {
    return Result<std::vector<std::byte>>::success(
        json_bytes(encoded.value()));
  }
  auto raw = canonical_json_fragment_text(
      value.validated_parameter_values, "/validated_parameter_values");
  if (!raw) return Result<std::vector<std::byte>>::failure(raw.error());
  auto shell = build_identity_json_with_parameters(value, Json(nullptr));
  if (!shell) return Result<std::vector<std::byte>>::failure(shell.error());
  return json_bytes_with_raw_value(
      std::move(shell).value(), "validated_parameter_values", raw.value(),
      "/validated_parameter_values");
}

[[nodiscard]] Result<std::vector<std::byte>> request_bytes(
    const SurrogateBuildRequest& value, const bool include_request_digest) {
  if (auto encoded = request_json(value, include_request_digest); encoded) {
    return Result<std::vector<std::byte>>::success(
        json_bytes(encoded.value()));
  }
  auto raw = canonical_json_fragment_text(value.validated_parameters(),
                                          "/validated_parameters");
  if (!raw) return Result<std::vector<std::byte>>::failure(raw.error());
  auto shell = request_json_with_parameters(
      value, include_request_digest, Json(nullptr));
  if (!shell) return Result<std::vector<std::byte>>::failure(shell.error());
  return json_bytes_with_raw_value(
      std::move(shell).value(), "validated_parameters", raw.value(),
      "/validated_parameters");
}

[[nodiscard]] BuildIdentityV1 reconstruct_identity(
    const SurrogateBuildRequest& value,
    const ValidatedProviderManifest& manifest) {
  return BuildIdentityV1{
      1U,
      value.provider_binding(),
      BuildIdentityClassificationsV1{
          value.classifications().construction_method,
          value.classifications().producer_mode,
          value.classifications().proposed_semantic_tag,
          value.classifications().proposed_access_tag,
          value.classifications().proposed_payload_tag,
          manifest.value().payload_class.version},
      value.framework_problem_view(),
      value.accepted_capability_contract(),
      std::vector<std::byte>(value.validated_parameters().begin(),
                             value.validated_parameters().end()),
      value.construction_budget(),
      BuildSubjectV1{1U,
                     value.framework_problem_view()
                         .target_selection()
                         .ordered_targets,
                     value.framework_problem_view()
                         .target_selection()
                         .construction_group_binding},
      value.protocol_version(),
      1U,
      value.required_build_report_schema()};
}

[[nodiscard]] bool arrival_assumption_shape_valid(
    const ArrivalAssumptionV1& value) {
  if (!valid_enum(value.kind) || !valid_enum(value.use) ||
      !valid_enum(value.provision)) {
    return false;
  }
  const bool has_any_transform_field =
      value.transform_kind.has_value() ||
      value.distribution_scope.has_value() ||
      value.argument_domain.has_value();
  const bool has_complete_transform =
      value.transform_kind.has_value() &&
      value.distribution_scope.has_value() &&
      value.argument_domain.has_value();
  const bool valid_domain =
      !value.argument_domain.has_value() ||
      value.argument_domain->lower < value.argument_domain->upper ||
      (value.argument_domain->lower == value.argument_domain->upper &&
       value.argument_domain->lower_inclusive &&
       value.argument_domain->upper_inclusive);
  if (value.moment_order.has_value() && value.moment_order->is_zero()) {
    return false;
  }
  switch (value.kind) {
    case ArrivalNeedKindV1::target_intensity:
      return !value.moment_order.has_value() &&
             !has_any_transform_field && !value.joint &&
             !value.phase_conditioned;
    case ArrivalNeedKindV1::arrival_moment:
      return value.moment_order.has_value() &&
             !has_any_transform_field;
    case ArrivalNeedKindV1::transform:
      return !value.moment_order.has_value() &&
             has_complete_transform && valid_domain &&
             valid_enum(*value.transform_kind) &&
             valid_enum(*value.distribution_scope);
    case ArrivalNeedKindV1::full_common_batch:
    case ArrivalNeedKindV1::predictive_phase:
    case ArrivalNeedKindV1::sequential_law:
    case ArrivalNeedKindV1::entrance_labels:
    case ArrivalNeedKindV1::finite_support:
    case ArrivalNeedKindV1::exact_iid_late:
      return !value.moment_order.has_value() &&
             !has_any_transform_field && !value.phase_conditioned;
  }
  return false;
}

[[nodiscard]] bool manifest_enums_valid(
    const SurrogateProviderManifestV1& value) {
  if (!valid_enum(value.construction_method) ||
      !valid_enum(value.producer_mode) ||
      !valid_enum(value.deployed_semantic_tag) ||
      !valid_enum(value.runtime_access_tag) ||
      !valid_enum(value.payload_class.tag)) {
    return false;
  }
  const auto& applicability = value.optimizer_constraint_applicability;
  const auto& prerequisites =
      value.target_and_arrival_scientific_prerequisites;
  const auto& policies = value.scientific_construction_policy_schema;
  const auto enums_valid = [](const auto& values) {
    return std::all_of(values.begin(), values.end(),
                       [](const auto item) { return valid_enum(item); });
  };
  const auto arrival_enums_valid = [](const ArrivalAssumptionV1& assumption) {
    return valid_enum(assumption.kind) && valid_enum(assumption.use) &&
           valid_enum(assumption.provision) &&
           (!assumption.transform_kind.has_value() ||
            valid_enum(*assumption.transform_kind)) &&
           (!assumption.distribution_scope.has_value() ||
            valid_enum(*assumption.distribution_scope));
  };
  return std::all_of(
             applicability.scheduler_optimizer_pairs.begin(),
             applicability.scheduler_optimizer_pairs.end(),
             [](const SchedulerConstraintPairV1& pair) {
               return valid_enum(pair.service_family) &&
                      valid_enum(pair.optimizer);
             }) &&
         enums_valid(applicability.timing_conventions) &&
         std::all_of(
             prerequisites.permitted_target_couplings.begin(),
             prerequisites.permitted_target_couplings.end(),
             [](const auto item) { return valid_enum(item); }) &&
         std::all_of(prerequisites.arrival_assumptions.begin(),
                     prerequisites.arrival_assumptions.end(),
                     arrival_enums_valid) &&
         std::all_of(value.allowed_metric_support_roles.begin(),
                     value.allowed_metric_support_roles.end(),
                     [](const auto item) { return valid_enum(item); }) &&
         enums_valid(policies.point_deployment) &&
         enums_valid(policies.coefficient_completion) &&
         enums_valid(policies.projection) &&
         enums_valid(policies.recoding) &&
         enums_valid(policies.evidence_roles);
}

[[nodiscard]] bool preview_policies_enums_valid(
    const PreviewPoliciesV1& value) {
  return valid_enum(value.point_deployment) &&
         valid_enum(value.coefficient_completion) &&
         valid_enum(value.projection) && valid_enum(value.recoding) &&
         valid_enum(value.evidence_roles);
}

[[nodiscard]] bool request_enums_valid(const SurrogateBuildRequest& value) {
  const auto& classification = value.classifications();
  return valid_enum(classification.construction_method) &&
         valid_enum(classification.producer_mode) &&
         valid_enum(classification.proposed_semantic_tag) &&
         valid_enum(classification.proposed_access_tag) &&
         valid_enum(classification.proposed_payload_tag) &&
         preview_policies_enums_valid(
             value.accepted_capability_contract().accepted_provider_policies) &&
         std::all_of(
             value.accepted_capability_contract()
                 .construction_prerequisites.arrival.begin(),
             value.accepted_capability_contract()
                 .construction_prerequisites.arrival.end(),
             arrival_assumption_shape_valid);
}

[[nodiscard]] bool scientific_projection_enums_valid(
    const ProviderScientificContractProjectionV1& value) {
  SurrogateProviderManifestV1 shell{
      1U,
      value.provider,
      false,
      zero_digest(),
      value.construction_method,
      ProducerModeV1::in_process_builder,
      value.deployed_semantic_tag,
      value.runtime_access_tag,
      value.payload_class,
      value.parameter_schema_version,
      value.parameter_schema_digest,
      value.supported_build_request_versions,
      value.supported_artifact_versions,
      value.required_build_report_schema_versions,
      value.required_method_counters,
      value.optimizer_constraint_applicability,
      value.target_and_arrival_scientific_prerequisites,
      value.metric_clause_upper_envelope,
      value.allowed_metric_support_roles,
      value.allowed_family_evidence_schemas,
      {},
      value.scientific_construction_policy_schema,
      std::nullopt,
      ProviderTransportLimitsV1{1U, 1U},
      zero_digest()};
  return manifest_enums_valid(shell);
}

[[nodiscard]] bool parameter_domain_is_subset(
    const MetricParameterDomainV1& subset,
    const MetricParameterDomainV1& ceiling) {
  const auto* subset_set =
      std::get_if<ExactMetricParameterSetV1>(&subset);
  const auto* ceiling_set =
      std::get_if<ExactMetricParameterSetV1>(&ceiling);
  if (subset_set != nullptr || ceiling_set != nullptr) {
    if (subset_set == nullptr || ceiling_set == nullptr) return false;
    return std::all_of(
        subset_set->values.begin(), subset_set->values.end(),
        [&](const MetricRequestParametersV1& value) {
          return std::find(ceiling_set->values.begin(),
                           ceiling_set->values.end(),
                           value) != ceiling_set->values.end();
        });
  }
  return subset == ceiling;
}

[[nodiscard]] bool clause_is_narrowing(
    const MetricSupportClauseV1& subset,
    const MetricSupportClauseV1& ceiling,
    const ProviderIdentityV1& provider,
    const std::span<const QueueId> deployed_targets) {
  return subset.clause_id == ceiling.clause_id &&
         subset.metric_kind == ceiling.metric_kind &&
         parameter_domain_is_subset(subset.parameter_domain,
                                    ceiling.parameter_domain) &&
         detail::metric_targets_are_narrowing(subset, ceiling, provider,
                                              deployed_targets) &&
         subset.target_coupling == ceiling.target_coupling &&
         subset.state_fields == ceiling.state_fields &&
         detail::metric_marks_are_narrowing(subset, ceiling, provider) &&
         subset.selection_domain == ceiling.selection_domain &&
         subset.phase_domain == ceiling.phase_domain &&
         subset.payload_class == ceiling.payload_class &&
         subset.semantic == ceiling.semantic &&
         subset.runtime_access == ceiling.runtime_access &&
         subset.arrival_assumptions == ceiling.arrival_assumptions &&
         subset.hypotheses == ceiling.hypotheses &&
         subset.solver_route == ceiling.solver_route &&
         subset.requested_accuracy == ceiling.requested_accuracy &&
         subset.error_promise == ceiling.error_promise &&
         subset.result_scope == ceiling.result_scope &&
         subset.mandatory_v0 == ceiling.mandatory_v0 &&
         subset.required_roles == ceiling.required_roles;
}

[[nodiscard]] bool manifest_is_subset(const MetricSupportManifest& subset,
                                      const MetricSupportManifest& ceiling,
                                      const ProviderIdentityV1& provider,
                                      const std::span<const QueueId>
                                          deployed_targets) {
  return std::all_of(
      subset.clauses().begin(), subset.clauses().end(),
      [&](const MetricSupportClauseV1& clause) {
        return std::any_of(
            ceiling.clauses().begin(), ceiling.clauses().end(),
            [&](const MetricSupportClauseV1& upper) {
              return clause_is_narrowing(clause, upper, provider,
                                         deployed_targets);
            });
      });
}

template <typename T>
[[nodiscard]] bool contains_value(const std::vector<T>& values,
                                  const T& wanted) {
  return std::find(values.begin(), values.end(), wanted) != values.end();
}

[[nodiscard]] bool contains_target(const std::span<const QueueId> values,
                                   const QueueId& wanted) {
  return std::find(values.begin(), values.end(), wanted) != values.end();
}

[[nodiscard]] bool accepted_policies_allowed(
    const PreviewPoliciesV1& policies,
    const ScientificConstructionPolicySchemaV1& schema) {
  return contains_value(schema.point_deployment, policies.point_deployment) &&
         contains_value(schema.coefficient_completion,
                        policies.coefficient_completion) &&
         contains_value(schema.projection, policies.projection) &&
         contains_value(schema.recoding, policies.recoding) &&
         contains_value(schema.evidence_roles, policies.evidence_roles);
}

}  // namespace

namespace artifact::detail {

Result<Digest256> canonical_analysis_selection_digest_v1(
    const PortableAnalysisSelectionV1& selection) {
  return hash_json_versioned("mwperf.framework_problem.analysis_selection",
                             analysis_selection_json(selection));
}

Result<Digest256> canonical_analysis_selection_digest_v1(
    const SelectionSpec& selection) {
  auto projected = project_analysis_selection(selection);
  if (!projected) {
    return Result<Digest256>::failure(projected.error());
  }
  return canonical_analysis_selection_digest_v1(projected.value());
}

Result<Digest256> canonical_ordered_metric_targets_digest_v1(
    const std::span<const QueueId> ordered_targets) {
  Json targets = Json::array();
  for (const QueueId& target : ordered_targets) {
    targets.push_back(strong_id_json(target));
  }
  return hash_json_versioned("mwperf.metric_request.ordered_targets",
                             targets);
}

Result<Digest256> canonical_ordered_metric_targets_digest_v1(
    const std::span<const ResolvedMetricTargetV1> ordered_targets) {
  std::vector<QueueId> queue_ids;
  queue_ids.reserve(ordered_targets.size());
  for (const ResolvedMetricTargetV1& target : ordered_targets) {
    queue_ids.push_back(target.queue_id);
  }
  return canonical_ordered_metric_targets_digest_v1(queue_ids);
}

Result<FrameworkProblemViewDigest>
canonical_framework_problem_view_digest_v1(
    const FrameworkProblemView& view) {
  auto digest = hash_view_without_digest(view);
  if (!digest) {
    return Result<FrameworkProblemViewDigest>::failure(digest.error());
  }
  return Result<FrameworkProblemViewDigest>::success(
      FrameworkProblemViewDigest(std::move(digest).value()));
}

}  // namespace artifact::detail

Result<std::vector<std::byte>> canonical_provider_manifest_bytes_v1(
    const SurrogateProviderManifestV1& manifest) {
  if (!manifest_enums_valid(manifest)) {
    return Result<std::vector<std::byte>>::failure(error(
        "c15.invalid_provider_manifest_enum",
        "provider manifest contains an unknown closed enum value"));
  }
  auto encoded = provider_manifest_json(manifest, true);
  if (!encoded) return Result<std::vector<std::byte>>::failure(encoded.error());
  return Result<std::vector<std::byte>>::success(json_bytes(encoded.value()));
}

Result<Digest256> digest_provider_manifest_v1(
    const SurrogateProviderManifestV1& manifest) {
  if (!manifest_enums_valid(manifest)) {
    return Result<Digest256>::failure(error(
        "c15.invalid_provider_manifest_enum",
        "provider manifest contains an unknown closed enum value"));
  }
  auto encoded = provider_manifest_json(manifest, false);
  if (!encoded) return Result<Digest256>::failure(encoded.error());
  return hash_json_versioned("mwperf.provider_manifest", encoded.value());
}

Result<std::vector<std::byte>>
canonical_provider_scientific_contract_bytes_v1(
    const ProviderScientificContractProjectionV1& projection) {
  if (!scientific_projection_enums_valid(projection)) {
    return Result<std::vector<std::byte>>::failure(error(
        "c15.invalid_scientific_projection_enum",
        "scientific projection contains an unknown closed enum value"));
  }
  auto encoded = scientific_projection_json(projection);
  if (!encoded) return Result<std::vector<std::byte>>::failure(encoded.error());
  return Result<std::vector<std::byte>>::success(json_bytes(encoded.value()));
}

Result<ProviderScientificContractDigest>
digest_provider_scientific_contract_v1(
    const ProviderScientificContractProjectionV1& projection) {
  if (!scientific_projection_enums_valid(projection)) {
    return Result<ProviderScientificContractDigest>::failure(error(
        "c15.invalid_scientific_projection_enum",
        "scientific projection contains an unknown closed enum value"));
  }
  auto encoded = scientific_projection_json(projection);
  if (!encoded) {
    return Result<ProviderScientificContractDigest>::failure(encoded.error());
  }
  auto digest = hash_json_versioned("mwperf.provider_scientific_contract",
                                    encoded.value());
  if (!digest) {
    return Result<ProviderScientificContractDigest>::failure(digest.error());
  }
  return Result<ProviderScientificContractDigest>::success(
      ProviderScientificContractDigest(std::move(digest.value())));
}

Result<ValidatedProviderManifest> validate_provider_manifest(
    const SurrogateProviderManifest& manifest) {
  if (manifest.manifest_schema_version != 1U) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.unsupported_manifest_version",
        "provider manifest schema version must be exactly 1",
        "/manifest_schema_version"));
  }
  if (!portable_identifier(manifest.provider.provider_id) ||
      !portable_identifier(manifest.provider.provider_version)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_provider_identity",
        "provider ID and version must use the closed portable ASCII grammar",
        "/provider"));
  }
  if (!manifest_enums_valid(manifest)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.unknown_manifest_enum",
        "provider manifest contains an unknown closed enum value"));
  }
  if (is_cp09_observation_only_identity(manifest.provider) &&
      !cp09_observation_only_authority_shape(manifest)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c32.cp09_observation_only_authority_invalid",
        "provider 1.4 must expose only the frozen observation/evidence role "
        "and nondeployment policy sets"));
  }
  const bool cp09_observation_only =
      cp09_observation_only_authority_shape(manifest);
  if (!nonzero_digest(manifest.source_build_identity) ||
      manifest.parameter_schema_version == 0U ||
      !nonzero_digest(manifest.parameter_schema_digest)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.missing_manifest_identity",
        "source/build and parameter-schema identities must be nonzero",
        "/parameter_schema_digest"));
  }
  if (!contains_version_one(manifest.supported_build_request_versions) ||
      !contains_version_one(manifest.supported_artifact_versions) ||
      !contains_version_one(manifest.required_build_report_schema_versions)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.unsupported_protocol_versions",
        "the closed C15 manifest must support exactly version 1 of each protocol",
        "/supported_build_request_versions"));
  }
  for (std::size_t index = 0U;
       index < manifest.required_method_counters.size(); ++index) {
    const auto& counter = manifest.required_method_counters[index];
    if (!portable_identifier(counter.name) ||
        reserved_method_counter_name(counter.name) ||
        (index != 0U &&
         !(manifest.required_method_counters[index - 1U].name <
           counter.name))) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.noncanonical_required_method_counters",
          "required provider method counters must have portable strictly sorted unique nonreserved names",
          "/required_method_counters"));
    }
  }
  if (manifest.payload_class.version != 1U ||
      !payload_access_compatible(manifest.payload_class.tag,
                                 manifest.deployed_semantic_tag,
                                 manifest.runtime_access_tag)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.incompatible_payload_access",
        "payload, deployed semantic, and runtime access are not a declared v1 tuple",
        "/payload_class"));
  }
  if (!method_mode_compatible(manifest.construction_method,
                              manifest.producer_mode)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.incompatible_method_mode",
        "construction method and producer mode are not a legal singular tuple",
        "/producer_mode"));
  }
  const auto& applicability = manifest.optimizer_constraint_applicability;
  if (applicability.scheduler_optimizer_pairs.empty() ||
      applicability.timing_conventions.size() != 1U ||
      applicability.timing_conventions.front() !=
          TimingConvention::early_service_late_admission ||
      !std::all_of(applicability.scheduler_optimizer_pairs.begin(),
                   applicability.scheduler_optimizer_pairs.end(), valid_pair)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_applicability",
        "applicability must contain exact supported scheduler/optimizer pairs and v1 timing",
        "/optimizer_constraint_applicability"));
  }
  for (std::size_t index = 1U;
       index < applicability.scheduler_optimizer_pairs.size(); ++index) {
    const auto& left = applicability.scheduler_optimizer_pairs[index - 1U];
    const auto& right = applicability.scheduler_optimizer_pairs[index];
    if (std::pair{static_cast<unsigned>(left.service_family),
                  static_cast<unsigned>(left.optimizer)} >=
        std::pair{static_cast<unsigned>(right.service_family),
                  static_cast<unsigned>(right.optimizer)}) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.noncanonical_applicability",
          "scheduler/optimizer applicability pairs must be sorted and unique",
          "/optimizer_constraint_applicability/scheduler_optimizer_pairs"));
    }
  }
  const auto& prerequisite =
      manifest.target_and_arrival_scientific_prerequisites;
  if (prerequisite.minimum_deployed_targets == 0U ||
      prerequisite.maximum_deployed_targets <
          prerequisite.minimum_deployed_targets ||
      prerequisite.permitted_target_couplings.empty() ||
      !strict_enum_sorted_unique(prerequisite.permitted_target_couplings)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_target_prerequisites",
        "target cardinality and coupling prerequisites are malformed",
        "/target_and_arrival_scientific_prerequisites"));
  }
  std::string previous_assumption;
  for (const auto& assumption : prerequisite.arrival_assumptions) {
    if (!arrival_assumption_shape_valid(assumption)) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.invalid_arrival_prerequisite",
          "arrival prerequisite has an invalid closed shape",
          "/target_and_arrival_scientific_prerequisites/arrival_assumptions"));
    }
    const std::string current = arrival_assumption_json(assumption).dump();
    if (!previous_assumption.empty() && previous_assumption >= current) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.noncanonical_arrival_prerequisites",
          "arrival prerequisites must be sorted and unique",
          "/target_and_arrival_scientific_prerequisites/arrival_assumptions"));
    }
    previous_assumption = current;
  }
  if (manifest.metric_clause_upper_envelope.clauses().empty() ||
      manifest.allowed_metric_support_roles.empty() ||
      !strict_enum_sorted_unique(manifest.allowed_metric_support_roles)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_capability_upper_envelope",
        "capability ceiling and allowed role set must be finite, nonempty, and canonical",
        "/metric_clause_upper_envelope"));
  }
  for (const auto role : manifest.allowed_metric_support_roles) {
    if (!role_is_used(manifest.metric_clause_upper_envelope, role) &&
        !cp09_observation_only) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.unbound_allowed_role",
          "every allowed metric role must occur in the capability upper envelope",
          "/allowed_metric_support_roles"));
    }
  }
  for (const auto& clause : manifest.metric_clause_upper_envelope.clauses()) {
    if (clause.payload_class != manifest.payload_class ||
        clause.semantic != manifest.deployed_semantic_tag ||
        clause.runtime_access != manifest.runtime_access_tag ||
        clause.ordered_targets.size() <
            prerequisite.minimum_deployed_targets ||
        clause.ordered_targets.size() >
            prerequisite.maximum_deployed_targets ||
        !contains_value(prerequisite.permitted_target_couplings,
                        clause.target_coupling)) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.upper_envelope_tuple_mismatch",
          "every capability-ceiling clause must use the manifest's singular payload/semantic/access tuple and target domain",
          "/metric_clause_upper_envelope"));
    }
    for (const auto& assumption : clause.arrival_assumptions) {
      if (!contains_value(prerequisite.arrival_assumptions, assumption)) {
        return Result<ValidatedProviderManifest>::failure(error(
            "c15.upper_envelope_arrival_mismatch",
            "capability-ceiling clause claims an arrival assumption absent from the scientific prerequisite ceiling",
            "/metric_clause_upper_envelope"));
      }
    }
    for (const auto& requirement : clause.required_roles) {
      if (!contains_value(manifest.allowed_metric_support_roles,
                          requirement.role) &&
          !cp09_observation_only) {
        return Result<ValidatedProviderManifest>::failure(error(
            "c15.missing_allowed_role",
            "upper-envelope role is absent from allowed role set",
            "/allowed_metric_support_roles"));
      }
    }
  }
  if (!strict_family_evidence_schema_key_order(
          manifest.allowed_family_evidence_schemas)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.noncanonical_evidence_schemas",
        "family evidence schemas must be sorted and unique by schema ID/version",
        "/allowed_family_evidence_schemas"));
  }
  for (const auto& schema : manifest.allowed_family_evidence_schemas) {
    if (!portable_identifier(schema.schema_id) || schema.schema_version == 0U ||
        schema.maximum_canonical_body_bytes == 0U ||
        schema.maximum_canonical_body_bytes >
            kSurrogateBuildProtocolV1MaximumResultBytes) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.invalid_evidence_schema",
          "family evidence schema declaration is incomplete or exceeds the core result-byte ceiling",
          "/allowed_family_evidence_schemas"));
    }
  }
  const auto& conformance_anchors =
      manifest.family_evidence_conformance_report_anchors;
  if (!strict_conformance_anchor_key_order(conformance_anchors)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.noncanonical_conformance_anchors",
        "family conformance-report anchors must be sorted and unique by schema ID/version",
        "/family_evidence_conformance_report_anchors"));
  }
  if (conformance_anchors.size() !=
      manifest.allowed_family_evidence_schemas.size()) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.conformance_anchor_set_mismatch",
        "every allowed family evidence schema must have exactly one conformance-report anchor and no extra anchor is permitted",
        "/family_evidence_conformance_report_anchors"));
  }
  for (std::size_t index = 0U; index < conformance_anchors.size(); ++index) {
    const auto& schema = manifest.allowed_family_evidence_schemas[index];
    const auto& anchor = conformance_anchors[index];
    const std::string path =
        "/family_evidence_conformance_report_anchors/" +
        std::to_string(index);
    if (anchor.family_evidence_schema_id != schema.schema_id ||
        anchor.family_evidence_schema_version != schema.schema_version) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.conformance_anchor_set_mismatch",
          "conformance-report anchor key does not match the corresponding allowed family evidence schema",
          path));
    }
    if (anchor.report_schema_version != kProtocolVersion ||
        !nonzero_digest(anchor.report_digest)) {
      return Result<ValidatedProviderManifest>::failure(error(
          "c15.invalid_conformance_anchor",
          "conformance-report anchor must carry report schema version 1 and a nonzero report digest",
          path));
    }
  }
  if (!policy_schema_valid(manifest.scientific_construction_policy_schema)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_policy_schema",
        "scientific construction policy domains must be closed nonempty canonical sets",
        "/scientific_construction_policy_schema"));
  }
  const auto& policy_schema = manifest.scientific_construction_policy_schema;
  const bool analytic_payload =
      manifest.payload_class.tag ==
      PayloadClassTagV1::finite_parameter_analytic_data_v1;
  const bool recipe_payload =
      manifest.payload_class.tag ==
      PayloadClassTagV1::registered_runtime_recipe_v1;
  if (policy_schema.registered_analytic_families.size() !=
          (analytic_payload ? 1U : 0U) ||
      policy_schema.registered_runtime_recipes.size() !=
          (recipe_payload ? 1U : 0U)) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.adapter_registration_mismatch",
        "manifest must bind exactly one matching registered adapter/recipe only for its selected payload class",
        "/scientific_construction_policy_schema"));
  }
  const bool local =
      manifest.producer_mode == ProducerModeV1::local_executable_builder;
  if (local != manifest.local_executable.has_value() ||
      (local && !executable_declaration_valid(*manifest.local_executable))) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_executable_declaration",
        "only a local-executable provider must carry one complete static executable declaration",
        "/local_executable"));
  }
  if (manifest.transport_limits.maximum_request_bytes == 0U ||
      manifest.transport_limits.maximum_result_bytes == 0U ||
      manifest.transport_limits.maximum_request_bytes >
          kSurrogateBuildProtocolV1MaximumRequestBytes ||
      manifest.transport_limits.maximum_result_bytes >
          kSurrogateBuildProtocolV1MaximumResultBytes) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.invalid_transport_limits",
        "request/result byte caps must be positive and no wider than core v1 caps",
        "/transport_limits"));
  }
  auto expected_manifest_digest = digest_provider_manifest_v1(manifest);
  if (!expected_manifest_digest ||
      expected_manifest_digest.value() != manifest.manifest_digest) {
    return Result<ValidatedProviderManifest>::failure(error(
        "c15.manifest_digest_mismatch",
        "provider manifest digest does not match its canonical value",
        "/manifest_digest"));
  }
  auto projection = make_projection(manifest);
  auto scientific_digest = digest_provider_scientific_contract_v1(projection);
  if (!scientific_digest) {
    return Result<ValidatedProviderManifest>::failure(scientific_digest.error());
  }
  return Result<ValidatedProviderManifest>::success(ValidatedProviderManifest(
      manifest, std::move(projection), std::move(scientific_digest.value())));
}

Result<std::vector<std::byte>> canonical_framework_problem_view_bytes_v1(
    const FrameworkProblemView& view) {
  auto encoded = framework_problem_view_json(view, true);
  if (!encoded) return Result<std::vector<std::byte>>::failure(encoded.error());
  return Result<std::vector<std::byte>>::success(json_bytes(encoded.value()));
}

Result<Digest256> canonical_physical_trajectory_digest_v1(
    const FrameworkProblemView& view) {
  return hash_json_versioned("mwperf.full_orbit.cp09.physical_trajectory",
                             physical_trajectory_projection_json(view));
}

Result<FrameworkProblemView> build_framework_problem_view(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival,
    const TargetSelection& targets) {
  if (targets.schema_version != 1U || targets.ordered_targets.empty()) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.invalid_target_selection",
        "target selection must be a nonempty closed version-1 value",
        "/target_selection"));
  }
  std::vector<QueueId> expected_targets;
  expected_targets.reserve(instance.targets().size());
  for (const auto& target : instance.targets().values()) {
    expected_targets.push_back(instance.queues().queue_id(target.queue));
  }
  if (targets.ordered_targets != expected_targets) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.target_selection_mismatch",
        "target selection must preserve the complete authored resolved target order",
        "/target_selection/ordered_targets"));
  }
  std::set<QueueId> unique_targets(targets.ordered_targets.begin(),
                                   targets.ordered_targets.end());
  if (unique_targets.size() != targets.ordered_targets.size()) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.duplicate_target", "target selection contains a duplicate queue",
        "/target_selection/ordered_targets"));
  }

  auto bound_arrival = detail::CompiledArrivalAccess::get(instance.arrival());
  if (!bound_arrival) {
    return Result<FrameworkProblemView>::failure(bound_arrival.error());
  }
  const BuilderArrivalView supplied_arrival = builder_arrival_view(arrival);
  const BuilderArrivalView expected_arrival =
      builder_arrival_view(*bound_arrival.value());
  if (supplied_arrival.binding() != expected_arrival.binding() ||
      supplied_arrival.digest() != expected_arrival.digest()) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.arrival_binding_mismatch",
        "compiled arrival law is not the law bound to the resolved instance",
        "/configured_arrival"));
  }
  if (supplied_arrival.version() != 1U ||
      supplied_arrival.binding().timing != instance.timing() ||
      supplied_arrival.binding().queue_cardinality != instance.queues().size() ||
      supplied_arrival.positive_support().size() != instance.queues().size() ||
      supplied_arrival.positive_support().bytes() !=
          instance.positive_arrival_support().bytes()) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.invalid_arrival_projection",
        "portable arrival view does not match resolved timing, dimension, or support",
        "/configured_arrival"));
  }

  std::vector<PortableQueueEntryV1> queues;
  queues.reserve(instance.queues().size());
  for (std::size_t ordinal = 0U; ordinal < instance.queues().size(); ++ordinal) {
    auto index = instance.queues().index_at(ordinal);
    if (!index) return Result<FrameworkProblemView>::failure(index.error());
    const QueueId& queue = instance.queues().queue_id(index.value());
    queues.push_back(PortableQueueEntryV1{
        queue,
        ordinal,
        ExactRational::one(),
        contains_target(targets.ordered_targets, queue),
        instance.serviceable().at(index.value()),
        instance.positive_arrival_support().at(index.value())});
  }

  PortableConstraintGeometryV1 geometry =
      project_constraint_geometry(instance.constraint(), instance.queues());
  std::vector<QueueId> priority;
  priority.reserve(instance.priority().size());
  for (const auto index : instance.priority().rank_to_queue()) {
    priority.push_back(instance.queues().queue_id(index));
  }
  if (!instance.analysis_spec().context) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.analysis_context_missing",
        "resolved instance has no immutable analysis selection",
        "/analysis_selection"));
  }
  auto projected_selection =
      project_analysis_selection(instance.analysis_spec().context->selection);
  if (!projected_selection) {
    return Result<FrameworkProblemView>::failure(projected_selection.error());
  }
  PortableAnalysisSelectionV1 analysis_selection =
      std::move(projected_selection).value();
  auto initial_law = project_initial_law(instance, arrival);
  if (!initial_law) {
    return Result<FrameworkProblemView>::failure(initial_law.error());
  }
  if (std::holds_alternative<PortableTransientSelectionV1>(
          analysis_selection) != initial_law.value().has_value()) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.selection_initial_law_mismatch",
        "a transient analysis selection must have exactly one compiled initial-law projection",
        "/initial_predictive_state_law"));
  }
  PortableUnitAndEncodingContractV1 units{
      1U, "packet", "unit_packet", "slot",
      IntegerEncodingV1::canonical_decimal_string,
      ScientificScalarEncodingV1::rational_or_binary64_bits, true,
      resolved_queue_capacity(instance)};

  auto constraint_digest = hash_json_versioned(
      "mwperf.framework_problem.constraint", constraint_geometry_json(geometry));
  auto target_digest = hash_json_versioned(
      "mwperf.framework_problem.target_selection", target_selection_json(targets));
  Json priority_json = Json::array();
  for (const auto& queue : priority) priority_json.push_back(strong_id_json(queue));
  Json tie_timing_json{{"priority_order", std::move(priority_json)},
                       {"timing", std::string(*token(instance.timing()))}};
  auto tie_digest = hash_json_versioned("mwperf.framework_problem.tie_timing",
                                        tie_timing_json);
  if (!constraint_digest || !target_digest || !tie_digest) {
    return Result<FrameworkProblemView>::failure(
        !constraint_digest ? constraint_digest.error()
        : !target_digest   ? target_digest.error()
                           : tie_digest.error());
  }

  const Digest256 compiled_arrival_digest = supplied_arrival.digest().value();
  Json queue_json = Json::array();
  for (const auto& entry : queues) {
    queue_json.push_back(Json{{"queue_id", strong_id_json(entry.queue_id)},
                              {"dense_index", std::to_string(entry.dense_index)},
                              {"maxweight_multiplier", rational_json(entry.maxweight_multiplier)},
                              {"selected_target", entry.selected_target},
                              {"individually_serviceable", entry.individually_serviceable},
                              {"positive_arrival_support", entry.positive_arrival_support}});
  }
  Json resolved_projection{
      {"authored_model", instance.fingerprints().model.hex()},
      {"analysis", instance.fingerprints().analysis.hex()},
      {"combined", instance.fingerprints().combined.hex()},
      {"queues", std::move(queue_json)},
      {"constraint", constraint_digest.value().hex()},
      {"targets", target_digest.value().hex()},
      {"tie_timing", tie_digest.value().hex()},
      {"arrival", compiled_arrival_digest.hex()},
      {"analysis_selection", analysis_selection_json(analysis_selection)},
      {"initial_law", initial_law_json(initial_law.value())}};
  auto resolved_digest = hash_json_versioned(
      "mwperf.framework_problem.resolved_instance", resolved_projection);
  if (!resolved_digest) {
    return Result<FrameworkProblemView>::failure(resolved_digest.error());
  }

  FrameworkProblemFingerprintsV1 fingerprints{
      instance.fingerprints(), resolved_digest.value(),
      constraint_digest.value(), target_digest.value(), tie_digest.value(),
      compiled_arrival_digest};
  const auto service = instance.service_identity();
  FrameworkProblemView provisional(
      1U, fingerprints, queues, targets,
      SchedulerConstraintPairV1{service.family, service.optimizer}, geometry,
      priority, instance.timing(), supplied_arrival, analysis_selection,
      initial_law.value(), units, FrameworkProblemViewDigest(zero_digest()));
  auto view_digest = hash_view_without_digest(provisional);
  if (!view_digest) {
    return Result<FrameworkProblemView>::failure(view_digest.error());
  }
  return Result<FrameworkProblemView>::success(FrameworkProblemView(
      1U, std::move(fingerprints), std::move(queues), targets,
      SchedulerConstraintPairV1{service.family, service.optimizer},
      std::move(geometry), std::move(priority), instance.timing(),
      supplied_arrival, std::move(analysis_selection),
      std::move(initial_law.value()), std::move(units),
      FrameworkProblemViewDigest(std::move(view_digest.value()))));
}

Result<FrameworkProblemView>
project_factorized_iid_framework_problem_view(
    const FrameworkProblemView& view) {
  auto projected_arrival = project_factorized_iid_builder_arrival_view(
      view.configured_arrival());
  if (!projected_arrival) {
    return Result<FrameworkProblemView>::failure(projected_arrival.error());
  }

  FrameworkProblemFingerprintsV1 fingerprints = view.fingerprints();
  fingerprints.compiled_arrival = projected_arrival.value().digest().value();
  Json queues = Json::array();
  for (const auto& entry : view.queues()) {
    queues.push_back(Json{{"queue_id", strong_id_json(entry.queue_id)},
                          {"dense_index", std::to_string(entry.dense_index)},
                          {"maxweight_multiplier",
                           rational_json(entry.maxweight_multiplier)},
                          {"selected_target", entry.selected_target},
                          {"individually_serviceable",
                           entry.individually_serviceable},
                          {"positive_arrival_support",
                           entry.positive_arrival_support}});
  }
  Json resolved_projection{
      {"authored_model", fingerprints.authored_inputs.model.hex()},
      {"analysis", fingerprints.authored_inputs.analysis.hex()},
      {"combined", fingerprints.authored_inputs.combined.hex()},
      {"queues", std::move(queues)},
      {"constraint", fingerprints.constraint.hex()},
      {"targets", fingerprints.target_selection.hex()},
      {"tie_timing", fingerprints.tie_and_timing.hex()},
      {"arrival", fingerprints.compiled_arrival.hex()},
      {"analysis_selection",
       analysis_selection_json(view.analysis_selection())},
      {"initial_law", initial_law_json(view.initial_predictive_law())}};
  auto resolved_digest = hash_json_versioned(
      "mwperf.framework_problem.resolved_instance", resolved_projection);
  if (!resolved_digest) {
    return Result<FrameworkProblemView>::failure(resolved_digest.error());
  }
  fingerprints.resolved_instance = std::move(resolved_digest).value();

  try {
    FrameworkProblemView provisional(
        view.schema_version(), fingerprints,
        std::vector<PortableQueueEntryV1>(view.queues().begin(),
                                          view.queues().end()),
        view.target_selection(), view.applicability_key(),
        view.constraint_geometry(),
        std::vector<QueueId>(view.priority_order().begin(),
                             view.priority_order().end()),
        view.timing(), projected_arrival.value(), view.analysis_selection(),
        view.initial_predictive_law(), view.units_and_encodings(),
        FrameworkProblemViewDigest(zero_digest()));
    auto view_digest = hash_view_without_digest(provisional);
    if (!view_digest) {
      return Result<FrameworkProblemView>::failure(view_digest.error());
    }
    return Result<FrameworkProblemView>::success(FrameworkProblemView(
        view.schema_version(), std::move(fingerprints),
        std::vector<PortableQueueEntryV1>(view.queues().begin(),
                                          view.queues().end()),
        view.target_selection(), view.applicability_key(),
        view.constraint_geometry(),
        std::vector<QueueId>(view.priority_order().begin(),
                             view.priority_order().end()),
        view.timing(), std::move(projected_arrival).value(),
        view.analysis_selection(), view.initial_predictive_law(),
        view.units_and_encodings(),
        FrameworkProblemViewDigest(std::move(view_digest).value())));
  } catch (const std::bad_alloc&) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.compact_problem_projection_allocation",
        "constructing the compact factorized-IID framework problem view "
        "exhausted memory",
        "/framework_problem_view/configured_arrival"));
  } catch (const std::length_error&) {
    return Result<FrameworkProblemView>::failure(error(
        "c15.compact_problem_projection_representation",
        "the compact factorized-IID framework problem view exceeded a host "
        "container limit",
        "/framework_problem_view/configured_arrival"));
  }
}

Result<FrameworkProblemView>
build_framework_problem_view_matching_arrival_projection(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival,
    const TargetSelection& targets,
    const Digest256& expected_compiled_arrival) {
  auto full = build_framework_problem_view(instance, arrival, targets);
  if (!full) {
    return full;
  }
  if (full.value().fingerprints().compiled_arrival ==
      expected_compiled_arrival) {
    return full;
  }
  auto compact = project_factorized_iid_framework_problem_view(full.value());
  if (compact && compact.value().fingerprints().compiled_arrival ==
                     expected_compiled_arrival) {
    return compact;
  }
  return Result<FrameworkProblemView>::failure(error(
      "c15.arrival_projection_fingerprint_mismatch",
      "the expected compiled-arrival fingerprint identifies neither the "
      "canonical full view nor its sanctioned compact factorized-IID "
      "projection",
      "/framework_problem_view/compiled_arrival_fingerprint"));
}

Result<Digest256> digest_surrogate_parameter_values_v1(
    const std::span<const std::byte> canonical_value_bytes) {
  auto validated = canonical_json_fragment_text(canonical_value_bytes,
                                                "/validated_parameters");
  if (!validated) return Result<Digest256>::failure(validated.error());
  std::vector<std::byte> framed{
      std::byte{0}, std::byte{0}, std::byte{0}, std::byte{1}};
  framed.insert(framed.end(), canonical_value_bytes.begin(),
                canonical_value_bytes.end());
  return sha256_domain_separated("mwperf.surrogate_parameter_values",
                                 framed);
}

Result<std::vector<std::byte>> canonical_construction_budget_bytes_v1(
    const ConstructionBudget& budget) {
  if (!valid_budget(budget)) {
    return Result<std::vector<std::byte>>::failure(error(
        "c15.invalid_construction_budget",
        "construction budget has an invalid tag/value shape"));
  }
  return Result<std::vector<std::byte>>::success(
      json_bytes(construction_budget_json(budget)));
}

Result<Digest256> digest_construction_budget_v1(
    const ConstructionBudget& budget) {
  if (!valid_budget(budget)) {
    return Result<Digest256>::failure(error(
        "c15.invalid_construction_budget",
        "construction budget has an invalid tag/value shape"));
  }
  return hash_json_versioned("mwperf.construction_budget",
                             construction_budget_json(budget));
}

Result<std::vector<std::byte>> canonical_build_identity_bytes_v1(
    const BuildIdentityV1& identity) {
  if (identity.build_identity_version != 1U ||
      identity.build_request_protocol_version != 1U ||
      identity.artifact_protocol_version != 1U ||
      identity.required_build_report_schema != 1U ||
      !valid_enum(identity.classifications.construction_method) ||
      !valid_enum(identity.classifications.producer_mode) ||
      !valid_enum(identity.classifications.deployed_semantic_tag) ||
      !valid_enum(identity.classifications.runtime_access_tag) ||
      !valid_enum(identity.classifications.payload_tag) ||
      !preview_policies_enums_valid(
          identity.accepted_capability_contract.accepted_provider_policies)) {
    return Result<std::vector<std::byte>>::failure(error(
        "c15.invalid_build_identity",
        "build identity contains an unsupported version or enum"));
  }
  return build_identity_bytes(identity);
}

Result<BuildIdentityDigest> digest_build_identity_v1(
    const BuildIdentityV1& identity) {
  auto encoded = canonical_build_identity_bytes_v1(identity);
  if (!encoded) return Result<BuildIdentityDigest>::failure(encoded.error());
  std::vector<std::byte> framed{
      std::byte{0}, std::byte{0}, std::byte{0}, std::byte{1}};
  framed.insert(framed.end(), encoded.value().begin(), encoded.value().end());
  auto digest = sha256_domain_separated("mwperf.surrogate_build_identity",
                                        framed);
  if (!digest) return Result<BuildIdentityDigest>::failure(digest.error());
  return Result<BuildIdentityDigest>::success(
      BuildIdentityDigest(std::move(digest.value())));
}

Result<std::vector<std::byte>> canonical_surrogate_build_request_bytes_v1(
    const SurrogateBuildRequest& request) {
  if (!request_enums_valid(request)) {
    return Result<std::vector<std::byte>>::failure(error(
        "c15.invalid_request_enum",
        "request contains an unknown closed enum value"));
  }
  return request_bytes(request, true);
}

namespace {

[[nodiscard]] Result<SurrogateBuildRequestDigest> digest_request(
    const SurrogateBuildRequest& request) {
  if (!request_enums_valid(request)) {
    return Result<SurrogateBuildRequestDigest>::failure(error(
        "c15.invalid_request_enum",
        "request contains an unknown closed enum value"));
  }
  auto encoded = request_bytes(request, false);
  if (!encoded) {
    return Result<SurrogateBuildRequestDigest>::failure(encoded.error());
  }
  std::vector<std::byte> framed{
      std::byte{0}, std::byte{0}, std::byte{0}, std::byte{1}};
  framed.insert(framed.end(), encoded.value().begin(), encoded.value().end());
  auto digest = sha256_domain_separated("mwperf.surrogate_build_request",
                                        framed);
  if (!digest) {
    return Result<SurrogateBuildRequestDigest>::failure(digest.error());
  }
  return Result<SurrogateBuildRequestDigest>::success(
      SurrogateBuildRequestDigest(std::move(digest.value())));
}

[[nodiscard]] bool contract_scope_valid(
    const std::span<const QueueId> construction_scope,
    const std::span<const QueueId> deployed_targets,
    const std::span<const PortableQueueEntryV1> queue_catalog) {
  if (construction_scope.empty()) return false;
  std::set<QueueId> unique(construction_scope.begin(), construction_scope.end());
  if (unique.size() != construction_scope.size()) return false;
  return std::all_of(
             construction_scope.begin(), construction_scope.end(),
             [queue_catalog](const QueueId& queue) {
               return std::any_of(
                   queue_catalog.begin(), queue_catalog.end(),
                   [&](const PortableQueueEntryV1& entry) {
                     return entry.queue_id == queue;
                   });
             }) &&
         std::all_of(deployed_targets.begin(), deployed_targets.end(),
                     [construction_scope](const QueueId& target) {
                       return contains_target(construction_scope, target);
                     });
}

[[nodiscard]] bool applicability_contains(
    const SchedulerConstraintApplicabilityV1& applicability,
    const SchedulerConstraintPairV1& pair, const TimingConvention timing) {
  return std::find(applicability.scheduler_optimizer_pairs.begin(),
                   applicability.scheduler_optimizer_pairs.end(), pair) !=
             applicability.scheduler_optimizer_pairs.end() &&
         std::find(applicability.timing_conventions.begin(),
                   applicability.timing_conventions.end(), timing) !=
             applicability.timing_conventions.end();
}

[[nodiscard]] Result<void> validate_contract_for_request(
    const ValidatedProviderManifest& manifest,
    const FrameworkProblemView& problem_view,
    const AcceptedCapabilityContract& contract,
    const ValidatedSurrogateParameters& parameters,
    const ConstructionBudget& budget) {
  const auto& provider = manifest.value();
  if (contract.schema_version() != 1U ||
      contract.provider() != provider.provider ||
      contract.construction_method() != provider.construction_method ||
      contract.producer_mode() != provider.producer_mode ||
      contract.payload_class() != provider.payload_class ||
      contract.semantic() != provider.deployed_semantic_tag ||
      contract.runtime_access() != provider.runtime_access_tag) {
    return Result<void>::failure(error(
        "c15.accepted_contract_provider_mismatch",
        "accepted capability contract does not match the validated provider tuple",
        "/accepted_capability_contract"));
  }
  auto core_digest =
      canonical_plug_descriptor_core_digest_v1(contract.descriptor_core());
  if (!core_digest || core_digest.value() != contract.descriptor_core().core_digest ||
      contract.descriptor_core().provider != provider.provider ||
      contract.descriptor_core().payload_class != provider.payload_class ||
      contract.descriptor_core().semantic != provider.deployed_semantic_tag ||
      contract.descriptor_core().runtime_access != provider.runtime_access_tag ||
      contract.descriptor_core().metric_support_manifest_digest !=
          contract.structural_manifest().canonical_digest()) {
    return Result<void>::failure(error(
        "c15.accepted_descriptor_integrity",
        "accepted descriptor core failed canonical self-integrity or provider binding",
        "/accepted_capability_contract/structural_metric_support_manifest"));
  }
  auto requirements_digest =
      canonical_metric_requirements_digest(contract.requirements());
  auto arrival_digest =
      canonical_arrival_capabilities_digest_v1(contract.arrival_capabilities());
  if (!requirements_digest ||
      requirements_digest.value() != contract.requirements_digest() ||
      !arrival_digest ||
      arrival_digest.value() != contract.arrival_capabilities_digest() ||
      contract.arrival_capabilities() !=
          problem_view.configured_arrival().capabilities()) {
    return Result<void>::failure(error(
        "c15.accepted_contract_integrity",
        "accepted requirements or arrival-capability binding failed canonical integrity",
        "/accepted_capability_contract"));
  }
  auto manifest_owner =
      std::make_shared<const MetricSupportManifest>(
          contract.structural_manifest());
  PlugDescriptorPreview reconstructed_preview{
      contract.schema_version(),
      contract.descriptor_core(),
      contract.construction_method(),
      contract.producer_mode(),
      std::vector<QueueId>(contract.construction_target_scope().begin(),
                           contract.construction_target_scope().end()),
      contract.policies(),
      contract.construction_prerequisites(),
      std::move(manifest_owner),
      problem_view.canonical_digest().value(),
      contract.parameter_digest(),
      contract.budget_digest(),
      contract.preview_digest()};
  auto reconstructed_preview_digest =
      canonical_plug_descriptor_preview_digest_v1(reconstructed_preview);
  if (!reconstructed_preview_digest ||
      reconstructed_preview_digest.value() != contract.preview_digest()) {
    return Result<void>::failure(error(
        "c15.accepted_preview_binding_mismatch",
        "accepted capability contract was not produced from this exact framework problem view",
        "/accepted_capability_contract/preview_digest"));
  }
  if (!manifest_is_subset(
          contract.structural_manifest(),
          provider.metric_clause_upper_envelope, provider.provider,
          contract.descriptor_core().deployed_targets)) {
    return Result<void>::failure(error(
        "c15.accepted_manifest_exceeds_provider",
        "accepted structural manifest is not an exact subset of the provider ceiling",
        "/accepted_capability_contract/structural_metric_support_manifest"));
  }
  if (contract.descriptor_core().deployed_targets !=
      problem_view.target_selection().ordered_targets ||
      !contract_scope_valid(contract.construction_target_scope(),
                            contract.descriptor_core().deployed_targets,
                            problem_view.queues())) {
    return Result<void>::failure(error(
        "c15.invalid_construction_target_scope",
        "deployed targets must match the problem view and be contained in construction scope",
        "/accepted_capability_contract/construction_target_scope"));
  }
  const auto count = contract.descriptor_core().deployed_targets.size();
  const auto& prerequisites =
      provider.target_and_arrival_scientific_prerequisites;
  if (count < prerequisites.minimum_deployed_targets ||
      count > prerequisites.maximum_deployed_targets ||
      !contains_value(prerequisites.permitted_target_couplings,
                      contract.descriptor_core().target_coupling) ||
      (provider.payload_class.tag ==
           PayloadClassTagV1::three_bin_scalar_response_v1 &&
       (count != 1U || contract.descriptor_core().target_coupling !=
                           TargetCouplingV1::scalar_target))) {
    return Result<void>::failure(error(
        "c15.invalid_deployed_target_domain",
        "accepted target cardinality/coupling is outside provider prerequisites",
        "/accepted_capability_contract"));
  }
  if (!applicability_contains(provider.optimizer_constraint_applicability,
                              problem_view.applicability_key(),
                              problem_view.timing()) ||
      !applicability_contains(contract.descriptor_core().applicability,
                              problem_view.applicability_key(),
                              problem_view.timing())) {
    return Result<void>::failure(error(
        "c15.problem_not_applicable",
        "problem optimizer/constraint/timing key is not exactly declared",
        "/framework_problem_view/optimizer_constraint_applicability_key"));
  }
  if (!accepted_policies_allowed(
          contract.policies(),
          provider.scientific_construction_policy_schema) &&
      !cp09_compatibility_policies(provider, contract.policies())) {
    return Result<void>::failure(error(
        "c15.accepted_policy_not_allowed",
        "accepted provider policy lies outside the manifest's closed policy schema",
        "/accepted_capability_contract/accepted_provider_policies"));
  }
  for (const auto& assumption : contract.construction_prerequisites().arrival) {
    if (!contains_value(prerequisites.arrival_assumptions, assumption)) {
      return Result<void>::failure(error(
          "c15.construction_arrival_prerequisite_mismatch",
          "accepted construction arrival prerequisite lies outside the provider scientific contract",
          "/accepted_capability_contract"));
    }
  }
  const auto grant_covers = [](const CountConstructionGrantV1& grant,
                               const std::optional<BigNat>& required) {
    if (!required.has_value()) return true;
    return grant.applicability == BudgetApplicabilityV1::applicable &&
           grant.amount.has_value() && *grant.amount >= *required;
  };
  std::optional<BigNat> required_search_states;
  if (!artifact::detail::checked_required_optimizer_search_states_v1(
          contract.construction_prerequisites(), required_search_states)) {
    return Result<void>::failure(error(
        "c15.construction_budget_arithmetic_failure",
        "computing the total optimizer search-state prerequisite failed",
        "/construction_budget/optimizer_search_states"));
  }
  if (!grant_covers(budget.exact_optimizer_calls,
                    contract.construction_prerequisites()
                        .required_optimizer_calls) ||
      !grant_covers(budget.optimizer_search_states,
                    required_search_states) ||
      !grant_covers(budget.configured_generator_draws,
                    contract.construction_prerequisites()
                        .required_generator_draws)) {
    return Result<void>::failure(error(
        "c15.construction_budget_insufficient",
        "accepted construction prerequisites exceed an applicable common grant",
        "/construction_budget"));
  }
  auto parameter_digest =
      digest_surrogate_parameter_values_v1(parameters.canonical_value_bytes());
  if (!parameter_digest ||
      parameter_digest.value() != parameters.canonical_value_digest() ||
      parameter_digest.value() != contract.parameter_digest() ||
      parameters.provider() != provider.provider ||
      parameters.parameter_schema_version() !=
          provider.parameter_schema_version ||
      parameters.parameter_schema_digest() !=
          provider.parameter_schema_digest) {
    return Result<void>::failure(error(
        "c15.validated_parameter_binding_mismatch",
        "validated parameters do not match provider/version/schema or accepted parameter digest",
        "/validated_parameters"));
  }
  auto budget_digest = digest_construction_budget_v1(budget);
  if (!budget_digest || budget_digest.value() != contract.budget_digest()) {
    return Result<void>::failure(error(
        "c15.construction_budget_binding_mismatch",
        "construction budget does not match the budget accepted by C14",
        "/construction_budget"));
  }
  auto problem_digest = hash_view_without_digest(problem_view);
  if (!problem_digest ||
      problem_digest.value() != problem_view.canonical_digest().value()) {
    return Result<void>::failure(error(
        "c15.problem_view_digest_mismatch",
        "framework problem view failed canonical self-integrity",
        "/framework_problem_view/canonical_digest"));
  }
  return Result<void>::success();
}

}  // namespace

Result<SurrogateBuildRequest> make_surrogate_build_request(
    const ValidatedProviderManifest& manifest,
    const FrameworkProblemView& problem_view,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateParameters& parameters,
    const ConstructionBudget& construction_budget,
    const MasterSeed& master_seed) {
  auto contract_validation = validate_contract_for_request(
      manifest, problem_view, accepted_contract, parameters,
      construction_budget);
  if (!contract_validation) {
    return Result<SurrogateBuildRequest>::failure(contract_validation.error());
  }
  const auto& provider = manifest.value();
  BuildProviderBindingV1 binding{
      provider.provider, provider.parameter_schema_version,
      manifest.scientific_contract_digest()};
  RequestClassificationsV1 request_classifications{
      provider.construction_method, provider.producer_mode,
      provider.deployed_semantic_tag, provider.runtime_access_tag,
      provider.payload_class.tag};
  BuildIdentityClassificationsV1 identity_classifications{
      provider.construction_method, provider.producer_mode,
      provider.deployed_semantic_tag, provider.runtime_access_tag,
      provider.payload_class.tag, provider.payload_class.version};
  AcceptedCapabilityContractSnapshotV1 snapshot{
      accepted_contract.contract_digest(),
      accepted_contract.requirements_digest(),
      accepted_contract.structural_manifest(),
      std::vector<QueueId>(accepted_contract.construction_target_scope().begin(),
                           accepted_contract.construction_target_scope().end()),
      accepted_contract.construction_prerequisites(),
      accepted_contract.policies()};
  BuildSubjectV1 subject{1U, problem_view.target_selection().ordered_targets,
                         problem_view.target_selection()
                             .construction_group_binding};
  BuildIdentityV1 identity{
      1U,
      binding,
      identity_classifications,
      problem_view,
      snapshot,
      std::vector<std::byte>(parameters.canonical_value_bytes().begin(),
                             parameters.canonical_value_bytes().end()),
      construction_budget,
      subject,
      1U,
      1U,
      1U};
  auto identity_digest = digest_build_identity_v1(identity);
  if (!identity_digest) {
    return Result<SurrogateBuildRequest>::failure(identity_digest.error());
  }
  BuildSeed seed(master_seed, identity_digest.value());
  SurrogateBuildRequest request(
      1U, identity_digest.value(), SurrogateBuildRequestDigest(zero_digest()),
      std::move(binding), request_classifications, problem_view,
      std::move(snapshot),
      std::vector<std::byte>(parameters.canonical_value_bytes().begin(),
                             parameters.canonical_value_bytes().end()),
      construction_budget, std::move(seed), 1U);
  auto final_digest = digest_request(request);
  if (!final_digest) {
    return Result<SurrogateBuildRequest>::failure(final_digest.error());
  }
  request.request_digest_ = std::move(final_digest.value());
  auto verified = artifact::detail::verify_request_bindings_v1(request,
                                                               manifest);
  if (!verified) {
    return Result<SurrogateBuildRequest>::failure(verified.error());
  }
  return Result<SurrogateBuildRequest>::success(std::move(request));
}

Result<void> artifact::detail::verify_request_bindings_v1(
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest) {
  const auto& provider = manifest.value();
  if (request.protocol_version() != 1U ||
      request.required_build_report_schema() != 1U ||
      request.build_seed().rng_version() != 1U) {
    return Result<void>::failure(error(
        "c15.unsupported_request_version",
        "request, build-report, and RNG schema versions must be exactly 1"));
  }
  if (!request_enums_valid(request)) {
    return Result<void>::failure(error(
        "c15.invalid_request_enum",
        "request contains an unknown closed enum value"));
  }
  auto projection_digest =
      digest_provider_scientific_contract_v1(manifest.scientific_projection());
  if (!projection_digest ||
      projection_digest.value() != manifest.scientific_contract_digest() ||
      request.provider_binding().provider != provider.provider ||
      request.provider_binding().parameter_schema_version !=
          provider.parameter_schema_version ||
      request.provider_binding().provider_scientific_contract_digest !=
          manifest.scientific_contract_digest()) {
    return Result<void>::failure(error(
        "c15.request_provider_binding_mismatch",
        "request provider binding or scientific projection digest is stale",
        "/provider_binding"));
  }
  const RequestClassificationsV1 expected_classifications{
      provider.construction_method, provider.producer_mode,
      provider.deployed_semantic_tag, provider.runtime_access_tag,
      provider.payload_class.tag};
  if (request.classifications() != expected_classifications) {
    return Result<void>::failure(error(
        "c15.request_classification_mismatch",
        "request classification tuple does not match the validated provider",
        "/classifications"));
  }
  auto problem_digest = hash_view_without_digest(request.framework_problem_view());
  if (!problem_digest || problem_digest.value() !=
                             request.framework_problem_view()
                                 .canonical_digest()
                                 .value()) {
    return Result<void>::failure(error(
        "c15.problem_view_digest_mismatch",
        "request problem view failed canonical self-integrity",
        "/framework_problem_view/canonical_digest"));
  }
  if (!manifest_is_subset(
          request.accepted_capability_contract()
              .structural_metric_support_manifest,
          provider.metric_clause_upper_envelope, provider.provider,
          request.framework_problem_view()
              .target_selection()
              .ordered_targets) ||
      !nonzero_digest(request.accepted_capability_contract()
                          .accepted_contract_digest) ||
      !nonzero_digest(request.accepted_capability_contract()
                          .normalized_metric_requirements_digest) ||
      (!accepted_policies_allowed(
           request.accepted_capability_contract().accepted_provider_policies,
           provider.scientific_construction_policy_schema) &&
       !cp09_compatibility_policies(
           provider,
           request.accepted_capability_contract()
               .accepted_provider_policies)) ||
      !contract_scope_valid(
          request.accepted_capability_contract().construction_target_scope,
          request.framework_problem_view().target_selection().ordered_targets,
          request.framework_problem_view().queues())) {
    return Result<void>::failure(error(
        "c15.request_contract_binding_mismatch",
        "request capability snapshot is outside the validated provider contract",
        "/accepted_capability_contract"));
  }
  const auto& accepted_prerequisites =
      request.accepted_capability_contract().construction_prerequisites;
  std::string previous_assumption;
  for (const auto& assumption : accepted_prerequisites.arrival) {
    const std::string current = arrival_assumption_json(assumption).dump();
    if (!arrival_assumption_shape_valid(assumption) ||
        assumption.use != ArrivalCapabilityUseV1::construction ||
        !contains_value(
            provider.target_and_arrival_scientific_prerequisites
                .arrival_assumptions,
            assumption) ||
        (!previous_assumption.empty() && previous_assumption >= current)) {
      return Result<void>::failure(error(
          "c15.request_construction_prerequisite_mismatch",
          "request construction prerequisites must be canonical accepted construction assumptions within the provider contract",
          "/accepted_capability_contract/construction_prerequisites/arrival"));
    }
    previous_assumption = current;
  }
  const auto grant_covers = [](const CountConstructionGrantV1& grant,
                               const std::optional<BigNat>& required) {
    return !required.has_value() ||
           (grant.applicability == BudgetApplicabilityV1::applicable &&
            grant.amount.has_value() && *grant.amount >= *required);
  };
  std::optional<BigNat> required_search_states;
  if (!artifact::detail::checked_required_optimizer_search_states_v1(
          accepted_prerequisites, required_search_states)) {
    return Result<void>::failure(error(
        "c15.request_construction_prerequisite_arithmetic_failure",
        "computing the request's total optimizer search-state prerequisite "
        "failed",
        "/accepted_capability_contract/construction_prerequisites"));
  }
  if (!grant_covers(request.construction_budget().exact_optimizer_calls,
                    accepted_prerequisites.required_optimizer_calls) ||
      !grant_covers(request.construction_budget().optimizer_search_states,
                    required_search_states) ||
      !grant_covers(request.construction_budget().configured_generator_draws,
                    accepted_prerequisites.required_generator_draws)) {
    return Result<void>::failure(error(
        "c15.request_construction_prerequisite_mismatch",
        "request construction prerequisites require applicable common grants with sufficient bounds",
        "/accepted_capability_contract/construction_prerequisites"));
  }
  BuildIdentityV1 identity = reconstruct_identity(request, manifest);
  auto expected_identity_digest = digest_build_identity_v1(identity);
  if (!expected_identity_digest ||
      expected_identity_digest.value() != request.build_identity_digest()) {
    return Result<void>::failure(error(
        "c15.build_identity_digest_mismatch",
        "request build-identity digest does not match the seed-free precursor",
        "/build_identity_digest"));
  }
  if (!request.build_seed().is_bound_to(expected_identity_digest.value())) {
    return Result<void>::failure(error(
        "c15.build_seed_parent_mismatch",
        "build seed does not name the request's seed-free build identity",
        "/build_seed/build_identity_digest"));
  }
  auto expected_request_digest = digest_request(request);
  if (!expected_request_digest ||
      expected_request_digest.value() != request.request_digest()) {
    return Result<void>::failure(error(
        "c15.request_digest_mismatch",
        "final request digest does not match all request fields except itself",
        "/request_digest"));
  }
  return Result<void>::success();
}

}  // namespace mwperf
