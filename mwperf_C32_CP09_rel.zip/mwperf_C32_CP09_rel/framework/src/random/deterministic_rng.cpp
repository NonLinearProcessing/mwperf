#include "mwperf/random/deterministic_rng.hpp"

#include <algorithm>
#include <bit>
#include <exception>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>

#include <boost/multiprecision/cpp_int.hpp>

#include "mwperf/math/probability.hpp"
#include "mwperf/model/typed_label.hpp"

namespace mwperf {
namespace {

using ByteVector = std::vector<std::byte>;
using BigInt = boost::multiprecision::cpp_int;

static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t),
              "version-1 component lengths require size_t to fit in u64");

constexpr std::string_view kInstanceDomain = "mwperf.rng.instance";
constexpr std::string_view kStreamDomain = "mwperf.rng.xoshiro256ss";

enum class ComponentType : std::uint8_t {
  raw_digest = 0x01,
  utf8 = 0x02,
  big_nat = 0x03,
  typed_label = 0x04,
  exact_state_digest = 0x05,
};

[[nodiscard]] Diagnostic rng_diagnostic(std::string code,
                                        std::string message) {
  return Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                    std::move(message), std::nullopt, std::nullopt, {}};
}

void append_u16be(ByteVector& output, std::uint16_t value) {
  output.push_back(static_cast<std::byte>((value >> 8U) & 0xffU));
  output.push_back(static_cast<std::byte>(value & 0xffU));
}

void append_u32be(ByteVector& output, std::uint32_t value) {
  for (int shift = 24; shift >= 0; shift -= 8) {
    output.push_back(
        static_cast<std::byte>((value >> static_cast<unsigned>(shift)) & 0xffU));
  }
}

void append_u64be(ByteVector& output, std::uint64_t value) {
  for (int shift = 56; shift >= 0; shift -= 8) {
    output.push_back(
        static_cast<std::byte>((value >> static_cast<unsigned>(shift)) & 0xffU));
  }
}

void append_ascii(ByteVector& output, std::string_view text) {
  output.reserve(output.size() + text.size());
  for (const unsigned char character : text) {
    output.push_back(static_cast<std::byte>(character));
  }
}

void append_bytes(ByteVector& output, std::span<const std::byte> bytes) {
  output.insert(output.end(), bytes.begin(), bytes.end());
}

void append_bytes(ByteVector& output, std::span<const std::uint8_t> bytes) {
  output.reserve(output.size() + bytes.size());
  for (const std::uint8_t value : bytes) {
    output.push_back(static_cast<std::byte>(value));
  }
}

[[nodiscard]] bool is_valid_utf8(std::string_view text) noexcept {
  const auto* bytes = reinterpret_cast<const unsigned char*>(text.data());
  std::size_t position = 0;
  while (position < text.size()) {
    const unsigned char first = bytes[position];
    if (first <= 0x7fU) {
      ++position;
      continue;
    }

    std::size_t continuation_count = 0;
    std::uint32_t code_point = 0;
    std::uint32_t minimum = 0;
    if (first >= 0xc2U && first <= 0xdfU) {
      continuation_count = 1;
      code_point = first & 0x1fU;
      minimum = 0x80U;
    } else if (first >= 0xe0U && first <= 0xefU) {
      continuation_count = 2;
      code_point = first & 0x0fU;
      minimum = 0x800U;
    } else if (first >= 0xf0U && first <= 0xf4U) {
      continuation_count = 3;
      code_point = first & 0x07U;
      minimum = 0x10000U;
    } else {
      return false;
    }

    if (continuation_count > text.size() - position - 1U) {
      return false;
    }
    for (std::size_t offset = 1; offset <= continuation_count; ++offset) {
      const unsigned char continuation = bytes[position + offset];
      if ((continuation & 0xc0U) != 0x80U) {
        return false;
      }
      code_point = (code_point << 6U) | (continuation & 0x3fU);
    }
    if (code_point < minimum || code_point > 0x10ffffU ||
        (code_point >= 0xd800U && code_point <= 0xdfffU)) {
      return false;
    }
    position += continuation_count + 1U;
  }
  return true;
}

[[nodiscard]] ByteVector string_payload(std::string_view text) {
  ByteVector result;
  append_ascii(result, text);
  return result;
}

[[nodiscard]] ByteVector digest_payload(const Digest256& digest) {
  return ByteVector(digest.bytes().begin(), digest.bytes().end());
}

[[nodiscard]] ByteVector big_nat_payload(const BigNat& value) {
  const auto magnitude = value.canonical_magnitude_bytes();
  ByteVector result;
  append_bytes(result, std::span<const std::uint8_t>(magnitude));
  return result;
}

[[nodiscard]] ByteVector typed_label_payload(const TypedLabel& label) {
  const auto encoding = label.canonical_bytes();
  ByteVector result;
  append_bytes(result, std::span<const std::uint8_t>(encoding));
  return result;
}

struct Component {
  ComponentType type;
  ByteVector payload;
};

void append_component(ByteVector& output, const Component& component) {
  output.push_back(static_cast<std::byte>(component.type));
  append_u64be(output, static_cast<std::uint64_t>(component.payload.size()));
  append_bytes(output, std::span<const std::byte>(component.payload));
}

[[nodiscard]] ByteVector encode_instance_key_preimage(
    std::span<const Component> components) {
  ByteVector preimage;
  append_ascii(preimage, kInstanceDomain);
  preimage.push_back(std::byte{0});
  append_u32be(preimage, kRngVersion);
  for (const Component& component : components) {
    append_component(preimage, component);
  }
  return preimage;
}

[[nodiscard]] Result<Digest256> hash_bytes(const ByteVector& bytes) {
  return sha256(std::span<const std::byte>(bytes));
}

[[nodiscard]] bool valid_stage(StageTag stage) noexcept {
  const std::uint16_t value = stage_tag_value(stage);
  return value >= stage_tag_value(StageTag::initial_joint_atom) &&
         value <= stage_tag_value(StageTag::surrogate_build_final);
}

[[nodiscard]] Result<Component> utf8_component(std::string_view text) {
  if (!is_valid_utf8(text)) {
    return Result<Component>::failure(rng_diagnostic(
        "invalid_rng_utf8_component",
        "an RNG instance-key text component is not valid UTF-8"));
  }
  return Result<Component>::success(
      Component{ComponentType::utf8, string_payload(text)});
}

[[nodiscard]] Component raw_digest_component(const Digest256& digest) {
  return Component{ComponentType::raw_digest, digest_payload(digest)};
}

[[nodiscard]] Component exact_state_component(const Digest256& digest) {
  return Component{ComponentType::exact_state_digest, digest_payload(digest)};
}

[[nodiscard]] Component big_nat_component(const BigNat& value) {
  return Component{ComponentType::big_nat, big_nat_payload(value)};
}

[[nodiscard]] Component typed_label_component(const TypedLabel& value) {
  return Component{ComponentType::typed_label, typed_label_payload(value)};
}

[[nodiscard]] ByteVector physical_reference_preimage_impl(
    const Digest256& combined_input_digest,
    const BigNat& path_or_replication_id) {
  const std::array<Component, 3> components{
      raw_digest_component(combined_input_digest),
      Component{ComponentType::utf8, string_payload("physical_reference")},
      big_nat_component(path_or_replication_id)};
  return encode_instance_key_preimage(components);
}

[[nodiscard]] ByteVector temporal_path_preimage_impl(
    const Digest256& audited_framework_digest,
    const Digest256& reduced_initial_law_digest,
    const BigNat& path_or_replication_id) {
  const std::array<Component, 4> components{
      raw_digest_component(audited_framework_digest),
      raw_digest_component(reduced_initial_law_digest),
      Component{ComponentType::utf8, string_payload("temporal_path")},
      big_nat_component(path_or_replication_id)};
  return encode_instance_key_preimage(components);
}

[[nodiscard]] Result<ByteVector> estimator_preimage_impl(
    const Digest256& seal_digest,
    const Digest256& conditioning_state_digest,
    std::string_view estimator_id,
    const BigNat& replication_index) {
  auto estimator = utf8_component(estimator_id);
  if (!estimator) {
    return Result<ByteVector>::failure(estimator.error());
  }
  std::array<Component, 4> components{
      raw_digest_component(seal_digest),
      exact_state_component(conditioning_state_digest),
      std::move(estimator).value(), big_nat_component(replication_index)};
  return Result<ByteVector>::success(encode_instance_key_preimage(components));
}

[[nodiscard]] Result<ByteVector> internal_draw_preimage_impl(
    const Digest256& seal_digest,
    const Digest256& exact_state_or_cursor_digest,
    std::string_view branch_address) {
  auto branch = utf8_component(branch_address);
  if (!branch) {
    return Result<ByteVector>::failure(branch.error());
  }
  std::array<Component, 3> components{
      raw_digest_component(seal_digest),
      exact_state_component(exact_state_or_cursor_digest),
      std::move(branch).value()};
  return Result<ByteVector>::success(encode_instance_key_preimage(components));
}

[[nodiscard]] Result<ByteVector> surrogate_build_preimage_impl(
    const BuildIdentityDigest& build_identity_digest,
    std::string_view provider_id,
    std::string_view provider_version,
    const TypedLabel& target_or_group_identity,
    const BigNat& build_replication_or_probe_id) {
  auto provider = utf8_component(provider_id);
  if (!provider) {
    return Result<ByteVector>::failure(provider.error());
  }
  auto version = utf8_component(provider_version);
  if (!version) {
    return Result<ByteVector>::failure(version.error());
  }
  std::array<Component, 5> components{
      raw_digest_component(build_identity_digest.digest()),
      std::move(provider).value(), std::move(version).value(),
      typed_label_component(target_or_group_identity),
      big_nat_component(build_replication_or_probe_id)};
  return Result<ByteVector>::success(encode_instance_key_preimage(components));
}

template <typename NextWord>
[[nodiscard]] Result<testing::ScriptedCategoricalResult> sample_exact_impl(
    const NormalizedPmf& pmf, NextWord&& next_word) {
  const BigInt& denominator = pmf.integral_denominator().value();
  const auto& cumulative = pmf.cumulative_masses();
  if (pmf.size() == 0U || cumulative.size() != pmf.size() ||
      denominator <= 0 || cumulative.back().value() != denominator) {
    return Result<testing::ScriptedCategoricalResult>::failure(rng_diagnostic(
        "invalid_normalized_pmf",
        "the normalized PMF violates its immutable exact-mass invariant"));
  }

  BigInt accepted = 0;
  std::size_t consumed = 0;
  if (denominator == 1) {
    if (pmf.sampling_bit_width() != 0U ||
        pmf.sampling_limb_count() != 0U) {
      return Result<testing::ScriptedCategoricalResult>::failure(
          rng_diagnostic(
              "invalid_normalized_pmf_sampling_metadata",
              "a unit-denominator PMF must consume no sampling words"));
    }
  } else {
    const std::size_t denominator_bits =
        pmf.integral_denominator().bit_length();
    const bool is_power_of_two =
        (denominator & (denominator - 1)) == 0;
    const std::size_t expected_bit_count =
        denominator_bits - (is_power_of_two ? 1U : 0U);
    const std::size_t expected_limb_count =
        expected_bit_count / 64U +
        (expected_bit_count % 64U == 0U ? 0U : 1U);
    const std::size_t bit_count = pmf.sampling_bit_width();
    const std::size_t limb_count = pmf.sampling_limb_count();
    if (bit_count != expected_bit_count ||
        limb_count != expected_limb_count) {
      return Result<testing::ScriptedCategoricalResult>::failure(
          rng_diagnostic(
              "invalid_normalized_pmf_sampling_metadata",
              "the normalized PMF sampling-width metadata is inconsistent"));
    }
    const BigInt mask = (BigInt(1) << bit_count) - 1;

    for (;;) {
      BigInt candidate = 0;
      for (std::size_t limb = 0; limb < limb_count; ++limb) {
        const std::optional<std::uint64_t> word = next_word();
        if (!word.has_value()) {
          return Result<testing::ScriptedCategoricalResult>::failure(
              rng_diagnostic("rng_script_exhausted",
                             "the scripted RNG word source was exhausted"));
        }
        ++consumed;
        candidate |= BigInt(*word) << (limb * 64U);
      }
      candidate &= mask;
      if (candidate < denominator) {
        accepted = std::move(candidate);
        break;
      }
    }
  }

  const auto selected = std::find_if(
      cumulative.begin(), cumulative.end(), [&accepted](const BigNat& mass) {
        return mass.value() > accepted;
      });
  if (selected == cumulative.end()) {
    return Result<testing::ScriptedCategoricalResult>::failure(rng_diagnostic(
        "invalid_normalized_pmf_lookup",
        "the exact PMF cumulative masses do not cover the sampled integer"));
  }
  return Result<testing::ScriptedCategoricalResult>::success(
      testing::ScriptedCategoricalResult{
          static_cast<std::size_t>(std::distance(cumulative.begin(), selected)),
          consumed});
}

}  // namespace

class InstanceKeyFactory final {
 public:
  [[nodiscard]] static Result<InstanceKey> make(const ByteVector& preimage) {
    auto digest = hash_bytes(preimage);
    if (!digest) {
      return Result<InstanceKey>::failure(digest.error());
    }
    return Result<InstanceKey>::success(
        InstanceKey(std::move(digest).value()));
  }
};

class DeterministicRngTestAccess final {
 public:
  [[nodiscard]] static RngCheckpoint checkpoint_with_version(
      const RngCheckpoint& checkpoint, const std::uint32_t rng_version) {
    return RngCheckpoint(rng_version, checkpoint.stream_identity_,
                         checkpoint.state_words_, checkpoint.consumed_words_);
  }
};

std::array<std::byte, 44> BuildSeed::canonical_bytes() const noexcept {
  std::array<std::byte, 44> result{};
  std::size_t position = 0;
  const auto append = [&result, &position](std::uint64_t value,
                                            unsigned byte_count) {
    for (unsigned remaining = byte_count; remaining > 0U; --remaining) {
      const unsigned shift = (remaining - 1U) * 8U;
      result[position++] = static_cast<std::byte>((value >> shift) & 0xffU);
    }
  };
  append(kRngVersion, 4U);
  append(master_seed_.value(), 8U);
  for (const std::byte value : build_identity_digest_.digest().bytes()) {
    result[position++] = value;
  }
  return result;
}

Result<InstanceKey> make_physical_reference_instance_key(
    const Digest256& combined_input_digest,
    const BigNat& path_or_replication_id) {
  return InstanceKeyFactory::make(physical_reference_preimage_impl(
      combined_input_digest, path_or_replication_id));
}

std::vector<std::byte> testing::physical_reference_instance_key_preimage(
    const Digest256& combined_input_digest,
    const BigNat& path_or_replication_id) {
  return physical_reference_preimage_impl(combined_input_digest,
                                           path_or_replication_id);
}

Result<InstanceKey> make_temporal_path_instance_key(
    const Digest256& audited_framework_digest,
    const Digest256& reduced_initial_law_digest,
    const BigNat& path_or_replication_id) {
  return InstanceKeyFactory::make(temporal_path_preimage_impl(
      audited_framework_digest, reduced_initial_law_digest,
      path_or_replication_id));
}

std::vector<std::byte> testing::temporal_path_instance_key_preimage(
    const Digest256& audited_framework_digest,
    const Digest256& reduced_initial_law_digest,
    const BigNat& path_or_replication_id) {
  return temporal_path_preimage_impl(audited_framework_digest,
                                     reduced_initial_law_digest,
                                     path_or_replication_id);
}

Result<InstanceKey> make_estimator_instance_key(
    const Digest256& seal_digest,
    const Digest256& conditioning_state_digest,
    std::string_view estimator_id,
    const BigNat& replication_index) {
  auto preimage = estimator_preimage_impl(
      seal_digest, conditioning_state_digest, estimator_id,
      replication_index);
  if (!preimage) {
    return Result<InstanceKey>::failure(preimage.error());
  }
  return InstanceKeyFactory::make(preimage.value());
}

Result<std::vector<std::byte>> testing::estimator_instance_key_preimage(
    const Digest256& seal_digest,
    const Digest256& conditioning_state_digest,
    std::string_view estimator_id,
    const BigNat& replication_index) {
  return estimator_preimage_impl(seal_digest, conditioning_state_digest,
                                 estimator_id, replication_index);
}

Result<InstanceKey> make_internal_draw_instance_key(
    const Digest256& seal_digest,
    const Digest256& exact_state_or_cursor_digest,
    std::string_view branch_address) {
  auto preimage = internal_draw_preimage_impl(
      seal_digest, exact_state_or_cursor_digest, branch_address);
  if (!preimage) {
    return Result<InstanceKey>::failure(preimage.error());
  }
  return InstanceKeyFactory::make(preimage.value());
}

Result<std::vector<std::byte>> testing::internal_draw_instance_key_preimage(
    const Digest256& seal_digest,
    const Digest256& exact_state_or_cursor_digest,
    std::string_view branch_address) {
  return internal_draw_preimage_impl(seal_digest,
                                     exact_state_or_cursor_digest,
                                     branch_address);
}

Result<InstanceKey> make_surrogate_build_instance_key(
    const BuildIdentityDigest& build_identity_digest,
    std::string_view provider_id,
    std::string_view provider_version,
    const TypedLabel& target_or_group_identity,
    const BigNat& build_replication_or_probe_id) {
  auto preimage = surrogate_build_preimage_impl(
      build_identity_digest, provider_id, provider_version,
      target_or_group_identity, build_replication_or_probe_id);
  if (!preimage) {
    return Result<InstanceKey>::failure(preimage.error());
  }
  return InstanceKeyFactory::make(preimage.value());
}

Result<std::vector<std::byte>>
testing::surrogate_build_instance_key_preimage(
    const BuildIdentityDigest& build_identity_digest,
    std::string_view provider_id,
    std::string_view provider_version,
    const TypedLabel& target_or_group_identity,
    const BigNat& build_replication_or_probe_id) {
  return surrogate_build_preimage_impl(
      build_identity_digest, provider_id, provider_version,
      target_or_group_identity, build_replication_or_probe_id);
}

DeterministicRng::DeterministicRng(std::array<std::uint64_t, 4> state,
                                   Digest256 stream_identity,
                                   const StageTag derivation_stage)
    : state_(state),
      stream_identity_(std::move(stream_identity)),
      consumed_words_(std::uint64_t{0}),
      derivation_stage_(derivation_stage),
      active_(true),
      transaction_open_(false) {}

RngCheckpoint::RngCheckpoint(RngCheckpoint&& other)
    : rng_version_(other.rng_version_),
      stream_identity_(other.stream_identity_),
      state_words_(other.state_words_),
      consumed_words_(other.consumed_words_) {}

RngCheckpoint& RngCheckpoint::operator=(RngCheckpoint&& other) {
  if (this != &other) {
    rng_version_ = other.rng_version_;
    stream_identity_ = other.stream_identity_;
    state_words_ = other.state_words_;
    consumed_words_ = other.consumed_words_;
  }
  return *this;
}

void DeterministicRng::require_unpinned(const DeterministicRng& rng) {
  if (rng.transaction_open_) {
    throw std::logic_error(
        "cannot move a deterministic RNG while a transaction is open");
  }
}

DeterministicRng::DeterministicRng(DeterministicRng&& other)
    : state_((require_unpinned(other), other.state_)),
      stream_identity_(std::move(other.stream_identity_)),
      consumed_words_(std::move(other.consumed_words_)),
      derivation_stage_(other.derivation_stage_),
      active_(other.active_),
      transaction_open_(false) {
  other.state_.fill(0U);
  other.active_ = false;
}

DeterministicRng& DeterministicRng::operator=(
    DeterministicRng&& other) {
  if (this != &other) {
    require_unpinned(*this);
    require_unpinned(other);
    state_ = other.state_;
    stream_identity_ = std::move(other.stream_identity_);
    consumed_words_ = std::move(other.consumed_words_);
    derivation_stage_ = other.derivation_stage_;
    active_ = other.active_;
    transaction_open_ = false;
    other.state_.fill(0U);
    other.active_ = false;
  }
  return *this;
}

void DeterministicRng::require_active() const {
  if (!active_) {
    throw std::logic_error("attempted to use a moved-from deterministic RNG");
  }
}

std::uint64_t DeterministicRng::next_u64() {
  require_active();
  BigNat next_count = consumed_words_ + BigNat(std::uint64_t{1});
  auto next_state = state_;
  const std::uint64_t result =
      std::rotl(next_state[1] * std::uint64_t{5}, 7) * std::uint64_t{9};
  const std::uint64_t temporary = next_state[1] << 17U;
  next_state[2] ^= next_state[0];
  next_state[3] ^= next_state[1];
  next_state[1] ^= next_state[2];
  next_state[0] ^= next_state[3];
  next_state[2] ^= temporary;
  next_state[3] = std::rotl(next_state[3], 45);
  state_ = next_state;
  consumed_words_ = std::move(next_count);
  return result;
}

RngCheckpoint DeterministicRng::checkpoint() const {
  require_active();
  return RngCheckpoint(kRngVersion, stream_identity_, state_, consumed_words_);
}

Result<void> DeterministicRng::restore(const RngCheckpoint& checkpoint_value) {
  require_active();
  if (checkpoint_value.rng_version_ != kRngVersion) {
    return Result<void>::failure(rng_diagnostic(
        "rng_checkpoint_version_mismatch",
        "the RNG checkpoint version does not match this engine"));
  }
  if (checkpoint_value.stream_identity_ != stream_identity_) {
    return Result<void>::failure(rng_diagnostic(
        "rng_checkpoint_stream_mismatch",
        "the RNG checkpoint belongs to a different derived stream"));
  }
  RngCheckpoint replacement = checkpoint_value;
  restore_unchecked(replacement);
  return Result<void>::success();
}

void DeterministicRng::restore_unchecked(RngCheckpoint& checkpoint_value) noexcept {
  if (!active_ || checkpoint_value.rng_version_ != kRngVersion ||
      checkpoint_value.stream_identity_ != stream_identity_) {
    std::terminate();
  }
  state_ = checkpoint_value.state_words_;
  using std::swap;
  swap(consumed_words_, checkpoint_value.consumed_words_);
}

void DeterministicRng::begin_transaction() {
  require_active();
  if (transaction_open_) {
    throw std::logic_error(
        "nested deterministic RNG transactions are not supported");
  }
  transaction_open_ = true;
}

void DeterministicRng::end_transaction() noexcept {
  if (!transaction_open_) {
    std::terminate();
  }
  transaction_open_ = false;
}

RngTransaction::RngTransaction(DeterministicRng& rng)
    : rng_(&rng), checkpoint_(rng.checkpoint()), committed_(false) {
  rng_->begin_transaction();
}

RngTransaction::~RngTransaction() noexcept {
  if (!committed_) {
    rng_->restore_unchecked(checkpoint_);
  }
  rng_->end_transaction();
}

std::vector<std::byte> testing::rng_derivation_preimage(
    MasterSeed master_seed, StageTag stage, const InstanceKey& instance_key) {
  if (!valid_stage(stage)) {
    throw std::invalid_argument("invalid version-1 RNG stage tag");
  }
  ByteVector preimage;
  append_ascii(preimage, kStreamDomain);
  preimage.push_back(std::byte{0});
  append_u32be(preimage, kRngVersion);
  append_u64be(preimage, master_seed.value());
  append_u16be(preimage, stage_tag_value(stage));
  append_bytes(preimage, instance_key.digest().bytes());
  return preimage;
}

std::array<std::uint64_t, 4> testing::decode_rng_state(
    const Digest256& digest) noexcept {
  std::array<std::uint64_t, 4> state{};
  const auto bytes = digest.bytes();
  for (std::size_t word = 0; word < state.size(); ++word) {
    std::uint64_t value = 0;
    for (std::size_t offset = 0; offset < 8U; ++offset) {
      value = (value << 8U) |
              static_cast<std::uint64_t>(
                  std::to_integer<std::uint8_t>(bytes[word * 8U + offset]));
    }
    state[word] = value;
  }
  if (std::all_of(state.begin(), state.end(),
                  [](std::uint64_t word) { return word == 0U; })) {
    state = {0x9e3779b97f4a7c15ULL, 0U, 0U, 0U};
  }
  return state;
}

RngCheckpoint testing::checkpoint_with_version(
    const RngCheckpoint& checkpoint, const std::uint32_t rng_version) {
  return DeterministicRngTestAccess::checkpoint_with_version(checkpoint,
                                                              rng_version);
}

DeterministicRng derive_rng_stream(MasterSeed master_seed, StageTag stage,
                                   const InstanceKey& instance_key) {
  const ByteVector preimage =
      testing::rng_derivation_preimage(master_seed, stage, instance_key);
  auto digest_result = hash_bytes(preimage);
  if (!digest_result) {
    throw std::logic_error("SHA-256 rejected a bounded RNG derivation preimage");
  }
  Digest256 digest = std::move(digest_result).value();
  const auto state = testing::decode_rng_state(digest);
  return DeterministicRng(state, std::move(digest), stage);
}

std::size_t sample_categorical(const NormalizedPmf& pmf,
                               DeterministicRng& rng) {
  auto result = sample_exact_impl(pmf, [&rng]() {
    return std::optional<std::uint64_t>(rng.next_u64());
  });
  if (!result) {
    throw std::logic_error(result.error().code);
  }
  return result.value().index;
}

Result<testing::ScriptedCategoricalResult>
testing::sample_categorical_with_script(
    const NormalizedPmf& pmf, std::span<const std::uint64_t> words) {
  std::size_t position = 0;
  return sample_exact_impl(pmf, [&words, &position]() -> std::optional<std::uint64_t> {
    if (position == words.size()) {
      return std::nullopt;
    }
    return words[position++];
  });
}

}  // namespace mwperf
