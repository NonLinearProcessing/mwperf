#include "mwperf/arrival/registry.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <exception>
#include <limits>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "core_internal.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/resolved_instance.hpp"

namespace mwperf {
namespace {

template <class... Callables>
struct Overloaded : Callables... {
  using Callables::operator()...;
};
template <class... Callables>
Overloaded(Callables...) -> Overloaded<Callables...>;

[[nodiscard]] Diagnostic internal_error(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic unavailable_error(std::string code,
                                           ArrivalFamily family,
                                           std::string_view checkpoint) {
  return Diagnostic{
      .category = DiagnosticCategory::unavailable,
      .code = std::move(code),
      .message = "the exact " + std::string(to_string(family)) +
                 " arrival backend is pending checkpoint " +
                 std::string(checkpoint),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {"the C09 registry does not substitute another arrival law"},
  };
}

[[nodiscard]] Diagnostic unsupported_arrival(
    const UnsupportedCompatibilityArrival& arrival) {
  std::optional<std::string> path;
  std::vector<std::string> notes;
  if (arrival.provenance.location.has_value()) {
    path = arrival.provenance.location->authored_path;
    notes.push_back("line " +
                    std::to_string(arrival.provenance.location->line) +
                    ", column " +
                    std::to_string(arrival.provenance.location->column));
  }
  return Diagnostic{
      .category = DiagnosticCategory::unavailable,
      .code = "unsupported_arrival_family",
      .message = "the analytical framework accepts only registered native "
                 "count-law arrival families",
      .authored_path = std::move(path),
      .json_pointer = arrival.provenance.json_pointer,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic allocation_error(std::string phase) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "arrival_compilation_allocation_failure",
      .message = "memory allocation failed while " + std::move(phase),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic exception_error(std::string phase,
                                         const std::exception& error) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = "arrival_compilation_exception",
      .message = "an exception interrupted " + std::move(phase),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {error.what()},
  };
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 56U;; shift -= 8U) {
    output.push_back(
        static_cast<std::byte>((value >> shift) & UINT64_C(0xff)));
    if (shift == 0U) {
      break;
    }
  }
}

void append_bytes(std::vector<std::byte>& output,
                  const std::span<const std::byte> bytes) {
  append_u64(output, static_cast<std::uint64_t>(bytes.size()));
  output.insert(output.end(), bytes.begin(), bytes.end());
}

void append_string(std::vector<std::byte>& output, const std::string& value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  for (const char character : value) {
    output.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_rational(std::vector<std::byte>& output,
                     const ExactRational& value) {
  append_string(output, value.numerator_decimal());
  append_string(output, value.denominator_decimal());
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> magnitude =
      value.canonical_magnitude_bytes();
  append_u64(output, static_cast<std::uint64_t>(magnitude.size()));
  for (const std::uint8_t byte : magnitude) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

void append_rational_sequence(
    std::vector<std::byte>& output,
    const std::span<const ExactRational> values) {
  append_u64(output, static_cast<std::uint64_t>(values.size()));
  for (const ExactRational& value : values) {
    append_rational(output, value);
  }
}

void append_big_nat_sequence(std::vector<std::byte>& output,
                             const std::span<const BigNat> values) {
  append_u64(output, static_cast<std::uint64_t>(values.size()));
  for (const BigNat& value : values) {
    append_big_nat(output, value);
  }
}

// The common registry owns this envelope rather than trusting a family child
// to remember the rows it was shown. It is also the byte string passed to the
// downstream law fingerprint, so an authored mass residual or significant row
// reordering changes the immutable law identity. Numerical long-double images
// and representation budgets are deliberately excluded from mathematical
// identity; all exact sampling data and the signed normalization delta remain.
[[nodiscard]] std::vector<std::byte> bind_normalized_rows_to_identity(
    const std::span<const std::byte> child_canonical_law_data,
    const std::span<const NormalizedArrivalRow> rows) {
  static constexpr std::string_view kEnvelopeDomain =
      "mwperf.c09.compiled_arrival_with_normalized_rows.v1";
  std::vector<std::byte> encoded;
  append_u64(encoded, static_cast<std::uint64_t>(kEnvelopeDomain.size()));
  for (const char character : kEnvelopeDomain) {
    encoded.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
  append_bytes(encoded, child_canonical_law_data);
  append_u64(encoded, static_cast<std::uint64_t>(rows.size()));
  for (std::size_t ordinal = 0U; ordinal < rows.size(); ++ordinal) {
    const NormalizedArrivalRow& row = rows[ordinal];
    append_u64(encoded, static_cast<std::uint64_t>(ordinal));
    encoded.push_back(static_cast<std::byte>(row.kind));
    append_u64(encoded, static_cast<std::uint64_t>(row.source_ordinal));
    append_u64(encoded, static_cast<std::uint64_t>(row.state_ordinal));

    const NormalizedPmf& pmf = row.pmf;
    append_u64(encoded,
               static_cast<std::uint64_t>(pmf.authored_probabilities().size()));
    for (const AuthoredProbability& probability :
         pmf.authored_probabilities()) {
      append_rational(encoded, probability.exact_value());
    }
    append_rational(encoded, pmf.authored_sum());
    append_rational(encoded, pmf.normalization_delta());
    append_rational_sequence(encoded, pmf.normalized_weights());
    append_big_nat_sequence(encoded, pmf.integral_masses());
    append_big_nat_sequence(encoded, pmf.cumulative_masses());
    append_big_nat(encoded, pmf.integral_denominator());
    append_u64(encoded,
               static_cast<std::uint64_t>(pmf.sampling_bit_width()));
    append_u64(encoded,
               static_cast<std::uint64_t>(pmf.sampling_limb_count()));
  }
  return encoded;
}

[[nodiscard]] Result<void> append_normalized_row(
    std::vector<NormalizedArrivalRow>& rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::size_t state_ordinal,
    const std::span<const AuthoredProbability> probabilities) {
  auto normalized = validate_and_normalize_pmf(
      probabilities, physical_pmf_tolerance());
  if (!normalized) {
    return Result<void>::failure(std::move(normalized.error()));
  }
  rows.push_back(NormalizedArrivalRow{
      .kind = kind,
      .source_ordinal = source_ordinal,
      .state_ordinal = state_ordinal,
      .pmf = std::move(normalized).value(),
  });
  return Result<void>::success();
}

template <typename Record, typename Projection>
[[nodiscard]] Result<void> normalize_record_row(
    std::vector<NormalizedArrivalRow>& rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::size_t state_ordinal, const std::span<const Record> records,
    Projection&& probability_of) {
  std::vector<AuthoredProbability> probabilities;
  probabilities.reserve(records.size());
  for (const Record& record : records) {
    probabilities.push_back(probability_of(record));
  }
  return append_normalized_row(rows, kind, source_ordinal, state_ordinal,
                               probabilities);
}

[[nodiscard]] Result<void> normalize_initial_state_row(
    std::vector<NormalizedArrivalRow>& rows,
    const AuthoredInitialState& initial,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal) {
  const auto* distribution =
      std::get_if<InitialStateDistribution>(&initial);
  if (distribution == nullptr) {
    return Result<void>::success();
  }
  return normalize_record_row(
      rows, kind, source_ordinal, 0U,
      std::span<const StateProbability>(distribution->distribution.value),
      [](const StateProbability& mass) { return mass.probability.value; });
}

[[nodiscard]] Result<void> normalize_interarrival_rows(
    std::vector<NormalizedArrivalRow>& rows,
    const AuthoredInterarrival& interarrival,
    const std::size_t source_ordinal) {
  return std::visit(
      Overloaded{
          [](const DeterministicInterarrival&) {
            return Result<void>::success();
          },
          [&](const FinitePmfInterarrival& finite) {
            return normalize_record_row(
                rows, ArrivalCategoricalRowKind::finite_interarrival,
                source_ordinal, 0U,
                std::span<const GapProbability>(finite.outcomes.value),
                [](const GapProbability& mass) {
                  return mass.probability.value;
                });
          },
          [&](const GeometricGridInterarrival& geometric) {
            std::vector<AuthoredProbability> probabilities;
            probabilities.reserve(2U);
            probabilities.push_back(geometric.p.value);
            auto complement = AuthoredProbability::from_exact(
                ExactRational::one() - geometric.p.value.exact_value());
            if (!complement) {
              return Result<void>::failure(std::move(complement.error()));
            }
            probabilities.push_back(std::move(complement).value());
            return append_normalized_row(
                rows, ArrivalCategoricalRowKind::geometric_trial,
                source_ordinal, 0U, probabilities);
          },
      },
      interarrival);
}

template <typename StateRecord, typename ProbabilityRecord,
          typename StateProjection, typename ProbabilityProjection>
[[nodiscard]] Result<void> normalize_state_conditioned_rows(
    std::vector<NormalizedArrivalRow>& rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::span<const StateRecord> declared_states,
    const std::span<const ProbabilityRecord> records,
    StateProjection&& record_state,
    ProbabilityProjection&& record_probability) {
  std::vector<std::string> row_keys;
  row_keys.reserve(declared_states.size() + records.size());
  for (const StateRecord& state : declared_states) {
    // A malformed duplicate declaration is diagnosed by the owning family
    // compiler, but it must not cause the common C09 boundary to normalize
    // the same authored categorical row twice.
    if (std::ranges::find(row_keys, state.value) == row_keys.end()) {
      row_keys.push_back(state.value);
    }
  }
  // Invalid/unknown state rows remain significant input. Normalizing them
  // here preserves the C09 exactly-once rule; the C11 child later diagnoses
  // that their state key is outside the declared domain.
  for (const ProbabilityRecord& record : records) {
    const std::string& key = record_state(record).value;
    if (std::ranges::find(row_keys, key) == row_keys.end()) {
      row_keys.push_back(key);
    }
  }

  for (std::size_t state_ordinal = 0U; state_ordinal < row_keys.size();
       ++state_ordinal) {
    std::vector<AuthoredProbability> probabilities;
    for (const ProbabilityRecord& record : records) {
      if (record_state(record).value == row_keys[state_ordinal]) {
        probabilities.push_back(record_probability(record));
      }
    }
    // A declared state without records has no authored categorical row.
    // Completeness is a C11 family diagnostic, not a synthetic C09 empty PMF.
    if (probabilities.empty()) {
      continue;
    }
    auto result = append_normalized_row(rows, kind, source_ordinal,
                                        state_ordinal, probabilities);
    if (!result) {
      return result;
    }
  }
  return Result<void>::success();
}

struct PreparedRows final {
  ArrivalFamily family;
  std::vector<NormalizedArrivalRow> rows;
};

[[nodiscard]] Result<PreparedRows> prepare_arrival_rows(
    const AuthoredArrivalConfig& authored) {
  return std::visit(
      Overloaded{
          [](const DeterministicTraceArrival&) {
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::deterministic_trace, {}});
          },
          [](const PeriodicGlobalPhaseArrival&) {
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::periodic_global_phase, {}});
          },
          [](const PeriodicSourceDelaysArrival&) {
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::periodic_source_delays, {}});
          },
          [](const IndependentMarkedRenewalArrival& arrival) {
            std::vector<NormalizedArrivalRow> rows;
            for (std::size_t source_ordinal = 0U;
                 source_ordinal < arrival.sources.value.size();
                 ++source_ordinal) {
              const MarkedRenewalSource& source =
                  arrival.sources.value[source_ordinal];
              auto result = std::visit(
                  Overloaded{
                      [&](const FactorizedRenewalSource& factorized) {
                        auto gap = normalize_interarrival_rows(
                            rows, factorized.interarrival.value,
                            source_ordinal);
                        if (!gap) {
                          return gap;
                        }
                        return normalize_record_row(
                            rows, ArrivalCategoricalRowKind::destination,
                            source_ordinal, 0U,
                            std::span<const DestinationProbability>(
                                factorized.destination_pmf.value),
                            [](const DestinationProbability& mass) {
                              return mass.probability.value;
                            });
                      },
                      [&](const JointRenewalSource& joint) {
                        return normalize_record_row(
                            rows,
                            ArrivalCategoricalRowKind::joint_gap_destination,
                            source_ordinal, 0U,
                            std::span<const JointRenewalMass>(
                                joint.joint_pmf.value),
                            [](const JointRenewalMass& mass) {
                              return mass.probability.value;
                            });
                      },
                  },
                  source);
              if (!result) {
                return Result<PreparedRows>::failure(
                    std::move(result.error()));
              }
            }
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::independent_marked_renewal,
                std::move(rows)});
          },
          [](const IndependentPrivateMarkovRenewalArrival& arrival) {
            std::vector<NormalizedArrivalRow> rows;
            for (std::size_t source_ordinal = 0U;
                 source_ordinal < arrival.sources.value.size();
                 ++source_ordinal) {
              const PrivateMarkovRenewalSource& source =
                  arrival.sources.value[source_ordinal];
              auto initial = normalize_initial_state_row(
                  rows, source.initial.value,
                  ArrivalCategoricalRowKind::private_initial_state,
                  source_ordinal);
              if (!initial) {
                return Result<PreparedRows>::failure(
                    std::move(initial.error()));
              }
              auto transitions = normalize_state_conditioned_rows(
                  rows, ArrivalCategoricalRowKind::private_transition,
                  source_ordinal,
                  std::span<const NormalizedToken>(source.states.value),
                  std::span<const StateTransition>(source.transitions.value),
                  [](const StateTransition& transition)
                      -> const NormalizedToken& { return transition.state; },
                  [](const StateTransition& transition) {
                    return transition.probability.value;
                  });
              if (!transitions) {
                return Result<PreparedRows>::failure(
                    std::move(transitions.error()));
              }
              auto destinations = normalize_record_row(
                  rows, ArrivalCategoricalRowKind::destination,
                  source_ordinal, 0U,
                  std::span<const DestinationProbability>(
                      source.destination_pmf.value),
                  [](const DestinationProbability& mass) {
                    return mass.probability.value;
                  });
              if (!destinations) {
                return Result<PreparedRows>::failure(
                    std::move(destinations.error()));
              }
            }
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::independent_private_markov_renewal,
                std::move(rows)});
          },
          [](const SharedJointRoundMarkovRenewalArrival& arrival) {
            std::vector<NormalizedArrivalRow> rows;
            auto initial = normalize_initial_state_row(
                rows, arrival.initial.value,
                ArrivalCategoricalRowKind::shared_initial_state, 0U);
            if (!initial) {
              return Result<PreparedRows>::failure(
                  std::move(initial.error()));
            }
            auto outcomes = normalize_state_conditioned_rows(
                rows, ArrivalCategoricalRowKind::shared_outcome, 0U,
                std::span<const NormalizedToken>(arrival.states.value),
                std::span<const SharedOutcome>(arrival.outcomes.value),
                [](const SharedOutcome& outcome) -> const NormalizedToken& {
                  return outcome.state;
                },
                [](const SharedOutcome& outcome) {
                  return outcome.probability.value;
                });
            if (!outcomes) {
              return Result<PreparedRows>::failure(
                  std::move(outcomes.error()));
            }
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::shared_joint_round_markov_renewal,
                std::move(rows)});
          },
          [](const IidIndependentBernoulliArrival&) {
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::iid_independent_bernoulli, {}});
          },
          [](const IidCountTableArrival&) {
            return Result<PreparedRows>::success(
                PreparedRows{ArrivalFamily::iid_count_table, {}});
          },
          [](const IidIndependentPoissonArrival&) {
            return Result<PreparedRows>::success(PreparedRows{
                ArrivalFamily::iid_independent_poisson, {}});
          },
          [](const IidMixedPoissonArrival&) {
            return Result<PreparedRows>::success(
                PreparedRows{ArrivalFamily::iid_mixed_poisson, {}});
          },
          [](const UnsupportedCompatibilityArrival& arrival) {
            return Result<PreparedRows>::failure(
                unsupported_arrival(arrival));
          },
      },
      authored.value);
}

[[nodiscard]] std::size_t family_slot(const ArrivalFamily family) {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return 0U;
    case ArrivalFamily::periodic_global_phase:
      return 1U;
    case ArrivalFamily::periodic_source_delays:
      return 2U;
    case ArrivalFamily::independent_marked_renewal:
      return 3U;
    case ArrivalFamily::independent_private_markov_renewal:
      return 4U;
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return 5U;
    case ArrivalFamily::iid_independent_bernoulli:
      return 6U;
    case ArrivalFamily::iid_count_table:
      return 7U;
    case ArrivalFamily::iid_independent_poisson:
      return 8U;
    case ArrivalFamily::iid_mixed_poisson:
      return 9U;
  }
  return std::numeric_limits<std::size_t>::max();
}

[[nodiscard]] detail::ArrivalBackendCompiler pending_compiler(
    const ArrivalFamily family, std::string code,
    std::string_view checkpoint) {
  return [family, code = std::move(code),
          checkpoint = std::string(checkpoint)](
             const PreparedArrivalCompilation&) {
    return Result<detail::CompiledArrivalProduct>::failure(
        unavailable_error(code, family, checkpoint));
  };
}

}  // namespace

namespace detail {

const ArrivalBackendRegistry& c09_pending_arrival_registry() {
  static const ArrivalBackendRegistry registry{{
      ArrivalBackendSlot{
          ArrivalFamily::deterministic_trace,
          pending_compiler(
              ArrivalFamily::deterministic_trace,
              "arrival_backend_pending_c10_deterministic_trace", "C10")},
      ArrivalBackendSlot{
          ArrivalFamily::periodic_global_phase,
          pending_compiler(
              ArrivalFamily::periodic_global_phase,
              "arrival_backend_pending_c10_periodic_global_phase", "C10")},
      ArrivalBackendSlot{
          ArrivalFamily::periodic_source_delays,
          pending_compiler(
              ArrivalFamily::periodic_source_delays,
              "arrival_backend_pending_c10_periodic_source_delays", "C10")},
      ArrivalBackendSlot{
          ArrivalFamily::independent_marked_renewal,
          pending_compiler(
              ArrivalFamily::independent_marked_renewal,
              "arrival_backend_pending_c11_independent_marked_renewal",
              "C11")},
      ArrivalBackendSlot{
          ArrivalFamily::independent_private_markov_renewal,
          pending_compiler(
              ArrivalFamily::independent_private_markov_renewal,
              "arrival_backend_pending_c11_independent_private_markov_renewal",
              "C11")},
      ArrivalBackendSlot{
          ArrivalFamily::shared_joint_round_markov_renewal,
          pending_compiler(
              ArrivalFamily::shared_joint_round_markov_renewal,
              "arrival_backend_pending_c11_shared_joint_round_markov_renewal",
              "C11")},
      ArrivalBackendSlot{
          ArrivalFamily::iid_independent_bernoulli,
          pending_compiler(
              ArrivalFamily::iid_independent_bernoulli,
              "arrival_backend_pending_cp09_iid_independent_bernoulli",
              "CP09")},
      ArrivalBackendSlot{
          ArrivalFamily::iid_count_table,
          pending_compiler(ArrivalFamily::iid_count_table,
                           "arrival_backend_pending_cp09_iid_count_table",
                           "CP09")},
      ArrivalBackendSlot{
          ArrivalFamily::iid_independent_poisson,
          pending_compiler(
              ArrivalFamily::iid_independent_poisson,
              "arrival_backend_pending_cp09_iid_independent_poisson",
              "CP09")},
      ArrivalBackendSlot{
          ArrivalFamily::iid_mixed_poisson,
          pending_compiler(ArrivalFamily::iid_mixed_poisson,
                           "arrival_backend_pending_cp09_iid_mixed_poisson",
                           "CP09")},
  }};
  return registry;
}

Result<CompiledArrivalLaw> compile_arrival_law_with_registry(
    const AuthoredArrivalConfig& authored, const QueueCatalog& queues,
    const ArrivalBackendRegistry& registry) {
  try {
    auto prepared = prepare_arrival_rows(authored);
    if (!prepared) {
      return Result<CompiledArrivalLaw>::failure(
          std::move(prepared.error()));
    }

    const std::array<ArrivalFamily, 10U> canonical_order{
        ArrivalFamily::deterministic_trace,
        ArrivalFamily::periodic_global_phase,
        ArrivalFamily::periodic_source_delays,
        ArrivalFamily::independent_marked_renewal,
        ArrivalFamily::independent_private_markov_renewal,
        ArrivalFamily::shared_joint_round_markov_renewal,
        ArrivalFamily::iid_independent_bernoulli,
        ArrivalFamily::iid_count_table,
        ArrivalFamily::iid_independent_poisson,
        ArrivalFamily::iid_mixed_poisson,
    };
    for (std::size_t index = 0U; index < registry.size(); ++index) {
      if (registry[index].family != canonical_order[index] ||
          !registry[index].compile) {
        return Result<CompiledArrivalLaw>::failure(internal_error(
            "arrival_registry_slot_mismatch",
            "the fixed C09 arrival registry has a missing, reordered, or "
            "mislabeled canonical slot",
            {"slot " + std::to_string(index)}));
      }
    }

    const std::size_t slot = family_slot(prepared.value().family);
    if (slot >= registry.size()) {
      return Result<CompiledArrivalLaw>::failure(internal_error(
          "arrival_registry_family_out_of_range",
          "the selected arrival family has no fixed registry slot"));
    }
    const PreparedArrivalCompilation request{
        .authored = authored,
        .queues = queues,
        .normalized_rows = prepared.value().rows,
    };
    auto compiled = registry[slot].compile(request);
    if (!compiled) {
      return Result<CompiledArrivalLaw>::failure(
          std::move(compiled.error()));
    }
    if (compiled.value().family != prepared.value().family) {
      return Result<CompiledArrivalLaw>::failure(internal_error(
          "arrival_backend_family_mismatch",
          "an arrival compiler returned a product for another canonical "
          "family",
          {"requested " + std::string(to_string(prepared.value().family)),
           "returned " + std::string(to_string(compiled.value().family))}));
    }
    compiled.value().canonical_law_data = bind_normalized_rows_to_identity(
        compiled.value().canonical_law_data, prepared.value().rows);
    // Overwrite rather than append: the common boundary is authoritative and
    // a child-provided copy (including a reordered or incomplete one) must not
    // enter the immutable compiled law.
    compiled.value().normalized_rows = std::move(prepared.value().rows);
    return publish_compiled_arrival_law(queues,
                                        std::move(compiled).value());
  } catch (const std::bad_alloc&) {
    return Result<CompiledArrivalLaw>::failure(
        allocation_error("compiling an arrival law"));
  } catch (const std::exception& error) {
    return Result<CompiledArrivalLaw>::failure(
        exception_error("compiling an arrival law", error));
  } catch (...) {
    return Result<CompiledArrivalLaw>::failure(internal_error(
        "arrival_compilation_exception",
        "a nonstandard exception interrupted arrival-law compilation"));
  }
}

}  // namespace detail

Result<CompiledArrivalLaw> detail::publish_compiled_arrival_law(
    const QueueCatalog& queues, CompiledArrivalProduct product) {
  return ArrivalCoreAccess::publish(queues, std::move(product));
}

Result<CompiledArrivalLaw> compile_arrival_law(
    const AuthoredArrivalConfig& authored, const QueueCatalog& queues) {
  // Acquiring the composed C11 table performs its one-time immutable
  // std::function copies.  Keep that allocation inside the same Result
  // boundary as family compilation so even first-use failure cannot escape
  // the arrival ABI as an exception.
  try {
    return detail::compile_arrival_law_with_registry(
        authored, queues, detail::c11_arrival_registry());
  } catch (const std::bad_alloc&) {
    return Result<CompiledArrivalLaw>::failure(
        allocation_error("initializing the C11 arrival registry"));
  } catch (const std::exception& error) {
    return Result<CompiledArrivalLaw>::failure(
        exception_error("initializing the C11 arrival registry", error));
  } catch (...) {
    return Result<CompiledArrivalLaw>::failure(internal_error(
        "arrival_registry_initialization_exception",
        "a nonstandard exception interrupted C11 arrival-registry "
        "initialization"));
  }
}

std::span<const NormalizedArrivalRow> normalized_arrival_rows(
    const CompiledArrivalLaw& law) noexcept {
  const auto& core = detail::ArrivalCoreAccess::law_core(law);
  if (!core) {
    return {};
  }
  return core->normalized_rows;
}

#if defined(MWPERF_C09_TEST_SEAMS)
namespace testing {

std::span<const NormalizedArrivalRow>
normalized_arrival_rows_for_testing(const CompiledArrivalLaw& law) noexcept {
  return normalized_arrival_rows(law);
}

}  // namespace testing
#endif

}  // namespace mwperf
