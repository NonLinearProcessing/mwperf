#include "mwperf/arrival/registry.hpp"

#include <cstddef>

namespace mwperf::detail {

const ArrivalBackendRegistry& c10_arrival_registry() {
  // Begin with the immutable C09 baseline so C11's three unavailable routes
  // (including their versioned diagnostics) remain byte-for-byte the same.
  // The returned table itself is immutable and is initialized exactly once;
  // there is no mutable registration state or static-initializer side effect.
  static const ArrivalBackendRegistry registry = [] {
    ArrivalBackendRegistry composed = c09_pending_arrival_registry();
    composed[0U].compile = compile_deterministic_trace_product;
    composed[1U].compile = compile_global_phase_periodic_product;
    composed[2U].compile = compile_source_delay_periodic_product;
    return composed;
  }();
  return registry;
}

}  // namespace mwperf::detail
