#include "mwperf/arrival/types.hpp"

#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <map>
#include <new>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic input_error(std::string code, std::string message,
                                     std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::input_validation,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] Diagnostic allocation_error() {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "arrival_aggregation_allocation_failure",
      .message =
          "memory allocation failed while aggregating an arrival batch",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic representation_error() {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = "arrival_aggregation_representation_failure",
      .message =
          "the aggregated arrival batch exceeds a host container limit",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] Diagnostic invariant_error() {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = "arrival_aggregation_invariant_failure",
      .message =
          "arrival aggregation raised an unexpected implementation failure",
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] bool is_valid_family(const ArrivalFamily family) noexcept {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
    case ArrivalFamily::periodic_global_phase:
    case ArrivalFamily::periodic_source_delays:
    case ArrivalFamily::independent_marked_renewal:
    case ArrivalFamily::independent_private_markov_renewal:
    case ArrivalFamily::shared_joint_round_markov_renewal:
    case ArrivalFamily::iid_independent_bernoulli:
    case ArrivalFamily::iid_count_table:
    case ArrivalFamily::iid_independent_poisson:
    case ArrivalFamily::iid_mixed_poisson:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_timing(const TimingConvention timing) noexcept {
  switch (timing) {
    case TimingConvention::early_service_late_admission:
      return true;
  }
  return false;
}

[[nodiscard]] std::optional<Diagnostic> validate_binding(
    const ArrivalBinding& binding) {
  if (!is_valid_family(binding.family)) {
    return input_error("arrival_binding_invalid_family",
                       "an arrival atom has an invalid family binding");
  }
  if (!is_valid_timing(binding.timing)) {
    return input_error("arrival_binding_invalid_timing",
                       "an arrival atom has an invalid timing binding");
  }
  if (binding.queue_cardinality == 0U) {
    return input_error(
        "arrival_binding_empty_catalog",
        "an arrival atom cannot be bound to an empty queue catalog");
  }
  return std::nullopt;
}

[[nodiscard]] std::optional<Diagnostic> validate_atom(
    const ArrivalAtom& atom) {
  if (auto binding_error = validate_binding(atom.binding());
      binding_error.has_value()) {
    return binding_error;
  }
  if (atom.queue().ordinal() >= atom.binding().queue_cardinality) {
    return input_error(
        "arrival_atom_queue_out_of_range",
        "an arrival atom queue is outside its bound dense catalog",
        {"queue ordinal " + std::to_string(atom.queue().ordinal()),
         "queue cardinality " +
             std::to_string(atom.binding().queue_cardinality)});
  }
  if (atom.count().is_zero()) {
    return input_error("arrival_atom_zero_count",
                       "an arrival atom count must be strictly positive");
  }
  return std::nullopt;
}

[[nodiscard]] const BigNat& maximum_arrival_count(
    const ArrivalFamily family) {
  static const BigNat legacy_maximum(static_cast<std::uint64_t>(
      std::numeric_limits<std::int64_t>::max()));
  static const BigNat count_table_maximum(
      std::numeric_limits<std::uint64_t>::max());
  return family == ArrivalFamily::iid_count_table ? count_table_maximum
                                                   : legacy_maximum;
}

}  // namespace

Result<ArrivalAtom> ArrivalAtom::make(DenseQueueIndex queue, BigNat count,
                                      ArrivalBinding binding) {
  try {
    ArrivalAtom atom(queue, std::move(count), std::move(binding));
    if (auto error = validate_atom(atom); error.has_value()) {
      return Result<ArrivalAtom>::failure(std::move(*error));
    }
    return Result<ArrivalAtom>::success(std::move(atom));
  } catch (const std::bad_alloc&) {
    return Result<ArrivalAtom>::failure(allocation_error());
  } catch (const std::length_error&) {
    return Result<ArrivalAtom>::failure(representation_error());
  } catch (const std::exception&) {
    return Result<ArrivalAtom>::failure(invariant_error());
  } catch (...) {
    return Result<ArrivalAtom>::failure(invariant_error());
  }
}

ArrivalBatch ArrivalBatch::empty() {
  return ArrivalBatch(std::nullopt, {});
}

Result<ArrivalBatch> aggregate_arrival_batch(
    const std::span<const ArrivalAtom> atoms) {
  try {
    if (atoms.empty()) {
      return Result<ArrivalBatch>::success(ArrivalBatch::empty());
    }

    const ArrivalBinding& binding = atoms.front().binding();
    if (auto error = validate_binding(binding); error.has_value()) {
      return Result<ArrivalBatch>::failure(std::move(*error));
    }

    bool canonical_unique_order = true;
    for (std::size_t index = 0U; index < atoms.size(); ++index) {
      const ArrivalAtom& atom = atoms[index];
      if (auto error = validate_atom(atom); error.has_value()) {
        return Result<ArrivalBatch>::failure(std::move(*error));
      }
      if (!(atom.binding() == binding)) {
        return Result<ArrivalBatch>::failure(input_error(
            "arrival_atom_binding_mismatch",
            "all atoms in one arrival batch must share one exact law and "
            "catalog binding"));
      }
      if (index != 0U &&
          !(atoms[index - 1U].queue() < atom.queue())) {
        canonical_unique_order = false;
      }
    }

    // Compiled IID laws already emit unique atoms in dense queue order.  Skip
    // the node-allocating map in that common hot path while retaining the
    // exact general aggregation path for legacy sources that may collide.
    if (canonical_unique_order) {
      const BigNat& maximum_count = maximum_arrival_count(binding.family);
      std::vector<ArrivalBatchEntry> entries;
      entries.reserve(atoms.size());
      for (const ArrivalAtom& atom : atoms) {
        if (atom.count() > maximum_count) {
          return Result<ArrivalBatch>::failure(input_error(
              "arrival_count_overflow",
              "an aggregated arrival count exceeds the law's runtime count "
              "carrier",
              {"queue ordinal " + std::to_string(atom.queue().ordinal()),
               "exact count " + atom.count().to_decimal_string(),
               "maximum count " +
                   maximum_count.to_decimal_string()}));
        }
        entries.push_back(ArrivalBatchEntry{atom.queue(), atom.count()});
      }
      return Result<ArrivalBatch>::success(
          ArrivalBatch(binding, std::move(entries)));
    }

    std::map<DenseQueueIndex, BigNat> exact_totals;
    for (const ArrivalAtom& atom : atoms) {
      auto [position, inserted] =
          exact_totals.emplace(atom.queue(), atom.count());
      if (!inserted) {
        position->second += atom.count();
      }
    }

    std::vector<ArrivalBatchEntry> entries;
    entries.reserve(exact_totals.size());
    const BigNat& maximum_count = maximum_arrival_count(binding.family);
    for (auto& [queue, count] : exact_totals) {
      if (count > maximum_count) {
        return Result<ArrivalBatch>::failure(input_error(
            "arrival_count_overflow",
            "an aggregated arrival count exceeds the law's runtime count "
            "carrier",
            {"queue ordinal " + std::to_string(queue.ordinal()),
             "exact count " + count.to_decimal_string(),
             "maximum count " +
                 maximum_count.to_decimal_string()}));
      }
      entries.push_back(ArrivalBatchEntry{queue, std::move(count)});
    }

    return Result<ArrivalBatch>::success(
        ArrivalBatch(binding, std::move(entries)));
  } catch (const std::bad_alloc&) {
    return Result<ArrivalBatch>::failure(allocation_error());
  } catch (const std::length_error&) {
    return Result<ArrivalBatch>::failure(representation_error());
  } catch (const std::exception&) {
    return Result<ArrivalBatch>::failure(invariant_error());
  } catch (...) {
    return Result<ArrivalBatch>::failure(invariant_error());
  }
}

}  // namespace mwperf
