#include "mwperf/arrival/periodic.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/registry.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  std::optional<std::string> path;
  std::optional<std::string> pointer;
  if (provenance.has_value()) {
    pointer = provenance->json_pointer;
    if (provenance->location.has_value()) {
      path = provenance->location->authored_path;
      notes.insert(notes.begin(),
                   "line " +
                       std::to_string(provenance->location->line) +
                       ", column " +
                       std::to_string(provenance->location->column));
    }
  }
  return Diagnostic{category, std::move(code), std::move(message),
                    std::move(path), std::move(pointer), std::move(notes)};
}

template <typename T>
[[nodiscard]] Result<T> input_failure(
    std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(
      diagnostic(DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), provenance, std::move(notes)));
}

template <typename T>
[[nodiscard]] Result<T> internal_failure(std::string code,
                                         std::string message) {
  return Result<T>::failure(
      diagnostic(DiagnosticCategory::internal, std::move(code),
                 std::move(message)));
}

template <typename T>
[[nodiscard]] Result<T> allocation_failure(std::string operation) {
  return Result<T>::failure(diagnostic(
      DiagnosticCategory::resource_limit,
      "periodic_arrival_allocation_failure",
      "memory allocation failed while " + std::move(operation)));
}

[[nodiscard]] Result<ArrivalBinding> compile_aggregation_binding(
    const ArrivalFamily family, const QueueCatalog& queues) {
  // Compilation must use the common checked aggregator before the immutable
  // law fingerprint exists.  This deterministic binding is strictly local to
  // that aggregation; no atom or batch carrying it enters the compiled law.
  auto catalog_digest = detail::digest_queue_catalog(queues);
  if (!catalog_digest) {
    return Result<ArrivalBinding>::failure(catalog_digest.error());
  }
  const std::string_view domain =
      family == ArrivalFamily::periodic_global_phase
          ? "mwperf.c10.compile_aggregation.global_periodic"
          : "mwperf.c10.compile_aggregation.source_delay_periodic";
  auto law_digest = sha256_domain_separated(
      domain, catalog_digest.value().value().bytes());
  if (!law_digest) {
    return Result<ArrivalBinding>::failure(law_digest.error());
  }
  return Result<ArrivalBinding>::success(ArrivalBinding{
      family, TimingConvention::early_service_late_admission, queues.size(),
      ArrivalLawDigest(law_digest.value()), catalog_digest.value()});
}

using BucketAtoms = std::map<BigNat, std::vector<ArrivalAtom>>;

[[nodiscard]] Result<std::vector<PeriodicResidueBucket>> freeze_buckets(
    BucketAtoms groups) {
  try {
    std::vector<PeriodicResidueBucket> result;
    result.reserve(groups.size());
    for (auto& [residue, atoms] : groups) {
      auto aggregated = aggregate_arrival_batch(atoms);
      if (!aggregated) {
        return Result<std::vector<PeriodicResidueBucket>>::failure(
            aggregated.error());
      }
      std::vector<PeriodicQueueCount> counts;
      counts.reserve(aggregated.value().entries().size());
      for (const ArrivalBatchEntry& entry : aggregated.value().entries()) {
        counts.push_back(PeriodicQueueCount{entry.queue, entry.count});
      }
      result.push_back(
          PeriodicResidueBucket{std::move(residue), std::move(counts)});
    }
    return Result<std::vector<PeriodicResidueBucket>>::success(
        std::move(result));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<PeriodicResidueBucket>>(
        "freezing sparse periodic residue buckets");
  } catch (const std::length_error&) {
    return Result<std::vector<PeriodicResidueBucket>>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "the sparse periodic representation exceeds a host container limit"));
  }
}

[[nodiscard]] Result<void> verify_source_id(
    const NormalizedToken& id, std::set<std::string>& seen) {
  if (id.value.empty()) {
    return Result<void>::failure(diagnostic(
        DiagnosticCategory::input_validation,
        "periodic_source_id_invalid",
        "a periodic source must have a nonempty normalized identifier",
        id.provenance));
  }
  if (!seen.insert(id.value).second) {
    return Result<void>::failure(diagnostic(
        DiagnosticCategory::input_validation,
        "periodic_duplicate_source_id",
        "periodic source identifiers must be unique after normalization",
        id.provenance, {"duplicate source: " + id.value}));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<BigNat> shifted_residue(const BigNat& offset,
                                             const BigNat& phase,
                                             const BigNat& period) {
  BigNat shifted = offset + phase;
  if (!(shifted < period)) {
    auto reduced = checked_subtract(shifted, period);
    if (!reduced) {
      return Result<BigNat>::failure(reduced.error());
    }
    shifted = std::move(reduced).value();
  }
  if (!(shifted < period)) {
    return internal_failure<BigNat>(
        "periodic_rotation_invariant_failure",
        "an exact periodic rotation did not produce a residue below period");
  }
  return Result<BigNat>::success(std::move(shifted));
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 24U;; shift -= 8U) {
    output.push_back(
        static_cast<std::byte>((value >> shift) & UINT32_C(0xff)));
    if (shift == 0U) {
      break;
    }
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 56U;; shift -= 8U) {
    output.push_back(
        static_cast<std::byte>((value >> shift) & UINT64_C(0xff)));
    if (shift == 0U) {
      break;
    }
  }
}

[[nodiscard]] bool read_u32(const std::span<const std::byte> encoded,
                            std::size_t& offset,
                            std::uint32_t& value) noexcept {
  if (offset > encoded.size() || encoded.size() - offset < 4U) {
    return false;
  }
  value = 0U;
  for (std::size_t index = 0U; index < 4U; ++index) {
    value = static_cast<std::uint32_t>(
        (value << 8U) |
        std::to_integer<std::uint8_t>(encoded[offset + index]));
  }
  offset += 4U;
  return true;
}

[[nodiscard]] bool read_u64(const std::span<const std::byte> encoded,
                            std::size_t& offset,
                            std::uint64_t& value) noexcept {
  if (offset > encoded.size() || encoded.size() - offset < 8U) {
    return false;
  }
  value = 0U;
  for (std::size_t index = 0U; index < 8U; ++index) {
    value = static_cast<std::uint64_t>(
        (value << 8U) |
        std::to_integer<std::uint8_t>(encoded[offset + index]));
  }
  offset += 8U;
  return true;
}

[[nodiscard]] bool read_big_nat(const std::span<const std::byte> encoded,
                                std::size_t& offset, BigNat& value) {
  std::uint64_t length_u64 = 0U;
  if (!read_u64(encoded, offset, length_u64) || length_u64 == 0U ||
      length_u64 > static_cast<std::uint64_t>(
                       std::numeric_limits<std::size_t>::max())) {
    return false;
  }
  const std::size_t length = static_cast<std::size_t>(length_u64);
  if (offset > encoded.size() || length > encoded.size() - offset ||
      (length > 1U && encoded[offset] == std::byte{0})) {
    return false;
  }
  BigInt exact = 0;
  for (std::size_t index = 0U; index < length; ++index) {
    exact <<= 8U;
    exact += std::to_integer<std::uint8_t>(encoded[offset + index]);
  }
  offset += length;
  auto natural = BigNat::from_big_int(std::move(exact));
  if (!natural) {
    return false;
  }
  value = std::move(natural).value();
  return true;
}

void append_size(std::vector<std::byte>& output, const std::size_t value) {
  static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
  append_u64(output, static_cast<std::uint64_t>(value));
}

void append_string(std::vector<std::byte>& output,
                   const std::string_view value) {
  append_size(output, value.size());
  for (const char character : value) {
    output.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> bytes = value.canonical_magnitude_bytes();
  append_size(output, bytes.size());
  for (const std::uint8_t byte : bytes) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

void append_bucket(std::vector<std::byte>& output,
                   const PeriodicResidueBucket& bucket) {
  append_big_nat(output, bucket.residue);
  append_size(output, bucket.counts.size());
  for (const PeriodicQueueCount& count : bucket.counts) {
    append_size(output, count.queue.ordinal());
    append_big_nat(output, count.count);
  }
}

[[nodiscard]] std::vector<std::byte> encode_global_law(
    const GlobalPhaseLaw& law) {
  std::vector<std::byte> encoded;
  append_string(encoded, "mwperf.c10.periodic_global_phase.v1");
  append_u32(encoded, 1U);
  append_big_nat(encoded, law.period());
  append_big_nat(encoded, law.configured_phase());
  append_size(encoded, law.sources().size());
  for (const GlobalPhasePeriodicSource& source : law.sources()) {
    append_string(encoded, source.source_id);
    append_size(encoded, source.shifted_residues.size());
    for (const PeriodicResidueBucket& bucket : source.shifted_residues) {
      append_bucket(encoded, bucket);
    }
  }
  return encoded;
}

[[nodiscard]] std::vector<std::byte> encode_source_delay_law(
    const SourceDelayLaw& law) {
  std::vector<std::byte> encoded;
  append_string(encoded, "mwperf.c10.periodic_source_delays.v1");
  append_u32(encoded, 1U);
  append_big_nat(encoded, law.period());
  append_size(encoded, law.sources().size());
  for (const SourceDelayPeriodicSource& source : law.sources()) {
    append_string(encoded, source.source_id);
    append_big_nat(encoded, source.delay);
    append_size(encoded, source.unshifted_residues.size());
    for (const PeriodicResidueBucket& bucket : source.unshifted_residues) {
      append_bucket(encoded, bucket);
    }
  }
  return encoded;
}

struct GlobalPeriodicCursorState final {
  BigNat residue;
};

struct SourceDelayCursorState final {
  BigNat next_slot;
};

[[nodiscard]] Result<BigNat> decode_periodic_phase_coordinate(
    const std::span<const std::byte> encoded,
    const ArrivalFamily expected_family) {
  std::size_t offset = 0U;
  std::uint32_t version = 0U;
  BigNat coordinate(0U);
  if (!read_u32(encoded, offset, version) || version != 1U ||
      offset >= encoded.size() ||
      encoded[offset++] != static_cast<std::byte>(expected_family) ||
      !read_big_nat(encoded, offset, coordinate) || offset != encoded.size()) {
    return input_failure<BigNat>(
        "periodic_phase_codec_invalid",
        "the periodic predictive phase is not its canonical version-1 "
        "family and exact-coordinate record");
  }
  return Result<BigNat>::success(std::move(coordinate));
}

[[nodiscard]] Result<detail::ArrivalCursorState> decode_global_phase(
    const GlobalPhaseLaw& law, const std::span<const std::byte> encoded) {
  auto residue = decode_periodic_phase_coordinate(
      encoded, ArrivalFamily::periodic_global_phase);
  if (!residue) {
    return Result<detail::ArrivalCursorState>::failure(residue.error());
  }
  if (!(residue.value() < law.period())) {
    return input_failure<detail::ArrivalCursorState>(
        "periodic_phase_residue_invalid",
        "the global-periodic predictive residue must be below its exact "
        "period");
  }
  try {
    auto state = std::make_shared<const GlobalPeriodicCursorState>(
        GlobalPeriodicCursorState{std::move(residue).value()});
    return Result<detail::ArrivalCursorState>::success(std::move(state));
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ArrivalCursorState>(
        "decoding a global-periodic predictive phase");
  }
}

[[nodiscard]] Result<detail::ArrivalCursorState> decode_source_delay_phase(
    const std::span<const std::byte> encoded) {
  auto next_slot = decode_periodic_phase_coordinate(
      encoded, ArrivalFamily::periodic_source_delays);
  if (!next_slot) {
    return Result<detail::ArrivalCursorState>::failure(next_slot.error());
  }
  try {
    auto state = std::make_shared<const SourceDelayCursorState>(
        SourceDelayCursorState{std::move(next_slot).value()});
    return Result<detail::ArrivalCursorState>::success(std::move(state));
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ArrivalCursorState>(
        "decoding a source-delay periodic predictive phase");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_global_phase(
    const detail::ArrivalCursorState& erased) {
  const auto state =
      std::static_pointer_cast<const GlobalPeriodicCursorState>(erased);
  if (!state) {
    return internal_failure<std::vector<std::byte>>(
        "periodic_cursor_state_missing",
        "the global-periodic cursor has no predictive state");
  }
  try {
    std::vector<std::byte> encoded;
    append_u32(encoded, 1U);
    encoded.push_back(
        static_cast<std::byte>(ArrivalFamily::periodic_global_phase));
    append_big_nat(encoded, state->residue);
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<std::byte>>(
        "encoding a global-periodic predictive phase");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_source_delay_phase(
    const detail::ArrivalCursorState& erased) {
  const auto state =
      std::static_pointer_cast<const SourceDelayCursorState>(erased);
  if (!state) {
    return internal_failure<std::vector<std::byte>>(
        "periodic_cursor_state_missing",
        "the source-delay cursor has no predictive state");
  }
  try {
    std::vector<std::byte> encoded;
    append_u32(encoded, 1U);
    encoded.push_back(
        static_cast<std::byte>(ArrivalFamily::periodic_source_delays));
    append_big_nat(encoded, state->next_slot);
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<std::byte>>(
        "encoding a source-delay predictive phase");
  }
}

[[nodiscard]] const PeriodicResidueBucket* find_bucket(
    const std::span<const PeriodicResidueBucket> buckets,
    const BigInt& residue) {
  const auto found = std::lower_bound(
      buckets.begin(), buckets.end(), residue,
      [](const PeriodicResidueBucket& bucket, const BigInt& value) {
        return bucket.residue.value() < value;
      });
  if (found == buckets.end() || found->residue.value() != residue) {
    return nullptr;
  }
  return &*found;
}

[[nodiscard]] Result<void> append_bucket_atoms(
    const PeriodicResidueBucket* bucket, const ArrivalBinding& binding,
    std::vector<ArrivalAtom>& atoms) {
  if (bucket == nullptr) {
    return Result<void>::success();
  }
  try {
    for (const PeriodicQueueCount& count : bucket->counts) {
      auto atom = ArrivalAtom::make(count.queue, count.count, binding);
      if (!atom) {
        return Result<void>::failure(atom.error());
      }
      atoms.push_back(std::move(atom).value());
    }
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return allocation_failure<void>("gathering periodic arrival atoms");
  } catch (const std::length_error&) {
    return Result<void>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "a periodic arrival transition exceeds a host container limit"));
  }
}

template <typename Law>
[[nodiscard]] Result<void> validate_runtime_binding(
    const Law& law, const ArrivalBinding& binding,
    const ArrivalFamily expected_family) {
  if (binding.family != expected_family ||
      binding.timing != TimingConvention::early_service_late_admission ||
      binding.queue_cardinality != law.queue_count() ||
      !(binding.catalog_digest == law.catalog_digest())) {
    return Result<void>::failure(diagnostic(
        DiagnosticCategory::internal,
        "periodic_runtime_binding_mismatch",
        "a periodic runtime received a law, family, timing, or queue catalog "
        "binding inconsistent with its immutable payload"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<detail::ProposedArrivalTransition>
propose_global_transition(const GlobalPhaseLaw& law,
                          const detail::ArrivalCursorState& erased,
                          const BigNat& authored_slot,
                          const ArrivalBinding& binding) {
  const auto state =
      std::static_pointer_cast<const GlobalPeriodicCursorState>(erased);
  auto valid_binding = validate_runtime_binding(
      law, binding, ArrivalFamily::periodic_global_phase);
  if (!valid_binding) {
    return Result<detail::ProposedArrivalTransition>::failure(
        valid_binding.error());
  }
  if (!state || !(state->residue < law.period()) ||
      state->residue.value() != authored_slot.value() % law.period().value()) {
    return internal_failure<detail::ProposedArrivalTransition>(
        "periodic_cursor_state_invalid",
        "the global-periodic cursor is inconsistent with its requested exact "
        "slot and residue");
  }

  try {
    std::vector<ArrivalAtom> atoms;
    for (const GlobalPhasePeriodicSource& source : law.sources()) {
      const PeriodicResidueBucket* bucket = find_bucket(
          source.shifted_residues, state->residue.value());
      auto appended = append_bucket_atoms(bucket, binding, atoms);
      if (!appended) {
        return Result<detail::ProposedArrivalTransition>::failure(
            appended.error());
      }
    }

    BigNat successor_residue = state->residue;
    ++successor_residue;
    if (successor_residue == law.period()) {
      successor_residue = BigNat(0U);
    }
    auto successor = std::make_shared<const GlobalPeriodicCursorState>(
        GlobalPeriodicCursorState{std::move(successor_residue)});
    return Result<detail::ProposedArrivalTransition>::success(
        detail::ProposedArrivalTransition{std::move(successor),
                                          std::move(atoms)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ProposedArrivalTransition>(
        "advancing a global-periodic cursor");
  } catch (const std::length_error&) {
    return Result<detail::ProposedArrivalTransition>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "a global-periodic transition exceeds a host container limit"));
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition>
propose_source_delay_transition(const SourceDelayLaw& law,
                                const detail::ArrivalCursorState& erased,
                                const BigNat& authored_slot,
                                const ArrivalBinding& binding) {
  const auto state =
      std::static_pointer_cast<const SourceDelayCursorState>(erased);
  auto valid_binding = validate_runtime_binding(
      law, binding, ArrivalFamily::periodic_source_delays);
  if (!valid_binding) {
    return Result<detail::ProposedArrivalTransition>::failure(
        valid_binding.error());
  }
  if (!state || !(state->next_slot == authored_slot)) {
    return internal_failure<detail::ProposedArrivalTransition>(
        "periodic_cursor_state_invalid",
        "the source-delay cursor is inconsistent with its requested exact "
        "slot");
  }

  try {
    std::vector<ArrivalAtom> atoms;
    for (const SourceDelayPeriodicSource& source : law.sources()) {
      // This guard is semantic, not merely an underflow check.  A residue
      // match in a two-sided modular extension must not emit before delay.
      if (authored_slot < source.delay) {
        continue;
      }
      auto elapsed = checked_subtract(authored_slot, source.delay);
      if (!elapsed) {
        return internal_failure<detail::ProposedArrivalTransition>(
            "periodic_delay_subtraction_invariant_failure",
            "a guarded source-delay subtraction unexpectedly underflowed");
      }
      const BigInt residue = elapsed.value().value() % law.period().value();
      const PeriodicResidueBucket* bucket =
          find_bucket(source.unshifted_residues, residue);
      auto appended = append_bucket_atoms(bucket, binding, atoms);
      if (!appended) {
        return Result<detail::ProposedArrivalTransition>::failure(
            appended.error());
      }
    }

    BigNat successor_slot = state->next_slot;
    ++successor_slot;
    auto successor = std::make_shared<const SourceDelayCursorState>(
        SourceDelayCursorState{std::move(successor_slot)});
    return Result<detail::ProposedArrivalTransition>::success(
        detail::ProposedArrivalTransition{std::move(successor),
                                          std::move(atoms)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ProposedArrivalTransition>(
        "advancing a source-delay periodic cursor");
  } catch (const std::length_error&) {
    return Result<detail::ProposedArrivalTransition>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "a source-delay transition exceeds a host container limit"));
  }
}

[[nodiscard]] ArrivalCapabilities deterministic_capabilities() {
  ArrivalCapabilities capabilities;
  capabilities.exact_positive_support = CapabilityAvailability::available;
  capabilities.sequential_normalized_sampler =
      CapabilityAvailability::available;
  // A succinct exact recurrence is not an enumerated phase/row table, an IID
  // vector law, an analytic transform, moments, or a stationary selection.
  return capabilities;
}

}  // namespace

std::size_t GlobalPhaseLaw::aggregate_entry_count() const noexcept {
  std::size_t count = 0U;
  for (const GlobalPhasePeriodicSource& source : sources_) {
    for (const PeriodicResidueBucket& bucket : source.shifted_residues) {
      count += bucket.counts.size();
    }
  }
  return count;
}

std::size_t SourceDelayLaw::aggregate_entry_count() const noexcept {
  std::size_t count = 0U;
  for (const SourceDelayPeriodicSource& source : sources_) {
    for (const PeriodicResidueBucket& bucket : source.unshifted_residues) {
      count += bucket.counts.size();
    }
  }
  return count;
}

Result<GlobalPhaseLaw> compile_global_phase_periodic(
    const PeriodicGlobalPhaseArrival& authored, const QueueCatalog& queues) {
  if (authored.period.value.is_zero()) {
    return input_failure<GlobalPhaseLaw>(
        "periodic_period_zero", "a periodic arrival period must be positive",
        authored.period.provenance);
  }
  if (!(authored.phase.value < authored.period.value)) {
    return input_failure<GlobalPhaseLaw>(
        "periodic_phase_out_of_range",
        "a global periodic phase must be strictly below its period",
        authored.phase.provenance);
  }

  try {
    auto scratch = compile_aggregation_binding(
        ArrivalFamily::periodic_global_phase, queues);
    if (!scratch) {
      return Result<GlobalPhaseLaw>::failure(scratch.error());
    }
    std::set<std::string> source_ids;
    std::vector<GlobalPhasePeriodicSource> sources;
    sources.reserve(authored.sources.value.size());
    for (const GlobalPhaseSource& source : authored.sources.value) {
      auto unique = verify_source_id(source.id, source_ids);
      if (!unique) {
        return Result<GlobalPhaseLaw>::failure(unique.error());
      }
      BucketAtoms groups;
      for (const PeriodicEntry& entry : source.entries.value) {
        if (!(entry.offset.value < authored.period.value)) {
          return input_failure<GlobalPhaseLaw>(
              "periodic_offset_out_of_range",
              "a periodic entry offset must be strictly below its period",
              entry.offset.provenance);
        }
        if (entry.count.value.is_zero()) {
          return input_failure<GlobalPhaseLaw>(
              "periodic_entry_count_zero",
              "a periodic entry count must be strictly positive",
              entry.count.provenance);
        }
        auto queue = queues.resolve(entry.queue_id.value,
                                    entry.queue_id.provenance);
        if (!queue) {
          return Result<GlobalPhaseLaw>::failure(queue.error());
        }
        auto residue = shifted_residue(entry.offset.value,
                                       authored.phase.value,
                                       authored.period.value);
        if (!residue) {
          return Result<GlobalPhaseLaw>::failure(residue.error());
        }
        auto atom = ArrivalAtom::make(queue.value(), entry.count.value,
                                      scratch.value());
        if (!atom) {
          return Result<GlobalPhaseLaw>::failure(atom.error());
        }
        groups[std::move(residue).value()].push_back(
            std::move(atom).value());
      }
      auto buckets = freeze_buckets(std::move(groups));
      if (!buckets) {
        return Result<GlobalPhaseLaw>::failure(buckets.error());
      }
      sources.push_back(GlobalPhasePeriodicSource{
          source.id.value, std::move(buckets).value()});
    }
    return Result<GlobalPhaseLaw>::success(GlobalPhaseLaw{
        authored.period.value, authored.phase.value, queues.size(),
        scratch.value().catalog_digest, std::move(sources)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<GlobalPhaseLaw>(
        "compiling a global-phase periodic arrival law");
  } catch (const std::length_error&) {
    return Result<GlobalPhaseLaw>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "the sparse global-periodic representation exceeds a host container "
        "limit"));
  } catch (const std::exception&) {
    return internal_failure<GlobalPhaseLaw>(
        "periodic_compilation_invariant_failure",
        "global-periodic compilation violated an exact representation "
        "invariant");
  }
}

Result<SourceDelayLaw> compile_source_delay_periodic(
    const PeriodicSourceDelaysArrival& authored, const QueueCatalog& queues) {
  if (authored.period.value.is_zero()) {
    return input_failure<SourceDelayLaw>(
        "periodic_period_zero", "a periodic arrival period must be positive",
        authored.period.provenance);
  }

  try {
    auto scratch = compile_aggregation_binding(
        ArrivalFamily::periodic_source_delays, queues);
    if (!scratch) {
      return Result<SourceDelayLaw>::failure(scratch.error());
    }
    std::set<std::string> source_ids;
    std::vector<SourceDelayPeriodicSource> sources;
    sources.reserve(authored.sources.value.size());
    for (const DelayedPeriodicSource& source : authored.sources.value) {
      auto unique = verify_source_id(source.id, source_ids);
      if (!unique) {
        return Result<SourceDelayLaw>::failure(unique.error());
      }
      BucketAtoms groups;
      for (const PeriodicEntry& entry : source.entries.value) {
        if (!(entry.offset.value < authored.period.value)) {
          return input_failure<SourceDelayLaw>(
              "periodic_offset_out_of_range",
              "a periodic entry offset must be strictly below its period",
              entry.offset.provenance);
        }
        if (entry.count.value.is_zero()) {
          return input_failure<SourceDelayLaw>(
              "periodic_entry_count_zero",
              "a periodic entry count must be strictly positive",
              entry.count.provenance);
        }
        auto queue = queues.resolve(entry.queue_id.value,
                                    entry.queue_id.provenance);
        if (!queue) {
          return Result<SourceDelayLaw>::failure(queue.error());
        }
        auto atom = ArrivalAtom::make(queue.value(), entry.count.value,
                                      scratch.value());
        if (!atom) {
          return Result<SourceDelayLaw>::failure(atom.error());
        }
        groups[entry.offset.value].push_back(std::move(atom).value());
      }
      auto buckets = freeze_buckets(std::move(groups));
      if (!buckets) {
        return Result<SourceDelayLaw>::failure(buckets.error());
      }
      sources.push_back(SourceDelayPeriodicSource{
          source.id.value, source.delay.value, std::move(buckets).value()});
    }
    return Result<SourceDelayLaw>::success(SourceDelayLaw{
        authored.period.value, queues.size(), scratch.value().catalog_digest,
        std::move(sources)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<SourceDelayLaw>(
        "compiling a source-delay periodic arrival law");
  } catch (const std::length_error&) {
    return Result<SourceDelayLaw>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "the sparse source-delay representation exceeds a host container "
        "limit"));
  } catch (const std::exception&) {
    return internal_failure<SourceDelayLaw>(
        "periodic_compilation_invariant_failure",
        "source-delay compilation violated an exact representation invariant");
  }
}

Result<ArrivalStep> next_periodic_batch(PeriodicCursor& cursor,
                                        const BigNat& authored_slot) {
  if (cursor.family() != ArrivalFamily::periodic_global_phase &&
      cursor.family() != ArrivalFamily::periodic_source_delays) {
    return input_failure<ArrivalStep>(
        "arrival_periodic_cursor_family_mismatch",
        "next_periodic_batch requires a global-phase or source-delay "
        "periodic cursor");
  }
  return next_arrival_step(cursor, authored_slot);
}

namespace detail {

Result<CompiledArrivalProduct> compile_global_phase_periodic_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<PeriodicGlobalPhaseArrival>(&request.authored.value);
  if (authored == nullptr) {
    return internal_failure<CompiledArrivalProduct>(
        "arrival_backend_authored_variant_mismatch",
        "the global-periodic registry slot received another authored family");
  }
  if (!request.normalized_rows.empty()) {
    return internal_failure<CompiledArrivalProduct>(
        "arrival_backend_normalized_rows_unexpected",
        "a deterministic global-periodic law received categorical rows");
  }
  auto compiled = compile_global_phase_periodic(*authored, request.queues);
  if (!compiled) {
    return Result<CompiledArrivalProduct>::failure(compiled.error());
  }

  try {
    auto payload = std::make_shared<const GlobalPhaseLaw>(
        std::move(compiled).value());
    std::vector<std::uint8_t> support(request.queues.size(), 0U);
    for (const GlobalPhasePeriodicSource& source : payload->sources()) {
      for (const PeriodicResidueBucket& bucket : source.shifted_residues) {
        for (const PeriodicQueueCount& count : bucket.counts) {
          support[count.queue.ordinal()] = 1U;
        }
      }
    }

    ArrivalRuntimeAdapter runtime;
    runtime.validate_initial =
        [](const std::shared_ptr<const void>&,
           const ArrivalInitialState& state) -> Result<void> {
      if (!std::holds_alternative<GlobalPeriodicOrigin>(state)) {
        return Result<void>::failure(diagnostic(
            DiagnosticCategory::input_validation,
            "arrival_initial_family_mismatch",
            "a global-periodic law requires global_periodic_origin"));
      }
      return Result<void>::success();
    };
    runtime.instantiate =
        [](const std::shared_ptr<const void>&,
           const ArrivalInitialState& state,
           DeterministicRng&) -> Result<ArrivalCursorInitialization> {
      if (!std::holds_alternative<GlobalPeriodicOrigin>(state)) {
        return Result<ArrivalCursorInitialization>::failure(diagnostic(
            DiagnosticCategory::input_validation,
            "arrival_initial_family_mismatch",
            "a global-periodic law requires global_periodic_origin"));
      }
      try {
        auto cursor = std::make_shared<const GlobalPeriodicCursorState>(
            GlobalPeriodicCursorState{BigNat(0U)});
        return Result<ArrivalCursorInitialization>::success(
            ArrivalCursorInitialization{std::move(cursor)});
      } catch (const std::bad_alloc&) {
        return allocation_failure<ArrivalCursorInitialization>(
            "instantiating a global-periodic cursor");
      }
    };
    runtime.encode_phase =
        [](const std::shared_ptr<const void>&,
           const ArrivalCursorState& state) {
      return encode_global_phase(state);
    };
    runtime.decode_phase =
        [](const std::shared_ptr<const void>& erased,
           const std::span<const std::byte> encoded) {
      const auto law = std::static_pointer_cast<const GlobalPhaseLaw>(erased);
      if (!law) {
        return internal_failure<ArrivalCursorState>(
            "periodic_law_payload_missing",
            "the global-periodic phase decoder has no immutable law payload");
      }
      return decode_global_phase(*law, encoded);
    };
    runtime.propose =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding,
           DeterministicRng&) -> Result<ProposedArrivalTransition> {
      const auto law = std::static_pointer_cast<const GlobalPhaseLaw>(erased);
      if (!law) {
        return internal_failure<ProposedArrivalTransition>(
            "periodic_law_payload_missing",
            "the global-periodic runtime has no immutable law payload");
      }
      return propose_global_transition(*law, state, slot, binding);
    };
    runtime.enumerate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding)
        -> Result<std::vector<ExactArrivalTransitionAtom>> {
      const auto law = std::static_pointer_cast<const GlobalPhaseLaw>(erased);
      if (!law) {
        return internal_failure<std::vector<ExactArrivalTransitionAtom>>(
            "periodic_law_payload_missing",
            "the global-periodic exact row has no immutable law payload");
      }
      auto before = encode_global_phase(state);
      if (!before) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            before.error());
      }
      auto proposal = propose_global_transition(*law, state, slot, binding);
      if (!proposal) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            proposal.error());
      }
      auto after = encode_global_phase(proposal.value().successor_state);
      if (!after) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            after.error());
      }
      try {
        std::vector<ExactArrivalTransitionAtom> row;
        row.reserve(1U);
        row.push_back(ExactArrivalTransitionAtom{
            .atoms = std::move(proposal.value().atoms),
            .phase_before = std::move(before.value()),
            .phase_after = std::move(after.value()),
            .mass = ExactRational::one(),
            .structural_support = true});
        return Result<std::vector<ExactArrivalTransitionAtom>>::success(
            std::move(row));
      } catch (const std::bad_alloc&) {
        return allocation_failure<std::vector<ExactArrivalTransitionAtom>>(
            "enumerating a global-periodic exact transition row");
      }
    };

    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::periodic_global_phase,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = deterministic_capabilities(),
        .canonical_law_data = encode_global_law(*payload),
        .portable_schema = PortableArrivalLawSchema::periodic_global_phase_v1,
        .payload = std::move(payload),
        .runtime = std::move(runtime),
        .iid_joint_table = std::nullopt,
        .moments = std::nullopt,
        .covariances = std::nullopt,
        .analytic_transform = std::nullopt,
        .joint_distribution = std::nullopt,
        .coordinate_distributions = std::nullopt,
        .replay_codec = std::nullopt,
        .unit_cube = std::nullopt,
        .finite_phase = std::nullopt,
        .transition_rows = std::nullopt,
        .stationary_phase_law = std::nullopt,
    });
  } catch (const std::bad_alloc&) {
    return allocation_failure<CompiledArrivalProduct>(
        "publishing a global-periodic arrival product");
  } catch (const std::length_error&) {
    return Result<CompiledArrivalProduct>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "the global-periodic product exceeds a host container limit"));
  }
}

Result<CompiledArrivalProduct> compile_source_delay_periodic_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<PeriodicSourceDelaysArrival>(&request.authored.value);
  if (authored == nullptr) {
    return internal_failure<CompiledArrivalProduct>(
        "arrival_backend_authored_variant_mismatch",
        "the source-delay registry slot received another authored family");
  }
  if (!request.normalized_rows.empty()) {
    return internal_failure<CompiledArrivalProduct>(
        "arrival_backend_normalized_rows_unexpected",
        "a deterministic source-delay law received categorical rows");
  }
  auto compiled = compile_source_delay_periodic(*authored, request.queues);
  if (!compiled) {
    return Result<CompiledArrivalProduct>::failure(compiled.error());
  }

  try {
    auto payload =
        std::make_shared<const SourceDelayLaw>(std::move(compiled).value());
    std::vector<std::uint8_t> support(request.queues.size(), 0U);
    for (const SourceDelayPeriodicSource& source : payload->sources()) {
      for (const PeriodicResidueBucket& bucket : source.unshifted_residues) {
        for (const PeriodicQueueCount& count : bucket.counts) {
          support[count.queue.ordinal()] = 1U;
        }
      }
    }

    ArrivalRuntimeAdapter runtime;
    runtime.validate_initial =
        [](const std::shared_ptr<const void>&,
           const ArrivalInitialState& state) -> Result<void> {
      if (!std::holds_alternative<SourceDelayOrigin>(state)) {
        return Result<void>::failure(diagnostic(
            DiagnosticCategory::input_validation,
            "arrival_initial_family_mismatch",
            "a source-delay law requires source_delay_origin"));
      }
      return Result<void>::success();
    };
    runtime.instantiate =
        [](const std::shared_ptr<const void>&,
           const ArrivalInitialState& state,
           DeterministicRng&) -> Result<ArrivalCursorInitialization> {
      if (!std::holds_alternative<SourceDelayOrigin>(state)) {
        return Result<ArrivalCursorInitialization>::failure(diagnostic(
            DiagnosticCategory::input_validation,
            "arrival_initial_family_mismatch",
            "a source-delay law requires source_delay_origin"));
      }
      try {
        auto cursor = std::make_shared<const SourceDelayCursorState>(
            SourceDelayCursorState{BigNat(0U)});
        return Result<ArrivalCursorInitialization>::success(
            ArrivalCursorInitialization{std::move(cursor)});
      } catch (const std::bad_alloc&) {
        return allocation_failure<ArrivalCursorInitialization>(
            "instantiating a source-delay periodic cursor");
      }
    };
    runtime.encode_phase =
        [](const std::shared_ptr<const void>&,
           const ArrivalCursorState& state) {
      return encode_source_delay_phase(state);
    };
    runtime.decode_phase =
        [](const std::shared_ptr<const void>&,
           const std::span<const std::byte> encoded) {
      return decode_source_delay_phase(encoded);
    };
    runtime.propose =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding,
           DeterministicRng&) -> Result<ProposedArrivalTransition> {
      const auto law = std::static_pointer_cast<const SourceDelayLaw>(erased);
      if (!law) {
        return internal_failure<ProposedArrivalTransition>(
            "periodic_law_payload_missing",
            "the source-delay runtime has no immutable law payload");
      }
      return propose_source_delay_transition(*law, state, slot, binding);
    };
    runtime.enumerate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding)
        -> Result<std::vector<ExactArrivalTransitionAtom>> {
      const auto law = std::static_pointer_cast<const SourceDelayLaw>(erased);
      if (!law) {
        return internal_failure<std::vector<ExactArrivalTransitionAtom>>(
            "periodic_law_payload_missing",
            "the source-delay exact row has no immutable law payload");
      }
      auto before = encode_source_delay_phase(state);
      if (!before) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            before.error());
      }
      auto proposal =
          propose_source_delay_transition(*law, state, slot, binding);
      if (!proposal) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            proposal.error());
      }
      auto after =
          encode_source_delay_phase(proposal.value().successor_state);
      if (!after) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            after.error());
      }
      try {
        std::vector<ExactArrivalTransitionAtom> row;
        row.reserve(1U);
        row.push_back(ExactArrivalTransitionAtom{
            .atoms = std::move(proposal.value().atoms),
            .phase_before = std::move(before.value()),
            .phase_after = std::move(after.value()),
            .mass = ExactRational::one(),
            .structural_support = true});
        return Result<std::vector<ExactArrivalTransitionAtom>>::success(
            std::move(row));
      } catch (const std::bad_alloc&) {
        return allocation_failure<std::vector<ExactArrivalTransitionAtom>>(
            "enumerating a source-delay exact transition row");
      }
    };

    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::periodic_source_delays,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = deterministic_capabilities(),
        .canonical_law_data = encode_source_delay_law(*payload),
        .portable_schema = PortableArrivalLawSchema::periodic_source_delays_v1,
        .payload = std::move(payload),
        .runtime = std::move(runtime),
        .iid_joint_table = std::nullopt,
        .moments = std::nullopt,
        .covariances = std::nullopt,
        .analytic_transform = std::nullopt,
        .joint_distribution = std::nullopt,
        .coordinate_distributions = std::nullopt,
        .replay_codec = std::nullopt,
        .unit_cube = std::nullopt,
        .finite_phase = std::nullopt,
        .transition_rows = std::nullopt,
        .stationary_phase_law = std::nullopt,
    });
  } catch (const std::bad_alloc&) {
    return allocation_failure<CompiledArrivalProduct>(
        "publishing a source-delay periodic arrival product");
  } catch (const std::length_error&) {
    return Result<CompiledArrivalProduct>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "periodic_arrival_representation_failure",
        "the source-delay product exceeds a host container limit"));
  }
}

}  // namespace detail
}  // namespace mwperf
