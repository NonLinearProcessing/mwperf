#pragma once

#include <algorithm>
#include <cstddef>
#include <exception>
#include <iterator>
#include <new>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"
#include "core_internal.hpp"

namespace mwperf::detail {
namespace initial_law_detail {

template <typename T>
[[nodiscard]] inline Result<T> fail(Diagnostic diagnostic) {
  return Result<T>::failure(std::move(diagnostic));
}

[[nodiscard]] inline Diagnostic diagnostic_at(
    const DiagnosticCategory category, std::string code, std::string message,
    const SourceNode& source, std::vector<std::string> notes = {}) {
  const SourceProvenance provenance = authored_provenance(source);
  Diagnostic diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = provenance.json_pointer,
      .notes = std::move(notes),
  };
  if (provenance.location.has_value()) {
    diagnostic.authored_path = provenance.location->authored_path;
    diagnostic.notes.push_back(
        "source line " + std::to_string(provenance.location->line) +
        ", column " + std::to_string(provenance.location->column));
  }
  return diagnostic;
}

[[nodiscard]] inline Diagnostic invariant_error(std::string code,
                                                std::string message,
                                                std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

[[nodiscard]] inline Diagnostic allocation_error(std::string code,
                                                 std::string message) {
  return Diagnostic{
      .category = DiagnosticCategory::resource_limit,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = {},
  };
}

[[nodiscard]] inline std::string_view initial_state_kind(
    const ArrivalInitialState& state) noexcept {
  return std::visit(
      [](const auto& value) -> std::string_view {
        using Value = std::remove_cvref_t<decltype(value)>;
        if constexpr (std::is_same_v<Value, TraceOrigin>) {
          return "trace_origin";
        } else if constexpr (std::is_same_v<Value, GlobalPeriodicOrigin>) {
          return "global_periodic_origin";
        } else if constexpr (std::is_same_v<Value, SourceDelayOrigin>) {
          return "source_delay_origin";
        } else if constexpr (std::is_same_v<Value, RenewalOrigin>) {
          return "renewal_origin";
        } else if constexpr (std::is_same_v<Value, PrivateMarkovStates>) {
          return "private_markov_states";
        } else {
          static_assert(std::is_same_v<Value, SharedRoundState>);
          return "shared_round_state";
        }
      },
      state);
}

[[nodiscard]] inline std::string_view expected_initial_state_kind(
    const ArrivalFamily family) noexcept {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return "trace_origin";
    case ArrivalFamily::periodic_global_phase:
      return "global_periodic_origin";
    case ArrivalFamily::periodic_source_delays:
      return "source_delay_origin";
    case ArrivalFamily::independent_marked_renewal:
      return "renewal_origin";
    case ArrivalFamily::independent_private_markov_renewal:
      return "private_markov_states";
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return "shared_round_state";
    case ArrivalFamily::iid_independent_bernoulli:
    case ArrivalFamily::iid_count_table:
    case ArrivalFamily::iid_independent_poisson:
    case ArrivalFamily::iid_mixed_poisson:
      return "renewal_origin";
  }
  return "invalid_arrival_family";
}

[[nodiscard]] inline bool initial_state_matches_family(
    const ArrivalFamily family, const ArrivalInitialState& state) noexcept {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return std::holds_alternative<TraceOrigin>(state);
    case ArrivalFamily::periodic_global_phase:
      return std::holds_alternative<GlobalPeriodicOrigin>(state);
    case ArrivalFamily::periodic_source_delays:
      return std::holds_alternative<SourceDelayOrigin>(state);
    case ArrivalFamily::independent_marked_renewal:
      return std::holds_alternative<RenewalOrigin>(state);
    case ArrivalFamily::independent_private_markov_renewal:
      return std::holds_alternative<PrivateMarkovStates>(state);
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return std::holds_alternative<SharedRoundState>(state);
    case ArrivalFamily::iid_independent_bernoulli:
    case ArrivalFamily::iid_count_table:
    case ArrivalFamily::iid_independent_poisson:
    case ArrivalFamily::iid_mixed_poisson:
      return std::holds_alternative<RenewalOrigin>(state);
  }
  return false;
}

// Source provenance is deliberately absent from mathematical atom identity.
// JSON objects compare as mappings, arrays retain order, and decimal spellings
// compare through their exact rational values just as C03 canonicalization
// does (so, for example, 1 and 1.0 denote the same opaque numeric value).
[[nodiscard]] inline Result<bool> source_values_equal(const SourceNode& left,
                                                      const SourceNode& right) {
  if (left.kind() != right.kind()) {
    return Result<bool>::success(false);
  }

  switch (left.kind()) {
    case SourceNodeKind::null_value:
      return Result<bool>::success(true);
    case SourceNodeKind::boolean:
      return Result<bool>::success(*left.boolean_value() ==
                                   *right.boolean_value());
    case SourceNodeKind::number: {
      auto left_value =
          parse_decimal_rational(NumericLexeme(*left.number_lexeme()));
      if (!left_value) {
        return fail<bool>(left_value.error());
      }
      auto right_value =
          parse_decimal_rational(NumericLexeme(*right.number_lexeme()));
      if (!right_value) {
        return fail<bool>(right_value.error());
      }
      return Result<bool>::success(left_value.value() == right_value.value());
    }
    case SourceNodeKind::string:
      return Result<bool>::success(*left.string_value() ==
                                   *right.string_value());
    case SourceNodeKind::array: {
      const std::span<const SourceNode> left_items = left.array_items();
      const std::span<const SourceNode> right_items = right.array_items();
      if (left_items.size() != right_items.size()) {
        return Result<bool>::success(false);
      }
      for (std::size_t index = 0U; index < left_items.size(); ++index) {
        auto equal = source_values_equal(left_items[index], right_items[index]);
        if (!equal) {
          return equal;
        }
        if (!equal.value()) {
          return Result<bool>::success(false);
        }
      }
      return Result<bool>::success(true);
    }
    case SourceNodeKind::object: {
      const std::span<const SourceObjectMember> left_members =
          left.object_members();
      if (left_members.size() != right.object_members().size()) {
        return Result<bool>::success(false);
      }
      for (const SourceObjectMember& member : left_members) {
        const SourceNode* right_value = right.find(member.key);
        if (right_value == nullptr) {
          return Result<bool>::success(false);
        }
        auto equal = source_values_equal(member.value, *right_value);
        if (!equal) {
          return equal;
        }
        if (!equal.value()) {
          return Result<bool>::success(false);
        }
      }
      return Result<bool>::success(true);
    }
  }

  return fail<bool>(invariant_error(
      "initial_law_source_node_kind_invalid",
      "a complete initial atom contains an invalid source-node kind"));
}

[[nodiscard]] inline bool private_states_equal(
    const PrivateMarkovStates& left,
    const PrivateMarkovStates& right) noexcept {
  if (left.states.size() != right.states.size()) {
    return false;
  }
  for (const PrivateMarkovState& left_state : left.states) {
    const auto first = std::ranges::find_if(
        right.states, [&](const PrivateMarkovState& right_state) {
          return right_state.source_id == left_state.source_id;
        });
    if (first == right.states.end() || first->state != left_state.state) {
      return false;
    }
    const auto duplicate = std::ranges::find_if(
        std::next(first), right.states.end(),
        [&](const PrivateMarkovState& right_state) {
          return right_state.source_id == left_state.source_id;
        });
    if (duplicate != right.states.end()) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] inline bool initial_states_equal(
    const ArrivalInitialState& left,
    const ArrivalInitialState& right) noexcept {
  if (left.index() != right.index()) {
    return false;
  }
  return std::visit(
      [](const auto& left_value, const auto& right_value) noexcept {
        using Left = std::remove_cvref_t<decltype(left_value)>;
        using Right = std::remove_cvref_t<decltype(right_value)>;
        if constexpr (!std::is_same_v<Left, Right>) {
          return false;
        } else if constexpr (std::is_same_v<Left, PrivateMarkovStates>) {
          return private_states_equal(left_value, right_value);
        } else if constexpr (std::is_same_v<Left, SharedRoundState>) {
          return left_value.state == right_value.state;
        } else {
          return true;
        }
      },
      left, right);
}

[[nodiscard]] inline Result<bool> complete_atoms_equal(
    const InitialPhysicalAtom& compiled,
    const ResolvedTransientInitialAtom& candidate) {
  if (compiled.backlog != candidate.backlog ||
      !initial_states_equal(compiled.arrival_state, candidate.arrival_state)) {
    return Result<bool>::success(false);
  }

  auto controller_equal =
      source_values_equal(compiled.controller_state, candidate.controller_state);
  if (!controller_equal || !controller_equal.value()) {
    return controller_equal;
  }
  auto context_equal =
      source_values_equal(compiled.static_context, candidate.static_context);
  if (!context_equal || !context_equal.value()) {
    return context_equal;
  }
  return source_values_equal(compiled.surrogate_initial,
                             candidate.surrogate_initial);
}

[[nodiscard]] inline Result<void> validate_initial_state(
    const CompiledArrivalLawCore& core,
    const ResolvedTransientInitialAtom& atom) {
  if (!initial_state_matches_family(core.binding.family, atom.arrival_state)) {
    return Result<void>::failure(diagnostic_at(
        DiagnosticCategory::input_validation,
        "arrival_initial_state_family_mismatch",
        "a transient initial atom uses an arrival-state codec for another "
        "arrival family",
        atom.arrival_state_source,
        {"compiled family " + std::string(to_string(core.binding.family)),
         "required state kind " +
             std::string(expected_initial_state_kind(core.binding.family)),
         "received state kind " +
             std::string(initial_state_kind(atom.arrival_state))}));
  }
  if (!core.runtime.validate_initial) {
    return Result<void>::failure(invariant_error(
        "arrival_initial_state_validator_missing",
        "the compiled arrival law has no initial-state validator"));
  }
  return core.runtime.validate_initial(core.payload, atom.arrival_state);
}

}  // namespace initial_law_detail

// Private implementation of F-C09-06. The public wrapper in contract.cpp is
// intentionally thin so this helper owns all one-time normalization and joint
// atom semantics without sharing source-file ownership.
[[nodiscard]] inline Result<InitialPhysicalLaw>
compile_initial_physical_law_impl(
    const ResolvedTransientInitialLaw& resolved,
    const CompiledArrivalLaw& arrival_law) {
  using namespace initial_law_detail;

  try {
    const std::shared_ptr<const CompiledArrivalLawCore>& core =
        ArrivalCoreAccess::law_core(arrival_law);
    if (!core) {
      return fail<InitialPhysicalLaw>(invariant_error(
          "initial_law_compiled_arrival_missing",
          "initial-law compilation received a null compiled arrival law"));
    }
    if (arrival_law.family() != core->binding.family) {
      return fail<InitialPhysicalLaw>(invariant_error(
          "initial_law_arrival_family_invariant",
          "the compiled arrival variant and its immutable binding disagree"));
    }

    std::vector<AuthoredProbability> authored_probabilities;
    authored_probabilities.reserve(resolved.atoms.size());
    for (const ResolvedTransientInitialAtom& atom : resolved.atoms) {
      authored_probabilities.push_back(atom.probability);
    }

    // This is the sole normalization of the complete joint initializer. The
    // original categorical row remains intact for C12's one-draw selection.
    auto normalized = validate_and_normalize_pmf(
        authored_probabilities, physical_pmf_tolerance());
    if (!normalized) {
      return fail<InitialPhysicalLaw>(normalized.error());
    }
    if (normalized.value().normalized_weights().size() !=
        resolved.atoms.size()) {
      return fail<InitialPhysicalLaw>(invariant_error(
          "initial_law_pmf_dimension_invariant",
          "the once-normalized initial PMF changed its row cardinality"));
    }

    std::vector<InitialPhysicalAtom> atoms;
    std::vector<std::size_t> original_to_atom;
    atoms.reserve(resolved.atoms.size());
    original_to_atom.reserve(resolved.atoms.size());

    for (std::size_t original_index = 0U;
         original_index < resolved.atoms.size(); ++original_index) {
      const ResolvedTransientInitialAtom& candidate =
          resolved.atoms[original_index];
      if (candidate.backlog.size() != core->binding.queue_cardinality) {
        return fail<InitialPhysicalLaw>(diagnostic_at(
            DiagnosticCategory::input_validation,
            "initial_backlog_dimension_mismatch",
            "a transient initial atom backlog does not match the compiled "
            "arrival queue catalog",
            candidate.source,
            {"expected " +
                 std::to_string(core->binding.queue_cardinality) +
                 " dense entries",
             "received " + std::to_string(candidate.backlog.size()) +
                 " dense entries"}));
      }

      auto state_valid = validate_initial_state(*core, candidate);
      if (!state_valid) {
        return fail<InitialPhysicalLaw>(state_valid.error());
      }

      std::size_t coalesced_index = atoms.size();
      for (std::size_t index = 0U; index < atoms.size(); ++index) {
        auto equal = complete_atoms_equal(atoms[index], candidate);
        if (!equal) {
          return fail<InitialPhysicalLaw>(equal.error());
        }
        if (equal.value()) {
          coalesced_index = index;
          break;
        }
      }

      const ExactRational& row_weight =
          normalized.value().normalized_weights()[original_index];
      if (coalesced_index == atoms.size()) {
        atoms.push_back(InitialPhysicalAtom{
            .probability = row_weight,
            .backlog = candidate.backlog,
            .arrival_state = candidate.arrival_state,
            .controller_state = candidate.controller_state,
            .static_context = candidate.static_context,
            .surrogate_initial = candidate.surrogate_initial,
            .source = candidate.source,
        });
      } else {
        atoms[coalesced_index].probability =
            atoms[coalesced_index].probability + row_weight;
      }
      original_to_atom.push_back(coalesced_index);
    }

    ExactRational coalesced_mass = ExactRational::zero();
    for (const InitialPhysicalAtom& atom : atoms) {
      coalesced_mass = coalesced_mass + atom.probability;
    }
    if (!(coalesced_mass == ExactRational::one()) ||
        original_to_atom.size() != resolved.atoms.size() || atoms.empty()) {
      return fail<InitialPhysicalLaw>(invariant_error(
          "initial_law_coalescing_invariant",
          "complete-atom coalescing did not preserve the normalized joint "
          "initial law"));
    }
    if (std::ranges::any_of(
            original_to_atom,
            [&](const std::size_t index) { return index >= atoms.size(); })) {
      return fail<InitialPhysicalLaw>(invariant_error(
          "initial_law_coalescing_map_invariant",
          "the original-to-coalesced initial atom map is out of range"));
    }

    return Result<InitialPhysicalLaw>::success(
        ArrivalCoreAccess::make_initial_law(
            core->binding, std::move(normalized).value(),
            std::move(atoms), std::move(original_to_atom)));
  } catch (const std::bad_alloc&) {
    return fail<InitialPhysicalLaw>(allocation_error(
        "initial_law_allocation_failure",
        "memory allocation failed while compiling the complete joint initial "
        "law"));
  } catch (const std::length_error&) {
    return fail<InitialPhysicalLaw>(allocation_error(
        "initial_law_representation_failure",
        "the complete joint initial law exceeds a host container limit"));
  } catch (const std::exception&) {
    return fail<InitialPhysicalLaw>(invariant_error(
        "initial_law_unexpected_exception",
        "initial-law compilation raised an unexpected implementation "
        "exception"));
  } catch (...) {
    return fail<InitialPhysicalLaw>(invariant_error(
        "initial_law_unknown_exception",
        "initial-law compilation raised an unknown implementation exception"));
  }
}

}  // namespace mwperf::detail
