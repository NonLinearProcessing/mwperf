#pragma once

#include <atomic>
#include <memory>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/arrival/build_services.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/registry.hpp"

namespace mwperf::detail {

struct CursorOwnerToken final {};

struct ArrivalPhaseCore final {
  ArrivalFamily family;
  ArrivalBinding binding;
  ArrivalStateDigest state_digest;
  std::vector<std::byte> canonical_state;
  BigNat next_authored_slot;
  ArrivalCursorState cursor_state;
  std::shared_ptr<const CursorOwnerToken> cursor_owner;
};

struct CompiledArrivalLawCore final {
  ArrivalBinding binding;
  QueueMask positive_support;
  ArrivalCapabilities capabilities;
  BuilderArrivalView builder_view;
  std::shared_ptr<const void> payload;
  ArrivalRuntimeAdapter runtime;
  // Immutable common-boundary copy. Family compilers only receive a span and
  // cannot replace this retained authored-row order or its normalization
  // diagnostics.
  std::vector<NormalizedArrivalRow> normalized_rows;
};

struct ArrivalProcessCore final {
  ArrivalProcessCore(std::shared_ptr<const CompiledArrivalLawCore> law_value,
                     std::unique_ptr<DeterministicRng> rng_value,
                     ArrivalCursorState state_value,
                     BigNat expected_slot_value,
                     std::shared_ptr<const CursorOwnerToken> owner_value,
                     Digest256 realization_identity_value) noexcept
      : law(std::move(law_value)),
        rng(std::move(rng_value)),
        state(std::move(state_value)),
        expected_slot(std::move(expected_slot_value)),
        owner(std::move(owner_value)),
        realization_identity(std::move(realization_identity_value)) {}

  std::shared_ptr<const CompiledArrivalLawCore> law;
  // Stable heap address: RngTransaction pins this object during a step.
  std::unique_ptr<DeterministicRng> rng;
  ArrivalCursorState state;
  BigNat expected_slot;
  std::shared_ptr<const CursorOwnerToken> owner;
  Digest256 realization_identity;
  mutable std::atomic_flag in_step = ATOMIC_FLAG_INIT;
};

struct BuilderArrivalServicesCore final {
  std::shared_ptr<const CompiledArrivalLawCore> law;
  BuilderArrivalViewDigest view_digest;
  bool replay_available;
  bool unit_cube_available;
};

struct ArrivalCoreAccess final {
  [[nodiscard]] static Result<CompiledArrivalLaw> publish(
      const QueueCatalog& queues, CompiledArrivalProduct product);

  [[nodiscard]] static const std::shared_ptr<const CompiledArrivalLawCore>&
  law_core(const CompiledArrivalLaw& law) noexcept;
  [[nodiscard]] static std::shared_ptr<ArrivalProcessCore> process_core(
      ArrivalProcess& process) noexcept;
  [[nodiscard]] static std::shared_ptr<const ArrivalProcessCore> process_core(
      const ArrivalProcess& process) noexcept;
  [[nodiscard]] static const std::shared_ptr<const ArrivalPhaseCore>& phase_core(
      const ArrivalPhase& phase) noexcept;

  [[nodiscard]] static CompiledArrivalLaw make_law(
      std::shared_ptr<const CompiledArrivalLawCore> core);
  [[nodiscard]] static ArrivalProcess make_process(
      ArrivalFamily family, std::shared_ptr<ArrivalProcessCore> core);
  [[nodiscard]] static ArrivalPhase make_phase(
      ArrivalFamily family, std::shared_ptr<const ArrivalPhaseCore> core);
  [[nodiscard]] static ArrivalBatch bind_empty_batch(
      ArrivalBatch batch, const ArrivalBinding& binding);
  [[nodiscard]] static InitialPhysicalLaw make_initial_law(
      ArrivalBinding binding, NormalizedPmf original_pmf,
      std::vector<InitialPhysicalAtom> atoms,
      std::vector<std::size_t> original_to_atom);
};

[[nodiscard]] Result<Digest256> digest_arrival_state(
    std::span<const std::byte> canonical_state);
[[nodiscard]] Result<QueueCatalogDigest> digest_queue_catalog(
    const QueueCatalog& queues);
[[nodiscard]] Result<ArrivalLawDigest> digest_arrival_law(
    ArrivalFamily family, const QueueCatalogDigest& catalog,
    std::span<const std::byte> canonical_law_data);

}  // namespace mwperf::detail
