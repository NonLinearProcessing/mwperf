#include "mwperf/arrival/registry.hpp"

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <boost/multiprecision/integer.hpp>

#include "core_internal.hpp"
#include "mwperf/arrival/renewal.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> failure(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

template <typename T>
[[nodiscard]] Result<T> internal_failure(std::string code,
                                         std::string message) {
  return failure<T>(DiagnosticCategory::internal, std::move(code),
                    std::move(message));
}

template <typename T>
[[nodiscard]] Result<T> resource_failure(std::string code,
                                         std::string message) {
  return failure<T>(DiagnosticCategory::resource_limit, std::move(code),
                    std::move(message));
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT32_C(0xff)));
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT64_C(0xff)));
  }
}

void append_string(std::vector<std::byte>& output,
                   const std::string_view value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  for (const char byte : value) {
    output.push_back(
        static_cast<std::byte>(static_cast<unsigned char>(byte)));
  }
}

void append_rational(std::vector<std::byte>& output,
                     const ExactRational& value) {
  append_string(output, value.numerator_decimal());
  append_string(output, value.denominator_decimal());
}

struct OperationalBinary64 final {
  std::uint64_t bits;
  double value;
};

inline constexpr std::uint64_t kMaximumPoissonUniformWordsPerVariate =
    std::numeric_limits<std::uint64_t>::max();

// Every operational-rate-dependent transcendental is compiled once.  A slot
// step therefore performs only the recurrence/rejection arithmetic and RNG
// reads; it never recomputes exp/log/sqrt or PTRS setup constants.
struct PoissonKernel final {
  OperationalBinary64 operational;
  double initial_probability;
  double ptrs_b;
  double ptrs_a;
  double ptrs_inverse_alpha;
  double ptrs_squeeze;
  double log_rate;
};

[[nodiscard]] PoissonKernel make_poisson_kernel(
    const OperationalBinary64 operational) {
  const double lambda = operational.value;
  if (lambda == 0.0) {
    return {operational, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  }
  if (lambda < 30.0) {
    return {operational, std::exp(-lambda), 0.0, 0.0, 0.0, 0.0,
            std::log(lambda)};
  }
  const double square_root = std::sqrt(lambda);
  const double b = 0.931 + 2.53 * square_root;
  const double a = -0.059 + 0.02483 * b;
  return {operational,
          0.0,
          b,
          a,
          1.1239 + 1.1328 / (b - 3.4),
          0.9277 - 3.6224 / (b - 2.0),
          std::log(lambda)};
}

[[nodiscard]] BigInt rounded_nonnegative_quotient(BigInt numerator,
                                                   BigInt denominator) {
  BigInt quotient = numerator / denominator;
  const BigInt remainder = numerator % denominator;
  const BigInt doubled = remainder << 1U;
  if (doubled > denominator ||
      (doubled == denominator && (quotient & 1U) != 0)) {
    ++quotient;
  }
  return quotient;
}

// Correct once-rounding of an exact nonnegative rational to IEEE-754 binary64
// under round-to-nearest, ties-to-even. No intermediate floating value is
// involved. Positive underflow, nonfinite results, and operational rates above
// 2^52 are rejected before a sampler can run.
[[nodiscard]] Result<OperationalBinary64> exact_rate_to_binary64(
    const ExactRational& rate) {
  if (!rate.is_nonnegative()) {
    return internal_failure<OperationalBinary64>(
        "schema4_iid_negative_rate",
        "a validated schema-4 IID rate became negative during compilation");
  }
  if (rate.is_zero()) {
    return Result<OperationalBinary64>::success({0U, 0.0});
  }

  static const ExactRational maximum = [] {
    auto made = ExactRational::make(BigInt(1) << 52U, BigInt(1));
    if (!made) {
      std::terminate();
    }
    return made.value();
  }();
  if (rate > maximum) {
    return resource_failure<OperationalBinary64>(
        "schema4_poisson_operational_rate_out_of_range",
        "a Poisson operational rate exceeds the exact CP09 maximum 2^52");
  }

  const BigInt numerator = rate.numerator();
  const BigInt denominator = rate.denominator();
  const auto numerator_msb = boost::multiprecision::msb(numerator);
  const auto denominator_msb = boost::multiprecision::msb(denominator);
  std::int64_t exponent =
      static_cast<std::int64_t>(numerator_msb) -
      static_cast<std::int64_t>(denominator_msb);
  if (exponent >= 0) {
    if (numerator < (denominator << static_cast<unsigned int>(exponent))) {
      --exponent;
    }
  } else if ((numerator << static_cast<unsigned int>(-exponent)) <
             denominator) {
    --exponent;
  }

  std::uint64_t bits = 0U;
  if (exponent < -1022) {
    if (exponent < -1075) {
      return resource_failure<OperationalBinary64>(
          "schema4_poisson_operational_rate_underflow",
          "a positive Poisson rate rounds to zero in binary64");
    }
    const BigInt rounded =
        rounded_nonnegative_quotient(numerator << 1074U, denominator);
    if (rounded == 0) {
      return resource_failure<OperationalBinary64>(
          "schema4_poisson_operational_rate_underflow",
          "a positive Poisson rate rounds to zero in binary64");
    }
    const BigInt largest_subnormal_or_minimum_normal = BigInt(1) << 52U;
    if (rounded > largest_subnormal_or_minimum_normal) {
      return internal_failure<OperationalBinary64>(
          "schema4_poisson_binary64_rounding_invariant",
          "subnormal binary64 rounding produced an out-of-range significand");
    }
    bits = rounded.convert_to<std::uint64_t>();
  } else {
    const std::int64_t shift = 52 - exponent;
    BigInt scaled_numerator = numerator;
    BigInt scaled_denominator = denominator;
    if (shift >= 0) {
      scaled_numerator <<= static_cast<unsigned int>(shift);
    } else {
      scaled_denominator <<= static_cast<unsigned int>(-shift);
    }
    BigInt significand = rounded_nonnegative_quotient(
        std::move(scaled_numerator), std::move(scaled_denominator));
    if (significand == (BigInt(1) << 53U)) {
      significand >>= 1U;
      ++exponent;
    }
    if (exponent > 1023 || significand < (BigInt(1) << 52U) ||
        significand >= (BigInt(1) << 53U)) {
      return resource_failure<OperationalBinary64>(
          "schema4_poisson_operational_rate_nonfinite",
          "a Poisson rate has no finite canonical binary64 operational image");
    }
    const std::uint64_t exponent_bits =
        static_cast<std::uint64_t>(exponent + 1023);
    const std::uint64_t fraction =
        (significand - (BigInt(1) << 52U)).convert_to<std::uint64_t>();
    bits = (exponent_bits << 52U) | fraction;
  }

  const double value = std::bit_cast<double>(bits);
  if (!std::isfinite(value) || !(value > 0.0)) {
    return internal_failure<OperationalBinary64>(
        "schema4_poisson_binary64_rounding_invariant",
        "exact binary64 rounding produced a nonpositive or nonfinite rate");
  }
  return Result<OperationalBinary64>::success({bits, value});
}

[[nodiscard]] Result<NormalizedPmf> exact_pmf(
    const std::span<const ExactRational> probabilities) {
  try {
    std::vector<AuthoredProbability> authored;
    authored.reserve(probabilities.size());
    for (const ExactRational& probability : probabilities) {
      auto converted = AuthoredProbability::from_exact(probability);
      if (!converted) {
        return Result<NormalizedPmf>::failure(converted.error());
      }
      authored.push_back(std::move(converted.value()));
    }
    auto normalized =
        validate_and_normalize_pmf(authored, physical_pmf_tolerance());
    if (!normalized) {
      return normalized;
    }
    if (!normalized.value().normalization_delta().is_zero()) {
      return internal_failure<NormalizedPmf>(
          "schema4_iid_probability_not_exactly_normalized",
          "a strict schema-4 IID categorical law required normalization");
    }
    return normalized;
  } catch (const std::bad_alloc&) {
    return resource_failure<NormalizedPmf>(
        "schema4_iid_pmf_allocation_failure",
        "constructing an exact schema-4 IID categorical row exhausted memory");
  }
}

[[nodiscard]] Result<QueueCatalogDigest> catalog_digest(
    const QueueCatalog& queues) {
  return detail::digest_queue_catalog(queues);
}

struct DenseRates final {
  std::vector<ExactRational> exact;
  std::vector<OperationalBinary64> operational;
};

[[nodiscard]] Result<DenseRates> resolve_dense_rates(
    const ExactQueueRates& authored, const QueueCatalog& queues,
    const bool require_operational) {
  try {
    std::vector<ExactRational> exact(queues.size(),
                                    authored.default_rate.value);
    for (const QueueRateOverride& item : authored.overrides.value) {
      auto queue = queues.resolve(item.queue_id.value,
                                  item.queue_id.provenance);
      if (!queue) {
        return Result<DenseRates>::failure(queue.error());
      }
      exact[queue.value().ordinal()] = item.rate.value;
    }
    std::vector<OperationalBinary64> operational;
    if (require_operational) {
      operational.reserve(exact.size());
      for (const ExactRational& rate : exact) {
        auto converted = exact_rate_to_binary64(rate);
        if (!converted) {
          return Result<DenseRates>::failure(converted.error());
        }
        operational.push_back(converted.value());
      }
    }
    return Result<DenseRates>::success(
        DenseRates{std::move(exact), std::move(operational)});
  } catch (const std::bad_alloc&) {
    return resource_failure<DenseRates>(
        "schema4_iid_rate_allocation_failure",
        "resolving the dense schema-4 IID rate vector exhausted memory");
  }
}

// The predictive state is mathematically empty.  The mutable vectors are only
// process-local atom and independent-queue modulation scratch; they are not
// encoded, digested, or consulted by any law calculation.  C09 serializes
// access to one ArrivalProcess, so reusing their capacity cannot race another
// step and avoids queue-count temporary allocations in every IID slot.
struct StatelessIidCursor final {
  mutable std::vector<ArrivalAtom> atoms;
  mutable std::vector<std::size_t> modulation_states;
};

struct BernoulliCoordinate final {
  DenseQueueIndex queue;
  bool certain;
  std::optional<NormalizedPmf> trial;
};

struct IidBernoulliLaw final {
  std::size_t queue_count;
  QueueCatalogDigest catalog;
  std::vector<ExactRational> rates;
  std::vector<BernoulliCoordinate> live;
};

struct CountOutcome final {
  std::string id;
  ExactRational probability;
  std::vector<ArrivalBatchEntry> counts;
};

struct IidCountTableLaw final {
  std::size_t queue_count;
  QueueCatalogDigest catalog;
  std::vector<CountOutcome> outcomes;
  NormalizedPmf probabilities;
};

struct IidPoissonLaw final {
  std::size_t queue_count;
  QueueCatalogDigest catalog;
  std::vector<ExactRational> rates;
  std::vector<PoissonKernel> kernels;
  std::vector<DenseQueueIndex> live;
};

struct IidMixedPoissonLaw final {
  std::size_t queue_count;
  QueueCatalogDigest catalog;
  MixedPoissonScope scope;
  std::vector<MixedPoissonState> states;
  NormalizedPmf state_probabilities;
  std::vector<ExactRational> base_rates;
  std::vector<std::vector<PoissonKernel>> kernels;
  std::vector<DenseQueueIndex> live;
};

template <typename Law>
[[nodiscard]] Result<void> validate_runtime_binding(
    const Law& law, const ArrivalFamily family, const ArrivalBinding& binding) {
  if (binding.family != family ||
      binding.timing != TimingConvention::early_service_late_admission ||
      binding.queue_cardinality != law.queue_count ||
      !(binding.catalog_digest == law.catalog)) {
    return internal_failure<void>(
        "schema4_iid_runtime_binding_mismatch",
        "a schema-4 IID runtime received a law or catalog binding mismatch");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_iid_initial(
    const ArrivalInitialState& initial) {
  if (!std::holds_alternative<RenewalOrigin>(initial)) {
    return failure<void>(
        DiagnosticCategory::input_validation,
        "arrival_initial_family_mismatch",
        "a schema-4 IID arrival law requires renewal_origin");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<detail::ArrivalCursorInitialization>
instantiate_iid_cursor(const ArrivalInitialState& initial,
                       const std::size_t queue_count) {
  auto valid = validate_iid_initial(initial);
  if (!valid) {
    return Result<detail::ArrivalCursorInitialization>::failure(valid.error());
  }
  try {
    std::vector<ArrivalAtom> atoms;
    atoms.reserve(queue_count);
    std::vector<std::size_t> modulation_states;
    modulation_states.reserve(queue_count);
    return Result<detail::ArrivalCursorInitialization>::success(
        {std::make_shared<const StatelessIidCursor>(
            StatelessIidCursor{std::move(atoms),
                               std::move(modulation_states)})});
  } catch (const std::bad_alloc&) {
    return resource_failure<detail::ArrivalCursorInitialization>(
        "schema4_iid_cursor_allocation_failure",
        "allocating the stateless schema-4 IID cursor exhausted memory");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_iid_phase(
    const detail::ArrivalCursorState& state) {
  if (!std::static_pointer_cast<const StatelessIidCursor>(state)) {
    return internal_failure<std::vector<std::byte>>(
        "schema4_iid_cursor_missing",
        "the stateless schema-4 IID cursor payload is missing");
  }
  return Result<std::vector<std::byte>>::success({});
}

[[nodiscard]] Result<ArrivalAtom> make_atom(const DenseQueueIndex queue,
                                            const BigNat& count,
                                            const ArrivalBinding& binding) {
  auto atom = ArrivalAtom::make(queue, count, binding);
  if (!atom) {
    return Result<ArrivalAtom>::failure(atom.error());
  }
  return atom;
}

[[nodiscard]] double uniform_open(DeterministicRng& rng) {
  const long double scaled =
      std::ldexp(static_cast<long double>(rng.next_u64()) + 0.5L, -64);
  double value = static_cast<double>(scaled);
  if (!(value < 1.0)) {
    value = std::nextafter(1.0, 0.0);
  }
  return value;
}

[[nodiscard]] Result<std::uint64_t> sample_poisson(const PoissonKernel& kernel,
                                                   DeterministicRng& rng) {
  const double lambda = kernel.operational.value;
  if (lambda == 0.0) {
    return Result<std::uint64_t>::success(0U);
  }
  if (!std::isfinite(lambda) || !(lambda > 0.0) ||
      lambda > 4503599627370496.0) {
    return internal_failure<std::uint64_t>(
        "schema4_poisson_operational_rate_invalid",
        "the compiled Poisson sampler received an invalid operational rate");
  }

  if (lambda < 30.0) {
    double product = 1.0;
    std::uint64_t count = 0U;
    while (true) {
      if (count == kMaximumPoissonUniformWordsPerVariate) {
        return resource_failure<std::uint64_t>(
            "schema4_poisson_retry_budget_exhausted",
            "a Poisson inversion draw exhausted its registered work bound");
      }
      product *= uniform_open(rng);
      if (product <= kernel.initial_probability) {
        return Result<std::uint64_t>::success(count);
      }
      ++count;
    }
  }

  // PTRS transformed rejection (Hörmann). The 2^52 preflight keeps every
  // accepted integer candidate exactly representable in binary64.
  const std::uint64_t maximum_attempts =
      kMaximumPoissonUniformWordsPerVariate / 2U;
  for (std::uint64_t attempt = 0U; attempt < maximum_attempts; ++attempt) {
    const double u = uniform_open(rng) - 0.5;
    const double v = uniform_open(rng);
    const double us = 0.5 - std::abs(u);
    if (!(us > 0.0)) {
      continue;
    }
    const double candidate =
        std::floor((2.0 * kernel.ptrs_a / us + kernel.ptrs_b) * u +
                   lambda + 0.43);
    if (candidate < 0.0) {
      continue;
    }
    if (candidate >= std::ldexp(1.0, 63)) {
      return resource_failure<std::uint64_t>(
          "schema4_poisson_count_overflow",
          "a Poisson draw exceeded the signed arrival-count domain");
    }
    if (us >= 0.07 && v <= kernel.ptrs_squeeze) {
      return Result<std::uint64_t>::success(
          static_cast<std::uint64_t>(candidate));
    }
    if (us < 0.013 && v > us) {
      continue;
    }
    const double lhs =
        std::log(v * kernel.ptrs_inverse_alpha /
                 (kernel.ptrs_a / (us * us) + kernel.ptrs_b));
    const double rhs = -lambda + candidate * kernel.log_rate -
                       std::lgamma(candidate + 1.0);
    if (lhs <= rhs) {
      return Result<std::uint64_t>::success(
          static_cast<std::uint64_t>(candidate));
    }
  }
  return resource_failure<std::uint64_t>(
      "schema4_poisson_retry_budget_exhausted",
      "a PTRS Poisson draw exhausted the u64 random-address domain");
}

[[nodiscard]] Result<detail::ProposedArrivalTransition> propose_bernoulli(
    const IidBernoulliLaw& law, const detail::ArrivalCursorState& state,
    const ArrivalBinding& binding, DeterministicRng& rng) {
  auto bound = validate_runtime_binding(
      law, ArrivalFamily::iid_independent_bernoulli, binding);
  if (!bound) {
    return Result<detail::ProposedArrivalTransition>::failure(bound.error());
  }
  try {
    const auto cursor =
        std::static_pointer_cast<const StatelessIidCursor>(state);
    if (!cursor) {
      return internal_failure<detail::ProposedArrivalTransition>(
          "schema4_iid_cursor_missing",
          "the Bernoulli process has no IID cursor");
    }
    cursor->atoms.clear();
    for (const BernoulliCoordinate& coordinate : law.live) {
      const bool arrives = coordinate.certain ||
                           sample_categorical(*coordinate.trial, rng) == 1U;
      if (!arrives) {
        continue;
      }
      auto atom = make_atom(coordinate.queue, BigNat(1U), binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(atom.error());
      }
      cursor->atoms.push_back(std::move(atom.value()));
    }
    return Result<detail::ProposedArrivalTransition>::success(
        {state, {}, std::span<const ArrivalAtom>(cursor->atoms)});
  } catch (const std::bad_alloc&) {
    return resource_failure<detail::ProposedArrivalTransition>(
        "schema4_iid_step_allocation_failure",
        "sampling a Bernoulli arrival vector exhausted memory");
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition> propose_count_table(
    const IidCountTableLaw& law, const detail::ArrivalCursorState& state,
    const ArrivalBinding& binding, DeterministicRng& rng) {
  auto bound =
      validate_runtime_binding(law, ArrivalFamily::iid_count_table, binding);
  if (!bound) {
    return Result<detail::ProposedArrivalTransition>::failure(bound.error());
  }
  try {
    const auto cursor =
        std::static_pointer_cast<const StatelessIidCursor>(state);
    if (!cursor) {
      return internal_failure<detail::ProposedArrivalTransition>(
          "schema4_iid_cursor_missing",
          "the count-table process has no IID cursor");
    }
    const std::size_t selected = sample_categorical(law.probabilities, rng);
    const CountOutcome& outcome = law.outcomes.at(selected);
    cursor->atoms.clear();
    for (const ArrivalBatchEntry& count : outcome.counts) {
      auto atom = make_atom(count.queue, count.count, binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(atom.error());
      }
      cursor->atoms.push_back(std::move(atom.value()));
    }
    return Result<detail::ProposedArrivalTransition>::success(
        {state, {}, std::span<const ArrivalAtom>(cursor->atoms)});
  } catch (const std::bad_alloc&) {
    return resource_failure<detail::ProposedArrivalTransition>(
        "schema4_iid_step_allocation_failure",
        "sampling an IID count-table arrival vector exhausted memory");
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition> propose_poisson(
    const IidPoissonLaw& law, const detail::ArrivalCursorState& state,
    const ArrivalBinding& binding, DeterministicRng& rng) {
  auto bound = validate_runtime_binding(
      law, ArrivalFamily::iid_independent_poisson, binding);
  if (!bound) {
    return Result<detail::ProposedArrivalTransition>::failure(bound.error());
  }
  try {
    const auto cursor =
        std::static_pointer_cast<const StatelessIidCursor>(state);
    if (!cursor) {
      return internal_failure<detail::ProposedArrivalTransition>(
          "schema4_iid_cursor_missing",
          "the independent-Poisson process has no IID cursor");
    }
    cursor->atoms.clear();
    for (const DenseQueueIndex queue : law.live) {
      auto count = sample_poisson(law.kernels[queue.ordinal()], rng);
      if (!count) {
        return Result<detail::ProposedArrivalTransition>::failure(count.error());
      }
      if (count.value() == 0U) {
        continue;
      }
      auto atom = make_atom(queue, BigNat(count.value()), binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(atom.error());
      }
      cursor->atoms.push_back(std::move(atom.value()));
    }
    return Result<detail::ProposedArrivalTransition>::success(
        {state, {}, std::span<const ArrivalAtom>(cursor->atoms)});
  } catch (const std::bad_alloc&) {
    return resource_failure<detail::ProposedArrivalTransition>(
        "schema4_iid_step_allocation_failure",
        "sampling an independent Poisson arrival vector exhausted memory");
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition>
propose_mixed_poisson(const IidMixedPoissonLaw& law,
                      const detail::ArrivalCursorState& state,
                      const ArrivalBinding& binding, DeterministicRng& rng) {
  auto bound =
      validate_runtime_binding(law, ArrivalFamily::iid_mixed_poisson, binding);
  if (!bound) {
    return Result<detail::ProposedArrivalTransition>::failure(bound.error());
  }
  try {
    const auto cursor =
        std::static_pointer_cast<const StatelessIidCursor>(state);
    if (!cursor) {
      return internal_failure<detail::ProposedArrivalTransition>(
          "schema4_iid_cursor_missing",
          "the mixed-Poisson process has no IID cursor");
    }
    std::size_t shared_state = 0U;
    if (law.scope == MixedPoissonScope::shared) {
      shared_state = sample_categorical(law.state_probabilities, rng);
    } else {
      cursor->modulation_states.clear();
      for (std::size_t index = 0U; index < law.live.size(); ++index) {
        cursor->modulation_states.push_back(
            sample_categorical(law.state_probabilities, rng));
      }
    }

    cursor->atoms.clear();
    for (std::size_t index = 0U; index < law.live.size(); ++index) {
      const DenseQueueIndex queue = law.live[index];
      const std::size_t selected =
          law.scope == MixedPoissonScope::shared
              ? shared_state
              : cursor->modulation_states[index];
      auto count = sample_poisson(
          law.kernels[queue.ordinal()][selected], rng);
      if (!count) {
        return Result<detail::ProposedArrivalTransition>::failure(count.error());
      }
      if (count.value() == 0U) {
        continue;
      }
      auto atom = make_atom(queue, BigNat(count.value()), binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(atom.error());
      }
      cursor->atoms.push_back(std::move(atom.value()));
    }
    return Result<detail::ProposedArrivalTransition>::success(
        {state, {}, std::span<const ArrivalAtom>(cursor->atoms)});
  } catch (const std::bad_alloc&) {
    return resource_failure<detail::ProposedArrivalTransition>(
        "schema4_iid_step_allocation_failure",
        "sampling a mixed-Poisson arrival vector exhausted memory");
  }
}

[[nodiscard]] ArrivalCapabilities iid_capabilities(const bool finite_joint) {
  ArrivalCapabilities capabilities;
  capabilities.exact_positive_support = CapabilityAvailability::available;
  capabilities.sequential_normalized_sampler = CapabilityAvailability::available;
  capabilities.exact_portable_iid_recipe =
      ExactPortableIidRecipeCapability{AccessProvision::portable_only};
  capabilities.exact_coordinate_moments = MomentCapability{
      BigNat(2U), false, false, AccessProvision::portable_only};
  capabilities.exact_covariance = CapabilityAvailability::available;
  if (finite_joint) {
    capabilities.exact_iid_joint_vector = ExactIidJointVectorCapability{
        true, AccessProvision::portable_only};
  }
  return capabilities;
}

[[nodiscard]] std::vector<ExactMomentDatum> coordinate_moments(
    const QueueCatalog& queues, const std::span<const ExactRational> means,
    const std::span<const ExactRational> second_moments) {
  std::vector<ExactMomentDatum> moments;
  moments.reserve(queues.size() * 2U);
  for (std::size_t ordinal = 0U; ordinal < queues.size(); ++ordinal) {
    auto queue = queues.index_at(ordinal);
    if (!queue) {
      throw std::logic_error("validated queue ordinal disappeared");
    }
    moments.push_back({{queue.value()}, BigNat(1U), means[ordinal]});
    moments.push_back(
        {{queue.value()}, BigNat(2U), second_moments[ordinal]});
  }
  return moments;
}

[[nodiscard]] std::vector<ExactMomentDatum> covariance_table(
    const QueueCatalog& queues,
    const std::vector<std::vector<ExactRational>>& covariance) {
  std::vector<ExactMomentDatum> table;
  table.reserve(queues.size() * (queues.size() + 1U) / 2U);
  for (std::size_t left = 0U; left < queues.size(); ++left) {
    auto left_queue = queues.index_at(left);
    if (!left_queue) {
      throw std::logic_error("validated queue ordinal disappeared");
    }
    for (std::size_t right = left; right < queues.size(); ++right) {
      auto right_queue = queues.index_at(right);
      if (!right_queue) {
        throw std::logic_error("validated queue ordinal disappeared");
      }
      table.push_back({{left_queue.value(), right_queue.value()}, BigNat(2U),
                       covariance[left][right]});
    }
  }
  return table;
}

[[nodiscard]] Result<std::vector<std::byte>> encode_bernoulli(
    const IidBernoulliLaw& law) {
  try {
    std::vector<std::byte> output;
    append_string(output, "mwperf.c32.iid_independent_bernoulli.v1");
    append_u32(output, 1U);
    append_u64(output, static_cast<std::uint64_t>(law.queue_count));
    for (const ExactRational& rate : law.rates) {
      append_rational(output, rate);
    }
    return Result<std::vector<std::byte>>::success(std::move(output));
  } catch (const std::bad_alloc&) {
    return resource_failure<std::vector<std::byte>>(
        "schema4_iid_encoding_allocation_failure",
        "encoding the Bernoulli portable recipe exhausted memory");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_count_table(
    const IidCountTableLaw& law) {
  try {
    std::vector<std::byte> output;
    append_string(output, "mwperf.c32.iid_count_table.v1");
    append_u32(output, 1U);
    append_u64(output, static_cast<std::uint64_t>(law.queue_count));
    append_u64(output, static_cast<std::uint64_t>(law.outcomes.size()));
    for (const CountOutcome& outcome : law.outcomes) {
      append_string(output, outcome.id);
      append_rational(output, outcome.probability);
      append_u64(output, static_cast<std::uint64_t>(outcome.counts.size()));
      for (const ArrivalBatchEntry& count : outcome.counts) {
        append_u64(output,
                   static_cast<std::uint64_t>(count.queue.ordinal()));
        append_u64(output, count.count.value().convert_to<std::uint64_t>());
      }
    }
    return Result<std::vector<std::byte>>::success(std::move(output));
  } catch (const std::bad_alloc&) {
    return resource_failure<std::vector<std::byte>>(
        "schema4_iid_encoding_allocation_failure",
        "encoding the count-table portable recipe exhausted memory");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_poisson(
    const IidPoissonLaw& law) {
  try {
    std::vector<std::byte> output;
    append_string(output, "mwperf.c32.iid_independent_poisson.v1");
    append_u32(output, 1U);
    append_u64(output, static_cast<std::uint64_t>(law.queue_count));
    for (std::size_t index = 0U; index < law.queue_count; ++index) {
      append_rational(output, law.rates[index]);
      append_u64(output, law.kernels[index].operational.bits);
    }
    return Result<std::vector<std::byte>>::success(std::move(output));
  } catch (const std::bad_alloc&) {
    return resource_failure<std::vector<std::byte>>(
        "schema4_iid_encoding_allocation_failure",
        "encoding the Poisson portable recipe exhausted memory");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_mixed_poisson(
    const IidMixedPoissonLaw& law) {
  try {
    std::vector<std::byte> output;
    append_string(output, "mwperf.c32.iid_mixed_poisson.v1");
    append_u32(output, 1U);
    append_u64(output, static_cast<std::uint64_t>(law.queue_count));
    output.push_back(static_cast<std::byte>(
        law.scope == MixedPoissonScope::shared ? 0U : 1U));
    append_u64(output, static_cast<std::uint64_t>(law.states.size()));
    for (const MixedPoissonState& state : law.states) {
      append_string(output, state.id.value);
      append_rational(output, state.probability.value.exact_value());
      append_rational(output, state.multiplier.value);
    }
    for (const ExactRational& rate : law.base_rates) {
      append_rational(output, rate);
    }
    for (const auto& row : law.kernels) {
      for (const PoissonKernel& value : row) {
        append_u64(output, value.operational.bits);
      }
    }
    return Result<std::vector<std::byte>>::success(std::move(output));
  } catch (const std::bad_alloc&) {
    return resource_failure<std::vector<std::byte>>(
        "schema4_iid_encoding_allocation_failure",
        "encoding the mixed-Poisson portable recipe exhausted memory");
  }
}

template <typename Law, typename Propose>
[[nodiscard]] detail::ArrivalRuntimeAdapter stateless_runtime(Propose propose) {
  detail::ArrivalRuntimeAdapter runtime;
  runtime.validate_initial =
      [](const std::shared_ptr<const void>&,
         const ArrivalInitialState& initial) {
        return validate_iid_initial(initial);
      };
  runtime.instantiate =
      [](const std::shared_ptr<const void>& erased,
         const ArrivalInitialState& initial, DeterministicRng&) {
        const auto law = std::static_pointer_cast<const Law>(erased);
        if (!law) {
          return internal_failure<detail::ArrivalCursorInitialization>(
              "schema4_iid_payload_missing",
              "the schema-4 IID runtime has no immutable law payload");
        }
        return instantiate_iid_cursor(initial, law->queue_count);
      };
  runtime.encode_phase =
      [](const std::shared_ptr<const void>&,
         const detail::ArrivalCursorState& state) {
        return encode_iid_phase(state);
      };
  runtime.propose =
      [propose](const std::shared_ptr<const void>& erased,
                const detail::ArrivalCursorState& state, const BigNat&,
                const ArrivalBinding& binding, DeterministicRng& rng) {
        const auto law = std::static_pointer_cast<const Law>(erased);
        if (!law) {
          return internal_failure<detail::ProposedArrivalTransition>(
              "schema4_iid_payload_missing",
              "the schema-4 IID runtime has no immutable law payload");
        }
        return propose(*law, state, binding, rng);
      };
  return runtime;
}

}  // namespace

namespace detail {

Result<CompiledArrivalProduct> compile_iid_independent_bernoulli_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<IidIndependentBernoulliArrival>(&request.authored.value);
  if (authored == nullptr || !request.normalized_rows.empty()) {
    return internal_failure<CompiledArrivalProduct>(
        "schema4_iid_authored_variant_mismatch",
        "the Bernoulli registry slot received another authored family or rows");
  }
  try {
    auto dense = resolve_dense_rates(authored->rates, request.queues, false);
    if (!dense) {
      return Result<CompiledArrivalProduct>::failure(dense.error());
    }
    auto catalog = catalog_digest(request.queues);
    if (!catalog) {
      return Result<CompiledArrivalProduct>::failure(catalog.error());
    }
    std::vector<BernoulliCoordinate> live;
    std::vector<ExactRational> means = dense.value().exact;
    std::vector<ExactRational> second = means;
    std::vector<std::vector<ExactRational>> covariance(
        request.queues.size(),
        std::vector<ExactRational>(request.queues.size(),
                                   ExactRational::zero()));
    for (std::size_t ordinal = 0U; ordinal < request.queues.size(); ++ordinal) {
      const ExactRational& rate = dense.value().exact[ordinal];
      covariance[ordinal][ordinal] = rate - rate * rate;
      if (rate.is_zero()) {
        continue;
      }
      auto queue = request.queues.index_at(ordinal);
      if (!queue) {
        return Result<CompiledArrivalProduct>::failure(queue.error());
      }
      if (rate == ExactRational::one()) {
        live.push_back({queue.value(), true, std::nullopt});
      } else {
        const std::vector<ExactRational> probabilities{
            ExactRational::one() - rate, rate};
        auto pmf = exact_pmf(probabilities);
        if (!pmf) {
          return Result<CompiledArrivalProduct>::failure(pmf.error());
        }
        live.push_back(
            {queue.value(), false, std::move(pmf.value())});
      }
    }
    IidBernoulliLaw law{request.queues.size(), catalog.value(),
                        dense.value().exact, std::move(live)};
    auto canonical = encode_bernoulli(law);
    if (!canonical) {
      return Result<CompiledArrivalProduct>::failure(canonical.error());
    }
    std::vector<std::uint8_t> support;
    support.reserve(law.rates.size());
    for (const ExactRational& rate : law.rates) {
      support.push_back(rate.is_positive() ? 1U : 0U);
    }
    auto payload = std::make_shared<const IidBernoulliLaw>(std::move(law));
    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::iid_independent_bernoulli,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = iid_capabilities(false),
        .canonical_law_data = std::move(canonical.value()),
        .portable_schema =
            PortableArrivalLawSchema::iid_independent_bernoulli_v1,
        .payload = std::move(payload),
        .runtime = stateless_runtime<IidBernoulliLaw>(propose_bernoulli),
        .iid_joint_table = std::nullopt,
        .moments = coordinate_moments(request.queues, means, second),
        .covariances = covariance_table(request.queues, covariance),
    });
  } catch (const std::bad_alloc&) {
    return resource_failure<CompiledArrivalProduct>(
        "schema4_iid_compile_allocation_failure",
        "compiling the Bernoulli arrival law exhausted memory");
  }
}

Result<CompiledArrivalProduct> compile_iid_count_table_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<IidCountTableArrival>(&request.authored.value);
  if (authored == nullptr || !request.normalized_rows.empty()) {
    return internal_failure<CompiledArrivalProduct>(
        "schema4_iid_authored_variant_mismatch",
        "the count-table registry slot received another authored family or rows");
  }
  try {
    auto catalog = catalog_digest(request.queues);
    if (!catalog) {
      return Result<CompiledArrivalProduct>::failure(catalog.error());
    }
    std::vector<CountOutcome> outcomes;
    std::vector<ExactRational> probabilities;
    outcomes.reserve(authored->outcomes.value.size());
    probabilities.reserve(authored->outcomes.value.size());
    for (const IidCountOutcome& source : authored->outcomes.value) {
      std::vector<ArrivalBatchEntry> counts;
      counts.reserve(source.counts.value.size());
      for (const IidCountEntry& count : source.counts.value) {
        auto queue = request.queues.resolve(count.queue_id.value,
                                            count.queue_id.provenance);
        if (!queue) {
          return Result<CompiledArrivalProduct>::failure(queue.error());
        }
        counts.push_back({queue.value(), count.count.value});
      }
      std::sort(counts.begin(), counts.end(),
                [](const ArrivalBatchEntry& left,
                   const ArrivalBatchEntry& right) {
                  return left.queue.ordinal() < right.queue.ordinal();
                });
      probabilities.push_back(source.probability.value.exact_value());
      outcomes.push_back({source.id.value,
                          source.probability.value.exact_value(),
                          std::move(counts)});
    }
    auto pmf = exact_pmf(probabilities);
    if (!pmf) {
      return Result<CompiledArrivalProduct>::failure(pmf.error());
    }
    IidCountTableLaw law{request.queues.size(), catalog.value(),
                         std::move(outcomes), std::move(pmf.value())};
    auto canonical = encode_count_table(law);
    if (!canonical) {
      return Result<CompiledArrivalProduct>::failure(canonical.error());
    }

    std::vector<ExactRational> means(request.queues.size(),
                                     ExactRational::zero());
    std::vector<ExactRational> second(request.queues.size(),
                                      ExactRational::zero());
    std::vector<std::vector<ExactRational>> cross(
        request.queues.size(),
        std::vector<ExactRational>(request.queues.size(),
                                   ExactRational::zero()));
    std::map<std::vector<BigNat>, ExactRational> coalesced;
    for (const CountOutcome& outcome : law.outcomes) {
      std::vector<BigNat> dense_counts(request.queues.size(), BigNat(0U));
      for (const ArrivalBatchEntry& item : outcome.counts) {
        dense_counts[item.queue.ordinal()] = item.count;
      }
      auto [position, inserted] =
          coalesced.try_emplace(dense_counts, outcome.probability);
      if (!inserted) {
        position->second = position->second + outcome.probability;
      }
      std::vector<ExactRational> dense_exact;
      dense_exact.reserve(dense_counts.size());
      for (const BigNat& count : dense_counts) {
        auto exact = ExactRational::make(count.value(), BigInt(1));
        if (!exact) {
          return Result<CompiledArrivalProduct>::failure(exact.error());
        }
        dense_exact.push_back(std::move(exact).value());
      }
      for (std::size_t left = 0U; left < dense_counts.size(); ++left) {
        means[left] = means[left] + outcome.probability * dense_exact[left];
        second[left] = second[left] + outcome.probability *
                                          dense_exact[left] *
                                          dense_exact[left];
        for (std::size_t right = left; right < dense_counts.size(); ++right) {
          cross[left][right] =
              cross[left][right] + outcome.probability *
                                       dense_exact[left] *
                                       dense_exact[right];
        }
      }
    }
    std::vector<std::vector<ExactRational>> covariance = cross;
    for (std::size_t left = 0U; left < request.queues.size(); ++left) {
      for (std::size_t right = left; right < request.queues.size(); ++right) {
        covariance[left][right] =
            covariance[left][right] - means[left] * means[right];
      }
    }
    std::vector<ExactJointBatchMass> joint;
    joint.reserve(coalesced.size());
    std::vector<std::uint8_t> support(request.queues.size(), 0U);
    for (auto& [counts, probability] : coalesced) {
      for (std::size_t index = 0U; index < counts.size(); ++index) {
        if (!counts[index].is_zero()) {
          support[index] = 1U;
        }
      }
      joint.push_back({std::move(counts), std::move(probability)});
    }
    auto payload = std::make_shared<const IidCountTableLaw>(std::move(law));
    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::iid_count_table,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = iid_capabilities(true),
        .canonical_law_data = std::move(canonical.value()),
        .portable_schema = PortableArrivalLawSchema::iid_count_table_v1,
        .payload = std::move(payload),
        .runtime = stateless_runtime<IidCountTableLaw>(propose_count_table),
        .iid_joint_table = std::move(joint),
        .moments = coordinate_moments(request.queues, means, second),
        .covariances = covariance_table(request.queues, covariance),
    });
  } catch (const std::bad_alloc&) {
    return resource_failure<CompiledArrivalProduct>(
        "schema4_iid_compile_allocation_failure",
        "compiling the count-table arrival law exhausted memory");
  }
}

Result<CompiledArrivalProduct> compile_iid_independent_poisson_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<IidIndependentPoissonArrival>(&request.authored.value);
  if (authored == nullptr || !request.normalized_rows.empty()) {
    return internal_failure<CompiledArrivalProduct>(
        "schema4_iid_authored_variant_mismatch",
        "the Poisson registry slot received another authored family or rows");
  }
  try {
    auto dense = resolve_dense_rates(authored->rates, request.queues, true);
    if (!dense) {
      return Result<CompiledArrivalProduct>::failure(dense.error());
    }
    auto catalog = catalog_digest(request.queues);
    if (!catalog) {
      return Result<CompiledArrivalProduct>::failure(catalog.error());
    }
    std::vector<DenseQueueIndex> live;
    std::vector<ExactRational> means = dense.value().exact;
    std::vector<ExactRational> second;
    second.reserve(means.size());
    std::vector<std::vector<ExactRational>> covariance(
        request.queues.size(),
        std::vector<ExactRational>(request.queues.size(),
                                   ExactRational::zero()));
    for (std::size_t ordinal = 0U; ordinal < means.size(); ++ordinal) {
      second.push_back(means[ordinal] + means[ordinal] * means[ordinal]);
      covariance[ordinal][ordinal] = means[ordinal];
      if (means[ordinal].is_positive()) {
        auto queue = request.queues.index_at(ordinal);
        if (!queue) {
          return Result<CompiledArrivalProduct>::failure(queue.error());
        }
        live.push_back(queue.value());
      }
    }
    std::vector<PoissonKernel> kernels;
    kernels.reserve(dense.value().operational.size());
    for (const OperationalBinary64 rate : dense.value().operational) {
      kernels.push_back(make_poisson_kernel(rate));
    }
    IidPoissonLaw law{request.queues.size(), catalog.value(),
                      std::move(dense.value().exact), std::move(kernels),
                      std::move(live)};
    auto canonical = encode_poisson(law);
    if (!canonical) {
      return Result<CompiledArrivalProduct>::failure(canonical.error());
    }
    std::vector<std::uint8_t> support;
    support.reserve(law.rates.size());
    for (const ExactRational& rate : law.rates) {
      support.push_back(rate.is_positive() ? 1U : 0U);
    }
    auto payload = std::make_shared<const IidPoissonLaw>(std::move(law));
    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::iid_independent_poisson,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = iid_capabilities(false),
        .canonical_law_data = std::move(canonical.value()),
        .portable_schema =
            PortableArrivalLawSchema::iid_independent_poisson_v1,
        .payload = std::move(payload),
        .runtime = stateless_runtime<IidPoissonLaw>(propose_poisson),
        .iid_joint_table = std::nullopt,
        .moments = coordinate_moments(request.queues, means, second),
        .covariances = covariance_table(request.queues, covariance),
    });
  } catch (const std::bad_alloc&) {
    return resource_failure<CompiledArrivalProduct>(
        "schema4_iid_compile_allocation_failure",
        "compiling the Poisson arrival law exhausted memory");
  }
}

Result<CompiledArrivalProduct> compile_iid_mixed_poisson_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<IidMixedPoissonArrival>(&request.authored.value);
  if (authored == nullptr || !request.normalized_rows.empty()) {
    return internal_failure<CompiledArrivalProduct>(
        "schema4_iid_authored_variant_mismatch",
        "the mixed-Poisson registry slot received another family or rows");
  }
  try {
    auto dense = resolve_dense_rates(authored->rates, request.queues, false);
    if (!dense) {
      return Result<CompiledArrivalProduct>::failure(dense.error());
    }
    auto catalog = catalog_digest(request.queues);
    if (!catalog) {
      return Result<CompiledArrivalProduct>::failure(catalog.error());
    }
    std::vector<ExactRational> state_probabilities;
    state_probabilities.reserve(authored->modulation.states.value.size());
    for (const MixedPoissonState& state :
         authored->modulation.states.value) {
      state_probabilities.push_back(state.probability.value.exact_value());
    }
    auto state_pmf = exact_pmf(state_probabilities);
    if (!state_pmf) {
      return Result<CompiledArrivalProduct>::failure(state_pmf.error());
    }
    std::vector<std::vector<PoissonKernel>> kernels;
    kernels.reserve(request.queues.size());
    std::vector<DenseQueueIndex> live;
    for (std::size_t queue = 0U; queue < request.queues.size(); ++queue) {
      std::vector<PoissonKernel> row;
      row.reserve(authored->modulation.states.value.size());
      for (const MixedPoissonState& state :
           authored->modulation.states.value) {
        const ExactRational product =
            dense.value().exact[queue] * state.multiplier.value;
        auto converted = exact_rate_to_binary64(product);
        if (!converted) {
          return Result<CompiledArrivalProduct>::failure(converted.error());
        }
        row.push_back(make_poisson_kernel(converted.value()));
      }
      kernels.push_back(std::move(row));
      if (dense.value().exact[queue].is_positive()) {
        auto index = request.queues.index_at(queue);
        if (!index) {
          return Result<CompiledArrivalProduct>::failure(index.error());
        }
        live.push_back(index.value());
      }
    }
    const ExactRational m2 =
        authored->modulation.second_moment_multiplier.value;
    std::vector<ExactRational> means = dense.value().exact;
    std::vector<ExactRational> second;
    second.reserve(means.size());
    std::vector<std::vector<ExactRational>> covariance(
        request.queues.size(),
        std::vector<ExactRational>(request.queues.size(),
                                   ExactRational::zero()));
    const ExactRational excess = m2 - ExactRational::one();
    for (std::size_t left = 0U; left < means.size(); ++left) {
      second.push_back(means[left] + means[left] * means[left] * m2);
      covariance[left][left] =
          means[left] + means[left] * means[left] * excess;
      if (authored->modulation.scope.value == MixedPoissonScope::shared) {
        for (std::size_t right = left + 1U; right < means.size(); ++right) {
          covariance[left][right] = means[left] * means[right] * excess;
        }
      }
    }
    IidMixedPoissonLaw law{
        request.queues.size(), catalog.value(),
        authored->modulation.scope.value,
        authored->modulation.states.value, std::move(state_pmf.value()),
        std::move(dense.value().exact), std::move(kernels),
        std::move(live)};
    auto canonical = encode_mixed_poisson(law);
    if (!canonical) {
      return Result<CompiledArrivalProduct>::failure(canonical.error());
    }
    std::vector<std::uint8_t> support;
    support.reserve(law.base_rates.size());
    for (const ExactRational& rate : law.base_rates) {
      support.push_back(rate.is_positive() ? 1U : 0U);
    }
    auto payload =
        std::make_shared<const IidMixedPoissonLaw>(std::move(law));
    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::iid_mixed_poisson,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = iid_capabilities(false),
        .canonical_law_data = std::move(canonical.value()),
        .portable_schema = PortableArrivalLawSchema::iid_mixed_poisson_v1,
        .payload = std::move(payload),
        .runtime =
            stateless_runtime<IidMixedPoissonLaw>(propose_mixed_poisson),
        .iid_joint_table = std::nullopt,
        .moments = coordinate_moments(request.queues, means, second),
        .covariances = covariance_table(request.queues, covariance),
    });
  } catch (const std::bad_alloc&) {
    return resource_failure<CompiledArrivalProduct>(
        "schema4_iid_compile_allocation_failure",
        "compiling the mixed-Poisson arrival law exhausted memory");
  }
}

}  // namespace detail

Result<std::vector<ExactTargetIidBatchMass>> project_exact_iid_target_pmf(
    const CompiledArrivalLaw& law, const DenseQueueIndex target) {
  if (law.family() == ArrivalFamily::independent_marked_renewal) {
    return project_exact_factorized_iid_target_pmf(law, target);
  }
  const BuilderArrivalView view = builder_arrival_view(law);
  if (target.ordinal() >= view.binding().queue_cardinality) {
    return failure<std::vector<ExactTargetIidBatchMass>>(
        DiagnosticCategory::input_validation,
        "iid_target_projection_out_of_range",
        "the requested IID target coordinate is outside the queue catalog");
  }
  if (law.family() == ArrivalFamily::iid_independent_bernoulli) {
    if (!view.moments().has_value()) {
      return internal_failure<std::vector<ExactTargetIidBatchMass>>(
          "iid_target_projection_moment_missing",
          "the Bernoulli target mean is absent from the portable view");
    }
    const auto first = std::ranges::find_if(
        *view.moments(), [&](const auto& datum) {
          return datum.coordinates.size() == 1U &&
                 datum.coordinates.front() == target &&
                 datum.order == BigNat(1U);
        });
    if (first == view.moments()->end()) {
      return internal_failure<std::vector<ExactTargetIidBatchMass>>(
          "iid_target_projection_moment_missing",
          "the Bernoulli target mean is absent from the portable view");
    }
    std::vector<ExactTargetIidBatchMass> result;
    const ExactRational zero = ExactRational::one() - first->value;
    if (zero.is_positive()) {
      result.push_back({BigNat(0U), zero});
    }
    if (first->value.is_positive()) {
      result.push_back({BigNat(1U), first->value});
    }
    return Result<std::vector<ExactTargetIidBatchMass>>::success(
        std::move(result));
  }
  if (law.family() == ArrivalFamily::iid_count_table &&
      view.iid_joint_table().has_value()) {
    std::map<BigNat, ExactRational> projected;
    for (const ExactJointBatchMass& atom : *view.iid_joint_table()) {
      auto [position, inserted] = projected.try_emplace(
          atom.dense_counts[target.ordinal()], atom.probability);
      if (!inserted) {
        position->second = position->second + atom.probability;
      }
    }
    std::vector<ExactTargetIidBatchMass> result;
    result.reserve(projected.size());
    for (auto& [count, probability] : projected) {
      if (probability.is_positive()) {
        result.push_back({std::move(count), std::move(probability)});
      }
    }
    return Result<std::vector<ExactTargetIidBatchMass>>::success(
        std::move(result));
  }
  return failure<std::vector<ExactTargetIidBatchMass>>(
      DiagnosticCategory::unavailable,
      "iid_target_finite_pmf_unavailable",
      "the configured IID target law has infinite support and publishes a compact analytic recipe rather than finite atoms");
}

}  // namespace mwperf
