#include "mwperf/arrival/private_markov_renewal.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/registry.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  std::optional<std::string> authored_path;
  std::optional<std::string> json_pointer;
  if (provenance.has_value()) {
    json_pointer = provenance->json_pointer;
    if (provenance->location.has_value()) {
      authored_path = provenance->location->authored_path;
      notes.insert(notes.begin(),
                   "line " +
                       std::to_string(provenance->location->line) +
                       ", column " +
                       std::to_string(provenance->location->column));
    }
  }
  return Diagnostic{category, std::move(code), std::move(message),
                    std::move(authored_path), std::move(json_pointer),
                    std::move(notes)};
}

template <typename Value>
[[nodiscard]] Result<Value> input_failure(
    std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(diagnostic(
      DiagnosticCategory::input_validation, std::move(code),
      std::move(message), provenance, std::move(notes)));
}

template <typename Value>
[[nodiscard]] Result<Value> internal_failure(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(diagnostic(
      DiagnosticCategory::internal, std::move(code), std::move(message),
      std::nullopt, std::move(notes)));
}

template <typename Value>
[[nodiscard]] Result<Value> allocation_failure(std::string operation) {
  return Result<Value>::failure(diagnostic(
      DiagnosticCategory::resource_limit,
      "private_markov_arrival_allocation_failure",
      "memory allocation failed while " + std::move(operation)));
}

[[nodiscard]] bool positive(const ExactRational& value) noexcept {
  return value.numerator() > 0;
}

[[nodiscard]] Result<void> append_normalized_row(
    std::vector<NormalizedArrivalRow>& rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::size_t state_ordinal,
    const std::span<const AuthoredProbability> probabilities) {
  auto normalized = validate_and_normalize_pmf(
      probabilities, physical_pmf_tolerance());
  if (!normalized) {
    return Result<void>::failure(normalized.error());
  }
  rows.push_back(NormalizedArrivalRow{
      kind, source_ordinal, state_ordinal, std::move(normalized).value()});
  return Result<void>::success();
}

// Standalone F-C11-03 has no common registry in front of it, so it performs
// the same exactly-once normalization traversal as C09. The product compiler
// below never calls this helper: it consumes request.normalized_rows as-is.
[[nodiscard]] Result<std::vector<NormalizedArrivalRow>>
normalize_private_rows_once(
    const IndependentPrivateMarkovRenewalArrival& authored) {
  try {
    std::vector<NormalizedArrivalRow> rows;
    for (std::size_t source_ordinal = 0U;
         source_ordinal < authored.sources.value.size(); ++source_ordinal) {
      const PrivateMarkovRenewalSource& source =
          authored.sources.value[source_ordinal];

      if (const auto* distribution =
              std::get_if<InitialStateDistribution>(&source.initial.value)) {
        std::vector<AuthoredProbability> probabilities;
        probabilities.reserve(distribution->distribution.value.size());
        for (const StateProbability& mass :
             distribution->distribution.value) {
          probabilities.push_back(mass.probability.value);
        }
        auto appended = append_normalized_row(
            rows, ArrivalCategoricalRowKind::private_initial_state,
            source_ordinal, 0U, probabilities);
        if (!appended) {
          return Result<std::vector<NormalizedArrivalRow>>::failure(
              appended.error());
        }
      }

      std::vector<std::string> row_keys;
      row_keys.reserve(source.states.value.size() +
                       source.transitions.value.size());
      for (const NormalizedToken& state : source.states.value) {
        if (std::ranges::find(row_keys, state.value) == row_keys.end()) {
          row_keys.push_back(state.value);
        }
      }
      for (const StateTransition& transition : source.transitions.value) {
        if (std::ranges::find(row_keys, transition.state.value) ==
            row_keys.end()) {
          row_keys.push_back(transition.state.value);
        }
      }
      for (std::size_t state_ordinal = 0U;
           state_ordinal < row_keys.size(); ++state_ordinal) {
        std::vector<AuthoredProbability> probabilities;
        for (const StateTransition& transition : source.transitions.value) {
          if (transition.state.value == row_keys[state_ordinal]) {
            probabilities.push_back(transition.probability.value);
          }
        }
        if (probabilities.empty()) {
          continue;
        }
        auto appended = append_normalized_row(
            rows, ArrivalCategoricalRowKind::private_transition,
            source_ordinal, state_ordinal, probabilities);
        if (!appended) {
          return Result<std::vector<NormalizedArrivalRow>>::failure(
              appended.error());
        }
      }

      std::vector<AuthoredProbability> destinations;
      destinations.reserve(source.destination_pmf.value.size());
      for (const DestinationProbability& mass :
           source.destination_pmf.value) {
        destinations.push_back(mass.probability.value);
      }
      auto appended = append_normalized_row(
          rows, ArrivalCategoricalRowKind::destination, source_ordinal, 0U,
          destinations);
      if (!appended) {
        return Result<std::vector<NormalizedArrivalRow>>::failure(
            appended.error());
      }
    }
    return Result<std::vector<NormalizedArrivalRow>>::success(
        std::move(rows));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<NormalizedArrivalRow>>(
        "normalizing private Markov categorical rows");
  } catch (const std::length_error&) {
    return Result<std::vector<NormalizedArrivalRow>>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "private_markov_arrival_representation_failure",
        "the private Markov categorical-row representation exceeds a host "
        "container limit"));
  }
}

class NormalizedRowReader final {
 public:
  explicit NormalizedRowReader(
      const std::span<const NormalizedArrivalRow> rows) noexcept
      : rows_(rows) {}

  [[nodiscard]] Result<NormalizedPmf> consume(
      const ArrivalCategoricalRowKind kind,
      const std::size_t source_ordinal,
      const std::size_t state_ordinal,
      const std::span<const AuthoredProbability> authored) {
    if (position_ >= rows_.size()) {
      return internal_failure<NormalizedPmf>(
          "private_markov_normalized_row_missing",
          "the exactly-once-normalized private Markov row table ended "
          "before the immutable family compiler consumed every row");
    }
    const NormalizedArrivalRow& row = rows_[position_];
    if (row.kind != kind || row.source_ordinal != source_ordinal ||
        row.state_ordinal != state_ordinal ||
        row.pmf.size() != authored.size() ||
        row.pmf.authored_probabilities().size() != authored.size()) {
      return internal_failure<NormalizedPmf>(
          "private_markov_normalized_row_mismatch",
          "a retained normalized row does not match its private Markov "
          "authored coordinate");
    }
    for (std::size_t index = 0U; index < authored.size(); ++index) {
      if (!(row.pmf.authored_probabilities()[index] == authored[index])) {
        return internal_failure<NormalizedPmf>(
            "private_markov_normalized_row_mismatch",
            "a retained normalized private Markov row changed an authored "
            "probability coordinate");
      }
    }
    ++position_;
    return Result<NormalizedPmf>::success(row.pmf);
  }

  [[nodiscard]] Result<void> finish() const {
    if (position_ != rows_.size()) {
      return internal_failure<void>(
          "private_markov_normalized_row_extra",
          "the exactly-once-normalized private Markov row table contains an "
          "unconsumed or unexpected row");
    }
    return Result<void>::success();
  }

 private:
  std::span<const NormalizedArrivalRow> rows_;
  std::size_t position_{0U};
};

struct PrivateMarkovLawParts final {
  std::size_t queue_count;
  QueueCatalogDigest catalog_digest;
  std::vector<PrivateMarkovLawSource> sources;
};

[[nodiscard]] Result<PrivateMarkovLawParts> build_private_markov_law(
    const IndependentPrivateMarkovRenewalArrival& authored,
    const QueueCatalog& queues,
    const std::span<const NormalizedArrivalRow> normalized_rows) {
  if (authored.sources.value.empty()) {
    return input_failure<PrivateMarkovLawParts>(
        "private_markov_empty_sources",
        "an independent private Markov renewal law requires at least one "
        "source",
        authored.sources.provenance);
  }

  try {
    auto catalog_digest = detail::digest_queue_catalog(queues);
    if (!catalog_digest) {
      return Result<PrivateMarkovLawParts>::failure(catalog_digest.error());
    }

    NormalizedRowReader rows(normalized_rows);
    std::set<std::string> source_ids;
    std::vector<PrivateMarkovLawSource> compiled_sources;
    compiled_sources.reserve(authored.sources.value.size());

    for (std::size_t source_ordinal = 0U;
         source_ordinal < authored.sources.value.size(); ++source_ordinal) {
      const PrivateMarkovRenewalSource& source =
          authored.sources.value[source_ordinal];
      if (source.id.value.empty()) {
        return input_failure<PrivateMarkovLawParts>(
            "private_markov_source_id_empty",
            "a private Markov renewal source must have a nonempty normalized "
            "identifier",
            source.id.provenance);
      }
      if (!source_ids.insert(source.id.value).second) {
        return input_failure<PrivateMarkovLawParts>(
            "private_markov_duplicate_source_id",
            "private Markov renewal source identifiers must be unique after "
            "normalization",
            source.id.provenance,
            {"duplicate source: " + source.id.value});
      }
      if (source.states.value.empty()) {
        return input_failure<PrivateMarkovLawParts>(
            "private_markov_empty_states",
            "each private Markov renewal source requires at least one state",
            source.states.provenance,
            {"source: " + source.id.value});
      }

      std::map<std::string, std::size_t> state_indices;
      for (std::size_t index = 0U; index < source.states.value.size();
           ++index) {
        const NormalizedToken& state = source.states.value[index];
        if (state.value.empty()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_state_id_empty",
              "a private Markov state must have a nonempty normalized "
              "identifier",
              state.provenance, {"source: " + source.id.value});
        }
        if (!state_indices.emplace(state.value, index).second) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_duplicate_state_id",
              "private Markov state identifiers must be unique within a "
              "source",
              state.provenance,
              {"source: " + source.id.value,
               "duplicate state: " + state.value});
        }
      }

      PrivateMarkovInitialLaw initial = [&]() -> PrivateMarkovInitialLaw {
        // This temporary is immediately replaced below. The lambda merely
        // keeps all construction of the non-default optional PMF explicit.
        return PrivateMarkovInitialLaw{{0U}, std::nullopt};
      }();
      if (const auto* exact =
              std::get_if<InitialExactState>(&source.initial.value)) {
        const auto found = state_indices.find(exact->state.value);
        if (found == state_indices.end()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_initial_state_unknown",
              "the fixed private Markov initial state is not declared by its "
              "source",
              exact->state.provenance,
              {"source: " + source.id.value,
               "state: " + exact->state.value});
        }
        initial = PrivateMarkovInitialLaw{{found->second}, std::nullopt};
      } else {
        const auto& distribution =
            std::get<InitialStateDistribution>(source.initial.value);
        if (distribution.distribution.value.empty()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_initial_distribution_empty",
              "a private Markov initial distribution must be nonempty",
              distribution.distribution.provenance,
              {"source: " + source.id.value});
        }
        std::vector<std::size_t> coordinates;
        std::vector<AuthoredProbability> probabilities;
        std::set<std::size_t> seen_coordinates;
        coordinates.reserve(distribution.distribution.value.size());
        probabilities.reserve(distribution.distribution.value.size());
        for (const StateProbability& mass :
             distribution.distribution.value) {
          const auto found = state_indices.find(mass.state.value);
          if (found == state_indices.end()) {
            return input_failure<PrivateMarkovLawParts>(
                "private_markov_initial_state_unknown",
                "a private Markov initial distribution references an "
                "undeclared state",
                mass.state.provenance,
                {"source: " + source.id.value,
                 "state: " + mass.state.value});
          }
          if (!seen_coordinates.insert(found->second).second) {
            return input_failure<PrivateMarkovLawParts>(
                "private_markov_duplicate_initial_coordinate",
                "a private Markov initial distribution contains a repeated "
                "state coordinate",
                mass.provenance,
                {"source: " + source.id.value,
                 "state: " + mass.state.value});
          }
          coordinates.push_back(found->second);
          probabilities.push_back(mass.probability.value);
        }
        if (coordinates.size() != source.states.value.size()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_initial_distribution_incomplete",
              "a private Markov initial distribution must contain every "
              "declared state exactly once",
              distribution.distribution.provenance,
              {"source: " + source.id.value,
               "declared states: " +
                   std::to_string(source.states.value.size()),
               "initial coordinates: " +
                   std::to_string(coordinates.size())});
        }
        auto normalized = rows.consume(
            ArrivalCategoricalRowKind::private_initial_state, source_ordinal,
            0U, probabilities);
        if (!normalized) {
          return Result<PrivateMarkovLawParts>::failure(normalized.error());
        }
        initial = PrivateMarkovInitialLaw{
            std::move(coordinates), std::move(normalized).value()};
      }

      std::vector<std::optional<BigNat>> gaps(source.states.value.size());
      for (const StateGap& gap : source.gaps.value) {
        const auto found = state_indices.find(gap.state.value);
        if (found == state_indices.end()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_gap_state_unknown",
              "a private Markov gap references an undeclared state",
              gap.state.provenance,
              {"source: " + source.id.value,
               "state: " + gap.state.value});
        }
        if (gaps[found->second].has_value()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_duplicate_state_gap",
              "each private Markov state must have exactly one gap",
              gap.provenance,
              {"source: " + source.id.value,
               "state: " + gap.state.value});
        }
        if (gap.d.value.is_zero()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_nonpositive_gap",
              "a private Markov state gap must be a positive integer",
              gap.d.provenance,
              {"source: " + source.id.value,
               "state: " + gap.state.value});
        }
        gaps[found->second] = gap.d.value;
      }
      for (std::size_t index = 0U; index < gaps.size(); ++index) {
        if (!gaps[index].has_value()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_missing_state_gap",
              "each private Markov state must have exactly one positive gap",
              source.gaps.provenance,
              {"source: " + source.id.value,
               "state: " + source.states.value[index].value});
        }
      }

      std::vector<std::vector<std::size_t>> next_states(
          source.states.value.size());
      std::vector<std::vector<AuthoredProbability>> transition_probabilities(
          source.states.value.size());
      std::set<std::pair<std::size_t, std::size_t>> transition_coordinates;
      for (const StateTransition& transition : source.transitions.value) {
        const auto current = state_indices.find(transition.state.value);
        if (current == state_indices.end()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_transition_state_unknown",
              "a private Markov transition row references an undeclared "
              "current state",
              transition.state.provenance,
              {"source: " + source.id.value,
               "state: " + transition.state.value});
        }
        const auto next = state_indices.find(transition.next_state.value);
        if (next == state_indices.end()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_transition_next_state_unknown",
              "a private Markov transition references an undeclared next "
              "state",
              transition.next_state.provenance,
              {"source: " + source.id.value,
               "next state: " + transition.next_state.value});
        }
        if (!transition_coordinates
                 .emplace(current->second, next->second)
                 .second) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_duplicate_transition_coordinate",
              "a private Markov transition coordinate may occur only once",
              transition.provenance,
              {"source: " + source.id.value,
               "state: " + transition.state.value,
               "next state: " + transition.next_state.value});
        }
        next_states[current->second].push_back(next->second);
        transition_probabilities[current->second].push_back(
            transition.probability.value);
      }

      std::vector<PrivateMarkovStateLaw> compiled_states;
      compiled_states.reserve(source.states.value.size());
      for (std::size_t state_index = 0U;
           state_index < source.states.value.size(); ++state_index) {
        if (next_states[state_index].empty()) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_missing_transition_row",
              "every private Markov state requires a nonempty outgoing "
              "transition row",
              source.transitions.provenance,
              {"source: " + source.id.value,
               "state: " + source.states.value[state_index].value});
        }
        auto normalized = rows.consume(
            ArrivalCategoricalRowKind::private_transition, source_ordinal,
            state_index, transition_probabilities[state_index]);
        if (!normalized) {
          return Result<PrivateMarkovLawParts>::failure(normalized.error());
        }
        compiled_states.push_back(PrivateMarkovStateLaw{
            source.states.value[state_index].value,
            *gaps[state_index], std::move(next_states[state_index]),
            std::move(normalized).value()});
      }

      if (source.destination_pmf.value.empty()) {
        return input_failure<PrivateMarkovLawParts>(
            "private_markov_destination_pmf_empty",
            "each private Markov source requires a nonempty destination PMF",
            source.destination_pmf.provenance,
            {"source: " + source.id.value});
      }
      std::vector<DenseQueueIndex> destinations;
      std::vector<AuthoredProbability> destination_probabilities;
      std::set<std::size_t> destination_coordinates;
      destinations.reserve(source.destination_pmf.value.size());
      destination_probabilities.reserve(source.destination_pmf.value.size());
      for (const DestinationProbability& mass :
           source.destination_pmf.value) {
        auto queue = queues.resolve(mass.queue_id.value,
                                    mass.queue_id.provenance);
        if (!queue) {
          return Result<PrivateMarkovLawParts>::failure(queue.error());
        }
        if (!destination_coordinates.insert(queue.value().ordinal()).second) {
          return input_failure<PrivateMarkovLawParts>(
              "private_markov_duplicate_destination_coordinate",
              "a private Markov destination coordinate may occur only once",
              mass.provenance,
              {"source: " + source.id.value});
        }
        destinations.push_back(queue.value());
        destination_probabilities.push_back(mass.probability.value);
      }
      auto destination_row = rows.consume(
          ArrivalCategoricalRowKind::destination, source_ordinal, 0U,
          destination_probabilities);
      if (!destination_row) {
        return Result<PrivateMarkovLawParts>::failure(
            destination_row.error());
      }

      compiled_sources.push_back(PrivateMarkovLawSource{
          source.id.value, std::move(initial), std::move(compiled_states),
          std::move(destinations), std::move(destination_row).value()});
    }

    auto finished = rows.finish();
    if (!finished) {
      return Result<PrivateMarkovLawParts>::failure(finished.error());
    }
    return Result<PrivateMarkovLawParts>::success(PrivateMarkovLawParts{
        queues.size(), std::move(catalog_digest).value(),
        std::move(compiled_sources)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<PrivateMarkovLawParts>(
        "compiling a private Markov renewal law");
  } catch (const std::length_error&) {
    return Result<PrivateMarkovLawParts>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "private_markov_arrival_representation_failure",
        "the private Markov renewal representation exceeds a host container "
        "limit"));
  } catch (const std::exception&) {
    return internal_failure<PrivateMarkovLawParts>(
        "private_markov_compile_invariant_failure",
        "private Markov renewal compilation violated an exact representation "
        "invariant");
  } catch (...) {
    return internal_failure<PrivateMarkovLawParts>(
        "private_markov_compile_invariant_failure",
        "private Markov renewal compilation raised a nonstandard exception");
  }
}

struct PrivateMarkovSourceCursor final {
  std::size_t state;
  BigNat next_event_slot;
  DenseQueueIndex pending_destination;
};

struct PrivateMarkovCursorState final {
  BigNat expected_slot;
  std::vector<PrivateMarkovSourceCursor> sources;
};

[[nodiscard]] const PrivateMarkovStateLaw* find_state(
    const PrivateMarkovLawSource& source,
    const std::string_view state_id,
    std::size_t* const index = nullptr) noexcept {
  const auto states = std::span<const PrivateMarkovStateLaw>(source.states);
  const auto found = std::ranges::find(states, state_id,
                                       &PrivateMarkovStateLaw::state_id);
  if (found == states.end()) {
    return nullptr;
  }
  if (index != nullptr) {
    *index = static_cast<std::size_t>(found - states.begin());
  }
  return &*found;
}

[[nodiscard]] bool initial_state_has_positive_mass(
    const PrivateMarkovLawSource& source,
    const std::size_t state_index) noexcept {
  for (std::size_t coordinate = 0U;
       coordinate < source.initial.state_indices.size(); ++coordinate) {
    if (source.initial.state_indices[coordinate] != state_index) {
      continue;
    }
    if (!source.initial.probabilities.has_value()) {
      return true;
    }
    return positive(source.initial.probabilities->normalized_weights()
                        [coordinate]);
  }
  return false;
}

[[nodiscard]] Result<void> validate_private_initial_state(
    const PrivateMarkovLaw& law, const ArrivalInitialState& initial_state) {
  const auto* private_states =
      std::get_if<PrivateMarkovStates>(&initial_state);
  if (private_states == nullptr) {
    return input_failure<void>(
        "arrival_initial_family_mismatch",
        "a private Markov renewal law requires private_markov_states");
  }
  std::set<std::string> seen_sources;
  for (const PrivateMarkovState& supplied : private_states->states) {
    if (!seen_sources.insert(supplied.source_id).second) {
      return input_failure<void>(
          "private_markov_initial_duplicate_source",
          "a concrete private Markov initial state repeats a source",
          std::nullopt, {"source: " + supplied.source_id});
    }
    const auto source = std::ranges::find(
        law.sources(), supplied.source_id,
        &PrivateMarkovLawSource::source_id);
    if (source == law.sources().end()) {
      return input_failure<void>(
          "private_markov_initial_source_unknown",
          "a concrete private Markov initial state names an undeclared "
          "source",
          std::nullopt, {"source: " + supplied.source_id});
    }
    std::size_t state_index = 0U;
    if (find_state(*source, supplied.state, &state_index) == nullptr) {
      return input_failure<void>(
          "private_markov_initial_state_unknown",
          "a concrete private Markov initial state names an undeclared state",
          std::nullopt,
          {"source: " + supplied.source_id,
           "state: " + supplied.state});
    }
    if (!initial_state_has_positive_mass(*source, state_index)) {
      return input_failure<void>(
          "private_markov_initial_state_zero_probability",
          "a concrete private Markov initial state is outside the positive "
          "support of its configured initial law",
          std::nullopt,
          {"source: " + supplied.source_id,
           "state: " + supplied.state});
    }
  }
  if (private_states->states.size() != law.sources().size()) {
    return input_failure<void>(
        "private_markov_initial_source_coverage",
        "a concrete private Markov initial state must name every source "
        "exactly once",
        std::nullopt,
        {"declared sources: " + std::to_string(law.sources().size()),
         "supplied source states: " +
             std::to_string(private_states->states.size())});
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_private_cursor_state(
    const PrivateMarkovLaw& law, const PrivateMarkovCursorState& cursor,
    const DiagnosticCategory category, std::string code) {
  if (cursor.sources.size() != law.sources().size()) {
    return Result<void>::failure(diagnostic(
        category, std::move(code),
        "a private Markov cursor does not contain exactly one state, clock, "
        "and pending mark per source"));
  }
  for (std::size_t index = 0U; index < cursor.sources.size(); ++index) {
    const PrivateMarkovLawSource& law_source = law.sources()[index];
    const PrivateMarkovSourceCursor& source = cursor.sources[index];
    if (source.state >= law_source.states.size()) {
      return Result<void>::failure(diagnostic(
          category, std::move(code),
          "a private Markov cursor state index is outside its immutable "
          "source state table",
          std::nullopt, {"source: " + law_source.source_id}));
    }
    if (source.next_event_slot < cursor.expected_slot) {
      return Result<void>::failure(diagnostic(
          category, std::move(code),
          "a private Markov cursor contains a pending event below its next "
          "authored slot",
          std::nullopt,
          {"source: " + law_source.source_id,
           "pending slot: " + source.next_event_slot.to_decimal_string(),
           "next authored slot: " + cursor.expected_slot.to_decimal_string()}));
    }
    const auto pending = std::ranges::find(law_source.destinations,
                                           source.pending_destination);
    const bool pending_has_positive_mass =
        pending != law_source.destinations.end() &&
        positive(law_source.destination_probabilities.normalized_weights()
                     [static_cast<std::size_t>(
                         pending - law_source.destinations.begin())]);
    if (!pending_has_positive_mass) {
      return Result<void>::failure(diagnostic(
          category, std::move(code),
          "a private Markov cursor pending mark is outside its immutable "
          "positive destination support",
          std::nullopt, {"source: " + law_source.source_id}));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<detail::ArrivalCursorInitialization>
instantiate_private_markov_cursor(const PrivateMarkovLaw& law,
                                  const ArrivalInitialState& initial_state,
                                  DeterministicRng& rng) {
  auto valid = validate_private_initial_state(law, initial_state);
  if (!valid) {
    return Result<detail::ArrivalCursorInitialization>::failure(
        valid.error());
  }
  const PrivateMarkovStates& supplied =
      std::get<PrivateMarkovStates>(initial_state);
  try {
    std::vector<PrivateMarkovSourceCursor> sources;
    sources.reserve(law.sources().size());
    for (const PrivateMarkovLawSource& source : law.sources()) {
      const auto selected = std::ranges::find(
          supplied.states, source.source_id,
          &PrivateMarkovState::source_id);
      if (selected == supplied.states.end()) {
        return internal_failure<detail::ArrivalCursorInitialization>(
            "private_markov_initial_coverage_invariant_failure",
            "a validated concrete initial state lost a declared source");
      }
      std::size_t state_index = 0U;
      const PrivateMarkovStateLaw* state =
          find_state(source, selected->state, &state_index);
      if (state == nullptr) {
        return internal_failure<detail::ArrivalCursorInitialization>(
            "private_markov_initial_state_invariant_failure",
            "a validated concrete initial state lost its state coordinate");
      }
      auto first_slot = checked_subtract(state->gap, BigNat(1U));
      if (!first_slot) {
        return internal_failure<detail::ArrivalCursorInitialization>(
            "private_markov_initial_clock_invariant_failure",
            "a positive private Markov initial-state gap could not be "
            "measured from the exact -1 origin");
      }
      const std::size_t destination =
          sample_categorical(source.destination_probabilities, rng);
      if (destination >= source.destinations.size()) {
        return internal_failure<detail::ArrivalCursorInitialization>(
            "private_markov_destination_sample_invariant_failure",
            "categorical sampling returned a private Markov destination "
            "outside its immutable row");
      }
      sources.push_back(PrivateMarkovSourceCursor{
          state_index, std::move(first_slot).value(),
          source.destinations[destination]});
    }
    auto cursor = std::make_shared<const PrivateMarkovCursorState>(
        PrivateMarkovCursorState{BigNat(0U), std::move(sources)});
    auto cursor_valid = validate_private_cursor_state(
        law, *cursor, DiagnosticCategory::internal,
        "private_markov_cursor_state_invariant_failure");
    if (!cursor_valid) {
      return Result<detail::ArrivalCursorInitialization>::failure(
          cursor_valid.error());
    }
    return Result<detail::ArrivalCursorInitialization>::success(
        detail::ArrivalCursorInitialization{std::move(cursor)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ArrivalCursorInitialization>(
        "instantiating a private Markov renewal cursor");
  } catch (const std::length_error&) {
    return Result<detail::ArrivalCursorInitialization>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "private_markov_arrival_representation_failure",
        "the private Markov cursor exceeds a host container limit"));
  }
}

[[nodiscard]] Result<void> validate_runtime_binding(
    const PrivateMarkovLaw& law, const ArrivalBinding& binding) {
  if (binding.family !=
          ArrivalFamily::independent_private_markov_renewal ||
      binding.timing != TimingConvention::early_service_late_admission ||
      binding.queue_cardinality != law.queue_count() ||
      !(binding.catalog_digest == law.catalog_digest())) {
    return internal_failure<void>(
        "private_markov_runtime_binding_mismatch",
        "the private Markov runtime received another family, timing "
        "convention, law, or queue catalog binding");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<detail::ProposedArrivalTransition>
propose_private_markov_transition(
    const PrivateMarkovLaw& law,
    const detail::ArrivalCursorState& erased_state,
    const BigNat& authored_slot, const ArrivalBinding& binding,
    DeterministicRng& rng) {
  auto valid_binding = validate_runtime_binding(law, binding);
  if (!valid_binding) {
    return Result<detail::ProposedArrivalTransition>::failure(
        valid_binding.error());
  }
  const auto cursor =
      std::static_pointer_cast<const PrivateMarkovCursorState>(erased_state);
  if (!cursor) {
    return internal_failure<detail::ProposedArrivalTransition>(
        "private_markov_cursor_state_missing",
        "the private Markov transition received no immutable cursor state");
  }
  auto valid = validate_private_cursor_state(
      law, *cursor, DiagnosticCategory::internal,
      "private_markov_cursor_state_invariant_failure");
  if (!valid) {
    return Result<detail::ProposedArrivalTransition>::failure(valid.error());
  }
  if (!(cursor->expected_slot == authored_slot)) {
    return internal_failure<detail::ProposedArrivalTransition>(
        "private_markov_cursor_slot_invariant_failure",
        "the private Markov family cursor and C09 sequential slot disagree",
        {"family cursor slot: " + cursor->expected_slot.to_decimal_string(),
         "requested slot: " + authored_slot.to_decimal_string()});
  }

  try {
    PrivateMarkovCursorState successor = *cursor;
    std::vector<ArrivalAtom> atoms;
    atoms.reserve(law.sources().size());

    for (std::size_t source_index = 0U;
         source_index < successor.sources.size(); ++source_index) {
      PrivateMarkovSourceCursor& source_cursor =
          successor.sources[source_index];
      const PrivateMarkovLawSource& source = law.sources()[source_index];
      if (source_cursor.next_event_slot < authored_slot) {
        return internal_failure<detail::ProposedArrivalTransition>(
            "private_markov_stale_pending_event",
            "a private Markov source retained an event below the requested "
            "slot",
            {"source: " + source.source_id});
      }
      if (!(source_cursor.next_event_slot == authored_slot)) {
        continue;
      }

      // The pending destination was sampled when this event was scheduled.
      // Publish it before consuming either draw that schedules its successor.
      auto atom = ArrivalAtom::make(source_cursor.pending_destination,
                                    BigNat(1U), binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(
            atom.error());
      }
      atoms.push_back(std::move(atom).value());

      const PrivateMarkovStateLaw& current =
          source.states[source_cursor.state];
      const std::size_t transition =
          sample_categorical(current.transition_probabilities, rng);
      if (transition >= current.next_states.size()) {
        return internal_failure<detail::ProposedArrivalTransition>(
            "private_markov_transition_sample_invariant_failure",
            "categorical sampling returned a private Markov transition "
            "outside its immutable row");
      }
      const std::size_t next_state = current.next_states[transition];
      if (next_state >= source.states.size()) {
        return internal_failure<detail::ProposedArrivalTransition>(
            "private_markov_next_state_invariant_failure",
            "a sampled private Markov transition references an invalid "
            "compiled state");
      }

      // Event-index convention: transition first, then advance by the NEW
      // state's positive gap. Using current.gap here would change the law.
      source_cursor.state = next_state;
      source_cursor.next_event_slot += source.states[next_state].gap;

      const std::size_t destination =
          sample_categorical(source.destination_probabilities, rng);
      if (destination >= source.destinations.size()) {
        return internal_failure<detail::ProposedArrivalTransition>(
            "private_markov_destination_sample_invariant_failure",
            "categorical sampling returned a private Markov destination "
            "outside its immutable row");
      }
      source_cursor.pending_destination = source.destinations[destination];
    }

    ++successor.expected_slot;
    auto successor_state =
        std::make_shared<const PrivateMarkovCursorState>(std::move(successor));
    auto successor_valid = validate_private_cursor_state(
        law, *successor_state, DiagnosticCategory::internal,
        "private_markov_successor_state_invariant_failure");
    if (!successor_valid) {
      return Result<detail::ProposedArrivalTransition>::failure(
          successor_valid.error());
    }
    return Result<detail::ProposedArrivalTransition>::success(
        detail::ProposedArrivalTransition{std::move(successor_state),
                                          std::move(atoms)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ProposedArrivalTransition>(
        "advancing a private Markov renewal cursor");
  } catch (const std::length_error&) {
    return Result<detail::ProposedArrivalTransition>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "private_markov_arrival_representation_failure",
        "the private Markov transition exceeds a host container limit"));
  }
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT32_C(0xff)));
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT64_C(0xff)));
  }
}

void append_size(std::vector<std::byte>& output, const std::size_t value) {
  static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
  append_u64(output, static_cast<std::uint64_t>(value));
}

void append_string(std::vector<std::byte>& output,
                   const std::string_view value) {
  append_size(output, value.size());
  for (const char character : value) {
    output.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> bytes = value.canonical_magnitude_bytes();
  append_size(output, bytes.size());
  for (const std::uint8_t byte : bytes) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

void append_rational(std::vector<std::byte>& output,
                     const ExactRational& value) {
  append_string(output, value.numerator_decimal());
  append_string(output, value.denominator_decimal());
}

void append_pmf(std::vector<std::byte>& output, const NormalizedPmf& pmf) {
  append_size(output, pmf.size());
  for (const ExactRational& weight : pmf.normalized_weights()) {
    append_rational(output, weight);
  }
}

[[nodiscard]] std::vector<std::byte> encode_private_markov_law(
    const PrivateMarkovLaw& law) {
  std::vector<std::byte> encoded;
  append_string(encoded,
                "mwperf.c11.independent_private_markov_renewal.v1");
  append_u32(encoded, 1U);
  append_size(encoded, law.queue_count());
  append_size(encoded, law.sources().size());
  for (const PrivateMarkovLawSource& source : law.sources()) {
    append_string(encoded, source.source_id);
    append_size(encoded, source.initial.state_indices.size());
    for (const std::size_t state : source.initial.state_indices) {
      append_size(encoded, state);
    }
    encoded.push_back(source.initial.probabilities.has_value()
                          ? std::byte{1}
                          : std::byte{0});
    if (source.initial.probabilities.has_value()) {
      append_pmf(encoded, *source.initial.probabilities);
    }
    append_size(encoded, source.states.size());
    for (const PrivateMarkovStateLaw& state : source.states) {
      append_string(encoded, state.state_id);
      append_big_nat(encoded, state.gap);
      append_size(encoded, state.next_states.size());
      for (const std::size_t next : state.next_states) {
        append_size(encoded, next);
      }
      append_pmf(encoded, state.transition_probabilities);
    }
    append_size(encoded, source.destinations.size());
    for (const DenseQueueIndex destination : source.destinations) {
      append_size(encoded, destination.ordinal());
    }
    append_pmf(encoded, source.destination_probabilities);
  }
  return encoded;
}

[[nodiscard]] Result<std::vector<std::byte>> encode_private_markov_phase(
    const PrivateMarkovLaw& law,
    const detail::ArrivalCursorState& erased_state) {
  const auto cursor =
      std::static_pointer_cast<const PrivateMarkovCursorState>(erased_state);
  if (!cursor) {
    return internal_failure<std::vector<std::byte>>(
        "private_markov_cursor_state_missing",
        "the private Markov phase encoder received no cursor state");
  }
  auto valid = validate_private_cursor_state(
      law, *cursor, DiagnosticCategory::internal,
      "private_markov_cursor_state_invariant_failure");
  if (!valid) {
    return Result<std::vector<std::byte>>::failure(valid.error());
  }
  try {
    std::vector<std::byte> encoded;
    append_u32(encoded, 1U);
    encoded.push_back(static_cast<std::byte>(
        ArrivalFamily::independent_private_markov_renewal));
    append_big_nat(encoded, cursor->expected_slot);
    append_size(encoded, cursor->sources.size());
    for (const PrivateMarkovSourceCursor& source : cursor->sources) {
      append_size(encoded, source.state);
      append_big_nat(encoded, source.next_event_slot);
      append_size(encoded, source.pending_destination.ordinal());
    }
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<std::byte>>(
        "encoding a private Markov predictive phase");
  } catch (const std::length_error&) {
    return Result<std::vector<std::byte>>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "private_markov_phase_representation_failure",
        "the private Markov predictive phase exceeds a host container limit"));
  }
}

[[nodiscard]] bool read_u32(const std::span<const std::byte> encoded,
                            std::size_t& offset,
                            std::uint32_t& value) noexcept {
  if (offset > encoded.size() || encoded.size() - offset < 4U) {
    return false;
  }
  value = 0U;
  for (std::size_t index = 0U; index < 4U; ++index) {
    value = static_cast<std::uint32_t>(
        (value << 8U) |
        std::to_integer<std::uint8_t>(encoded[offset + index]));
  }
  offset += 4U;
  return true;
}

[[nodiscard]] bool read_u64(const std::span<const std::byte> encoded,
                            std::size_t& offset,
                            std::uint64_t& value) noexcept {
  if (offset > encoded.size() || encoded.size() - offset < 8U) {
    return false;
  }
  value = 0U;
  for (std::size_t index = 0U; index < 8U; ++index) {
    value = static_cast<std::uint64_t>(
        (value << 8U) |
        std::to_integer<std::uint8_t>(encoded[offset + index]));
  }
  offset += 8U;
  return true;
}

[[nodiscard]] bool read_size(const std::span<const std::byte> encoded,
                             std::size_t& offset,
                             std::size_t& value) noexcept {
  std::uint64_t decoded = 0U;
  if (!read_u64(encoded, offset, decoded) ||
      decoded >
          static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
    return false;
  }
  value = static_cast<std::size_t>(decoded);
  return true;
}

[[nodiscard]] bool read_big_nat(const std::span<const std::byte> encoded,
                                std::size_t& offset, BigNat& value) {
  std::size_t length = 0U;
  if (!read_size(encoded, offset, length) || length == 0U ||
      offset > encoded.size() || length > encoded.size() - offset ||
      (length > 1U && encoded[offset] == std::byte{0})) {
    return false;
  }
  BigInt exact = 0;
  for (std::size_t index = 0U; index < length; ++index) {
    exact <<= 8U;
    exact += std::to_integer<std::uint8_t>(encoded[offset + index]);
  }
  offset += length;
  auto natural = BigNat::from_big_int(std::move(exact));
  if (!natural) {
    return false;
  }
  value = std::move(natural).value();
  return true;
}

[[nodiscard]] Result<detail::ArrivalCursorState>
decode_private_markov_phase(const PrivateMarkovLaw& law,
                            const std::span<const std::byte> encoded) {
  try {
    std::size_t offset = 0U;
    std::uint32_t version = 0U;
    if (!read_u32(encoded, offset, version) || version != 1U ||
        offset >= encoded.size() ||
        encoded[offset++] != static_cast<std::byte>(
                                 ArrivalFamily::
                                     independent_private_markov_renewal)) {
      return input_failure<detail::ArrivalCursorState>(
          "private_markov_phase_codec_invalid",
          "the private Markov phase is not a canonical version-1 family "
          "record");
    }
    BigNat expected_slot(0U);
    std::size_t source_count = 0U;
    if (!read_big_nat(encoded, offset, expected_slot) ||
        !read_size(encoded, offset, source_count) ||
        source_count != law.sources().size()) {
      return input_failure<detail::ArrivalCursorState>(
          "private_markov_phase_codec_invalid",
          "the private Markov phase has an invalid slot or source dimension");
    }

    std::vector<PrivateMarkovSourceCursor> sources;
    sources.reserve(source_count);
    for (std::size_t source_index = 0U; source_index < source_count;
         ++source_index) {
      std::size_t state = 0U;
      BigNat next_event(0U);
      std::size_t destination_ordinal = 0U;
      if (!read_size(encoded, offset, state) ||
          !read_big_nat(encoded, offset, next_event) ||
          !read_size(encoded, offset, destination_ordinal) ||
          state >= law.sources()[source_index].states.size()) {
        return input_failure<detail::ArrivalCursorState>(
            "private_markov_phase_codec_invalid",
            "the private Markov phase contains an invalid source state or "
            "clock");
      }
      const auto destination = std::ranges::find_if(
          law.sources()[source_index].destinations,
          [destination_ordinal](const DenseQueueIndex candidate) {
            return candidate.ordinal() == destination_ordinal;
          });
      if (destination == law.sources()[source_index].destinations.end()) {
        return input_failure<detail::ArrivalCursorState>(
            "private_markov_phase_codec_invalid",
            "the private Markov phase contains a pending destination outside "
            "its source row");
      }
      sources.push_back(PrivateMarkovSourceCursor{
          state, std::move(next_event), *destination});
    }
    if (offset != encoded.size()) {
      return input_failure<detail::ArrivalCursorState>(
          "private_markov_phase_codec_invalid",
          "the private Markov phase contains trailing data");
    }
    auto cursor = std::make_shared<const PrivateMarkovCursorState>(
        PrivateMarkovCursorState{std::move(expected_slot),
                                 std::move(sources)});
    auto valid = validate_private_cursor_state(
        law, *cursor, DiagnosticCategory::input_validation,
        "private_markov_phase_codec_invalid");
    if (!valid) {
      return Result<detail::ArrivalCursorState>::failure(valid.error());
    }
    return Result<detail::ArrivalCursorState>::success(std::move(cursor));
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ArrivalCursorState>(
        "decoding a private Markov predictive phase");
  } catch (const std::exception&) {
    return input_failure<detail::ArrivalCursorState>(
        "private_markov_phase_codec_invalid",
        "the private Markov phase could not be decoded exactly");
  }
}

[[nodiscard]] ArrivalCapabilities private_markov_capabilities() {
  ArrivalCapabilities capabilities;
  capabilities.exact_positive_support = CapabilityAvailability::available;
  capabilities.sequential_normalized_sampler =
      CapabilityAvailability::available;
  // Event clocks are unbounded. A finite authored chain therefore does not
  // imply a finite enumerated predictive phase, stationarity, moments, or an
  // analytic transform.
  return capabilities;
}

[[nodiscard]] std::vector<std::uint8_t> private_markov_support(
    const PrivateMarkovLaw& law) {
  std::vector<std::uint8_t> support(law.queue_count(), 0U);
  for (const PrivateMarkovLawSource& source : law.sources()) {
    for (std::size_t coordinate = 0U;
         coordinate < source.destinations.size(); ++coordinate) {
      if (positive(source.destination_probabilities.normalized_weights()
                       [coordinate])) {
        support[source.destinations[coordinate].ordinal()] = 1U;
      }
    }
  }
  return support;
}

}  // namespace

Result<PrivateMarkovLaw> compile_private_markov_renewal(
    const IndependentPrivateMarkovRenewalArrival& authored,
    const QueueCatalog& queues) {
  auto normalized = normalize_private_rows_once(authored);
  if (!normalized) {
    return Result<PrivateMarkovLaw>::failure(normalized.error());
  }
  auto parts = build_private_markov_law(authored, queues, normalized.value());
  if (!parts) {
    return Result<PrivateMarkovLaw>::failure(parts.error());
  }
  try {
    return Result<PrivateMarkovLaw>::success(PrivateMarkovLaw(
        parts.value().queue_count, std::move(parts.value().catalog_digest),
        std::move(parts.value().sources)));
  } catch (const std::bad_alloc&) {
    return allocation_failure<PrivateMarkovLaw>(
        "freezing a private Markov renewal law");
  }
}

Result<ArrivalStep> next_private_markov_batch(
    PrivateMarkovCursor& cursor, const BigNat& authored_slot) {
  if (cursor.family() !=
      ArrivalFamily::independent_private_markov_renewal) {
    return input_failure<ArrivalStep>(
        "private_markov_cursor_family_mismatch",
        "next_private_markov_batch requires an independent private Markov "
        "renewal cursor");
  }
  return next_arrival_step(cursor, authored_slot);
}

namespace detail {

Result<CompiledArrivalProduct> compile_private_markov_renewal_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<IndependentPrivateMarkovRenewalArrival>(
          &request.authored.value);
  if (authored == nullptr) {
    return internal_failure<CompiledArrivalProduct>(
        "private_markov_backend_family_mismatch",
        "the private Markov registry slot received another authored family");
  }

  // C09 already normalized every row. Revalidation here would silently make
  // this child a second PMF authority, so consume and structurally bind only.
  auto parts =
      build_private_markov_law(*authored, request.queues,
                               request.normalized_rows);
  if (!parts) {
    return Result<CompiledArrivalProduct>::failure(parts.error());
  }

  try {
    auto payload = std::make_shared<const PrivateMarkovLaw>(
        PrivateMarkovLaw(parts.value().queue_count,
                         std::move(parts.value().catalog_digest),
                         std::move(parts.value().sources)));

    ArrivalRuntimeAdapter runtime;
    runtime.validate_initial =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalInitialState& state) -> Result<void> {
      const auto law =
          std::static_pointer_cast<const PrivateMarkovLaw>(erased);
      if (!law) {
        return internal_failure<void>(
            "private_markov_law_payload_missing",
            "the private Markov initial-state validator has no immutable law "
            "payload");
      }
      return validate_private_initial_state(*law, state);
    };
    runtime.instantiate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalInitialState& state,
           DeterministicRng& rng) -> Result<ArrivalCursorInitialization> {
      const auto law =
          std::static_pointer_cast<const PrivateMarkovLaw>(erased);
      if (!law) {
        return internal_failure<ArrivalCursorInitialization>(
            "private_markov_law_payload_missing",
            "the private Markov cursor initializer has no immutable law "
            "payload");
      }
      return instantiate_private_markov_cursor(*law, state, rng);
    };
    runtime.encode_phase =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state) {
      const auto law =
          std::static_pointer_cast<const PrivateMarkovLaw>(erased);
      if (!law) {
        return internal_failure<std::vector<std::byte>>(
            "private_markov_law_payload_missing",
            "the private Markov phase encoder has no immutable law payload");
      }
      return encode_private_markov_phase(*law, state);
    };
    runtime.decode_phase =
        [](const std::shared_ptr<const void>& erased,
           const std::span<const std::byte> encoded) {
      const auto law =
          std::static_pointer_cast<const PrivateMarkovLaw>(erased);
      if (!law) {
        return internal_failure<ArrivalCursorState>(
            "private_markov_law_payload_missing",
            "the private Markov phase decoder has no immutable law payload");
      }
      return decode_private_markov_phase(*law, encoded);
    };
    runtime.propose =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding,
           DeterministicRng& rng) -> Result<ProposedArrivalTransition> {
      const auto law =
          std::static_pointer_cast<const PrivateMarkovLaw>(erased);
      if (!law) {
        return internal_failure<ProposedArrivalTransition>(
            "private_markov_law_payload_missing",
            "the private Markov transition has no immutable law payload");
      }
      return propose_private_markov_transition(*law, state, slot, binding,
                                               rng);
    };

    std::vector<std::uint8_t> support = private_markov_support(*payload);
    std::vector<std::byte> canonical = encode_private_markov_law(*payload);
    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::independent_private_markov_renewal,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = private_markov_capabilities(),
        .canonical_law_data = std::move(canonical),
        .portable_schema =
            PortableArrivalLawSchema::independent_private_markov_renewal_v1,
        .payload = std::move(payload),
        .runtime = std::move(runtime),
        .iid_joint_table = std::nullopt,
        .moments = std::nullopt,
        .covariances = std::nullopt,
        .analytic_transform = std::nullopt,
        .joint_distribution = std::nullopt,
        .coordinate_distributions = std::nullopt,
        .replay_codec = std::nullopt,
        .unit_cube = std::nullopt,
        .finite_phase = std::nullopt,
        .transition_rows = std::nullopt,
        .stationary_phase_law = std::nullopt,
    });
  } catch (const std::bad_alloc&) {
    return allocation_failure<CompiledArrivalProduct>(
        "publishing a private Markov renewal product");
  } catch (const std::length_error&) {
    return Result<CompiledArrivalProduct>::failure(diagnostic(
        DiagnosticCategory::resource_limit,
        "private_markov_arrival_representation_failure",
        "the private Markov product exceeds a host container limit"));
  } catch (const std::exception&) {
    return internal_failure<CompiledArrivalProduct>(
        "private_markov_publish_invariant_failure",
        "publishing the private Markov product violated an exact invariant");
  } catch (...) {
    return internal_failure<CompiledArrivalProduct>(
        "private_markov_publish_invariant_failure",
        "publishing the private Markov product raised a nonstandard "
        "exception");
  }
}

}  // namespace detail
}  // namespace mwperf
