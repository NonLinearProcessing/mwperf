#include "mwperf/arrival/contract.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/build_services.hpp"
#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/random/deterministic_rng.hpp"

#include "core_internal.hpp"
#include "initial_law_detail.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> failure(const DiagnosticCategory category,
                                std::string code, std::string message,
                                std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{category,
                                       std::move(code),
                                       std::move(message),
                                       std::nullopt,
                                       std::nullopt,
                                       std::move(notes)});
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_bytes(std::vector<std::byte>& output,
                  const std::span<const std::byte> bytes) {
  append_u64(output, static_cast<std::uint64_t>(bytes.size()));
  output.insert(output.end(), bytes.begin(), bytes.end());
}

void append_string(std::vector<std::byte>& output, const std::string& value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  for (const char byte : value) {
    output.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(byte)));
  }
}

void append_digest(std::vector<std::byte>& output, const Digest256& digest) {
  const auto bytes = digest.bytes();
  output.insert(output.end(), bytes.begin(), bytes.end());
}

void append_bool(std::vector<std::byte>& output, const bool value) {
  output.push_back(value ? std::byte{1} : std::byte{0});
}

void append_rational(std::vector<std::byte>& output,
                     const ExactRational& value) {
  append_string(output, value.numerator_decimal());
  append_string(output, value.denominator_decimal());
}

void append_normalized_pmf(std::vector<std::byte>& output,
                           const NormalizedPmf& value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  for (const AuthoredProbability& probability :
       value.authored_probabilities()) {
    append_rational(output, probability.exact_value());
  }
  append_rational(output, value.authored_sum());
  append_rational(output, value.normalization_delta());
  for (const ExactRational& probability : value.normalized_weights()) {
    append_rational(output, probability);
  }
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const auto magnitude = value.canonical_magnitude_bytes();
  append_u64(output, static_cast<std::uint64_t>(magnitude.size()));
  for (const std::uint8_t byte : magnitude) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

// Keep the portable unsigned-byte order explicit.  GCC 13's optimized
// libstdc++ vector comparison can otherwise emit a spurious overread warning.
struct CanonicalByteVectorLess final {
  [[nodiscard]] bool operator()(const std::vector<std::byte>& left,
                                const std::vector<std::byte>& right) const
      noexcept {
    const std::size_t common_size = std::min(left.size(), right.size());
    for (std::size_t index = 0U; index < common_size; ++index) {
      const unsigned int left_byte =
          std::to_integer<unsigned int>(left[index]);
      const unsigned int right_byte =
          std::to_integer<unsigned int>(right[index]);
      if (left_byte != right_byte) {
        return left_byte < right_byte;
      }
    }
    return left.size() < right.size();
  }
};

[[nodiscard]] std::vector<std::byte> canonical_homogeneous_outcome_key(
    const detail::ExactArrivalTransitionAtom& atom,
    const ArrivalBatch& batch) {
  std::vector<std::byte> encoded;
  append_u32(encoded, 1U);
  append_bytes(encoded, atom.phase_before);
  append_bytes(encoded, atom.phase_after);
  append_u64(encoded, static_cast<std::uint64_t>(batch.entries().size()));
  for (const ArrivalBatchEntry& arrival : batch.entries()) {
    append_u64(encoded,
               static_cast<std::uint64_t>(arrival.queue.ordinal()));
    append_big_nat(encoded, arrival.count);
  }
  return encoded;
}

[[nodiscard]] std::vector<std::byte> canonical_homogeneous_row_atom(
    const std::span<const std::byte> outcome_key,
    const ExactRational& mass) {
  std::vector<std::byte> encoded;
  append_u32(encoded, 1U);
  append_bytes(encoded, outcome_key);
  append_rational(encoded, mass);
  append_bool(encoded, mass.is_positive());
  return encoded;
}

void append_transform(std::vector<std::byte>& output,
                      const TransformCapability& value) {
  output.push_back(static_cast<std::byte>(value.kind));
  output.push_back(static_cast<std::byte>(value.scope));
  append_rational(output, value.domain.lower);
  append_rational(output, value.domain.upper);
  append_bool(output, value.domain.lower_inclusive);
  append_bool(output, value.domain.upper_inclusive);
  output.push_back(static_cast<std::byte>(value.phase_requirement));
  output.push_back(static_cast<std::byte>(value.provision));
}

void append_moment(std::vector<std::byte>& output,
                   const MomentCapability& value) {
  append_bool(output, value.maximum_order.has_value());
  if (value.maximum_order.has_value()) {
    append_big_nat(output, *value.maximum_order);
  }
  append_bool(output, value.joint);
  append_bool(output, value.conditioned_on_phase);
  output.push_back(static_cast<std::byte>(value.provision));
}

void append_capabilities(std::vector<std::byte>& output,
                         const ArrivalCapabilities& value) {
  append_u32(output, value.version);
  output.push_back(static_cast<std::byte>(value.exact_positive_support));
  output.push_back(
      static_cast<std::byte>(value.sequential_normalized_sampler));
  output.push_back(
      static_cast<std::byte>(value.finite_enumerated_predictive_phase));
  output.push_back(
      static_cast<std::byte>(value.finite_enumerated_transition_row));
  append_bool(output, value.analytic_transform.has_value());
  if (value.analytic_transform) {
    append_transform(output, *value.analytic_transform);
  }
  append_bool(output, value.analytic_moments.has_value());
  if (value.analytic_moments) {
    append_moment(output, *value.analytic_moments);
  }
  output.push_back(static_cast<std::byte>(value.stationary_phase_law));
  append_bool(output, value.exact_iid_joint_vector.has_value());
  if (value.exact_iid_joint_vector) {
    append_bool(output, value.exact_iid_joint_vector->finite_support);
    output.push_back(
        static_cast<std::byte>(value.exact_iid_joint_vector->provision));
  }
  append_bool(output, value.exact_joint_moments.has_value());
  if (value.exact_joint_moments) {
    append_moment(output, *value.exact_joint_moments);
  }
  append_bool(output, value.exact_coordinate_moments.has_value());
  if (value.exact_coordinate_moments) {
    append_moment(output, *value.exact_coordinate_moments);
  }
  output.push_back(static_cast<std::byte>(value.exact_covariance));
  output.push_back(static_cast<std::byte>(value.exact_cross_moments));
  append_bool(output, value.exact_joint_distribution.has_value());
  if (value.exact_joint_distribution) {
    append_transform(output, *value.exact_joint_distribution);
  }
  append_bool(output, value.exact_coordinate_distributions.has_value());
  if (value.exact_coordinate_distributions) {
    append_transform(output, *value.exact_coordinate_distributions);
  }
  append_bool(output, value.adjacent_batch_replay.has_value());
  if (value.adjacent_batch_replay) {
    append_bool(output,
                value.adjacent_batch_replay->explicit_initial_state);
    append_bool(output, value.adjacent_batch_replay->explicit_phase);
    append_bool(output,
                value.adjacent_batch_replay->normalized_initial_law);
    append_bool(output,
                value.adjacent_batch_replay->named_stationary_initialization);
    output.push_back(
        static_cast<std::byte>(value.adjacent_batch_replay->provision));
  }
  append_bool(output, value.unit_cube_transform.has_value());
  if (value.unit_cube_transform) {
    append_big_nat(output, value.unit_cube_transform->dimension);
    output.push_back(
        static_cast<std::byte>(value.unit_cube_transform->boundary));
    output.push_back(
        static_cast<std::byte>(value.unit_cube_transform->inverse_cdf));
    output.push_back(
        static_cast<std::byte>(value.unit_cube_transform->phase_requirement));
    output.push_back(
        static_cast<std::byte>(value.unit_cube_transform->provision));
  }
}

void append_portable_access_data(
    std::vector<std::byte>& output,
    const std::optional<std::vector<ExactJointBatchMass>>& iid_joint_table,
    const std::optional<std::vector<ExactMomentDatum>>& moments,
    const std::optional<std::vector<ExactMomentDatum>>& covariances,
    const std::optional<PortableTransformDescriptor>& analytic_transform,
    const std::optional<PortableTransformDescriptor>& joint_distribution,
    const std::optional<PortableTransformDescriptor>& coordinate_distributions,
    const std::optional<ReplayCodecDescriptor>& replay_codec,
    const std::optional<UnitCubeDescriptor>& unit_cube,
    const std::optional<FinitePhaseDescriptor>& finite_phase,
    const std::optional<EnumeratedTransitionRowsDescriptor>& transition_rows,
    const std::optional<StationaryPhaseLawDescriptor>& stationary_phase_law) {
  append_bool(output, iid_joint_table.has_value());
  if (iid_joint_table) {
    append_u64(output,
               static_cast<std::uint64_t>(iid_joint_table->size()));
    for (const auto& mass : *iid_joint_table) {
      append_u64(output,
                 static_cast<std::uint64_t>(mass.dense_counts.size()));
      for (const auto& count : mass.dense_counts) {
        append_big_nat(output, count);
      }
      append_rational(output, mass.probability);
    }
  }
  append_bool(output, moments.has_value());
  if (moments) {
    append_u64(output, static_cast<std::uint64_t>(moments->size()));
    for (const auto& datum : *moments) {
      append_u64(output,
                 static_cast<std::uint64_t>(datum.coordinates.size()));
      for (const auto queue : datum.coordinates) {
        append_u64(output, static_cast<std::uint64_t>(queue.ordinal()));
      }
      append_big_nat(output, datum.order);
      append_rational(output, datum.value);
    }
  }
  append_bool(output, covariances.has_value());
  if (covariances) {
    append_u64(output,
               static_cast<std::uint64_t>(covariances->size()));
    for (const auto& datum : *covariances) {
      append_u64(output,
                 static_cast<std::uint64_t>(datum.coordinates.size()));
      for (const auto queue : datum.coordinates) {
        append_u64(output, static_cast<std::uint64_t>(queue.ordinal()));
      }
      append_big_nat(output, datum.order);
      append_rational(output, datum.value);
    }
  }
  const auto append_descriptor = [&](
                                     const std::optional<
                                         PortableTransformDescriptor>& value) {
    append_bool(output, value.has_value());
    if (value) {
      append_transform(output, value->capability);
      append_u32(output, value->codec_version);
      append_bytes(output, value->canonical_parameters);
    }
  };
  append_descriptor(analytic_transform);
  append_descriptor(joint_distribution);
  append_descriptor(coordinate_distributions);
  append_bool(output, replay_codec.has_value());
  if (replay_codec) {
    append_u32(output, replay_codec->codec_version);
    append_bool(output, replay_codec->requires_complete_initial_state);
    append_bool(output,
                replay_codec->preserves_adjacent_temporal_order);
    append_bytes(output, replay_codec->canonical_parameters);
  }
  append_bool(output, unit_cube.has_value());
  if (unit_cube) {
    append_big_nat(output, unit_cube->capability.dimension);
    output.push_back(
        static_cast<std::byte>(unit_cube->capability.boundary));
    output.push_back(
        static_cast<std::byte>(unit_cube->capability.inverse_cdf));
    output.push_back(static_cast<std::byte>(
        unit_cube->capability.phase_requirement));
    output.push_back(
        static_cast<std::byte>(unit_cube->capability.provision));
    append_u64(output,
               static_cast<std::uint64_t>(
                   unit_cube->coordinate_order.size()));
    for (const auto& coordinate : unit_cube->coordinate_order) {
      append_u64(output, static_cast<std::uint64_t>(coordinate.ordinal));
      append_string(output, coordinate.role);
    }
    append_u32(output, unit_cube->codec_version);
    append_bytes(output, unit_cube->canonical_parameters);
  }
  append_bool(output, finite_phase.has_value());
  if (finite_phase) {
    append_u32(output, finite_phase->codec_version);
    output.push_back(static_cast<std::byte>(
        finite_phase->row_clock_semantics));
    append_u64(output,
               static_cast<std::uint64_t>(
                   finite_phase->canonical_states.size()));
    for (const auto& state : finite_phase->canonical_states) {
      append_bytes(output, state);
    }
  }
  append_bool(output, transition_rows.has_value());
  if (transition_rows) {
    append_u32(output, transition_rows->codec_version);
    append_bytes(output, transition_rows->canonical_rows);
  }
  append_bool(output, stationary_phase_law.has_value());
  if (stationary_phase_law) {
    append_string(output, stationary_phase_law->law_id);
    append_u32(output, stationary_phase_law->codec_version);
    append_u64(output,
               static_cast<std::uint64_t>(
                   stationary_phase_law->canonical_states.size()));
    for (const auto& state :
         stationary_phase_law->canonical_states) {
      append_bytes(output, state);
    }
    append_normalized_pmf(output,
                          stationary_phase_law->probabilities);
  }
}

[[nodiscard]] Result<Digest256> digest_builder_arrival_view_fields(
    const ArrivalBinding& binding, const QueueMask& positive_support,
    const ArrivalCapabilities& capabilities,
    const PortableArrivalLawDescriptor& configured_law,
    const std::optional<std::vector<ExactJointBatchMass>>& iid_joint_table,
    const std::optional<std::vector<ExactMomentDatum>>& moments,
    const std::optional<std::vector<ExactMomentDatum>>& covariances,
    const std::optional<PortableTransformDescriptor>& analytic_transform,
    const std::optional<PortableTransformDescriptor>& joint_distribution,
    const std::optional<PortableTransformDescriptor>& coordinate_distributions,
    const std::optional<ReplayCodecDescriptor>& replay_codec,
    const std::optional<UnitCubeDescriptor>& unit_cube,
    const std::optional<FinitePhaseDescriptor>& finite_phase,
    const std::optional<EnumeratedTransitionRowsDescriptor>& transition_rows,
    const std::optional<StationaryPhaseLawDescriptor>& stationary_phase_law) {
  std::vector<std::byte> view_bytes;
  try {
    append_u32(view_bytes, 1U);
    view_bytes.push_back(static_cast<std::byte>(binding.family));
    view_bytes.push_back(static_cast<std::byte>(binding.timing));
    append_u64(view_bytes,
               static_cast<std::uint64_t>(binding.queue_cardinality));
    append_digest(view_bytes, binding.law_digest.value());
    append_digest(view_bytes, binding.catalog_digest.value());
    append_u64(view_bytes,
               static_cast<std::uint64_t>(positive_support.bytes().size()));
    for (const std::uint8_t bit : positive_support.bytes()) {
      view_bytes.push_back(static_cast<std::byte>(bit));
    }
    append_capabilities(view_bytes, capabilities);
    view_bytes.push_back(static_cast<std::byte>(configured_law.schema));
    append_u32(view_bytes, configured_law.version);
    append_digest(view_bytes, configured_law.payload_digest);
    append_portable_access_data(
        view_bytes, iid_joint_table, moments, covariances,
        analytic_transform, joint_distribution, coordinate_distributions,
        replay_codec, unit_cube, finite_phase, transition_rows,
        stationary_phase_law);
    // Conditional, domain-tagged suffixes: legacy capability/view bytes
    // remain unchanged when the append-only IID recipe facts are absent.
    // Each present fact is identity-bound without being confused with the
    // explicit joint-vector table or with the other recipe semantics.
    if (capabilities.exact_factorized_iid_generator.has_value()) {
      append_string(
          view_bytes,
          "mwperf.arrival.exact_factorized_iid_generator.capability.v1");
      view_bytes.push_back(static_cast<std::byte>(
          capabilities.exact_factorized_iid_generator->provision));
    }
    if (capabilities.exact_portable_iid_recipe.has_value()) {
      append_string(
          view_bytes,
          "mwperf.arrival.exact_portable_iid_recipe.capability.v1");
      view_bytes.push_back(static_cast<std::byte>(
          capabilities.exact_portable_iid_recipe->provision));
    }
  } catch (const std::bad_alloc&) {
    return failure<Digest256>(
        DiagnosticCategory::resource_limit, "arrival_view_digest_allocation",
        "arrival construction-view fingerprinting exhausted memory");
  }
  return sha256_domain_separated("mwperf.arrival.builder_view", view_bytes);
}

[[nodiscard]] Result<Digest256> state_digest(
    const std::span<const std::byte> bytes) {
  return sha256_domain_separated("mwperf.arrival.state", bytes);
}

[[nodiscard]] Result<std::vector<std::byte>> encode_initial_state(
    const ArrivalInitialState& state) {
  std::vector<std::byte> encoded;
  try {
    encoded.push_back(static_cast<std::byte>(state.index()));
    std::visit(
        [&encoded](const auto& value) {
          using Value = std::remove_cvref_t<decltype(value)>;
          if constexpr (std::same_as<Value, PrivateMarkovStates>) {
            append_u64(encoded,
                       static_cast<std::uint64_t>(value.states.size()));
            for (const auto& item : value.states) {
              append_string(encoded, item.source_id);
              append_string(encoded, item.state);
            }
          } else if constexpr (std::same_as<Value, SharedRoundState>) {
            append_string(encoded, value.state);
          }
        },
        state);
  } catch (const std::bad_alloc&) {
    return failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit, "arrival_state_encoding_allocation",
        "arrival initial-state encoding exhausted memory");
  }
  return Result<std::vector<std::byte>>::success(std::move(encoded));
}

[[nodiscard]] Result<Digest256> realization_digest_bytes(
    const detail::CompiledArrivalLawCore& law,
    const DeterministicRng& rng, const std::byte initialization_kind,
    const std::span<const std::byte> initialization,
    const BigNat& expected_slot) {
  std::vector<std::byte> encoded;
  try {
    append_u32(encoded, 1U);
    append_digest(encoded, law.binding.law_digest.value());
    append_digest(encoded, law.binding.catalog_digest.value());
    append_digest(encoded, rng.stream_identity());
    encoded.push_back(initialization_kind);
    append_big_nat(encoded, expected_slot);
    append_bytes(encoded, initialization);
  } catch (const std::bad_alloc&) {
    return failure<Digest256>(
        DiagnosticCategory::resource_limit,
        "arrival_realization_identity_allocation",
        "arrival realization identity construction exhausted memory");
  }
  return sha256_domain_separated("mwperf.arrival.realization", encoded);
}

[[nodiscard]] Result<Digest256> realization_digest(
    const detail::CompiledArrivalLawCore& law,
    const DeterministicRng& rng, const ArrivalInitialState& state) {
  auto initial = encode_initial_state(state);
  if (!initial) {
    return Result<Digest256>::failure(initial.error());
  }
  return realization_digest_bytes(law, rng, std::byte{0}, initial.value(),
                                  BigNat(0U));
}

[[nodiscard]] Result<Digest256> realization_digest_from_phase(
    const detail::CompiledArrivalLawCore& law,
    const DeterministicRng& rng,
    const std::span<const std::byte> canonical_phase,
    const BigNat& expected_slot) {
  return realization_digest_bytes(law, rng, std::byte{1}, canonical_phase,
                                  expected_slot);
}

[[nodiscard]] Result<ArrivalPhase> make_phase_snapshot(
    const std::shared_ptr<const detail::CompiledArrivalLawCore>& law,
    const detail::ArrivalCursorState& state,
    const BigNat& expected_slot,
    const std::shared_ptr<const detail::CursorOwnerToken>& owner) {
  if (!law->runtime.encode_phase) {
    return failure<ArrivalPhase>(
        DiagnosticCategory::internal, "arrival_phase_encoder_missing",
        "the compiled arrival law has no predictive-phase encoder");
  }
  auto encoded = law->runtime.encode_phase(law->payload, state);
  if (!encoded) {
    return Result<ArrivalPhase>::failure(encoded.error());
  }
  auto digest = state_digest(encoded.value());
  if (!digest) {
    return Result<ArrivalPhase>::failure(digest.error());
  }
  try {
    auto core = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{law->binding.family,
                                 law->binding,
                                 ArrivalStateDigest(digest.value()),
                                 std::move(encoded.value()),
                                 expected_slot,
                                 state,
                                 owner});
    return Result<ArrivalPhase>::success(
        detail::ArrivalCoreAccess::make_phase(law->binding.family,
                                              std::move(core)));
  } catch (const std::bad_alloc&) {
    return failure<ArrivalPhase>(DiagnosticCategory::resource_limit,
                                 "arrival_phase_allocation",
                                 "arrival phase construction exhausted memory");
  }
}

[[nodiscard]] Result<detail::ArrivalCursorState> decode_canonical_phase(
    const std::shared_ptr<const detail::CompiledArrivalLawCore>& law,
    const std::span<const std::byte> canonical_state) {
  if (!law->runtime.decode_phase || !law->runtime.encode_phase) {
    return failure<detail::ArrivalCursorState>(
        DiagnosticCategory::internal, "arrival_phase_codec_missing",
        "the compiled arrival law has no complete predictive-phase codec");
  }
  auto decoded =
      law->runtime.decode_phase(law->payload, canonical_state);
  if (!decoded) {
    return Result<detail::ArrivalCursorState>::failure(decoded.error());
  }
  if (!decoded.value()) {
    return failure<detail::ArrivalCursorState>(
        DiagnosticCategory::internal, "arrival_phase_decoder_returned_null",
        "the predictive-phase decoder returned no immutable cursor state");
  }
  auto encoded = law->runtime.encode_phase(law->payload, decoded.value());
  if (!encoded) {
    return Result<detail::ArrivalCursorState>::failure(encoded.error());
  }
  if (!std::ranges::equal(encoded.value(), canonical_state)) {
    return failure<detail::ArrivalCursorState>(
        DiagnosticCategory::internal, "arrival_phase_codec_not_canonical",
        "decoding and re-encoding a predictive phase changed its canonical "
        "representation");
  }
  return Result<detail::ArrivalCursorState>::success(
      std::move(decoded).value());
}

[[nodiscard]] Result<ArrivalProcess> make_process_from_phase_state(
    const std::shared_ptr<const detail::CompiledArrivalLawCore>& law,
    detail::ArrivalCursorState state,
    const std::span<const std::byte> canonical_phase,
    BigNat expected_slot,
    std::unique_ptr<DeterministicRng> rng) {
  if (!state || !rng) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::internal, "arrival_replay_cursor_missing",
        "replay initialization produced no cursor state or RNG stream");
  }
  auto identity = realization_digest_from_phase(
      *law, *rng, canonical_phase, expected_slot);
  if (!identity) {
    return Result<ArrivalProcess>::failure(identity.error());
  }
  try {
    auto owner = std::make_shared<const detail::CursorOwnerToken>();
    auto core = std::make_shared<detail::ArrivalProcessCore>(
        law, std::move(rng), std::move(state), std::move(expected_slot),
        std::move(owner), identity.value());
    return Result<ArrivalProcess>::success(
        detail::ArrivalCoreAccess::make_process(law->binding.family,
                                                std::move(core)));
  } catch (const std::bad_alloc&) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::resource_limit,
        "arrival_replay_cursor_allocation_failure",
        "creating a fresh builder-only replay cursor exhausted memory");
  }
}

class BusyLease final {
 public:
  explicit BusyLease(std::atomic_flag& flag) noexcept
      : flag_(&flag), acquired_(!flag.test_and_set(std::memory_order_acquire)) {}
  BusyLease(const BusyLease&) = delete;
  BusyLease& operator=(const BusyLease&) = delete;
  ~BusyLease() {
    if (acquired_) {
      flag_->clear(std::memory_order_release);
    }
  }
  [[nodiscard]] bool acquired() const noexcept { return acquired_; }

 private:
  std::atomic_flag* flag_;
  bool acquired_;
};

[[nodiscard]] bool is_construction_stage(const StageTag stage) noexcept {
  return stage == StageTag::surrogate_build_input ||
         stage == StageTag::surrogate_build_context ||
         stage == StageTag::surrogate_build_probe ||
         stage == StageTag::surrogate_build_final;
}

[[nodiscard]] bool has_process_local_access(
    const AccessProvision provision) noexcept {
  return provision == AccessProvision::process_local_only ||
         provision == AccessProvision::portable_and_process_local;
}

[[nodiscard]] bool is_valid_availability(
    const CapabilityAvailability availability) noexcept {
  switch (availability) {
    case CapabilityAvailability::unavailable:
    case CapabilityAvailability::available:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_stationary_status(
    const StationaryPhaseLawStatus status) noexcept {
  switch (status) {
    case StationaryPhaseLawStatus::unavailable:
    case StationaryPhaseLawStatus::supplied:
    case StationaryPhaseLawStatus::selected:
    case StationaryPhaseLawStatus::proved_unique:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_phase_requirement(
    const PhaseArgumentRequirement requirement) noexcept {
  switch (requirement) {
    case PhaseArgumentRequirement::phase_free:
    case PhaseArgumentRequirement::explicit_phase_required:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_access_provision(
    const AccessProvision provision) noexcept {
  switch (provision) {
    case AccessProvision::portable_only:
    case AccessProvision::process_local_only:
    case AccessProvision::portable_and_process_local:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_transform_kind(
    const TransformKind kind) noexcept {
  switch (kind) {
    case TransformKind::exact_pmf:
    case TransformKind::exact_pgf:
    case TransformKind::closed_transform:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_distribution_scope(
    const DistributionScope scope) noexcept {
  switch (scope) {
    case DistributionScope::joint_vector:
    case DistributionScope::per_coordinate:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_cube_boundary(
    const UnitCubeBoundary boundary) noexcept {
  switch (boundary) {
    case UnitCubeBoundary::left_closed_right_open:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_valid_inverse_cdf(
    const InverseCdfConvention convention) noexcept {
  switch (convention) {
    case InverseCdfConvention::first_cumulative_mass_strictly_greater:
      return true;
  }
  return false;
}

[[nodiscard]] bool is_nonempty_domain(
    const ExactArgumentDomain& domain) {
  if (domain.lower < domain.upper) {
    return true;
  }
  return domain.lower == domain.upper && domain.lower_inclusive &&
         domain.upper_inclusive;
}

[[nodiscard]] bool is_valid_transform(
    const TransformCapability& capability) {
  return is_valid_transform_kind(capability.kind) &&
         is_valid_distribution_scope(capability.scope) &&
         is_nonempty_domain(capability.domain) &&
         is_valid_phase_requirement(capability.phase_requirement) &&
         is_valid_access_provision(capability.provision);
}

[[nodiscard]] bool is_valid_moment_capability(
    const MomentCapability& capability) {
  // C09's portable moment carrier is a finite, unconditioned exact table.
  // Do not claim an infinite-order or phase-indexed evaluator that the frozen
  // construction ABI cannot actually provide.  Orders above two likewise
  // need a future reviewed multi-index/formula descriptor rather than an
  // ambiguous finite table row.
  return is_valid_access_provision(capability.provision) &&
         capability.maximum_order.has_value() &&
         !capability.maximum_order->is_zero() &&
         capability.maximum_order->value() <= 2 &&
         !capability.conditioned_on_phase;
}

[[nodiscard]] bool has_canonical_coordinates(
    const ExactMomentDatum& datum, const std::size_t queue_count) noexcept {
  if (datum.coordinates.empty() || datum.order.is_zero()) {
    return false;
  }
  for (std::size_t index = 0U; index < datum.coordinates.size(); ++index) {
    if (datum.coordinates[index].ordinal() >= queue_count ||
        (index != 0U &&
         datum.coordinates[index - 1U].ordinal() >
             datum.coordinates[index].ordinal())) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool moment_key_less(const ExactMomentDatum& left,
                                   const ExactMomentDatum& right) noexcept {
  const std::size_t common =
      std::min(left.coordinates.size(), right.coordinates.size());
  for (std::size_t index = 0U; index < common; ++index) {
    if (left.coordinates[index].ordinal() !=
        right.coordinates[index].ordinal()) {
      return left.coordinates[index].ordinal() <
             right.coordinates[index].ordinal();
    }
  }
  if (left.coordinates.size() != right.coordinates.size()) {
    return left.coordinates.size() < right.coordinates.size();
  }
  return left.order < right.order;
}

[[nodiscard]] bool is_canonical_moment_table(
    const std::vector<ExactMomentDatum>& table,
    const std::size_t queue_count, const bool covariance) noexcept {
  if (table.empty()) {
    return false;
  }
  for (std::size_t index = 0U; index < table.size(); ++index) {
    const auto& datum = table[index];
    if (!has_canonical_coordinates(datum, queue_count) ||
        (!covariance && !datum.value.is_nonnegative()) ||
        (covariance &&
         (datum.coordinates.size() != 2U || datum.order.value() != 2)) ||
        (index != 0U && !moment_key_less(table[index - 1U], datum))) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] bool contains_moment(
    const std::vector<ExactMomentDatum>& table,
    const std::span<const DenseQueueIndex> coordinates,
    const std::uint64_t order) {
  return std::ranges::any_of(table, [&](const ExactMomentDatum& datum) {
    return datum.order == BigNat(order) &&
           std::ranges::equal(datum.coordinates, coordinates);
  });
}

[[nodiscard]] bool moment_table_covers_claim(
    const std::vector<ExactMomentDatum>& table,
    const MomentCapability& claim, const QueueCatalog& queues) {
  const bool second_order = *claim.maximum_order == BigNat(2U);
  for (const ExactMomentDatum& datum : table) {
    if ((claim.joint || datum.coordinates.size() == 1U) &&
        datum.order > *claim.maximum_order) {
      return false;
    }
  }
  for (std::size_t left = 0U; left < queues.size(); ++left) {
    const auto left_queue = queues.index_at(left);
    if (!left_queue) {
      return false;
    }
    const std::array first_coordinate{left_queue.value()};
    if (!contains_moment(table, first_coordinate, 1U) ||
        (second_order &&
         !contains_moment(table, first_coordinate, 2U))) {
      return false;
    }
    if (!claim.joint || !second_order) {
      continue;
    }
    for (std::size_t right = left + 1U; right < queues.size(); ++right) {
      const auto right_queue = queues.index_at(right);
      if (!right_queue) {
        return false;
      }
      const std::array coordinates{left_queue.value(), right_queue.value()};
      if (!contains_moment(table, coordinates, 2U)) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] bool second_order_pair_table_covers_catalog(
    const std::vector<ExactMomentDatum>& table, const QueueCatalog& queues,
    const bool include_diagonal) {
  for (std::size_t left = 0U; left < queues.size(); ++left) {
    const auto left_queue = queues.index_at(left);
    if (!left_queue) {
      return false;
    }
    const std::size_t first_right = include_diagonal ? left : left + 1U;
    for (std::size_t right = first_right; right < queues.size(); ++right) {
      const auto right_queue = queues.index_at(right);
      if (!right_queue) {
        return false;
      }
      const std::array coordinates{left_queue.value(), right_queue.value()};
      if (!contains_moment(table, coordinates, 2U)) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] bool has_valid_capability_enums(
    const ArrivalCapabilities& capabilities) {
  if (!is_valid_availability(capabilities.exact_positive_support) ||
      !is_valid_availability(capabilities.sequential_normalized_sampler) ||
      !is_valid_availability(
          capabilities.finite_enumerated_predictive_phase) ||
      !is_valid_availability(
          capabilities.finite_enumerated_transition_row) ||
      !is_valid_stationary_status(capabilities.stationary_phase_law) ||
      !is_valid_availability(capabilities.exact_covariance) ||
      !is_valid_availability(capabilities.exact_cross_moments)) {
    return false;
  }
  const auto valid_optional_transform = [](const auto& value) {
    return !value.has_value() || is_valid_transform(*value);
  };
  const auto valid_optional_moment = [](const auto& value) noexcept {
    return !value.has_value() || is_valid_moment_capability(*value);
  };
  if (!valid_optional_transform(capabilities.analytic_transform) ||
      !valid_optional_transform(capabilities.exact_joint_distribution) ||
      !valid_optional_transform(
          capabilities.exact_coordinate_distributions) ||
      !valid_optional_moment(capabilities.analytic_moments) ||
      !valid_optional_moment(capabilities.exact_joint_moments) ||
      !valid_optional_moment(capabilities.exact_coordinate_moments)) {
    return false;
  }
  if (capabilities.exact_iid_joint_vector.has_value() &&
      !is_valid_access_provision(
          capabilities.exact_iid_joint_vector->provision)) {
    return false;
  }
  if (capabilities.adjacent_batch_replay.has_value() &&
      !is_valid_access_provision(
          capabilities.adjacent_batch_replay->provision)) {
    return false;
  }
  if (capabilities.unit_cube_transform.has_value()) {
    const auto& cube = *capabilities.unit_cube_transform;
    if (!is_valid_cube_boundary(cube.boundary) ||
        !is_valid_inverse_cdf(cube.inverse_cdf) ||
        !is_valid_phase_requirement(cube.phase_requirement) ||
        !is_valid_access_provision(cube.provision)) {
      return false;
    }
  }
  if (capabilities.exact_factorized_iid_generator.has_value() &&
      !is_valid_access_provision(
          capabilities.exact_factorized_iid_generator->provision)) {
    return false;
  }
  if (capabilities.exact_portable_iid_recipe.has_value() &&
      capabilities.exact_portable_iid_recipe->provision !=
          AccessProvision::portable_only) {
    return false;
  }
  return true;
}

[[nodiscard]] bool is_exact_portable_iid_recipe_schema(
    const PortableArrivalLawSchema schema) noexcept {
  switch (schema) {
    case PortableArrivalLawSchema::iid_independent_bernoulli_v1:
    case PortableArrivalLawSchema::iid_count_table_v1:
    case PortableArrivalLawSchema::iid_independent_poisson_v1:
    case PortableArrivalLawSchema::iid_mixed_poisson_v1:
      return true;
    default:
      return false;
  }
}

[[nodiscard]] std::optional<PortableArrivalLawSchema> expected_schema(
    const ArrivalFamily family) noexcept {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return PortableArrivalLawSchema::deterministic_trace_v1;
    case ArrivalFamily::periodic_global_phase:
      return PortableArrivalLawSchema::periodic_global_phase_v1;
    case ArrivalFamily::periodic_source_delays:
      return PortableArrivalLawSchema::periodic_source_delays_v1;
    case ArrivalFamily::independent_marked_renewal:
      return PortableArrivalLawSchema::independent_marked_renewal_v1;
    case ArrivalFamily::independent_private_markov_renewal:
      return PortableArrivalLawSchema::independent_private_markov_renewal_v1;
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1;
    case ArrivalFamily::iid_independent_bernoulli:
      return PortableArrivalLawSchema::iid_independent_bernoulli_v1;
    case ArrivalFamily::iid_count_table:
      return PortableArrivalLawSchema::iid_count_table_v1;
    case ArrivalFamily::iid_independent_poisson:
      return PortableArrivalLawSchema::iid_independent_poisson_v1;
    case ArrivalFamily::iid_mixed_poisson:
      return PortableArrivalLawSchema::iid_mixed_poisson_v1;
  }
  return std::nullopt;
}

}  // namespace

namespace detail {

Result<Digest256> digest_arrival_state(
    const std::span<const std::byte> canonical_state) {
  return state_digest(canonical_state);
}

Result<QueueCatalogDigest> digest_queue_catalog(const QueueCatalog& queues) {
  std::vector<std::byte> encoded;
  try {
    append_u32(encoded, 1U);
    append_u64(encoded, static_cast<std::uint64_t>(queues.size()));
    for (const auto& entry : queues.entries()) {
      const auto label = entry.id.canonical_bytes();
      append_u64(encoded, static_cast<std::uint64_t>(label.size()));
      for (const auto byte : label) {
        encoded.push_back(static_cast<std::byte>(byte));
      }
    }
  } catch (const std::bad_alloc&) {
    return failure<QueueCatalogDigest>(
        DiagnosticCategory::resource_limit, "arrival_catalog_digest_allocation",
        "arrival queue-catalog fingerprinting exhausted memory");
  }
  auto digest =
      sha256_domain_separated("mwperf.arrival.queue_catalog", encoded);
  if (!digest) {
    return Result<QueueCatalogDigest>::failure(digest.error());
  }
  return Result<QueueCatalogDigest>::success(
      QueueCatalogDigest(digest.value()));
}

Result<ArrivalLawDigest> digest_arrival_law(
    const ArrivalFamily family, const QueueCatalogDigest& catalog,
    const std::span<const std::byte> canonical_law_data) {
  std::vector<std::byte> encoded;
  try {
    append_u32(encoded, 1U);
    encoded.push_back(static_cast<std::byte>(family));
    append_digest(encoded, catalog.value());
    append_bytes(encoded, canonical_law_data);
  } catch (const std::bad_alloc&) {
    return failure<ArrivalLawDigest>(
        DiagnosticCategory::resource_limit, "arrival_law_digest_allocation",
        "arrival-law fingerprinting exhausted memory");
  }
  auto digest = sha256_domain_separated("mwperf.arrival.compiled_law", encoded);
  if (!digest) {
    return Result<ArrivalLawDigest>::failure(digest.error());
  }
  return Result<ArrivalLawDigest>::success(ArrivalLawDigest(digest.value()));
}

const std::shared_ptr<const CompiledArrivalLawCore>& ArrivalCoreAccess::law_core(
    const CompiledArrivalLaw& law) noexcept {
  return std::visit(
      [](const auto& handle)
          -> const std::shared_ptr<const CompiledArrivalLawCore>& {
        return handle.core_;
      },
      law.variant_);
}

std::shared_ptr<ArrivalProcessCore> ArrivalCoreAccess::process_core(
    ArrivalProcess& process) noexcept {
  return std::visit(
      [](auto& handle) -> std::shared_ptr<ArrivalProcessCore> {
        return handle.core_;
      },
      process.variant_);
}

std::shared_ptr<const ArrivalProcessCore> ArrivalCoreAccess::process_core(
    const ArrivalProcess& process) noexcept {
  return std::visit(
      [](const auto& handle) -> std::shared_ptr<const ArrivalProcessCore> {
        return handle.core_;
      },
      process.variant_);
}

const std::shared_ptr<const ArrivalPhaseCore>& ArrivalCoreAccess::phase_core(
    const ArrivalPhase& phase) noexcept {
  return std::visit(
      [](const auto& handle) -> const std::shared_ptr<const ArrivalPhaseCore>& {
        return handle.core_;
      },
      phase);
}

CompiledArrivalLaw ArrivalCoreAccess::make_law(
    std::shared_ptr<const CompiledArrivalLawCore> core) {
  switch (core->binding.family) {
    case ArrivalFamily::deterministic_trace:
      return CompiledArrivalLaw(
          CompiledArrivalVariant(CompiledTraceArrivalLaw(std::move(core))));
    case ArrivalFamily::periodic_global_phase:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledGlobalPeriodicArrivalLaw(std::move(core))));
    case ArrivalFamily::periodic_source_delays:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledSourceDelayArrivalLaw(std::move(core))));
    case ArrivalFamily::independent_marked_renewal:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledMarkedRenewalArrivalLaw(std::move(core))));
    case ArrivalFamily::independent_private_markov_renewal:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledPrivateMarkovArrivalLaw(std::move(core))));
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledSharedRoundArrivalLaw(std::move(core))));
    case ArrivalFamily::iid_independent_bernoulli:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledIidBernoulliArrivalLaw(std::move(core))));
    case ArrivalFamily::iid_count_table:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledIidCountTableArrivalLaw(std::move(core))));
    case ArrivalFamily::iid_independent_poisson:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledIidPoissonArrivalLaw(std::move(core))));
    case ArrivalFamily::iid_mixed_poisson:
      return CompiledArrivalLaw(CompiledArrivalVariant(
          CompiledIidMixedPoissonArrivalLaw(std::move(core))));
  }
  std::terminate();
}

ArrivalProcess ArrivalCoreAccess::make_process(
    const ArrivalFamily family, std::shared_ptr<ArrivalProcessCore> core) {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return ArrivalProcess(
          ArrivalProcessVariant(TraceArrivalProcess(std::move(core))));
    case ArrivalFamily::periodic_global_phase:
      return ArrivalProcess(ArrivalProcessVariant(
          GlobalPeriodicArrivalProcess(std::move(core))));
    case ArrivalFamily::periodic_source_delays:
      return ArrivalProcess(ArrivalProcessVariant(
          SourceDelayArrivalProcess(std::move(core))));
    case ArrivalFamily::independent_marked_renewal:
      return ArrivalProcess(ArrivalProcessVariant(
          MarkedRenewalArrivalProcess(std::move(core))));
    case ArrivalFamily::independent_private_markov_renewal:
      return ArrivalProcess(ArrivalProcessVariant(
          PrivateMarkovArrivalProcess(std::move(core))));
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return ArrivalProcess(ArrivalProcessVariant(
          SharedRoundArrivalProcess(std::move(core))));
    case ArrivalFamily::iid_independent_bernoulli:
      return ArrivalProcess(ArrivalProcessVariant(
          IidBernoulliArrivalProcess(std::move(core))));
    case ArrivalFamily::iid_count_table:
      return ArrivalProcess(ArrivalProcessVariant(
          IidCountTableArrivalProcess(std::move(core))));
    case ArrivalFamily::iid_independent_poisson:
      return ArrivalProcess(ArrivalProcessVariant(
          IidPoissonArrivalProcess(std::move(core))));
    case ArrivalFamily::iid_mixed_poisson:
      return ArrivalProcess(ArrivalProcessVariant(
          IidMixedPoissonArrivalProcess(std::move(core))));
  }
  std::terminate();
}

ArrivalPhase ArrivalCoreAccess::make_phase(
    const ArrivalFamily family, std::shared_ptr<const ArrivalPhaseCore> core) {
  switch (family) {
    case ArrivalFamily::deterministic_trace:
      return ArrivalPhase(TraceArrivalPhase(std::move(core)));
    case ArrivalFamily::periodic_global_phase:
      return ArrivalPhase(GlobalPeriodicArrivalPhase(std::move(core)));
    case ArrivalFamily::periodic_source_delays:
      return ArrivalPhase(SourceDelayArrivalPhase(std::move(core)));
    case ArrivalFamily::independent_marked_renewal:
      return ArrivalPhase(MarkedRenewalArrivalPhase(std::move(core)));
    case ArrivalFamily::independent_private_markov_renewal:
      return ArrivalPhase(PrivateMarkovArrivalPhase(std::move(core)));
    case ArrivalFamily::shared_joint_round_markov_renewal:
      return ArrivalPhase(SharedRoundArrivalPhase(std::move(core)));
    case ArrivalFamily::iid_independent_bernoulli:
      return ArrivalPhase(IidBernoulliArrivalPhase(std::move(core)));
    case ArrivalFamily::iid_count_table:
      return ArrivalPhase(IidCountTableArrivalPhase(std::move(core)));
    case ArrivalFamily::iid_independent_poisson:
      return ArrivalPhase(IidPoissonArrivalPhase(std::move(core)));
    case ArrivalFamily::iid_mixed_poisson:
      return ArrivalPhase(IidMixedPoissonArrivalPhase(std::move(core)));
  }
  std::terminate();
}

ArrivalBatch ArrivalCoreAccess::bind_empty_batch(
    ArrivalBatch batch, const ArrivalBinding& binding) {
  if (batch.entries_.empty() && !batch.binding_.has_value()) {
    batch.binding_ = binding;
  }
  return batch;
}

InitialPhysicalLaw ArrivalCoreAccess::make_initial_law(
    ArrivalBinding binding, NormalizedPmf original_pmf,
    std::vector<InitialPhysicalAtom> atoms,
    std::vector<std::size_t> original_to_atom) {
  auto origin =
      std::make_shared<const InitialPhysicalLaw::OriginToken>();
  return InitialPhysicalLaw(std::move(binding), std::move(original_pmf),
                            std::move(atoms),
                            std::move(original_to_atom), std::move(origin));
}

Result<CompiledArrivalLaw> ArrivalCoreAccess::publish(
    const QueueCatalog& queues, CompiledArrivalProduct product) {
  try {
  const auto schema = expected_schema(product.family);
  if (!schema.has_value() || *schema != product.portable_schema) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_portable_schema_mismatch",
        "the compiled arrival family and its closed portable schema disagree");
  }
  if (!product.payload) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_compiled_payload_missing",
        "an arrival compiler returned no immutable family payload");
  }
  if (product.capabilities.version != 1U) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_version_unsupported",
        "an arrival compiler returned an unsupported capability version");
  }
  if (!has_valid_capability_enums(product.capabilities)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "an arrival compiler returned an invalid capability discriminant or "
        "an empty exact transform domain");
  }
  if (product.capabilities.exact_positive_support !=
      CapabilityAvailability::available) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "every compiled arrival law must advertise its exact positive support");
  }
  auto support =
      QueueMask::from_bytes(std::move(product.positive_support), queues.size());
  if (!support) {
    return Result<CompiledArrivalLaw>::failure(support.error());
  }
  const bool any_sampler_operation =
      static_cast<bool>(product.runtime.validate_initial) ||
      static_cast<bool>(product.runtime.instantiate) ||
      static_cast<bool>(product.runtime.encode_phase) ||
      static_cast<bool>(product.runtime.propose);
  const bool sampler_backed = product.runtime.validate_initial &&
                              product.runtime.instantiate &&
                              product.runtime.encode_phase &&
                              product.runtime.propose;
  if (any_sampler_operation && !sampler_backed) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_runtime_adapter_incomplete",
        "a sequential arrival runtime must register its validator, cursor "
        "initializer, phase encoder, and transition operation together");
  }
  if ((product.capabilities.sequential_normalized_sampler ==
       CapabilityAvailability::available) != sampler_backed) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the sequential-sampler capability does not match its registered "
        "runtime operations");
  }
  if ((product.capabilities.finite_enumerated_predictive_phase ==
       CapabilityAvailability::available) !=
      product.finite_phase.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the finite predictive-phase claim does not match its portable "
        "descriptor");
  }
  if ((product.capabilities.finite_enumerated_transition_row ==
       CapabilityAvailability::available) !=
      product.transition_rows.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the enumerated-transition claim does not match its portable rows");
  }
  if (product.transition_rows.has_value() &&
      !product.finite_phase.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "enumerated transition rows require a finite enumerated phase domain");
  }
  if ((product.capabilities.stationary_phase_law !=
       StationaryPhaseLawStatus::unavailable) !=
      product.stationary_phase_law.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the stationary-phase status does not match its exact portable law");
  }
  if (product.capabilities.exact_iid_joint_vector.has_value() !=
      product.iid_joint_table.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact IID joint-vector claim lacks its exact joint table, or vice "
        "versa");
  }
  if (product.capabilities.exact_iid_joint_vector.has_value() &&
      product.capabilities.exact_iid_joint_vector->provision !=
          AccessProvision::portable_only) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact IID joint-vector table has no process-local evaluator; its "
        "access provision must be portable-only");
  }
  if (product.capabilities.exact_iid_joint_vector.has_value() &&
      !product.capabilities.exact_iid_joint_vector->finite_support) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "an exact IID joint-vector table is a finite-support accessor and "
        "must advertise finite support");
  }
  if (product.capabilities.exact_factorized_iid_generator.has_value() &&
      (product.capabilities.exact_factorized_iid_generator->provision !=
           AccessProvision::portable_only ||
       product.family != ArrivalFamily::independent_marked_renewal ||
       product.portable_schema !=
           PortableArrivalLawSchema::independent_marked_renewal_v1)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact factorized IID generator must be backed by the portable "
        "independent-marked-renewal descriptor");
  }
  if (product.capabilities.exact_portable_iid_recipe.has_value() &&
      (product.capabilities.exact_portable_iid_recipe->provision !=
           AccessProvision::portable_only ||
       !is_exact_portable_iid_recipe_schema(product.portable_schema) ||
       product.canonical_law_data.empty())) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact portable IID recipe capability must be backed by a "
        "canonical schema-4 IID configured-law descriptor");
  }
  if (product.iid_joint_table.has_value()) {
    if (product.iid_joint_table->empty()) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal,
          "arrival_capability_contract_mismatch",
          "an exact IID joint-vector table cannot be empty");
    }
    ExactRational mass = ExactRational::zero();
    std::vector<std::uint8_t> table_support(queues.size(), 0U);
    std::set<std::vector<BigNat>> distinct_atoms;
    const BigNat maximum_count(
        product.family == ArrivalFamily::iid_count_table
            ? std::numeric_limits<std::uint64_t>::max()
            : static_cast<std::uint64_t>(
                  std::numeric_limits<std::int64_t>::max()));
    for (const auto& atom : *product.iid_joint_table) {
      if (atom.dense_counts.size() != queues.size() ||
          !atom.probability.is_positive()) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "an exact IID joint-vector support atom has invalid dimension or "
            "nonpositive mass");
      }
      if (std::ranges::any_of(atom.dense_counts,
                              [&](const BigNat& count) {
                                return count > maximum_count;
                              })) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "an exact IID joint-vector atom exceeds the canonical count "
            "bound");
      }
      if (!distinct_atoms.insert(atom.dense_counts).second) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "an exact IID joint-vector table contains a duplicate complete "
            "batch atom");
      }
      for (std::size_t queue = 0U; queue < atom.dense_counts.size(); ++queue) {
        if (!atom.dense_counts[queue].is_zero()) {
          table_support[queue] = 1U;
        }
      }
      mass = mass + atom.probability;
    }
    if (!(mass == ExactRational::one())) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal,
          "arrival_capability_contract_mismatch",
          "the exact IID joint-vector table is not exactly normalized");
    }
    if (table_support != support.value().bytes()) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "the exact IID joint-vector table's positive queue support differs "
          "from the compiled law's exact positive support");
    }
  }
  const bool any_moment_claim =
      product.capabilities.analytic_moments.has_value() ||
      product.capabilities.exact_joint_moments.has_value() ||
      product.capabilities.exact_coordinate_moments.has_value();
  if (any_moment_claim != product.moments.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact moment claims do not match their portable data");
  }
  const auto unsupported_moment_provision = [](const auto& claim) {
    return claim.has_value() &&
           claim->provision != AccessProvision::portable_only;
  };
  if (unsupported_moment_provision(
          product.capabilities.analytic_moments) ||
      unsupported_moment_provision(
          product.capabilities.exact_joint_moments) ||
      unsupported_moment_provision(
          product.capabilities.exact_coordinate_moments)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "exact moment data have no process-local evaluator; their access "
        "provision must be portable-only");
  }
  if (product.capabilities.exact_joint_moments.has_value() &&
      !product.capabilities.exact_joint_moments->joint) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact joint-moment capability must identify joint access");
  }
  if (product.capabilities.exact_coordinate_moments.has_value() &&
      product.capabilities.exact_coordinate_moments->joint) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact coordinate-moment capability cannot identify joint "
        "access");
  }
  if (product.moments.has_value() &&
      !is_canonical_moment_table(*product.moments, queues.size(), false)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact moment table has an empty, out-of-range, noncanonical, "
        "duplicate, nonpositive-order, or negative-moment row");
  }
  if (product.capabilities.analytic_moments.has_value() &&
      !moment_table_covers_claim(*product.moments,
                                 *product.capabilities.analytic_moments,
                                 queues)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the analytic-moment table does not contain canonical data within "
        "its advertised order bound");
  }
  if (product.capabilities.exact_joint_moments.has_value() &&
      !moment_table_covers_claim(*product.moments,
                                 *product.capabilities.exact_joint_moments,
                                 queues)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact joint-moment table exceeds its advertised order bound");
  }
  if (product.capabilities.exact_coordinate_moments.has_value() &&
      !moment_table_covers_claim(
          *product.moments,
          *product.capabilities.exact_coordinate_moments, queues)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact coordinate-moment table lacks coordinate data within its "
        "advertised order bound");
  }
  if ((product.capabilities.exact_covariance ==
       CapabilityAvailability::available) !=
      product.covariances.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the covariance claim does not match its portable data");
  }
  if (product.covariances.has_value() &&
      !is_canonical_moment_table(*product.covariances, queues.size(), true)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact covariance table has an out-of-range, noncanonical, "
        "duplicate, or non-second-order row");
  }
  if (product.covariances.has_value() &&
      !second_order_pair_table_covers_catalog(*product.covariances, queues,
                                              true)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact covariance table does not cover every canonical queue "
        "pair, including the diagonal");
  }
  if (product.capabilities.exact_cross_moments ==
          CapabilityAvailability::available &&
      !product.moments.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact cross-moment claim has no exact portable moment data");
  }
  if (product.capabilities.exact_cross_moments ==
          CapabilityAvailability::available &&
      !second_order_pair_table_covers_catalog(*product.moments, queues,
                                              false)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact cross-moment table does not cover every distinct "
        "canonical queue pair");
  }
  if (product.capabilities.analytic_transform.has_value() !=
      product.analytic_transform.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the analytic-transform claim does not match its independent portable "
        "descriptor");
  }
  if (product.capabilities.exact_joint_distribution.has_value() !=
      product.joint_distribution.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact joint-distribution claim does not match its independent "
        "portable descriptor");
  }
  if (product.capabilities.exact_coordinate_distributions.has_value() !=
      product.coordinate_distributions.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the exact coordinate-distribution claim does not match its "
        "independent portable descriptor");
  }
  const auto unsupported_transform_provision = [](const auto& claim) {
    return claim.has_value() &&
           claim->provision != AccessProvision::portable_only;
  };
  if (unsupported_transform_provision(
          product.capabilities.analytic_transform) ||
      unsupported_transform_provision(
          product.capabilities.exact_joint_distribution) ||
      unsupported_transform_provision(
          product.capabilities.exact_coordinate_distributions)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "transform/distribution descriptors have no process-local evaluator; "
        "their access provision must be portable-only");
  }
  if (product.capabilities.adjacent_batch_replay.has_value() !=
      product.replay_codec.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the adjacent-replay claim does not match its initialization codec");
  }
  if (product.capabilities.adjacent_batch_replay.has_value()) {
    const ReplayCapability& replay =
        *product.capabilities.adjacent_batch_replay;
    if (!replay.explicit_initial_state && !replay.explicit_phase &&
        !replay.normalized_initial_law &&
        !replay.named_stationary_initialization) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "an adjacent-replay capability must advertise at least one complete "
          "initialization mode");
    }
    const bool local_replay = has_process_local_access(replay.provision);
    if (local_replay && !sampler_backed) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "process-local adjacent replay requires a complete sequential "
          "arrival sampler");
    }
    if (local_replay &&
        (replay.explicit_initial_state || replay.normalized_initial_law) &&
        (!product.runtime.validate_initial || !product.runtime.instantiate)) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "initial-state replay lacks its family validator or cursor "
          "initializer");
    }
    if (local_replay && replay.explicit_phase &&
        (!product.runtime.decode_phase || !product.runtime.encode_phase)) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "explicit predictive-phase replay lacks a complete exact phase "
          "codec");
    }
    if (local_replay && replay.named_stationary_initialization &&
        (product.capabilities.stationary_phase_law ==
             StationaryPhaseLawStatus::unavailable ||
         !product.stationary_phase_law.has_value() ||
         !product.runtime.decode_phase)) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "named stationary replay lacks a stationary phase law or exact "
          "phase decoder");
    }
  }
  if (product.capabilities.unit_cube_transform.has_value() !=
      product.unit_cube.has_value()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the unit-cube claim and portable descriptor are inconsistent");
  }
  if (!product.capabilities.unit_cube_transform.has_value() &&
      product.runtime.unit_cube) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "a hidden process-local unit-cube evaluator was registered without "
        "a capability claim");
  }
  if (product.capabilities.unit_cube_transform.has_value()) {
    const bool local_cube = has_process_local_access(
        product.capabilities.unit_cube_transform->provision);
    if (local_cube != static_cast<bool>(product.runtime.unit_cube) ||
        (local_cube &&
         (!product.runtime.decode_phase || !product.runtime.encode_phase))) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "the unit-cube access provision does not match its process-local "
          "evaluator and complete predictive-phase codec");
    }
  }
  if (product.capabilities.unit_cube_transform.has_value() &&
      !(*product.capabilities.unit_cube_transform ==
        product.unit_cube->capability)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the unit-cube capability and portable descriptor disagree");
  }
  if (product.capabilities.analytic_transform.has_value() &&
      !(*product.capabilities.analytic_transform ==
        product.analytic_transform->capability)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the analytic-transform capability and portable descriptor disagree");
  }
  const auto descriptor_codec_is_valid = [](const auto& descriptor) {
    return !descriptor.has_value() || descriptor->codec_version != 0U;
  };
  if (!descriptor_codec_is_valid(product.analytic_transform) ||
      !descriptor_codec_is_valid(product.joint_distribution) ||
      !descriptor_codec_is_valid(product.coordinate_distributions)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "a portable transform/distribution descriptor has codec version "
        "zero");
  }
  if (product.capabilities.exact_joint_distribution.has_value() &&
      !(*product.capabilities.exact_joint_distribution ==
        product.joint_distribution->capability)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the joint-distribution capability and portable descriptor disagree");
  }
  if (product.joint_distribution.has_value() &&
      product.joint_distribution->capability.scope !=
          DistributionScope::joint_vector) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "an exact joint-distribution descriptor must have joint-vector "
        "scope");
  }
  if (product.capabilities.exact_coordinate_distributions.has_value() &&
      !(*product.capabilities.exact_coordinate_distributions ==
        product.coordinate_distributions->capability)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "the coordinate-distribution capability and portable descriptor "
        "disagree");
  }
  if (product.coordinate_distributions.has_value() &&
      product.coordinate_distributions->capability.scope !=
          DistributionScope::per_coordinate) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "an exact coordinate-distribution descriptor must have "
        "per-coordinate scope");
  }
  if (product.replay_codec.has_value() &&
      (product.replay_codec->codec_version == 0U ||
       !product.replay_codec->requires_complete_initial_state ||
       !product.replay_codec->preserves_adjacent_temporal_order)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "an adjacent replay codec must be versioned, require complete "
        "initialization, and preserve adjacent temporal order");
  }
  if (product.unit_cube.has_value()) {
    const auto& cube = *product.unit_cube;
    if (cube.codec_version == 0U ||
        cube.capability.dimension.value() !=
            BigInt(cube.coordinate_order.size())) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "the unit-cube descriptor has an invalid codec version or its "
          "coordinate count differs from its exact dimension");
    }
    std::set<std::string> roles;
    for (std::size_t index = 0U; index < cube.coordinate_order.size();
         ++index) {
      const auto& coordinate = cube.coordinate_order[index];
      if (coordinate.ordinal != index || coordinate.role.empty() ||
          !roles.insert(coordinate.role).second) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "the unit-cube coordinate metadata is not a canonical "
            "zero-based ordering with unique nonempty roles");
      }
    }
  }
  if (product.finite_phase.has_value() &&
      product.finite_phase->canonical_states.empty()) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "an advertised finite phase domain must enumerate at least one state");
  }
  const bool homogeneous_phase_rows =
      product.finite_phase.has_value() &&
      product.finite_phase->row_clock_semantics ==
          ArrivalRowClockSemanticsV1::finite_phase_time_homogeneous;
  const bool authored_slot_rows =
      !product.finite_phase.has_value() ||
      product.finite_phase->row_clock_semantics ==
          ArrivalRowClockSemanticsV1::authored_slot_conditioned;
  if (!homogeneous_phase_rows && !authored_slot_rows) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal,
        "arrival_capability_contract_mismatch",
        "the finite predictive-phase descriptor has an unknown row-clock "
        "semantics");
  }
  if (product.finite_phase.has_value()) {
    const auto& states = product.finite_phase->canonical_states;
    if (product.finite_phase->codec_version == 0U) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "the finite predictive-phase descriptor has codec version zero");
    }
    const bool complete_phase_codec =
        product.runtime.decode_phase && product.runtime.encode_phase;
    if (homogeneous_phase_rows && !complete_phase_codec) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "a finite time-homogeneous predictive-phase descriptor requires "
          "complete exact encode/decode operations");
    }
    for (std::size_t index = 0U; index < states.size(); ++index) {
      if (std::ranges::find(states.begin(), states.begin() + index,
                            states[index]) != states.begin() + index) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "the finite predictive-phase descriptor contains duplicate "
            "canonical states");
      }
      if (complete_phase_codec) {
        auto decoded =
            product.runtime.decode_phase(product.payload, states[index]);
        if (!decoded || !decoded.value()) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_capability_contract_mismatch",
              "a finite predictive-phase state is rejected by its exact "
              "process-local codec");
        }
        auto encoded =
            product.runtime.encode_phase(product.payload, decoded.value());
        if (!encoded || !std::ranges::equal(encoded.value(), states[index])) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_capability_contract_mismatch",
              "a finite predictive-phase state does not round-trip through "
              "its exact process-local codec");
        }
      }
    }
  }
  if (homogeneous_phase_rows !=
      static_cast<bool>(product.runtime.enumerate_time_homogeneous)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal,
        "arrival_capability_contract_mismatch",
        "a finite time-homogeneous phase claim and its slot-free exact row "
        "operation must be supplied together");
  }
  if (homogeneous_phase_rows &&
      (!product.transition_rows.has_value() ||
       product.capabilities.finite_enumerated_predictive_phase !=
           CapabilityAvailability::available ||
       product.capabilities.finite_enumerated_transition_row !=
           CapabilityAvailability::available ||
       !product.runtime.enumerate)) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal,
        "arrival_capability_contract_mismatch",
        "a finite time-homogeneous phase claim requires the finite phase, "
        "portable transition rows, and ordinary exact-row capability in "
        "addition to its slot-free operation");
  }
  if (product.transition_rows.has_value() &&
      (product.transition_rows->codec_version == 0U ||
       product.transition_rows->canonical_rows.empty() ||
       (product.finite_phase.has_value() &&
        product.transition_rows->codec_version !=
            product.finite_phase->codec_version))) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
        "enumerated transition rows must use a nonzero codec matching their "
        "finite predictive-phase descriptor and retain nonempty canonical "
        "row bytes");
  }
  if (product.stationary_phase_law.has_value()) {
    const auto& stationary = *product.stationary_phase_law;
    if (stationary.law_id.empty() || stationary.codec_version == 0U ||
        stationary.canonical_states.empty() ||
        stationary.canonical_states.size() != stationary.probabilities.size()) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal,
          "arrival_capability_contract_mismatch",
          "the stationary phase law has inconsistent state/probability "
          "dimensions");
    }
    if (product.finite_phase.has_value() &&
        stationary.codec_version != product.finite_phase->codec_version) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal, "arrival_capability_contract_mismatch",
          "the stationary phase law and finite phase domain use different "
          "state codec versions");
    }
    auto valid_stationary = revalidate_normalized_pmf(
        stationary.probabilities, physical_pmf_tolerance());
    if (!valid_stationary) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::internal,
          "arrival_capability_contract_mismatch",
          "the stationary phase law does not contain a valid pre-normalized "
          "exact PMF");
    }
    for (std::size_t index = 0U;
         index < stationary.canonical_states.size(); ++index) {
      const auto& canonical = stationary.canonical_states[index];
      if (std::ranges::find(stationary.canonical_states.begin(),
                            stationary.canonical_states.begin() + index,
                            canonical) !=
          stationary.canonical_states.begin() + index) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "the stationary phase law contains duplicate canonical states");
      }
      if (product.finite_phase.has_value() &&
          std::ranges::find(product.finite_phase->canonical_states,
                            canonical) ==
              product.finite_phase->canonical_states.end()) {
        return failure<CompiledArrivalLaw>(
            DiagnosticCategory::internal,
            "arrival_capability_contract_mismatch",
            "the stationary phase law contains a state outside the "
            "advertised finite phase domain");
      }
      if (product.capabilities.adjacent_batch_replay.has_value() &&
          has_process_local_access(
              product.capabilities.adjacent_batch_replay->provision) &&
          product.capabilities.adjacent_batch_replay
              ->named_stationary_initialization) {
        auto decoded = product.runtime.decode_phase(product.payload,
                                                     canonical);
        if (!decoded || !decoded.value()) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_capability_contract_mismatch",
              "the stationary phase law contains a state rejected by its "
              "process-local codec");
        }
        auto encoded = product.runtime.encode_phase(product.payload,
                                                     decoded.value());
        if (!encoded || !std::ranges::equal(encoded.value(), canonical)) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_capability_contract_mismatch",
              "the stationary phase codec does not round-trip canonically");
        }
      }
    }
  }

  auto catalog_digest = digest_queue_catalog(queues);
  if (!catalog_digest) {
    return Result<CompiledArrivalLaw>::failure(catalog_digest.error());
  }
  auto law_digest = digest_arrival_law(product.family, catalog_digest.value(),
                                       product.canonical_law_data);
  if (!law_digest) {
    return Result<CompiledArrivalLaw>::failure(law_digest.error());
  }
  ArrivalBinding binding{product.family,
                         TimingConvention::early_service_late_admission,
                         queues.size(),
                         law_digest.value(),
                         catalog_digest.value()};

  if (homogeneous_phase_rows) {
    try {
      std::vector<std::byte> derived_rows;
      std::vector<bool> witnessed_positive_support(queues.size(), false);
      append_u32(derived_rows, 1U);
      append_u64(derived_rows, static_cast<std::uint64_t>(
                                   product.finite_phase->canonical_states
                                       .size()));
      for (const auto& canonical_phase :
           product.finite_phase->canonical_states) {
        auto cursor =
            product.runtime.decode_phase(product.payload, canonical_phase);
        if (!cursor || !cursor.value()) {
          return cursor
                     ? failure<CompiledArrivalLaw>(
                           DiagnosticCategory::internal,
                           "arrival_homogeneous_phase_decode_null",
                           "a finite homogeneous phase decoded to a null "
                           "process-local cursor")
                     : Result<CompiledArrivalLaw>::failure(cursor.error());
        }
        auto row = product.runtime.enumerate_time_homogeneous(
            product.payload, cursor.value(), binding);
        if (!row) {
          return Result<CompiledArrivalLaw>::failure(row.error());
        }
        if (row.value().empty()) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_homogeneous_row_empty",
              "every advertised finite homogeneous phase must have a "
              "nonempty exact transition row");
        }
        ExactRational total = ExactRational::zero();
        std::map<std::vector<std::byte>, ExactRational,
                 CanonicalByteVectorLess>
            canonical_outcomes;
        for (const ExactArrivalTransitionAtom& atom : row.value()) {
          if (atom.phase_before != canonical_phase ||
              std::ranges::find(product.finite_phase->canonical_states,
                                atom.phase_after) ==
                  product.finite_phase->canonical_states.end() ||
              atom.mass < ExactRational::zero() ||
              (atom.mass.is_zero() && atom.structural_support) ||
              (atom.mass.is_positive() && !atom.structural_support)) {
            return failure<CompiledArrivalLaw>(
                DiagnosticCategory::internal,
                "arrival_homogeneous_row_invalid",
                "a finite homogeneous row has a foreign "
                "conditioning/successor phase, negative mass, or "
                "disagreement between exact positive mass and structural "
                "support");
          }
          auto aggregated = aggregate_arrival_batch(atom.atoms);
          if (!aggregated) {
            if (aggregated.error().category ==
                DiagnosticCategory::resource_limit) {
              return Result<CompiledArrivalLaw>::failure(
                  aggregated.error());
            }
            return failure<CompiledArrivalLaw>(
                DiagnosticCategory::internal,
                "arrival_homogeneous_row_invalid_batch",
                "a finite homogeneous row does not form an executable "
                "canonical arrival batch",
                {aggregated.error().code, aggregated.error().message});
          }
          ArrivalBatch batch = std::move(aggregated).value();
          if (batch.empty_batch()) {
            batch = bind_empty_batch(std::move(batch), binding);
          }
          if (!batch.binding().has_value() ||
              !(*batch.binding() == binding)) {
            return failure<CompiledArrivalLaw>(
                DiagnosticCategory::internal,
                "arrival_homogeneous_row_binding_mismatch",
                "a finite homogeneous row emits outside its bound law or "
                "queue catalog");
          }
          for (const ArrivalBatchEntry& arrival : batch.entries()) {
            if (arrival.queue.ordinal() >= queues.size() ||
                !support.value().at(arrival.queue)) {
              return failure<CompiledArrivalLaw>(
                  DiagnosticCategory::internal,
                  "arrival_homogeneous_row_support_mismatch",
                  "a finite homogeneous row emits outside its exact "
                  "positive-support mask");
            }
            if (atom.mass.is_positive()) {
              witnessed_positive_support[arrival.queue.ordinal()] = true;
            }
          }
          total = total + atom.mass;
          if (atom.mass.is_positive()) {
            auto key = canonical_homogeneous_outcome_key(atom, batch);
            const auto [position, inserted] =
                canonical_outcomes.try_emplace(std::move(key), atom.mass);
            if (!inserted) {
              position->second = position->second + atom.mass;
            }
          }
        }
        if (!(total == ExactRational::one())) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_homogeneous_row_mass_mismatch",
              "every finite homogeneous transition row must have exact "
              "unit mass without normalization");
        }
        append_bytes(derived_rows, canonical_phase);
        append_u64(derived_rows,
                   static_cast<std::uint64_t>(canonical_outcomes.size()));
        for (const auto& [outcome_key, mass] : canonical_outcomes) {
          const auto atom = canonical_homogeneous_row_atom(outcome_key, mass);
          append_bytes(derived_rows, atom);
        }
      }
      for (std::size_t index = 0U; index < queues.size(); ++index) {
        auto queue = queues.index_at(index);
        if (!queue) {
          return Result<CompiledArrivalLaw>::failure(queue.error());
        }
        if (support.value().at(queue.value()) !=
            witnessed_positive_support[index]) {
          return failure<CompiledArrivalLaw>(
              DiagnosticCategory::internal,
              "arrival_homogeneous_row_support_mismatch",
              "the union of positive-mass finite homogeneous rows does not "
              "equal the advertised exact positive-support mask",
              {"queue ordinal " + std::to_string(index)});
        }
      }
      // For the stronger homogeneous contract the validated slot-free
      // callback is the sole row authority.  Store its deterministic exact
      // serialization in the portable descriptor, replacing any child
      // placeholder bytes and eliminating two competing row descriptions.
      product.transition_rows->canonical_rows = std::move(derived_rows);
    } catch (const std::bad_alloc&) {
      return failure<CompiledArrivalLaw>(
          DiagnosticCategory::resource_limit,
          "arrival_homogeneous_rows_allocation_failure",
          "validating and canonicalizing finite homogeneous rows exhausted "
          "memory");
    }
  }

  auto payload_digest = sha256_domain_separated(
      "mwperf.arrival.portable_payload", product.canonical_law_data);
  if (!payload_digest) {
    return Result<CompiledArrivalLaw>::failure(payload_digest.error());
  }
  PortableArrivalLawDescriptor descriptor{
      product.portable_schema, 1U, product.canonical_law_data,
      payload_digest.value()};

  auto view_digest = digest_builder_arrival_view_fields(
      binding, support.value(), product.capabilities, descriptor,
      product.iid_joint_table, product.moments, product.covariances,
      product.analytic_transform, product.joint_distribution,
      product.coordinate_distributions, product.replay_codec,
      product.unit_cube, product.finite_phase, product.transition_rows,
      product.stationary_phase_law);
  if (!view_digest) {
    return Result<CompiledArrivalLaw>::failure(view_digest.error());
  }

  try {
    BuilderArrivalView view(
        binding, BuilderArrivalViewDigest(view_digest.value()),
        product.capabilities, support.value(), std::move(descriptor),
        std::move(product.iid_joint_table), std::move(product.moments),
        std::move(product.covariances),
        std::move(product.analytic_transform),
        std::move(product.joint_distribution),
        std::move(product.coordinate_distributions),
        std::move(product.replay_codec), std::move(product.unit_cube),
        std::move(product.finite_phase),
        std::move(product.transition_rows),
        std::move(product.stationary_phase_law));
    auto core = std::make_shared<const CompiledArrivalLawCore>(
        CompiledArrivalLawCore{std::move(binding),
                               std::move(support.value()),
                               std::move(product.capabilities),
                               std::move(view),
                               std::move(product.payload),
                               std::move(product.runtime),
                               std::move(product.normalized_rows)});
    return Result<CompiledArrivalLaw>::success(make_law(std::move(core)));
  } catch (const std::bad_alloc&) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::resource_limit,
        "arrival_compiled_law_allocation_failure",
        "publishing the immutable compiled arrival law exhausted memory");
  }
  } catch (const std::bad_alloc&) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::resource_limit,
        "arrival_compiled_law_allocation_failure",
        "publishing the immutable compiled arrival law exhausted memory");
  } catch (const std::length_error&) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::resource_limit,
        "arrival_compiled_law_representation_failure",
        "publishing the immutable compiled arrival law exceeded a host "
        "container limit");
  } catch (const std::exception&) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_compiler_exception",
        "an arrival compiler or registered capability codec raised an "
        "unexpected exception while publishing its immutable law");
  } catch (...) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::internal, "arrival_compiler_exception",
        "an arrival compiler or registered capability codec raised a "
        "nonstandard exception while publishing its immutable law");
  }
}

}  // namespace detail

ArrivalFamily CompiledArrivalLaw::family() const noexcept {
  return std::visit([](const auto& value) { return value.family(); }, variant_);
}

ArrivalFamily ArrivalProcess::family() const noexcept {
  return std::visit([](const auto& value) { return value.family(); }, variant_);
}

const Digest256& ArrivalStreamKey::stream_identity() const noexcept {
  return rng_->stream_identity();
}

const BigNat& ArrivalStreamKey::consumed_words() const noexcept {
  return rng_->consumed_words();
}

Result<ArrivalStreamKey> make_configured_arrival_stream_key(
    const CompiledArrivalLaw& law, DeterministicRng stream) {
  if (stream.derivation_stage() != StageTag::configured_arrival) {
    return failure<ArrivalStreamKey>(
        DiagnosticCategory::input_validation,
        "arrival_stream_stage_mismatch",
        "a configured-arrival stream key must wrap a stream derived for the "
        "configured_arrival RNG stage");
  }
  try {
    auto rng = std::make_unique<DeterministicRng>(std::move(stream));
    return Result<ArrivalStreamKey>::success(ArrivalStreamKey(
        detail::ArrivalCoreAccess::law_core(law)->binding, std::move(rng)));
  } catch (const std::bad_alloc&) {
    return failure<ArrivalStreamKey>(
        DiagnosticCategory::resource_limit, "arrival_stream_key_allocation",
        "binding the configured-arrival stream exhausted memory");
  } catch (const std::exception&) {
    return failure<ArrivalStreamKey>(
        DiagnosticCategory::internal, "arrival_stream_key_invalid",
        "the supplied configured-arrival stream was not live and movable");
  }
}

ArrivalCapabilities arrival_capabilities(const CompiledArrivalLaw& law) {
  return detail::ArrivalCoreAccess::law_core(law)->capabilities;
}

QueueMask positive_arrival_support(const CompiledArrivalLaw& law) {
  return detail::ArrivalCoreAccess::law_core(law)->positive_support;
}

const ArrivalBinding& arrival_law_binding(
    const CompiledArrivalLaw& law) noexcept {
  return detail::ArrivalCoreAccess::law_core(law)->binding;
}

BuilderArrivalView builder_arrival_view(const CompiledArrivalLaw& law) {
  return detail::ArrivalCoreAccess::law_core(law)->builder_view;
}

Result<BuilderArrivalView> project_factorized_iid_builder_arrival_view(
    const BuilderArrivalView& view) {
  const auto& factorized =
      view.capabilities().exact_factorized_iid_generator;
  if (view.version() != 1U || !factorized.has_value() ||
      factorized->provision != AccessProvision::portable_only ||
      view.binding().family != ArrivalFamily::independent_marked_renewal ||
      view.configured_law().schema !=
          PortableArrivalLawSchema::independent_marked_renewal_v1 ||
      view.configured_law().version != 1U ||
      view.configured_law().canonical_data.empty()) {
    return failure<BuilderArrivalView>(
        DiagnosticCategory::unavailable,
        "arrival_compact_factorized_iid_projection_unavailable",
        "the compact IID construction projection requires the canonical "
        "portable independent-marked-renewal generator descriptor");
  }

  ArrivalCapabilities projected_capabilities = view.capabilities();
  // These two fields describe one legacy Cartesian representation.  The
  // canonical configured law and its independent-source generator capability
  // remain authoritative and all unrelated portable accessors are retained.
  projected_capabilities.exact_iid_joint_vector.reset();
  const std::optional<std::vector<ExactJointBatchMass>> no_joint_table;
  auto projected_digest = digest_builder_arrival_view_fields(
      view.binding(), view.positive_support(), projected_capabilities,
      view.configured_law(), no_joint_table, view.moments(),
      view.covariances(), view.analytic_transform(),
      view.joint_distribution(), view.coordinate_distributions(),
      view.replay_codec(), view.unit_cube(), view.finite_phase(),
      view.transition_rows(), view.stationary_phase_law());
  if (!projected_digest) {
    return Result<BuilderArrivalView>::failure(projected_digest.error());
  }

  try {
    return Result<BuilderArrivalView>::success(BuilderArrivalView(
        view.binding(), BuilderArrivalViewDigest(projected_digest.value()),
        std::move(projected_capabilities), view.positive_support(),
        view.configured_law(), std::nullopt, view.moments(),
        view.covariances(), view.analytic_transform(),
        view.joint_distribution(), view.coordinate_distributions(),
        view.replay_codec(), view.unit_cube(), view.finite_phase(),
        view.transition_rows(), view.stationary_phase_law()));
  } catch (const std::bad_alloc&) {
    return failure<BuilderArrivalView>(
        DiagnosticCategory::resource_limit,
        "arrival_compact_factorized_iid_projection_allocation",
        "constructing the compact factorized-IID arrival view exhausted "
        "memory");
  } catch (const std::length_error&) {
    return failure<BuilderArrivalView>(
        DiagnosticCategory::resource_limit,
        "arrival_compact_factorized_iid_projection_representation",
        "the compact factorized-IID arrival view exceeded a host container "
        "limit");
  }
}

Result<ArrivalProcess> instantiate_arrival_process(
    const CompiledArrivalLaw& law, const ArrivalInitialState& initial_state,
    ArrivalStreamKey stream_key) {
  const auto law_core = detail::ArrivalCoreAccess::law_core(law);
  if (!(stream_key.binding_ == law_core->binding)) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::input_validation, "arrival_stream_binding_mismatch",
        "the supplied configured-arrival stream key is bound to another law "
        "or queue catalog");
  }
  if (!stream_key.rng_) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::input_validation, "arrival_stream_key_consumed",
        "the configured-arrival stream key has already been moved");
  }
  if (!law_core->runtime.validate_initial || !law_core->runtime.instantiate ||
      !law_core->runtime.encode_phase || !law_core->runtime.propose) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::unavailable, "arrival_sequential_sampler_unavailable",
        "the compiled arrival law does not advertise a sequential sampler");
  }
  try {
    auto valid =
        law_core->runtime.validate_initial(law_core->payload, initial_state);
    if (!valid) {
      return Result<ArrivalProcess>::failure(valid.error());
    }
    auto owner = std::make_shared<const detail::CursorOwnerToken>();
    BigNat initial_slot(0U);
    RngTransaction transaction(*stream_key.rng_);
    auto initialized = law_core->runtime.instantiate(
        law_core->payload, initial_state, *stream_key.rng_);
    if (!initialized) {
      return Result<ArrivalProcess>::failure(initialized.error());
    }
    if (!initialized.value().state) {
      return failure<ArrivalProcess>(
          DiagnosticCategory::internal, "arrival_initial_cursor_missing",
          "the family initializer returned no explicit cursor state");
    }
    auto identity =
        realization_digest(*law_core, *stream_key.rng_, initial_state);
    if (!identity) {
      return Result<ArrivalProcess>::failure(identity.error());
    }
    // Keep ownership of the pinned RNG in stream_key until every allocation
    // and result construction has succeeded.  Moving it into a potentially
    // throwing make_shared call could destroy the RNG before RngTransaction
    // had a chance to roll it back during stack unwinding.
    auto core = std::make_shared<detail::ArrivalProcessCore>(
        law_core, std::unique_ptr<DeterministicRng>{},
        initialized.value().state, std::move(initial_slot), std::move(owner),
        identity.value());
    ArrivalProcess process = detail::ArrivalCoreAccess::make_process(
        law_core->binding.family, std::move(core));
    Result<ArrivalProcess> result =
        Result<ArrivalProcess>::success(std::move(process));
    const auto result_core =
        detail::ArrivalCoreAccess::process_core(result.value());
    result_core->rng = std::move(stream_key.rng_);
    transaction.commit();
    return result;
  } catch (const std::bad_alloc&) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::resource_limit,
        "arrival_process_allocation_failure",
        "arrival process instantiation exhausted memory");
  } catch (const std::exception&) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::internal, "arrival_process_initialization_failure",
        "arrival process initialization violated its exact cursor contract");
  } catch (...) {
    return failure<ArrivalProcess>(
        DiagnosticCategory::internal, "arrival_process_initialization_failure",
        "arrival process initialization raised a nonstandard exception");
  }
}

Result<ArrivalStep> next_arrival_step(ArrivalProcess& process,
                                      const BigNat& authored_slot) {
  const auto core = detail::ArrivalCoreAccess::process_core(process);
  if (!core) {
    return failure<ArrivalStep>(DiagnosticCategory::input_validation,
                                "arrival_process_moved_from",
                                "the arrival process has been moved from");
  }
  BusyLease lease(core->in_step);
  if (!lease.acquired()) {
    return failure<ArrivalStep>(
        DiagnosticCategory::input_validation,
        "nonsequential_arrival_access",
        "an arrival cursor cannot be mutated concurrently or reentrantly");
  }
  if (!(authored_slot == core->expected_slot)) {
    return failure<ArrivalStep>(
        DiagnosticCategory::input_validation,
        "nonsequential_arrival_access",
        "arrival slots must be requested exactly once in the sequence "
        "0,1,2,...",
        {"expected slot " + core->expected_slot.to_decimal_string() +
         "; received " + authored_slot.to_decimal_string()});
  }

  try {
    BigNat successor_slot = core->expected_slot;
    ++successor_slot;
    auto before = make_phase_snapshot(core->law, core->state,
                                      core->expected_slot, core->owner);
    if (!before) {
      return Result<ArrivalStep>::failure(before.error());
    }

    RngTransaction transaction(*core->rng);
    auto proposal = core->law->runtime.propose(
        core->law->payload, core->state, authored_slot, core->law->binding,
        *core->rng);
    if (!proposal) {
      return Result<ArrivalStep>::failure(proposal.error());
    }
    if (!proposal.value().successor_state) {
      return failure<ArrivalStep>(
          DiagnosticCategory::internal, "arrival_successor_cursor_missing",
          "the family transition returned no explicit successor cursor");
    }
    if (proposal.value().borrowed_atoms.has_value() &&
        !proposal.value().atoms.empty()) {
      return failure<ArrivalStep>(
          DiagnosticCategory::internal,
          "arrival_proposal_storage_ambiguous",
          "an arrival transition populated both owning and borrowed atom "
          "storage");
    }
    const std::span<const ArrivalAtom> proposed_atoms =
        proposal.value().borrowed_atoms.has_value()
            ? *proposal.value().borrowed_atoms
            : std::span<const ArrivalAtom>(proposal.value().atoms);
    auto batch = aggregate_arrival_batch(proposed_atoms);
    if (!batch) {
      return Result<ArrivalStep>::failure(batch.error());
    }
    batch.value() = detail::ArrivalCoreAccess::bind_empty_batch(
        std::move(batch.value()), core->law->binding);
    if (!batch.value().binding().has_value() ||
        !(*batch.value().binding() == core->law->binding)) {
      return failure<ArrivalStep>(
          DiagnosticCategory::internal, "arrival_batch_binding_mismatch",
          "a family transition emitted atoms for another compiled law");
    }
    for (const auto& entry : batch.value().entries()) {
      if (!core->law->positive_support.at(entry.queue)) {
        return failure<ArrivalStep>(
            DiagnosticCategory::internal,
            "arrival_emission_outside_positive_support",
            "a family transition emitted a queue absent from its exact "
            "positive-support mask");
      }
    }
    auto after = make_phase_snapshot(core->law,
                                     proposal.value().successor_state,
                                     successor_slot,
                                     core->owner);
    if (!after) {
      return Result<ArrivalStep>::failure(after.error());
    }
    ArrivalStep step{authored_slot,
                     std::move(batch.value()),
                     std::move(before.value()),
                     std::move(after.value()),
                     core->law->binding.law_digest,
                     core->realization_identity};
    Result<ArrivalStep> result =
        Result<ArrivalStep>::success(std::move(step));

    static_assert(std::is_nothrow_move_constructible_v<ArrivalStep>);
    static_assert(std::is_nothrow_move_constructible_v<Result<ArrivalStep>>);
    core->state.swap(proposal.value().successor_state);
    swap(core->expected_slot, successor_slot);
    transaction.commit();
    return result;
  } catch (const std::bad_alloc&) {
    return failure<ArrivalStep>(
        DiagnosticCategory::resource_limit,
        "arrival_transition_allocation_failure",
        "the arrival transition exhausted memory and was rolled back");
  } catch (const std::exception&) {
    return failure<ArrivalStep>(
        DiagnosticCategory::internal, "arrival_transition_invariant_failure",
        "the arrival transition violated its exact transactional contract and "
        "was rolled back");
  } catch (...) {
    return failure<ArrivalStep>(
        DiagnosticCategory::internal, "arrival_transition_invariant_failure",
        "the arrival transition raised a nonstandard exception and was "
        "rolled back");
  }
}

ArrivalFamily arrival_phase_family(const ArrivalPhase& phase) noexcept {
  return std::visit([](const auto& value) { return value.family(); }, phase);
}

ArrivalStateDigest arrival_phase_digest(const ArrivalPhase& phase) {
  return detail::ArrivalCoreAccess::phase_core(phase)->state_digest;
}

std::span<const std::byte> arrival_phase_canonical_state(
    const ArrivalPhase& phase) noexcept {
  return detail::ArrivalCoreAccess::phase_core(phase)->canonical_state;
}

bool arrival_phases_share_cursor(const ArrivalPhase& left,
                                 const ArrivalPhase& right) noexcept {
  const auto& left_core = detail::ArrivalCoreAccess::phase_core(left);
  const auto& right_core = detail::ArrivalCoreAccess::phase_core(right);
  return left_core->cursor_owner && right_core->cursor_owner &&
         !left_core->cursor_owner.owner_before(right_core->cursor_owner) &&
         !right_core->cursor_owner.owner_before(left_core->cursor_owner);
}

Result<BigNat> project_arrival_count(const ArrivalBatch& batch,
                                     const DenseQueueIndex queue,
                                     const ArrivalBinding& expected_binding) {
  if (queue.ordinal() >= expected_binding.queue_cardinality) {
    return failure<BigNat>(DiagnosticCategory::input_validation,
                           "arrival_projection_queue_out_of_range",
                           "the requested arrival projection queue is outside "
                           "the declared catalog");
  }
  if (!batch.binding().has_value() ||
      !(*batch.binding() == expected_binding)) {
    return failure<BigNat>(DiagnosticCategory::input_validation,
                           "arrival_projection_binding_mismatch",
                           "the joint arrival batch belongs to another law, "
                           "queue catalog, or timing convention");
  }
  const auto entries = batch.entries();
  const auto found = std::lower_bound(
      entries.begin(), entries.end(), queue.ordinal(),
      [](const ArrivalBatchEntry& entry, const std::size_t ordinal) {
        return entry.queue.ordinal() < ordinal;
      });
  if (found == entries.end() || found->queue != queue) {
    return Result<BigNat>::success(BigNat(0U));
  }
  return Result<BigNat>::success(found->count);
}

Result<InitialPhysicalLaw> compile_initial_physical_law(
    const ResolvedTransientInitialLaw& resolved,
    const CompiledArrivalLaw& arrival_law) {
  return detail::compile_initial_physical_law_impl(resolved, arrival_law);
}

Result<std::shared_ptr<const CompiledArrivalLaw>>
detail::CompiledArrivalAccess::get(const ConfiguredArrivalBinding& binding) {
  if (!binding.compiled_product_owner_ ||
      binding.compiled_product_kind_ !=
          ArrivalCompiledProductKind::compiled_arrival_law_v1) {
    return failure<std::shared_ptr<const CompiledArrivalLaw>>(
        DiagnosticCategory::input_validation,
        "arrival_compiled_product_type_mismatch",
        "the configured arrival binding does not own a C09 compiled law");
  }
  if (!binding.compiled_product_identity_.has_value()) {
    return failure<std::shared_ptr<const CompiledArrivalLaw>>(
        DiagnosticCategory::internal,
        "arrival_compiled_product_binding_mismatch",
        "the C09 compiled-law carrier has no retained product identity");
  }
  const ArrivalProductBindingIdentity& retained =
      *binding.compiled_product_identity_;
  if (retained.family != binding.identity_.arrival_family ||
      retained.timing != binding.identity_.timing ||
      retained.queue_cardinality != binding.identity_.queue_cardinality) {
    return failure<std::shared_ptr<const CompiledArrivalLaw>>(
        DiagnosticCategory::internal,
        "arrival_compiled_product_binding_mismatch",
        "the C09 compiled-law identity does not match its physical carrier");
  }
  const auto recovered = std::static_pointer_cast<const CompiledArrivalLaw>(
      binding.compiled_product_owner_);
  const ArrivalBinding& actual = arrival_law_binding(*recovered);
  if (retained.family != actual.family || retained.timing != actual.timing ||
      retained.queue_cardinality != actual.queue_cardinality ||
      retained.law_digest != actual.law_digest.value() ||
      retained.catalog_digest != actual.catalog_digest.value()) {
    return failure<std::shared_ptr<const CompiledArrivalLaw>>(
        DiagnosticCategory::internal,
        "arrival_compiled_product_binding_mismatch",
        "the recovered C09 law does not match the retained law and catalog "
        "fingerprints");
  }
  return Result<std::shared_ptr<const CompiledArrivalLaw>>::success(
      std::move(recovered));
}

Result<std::shared_ptr<const InitialPhysicalLaw>>
detail::CompiledInitialLawAccess::get(const InitialLawBinding& binding) {
  if (!binding.compiled_product_owner_ ||
      binding.compiled_product_kind_ !=
          InitialCompiledProductKind::initial_physical_law_v1) {
    return failure<std::shared_ptr<const InitialPhysicalLaw>>(
        DiagnosticCategory::input_validation,
        "initial_compiled_product_type_mismatch",
        "the initial-law binding does not own a C09 initial physical law");
  }
  if (!binding.compiled_product_identity_.has_value()) {
    return failure<std::shared_ptr<const InitialPhysicalLaw>>(
        DiagnosticCategory::internal,
        "initial_compiled_product_binding_mismatch",
        "the C09 initial-law carrier has no retained arrival identity");
  }
  const ArrivalProductBindingIdentity& retained =
      *binding.compiled_product_identity_;
  if (retained.family != binding.identity_.arrival_family ||
      retained.timing != binding.identity_.timing ||
      retained.queue_cardinality != binding.identity_.queue_cardinality) {
    return failure<std::shared_ptr<const InitialPhysicalLaw>>(
        DiagnosticCategory::internal,
        "initial_compiled_product_binding_mismatch",
        "the C09 initial-law identity does not match its physical carrier");
  }
  const auto recovered = std::static_pointer_cast<const InitialPhysicalLaw>(
      binding.compiled_product_owner_);
  const ArrivalBinding& actual = recovered->arrival_binding();
  if (retained.family != actual.family || retained.timing != actual.timing ||
      retained.queue_cardinality != actual.queue_cardinality ||
      retained.law_digest != actual.law_digest.value() ||
      retained.catalog_digest != actual.catalog_digest.value()) {
    return failure<std::shared_ptr<const InitialPhysicalLaw>>(
        DiagnosticCategory::internal,
        "initial_compiled_product_binding_mismatch",
        "the recovered C09 initial law does not match the retained law and "
        "catalog fingerprints");
  }
  return Result<std::shared_ptr<const InitialPhysicalLaw>>::success(
      std::move(recovered));
}

#if defined(MWPERF_C09_TEST_SEAMS)
Result<std::shared_ptr<const CompiledArrivalLaw>>
detail::CompiledArrivalAccess::recover_for_testing(
    PhysicalBindingIdentity physical_identity,
    ArrivalProductBindingIdentity product_identity,
    std::shared_ptr<const CompiledArrivalLaw> owner) {
  ConfiguredArrivalBinding carrier(
      std::move(physical_identity), {}, std::move(owner),
      ArrivalCompiledProductKind::compiled_arrival_law_v1,
      std::move(product_identity));
  return get(carrier);
}

Result<std::shared_ptr<const InitialPhysicalLaw>>
detail::CompiledInitialLawAccess::recover_for_testing(
    PhysicalBindingIdentity physical_identity,
    ArrivalProductBindingIdentity product_identity,
    ResolvedTransientInitialLaw resolved,
    std::shared_ptr<const InitialPhysicalLaw> owner) {
  InitialLawBinding carrier(
      std::move(physical_identity), std::move(resolved), std::move(owner),
      InitialCompiledProductKind::initial_physical_law_v1,
      std::move(product_identity));
  return get(carrier);
}
#endif

const Digest256& BuilderArrivalStreamKey::stream_identity() const noexcept {
  return rng_->stream_identity();
}

Result<BuilderArrivalStreamKey> make_builder_arrival_stream_key(
    const CompiledArrivalLaw& law, const StageTag construction_stage,
    DeterministicRng stream) {
  if (!is_construction_stage(construction_stage)) {
    return failure<BuilderArrivalStreamKey>(
        DiagnosticCategory::input_validation,
        "arrival_builder_stream_stage_mismatch",
        "a builder arrival stream must use one of the four declared "
        "surrogate-build RNG stages");
  }
  if (stream.derivation_stage() != construction_stage) {
    return failure<BuilderArrivalStreamKey>(
        DiagnosticCategory::input_validation,
        "arrival_builder_stream_stage_mismatch",
        "the supplied builder RNG was derived for a different stage than "
        "the requested construction stream key");
  }
  try {
    auto rng = std::make_unique<DeterministicRng>(std::move(stream));
    return Result<BuilderArrivalStreamKey>::success(BuilderArrivalStreamKey(
        detail::ArrivalCoreAccess::law_core(law)->binding,
        construction_stage, std::move(rng)));
  } catch (const std::bad_alloc&) {
    return failure<BuilderArrivalStreamKey>(
        DiagnosticCategory::resource_limit,
        "arrival_builder_stream_allocation",
        "binding the builder arrival stream exhausted memory");
  } catch (const std::exception&) {
    return failure<BuilderArrivalStreamKey>(
        DiagnosticCategory::internal, "arrival_builder_stream_invalid",
        "the supplied builder stream was not live and movable");
  }
}

const BuilderArrivalViewDigest& BuilderArrivalServices::view_digest()
    const noexcept {
  return core_->view_digest;
}

bool BuilderArrivalServices::has_replay() const noexcept {
  return core_ && core_->replay_available;
}

bool BuilderArrivalServices::has_unit_cube() const noexcept {
  return core_ && core_->unit_cube_available;
}

std::optional<AdjacentReplayService>
BuilderArrivalServices::replay_service() const noexcept {
  if (!has_replay()) {
    return std::nullopt;
  }
  return AdjacentReplayService(core_);
}

std::optional<UnitCubeArrivalService>
BuilderArrivalServices::unit_cube_service() const noexcept {
  if (!has_unit_cube()) {
    return std::nullopt;
  }
  return UnitCubeArrivalService(core_);
}

Result<AdjacentReplayResult> AdjacentReplayService::replay(
    AdjacentReplayRequest request) const {
  return BuilderArrivalServices(core_).replay_adjacent(std::move(request));
}

Result<JointArrivalTransition> UnitCubeArrivalService::evaluate(
    const UnitCubeRequest& request) const {
  return BuilderArrivalServices(core_).evaluate_unit_cube(request);
}

Result<BuilderArrivalServices> make_builder_arrival_services(
    const CompiledArrivalLaw& law, const BuilderArrivalView& view) {
  const auto law_core = detail::ArrivalCoreAccess::law_core(law);
  if (!(view.binding() == law_core->binding) ||
      !(view.digest() == law_core->builder_view.digest())) {
    return failure<BuilderArrivalServices>(
        DiagnosticCategory::input_validation, "arrival_view_binding_mismatch",
        "builder arrival services cannot bind a view from another law, queue "
        "catalog, or timing convention");
  }
  try {
    auto core = std::make_shared<const detail::BuilderArrivalServicesCore>(
        detail::BuilderArrivalServicesCore{
            law_core,
            view.digest(),
            view.capabilities().adjacent_batch_replay.has_value() &&
                has_process_local_access(
                    view.capabilities().adjacent_batch_replay->provision),
            view.capabilities().unit_cube_transform.has_value() &&
                has_process_local_access(
                    view.capabilities().unit_cube_transform->provision)});
    return Result<BuilderArrivalServices>::success(
        BuilderArrivalServices(std::move(core)));
  } catch (const std::bad_alloc&) {
    return failure<BuilderArrivalServices>(
        DiagnosticCategory::resource_limit,
        "arrival_builder_services_allocation",
        "constructing builder arrival services exhausted memory");
  }
}

Result<AdjacentReplayResult> BuilderArrivalServices::replay_adjacent(
    AdjacentReplayRequest request) const {
  if (!core_ || !core_->replay_available) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::unavailable, "arrival_replay_unavailable",
        "the compiled arrival law does not advertise adjacent-batch replay");
  }
  if (!(request.view_digest == core_->view_digest) ||
      !(request.stream.binding_ == core_->law->binding)) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::input_validation, "arrival_view_binding_mismatch",
        "the replay request, stream, and construction view are not bound to "
        "the same arrival law");
  }
  if (request.replay_identity.empty()) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::input_validation, "arrival_replay_identity_empty",
        "an adjacent replay requires a named replay/probe identity");
  }
  auto length = checked_index(
      request.length, std::numeric_limits<std::size_t>::max());
  if (!length) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::resource_limit, "arrival_replay_length_too_large",
        "the requested adjacent replay cannot be represented by this process");
  }
  if (!request.stream.rng_) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::input_validation,
        "arrival_builder_stream_consumed",
        "the builder stream has already been moved");
  }

  try {
    const BigNat words_before = request.stream.rng_->consumed_words();
    const ReplayCapability& capability =
        *core_->law->capabilities.adjacent_batch_replay;
    std::optional<ArrivalProcess> process;

    if (const auto* explicit_initial =
            std::get_if<ExplicitReplayInitialState>(
                &request.initialization)) {
      if (!capability.explicit_initial_state) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::unavailable,
            "arrival_replay_initialization_unsupported",
            "this compiled law does not advertise explicit initial-state "
            "replay");
      }
      if (!request.authored_start_slot.is_zero()) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::input_validation,
            "arrival_replay_start_state_mismatch",
            "an explicit configured initial state is valid only at authored "
            "start slot zero");
      }
      ArrivalStreamKey configured(core_->law->binding,
                                  std::move(request.stream.rng_));
      auto initialized = instantiate_arrival_process(
          detail::ArrivalCoreAccess::make_law(core_->law),
          explicit_initial->value, std::move(configured));
      if (!initialized) {
        return Result<AdjacentReplayResult>::failure(initialized.error());
      }
      process.emplace(std::move(initialized).value());
    } else if (const auto* explicit_phase =
                   std::get_if<ExplicitReplayPhase>(
                       &request.initialization)) {
      if (!capability.explicit_phase) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::unavailable,
            "arrival_replay_initialization_unsupported",
            "this compiled law does not advertise explicit predictive-phase "
            "replay");
      }
      const auto& phase_core =
          detail::ArrivalCoreAccess::phase_core(explicit_phase->value);
      if (!phase_core || !(phase_core->binding == core_->law->binding)) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::input_validation,
            "arrival_replay_phase_binding_mismatch",
            "the explicit replay phase belongs to another arrival law");
      }
      if (!(phase_core->next_authored_slot ==
            request.authored_start_slot)) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::input_validation,
            "arrival_replay_phase_slot_mismatch",
            "the explicit replay phase is not positioned at the requested "
            "authored start slot");
      }
      auto initialized = make_process_from_phase_state(
          core_->law, phase_core->cursor_state,
          phase_core->canonical_state, request.authored_start_slot,
          std::move(request.stream.rng_));
      if (!initialized) {
        return Result<AdjacentReplayResult>::failure(initialized.error());
      }
      process.emplace(std::move(initialized).value());
    } else if (const auto* initial_law =
                   std::get_if<NormalizedReplayInitialLaw>(
                       &request.initialization)) {
      if (!capability.normalized_initial_law) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::unavailable,
            "arrival_replay_initialization_unsupported",
            "this compiled law does not advertise normalized initial-law "
            "replay");
      }
      if (!request.authored_start_slot.is_zero()) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::input_validation,
            "arrival_replay_start_state_mismatch",
            "a normalized configured initial law is valid only at authored "
            "start slot zero");
      }
      if (initial_law->states.empty() ||
          initial_law->states.size() != initial_law->probabilities.size()) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::input_validation,
            "arrival_replay_initial_law_dimension_mismatch",
            "the normalized replay initial law has inconsistent state and "
            "probability dimensions");
      }
      auto valid_pmf = revalidate_normalized_pmf(
          initial_law->probabilities, physical_pmf_tolerance());
      if (!valid_pmf) {
        return Result<AdjacentReplayResult>::failure(valid_pmf.error());
      }
      for (const ArrivalInitialState& state : initial_law->states) {
        if (!detail::initial_law_detail::initial_state_matches_family(
                core_->law->binding.family, state)) {
          return failure<AdjacentReplayResult>(
              DiagnosticCategory::input_validation,
              "arrival_initial_state_family_mismatch",
              "the normalized replay law contains a state for another "
              "arrival family");
        }
        auto valid = core_->law->runtime.validate_initial(core_->law->payload,
                                                          state);
        if (!valid) {
          return Result<AdjacentReplayResult>::failure(valid.error());
        }
      }
      const std::size_t selected = sample_categorical(
          initial_law->probabilities, *request.stream.rng_);
      ArrivalStreamKey configured(core_->law->binding,
                                  std::move(request.stream.rng_));
      auto initialized = instantiate_arrival_process(
          detail::ArrivalCoreAccess::make_law(core_->law),
          initial_law->states[selected], std::move(configured));
      if (!initialized) {
        return Result<AdjacentReplayResult>::failure(initialized.error());
      }
      process.emplace(std::move(initialized).value());
    } else {
      const auto& stationary_request =
          std::get<NamedStationaryPhaseLaw>(request.initialization);
      if (!capability.named_stationary_initialization ||
          core_->law->capabilities.stationary_phase_law ==
              StationaryPhaseLawStatus::unavailable ||
          !core_->law->builder_view.stationary_phase_law().has_value()) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::unavailable,
            "arrival_stationary_replay_unsupported",
            "stationary replay was requested without a supplied and "
            "advertised stationary phase law");
      }
      const StationaryPhaseLawDescriptor& stationary =
          *core_->law->builder_view.stationary_phase_law();
      if (stationary_request.law_id != stationary.law_id) {
        return failure<AdjacentReplayResult>(
            DiagnosticCategory::input_validation,
            "arrival_stationary_replay_law_mismatch",
            "the named stationary replay law does not match the compiled "
            "arrival phase law");
      }
      const std::size_t selected = sample_categorical(
          stationary.probabilities, *request.stream.rng_);
      auto state = decode_canonical_phase(
          core_->law, stationary.canonical_states[selected]);
      if (!state) {
        return Result<AdjacentReplayResult>::failure(state.error());
      }
      auto initialized = make_process_from_phase_state(
          core_->law, std::move(state).value(),
          stationary.canonical_states[selected], request.authored_start_slot,
          std::move(request.stream.rng_));
      if (!initialized) {
        return Result<AdjacentReplayResult>::failure(initialized.error());
      }
      process.emplace(std::move(initialized).value());
    }

    std::vector<ArrivalStep> steps;
    steps.reserve(length.value());
    BigNat slot = request.authored_start_slot;
    for (std::size_t index = 0U; index < length.value(); ++index) {
      auto step = next_arrival_step(*process, slot);
      if (!step) {
        return Result<AdjacentReplayResult>::failure(step.error());
      }
      steps.push_back(std::move(step.value()));
      ++slot;
    }
    const auto process_core =
        detail::ArrivalCoreAccess::process_core(*process);
    auto words = checked_subtract(process_core->rng->consumed_words(),
                                  words_before);
    if (!words) {
      return failure<AdjacentReplayResult>(
          DiagnosticCategory::internal,
          "arrival_replay_draw_accounting_underflow",
          "builder replay RNG accounting moved backwards");
    }
    AdjacentReplayResult result{core_->view_digest,
                                std::move(request.replay_identity),
                                std::move(steps),
                                ReplayContextStatus::ordered_dependent_contexts,
                                GeneratorDrawAccounting{request.length,
                                                        std::move(words.value())}};
    return Result<AdjacentReplayResult>::success(std::move(result));
  } catch (const std::bad_alloc&) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::resource_limit,
        "arrival_replay_allocation_failure",
        "the adjacent builder replay exhausted memory");
  } catch (const std::exception&) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::internal,
        "arrival_replay_invariant_failure",
        "the adjacent builder replay violated its exact cursor contract");
  } catch (...) {
    return failure<AdjacentReplayResult>(
        DiagnosticCategory::internal,
        "arrival_replay_unknown_failure",
        "the adjacent builder replay raised an unknown implementation "
        "failure");
  }
}

Result<JointArrivalTransition> BuilderArrivalServices::evaluate_unit_cube(
    const UnitCubeRequest& request) const {
  try {
  if (!core_ || !core_->unit_cube_available ||
      !core_->law->runtime.unit_cube) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::unavailable, "arrival_unit_cube_unavailable",
        "the compiled arrival law does not advertise a unit-cube transform");
  }
  if (!(request.view_digest == core_->view_digest)) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::input_validation, "arrival_view_binding_mismatch",
        "the unit-cube request is bound to another construction view");
  }
  const auto& capability = *core_->law->capabilities.unit_cube_transform;
  auto dimension = checked_index(
      capability.dimension, std::numeric_limits<std::size_t>::max());
  if (!dimension || dimension.value() != request.coordinates.size()) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::input_validation,
        "arrival_unit_cube_dimension_mismatch",
        "the unit-cube coordinate vector has the wrong exact dimension");
  }
  for (const auto& coordinate : request.coordinates) {
    if (!coordinate.is_nonnegative() || !(coordinate < ExactRational::one())) {
      return failure<JointArrivalTransition>(
          DiagnosticCategory::input_validation,
          "arrival_unit_cube_point_out_of_domain",
          "every unit-cube coordinate must lie in the half-open interval "
          "[0,1)");
    }
  }
  if (capability.phase_requirement ==
          PhaseArgumentRequirement::explicit_phase_required &&
      !request.phase.has_value()) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::input_validation,
        "arrival_unit_cube_phase_required",
        "this unit-cube transform requires an explicit predictive phase");
  }
  if (capability.phase_requirement == PhaseArgumentRequirement::phase_free &&
      request.phase.has_value()) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::input_validation,
        "arrival_unit_cube_phase_unexpected",
        "a phase-free unit-cube transform must not receive a predictive "
        "phase");
  }
  if (request.phase.has_value()) {
    const auto& phase_core =
        detail::ArrivalCoreAccess::phase_core(*request.phase);
    if (!phase_core || !(phase_core->binding == core_->law->binding)) {
      return failure<JointArrivalTransition>(
          DiagnosticCategory::input_validation,
          "arrival_unit_cube_phase_binding_mismatch",
          "the supplied unit-cube phase belongs to another arrival law");
    }
    if (!(phase_core->next_authored_slot == request.authored_slot)) {
      return failure<JointArrivalTransition>(
          DiagnosticCategory::input_validation,
          "arrival_unit_cube_phase_slot_mismatch",
          "the supplied predictive phase is not positioned at the requested "
          "authored slot");
    }
  }

  auto proposal = core_->law->runtime.unit_cube(
      core_->law->payload, request.authored_slot, request.phase,
      request.coordinates, core_->law->binding);
  if (!proposal) {
    return Result<JointArrivalTransition>::failure(proposal.error());
  }
  if (request.phase.has_value() &&
      !std::ranges::equal(
          proposal.value().phase_before,
          detail::ArrivalCoreAccess::phase_core(*request.phase)
              ->canonical_state)) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::internal,
        "arrival_unit_cube_before_phase_mismatch",
        "the unit-cube evaluator changed the supplied predictive phase "
        "before applying the joint transform");
  }
  auto before_cursor = decode_canonical_phase(
      core_->law, proposal.value().phase_before);
  if (!before_cursor) {
    return Result<JointArrivalTransition>::failure(before_cursor.error());
  }
  auto after_cursor = decode_canonical_phase(
      core_->law, proposal.value().phase_after);
  if (!after_cursor) {
    return Result<JointArrivalTransition>::failure(after_cursor.error());
  }
  auto batch = aggregate_arrival_batch(proposal.value().atoms);
  if (!batch) {
    return Result<JointArrivalTransition>::failure(batch.error());
  }
  batch.value() = detail::ArrivalCoreAccess::bind_empty_batch(
      std::move(batch.value()), core_->law->binding);
  if (!batch.value().binding().has_value() ||
      !(*batch.value().binding() == core_->law->binding)) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::internal, "arrival_batch_binding_mismatch",
        "the unit-cube evaluator emitted atoms for another compiled law");
  }
  for (const auto& entry : batch.value().entries()) {
    if (!core_->law->positive_support.at(entry.queue)) {
      return failure<JointArrivalTransition>(
          DiagnosticCategory::internal,
          "arrival_emission_outside_positive_support",
          "the unit-cube evaluator emitted a queue absent from exact support");
    }
  }
  BigNat successor_slot = request.authored_slot;
  ++successor_slot;
  const auto owner = std::make_shared<const detail::CursorOwnerToken>();
  auto before = make_phase_snapshot(core_->law, before_cursor.value(),
                                    request.authored_slot, owner);
  if (!before) {
    return Result<JointArrivalTransition>::failure(before.error());
  }
  auto after = make_phase_snapshot(core_->law, after_cursor.value(),
                                   successor_slot, owner);
  if (!after) {
    return Result<JointArrivalTransition>::failure(after.error());
  }
  JointArrivalTransition transition{
      core_->view_digest,
      request.authored_slot,
      std::move(batch.value()),
      std::move(before).value(),
      std::move(after).value()};
  return Result<JointArrivalTransition>::success(std::move(transition));
  } catch (const std::bad_alloc&) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::resource_limit,
        "arrival_unit_cube_allocation_failure",
        "the unit-cube transition exhausted memory");
  } catch (const std::length_error&) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::resource_limit,
        "arrival_unit_cube_representation_failure",
        "the unit-cube transition exceeded a host container limit");
  } catch (const std::exception&) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::internal,
        "arrival_unit_cube_invariant_failure",
        "the unit-cube evaluator violated its exact transition contract");
  } catch (...) {
    return failure<JointArrivalTransition>(
        DiagnosticCategory::internal,
        "arrival_unit_cube_unknown_failure",
        "the unit-cube evaluator raised a nonstandard implementation "
        "exception");
  }
}

#if defined(MWPERF_C09_TEST_SEAMS)
namespace {

struct C09FixturePayload final {
  NormalizedPmf outcome_pmf;
  ExactRational first_outcome_mass;
  ExactRational second_outcome_mass;
  DenseQueueIndex first;
  DenseQueueIndex second;
  testing::FixtureFailureMode failure_mode;
  testing::FixtureConstructionProfile construction_profile;
  bool reverse_exact_row_for_testing;
  bool absorbing_phase_rows;
  bool phase_selective_transient_rows;
};

struct C09FixtureCursor final {
  std::uint8_t phase;
};

[[nodiscard]] Result<std::vector<ArrivalAtom>> fixture_atoms(
    const C09FixturePayload& fixture, const std::size_t outcome,
    const ArrivalBinding& binding) {
  std::vector<ArrivalAtom> atoms;
  try {
    if (fixture.failure_mode ==
        testing::FixtureFailureMode::overflow_after_draw) {
      auto maximum = ArrivalAtom::make(
          fixture.first,
          BigNat(static_cast<std::uint64_t>(
              std::numeric_limits<std::int64_t>::max())),
          binding);
      auto one = ArrivalAtom::make(fixture.first, BigNat(1U), binding);
      if (!maximum || !one) {
        return Result<std::vector<ArrivalAtom>>::failure(
            !maximum ? maximum.error() : one.error());
      }
      atoms.push_back(std::move(maximum.value()));
      atoms.push_back(std::move(one.value()));
      return Result<std::vector<ArrivalAtom>>::success(std::move(atoms));
    }
    if (fixture.phase_selective_transient_rows) {
      const DenseQueueIndex queue =
          outcome == 0U ? fixture.first : fixture.second;
      auto atom = ArrivalAtom::make(queue, BigNat{1U}, binding);
      if (!atom) {
        return Result<std::vector<ArrivalAtom>>::failure(atom.error());
      }
      atoms.push_back(std::move(atom).value());
      return Result<std::vector<ArrivalAtom>>::success(std::move(atoms));
    }
    if (fixture.construction_profile ==
            testing::FixtureConstructionProfile::
                portable_iid_bernoulli_joint_table ||
        fixture.construction_profile ==
            testing::FixtureConstructionProfile::
                portable_iid_batch_joint_table) {
      const bool first_outcome = outcome == 0U;
      const DenseQueueIndex queue =
          first_outcome ? fixture.second : fixture.first;
      const std::uint64_t count =
          !first_outcome &&
                  fixture.construction_profile ==
                      testing::FixtureConstructionProfile::
                          portable_iid_batch_joint_table
              ? 2U
              : 1U;
      auto atom = ArrivalAtom::make(queue, BigNat(count), binding);
      if (!atom) {
        return Result<std::vector<ArrivalAtom>>::failure(atom.error());
      }
      atoms.push_back(std::move(atom).value());
      return Result<std::vector<ArrivalAtom>>::success(std::move(atoms));
    }
    const std::uint64_t first_count = outcome == 0U ? 1U : 3U;
    const std::uint64_t second_count = outcome == 0U ? 4U : 2U;
    auto first =
        ArrivalAtom::make(fixture.first, BigNat(first_count), binding);
    auto second =
        ArrivalAtom::make(fixture.second, BigNat(second_count), binding);
    if (!first || !second) {
      return Result<std::vector<ArrivalAtom>>::failure(
          !first ? first.error() : second.error());
    }
    atoms.push_back(std::move(first.value()));
    atoms.push_back(std::move(second.value()));
    return Result<std::vector<ArrivalAtom>>::success(std::move(atoms));
  } catch (const std::bad_alloc&) {
    return failure<std::vector<ArrivalAtom>>(
        DiagnosticCategory::resource_limit,
        "arrival_fixture_atom_allocation_failure",
        "the private C09 fixture exhausted memory");
  }
}

[[nodiscard]] Result<NormalizedPmf> fixture_pmf(
    const ExactRational& first_mass,
    const ExactRational& second_mass) {
  auto first = AuthoredProbability::from_exact(first_mass);
  auto second = AuthoredProbability::from_exact(second_mass);
  if (!first || !second) {
    return Result<NormalizedPmf>::failure(!first ? first.error()
                                                : second.error());
  }
  const std::array<AuthoredProbability, 2U> values{first.value(),
                                                  second.value()};
  return validate_and_normalize_pmf(values, physical_pmf_tolerance());
}

}  // namespace

namespace testing {

namespace {

Result<CompiledArrivalLaw> make_c09_correlated_fixture_law_impl(
    const QueueCatalog& queues,
    const ExactRational& first_outcome_mass,
    const ExactRational& second_outcome_mass,
    const bool encode_weighted_identity,
    const FixtureFailureMode failure_mode,
    const FixtureConstructionProfile construction_profile,
    const bool advertise_time_homogeneous,
    const bool reverse_exact_row_for_testing,
    const bool absorbing_phase_rows,
    const bool phase_selective_transient_rows,
    const ExactRational& phase_zero_stationary_mass,
    const ExactRational& phase_one_stationary_mass) {
  if (!first_outcome_mass.is_positive() ||
      !second_outcome_mass.is_positive() ||
      !(first_outcome_mass + second_outcome_mass ==
        ExactRational::one())) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::input_validation,
        "arrival_fixture_invalid_transition_masses",
        "the weighted correlated fixture requires two strictly positive "
        "exact transition masses summing to one");
  }
  if (!phase_zero_stationary_mass.is_nonnegative() ||
      !phase_one_stationary_mass.is_nonnegative() ||
      !(phase_zero_stationary_mass + phase_one_stationary_mass ==
        ExactRational::one())) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::input_validation,
        "arrival_fixture_invalid_stationary_phase_mixture",
        "the absorbing two-phase fixture requires two nonnegative exact "
        "stationary phase masses summing to one");
  }
  if (queues.size() < 2U) {
    return failure<CompiledArrivalLaw>(
        DiagnosticCategory::input_validation,
        "arrival_fixture_requires_two_queues",
        "the private correlated C09 fixture requires at least two queues");
  }
  auto first = queues.index_at(0U);
  auto second = queues.index_at(1U);
  auto pmf = fixture_pmf(first_outcome_mass, second_outcome_mass);
  auto stationary_phase_pmf = fixture_pmf(
      phase_zero_stationary_mass, phase_one_stationary_mass);
  if (!first || !second || !pmf || !stationary_phase_pmf) {
    if (!first) {
      return Result<CompiledArrivalLaw>::failure(first.error());
    }
    if (!second) {
      return Result<CompiledArrivalLaw>::failure(second.error());
    }
    if (!pmf) {
      return Result<CompiledArrivalLaw>::failure(pmf.error());
    }
    if (!stationary_phase_pmf) {
      return Result<CompiledArrivalLaw>::failure(
          stationary_phase_pmf.error());
    }
  }

  auto payload = std::make_shared<const C09FixturePayload>(C09FixturePayload{
      pmf.value(), first_outcome_mass, second_outcome_mass,
      first.value(), second.value(), failure_mode, construction_profile,
      reverse_exact_row_for_testing, absorbing_phase_rows,
      phase_selective_transient_rows});
  detail::ArrivalRuntimeAdapter runtime;
  runtime.validate_initial =
      [](const std::shared_ptr<const void>& erased,
         const ArrivalInitialState& state) -> Result<void> {
    const auto fixture =
        std::static_pointer_cast<const C09FixturePayload>(erased);
    if (fixture->failure_mode ==
        FixtureFailureMode::throwing_initial_validator) {
      throw std::runtime_error("private fixture initial validator failure");
    }
    const auto* shared = std::get_if<SharedRoundState>(&state);
    if (shared == nullptr) {
      return failure<void>(DiagnosticCategory::input_validation,
                           "arrival_initial_family_mismatch",
                           "the shared-round fixture requires a shared-round "
                           "initial state");
    }
    if (shared->state != "h0" && shared->state != "h1") {
      return failure<void>(DiagnosticCategory::input_validation,
                           "arrival_initial_state_unreachable",
                           "the shared-round fixture state must be h0 or h1");
    }
    return Result<void>::success();
  };
  runtime.instantiate =
      [](const std::shared_ptr<const void>&,
         const ArrivalInitialState& state,
         DeterministicRng&) -> Result<detail::ArrivalCursorInitialization> {
    const auto& shared = std::get<SharedRoundState>(state);
    try {
      auto cursor = std::make_shared<const C09FixtureCursor>(
          C09FixtureCursor{static_cast<std::uint8_t>(shared.state == "h1")});
      return Result<detail::ArrivalCursorInitialization>::success(
          detail::ArrivalCursorInitialization{std::move(cursor)});
    } catch (const std::bad_alloc&) {
      return failure<detail::ArrivalCursorInitialization>(
          DiagnosticCategory::resource_limit,
          "arrival_fixture_cursor_allocation_failure",
          "the private C09 fixture cursor exhausted memory");
    }
  };
  runtime.encode_phase =
      [](const std::shared_ptr<const void>&,
         const detail::ArrivalCursorState& state)
      -> Result<std::vector<std::byte>> {
    const auto cursor = std::static_pointer_cast<const C09FixtureCursor>(state);
    return Result<std::vector<std::byte>>::success(
        std::vector<std::byte>{static_cast<std::byte>(cursor->phase)});
  };
  runtime.decode_phase =
      [](const std::shared_ptr<const void>&,
         const std::span<const std::byte> encoded)
      -> Result<detail::ArrivalCursorState> {
    if (encoded.size() != 1U ||
        (encoded[0] != std::byte{0} && encoded[0] != std::byte{1})) {
      return failure<detail::ArrivalCursorState>(
          DiagnosticCategory::input_validation,
          "arrival_phase_codec_value_invalid",
          "the private C09 fixture phase must be the canonical h0 or h1 "
          "byte");
    }
    try {
      auto cursor = std::make_shared<const C09FixtureCursor>(
          C09FixtureCursor{static_cast<std::uint8_t>(encoded[0])});
      return Result<detail::ArrivalCursorState>::success(std::move(cursor));
    } catch (const std::bad_alloc&) {
      return failure<detail::ArrivalCursorState>(
          DiagnosticCategory::resource_limit,
          "arrival_fixture_cursor_allocation_failure",
          "the private C09 fixture cursor exhausted memory");
    }
  };
  runtime.propose =
      [](const std::shared_ptr<const void>& erased,
         const detail::ArrivalCursorState& state, const BigNat&,
         const ArrivalBinding& binding,
         DeterministicRng& rng)
      -> Result<detail::ProposedArrivalTransition> {
    const auto fixture =
        std::static_pointer_cast<const C09FixturePayload>(erased);
    const auto cursor = std::static_pointer_cast<const C09FixtureCursor>(state);
    if (!fixture || !cursor) {
      return failure<detail::ProposedArrivalTransition>(
          DiagnosticCategory::internal,
          "arrival_fixture_sampler_state_missing",
          "the private C09 sampler requires its immutable law and phase");
    }
    const std::size_t outcome =
        (fixture->absorbing_phase_rows ||
         fixture->phase_selective_transient_rows)
            ? static_cast<std::size_t>(cursor->phase)
            : sample_categorical(fixture->outcome_pmf, rng);
    auto atoms = fixture_atoms(*fixture, outcome, binding);
    if (!atoms) {
      return Result<detail::ProposedArrivalTransition>::failure(atoms.error());
    }
    try {
      const std::uint8_t successor_phase =
          fixture->phase_selective_transient_rows
              ? 1U
              : static_cast<std::uint8_t>(outcome);
      auto successor = std::make_shared<const C09FixtureCursor>(
          C09FixtureCursor{successor_phase});
      return Result<detail::ProposedArrivalTransition>::success(
          detail::ProposedArrivalTransition{std::move(successor),
                                            std::move(atoms.value())});
    } catch (const std::bad_alloc&) {
      return failure<detail::ProposedArrivalTransition>(
          DiagnosticCategory::resource_limit,
          "arrival_fixture_cursor_allocation_failure",
          "the private C09 fixture cursor exhausted memory");
    }
  };
  runtime.enumerate =
      [](const std::shared_ptr<const void>& erased,
         const detail::ArrivalCursorState& state, const BigNat&,
         const ArrivalBinding& binding)
      -> Result<std::vector<detail::ExactArrivalTransitionAtom>> {
    const auto fixture =
        std::static_pointer_cast<const C09FixturePayload>(erased);
    const auto cursor = std::static_pointer_cast<const C09FixtureCursor>(state);
    if (!fixture || !cursor) {
      return failure<std::vector<detail::ExactArrivalTransitionAtom>>(
          DiagnosticCategory::internal,
          "arrival_fixture_exact_row_state_missing",
          "the private C09 exact row requires its immutable law and phase");
    }
    try {
      std::vector<detail::ExactArrivalTransitionAtom> row;
      const std::size_t first_outcome =
          (fixture->absorbing_phase_rows ||
           fixture->phase_selective_transient_rows)
              ? static_cast<std::size_t>(cursor->phase)
              : 0U;
      const std::size_t outcome_count =
          (fixture->absorbing_phase_rows ||
           fixture->phase_selective_transient_rows)
              ? 1U
              : 2U;
      row.reserve(outcome_count);
      for (std::size_t branch = 0U; branch < outcome_count; ++branch) {
        const std::size_t outcome = first_outcome + branch;
        auto atoms = fixture_atoms(*fixture, outcome, binding);
        if (!atoms) {
          return Result<std::vector<detail::ExactArrivalTransitionAtom>>::
              failure(atoms.error());
        }
        row.push_back(detail::ExactArrivalTransitionAtom{
            .atoms = std::move(atoms.value()),
            .phase_before =
                std::vector<std::byte>{static_cast<std::byte>(cursor->phase)},
            .phase_after =
                std::vector<std::byte>{static_cast<std::byte>(
                    fixture->phase_selective_transient_rows ? 1U
                                                            : outcome)},
            .mass = (fixture->absorbing_phase_rows ||
                     fixture->phase_selective_transient_rows)
                        ? ExactRational::one()
                        : (outcome == 0U ? fixture->first_outcome_mass
                                         : fixture->second_outcome_mass),
            .structural_support = true});
      }
      if (fixture->reverse_exact_row_for_testing) {
        std::reverse(row.begin(), row.end());
      }
      return Result<std::vector<detail::ExactArrivalTransitionAtom>>::success(
          std::move(row));
    } catch (const std::bad_alloc&) {
      return failure<std::vector<detail::ExactArrivalTransitionAtom>>(
          DiagnosticCategory::resource_limit,
          "arrival_fixture_exact_row_allocation_failure",
          "the private C09 exact transition row exhausted memory");
    }
  };
  if (advertise_time_homogeneous) {
    runtime.enumerate_time_homogeneous =
        [enumerate = runtime.enumerate](
            const std::shared_ptr<const void>& erased,
            const detail::ArrivalCursorState& state,
            const ArrivalBinding& binding) {
          // The dedicated finite-phase fixture's exact row is independent of
          // authored slot.  Binding it through a slot-free operation makes
          // that stronger fact structural rather than a finite probe
          // assertion.
          return enumerate(erased, state, BigNat{0U}, binding);
        };
  }
  runtime.unit_cube =
      [](const std::shared_ptr<const void>& erased, const BigNat&,
         const std::optional<ArrivalPhase>& phase,
         const std::span<const ExactRational> coordinates,
         const ArrivalBinding& binding) -> Result<detail::UnitCubeProposal> {
    const auto fixture =
        std::static_pointer_cast<const C09FixturePayload>(erased);
    if (!fixture) {
      return failure<detail::UnitCubeProposal>(
          DiagnosticCategory::internal,
          "arrival_fixture_unit_cube_law_missing",
          "the private C09 unit-cube evaluator requires its immutable law");
    }
    if (fixture->failure_mode == FixtureFailureMode::throwing_unit_cube) {
      throw std::runtime_error("private fixture unit-cube failure");
    }
    if (coordinates.size() != 1U) {
      return failure<detail::UnitCubeProposal>(
          DiagnosticCategory::input_validation,
          "arrival_unit_cube_dimension_mismatch",
          "the private C09 fixture unit cube has dimension one");
    }
    std::vector<std::byte> before{std::byte{0}};
    if (fixture->absorbing_phase_rows ||
        fixture->phase_selective_transient_rows ||
        fixture->construction_profile ==
            FixtureConstructionProfile::phase_required_unit_cube) {
      if (!phase.has_value()) {
        return failure<detail::UnitCubeProposal>(
            DiagnosticCategory::internal,
            "arrival_fixture_required_phase_missing",
            "the generic unit-cube boundary omitted a required phase");
      }
      const auto canonical = arrival_phase_canonical_state(*phase);
      before.assign(canonical.begin(), canonical.end());
    }
    if (before.size() != 1U ||
        (before[0] != std::byte{0} && before[0] != std::byte{1})) {
      return failure<detail::UnitCubeProposal>(
          DiagnosticCategory::input_validation,
          "arrival_fixture_unit_cube_phase_invalid",
          "the private C09 unit-cube phase must be canonical h0 or h1");
    }
    const std::size_t outcome =
        (fixture->absorbing_phase_rows ||
         fixture->phase_selective_transient_rows)
            ? static_cast<std::size_t>(before[0])
            : (coordinates[0] < fixture->first_outcome_mass ? 0U : 1U);
    auto atoms = fixture_atoms(*fixture, outcome, binding);
    if (!atoms) {
      return Result<detail::UnitCubeProposal>::failure(atoms.error());
    }
    return Result<detail::UnitCubeProposal>::success(
        detail::UnitCubeProposal{
            std::move(atoms.value()),
            std::move(before),
            std::vector<std::byte>{static_cast<std::byte>(
                fixture->phase_selective_transient_rows ? 1U : outcome)}});
  };
  if (construction_profile ==
      FixtureConstructionProfile::portable_only_construction_access) {
    runtime.unit_cube = {};
  }

  ArrivalCapabilities capabilities;
  capabilities.exact_positive_support = CapabilityAvailability::available;
  capabilities.sequential_normalized_sampler =
      CapabilityAvailability::available;
  capabilities.finite_enumerated_predictive_phase =
      CapabilityAvailability::available;
  capabilities.finite_enumerated_transition_row =
      CapabilityAvailability::available;
  const bool supplies_stationary_phase =
      construction_profile !=
      FixtureConstructionProfile::replay_without_stationary;
  capabilities.stationary_phase_law =
      supplies_stationary_phase ? StationaryPhaseLawStatus::supplied
                                : StationaryPhaseLawStatus::unavailable;
  capabilities.adjacent_batch_replay =
      ReplayCapability{true, true, true, supplies_stationary_phase,
                       construction_profile ==
                               FixtureConstructionProfile::
                                   portable_only_construction_access
                           ? AccessProvision::portable_only
                           : AccessProvision::process_local_only};
  const UnitCubeCapability cube_capability{
      BigNat(1U), UnitCubeBoundary::left_closed_right_open,
      InverseCdfConvention::first_cumulative_mass_strictly_greater,
      construction_profile ==
              FixtureConstructionProfile::phase_required_unit_cube
          ? PhaseArgumentRequirement::explicit_phase_required
          : PhaseArgumentRequirement::phase_free,
      construction_profile ==
              FixtureConstructionProfile::portable_only_construction_access
          ? AccessProvision::portable_only
          : AccessProvision::portable_and_process_local};
  capabilities.unit_cube_transform = cube_capability;

  std::optional<std::vector<ExactJointBatchMass>> iid_joint_table;
  std::optional<std::vector<ExactMomentDatum>> moments;
  std::optional<std::vector<ExactMomentDatum>> covariances;
  std::optional<PortableTransformDescriptor> analytic_transform;
  std::optional<PortableTransformDescriptor> joint_distribution;
  std::optional<PortableTransformDescriptor> coordinate_distributions;
  const ExactArgumentDomain unit_domain{ExactRational::zero(),
                                        ExactRational::one(), true, true};
  switch (construction_profile) {
    case FixtureConstructionProfile::baseline:
    case FixtureConstructionProfile::phase_required_unit_cube:
    case FixtureConstructionProfile::portable_only_construction_access:
    case FixtureConstructionProfile::replay_without_stationary:
    case FixtureConstructionProfile::invalid_availability_discriminant:
    case FixtureConstructionProfile::invalid_stationary_status_discriminant:
    case FixtureConstructionProfile::invalid_access_provision_discriminant:
    case FixtureConstructionProfile::invalid_transform_kind_discriminant:
    case FixtureConstructionProfile::invalid_distribution_scope_discriminant:
    case FixtureConstructionProfile::invalid_phase_requirement_discriminant:
    case FixtureConstructionProfile::invalid_cube_boundary_discriminant:
    case FixtureConstructionProfile::invalid_inverse_cdf_discriminant:
    case FixtureConstructionProfile::partial_sampler_runtime:
    case FixtureConstructionProfile::nonfinite_iid_claim:
    case FixtureConstructionProfile::iid_support_mismatch:
    case FixtureConstructionProfile::noncanonical_moment_table:
    case FixtureConstructionProfile::noncanonical_covariance_table:
    case FixtureConstructionProfile::invalid_unit_cube_coordinates:
    case FixtureConstructionProfile::incomplete_replay_codec:
    case FixtureConstructionProfile::empty_transform_domain:
    case FixtureConstructionProfile::zero_transform_codec:
    case FixtureConstructionProfile::throwing_phase_decoder:
    case FixtureConstructionProfile::support_dimension_mismatch:
    case FixtureConstructionProfile::unbounded_moment_claim:
    case FixtureConstructionProfile::phase_conditioned_moment_claim:
    case FixtureConstructionProfile::incomplete_coordinate_moment_table:
    case FixtureConstructionProfile::unit_cube_missing_phase_encoder:
    case FixtureConstructionProfile::replay_missing_sequential_sampler:
      break;
    case FixtureConstructionProfile::independent_portable_transforms: {
      capabilities.analytic_transform = TransformCapability{
          TransformKind::closed_transform, DistributionScope::joint_vector,
          unit_domain, PhaseArgumentRequirement::phase_free,
          AccessProvision::portable_only};
      capabilities.exact_joint_distribution = TransformCapability{
          TransformKind::exact_pgf, DistributionScope::joint_vector,
          unit_domain, PhaseArgumentRequirement::phase_free,
          AccessProvision::portable_only};
      capabilities.exact_coordinate_distributions = TransformCapability{
          TransformKind::exact_pmf, DistributionScope::per_coordinate,
          unit_domain, PhaseArgumentRequirement::phase_free,
          AccessProvision::portable_only};
      analytic_transform = PortableTransformDescriptor{
          *capabilities.analytic_transform, 11U,
          std::vector<std::byte>{std::byte{0xa1}}};
      joint_distribution = PortableTransformDescriptor{
          *capabilities.exact_joint_distribution, 12U,
          std::vector<std::byte>{std::byte{0xb2}}};
      coordinate_distributions = PortableTransformDescriptor{
          *capabilities.exact_coordinate_distributions, 13U,
          std::vector<std::byte>{std::byte{0xc3}}};
      break;
    }
    case FixtureConstructionProfile::portable_iid_joint_table: {
      capabilities.exact_iid_joint_vector = ExactIidJointVectorCapability{
          true, AccessProvision::portable_only};
      std::vector<BigNat> first_outcome(queues.size(), BigNat(0U));
      first_outcome[first.value().ordinal()] = BigNat(1U);
      first_outcome[second.value().ordinal()] = BigNat(4U);
      std::vector<BigNat> second_outcome(queues.size(), BigNat(0U));
      second_outcome[first.value().ordinal()] = BigNat(3U);
      second_outcome[second.value().ordinal()] = BigNat(2U);
      iid_joint_table = std::vector<ExactJointBatchMass>{
          ExactJointBatchMass{std::move(first_outcome), first_outcome_mass},
          ExactJointBatchMass{std::move(second_outcome),
                              second_outcome_mass}};
      break;
    }
    case FixtureConstructionProfile::portable_iid_bernoulli_joint_table:
    case FixtureConstructionProfile::portable_iid_batch_joint_table: {
      capabilities.exact_iid_joint_vector = ExactIidJointVectorCapability{
          true, AccessProvision::portable_only};
      std::vector<BigNat> first_outcome(queues.size(), BigNat(0U));
      first_outcome[second.value().ordinal()] = BigNat(1U);
      std::vector<BigNat> second_outcome(queues.size(), BigNat(0U));
      second_outcome[first.value().ordinal()] = BigNat(
          construction_profile ==
                  FixtureConstructionProfile::portable_iid_batch_joint_table
              ? 2U
              : 1U);
      iid_joint_table = std::vector<ExactJointBatchMass>{
          ExactJointBatchMass{std::move(first_outcome), first_outcome_mass},
          ExactJointBatchMass{std::move(second_outcome),
                              second_outcome_mass}};
      // These IID tables are also exact target-intensity carriers used by the
      // C27 stationary flow-identity tests.  Publish their first-coordinate
      // moments explicitly rather than asking C27 to infer them from a
      // differently typed IID table.  This keeps capability negotiation and
      // the later numerical identity bound on the same C09 product while
      // preserving the joint table needed by C19.
      if (construction_profile ==
              FixtureConstructionProfile::portable_iid_bernoulli_joint_table ||
          construction_profile ==
              FixtureConstructionProfile::portable_iid_batch_joint_table) {
        capabilities.exact_coordinate_moments = MomentCapability{
            BigNat(1U), false, false, AccessProvision::portable_only};
        moments.emplace();
        moments->reserve(queues.size());
        for (std::size_t ordinal = 0U; ordinal < queues.size(); ++ordinal) {
          auto coordinate = queues.index_at(ordinal);
          if (!coordinate) {
            return Result<CompiledArrivalLaw>::failure(coordinate.error());
          }
          ExactRational first_coordinate_mean = second_outcome_mass;
          if (construction_profile ==
              FixtureConstructionProfile::portable_iid_batch_joint_table) {
            first_coordinate_mean =
                first_coordinate_mean + second_outcome_mass;
          }
          const ExactRational mean = ordinal == first.value().ordinal()
                                         ? first_coordinate_mean
                                     : ordinal == second.value().ordinal()
                                         ? first_outcome_mass
                                         : ExactRational::zero();
          moments->push_back(ExactMomentDatum{
              std::vector<DenseQueueIndex>{coordinate.value()}, BigNat(1U),
              mean});
        }
      }
      break;
    }
    case FixtureConstructionProfile::portable_moments_and_covariance:
    case FixtureConstructionProfile::incomplete_covariance_table:
    case FixtureConstructionProfile::incomplete_cross_moment_table: {
      capabilities.exact_joint_moments = MomentCapability{
          BigNat(2U), true, false, AccessProvision::portable_only};
      capabilities.exact_coordinate_moments = MomentCapability{
          BigNat(2U), false, false, AccessProvision::portable_only};
      capabilities.exact_covariance = CapabilityAvailability::available;
      capabilities.exact_cross_moments = CapabilityAvailability::available;

      const ExactRational two = ExactRational::one() + ExactRational::one();
      const ExactRational three = two + ExactRational::one();
      const ExactRational five = two + three;
      const ExactRational ten = five + five;
      moments.emplace();
      covariances.emplace();
      for (std::size_t left = 0U; left < queues.size(); ++left) {
        auto left_queue = queues.index_at(left);
        if (!left_queue) {
          return Result<CompiledArrivalLaw>::failure(left_queue.error());
        }
        const ExactRational mean =
            left == 0U ? two
                       : (left == 1U ? three : ExactRational::zero());
        const ExactRational second_moment =
            left == 0U ? five
                       : (left == 1U ? ten : ExactRational::zero());
        moments->push_back(ExactMomentDatum{
            std::vector<DenseQueueIndex>{left_queue.value()}, BigNat(1U),
            mean});
        moments->push_back(ExactMomentDatum{
            std::vector<DenseQueueIndex>{left_queue.value()}, BigNat(2U),
            second_moment});
        for (std::size_t right = left + 1U; right < queues.size(); ++right) {
          auto right_queue = queues.index_at(right);
          if (!right_queue) {
            return Result<CompiledArrivalLaw>::failure(right_queue.error());
          }
          moments->push_back(ExactMomentDatum{
              std::vector<DenseQueueIndex>{left_queue.value(),
                                           right_queue.value()},
              BigNat(2U),
              left == 0U && right == 1U ? five : ExactRational::zero()});
        }
      }
      for (std::size_t left = 0U; left < queues.size(); ++left) {
        auto left_queue = queues.index_at(left);
        if (!left_queue) {
          return Result<CompiledArrivalLaw>::failure(left_queue.error());
        }
        for (std::size_t right = left; right < queues.size(); ++right) {
          auto right_queue = queues.index_at(right);
          if (!right_queue) {
            return Result<CompiledArrivalLaw>::failure(right_queue.error());
          }
          ExactRational covariance = ExactRational::zero();
          if (left == right && left < 2U) {
            covariance = ExactRational::one();
          } else if (left == 0U && right == 1U) {
            covariance = -ExactRational::one();
          }
          covariances->push_back(ExactMomentDatum{
              std::vector<DenseQueueIndex>{left_queue.value(),
                                           right_queue.value()},
              BigNat(2U), std::move(covariance)});
        }
      }
      break;
    }
    case FixtureConstructionProfile::unsupported_process_local_iid: {
      capabilities.exact_iid_joint_vector = ExactIidJointVectorCapability{
          true, AccessProvision::process_local_only};
      std::vector<BigNat> dense_counts(queues.size(), BigNat(0U));
      dense_counts[first.value().ordinal()] = BigNat(1U);
      dense_counts[second.value().ordinal()] = BigNat(4U);
      iid_joint_table = std::vector<ExactJointBatchMass>{ExactJointBatchMass{
          std::move(dense_counts), ExactRational::one()}};
      break;
    }
    case FixtureConstructionProfile::unsupported_process_local_moment:
      capabilities.analytic_moments = MomentCapability{
          BigNat(1U), true, false, AccessProvision::process_local_only};
      moments = std::vector<ExactMomentDatum>{ExactMomentDatum{
          std::vector<DenseQueueIndex>{first.value()}, BigNat(1U),
          ExactRational::one()}};
      break;
    case FixtureConstructionProfile::unsupported_process_local_transform:
      capabilities.analytic_transform = TransformCapability{
          TransformKind::closed_transform, DistributionScope::joint_vector,
          unit_domain, PhaseArgumentRequirement::phase_free,
          AccessProvision::process_local_only};
      analytic_transform = PortableTransformDescriptor{
          *capabilities.analytic_transform, 14U,
          std::vector<std::byte>{std::byte{0xd4}}};
      break;
  }

  std::vector<std::uint8_t> support(queues.size(), 0U);
  support[0U] = 1U;
  support[1U] = 1U;
  std::vector<std::byte> canonical_law_data{
      std::byte{0x43}, std::byte{0x30}, std::byte{0x39},
      static_cast<std::byte>(failure_mode),
      static_cast<std::byte>(construction_profile)};
  if (encode_weighted_identity) {
    canonical_law_data.push_back(std::byte{0x57});
    append_rational(canonical_law_data, first_outcome_mass);
    append_rational(canonical_law_data, second_outcome_mass);
  }
  if (absorbing_phase_rows) {
    canonical_law_data.push_back(std::byte{0x41});
    append_rational(canonical_law_data, phase_zero_stationary_mass);
    append_rational(canonical_law_data, phase_one_stationary_mass);
  }
  if (phase_selective_transient_rows) {
    canonical_law_data.push_back(std::byte{0x54});
  }
  detail::CompiledArrivalProduct product{
      .family = ArrivalFamily::shared_joint_round_markov_renewal,
      .normalized_rows = {},
      .positive_support = std::move(support),
      .capabilities = std::move(capabilities),
      .canonical_law_data = std::move(canonical_law_data),
      .portable_schema =
          PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1,
      .payload = std::move(payload),
      .runtime = std::move(runtime),
      .iid_joint_table = std::move(iid_joint_table),
      .moments = std::move(moments),
      .covariances = std::move(covariances),
      .analytic_transform = std::move(analytic_transform),
      .joint_distribution = std::move(joint_distribution),
      .coordinate_distributions = std::move(coordinate_distributions),
      .replay_codec =
          ReplayCodecDescriptor{1U, true, true,
                                std::vector<std::byte>{std::byte{0x01}}},
      .unit_cube =
          UnitCubeDescriptor{
              cube_capability,
              std::vector<UnitCubeCoordinate>{
                  UnitCubeCoordinate{0U, "joint_u0"}},
              1U,
              std::vector<std::byte>{std::byte{0x01}}},
      .finite_phase =
          FinitePhaseDescriptor{
              1U,
              std::vector<std::vector<std::byte>>{
                  std::vector<std::byte>{std::byte{0}},
                  std::vector<std::byte>{std::byte{1}}},
              advertise_time_homogeneous
                  ? ArrivalRowClockSemanticsV1::
                        finite_phase_time_homogeneous
                  : ArrivalRowClockSemanticsV1::authored_slot_conditioned},
      .transition_rows =
          EnumeratedTransitionRowsDescriptor{
              1U, std::vector<std::byte>{std::byte{0}, std::byte{1}}},
      .stationary_phase_law =
          supplies_stationary_phase
              ? std::optional<StationaryPhaseLawDescriptor>{
                    StationaryPhaseLawDescriptor{
                        absorbing_phase_rows
                            ? "c09_fixture_absorbing_stationary_h01"
                            : "c09_fixture_stationary_h01",
                        1U,
                        std::vector<std::vector<std::byte>>{
                            std::vector<std::byte>{std::byte{0}},
                            std::vector<std::byte>{std::byte{1}}},
                        stationary_phase_pmf.value()}}
              : std::nullopt};

  if (absorbing_phase_rows) {
    // This test-only C21 law has a separately configured stationary mixture
    // over its two absorbing predictive phases.  Its ordinary-slot target
    // intensities are therefore the exact mixture of the two deterministic
    // phase rows, not either event-entry marginal and not a sampled estimate.
    // Publishing the complete order-one coordinate table lets the real C14
    // Palm/FIFO alternative establish target intensity without changing the
    // semantics of any pre-C21 fixture law.
    product.capabilities.exact_coordinate_moments = MomentCapability{
        BigNat{1U}, false, false, AccessProvision::portable_only};
    product.moments.emplace();
    product.moments->reserve(queues.size());
    const ExactRational two = ExactRational::one() + ExactRational::one();
    const ExactRational three = two + ExactRational::one();
    const ExactRational four = two + two;
    const ExactRational first_mean =
        phase_zero_stationary_mass + phase_one_stationary_mass * three;
    const ExactRational second_mean =
        phase_zero_stationary_mass * four +
        phase_one_stationary_mass * two;
    for (std::size_t ordinal = 0U; ordinal < queues.size(); ++ordinal) {
      auto queue = queues.index_at(ordinal);
      if (!queue) {
        return Result<CompiledArrivalLaw>::failure(queue.error());
      }
      const ExactRational value =
          ordinal == first.value().ordinal()
              ? first_mean
              : (ordinal == second.value().ordinal()
                     ? second_mean
                     : ExactRational::zero());
      product.moments->push_back(ExactMomentDatum{
          std::vector<DenseQueueIndex>{queue.value()}, BigNat{1U}, value});
    }
  }

  const auto install_iid_table = [&]() {
    product.capabilities.exact_iid_joint_vector =
        ExactIidJointVectorCapability{true, AccessProvision::portable_only};
    std::vector<BigNat> first_outcome(queues.size(), BigNat(0U));
    first_outcome[first.value().ordinal()] = BigNat(1U);
    first_outcome[second.value().ordinal()] = BigNat(4U);
    std::vector<BigNat> second_outcome(queues.size(), BigNat(0U));
    second_outcome[first.value().ordinal()] = BigNat(3U);
    second_outcome[second.value().ordinal()] = BigNat(2U);
    product.iid_joint_table = std::vector<ExactJointBatchMass>{
        ExactJointBatchMass{std::move(first_outcome), first_outcome_mass},
        ExactJointBatchMass{std::move(second_outcome), second_outcome_mass}};
  };
  const auto install_analytic_transform = [&]() {
    const TransformCapability capability{
        TransformKind::closed_transform, DistributionScope::joint_vector,
        ExactArgumentDomain{ExactRational::zero(), ExactRational::one(), true,
                            true},
        PhaseArgumentRequirement::phase_free, AccessProvision::portable_only};
    product.capabilities.analytic_transform = capability;
    product.analytic_transform = PortableTransformDescriptor{
        capability, 1U, std::vector<std::byte>{std::byte{0x7f}}};
  };

  switch (construction_profile) {
    case FixtureConstructionProfile::invalid_availability_discriminant:
      product.capabilities.exact_covariance =
          static_cast<CapabilityAvailability>(0xffU);
      break;
    case FixtureConstructionProfile::invalid_stationary_status_discriminant:
      product.capabilities.stationary_phase_law =
          static_cast<StationaryPhaseLawStatus>(0xffU);
      break;
    case FixtureConstructionProfile::invalid_access_provision_discriminant:
      product.capabilities.adjacent_batch_replay->provision =
          static_cast<AccessProvision>(0xffU);
      break;
    case FixtureConstructionProfile::invalid_transform_kind_discriminant:
      install_analytic_transform();
      product.capabilities.analytic_transform->kind =
          static_cast<TransformKind>(0xffU);
      product.analytic_transform->capability =
          *product.capabilities.analytic_transform;
      break;
    case FixtureConstructionProfile::invalid_distribution_scope_discriminant:
      install_analytic_transform();
      product.capabilities.analytic_transform->scope =
          static_cast<DistributionScope>(0xffU);
      product.analytic_transform->capability =
          *product.capabilities.analytic_transform;
      break;
    case FixtureConstructionProfile::invalid_phase_requirement_discriminant:
      product.capabilities.unit_cube_transform->phase_requirement =
          static_cast<PhaseArgumentRequirement>(0xffU);
      product.unit_cube->capability =
          *product.capabilities.unit_cube_transform;
      break;
    case FixtureConstructionProfile::invalid_cube_boundary_discriminant:
      product.capabilities.unit_cube_transform->boundary =
          static_cast<UnitCubeBoundary>(0xffU);
      product.unit_cube->capability =
          *product.capabilities.unit_cube_transform;
      break;
    case FixtureConstructionProfile::invalid_inverse_cdf_discriminant:
      product.capabilities.unit_cube_transform->inverse_cdf =
          static_cast<InverseCdfConvention>(0xffU);
      product.unit_cube->capability =
          *product.capabilities.unit_cube_transform;
      break;
    case FixtureConstructionProfile::partial_sampler_runtime:
      product.runtime.propose = {};
      break;
    case FixtureConstructionProfile::nonfinite_iid_claim:
      install_iid_table();
      product.capabilities.exact_iid_joint_vector->finite_support = false;
      break;
    case FixtureConstructionProfile::iid_support_mismatch:
      install_iid_table();
      product.positive_support[second.value().ordinal()] = 0U;
      break;
    case FixtureConstructionProfile::noncanonical_moment_table:
      product.capabilities.exact_coordinate_moments = MomentCapability{
          BigNat(1U), false, false, AccessProvision::portable_only};
      product.moments = std::vector<ExactMomentDatum>{
          ExactMomentDatum{std::vector<DenseQueueIndex>{second.value()},
                           BigNat(1U), ExactRational::one()},
          ExactMomentDatum{std::vector<DenseQueueIndex>{first.value()},
                           BigNat(1U), ExactRational::one()}};
      break;
    case FixtureConstructionProfile::noncanonical_covariance_table:
      product.capabilities.exact_covariance =
          CapabilityAvailability::available;
      product.covariances = std::vector<ExactMomentDatum>{ExactMomentDatum{
          std::vector<DenseQueueIndex>{second.value(), first.value()},
          BigNat(2U), ExactRational::zero()}};
      break;
    case FixtureConstructionProfile::invalid_unit_cube_coordinates:
      product.unit_cube->coordinate_order[0U] =
          UnitCubeCoordinate{1U, ""};
      break;
    case FixtureConstructionProfile::incomplete_replay_codec:
      product.replay_codec->preserves_adjacent_temporal_order = false;
      break;
    case FixtureConstructionProfile::empty_transform_domain:
      install_analytic_transform();
      product.capabilities.analytic_transform->domain = ExactArgumentDomain{
          ExactRational::one(), ExactRational::zero(), true, true};
      product.analytic_transform->capability =
          *product.capabilities.analytic_transform;
      break;
    case FixtureConstructionProfile::zero_transform_codec:
      install_analytic_transform();
      product.analytic_transform->codec_version = 0U;
      break;
    case FixtureConstructionProfile::throwing_phase_decoder:
      product.runtime.decode_phase =
          [](const std::shared_ptr<const void>&,
             const std::span<const std::byte>)
          -> Result<detail::ArrivalCursorState> {
        throw std::runtime_error("private fixture decoder failure");
      };
      break;
    case FixtureConstructionProfile::support_dimension_mismatch:
      product.positive_support.pop_back();
      break;
    case FixtureConstructionProfile::unbounded_moment_claim:
      product.capabilities.exact_coordinate_moments = MomentCapability{
          std::nullopt, false, false, AccessProvision::portable_only};
      product.moments = std::vector<ExactMomentDatum>{ExactMomentDatum{
          std::vector<DenseQueueIndex>{first.value()}, BigNat(1U),
          ExactRational::one()}};
      break;
    case FixtureConstructionProfile::phase_conditioned_moment_claim:
      product.capabilities.exact_coordinate_moments = MomentCapability{
          BigNat(1U), false, true, AccessProvision::portable_only};
      product.moments = std::vector<ExactMomentDatum>{ExactMomentDatum{
          std::vector<DenseQueueIndex>{first.value()}, BigNat(1U),
          ExactRational::one()}};
      break;
    case FixtureConstructionProfile::incomplete_coordinate_moment_table:
      product.capabilities.exact_coordinate_moments = MomentCapability{
          BigNat(1U), false, false, AccessProvision::portable_only};
      product.moments = std::vector<ExactMomentDatum>{ExactMomentDatum{
          std::vector<DenseQueueIndex>{first.value()}, BigNat(1U),
          ExactRational::one()}};
      break;
    case FixtureConstructionProfile::incomplete_covariance_table:
      product.covariances->pop_back();
      break;
    case FixtureConstructionProfile::incomplete_cross_moment_table: {
      const auto missing = std::ranges::find_if(
          *product.moments, [](const ExactMomentDatum& datum) {
            return datum.coordinates.size() == 2U;
          });
      product.moments->erase(missing);
      break;
    }
    case FixtureConstructionProfile::unit_cube_missing_phase_encoder:
      product.capabilities.sequential_normalized_sampler =
          CapabilityAvailability::unavailable;
      product.capabilities.adjacent_batch_replay->provision =
          AccessProvision::portable_only;
      product.runtime.validate_initial = {};
      product.runtime.instantiate = {};
      product.runtime.encode_phase = {};
      product.runtime.propose = {};
      break;
    case FixtureConstructionProfile::replay_missing_sequential_sampler:
      product.capabilities.sequential_normalized_sampler =
          CapabilityAvailability::unavailable;
      product.capabilities.adjacent_batch_replay = ReplayCapability{
          false, false, false, true, AccessProvision::process_local_only};
      product.capabilities.unit_cube_transform->provision =
          AccessProvision::portable_only;
      product.unit_cube->capability =
          *product.capabilities.unit_cube_transform;
      product.runtime.validate_initial = {};
      product.runtime.instantiate = {};
      product.runtime.encode_phase = {};
      product.runtime.propose = {};
      product.runtime.unit_cube = {};
      break;
    case FixtureConstructionProfile::baseline:
    case FixtureConstructionProfile::phase_required_unit_cube:
    case FixtureConstructionProfile::portable_only_construction_access:
    case FixtureConstructionProfile::independent_portable_transforms:
    case FixtureConstructionProfile::portable_iid_joint_table:
    case FixtureConstructionProfile::portable_iid_bernoulli_joint_table:
    case FixtureConstructionProfile::portable_iid_batch_joint_table:
    case FixtureConstructionProfile::portable_moments_and_covariance:
    case FixtureConstructionProfile::replay_without_stationary:
    case FixtureConstructionProfile::unsupported_process_local_iid:
    case FixtureConstructionProfile::unsupported_process_local_moment:
    case FixtureConstructionProfile::unsupported_process_local_transform:
      break;
  }
  return detail::publish_compiled_arrival_law(queues, std::move(product));
}

}  // namespace

Result<CompiledArrivalLaw> make_c09_correlated_fixture_law(
    const QueueCatalog& queues, const FixtureFailureMode failure_mode,
    const FixtureConstructionProfile construction_profile) {
  auto half = ExactRational::make(BigInt(1), BigInt(2));
  if (!half) {
    return Result<CompiledArrivalLaw>::failure(half.error());
  }
  return make_c09_correlated_fixture_law_impl(
      queues, half.value(), half.value(), false, failure_mode,
      construction_profile, false, false, false, false, half.value(),
      half.value());
}

Result<CompiledArrivalLaw>
make_c09_time_homogeneous_correlated_fixture_law(
    const QueueCatalog& queues,
    const bool reverse_exact_row_for_testing) {
  auto half = ExactRational::make(BigInt(1), BigInt(2));
  if (!half) {
    return Result<CompiledArrivalLaw>::failure(half.error());
  }
  return make_c09_correlated_fixture_law_impl(
      queues, half.value(), half.value(), false, FixtureFailureMode::none,
      FixtureConstructionProfile::baseline, true,
      reverse_exact_row_for_testing, false, false, half.value(),
      half.value());
}

Result<CompiledArrivalLaw>
make_c09_absorbing_two_phase_time_homogeneous_fixture_law(
    const QueueCatalog& queues, ExactRational phase_zero_stationary_mass,
    ExactRational phase_one_stationary_mass) {
  auto half = ExactRational::make(BigInt(1), BigInt(2));
  if (!half) {
    return Result<CompiledArrivalLaw>::failure(half.error());
  }
  return make_c09_correlated_fixture_law_impl(
      queues, half.value(), half.value(), false, FixtureFailureMode::none,
      FixtureConstructionProfile::phase_required_unit_cube, true, false,
      true, false, phase_zero_stationary_mass, phase_one_stationary_mass);
}

Result<CompiledArrivalLaw>
make_c09_phase_selective_transient_fixture_law(
    const QueueCatalog& queues) {
  auto half = ExactRational::make(BigInt(1), BigInt(2));
  if (!half) {
    return Result<CompiledArrivalLaw>::failure(half.error());
  }
  return make_c09_correlated_fixture_law_impl(
      queues, half.value(), half.value(), false, FixtureFailureMode::none,
      FixtureConstructionProfile::phase_required_unit_cube, true, false,
      false, true, ExactRational::zero(), ExactRational::one());
}

Result<CompiledArrivalLaw> make_c09_weighted_correlated_fixture_law(
    const QueueCatalog& queues, ExactRational first_outcome_mass,
    const FixtureConstructionProfile construction_profile) {
  const ExactRational second_outcome_mass =
      ExactRational::one() - first_outcome_mass;
  auto half = ExactRational::make(BigInt(1), BigInt(2));
  if (!half) {
    return Result<CompiledArrivalLaw>::failure(half.error());
  }
  if (first_outcome_mass == half.value() &&
      construction_profile == FixtureConstructionProfile::baseline) {
    return make_c09_correlated_fixture_law(queues);
  }
  return make_c09_correlated_fixture_law_impl(
      queues, first_outcome_mass, second_outcome_mass, true,
      FixtureFailureMode::none, construction_profile, false, false, false,
      false, first_outcome_mass, second_outcome_mass);
}

Result<ArrivalProcessSnapshot> snapshot_arrival_process(
    const ArrivalProcess& process) {
  const auto core = detail::ArrivalCoreAccess::process_core(process);
  if (!core) {
    return failure<ArrivalProcessSnapshot>(
        DiagnosticCategory::input_validation, "arrival_process_moved_from",
        "the arrival process has been moved from");
  }
  BusyLease lease(core->in_step);
  if (!lease.acquired()) {
    return failure<ArrivalProcessSnapshot>(
        DiagnosticCategory::input_validation,
        "nonsequential_arrival_access",
        "an arrival cursor cannot be inspected while it is mutating");
  }
  auto encoded = core->law->runtime.encode_phase(core->law->payload,
                                                  core->state);
  if (!encoded) {
    return Result<ArrivalProcessSnapshot>::failure(encoded.error());
  }
  auto digest = state_digest(encoded.value());
  if (!digest) {
    return Result<ArrivalProcessSnapshot>::failure(digest.error());
  }
  return Result<ArrivalProcessSnapshot>::success(ArrivalProcessSnapshot{
      core->expected_slot, ArrivalStateDigest(digest.value()),
      core->rng->checkpoint()});
}

Result<ArrivalPhase> make_c09_fixture_phase_for_testing(
    const CompiledArrivalLaw& law, const std::uint8_t canonical_phase,
    BigNat next_authored_slot) {
  const auto core = detail::ArrivalCoreAccess::law_core(law);
  if (!core || canonical_phase > 1U ||
      !core->builder_view.finite_phase().has_value() ||
      !core->runtime.decode_phase) {
    return failure<ArrivalPhase>(
        DiagnosticCategory::input_validation,
        "arrival_fixture_phase_unavailable",
        "the requested law is not the private finite-phase fixture");
  }
  std::vector<std::byte> canonical{
      static_cast<std::byte>(canonical_phase)};
  auto cursor = core->runtime.decode_phase(core->payload, canonical);
  auto digest = detail::digest_arrival_state(canonical);
  if (!cursor || !digest) {
    return cursor ? Result<ArrivalPhase>::failure(digest.error())
                  : Result<ArrivalPhase>::failure(cursor.error());
  }
  try {
    auto owner = std::make_shared<const detail::CursorOwnerToken>();
    auto phase_core = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{
            core->binding.family, core->binding,
            ArrivalStateDigest(std::move(digest).value()),
            std::move(canonical), std::move(next_authored_slot),
            std::move(cursor).value(), std::move(owner)});
    return Result<ArrivalPhase>::success(
        detail::ArrivalCoreAccess::make_phase(core->binding.family,
                                              std::move(phase_core)));
  } catch (const std::bad_alloc&) {
    return failure<ArrivalPhase>(
        DiagnosticCategory::resource_limit,
        "arrival_fixture_phase_allocation_failure",
        "constructing the private finite homogeneous fixture phase exhausted "
        "memory");
  }
}

Result<ArrivalPhase> reanchor_c09_fixture_phase_for_testing(
    const ArrivalPhase& phase, BigNat next_authored_slot) {
  const auto core = detail::ArrivalCoreAccess::phase_core(phase);
  if (!core) {
    return failure<ArrivalPhase>(
        DiagnosticCategory::input_validation,
        "arrival_fixture_phase_unavailable",
        "the fixture phase cannot be re-anchored after it was moved from");
  }
  try {
    auto anchored = std::make_shared<const detail::ArrivalPhaseCore>(
        detail::ArrivalPhaseCore{
            core->family, core->binding, core->state_digest,
            core->canonical_state, std::move(next_authored_slot),
            core->cursor_state, core->cursor_owner});
    return Result<ArrivalPhase>::success(
        detail::ArrivalCoreAccess::make_phase(core->family,
                                              std::move(anchored)));
  } catch (const std::bad_alloc&) {
    return failure<ArrivalPhase>(
        DiagnosticCategory::resource_limit,
        "arrival_fixture_phase_allocation_failure",
        "re-anchoring the fixture phase exhausted memory");
  }
}

}  // namespace testing
#endif

}  // namespace mwperf
