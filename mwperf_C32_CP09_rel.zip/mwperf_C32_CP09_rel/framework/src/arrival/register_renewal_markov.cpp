#include "mwperf/arrival/registry.hpp"

namespace mwperf::detail {

const ArrivalBackendRegistry& c11_arrival_registry() {
  // Preserve the immutable C10 layer for conformance and reversion.  The
  // released C11 compilers retain slots 3--5 and CP09 appends concrete IID
  // compilers in slots 6--9; there is no mutable registration order, alias,
  // or fallback law.
  static const ArrivalBackendRegistry registry = [] {
    ArrivalBackendRegistry composed = c10_arrival_registry();
    composed[3U].compile = compile_marked_renewal_product;
    composed[4U].compile = compile_private_markov_renewal_product;
    composed[5U].compile = compile_shared_round_renewal_product;
    composed[6U].compile = compile_iid_independent_bernoulli_product;
    composed[7U].compile = compile_iid_count_table_product;
    composed[8U].compile = compile_iid_independent_poisson_product;
    composed[9U].compile = compile_iid_mixed_poisson_product;
    return composed;
  }();
  return registry;
}

}  // namespace mwperf::detail
