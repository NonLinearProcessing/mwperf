#include "mwperf/arrival/shared_round_renewal.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/registry.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/random/deterministic_rng.hpp"

#include "core_internal.hpp"

namespace mwperf {
namespace {

template <typename Value>
[[nodiscard]] Result<Value> fail(
    const DiagnosticCategory category, std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  std::optional<std::string> path;
  std::optional<std::string> pointer;
  if (provenance.has_value()) {
    pointer = provenance->json_pointer;
    if (provenance->location.has_value()) {
      path = provenance->location->authored_path;
      notes.insert(notes.begin(),
                   "line " +
                       std::to_string(provenance->location->line) +
                       ", column " +
                       std::to_string(provenance->location->column));
    }
  }
  return Result<Value>::failure(Diagnostic{
      category, std::move(code), std::move(message), std::move(path),
      std::move(pointer), std::move(notes)});
}

template <typename Value>
[[nodiscard]] Result<Value> input_fail(
    std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  return fail<Value>(DiagnosticCategory::input_validation, std::move(code),
                     std::move(message), provenance, std::move(notes));
}

template <typename Value>
[[nodiscard]] Result<Value> internal_fail(std::string code,
                                          std::string message) {
  return fail<Value>(DiagnosticCategory::internal, std::move(code),
                     std::move(message));
}

template <typename Value>
[[nodiscard]] Result<Value> allocation_fail(std::string operation) {
  return fail<Value>(
      DiagnosticCategory::resource_limit,
      "shared_round_arrival_allocation_failure",
      "memory allocation failed while " + std::move(operation));
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(value >> (shift - 8U)));
  }
}

void append_size(std::vector<std::byte>& output, const std::size_t value) {
  static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));
  append_u64(output, static_cast<std::uint64_t>(value));
}

void append_string(std::vector<std::byte>& output,
                   const std::string_view value) {
  append_size(output, value.size());
  for (const char character : value) {
    output.push_back(
        static_cast<std::byte>(static_cast<unsigned char>(character)));
  }
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> bytes = value.canonical_magnitude_bytes();
  append_size(output, bytes.size());
  for (const std::uint8_t byte : bytes) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

struct SharedCompiledComponents final {
  std::size_t queue_count;
  QueueCatalogDigest catalog_digest;
  std::vector<std::string> source_ids;
  SharedRoundInitialLaw initial;
  std::vector<SharedRoundStateLaw> states;
  std::vector<std::uint8_t> positive_support;
};

[[nodiscard]] const NormalizedArrivalRow* find_row(
    const std::span<const NormalizedArrivalRow> rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::size_t state_ordinal) {
  const NormalizedArrivalRow* found = nullptr;
  for (const NormalizedArrivalRow& row : rows) {
    if (row.kind == kind && row.source_ordinal == source_ordinal &&
        row.state_ordinal == state_ordinal) {
      if (found != nullptr) {
        return nullptr;
      }
      found = &row;
    }
  }
  return found;
}

[[nodiscard]] Result<std::vector<NormalizedArrivalRow>> prepare_rows(
    const SharedJointRoundMarkovRenewalArrival& authored) {
  try {
    std::vector<NormalizedArrivalRow> rows;
    if (const auto* distribution =
            std::get_if<InitialStateDistribution>(&authored.initial.value)) {
      std::vector<AuthoredProbability> probabilities;
      probabilities.reserve(distribution->distribution.value.size());
      for (const StateProbability& mass :
           distribution->distribution.value) {
        probabilities.push_back(mass.probability.value);
      }
      auto normalized = validate_and_normalize_pmf(
          probabilities, physical_pmf_tolerance());
      if (!normalized) {
        return Result<std::vector<NormalizedArrivalRow>>::failure(
            normalized.error());
      }
      rows.push_back(NormalizedArrivalRow{
          ArrivalCategoricalRowKind::shared_initial_state, 0U, 0U,
          std::move(normalized).value()});
    }

    std::vector<std::string> row_keys;
    row_keys.reserve(authored.states.value.size() +
                     authored.outcomes.value.size());
    for (const NormalizedToken& state : authored.states.value) {
      if (std::ranges::find(row_keys, state.value) == row_keys.end()) {
        row_keys.push_back(state.value);
      }
    }
    for (const SharedOutcome& outcome : authored.outcomes.value) {
      if (std::ranges::find(row_keys, outcome.state.value) == row_keys.end()) {
        row_keys.push_back(outcome.state.value);
      }
    }
    for (std::size_t state_ordinal = 0U;
         state_ordinal < row_keys.size(); ++state_ordinal) {
      std::vector<AuthoredProbability> probabilities;
      for (const SharedOutcome& outcome : authored.outcomes.value) {
        if (outcome.state.value == row_keys[state_ordinal]) {
          probabilities.push_back(outcome.probability.value);
        }
      }
      if (probabilities.empty()) {
        continue;
      }
      auto normalized = validate_and_normalize_pmf(
          probabilities, physical_pmf_tolerance());
      if (!normalized) {
        return Result<std::vector<NormalizedArrivalRow>>::failure(
            normalized.error());
      }
      rows.push_back(NormalizedArrivalRow{
          ArrivalCategoricalRowKind::shared_outcome, 0U, state_ordinal,
          std::move(normalized).value()});
    }
    return Result<std::vector<NormalizedArrivalRow>>::success(
        std::move(rows));
  } catch (const std::bad_alloc&) {
    return allocation_fail<std::vector<NormalizedArrivalRow>>(
        "normalizing standalone shared-round categorical rows");
  } catch (const std::length_error&) {
    return fail<std::vector<NormalizedArrivalRow>>(
        DiagnosticCategory::resource_limit,
        "shared_round_arrival_representation_failure",
        "the shared-round categorical representation exceeds a host limit");
  }
}

[[nodiscard]] Result<SharedCompiledComponents> compile_components(
    const SharedJointRoundMarkovRenewalArrival& authored,
    const QueueCatalog& queues,
    const std::span<const NormalizedArrivalRow> rows) {
  if (authored.sources.value.empty()) {
    return input_fail<SharedCompiledComponents>(
        "shared_round_sources_empty",
        "a shared-round renewal law requires at least one source",
        authored.sources.provenance);
  }
  if (authored.states.value.empty()) {
    return input_fail<SharedCompiledComponents>(
        "shared_round_states_empty",
        "a shared-round renewal law requires at least one state",
        authored.states.provenance);
  }

  try {
    std::map<std::string, std::size_t> source_indices;
    std::vector<std::string> source_ids;
    source_ids.reserve(authored.sources.value.size());
    for (std::size_t index = 0U; index < authored.sources.value.size();
         ++index) {
      const SharedRenewalSource& source = authored.sources.value[index];
      if (source.id.value.empty()) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_source_id_empty",
            "a shared-round source identifier must be nonempty",
            source.id.provenance);
      }
      if (!source_indices.emplace(source.id.value, index).second) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_duplicate_source_id",
            "shared-round source identifiers must be unique after "
            "normalization",
            source.id.provenance,
            {"duplicate source: " + source.id.value});
      }
      source_ids.push_back(source.id.value);
    }

    std::map<std::string, std::size_t> state_indices;
    for (std::size_t index = 0U; index < authored.states.value.size();
         ++index) {
      const NormalizedToken& state = authored.states.value[index];
      if (state.value.empty()) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_state_id_empty",
            "a shared-round state identifier must be nonempty",
            state.provenance);
      }
      if (!state_indices.emplace(state.value, index).second) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_duplicate_state_id",
            "shared-round state identifiers must be unique after "
            "normalization",
            state.provenance,
            {"duplicate state: " + state.value});
      }
    }

    SharedRoundInitialLaw initial{{}, std::nullopt};
    std::size_t expected_rows = 0U;
    if (const auto* exact =
            std::get_if<InitialExactState>(&authored.initial.value)) {
      const auto found = state_indices.find(exact->state.value);
      if (found == state_indices.end()) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_initial_state_unknown",
            "the fixed shared-round initial state is not declared",
            exact->state.provenance,
            {"state: " + exact->state.value});
      }
      initial.state_indices.push_back(found->second);
    } else {
      const auto& distribution =
          std::get<InitialStateDistribution>(authored.initial.value);
      if (distribution.distribution.value.empty()) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_initial_distribution_empty",
            "the shared-round initial distribution must be nonempty",
            distribution.distribution.provenance);
      }
      if (distribution.distribution.value.size() !=
          authored.states.value.size()) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_initial_state_coverage_incomplete",
            "a shared-round initial distribution must contain every "
            "declared state exactly once",
            distribution.distribution.provenance,
            {"declared states: " +
                 std::to_string(authored.states.value.size()),
             "initial coordinates: " +
                 std::to_string(distribution.distribution.value.size())});
      }
      const NormalizedArrivalRow* row = find_row(
          rows, ArrivalCategoricalRowKind::shared_initial_state, 0U, 0U);
      if (row == nullptr ||
          row->pmf.size() != distribution.distribution.value.size()) {
        return internal_fail<SharedCompiledComponents>(
            "shared_round_normalized_initial_row_mismatch",
            "the common arrival boundary supplied no matching normalized "
            "shared initial-state row");
      }
      for (std::size_t coordinate = 0U;
           coordinate < distribution.distribution.value.size();
           ++coordinate) {
        if (!(row->pmf.authored_probabilities()[coordinate] ==
              distribution.distribution.value[coordinate]
                  .probability.value)) {
          return internal_fail<SharedCompiledComponents>(
              "shared_round_normalized_initial_row_mismatch",
              "the normalized shared initial-state row changed an authored "
              "probability coordinate or its significant order");
        }
      }
      ++expected_rows;
      std::set<std::string> seen;
      initial.state_indices.reserve(distribution.distribution.value.size());
      for (const StateProbability& mass :
           distribution.distribution.value) {
        if (!seen.insert(mass.state.value).second) {
          return input_fail<SharedCompiledComponents>(
              "shared_round_duplicate_initial_state",
              "a shared-round initial distribution cannot repeat a state",
              mass.state.provenance,
              {"duplicate state: " + mass.state.value});
        }
        const auto found = state_indices.find(mass.state.value);
        if (found == state_indices.end()) {
          return input_fail<SharedCompiledComponents>(
              "shared_round_initial_state_unknown",
              "a shared-round initial-distribution state is not declared",
              mass.state.provenance,
              {"state: " + mass.state.value});
        }
        initial.state_indices.push_back(found->second);
      }
      initial.probabilities = row->pmf;
    }

    for (const SharedOutcome& outcome : authored.outcomes.value) {
      if (!state_indices.contains(outcome.state.value)) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_outcome_state_unknown",
            "a shared-round outcome row names an undeclared current state",
            outcome.state.provenance,
            {"state: " + outcome.state.value});
      }
    }

    std::vector<SharedRoundStateLaw> states;
    states.reserve(authored.states.value.size());
    for (std::size_t state_ordinal = 0U;
         state_ordinal < authored.states.value.size(); ++state_ordinal) {
      const NormalizedToken& declared = authored.states.value[state_ordinal];
      std::vector<const SharedOutcome*> authored_row;
      for (const SharedOutcome& outcome : authored.outcomes.value) {
        if (outcome.state.value == declared.value) {
          authored_row.push_back(&outcome);
        }
      }
      if (authored_row.empty()) {
        return input_fail<SharedCompiledComponents>(
            "shared_round_outgoing_row_missing",
            "every shared-round state requires a nonempty outgoing outcome "
            "row",
            declared.provenance,
            {"state: " + declared.value});
      }
      const NormalizedArrivalRow* normalized = find_row(
          rows, ArrivalCategoricalRowKind::shared_outcome, 0U,
          state_ordinal);
      if (normalized == nullptr ||
          normalized->pmf.size() != authored_row.size()) {
        return internal_fail<SharedCompiledComponents>(
            "shared_round_normalized_outcome_row_mismatch",
            "the common arrival boundary supplied no matching normalized "
            "shared outcome row");
      }
      for (std::size_t coordinate = 0U; coordinate < authored_row.size();
           ++coordinate) {
        if (!(normalized->pmf.authored_probabilities()[coordinate] ==
              authored_row[coordinate]->probability.value)) {
          return internal_fail<SharedCompiledComponents>(
              "shared_round_normalized_outcome_row_mismatch",
              "the normalized shared outcome row changed an authored "
              "probability coordinate or its significant order");
        }
      }
      ++expected_rows;

      std::vector<SharedRoundOutcomeLaw> outcomes;
      outcomes.reserve(authored_row.size());
      for (const SharedOutcome* authored_outcome : authored_row) {
        const auto next = state_indices.find(
            authored_outcome->next_state.value);
        if (next == state_indices.end()) {
          return input_fail<SharedCompiledComponents>(
              "shared_round_next_state_unknown",
              "a shared-round outcome names an undeclared next state",
              authored_outcome->next_state.provenance,
              {"state: " + authored_outcome->next_state.value});
        }
        std::vector<std::optional<SharedRoundEmissionLaw>> ordered(
            source_ids.size());
        for (const SharedEmission& emission :
             authored_outcome->emissions.value) {
          const auto source = source_indices.find(emission.source_id.value);
          if (source == source_indices.end()) {
            return input_fail<SharedCompiledComponents>(
                "shared_round_emission_source_unknown",
                "a shared-round outcome contains an undeclared source",
                emission.source_id.provenance,
                {"source: " + emission.source_id.value});
          }
          if (ordered[source->second].has_value()) {
            return input_fail<SharedCompiledComponents>(
                "shared_round_duplicate_source_emission",
                "a shared-round outcome must contain exactly one emission "
                "for each source",
                emission.source_id.provenance,
                {"duplicate source: " + emission.source_id.value});
          }
          if (emission.d.value.is_zero()) {
            return input_fail<SharedCompiledComponents>(
                "shared_round_gap_nonpositive",
                "every shared-round emission gap must be positive",
                emission.d.provenance);
          }
          auto queue = queues.resolve(emission.queue_id.value,
                                      emission.queue_id.provenance);
          if (!queue) {
            return Result<SharedCompiledComponents>::failure(queue.error());
          }
          ordered[source->second] = SharedRoundEmissionLaw{
              emission.d.value, queue.value()};
        }
        if (authored_outcome->emissions.value.size() != source_ids.size() ||
            std::ranges::any_of(ordered, [](const auto& value) {
              return !value.has_value();
            })) {
          return input_fail<SharedCompiledComponents>(
              "shared_round_source_emission_incomplete",
              "every shared-round outcome must contain exactly one emission "
              "for every declared source",
              authored_outcome->emissions.provenance,
              {"declared sources: " + std::to_string(source_ids.size()),
               "emission records: " +
                   std::to_string(authored_outcome->emissions.value.size())});
        }
        std::vector<SharedRoundEmissionLaw> emissions;
        emissions.reserve(ordered.size());
        for (auto& emission : ordered) {
          emissions.push_back(std::move(*emission));
        }
        SharedRoundOutcomeLaw compiled{next->second, std::move(emissions)};
        if (std::ranges::find(outcomes, compiled) != outcomes.end()) {
          return input_fail<SharedCompiledComponents>(
              "shared_round_duplicate_outcome",
              "a shared-round state row cannot repeat a complete joint "
              "outcome coordinate",
              authored_outcome->provenance,
              {"state: " + declared.value});
        }
        outcomes.push_back(std::move(compiled));
      }
      states.push_back(SharedRoundStateLaw{
          declared.value, std::move(outcomes), normalized->pmf});
    }

    if (rows.size() != expected_rows) {
      return internal_fail<SharedCompiledComponents>(
          "shared_round_normalized_row_set_mismatch",
          "the shared-round compiler did not consume exactly the categorical "
          "rows prepared by the common arrival boundary");
    }

    std::vector<std::uint8_t> support(queues.size(), 0U);
    std::vector<std::uint8_t> reachable(states.size(), 0U);
    std::vector<std::size_t> frontier;
    const auto seed = [&](const std::size_t state) {
      if (reachable[state] == 0U) {
        reachable[state] = 1U;
        frontier.push_back(state);
      }
    };
    if (initial.probabilities.has_value()) {
      for (std::size_t index = 0U; index < initial.state_indices.size();
           ++index) {
        if (initial.probabilities->normalized_weights()[index].is_positive()) {
          seed(initial.state_indices[index]);
        }
      }
    } else {
      seed(initial.state_indices.front());
    }
    for (std::size_t next = 0U; next < frontier.size(); ++next) {
      const SharedRoundStateLaw& state = states[frontier[next]];
      for (std::size_t outcome_index = 0U;
           outcome_index < state.outcomes.size(); ++outcome_index) {
        if (!state.outcome_probabilities.normalized_weights()[outcome_index]
                 .is_positive()) {
          continue;
        }
        const SharedRoundOutcomeLaw& outcome = state.outcomes[outcome_index];
        for (const SharedRoundEmissionLaw& emission : outcome.emissions) {
          support[emission.destination.ordinal()] = 1U;
        }
        seed(outcome.next_state);
      }
    }

    auto catalog_digest = detail::digest_queue_catalog(queues);
    if (!catalog_digest) {
      return Result<SharedCompiledComponents>::failure(
          catalog_digest.error());
    }
    return Result<SharedCompiledComponents>::success(SharedCompiledComponents{
        queues.size(), catalog_digest.value(), std::move(source_ids),
        std::move(initial), std::move(states), std::move(support)});
  } catch (const std::bad_alloc&) {
    return allocation_fail<SharedCompiledComponents>(
        "compiling a shared-round renewal law");
  } catch (const std::length_error&) {
    return fail<SharedCompiledComponents>(
        DiagnosticCategory::resource_limit,
        "shared_round_arrival_representation_failure",
        "the shared-round law exceeds a host container limit");
  } catch (const std::exception&) {
    return internal_fail<SharedCompiledComponents>(
        "shared_round_compilation_invariant_failure",
        "shared-round compilation violated an exact representation "
        "invariant");
  }
}

[[nodiscard]] std::vector<std::byte> encode_law(const SharedRoundLaw& law) {
  std::vector<std::byte> encoded;
  append_string(encoded, "mwperf.c11.shared_joint_round_markov_renewal.v1");
  append_u32(encoded, 1U);
  append_size(encoded, law.queue_count());
  append_size(encoded, law.source_ids().size());
  for (const std::string& source : law.source_ids()) {
    append_string(encoded, source);
  }
  encoded.push_back(law.initial().probabilities.has_value() ? std::byte{1}
                                                            : std::byte{0});
  append_size(encoded, law.initial().state_indices.size());
  for (const std::size_t state : law.initial().state_indices) {
    append_size(encoded, state);
  }
  append_size(encoded, law.states().size());
  for (const SharedRoundStateLaw& state : law.states()) {
    append_string(encoded, state.state_id);
    append_size(encoded, state.outcomes.size());
    for (const SharedRoundOutcomeLaw& outcome : state.outcomes) {
      append_size(encoded, outcome.next_state);
      append_size(encoded, outcome.emissions.size());
      for (const SharedRoundEmissionLaw& emission : outcome.emissions) {
        append_big_nat(encoded, emission.gap);
        append_size(encoded, emission.destination.ordinal());
      }
    }
  }
  return encoded;
}

struct SharedPendingEvent final {
  BigNat slot;
  std::size_t source;
  DenseQueueIndex destination;
};

struct SharedRoundCursorState final {
  std::size_t global_state;
  std::vector<std::optional<BigNat>> latest_slots;
  std::vector<SharedPendingEvent> pending;
};

[[nodiscard]] bool pending_less(const SharedPendingEvent& left,
                                const SharedPendingEvent& right) {
  if (left.slot != right.slot) {
    return left.slot < right.slot;
  }
  return left.source < right.source;
}

[[nodiscard]] Result<void> validate_cursor(const SharedRoundLaw& law,
                                           const SharedRoundCursorState& state) {
  if (state.global_state >= law.states().size() ||
      state.latest_slots.size() != law.source_ids().size()) {
    return internal_fail<void>(
        "shared_round_cursor_state_invalid",
        "the shared-round cursor has an invalid state or clock dimension");
  }
  for (std::size_t index = 0U; index < state.pending.size(); ++index) {
    const SharedPendingEvent& event = state.pending[index];
    if (event.source >= law.source_ids().size() ||
        event.destination.ordinal() >= law.queue_count() ||
        law.positive_support_bytes()[event.destination.ordinal()] == 0U ||
        !state.latest_slots[event.source].has_value() ||
        *state.latest_slots[event.source] < event.slot ||
        (index != 0U && !pending_less(state.pending[index - 1U], event))) {
      return internal_fail<void>(
          "shared_round_cursor_state_invalid",
          "the shared-round pending-event set is not a canonical exact "
          "slot/source ordering");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<std::vector<std::byte>> encode_phase(
    const SharedRoundLaw& law, const detail::ArrivalCursorState& erased) {
  const auto state =
      std::static_pointer_cast<const SharedRoundCursorState>(erased);
  if (!state) {
    return internal_fail<std::vector<std::byte>>(
        "shared_round_cursor_state_missing",
        "the shared-round phase encoder received no cursor state");
  }
  auto valid = validate_cursor(law, *state);
  if (!valid) {
    return Result<std::vector<std::byte>>::failure(valid.error());
  }
  try {
    std::vector<std::byte> encoded;
    append_u32(encoded, 1U);
    encoded.push_back(static_cast<std::byte>(
        ArrivalFamily::shared_joint_round_markov_renewal));
    append_size(encoded, state->global_state);
    append_size(encoded, state->latest_slots.size());
    for (const auto& slot : state->latest_slots) {
      encoded.push_back(slot.has_value() ? std::byte{1} : std::byte{0});
      if (slot.has_value()) {
        append_big_nat(encoded, *slot);
      }
    }
    append_size(encoded, state->pending.size());
    for (const SharedPendingEvent& event : state->pending) {
      append_big_nat(encoded, event.slot);
      append_size(encoded, event.source);
      append_size(encoded, event.destination.ordinal());
    }
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return allocation_fail<std::vector<std::byte>>(
        "encoding a shared-round predictive phase");
  } catch (const std::length_error&) {
    return fail<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "shared_round_phase_representation_failure",
        "the shared-round predictive phase exceeds a host container limit");
  }
}

[[nodiscard]] bool initial_supports(const SharedRoundLaw& law,
                                    const std::size_t state) {
  const SharedRoundInitialLaw& initial = law.initial();
  for (std::size_t index = 0U; index < initial.state_indices.size(); ++index) {
    if (initial.state_indices[index] != state) {
      continue;
    }
    return !initial.probabilities.has_value() ||
           initial.probabilities->normalized_weights()[index].is_positive();
  }
  return false;
}

[[nodiscard]] Result<std::size_t> validate_initial(
    const SharedRoundLaw& law, const ArrivalInitialState& initial) {
  const auto* supplied = std::get_if<SharedRoundState>(&initial);
  if (supplied == nullptr) {
    return input_fail<std::size_t>(
        "arrival_initial_family_mismatch",
        "a shared-round renewal law requires a shared_round_state initial "
        "value");
  }
  const auto states = law.states();
  const auto found = std::ranges::find_if(
      states, [&](const SharedRoundStateLaw& state) {
        return state.state_id == supplied->state;
      });
  if (found == states.end()) {
    return input_fail<std::size_t>(
        "shared_round_supplied_initial_state_unknown",
        "the supplied shared-round initial state is not declared",
        std::nullopt, {"state: " + supplied->state});
  }
  const std::size_t index =
      static_cast<std::size_t>(std::distance(states.begin(), found));
  if (!initial_supports(law, index)) {
    return input_fail<std::size_t>(
        "shared_round_supplied_initial_state_zero_mass",
        "the supplied shared-round initial state has zero configured initial "
        "probability",
        std::nullopt, {"state: " + supplied->state});
  }
  return Result<std::size_t>::success(index);
}

[[nodiscard]] Result<detail::ArrivalCursorInitialization> instantiate_cursor(
    const SharedRoundLaw& law, const ArrivalInitialState& initial) {
  auto state = validate_initial(law, initial);
  if (!state) {
    return Result<detail::ArrivalCursorInitialization>::failure(state.error());
  }
  try {
    std::vector<std::optional<BigNat>> clocks(law.source_ids().size());
    auto cursor = std::make_shared<const SharedRoundCursorState>(
        SharedRoundCursorState{state.value(), std::move(clocks), {}});
    return Result<detail::ArrivalCursorInitialization>::success(
        detail::ArrivalCursorInitialization{std::move(cursor)});
  } catch (const std::bad_alloc&) {
    return allocation_fail<detail::ArrivalCursorInitialization>(
        "instantiating a shared-round cursor");
  }
}

[[nodiscard]] Result<BigNat> first_event_slot(const BigNat& gap) {
  return checked_subtract(gap, BigNat(1U));
}

[[nodiscard]] Result<void> insert_pending(
    std::vector<SharedPendingEvent>& pending, SharedPendingEvent event) {
  try {
    const auto position = std::lower_bound(
        pending.begin(), pending.end(), event, pending_less);
    if (position != pending.end() && position->slot == event.slot &&
        position->source == event.source) {
      return internal_fail<void>(
          "shared_round_duplicate_pending_event",
          "positive shared-round gaps produced duplicate source/slot events");
    }
    pending.insert(position, std::move(event));
    return Result<void>::success();
  } catch (const std::bad_alloc&) {
    return allocation_fail<void>("retaining a future shared-round event");
  } catch (const std::length_error&) {
    return fail<void>(DiagnosticCategory::resource_limit,
                      "shared_round_pending_representation_failure",
                      "the exact shared-round pending set exceeds a host "
                      "container limit");
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition> propose_transition(
    const SharedRoundLaw& law, const detail::ArrivalCursorState& erased,
    const BigNat& authored_slot, const ArrivalBinding& binding,
    DeterministicRng& rng) {
  if (binding.family !=
          ArrivalFamily::shared_joint_round_markov_renewal ||
      binding.timing != TimingConvention::early_service_late_admission ||
      binding.queue_cardinality != law.queue_count() ||
      !(binding.catalog_digest == law.catalog_digest())) {
    return internal_fail<detail::ProposedArrivalTransition>(
        "shared_round_runtime_binding_mismatch",
        "the shared-round runtime received another law, catalog, family, or "
        "timing binding");
  }
  const auto cursor =
      std::static_pointer_cast<const SharedRoundCursorState>(erased);
  if (!cursor) {
    return internal_fail<detail::ProposedArrivalTransition>(
        "shared_round_cursor_state_missing",
        "the shared-round transition received no cursor state");
  }
  auto valid = validate_cursor(law, *cursor);
  if (!valid) {
    return Result<detail::ProposedArrivalTransition>::failure(valid.error());
  }
  if (!cursor->pending.empty() &&
      cursor->pending.front().slot < authored_slot) {
    return internal_fail<detail::ProposedArrivalTransition>(
        "shared_round_pending_event_below_slot",
        "the shared-round cursor retained an unconsumed event below the "
        "requested slot");
  }

  try {
    SharedRoundCursorState successor = *cursor;
    const auto needs_round = [&]() {
      return std::ranges::any_of(
          successor.latest_slots, [&](const auto& clock) {
            return !clock.has_value() || *clock < authored_slot;
          });
    };
    while (needs_round()) {
      const SharedRoundStateLaw& state =
          law.states()[successor.global_state];
      const std::size_t selected =
          sample_categorical(state.outcome_probabilities, rng);
      if (selected >= state.outcomes.size()) {
        return internal_fail<detail::ProposedArrivalTransition>(
            "shared_round_sample_index_invalid",
            "categorical sampling returned an out-of-range shared outcome");
      }
      const SharedRoundOutcomeLaw& outcome = state.outcomes[selected];
      for (std::size_t source = 0U; source < outcome.emissions.size();
           ++source) {
        const SharedRoundEmissionLaw& emission = outcome.emissions[source];
        BigNat event_slot(0U);
        if (successor.latest_slots[source].has_value()) {
          event_slot = *successor.latest_slots[source] + emission.gap;
        } else {
          auto first = first_event_slot(emission.gap);
          if (!first) {
            return internal_fail<detail::ProposedArrivalTransition>(
                "shared_round_first_gap_invariant_failure",
                "a positive shared-round gap underflowed the exact -1 "
                "origin");
          }
          event_slot = std::move(first).value();
        }
        successor.latest_slots[source] = event_slot;
        auto inserted = insert_pending(
            successor.pending,
            SharedPendingEvent{std::move(event_slot), source,
                               emission.destination});
        if (!inserted) {
          return Result<detail::ProposedArrivalTransition>::failure(
              inserted.error());
        }
      }
      successor.global_state = outcome.next_state;
    }

    if (!successor.pending.empty() &&
        successor.pending.front().slot < authored_slot) {
      return internal_fail<detail::ProposedArrivalTransition>(
          "shared_round_pending_event_below_slot",
          "shared-round extension left an event below the requested slot");
    }

    std::vector<ArrivalAtom> atoms;
    auto first = std::lower_bound(
        successor.pending.begin(), successor.pending.end(), authored_slot,
        [](const SharedPendingEvent& event, const BigNat& slot) {
          return event.slot < slot;
        });
    auto last = first;
    while (last != successor.pending.end() &&
           last->slot == authored_slot) {
      auto atom = ArrivalAtom::make(last->destination, BigNat(1U), binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(
            atom.error());
      }
      atoms.push_back(std::move(atom).value());
      ++last;
    }
    successor.pending.erase(first, last);
    auto frozen = std::make_shared<const SharedRoundCursorState>(
        std::move(successor));
    return Result<detail::ProposedArrivalTransition>::success(
        detail::ProposedArrivalTransition{std::move(frozen),
                                          std::move(atoms)});
  } catch (const std::bad_alloc&) {
    return allocation_fail<detail::ProposedArrivalTransition>(
        "advancing a shared-round cursor");
  } catch (const std::length_error&) {
    return fail<detail::ProposedArrivalTransition>(
        DiagnosticCategory::resource_limit,
        "shared_round_transition_representation_failure",
        "the exact shared-round transition exceeds a host container limit");
  } catch (const std::exception&) {
    return internal_fail<detail::ProposedArrivalTransition>(
        "shared_round_transition_invariant_failure",
        "the shared-round transition violated an exact cursor invariant");
  }
}

[[nodiscard]] ArrivalCapabilities conservative_capabilities() {
  ArrivalCapabilities capabilities;
  capabilities.exact_positive_support = CapabilityAvailability::available;
  capabilities.sequential_normalized_sampler =
      CapabilityAvailability::available;
  return capabilities;
}

}  // namespace

Result<SharedRoundLaw> compile_shared_round_renewal(
    const SharedJointRoundMarkovRenewalArrival& authored,
    const QueueCatalog& queues) {
  auto rows = prepare_rows(authored);
  if (!rows) {
    return Result<SharedRoundLaw>::failure(rows.error());
  }
  auto compiled = compile_components(authored, queues, rows.value());
  if (!compiled) {
    return Result<SharedRoundLaw>::failure(compiled.error());
  }
  SharedCompiledComponents value = std::move(compiled).value();
  return Result<SharedRoundLaw>::success(SharedRoundLaw{
      value.queue_count, std::move(value.catalog_digest),
      std::move(value.source_ids), std::move(value.initial),
      std::move(value.states), std::move(value.positive_support)});
}

Result<ArrivalStep> next_shared_round_batch(SharedRoundCursor& cursor,
                                            const BigNat& authored_slot) {
  if (cursor.family() !=
      ArrivalFamily::shared_joint_round_markov_renewal) {
    return input_fail<ArrivalStep>(
        "shared_round_cursor_family_mismatch",
        "next_shared_round_batch requires a shared-round renewal cursor");
  }
  return next_arrival_step(cursor, authored_slot);
}

namespace detail {

Result<CompiledArrivalProduct> compile_shared_round_renewal_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<SharedJointRoundMarkovRenewalArrival>(
          &request.authored.value);
  if (authored == nullptr) {
    return internal_fail<CompiledArrivalProduct>(
        "arrival_backend_authored_variant_mismatch",
        "the shared-round registry slot received another authored family");
  }
  auto compiled =
      compile_components(*authored, request.queues, request.normalized_rows);
  if (!compiled) {
    return Result<CompiledArrivalProduct>::failure(compiled.error());
  }

  try {
    SharedCompiledComponents value = std::move(compiled).value();
    auto payload = std::make_shared<const SharedRoundLaw>(SharedRoundLaw{
        value.queue_count, std::move(value.catalog_digest),
        std::move(value.source_ids), std::move(value.initial),
        std::move(value.states), std::move(value.positive_support)});

    ArrivalRuntimeAdapter runtime;
    runtime.validate_initial =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalInitialState& initial) -> Result<void> {
      const auto law = std::static_pointer_cast<const SharedRoundLaw>(erased);
      if (!law) {
        return internal_fail<void>(
            "shared_round_law_payload_missing",
            "the shared-round runtime has no immutable law payload");
      }
      auto valid = validate_initial(*law, initial);
      if (!valid) {
        return Result<void>::failure(valid.error());
      }
      return Result<void>::success();
    };
    runtime.instantiate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalInitialState& initial,
           DeterministicRng&) -> Result<ArrivalCursorInitialization> {
      const auto law = std::static_pointer_cast<const SharedRoundLaw>(erased);
      if (!law) {
        return internal_fail<ArrivalCursorInitialization>(
            "shared_round_law_payload_missing",
            "the shared-round runtime has no immutable law payload");
      }
      return instantiate_cursor(*law, initial);
    };
    runtime.encode_phase =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state) {
      const auto law = std::static_pointer_cast<const SharedRoundLaw>(erased);
      if (!law) {
        return internal_fail<std::vector<std::byte>>(
            "shared_round_law_payload_missing",
            "the shared-round runtime has no immutable law payload");
      }
      return encode_phase(*law, state);
    };
    runtime.propose =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding,
           DeterministicRng& rng) -> Result<ProposedArrivalTransition> {
      const auto law = std::static_pointer_cast<const SharedRoundLaw>(erased);
      if (!law) {
        return internal_fail<ProposedArrivalTransition>(
            "shared_round_law_payload_missing",
            "the shared-round runtime has no immutable law payload");
      }
      return propose_transition(*law, state, slot, binding, rng);
    };

    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::shared_joint_round_markov_renewal,
        .normalized_rows = {},
        .positive_support =
            std::vector<std::uint8_t>(
                payload->positive_support_bytes().begin(),
                payload->positive_support_bytes().end()),
        .capabilities = conservative_capabilities(),
        .canonical_law_data = encode_law(*payload),
        .portable_schema =
            PortableArrivalLawSchema::shared_joint_round_markov_renewal_v1,
        .payload = std::move(payload),
        .runtime = std::move(runtime),
        .iid_joint_table = std::nullopt,
        .moments = std::nullopt,
        .covariances = std::nullopt,
        .analytic_transform = std::nullopt,
        .joint_distribution = std::nullopt,
        .coordinate_distributions = std::nullopt,
        .replay_codec = std::nullopt,
        .unit_cube = std::nullopt,
        .finite_phase = std::nullopt,
        .transition_rows = std::nullopt,
        .stationary_phase_law = std::nullopt,
    });
  } catch (const std::bad_alloc&) {
    return allocation_fail<CompiledArrivalProduct>(
        "publishing a shared-round arrival product");
  } catch (const std::length_error&) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::resource_limit,
        "shared_round_arrival_representation_failure",
        "the shared-round product exceeds a host container limit");
  }
}

}  // namespace detail

#if defined(MWPERF_C11_TEST_SEAMS)
namespace testing {

Result<CompiledArrivalLaw> make_shared_round_overflow_fixture_law(
    const SharedJointRoundMarkovRenewalArrival& authored,
    const QueueCatalog& queues, BigNat failure_slot) {
  auto queue = queues.index_at(0U);
  if (!queue) {
    return Result<CompiledArrivalLaw>::failure(queue.error());
  }
  detail::ArrivalBackendRegistry registry = detail::c11_arrival_registry();
  registry[5U].compile =
      [failure_slot, overflow_queue = queue.value()](
          const PreparedArrivalCompilation& request)
      -> Result<detail::CompiledArrivalProduct> {
    auto product = detail::compile_shared_round_renewal_product(request);
    if (!product) {
      return product;
    }
    const detail::ArrivalRuntimeAdapter::Propose ordinary =
        product.value().runtime.propose;
    product.value().runtime.propose =
        [ordinary, failure_slot, overflow_queue](
            const std::shared_ptr<const void>& payload,
            const detail::ArrivalCursorState& state, const BigNat& slot,
            const ArrivalBinding& binding,
            DeterministicRng& rng)
        -> Result<detail::ProposedArrivalTransition> {
      auto proposal = ordinary(payload, state, slot, binding, rng);
      if (!proposal || !(slot == failure_slot)) {
        return proposal;
      }
      auto maximum = ArrivalAtom::make(
          overflow_queue,
          BigNat(static_cast<std::uint64_t>(
              std::numeric_limits<std::int64_t>::max())),
          binding);
      auto one = ArrivalAtom::make(overflow_queue, BigNat(1U), binding);
      if (!maximum || !one) {
        return Result<detail::ProposedArrivalTransition>::failure(
            !maximum ? maximum.error() : one.error());
      }
      try {
        proposal.value().atoms.push_back(std::move(maximum).value());
        proposal.value().atoms.push_back(std::move(one).value());
        return proposal;
      } catch (const std::bad_alloc&) {
        return allocation_fail<detail::ProposedArrivalTransition>(
            "injecting the shared-round overflow fixture atoms");
      } catch (const std::length_error&) {
        return fail<detail::ProposedArrivalTransition>(
            DiagnosticCategory::resource_limit,
            "shared_round_fixture_representation_failure",
            "the shared-round overflow fixture exceeded a host container "
            "limit");
      }
    };
    append_string(product.value().canonical_law_data,
                  "mwperf.c11.shared_round.overflow_fixture");
    append_big_nat(product.value().canonical_law_data, failure_slot);
    return product;
  };
  AuthoredArrivalConfig wrapped{AuthoredArrivalVariant{authored},
                                authored.provenance};
  return detail::compile_arrival_law_with_registry(wrapped, queues,
                                                   registry);
}

}  // namespace testing
#endif

}  // namespace mwperf
