#include "mwperf/arrival/renewal.hpp"

#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/registry.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "core_internal.hpp"

namespace mwperf {
namespace {

static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));

template <class... Callables>
struct Overloaded : Callables... {
  using Callables::operator()...;
};
template <class... Callables>
Overloaded(Callables...) -> Overloaded<Callables...>;

[[nodiscard]] Diagnostic diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  std::optional<std::string> path;
  std::optional<std::string> pointer;
  if (provenance.has_value()) {
    pointer = provenance->json_pointer;
    if (provenance->location.has_value()) {
      path = provenance->location->authored_path;
      notes.insert(notes.begin(),
                   "line " +
                       std::to_string(provenance->location->line) +
                       ", column " +
                       std::to_string(provenance->location->column));
    }
  }
  return Diagnostic{category, std::move(code), std::move(message),
                    std::move(path), std::move(pointer), std::move(notes)};
}

template <typename Value>
[[nodiscard]] Result<Value> input_failure(
    std::string code, std::string message,
    const std::optional<ModelProvenance>& provenance = std::nullopt,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(
      diagnostic(DiagnosticCategory::input_validation, std::move(code),
                 std::move(message), provenance, std::move(notes)));
}

template <typename Value>
[[nodiscard]] Result<Value> internal_failure(std::string code,
                                             std::string message) {
  return Result<Value>::failure(
      diagnostic(DiagnosticCategory::internal, std::move(code),
                 std::move(message)));
}

template <typename Value>
[[nodiscard]] Result<Value> allocation_failure(std::string operation) {
  return Result<Value>::failure(diagnostic(
      DiagnosticCategory::resource_limit,
      "renewal_arrival_allocation_failure",
      "memory allocation failed while " + std::move(operation)));
}

template <typename Value>
[[nodiscard]] Result<Value> representation_failure(std::string message) {
  return Result<Value>::failure(diagnostic(
      DiagnosticCategory::resource_limit,
      "renewal_arrival_representation_failure", std::move(message)));
}

[[nodiscard]] Result<void> append_normalized_row(
    std::vector<NormalizedArrivalRow>& rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::span<const AuthoredProbability> probabilities) {
  auto normalized = validate_and_normalize_pmf(
      probabilities, physical_pmf_tolerance());
  if (!normalized) {
    return Result<void>::failure(normalized.error());
  }
  rows.push_back(NormalizedArrivalRow{
      .kind = kind,
      .source_ordinal = source_ordinal,
      .state_ordinal = 0U,
      .pmf = std::move(normalized).value(),
  });
  return Result<void>::success();
}

template <typename Record, typename Projection>
[[nodiscard]] Result<void> normalize_record_row(
    std::vector<NormalizedArrivalRow>& rows,
    const ArrivalCategoricalRowKind kind, const std::size_t source_ordinal,
    const std::span<const Record> records, Projection&& probability_of) {
  std::vector<AuthoredProbability> probabilities;
  probabilities.reserve(records.size());
  for (const Record& record : records) {
    probabilities.push_back(probability_of(record));
  }
  return append_normalized_row(rows, kind, source_ordinal, probabilities);
}

[[nodiscard]] Result<void> normalize_interarrival_row(
    std::vector<NormalizedArrivalRow>& rows,
    const AuthoredInterarrival& interarrival,
    const std::size_t source_ordinal) {
  return std::visit(
      Overloaded{
          [](const DeterministicInterarrival&) {
            return Result<void>::success();
          },
          [&](const FinitePmfInterarrival& finite) {
            return normalize_record_row(
                rows, ArrivalCategoricalRowKind::finite_interarrival,
                source_ordinal,
                std::span<const GapProbability>(finite.outcomes.value),
                [](const GapProbability& mass) {
                  return mass.probability.value;
                });
          },
          [&](const GeometricGridInterarrival& geometric) {
            std::vector<AuthoredProbability> probabilities;
            probabilities.reserve(2U);
            probabilities.push_back(geometric.p.value);
            auto complement = AuthoredProbability::from_exact(
                ExactRational::one() -
                geometric.p.value.exact_value());
            if (!complement) {
              return Result<void>::failure(complement.error());
            }
            probabilities.push_back(std::move(complement).value());
            return append_normalized_row(
                rows, ArrivalCategoricalRowKind::geometric_trial,
                source_ordinal, probabilities);
          },
      },
      interarrival);
}

[[nodiscard]] Result<std::vector<NormalizedArrivalRow>>
normalize_renewal_rows(const IndependentMarkedRenewalArrival& authored) {
  try {
    std::vector<NormalizedArrivalRow> rows;
    for (std::size_t source_ordinal = 0U;
         source_ordinal < authored.sources.value.size(); ++source_ordinal) {
      const MarkedRenewalSource& source =
          authored.sources.value[source_ordinal];
      auto normalized = std::visit(
          Overloaded{
              [&](const FactorizedRenewalSource& factorized) {
                auto gap = normalize_interarrival_row(
                    rows, factorized.interarrival.value, source_ordinal);
                if (!gap) {
                  return gap;
                }
                return normalize_record_row(
                    rows, ArrivalCategoricalRowKind::destination,
                    source_ordinal,
                    std::span<const DestinationProbability>(
                        factorized.destination_pmf.value),
                    [](const DestinationProbability& mass) {
                      return mass.probability.value;
                    });
              },
              [&](const JointRenewalSource& joint) {
                return normalize_record_row(
                    rows,
                    ArrivalCategoricalRowKind::joint_gap_destination,
                    source_ordinal,
                    std::span<const JointRenewalMass>(joint.joint_pmf.value),
                    [](const JointRenewalMass& mass) {
                      return mass.probability.value;
                    });
              },
          },
          source);
      if (!normalized) {
        return Result<std::vector<NormalizedArrivalRow>>::failure(
            normalized.error());
      }
    }
    return Result<std::vector<NormalizedArrivalRow>>::success(
        std::move(rows));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<NormalizedArrivalRow>>(
        "normalizing independent marked-renewal rows");
  } catch (const std::length_error&) {
    return representation_failure<std::vector<NormalizedArrivalRow>>(
        "the normalized marked-renewal row table exceeds a host container "
        "limit");
  } catch (const std::exception&) {
    return internal_failure<std::vector<NormalizedArrivalRow>>(
        "renewal_normalization_invariant_failure",
        "marked-renewal row normalization violated an exact representation "
        "invariant");
  }
}

class NormalizedRowCursor final {
 public:
  explicit NormalizedRowCursor(
      const std::span<const NormalizedArrivalRow> rows) noexcept
      : rows_(rows) {}

  [[nodiscard]] Result<NormalizedPmf> consume(
      const ArrivalCategoricalRowKind expected_kind,
      const std::size_t expected_source,
      const std::span<const AuthoredProbability> authored_probabilities) {
    if (position_ >= rows_.size()) {
      return internal_failure<NormalizedPmf>(
          "renewal_normalized_row_missing",
          "the marked-renewal compiler did not receive every categorical "
          "row prepared by the common arrival boundary");
    }
    const NormalizedArrivalRow& row = rows_[position_];
    if (row.kind != expected_kind ||
        row.source_ordinal != expected_source || row.state_ordinal != 0U) {
      return internal_failure<NormalizedPmf>(
          "renewal_normalized_row_order_mismatch",
          "a marked-renewal categorical row has the wrong kind, source, or "
          "significant authored position");
    }
    if (row.pmf.size() != authored_probabilities.size() ||
        row.pmf.authored_probabilities().size() !=
            authored_probabilities.size()) {
      return internal_failure<NormalizedPmf>(
          "renewal_normalized_row_dimension_mismatch",
          "a marked-renewal categorical row does not match its authored "
          "coordinate count");
    }
    for (std::size_t index = 0U; index < authored_probabilities.size();
         ++index) {
      if (!(row.pmf.authored_probabilities()[index].exact_value() ==
            authored_probabilities[index].exact_value())) {
        return internal_failure<NormalizedPmf>(
            "renewal_normalized_row_coordinate_mismatch",
            "a marked-renewal categorical row changed an authored "
            "probability coordinate or its significant order");
      }
    }
    ++position_;
    return Result<NormalizedPmf>::success(row.pmf);
  }

  [[nodiscard]] bool exhausted() const noexcept {
    return position_ == rows_.size();
  }

 private:
  std::span<const NormalizedArrivalRow> rows_;
  std::size_t position_{0U};
};

struct RenewalCompilationData final {
  std::size_t queue_count;
  QueueCatalogDigest catalog_digest;
  std::vector<RenewalLawSource> sources;
};

[[nodiscard]] Result<void> validate_source_id(
    const NormalizedToken& id, std::set<std::string>& seen) {
  if (id.value.empty()) {
    return input_failure<void>(
        "renewal_source_id_invalid",
        "a marked-renewal source must have a nonempty normalized "
        "identifier",
        id.provenance);
  }
  if (!seen.insert(id.value).second) {
    return input_failure<void>(
        "renewal_duplicate_source_id",
        "marked-renewal source identifiers must be unique after "
        "normalization",
        id.provenance, {"duplicate source: " + id.value});
  }
  return Result<void>::success();
}

[[nodiscard]] Result<RenewalGapLaw> compile_gap_law(
    const AuthoredInterarrival& authored, const std::size_t source_ordinal,
    NormalizedRowCursor& rows) {
  return std::visit(
      Overloaded{
          [&](const DeterministicInterarrival& deterministic)
              -> Result<RenewalGapLaw> {
            if (deterministic.d.value.is_zero()) {
              return input_failure<RenewalGapLaw>(
                  "renewal_gap_nonpositive",
                  "a marked-renewal interarrival gap must be strictly "
                  "positive",
                  deterministic.d.provenance);
            }
            return Result<RenewalGapLaw>::success(
                DeterministicRenewalGap{deterministic.d.value});
          },
          [&](const FinitePmfInterarrival& finite)
              -> Result<RenewalGapLaw> {
            std::vector<AuthoredProbability> authored_probabilities;
            authored_probabilities.reserve(finite.outcomes.value.size());
            for (const GapProbability& outcome : finite.outcomes.value) {
              authored_probabilities.push_back(outcome.probability.value);
            }
            auto probabilities = rows.consume(
                ArrivalCategoricalRowKind::finite_interarrival,
                source_ordinal, authored_probabilities);
            if (!probabilities) {
              return Result<RenewalGapLaw>::failure(probabilities.error());
            }
            std::vector<BigNat> gaps;
            gaps.reserve(finite.outcomes.value.size());
            std::set<BigNat> seen_gaps;
            for (const GapProbability& outcome : finite.outcomes.value) {
              if (outcome.d.value.is_zero()) {
                return input_failure<RenewalGapLaw>(
                    "renewal_gap_nonpositive",
                    "a finite marked-renewal gap must be strictly positive",
                    outcome.d.provenance);
              }
              if (!seen_gaps.insert(outcome.d.value).second) {
                return input_failure<RenewalGapLaw>(
                    "renewal_duplicate_gap_coordinate",
                    "finite marked-renewal gap coordinates must be unique",
                    outcome.d.provenance,
                    {"duplicate gap: " +
                     outcome.d.value.to_decimal_string()});
              }
              gaps.push_back(outcome.d.value);
            }
            return Result<RenewalGapLaw>::success(FiniteRenewalGap{
                std::move(gaps), std::move(probabilities).value()});
          },
          [&](const GeometricGridInterarrival& geometric)
              -> Result<RenewalGapLaw> {
            std::vector<AuthoredProbability> authored_probabilities;
            authored_probabilities.reserve(2U);
            authored_probabilities.push_back(geometric.p.value);
            auto complement = AuthoredProbability::from_exact(
                ExactRational::one() -
                geometric.p.value.exact_value());
            if (!complement) {
              return Result<RenewalGapLaw>::failure(complement.error());
            }
            authored_probabilities.push_back(
                std::move(complement).value());
            auto probabilities = rows.consume(
                ArrivalCategoricalRowKind::geometric_trial,
                source_ordinal, authored_probabilities);
            if (!probabilities) {
              return Result<RenewalGapLaw>::failure(probabilities.error());
            }
            if (geometric.d_min.value.is_zero() ||
                geometric.delta.value.is_zero()) {
              return input_failure<RenewalGapLaw>(
                  "renewal_geometric_grid_invalid",
                  "a geometric-grid marked renewal requires positive d_min "
                  "and delta",
                  geometric.provenance);
            }
            if (!geometric.p.value.exact_value().is_positive()) {
              return input_failure<RenewalGapLaw>(
                  "renewal_geometric_probability_invalid",
                  "a geometric-grid success probability must lie in the "
                  "exact interval (0,1]",
                  geometric.p.provenance);
            }
            return Result<RenewalGapLaw>::success(
                GeometricGridRenewalGap{
                    geometric.d_min.value, geometric.delta.value,
                    std::move(probabilities).value()});
          },
      },
      authored);
}

struct CompiledDestinations final {
  std::vector<DenseQueueIndex> coordinates;
  NormalizedPmf probabilities;
};

[[nodiscard]] Result<CompiledDestinations> compile_destinations(
    const std::span<const DestinationProbability> authored,
    const std::size_t source_ordinal, const QueueCatalog& queues,
    NormalizedRowCursor& rows) {
  std::vector<AuthoredProbability> authored_probabilities;
  authored_probabilities.reserve(authored.size());
  for (const DestinationProbability& coordinate : authored) {
    authored_probabilities.push_back(coordinate.probability.value);
  }
  auto probabilities = rows.consume(
      ArrivalCategoricalRowKind::destination, source_ordinal,
      authored_probabilities);
  if (!probabilities) {
    return Result<CompiledDestinations>::failure(probabilities.error());
  }

  std::vector<DenseQueueIndex> destinations;
  destinations.reserve(authored.size());
  std::set<std::size_t> seen;
  for (const DestinationProbability& coordinate : authored) {
    auto destination = queues.resolve(coordinate.queue_id.value,
                                      coordinate.queue_id.provenance);
    if (!destination) {
      return Result<CompiledDestinations>::failure(destination.error());
    }
    if (!seen.insert(destination.value().ordinal()).second) {
      return input_failure<CompiledDestinations>(
          "renewal_duplicate_destination_coordinate",
          "a factorized marked-renewal destination row must not repeat a "
          "queue coordinate",
          coordinate.queue_id.provenance);
    }
    destinations.push_back(destination.value());
  }
  return Result<CompiledDestinations>::success(CompiledDestinations{
      std::move(destinations), std::move(probabilities).value()});
}

[[nodiscard]] Result<RenewalLawSource> compile_factorized_source(
    const FactorizedRenewalSource& authored,
    const std::size_t source_ordinal, const QueueCatalog& queues,
    NormalizedRowCursor& rows) {
  auto gap = compile_gap_law(authored.interarrival.value, source_ordinal,
                             rows);
  if (!gap) {
    return Result<RenewalLawSource>::failure(gap.error());
  }
  auto destinations = compile_destinations(
      authored.destination_pmf.value, source_ordinal, queues, rows);
  if (!destinations) {
    return Result<RenewalLawSource>::failure(destinations.error());
  }
  return Result<RenewalLawSource>::success(FactorizedRenewalLawSource{
      authored.id.value, std::move(gap).value(),
      std::move(destinations.value().coordinates),
      std::move(destinations.value().probabilities)});
}

[[nodiscard]] Result<RenewalLawSource> compile_joint_source(
    const JointRenewalSource& authored, const std::size_t source_ordinal,
    const QueueCatalog& queues, NormalizedRowCursor& rows) {
  std::vector<AuthoredProbability> authored_probabilities;
  authored_probabilities.reserve(authored.joint_pmf.value.size());
  for (const JointRenewalMass& coordinate : authored.joint_pmf.value) {
    authored_probabilities.push_back(coordinate.probability.value);
  }
  auto probabilities = rows.consume(
      ArrivalCategoricalRowKind::joint_gap_destination, source_ordinal,
      authored_probabilities);
  if (!probabilities) {
    return Result<RenewalLawSource>::failure(probabilities.error());
  }

  std::vector<JointRenewalOutcome> outcomes;
  outcomes.reserve(authored.joint_pmf.value.size());
  std::set<std::pair<BigNat, std::size_t>> seen;
  for (const JointRenewalMass& coordinate : authored.joint_pmf.value) {
    if (coordinate.d.value.is_zero()) {
      return input_failure<RenewalLawSource>(
          "renewal_gap_nonpositive",
          "a joint marked-renewal gap must be strictly positive",
          coordinate.d.provenance);
    }
    auto destination = queues.resolve(coordinate.queue_id.value,
                                      coordinate.queue_id.provenance);
    if (!destination) {
      return Result<RenewalLawSource>::failure(destination.error());
    }
    const auto key =
        std::make_pair(coordinate.d.value, destination.value().ordinal());
    if (!seen.insert(key).second) {
      return input_failure<RenewalLawSource>(
          "renewal_duplicate_joint_coordinate",
          "complete joint (gap,destination) coordinates must be unique",
          coordinate.provenance,
          {"duplicate gap: " + coordinate.d.value.to_decimal_string(),
           "duplicate destination ordinal: " +
               std::to_string(destination.value().ordinal())});
    }
    outcomes.push_back(
        JointRenewalOutcome{coordinate.d.value, destination.value()});
  }
  return Result<RenewalLawSource>::success(JointRenewalLawSource{
      authored.id.value, std::move(outcomes),
      std::move(probabilities).value()});
}

[[nodiscard]] Result<RenewalCompilationData> compile_renewal_geometry(
    const IndependentMarkedRenewalArrival& authored,
    const QueueCatalog& queues,
    const std::span<const NormalizedArrivalRow> normalized_rows) {
  if (authored.sources.value.empty()) {
    return input_failure<RenewalCompilationData>(
        "renewal_sources_empty",
        "an independent marked-renewal law requires at least one source",
        authored.sources.provenance);
  }

  auto catalog_digest = detail::digest_queue_catalog(queues);
  if (!catalog_digest) {
    return Result<RenewalCompilationData>::failure(catalog_digest.error());
  }

  NormalizedRowCursor rows(normalized_rows);
  std::set<std::string> source_ids;
  std::vector<RenewalLawSource> sources;
  sources.reserve(authored.sources.value.size());
  for (std::size_t source_ordinal = 0U;
       source_ordinal < authored.sources.value.size(); ++source_ordinal) {
    const MarkedRenewalSource& source =
        authored.sources.value[source_ordinal];
    const NormalizedToken* id = std::visit(
        [](const auto& value) -> const NormalizedToken* {
          return &value.id;
        },
        source);
    auto valid_id = validate_source_id(*id, source_ids);
    if (!valid_id) {
      return Result<RenewalCompilationData>::failure(valid_id.error());
    }

    auto compiled = std::visit(
        Overloaded{
            [&](const FactorizedRenewalSource& factorized) {
              return compile_factorized_source(
                  factorized, source_ordinal, queues, rows);
            },
            [&](const JointRenewalSource& joint) {
              return compile_joint_source(joint, source_ordinal, queues,
                                          rows);
            },
        },
        source);
    if (!compiled) {
      return Result<RenewalCompilationData>::failure(compiled.error());
    }
    sources.push_back(std::move(compiled).value());
  }
  if (!rows.exhausted()) {
    return internal_failure<RenewalCompilationData>(
        "renewal_normalized_row_surplus",
        "the marked-renewal compiler received categorical rows not owned by "
        "the authored source table");
  }

  return Result<RenewalCompilationData>::success(RenewalCompilationData{
      queues.size(), std::move(catalog_digest).value(),
      std::move(sources)});
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT32_C(0xff)));
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT64_C(0xff)));
  }
}

void append_string(std::vector<std::byte>& output,
                   const std::string_view value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  for (const char character : value) {
    output.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> magnitude =
      value.canonical_magnitude_bytes();
  append_u64(output, static_cast<std::uint64_t>(magnitude.size()));
  for (const std::uint8_t byte : magnitude) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

void append_rational(std::vector<std::byte>& output,
                     const ExactRational& value) {
  append_string(output, value.numerator_decimal());
  append_string(output, value.denominator_decimal());
}

void append_pmf(std::vector<std::byte>& output, const NormalizedPmf& pmf) {
  append_u64(output, static_cast<std::uint64_t>(pmf.size()));
  for (const AuthoredProbability& probability :
       pmf.authored_probabilities()) {
    append_rational(output, probability.exact_value());
  }
  append_rational(output, pmf.authored_sum());
  append_rational(output, pmf.normalization_delta());
  for (const ExactRational& weight : pmf.normalized_weights()) {
    append_rational(output, weight);
  }
  for (const BigNat& mass : pmf.integral_masses()) {
    append_big_nat(output, mass);
  }
  for (const BigNat& cumulative : pmf.cumulative_masses()) {
    append_big_nat(output, cumulative);
  }
  append_big_nat(output, pmf.integral_denominator());
  append_u64(output,
             static_cast<std::uint64_t>(pmf.sampling_bit_width()));
  append_u64(output,
             static_cast<std::uint64_t>(pmf.sampling_limb_count()));
}

void append_gap_law(std::vector<std::byte>& output,
                    const RenewalGapLaw& gap) {
  std::visit(
      Overloaded{
          [&](const DeterministicRenewalGap& deterministic) {
            output.push_back(std::byte{0});
            append_big_nat(output, deterministic.gap);
          },
          [&](const FiniteRenewalGap& finite) {
            output.push_back(std::byte{1});
            append_u64(output,
                       static_cast<std::uint64_t>(finite.gaps.size()));
            for (const BigNat& coordinate : finite.gaps) {
              append_big_nat(output, coordinate);
            }
            append_pmf(output, finite.probabilities);
          },
          [&](const GeometricGridRenewalGap& geometric) {
            output.push_back(std::byte{2});
            append_big_nat(output, geometric.d_min);
            append_big_nat(output, geometric.delta);
            append_pmf(output, geometric.trial_probabilities);
          },
      },
      gap);
}

[[nodiscard]] Result<std::vector<std::byte>> encode_renewal_law(
    const RenewalLaw& law) {
  try {
    static constexpr std::string_view kDomain =
        "mwperf.c11.independent_marked_renewal.v1";
    std::vector<std::byte> encoded;
    append_string(encoded, kDomain);
    append_u32(encoded, 1U);
    append_u64(encoded, static_cast<std::uint64_t>(law.queue_count()));
    append_u64(encoded,
               static_cast<std::uint64_t>(law.sources().size()));
    for (const RenewalLawSource& source : law.sources()) {
      std::visit(
          Overloaded{
              [&](const FactorizedRenewalLawSource& factorized) {
                encoded.push_back(std::byte{0});
                append_string(encoded, factorized.source_id);
                append_gap_law(encoded, factorized.interarrival);
                append_u64(encoded, static_cast<std::uint64_t>(
                                        factorized.destinations.size()));
                for (const DenseQueueIndex destination :
                     factorized.destinations) {
                  append_u64(encoded, static_cast<std::uint64_t>(
                                          destination.ordinal()));
                }
                append_pmf(encoded,
                           factorized.destination_probabilities);
              },
              [&](const JointRenewalLawSource& joint) {
                encoded.push_back(std::byte{1});
                append_string(encoded, joint.source_id);
                append_u64(encoded,
                           static_cast<std::uint64_t>(joint.outcomes.size()));
                for (const JointRenewalOutcome& outcome : joint.outcomes) {
                  append_big_nat(encoded, outcome.gap);
                  append_u64(encoded, static_cast<std::uint64_t>(
                                          outcome.destination.ordinal()));
                }
                append_pmf(encoded, joint.probabilities);
              },
          },
          source);
    }
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<std::byte>>(
        "encoding an independent marked-renewal law");
  } catch (const std::length_error&) {
    return representation_failure<std::vector<std::byte>>(
        "the encoded marked-renewal law exceeds a host container limit");
  }
}

struct SampledRenewalPair final {
  BigNat gap;
  DenseQueueIndex destination;
};

[[nodiscard]] Result<BigNat> sample_gap(const RenewalGapLaw& law,
                                        DeterministicRng& rng) {
  return std::visit(
      Overloaded{
          [](const DeterministicRenewalGap& deterministic) {
            return Result<BigNat>::success(deterministic.gap);
          },
          [&](const FiniteRenewalGap& finite) {
            const std::size_t selected =
                sample_categorical(finite.probabilities, rng);
            if (selected >= finite.gaps.size()) {
              return internal_failure<BigNat>(
                  "renewal_gap_sample_out_of_range",
                  "categorical sampling selected a finite renewal-gap "
                  "coordinate outside its immutable table");
            }
            return Result<BigNat>::success(finite.gaps[selected]);
          },
          [&](const GeometricGridRenewalGap& geometric) {
            BigNat failures(0U);
            for (;;) {
              const std::size_t selected =
                  sample_categorical(geometric.trial_probabilities, rng);
              if (selected == 0U) {
                BigNat offset = geometric.delta * failures;
                return Result<BigNat>::success(geometric.d_min + offset);
              }
              if (selected != 1U) {
                return internal_failure<BigNat>(
                    "renewal_geometric_sample_out_of_range",
                    "geometric-grid sampling selected a coordinate outside "
                    "the fixed [success,failure] row");
              }
              ++failures;
            }
          },
      },
      law);
}

[[nodiscard]] Result<SampledRenewalPair> sample_pair(
    const RenewalLawSource& law, DeterministicRng& rng) {
  return std::visit(
      Overloaded{
          [&](const FactorizedRenewalLawSource& factorized)
              -> Result<SampledRenewalPair> {
            auto gap = sample_gap(factorized.interarrival, rng);
            if (!gap) {
              return Result<SampledRenewalPair>::failure(gap.error());
            }
            const std::size_t selected = sample_categorical(
                factorized.destination_probabilities, rng);
            if (selected >= factorized.destinations.size()) {
              return internal_failure<SampledRenewalPair>(
                  "renewal_destination_sample_out_of_range",
                  "categorical sampling selected a destination outside its "
                  "immutable factorized row");
            }
            return Result<SampledRenewalPair>::success(SampledRenewalPair{
                std::move(gap).value(), factorized.destinations[selected]});
          },
          [&](const JointRenewalLawSource& joint)
              -> Result<SampledRenewalPair> {
            const std::size_t selected =
                sample_categorical(joint.probabilities, rng);
            if (selected >= joint.outcomes.size()) {
              return internal_failure<SampledRenewalPair>(
                  "renewal_joint_sample_out_of_range",
                  "categorical sampling selected a joint renewal outcome "
                  "outside its immutable row");
            }
            const JointRenewalOutcome& outcome = joint.outcomes[selected];
            return Result<SampledRenewalPair>::success(
                SampledRenewalPair{outcome.gap, outcome.destination});
          },
      },
      law);
}

struct RenewalPendingSource final {
  BigNat next_slot;
  DenseQueueIndex pending_destination;
};

struct RenewalCursorState final {
  std::vector<RenewalPendingSource> sources;
};

[[nodiscard]] bool source_supports_destination(
    const RenewalLawSource& source,
    const DenseQueueIndex destination) noexcept {
  return std::visit(
      Overloaded{
          [&](const FactorizedRenewalLawSource& factorized) {
            for (std::size_t index = 0U;
                 index < factorized.destinations.size(); ++index) {
              if (factorized.destinations[index] == destination &&
                  factorized.destination_probabilities.normalized_weights()
                      [index]
                          .is_positive()) {
                return true;
              }
            }
            return false;
          },
          [&](const JointRenewalLawSource& joint) {
            for (std::size_t index = 0U; index < joint.outcomes.size();
                 ++index) {
              if (joint.outcomes[index].destination == destination &&
                  joint.probabilities.normalized_weights()[index]
                      .is_positive()) {
                return true;
              }
            }
            return false;
          },
      },
      source);
}

[[nodiscard]] Result<void> validate_cursor_shape(
    const RenewalLaw& law, const RenewalCursorState& cursor) {
  if (cursor.sources.size() != law.sources().size()) {
    return internal_failure<void>(
        "renewal_cursor_source_count_mismatch",
        "a marked-renewal cursor does not contain exactly one clock and "
        "pending mark for every source");
  }
  for (std::size_t index = 0U; index < cursor.sources.size(); ++index) {
    const RenewalPendingSource& pending = cursor.sources[index];
    if (pending.pending_destination.ordinal() >= law.queue_count() ||
        !source_supports_destination(law.sources()[index],
                                     pending.pending_destination)) {
      return internal_failure<void>(
          "renewal_cursor_pending_mark_invalid",
          "a marked-renewal cursor contains a pending destination outside "
          "its source's exact positive support");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_runtime_binding(
    const RenewalLaw& law, const ArrivalBinding& binding) {
  if (binding.family != ArrivalFamily::independent_marked_renewal ||
      binding.timing != TimingConvention::early_service_late_admission ||
      binding.queue_cardinality != law.queue_count() ||
      !(binding.catalog_digest == law.catalog_digest())) {
    return internal_failure<void>(
        "renewal_runtime_binding_mismatch",
        "the marked-renewal runtime received a law, family, timing, or "
        "queue-catalog binding inconsistent with its immutable payload");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_renewal_initial_state(
    const ArrivalInitialState& state) {
  if (!std::holds_alternative<RenewalOrigin>(state)) {
    return input_failure<void>(
        "arrival_initial_family_mismatch",
        "an independent marked-renewal law requires renewal_origin");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<detail::ArrivalCursorInitialization>
instantiate_renewal_cursor(const RenewalLaw& law,
                           const ArrivalInitialState& initial,
                           DeterministicRng& rng) {
  auto valid_initial = validate_renewal_initial_state(initial);
  if (!valid_initial) {
    return Result<detail::ArrivalCursorInitialization>::failure(
        valid_initial.error());
  }
  try {
    std::vector<RenewalPendingSource> pending;
    pending.reserve(law.sources().size());
    const BigNat one(1U);
    for (const RenewalLawSource& source : law.sources()) {
      auto pair = sample_pair(source, rng);
      if (!pair) {
        return Result<detail::ArrivalCursorInitialization>::failure(
            pair.error());
      }
      auto first_slot = checked_subtract(pair.value().gap, one);
      if (!first_slot) {
        return internal_failure<detail::ArrivalCursorInitialization>(
            "renewal_first_clock_invariant_failure",
            "a validated positive renewal gap could not be placed relative "
            "to the exact pre-first-event sentinel -1");
      }
      pending.push_back(RenewalPendingSource{
          std::move(first_slot).value(), pair.value().destination});
    }
    auto cursor = std::make_shared<const RenewalCursorState>(
        RenewalCursorState{std::move(pending)});
    return Result<detail::ArrivalCursorInitialization>::success(
        detail::ArrivalCursorInitialization{std::move(cursor)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ArrivalCursorInitialization>(
        "instantiating an independent marked-renewal cursor");
  } catch (const std::length_error&) {
    return representation_failure<detail::ArrivalCursorInitialization>(
        "the marked-renewal cursor exceeds a host container limit");
  } catch (const std::exception&) {
    return internal_failure<detail::ArrivalCursorInitialization>(
        "renewal_cursor_initialization_invariant_failure",
        "independent marked-renewal cursor initialization violated an exact "
        "sampling invariant");
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_renewal_phase(
    const RenewalLaw& law, const detail::ArrivalCursorState& erased) {
  const auto cursor =
      std::static_pointer_cast<const RenewalCursorState>(erased);
  if (!cursor) {
    return internal_failure<std::vector<std::byte>>(
        "renewal_cursor_state_missing",
        "the marked-renewal cursor has no predictive state");
  }
  auto valid = validate_cursor_shape(law, *cursor);
  if (!valid) {
    return Result<std::vector<std::byte>>::failure(valid.error());
  }
  try {
    static constexpr std::string_view kDomain =
        "mwperf.c11.independent_marked_renewal.phase.v1";
    std::vector<std::byte> encoded;
    append_string(encoded, kDomain);
    append_u32(encoded, 1U);
    encoded.push_back(static_cast<std::byte>(
        ArrivalFamily::independent_marked_renewal));
    append_u64(encoded,
               static_cast<std::uint64_t>(cursor->sources.size()));
    for (const RenewalPendingSource& pending : cursor->sources) {
      append_big_nat(encoded, pending.next_slot);
      append_u64(encoded, static_cast<std::uint64_t>(
                              pending.pending_destination.ordinal()));
    }
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<std::byte>>(
        "encoding an independent marked-renewal predictive phase");
  } catch (const std::length_error&) {
    return representation_failure<std::vector<std::byte>>(
        "the marked-renewal predictive phase exceeds a host container "
        "limit");
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition>
propose_renewal_transition(const RenewalLaw& law,
                           const detail::ArrivalCursorState& erased,
                           const BigNat& authored_slot,
                           const ArrivalBinding& binding,
                           DeterministicRng& rng) {
  auto valid_binding = validate_runtime_binding(law, binding);
  if (!valid_binding) {
    return Result<detail::ProposedArrivalTransition>::failure(
        valid_binding.error());
  }
  const auto cursor =
      std::static_pointer_cast<const RenewalCursorState>(erased);
  if (!cursor) {
    return internal_failure<detail::ProposedArrivalTransition>(
        "renewal_cursor_state_missing",
        "the marked-renewal transition received no cursor state");
  }
  auto valid = validate_cursor_shape(law, *cursor);
  if (!valid) {
    return Result<detail::ProposedArrivalTransition>::failure(valid.error());
  }

  try {
    std::vector<RenewalPendingSource> successor_sources = cursor->sources;
    std::vector<ArrivalAtom> atoms;
    atoms.reserve(cursor->sources.size());
    for (std::size_t source_ordinal = 0U;
         source_ordinal < cursor->sources.size(); ++source_ordinal) {
      const RenewalPendingSource& current = cursor->sources[source_ordinal];
      if (current.next_slot < authored_slot) {
        return internal_failure<detail::ProposedArrivalTransition>(
            "renewal_pending_event_stale",
            "a marked-renewal cursor contains a pending event below the "
            "requested exact slot");
      }
      if (!(current.next_slot == authored_slot)) {
        continue;
      }

      auto atom = ArrivalAtom::make(current.pending_destination, BigNat(1U),
                                    binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(
            atom.error());
      }
      atoms.push_back(std::move(atom).value());

      auto next = sample_pair(law.sources()[source_ordinal], rng);
      if (!next) {
        return Result<detail::ProposedArrivalTransition>::failure(
            next.error());
      }
      successor_sources[source_ordinal].next_slot += next.value().gap;
      successor_sources[source_ordinal].pending_destination =
          next.value().destination;
    }

    auto successor = std::make_shared<const RenewalCursorState>(
        RenewalCursorState{std::move(successor_sources)});
    return Result<detail::ProposedArrivalTransition>::success(
        detail::ProposedArrivalTransition{std::move(successor),
                                          std::move(atoms)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<detail::ProposedArrivalTransition>(
        "advancing an independent marked-renewal cursor");
  } catch (const std::length_error&) {
    return representation_failure<detail::ProposedArrivalTransition>(
        "a marked-renewal transition exceeds a host container limit");
  } catch (const std::exception&) {
    return internal_failure<detail::ProposedArrivalTransition>(
        "renewal_transition_invariant_failure",
        "an independent marked-renewal transition violated an exact "
        "sampling invariant");
  }
}

[[nodiscard]] std::vector<std::uint8_t> exact_positive_support(
    const RenewalLaw& law) {
  std::vector<std::uint8_t> support(law.queue_count(), 0U);
  for (const RenewalLawSource& source : law.sources()) {
    std::visit(
        Overloaded{
            [&](const FactorizedRenewalLawSource& factorized) {
              for (std::size_t index = 0U;
                   index < factorized.destinations.size(); ++index) {
                if (factorized.destination_probabilities.normalized_weights()
                        [index]
                            .is_positive()) {
                  support[factorized.destinations[index].ordinal()] = 1U;
                }
              }
            },
            [&](const JointRenewalLawSource& joint) {
              for (std::size_t index = 0U; index < joint.outcomes.size();
                   ++index) {
                if (joint.probabilities.normalized_weights()[index]
                        .is_positive()) {
                  support[joint.outcomes[index].destination.ordinal()] = 1U;
                }
              }
            },
        },
        source);
  }
  return support;
}

[[nodiscard]] ArrivalCapabilities renewal_capabilities() {
  ArrivalCapabilities capabilities;
  capabilities.exact_positive_support = CapabilityAvailability::available;
  capabilities.sequential_normalized_sampler =
      CapabilityAvailability::available;
  return capabilities;
}

// A factorized renewal source with D = 1 + F and unit grid spacing is exactly
// a Bernoulli trial in every slot.  The geometric memoryless law and the
// independently sampled destination mark therefore define a finite exact IID
// batch coordinate.  Publish that stronger fact whenever every source has
// this proved shape.  The compact generator proof and coordinate means are
// independent of whether the optional legacy Cartesian table fits its
// representation budget; the deployed renewal cursor and sampling order
// remain unchanged.
struct PortableMemorylessIidProjection final {
  std::optional<std::vector<ExactJointBatchMass>> joint_table;
  std::vector<ExactMomentDatum> coordinate_means;
};

struct MemorylessSourceOutcome final {
  std::optional<std::size_t> destination;
  ExactRational probability;
};

[[nodiscard]] std::optional<PortableMemorylessIidProjection>
project_memoryless_unit_grid_iid(const RenewalLaw& law,
                                 const QueueCatalog& queues) {
  // This is a capability projection, not a new representation requirement on
  // the physical law.  Keep the legacy portable table bounded, but do not let
  // that optional representation cap erase the exact compact IID fact.
  static constexpr std::size_t kMaximumProjectedSources = 64U;
  static constexpr std::size_t kMaximumProjectedAtoms = 65'536U;

  using DenseCounts = std::vector<BigNat>;
  std::optional<std::map<DenseCounts, ExactRational>> accumulated;
  if (law.sources().size() <= kMaximumProjectedSources) {
    accumulated.emplace();
    accumulated->emplace(DenseCounts(law.queue_count(), BigNat(0U)),
                         ExactRational::one());
  }
  std::vector<ExactRational> coordinate_means(
      law.queue_count(), ExactRational::zero());

  for (const RenewalLawSource& source : law.sources()) {
    const auto* factorized =
        std::get_if<FactorizedRenewalLawSource>(&source);
    if (factorized == nullptr) {
      return std::nullopt;
    }
    const auto* geometric =
        std::get_if<GeometricGridRenewalGap>(&factorized->interarrival);
    if (geometric == nullptr || geometric->d_min != BigNat(1U) ||
        geometric->delta != BigNat(1U) ||
        geometric->trial_probabilities.normalized_weights().size() != 2U ||
        factorized->destinations.size() !=
            factorized->destination_probabilities.normalized_weights()
                .size()) {
      return std::nullopt;
    }

    const ExactRational& success =
        geometric->trial_probabilities.normalized_weights()[0U];
    const ExactRational& failure =
        geometric->trial_probabilities.normalized_weights()[1U];
    std::vector<MemorylessSourceOutcome> outcomes;
    outcomes.reserve(factorized->destinations.size() + 1U);
    if (failure.is_positive()) {
      outcomes.push_back(MemorylessSourceOutcome{std::nullopt, failure});
    }
    for (std::size_t index = 0U;
         index < factorized->destinations.size(); ++index) {
      ExactRational probability =
          success * factorized->destination_probabilities
                        .normalized_weights()[index];
      if (!probability.is_positive()) {
        continue;
      }
      const std::size_t ordinal =
          factorized->destinations[index].ordinal();
      if (ordinal >= law.queue_count()) {
        return std::nullopt;
      }
      coordinate_means[ordinal] =
          coordinate_means[ordinal] + probability;
      outcomes.push_back(
          MemorylessSourceOutcome{ordinal, std::move(probability)});
    }
    if (outcomes.empty()) {
      return std::nullopt;
    }

    if (accumulated.has_value()) {
      std::map<DenseCounts, ExactRational> next;
      bool representation_limit_exceeded = false;
      for (const auto& [counts, prefix_probability] : *accumulated) {
        for (const MemorylessSourceOutcome& outcome : outcomes) {
          DenseCounts successor = counts;
          if (outcome.destination.has_value()) {
            ++successor[*outcome.destination];
          }
          ExactRational probability =
              prefix_probability * outcome.probability;
          auto [position, inserted] =
              next.emplace(std::move(successor), probability);
          if (!inserted) {
            position->second = position->second + probability;
          }
          if (next.size() > kMaximumProjectedAtoms) {
            representation_limit_exceeded = true;
            break;
          }
        }
        if (representation_limit_exceeded) {
          break;
        }
      }
      if (representation_limit_exceeded) {
        accumulated.reset();
      } else {
        accumulated = std::move(next);
      }
    }
  }

  PortableMemorylessIidProjection projection;
  if (accumulated.has_value()) {
    std::vector<ExactJointBatchMass> joint_table;
    joint_table.reserve(accumulated->size());
    for (auto& [counts, probability] : *accumulated) {
      if (probability.is_positive()) {
        joint_table.push_back(
            ExactJointBatchMass{std::move(counts), std::move(probability)});
      }
    }
    if (joint_table.empty()) {
      return std::nullopt;
    }
    projection.joint_table = std::move(joint_table);
  }
  projection.coordinate_means.reserve(law.queue_count());
  for (std::size_t ordinal = 0U; ordinal < law.queue_count(); ++ordinal) {
    auto coordinate = queues.index_at(ordinal);
    if (!coordinate) {
      return std::nullopt;
    }
    projection.coordinate_means.push_back(ExactMomentDatum{
        {coordinate.value()}, BigNat(1U),
        std::move(coordinate_means[ordinal])});
  }
  return projection;
}

}  // namespace

Result<RenewalLaw> compile_marked_renewal(
    const IndependentMarkedRenewalArrival& authored,
    const QueueCatalog& queues) {
  try {
    auto rows = normalize_renewal_rows(authored);
    if (!rows) {
      return Result<RenewalLaw>::failure(rows.error());
    }
    auto compiled = compile_renewal_geometry(authored, queues, rows.value());
    if (!compiled) {
      return Result<RenewalLaw>::failure(compiled.error());
    }
    return Result<RenewalLaw>::success(RenewalLaw{
        compiled.value().queue_count,
        std::move(compiled.value().catalog_digest),
        std::move(compiled.value().sources)});
  } catch (const std::bad_alloc&) {
    return allocation_failure<RenewalLaw>(
        "compiling an independent marked-renewal law");
  } catch (const std::length_error&) {
    return representation_failure<RenewalLaw>(
        "the compiled marked-renewal law exceeds a host container limit");
  } catch (const std::exception&) {
    return internal_failure<RenewalLaw>(
        "renewal_compilation_invariant_failure",
        "independent marked-renewal compilation violated an exact "
        "representation invariant");
  } catch (...) {
    return internal_failure<RenewalLaw>(
        "renewal_compilation_invariant_failure",
        "independent marked-renewal compilation raised a nonstandard "
        "exception");
  }
}

Result<ArrivalStep> next_marked_renewal_batch(
    RenewalCursor& cursor, const BigNat& authored_slot) {
  if (cursor.family() != ArrivalFamily::independent_marked_renewal) {
    return input_failure<ArrivalStep>(
        "arrival_renewal_cursor_family_mismatch",
        "next_marked_renewal_batch requires an independent marked-renewal "
        "arrival cursor");
  }
  return next_arrival_step(cursor, authored_slot);
}

namespace detail {

Result<CompiledArrivalProduct> compile_marked_renewal_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<IndependentMarkedRenewalArrival>(&request.authored.value);
  if (authored == nullptr) {
    return internal_failure<CompiledArrivalProduct>(
        "arrival_backend_authored_variant_mismatch",
        "the marked-renewal registry slot received another authored family");
  }

  try {
    // The common C09 boundary has already normalized these rows. This route
    // consumes that immutable sequence directly and never invokes the public
    // standalone compiler (which owns its own exactly-once normalization).
    auto compiled = compile_renewal_geometry(
        *authored, request.queues, request.normalized_rows);
    if (!compiled) {
      return Result<CompiledArrivalProduct>::failure(compiled.error());
    }
    RenewalLaw law(compiled.value().queue_count,
                   std::move(compiled.value().catalog_digest),
                   std::move(compiled.value().sources));
    auto canonical = encode_renewal_law(law);
    if (!canonical) {
      return Result<CompiledArrivalProduct>::failure(canonical.error());
    }
    auto payload = std::make_shared<const RenewalLaw>(std::move(law));
    std::vector<std::uint8_t> support = exact_positive_support(*payload);
    auto iid_projection =
        project_memoryless_unit_grid_iid(*payload, request.queues);
    ArrivalCapabilities capabilities = renewal_capabilities();
    std::optional<std::vector<ExactJointBatchMass>> iid_joint_table;
    std::optional<std::vector<ExactMomentDatum>> moments;
    if (iid_projection.has_value()) {
      capabilities.exact_factorized_iid_generator =
          ExactFactorizedIidGeneratorCapability{
              AccessProvision::portable_only};
      capabilities.exact_coordinate_moments = MomentCapability{
          BigNat(1U), false, false, AccessProvision::portable_only};
      moments = std::move(iid_projection->coordinate_means);
      if (iid_projection->joint_table.has_value()) {
        capabilities.exact_iid_joint_vector = ExactIidJointVectorCapability{
            true, AccessProvision::portable_only};
        iid_joint_table = std::move(*iid_projection->joint_table);
      }
    }

    ArrivalRuntimeAdapter runtime;
    runtime.validate_initial =
        [](const std::shared_ptr<const void>&,
           const ArrivalInitialState& state) {
          return validate_renewal_initial_state(state);
        };
    runtime.instantiate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalInitialState& state,
           DeterministicRng& rng) {
          const auto law =
              std::static_pointer_cast<const RenewalLaw>(erased);
          if (!law) {
            return internal_failure<ArrivalCursorInitialization>(
                "renewal_law_payload_missing",
                "the marked-renewal runtime has no immutable law payload");
          }
          return instantiate_renewal_cursor(*law, state, rng);
        };
    runtime.encode_phase =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state) {
          const auto law =
              std::static_pointer_cast<const RenewalLaw>(erased);
          if (!law) {
            return internal_failure<std::vector<std::byte>>(
                "renewal_law_payload_missing",
                "the marked-renewal runtime has no immutable law payload");
          }
          return encode_renewal_phase(*law, state);
        };
    runtime.propose =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& slot,
           const ArrivalBinding& binding,
           DeterministicRng& rng) {
          const auto law =
              std::static_pointer_cast<const RenewalLaw>(erased);
          if (!law) {
            return internal_failure<ProposedArrivalTransition>(
                "renewal_law_payload_missing",
                "the marked-renewal runtime has no immutable law payload");
          }
          return propose_renewal_transition(*law, state, slot, binding, rng);
        };

    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::independent_marked_renewal,
        .normalized_rows = {},
        .positive_support = std::move(support),
        .capabilities = std::move(capabilities),
        .canonical_law_data = std::move(canonical).value(),
        .portable_schema =
            PortableArrivalLawSchema::independent_marked_renewal_v1,
        .payload = std::move(payload),
        .runtime = std::move(runtime),
        .iid_joint_table = std::move(iid_joint_table),
        .moments = std::move(moments),
        .covariances = std::nullopt,
        .analytic_transform = std::nullopt,
        .joint_distribution = std::nullopt,
        .coordinate_distributions = std::nullopt,
        .replay_codec = std::nullopt,
        .unit_cube = std::nullopt,
        .finite_phase = std::nullopt,
        .transition_rows = std::nullopt,
        .stationary_phase_law = std::nullopt,
    });
  } catch (const std::bad_alloc&) {
    return allocation_failure<CompiledArrivalProduct>(
        "publishing an independent marked-renewal product");
  } catch (const std::length_error&) {
    return representation_failure<CompiledArrivalProduct>(
        "the marked-renewal product exceeds a host container limit");
  } catch (const std::exception&) {
    return internal_failure<CompiledArrivalProduct>(
        "renewal_product_invariant_failure",
        "publishing an independent marked-renewal product violated an exact "
        "representation invariant");
  } catch (...) {
    return internal_failure<CompiledArrivalProduct>(
        "renewal_product_invariant_failure",
        "publishing an independent marked-renewal product raised a "
        "nonstandard exception");
  }
}

}  // namespace detail

Result<std::vector<ExactTargetIidBatchMass>>
project_exact_factorized_iid_target_pmf(
    const CompiledArrivalLaw& law, const DenseQueueIndex target) {
  const auto core = detail::ArrivalCoreAccess::law_core(law);
  if (!core || law.family() != ArrivalFamily::independent_marked_renewal ||
      !core->capabilities.exact_factorized_iid_generator.has_value()) {
    return Result<std::vector<ExactTargetIidBatchMass>>::failure(diagnostic(
        DiagnosticCategory::unavailable,
        "renewal_factorized_iid_projection_unavailable",
        "the configured arrival does not publish an exact factorized IID "
        "marked-renewal generator"));
  }
  if (target.ordinal() >= core->binding.queue_cardinality) {
    return input_failure<std::vector<ExactTargetIidBatchMass>>(
        "renewal_factorized_iid_target_out_of_range",
        "the requested target coordinate is absent from the configured "
        "arrival queue catalog");
  }
  const auto renewal =
      std::static_pointer_cast<const RenewalLaw>(core->payload);
  if (!renewal || renewal->queue_count() != core->binding.queue_cardinality ||
      renewal->catalog_digest() != core->binding.catalog_digest) {
    return internal_failure<std::vector<ExactTargetIidBatchMass>>(
        "renewal_factorized_iid_payload_binding",
        "the compact IID projection payload is absent or bound to another "
        "queue catalog");
  }

  try {
    // pmf[k] is the exact probability that the processed sources contribute
    // k packets to the selected target in one slot.
    std::vector<ExactRational> pmf{ExactRational::one()};
    for (const RenewalLawSource& source : renewal->sources()) {
      const auto* factorized =
          std::get_if<FactorizedRenewalLawSource>(&source);
      const auto* geometric =
          factorized == nullptr
              ? nullptr
              : std::get_if<GeometricGridRenewalGap>(
                    &factorized->interarrival);
      if (geometric == nullptr || geometric->d_min != BigNat(1U) ||
          geometric->delta != BigNat(1U) ||
          geometric->trial_probabilities.normalized_weights().size() != 2U ||
          factorized->destinations.size() !=
              factorized->destination_probabilities.normalized_weights()
                  .size()) {
        return internal_failure<std::vector<ExactTargetIidBatchMass>>(
            "renewal_factorized_iid_capability_contradiction",
            "the compiled law advertises compact IID access but contains a "
            "non-memoryless or non-factorized source");
      }

      const ExactRational& firing_probability =
          geometric->trial_probabilities.normalized_weights().front();
      ExactRational target_route_probability = ExactRational::zero();
      for (std::size_t destination = 0U;
           destination < factorized->destinations.size(); ++destination) {
        if (factorized->destinations[destination] == target) {
          target_route_probability =
              target_route_probability +
              factorized->destination_probabilities.normalized_weights()
                  [destination];
        }
      }
      const ExactRational theta =
          firing_probability * target_route_probability;
      if (!theta.is_nonnegative() || theta > ExactRational::one()) {
        return internal_failure<std::vector<ExactTargetIidBatchMass>>(
            "renewal_factorized_iid_theta_invalid",
            "an exact factorized IID source produced a target Bernoulli "
            "parameter outside [0,1]");
      }
      // A source that cannot reach this target contributes the identity
      // polynomial.  Skipping it keeps this a genuinely target-only
      // projection: O(K^2) arithmetic and O(K) storage for the K sources
      // with positive target probability, independent of unrelated sources.
      if (theta.is_zero()) {
        continue;
      }
      const ExactRational no_target = ExactRational::one() - theta;
      std::vector<ExactRational> next(pmf.size() + 1U,
                                      ExactRational::zero());
      for (std::size_t count = 0U; count < pmf.size(); ++count) {
        next[count] = next[count] + pmf[count] * no_target;
        next[count + 1U] = next[count + 1U] + pmf[count] * theta;
      }
      pmf = std::move(next);
    }

    ExactRational total = ExactRational::zero();
    std::vector<ExactTargetIidBatchMass> projection;
    projection.reserve(pmf.size());
    for (std::size_t count = 0U; count < pmf.size(); ++count) {
      total = total + pmf[count];
      if (pmf[count].is_positive()) {
        projection.push_back(
            {BigNat{static_cast<std::uint64_t>(count)}, pmf[count]});
      }
    }
    if (!(total == ExactRational::one()) || projection.empty()) {
      return internal_failure<std::vector<ExactTargetIidBatchMass>>(
          "renewal_factorized_iid_projection_not_normalized",
          "the exact target projection did not produce a normalized PMF");
    }
    return Result<std::vector<ExactTargetIidBatchMass>>::success(
        std::move(projection));
  } catch (const std::bad_alloc&) {
    return allocation_failure<std::vector<ExactTargetIidBatchMass>>(
        "projecting the exact factorized IID target law");
  } catch (const std::length_error&) {
    return representation_failure<std::vector<ExactTargetIidBatchMass>>(
        "the exact factorized IID target projection exceeds a host "
        "container limit");
  } catch (const std::exception&) {
    return internal_failure<std::vector<ExactTargetIidBatchMass>>(
        "renewal_factorized_iid_projection_invariant_failure",
        "projecting the exact factorized IID target law violated an exact "
        "representation invariant");
  } catch (...) {
    return internal_failure<std::vector<ExactTargetIidBatchMass>>(
        "renewal_factorized_iid_projection_invariant_failure",
        "projecting the exact factorized IID target law raised a "
        "nonstandard exception");
  }
}

}  // namespace mwperf
