#include "mwperf/arrival/trace.hpp"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <memory>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/registry.hpp"
#include "mwperf/arrival/types.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace mwperf {
namespace {

static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t));

struct TraceCursorState final {
  BigNat next_slot;
  std::size_t next_event;
  bool exhausted;
};

template <typename Value>
[[nodiscard]] Result<Value> fail(
    const DiagnosticCategory category, std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Result<Value>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

[[nodiscard]] Result<void> trace_initial_state_is_valid(
    const ArrivalInitialState& state) {
  if (!std::holds_alternative<TraceOrigin>(state)) {
    return fail<void>(
        DiagnosticCategory::input_validation,
        "arrival_initial_family_mismatch",
        "a deterministic trace requires the trace_origin initial state");
  }
  return Result<void>::success();
}

void append_u32(std::vector<std::byte>& output, const std::uint32_t value) {
  for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT32_C(0xff)));
  }
}

void append_u64(std::vector<std::byte>& output, const std::uint64_t value) {
  for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
    output.push_back(static_cast<std::byte>(
        (value >> (shift - 8U)) & UINT64_C(0xff)));
  }
}

void append_string(std::vector<std::byte>& output,
                   const std::string_view value) {
  append_u64(output, static_cast<std::uint64_t>(value.size()));
  for (const char character : value) {
    output.push_back(static_cast<std::byte>(
        static_cast<unsigned char>(character)));
  }
}

void append_big_nat(std::vector<std::byte>& output, const BigNat& value) {
  const std::vector<std::uint8_t> magnitude =
      value.canonical_magnitude_bytes();
  append_u64(output, static_cast<std::uint64_t>(magnitude.size()));
  for (const std::uint8_t byte : magnitude) {
    output.push_back(static_cast<std::byte>(byte));
  }
}

[[nodiscard]] Result<std::vector<std::byte>> encode_trace_law(
    const std::size_t queue_count,
    const std::span<const ExactTraceEvent> events) {
  try {
    static constexpr std::string_view kDomain =
        "mwperf.c10.deterministic_trace.v1";
    std::vector<std::byte> encoded;
    append_string(encoded, kDomain);
    append_u32(encoded, 1U);
    append_u64(encoded, static_cast<std::uint64_t>(queue_count));
    append_u64(encoded, static_cast<std::uint64_t>(events.size()));
    for (const ExactTraceEvent& event : events) {
      append_big_nat(encoded, event.slot);
      append_u64(encoded,
                 static_cast<std::uint64_t>(event.queue.ordinal()));
      append_big_nat(encoded, event.count);
    }
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return fail<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "trace_compile_allocation_failure",
        "encoding the immutable deterministic trace exhausted memory");
  } catch (const std::length_error&) {
    return fail<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "trace_compile_representation_failure",
        "the immutable deterministic trace exceeds a host container limit");
  }
}

[[nodiscard]] Result<ArrivalBinding> compile_aggregation_binding(
    const QueueCatalog& queues) {
  auto catalog = detail::digest_queue_catalog(queues);
  if (!catalog) {
    return Result<ArrivalBinding>::failure(catalog.error());
  }
  auto aggregation_identity = sha256_domain_separated(
      "mwperf.c10.trace.compile_aggregation",
      catalog.value().value().bytes());
  if (!aggregation_identity) {
    return Result<ArrivalBinding>::failure(aggregation_identity.error());
  }
  // F-C09-05 requires a complete binding even during compilation, before the
  // final law digest can exist.  This binding is used only to prove that all
  // atoms in one compile-time aggregation refer to the same catalog.  No
  // batch or digest made here is retained in TraceLaw.
  return Result<ArrivalBinding>::success(ArrivalBinding{
      ArrivalFamily::deterministic_trace,
      TimingConvention::early_service_late_admission,
      queues.size(),
      ArrivalLawDigest(aggregation_identity.value()),
      catalog.value(),
  });
}

[[nodiscard]] bool trace_events_are_canonical(
    const std::span<const ExactTraceEvent> events,
    const std::size_t queue_count) noexcept {
  for (std::size_t index = 0U; index < events.size(); ++index) {
    const ExactTraceEvent& event = events[index];
    if (event.queue.ordinal() >= queue_count || event.count.is_zero()) {
      return false;
    }
    if (index != 0U) {
      const ExactTraceEvent& previous = events[index - 1U];
      if (event.slot < previous.slot ||
          (event.slot == previous.slot &&
           event.queue.ordinal() <= previous.queue.ordinal())) {
        return false;
      }
    }
  }
  return true;
}

[[nodiscard]] Result<void> validate_cursor_state(
    const TraceLaw& law, const TraceCursorState& cursor,
    const DiagnosticCategory category, std::string code) {
  const auto events = law.events();
  if (cursor.next_event > events.size()) {
    return fail<void>(category, std::move(code),
                      "a deterministic-trace cursor event index is outside "
                      "its immutable sparse event table");
  }
  if (cursor.exhausted != (cursor.next_event == events.size())) {
    return fail<void>(category, std::move(code),
                      "a deterministic-trace cursor has an inconsistent "
                      "exhausted flag and event index");
  }
  if (cursor.next_event != 0U &&
      !(events[cursor.next_event - 1U].slot < cursor.next_slot)) {
    return fail<void>(category, std::move(code),
                      "a deterministic-trace cursor skipped an event that is "
                      "not earlier than its next requested slot");
  }
  if (cursor.next_event != events.size() &&
      events[cursor.next_event].slot < cursor.next_slot) {
    return fail<void>(category, std::move(code),
                      "a deterministic-trace cursor contains a stale "
                      "unconsumed event");
  }
  return Result<void>::success();
}

[[nodiscard]] bool read_u32(const std::span<const std::byte> encoded,
                            std::size_t& offset,
                            std::uint32_t& value) noexcept {
  if (encoded.size() - std::min(offset, encoded.size()) < 4U) {
    return false;
  }
  value = 0U;
  for (std::size_t index = 0U; index < 4U; ++index) {
    value = static_cast<std::uint32_t>(
        (value << 8U) |
        std::to_integer<std::uint8_t>(encoded[offset + index]));
  }
  offset += 4U;
  return true;
}

[[nodiscard]] bool read_u64(const std::span<const std::byte> encoded,
                            std::size_t& offset,
                            std::uint64_t& value) noexcept {
  if (encoded.size() - std::min(offset, encoded.size()) < 8U) {
    return false;
  }
  value = 0U;
  for (std::size_t index = 0U; index < 8U; ++index) {
    value = static_cast<std::uint64_t>(
        (value << 8U) |
        std::to_integer<std::uint8_t>(encoded[offset + index]));
  }
  offset += 8U;
  return true;
}

[[nodiscard]] bool read_big_nat(const std::span<const std::byte> encoded,
                                std::size_t& offset, BigNat& value) {
  std::uint64_t length_u64 = 0U;
  if (!read_u64(encoded, offset, length_u64) || length_u64 == 0U ||
      length_u64 > static_cast<std::uint64_t>(
                       std::numeric_limits<std::size_t>::max())) {
    return false;
  }
  const std::size_t length = static_cast<std::size_t>(length_u64);
  if (offset > encoded.size() || length > encoded.size() - offset) {
    return false;
  }
  if (length > 1U && encoded[offset] == std::byte{0}) {
    return false;
  }
  BigInt exact = 0;
  for (std::size_t index = 0U; index < length; ++index) {
    exact <<= 8U;
    exact += std::to_integer<std::uint8_t>(encoded[offset + index]);
  }
  offset += length;
  auto natural = BigNat::from_big_int(std::move(exact));
  if (!natural) {
    return false;
  }
  value = std::move(natural).value();
  return true;
}

[[nodiscard]] Result<std::vector<std::byte>> encode_trace_phase(
    const TraceLaw& law, const detail::ArrivalCursorState& erased_state) {
  if (!erased_state) {
    return fail<std::vector<std::byte>>(
        DiagnosticCategory::internal, "trace_cursor_state_missing",
        "the deterministic-trace phase encoder received no cursor state");
  }
  const auto cursor =
      std::static_pointer_cast<const TraceCursorState>(erased_state);
  auto valid = validate_cursor_state(
      law, *cursor, DiagnosticCategory::internal,
      "trace_cursor_state_invariant_failure");
  if (!valid) {
    return Result<std::vector<std::byte>>::failure(valid.error());
  }
  try {
    std::vector<std::byte> encoded;
    append_u32(encoded, 1U);
    append_big_nat(encoded, cursor->next_slot);
    append_u64(encoded, static_cast<std::uint64_t>(cursor->next_event));
    encoded.push_back(cursor->exhausted ? std::byte{1} : std::byte{0});
    return Result<std::vector<std::byte>>::success(std::move(encoded));
  } catch (const std::bad_alloc&) {
    return fail<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "trace_phase_encoding_allocation_failure",
        "encoding the deterministic-trace phase exhausted memory");
  } catch (const std::length_error&) {
    return fail<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "trace_phase_encoding_representation_failure",
        "the deterministic-trace phase exceeds a host container limit");
  }
}

[[nodiscard]] Result<detail::ArrivalCursorState> decode_trace_phase(
    const TraceLaw& law, const std::span<const std::byte> encoded) {
  try {
    std::size_t offset = 0U;
    std::uint32_t version = 0U;
    BigNat next_slot(0U);
    std::uint64_t next_event_u64 = 0U;
    if (!read_u32(encoded, offset, version) || version != 1U ||
        !read_big_nat(encoded, offset, next_slot) ||
        !read_u64(encoded, offset, next_event_u64) ||
        next_event_u64 > static_cast<std::uint64_t>(
                             std::numeric_limits<std::size_t>::max()) ||
        offset >= encoded.size()) {
      return fail<detail::ArrivalCursorState>(
          DiagnosticCategory::input_validation,
          "trace_phase_codec_invalid",
          "the deterministic-trace phase is not a canonical version-1 "
          "state record");
    }
    const std::byte exhausted_byte = encoded[offset++];
    if ((exhausted_byte != std::byte{0} &&
         exhausted_byte != std::byte{1}) ||
        offset != encoded.size()) {
      return fail<detail::ArrivalCursorState>(
          DiagnosticCategory::input_validation,
          "trace_phase_codec_invalid",
          "the deterministic-trace phase has an invalid exhausted flag or "
          "trailing data");
    }
    auto cursor = std::make_shared<const TraceCursorState>(TraceCursorState{
        std::move(next_slot), static_cast<std::size_t>(next_event_u64),
        exhausted_byte == std::byte{1}});
    auto valid = validate_cursor_state(
        law, *cursor, DiagnosticCategory::input_validation,
        "trace_phase_codec_invalid");
    if (!valid) {
      return Result<detail::ArrivalCursorState>::failure(valid.error());
    }
    return Result<detail::ArrivalCursorState>::success(std::move(cursor));
  } catch (const std::bad_alloc&) {
    return fail<detail::ArrivalCursorState>(
        DiagnosticCategory::resource_limit,
        "trace_phase_decoding_allocation_failure",
        "decoding the deterministic-trace phase exhausted memory");
  } catch (const std::exception&) {
    return fail<detail::ArrivalCursorState>(
        DiagnosticCategory::input_validation,
        "trace_phase_codec_invalid",
        "the deterministic-trace phase could not be decoded exactly");
  }
}

[[nodiscard]] Result<detail::ArrivalCursorInitialization>
instantiate_trace_cursor(const TraceLaw& law,
                         const ArrivalInitialState& state) {
  auto valid = trace_initial_state_is_valid(state);
  if (!valid) {
    return Result<detail::ArrivalCursorInitialization>::failure(valid.error());
  }
  try {
    auto cursor = std::make_shared<const TraceCursorState>(TraceCursorState{
        BigNat(0U), 0U, law.events().empty()});
    return Result<detail::ArrivalCursorInitialization>::success(
        detail::ArrivalCursorInitialization{std::move(cursor)});
  } catch (const std::bad_alloc&) {
    return fail<detail::ArrivalCursorInitialization>(
        DiagnosticCategory::resource_limit,
        "trace_cursor_allocation_failure",
        "creating the deterministic-trace cursor exhausted memory");
  }
}

[[nodiscard]] Result<detail::ProposedArrivalTransition>
propose_trace_transition(const TraceLaw& law,
                         const detail::ArrivalCursorState& erased_state,
                         const BigNat& authored_slot,
                         const ArrivalBinding& binding) {
  if (!erased_state) {
    return fail<detail::ProposedArrivalTransition>(
        DiagnosticCategory::internal, "trace_cursor_state_missing",
        "the deterministic-trace transition received no cursor state");
  }
  if (binding.family != ArrivalFamily::deterministic_trace ||
      binding.timing != TimingConvention::early_service_late_admission ||
      binding.queue_cardinality != law.queue_count() ||
      !(binding.catalog_digest == law.catalog_digest())) {
    return fail<detail::ProposedArrivalTransition>(
        DiagnosticCategory::internal, "trace_runtime_binding_mismatch",
        "the deterministic-trace transition received another law, queue "
        "catalog, or timing convention");
  }
  const auto cursor =
      std::static_pointer_cast<const TraceCursorState>(erased_state);
  auto valid = validate_cursor_state(
      law, *cursor, DiagnosticCategory::internal,
      "trace_cursor_state_invariant_failure");
  if (!valid) {
    return Result<detail::ProposedArrivalTransition>::failure(valid.error());
  }
  if (!(cursor->next_slot == authored_slot)) {
    return fail<detail::ProposedArrivalTransition>(
        DiagnosticCategory::internal, "trace_cursor_slot_invariant_failure",
        "the deterministic-trace family cursor and C09 sequential slot "
        "disagree",
        {"family cursor slot " + cursor->next_slot.to_decimal_string(),
         "requested slot " + authored_slot.to_decimal_string()});
  }

  try {
    const auto events = law.events();
    std::size_t next_event = cursor->next_event;
    std::vector<ArrivalAtom> atoms;
    if (next_event < events.size() &&
        events[next_event].slot < authored_slot) {
      return fail<detail::ProposedArrivalTransition>(
          DiagnosticCategory::internal,
          "trace_cursor_stale_unconsumed_event",
          "the deterministic-trace cursor reached a slot after its first "
          "unconsumed event");
    }
    std::size_t end = next_event;
    while (end < events.size() && events[end].slot == authored_slot) {
      ++end;
    }
    atoms.reserve(end - next_event);
    for (; next_event < end; ++next_event) {
      auto atom = ArrivalAtom::make(events[next_event].queue,
                                    events[next_event].count, binding);
      if (!atom) {
        return Result<detail::ProposedArrivalTransition>::failure(
            atom.error());
      }
      atoms.push_back(std::move(atom).value());
    }

    BigNat successor_slot = authored_slot;
    ++successor_slot;
    auto successor = std::make_shared<const TraceCursorState>(
        TraceCursorState{std::move(successor_slot), next_event,
                         next_event == events.size()});
    return Result<detail::ProposedArrivalTransition>::success(
        detail::ProposedArrivalTransition{std::move(successor),
                                          std::move(atoms)});
  } catch (const std::bad_alloc&) {
    return fail<detail::ProposedArrivalTransition>(
        DiagnosticCategory::resource_limit,
        "trace_transition_allocation_failure",
        "the deterministic-trace transition exhausted memory");
  } catch (const std::length_error&) {
    return fail<detail::ProposedArrivalTransition>(
        DiagnosticCategory::resource_limit,
        "trace_transition_representation_failure",
        "the deterministic-trace transition exceeds a host container limit");
  }
}

}  // namespace

Result<TraceLaw> compile_deterministic_trace(
    const DeterministicTraceArrival& authored, const QueueCatalog& queues) {
  try {
    std::vector<ExactTraceEvent> resolved;
    resolved.reserve(authored.events.value.size());
    for (const TraceEvent& event : authored.events.value) {
      auto queue = queues.resolve(event.queue_id.value,
                                  event.queue_id.provenance);
      if (!queue) {
        return Result<TraceLaw>::failure(queue.error());
      }
      resolved.push_back(ExactTraceEvent{
          event.slot.value, queue.value(), event.count.value});
    }

    std::ranges::stable_sort(
        resolved, [](const ExactTraceEvent& left,
                     const ExactTraceEvent& right) {
          if (left.slot != right.slot) {
            return left.slot < right.slot;
          }
          return left.queue.ordinal() < right.queue.ordinal();
        });

    auto compile_binding = compile_aggregation_binding(queues);
    if (!compile_binding) {
      return Result<TraceLaw>::failure(compile_binding.error());
    }

    std::vector<ExactTraceEvent> aggregated;
    aggregated.reserve(resolved.size());
    std::vector<std::uint8_t> support(queues.size(), 0U);
    if (!resolved.empty()) {
      std::size_t first = 0U;
      while (first < resolved.size()) {
        std::size_t last = first + 1U;
        while (last < resolved.size() &&
               resolved[last].slot == resolved[first].slot) {
          ++last;
        }
        std::vector<ArrivalAtom> atoms;
        atoms.reserve(last - first);
        for (std::size_t index = first; index < last; ++index) {
          auto atom = ArrivalAtom::make(resolved[index].queue,
                                        resolved[index].count,
                                        compile_binding.value());
          if (!atom) {
            return Result<TraceLaw>::failure(atom.error());
          }
          atoms.push_back(std::move(atom).value());
        }
        auto batch = aggregate_arrival_batch(atoms);
        if (!batch) {
          return Result<TraceLaw>::failure(batch.error());
        }
        for (const ArrivalBatchEntry& entry : batch.value().entries()) {
          aggregated.push_back(
              ExactTraceEvent{resolved[first].slot, entry.queue, entry.count});
          support[entry.queue.ordinal()] = 1U;
        }
        first = last;
      }
    }

    if (!trace_events_are_canonical(aggregated, queues.size())) {
      return fail<TraceLaw>(
          DiagnosticCategory::internal,
          "trace_compile_canonicalization_invariant_failure",
          "deterministic-trace aggregation did not produce strict exact "
          "slot/dense-queue order");
    }
    auto canonical = encode_trace_law(queues.size(), aggregated);
    if (!canonical) {
      return Result<TraceLaw>::failure(canonical.error());
    }
    return Result<TraceLaw>::success(
        TraceLaw(queues.size(), std::move(aggregated), std::move(support),
                 std::move(canonical).value(),
                 compile_binding.value().catalog_digest));
  } catch (const std::bad_alloc&) {
    return fail<TraceLaw>(DiagnosticCategory::resource_limit,
                          "trace_compile_allocation_failure",
                          "compiling the deterministic trace exhausted "
                          "memory");
  } catch (const std::length_error&) {
    return fail<TraceLaw>(DiagnosticCategory::resource_limit,
                          "trace_compile_representation_failure",
                          "the deterministic trace exceeds a host container "
                          "limit");
  } catch (const std::exception&) {
    return fail<TraceLaw>(DiagnosticCategory::internal,
                          "trace_compile_invariant_failure",
                          "deterministic-trace compilation raised an "
                          "unexpected implementation exception");
  } catch (...) {
    return fail<TraceLaw>(DiagnosticCategory::internal,
                          "trace_compile_invariant_failure",
                          "deterministic-trace compilation raised an unknown "
                          "implementation exception");
  }
}

Result<ArrivalStep> next_trace_batch(TraceCursor& cursor,
                                     const BigNat& authored_slot) {
  if (cursor.family() != ArrivalFamily::deterministic_trace) {
    return fail<ArrivalStep>(
        DiagnosticCategory::input_validation, "trace_cursor_family_mismatch",
        "next_trace_batch requires a deterministic-trace arrival cursor");
  }
  return next_arrival_step(cursor, authored_slot);
}

#if defined(MWPERF_C10_TEST_SEAMS)
namespace testing {

Result<void> validate_trace_cursor_state_for_testing(
    const TraceLaw& law, BigNat next_slot, const std::size_t next_event,
    const bool exhausted) {
  return validate_cursor_state(
      law,
      TraceCursorState{std::move(next_slot), next_event, exhausted},
      DiagnosticCategory::internal,
      "trace_cursor_state_invariant_failure");
}

}  // namespace testing
#endif

namespace detail {

Result<CompiledArrivalProduct> compile_deterministic_trace_product(
    const PreparedArrivalCompilation& request) {
  const auto* authored =
      std::get_if<DeterministicTraceArrival>(&request.authored.value);
  if (authored == nullptr) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::internal, "trace_backend_family_mismatch",
        "the deterministic-trace compiler received another authored family");
  }
  if (!request.normalized_rows.empty()) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::internal,
        "trace_backend_normalized_rows_invariant_failure",
        "a deterministic trace unexpectedly received categorical PMF rows");
  }

  auto compiled = compile_deterministic_trace(*authored, request.queues);
  if (!compiled) {
    return Result<CompiledArrivalProduct>::failure(compiled.error());
  }

  try {
    auto payload = std::make_shared<const TraceLaw>(
        std::move(compiled).value());
    ArrivalRuntimeAdapter runtime;
    runtime.validate_initial =
        [](const std::shared_ptr<const void>&,
           const ArrivalInitialState& state) {
          return trace_initial_state_is_valid(state);
        };
    runtime.instantiate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalInitialState& state,
           DeterministicRng&) {
          const auto law = std::static_pointer_cast<const TraceLaw>(erased);
          return instantiate_trace_cursor(*law, state);
        };
    runtime.encode_phase =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state) {
          const auto law = std::static_pointer_cast<const TraceLaw>(erased);
          return encode_trace_phase(*law, state);
        };
    runtime.decode_phase =
        [](const std::shared_ptr<const void>& erased,
           const std::span<const std::byte> encoded) {
          const auto law = std::static_pointer_cast<const TraceLaw>(erased);
          return decode_trace_phase(*law, encoded);
        };
    runtime.propose =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& authored_slot,
           const ArrivalBinding& binding, DeterministicRng&) {
          const auto law = std::static_pointer_cast<const TraceLaw>(erased);
          return propose_trace_transition(*law, state, authored_slot, binding);
        };
    runtime.enumerate =
        [](const std::shared_ptr<const void>& erased,
           const ArrivalCursorState& state, const BigNat& authored_slot,
           const ArrivalBinding& binding)
        -> Result<std::vector<ExactArrivalTransitionAtom>> {
      const auto law = std::static_pointer_cast<const TraceLaw>(erased);
      auto before = encode_trace_phase(*law, state);
      if (!before) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            before.error());
      }
      auto proposal =
          propose_trace_transition(*law, state, authored_slot, binding);
      if (!proposal) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            proposal.error());
      }
      auto after = encode_trace_phase(*law, proposal.value().successor_state);
      if (!after) {
        return Result<std::vector<ExactArrivalTransitionAtom>>::failure(
            after.error());
      }
      try {
        std::vector<ExactArrivalTransitionAtom> row;
        row.reserve(1U);
        row.push_back(ExactArrivalTransitionAtom{
            .atoms = std::move(proposal.value().atoms),
            .phase_before = std::move(before.value()),
            .phase_after = std::move(after.value()),
            .mass = ExactRational::one(),
            .structural_support = true});
        return Result<std::vector<ExactArrivalTransitionAtom>>::success(
            std::move(row));
      } catch (const std::bad_alloc&) {
        return fail<std::vector<ExactArrivalTransitionAtom>>(
            DiagnosticCategory::resource_limit,
            "trace_exact_row_allocation_failure",
            "the deterministic-trace exact transition row exhausted memory");
      }
    };

    ArrivalCapabilities capabilities;
    capabilities.exact_positive_support = CapabilityAvailability::available;
    capabilities.sequential_normalized_sampler =
        CapabilityAvailability::available;

    return Result<CompiledArrivalProduct>::success(CompiledArrivalProduct{
        .family = ArrivalFamily::deterministic_trace,
        .normalized_rows = {},
        .positive_support =
            std::vector<std::uint8_t>(payload->positive_support_bytes().begin(),
                                      payload->positive_support_bytes().end()),
        .capabilities = std::move(capabilities),
        .canonical_law_data =
            std::vector<std::byte>(payload->canonical_law_data().begin(),
                                   payload->canonical_law_data().end()),
        .portable_schema = PortableArrivalLawSchema::deterministic_trace_v1,
        .payload = std::move(payload),
        .runtime = std::move(runtime),
        .iid_joint_table = std::nullopt,
        .moments = std::nullopt,
        .covariances = std::nullopt,
        .analytic_transform = std::nullopt,
        .joint_distribution = std::nullopt,
        .coordinate_distributions = std::nullopt,
        .replay_codec = std::nullopt,
        .unit_cube = std::nullopt,
        .finite_phase = std::nullopt,
        .transition_rows = std::nullopt,
        .stationary_phase_law = std::nullopt,
    });
  } catch (const std::bad_alloc&) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::resource_limit,
        "trace_publish_allocation_failure",
        "constructing the deterministic-trace product exhausted memory");
  } catch (const std::length_error&) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::resource_limit,
        "trace_publish_representation_failure",
        "the deterministic-trace product exceeds a host container limit");
  } catch (const std::exception&) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::internal, "trace_publish_invariant_failure",
        "constructing the deterministic-trace product raised an unexpected "
        "implementation exception");
  } catch (...) {
    return fail<CompiledArrivalProduct>(
        DiagnosticCategory::internal, "trace_publish_invariant_failure",
        "constructing the deterministic-trace product raised an unknown "
        "implementation exception");
  }
}

}  // namespace detail
}  // namespace mwperf
