#include "mwperf/certificates/transfer_bounds.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <new>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/metrics/metric_requirements.hpp"

#include "certificates/c25_internal.hpp"

namespace mwperf {
namespace {

template <typename T>
[[nodiscard]] Result<T> fail(
    std::string code, std::string message,
    const DiagnosticCategory category = DiagnosticCategory::input_validation,
    std::vector<std::string> notes = {}) {
  return Result<T>::failure(Diagnostic{
      .category = category,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  });
}

[[nodiscard]] Result<std::size_t> finite_horizon_size(
    const Horizon& horizon) {
  const BigInt& exact = horizon.value();
  if (exact < 0 ||
      exact > BigInt(std::numeric_limits<std::size_t>::max())) {
    return fail<std::size_t>(
        "c25.transfer_horizon_out_of_range",
        "the finite transfer horizon exceeds the addressable range",
        DiagnosticCategory::resource_limit,
        {"authored horizon " + horizon.to_decimal_string()});
  }
  return Result<std::size_t>::success(exact.convert_to<std::size_t>());
}

[[nodiscard]] bool finite_probability(const long double value) noexcept {
  return std::isfinite(value) && value >= 0.0L && value <= 1.0L;
}

struct StableTvResult final {
  long double value;
  long double union_bound;
  bool boundary_case;
};

[[nodiscard]] long double stable_union_bound(
    const long double initial_defect, const long double row_defect,
    const std::size_t horizon) noexcept {
  if (initial_defect >= 1.0L) {
    return 1.0L;
  }
  if (horizon == 0U || row_defect == 0.0L) {
    return initial_defect;
  }
  const long double remaining = 1.0L - initial_defect;
  const long double steps = static_cast<long double>(horizon);
  // Compare before multiplying, so the displayed union cap never relies on
  // an overflowing intermediate.
  if (steps >= remaining / row_defect) {
    return 1.0L;
  }
  return initial_defect + steps * row_defect;
}

[[nodiscard]] Result<StableTvResult> stable_tv_failure_probability(
    const long double initial_defect, const long double row_defect,
    const std::size_t horizon) {
  if (!finite_probability(initial_defect) ||
      !finite_probability(row_defect)) {
    return fail<StableTvResult>(
        "c25.row_error_probability_out_of_range",
        "finite-horizon TV defects must be finite values in [0,1]");
  }

  const long double union_bound =
      stable_union_bound(initial_defect, row_defect, horizon);
  if (horizon == 0U || row_defect == 0.0L) {
    return Result<StableTvResult>::success(
        StableTvResult{initial_defect, union_bound, true});
  }
  if (initial_defect == 1.0L || row_defect == 1.0L) {
    return Result<StableTvResult>::success(
        StableTvResult{1.0L, union_bound, true});
  }

  const long double log_survival = std::fma(
      static_cast<long double>(horizon), std::log1p(-row_defect),
      std::log1p(-initial_defect));
  long double value = -std::expm1(log_survival);
  if (!std::isfinite(value)) {
    return fail<StableTvResult>(
        "c25.finite_horizon_tv_numeric_failure",
        "stable finite-horizon TV arithmetic produced a nonfinite value",
        DiagnosticCategory::internal);
  }
  // Correct only a last-bit transcendental excursion and make that path
  // externally visible through boundary_case.  A material excursion is an
  // internal failure, never a silent clip.
  const long double tolerance =
      16.0L * std::numeric_limits<long double>::epsilon();
  bool corrected = false;
  if (value < 0.0L && value >= -tolerance) {
    value = 0.0L;
    corrected = true;
  } else if (value > 1.0L && value <= 1.0L + tolerance) {
    value = 1.0L;
    corrected = true;
  } else if (value < 0.0L || value > 1.0L) {
    return fail<StableTvResult>(
        "c25.finite_horizon_tv_numeric_range_failure",
        "stable finite-horizon TV arithmetic left the probability range",
        DiagnosticCategory::internal);
  }
  return Result<StableTvResult>::success(
      StableTvResult{value, union_bound, corrected});
}

[[nodiscard]] Result<long double> checked_nonnegative_quotient(
    const long double numerator, const long double denominator,
    const std::string& role) {
  if (!std::isfinite(numerator) || numerator < 0.0L ||
      !std::isfinite(denominator) || denominator <= 0.0L) {
    return fail<long double>(
        "c25.invalid_nonnegative_bound_arithmetic",
        role + " has a nonfinite/negative numerator or nonpositive denominator");
  }
  const long double result = numerator / denominator;
  if (!std::isfinite(result) || result < 0.0L) {
    return fail<long double>(
        "c25.transfer_bound_numeric_overflow",
        role + " is finite mathematically but not representable in long double",
        DiagnosticCategory::unavailable);
  }
  return Result<long double>::success(result);
}

[[nodiscard]] Result<long double> checked_nonnegative_product(
    const long double left, const long double right,
    const std::string& role) {
  if (!std::isfinite(left) || left < 0.0L || !std::isfinite(right) ||
      right < 0.0L) {
    return fail<long double>(
        "c25.invalid_nonnegative_bound_arithmetic",
        role + " has a nonfinite or negative factor");
  }
  if (left == 0.0L || right == 0.0L) {
    return Result<long double>::success(0.0L);
  }
  if (left > std::numeric_limits<long double>::max() / right) {
    return fail<long double>(
        "c25.transfer_bound_numeric_overflow",
        role + " is finite mathematically but not representable in long double",
        DiagnosticCategory::unavailable);
  }
  return Result<long double>::success(left * right);
}

struct ExactMatrix final {
  std::size_t dimension;
  std::vector<ExactRational> entries;
};

[[nodiscard]] Result<ExactMatrix> exact_matrix_from_evidence(
    const ExactDenseMatrixV1& matrix, const std::string& role) {
  if (matrix.rows == 0U || matrix.columns == 0U) {
    return fail<ExactMatrix>("c25.empty_killed_state_space",
                             role + " must have at least one state");
  }
  if (matrix.rows != matrix.columns) {
    return fail<ExactMatrix>("c25.killed_matrix_not_square",
                             role + " must be square");
  }
  if (matrix.rows >
      std::numeric_limits<std::size_t>::max() / matrix.columns) {
    return fail<ExactMatrix>(
        "c25.killed_matrix_dimension_overflow",
        role + " dense dimension overflows size_t",
        DiagnosticCategory::resource_limit);
  }
  if (matrix.entries.size() != matrix.rows * matrix.columns) {
    return fail<ExactMatrix>("c25.killed_matrix_size_mismatch",
                             role + " has an inconsistent entry count");
  }
  return Result<ExactMatrix>::success(
      ExactMatrix{matrix.rows, matrix.entries});
}

[[nodiscard]] Result<void> validate_square_matrix(const ExactMatrix& matrix,
                                                  const std::string& role) {
  if (matrix.dimension == 0U) {
    return fail<void>("c25.empty_killed_state_space",
                      role + " must have at least one state");
  }
  if (matrix.dimension >
      std::numeric_limits<std::size_t>::max() / matrix.dimension) {
    return fail<void>(
        "c25.killed_matrix_dimension_overflow",
        role + " dense dimension overflows size_t",
        DiagnosticCategory::resource_limit);
  }
  if (matrix.entries.size() != matrix.dimension * matrix.dimension) {
    return fail<void>("c25.killed_matrix_size_mismatch",
                      role + " does not contain dimension-squared entries");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_substochastic(
    const ExactMatrix& matrix, const std::string& role) {
  auto shape = validate_square_matrix(matrix, role);
  if (!shape) {
    return shape;
  }
  for (std::size_t row = 0U; row < matrix.dimension; ++row) {
    ExactRational total = ExactRational::zero();
    for (std::size_t column = 0U; column < matrix.dimension; ++column) {
      const ExactRational& entry =
          matrix.entries[row * matrix.dimension + column];
      if (!entry.is_nonnegative()) {
        return fail<void>(
            "c25.negative_killed_kernel_entry",
            role + " has a negative killed-kernel entry",
            DiagnosticCategory::input_validation,
            {"row " + std::to_string(row),
             "column " + std::to_string(column)});
      }
      total = total + entry;
    }
    if (total > ExactRational::one()) {
      return fail<void>(
          "c25.killed_kernel_row_mass_exceeds_one",
          role + " has a survivor row whose exact mass exceeds one",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(row),
           "exact row mass " + total.to_canonical_string()});
    }
  }
  return Result<void>::success();
}

[[nodiscard]] ExactMatrix identity_minus(const ExactMatrix& killed) {
  ExactMatrix result{killed.dimension, killed.entries};
  for (ExactRational& value : result.entries) {
    value = -value;
  }
  for (std::size_t index = 0U; index < killed.dimension; ++index) {
    const std::size_t diagonal = index * killed.dimension + index;
    result.entries[diagonal] =
        result.entries[diagonal] + ExactRational::one();
  }
  return result;
}

[[nodiscard]] Result<ExactMatrix> exact_inverse(ExactMatrix matrix,
                                                const std::string& role) {
  auto shape = validate_square_matrix(matrix, role);
  if (!shape) {
    return Result<ExactMatrix>::failure(shape.error());
  }
  const std::size_t dimension = matrix.dimension;
  std::vector<ExactRational> inverse(dimension * dimension,
                                     ExactRational::zero());
  for (std::size_t index = 0U; index < dimension; ++index) {
    inverse[index * dimension + index] = ExactRational::one();
  }

  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension &&
           matrix.entries[pivot * dimension + column].is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return fail<ExactMatrix>(
          "c25.killed_resolvent_singular",
          role + " has no finite bounded Neumann resolvent",
          DiagnosticCategory::unavailable,
          {"singular pivot column " + std::to_string(column)});
    }
    if (pivot != column) {
      for (std::size_t entry = 0U; entry < dimension; ++entry) {
        std::swap(matrix.entries[column * dimension + entry],
                  matrix.entries[pivot * dimension + entry]);
        std::swap(inverse[column * dimension + entry],
                  inverse[pivot * dimension + entry]);
      }
    }

    const ExactRational pivot_value =
        matrix.entries[column * dimension + column];
    for (std::size_t entry = 0U; entry < dimension; ++entry) {
      auto left = checked_divide(
          matrix.entries[column * dimension + entry], pivot_value);
      auto right = checked_divide(inverse[column * dimension + entry],
                                  pivot_value);
      if (!left) {
        return Result<ExactMatrix>::failure(left.error());
      }
      if (!right) {
        return Result<ExactMatrix>::failure(right.error());
      }
      matrix.entries[column * dimension + entry] =
          std::move(left).value();
      inverse[column * dimension + entry] = std::move(right).value();
    }

    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const ExactRational factor =
          matrix.entries[row * dimension + column];
      if (factor.is_zero()) {
        continue;
      }
      for (std::size_t entry = 0U; entry < dimension; ++entry) {
        matrix.entries[row * dimension + entry] =
            matrix.entries[row * dimension + entry] -
            factor * matrix.entries[column * dimension + entry];
        inverse[row * dimension + entry] =
            inverse[row * dimension + entry] -
            factor * inverse[column * dimension + entry];
      }
    }
  }
  return Result<ExactMatrix>::success(
      ExactMatrix{dimension, std::move(inverse)});
}

[[nodiscard]] Result<ExactMatrix> matrix_difference(
    const ExactMatrix& left, const ExactMatrix& right,
    const std::string& role) {
  if (left.dimension != right.dimension ||
      left.entries.size() != right.entries.size()) {
    return fail<ExactMatrix>("c25.killed_matrix_dimension_mismatch",
                             role + " uses different state dimensions");
  }
  std::vector<ExactRational> values;
  values.reserve(left.entries.size());
  for (std::size_t index = 0U; index < left.entries.size(); ++index) {
    values.push_back(left.entries[index] - right.entries[index]);
  }
  return Result<ExactMatrix>::success(
      ExactMatrix{left.dimension, std::move(values)});
}

[[nodiscard]] Result<ExactMatrix> matrix_product(
    const ExactMatrix& left, const ExactMatrix& right,
    const std::string& role) {
  if (left.dimension != right.dimension) {
    return fail<ExactMatrix>("c25.killed_matrix_dimension_mismatch",
                             role + " uses different state dimensions");
  }
  const std::size_t dimension = left.dimension;
  std::vector<ExactRational> result(dimension * dimension,
                                    ExactRational::zero());
  for (std::size_t row = 0U; row < dimension; ++row) {
    for (std::size_t column = 0U; column < dimension; ++column) {
      ExactRational value = ExactRational::zero();
      for (std::size_t inner = 0U; inner < dimension; ++inner) {
        value = value +
                left.entries[row * dimension + inner] *
                    right.entries[inner * dimension + column];
      }
      result[row * dimension + column] = std::move(value);
    }
  }
  return Result<ExactMatrix>::success(
      ExactMatrix{dimension, std::move(result)});
}

[[nodiscard]] std::vector<ExactRational> matrix_times_one(
    const ExactMatrix& matrix) {
  std::vector<ExactRational> result(matrix.dimension,
                                    ExactRational::zero());
  for (std::size_t row = 0U; row < matrix.dimension; ++row) {
    for (std::size_t column = 0U; column < matrix.dimension; ++column) {
      result[row] = result[row] +
                    matrix.entries[row * matrix.dimension + column];
    }
  }
  return result;
}

[[nodiscard]] Result<ExactRational> weighted_sup_operator_norm(
    const ExactMatrix& matrix,
    const std::vector<ExactRational>& weights) {
  if (weights.size() != matrix.dimension) {
    return fail<ExactRational>(
        "c25.operator_norm_weight_dimension_mismatch",
        "the operator-norm weight vector does not match the killed state space");
  }
  ExactRational maximum = ExactRational::zero();
  for (std::size_t row = 0U; row < matrix.dimension; ++row) {
    if (!weights[row].is_positive()) {
      return fail<ExactRational>(
          "c25.operator_norm_nonpositive_weight",
          "every weighted-supremum norm weight must be strictly positive");
    }
    ExactRational numerator = ExactRational::zero();
    for (std::size_t column = 0U; column < matrix.dimension; ++column) {
      if (!weights[column].is_positive()) {
        return fail<ExactRational>(
            "c25.operator_norm_nonpositive_weight",
            "every weighted-supremum norm weight must be strictly positive");
      }
      numerator =
          numerator +
          absolute_value(matrix.entries[row * matrix.dimension + column]) *
              weights[column];
    }
    auto row_norm = checked_divide(numerator, weights[row]);
    if (!row_norm) {
      return Result<ExactRational>::failure(row_norm.error());
    }
    if (row_norm.value() > maximum) {
      maximum = row_norm.value();
    }
  }
  return Result<ExactRational>::success(std::move(maximum));
}

[[nodiscard]] Result<ExactRational> weighted_sup_vector_norm(
    const std::vector<ExactRational>& vector,
    const std::vector<ExactRational>& weights) {
  if (vector.size() != weights.size() || vector.empty()) {
    return fail<ExactRational>(
        "c25.operator_norm_weight_dimension_mismatch",
        "the vector and weighted norm use different dimensions");
  }
  ExactRational maximum = ExactRational::zero();
  for (std::size_t index = 0U; index < vector.size(); ++index) {
    if (!weights[index].is_positive()) {
      return fail<ExactRational>(
          "c25.operator_norm_nonpositive_weight",
          "every weighted-supremum norm weight must be strictly positive");
    }
    auto coordinate =
        checked_divide(absolute_value(vector[index]), weights[index]);
    if (!coordinate) {
      return Result<ExactRational>::failure(coordinate.error());
    }
    if (coordinate.value() > maximum) {
      maximum = coordinate.value();
    }
  }
  return Result<ExactRational>::success(std::move(maximum));
}

[[nodiscard]] Result<ExactRational> weighted_dual_vector_norm(
    const std::vector<ExactRational>& vector,
    const std::vector<ExactRational>& weights) {
  if (vector.size() != weights.size() || vector.empty()) {
    return fail<ExactRational>(
        "c25.operator_norm_weight_dimension_mismatch",
        "the entrance vector and weighted norm use different dimensions");
  }
  ExactRational result = ExactRational::zero();
  for (std::size_t index = 0U; index < vector.size(); ++index) {
    if (!weights[index].is_positive()) {
      return fail<ExactRational>(
          "c25.operator_norm_nonpositive_weight",
          "every weighted-supremum norm weight must be strictly positive");
    }
    result = result + absolute_value(vector[index]) * weights[index];
  }
  return Result<ExactRational>::success(std::move(result));
}

[[nodiscard]] Result<void> validate_probability_vector(
    const std::vector<ExactRational>& vector, const std::size_t dimension,
    const std::string& role) {
  if (vector.size() != dimension) {
    return fail<void>("c25.entrance_dimension_mismatch",
                      role + " does not match the killed state space");
  }
  ExactRational total = ExactRational::zero();
  for (const ExactRational& value : vector) {
    if (!value.is_nonnegative()) {
      return fail<void>("c25.negative_entrance_mass",
                        role + " contains negative mass");
    }
    total = total + value;
  }
  if (!(total == ExactRational::one())) {
    return fail<void>(
        "c25.entrance_mass_not_unit",
        role + " must have exact unit mass",
        DiagnosticCategory::input_validation,
        {"exact mass " + total.to_canonical_string()});
  }
  return Result<void>::success();
}

[[nodiscard]] Result<long double> finite_numerical_image(
    const ExactRational& value, const std::string& role) {
  const long double image = value.to_long_double();
  if (!std::isfinite(image) || image < 0.0L) {
    return fail<long double>(
        "c25.transfer_bound_numeric_overflow",
        role + " is exact and finite but has no nonnegative long-double image",
        DiagnosticCategory::unavailable,
        {"exact value " + value.to_canonical_string()});
  }
  return Result<long double>::success(image);
}

[[nodiscard]] Result<long double> checked_nonnegative_sum(
    const long double left, const long double right,
    const std::string& role) {
  if (!std::isfinite(left) || left < 0.0L || !std::isfinite(right) ||
      right < 0.0L ||
      left > std::numeric_limits<long double>::max() - right) {
    return fail<long double>(
        "c25.transfer_bound_numeric_overflow",
        role + " is finite mathematically but not representable in long double",
        DiagnosticCategory::unavailable);
  }
  return Result<long double>::success(left + right);
}

[[nodiscard]] Result<void> validate_tv_reward(
    const RowErrorEvidenceV1& row,
    const TotalVariationGeometryV1& geometry) {
  if (geometry.convention != TvConventionV1::supremum_event_difference) {
    return fail<void>(
        "c25.tv_convention_mismatch",
        "C25 implements the supremum-event total-variation convention");
  }
  switch (row.reward.kind) {
    case RewardGeometryKindV1::event_indicator:
      if (geometry.reward_lower.has_value() ||
          geometry.reward_upper.has_value()) {
        return fail<void>(
            "c25.reward_geometry_mismatch",
            "an event-indicator TV claim cannot be rebound to a different reward range");
      }
      return Result<void>::success();
    case RewardGeometryKindV1::bounded_range: {
      if (!row.reward.lower.has_value() || !row.reward.upper.has_value() ||
          !geometry.reward_lower.has_value() ||
          !geometry.reward_upper.has_value()) {
        return fail<void>(
            "c25.bounded_reward_range_missing",
            "a bounded-reward TV claim requires both finite range endpoints");
      }
      const long double lower = *row.reward.lower;
      const long double upper = *row.reward.upper;
      if (!std::isfinite(lower) || !std::isfinite(upper) || lower > upper ||
          lower != *geometry.reward_lower ||
          upper != *geometry.reward_upper) {
        return fail<void>(
            "c25.reward_geometry_mismatch",
            "the bounded reward range differs from the validated TV evidence");
      }
      return Result<void>::success();
    }
    case RewardGeometryKindV1::metric_lipschitz:
    case RewardGeometryKindV1::unbounded:
      return fail<void>(
          "c25.tv_unbounded_reward_unsupported",
          "plain total variation does not control the requested unbounded reward");
  }
  return fail<void>("c25.unknown_reward_geometry",
                    "the row error uses an unknown reward geometry",
                    DiagnosticCategory::internal);
}

[[nodiscard]] Result<long double> tv_reward_scale(
    const RowErrorEvidenceV1& row) {
  if (row.reward.kind == RewardGeometryKindV1::event_indicator) {
    return Result<long double>::success(1.0L);
  }
  if (row.reward.kind != RewardGeometryKindV1::bounded_range ||
      !row.reward.lower.has_value() || !row.reward.upper.has_value()) {
    return fail<long double>(
        "c25.tv_unbounded_reward_unsupported",
        "plain total variation controls only event indicators and explicitly bounded rewards");
  }
  const long double width = *row.reward.upper - *row.reward.lower;
  if (!std::isfinite(width) || width < 0.0L) {
    return fail<long double>(
        "c25.invalid_bounded_reward_range",
        "the bounded reward range width must be finite and nonnegative");
  }
  return Result<long double>::success(width);
}

[[nodiscard]] Result<void> validate_contraction_binding(
    const RowErrorBound& row_view,
    const ContractionWitness& contraction_view,
    const RowErrorEvidenceV1& row,
    const ContractionEvidenceV1& contraction,
    const MetricGeometry& requested_geometry) {
  if (!certificates::detail::C25CoreAccess::same_owner(row_view,
                                                        contraction_view)) {
    return fail<void>(
        "c25.validated_view_owner_mismatch",
        "the row error and contraction witness were not issued by the same validated certificate bundle");
  }
  if (!(contraction.row_error_id == row.evidence_id)) {
    return fail<void>(
        "c25.contraction_row_dependency_mismatch",
        "the contraction witness does not depend on the supplied row-error evidence");
  }
  if (!(contraction.reference_kernel == row.reference_law) ||
      !(contraction.approximate_kernel == row.approximate_law)) {
    return fail<void>(
        "c25.contraction_law_orientation_mismatch",
        "the contraction witness and row defect name different ordered kernels");
  }
  if (!(row.geometry == contraction.geometry) ||
      !(row.geometry == requested_geometry)) {
    return fail<void>(
        "c25.contraction_geometry_mismatch",
        "the row defect, contraction witness, and requested metric geometry must match exactly");
  }
  if (!contraction.invariant_laws_established) {
    return fail<void>(
        "c25.contraction_invariant_laws_not_established",
        "stationary contraction transfer requires both named invariant laws");
  }
  if (!std::isfinite(contraction.coefficient) ||
      contraction.coefficient < 0.0L || contraction.coefficient >= 1.0L) {
    return fail<void>(
        "c25.contraction_coefficient_not_strict",
        "the verified contraction coefficient must be finite and satisfy 0 <= c < 1");
  }
  if (!std::isfinite(row.row_defect) || row.row_defect < 0.0L) {
    return fail<void>(
        "c25.invalid_stationary_row_defect",
        "a stationary row defect must be finite and nonnegative");
  }
  return Result<void>::success();
}

}  // namespace

TransferGeometryKindV1 MetricGeometry::kind() const noexcept {
  return std::visit(
      [](const auto& geometry) noexcept {
        using Geometry = std::decay_t<decltype(geometry)>;
        if constexpr (std::is_same_v<Geometry, TotalVariationGeometryV1>) {
          return TransferGeometryKindV1::total_variation;
        } else if constexpr (std::is_same_v<Geometry,
                                            WassersteinGeometryV1>) {
          return TransferGeometryKindV1::wasserstein_metric;
        } else if constexpr (std::is_same_v<Geometry, WeightedGeometryV1>) {
          return TransferGeometryKindV1::weighted_total_variation;
        } else {
          return TransferGeometryKindV1::operator_norm;
        }
      },
      value);
}

Result<ErrorBound> compute_finite_horizon_tv_transfer(
    const RowErrorBound& row_error, const Horizon& horizon) {
  try {
    const RowErrorEvidenceV1& row =
        certificates::detail::C25CoreAccess::row_error(row_error);
    auto finite_horizon = finite_horizon_size(horizon);
    if (!finite_horizon) {
      return Result<ErrorBound>::failure(finite_horizon.error());
    }
    const auto* tv = std::get_if<TotalVariationGeometryV1>(
        &row.geometry.value);
    if (tv == nullptr) {
      return fail<ErrorBound>(
          "c25.finite_horizon_geometry_mismatch",
          "finite-horizon TV transfer requires total-variation row evidence");
    }
    auto reward = validate_tv_reward(row, *tv);
    if (!reward) {
      return Result<ErrorBound>::failure(reward.error());
    }
    auto reward_scale = tv_reward_scale(row);
    if (!reward_scale) {
      return Result<ErrorBound>::failure(reward_scale.error());
    }

    long double initial_defect = 0.0L;
    TransferScopeV1 scope = TransferScopeV1::finite_residence_words;
    std::string theorem_id = "framework.proposition_13.1.event_horizon_tv";
    std::vector<std::string> assumptions;
    assumptions.reserve(8U);
    assumptions.push_back("supremum-event total-variation convention");
    assumptions.push_back("bounded finite-horizon observable only");

    switch (row.kind) {
      case RowErrorKindV1::marked_residence_event_row:
        if (row.horizon_domain !=
            HorizonDomainV1::complete_residence_words) {
          return fail<ErrorBound>(
              "c25.finite_horizon_domain_mismatch",
              "an event-residence row witness cannot be used as a slot-row witness");
        }
        if (!row.equal_initial_law) {
          return fail<ErrorBound>(
              "c25.event_horizon_initial_law_mismatch",
              "the event-horizon theorem requires matching initial laws");
        }
        if (row.initial_defect.has_value() &&
            *row.initial_defect != 0.0L) {
          return fail<ErrorBound>(
              "c25.event_horizon_initial_defect_nonzero",
              "the equal-initial event theorem cannot carry an initial defect");
        }
        if (!row.common_refinement_established) {
          return fail<ErrorBound>(
              "c25.residence_segmentation_not_common",
              "event-residence comparison requires one segmentation or a proved common refinement");
        }
        assumptions.push_back("matching initial law");
        assumptions.push_back("common residence-word segmentation");
        break;
      case RowErrorKindV1::approximate_relational_slot_row:
        if (row.horizon_domain != HorizonDomainV1::relational_slots) {
          return fail<ErrorBound>(
              "c25.finite_horizon_domain_mismatch",
              "a relational slot-row witness cannot be used as an event-residence witness");
        }
        if (!row.initial_defect.has_value() && !row.equal_initial_law) {
          return fail<ErrorBound>(
              "c25.relational_initial_defect_missing",
              "a relational-slot theorem requires its initial relation defect");
        }
        initial_defect = row.initial_defect.value_or(0.0L);
        scope = TransferScopeV1::finite_relational_slots;
        theorem_id =
            "framework.proposition_13.1a.relational_slot_simulation";
        assumptions.push_back("common metric mark and compatibility relation");
        assumptions.push_back("recursive related-row coupling");
        break;
      case RowErrorKindV1::stationary_uniform_total_variation:
      case RowErrorKindV1::stationary_wasserstein_occupation:
      case RowErrorKindV1::stationary_weighted_norm:
        return fail<ErrorBound>(
            "c25.finite_horizon_row_kind_mismatch",
            "stationary row evidence cannot be reinterpreted as a finite-horizon coupling witness");
    }

    auto stable = stable_tv_failure_probability(
        initial_defect, row.row_defect, finite_horizon.value());
    if (!stable) {
      return Result<ErrorBound>::failure(stable.error());
    }
    auto row_only = stable_tv_failure_probability(
        0.0L, row.row_defect, finite_horizon.value());
    if (!row_only) {
      return Result<ErrorBound>::failure(row_only.error());
    }

    std::vector<ErrorBoundComponentV1> components;
    if (row.kind == RowErrorKindV1::approximate_relational_slot_row) {
      components.push_back(ErrorBoundComponentV1{
          ErrorBoundComponentKindV1::initial_relation_defect,
          BoundValueStatusV1::finite, std::nullopt, initial_defect,
          "initial relation defect epsilon_0", {"validated initial coupling"}});
    }
    components.push_back(ErrorBoundComponentV1{
        ErrorBoundComponentKindV1::finite_row_compounding,
        BoundValueStatusV1::finite, std::nullopt, row_only.value().value,
        "finite row-defect compounding",
        {"conditional next-step failure bound epsilon"}});

    assumptions.push_back(
        "no stationary or unbounded-reward conclusion is emitted");
    auto presented = checked_nonnegative_product(
        stable.value().value, reward_scale.value(),
        "the finite-horizon bounded-reward consequence");
    if (!presented) {
      return Result<ErrorBound>::failure(presented.error());
    }
    if (row.reward.kind == RewardGeometryKindV1::bounded_range) {
      assumptions.push_back(
          "bounded reward consequence scaled by its explicit range");
    }
    std::vector<ErrorBoundConstantV1> constants;
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::horizon, horizon, std::nullopt,
        std::nullopt, "complete event words or relational slots"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::initial_defect, std::nullopt,
        std::nullopt, initial_defect, "initial coupling defect epsilon_0"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::row_defect, std::nullopt, std::nullopt,
        row.row_defect, "uniform conditional row defect epsilon"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::reward_scale, std::nullopt, std::nullopt,
        reward_scale.value(), "bounded reward range width"});
    return Result<ErrorBound>::success(ErrorBound{
        CertificateClaimStateV1::established,
        BoundValueStatusV1::finite,
        std::move(theorem_id),
        scope,
        row.geometry,
        std::nullopt,
        stable.value().value,
        presented.value(),
        stable.value().union_bound,
        std::nullopt,
        false,
        row.reference_law,
        row.approximate_law,
        std::move(constants),
        std::move(components),
        std::move(assumptions),
        stable.value().boundary_case
            ? "explicit_boundary_case_with_log1p_expm1_policy"
            : "long_double_log1p_expm1_survival_composition"});
  } catch (const std::bad_alloc&) {
    return fail<ErrorBound>(
        "c25.finite_horizon_transfer_allocation_failure",
        "finite-horizon transfer exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ErrorBound>(
        "c25.finite_horizon_transfer_exception",
        "finite-horizon transfer raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<ErrorBound> compute_contraction_transfer(
    const RowErrorBound& row_error,
    const ContractionWitness& contraction_witness,
    const MetricGeometry& geometry) {
  try {
    const RowErrorEvidenceV1& row =
        certificates::detail::C25CoreAccess::row_error(row_error);
    const ContractionEvidenceV1& contraction =
        certificates::detail::C25CoreAccess::contraction(
            contraction_witness);
    auto binding = validate_contraction_binding(
        row_error, contraction_witness, row, contraction, geometry);
    if (!binding) {
      return Result<ErrorBound>::failure(binding.error());
    }

    const long double gap = 1.0L - contraction.coefficient;
    auto conditioning = checked_nonnegative_quotient(
        1.0L, gap, "the contraction conditioning factor");
    if (!conditioning) {
      return Result<ErrorBound>::failure(conditioning.error());
    }
    auto raw = checked_nonnegative_quotient(
        row.row_defect, gap, "the stationary contraction quotient");
    if (!raw) {
      return Result<ErrorBound>::failure(raw.error());
    }

    long double presented = raw.value();
    long double reward_scale = 1.0L;
    bool capped = false;
    std::string theorem_id;
    std::vector<std::string> assumptions;
    assumptions.push_back("both named invariant laws are established");
    assumptions.push_back("strict contraction coefficient c < 1");

    switch (row.kind) {
      case RowErrorKindV1::stationary_uniform_total_variation: {
        const auto* tv =
            std::get_if<TotalVariationGeometryV1>(&geometry.value);
        if (tv == nullptr || row.row_defect > 1.0L) {
          return fail<ErrorBound>(
              "c25.contraction_geometry_mismatch",
              "uniform stationary TV transfer requires a row defect in [0,1] and TV geometry");
        }
        auto reward = validate_tv_reward(row, *tv);
        if (!reward) {
          return Result<ErrorBound>::failure(reward.error());
        }
        auto tv_scale = tv_reward_scale(row);
        if (!tv_scale) {
          return Result<ErrorBound>::failure(tv_scale.error());
        }
        reward_scale = tv_scale.value();
        const long double tv_presentation = std::min(raw.value(), 1.0L);
        auto scaled = checked_nonnegative_product(
            tv_presentation, reward_scale,
            "the stationary TV bounded-reward consequence");
        if (!scaled) {
          return Result<ErrorBound>::failure(scaled.error());
        }
        presented = scaled.value();
        capped = raw.value() > 1.0L;
        if (row.reward.kind == RewardGeometryKindV1::bounded_range) {
          assumptions.push_back(
              "bounded reward consequence scaled by its explicit range");
        }
        theorem_id =
            "framework.proposition_13.2.uniform_tv_contraction";
        assumptions.push_back("uniform total-variation row defect");
        break;
      }
      case RowErrorKindV1::stationary_wasserstein_occupation: {
        const auto* wasserstein =
            std::get_if<WassersteinGeometryV1>(&geometry.value);
        if (wasserstein == nullptr ||
            row.orientation != TransferOrientationV1::approximate_to_reference) {
          return fail<ErrorBound>(
              "c25.wasserstein_orientation_mismatch",
              "the Wasserstein defect must be occupation-weighted under the approximate invariant law");
        }
        if (!wasserstein->lower_semicontinuous ||
            !wasserstein->triangle_inequality ||
            !wasserstein->generates_borel_sigma_field) {
          return fail<ErrorBound>(
              "c25.wasserstein_cost_not_metric",
              "the contraction argument requires a lower-semicontinuous metric with the triangle inequality and the declared Borel field");
        }
        if (!wasserstein->reference_first_moment_finite ||
            !wasserstein->approximate_first_moment_finite ||
            !contraction.reference_first_moment_finite ||
            !contraction.approximate_first_moment_finite ||
            !row.reward.required_moments_established ||
            !wasserstein->reward_expectations_exist) {
          return fail<ErrorBound>(
              "c25.wasserstein_moment_premise_missing",
              "Wasserstein transfer requires both invariant first moments and the requested reward moments");
        }
        if (row.reward.kind != RewardGeometryKindV1::metric_lipschitz ||
            !row.reward.lipschitz_modulus.has_value() ||
            !wasserstein->reward_lipschitz_modulus.has_value() ||
            *row.reward.lipschitz_modulus !=
                *wasserstein->reward_lipschitz_modulus ||
            !std::isfinite(*wasserstein->reward_lipschitz_modulus) ||
            *wasserstein->reward_lipschitz_modulus < 0.0L) {
          return fail<ErrorBound>(
              "c25.wasserstein_reward_not_lipschitz",
              "only a validated d-Lipschitz reward inherits the requested Wasserstein consequence");
        }
        auto scaled = checked_nonnegative_product(
            raw.value(), *wasserstein->reward_lipschitz_modulus,
            "the Wasserstein reward bound");
        if (!scaled) {
          return Result<ErrorBound>::failure(scaled.error());
        }
        reward_scale = *wasserstein->reward_lipschitz_modulus;
        presented = scaled.value();
        theorem_id =
            "framework.proposition_13.2a.wasserstein_occupation_contraction";
        assumptions.push_back(
            "row defect integrated under the approximate invariant law");
        assumptions.push_back("d-Lipschitz reward with finite moments");
        break;
      }
      case RowErrorKindV1::stationary_weighted_norm: {
        const auto* weighted =
            std::get_if<WeightedGeometryV1>(&geometry.value);
        if (weighted == nullptr ||
            row.orientation != TransferOrientationV1::approximate_to_reference) {
          return fail<ErrorBound>(
              "c25.weighted_geometry_orientation_mismatch",
              "weighted contraction requires its declared oriented defect and weighted geometry");
        }
        if (!weighted->complete_normed_space ||
            !weighted->shared_foster_lyapunov_tail ||
            !contraction.shared_foster_lyapunov_tail ||
            !row.reward.required_moments_established ||
            !weighted->reward_dual_modulus.has_value() ||
            !std::isfinite(*weighted->reward_dual_modulus) ||
            *weighted->reward_dual_modulus < 0.0L) {
          return fail<ErrorBound>(
              "c25.weighted_geometry_premise_missing",
              "weighted/V-norm transfer requires its Banach, tail, moment, and reward-dual premises");
        }
        auto scaled = checked_nonnegative_product(
            raw.value(), *weighted->reward_dual_modulus,
            "the weighted-geometry reward bound");
        if (!scaled) {
          return Result<ErrorBound>::failure(scaled.error());
        }
        reward_scale = *weighted->reward_dual_modulus;
        presented = scaled.value();
        theorem_id = "framework.proposition_13.2.weighted_norm_variant";
        assumptions.push_back("shared Foster-Lyapunov/tail envelope");
        assumptions.push_back("declared weighted dual reward modulus");
        break;
      }
      case RowErrorKindV1::marked_residence_event_row:
      case RowErrorKindV1::approximate_relational_slot_row:
        return fail<ErrorBound>(
            "c25.stationary_contraction_row_kind_mismatch",
            "finite-horizon row evidence cannot be reused as stationary contraction evidence");
    }

    std::vector<ErrorBoundComponentV1> components;
    components.push_back(ErrorBoundComponentV1{
        ErrorBoundComponentKindV1::contraction_amplification,
        BoundValueStatusV1::finite, std::nullopt, raw.value(),
        "row defect amplified by 1/(1-c)",
        {"conditioning factor " + std::to_string(conditioning.value())}});
    std::vector<ErrorBoundConstantV1> constants;
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::row_defect, std::nullopt, std::nullopt,
        row.row_defect, "stationary row defect"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::contraction_coefficient, std::nullopt,
        std::nullopt, contraction.coefficient, "contraction coefficient c"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::contraction_gap, std::nullopt,
        std::nullopt, gap, "strict contraction gap 1-c"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::conditioning_factor, std::nullopt,
        std::nullopt, conditioning.value(), "conditioning factor 1/(1-c)"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::reward_scale, std::nullopt, std::nullopt,
        reward_scale, "reward range, Lipschitz, or dual modulus"});
    return Result<ErrorBound>::success(ErrorBound{
        CertificateClaimStateV1::established,
        BoundValueStatusV1::finite,
        std::move(theorem_id),
        TransferScopeV1::stationary_law,
        geometry,
        std::nullopt,
        raw.value(),
        presented,
        std::nullopt,
        conditioning.value(),
        capped,
        row.reference_law,
        row.approximate_law,
        std::move(constants),
        std::move(components),
        std::move(assumptions),
        "checked_nonnegative_long_double_quotient"});
  } catch (const std::bad_alloc&) {
    return fail<ErrorBound>(
        "c25.contraction_transfer_allocation_failure",
        "stationary contraction transfer exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ErrorBound>(
        "c25.contraction_transfer_exception",
        "stationary contraction transfer raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

Result<ErrorBound> compute_stopped_resolvent_transfer(
    const KilledKernelPair& kernels,
    const ResolventWitness& resolvent_witness) {
  try {
    if (!certificates::detail::C25CoreAccess::same_owner(
            kernels, resolvent_witness)) {
      return fail<ErrorBound>(
          "c25.validated_view_owner_mismatch",
          "the killed-kernel pair and resolvent witness were not issued by the same validated certificate bundle");
    }
    const KilledKernelPairEvidenceV1& pair =
        certificates::detail::C25CoreAccess::killed_pair(kernels);
    const ResolventEvidenceV1& witness =
        certificates::detail::C25CoreAccess::resolvent(resolvent_witness);
    if (!(witness.killed_pair_id == pair.evidence_id)) {
      return fail<ErrorBound>(
          "c25.resolvent_pair_dependency_mismatch",
          "the resolvent witness does not depend on the supplied killed-kernel pair");
    }
    if (!pair.common_state_and_lift_established) {
      return fail<ErrorBound>(
          "c25.killed_common_lift_not_established",
          "killed-resolvent transfer requires one established common state/lift and stopping event");
    }
    if (!witness.bounded_neumann_resolvents ||
        !witness.space_contains_one ||
        !witness.minimal_potentials_finite ||
        !witness.norm.complete_normed_space ||
        !witness.norm.contains_constant_one) {
      return fail<ErrorBound>(
          "c25.killed_resolvent_premise_unavailable",
          "both bounded Neumann resolvents, finite minimal potentials, and a common normed space containing one are required",
          DiagnosticCategory::unavailable);
    }
    if (witness.norm.kind != OperatorNormKindV1::weighted_supremum ||
        witness.norm.state_space_identity != pair.state_order_identity) {
      return fail<ErrorBound>(
          "c25.killed_operator_geometry_mismatch",
          "the resolvent norm does not match the common killed-state ordering");
    }
    if (witness.certified_inverse_residual_conversion.has_value()) {
      const long double conversion =
          *witness.certified_inverse_residual_conversion;
      if (!std::isfinite(conversion) || conversion < 0.0L) {
        return fail<ErrorBound>(
            "c25.invalid_resolvent_residual_conversion",
            "an inverse-residual conversion must be finite and nonnegative");
      }
      if (conversion != 0.0L) {
        return fail<ErrorBound>(
            "c25.approximate_resolvent_conversion_unavailable",
            "C25's implemented resolvent route validates exact rational two-sided inverses; a scalar residual conversion without its residual norm, orientation, and conversion theorem cannot certify an approximate inverse",
            DiagnosticCategory::unavailable);
      }
    }

    auto reference_killed = exact_matrix_from_evidence(
        pair.reference_killed_kernel, "the reference killed kernel");
    auto approximate_killed = exact_matrix_from_evidence(
        pair.approximate_killed_kernel, "the approximate killed kernel");
    auto authored_reference_resolvent = exact_matrix_from_evidence(
        witness.reference_resolvent, "the reference resolvent witness");
    auto authored_approximate_resolvent = exact_matrix_from_evidence(
        witness.approximate_resolvent,
        "the approximate resolvent witness");
    if (!reference_killed) {
      return Result<ErrorBound>::failure(reference_killed.error());
    }
    if (!approximate_killed) {
      return Result<ErrorBound>::failure(approximate_killed.error());
    }
    if (!authored_reference_resolvent) {
      return Result<ErrorBound>::failure(
          authored_reference_resolvent.error());
    }
    if (!authored_approximate_resolvent) {
      return Result<ErrorBound>::failure(
          authored_approximate_resolvent.error());
    }
    if (reference_killed.value().dimension !=
            approximate_killed.value().dimension ||
        reference_killed.value().dimension !=
            authored_reference_resolvent.value().dimension ||
        reference_killed.value().dimension !=
            authored_approximate_resolvent.value().dimension) {
      return fail<ErrorBound>(
          "c25.killed_matrix_dimension_mismatch",
          "the killed kernels and resolvents do not use one common state dimension");
    }
    auto valid_reference = validate_substochastic(
        reference_killed.value(), "the reference killed kernel");
    auto valid_approximate = validate_substochastic(
        approximate_killed.value(), "the approximate killed kernel");
    if (!valid_reference) {
      return Result<ErrorBound>::failure(valid_reference.error());
    }
    if (!valid_approximate) {
      return Result<ErrorBound>::failure(valid_approximate.error());
    }

    auto computed_reference = exact_inverse(
        identity_minus(reference_killed.value()),
        "the reference killed kernel");
    auto computed_approximate = exact_inverse(
        identity_minus(approximate_killed.value()),
        "the approximate killed kernel");
    if (!computed_reference) {
      return Result<ErrorBound>::failure(computed_reference.error());
    }
    if (!computed_approximate) {
      return Result<ErrorBound>::failure(computed_approximate.error());
    }
    if (computed_reference.value().entries !=
            authored_reference_resolvent.value().entries ||
        computed_approximate.value().entries !=
            authored_approximate_resolvent.value().entries) {
      return fail<ErrorBound>(
          "c25.resolvent_inverse_identity_failed",
          "an authored resolvent is not the exact two-sided inverse of its killed kernel");
    }
    for (const ExactRational& value : computed_reference.value().entries) {
      if (!value.is_nonnegative()) {
        return fail<ErrorBound>(
            "c25.resolvent_not_neumann_positive",
            "the reference inverse is not a nonnegative Neumann resolvent",
            DiagnosticCategory::unavailable);
      }
    }
    for (const ExactRational& value : computed_approximate.value().entries) {
      if (!value.is_nonnegative()) {
        return fail<ErrorBound>(
            "c25.resolvent_not_neumann_positive",
            "the approximate inverse is not a nonnegative Neumann resolvent",
            DiagnosticCategory::unavailable);
      }
    }

    auto resolvent_difference = matrix_difference(
        computed_reference.value(), computed_approximate.value(),
        "the resolvent identity left side");
    auto killed_difference = matrix_difference(
        reference_killed.value(), approximate_killed.value(),
        "the killed-kernel defect");
    if (!resolvent_difference) {
      return Result<ErrorBound>::failure(resolvent_difference.error());
    }
    if (!killed_difference) {
      return Result<ErrorBound>::failure(killed_difference.error());
    }
    auto first_product = matrix_product(
        computed_reference.value(), killed_difference.value(),
        "the resolvent identity first product");
    if (!first_product) {
      return Result<ErrorBound>::failure(first_product.error());
    }
    auto identity_right = matrix_product(
        first_product.value(), computed_approximate.value(),
        "the resolvent identity second product");
    if (!identity_right) {
      return Result<ErrorBound>::failure(identity_right.error());
    }
    if (resolvent_difference.value().entries !=
        identity_right.value().entries) {
      return fail<ErrorBound>(
          "c25.resolvent_perturbation_identity_failed",
          "R-Rhat does not equal R(K-Khat)Rhat exactly",
          DiagnosticCategory::internal);
    }

    const std::vector<ExactRational>& weights = witness.norm.weights;
    auto reference_norm = weighted_sup_operator_norm(
        computed_reference.value(), weights);
    auto kernel_defect_norm = weighted_sup_operator_norm(
        killed_difference.value(), weights);
    const std::vector<ExactRational> approximate_potential =
        matrix_times_one(computed_approximate.value());
    auto approximate_potential_norm =
        weighted_sup_vector_norm(approximate_potential, weights);
    if (!reference_norm) {
      return Result<ErrorBound>::failure(reference_norm.error());
    }
    if (!kernel_defect_norm) {
      return Result<ErrorBound>::failure(kernel_defect_norm.error());
    }
    if (!approximate_potential_norm) {
      return Result<ErrorBound>::failure(
          approximate_potential_norm.error());
    }
    ExactRational kernel_term =
        reference_norm.value() * kernel_defect_norm.value() *
        approximate_potential_norm.value();

    TransferScopeV1 scope = TransferScopeV1::stopped_potential;
    ExactRational entrance_term = ExactRational::zero();
    std::optional<ExactRational> reference_entrance_dual_norm;
    std::optional<ExactRational> entrance_defect_dual_norm;
    std::vector<std::string> assumptions{
        "common killed state, stopping event, lift, and weighted norm",
        "exact bounded Neumann resolvents",
        "finite minimal killed potentials"};
    if (pair.reference_entrance_law.has_value() !=
        pair.approximate_entrance_law.has_value()) {
      return fail<ErrorBound>(
          "c25.killed_entrance_pair_incomplete",
          "entrance-averaged stopped transfer requires both entrance laws");
    }
    if (pair.reference_entrance_law.has_value()) {
      auto valid_reference_entrance = validate_probability_vector(
          *pair.reference_entrance_law,
          reference_killed.value().dimension, "the reference entrance law");
      auto valid_approximate_entrance = validate_probability_vector(
          *pair.approximate_entrance_law,
          reference_killed.value().dimension,
          "the approximate entrance law");
      if (!valid_reference_entrance) {
        return Result<ErrorBound>::failure(
            valid_reference_entrance.error());
      }
      if (!valid_approximate_entrance) {
        return Result<ErrorBound>::failure(
            valid_approximate_entrance.error());
      }
      auto reference_entrance_norm = weighted_dual_vector_norm(
          *pair.reference_entrance_law, weights);
      if (!reference_entrance_norm) {
        return Result<ErrorBound>::failure(
            reference_entrance_norm.error());
      }
      reference_entrance_dual_norm = reference_entrance_norm.value();
      kernel_term = reference_entrance_norm.value() * kernel_term;
      std::vector<ExactRational> entrance_difference;
      entrance_difference.reserve(pair.reference_entrance_law->size());
      for (std::size_t index = 0U;
           index < pair.reference_entrance_law->size(); ++index) {
        entrance_difference.push_back(
            (*pair.reference_entrance_law)[index] -
            (*pair.approximate_entrance_law)[index]);
      }
      auto entrance_defect_norm =
          weighted_dual_vector_norm(entrance_difference, weights);
      if (!entrance_defect_norm) {
        return Result<ErrorBound>::failure(entrance_defect_norm.error());
      }
      entrance_defect_dual_norm = entrance_defect_norm.value();
      entrance_term = entrance_defect_norm.value() *
                      approximate_potential_norm.value();
      scope = TransferScopeV1::entrance_averaged_stopped_potential;
      assumptions.push_back(
          "entrance decomposition eta(R-Rhat)1+(eta-etahat)Rhat1");
    }

    ExactRational exact_total = kernel_term + entrance_term;
    auto kernel_numeric =
        finite_numerical_image(kernel_term, "the killed-kernel term");
    auto entrance_numeric =
        finite_numerical_image(entrance_term, "the entrance-law term");
    auto exact_total_numeric =
        finite_numerical_image(exact_total, "the exact resolvent total");
    if (!kernel_numeric) {
      return Result<ErrorBound>::failure(kernel_numeric.error());
    }
    if (!entrance_numeric) {
      return Result<ErrorBound>::failure(entrance_numeric.error());
    }
    if (!exact_total_numeric) {
      return Result<ErrorBound>::failure(exact_total_numeric.error());
    }

    constexpr long double numerical_residual = 0.0L;
    auto total_numeric = checked_nonnegative_sum(
        exact_total_numeric.value(), numerical_residual,
        "the stopped-resolvent total");
    if (!total_numeric) {
      return Result<ErrorBound>::failure(total_numeric.error());
    }

    std::vector<ErrorBoundComponentV1> components;
    components.push_back(ErrorBoundComponentV1{
        ErrorBoundComponentKindV1::killed_kernel,
        BoundValueStatusV1::finite, kernel_term, kernel_numeric.value(),
        "resolvent-kernel perturbation term",
        {"||R|| ||K-Khat|| ||Rhat 1|| with entrance dual factor when applicable"}});
    components.push_back(ErrorBoundComponentV1{
        ErrorBoundComponentKindV1::entrance_law,
        BoundValueStatusV1::finite, entrance_term, entrance_numeric.value(),
        "separate entrance-law discrepancy term",
        {"approximate-potential orientation"}});
    components.push_back(ErrorBoundComponentV1{
        ErrorBoundComponentKindV1::potential_numerical_residual,
        BoundValueStatusV1::finite,
        ExactRational::zero(),
        numerical_residual,
        "exact potential/inverse residual contribution",
        {"exact rational two-sided inverse residual is zero"}});

    auto reference_norm_numeric = finite_numerical_image(
        reference_norm.value(), "the reference resolvent norm");
    auto kernel_defect_norm_numeric = finite_numerical_image(
        kernel_defect_norm.value(), "the killed-kernel defect norm");
    auto approximate_potential_norm_numeric = finite_numerical_image(
        approximate_potential_norm.value(),
        "the approximate minimal-potential norm");
    if (!reference_norm_numeric) {
      return Result<ErrorBound>::failure(reference_norm_numeric.error());
    }
    if (!kernel_defect_norm_numeric) {
      return Result<ErrorBound>::failure(kernel_defect_norm_numeric.error());
    }
    if (!approximate_potential_norm_numeric) {
      return Result<ErrorBound>::failure(
          approximate_potential_norm_numeric.error());
    }
    std::vector<ErrorBoundConstantV1> constants;
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::reference_resolvent_norm, std::nullopt,
        reference_norm.value(), reference_norm_numeric.value(), "||R||"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::killed_kernel_defect_norm, std::nullopt,
        kernel_defect_norm.value(), kernel_defect_norm_numeric.value(),
        "||K-Khat||"});
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::approximate_potential_norm, std::nullopt,
        approximate_potential_norm.value(),
        approximate_potential_norm_numeric.value(), "||Rhat 1||"});
    if (reference_entrance_dual_norm.has_value()) {
      auto image = finite_numerical_image(
          *reference_entrance_dual_norm,
          "the reference entrance dual norm");
      if (!image) {
        return Result<ErrorBound>::failure(image.error());
      }
      constants.push_back(ErrorBoundConstantV1{
          ErrorBoundConstantKindV1::reference_entrance_dual_norm,
          std::nullopt, *reference_entrance_dual_norm, image.value(),
          "||eta||_*"});
    }
    if (entrance_defect_dual_norm.has_value()) {
      auto image = finite_numerical_image(
          *entrance_defect_dual_norm, "the entrance defect dual norm");
      if (!image) {
        return Result<ErrorBound>::failure(image.error());
      }
      constants.push_back(ErrorBoundConstantV1{
          ErrorBoundConstantKindV1::entrance_defect_dual_norm,
          std::nullopt, *entrance_defect_dual_norm, image.value(),
          "||eta-etahat||_*"});
    }
    constants.push_back(ErrorBoundConstantV1{
        ErrorBoundConstantKindV1::inverse_residual_conversion, std::nullopt,
        ExactRational::zero(), 0.0L,
        "exact two-sided inverse residual conversion"});
    return Result<ErrorBound>::success(ErrorBound{
        CertificateClaimStateV1::established,
        BoundValueStatusV1::finite,
        "framework.proposition_13.2b.killed_resolvent_perturbation",
        scope,
        MetricGeometry{witness.norm},
        std::move(exact_total),
        total_numeric.value(),
        total_numeric.value(),
        std::nullopt,
        reference_norm_numeric.value(),
        false,
        pair.reference_law,
        pair.approximate_law,
        std::move(constants),
        std::move(components),
        std::move(assumptions),
        "exact_rational_gauss_jordan_and_weighted_supremum_norm"});
  } catch (const std::bad_alloc&) {
    return fail<ErrorBound>(
        "c25.resolvent_transfer_allocation_failure",
        "stopped-resolvent transfer exhausted memory",
        DiagnosticCategory::resource_limit);
  } catch (const std::exception&) {
    return fail<ErrorBound>(
        "c25.resolvent_transfer_exception",
        "stopped-resolvent transfer raised an unexpected exception",
        DiagnosticCategory::internal);
  }
}

}  // namespace mwperf

// F-C25-05/F-C25-06 are kept in an isolated section because their evidence
// views are minted by the certificate bundle rather than by the transfer
// arithmetic above.
#include <map>
#include <queue>
#include <set>

#include "mwperf/arrival/build_view.hpp"

#include "c25_internal.hpp"

namespace mwperf {
namespace {

constexpr long double kEnvelopeTolerance = 1.0e-12L;
constexpr std::size_t kMaximumFiniteEnvelopeStates = 4096U;
constexpr std::size_t kMaximumTailRecursionLevel = 100000U;

[[nodiscard]] bool c25_finite_nonnegative(
    const long double value) noexcept {
  return std::isfinite(value) && value >= 0.0L;
}

[[nodiscard]] bool c25_close(const long double left,
                             const long double right) noexcept {
  if (!std::isfinite(left) || !std::isfinite(right)) {
    return false;
  }
  const long double scale =
      std::max({1.0L, std::fabs(left), std::fabs(right)});
  return std::fabs(left - right) <= kEnvelopeTolerance * scale;
}

[[nodiscard]] MetricIntervalEndpointV1 unresolved_endpoint(
    std::string label, std::vector<std::string> assumptions = {}) {
  return MetricIntervalEndpointV1{
      .value_status = BoundValueStatusV1::unresolved,
      .claim_state = CertificateClaimStateV1::not_established,
      .exact_value = std::nullopt,
      .numerical_value = std::nullopt,
      .source_label = std::move(label),
      .assumptions = std::move(assumptions),
  };
}

[[nodiscard]] MetricIntervalEndpointV1 finite_endpoint(
    const long double value, std::string label,
    std::vector<std::string> assumptions = {}) {
  return MetricIntervalEndpointV1{
      .value_status = BoundValueStatusV1::finite,
      .claim_state = CertificateClaimStateV1::established,
      .exact_value = std::nullopt,
      .numerical_value = value,
      .source_label = std::move(label),
      .assumptions = std::move(assumptions),
  };
}

[[nodiscard]] MetricIntervalEndpointV1 finite_exact_endpoint(
    ExactRational value, std::string label,
    std::vector<std::string> assumptions = {}) {
  const long double image = value.to_long_double();
  return MetricIntervalEndpointV1{
      .value_status = BoundValueStatusV1::finite,
      .claim_state = CertificateClaimStateV1::established,
      .exact_value = std::move(value),
      .numerical_value = image,
      .source_label = std::move(label),
      .assumptions = std::move(assumptions),
  };
}

[[nodiscard]] MetricInterval unavailable_interval(
    const MetricKindV1 kind, const EnvelopeEvaluationRouteV1 route,
    const EnvelopeTailSlackStatusV1 tail_status, std::string theorem,
    std::vector<std::string> diagnostics) {
  return MetricInterval{
      .claim_state = CertificateClaimStateV1::not_established,
      .metric_kind = kind,
      .route = route,
      .order_strength = ResponseOrderStrengthV1::pathwise_stochastic,
      .tail_slack_status = tail_status,
      .lower = unresolved_endpoint("faster-service lower endpoint"),
      .upper = unresolved_endpoint("slower-service upper endpoint"),
      .physical_transfer_claim =
          CertificateClaimStateV1::not_established,
      .arrival_intensity = std::nullopt,
      .slow_tail_service = std::nullopt,
      .fast_tail_service = std::nullopt,
      .slow_tail_slack = std::nullopt,
      .fast_tail_slack = std::nullopt,
      .theorem_id = std::move(theorem),
      .assumptions = {},
      .diagnostics = std::move(diagnostics),
      .numerical_method = "theorem route unavailable",
  };
}

[[nodiscard]] bool response_value_valid(const long double value) noexcept {
  return std::isfinite(value) && value >= 0.0L && value <= 1.0L;
}

[[nodiscard]] Result<void> validate_response_pair(
    const ScalarResponseCoefficientsV1& slow,
    const ScalarResponseCoefficientsV1& point,
    const ScalarResponseCoefficientsV1& fast) {
  const std::array<long double, 3U> slow_values{slow.one, slow.two,
                                                slow.tail};
  const std::array<long double, 3U> point_values{point.one, point.two,
                                                 point.tail};
  const std::array<long double, 3U> fast_values{fast.one, fast.two,
                                                fast.tail};
  for (std::size_t index = 0U; index < slow_values.size(); ++index) {
    if (!response_value_valid(slow_values[index]) ||
        !response_value_valid(point_values[index]) ||
        !response_value_valid(fast_values[index])) {
      return fail<void>(
          "c25.envelope_response_out_of_range",
          "every response-envelope coefficient must be finite and in [0,1]",
          DiagnosticCategory::input_validation,
          {"coefficient index " + std::to_string(index)});
    }
    if (slow_values[index] > point_values[index] ||
        point_values[index] > fast_values[index]) {
      return fail<void>(
          "c25.envelope_service_order_reversed",
          "the source response must lie pointwise between the slower and "
          "faster responses at every declared backlog bin",
          DiagnosticCategory::input_validation,
          {"coefficient index " + std::to_string(index)});
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool point_response_stage(
    const ResponseProductStageV1 stage) noexcept {
  return stage == ResponseProductStageV1::raw_response ||
         stage == ResponseProductStageV1::nominal_response ||
         stage == ResponseProductStageV1::recoded_response;
}

[[nodiscard]] Result<void> validate_envelope_product_bindings(
    const ResponseEnvelopeCertificateEvidenceV1& evidence) {
  const std::array<const EnvelopeResponseProductBindingV1*, 3U> bindings{
      &evidence.subject_product, &evidence.slow_product,
      &evidence.fast_product};
  const std::array<Digest256, 3U> legacy_identities{
      evidence.subject_product_identity, evidence.slow_product_identity,
      evidence.fast_product_identity};
  const std::array<std::string_view, 3U> labels{"subject", "slow", "fast"};
  for (std::size_t index = 0U; index < bindings.size(); ++index) {
    const EnvelopeResponseProductBindingV1& binding = *bindings[index];
    if (!(binding.identity == legacy_identities[index])) {
      return fail<void>(
          "c25.envelope_typed_product_identity_mismatch",
          "the typed response-product identity differs from its bound "
          "certificate identity",
          DiagnosticCategory::input_validation,
          {std::string(labels[index]) + " product"});
    }
    if (!point_response_stage(binding.stage)) {
      return fail<void>(
          "c25.envelope_mean_stage_not_response",
          "projection-center and projected-mean products cannot be evaluated "
          "as three-bin response coefficients",
          DiagnosticCategory::input_validation,
          {std::string(labels[index]) + " product"});
    }
    if (binding.raw_value_status != RawValueStatusV1::exact_point) {
      return fail<void>(
          "c25.envelope_interval_product_not_point_law",
          "an interval-only or absent raw value cannot be evaluated as a "
          "point response law",
          DiagnosticCategory::input_validation,
          {std::string(labels[index]) + " product"});
    }
    if (binding.validated_cross_product_transfer !=
        binding.transfer_evidence.has_value()) {
      return fail<void>(
          "c25.envelope_product_transfer_binding_incomplete",
          "a cross-product transfer flag and its typed evidence reference "
          "must be present together",
          DiagnosticCategory::input_validation,
          {std::string(labels[index]) + " product"});
    }
  }
  if (!(evidence.subject_product.law_identity ==
        evidence.subject_law_identity)) {
    return fail<void>(
        "c25.envelope_subject_law_identity_mismatch",
        "the evaluated point response does not bind the certificate subject "
        "law identity");
  }
  if (!evidence.subject_product.designated_deployed_point ||
      !evidence.slow_product.designated_deployed_point ||
      !evidence.fast_product.designated_deployed_point) {
    return fail<void>(
        "c25.envelope_subject_not_deployed_point",
        "F-C25-06 may evaluate only exact typed deployed point products for "
        "the subject and both envelope laws; a source product requires a "
        "validated transfer to a typed deployed destination first");
  }
  return Result<void>::success();
}

[[nodiscard]] long double response_at(
    const ScalarResponseCoefficientsV1& response,
    const std::uint64_t backlog) noexcept {
  if (backlog == 0U) {
    return 0.0L;
  }
  if (backlog == 1U) {
    return response.one;
  }
  if (backlog == 2U) {
    return response.two;
  }
  return response.tail;
}

struct EnvelopePmf final {
  std::vector<ScalarBatchMassV1> atoms;
  long double mean;
  long double second_moment;
  long double zero_mass;
  bool bernoulli;
};

[[nodiscard]] Result<EnvelopePmf> validate_envelope_pmf(
    const ResponseEnvelopeCertificateEvidenceV1& evidence) {
  if (evidence.iid_target_marginal.empty()) {
    return fail<EnvelopePmf>(
        "c25.envelope_iid_marginal_missing",
        "an IID envelope theorem requires the exact configured target "
        "marginal");
  }

  std::map<std::uint64_t, long double> combined;
  long double total = 0.0L;
  for (const ScalarBatchMassV1& atom : evidence.iid_target_marginal) {
    if (!finite_probability(atom.probability)) {
      return fail<EnvelopePmf>(
          "c25.envelope_arrival_probability_out_of_range",
          "every scalar arrival mass must be finite and in [0,1]");
    }
    combined[atom.batch] += atom.probability;
    total += atom.probability;
  }
  if (!std::isfinite(total) || !c25_close(total, 1.0L)) {
    return fail<EnvelopePmf>(
        "c25.envelope_arrival_mass_not_unit",
        "the configured IID target marginal must have unit mass",
        DiagnosticCategory::input_validation,
        {"reported mass " + std::to_string(static_cast<double>(total))});
  }

  std::vector<ScalarBatchMassV1> atoms;
  atoms.reserve(combined.size());
  long double mean = 0.0L;
  long double second = 0.0L;
  long double zero_mass = 0.0L;
  bool bernoulli = true;
  for (const auto& [batch, unnormalized] : combined) {
    const long double probability = unnormalized / total;
    if (probability == 0.0L) {
      continue;
    }
    atoms.push_back(ScalarBatchMassV1{batch, probability});
    const long double batch_value = static_cast<long double>(batch);
    mean = std::fma(probability, batch_value, mean);
    second = std::fma(probability, batch_value * batch_value, second);
    if (batch == 0U) {
      zero_mass = probability;
    }
    if (batch > 1U) {
      bernoulli = false;
    }
  }
  if (!std::isfinite(mean) || !std::isfinite(second)) {
    return fail<EnvelopePmf>(
        "c25.envelope_arrival_moment_overflow",
        "the configured scalar arrival moments are not representable",
        DiagnosticCategory::unavailable);
  }
  if (!c25_close(mean, evidence.lambda)) {
    return fail<EnvelopePmf>(
        "c25.envelope_arrival_mean_mismatch",
        "the declared arrival intensity does not equal the configured IID "
        "target marginal mean");
  }
  if (evidence.arrival_second_moment_finite &&
      !c25_close(second, evidence.arrival_second_moment)) {
    return fail<EnvelopePmf>(
        "c25.envelope_arrival_second_moment_mismatch",
        "the declared second arrival moment does not equal the configured IID "
        "target marginal moment");
  }
  bernoulli = bernoulli && mean > 0.0L && mean < 1.0L &&
              zero_mass > 0.0L;
  return Result<EnvelopePmf>::success(
      EnvelopePmf{std::move(atoms), mean, second, zero_mass, bernoulli});
}

[[nodiscard]] long double survival_probability(
    const EnvelopePmf& pmf, const std::uint64_t threshold) noexcept {
  if (threshold == 0U) {
    return 1.0L;
  }
  long double result = 0.0L;
  for (const ScalarBatchMassV1& atom : pmf.atoms) {
    if (atom.batch >= threshold) {
      result += atom.probability;
    }
  }
  return result;
}

struct EnvelopeRequest final {
  enum class Quantity : std::uint8_t {
    mean_backlog,
    mean_sojourn,
    backlog_tail,
    empty_probability,
    unsupported,
  };

  Quantity quantity;
  std::optional<BigNat> tail_threshold;
};

[[nodiscard]] EnvelopeRequest decode_envelope_request(
    const MetricRequest& request) {
  const MetricKindV1 kind = metric_request_kind(request);
  if (kind == MetricKindV1::mean_sojourn) {
    return EnvelopeRequest{EnvelopeRequest::Quantity::mean_sojourn,
                           std::nullopt};
  }
  if (kind == MetricKindV1::stationary_empty_probability) {
    return EnvelopeRequest{EnvelopeRequest::Quantity::empty_probability,
                           std::nullopt};
  }
  if (kind == MetricKindV1::stationary_backlog_tail) {
    const auto parameters =
        std::get<StationaryBacklogTailParametersV1>(
            metric_request_parameters(request));
    return EnvelopeRequest{EnvelopeRequest::Quantity::backlog_tail,
                           parameters.threshold};
  }
  if (kind == MetricKindV1::stationary_backlog_moment) {
    const auto parameters =
        std::get<StationaryBacklogMomentParametersV1>(
            metric_request_parameters(request));
    if (parameters.order == BigNat{1U}) {
      return EnvelopeRequest{EnvelopeRequest::Quantity::mean_backlog,
                             std::nullopt};
    }
  }
  return EnvelopeRequest{EnvelopeRequest::Quantity::unsupported,
                         std::nullopt};
}

[[nodiscard]] bool stationary_selection(
    const MetricSelectionRegimeV1 selection) noexcept {
  return selection == MetricSelectionRegimeV1::stationary_unique ||
         selection == MetricSelectionRegimeV1::stationary_class ||
         selection == MetricSelectionRegimeV1::stationary_mixture;
}

[[nodiscard]] Result<void> validate_envelope_request_binding(
    const ResponseEnvelopeCertificateEvidenceV1& evidence,
    const MetricRequest& request) {
  const MetricRequestHeader& header = metric_request_header(request);
  if (header.coupling != MetricTargetCouplingV1::scalar_singleton ||
      header.ordered_targets.size() != 1U ||
      !(header.ordered_targets.front().queue_id == evidence.target)) {
    return fail<void>(
        "c25.envelope_metric_target_mismatch",
        "the envelope evaluator requires its exact singleton target");
  }
  if (!stationary_selection(header.selection_regime)) {
    return fail<void>(
        "c25.envelope_metric_not_stationary",
        "a stationary response envelope cannot answer a transient request");
  }
  return Result<void>::success();
}

struct FiniteEnvelopeLaw final {
  std::vector<std::uint64_t> states;
  std::vector<long double> probabilities;
  long double mean;
  long double empty_probability;

  [[nodiscard]] long double tail_probability(
      const BigNat& threshold) const noexcept {
    long double result = 0.0L;
    for (std::size_t index = 0U; index < states.size(); ++index) {
      if (BigInt(states[index]) >= threshold.value()) {
        result += probabilities[index];
      }
    }
    return result;
  }
};

using SparseEnvelopeRow = std::map<std::uint64_t, long double>;

[[nodiscard]] Result<SparseEnvelopeRow> finite_envelope_row(
    const std::uint64_t level,
    const ScalarResponseCoefficientsV1& response, const EnvelopePmf& pmf,
    const std::uint64_t boundary, const std::string& role) {
  SparseEnvelopeRow row;
  const long double service = response_at(response, level);
  for (const ScalarBatchMassV1& atom : pmf.atoms) {
    if (atom.batch >
        std::numeric_limits<std::uint64_t>::max() - level) {
      return fail<SparseEnvelopeRow>(
          "c25.envelope_level_overflow",
          role + " transition overflows the represented backlog level",
          DiagnosticCategory::resource_limit);
    }
    const std::uint64_t no_service_next = level + atom.batch;
    const long double no_service_mass = atom.probability * (1.0L - service);
    if (no_service_mass > 0.0L) {
      if (no_service_next > boundary) {
        return fail<SparseEnvelopeRow>(
            "c25.envelope_exact_closure_violated",
            role + " has positive transition mass outside the claimed finite "
                   "boundary");
      }
      row[no_service_next] += no_service_mass;
    }
    if (level > 0U && service > 0.0L) {
      const std::uint64_t service_next = level - 1U + atom.batch;
      const long double service_mass = atom.probability * service;
      if (service_mass > 0.0L) {
        if (service_next > boundary) {
          return fail<SparseEnvelopeRow>(
              "c25.envelope_exact_closure_violated",
              role +
                  " has positive transition mass outside the claimed finite "
                  "boundary");
        }
        row[service_next] += service_mass;
      }
    }
  }
  long double total = 0.0L;
  for (const auto& [unused, mass] : row) {
    static_cast<void>(unused);
    total += mass;
  }
  if (!c25_close(total, 1.0L)) {
    return fail<SparseEnvelopeRow>(
        "c25.envelope_transition_mass_not_unit",
        role + " finite transition row does not have unit mass",
        DiagnosticCategory::internal);
  }
  for (auto& [unused, mass] : row) {
    static_cast<void>(unused);
    mass /= total;
  }
  return Result<SparseEnvelopeRow>::success(std::move(row));
}

[[nodiscard]] Result<std::vector<long double>> solve_invariant_probability(
    const std::vector<std::uint64_t>& closed_class,
    const std::map<std::uint64_t, SparseEnvelopeRow>& rows,
    const std::string& role) {
  const std::size_t dimension = closed_class.size();
  if (dimension == 0U) {
    return fail<std::vector<long double>>(
        "c25.envelope_empty_closed_class",
        role + " does not contain a selected closed class");
  }
  std::map<std::uint64_t, std::size_t> index;
  for (std::size_t ordinal = 0U; ordinal < dimension; ++ordinal) {
    index.emplace(closed_class[ordinal], ordinal);
  }
  std::vector<long double> augmented(dimension * (dimension + 1U), 0.0L);
  const auto at = [dimension, &augmented](const std::size_t row,
                                          const std::size_t column)
                      -> long double& {
    return augmented[row * (dimension + 1U) + column];
  };
  for (std::size_t equation = 0U; equation + 1U < dimension; ++equation) {
    for (std::size_t source = 0U; source < dimension; ++source) {
      const auto row = rows.find(closed_class[source]);
      if (row == rows.end()) {
        return fail<std::vector<long double>>(
            "c25.envelope_missing_finite_row",
            role + " is missing a row in its closed class",
            DiagnosticCategory::internal);
      }
      const auto mass = row->second.find(closed_class[equation]);
      if (mass != row->second.end()) {
        at(equation, source) += mass->second;
      }
      if (source == equation) {
        at(equation, source) -= 1.0L;
      }
    }
  }
  for (std::size_t column = 0U; column < dimension; ++column) {
    at(dimension - 1U, column) = 1.0L;
  }
  at(dimension - 1U, dimension) = 1.0L;

  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    for (std::size_t candidate = column + 1U; candidate < dimension;
         ++candidate) {
      if (std::fabs(at(candidate, column)) >
          std::fabs(at(pivot, column))) {
        pivot = candidate;
      }
    }
    if (std::fabs(at(pivot, column)) <= kEnvelopeTolerance) {
      return fail<std::vector<long double>>(
          "c25.envelope_stationary_system_singular",
          role + " finite stationary equations are singular",
          DiagnosticCategory::unavailable);
    }
    if (pivot != column) {
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        std::swap(at(column, entry), at(pivot, entry));
      }
    }
    const long double pivot_value = at(column, column);
    for (std::size_t entry = column; entry <= dimension; ++entry) {
      at(column, entry) /= pivot_value;
    }
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const long double factor = at(row, column);
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        at(row, entry) -= factor * at(column, entry);
      }
    }
  }

  std::vector<long double> probability(dimension, 0.0L);
  long double total = 0.0L;
  for (std::size_t index_value = 0U; index_value < dimension; ++index_value) {
    long double value = at(index_value, dimension);
    if (!std::isfinite(value) || value < -kEnvelopeTolerance) {
      return fail<std::vector<long double>>(
          "c25.envelope_stationary_probability_invalid",
          role + " finite solve produced a negative or nonfinite mass",
          DiagnosticCategory::unavailable);
    }
    if (value < 0.0L) {
      value = 0.0L;
    }
    probability[index_value] = value;
    total += value;
  }
  if (!std::isfinite(total) || total <= 0.0L) {
    return fail<std::vector<long double>>(
        "c25.envelope_stationary_normalization_failed",
        role + " finite stationary solve has no positive normalization",
        DiagnosticCategory::unavailable);
  }
  for (long double& value : probability) {
    value /= total;
  }
  return Result<std::vector<long double>>::success(std::move(probability));
}

[[maybe_unused, nodiscard]] Result<FiniteEnvelopeLaw>
solve_finite_envelope_law(
    const ScalarResponseCoefficientsV1& response, const EnvelopePmf& pmf,
    const ExactFiniteClosureEvidenceV1& closure, const std::string& role,
    const bool require_declared_class) {
  if (closure.boundary >= kMaximumFiniteEnvelopeStates) {
    return fail<FiniteEnvelopeLaw>(
        "c25.envelope_finite_boundary_resource_limit",
        role + " finite boundary exceeds the guarded exact-closure solver",
        DiagnosticCategory::resource_limit,
        {"boundary " + std::to_string(closure.boundary),
         "maximum " +
             std::to_string(kMaximumFiniteEnvelopeStates - 1U)});
  }
  if (closure.initial_support.empty()) {
    return fail<FiniteEnvelopeLaw>(
        "c25.envelope_initial_support_missing",
        "an exact finite-closure proof must name its selected initial support");
  }

  std::queue<std::uint64_t> pending;
  std::set<std::uint64_t> discovered;
  for (const std::uint64_t level : closure.initial_support) {
    if (level > closure.boundary) {
      return fail<FiniteEnvelopeLaw>(
          "c25.envelope_initial_support_outside_closure",
          role + " initial support lies outside the claimed finite boundary");
    }
    if (discovered.insert(level).second) {
      pending.push(level);
    }
  }
  std::map<std::uint64_t, SparseEnvelopeRow> rows;
  while (!pending.empty()) {
    const std::uint64_t level = pending.front();
    pending.pop();
    auto row = finite_envelope_row(level, response, pmf, closure.boundary,
                                   role);
    if (!row) {
      return Result<FiniteEnvelopeLaw>::failure(row.error());
    }
    for (const auto& [next, mass] : row.value()) {
      if (mass > 0.0L && discovered.insert(next).second) {
        pending.push(next);
      }
    }
    rows.emplace(level, std::move(row).value());
  }

  std::vector<std::uint64_t> vertices(discovered.begin(), discovered.end());
  std::map<std::uint64_t, std::size_t> vertex_index;
  for (std::size_t index = 0U; index < vertices.size(); ++index) {
    vertex_index.emplace(vertices[index], index);
  }
  std::vector<int> discovery(vertices.size(), -1);
  std::vector<int> low(vertices.size(), -1);
  std::vector<std::size_t> stack;
  std::vector<bool> on_stack(vertices.size(), false);
  std::vector<std::vector<std::uint64_t>> components;
  int next_discovery = 0;
  const auto visit = [&](const auto& self, const std::size_t vertex) -> void {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = true;
    for (const auto& [next_level, mass] : rows.at(vertices[vertex])) {
      if (mass <= 0.0L) {
        continue;
      }
      const std::size_t next = vertex_index.at(next_level);
      if (discovery[next] < 0) {
        self(self, next);
        low[vertex] = std::min(low[vertex], low[next]);
      } else if (on_stack[next]) {
        low[vertex] = std::min(low[vertex], discovery[next]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::uint64_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = false;
      component.push_back(vertices[member]);
      if (member == vertex) {
        break;
      }
    }
    std::ranges::sort(component);
    components.push_back(std::move(component));
  };
  for (std::size_t vertex = 0U; vertex < vertices.size(); ++vertex) {
    if (discovery[vertex] < 0) {
      visit(visit, vertex);
    }
  }

  std::vector<std::vector<std::uint64_t>> closed_components;
  for (const auto& component : components) {
    const std::set<std::uint64_t> members(component.begin(), component.end());
    bool closed = true;
    for (const std::uint64_t level : component) {
      for (const auto& [next, mass] : rows.at(level)) {
        if (mass > 0.0L && !members.contains(next)) {
          closed = false;
        }
      }
    }
    if (closed) {
      closed_components.push_back(component);
    }
  }
  if (closed_components.size() != 1U) {
    return fail<FiniteEnvelopeLaw>(
        "c25.envelope_closed_class_not_unique",
        role + " does not have exactly one closed class reachable from the "
               "selected initial support");
  }
  const std::vector<std::uint64_t>& closed_class = closed_components.front();
  if (require_declared_class) {
    std::vector<std::uint64_t> declared =
        closure.selected_accessible_class;
    std::ranges::sort(declared);
    if (declared != closed_class) {
      return fail<FiniteEnvelopeLaw>(
          "c25.envelope_selected_class_mismatch",
          "the slow-envelope closure proof names a different selected class "
          "than exact reachability establishes");
    }
  }

  auto probabilities =
      solve_invariant_probability(closed_class, rows, role);
  if (!probabilities) {
    return Result<FiniteEnvelopeLaw>::failure(probabilities.error());
  }
  long double mean = 0.0L;
  long double empty = 0.0L;
  for (std::size_t index = 0U; index < closed_class.size(); ++index) {
    mean = std::fma(static_cast<long double>(closed_class[index]),
                    probabilities.value()[index], mean);
    if (closed_class[index] == 0U) {
      empty = probabilities.value()[index];
    }
  }
  return Result<FiniteEnvelopeLaw>::success(FiniteEnvelopeLaw{
      closed_class, std::move(probabilities).value(), mean, empty});
}

struct ExactEnvelopePmf final {
  std::vector<ExactScalarBatchMassV1> atoms;
  ExactRational mean;
  ExactRational second_moment;
  ExactRational zero_mass;
  bool bernoulli;
};

struct ExactFiniteEnvelopeLaw final {
  std::vector<std::uint64_t> states;
  std::vector<ExactRational> probabilities;
  ExactRational mean;
  ExactRational empty_probability;

  [[nodiscard]] ExactRational tail_probability(
      const BigNat& threshold) const {
    ExactRational result = ExactRational::zero();
    for (std::size_t index = 0U; index < states.size(); ++index) {
      if (BigInt(states[index]) >= threshold.value()) {
        result = result + probabilities[index];
      }
    }
    return result;
  }
};

using ExactSparseEnvelopeRow =
    std::map<std::uint64_t, ExactRational>;

[[nodiscard]] ExactRational exact_nonnegative_integer(
    const std::uint64_t value) {
  // A denominator of one is infallible and cannot exceed the arbitrary-
  // precision representation.
  return ExactRational::make(BigInt(value), BigInt(1)).value();
}

[[nodiscard]] bool exact_probability(
    const ExactRational& value) noexcept {
  return value.is_nonnegative() && value <= ExactRational::one();
}

void add_exact_mass(ExactSparseEnvelopeRow& row,
                    const std::uint64_t destination,
                    const ExactRational& mass) {
  const auto found = row.find(destination);
  if (found == row.end()) {
    row.emplace(destination, mass);
  } else {
    found->second = found->second + mass;
  }
}

[[nodiscard]] std::vector<ExactScalarBatchMassV1> combine_exact_marginal(
    const std::vector<ExactScalarBatchMassV1>& input) {
  std::map<std::uint64_t, ExactRational> combined;
  for (const ExactScalarBatchMassV1& atom : input) {
    const auto found = combined.find(atom.batch);
    if (found == combined.end()) {
      combined.emplace(atom.batch, atom.probability);
    } else {
      found->second = found->second + atom.probability;
    }
  }
  std::vector<ExactScalarBatchMassV1> output;
  output.reserve(combined.size());
  for (auto& [batch, probability] : combined) {
    if (!probability.is_zero()) {
      output.push_back(
          ExactScalarBatchMassV1{batch, std::move(probability)});
    }
  }
  return output;
}

[[nodiscard]] Result<std::vector<ExactScalarBatchMassV1>>
sealed_exact_target_marginal(
    const ResponseEnvelope& envelope,
    const ResponseEnvelopeCertificateEvidenceV1& evidence) {
  using certificates::detail::C25CoreAccess;
  const certificates::detail::ValidatedCertificateCore* owner =
      C25CoreAccess::owner(envelope);
  if (owner == nullptr || !owner->framework_core) {
    return fail<std::vector<ExactScalarBatchMassV1>>(
        "c25.envelope_exact_arrival_carrier_missing",
        "the exact-closure view has lost its sealed configured-arrival "
        "carrier",
        DiagnosticCategory::internal);
  }
  const BuilderArrivalView arrival = builder_arrival_view(
      owner->framework_core->inputs().configured_arrival);
  if (!arrival.iid_joint_table().has_value() ||
      arrival.iid_joint_table()->empty()) {
    return fail<std::vector<ExactScalarBatchMassV1>>(
        "c25.envelope_exact_arrival_table_missing",
        "exact finite closure requires the sealed C09 exact IID joint "
        "table");
  }
  const QueueCatalog& queues = owner->framework_core->inputs().instance.queues();
  std::optional<std::size_t> target_ordinal;
  for (std::size_t ordinal = 0U; ordinal < queues.size(); ++ordinal) {
    auto dense = queues.index_at(ordinal);
    if (!dense) {
      return Result<std::vector<ExactScalarBatchMassV1>>::failure(
          dense.error());
    }
    if (queues.queue_id(dense.value()) == evidence.target) {
      target_ordinal = ordinal;
      break;
    }
  }
  if (!target_ordinal.has_value()) {
    return fail<std::vector<ExactScalarBatchMassV1>>(
        "c25.envelope_exact_target_missing",
        "the exact-closure target is absent from the sealed C09 queue "
        "catalog");
  }

  std::vector<ExactScalarBatchMassV1> marginal;
  marginal.reserve(arrival.iid_joint_table()->size());
  for (const ExactJointBatchMass& atom : *arrival.iid_joint_table()) {
    if (*target_ordinal >= atom.dense_counts.size() ||
        atom.dense_counts[*target_ordinal].bit_length() > 64U) {
      return fail<std::vector<ExactScalarBatchMassV1>>(
          "c25.envelope_exact_batch_not_representable",
          "an exact C09 target batch exceeds the finite-closure wire "
          "range",
          DiagnosticCategory::resource_limit);
    }
    marginal.push_back(ExactScalarBatchMassV1{
        atom.dense_counts[*target_ordinal]
            .value()
            .convert_to<std::uint64_t>(),
        atom.probability});
  }
  return Result<std::vector<ExactScalarBatchMassV1>>::success(
      combine_exact_marginal(marginal));
}

[[nodiscard]] bool exact_response_matches_image(
    const ExactScalarResponseCoefficientsV1& exact,
    const ScalarResponseCoefficientsV1& image) noexcept {
  return exact.one.to_long_double() == image.one &&
         exact.two.to_long_double() == image.two &&
         exact.tail.to_long_double() == image.tail;
}

[[nodiscard]] Result<ExactEnvelopePmf> validate_exact_closure_inputs(
    const ResponseEnvelopeCertificateEvidenceV1& evidence,
    const std::vector<ExactScalarBatchMassV1>& sealed_marginal) {
  if (!evidence.closure.exact_inputs.has_value()) {
    return fail<ExactEnvelopePmf>(
        "c25.envelope_exact_closure_inputs_missing",
        "an exact finite-closure claim requires exact rational response "
        "coefficients and the exact C09 target marginal");
  }
  const ExactFiniteEnvelopeInputsV1& inputs =
      *evidence.closure.exact_inputs;
  if (!exact_response_matches_image(inputs.mu_minus, evidence.mu_minus) ||
      !exact_response_matches_image(inputs.mu_point, evidence.mu_point) ||
      !exact_response_matches_image(inputs.mu_plus, evidence.mu_plus)) {
    return fail<ExactEnvelopePmf>(
        "c25.envelope_exact_response_image_mismatch",
        "the exact closure coefficients do not have the declared response "
        "coefficients as their numerical images");
  }

  const std::array<const ExactScalarResponseCoefficientsV1*, 3U> responses{
      &inputs.mu_minus, &inputs.mu_point, &inputs.mu_plus};
  for (const ExactScalarResponseCoefficientsV1* response : responses) {
    if (!exact_probability(response->one) ||
        !exact_probability(response->two) ||
        !exact_probability(response->tail)) {
      return fail<ExactEnvelopePmf>(
          "c25.envelope_exact_response_out_of_range",
          "every exact finite-closure response coefficient must lie in "
          "[0,1]");
    }
  }
  if (inputs.mu_minus.one > inputs.mu_point.one ||
      inputs.mu_point.one > inputs.mu_plus.one ||
      inputs.mu_minus.two > inputs.mu_point.two ||
      inputs.mu_point.two > inputs.mu_plus.two ||
      inputs.mu_minus.tail > inputs.mu_point.tail ||
      inputs.mu_point.tail > inputs.mu_plus.tail) {
    return fail<ExactEnvelopePmf>(
        "c25.envelope_exact_service_order_reversed",
        "the exact finite-closure response payload violates the certified "
        "pointwise order");
  }

  const std::vector<ExactScalarBatchMassV1> declared =
      combine_exact_marginal(inputs.iid_target_marginal);
  const std::vector<ExactScalarBatchMassV1> sealed =
      combine_exact_marginal(sealed_marginal);
  if (declared.size() != sealed.size()) {
    return fail<ExactEnvelopePmf>(
        "c25.envelope_exact_marginal_mismatch",
        "the exact closure marginal has different support from the sealed "
        "C09 target marginal");
  }
  for (std::size_t index = 0U; index < declared.size(); ++index) {
    if (declared[index].batch != sealed[index].batch ||
        declared[index].probability != sealed[index].probability) {
      return fail<ExactEnvelopePmf>(
          "c25.envelope_exact_marginal_mismatch",
          "the exact closure marginal differs from the sealed C09 target "
          "marginal");
    }
  }

  ExactRational total = ExactRational::zero();
  ExactRational mean = ExactRational::zero();
  ExactRational second = ExactRational::zero();
  ExactRational zero_mass = ExactRational::zero();
  bool bernoulli = true;
  for (const ExactScalarBatchMassV1& atom : declared) {
    if (!exact_probability(atom.probability)) {
      return fail<ExactEnvelopePmf>(
          "c25.envelope_exact_arrival_probability_out_of_range",
          "every exact target arrival mass must lie in [0,1]");
    }
    const ExactRational batch = exact_nonnegative_integer(atom.batch);
    total = total + atom.probability;
    mean = mean + atom.probability * batch;
    second = second + atom.probability * batch * batch;
    if (atom.batch == 0U) {
      zero_mass = zero_mass + atom.probability;
    }
    if (atom.batch > 1U && atom.probability.is_positive()) {
      bernoulli = false;
    }
  }
  if (total != ExactRational::one()) {
    return fail<ExactEnvelopePmf>(
        "c25.envelope_exact_arrival_mass_not_unit",
        "the exact C09 target marginal must sum to one exactly");
  }
  bernoulli = bernoulli && mean.is_positive() &&
              mean < ExactRational::one() && zero_mass.is_positive();
  return Result<ExactEnvelopePmf>::success(ExactEnvelopePmf{
      declared, std::move(mean), std::move(second), std::move(zero_mass),
      bernoulli});
}

[[nodiscard]] const ExactRational& exact_response_at(
    const ExactScalarResponseCoefficientsV1& response,
    const std::uint64_t backlog, const ExactRational& zero) noexcept {
  if (backlog == 0U) {
    return zero;
  }
  if (backlog == 1U) {
    return response.one;
  }
  if (backlog == 2U) {
    return response.two;
  }
  return response.tail;
}

[[nodiscard]] Result<ExactSparseEnvelopeRow> exact_finite_envelope_row(
    const std::uint64_t level,
    const ExactScalarResponseCoefficientsV1& response,
    const ExactEnvelopePmf& pmf, const std::uint64_t boundary,
    const std::string& role) {
  ExactSparseEnvelopeRow row;
  const ExactRational zero = ExactRational::zero();
  const ExactRational service = exact_response_at(response, level, zero);
  const ExactRational no_service = ExactRational::one() - service;
  for (const ExactScalarBatchMassV1& atom : pmf.atoms) {
    if (atom.batch >
        std::numeric_limits<std::uint64_t>::max() - level) {
      return fail<ExactSparseEnvelopeRow>(
          "c25.envelope_level_overflow",
          role + " transition overflows the represented backlog level",
          DiagnosticCategory::resource_limit);
    }
    const std::uint64_t no_service_next = level + atom.batch;
    const ExactRational no_service_mass =
        atom.probability * no_service;
    if (no_service_mass.is_positive()) {
      if (no_service_next > boundary) {
        return fail<ExactSparseEnvelopeRow>(
            "c25.envelope_exact_closure_violated",
            role + " has exact positive transition mass outside the "
                   "claimed finite boundary");
      }
      add_exact_mass(row, no_service_next, no_service_mass);
    }
    if (level > 0U && service.is_positive()) {
      const std::uint64_t service_next = level - 1U + atom.batch;
      const ExactRational service_mass = atom.probability * service;
      if (service_mass.is_positive()) {
        if (service_next > boundary) {
          return fail<ExactSparseEnvelopeRow>(
              "c25.envelope_exact_closure_violated",
              role + " has exact positive transition mass outside the "
                     "claimed finite boundary");
        }
        add_exact_mass(row, service_next, service_mass);
      }
    }
  }
  ExactRational total = ExactRational::zero();
  for (const auto& [unused, mass] : row) {
    static_cast<void>(unused);
    total = total + mass;
  }
  if (total != ExactRational::one()) {
    return fail<ExactSparseEnvelopeRow>(
        "c25.envelope_exact_transition_mass_not_unit",
        role + " exact finite transition row does not sum to one",
        DiagnosticCategory::internal);
  }
  return Result<ExactSparseEnvelopeRow>::success(std::move(row));
}

[[nodiscard]] Result<std::vector<ExactRational>>
solve_exact_invariant_probability(
    const std::vector<std::uint64_t>& closed_class,
    const std::map<std::uint64_t, ExactSparseEnvelopeRow>& rows,
    const std::string& role) {
  const std::size_t dimension = closed_class.size();
  if (dimension == 0U) {
    return fail<std::vector<ExactRational>>(
        "c25.envelope_empty_closed_class",
        role + " does not contain a selected closed class");
  }
  std::map<std::uint64_t, std::size_t> index;
  for (std::size_t ordinal = 0U; ordinal < dimension; ++ordinal) {
    index.emplace(closed_class[ordinal], ordinal);
  }
  std::vector<ExactRational> augmented(
      dimension * (dimension + 1U), ExactRational::zero());
  const auto at = [dimension, &augmented](const std::size_t row,
                                          const std::size_t column)
                      -> ExactRational& {
    return augmented[row * (dimension + 1U) + column];
  };
  for (std::size_t equation = 0U; equation + 1U < dimension; ++equation) {
    for (std::size_t source = 0U; source < dimension; ++source) {
      const auto row = rows.find(closed_class[source]);
      if (row == rows.end()) {
        return fail<std::vector<ExactRational>>(
            "c25.envelope_missing_finite_row",
            role + " is missing an exact row in its closed class",
            DiagnosticCategory::internal);
      }
      const auto mass = row->second.find(closed_class[equation]);
      if (mass != row->second.end()) {
        at(equation, source) = at(equation, source) + mass->second;
      }
      if (source == equation) {
        at(equation, source) =
            at(equation, source) - ExactRational::one();
      }
    }
  }
  for (std::size_t column = 0U; column < dimension; ++column) {
    at(dimension - 1U, column) = ExactRational::one();
  }
  at(dimension - 1U, dimension) = ExactRational::one();

  for (std::size_t column = 0U; column < dimension; ++column) {
    std::size_t pivot = column;
    while (pivot < dimension && at(pivot, column).is_zero()) {
      ++pivot;
    }
    if (pivot == dimension) {
      return fail<std::vector<ExactRational>>(
          "c25.envelope_exact_stationary_system_singular",
          role + " exact finite stationary equations are singular",
          DiagnosticCategory::unavailable);
    }
    if (pivot != column) {
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        std::swap(at(column, entry), at(pivot, entry));
      }
    }
    const ExactRational pivot_value = at(column, column);
    for (std::size_t entry = column; entry <= dimension; ++entry) {
      auto quotient = checked_divide(at(column, entry), pivot_value);
      if (!quotient) {
        return Result<std::vector<ExactRational>>::failure(
            quotient.error());
      }
      at(column, entry) = std::move(quotient).value();
    }
    for (std::size_t row = 0U; row < dimension; ++row) {
      if (row == column) {
        continue;
      }
      const ExactRational factor = at(row, column);
      for (std::size_t entry = column; entry <= dimension; ++entry) {
        at(row, entry) =
            at(row, entry) - factor * at(column, entry);
      }
    }
  }

  std::vector<ExactRational> probability;
  probability.reserve(dimension);
  ExactRational total = ExactRational::zero();
  for (std::size_t index_value = 0U; index_value < dimension;
       ++index_value) {
    const ExactRational& value = at(index_value, dimension);
    if (!value.is_nonnegative()) {
      return fail<std::vector<ExactRational>>(
          "c25.envelope_exact_stationary_probability_invalid",
          role + " exact finite solve produced a negative mass",
          DiagnosticCategory::unavailable);
    }
    probability.push_back(value);
    total = total + value;
  }
  if (total != ExactRational::one()) {
    return fail<std::vector<ExactRational>>(
        "c25.envelope_exact_stationary_normalization_failed",
        role + " exact stationary law does not sum to one",
        DiagnosticCategory::internal);
  }
  return Result<std::vector<ExactRational>>::success(
      std::move(probability));
}

[[nodiscard]] Result<ExactFiniteEnvelopeLaw>
solve_exact_finite_envelope_law(
    const ExactScalarResponseCoefficientsV1& response,
    const ExactEnvelopePmf& pmf,
    const ExactFiniteClosureEvidenceV1& closure, const std::string& role,
    const bool require_declared_class) {
  if (closure.boundary >= kMaximumFiniteEnvelopeStates) {
    return fail<ExactFiniteEnvelopeLaw>(
        "c25.envelope_finite_boundary_resource_limit",
        role + " finite boundary exceeds the guarded exact-closure solver",
        DiagnosticCategory::resource_limit,
        {"boundary " + std::to_string(closure.boundary),
         "maximum " +
             std::to_string(kMaximumFiniteEnvelopeStates - 1U)});
  }
  if (closure.initial_support.empty()) {
    return fail<ExactFiniteEnvelopeLaw>(
        "c25.envelope_initial_support_missing",
        "an exact finite-closure proof must name its selected initial "
        "support");
  }

  std::queue<std::uint64_t> pending;
  std::set<std::uint64_t> discovered;
  for (const std::uint64_t level : closure.initial_support) {
    if (level > closure.boundary) {
      return fail<ExactFiniteEnvelopeLaw>(
          "c25.envelope_initial_support_outside_closure",
          role + " initial support lies outside the claimed finite "
                 "boundary");
    }
    if (discovered.insert(level).second) {
      pending.push(level);
    }
  }
  std::map<std::uint64_t, ExactSparseEnvelopeRow> rows;
  while (!pending.empty()) {
    const std::uint64_t level = pending.front();
    pending.pop();
    auto row = exact_finite_envelope_row(level, response, pmf,
                                         closure.boundary, role);
    if (!row) {
      return Result<ExactFiniteEnvelopeLaw>::failure(row.error());
    }
    for (const auto& [next, mass] : row.value()) {
      if (mass.is_positive() && discovered.insert(next).second) {
        pending.push(next);
      }
    }
    rows.emplace(level, std::move(row).value());
  }

  std::vector<std::uint64_t> vertices(discovered.begin(), discovered.end());
  std::map<std::uint64_t, std::size_t> vertex_index;
  for (std::size_t index = 0U; index < vertices.size(); ++index) {
    vertex_index.emplace(vertices[index], index);
  }
  std::vector<int> discovery(vertices.size(), -1);
  std::vector<int> low(vertices.size(), -1);
  std::vector<std::size_t> stack;
  std::vector<bool> on_stack(vertices.size(), false);
  std::vector<std::vector<std::uint64_t>> components;
  int next_discovery = 0;
  const auto visit = [&](const auto& self, const std::size_t vertex) -> void {
    discovery[vertex] = next_discovery;
    low[vertex] = next_discovery;
    ++next_discovery;
    stack.push_back(vertex);
    on_stack[vertex] = true;
    for (const auto& [next_level, mass] : rows.at(vertices[vertex])) {
      if (!mass.is_positive()) {
        continue;
      }
      const std::size_t next = vertex_index.at(next_level);
      if (discovery[next] < 0) {
        self(self, next);
        low[vertex] = std::min(low[vertex], low[next]);
      } else if (on_stack[next]) {
        low[vertex] = std::min(low[vertex], discovery[next]);
      }
    }
    if (low[vertex] != discovery[vertex]) {
      return;
    }
    std::vector<std::uint64_t> component;
    while (true) {
      const std::size_t member = stack.back();
      stack.pop_back();
      on_stack[member] = false;
      component.push_back(vertices[member]);
      if (member == vertex) {
        break;
      }
    }
    std::ranges::sort(component);
    components.push_back(std::move(component));
  };
  for (std::size_t vertex = 0U; vertex < vertices.size(); ++vertex) {
    if (discovery[vertex] < 0) {
      visit(visit, vertex);
    }
  }

  std::vector<std::vector<std::uint64_t>> closed_components;
  for (const auto& component : components) {
    const std::set<std::uint64_t> members(component.begin(), component.end());
    bool closed = true;
    for (const std::uint64_t level : component) {
      for (const auto& [next, mass] : rows.at(level)) {
        if (mass.is_positive() && !members.contains(next)) {
          closed = false;
        }
      }
    }
    if (closed) {
      closed_components.push_back(component);
    }
  }
  if (closed_components.size() != 1U) {
    return fail<ExactFiniteEnvelopeLaw>(
        "c25.envelope_closed_class_not_unique",
        role + " does not have exactly one exact closed class reachable "
               "from the selected initial support");
  }
  const std::vector<std::uint64_t>& closed_class =
      closed_components.front();
  if (require_declared_class) {
    std::vector<std::uint64_t> declared =
        closure.selected_accessible_class;
    std::ranges::sort(declared);
    if (declared != closed_class) {
      return fail<ExactFiniteEnvelopeLaw>(
          "c25.envelope_selected_class_mismatch",
          "the slow-envelope closure proof names a different selected class "
          "than exact reachability establishes");
    }
  }

  auto probabilities =
      solve_exact_invariant_probability(closed_class, rows, role);
  if (!probabilities) {
    return Result<ExactFiniteEnvelopeLaw>::failure(probabilities.error());
  }
  ExactRational mean = ExactRational::zero();
  ExactRational empty = ExactRational::zero();
  for (std::size_t index = 0U; index < closed_class.size(); ++index) {
    mean = mean + exact_nonnegative_integer(closed_class[index]) *
                      probabilities.value()[index];
    if (closed_class[index] == 0U) {
      empty = probabilities.value()[index];
    }
  }
  return Result<ExactFiniteEnvelopeLaw>::success(ExactFiniteEnvelopeLaw{
      closed_class, std::move(probabilities).value(), std::move(mean),
      std::move(empty)});
}

struct ConstantTailLaw final {
  long double empty_probability;
  std::optional<long double> mean;
  std::optional<long double> requested_tail;
};

[[nodiscard]] Result<std::size_t> tail_recursion_limit(
    const std::optional<BigNat>& threshold) {
  if (!threshold.has_value() || threshold->is_zero()) {
    return Result<std::size_t>::success(2U);
  }
  if (threshold->value() > BigInt(kMaximumTailRecursionLevel)) {
    return fail<std::size_t>(
        "c25.envelope_tail_threshold_resource_limit",
        "the requested tail threshold exceeds the guarded finite recursion",
        DiagnosticCategory::resource_limit);
  }
  const std::size_t value = threshold->value().convert_to<std::size_t>();
  return Result<std::size_t>::success(std::max<std::size_t>(2U, value));
}

[[nodiscard]] Result<ConstantTailLaw> evaluate_constant_tail_law(
    const ScalarResponseCoefficientsV1& response, const EnvelopePmf& pmf,
    const bool need_mean, const bool second_moment_established,
    const std::optional<BigNat>& tail_threshold, const std::string& role) {
  if (!(pmf.zero_mass > 0.0L)) {
    return fail<ConstantTailLaw>(
        "c25.envelope_reachable_tail_requires_a0",
        role + " reachable-tail theorem requires positive zero-arrival mass");
  }
  if (!(response.one > 0.0L) || !(response.two > 0.0L) ||
      !(response.tail > pmf.mean)) {
    return fail<ConstantTailLaw>(
        "c25.envelope_reachable_tail_premise_failed",
        role + " does not have positive boundary service and strict tail "
               "slack");
  }
  auto limit = tail_recursion_limit(tail_threshold);
  if (!limit) {
    return Result<ConstantTailLaw>::failure(limit.error());
  }
  std::vector<long double> weights(limit.value() + 1U, 0.0L);
  weights[0U] = 1.0L;
  for (std::size_t level = 1U; level <= limit.value(); ++level) {
    const long double service =
        response_at(response, static_cast<std::uint64_t>(level));
    const long double denominator = pmf.zero_mass * service;
    if (!(denominator > 0.0L) || !std::isfinite(denominator)) {
      return fail<ConstantTailLaw>(
          "c25.envelope_cut_recursion_zero_denominator",
          role + " has a zero/nonfinite cut-recursion denominator");
    }
    long double numerator = 0.0L;
    for (std::size_t lower = 0U; lower < level; ++lower) {
      const long double lower_service =
          response_at(response, static_cast<std::uint64_t>(lower));
      const std::uint64_t gap = static_cast<std::uint64_t>(level - lower);
      const long double crossing =
          (1.0L - lower_service) * survival_probability(pmf, gap) +
          lower_service * survival_probability(pmf, gap + 1U);
      numerator = std::fma(weights[lower], crossing, numerator);
    }
    weights[level] = numerator / denominator;
    if (!c25_finite_nonnegative(weights[level])) {
      return fail<ConstantTailLaw>(
          "c25.envelope_cut_recursion_numeric_failure",
          role + " cut recursion produced a negative or nonfinite weight",
          DiagnosticCategory::unavailable);
    }
  }

  const std::array<long double, 3U> boundary_service{
      0.0L, response.one, response.two};
  long double normalization_polynomial = 0.0L;
  long double derivative_polynomial = 0.0L;
  for (std::size_t level = 0U; level <= 2U; ++level) {
    const long double correction =
        weights[level] * (response.tail - boundary_service[level]);
    normalization_polynomial += correction;
    derivative_polynomial += static_cast<long double>(level) * correction;
  }
  const long double slack = response.tail - pmf.mean;
  if (!(normalization_polynomial > 0.0L) || !std::isfinite(slack)) {
    return fail<ConstantTailLaw>(
        "c25.envelope_constant_tail_normalization_invalid",
        role + " SF.22d normalization is nonpositive or nonfinite",
        DiagnosticCategory::unavailable);
  }
  const long double pi0 = slack / normalization_polynomial;
  if (!finite_probability(pi0)) {
    return fail<ConstantTailLaw>(
        "c25.envelope_constant_tail_pi0_invalid",
        role + " SF.22d produced an invalid empty probability",
        DiagnosticCategory::unavailable);
  }

  std::optional<long double> mean;
  if (need_mean) {
    if (!second_moment_established) {
      return fail<ConstantTailLaw>(
          "c25.envelope_second_moment_not_established",
          role + " SF.22e mean requires an independently established finite "
                 "second arrival moment",
          DiagnosticCategory::unavailable);
    }
    const long double c_prime = pi0 * derivative_polynomial;
    const long double numerator =
        pmf.second_moment + pmf.mean - 2.0L * pmf.mean * pmf.mean +
        2.0L * c_prime;
    const long double value = numerator / (2.0L * slack);
    if (!std::isfinite(value) || value < -kEnvelopeTolerance) {
      return fail<ConstantTailLaw>(
          "c25.envelope_mean_numeric_failure",
          role + " SF.22e produced a negative or nonfinite mean",
          DiagnosticCategory::unavailable);
    }
    mean = std::max(0.0L, value);
  }

  std::optional<long double> tail;
  if (tail_threshold.has_value()) {
    if (tail_threshold->is_zero()) {
      tail = 1.0L;
    } else {
      const std::size_t threshold =
          tail_threshold->value().convert_to<std::size_t>();
      long double below = 0.0L;
      for (std::size_t level = 0U; level < threshold; ++level) {
        below = std::fma(pi0, weights[level], below);
      }
      long double value = 1.0L - below;
      if (value < 0.0L && value >= -kEnvelopeTolerance) {
        value = 0.0L;
      }
      if (value > 1.0L && value <= 1.0L + kEnvelopeTolerance) {
        value = 1.0L;
      }
      if (!finite_probability(value)) {
        return fail<ConstantTailLaw>(
            "c25.envelope_tail_probability_numeric_failure",
            role + " finite cut recursion produced an invalid tail "
                   "probability",
            DiagnosticCategory::unavailable);
      }
      tail = value;
    }
  }
  return Result<ConstantTailLaw>::success(
      ConstantTailLaw{pi0, mean, tail});
}

[[nodiscard]] bool little_law_established(
    const ResponseEnvelopeCertificateEvidenceV1& evidence) noexcept {
  return evidence.little_lossless && evidence.little_unit_packets &&
         evidence.little_eventual_departure &&
         evidence.little_positive_finite_intensity &&
         evidence.little_finite_backlog_first_moment && evidence.little_law &&
         evidence.lambda > 0.0L && std::isfinite(evidence.lambda);
}

[[nodiscard]] ResponseOrderStrengthV1 envelope_order_strength(
    const EnvelopePmf& pmf,
    const ResponseEnvelopeCertificateEvidenceV1& evidence) noexcept {
  const auto interior = [](const long double value) {
    return value > 0.0L && value < 1.0L;
  };
  if (pmf.bernoulli && interior(evidence.mu_minus.one) &&
      interior(evidence.mu_minus.two) &&
      interior(evidence.mu_minus.tail) &&
      interior(evidence.mu_point.one) &&
      interior(evidence.mu_point.two) &&
      interior(evidence.mu_point.tail) &&
      interior(evidence.mu_plus.one) && interior(evidence.mu_plus.two) &&
      interior(evidence.mu_plus.tail)) {
    return ResponseOrderStrengthV1::stationary_mlr_and_stochastic;
  }
  return ResponseOrderStrengthV1::stationary_stochastic;
}

[[nodiscard]] Result<MetricInterval> exact_finite_law_interval(
    const ResponseEnvelopeCertificateEvidenceV1& evidence,
    const ExactEnvelopePmf& pmf, const EnvelopeRequest& decoded,
    const MetricKindV1 kind, const ExactFiniteEnvelopeLaw& slow,
    const ExactFiniteEnvelopeLaw& fast) {
  ExactRational lower = ExactRational::zero();
  ExactRational upper = ExactRational::zero();
  std::string lower_label = "faster-service exact finite-class law";
  std::string upper_label = "slower-service exact finite-class law";
  if (decoded.quantity == EnvelopeRequest::Quantity::mean_backlog ||
      decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
    lower = fast.mean;
    upper = slow.mean;
    if (decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
      auto lower_sojourn = checked_divide(lower, pmf.mean);
      auto upper_sojourn = checked_divide(upper, pmf.mean);
      if (!lower_sojourn || !upper_sojourn) {
        return fail<MetricInterval>(
            "c25.envelope_exact_little_division_failed",
            "the exact finite-class Little-law conversion requires positive "
            "arrival intensity");
      }
      lower = std::move(lower_sojourn).value();
      upper = std::move(upper_sojourn).value();
      lower_label += "; exact Little-law mean sojourn including departure slot";
      upper_label += "; exact Little-law mean sojourn including departure slot";
    }
  } else if (decoded.quantity ==
             EnvelopeRequest::Quantity::empty_probability) {
    lower = slow.empty_probability;
    upper = fast.empty_probability;
    lower_label = "slower-service exact finite-class empty probability";
    upper_label = "faster-service exact finite-class empty probability";
  } else {
    lower = fast.tail_probability(*decoded.tail_threshold);
    upper = slow.tail_probability(*decoded.tail_threshold);
  }
  return Result<MetricInterval>::success(MetricInterval{
      .claim_state = CertificateClaimStateV1::established,
      .metric_kind = kind,
      .route = EnvelopeEvaluationRouteV1::exact_finite_closure,
      .order_strength = envelope_order_strength(
          EnvelopePmf{{}, pmf.mean.to_long_double(),
                      pmf.second_moment.to_long_double(),
                      pmf.zero_mass.to_long_double(), pmf.bernoulli},
          evidence),
      .tail_slack_status =
          EnvelopeTailSlackStatusV1::not_applicable_off_class,
      .lower = finite_exact_endpoint(std::move(lower),
                                     std::move(lower_label)),
      .upper = finite_exact_endpoint(std::move(upper),
                                     std::move(upper_label)),
      .physical_transfer_claim =
          CertificateClaimStateV1::not_established,
      .arrival_intensity = pmf.mean.to_long_double(),
      .slow_tail_service = evidence.mu_minus.tail,
      .fast_tail_service = evidence.mu_plus.tail,
      .slow_tail_slack = std::nullopt,
      .fast_tail_slack = std::nullopt,
      .theorem_id = "c25.response_envelope.exact_finite_closure.v1",
      .assumptions = {"exact slow-law reachability and closure",
                      "one reachable selected closed class",
                      "common arrivals and common uniform service coupling"},
      .diagnostics = {"tail_slack=not_applicable_off_class",
                      "closure_decisions=exact_rational",
                      "physical_transfer=not_established"},
      .numerical_method =
          "exact-rational finite transition construction; exact-positive "
          "SCC class check; exact-rational stationary linear solve; final "
          "presentation conversion only",
  });
}

[[maybe_unused, nodiscard]] MetricInterval finite_law_interval(
    const ResponseEnvelopeCertificateEvidenceV1& evidence,
    const EnvelopePmf& pmf, const EnvelopeRequest& decoded,
    const MetricKindV1 kind, const FiniteEnvelopeLaw& slow,
    const FiniteEnvelopeLaw& fast) {
  long double lower = 0.0L;
  long double upper = 0.0L;
  std::string lower_label = "faster-service finite-class law";
  std::string upper_label = "slower-service finite-class law";
  if (decoded.quantity == EnvelopeRequest::Quantity::mean_backlog ||
      decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
    lower = fast.mean;
    upper = slow.mean;
    if (decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
      lower /= pmf.mean;
      upper /= pmf.mean;
      lower_label += "; Little-law mean sojourn including departure slot";
      upper_label += "; Little-law mean sojourn including departure slot";
    }
  } else if (decoded.quantity ==
             EnvelopeRequest::Quantity::empty_probability) {
    lower = slow.empty_probability;
    upper = fast.empty_probability;
    lower_label = "slower-service finite-class empty probability";
    upper_label = "faster-service finite-class empty probability";
  } else {
    lower = fast.tail_probability(*decoded.tail_threshold);
    upper = slow.tail_probability(*decoded.tail_threshold);
  }
  return MetricInterval{
      .claim_state = CertificateClaimStateV1::established,
      .metric_kind = kind,
      .route = EnvelopeEvaluationRouteV1::exact_finite_closure,
      .order_strength = envelope_order_strength(pmf, evidence),
      .tail_slack_status =
          EnvelopeTailSlackStatusV1::not_applicable_off_class,
      .lower = finite_endpoint(lower, std::move(lower_label)),
      .upper = finite_endpoint(upper, std::move(upper_label)),
      .physical_transfer_claim =
          CertificateClaimStateV1::not_established,
      .arrival_intensity = pmf.mean,
      .slow_tail_service = evidence.mu_minus.tail,
      .fast_tail_service = evidence.mu_plus.tail,
      .slow_tail_slack = std::nullopt,
      .fast_tail_slack = std::nullopt,
      .theorem_id = "c25.response_envelope.exact_finite_closure.v1",
      .assumptions = {"exact slow-law reachability and closure",
                      "one reachable selected closed class",
                      "common arrivals and common uniform service coupling"},
      .diagnostics = {
          "tail_slack=not_applicable_off_class",
          "physical_transfer=not_established"},
      .numerical_method =
          "finite transition construction; SCC class check; pivoted "
          "stationary linear solve",
  };
}

[[nodiscard]] Result<MetricInterval> evaluate_iid_envelope(
    const ResponseEnvelopeCertificateEvidenceV1& evidence,
    const ResponseEnvelope& envelope, const MetricRequest& request) {
  auto pmf_result = validate_envelope_pmf(evidence);
  if (!pmf_result) {
    return Result<MetricInterval>::failure(pmf_result.error());
  }
  const EnvelopePmf& pmf = pmf_result.value();
  const MetricKindV1 kind = metric_request_kind(request);
  const EnvelopeRequest decoded = decode_envelope_request(request);
  if (decoded.quantity == EnvelopeRequest::Quantity::unsupported) {
    MetricInterval result = unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::unavailable,
        EnvelopeTailSlackStatusV1::not_established,
        "c25.response_envelope.unsupported_reward.v1",
        {"the requested reward is not a supported monotone scalar backlog "
         "consequence"});
    result.arrival_intensity = pmf.mean;
    return Result<MetricInterval>::success(std::move(result));
  }

  // Exact closure is deliberately evaluated before a0, tail slack, or an
  // arrival second-moment premise.  The proof names the slow product itself;
  // an equal-valued C19 deployed-point proof cannot enter this branch.
  const ExactFiniteClosureEvidenceV1& closure = evidence.closure;
  if (closure.established) {
    if (!(closure.bound_slow_product_identity ==
          evidence.slow_product_identity) ||
        !closure.exact_reachability ||
        !closure.unique_reachable_closed_class) {
      return fail<MetricInterval>(
          "c25.envelope_exact_closure_evidence_invalid",
          "the exact finite-closure evidence is not bound to the slow "
          "envelope product and selected class");
    }
    auto sealed_marginal = sealed_exact_target_marginal(envelope, evidence);
    if (!sealed_marginal) {
      return Result<MetricInterval>::failure(sealed_marginal.error());
    }
    auto exact_inputs = validate_exact_closure_inputs(
        evidence, sealed_marginal.value());
    if (!exact_inputs) {
      return Result<MetricInterval>::failure(exact_inputs.error());
    }
    const ExactFiniteEnvelopeInputsV1& exact = *closure.exact_inputs;
    auto slow = solve_exact_finite_envelope_law(
        exact.mu_minus, exact_inputs.value(), closure, "slow envelope",
        true);
    if (!slow) {
      return Result<MetricInterval>::failure(slow.error());
    }
    auto fast = solve_exact_finite_envelope_law(
        exact.mu_plus, exact_inputs.value(), closure, "fast envelope",
        false);
    if (!fast) {
      return Result<MetricInterval>::failure(fast.error());
    }
    if (decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn &&
        !little_law_established(evidence)) {
      MetricInterval result = unavailable_interval(
          kind, EnvelopeEvaluationRouteV1::exact_finite_closure,
          EnvelopeTailSlackStatusV1::not_applicable_off_class,
          "c25.response_envelope.exact_finite_closure.v1",
          {"mean sojourn requires every labelled Little-law premise and "
           "positive intensity"});
      result.arrival_intensity = pmf.mean;
      result.slow_tail_service = evidence.mu_minus.tail;
      result.fast_tail_service = evidence.mu_plus.tail;
      return Result<MetricInterval>::success(std::move(result));
    }
    return exact_finite_law_interval(evidence, exact_inputs.value(), decoded,
                                     kind, slow.value(), fast.value());
  }

  if (!evidence.tail.boundary_order_certified ||
      !evidence.tail.tail_order_certified) {
    return fail<MetricInterval>(
        "c25.envelope_reachable_tail_order_not_certified",
        "the reachable-tail route requires independent boundary and tail "
        "pointwise-order certificates");
  }
  if (!(pmf.zero_mass > 0.0L)) {
    return fail<MetricInterval>(
        "c25.envelope_reachable_tail_requires_a0",
        "the reachable-tail route requires positive zero-arrival mass");
  }
  if (!evidence.stationary_existence_convergence) {
    MetricInterval result = unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::reachable_tail_strict_slack,
        EnvelopeTailSlackStatusV1::applicable,
        "c25.response_envelope.reachable_tail.v1",
        {"stationary existence/convergence for the compared laws is not "
         "established"});
    result.arrival_intensity = pmf.mean;
    result.slow_tail_service = evidence.mu_minus.tail;
    result.fast_tail_service = evidence.mu_plus.tail;
    result.slow_tail_slack = evidence.mu_minus.tail - pmf.mean;
    result.fast_tail_slack = evidence.mu_plus.tail - pmf.mean;
    return Result<MetricInterval>::success(std::move(result));
  }

  const bool needs_mean =
      decoded.quantity == EnvelopeRequest::Quantity::mean_backlog ||
      decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn;
  if (decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn &&
      !little_law_established(evidence)) {
    MetricInterval result = unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::reachable_tail_strict_slack,
        EnvelopeTailSlackStatusV1::applicable,
        "c25.response_envelope.reachable_tail.v1",
        {"mean sojourn requires every labelled Little-law premise and "
         "positive intensity"});
    result.arrival_intensity = pmf.mean;
    result.slow_tail_service = evidence.mu_minus.tail;
    result.fast_tail_service = evidence.mu_plus.tail;
    result.slow_tail_slack = evidence.mu_minus.tail - pmf.mean;
    result.fast_tail_slack = evidence.mu_plus.tail - pmf.mean;
    return Result<MetricInterval>::success(std::move(result));
  }
  if (needs_mean && (!evidence.tail.finite_second_moment ||
                     !evidence.arrival_second_moment_finite)) {
    MetricInterval result = unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::reachable_tail_strict_slack,
        EnvelopeTailSlackStatusV1::applicable,
        "c25.response_envelope.reachable_tail.v1",
        {"SF.22e requires a finite independently established second arrival "
         "moment"});
    result.arrival_intensity = pmf.mean;
    result.slow_tail_service = evidence.mu_minus.tail;
    result.fast_tail_service = evidence.mu_plus.tail;
    result.slow_tail_slack = evidence.mu_minus.tail - pmf.mean;
    result.fast_tail_slack = evidence.mu_plus.tail - pmf.mean;
    return Result<MetricInterval>::success(std::move(result));
  }

  const bool slow_stable = evidence.mu_minus.tail > pmf.mean &&
                           evidence.mu_minus.one > 0.0L &&
                           evidence.mu_minus.two > 0.0L;
  const bool fast_stable = evidence.mu_plus.tail > pmf.mean &&
                           evidence.mu_plus.one > 0.0L &&
                           evidence.mu_plus.two > 0.0L;
  if (!slow_stable) {
    MetricInterval result = unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::reachable_tail_strict_slack,
        EnvelopeTailSlackStatusV1::applicable,
        "c25.response_envelope.reachable_tail.v1",
        {"the slow reachable tail lacks strict c_minus>lambda slack; no "
         "finite upper backlog side is claimed"});
    result.arrival_intensity = pmf.mean;
    result.slow_tail_service = evidence.mu_minus.tail;
    result.fast_tail_service = evidence.mu_plus.tail;
    result.slow_tail_slack = evidence.mu_minus.tail - pmf.mean;
    result.fast_tail_slack = evidence.mu_plus.tail - pmf.mean;
    if (fast_stable) {
      auto fast = evaluate_constant_tail_law(
          evidence.mu_plus, pmf, needs_mean,
          evidence.tail.finite_second_moment &&
              evidence.arrival_second_moment_finite,
          decoded.tail_threshold, "fast envelope");
      if (fast) {
        long double value = fast.value().empty_probability;
        if (decoded.quantity == EnvelopeRequest::Quantity::mean_backlog ||
            decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
          value = *fast.value().mean;
          if (decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
            value /= pmf.mean;
          }
          result.lower = finite_endpoint(
              value, "faster-service reachable-tail lower endpoint");
        } else if (decoded.quantity ==
                   EnvelopeRequest::Quantity::backlog_tail) {
          result.lower = finite_endpoint(
              *fast.value().requested_tail,
              "faster-service reachable-tail lower endpoint");
        } else {
          result.upper = finite_endpoint(
              value, "faster-service empty-probability upper endpoint");
        }
      }
    }
    return Result<MetricInterval>::success(std::move(result));
  }

  auto slow = evaluate_constant_tail_law(
      evidence.mu_minus, pmf, needs_mean,
      evidence.tail.finite_second_moment &&
          evidence.arrival_second_moment_finite,
      decoded.tail_threshold, "slow envelope");
  if (!slow) {
    return Result<MetricInterval>::failure(slow.error());
  }
  auto fast = evaluate_constant_tail_law(
      evidence.mu_plus, pmf, needs_mean,
      evidence.tail.finite_second_moment &&
          evidence.arrival_second_moment_finite,
      decoded.tail_threshold, "fast envelope");
  if (!fast) {
    return Result<MetricInterval>::failure(fast.error());
  }

  long double lower = 0.0L;
  long double upper = 0.0L;
  std::string lower_label = "faster-service reachable-tail law";
  std::string upper_label = "slower-service reachable-tail law";
  if (decoded.quantity == EnvelopeRequest::Quantity::mean_backlog ||
      decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
    lower = *fast.value().mean;
    upper = *slow.value().mean;
    if (decoded.quantity == EnvelopeRequest::Quantity::mean_sojourn) {
      lower /= pmf.mean;
      upper /= pmf.mean;
      lower_label += "; Little-law mean sojourn including departure slot";
      upper_label += "; Little-law mean sojourn including departure slot";
    }
  } else if (decoded.quantity ==
             EnvelopeRequest::Quantity::empty_probability) {
    lower = slow.value().empty_probability;
    upper = fast.value().empty_probability;
    lower_label = "slower-service empty probability";
    upper_label = "faster-service empty probability";
  } else {
    lower = *fast.value().requested_tail;
    upper = *slow.value().requested_tail;
  }

  return Result<MetricInterval>::success(MetricInterval{
      .claim_state = CertificateClaimStateV1::established,
      .metric_kind = kind,
      .route = EnvelopeEvaluationRouteV1::reachable_tail_strict_slack,
      .order_strength = envelope_order_strength(pmf, evidence),
      .tail_slack_status = EnvelopeTailSlackStatusV1::applicable,
      .lower = finite_endpoint(lower, std::move(lower_label)),
      .upper = finite_endpoint(upper, std::move(upper_label)),
      .physical_transfer_claim =
          CertificateClaimStateV1::not_established,
      .arrival_intensity = pmf.mean,
      .slow_tail_service = evidence.mu_minus.tail,
      .fast_tail_service = evidence.mu_plus.tail,
      .slow_tail_slack = evidence.mu_minus.tail - pmf.mean,
      .fast_tail_slack = evidence.mu_plus.tail - pmf.mean,
      .theorem_id = "c25.response_envelope.reachable_tail.v1",
      .assumptions = {"IID-across-slots configured target arrival",
                      "positive zero-arrival mass",
                      "certified pointwise boundary and tail order",
                      "strict slow-tail service slack",
                      "common arrivals and common uniform service coupling"},
      .diagnostics = {"physical_transfer=not_established"},
      .numerical_method =
          "finite cut recursion and local SF.22d/SF.22e evaluation",
  });
}

[[nodiscard]] Result<MetricInterval> evaluate_temporal_envelope(
    const ResponseEnvelopeCertificateEvidenceV1& evidence,
    const AuditedFrameworkBindingsV1& bindings,
    const MetricRequest& request) {
  const MetricKindV1 kind = metric_request_kind(request);
  if (!evidence.temporal_backend.has_value()) {
    return Result<MetricInterval>::success(unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::augmented_temporal_backend,
        EnvelopeTailSlackStatusV1::not_established,
        "c25.response_envelope.augmented_temporal_backend.v1",
        {"no accepted augmented-state temporal envelope backend is bound; "
         "the phase-free response remains valid"}));
  }
  const TemporalEnvelopeBackendEvidenceV1& backend =
      *evidence.temporal_backend;
  if (!(evidence.configured_arrival_identity ==
        bindings.problem_fingerprints.compiled_arrival) ||
      !(backend.accepted_contract_digest ==
        bindings.accepted_contract_digest) ||
      !(backend.configured_arrival_identity ==
        evidence.configured_arrival_identity) ||
      !(backend.slow_product_identity == evidence.slow_product_identity) ||
      !(backend.fast_product_identity == evidence.fast_product_identity)) {
    return fail<MetricInterval>(
        "c25.temporal_envelope_identity_mismatch",
        "the temporal backend does not bind the accepted carrier contract, "
        "configured arrival, and exact response-envelope products");
  }
  if (!backend.accepted || !backend.common_arrival_phase_coupling ||
      !backend.service_independent_phase || !backend.invariant_exists ||
      !backend.convergence_established) {
    return Result<MetricInterval>::success(unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::augmented_temporal_backend,
        EnvelopeTailSlackStatusV1::not_established,
        "c25.response_envelope.augmented_temporal_backend.v1",
        {"the augmented temporal theorem/backend lacks an acceptance, common "
         "phase coupling, invariant, or convergence premise"}));
  }

  const MetricRequestHeader& header = metric_request_header(request);
  auto request_digest = canonical_metric_requirements_digest(
      requirements_for_metric(request));
  if (!request_digest) {
    return Result<MetricInterval>::failure(request_digest.error());
  }
  const auto match = std::ranges::find_if(
      backend.metric_intervals,
      [&](const TemporalEnvelopeMetricIntervalV1& interval) {
        return interval.metric_kind == kind &&
               interval.metric_id == header.metric_id &&
               interval.normalized_request_digest == request_digest.value();
      });
  if (match == backend.metric_intervals.end()) {
    return Result<MetricInterval>::success(unavailable_interval(
        kind, EnvelopeEvaluationRouteV1::augmented_temporal_backend,
        EnvelopeTailSlackStatusV1::not_established,
        "c25.response_envelope.augmented_temporal_backend.v1",
        {"the accepted temporal backend does not authorize this exact metric "
         "request"}));
  }
  const auto endpoint = [](const BoundValueStatusV1 status,
                           const std::optional<long double> value,
                           std::string label)
      -> Result<MetricIntervalEndpointV1> {
    if (status == BoundValueStatusV1::finite) {
      if (!value.has_value() || !c25_finite_nonnegative(*value)) {
        return fail<MetricIntervalEndpointV1>(
            "c25.temporal_envelope_interval_invalid",
            "a finite temporal endpoint requires one finite nonnegative "
            "value");
      }
      return Result<MetricIntervalEndpointV1>::success(
          finite_endpoint(*value, std::move(label)));
    }
    if (value.has_value()) {
      return fail<MetricIntervalEndpointV1>(
          "c25.temporal_envelope_interval_invalid",
          "an infinite or unresolved temporal endpoint must not carry a "
          "finite numeric value");
    }
    return Result<MetricIntervalEndpointV1>::success(
        MetricIntervalEndpointV1{
            .value_status = status,
            .claim_state =
                status == BoundValueStatusV1::infinite
                    ? CertificateClaimStateV1::established
                    : CertificateClaimStateV1::not_established,
            .exact_value = std::nullopt,
            .numerical_value = std::nullopt,
            .source_label = std::move(label),
            .assumptions = {},
        });
  };
  auto lower = endpoint(
      match->lower_status, match->lower,
      "accepted augmented temporal faster-law endpoint");
  if (!lower) {
    return Result<MetricInterval>::failure(lower.error());
  }
  auto upper = endpoint(
      match->upper_status, match->upper,
      "accepted augmented temporal slower-law endpoint");
  if (!upper) {
    return Result<MetricInterval>::failure(upper.error());
  }
  if ((match->lower_status == BoundValueStatusV1::finite &&
       match->upper_status == BoundValueStatusV1::finite &&
       *match->lower > *match->upper) ||
      (match->lower_status == BoundValueStatusV1::infinite &&
       match->upper_status == BoundValueStatusV1::finite)) {
    return fail<MetricInterval>(
        "c25.temporal_envelope_interval_invalid",
        "the accepted temporal backend interval has reversed endpoint "
        "statuses or values");
  }
  const bool resolved =
      match->lower_status != BoundValueStatusV1::unresolved &&
      match->upper_status != BoundValueStatusV1::unresolved;
  return Result<MetricInterval>::success(MetricInterval{
      .claim_state = resolved ? CertificateClaimStateV1::established
                              : CertificateClaimStateV1::not_established,
      .metric_kind = kind,
      .route = EnvelopeEvaluationRouteV1::augmented_temporal_backend,
      .order_strength = ResponseOrderStrengthV1::stationary_stochastic,
      .tail_slack_status = EnvelopeTailSlackStatusV1::not_established,
      .lower = std::move(lower).value(),
      .upper = std::move(upper).value(),
      .physical_transfer_claim =
          CertificateClaimStateV1::not_established,
      .arrival_intensity = std::nullopt,
      .slow_tail_service = evidence.mu_minus.tail,
      .fast_tail_service = evidence.mu_plus.tail,
      .slow_tail_slack = std::nullopt,
      .fast_tail_slack = std::nullopt,
      .theorem_id =
          "c25.response_envelope.augmented_temporal_backend.v1",
      .assumptions = {"same configured augmented arrival process",
                      "common exogenous phase and arrival coupling",
                      "service-independent exogenous phase",
                      "backend-specific invariant existence and convergence"},
      .diagnostics = {"IID marginal replay was not used",
                      "physical_transfer=not_established"},
      .numerical_method = "validated bound backend result",
  });
}

}  // namespace

Result<StabilityCertificate> validate_drift_stability_witness(
    const DriftWitness& witness,
    const AuditedCompiledFramework& framework) {
  using certificates::detail::C25CoreAccess;
  if (!C25CoreAccess::same_framework(witness, framework)) {
    return fail<StabilityCertificate>(
        "c25.drift_framework_mismatch",
        "the drift witness was not issued for this audited framework");
  }
  if (!v0_witness_report(framework).passed()) {
    return fail<StabilityCertificate>(
        "c25.drift_v0_not_established",
        "schedule-coupled stability evaluation requires a successful V0 "
        "causality audit");
  }
  const DriftWitnessEvidenceV1& evidence = C25CoreAccess::drift(witness);
  const AuditedFrameworkBindingsV1& bindings =
      C25CoreAccess::framework_bindings(witness);
  if (!(evidence.configured_arrival_fingerprint ==
        bindings.problem_fingerprints.compiled_arrival)) {
    return fail<StabilityCertificate>(
        "c25.drift_arrival_identity_mismatch",
        "the drift witness names a different configured arrival law");
  }
  if (!evidence.retains_full_physical_backlog) {
    return fail<StabilityCertificate>(
        "c25.drift_full_backlog_not_retained",
        "a scalar target response cannot establish schedule-coupled drift");
  }
  if (!evidence.iid_across_slots_exact_joint) {
    return fail<StabilityCertificate>(
        "c25.drift_iid_joint_arrival_not_established",
        "the quadratic drift theorem requires the configured arrival-vector "
        "sequence to be IID across slots with its joint law retained");
  }
  if (!evidence.capacity_interior_verified) {
    return fail<StabilityCertificate>(
        "c25.drift_capacity_interior_not_verified",
        "lambda+epsilon*1 membership in the physical schedule capacity "
        "region is not independently verified");
  }
  if (!evidence.common_joint_schedule_law_established) {
    return fail<StabilityCertificate>(
        "c25.drift_common_joint_schedule_law_missing",
        "independently generated target services cannot establish a common "
        "physical schedule-coupled drift witness");
  }
  if (!evidence.declared_domain_forward_invariant ||
      !evidence.initial_support_contained) {
    return fail<StabilityCertificate>(
        "c25.drift_domain_not_forward_invariant",
        "the drift inequality must cover a forward-invariant domain "
        "containing the initial support");
  }
  const bool admissible_domain_coverage =
      evidence.domain_coverage ==
          CertificateCoverageV1::global_declared_domain ||
      evidence.domain_coverage ==
          CertificateCoverageV1::forward_invariant_domain ||
      evidence.domain_coverage ==
          CertificateCoverageV1::finite_complete_domain;
  if (!admissible_domain_coverage ||
      !evidence.all_declared_domain_rows_verified) {
    return fail<StabilityCertificate>(
        "c25.drift_domain_coverage_incomplete",
        "sampled rows or an incomplete finite subset cannot establish a "
        "global schedule-coupled drift inequality");
  }
  if (!evidence.initial_quadratic_backlog_moment_finite) {
    return fail<StabilityCertificate>(
        "c25.drift_initial_second_moment_not_established",
        "the time-average conclusion requires a finite quadratic initial "
        "backlog moment");
  }
  if (!std::isfinite(evidence.epsilon) || evidence.epsilon <= 0.0L ||
      !c25_finite_nonnegative(evidence.b) ||
      !c25_finite_nonnegative(evidence.delta) ||
      !c25_finite_nonnegative(evidence.deterministic_row_tolerance) ||
      !(evidence.delta < evidence.epsilon)) {
    return fail<StabilityCertificate>(
        "c25.drift_slack_invalid",
        "drift constants must satisfy epsilon>0, finite b and deterministic "
        "tolerance, and 0<=delta<epsilon");
  }
  const long double effective_b =
      evidence.b + evidence.deterministic_row_tolerance;
  if (!std::isfinite(effective_b)) {
    return fail<StabilityCertificate>(
        "c25.drift_bound_numeric_overflow",
        "adding the declared deterministic row tolerance to b overflows "
        "long-double arithmetic",
        DiagnosticCategory::unavailable);
  }
  if (!c25_finite_nonnegative(evidence.arrival_second_norm_moment) ||
      !c25_finite_nonnegative(evidence.max_schedule_squared_norm)) {
    return fail<StabilityCertificate>(
        "c25.drift_quadratic_constant_invalid",
        "arrival and feasible-schedule quadratic constants must be finite "
        "and nonnegative");
  }
  if (evidence.rows.empty()) {
    return fail<StabilityCertificate>(
        "c25.drift_domain_rows_missing",
        "the declared drift domain contains no verified rows");
  }
  for (std::size_t index = 0U; index < evidence.rows.size(); ++index) {
    const DriftRowEvidenceV1& row = evidence.rows[index];
    if (!row.common_feasible_schedule) {
      return fail<StabilityCertificate>(
          "c25.drift_common_schedule_missing",
          "every drift row must emit one common feasible eligible schedule",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(index)});
    }
    if (!c25_finite_nonnegative(row.h_capacity) ||
        !c25_finite_nonnegative(row.expected_q_dot_service) ||
        !c25_finite_nonnegative(row.backlog_l1)) {
      return fail<StabilityCertificate>(
          "c25.drift_row_value_invalid",
          "drift row values must be finite and nonnegative",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(index)});
    }
    const long double left =
        row.h_capacity - row.expected_q_dot_service;
    const long double right =
        effective_b + evidence.delta * row.backlog_l1;
    if (row.expected_q_dot_service >
        row.h_capacity + evidence.deterministic_row_tolerance) {
      return fail<StabilityCertificate>(
          "c25.drift_service_exceeds_capacity_support",
          "an expected feasible schedule reward cannot exceed the exact "
          "capacity support function",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(index)});
    }
    if (!std::isfinite(right) || left > right) {
      return fail<StabilityCertificate>(
          "c25.drift_row_inequality_failed",
          "a declared row violates the schedule-coupled Lyapunov premise",
          DiagnosticCategory::input_validation,
          {"row " + std::to_string(index)});
    }
  }

  const long double c0 = evidence.arrival_second_norm_moment +
                         evidence.max_schedule_squared_norm;
  const long double gap = evidence.epsilon - evidence.delta;
  const long double coefficient = 2.0L * gap;
  const long double numerator = c0 + 2.0L * effective_b;
  if (!std::isfinite(c0) || !std::isfinite(coefficient) ||
      !std::isfinite(numerator) || !(coefficient > 0.0L)) {
    return fail<StabilityCertificate>(
        "c25.drift_bound_numeric_overflow",
        "the verified drift constants are not representable in checked "
        "long-double arithmetic",
        DiagnosticCategory::unavailable);
  }
  const long double time_average_bound = numerator / coefficient;
  if (!c25_finite_nonnegative(time_average_bound)) {
    return fail<StabilityCertificate>(
        "c25.drift_bound_numeric_overflow",
        "the time-average backlog bound is not representable",
        DiagnosticCategory::unavailable);
  }

  const bool recurrence = evidence.irreducible && evidence.petite_set &&
                          evidence.norm_like_all_unbounded_phases;
  return Result<StabilityCertificate>::success(StabilityCertificate{
      .claim_state = CertificateClaimStateV1::established,
      .strongest_conclusion =
          recurrence ? StabilityConclusionV1::positive_recurrence
                     : StabilityConclusionV1::time_average_drift,
      .time_average_claim = CertificateClaimStateV1::established,
      .recurrence_claim =
          recurrence ? CertificateClaimStateV1::established
                     : CertificateClaimStateV1::not_established,
      .positive_recurrence_claim =
          recurrence ? CertificateClaimStateV1::established
                     : CertificateClaimStateV1::not_established,
      .time_average_bound_status = BoundValueStatusV1::finite,
      .epsilon = evidence.epsilon,
      .approximation_slope_delta = evidence.delta,
      .additive_gap_b = effective_b,
      .deterministic_row_tolerance =
          evidence.deterministic_row_tolerance,
      .arrival_second_norm_moment =
          evidence.arrival_second_norm_moment,
      .maximum_schedule_squared_norm =
          evidence.max_schedule_squared_norm,
      .common_joint_schedule_law_identity =
          evidence.common_joint_schedule_law_identity,
      .drift_constant_c0 = c0,
      .negative_drift_coefficient = coefficient,
      .time_average_backlog_bound = time_average_bound,
      .theorem_id = "c25.schedule_coupled_quadratic_drift.v1",
      .assumptions = {"IID arrival vectors across slots with joint law",
                      "finite second arrival-vector moment",
                      "one common feasible eligible schedule",
                      "lambda+epsilon*1 in the schedule capacity region",
                      "forward-invariant domain containing initial support",
                      "finite quadratic initial backlog moment"},
      .diagnostics = recurrence
                         ? std::vector<std::string>{
                               "positive recurrence premises independently "
                               "established"}
                         : std::vector<std::string>{
                               "positive_recurrence=not_established",
                               "time-average drift does not by itself imply "
                               "recurrence"},
      .numerical_method =
          "checked row inequalities and guarded long-double drift arithmetic",
  });
}

Result<MetricInterval> evaluate_response_envelope(
    const ResponseEnvelope& envelope, const CertificateArrivalLaw& arrival,
    const MetricRequest& request) {
  using certificates::detail::C25CoreAccess;
  if (!C25CoreAccess::same_owner(envelope, arrival)) {
    return fail<MetricInterval>(
        "c25.envelope_arrival_owner_mismatch",
        "the envelope and configured-arrival authority were not issued by "
        "the same validated certificate bundle");
  }
  const ResponseEnvelopeCertificateEvidenceV1& evidence =
      C25CoreAccess::envelope(envelope);
  const ResponseEnvelopeCertificateEvidenceV1& arrival_evidence =
      C25CoreAccess::arrival(arrival);
  if (!(evidence.evidence_id == arrival_evidence.evidence_id)) {
    return fail<MetricInterval>(
        "c25.envelope_arrival_evidence_mismatch",
        "the arrival authority is bound to a different response envelope");
  }
  auto request_binding = validate_envelope_request_binding(evidence, request);
  if (!request_binding) {
    return Result<MetricInterval>::failure(request_binding.error());
  }
  const AuditedFrameworkBindingsV1& bindings =
      C25CoreAccess::framework_bindings(envelope);
  if (!(evidence.configured_arrival_identity ==
        bindings.problem_fingerprints.compiled_arrival)) {
    return fail<MetricInterval>(
        "c25.envelope_configured_arrival_identity_mismatch",
        "the response envelope is not bound to the audited framework's "
        "configured arrival law");
  }
  if (!evidence.pointwise_order_independently_certified) {
    return fail<MetricInterval>(
        "c25.envelope_pointwise_order_not_certified",
        "numeric coefficient order is not a substitute for an independent "
        "pointwise response-envelope certificate");
  }
  auto response_pair = validate_response_pair(
      evidence.mu_minus, evidence.mu_point, evidence.mu_plus);
  if (!response_pair) {
    return Result<MetricInterval>::failure(response_pair.error());
  }
  auto product_bindings = validate_envelope_product_bindings(evidence);
  if (!product_bindings) {
    return Result<MetricInterval>::failure(product_bindings.error());
  }

  if (evidence.arrival_semantics ==
      EnvelopeArrivalSemanticsV1::temporal_augmented) {
    if (evidence.requested_route !=
        EnvelopeClosureRouteV1::temporal_backend) {
      return fail<MetricInterval>(
          "c25.envelope_arrival_route_mismatch",
          "a temporally dependent configured arrival requires the explicitly "
          "accepted augmented temporal envelope route");
    }
    return evaluate_temporal_envelope(evidence, bindings, request);
  }
  if (evidence.requested_route ==
      EnvelopeClosureRouteV1::temporal_backend) {
    return fail<MetricInterval>(
        "c25.envelope_arrival_route_mismatch",
        "an IID configured arrival cannot be relabelled as an augmented "
        "temporal backend route");
  }
  return evaluate_iid_envelope(evidence, envelope, request);
}

}  // namespace mwperf
