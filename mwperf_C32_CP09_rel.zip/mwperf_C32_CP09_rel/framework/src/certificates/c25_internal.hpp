#pragma once

#include <cstddef>
#include <memory>
#include <utility>
#include <vector>

#include "mwperf/certificates/certificate_bundle.hpp"

#include "../kernel/c17_core_internal.hpp"

namespace mwperf::certificates::detail {

struct ValidatedCertificateCore final {
  V0WitnessReport v0_report;
  V0WitnessBindingsV1 v0_bindings;
  AuditedFrameworkBindingsV1 framework_bindings;
  Digest256 graph_digest;
  std::vector<CertificateEvidenceNodeV1> nodes;
  std::vector<ValidatedClaimV1> claims;
  std::size_t v1_claim_index;
  std::size_t v2_claim_index;
  std::size_t stationary_claim_index;
  std::size_t physical_claim_index;
  std::size_t stability_claim_index;
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
      framework_seal;
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework_core;

  ValidatedCertificateCore(
      V0WitnessReport report, V0WitnessBindingsV1 bindings,
      AuditedFrameworkBindingsV1 audited_bindings, Digest256 digest,
      std::vector<CertificateEvidenceNodeV1> evidence_nodes,
      std::vector<ValidatedClaimV1> validated_claims,
      std::size_t v1_index, std::size_t v2_index,
      std::size_t stationary_index, std::size_t physical_index,
      std::size_t stability_index,
      std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
          seal,
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> sealed_core)
      : v0_report(std::move(report)),
        v0_bindings(std::move(bindings)),
        framework_bindings(std::move(audited_bindings)),
        graph_digest(std::move(digest)),
        nodes(std::move(evidence_nodes)),
        claims(std::move(validated_claims)),
        v1_claim_index(v1_index),
        v2_claim_index(v2_index),
        stationary_claim_index(stationary_index),
        physical_claim_index(physical_index),
        stability_claim_index(stability_index),
        framework_seal(std::move(seal)),
        framework_core(std::move(sealed_core)) {}
};

class C25CoreAccess final {
 public:
  C25CoreAccess() = delete;

  [[nodiscard]] static const AuditedFrameworkBindingsV1& framework_bindings(
      const AuditedCompiledFramework& framework) noexcept {
    return framework.bindings_;
  }

  [[nodiscard]] static const std::shared_ptr<
      surrogate::detail::SealedFrameworkCore>&
  framework_core(const AuditedCompiledFramework& framework) noexcept {
    return framework.c17_core_;
  }

  [[nodiscard]] static const std::shared_ptr<
      const surrogate::detail::AuditedConsumerSealIdentity>&
  framework_seal(const AuditedCompiledFramework& framework) noexcept {
    return framework.seal_;
  }

  [[nodiscard]] static bool same_framework(
      const ValidatedCertificateCore& core,
      const AuditedCompiledFramework& framework) noexcept {
    return core.framework_seal && framework.seal_ &&
           core.framework_seal == framework.seal_ &&
           core.framework_core == framework.c17_core_;
  }

  [[nodiscard]] static bool same_framework(
      const Evidence& evidence,
      const AuditedCompiledFramework& framework) noexcept {
    return evidence.framework_seal_ && evidence.framework_core_ &&
           framework.seal_ && framework.c17_core_ &&
           evidence.framework_seal_ == framework.seal_ &&
           evidence.framework_core_ == framework.c17_core_;
  }

  [[nodiscard]] static bool same_graph(
      const CertificateBundle& bundle,
      const Evidence& evidence) noexcept {
    return bundle.graph_seal_ && evidence.graph_seal_ &&
           bundle.graph_seal_ == evidence.graph_seal_;
  }

  [[nodiscard]] static ValidatedCertificates validated_certificates(
      std::shared_ptr<const ValidatedCertificateCore> core) {
    return ValidatedCertificates(std::move(core));
  }

  [[nodiscard]] static const std::shared_ptr<const ValidatedCertificateCore>&
  core(const ValidatedCertificates& certificates) noexcept {
    return certificates.core_;
  }

  [[nodiscard]] static RowErrorBound row_error_bound(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return RowErrorBound(std::move(core), index);
  }

  [[nodiscard]] static ContractionWitness contraction_witness(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return ContractionWitness(std::move(core), index);
  }

  [[nodiscard]] static KilledKernelPair killed_kernel_pair(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return KilledKernelPair(std::move(core), index);
  }

  [[nodiscard]] static ResolventWitness resolvent_witness(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return ResolventWitness(std::move(core), index);
  }

  [[nodiscard]] static DriftWitness drift_witness(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return DriftWitness(std::move(core), index);
  }

  [[nodiscard]] static ResponseEnvelope response_envelope(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return ResponseEnvelope(std::move(core), index);
  }

  [[nodiscard]] static CertificateArrivalLaw certificate_arrival_law(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return CertificateArrivalLaw(std::move(core), index);
  }

  [[nodiscard]] static PhysicalFidelityAnchor physical_fidelity_anchor(
      std::shared_ptr<const ValidatedCertificateCore> core,
      const std::size_t index) {
    return PhysicalFidelityAnchor(std::move(core), index);
  }

  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const RowErrorBound& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const ContractionWitness& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const KilledKernelPair& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const ResolventWitness& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const DriftWitness& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const ResponseEnvelope& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const CertificateArrivalLaw& value) noexcept {
    return value.core_.get();
  }
  [[nodiscard]] static const ValidatedCertificateCore* owner(
      const PhysicalFidelityAnchor& value) noexcept {
    return value.core_.get();
  }

  [[nodiscard]] static const RowErrorEvidenceV1& row_error(
      const RowErrorBound& value) noexcept {
    return std::get<RowErrorEvidenceV1>(value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const ContractionEvidenceV1& contraction(
      const ContractionWitness& value) noexcept {
    return std::get<ContractionEvidenceV1>(
        value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const KilledKernelPairEvidenceV1& killed_pair(
      const KilledKernelPair& value) noexcept {
    return std::get<KilledKernelPairEvidenceV1>(
        value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const ResolventEvidenceV1& resolvent(
      const ResolventWitness& value) noexcept {
    return std::get<ResolventEvidenceV1>(value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const DriftWitnessEvidenceV1& drift(
      const DriftWitness& value) noexcept {
    return std::get<DriftWitnessEvidenceV1>(
        value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const ResponseEnvelopeCertificateEvidenceV1& envelope(
      const ResponseEnvelope& value) noexcept {
    return std::get<ResponseEnvelopeCertificateEvidenceV1>(
        value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const ResponseEnvelopeCertificateEvidenceV1& arrival(
      const CertificateArrivalLaw& value) noexcept {
    return std::get<ResponseEnvelopeCertificateEvidenceV1>(
        value.core_->nodes[value.index_]);
  }
  [[nodiscard]] static const PhysicalFidelityEvidenceV1& physical_fidelity(
      const PhysicalFidelityAnchor& value) noexcept {
    return std::get<PhysicalFidelityEvidenceV1>(
        value.core_->nodes[value.index_]);
  }

  [[nodiscard]] static const AuditedFrameworkBindingsV1& framework_bindings(
      const DriftWitness& value) noexcept {
    return value.core_->framework_bindings;
  }
  [[nodiscard]] static const AuditedFrameworkBindingsV1& framework_bindings(
      const ResponseEnvelope& value) noexcept {
    return value.core_->framework_bindings;
  }
  [[nodiscard]] static const AuditedFrameworkBindingsV1& framework_bindings(
      const CertificateArrivalLaw& value) noexcept {
    return value.core_->framework_bindings;
  }

  [[nodiscard]] static bool same_owner(const RowErrorBound& left,
                                       const ContractionWitness& right)
      noexcept {
    return left.core_ && right.core_ && left.core_ == right.core_;
  }
  [[nodiscard]] static bool same_owner(const KilledKernelPair& left,
                                       const ResolventWitness& right)
      noexcept {
    return left.core_ && right.core_ && left.core_ == right.core_;
  }
  [[nodiscard]] static bool same_owner(const ResponseEnvelope& left,
                                       const CertificateArrivalLaw& right)
      noexcept {
    return left.core_ && right.core_ && left.core_ == right.core_;
  }

  [[nodiscard]] static bool same_framework(
      const DriftWitness& witness,
      const AuditedCompiledFramework& framework) noexcept {
    return witness.core_ && same_framework(*witness.core_, framework);
  }
};

}  // namespace mwperf::certificates::detail
