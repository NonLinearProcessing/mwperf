#include "mwperf/certificates/certificate_bundle.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <limits>
#include <span>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include "mwperf/arrival/build_view.hpp"

#include "c25_internal.hpp"

namespace mwperf {
namespace {

using certificates::detail::C25CoreAccess;
using certificates::detail::ValidatedCertificateCore;

template <typename T>
[[nodiscard]] Result<T> failure(std::string code, std::string message,
                                std::string path = {}) {
  return Result<T>::failure(Diagnostic{
      DiagnosticCategory::input_validation, std::move(code),
      std::move(message), path.empty() ? std::nullopt
                                       : std::optional<std::string>{path},
      std::nullopt, {}});
}

[[nodiscard]] Result<void> invalid(std::string code, std::string message,
                                   std::string path = {}) {
  return failure<void>(std::move(code), std::move(message), std::move(path));
}

[[nodiscard]] bool finite_nonnegative(const long double value) noexcept {
  return std::isfinite(value) && value >= 0.0L;
}

[[nodiscard]] bool probability(const long double value) noexcept {
  return finite_nonnegative(value) && value <= 1.0L;
}

[[nodiscard]] bool nonzero_digest(const Digest256& value) noexcept {
  return std::ranges::any_of(value.bytes(), [](const std::byte byte) {
    return byte != std::byte{0};
  });
}

[[nodiscard]] bool premise_bearing_claim(
    const CertificateClaimKindV1 kind) noexcept {
  switch (kind) {
    case CertificateClaimKindV1::v1_fibre_geometry:
    case CertificateClaimKindV1::v2_dynamic_lift:
    case CertificateClaimKindV1::stationary_integrated_fidelity:
    case CertificateClaimKindV1::physical_fidelity:
    case CertificateClaimKindV1::stability:
    case CertificateClaimKindV1::finite_horizon_transfer:
    case CertificateClaimKindV1::contraction_transfer:
    case CertificateClaimKindV1::stopped_resolvent_transfer:
    case CertificateClaimKindV1::response_envelope:
    case CertificateClaimKindV1::response_product_transfer:
    case CertificateClaimKindV1::decision_sensitivity:
    case CertificateClaimKindV1::poisson_reward:
      return true;
    case CertificateClaimKindV1::numerics:
    case CertificateClaimKindV1::complexity:
    case CertificateClaimKindV1::validation:
    case CertificateClaimKindV1::provenance:
    case CertificateClaimKindV1::premise:
      return false;
  }
  return false;
}

[[nodiscard]] bool valid_complexity_category(
    const ComplexityCostCategoryV1 category) noexcept {
  switch (category) {
    case ComplexityCostCategoryV1::construction:
    case ComplexityCostCategoryV1::calibration:
    case ComplexityCostCategoryV1::representation:
    case ComplexityCostCategoryV1::surrogate_solve:
    case ComplexityCostCategoryV1::optimizer_calls:
    case ComplexityCostCategoryV1::storage:
    case ComplexityCostCategoryV1::trace_warmup_and_dependence:
    case ComplexityCostCategoryV1::proposal_generation:
    case ComplexityCostCategoryV1::tail_proof:
    case ComplexityCostCategoryV1::certificate_evaluation:
      return true;
  }
  return false;
}

[[nodiscard]] bool valid_complexity_unit(
    const ComplexityCostUnitV1 unit) noexcept {
  switch (unit) {
    case ComplexityCostUnitV1::wall_clock_seconds:
    case ComplexityCostUnitV1::cpu_seconds:
    case ComplexityCostUnitV1::bytes:
    case ComplexityCostUnitV1::calls:
    case ComplexityCostUnitV1::samples:
    case ComplexityCostUnitV1::states:
    case ComplexityCostUnitV1::scalar_coefficients:
    case ComplexityCostUnitV1::dimensionless_work_units:
      return true;
  }
  return false;
}

[[nodiscard]] long double response_coefficient(
    const ScalarResponseCoefficientsV1& value,
    const ThreeBinCoefficientV1 coefficient) noexcept {
  switch (coefficient) {
    case ThreeBinCoefficientV1::one:
      return value.one;
    case ThreeBinCoefficientV1::two:
      return value.two;
    case ThreeBinCoefficientV1::tail_from_three:
      return value.tail;
  }
  return std::numeric_limits<long double>::quiet_NaN();
}

[[nodiscard]] const CertificateEvidenceIdV1& evidence_id(
    const CertificateEvidenceNodeV1& node) {
  return std::visit(
      [](const auto& value) -> const CertificateEvidenceIdV1& {
        return value.evidence_id;
      },
      node);
}

[[nodiscard]] std::span<const CertificateEvidenceIdV1> dependencies(
    const CertificateEvidenceNodeV1& node) {
  return std::visit(
      [](const auto& value) -> std::span<const CertificateEvidenceIdV1> {
        return value.dependencies;
      },
      node);
}

[[nodiscard]] CertificateClaimKindV1 node_kind(
    const CertificateEvidenceNodeV1& node) noexcept {
  return std::visit(
      [](const auto& value) noexcept {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, V1GeometryEvidenceV1>) {
          return CertificateClaimKindV1::v1_fibre_geometry;
        } else if constexpr (std::is_same_v<T, V2DynamicLiftEvidenceV1>) {
          return CertificateClaimKindV1::v2_dynamic_lift;
        } else if constexpr (
            std::is_same_v<T, StationaryIntegratedFidelityEvidenceV1>) {
          return CertificateClaimKindV1::stationary_integrated_fidelity;
        } else if constexpr (std::is_same_v<T,
                                            PhysicalFidelityEvidenceV1>) {
          return CertificateClaimKindV1::physical_fidelity;
        } else if constexpr (std::is_same_v<T, DriftWitnessEvidenceV1>) {
          return CertificateClaimKindV1::stability;
        } else if constexpr (std::is_same_v<T, RowErrorEvidenceV1>) {
          return CertificateClaimKindV1::finite_horizon_transfer;
        } else if constexpr (std::is_same_v<T, ContractionEvidenceV1>) {
          return CertificateClaimKindV1::contraction_transfer;
        } else if constexpr (
            std::is_same_v<T, KilledKernelPairEvidenceV1> ||
            std::is_same_v<T, ResolventEvidenceV1>) {
          return CertificateClaimKindV1::stopped_resolvent_transfer;
        } else if constexpr (
            std::is_same_v<T, ResponseEnvelopeCertificateEvidenceV1>) {
          return CertificateClaimKindV1::response_envelope;
        } else if constexpr (
            std::is_same_v<T, EnvelopeResponseProductTransferEvidenceV1>) {
          return CertificateClaimKindV1::response_product_transfer;
        } else if constexpr (
            std::is_same_v<T, DecisionSensitivityEvidenceV1>) {
          return CertificateClaimKindV1::decision_sensitivity;
        } else if constexpr (std::is_same_v<T, PoissonDefectEvidenceV1>) {
          return CertificateClaimKindV1::poisson_reward;
        } else if constexpr (
            std::is_same_v<T, CertificatePremiseEvidenceV1>) {
          return CertificateClaimKindV1::premise;
        } else if constexpr (
            std::is_same_v<T, ComplexityCostEvidenceV1>) {
          return CertificateClaimKindV1::complexity;
        } else {
          return value.kind;
        }
      },
      node);
}

[[nodiscard]] CertificateCoverageV1 node_coverage(
    const CertificateEvidenceNodeV1& node) noexcept {
  return std::visit(
      [](const auto& value) noexcept {
        using T = std::decay_t<decltype(value)>;
        if constexpr (requires { value.coverage; }) {
          return value.coverage;
        } else if constexpr (std::is_same_v<T, DriftWitnessEvidenceV1>) {
          return value.domain_coverage;
        } else if constexpr (
            std::is_same_v<T, StationaryIntegratedFidelityEvidenceV1> ||
            std::is_same_v<T, ContractionEvidenceV1>) {
          return CertificateCoverageV1::selected_stationary_integrated;
        } else if constexpr (
            std::is_same_v<T, KilledKernelPairEvidenceV1> ||
            std::is_same_v<T, ResolventEvidenceV1>) {
          return CertificateCoverageV1::finite_complete_domain;
        } else {
          return CertificateCoverageV1::global_declared_domain;
        }
      },
      node);
}

[[nodiscard]] std::optional<std::size_t> find_node(
    std::span<const CertificateEvidenceNodeV1> nodes,
    const CertificateEvidenceIdV1& wanted) {
  for (std::size_t index = 0; index < nodes.size(); ++index) {
    if (evidence_id(nodes[index]) == wanted) {
      return index;
    }
  }
  return std::nullopt;
}

class GraphEncoder final {
 public:
  void u8(const std::uint8_t value) {
    bytes_.push_back(static_cast<std::byte>(value));
  }
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(
          static_cast<std::byte>(value >> (shift - 8U)));
    }
  }
  void raw(std::span<const std::byte> bytes) {
    bytes_.insert(bytes_.end(), bytes.begin(), bytes.end());
  }
  void identity(const ArtifactObjectReferenceV1& value) {
    const std::vector<std::uint8_t> label = value.object_id.canonical_bytes();
    u64(static_cast<std::uint64_t>(label.size()));
    raw(std::as_bytes(std::span(label)));
    raw(value.object_digest.bytes());
  }
  [[nodiscard]] const std::vector<std::byte>& bytes() const noexcept {
    return bytes_;
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] Result<void> validate_matrix(const ExactDenseMatrixV1& matrix,
                                           const bool square,
                                           const std::string& path) {
  if (matrix.rows == 0U || matrix.columns == 0U ||
      (square && matrix.rows != matrix.columns) ||
      matrix.rows > std::numeric_limits<std::size_t>::max() /
                        matrix.columns ||
      matrix.entries.size() != matrix.rows * matrix.columns) {
    return invalid("c25.invalid_dense_matrix_shape",
                   "an exact dense matrix must have a complete, nonempty "
                   "declared shape",
                   path);
  }
  return Result<void>::success();
}

[[nodiscard]] TransferGeometryKindV1 geometry_kind(
    const MetricGeometry& geometry) noexcept {
  return std::visit(
      [](const auto& value) noexcept {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, TotalVariationGeometryV1>) {
          return TransferGeometryKindV1::total_variation;
        } else if constexpr (std::is_same_v<T, WassersteinGeometryV1>) {
          return TransferGeometryKindV1::wasserstein_metric;
        } else if constexpr (std::is_same_v<T, WeightedGeometryV1>) {
          return TransferGeometryKindV1::weighted_total_variation;
        } else {
          return TransferGeometryKindV1::operator_norm;
        }
      },
      geometry.value);
}

[[nodiscard]] bool is_response_stage(
    const ResponseProductStageV1 stage) noexcept {
  return stage == ResponseProductStageV1::raw_response ||
         stage == ResponseProductStageV1::nominal_response ||
         stage == ResponseProductStageV1::recoded_response;
}

[[nodiscard]] Result<void> validate_envelope_product_binding(
    const EnvelopeResponseProductBindingV1& binding,
    const std::string& path) {
  if (!is_response_stage(binding.stage)) {
    return invalid("c25.envelope_mean_stage_not_response",
                   "projection-center and projected-mean products cannot be "
                   "evaluated as three-bin response coefficients",
                   path);
  }
  if (binding.raw_value_status != RawValueStatusV1::exact_point) {
    return invalid("c25.envelope_product_not_point_valued",
                   "an interval-only or absent raw product is not a deployed "
                   "point response law",
                   path);
  }
  if (binding.validated_cross_product_transfer !=
      binding.transfer_evidence.has_value()) {
    return invalid("c25.envelope_transfer_binding_inconsistent",
                   "a cross-product transfer flag and its typed evidence "
                   "identity must be present together",
                   path);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_node_shape(
    const CertificateEvidenceNodeV1& node,
    const AuditedFrameworkBindingsV1& bindings) {
  return std::visit(
      [&](const auto& value) -> Result<void> {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, V1GeometryEvidenceV1>) {
          if (value.framework_fingerprint !=
              bindings.problem_fingerprints.resolved_instance) {
            return invalid("c25.v1_framework_binding_mismatch",
                           "V1 evidence names a different resolved physical "
                           "problem");
          }
        } else if constexpr (std::is_same_v<T,
                                            V2DynamicLiftEvidenceV1>) {
          if (value.framework_fingerprint !=
                  bindings.problem_fingerprints.resolved_instance ||
              value.configured_arrival_identity !=
                  bindings.problem_fingerprints.compiled_arrival) {
            return invalid("c25.v2_framework_binding_mismatch",
                           "V2 evidence changes the physical problem or "
                           "configured arrival law");
          }
          if (value.claims_path_identity &&
              (!value.lifted_initial_law_identity.has_value() ||
               !value.initial_support_established)) {
            return invalid("c25.v2_path_initial_lift_missing",
                           "a V2 path claim requires its lifted initial law "
                           "and initial-support witness");
          }
        } else if constexpr (
            std::is_same_v<T, StationaryIntegratedFidelityEvidenceV1>) {
          if (value.framework_fingerprint !=
              bindings.problem_fingerprints.resolved_instance) {
            return invalid("c25.stationary_fidelity_binding_mismatch",
                           "stationary integrated evidence names a different "
                           "resolved physical problem");
          }
          if (value.uses_requested_unknown_physical_stationary_law &&
              value.origin !=
                  CertificateEvidenceOriginV1::stationary_oracle_benchmark) {
            return invalid("c25.unlabelled_stationary_oracle",
                           "evidence using the requested unknown physical "
                           "stationary law must be labelled as an oracle "
                           "benchmark");
          }
        } else if constexpr (std::is_same_v<T,
                                            PhysicalFidelityEvidenceV1>) {
          if (value.framework_fingerprint !=
              bindings.problem_fingerprints.resolved_instance) {
            return invalid("c25.physical_fidelity_binding_mismatch",
                           "physical-fidelity evidence names a different "
                           "resolved physical problem");
          }
          if (value.uses_requested_unknown_physical_stationary_law &&
              value.origin !=
                  CertificateEvidenceOriginV1::stationary_oracle_benchmark) {
            return invalid("c25.unlabelled_stationary_oracle",
                           "physical evidence circularly using the requested "
                           "unknown stationary law must be labelled as an "
                           "oracle benchmark");
          }
          if (value.finite_bound.has_value() &&
              !finite_nonnegative(*value.finite_bound)) {
            return invalid("c25.invalid_physical_fidelity_bound",
                           "a finite physical-fidelity bound must be finite "
                           "and nonnegative");
          }
          if (value.finite_bound.has_value() &&
              value.kind != PhysicalFidelityKindV1::bounded &&
              value.kind != PhysicalFidelityKindV1::exact) {
            return invalid(
                "c25.physical_fidelity_bound_kind_mismatch",
                "only exact or theorem-bounded physical fidelity may carry a "
                "finite error bound");
          }
          if (value.kind == PhysicalFidelityKindV1::exact &&
              value.finite_bound.has_value() && *value.finite_bound != 0.0L) {
            return invalid("c25.nonzero_exact_physical_fidelity_bound",
                           "an exact physical-fidelity claim can carry only a "
                           "zero error bound");
          }
        } else if constexpr (std::is_same_v<T, RowErrorEvidenceV1>) {
          const bool probability_geometry =
              value.kind == RowErrorKindV1::marked_residence_event_row ||
              value.kind ==
                  RowErrorKindV1::approximate_relational_slot_row ||
              value.kind ==
                  RowErrorKindV1::stationary_uniform_total_variation;
          if ((probability_geometry && !probability(value.row_defect)) ||
              (!probability_geometry &&
               !finite_nonnegative(value.row_defect)) ||
              (value.initial_defect.has_value() &&
               !probability(*value.initial_defect))) {
            return invalid(
                "c25.invalid_row_defect",
                probability_geometry
                    ? "TV row and initial defects must lie in [0,1]"
                    : "Wasserstein/weighted row defects must be finite and "
                      "nonnegative");
          }
          if (value.initial_defect.has_value() &&
              value.kind !=
                  RowErrorKindV1::approximate_relational_slot_row) {
            return invalid(
                "c25.initial_defect_branch_mismatch",
                "only relational-slot evidence may carry an initial defect");
          }
          const TransferGeometryKindV1 kind = geometry_kind(value.geometry);
          const bool event = value.kind ==
                             RowErrorKindV1::marked_residence_event_row;
          const bool relational =
              value.kind ==
              RowErrorKindV1::approximate_relational_slot_row;
          if ((event && value.horizon_domain !=
                            HorizonDomainV1::complete_residence_words) ||
              (relational && value.horizon_domain !=
                                   HorizonDomainV1::relational_slots)) {
            return invalid("c25.row_horizon_domain_mismatch",
                           "event-row and relational-slot evidence cannot be "
                           "used with the other horizon type");
          }
          if ((event || relational ||
               value.kind ==
                   RowErrorKindV1::stationary_uniform_total_variation) &&
              kind != TransferGeometryKindV1::total_variation) {
            return invalid("c25.row_geometry_mismatch",
                           "the row defect geometry does not match its "
                           "declared theorem branch");
          }
          if (value.kind ==
                  RowErrorKindV1::stationary_wasserstein_occupation &&
              kind != TransferGeometryKindV1::wasserstein_metric) {
            return invalid("c25.row_geometry_mismatch",
                           "Wasserstein occupation evidence requires a "
                           "Wasserstein metric geometry");
          }
          if (value.kind == RowErrorKindV1::stationary_weighted_norm &&
              kind != TransferGeometryKindV1::weighted_total_variation) {
            return invalid("c25.row_geometry_mismatch",
                           "weighted row evidence requires weighted "
                           "total-variation geometry");
          }
          if (event && !value.equal_initial_law) {
            return invalid("c25.event_row_initial_law_mismatch",
                           "the marked-residence event formula requires an "
                           "equal initial law");
          }
          if (event && !value.common_refinement_established) {
            return invalid("c25.event_row_common_refinement_missing",
                           "residence segmentations require an established "
                           "common refinement");
          }
        } else if constexpr (std::is_same_v<T, ContractionEvidenceV1>) {
          if (!std::isfinite(value.coefficient) || value.coefficient < 0.0L) {
            return invalid("c25.invalid_contraction_coefficient",
                           "a contraction coefficient must be finite and "
                           "nonnegative");
          }
        } else if constexpr (
            std::is_same_v<T, KilledKernelPairEvidenceV1>) {
          auto left = validate_matrix(value.reference_killed_kernel, true,
                                      "/evidence/killed/reference");
          if (!left) return left;
          auto right = validate_matrix(value.approximate_killed_kernel, true,
                                       "/evidence/killed/approximate");
          if (!right) return right;
          if (value.reference_killed_kernel.rows !=
              value.approximate_killed_kernel.rows) {
            return invalid("c25.killed_kernel_dimension_mismatch",
                           "compared killed kernels must use one ordered "
                           "state space");
          }
        } else if constexpr (std::is_same_v<T, ResolventEvidenceV1>) {
          auto left = validate_matrix(value.reference_resolvent, true,
                                      "/evidence/resolvent/reference");
          if (!left) return left;
          auto right = validate_matrix(value.approximate_resolvent, true,
                                       "/evidence/resolvent/approximate");
          if (!right) return right;
          if (value.reference_resolvent.rows !=
                  value.approximate_resolvent.rows ||
              value.norm.weights.size() != value.reference_resolvent.rows) {
            return invalid("c25.resolvent_dimension_mismatch",
                           "resolvents and weighted operator norm must share "
                           "one state dimension");
          }
        } else if constexpr (std::is_same_v<T,
                                            DriftWitnessEvidenceV1>) {
          if (value.framework_fingerprint !=
                  bindings.problem_fingerprints.resolved_instance ||
              value.configured_arrival_fingerprint !=
                  bindings.problem_fingerprints.compiled_arrival) {
            return invalid("c25.drift_framework_binding_mismatch",
                           "drift evidence changes the physical problem or "
                           "configured arrival law");
          }
          if (!std::isfinite(value.epsilon) || value.epsilon <= 0.0L ||
              !finite_nonnegative(value.b) ||
              !finite_nonnegative(value.delta) ||
              !finite_nonnegative(value.deterministic_row_tolerance) ||
              !finite_nonnegative(value.arrival_second_norm_moment) ||
              !finite_nonnegative(value.max_schedule_squared_norm)) {
            return invalid("c25.invalid_drift_constants",
                           "drift constants and moments must be finite with "
                           "strictly positive epsilon");
          }
          if (value.domain_coverage == CertificateCoverageV1::sampled_only ||
              (value.domain_coverage !=
                   CertificateCoverageV1::global_declared_domain &&
               value.domain_coverage !=
                   CertificateCoverageV1::forward_invariant_domain &&
               value.domain_coverage !=
                   CertificateCoverageV1::finite_complete_domain)) {
            return invalid(
                "c25.drift_domain_coverage_incomplete",
                "drift evidence must cover its complete declared domain, not "
                "only sampled rows");
          }
        } else if constexpr (
            std::is_same_v<T, ResponseEnvelopeCertificateEvidenceV1>) {
          if (value.framework_fingerprint !=
                  bindings.problem_fingerprints.resolved_instance ||
              value.configured_arrival_identity !=
                  bindings.problem_fingerprints.compiled_arrival) {
            return invalid("c25.envelope_framework_binding_mismatch",
                           "response-envelope evidence names a different "
                           "resolved physical problem or configured arrival "
                           "law");
          }
          if (value.subject_product.identity !=
                  value.subject_product_identity ||
              value.subject_product.law_identity != value.subject_law_identity ||
              value.slow_product.identity != value.slow_product_identity ||
              value.fast_product.identity != value.fast_product_identity) {
            return invalid(
                "c25.envelope_product_binding_mismatch",
                "the typed envelope product bindings must exactly match the "
                "subject, slow, fast, and law identities they qualify");
          }
          auto subject_binding = validate_envelope_product_binding(
              value.subject_product, "/evidence/envelope/subject_product");
          if (!subject_binding) return subject_binding;
          auto slow_binding = validate_envelope_product_binding(
              value.slow_product, "/evidence/envelope/slow_product");
          if (!slow_binding) return slow_binding;
          auto fast_binding = validate_envelope_product_binding(
              value.fast_product, "/evidence/envelope/fast_product");
          if (!fast_binding) return fast_binding;
          if (!value.subject_product.designated_deployed_point ||
              !value.slow_product.designated_deployed_point ||
              !value.fast_product.designated_deployed_point) {
            return invalid(
                "c25.envelope_product_not_designated_point",
                "every evaluated subject, slow, and fast binding must name "
                "an exact designated point-response product; raw sources "
                "must first transfer to those destination identities");
          }
          const auto coefficient_ok = [](const long double coefficient) {
            return probability(coefficient);
          };
          if (!coefficient_ok(value.mu_minus.one) ||
              !coefficient_ok(value.mu_minus.two) ||
              !coefficient_ok(value.mu_minus.tail) ||
              !coefficient_ok(value.mu_point.one) ||
              !coefficient_ok(value.mu_point.two) ||
              !coefficient_ok(value.mu_point.tail) ||
              !coefficient_ok(value.mu_plus.one) ||
              !coefficient_ok(value.mu_plus.two) ||
              !coefficient_ok(value.mu_plus.tail)) {
            return invalid("c25.invalid_envelope_response",
                           "all response-envelope coefficients must lie in "
                           "[0,1]");
          }
          if (!value.pointwise_order_independently_certified ||
              value.mu_plus.one < value.mu_point.one ||
              value.mu_point.one < value.mu_minus.one ||
              value.mu_plus.two < value.mu_point.two ||
              value.mu_point.two < value.mu_minus.two ||
              value.mu_plus.tail < value.mu_point.tail ||
              value.mu_point.tail < value.mu_minus.tail) {
            return invalid("c25.response_envelope_order_not_established",
                           "a response envelope requires an independently "
                           "certified mu_plus >= mu >= mu_minus order for the "
                           "exact point product");
          }
          if (!finite_nonnegative(value.lambda) ||
              !finite_nonnegative(value.arrival_second_moment)) {
            return invalid("c25.invalid_envelope_arrival_moment",
                           "arrival intensity and second moment must be finite "
                           "and nonnegative");
          }
          if (value.closure.established &&
              value.closure.bound_slow_product_identity !=
                  value.slow_product.identity) {
            return invalid(
                "c25.envelope_closure_product_mismatch",
                "exact finite closure must name the exact slow-envelope "
                "product");
          }
          if (value.temporal_backend.has_value()) {
            const auto& backend = *value.temporal_backend;
            if (value.arrival_semantics !=
                    EnvelopeArrivalSemanticsV1::temporal_augmented ||
                value.requested_route !=
                    EnvelopeClosureRouteV1::temporal_backend) {
              return invalid(
                  "c25.temporal_envelope_backend_route_mismatch",
                  "an augmented temporal backend may qualify only a temporal "
                  "configured-arrival envelope route");
            }
            if (backend.accepted_contract_digest !=
                    bindings.accepted_contract_digest ||
                backend.configured_arrival_identity !=
                    value.configured_arrival_identity ||
                backend.slow_product_identity != value.slow_product.identity ||
                backend.fast_product_identity != value.fast_product.identity) {
              return invalid(
                  "c25.temporal_envelope_backend_binding_mismatch",
                  "a temporal envelope backend must bind the carrier's exact "
                  "accepted contract, configured arrival, and slow/fast "
                  "response products");
            }
            if (!nonzero_digest(backend.backend_identity) ||
                !nonzero_digest(backend.theorem_identity) ||
                std::find(value.dependencies.begin(), value.dependencies.end(),
                          backend.evidence_dependency) ==
                    value.dependencies.end()) {
              return invalid(
                  "c25.temporal_envelope_backend_evidence_missing",
                  "a temporal envelope backend requires explicit nonzero "
                  "backend/theorem identities and a graph dependency");
            }
            for (std::size_t interval_index = 0U;
                 interval_index < backend.metric_intervals.size();
                 ++interval_index) {
              const auto& interval =
                  backend.metric_intervals[interval_index];
              const bool lower_finite =
                  interval.lower_status == BoundValueStatusV1::finite;
              const bool upper_finite =
                  interval.upper_status == BoundValueStatusV1::finite;
              if (interval.metric_id.empty() ||
                  !nonzero_digest(interval.normalized_request_digest) ||
                  lower_finite != interval.lower.has_value() ||
                  upper_finite != interval.upper.has_value() ||
                  (interval.lower.has_value() &&
                   !finite_nonnegative(*interval.lower)) ||
                  (interval.upper.has_value() &&
                   !finite_nonnegative(*interval.upper)) ||
                  (interval.lower.has_value() && interval.upper.has_value() &&
                   *interval.lower > *interval.upper)) {
                return invalid(
                    "c25.invalid_temporal_envelope_interval",
                    "temporal endpoint statuses and nonnegative ordered "
                    "values must agree exactly");
              }
              for (std::size_t prior = 0U; prior < interval_index; ++prior) {
                if (backend.metric_intervals[prior]
                        .normalized_request_digest ==
                    interval.normalized_request_digest) {
                  return invalid(
                      "c25.duplicate_temporal_envelope_request",
                      "a temporal backend cannot provide two intervals for "
                      "one canonical metric request identity");
                }
              }
            }
          }
        } else if constexpr (
            std::is_same_v<T, EnvelopeResponseProductTransferEvidenceV1>) {
          if (!is_response_stage(value.source_stage) ||
              !is_response_stage(value.destination_stage) ||
              value.source_value_status == RawValueStatusV1::absent ||
              value.destination_value_status !=
                  RawValueStatusV1::exact_point ||
              value.direction !=
                  ResponseProductTransferDirectionV1::source_to_destination ||
              !value.direction_and_assumptions_validated ||
              !value.destination_is_designated_deployed_point ||
              value.source_reference.object_digest !=
                  value.source_product_identity ||
              (value.source_product_identity ==
                   value.destination_product_identity &&
               value.source_stage == value.destination_stage &&
               value.source_law_identity == value.destination_law_identity) ||
              std::find(value.dependencies.begin(), value.dependencies.end(),
                        value.source_evidence) == value.dependencies.end() ||
              value.assumptions.empty() ||
              std::ranges::any_of(value.assumptions,
                                  [](const std::string& assumption) {
                                    return assumption.empty();
                                  })) {
            return invalid(
                "c25.invalid_envelope_cross_product_transfer",
                "an envelope transfer must map an evidenced available typed "
                "response source, under explicit assumptions and direction, "
                "to a distinct exact designated point law");
          }
          std::array<bool, 3U> seen{};
          for (const auto& interval : value.coefficient_intervals) {
            const std::size_t bin =
                static_cast<std::size_t>(interval.coefficient);
            if (bin >= seen.size() || seen[bin] ||
                !probability(interval.source_lower) ||
                !probability(interval.source_upper) ||
                !probability(interval.result_lower) ||
                !probability(interval.result_upper) ||
                interval.source_lower > interval.source_upper ||
                interval.result_lower > interval.result_upper) {
              return invalid(
                  "c25.invalid_envelope_cross_product_interval",
                  "a response-product transfer requires one ordered source "
                  "and result interval for each distinct response bin");
            }
            seen[bin] = true;
          }
        } else if constexpr (
            std::is_same_v<T, DecisionSensitivityEvidenceV1>) {
          if (!std::isfinite(value.eta) || value.eta <= 0.0L) {
            return invalid("c25.invalid_decision_sensitivity_eta",
                           "decision sensitivity requires finite eta > 0");
          }
          for (const auto term :
               {value.near_boundary_probability,
                value.reconstruction_probability,
                value.eligibility_probability, value.tie_probability}) {
            if (term.has_value() && !probability(*term)) {
              return invalid(
                  "c25.invalid_decision_sensitivity_probability",
                  "every supplied decision-sensitivity probability must lie "
                  "in [0,1]");
            }
          }
        } else if constexpr (std::is_same_v<T,
                                            PoissonDefectEvidenceV1>) {
          if (!finite_nonnegative(value.delta) ||
              !finite_nonnegative(value.moment_bound)) {
            return invalid("c25.invalid_poisson_defect_constants",
                           "Poisson defect and moment constants must be finite "
                           "and nonnegative");
          }
        } else if constexpr (
            std::is_same_v<T, CertificatePremiseEvidenceV1>) {
          if (!premise_bearing_claim(value.supported_claim)) {
            return invalid(
                "c25.invalid_premise_claim_kind",
                "typed premise evidence may support only a theorem, "
                "fidelity, stability, or diagnostic claim");
          }
          if (!nonzero_digest(value.subject_product_identity) ||
              !nonzero_digest(value.subject_law_identity) ||
              !nonzero_digest(value.premise_identity) ||
              !nonzero_digest(value.provenance_identity.object_digest)) {
            return invalid(
                "c25.invalid_premise_identity",
                "typed premise evidence requires exact nonzero subject, "
                "premise, and provenance identities");
          }
          if (value.coverage == CertificateCoverageV1::not_applicable) {
            return invalid("c25.invalid_premise_coverage",
                           "typed premise evidence requires an explicit "
                           "coverage domain");
          }
        } else if constexpr (
            std::is_same_v<T, ComplexityCostEvidenceV1>) {
          if (!valid_complexity_category(value.category) ||
              !valid_complexity_unit(value.unit)) {
            return invalid("c25.invalid_complexity_cost_type",
                           "complexity category and unit must be recognized "
                           "closed C25 values");
          }
          if (!finite_nonnegative(value.amount)) {
            return invalid("c25.invalid_complexity_cost_amount",
                           "a complexity cost must be finite and "
                           "nonnegative");
          }
          if (value.convention.empty()) {
            return invalid("c25.complexity_cost_convention_missing",
                           "a complexity cost requires an explicit unit "
                           "interpretation and accounting convention");
          }
          if (!nonzero_digest(value.subject_product_identity) ||
              !nonzero_digest(value.subject_law_identity) ||
              !nonzero_digest(value.provenance_identity.object_digest)) {
            return invalid(
                "c25.complexity_cost_identity_missing",
                "a complexity cost must bind an exact product, law, and "
                "provenance identity");
          }
          if (value.coverage == CertificateCoverageV1::not_applicable) {
            return invalid("c25.complexity_cost_coverage_missing",
                           "a complexity cost requires an explicit scope");
          }
          if ((value.category == ComplexityCostCategoryV1::optimizer_calls &&
               value.unit != ComplexityCostUnitV1::calls) ||
              (value.category == ComplexityCostCategoryV1::storage &&
               value.unit != ComplexityCostUnitV1::bytes) ||
              (value.category ==
                   ComplexityCostCategoryV1::trace_warmup_and_dependence &&
               value.unit != ComplexityCostUnitV1::samples)) {
            return invalid(
                "c25.complexity_cost_unit_mismatch",
                "optimizer-call, storage, and trace costs require calls, "
                "bytes, and samples respectively");
          }
        } else if constexpr (
            std::is_same_v<T, ScopedCertificateRecordEvidenceV1>) {
          if (value.kind != CertificateClaimKindV1::numerics &&
              value.kind != CertificateClaimKindV1::validation &&
              value.kind != CertificateClaimKindV1::provenance) {
            return invalid("c25.invalid_scoped_record_kind",
                           "a scoped record may carry only numerics, "
                           "validation, or provenance; complexity requires "
                           "a quantitative typed cost record");
          }
        }
        return Result<void>::success();
      },
      node);
}

[[nodiscard]] Result<void> validate_graph(
    std::span<const CertificateEvidenceNodeV1> nodes,
    const AuditedFrameworkBindingsV1& bindings) {
  for (std::size_t left = 0; left < nodes.size(); ++left) {
    for (std::size_t right = left + 1U; right < nodes.size(); ++right) {
      if (evidence_id(nodes[left]) == evidence_id(nodes[right])) {
        return invalid("c25.duplicate_evidence_identity",
                       "certificate evidence identities must be unique");
      }
    }
    auto shaped = validate_node_shape(nodes[left], bindings);
    if (!shaped) return shaped;
    for (const CertificateEvidenceIdV1& dependency :
         dependencies(nodes[left])) {
      if (!find_node(nodes, dependency).has_value()) {
        return invalid("c25.dangling_evidence_dependency",
                       "a certificate evidence dependency is absent from the "
                       "bound graph");
      }
    }
    if (const auto* contraction =
            std::get_if<ContractionEvidenceV1>(&nodes[left]);
        contraction != nullptr) {
      const auto row_index = find_node(nodes, contraction->row_error_id);
      if (!row_index.has_value() ||
          !std::holds_alternative<RowErrorEvidenceV1>(nodes[*row_index]) ||
          std::find(contraction->dependencies.begin(),
                    contraction->dependencies.end(),
                    contraction->row_error_id) ==
              contraction->dependencies.end()) {
        return invalid("c25.contraction_row_dependency_mismatch",
                       "a contraction witness must depend on its exact typed "
                       "row-error evidence node");
      }
    }
    if (const auto* resolvent =
            std::get_if<ResolventEvidenceV1>(&nodes[left]);
        resolvent != nullptr) {
      const auto pair_index = find_node(nodes, resolvent->killed_pair_id);
      if (!pair_index.has_value() ||
          !std::holds_alternative<KilledKernelPairEvidenceV1>(
              nodes[*pair_index]) ||
          std::find(resolvent->dependencies.begin(),
                    resolvent->dependencies.end(),
                    resolvent->killed_pair_id) ==
              resolvent->dependencies.end()) {
        return invalid("c25.resolvent_kernel_dependency_mismatch",
                       "a resolvent witness must depend on its exact typed "
                       "killed-kernel pair evidence node");
      }
    }
    if (const auto* transfer =
            std::get_if<EnvelopeResponseProductTransferEvidenceV1>(
                &nodes[left]);
        transfer != nullptr) {
      const auto source_index = find_node(nodes, transfer->source_evidence);
      bool exact_source_binding = false;
      if (source_index.has_value()) {
        exact_source_binding = std::visit(
            [&](const auto& source) {
              if constexpr (requires {
                              source.subject_product_identity;
                              source.subject_law_identity;
                            }) {
                return source.subject_product_identity ==
                           transfer->source_product_identity &&
                       source.subject_law_identity ==
                           transfer->source_law_identity;
              }
              return false;
            },
            nodes[*source_index]);
      }
      if (!source_index.has_value() || !exact_source_binding) {
        return invalid(
            "c25.envelope_transfer_source_evidence_mismatch",
            "an envelope bridge source dependency must evidence the exact "
            "source product and law identities named by the transfer");
      }
      const bool has_transfer_premise = std::ranges::any_of(
          transfer->dependencies,
          [&](const CertificateEvidenceIdV1& dependency) {
            const auto index = find_node(nodes, dependency);
            if (!index.has_value()) return false;
            const auto* premise = std::get_if<CertificatePremiseEvidenceV1>(
                &nodes[*index]);
            return premise != nullptr &&
                   premise->supported_claim ==
                       CertificateClaimKindV1::response_product_transfer &&
                   premise->subject_product_identity ==
                       transfer->destination_product_identity &&
                   premise->subject_law_identity ==
                       transfer->destination_law_identity &&
                   premise->coverage ==
                       CertificateCoverageV1::global_declared_domain &&
                   premise->origin != CertificateEvidenceOriginV1::
                                          stationary_oracle_benchmark;
          });
      if (!has_transfer_premise) {
        return invalid(
            "c25.envelope_transfer_premise_missing",
            "a response-product bridge requires a direct independently "
            "identified typed premise for its exact destination product and "
            "law; a self-asserted validation boolean is insufficient");
      }
    }
    if (const auto* envelope =
            std::get_if<ResponseEnvelopeCertificateEvidenceV1>(&nodes[left]);
        envelope != nullptr) {
      if (envelope->temporal_backend.has_value()) {
        const auto& backend = *envelope->temporal_backend;
        const auto backend_index =
            find_node(nodes, backend.evidence_dependency);
        const auto* premise =
            backend_index.has_value()
                ? std::get_if<CertificatePremiseEvidenceV1>(
                      &nodes[*backend_index])
                : nullptr;
        if (premise == nullptr ||
            premise->supported_claim !=
                CertificateClaimKindV1::response_envelope ||
            premise->subject_product_identity !=
                envelope->subject_product_identity ||
            premise->subject_law_identity != envelope->subject_law_identity ||
            premise->coverage !=
                CertificateCoverageV1::global_declared_domain ||
            premise->origin ==
                CertificateEvidenceOriginV1::stationary_oracle_benchmark) {
          return invalid(
              "c25.temporal_envelope_backend_dependency_mismatch",
              "the temporal backend requires a direct typed response-envelope "
              "premise with the exact subject product, law, and coverage");
        }
      }
      const auto validate_transfer = [&](const auto& binding,
                                         const auto& coefficients)
          -> Result<void> {
        if (!binding.transfer_evidence.has_value()) {
          return Result<void>::success();
        }
        const auto transfer_index =
            find_node(nodes, *binding.transfer_evidence);
        if (!transfer_index.has_value() ||
            !std::holds_alternative<
                EnvelopeResponseProductTransferEvidenceV1>(
                nodes[*transfer_index]) ||
            std::find(envelope->dependencies.begin(),
                      envelope->dependencies.end(),
                      *binding.transfer_evidence) ==
                envelope->dependencies.end()) {
          return invalid(
              "c25.envelope_transfer_dependency_mismatch",
              "an envelope cross-product bridge must be a typed dependency "
              "of the exact envelope node");
        }
        const auto& transfer =
            std::get<EnvelopeResponseProductTransferEvidenceV1>(
                nodes[*transfer_index]);
        if (transfer.destination_product_identity != binding.identity ||
            transfer.destination_stage != binding.stage ||
            transfer.destination_value_status != binding.raw_value_status ||
            transfer.destination_law_identity != binding.law_identity ||
            !transfer.direction_and_assumptions_validated ||
            !transfer.destination_is_designated_deployed_point) {
          return invalid(
              "c25.envelope_transfer_product_mismatch",
              "an envelope bridge must name the exact evaluated product as "
              "its validated designated deployed destination");
        }
        for (const auto& interval : transfer.coefficient_intervals) {
          const long double deployed =
              response_coefficient(coefficients, interval.coefficient);
          if (!std::isfinite(deployed) || deployed < interval.result_lower ||
              deployed > interval.result_upper) {
            return invalid(
                "c25.envelope_transfer_result_excludes_destination",
                "the exact deployed response coefficient lies outside the "
                "bridge's certified result interval");
          }
        }
        return Result<void>::success();
      };
      auto subject_transfer = validate_transfer(envelope->subject_product,
                                                envelope->mu_point);
      if (!subject_transfer) return subject_transfer;
      auto slow_transfer = validate_transfer(envelope->slow_product,
                                             envelope->mu_minus);
      if (!slow_transfer) return slow_transfer;
      auto fast_transfer = validate_transfer(envelope->fast_product,
                                             envelope->mu_plus);
      if (!fast_transfer) return fast_transfer;
    }
  }

  std::vector<std::uint8_t> state(nodes.size(), 0U);
  const auto visit = [&](const auto& self,
                         const std::size_t index) -> Result<void> {
    if (state[index] == 1U) {
      return invalid("c25.circular_evidence_dependency",
                     "certificate evidence dependencies must form an acyclic "
                     "graph");
    }
    if (state[index] == 2U) return Result<void>::success();
    state[index] = 1U;
    for (const CertificateEvidenceIdV1& dependency : dependencies(nodes[index])) {
      const std::optional<std::size_t> child = find_node(nodes, dependency);
      if (!child.has_value()) {
        return invalid("c25.dangling_evidence_dependency",
                       "a certificate evidence dependency is absent from the "
                       "bound graph");
      }
      auto nested = self(self, *child);
      if (!nested) return nested;
    }
    state[index] = 2U;
    return Result<void>::success();
  };
  for (std::size_t index = 0; index < nodes.size(); ++index) {
    auto acyclic = visit(visit, index);
    if (!acyclic) return acyclic;
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_bound_arrival_semantics(
    std::span<const CertificateEvidenceNodeV1> nodes,
    const surrogate::detail::SealedFrameworkCore& core) {
  const BuilderArrivalView arrival =
      builder_arrival_view(core.inputs().configured_arrival);
  const bool exact_iid =
      arrival.capabilities().exact_iid_joint_vector.has_value() &&
      arrival.capabilities().exact_iid_joint_vector->finite_support &&
      arrival.iid_joint_table().has_value() &&
      !arrival.iid_joint_table()->empty();

  for (const CertificateEvidenceNodeV1& node : nodes) {
    if (std::holds_alternative<DriftWitnessEvidenceV1>(node) && !exact_iid) {
      return invalid(
          "c25.drift_configured_arrival_not_exact_iid",
          "the IID drift theorem requires the sealed configured arrival to "
          "supply an exact finite joint-vector law, not only an authored IID "
          "assertion or matching marginal");
    }
    const auto* envelope =
        std::get_if<ResponseEnvelopeCertificateEvidenceV1>(&node);
    if (envelope == nullptr) continue;
    if (envelope->arrival_semantics ==
        EnvelopeArrivalSemanticsV1::temporal_augmented) {
      if (!envelope->iid_target_marginal.empty()) {
        return invalid(
            "c25.temporal_envelope_contains_iid_replay",
            "a temporal envelope cannot carry an IID replay table for the "
            "configured arrival process");
      }
      continue;
    }
    if (!exact_iid) {
      return invalid(
          "c25.envelope_configured_arrival_not_exact_iid",
          "an IID envelope route requires the sealed configured arrival to "
          "supply its exact finite joint-vector law");
    }

    std::optional<std::size_t> target_ordinal;
    const QueueCatalog& queues = core.inputs().instance.queues();
    for (std::size_t ordinal = 0U; ordinal < queues.size(); ++ordinal) {
      auto dense = queues.index_at(ordinal);
      if (!dense) return Result<void>::failure(dense.error());
      if (queues.queue_id(dense.value()) == envelope->target) {
        target_ordinal = ordinal;
        break;
      }
    }
    if (!target_ordinal.has_value()) {
      return invalid("c25.envelope_target_not_in_configured_arrival",
                     "the envelope target is absent from the sealed queue "
                     "catalog");
    }

    std::vector<std::pair<std::uint64_t, ExactRational>> marginal;
    for (const ExactJointBatchMass& atom : *arrival.iid_joint_table()) {
      if (*target_ordinal >= atom.dense_counts.size() ||
          atom.dense_counts[*target_ordinal].bit_length() > 64U) {
        return invalid(
            "c25.envelope_iid_batch_not_representable",
            "the exact target batch cannot be represented by the C25 scalar "
            "envelope wire type");
      }
      const std::uint64_t batch =
          atom.dense_counts[*target_ordinal].value().convert_to<std::uint64_t>();
      const auto found = std::find_if(
          marginal.begin(), marginal.end(),
          [batch](const auto& entry) { return entry.first == batch; });
      if (found == marginal.end()) {
        marginal.emplace_back(batch, atom.probability);
      } else {
        found->second = found->second + atom.probability;
      }
    }
    std::sort(marginal.begin(), marginal.end(),
              [](const auto& left, const auto& right) {
                return left.first < right.first;
              });
    std::vector<ScalarBatchMassV1> declared = envelope->iid_target_marginal;
    std::sort(declared.begin(), declared.end(),
              [](const auto& left, const auto& right) {
                return left.batch < right.batch;
              });
    if (declared.size() != marginal.size()) {
      return invalid("c25.envelope_iid_target_marginal_mismatch",
                     "the declared target marginal does not have the exact "
                     "support of the sealed joint arrival law");
    }
    long double exact_mean = 0.0L;
    long double exact_second_moment = 0.0L;
    for (std::size_t index = 0U; index < marginal.size(); ++index) {
      const long double mass = marginal[index].second.to_long_double();
      if (declared[index].batch != marginal[index].first ||
          declared[index].probability != mass) {
        return invalid("c25.envelope_iid_target_marginal_mismatch",
                       "the declared target marginal differs from the exact "
                       "marginal of the sealed joint arrival law");
      }
      const long double batch =
          static_cast<long double>(marginal[index].first);
      exact_mean += batch * mass;
      exact_second_moment += batch * batch * mass;
    }
    if (!std::isfinite(exact_mean) || !std::isfinite(exact_second_moment) ||
        envelope->lambda != exact_mean ||
        (envelope->arrival_second_moment_finite &&
         envelope->arrival_second_moment != exact_second_moment)) {
      return invalid(
          "c25.envelope_iid_arrival_moment_mismatch",
          "arrival intensity and any claimed finite second moment must equal "
          "the exact target marginal derived from the sealed joint law");
    }
  }
  return Result<void>::success();
}

[[nodiscard]] bool same_v0_report(const V0WitnessReport& left,
                                  const V0WitnessReport& right) {
  return left.passed() == right.passed() &&
         left.bindings() == right.bindings() &&
         std::equal(left.entries().begin(), left.entries().end(),
                    right.entries().begin(), right.entries().end());
}

[[nodiscard]] Result<void> validate_v0_report(
    const V0WitnessReport& report,
    const AuditedFrameworkBindingsV1& bindings,
    const surrogate::detail::SealedFrameworkCore& core) {
  if (!report.passed()) {
    return invalid("c25.v0_required",
                   "certificate validation requires a successful bound C17 "
                   "V0 report");
  }
  constexpr std::size_t count =
      static_cast<std::size_t>(V0ObligationV1::framework_unit_residence) + 1U;
  std::array<bool, count> seen{};
  if (report.entries().size() != count) {
    return invalid("c25.incomplete_v0_report",
                   "the bound V0 report must contain every obligation exactly "
                   "once");
  }
  for (const V0WitnessEntryV1& entry : report.entries()) {
    const std::size_t index = static_cast<std::size_t>(entry.obligation);
    if (index >= count || seen[index] || !entry.passed) {
      return invalid("c25.invalid_v0_report",
                     "the bound V0 report contains a duplicate, invalid, or "
                     "failed obligation");
    }
    seen[index] = true;
  }
  if (report.bindings().resolved_instance !=
          bindings.problem_fingerprints.resolved_instance ||
      report.bindings().descriptor != bindings.descriptor_digest ||
      report.bindings().access != bindings.access_digest ||
      report.bindings().descriptor != core.descriptor().descriptor_digest ||
      report.bindings().ownership_schema !=
          core.inputs().exact_state_schema.ownership_schema_digest ||
      report.bindings().exact_update_schema !=
          core.inputs().exact_state_schema.exact_update_schema_digest) {
    return invalid("c25.v0_carrier_binding_mismatch",
                   "the V0 report and sealed framework do not retain the same "
                   "instance, descriptor, access, ownership, and exact-update "
                   "identities");
  }
  return Result<void>::success();
}

enum class DescriptorClaimMatchV1 : std::uint8_t {
  absent,
  exact,
  mismatch,
};

[[nodiscard]] DescriptorClaimMatchV1 descriptor_claim_match(
    const PlugDescriptor& descriptor, const CertificateCategoryV1 category,
    const CertificateLevelV1 level, const CodecIdentityV1& schema) {
  const auto claim = std::find_if(
      descriptor.certificates.begin(), descriptor.certificates.end(),
      [category](const RuntimeCertificateClaimV1& value) {
        return value.category == category;
      });
  if (claim == descriptor.certificates.end()) {
    return DescriptorClaimMatchV1::absent;
  }
  return claim->level == level &&
                 claim->witness_schema ==
                     std::optional<CodecIdentityV1>{schema}
             ? DescriptorClaimMatchV1::exact
             : DescriptorClaimMatchV1::mismatch;
}

[[nodiscard]] std::vector<CertificateEvidenceIdV1> dependency_closure(
    std::span<const CertificateEvidenceNodeV1> nodes,
    const std::size_t root) {
  std::vector<CertificateEvidenceIdV1> result;
  std::vector<std::size_t> stack{root};
  std::vector<bool> seen(nodes.size(), false);
  while (!stack.empty()) {
    const std::size_t index = stack.back();
    stack.pop_back();
    if (seen[index]) continue;
    seen[index] = true;
    if (index != root) result.push_back(evidence_id(nodes[index]));
    for (const CertificateEvidenceIdV1& dependency : dependencies(nodes[index])) {
      if (const auto found = find_node(nodes, dependency); found.has_value()) {
        stack.push_back(*found);
      }
    }
  }
  std::sort(result.begin(), result.end());
  return result;
}

[[nodiscard]] bool premise_coverage_supports(
    const CertificateCoverageV1 premise,
    const CertificateCoverageV1 claim) noexcept {
  if (premise == CertificateCoverageV1::sampled_only ||
      premise == CertificateCoverageV1::not_applicable) {
    return false;
  }
  return premise == CertificateCoverageV1::global_declared_domain ||
         premise == claim;
}

[[nodiscard]] bool has_matching_typed_premise(
    std::span<const CertificateEvidenceNodeV1> nodes,
    const std::size_t root, const CertificateClaimKindV1 claim_kind,
    const CertificateCoverageV1 claim_coverage) {
  return std::visit(
      [&](const auto& claim) {
        return std::ranges::any_of(
            claim.dependencies,
            [&](const CertificateEvidenceIdV1& dependency) {
              const auto index = find_node(nodes, dependency);
              if (!index.has_value()) return false;
              const auto* premise = std::get_if<CertificatePremiseEvidenceV1>(
                  &nodes[*index]);
              if (premise == nullptr ||
                  premise->supported_claim != claim_kind ||
                  premise->origin == CertificateEvidenceOriginV1::
                                         stationary_oracle_benchmark ||
                  !premise_coverage_supports(premise->coverage,
                                             claim_coverage)) {
                return false;
              }
              if constexpr (requires {
                              claim.subject_product_identity;
                              claim.subject_law_identity;
                            }) {
                return premise->subject_product_identity ==
                           claim.subject_product_identity &&
                       premise->subject_law_identity ==
                           claim.subject_law_identity;
              }
              return true;
            });
      },
      nodes[root]);
}

[[nodiscard]] ValidatedClaimV1 absent_claim(
    const CertificateClaimKindV1 kind) {
  return ValidatedClaimV1{
      .state = CertificateClaimStateV1::not_established,
      .kind = kind,
      .evidence = std::nullopt,
      .coverage = CertificateCoverageV1::not_applicable,
      .dependency_closure = {},
      .diagnostics = {
          "no evidence was supplied for this optional claim"},
      .result_value_status = BoundValueStatusV1::unresolved,
      .raw_result_value = std::nullopt,
      .presented_result_value = std::nullopt,
  };
}

[[nodiscard]] Result<ValidatedClaimV1> validate_claim_reference(
    const CertificateEvidenceIdV1& reference,
    const CertificateClaimKindV1 expected,
    std::span<const CertificateEvidenceNodeV1> nodes) {
  const std::optional<std::size_t> index = find_node(nodes, reference);
  if (!index.has_value()) {
    return failure<ValidatedClaimV1>(
        "c25.claim_evidence_missing",
        "a certificate claim references evidence absent from the graph");
  }
  const CertificateClaimKindV1 actual = node_kind(nodes[*index]);
  if (actual != expected &&
      !(expected == CertificateClaimKindV1::stopped_resolvent_transfer &&
        actual == CertificateClaimKindV1::stopped_resolvent_transfer)) {
    return failure<ValidatedClaimV1>(
        "c25.claim_evidence_kind_mismatch",
        "a certificate claim references the wrong typed evidence kind");
  }
  CertificateClaimStateV1 state = CertificateClaimStateV1::established;
  BoundValueStatusV1 result_status = BoundValueStatusV1::unresolved;
  std::optional<long double> raw_result;
  std::optional<long double> presented_result;
  std::vector<std::string> diagnostics;
  const CertificateCoverageV1 coverage = node_coverage(nodes[*index]);
  if (coverage == CertificateCoverageV1::sampled_only) {
    state = CertificateClaimStateV1::not_established;
    diagnostics.push_back(
        "sampled-only evidence is validation evidence, not a global "
        "certificate");
  }
  std::visit(
      [&](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, V1GeometryEvidenceV1>) {
          if (!value.compatible_support_established ||
              !value.current_decision_mixture_identity_established ||
              !value.common_feasible_schedule_established ||
              !value.exact_tie_and_lattice_semantics_established) {
            state = CertificateClaimStateV1::refuted;
          }
        } else if constexpr (std::is_same_v<T, V2DynamicLiftEvidenceV1>) {
          if (!value.row_intertwining_established) {
            state = CertificateClaimStateV1::refuted;
          }
        } else if constexpr (
            std::is_same_v<T, StationaryIntegratedFidelityEvidenceV1>) {
          if (value.origin ==
              CertificateEvidenceOriginV1::stationary_oracle_benchmark) {
            state = CertificateClaimStateV1::not_established;
            diagnostics.push_back(
                "stationary-oracle evidence is retained as a benchmark and "
                "does not establish an a-priori transfer");
          } else if (!value.selected_surrogate_invariant_established ||
                     !value.integrated_invariance_established ||
                     !value.physical_selection_and_uniqueness_established) {
            state = CertificateClaimStateV1::refuted;
          }
        } else if constexpr (std::is_same_v<T,
                                            PhysicalFidelityEvidenceV1>) {
          if (value.kind == PhysicalFidelityKindV1::not_established ||
              value.origin ==
                  CertificateEvidenceOriginV1::stationary_oracle_benchmark) {
            state = CertificateClaimStateV1::not_established;
          } else if (value.kind == PhysicalFidelityKindV1::bounded &&
                     !value.finite_bound.has_value()) {
            state = CertificateClaimStateV1::refuted;
          } else if (value.finite_bound.has_value()) {
            result_status = BoundValueStatusV1::finite;
            raw_result = value.finite_bound;
            presented_result = value.finite_bound;
          }
        } else if constexpr (std::is_same_v<T, ContractionEvidenceV1>) {
          if (value.coefficient >= 1.0L) {
            state = CertificateClaimStateV1::refuted;
            diagnostics.push_back(
                "a stationary transfer requires a strict contraction c < 1");
          }
        } else if constexpr (std::is_same_v<T, DriftWitnessEvidenceV1>) {
          if (!value.retains_full_physical_backlog ||
              !value.iid_across_slots_exact_joint ||
              !value.capacity_interior_verified ||
              !value.declared_domain_forward_invariant ||
              !value.all_declared_domain_rows_verified ||
              !value.common_joint_schedule_law_established ||
              !value.initial_support_contained ||
              !value.initial_quadratic_backlog_moment_finite) {
            state = CertificateClaimStateV1::refuted;
          }
        } else if constexpr (
            std::is_same_v<T, DecisionSensitivityEvidenceV1>) {
          if (!value.every_term_independently_bounded ||
              !value.near_boundary_probability.has_value() ||
              !value.reconstruction_probability.has_value() ||
              !value.eligibility_probability.has_value() ||
              !value.tie_probability.has_value()) {
            state = CertificateClaimStateV1::not_established;
            diagnostics.push_back(
                "a numeric mismatch bound requires all four independently "
                "bounded probability terms");
          } else {
            const long double total = *value.near_boundary_probability +
                                      *value.reconstruction_probability +
                                      *value.eligibility_probability +
                                      *value.tie_probability;
            result_status = BoundValueStatusV1::finite;
            raw_result = total;
            presented_result = std::min(total, 1.0L);
          }
        } else if constexpr (std::is_same_v<T,
                                            PoissonDefectEvidenceV1>) {
          if (!value.invariant_law_established ||
              !value.invariant_coboundary_identity_justified ||
              !value.domain_and_integrability_established ||
              !value.global_residual_established) {
            state = CertificateClaimStateV1::not_established;
          } else if (value.delta == 0.0L || value.moment_bound == 0.0L) {
            result_status = BoundValueStatusV1::finite;
            raw_result = 0.0L;
            presented_result = 0.0L;
          } else if (value.delta >
                     std::numeric_limits<long double>::max() /
                         value.moment_bound) {
            result_status = BoundValueStatusV1::infinite;
            diagnostics.push_back(
                "delta times the certified moment bound exceeds finite "
                "long-double range");
          } else {
            result_status = BoundValueStatusV1::finite;
            raw_result = value.delta * value.moment_bound;
            presented_result = raw_result;
          }
        }
      },
      nodes[*index]);
  if (state == CertificateClaimStateV1::established &&
      premise_bearing_claim(expected) &&
      !has_matching_typed_premise(nodes, *index, expected, coverage)) {
    state = CertificateClaimStateV1::not_established;
    result_status = BoundValueStatusV1::unresolved;
    raw_result.reset();
    presented_result.reset();
    diagnostics.push_back(
        "the selected evidence lacks a direct typed, product/law-matched "
        "premise dependency for this claim");
  }
  return Result<ValidatedClaimV1>::success(ValidatedClaimV1{
      .state = state,
      .kind = expected,
      .evidence = reference,
      .coverage = coverage,
      .dependency_closure = dependency_closure(nodes, *index),
      .diagnostics = std::move(diagnostics),
      .result_value_status = result_status,
      .raw_result_value = raw_result,
      .presented_result_value = presented_result,
  });
}

[[nodiscard]] Result<void> validate_unique_claim_list(
    std::span<const CertificateEvidenceIdV1> claims) {
  for (std::size_t left = 0; left < claims.size(); ++left) {
    for (std::size_t right = left + 1U; right < claims.size(); ++right) {
      if (claims[left] == claims[right]) {
        return invalid("c25.duplicate_claim_reference",
                       "a certificate bundle cannot repeat one evidence "
                       "identity in the same claim field");
      }
    }
  }
  return Result<void>::success();
}

template <typename View, typename Alternative, typename Mint>
[[nodiscard]] Result<View> bind_view(
    const std::shared_ptr<const ValidatedCertificateCore>& core,
    const CertificateEvidenceIdV1& evidence, Mint&& mint) {
  if (!core) {
    return failure<View>("c25.empty_validated_certificate_core",
                         "the validated certificate carrier has no core");
  }
  const auto index = find_node(core->nodes, evidence);
  if (!index.has_value() ||
      !std::holds_alternative<Alternative>(core->nodes[*index])) {
    return failure<View>("c25.validated_view_kind_mismatch",
                         "the requested evidence does not have the required "
                         "validated theorem type");
  }
  const auto claim = std::find_if(
      core->claims.begin(), core->claims.end(),
      [&](const ValidatedClaimV1& candidate) {
        return candidate.evidence.has_value() &&
               *candidate.evidence == evidence;
      });
  if (claim == core->claims.end()) {
    return failure<View>(
        "c25.validated_view_not_selected",
        "the requested theorem evidence was not selected by the validated "
        "certificate bundle");
  }
  if (claim->state == CertificateClaimStateV1::not_established) {
    return failure<View>(
        "c25.validated_view_premise_not_established",
        "an opaque theorem view cannot be issued until its selected evidence "
        "has a direct typed premise dependency for the exact claim and "
        "product/law scope");
  }
  // The opaque handle attests that the raw theorem evidence was selected,
  // graph-validated, premise-backed, and bound to this exact audited carrier.
  // It does not pre-judge refuted theorem-specific hypotheses: F-C25-02
  // through F-C25-06 must still reject a non-strict contraction, missing
  // drift slack, an unavailable envelope side, and analogous failures.
  // Independent
  // result capabilities such as PhysicalFidelityAnchor retain their explicit
  // established-claim gate at the public minting method.
  return Result<View>::success(mint(core, *index));
}

}  // namespace

const ExactRational& ExactDenseMatrixV1::at(const std::size_t row,
                                            const std::size_t column) const {
  return entries.at(row * columns + column);
}

Result<Digest256> Evidence::canonical_graph_digest(
    const std::span<const CertificateEvidenceNodeV1> nodes) {
  try {
    std::vector<const CertificateEvidenceNodeV1*> ordered;
    ordered.reserve(nodes.size());
    for (const CertificateEvidenceNodeV1& node : nodes) {
      ordered.push_back(&node);
    }
    std::sort(ordered.begin(), ordered.end(), [](const auto* left,
                                                  const auto* right) {
      return evidence_id(*left) < evidence_id(*right);
    });
    GraphEncoder encoder;
    constexpr std::string_view domain{"mwperf.c25.evidence_graph.v1"};
    encoder.u64(static_cast<std::uint64_t>(domain.size()));
    encoder.raw(std::as_bytes(std::span(domain)));
    encoder.u64(static_cast<std::uint64_t>(ordered.size()));
    for (const CertificateEvidenceNodeV1* node : ordered) {
      encoder.identity(evidence_id(*node));
      encoder.u8(static_cast<std::uint8_t>(node_kind(*node)));
      std::vector<CertificateEvidenceIdV1> parents(dependencies(*node).begin(),
                                                   dependencies(*node).end());
      std::sort(parents.begin(), parents.end());
      encoder.u64(static_cast<std::uint64_t>(parents.size()));
      for (const CertificateEvidenceIdV1& parent : parents) {
        encoder.identity(parent);
      }
    }
    return sha256_domain_separated("mwperf.c25.evidence_graph.v1",
                                   encoder.bytes());
  } catch (const std::bad_alloc&) {
    return failure<Digest256>("c25.graph_digest_allocation_failure",
                              "computing the evidence graph digest exhausted "
                              "memory");
  } catch (const std::exception&) {
    return failure<Digest256>("c25.graph_digest_failure",
                              "computing the evidence graph digest raised an "
                              "implementation exception");
  } catch (...) {
    return failure<Digest256>("c25.graph_digest_unknown_failure",
                              "computing the evidence graph digest raised an "
                              "unknown exception");
  }
}

Result<Evidence> Evidence::bind(
    const AuditedCompiledFramework& framework,
    std::vector<CertificateEvidenceNodeV1> nodes) {
  const auto& core = C25CoreAccess::framework_core(framework);
  if (!core || !C25CoreAccess::framework_seal(framework)) {
    return failure<Evidence>("c25.unsealed_framework",
                             "certificate evidence can bind only to a live "
                             "V0-sealed framework");
  }
  const V0WitnessReport& report = v0_witness_report(framework);
  if (!report.passed()) {
    return failure<Evidence>("c25.v0_required",
                             "certificate evidence requires a successful V0 "
                             "report");
  }
  auto digest = canonical_graph_digest(nodes);
  if (!digest) return Result<Evidence>::failure(digest.error());
  return Result<Evidence>::success(Evidence(
      1U, report.bindings(), C25CoreAccess::framework_bindings(framework),
      std::move(digest).value(), std::move(nodes),
      C25CoreAccess::framework_seal(framework),
      C25CoreAccess::framework_core(framework),
      std::make_shared<
          const certificates::detail::EvidenceGraphSealIdentity>()));
}

CertificateBundle CertificateBundle::v0_only(const Evidence& evidence) {
  return CertificateBundle(1U, evidence.v0_bindings_,
                           evidence.framework_bindings_,
                           evidence.graph_digest_, evidence.graph_seal_);
}

const V0WitnessReport& ValidatedCertificates::v0_report() const noexcept {
  return core_->v0_report;
}

const Digest256& ValidatedCertificates::graph_digest() const noexcept {
  return core_->graph_digest;
}

const ValidatedClaimV1& ValidatedCertificates::v1_geometry() const noexcept {
  return core_->claims[core_->v1_claim_index];
}

const ValidatedClaimV1& ValidatedCertificates::v2_dynamic_lift() const
    noexcept {
  return core_->claims[core_->v2_claim_index];
}

const ValidatedClaimV1&
ValidatedCertificates::stationary_integrated_fidelity() const noexcept {
  return core_->claims[core_->stationary_claim_index];
}

const ValidatedClaimV1& ValidatedCertificates::physical_fidelity() const
    noexcept {
  return core_->claims[core_->physical_claim_index];
}

const ValidatedClaimV1& ValidatedCertificates::stability() const noexcept {
  return core_->claims[core_->stability_claim_index];
}

std::span<const ValidatedClaimV1> ValidatedCertificates::claims() const
    noexcept {
  return core_->claims;
}

std::vector<ComplexityCostEvidenceV1>
ValidatedCertificates::complexity_costs() const {
  std::vector<ComplexityCostEvidenceV1> result;
  for (const ValidatedClaimV1& claim : core_->claims) {
    if (claim.kind != CertificateClaimKindV1::complexity ||
        !claim.evidence.has_value()) {
      continue;
    }
    const auto index = find_node(core_->nodes, *claim.evidence);
    if (index.has_value()) {
      if (const auto* cost =
              std::get_if<ComplexityCostEvidenceV1>(&core_->nodes[*index]);
          cost != nullptr) {
        result.push_back(*cost);
      }
    }
  }
  return result;
}

Result<RowErrorBound> ValidatedCertificates::row_error_bound(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<RowErrorBound, RowErrorEvidenceV1>(
      core_, evidence, C25CoreAccess::row_error_bound);
}

Result<ContractionWitness> ValidatedCertificates::contraction_witness(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<ContractionWitness, ContractionEvidenceV1>(
      core_, evidence, C25CoreAccess::contraction_witness);
}

Result<KilledKernelPair> ValidatedCertificates::killed_kernel_pair(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<KilledKernelPair, KilledKernelPairEvidenceV1>(
      core_, evidence, C25CoreAccess::killed_kernel_pair);
}

Result<ResolventWitness> ValidatedCertificates::resolvent_witness(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<ResolventWitness, ResolventEvidenceV1>(
      core_, evidence, C25CoreAccess::resolvent_witness);
}

Result<DriftWitness> ValidatedCertificates::drift_witness(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<DriftWitness, DriftWitnessEvidenceV1>(
      core_, evidence, C25CoreAccess::drift_witness);
}

Result<ResponseEnvelope> ValidatedCertificates::response_envelope(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<ResponseEnvelope, ResponseEnvelopeCertificateEvidenceV1>(
      core_, evidence, C25CoreAccess::response_envelope);
}

Result<CertificateArrivalLaw> ValidatedCertificates::certificate_arrival_law(
    const CertificateEvidenceIdV1& evidence) const {
  return bind_view<CertificateArrivalLaw,
                   ResponseEnvelopeCertificateEvidenceV1>(
      core_, evidence, C25CoreAccess::certificate_arrival_law);
}

Result<PhysicalFidelityAnchor>
ValidatedCertificates::physical_fidelity_anchor() const {
  if (!core_ || core_->physical_claim_index >= core_->claims.size()) {
    return failure<PhysicalFidelityAnchor>(
        "c25.empty_validated_certificate_core",
        "the validated certificate carrier has no physical claim core");
  }
  const ValidatedClaimV1& claim = core_->claims[core_->physical_claim_index];
  if (claim.state != CertificateClaimStateV1::established ||
      !claim.evidence.has_value()) {
    return failure<PhysicalFidelityAnchor>(
        "c25.physical_fidelity_not_established",
        "a physical-fidelity anchor is available only from independently "
        "established selected physical evidence");
  }
  return bind_view<PhysicalFidelityAnchor, PhysicalFidelityEvidenceV1>(
      core_, *claim.evidence, C25CoreAccess::physical_fidelity_anchor);
}

const Digest256& PhysicalFidelityAnchor::subject_product_identity()
    const noexcept {
  return C25CoreAccess::physical_fidelity(*this).subject_product_identity;
}

const Digest256& PhysicalFidelityAnchor::subject_law_identity() const noexcept {
  return C25CoreAccess::physical_fidelity(*this).subject_law_identity;
}

const Digest256& PhysicalFidelityAnchor::physical_reference_law_identity()
    const noexcept {
  return C25CoreAccess::physical_fidelity(*this).physical_reference_law_identity;
}

const Digest256& PhysicalFidelityAnchor::metric_identity() const noexcept {
  return C25CoreAccess::physical_fidelity(*this).metric_identity;
}

const Digest256& PhysicalFidelityAnchor::regime_identity() const noexcept {
  return C25CoreAccess::physical_fidelity(*this).regime_identity;
}

const Digest256& PhysicalFidelityAnchor::comparison_theorem_identity()
    const noexcept {
  return C25CoreAccess::physical_fidelity(*this).comparison_theorem_identity;
}

PhysicalFidelityKindV1 PhysicalFidelityAnchor::kind() const noexcept {
  return C25CoreAccess::physical_fidelity(*this).kind;
}

CertificateEvidenceOriginV1 PhysicalFidelityAnchor::origin() const noexcept {
  return C25CoreAccess::physical_fidelity(*this).origin;
}

const std::optional<long double>& PhysicalFidelityAnchor::finite_bound()
    const noexcept {
  return C25CoreAccess::physical_fidelity(*this).finite_bound;
}

Result<ValidatedCertificates> validate_certificate_bundle(
    const CertificateBundle& bundle,
    const AuditedCompiledFramework& framework,
    const Evidence& evidence) {
  try {
    if (bundle.schema_version != 1U || evidence.schema_version() != 1U) {
      return failure<ValidatedCertificates>(
          "c25.unsupported_certificate_schema",
          "C25 accepts only certificate bundle and evidence schema version "
          "one");
    }
    const auto& sealed_core = C25CoreAccess::framework_core(framework);
    if (!sealed_core || !C25CoreAccess::framework_seal(framework)) {
      return failure<ValidatedCertificates>(
          "c25.unsealed_framework",
          "certificate validation requires a live V0-sealed framework");
    }
    if (!C25CoreAccess::same_framework(evidence, framework)) {
      return failure<ValidatedCertificates>(
          "c25.evidence_carrier_seal_mismatch",
          "certificate evidence is bound to a different V0-audited carrier, "
          "even if its public fingerprints happen to compare equal");
    }
    if (!C25CoreAccess::same_graph(bundle, evidence)) {
      return failure<ValidatedCertificates>(
          "c25.bundle_evidence_graph_seal_mismatch",
          "a certificate bundle can be validated only with the exact immutable "
          "evidence graph from which it was created");
    }
    const AuditedFrameworkBindingsV1& authoritative_bindings =
        C25CoreAccess::framework_bindings(framework);
    const V0WitnessReport& public_report = v0_witness_report(framework);
    if (!same_v0_report(public_report, sealed_core->report())) {
      return failure<ValidatedCertificates>(
          "c25.v0_report_carrier_mismatch",
          "the public V0 report differs from the report retained by the "
          "sealed framework core");
    }
    auto v0 = validate_v0_report(public_report, authoritative_bindings,
                                 *sealed_core);
    if (!v0) return Result<ValidatedCertificates>::failure(v0.error());
    if (bundle.v0_bindings != public_report.bindings() ||
        evidence.v0_bindings() != public_report.bindings() ||
        bundle.framework_bindings != authoritative_bindings ||
        evidence.framework_bindings() != authoritative_bindings ||
        bundle.evidence_graph_digest != evidence.graph_digest()) {
      return failure<ValidatedCertificates>(
          "c25.certificate_carrier_binding_mismatch",
          "bundle, evidence graph, and audited framework must retain exactly "
          "the same V0 and immutable framework bindings");
    }
    auto digest = Evidence::canonical_graph_digest(evidence.nodes());
    if (!digest) {
      return Result<ValidatedCertificates>::failure(digest.error());
    }
    if (digest.value() != evidence.graph_digest()) {
      return failure<ValidatedCertificates>(
          "c25.evidence_graph_digest_mismatch",
          "the supplied graph digest does not bind the canonical evidence "
          "identities and dependency edges");
    }
    auto graph = validate_graph(evidence.nodes(), authoritative_bindings);
    if (!graph) return Result<ValidatedCertificates>::failure(graph.error());
    auto arrival_semantics =
        validate_bound_arrival_semantics(evidence.nodes(), *sealed_core);
    if (!arrival_semantics) {
      return Result<ValidatedCertificates>::failure(
          arrival_semantics.error());
    }

    for (const auto& list : {std::span(bundle.transfer_claims),
                             std::span(bundle.response_envelopes),
                             std::span(bundle.decision_diagnostics),
                             std::span(bundle.poisson_rewards),
                             std::span(bundle.numerics),
                             std::span(bundle.complexity),
                             std::span(bundle.validation),
                             std::span(bundle.provenance)}) {
      auto unique = validate_unique_claim_list(list);
      if (!unique) {
        return Result<ValidatedCertificates>::failure(unique.error());
      }
    }

    std::vector<ValidatedClaimV1> claims;
    claims.reserve(5U + bundle.transfer_claims.size() +
                   bundle.response_envelopes.size() +
                   bundle.decision_diagnostics.size() +
                   bundle.poisson_rewards.size() + bundle.numerics.size() +
                   bundle.complexity.size() + bundle.validation.size() +
                   bundle.provenance.size());

    const auto append_optional = [&](
                                     const std::optional<CertificateEvidenceIdV1>&
                                         reference,
                                     const CertificateClaimKindV1 kind)
        -> Result<void> {
      if (!reference.has_value()) {
        claims.push_back(absent_claim(kind));
        return Result<void>::success();
      }
      auto claim = validate_claim_reference(*reference, kind, evidence.nodes());
      if (!claim) return Result<void>::failure(claim.error());
      claims.push_back(std::move(claim).value());
      return Result<void>::success();
    };

    const std::size_t v1_index = claims.size();
    auto append = append_optional(bundle.v1_geometry,
                                  CertificateClaimKindV1::v1_fibre_geometry);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    if (bundle.v1_geometry.has_value()) {
      const auto index = find_node(evidence.nodes(), *bundle.v1_geometry);
      const auto& node =
          std::get<V1GeometryEvidenceV1>(evidence.nodes()[*index]);
      if (descriptor_claim_match(sealed_core->descriptor(),
                                 CertificateCategoryV1::geometry,
                                 CertificateLevelV1::v1_witness,
                                 node.witness_schema) ==
          DescriptorClaimMatchV1::mismatch) {
        return failure<ValidatedCertificates>(
            "c25.v1_descriptor_declaration_mismatch",
            "V1 evidence must exactly match the geometry witness schema when "
            "C16 declares that independent category");
      }
    }

    const std::size_t v2_index = claims.size();
    append = append_optional(bundle.v2_dynamic_lift,
                             CertificateClaimKindV1::v2_dynamic_lift);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    if (bundle.v2_dynamic_lift.has_value()) {
      const auto index = find_node(evidence.nodes(), *bundle.v2_dynamic_lift);
      const auto& node =
          std::get<V2DynamicLiftEvidenceV1>(evidence.nodes()[*index]);
      if (descriptor_claim_match(sealed_core->descriptor(),
                                 CertificateCategoryV1::lift,
                                 CertificateLevelV1::v2_witness,
                                 node.witness_schema) ==
          DescriptorClaimMatchV1::mismatch) {
        return failure<ValidatedCertificates>(
            "c25.v2_descriptor_declaration_mismatch",
            "V2 evidence must exactly match the lift witness schema when C16 "
            "declares that independent category");
      }
      if (claims[v1_index].state != CertificateClaimStateV1::established ||
          !bundle.v1_geometry.has_value()) {
        return failure<ValidatedCertificates>(
            "c25.v2_without_validated_v1",
            "V2 requires a separately supplied and established V1 geometry "
            "claim");
      }
      if (node.coverage == CertificateCoverageV1::sampled_only) {
        return failure<ValidatedCertificates>(
            "c25.v2_sampled_rows_overclaim",
            "sampled-row evidence cannot be selected as a V2 dynamic-lift "
            "certificate");
      }
      const auto v1_node_index =
          find_node(evidence.nodes(), *bundle.v1_geometry);
      const auto& v1_node =
          std::get<V1GeometryEvidenceV1>(evidence.nodes()[*v1_node_index]);
      if (node.subject_product_identity != v1_node.subject_product_identity ||
          node.subject_law_identity != v1_node.subject_law_identity ||
          node.compatibility_relation_identity !=
              v1_node.compatibility_relation_identity ||
          node.lifting_kernel_identity != v1_node.lifting_kernel_identity ||
          node.marked_decoder_identity !=
              v1_node.complete_decision_mark_identity) {
        return failure<ValidatedCertificates>(
            "c25.v2_lift_identity_mismatch",
            "V2 must use the exact subject product/law, relation, lifting "
            "kernel, and mark-decoder identities validated for V1");
      }
    }

    const std::size_t stationary_index = claims.size();
    append = append_optional(
        bundle.stationary_integrated_fidelity,
        CertificateClaimKindV1::stationary_integrated_fidelity);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    if (bundle.stationary_integrated_fidelity.has_value()) {
      const auto index = find_node(evidence.nodes(),
                                   *bundle.stationary_integrated_fidelity);
      const auto& node = std::get<StationaryIntegratedFidelityEvidenceV1>(
          evidence.nodes()[*index]);
      if (descriptor_claim_match(sealed_core->descriptor(),
                                 CertificateCategoryV1::fidelity,
                                 CertificateLevelV1::declaration,
                                 node.witness_schema) ==
          DescriptorClaimMatchV1::mismatch) {
        return failure<ValidatedCertificates>(
            "c25.stationary_fidelity_descriptor_mismatch",
            "independent stationary-fidelity evidence must exactly match a "
            "C16 fidelity declaration when that category is present");
      }
    }

    const std::size_t physical_index = claims.size();
    append = append_optional(bundle.physical_fidelity,
                             CertificateClaimKindV1::physical_fidelity);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    if (bundle.physical_fidelity.has_value()) {
      const auto index =
          find_node(evidence.nodes(), *bundle.physical_fidelity);
      const auto& node =
          std::get<PhysicalFidelityEvidenceV1>(evidence.nodes()[*index]);
      if (descriptor_claim_match(sealed_core->descriptor(),
                                 CertificateCategoryV1::fidelity,
                                 CertificateLevelV1::declaration,
                                 node.witness_schema) ==
          DescriptorClaimMatchV1::mismatch) {
        return failure<ValidatedCertificates>(
            "c25.physical_fidelity_descriptor_mismatch",
            "physical-fidelity evidence must exactly match the witness schema "
            "when C16 declares that independent category");
      }
    }

    const std::size_t stability_index = claims.size();
    append = append_optional(bundle.stability,
                             CertificateClaimKindV1::stability);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());

    const auto append_list = [&](std::span<const CertificateEvidenceIdV1> refs,
                                 const CertificateClaimKindV1 kind)
        -> Result<void> {
      for (const CertificateEvidenceIdV1& reference : refs) {
        auto claim =
            validate_claim_reference(reference, kind, evidence.nodes());
        if (!claim) return Result<void>::failure(claim.error());
        claims.push_back(std::move(claim).value());
      }
      return Result<void>::success();
    };
    // Transfer nodes are heterogeneous; preserve their exact own kind.
    for (const CertificateEvidenceIdV1& reference : bundle.transfer_claims) {
      const auto index = find_node(evidence.nodes(), reference);
      if (!index.has_value()) {
        return failure<ValidatedCertificates>(
            "c25.claim_evidence_missing",
            "a transfer claim references evidence absent from the graph");
      }
      const CertificateClaimKindV1 kind =
          node_kind(evidence.nodes()[*index]);
      if (kind != CertificateClaimKindV1::finite_horizon_transfer &&
          kind != CertificateClaimKindV1::contraction_transfer &&
          kind != CertificateClaimKindV1::stopped_resolvent_transfer) {
        return failure<ValidatedCertificates>(
            "c25.claim_evidence_kind_mismatch",
            "the transfer list may contain only row, contraction, killed, or "
            "resolvent evidence");
      }
      auto claim =
          validate_claim_reference(reference, kind, evidence.nodes());
      if (!claim) return Result<ValidatedCertificates>::failure(claim.error());
      claims.push_back(std::move(claim).value());
    }
    append = append_list(bundle.response_envelopes,
                         CertificateClaimKindV1::response_envelope);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    append = append_list(bundle.decision_diagnostics,
                         CertificateClaimKindV1::decision_sensitivity);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    append = append_list(bundle.poisson_rewards,
                         CertificateClaimKindV1::poisson_reward);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    append = append_list(bundle.numerics,
                         CertificateClaimKindV1::numerics);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    append = append_list(bundle.complexity,
                         CertificateClaimKindV1::complexity);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    append = append_list(bundle.validation,
                         CertificateClaimKindV1::validation);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());
    append = append_list(bundle.provenance,
                         CertificateClaimKindV1::provenance);
    if (!append) return Result<ValidatedCertificates>::failure(append.error());

    auto validated_core = std::make_shared<ValidatedCertificateCore>(
        public_report, public_report.bindings(), authoritative_bindings,
        evidence.graph_digest(),
        std::vector<CertificateEvidenceNodeV1>(evidence.nodes().begin(),
                                               evidence.nodes().end()),
        std::move(claims), v1_index,
        v2_index, stationary_index, physical_index, stability_index,
        C25CoreAccess::framework_seal(framework), sealed_core);
    return Result<ValidatedCertificates>::success(
        C25CoreAccess::validated_certificates(std::move(validated_core)));
  } catch (const std::bad_alloc&) {
    return failure<ValidatedCertificates>(
        "c25.validation_allocation_failure",
        "validating the certificate bundle exhausted memory");
  } catch (const std::exception&) {
    return failure<ValidatedCertificates>(
        "c25.validation_exception",
        "validating the certificate bundle raised an implementation "
        "exception");
  } catch (...) {
    return failure<ValidatedCertificates>(
        "c25.validation_unknown_exception",
        "validating the certificate bundle raised an unknown exception");
  }
}

}  // namespace mwperf
