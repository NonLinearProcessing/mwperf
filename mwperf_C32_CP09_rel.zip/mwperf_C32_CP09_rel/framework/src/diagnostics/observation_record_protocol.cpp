#include "mwperf/diagnostics/observation_record.hpp"

#include <algorithm>
#include <array>
#include <charconv>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <initializer_list>
#include <limits>
#include <new>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <type_traits>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>

#include <nlohmann/json.hpp>

#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

using Json = nlohmann::ordered_json;

constexpr std::string_view kObservationDigestDomain =
    "mwperf.construction_observation_bundle.v1";

[[nodiscard]] Diagnostic wire_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::optional<std::string> pointer = std::nullopt) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::move(pointer), {}};
}

template <typename T>
[[nodiscard]] Result<T> wire_failure(
    const DiagnosticCategory category, std::string code, std::string message,
    std::optional<std::string> pointer = std::nullopt) {
  return Result<T>::failure(wire_diagnostic(
      category, std::move(code), std::move(message), std::move(pointer)));
}

class DecodeError final : public std::exception {
 public:
  explicit DecodeError(Diagnostic diagnostic)
      : diagnostic_(std::move(diagnostic)) {}

  [[nodiscard]] const char* what() const noexcept override {
    return "construction observation wire decode failed";
  }

  [[nodiscard]] const Diagnostic& diagnostic() const noexcept {
    return diagnostic_;
  }

 private:
  Diagnostic diagnostic_;
};

[[noreturn]] void decode_fail(
    std::string code, std::string message, std::string path,
    const DiagnosticCategory category = DiagnosticCategory::input_validation) {
  throw DecodeError(wire_diagnostic(category, std::move(code),
                                    std::move(message), std::move(path)));
}

template <typename T>
[[nodiscard]] T take_or_decode_fail(Result<T> result, std::string path,
                                    std::string_view fallback_code) {
  if (!result) {
    Diagnostic diagnostic = std::move(result).error();
    if (diagnostic.code.empty()) {
      diagnostic.code = std::string(fallback_code);
    }
    diagnostic.json_pointer = std::move(path);
    throw DecodeError(std::move(diagnostic));
  }
  return std::move(result).value();
}

[[nodiscard]] std::string child_pointer(const std::string_view base,
                                        const std::string_view child) {
  std::string result(base);
  result.push_back('/');
  for (const char character : child) {
    if (character == '~') {
      result += "~0";
    } else if (character == '/') {
      result += "~1";
    } else {
      result.push_back(character);
    }
  }
  return result;
}

[[nodiscard]] std::string index_pointer(const std::string_view base,
                                        const std::size_t index) {
  return std::string(base) + "/" + std::to_string(index);
}

[[nodiscard]] std::optional<std::size_t> first_invalid_utf8(
    const ObservationByteSpan bytes) noexcept {
  std::size_t offset = 0U;
  while (offset < bytes.size()) {
    const auto first = std::to_integer<unsigned char>(bytes[offset]);
    if (first <= 0x7fU) {
      ++offset;
      continue;
    }

    std::size_t continuation_count = 0U;
    std::uint32_t code_point = 0U;
    std::uint32_t minimum = 0U;
    if (first >= 0xc2U && first <= 0xdfU) {
      continuation_count = 1U;
      code_point = static_cast<std::uint32_t>(first & 0x1fU);
      minimum = 0x80U;
    } else if (first >= 0xe0U && first <= 0xefU) {
      continuation_count = 2U;
      code_point = static_cast<std::uint32_t>(first & 0x0fU);
      minimum = 0x800U;
    } else if (first >= 0xf0U && first <= 0xf4U) {
      continuation_count = 3U;
      code_point = static_cast<std::uint32_t>(first & 0x07U);
      minimum = 0x10000U;
    } else {
      return offset;
    }

    if (continuation_count > bytes.size() - offset - 1U) {
      return offset;
    }
    for (std::size_t index = 1U; index <= continuation_count; ++index) {
      const auto continuation =
          std::to_integer<unsigned char>(bytes[offset + index]);
      if ((continuation & 0xc0U) != 0x80U) {
        return offset + index;
      }
      code_point = (code_point << 6U) |
                   static_cast<std::uint32_t>(continuation & 0x3fU);
    }
    if (code_point < minimum || code_point > 0x10ffffU ||
        (code_point >= 0xd800U && code_point <= 0xdfffU)) {
      return offset;
    }
    offset += continuation_count + 1U;
  }
  return std::nullopt;
}

enum class ArrayRole : std::uint8_t {
  generic,
  replications,
  blocks,
  levels,
  boundary_rows,
  arrival_atoms,
  reporting_boundaries,
};

class ObservationSaxPreflight final : public nlohmann::json_sax<Json> {
 public:
  explicit ObservationSaxPreflight(const ObservationParseLimitsV1& limits)
      : limits_(limits) {}

  [[nodiscard]] bool null() override { return scalar_value(kNodeBytes); }
  [[nodiscard]] bool boolean(bool /*unused*/) override {
    return scalar_value(kNodeBytes);
  }
  [[nodiscard]] bool number_integer(number_integer_t /*unused*/) override {
    return scalar_value(kNodeBytes);
  }
  [[nodiscard]] bool number_unsigned(number_unsigned_t /*unused*/) override {
    return scalar_value(kNodeBytes);
  }
  [[nodiscard]] bool number_float(number_float_t /*unused*/,
                                  const string_t& /*unused*/) override {
    return reject(DiagnosticCategory::input_validation,
                  "observation_parse_decimal_number_forbidden",
                  "decimal JSON numbers are not part of the closed "
                  "observation-v1 wire grammar");
  }
  [[nodiscard]] bool string(string_t& value) override {
    if (!check_string(value) || !scalar_value(kNodeBytes + kStringBytes)) {
      return false;
    }
    return charge(value.size()) && charge(value.size()) &&
           charge(value.size());
  }
  [[nodiscard]] bool binary(binary_t& /*unused*/) override {
    return reject(DiagnosticCategory::input_validation,
                  "observation_parse_binary_value_forbidden",
                  "binary values are not valid observation-v1 JSON");
  }

  [[nodiscard]] bool start_object(std::size_t /*elements*/) override {
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= limits_.maximum_nesting_depth) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_nesting_limit",
                    "the observation JSON exceeds the nesting-depth cap");
    }
    if (!charge(kNodeBytes + kContainerBytes)) {
      return false;
    }
    frames_.push_back(Frame{FrameKind::object, ArrayRole::generic, {}, {}});
    return true;
  }

  [[nodiscard]] bool key(string_t& value) override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject(DiagnosticCategory::input_validation,
                    "observation_parse_invalid_json",
                    "an object key appeared outside an object");
    }
    if (!check_string(value)) {
      return false;
    }
    if (object_entries_ == limits_.maximum_object_entries) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_object_entries_limit",
                    "the observation JSON exceeds the object-entry cap");
    }
    ++object_entries_;
    Frame& frame = frames_.back();
    if (frame.keys.find(value) != frame.keys.end()) {
      return reject(DiagnosticCategory::input_validation,
                    "observation_parse_duplicate_key",
                    "the observation JSON contains a duplicate decoded key");
    }
    // Charge the hash node, the retained key and the pending-key copy before
    // either retained string is allocated.  Hash lookup avoids an O(k^2)
    // hostile-object path while preserving decoded-key duplicate semantics.
    if (!charge(kKeyIndexBytes) || !charge(value.size()) ||
        !charge(value.size())) {
      return false;
    }
    frame.keys.insert(value);
    frame.pending_key = value;
    return true;
  }

  [[nodiscard]] bool end_object() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return reject(DiagnosticCategory::input_validation,
                    "observation_parse_invalid_json",
                    "the observation JSON has an unmatched object end");
    }
    frames_.pop_back();
    return true;
  }

  [[nodiscard]] bool start_array(std::size_t /*elements*/) override {
    const ArrayRole role = pending_array_role();
    if (!begin_value()) {
      return false;
    }
    if (frames_.size() >= limits_.maximum_nesting_depth) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_nesting_limit",
                    "the observation JSON exceeds the nesting-depth cap");
    }
    if (!charge(kNodeBytes + kContainerBytes)) {
      return false;
    }
    frames_.push_back(Frame{FrameKind::array, role, {}, {}});
    return true;
  }

  [[nodiscard]] bool end_array() override {
    if (frames_.empty() || frames_.back().kind != FrameKind::array) {
      return reject(DiagnosticCategory::input_validation,
                    "observation_parse_invalid_json",
                    "the observation JSON has an unmatched array end");
    }
    frames_.pop_back();
    return true;
  }

  [[nodiscard]] bool parse_error(std::size_t /*position*/,
                                 const std::string& /*last_token*/,
                                 const nlohmann::detail::exception& error)
      override {
    if (!diagnostic_.has_value()) {
      diagnostic_ = wire_diagnostic(
          DiagnosticCategory::input_validation,
          "observation_parse_invalid_json",
          std::string("invalid observation-v1 JSON: ") + error.what());
    }
    return false;
  }

  [[nodiscard]] const std::optional<Diagnostic>& diagnostic() const noexcept {
    return diagnostic_;
  }

 private:
  static constexpr std::size_t kNodeBytes = 64U;
  static constexpr std::size_t kContainerBytes = 32U;
  static constexpr std::size_t kStringBytes = 32U;
  static constexpr std::size_t kKeyIndexBytes = 96U;

  enum class FrameKind : std::uint8_t { object, array };
  struct Frame final {
    FrameKind kind;
    ArrayRole array_role;
    std::unordered_set<std::string> keys;
    std::string pending_key;
  };

  [[nodiscard]] bool reject(const DiagnosticCategory category,
                            std::string code, std::string message) {
    if (!diagnostic_.has_value()) {
      diagnostic_ = wire_diagnostic(category, std::move(code),
                                    std::move(message));
    }
    return false;
  }

  [[nodiscard]] bool check_string(const std::string_view value) {
    if (value.size() > limits_.maximum_string_bytes) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_string_limit",
                    "an observation JSON string exceeds the length cap");
    }
    return true;
  }

  [[nodiscard]] bool charge(const std::size_t amount) {
    if (amount > limits_.maximum_total_decoded_allocation_bytes ||
        decoded_allocation_bytes_ >
            limits_.maximum_total_decoded_allocation_bytes - amount) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_allocation_limit",
                    "the observation JSON exceeds the decoded-allocation "
                    "cap");
    }
    decoded_allocation_bytes_ += amount;
    return true;
  }

  [[nodiscard]] ArrayRole pending_array_role() const noexcept {
    if (frames_.empty() || frames_.back().kind != FrameKind::object) {
      return ArrayRole::generic;
    }
    const std::string_view key = frames_.back().pending_key;
    if (key == "replications") {
      return ArrayRole::replications;
    }
    if (key == "blocks") {
      return ArrayRole::blocks;
    }
    if (key == "levels") {
      return ArrayRole::levels;
    }
    if (key == "rows") {
      return ArrayRole::boundary_rows;
    }
    if (key == "atoms") {
      return ArrayRole::arrival_atoms;
    }
    if (key == "reporting_block_boundaries") {
      return ArrayRole::reporting_boundaries;
    }
    return ArrayRole::generic;
  }

  [[nodiscard]] bool increment_role(const ArrayRole role) {
    std::size_t* counter = nullptr;
    std::size_t limit = 0U;
    std::string_view code;
    std::string_view name;
    switch (role) {
      case ArrayRole::generic:
        return true;
      case ArrayRole::replications:
        counter = &replications_;
        limit = limits_.maximum_replications;
        code = "observation_parse_replication_limit";
        name = "replication";
        break;
      case ArrayRole::blocks:
        counter = &blocks_;
        limit = limits_.maximum_total_blocks;
        code = "observation_parse_block_limit";
        name = "block";
        break;
      case ArrayRole::levels:
        counter = &level_rows_;
        limit = limits_.maximum_total_level_rows;
        code = "observation_parse_level_row_limit";
        name = "exact-level row";
        break;
      case ArrayRole::boundary_rows:
        counter = &boundary_rows_;
        limit = limits_.maximum_total_boundary_rows;
        code = "observation_parse_boundary_row_limit";
        name = "boundary row";
        break;
      case ArrayRole::arrival_atoms:
        counter = &arrival_atoms_;
        limit = limits_.maximum_arrival_atoms;
        code = "observation_parse_arrival_atom_limit";
        name = "arrival atom";
        break;
      case ArrayRole::reporting_boundaries:
        counter = &reporting_boundaries_;
        limit = limits_.maximum_reporting_boundaries;
        code = "observation_parse_reporting_boundary_limit";
        name = "reporting boundary";
        break;
    }
    if (*counter == limit) {
      return reject(DiagnosticCategory::resource_limit, std::string(code),
                    "the observation JSON exceeds the configured " +
                        std::string(name) + " cap");
    }
    ++*counter;
    return true;
  }

  [[nodiscard]] bool begin_value() {
    if (!frames_.empty() && frames_.back().kind == FrameKind::array) {
      if (array_entries_ == limits_.maximum_array_entries) {
        return reject(DiagnosticCategory::resource_limit,
                      "observation_parse_array_entries_limit",
                      "the observation JSON exceeds the cumulative "
                      "array-entry cap");
      }
      ++array_entries_;
      if (!increment_role(frames_.back().array_role)) {
        return false;
      }
    }
    return true;
  }

  [[nodiscard]] bool scalar_value(const std::size_t allocation) {
    if (!begin_value()) {
      return false;
    }
    if (scalar_count_ == limits_.maximum_scalar_count) {
      return reject(DiagnosticCategory::resource_limit,
                    "observation_parse_scalar_limit",
                    "the observation JSON exceeds the scalar-count cap");
    }
    ++scalar_count_;
    return charge(allocation);
  }

  const ObservationParseLimitsV1& limits_;
  std::vector<Frame> frames_;
  std::size_t object_entries_{0U};
  std::size_t array_entries_{0U};
  std::size_t scalar_count_{0U};
  std::size_t decoded_allocation_bytes_{0U};
  std::size_t replications_{0U};
  std::size_t blocks_{0U};
  std::size_t level_rows_{0U};
  std::size_t boundary_rows_{0U};
  std::size_t arrival_atoms_{0U};
  std::size_t reporting_boundaries_{0U};
  std::optional<Diagnostic> diagnostic_;
};

void require_object_shape(const Json& value, const std::string& path,
                          const std::initializer_list<std::string_view> keys) {
  if (!value.is_object()) {
    decode_fail("observation_wire_expected_object",
                "expected a closed observation-v1 object", path);
  }
  if (value.size() != keys.size()) {
    decode_fail("observation_wire_object_shape",
                "the observation-v1 object has missing or unknown members",
                path);
  }
  for (const std::string_view key : keys) {
    if (!value.contains(std::string(key))) {
      decode_fail("observation_wire_object_shape",
                  "the observation-v1 object has missing or unknown members",
                  path);
    }
  }
}

[[nodiscard]] const Json& required_member(const Json& value,
                                          const std::string_view key,
                                          const std::string& path) {
  const auto iterator = value.find(std::string(key));
  if (iterator == value.end()) {
    decode_fail("observation_wire_missing_member",
                "a required observation-v1 member is absent",
                child_pointer(path, key));
  }
  return *iterator;
}

[[nodiscard]] std::string decode_string(const Json& value,
                                        const std::string& path) {
  if (!value.is_string()) {
    decode_fail("observation_wire_expected_string", "expected a string",
                path);
  }
  return value.get<std::string>();
}

[[nodiscard]] bool decode_bool(const Json& value, const std::string& path) {
  if (!value.is_boolean()) {
    decode_fail("observation_wire_expected_boolean", "expected a boolean",
                path);
  }
  return value.get<bool>();
}

[[nodiscard]] std::uint64_t decode_u64(const Json& value,
                                       const std::string& path) {
  if (!value.is_number_unsigned()) {
    decode_fail("observation_wire_expected_u64",
                "expected an unsigned 64-bit integer", path);
  }
  return value.get<std::uint64_t>();
}

[[nodiscard]] std::uint32_t decode_u32(const Json& value,
                                       const std::string& path) {
  const std::uint64_t decoded = decode_u64(value, path);
  if (decoded > std::numeric_limits<std::uint32_t>::max()) {
    decode_fail("observation_wire_expected_u32",
                "the integer exceeds the unsigned 32-bit range", path);
  }
  return static_cast<std::uint32_t>(decoded);
}

[[nodiscard]] Digest256 decode_digest(const Json& value,
                                      const std::string& path) {
  const std::string encoded = decode_string(value, path);
  return take_or_decode_fail(Digest256::from_hex(encoded), path,
                             "observation_wire_digest");
}

[[nodiscard]] Json encode_digest(const Digest256& value) {
  return value.hex();
}

[[nodiscard]] BigNat decode_big_nat(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  const std::string encoded = decode_string(value, path);
  BoundPolicy policy;
  policy.maximum_bits = limits.maximum_integer_bits;
  policy.maximum_decimal_digits = limits.maximum_integer_decimal_digits;
  return take_or_decode_fail(
      parse_exact_nonnegative_integer(JsonNumber(encoded), std::move(policy)),
      path, "observation_wire_big_nat");
}

[[nodiscard]] Json encode_big_nat(const BigNat& value) {
  return value.to_decimal_string();
}

[[nodiscard]] PortableScientificScalar decode_portable_scalar(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  if (!value.is_object() || !value.contains("kind") ||
      !value.at("kind").is_string()) {
    decode_fail("observation_wire_scalar_shape",
                "expected a tagged scientific scalar", path);
  }
  const std::string kind = value.at("kind").get<std::string>();
  if (kind == "rational") {
    require_object_shape(value, path,
                         {"kind", "numerator", "denominator"});
    const std::string numerator = decode_string(
        required_member(value, "numerator", path),
        child_pointer(path, "numerator"));
    const std::string denominator = decode_string(
        required_member(value, "denominator", path),
        child_pointer(path, "denominator"));
    RationalBoundPolicy policy;
    policy.maximum_bits = limits.maximum_integer_bits;
    policy.maximum_decimal_digits = limits.maximum_integer_decimal_digits;
    return take_or_decode_fail(
        PortableScientificScalar::parse_rational(numerator, denominator,
                                                 std::move(policy)),
        path, "observation_wire_rational");
  }
  if (kind == "binary64") {
    require_object_shape(value, path, {"kind", "bits"});
    const std::string bits = decode_string(
        required_member(value, "bits", path), child_pointer(path, "bits"));
    return take_or_decode_fail(PortableScientificScalar::parse_binary64(bits),
                               path, "observation_wire_binary64");
  }
  decode_fail("observation_wire_scalar_kind",
              "unknown observation scientific-scalar kind",
              child_pointer(path, "kind"));
}

[[nodiscard]] Json encode_portable_scalar(
    const PortableScientificScalar& value) {
  Json result = Json::object();
  if (value.kind() == PortableScientificScalarKind::rational) {
    result["kind"] = "rational";
    result["numerator"] = value.rational_value().numerator_decimal();
    result["denominator"] = value.rational_value().denominator_decimal();
  } else {
    result["kind"] = "binary64";
    result["bits"] = value.binary64_encoding();
  }
  return result;
}

[[nodiscard]] ExactRational decode_exact_rational(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  PortableScientificScalar decoded =
      decode_portable_scalar(value, path, limits);
  if (decoded.kind() != PortableScientificScalarKind::rational) {
    decode_fail("observation_wire_expected_exact_rational",
                "this observation-v1 field requires a rational scalar",
                path);
  }
  return decoded.rational_value();
}

[[nodiscard]] Json encode_exact_rational(const ExactRational& value) {
  return encode_portable_scalar(PortableScientificScalar::rational(value));
}

[[nodiscard]] Json encode_typed_label(const TypedLabel& value) {
  Json result = Json::object();
  if (value.is_numeric()) {
    result["kind"] = "numeric";
    result["value"] = value.numeric_value()->to_decimal_string();
  } else {
    result["kind"] = "text";
    result["value"] = *value.text_value();
  }
  return result;
}

[[nodiscard]] TypedLabel decode_typed_label(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path, {"kind", "value"});
  const std::string kind = decode_string(required_member(value, "kind", path),
                                         child_pointer(path, "kind"));
  const std::string body = decode_string(required_member(value, "value", path),
                                         child_pointer(path, "value"));
  if (kind == "numeric") {
    BoundPolicy policy;
    policy.maximum_bits = limits.maximum_integer_bits;
    policy.maximum_decimal_digits = limits.maximum_integer_decimal_digits;
    BigNat number = take_or_decode_fail(
        parse_exact_nonnegative_integer(JsonNumber(body), std::move(policy)),
        child_pointer(path, "value"), "observation_wire_typed_label");
    return TypedLabel::numeric(std::move(number));
  }
  if (kind == "text") {
    return take_or_decode_fail(TypedLabel::text(body),
                               child_pointer(path, "value"),
                               "observation_wire_typed_label");
  }
  decode_fail("observation_wire_typed_label_kind",
              "unknown typed-label kind", child_pointer(path, "kind"));
}

template <typename Enum>
[[nodiscard]] Enum decode_enum(
    const Json& value, const std::string& path,
    const std::initializer_list<std::pair<std::string_view, Enum>> spellings) {
  const std::string encoded = decode_string(value, path);
  for (const auto& [spelling, enumeration] : spellings) {
    if (encoded == spelling) {
      return enumeration;
    }
  }
  decode_fail("observation_wire_enum",
              "unknown value for a closed observation-v1 enumeration", path);
}

[[nodiscard]] std::string_view encode_source_role(
    const ObservationSourceRoleV1 value) {
  switch (value) {
    case ObservationSourceRoleV1::weighted_ensemble:
      return "weighted_ensemble";
    case ObservationSourceRoleV1::short_restart_reference:
      return "short_restart_reference";
    case ObservationSourceRoleV1::long_stationary_reference:
      return "long_stationary_reference";
  }
  throw std::invalid_argument("invalid observation source role");
}

[[nodiscard]] ObservationSourceRoleV1 decode_source_role(
    const Json& value, const std::string& path) {
  return decode_enum<ObservationSourceRoleV1>(
      value, path,
      {{"weighted_ensemble", ObservationSourceRoleV1::weighted_ensemble},
       {"short_restart_reference",
        ObservationSourceRoleV1::short_restart_reference},
       {"long_stationary_reference",
        ObservationSourceRoleV1::long_stationary_reference}});
}

[[nodiscard]] std::string_view encode_scalar_representation(
    const ObservationScalarRepresentationV1 value) {
  switch (value) {
    case ObservationScalarRepresentationV1::exact_rational:
      return "exact_rational";
    case ObservationScalarRepresentationV1::enclosed_binary64:
      return "enclosed_binary64";
  }
  throw std::invalid_argument("invalid observation scalar representation");
}

[[nodiscard]] ObservationScalarRepresentationV1
decode_scalar_representation(const Json& value, const std::string& path) {
  return decode_enum<ObservationScalarRepresentationV1>(
      value, path,
      {{"exact_rational",
        ObservationScalarRepresentationV1::exact_rational},
       {"enclosed_binary64",
        ObservationScalarRepresentationV1::enclosed_binary64}});
}

[[nodiscard]] std::string_view encode_completeness(
    const ObservationCompletenessV1 value) {
  switch (value) {
    case ObservationCompletenessV1::complete:
      return "complete";
    case ObservationCompletenessV1::partial:
      return "partial";
  }
  throw std::invalid_argument("invalid observation completeness");
}

[[nodiscard]] ObservationCompletenessV1 decode_completeness(
    const Json& value, const std::string& path) {
  return decode_enum<ObservationCompletenessV1>(
      value, path,
      {{"complete", ObservationCompletenessV1::complete},
       {"partial", ObservationCompletenessV1::partial}});
}

[[nodiscard]] std::string_view encode_normalization_claim(
    const ObservationNormalizationClaimV1 value) {
  switch (value) {
    case ObservationNormalizationClaimV1::exact:
      return "exact";
    case ObservationNormalizationClaimV1::enclosed:
      return "enclosed";
    case ObservationNormalizationClaimV1::not_claimed:
      return "not_claimed";
  }
  throw std::invalid_argument("invalid observation normalization claim");
}

[[nodiscard]] ObservationNormalizationClaimV1 decode_normalization_claim(
    const Json& value, const std::string& path) {
  return decode_enum<ObservationNormalizationClaimV1>(
      value, path,
      {{"exact", ObservationNormalizationClaimV1::exact},
       {"enclosed", ObservationNormalizationClaimV1::enclosed},
       {"not_claimed", ObservationNormalizationClaimV1::not_claimed}});
}

[[nodiscard]] std::string_view encode_slot_stage(
    const ObservationSlotStageV1 value) {
  switch (value) {
    case ObservationSlotStageV1::solve_primary_maxweight:
      return "solve_primary_maxweight";
    case ObservationSlotStageV1::observe_pre_service:
      return "observe_pre_service";
    case ObservationSlotStageV1::apply_actual_service:
      return "apply_actual_service";
    case ObservationSlotStageV1::classify_and_resample:
      return "classify_and_resample";
    case ObservationSlotStageV1::allocate_child_lineage:
      return "allocate_child_lineage";
    case ObservationSlotStageV1::apply_fresh_late_arrival:
      return "apply_fresh_late_arrival";
    case ObservationSlotStageV1::commit_post_slot_state:
      return "commit_post_slot_state";
    case ObservationSlotStageV1::emit_committed_observation:
      return "emit_committed_observation";
  }
  throw std::invalid_argument("invalid observation slot stage");
}

[[nodiscard]] ObservationSlotStageV1 decode_slot_stage(
    const Json& value, const std::string& path) {
  return decode_enum<ObservationSlotStageV1>(
      value, path,
      {{"solve_primary_maxweight",
        ObservationSlotStageV1::solve_primary_maxweight},
       {"observe_pre_service", ObservationSlotStageV1::observe_pre_service},
       {"apply_actual_service", ObservationSlotStageV1::apply_actual_service},
       {"classify_and_resample",
        ObservationSlotStageV1::classify_and_resample},
       {"allocate_child_lineage",
        ObservationSlotStageV1::allocate_child_lineage},
       {"apply_fresh_late_arrival",
        ObservationSlotStageV1::apply_fresh_late_arrival},
       {"commit_post_slot_state",
        ObservationSlotStageV1::commit_post_slot_state},
       {"emit_committed_observation",
        ObservationSlotStageV1::emit_committed_observation}});
}

[[nodiscard]] Json encode_enclosure(
    const ObservationNumericalEnclosureV1& value) {
  Json result = Json::object();
  result["absolute_error"] = encode_portable_scalar(value.absolute_error);
  result["l1_norm"] = encode_portable_scalar(value.l1_norm);
  return result;
}

[[nodiscard]] ObservationNumericalEnclosureV1 decode_enclosure(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path, {"absolute_error", "l1_norm"});
  return ObservationNumericalEnclosureV1{
      decode_portable_scalar(required_member(value, "absolute_error", path),
                             child_pointer(path, "absolute_error"), limits),
      decode_portable_scalar(required_member(value, "l1_norm", path),
                             child_pointer(path, "l1_norm"), limits)};
}

[[nodiscard]] Json encode_observation_scalar(
    const ObservationScalarV1& value) {
  Json result = Json::object();
  result["value"] = encode_portable_scalar(value.value);
  result["enclosure"] = value.enclosure.has_value()
                            ? encode_enclosure(*value.enclosure)
                            : Json(nullptr);
  return result;
}

[[nodiscard]] ObservationScalarV1 decode_observation_scalar(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path, {"value", "enclosure"});
  std::optional<ObservationNumericalEnclosureV1> enclosure;
  const Json& enclosure_json = required_member(value, "enclosure", path);
  if (!enclosure_json.is_null()) {
    enclosure = decode_enclosure(enclosure_json,
                                 child_pointer(path, "enclosure"), limits);
  }
  return ObservationScalarV1{
      decode_portable_scalar(required_member(value, "value", path),
                             child_pointer(path, "value"), limits),
      std::move(enclosure)};
}

[[nodiscard]] Json encode_mass_balance(
    const ObservationMassBalanceV1& value) {
  Json result = Json::object();
  result["claim"] = std::string(encode_normalization_claim(value.claim));
  result["recorded_mass"] = encode_observation_scalar(value.recorded_mass);
  result["signed_mass_defect"] =
      encode_observation_scalar(value.signed_mass_defect);
  return result;
}

[[nodiscard]] ObservationMassBalanceV1 decode_mass_balance(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path,
                       {"claim", "recorded_mass", "signed_mass_defect"});
  return ObservationMassBalanceV1{
      decode_normalization_claim(required_member(value, "claim", path),
                                 child_pointer(path, "claim")),
      decode_observation_scalar(required_member(value, "recorded_mass", path),
                                child_pointer(path, "recorded_mass"), limits),
      decode_observation_scalar(
          required_member(value, "signed_mass_defect", path),
          child_pointer(path, "signed_mass_defect"), limits)};
}

[[nodiscard]] Json encode_gap_cell(const ObservationGapCellV1& value) {
  Json result = Json::object();
  result["negative_mass"] = encode_observation_scalar(value.negative_mass);
  result["tie_mass"] = encode_observation_scalar(value.tie_mass);
  result["positive_mass"] = encode_observation_scalar(value.positive_mass);
  result["tied_and_served_mass"] =
      encode_observation_scalar(value.tied_and_served_mass);
  result["positive_magnitude_mass"] =
      encode_observation_scalar(value.positive_magnitude_mass);
  result["negative_magnitude_mass"] =
      encode_observation_scalar(value.negative_magnitude_mass);
  return result;
}

[[nodiscard]] ObservationGapCellV1 decode_gap_cell(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path,
                       {"negative_mass", "tie_mass", "positive_mass",
                        "tied_and_served_mass", "positive_magnitude_mass",
                        "negative_magnitude_mass"});
  return ObservationGapCellV1{
      decode_observation_scalar(required_member(value, "negative_mass", path),
                                child_pointer(path, "negative_mass"), limits),
      decode_observation_scalar(required_member(value, "tie_mass", path),
                                child_pointer(path, "tie_mass"), limits),
      decode_observation_scalar(required_member(value, "positive_mass", path),
                                child_pointer(path, "positive_mass"), limits),
      decode_observation_scalar(
          required_member(value, "tied_and_served_mass", path),
          child_pointer(path, "tied_and_served_mass"), limits),
      decode_observation_scalar(
          required_member(value, "positive_magnitude_mass", path),
          child_pointer(path, "positive_magnitude_mass"), limits),
      decode_observation_scalar(
          required_member(value, "negative_magnitude_mass", path),
          child_pointer(path, "negative_magnitude_mass"), limits)};
}

[[nodiscard]] Json encode_level(const ExactLevelObservationV1& value) {
  Json result = Json::object();
  result["backlog_level"] = encode_big_nat(value.backlog_level);
  result["exposure_mass"] = encode_observation_scalar(value.exposure_mass);
  result["served_mass"] = encode_observation_scalar(value.served_mass);
  result["gap"] =
      value.gap.has_value() ? encode_gap_cell(*value.gap) : Json(nullptr);
  return result;
}

[[nodiscard]] ExactLevelObservationV1 decode_level(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path,
                       {"backlog_level", "exposure_mass", "served_mass",
                        "gap"});
  std::optional<ObservationGapCellV1> gap;
  const Json& gap_json = required_member(value, "gap", path);
  if (!gap_json.is_null()) {
    gap = decode_gap_cell(gap_json, child_pointer(path, "gap"), limits);
  }
  return ExactLevelObservationV1{
      decode_big_nat(required_member(value, "backlog_level", path),
                     child_pointer(path, "backlog_level"), limits),
      decode_observation_scalar(required_member(value, "exposure_mass", path),
                                child_pointer(path, "exposure_mass"), limits),
      decode_observation_scalar(required_member(value, "served_mass", path),
                                child_pointer(path, "served_mass"), limits),
      std::move(gap)};
}

[[nodiscard]] Json encode_boundary_row(const BoundaryBacklogMassV1& value) {
  Json result = Json::object();
  result["backlog_level"] = encode_big_nat(value.backlog_level);
  result["mass"] = encode_observation_scalar(value.mass);
  return result;
}

[[nodiscard]] BoundaryBacklogMassV1 decode_boundary_row(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path, {"backlog_level", "mass"});
  return BoundaryBacklogMassV1{
      decode_big_nat(required_member(value, "backlog_level", path),
                     child_pointer(path, "backlog_level"), limits),
      decode_observation_scalar(required_member(value, "mass", path),
                                child_pointer(path, "mass"), limits)};
}

template <typename T, typename Encoder>
[[nodiscard]] Json encode_array(const std::vector<T>& values,
                                Encoder&& encoder) {
  Json result = Json::array();
  for (const T& value : values) {
    result.push_back(encoder(value));
  }
  return result;
}

template <typename T, typename Decoder>
[[nodiscard]] std::vector<T> decode_array(
    const Json& value, const std::string& path, const std::size_t maximum,
    Decoder&& decoder, const std::string_view limit_code) {
  if (!value.is_array()) {
    decode_fail("observation_wire_expected_array", "expected an array",
                path);
  }
  if (value.size() > maximum) {
    decode_fail(std::string(limit_code),
                "the observation array exceeds its configured cap", path,
                DiagnosticCategory::resource_limit);
  }
  std::vector<T> result;
  result.reserve(value.size());
  for (std::size_t index = 0U; index < value.size(); ++index) {
    result.push_back(decoder(value[index], index_pointer(path, index)));
  }
  return result;
}

[[nodiscard]] Json encode_boundary_law(const BoundaryBacklogLawV1& value) {
  Json result = Json::object();
  result["boundary"] = value.boundary;
  result["rows"] = encode_array(value.rows, encode_boundary_row);
  result["mass_balance"] = encode_mass_balance(value.mass_balance);
  return result;
}

[[nodiscard]] BoundaryBacklogLawV1 decode_boundary_law(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path, {"boundary", "rows", "mass_balance"});
  return BoundaryBacklogLawV1{
      decode_u64(required_member(value, "boundary", path),
                 child_pointer(path, "boundary")),
      decode_array<BoundaryBacklogMassV1>(
          required_member(value, "rows", path), child_pointer(path, "rows"),
          limits.maximum_total_boundary_rows,
          [&](const Json& row, const std::string& row_path) {
            return decode_boundary_row(row, row_path, limits);
          },
          "observation_parse_boundary_row_limit"),
      decode_mass_balance(required_member(value, "mass_balance", path),
                          child_pointer(path, "mass_balance"), limits)};
}

[[nodiscard]] Json encode_block(const ConstructionObservationBlockV1& value) {
  Json result = Json::object();
  result["begin_boundary"] = value.begin_boundary;
  result["end_boundary"] = value.end_boundary;
  result["completeness"] = std::string(encode_completeness(value.completeness));
  result["committed_through_boundary"] = value.committed_through_boundary;
  result["levels"] = encode_array(value.levels, encode_level);
  result["exposure_mass_balance"] =
      encode_mass_balance(value.exposure_mass_balance);
  result["initial_boundary_law"] =
      encode_boundary_law(value.initial_boundary_law);
  result["committed_boundary_law"] =
      encode_boundary_law(value.committed_boundary_law);
  return result;
}

[[nodiscard]] ConstructionObservationBlockV1 decode_block(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(
      value, path,
      {"begin_boundary", "end_boundary", "completeness",
       "committed_through_boundary", "levels", "exposure_mass_balance",
       "initial_boundary_law", "committed_boundary_law"});
  return ConstructionObservationBlockV1{
      decode_u64(required_member(value, "begin_boundary", path),
                 child_pointer(path, "begin_boundary")),
      decode_u64(required_member(value, "end_boundary", path),
                 child_pointer(path, "end_boundary")),
      decode_completeness(required_member(value, "completeness", path),
                          child_pointer(path, "completeness")),
      decode_u64(required_member(value, "committed_through_boundary", path),
                 child_pointer(path, "committed_through_boundary")),
      decode_array<ExactLevelObservationV1>(
          required_member(value, "levels", path),
          child_pointer(path, "levels"), limits.maximum_total_level_rows,
          [&](const Json& row, const std::string& row_path) {
            return decode_level(row, row_path, limits);
          },
          "observation_parse_level_row_limit"),
      decode_mass_balance(
          required_member(value, "exposure_mass_balance", path),
          child_pointer(path, "exposure_mass_balance"), limits),
      decode_boundary_law(required_member(value, "initial_boundary_law", path),
                          child_pointer(path, "initial_boundary_law"), limits),
      decode_boundary_law(
          required_member(value, "committed_boundary_law", path),
          child_pointer(path, "committed_boundary_law"), limits)};
}

[[nodiscard]] Json encode_replication(
    const ConstructionObservationReplicationV1& value) {
  Json result = Json::object();
  result["replication_id"] = encode_typed_label(value.replication_id);
  result["replay_identity"] = encode_digest(value.replay_identity);
  result["lineage_arrival_identity"] =
      value.lineage_arrival_identity.has_value()
          ? encode_digest(*value.lineage_arrival_identity)
          : Json(nullptr);
  result["completeness"] = std::string(encode_completeness(value.completeness));
  result["committed_through_boundary"] = value.committed_through_boundary;
  result["blocks"] = encode_array(value.blocks, encode_block);
  return result;
}

[[nodiscard]] ConstructionObservationReplicationV1 decode_replication(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path,
                       {"replication_id", "replay_identity",
                        "lineage_arrival_identity", "completeness",
                        "committed_through_boundary", "blocks"});
  std::optional<Digest256> lineage_identity;
  const Json& lineage_json =
      required_member(value, "lineage_arrival_identity", path);
  if (!lineage_json.is_null()) {
    lineage_identity = decode_digest(
        lineage_json, child_pointer(path, "lineage_arrival_identity"));
  }
  return ConstructionObservationReplicationV1{
      decode_typed_label(required_member(value, "replication_id", path),
                         child_pointer(path, "replication_id"), limits),
      decode_digest(required_member(value, "replay_identity", path),
                    child_pointer(path, "replay_identity")),
      std::move(lineage_identity),
      decode_completeness(required_member(value, "completeness", path),
                          child_pointer(path, "completeness")),
      decode_u64(required_member(value, "committed_through_boundary", path),
                 child_pointer(path, "committed_through_boundary")),
      decode_array<ConstructionObservationBlockV1>(
          required_member(value, "blocks", path), child_pointer(path, "blocks"),
          limits.maximum_total_blocks,
          [&](const Json& block, const std::string& block_path) {
            return decode_block(block, block_path, limits);
          },
          "observation_parse_block_limit")};
}

[[nodiscard]] Json encode_arrival_atom(const ExactTargetArrivalAtomV1& value) {
  Json result = Json::object();
  result["batch_size"] = encode_big_nat(value.batch_size);
  result["probability"] = encode_exact_rational(value.probability);
  return result;
}

[[nodiscard]] ExactTargetArrivalAtomV1 decode_arrival_atom(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path, {"batch_size", "probability"});
  return ExactTargetArrivalAtomV1{
      decode_big_nat(required_member(value, "batch_size", path),
                     child_pointer(path, "batch_size"), limits),
      decode_exact_rational(required_member(value, "probability", path),
                            child_pointer(path, "probability"), limits)};
}

[[nodiscard]] Json encode_target_arrival(
    const TargetArrivalDescriptionV1& value) {
  Json result = Json::object();
  std::visit(
      [&](const auto& active) {
        using Active = std::remove_cvref_t<decltype(active)>;
        if constexpr (std::same_as<Active, ExactTargetArrivalMarginalV1>) {
          result["kind"] = "exact_marginal";
          result["atoms"] = encode_array(active.atoms, encode_arrival_atom);
        } else {
          result["kind"] = "overshoot_descriptor";
          result["descriptor_id"] = active.descriptor_id;
          result["descriptor_version"] = active.descriptor_version;
          result["descriptor_digest"] =
              encode_digest(active.descriptor_digest);
        }
      },
      value);
  return result;
}

[[nodiscard]] TargetArrivalDescriptionV1 decode_target_arrival(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  if (!value.is_object()) {
    decode_fail("observation_wire_expected_object",
                "expected a target-arrival object", path);
  }
  const std::string kind = decode_string(
      required_member(value, "kind", path), child_pointer(path, "kind"));
  if (kind == "exact_marginal") {
    require_object_shape(value, path, {"kind", "atoms"});
    return ExactTargetArrivalMarginalV1{decode_array<ExactTargetArrivalAtomV1>(
        required_member(value, "atoms", path), child_pointer(path, "atoms"),
        limits.maximum_arrival_atoms,
        [&](const Json& atom, const std::string& atom_path) {
          return decode_arrival_atom(atom, atom_path, limits);
        },
        "observation_parse_arrival_atom_limit")};
  }
  if (kind == "overshoot_descriptor") {
    require_object_shape(value, path,
                         {"kind", "descriptor_id", "descriptor_version",
                          "descriptor_digest"});
    return TargetArrivalOvershootDescriptorV1{
        decode_string(required_member(value, "descriptor_id", path),
                      child_pointer(path, "descriptor_id")),
        decode_u32(required_member(value, "descriptor_version", path),
                   child_pointer(path, "descriptor_version")),
        decode_digest(required_member(value, "descriptor_digest", path),
                      child_pointer(path, "descriptor_digest"))};
  }
  decode_fail("observation_wire_target_arrival_kind",
              "unknown target-arrival description kind",
              child_pointer(path, "kind"));
}

[[nodiscard]] Json encode_arrival_binding(
    const ObservationArrivalBindingV1& value) {
  Json result = Json::object();
  result["arrival_family_id"] = value.arrival_family_id;
  result["configured_law_digest"] = encode_digest(value.configured_law_digest);
  result["target_arrival"] = encode_target_arrival(value.target_arrival);
  result["mean"] = encode_exact_rational(value.mean);
  result["second_moment"] = encode_exact_rational(value.second_moment);
  return result;
}

[[nodiscard]] ObservationArrivalBindingV1 decode_arrival_binding(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path,
                       {"arrival_family_id", "configured_law_digest",
                        "target_arrival", "mean", "second_moment"});
  return ObservationArrivalBindingV1{
      decode_string(required_member(value, "arrival_family_id", path),
                    child_pointer(path, "arrival_family_id")),
      decode_digest(required_member(value, "configured_law_digest", path),
                    child_pointer(path, "configured_law_digest")),
      decode_target_arrival(required_member(value, "target_arrival", path),
                            child_pointer(path, "target_arrival"), limits),
      decode_exact_rational(required_member(value, "mean", path),
                            child_pointer(path, "mean"), limits),
      decode_exact_rational(required_member(value, "second_moment", path),
                            child_pointer(path, "second_moment"), limits)};
}

[[nodiscard]] Json encode_target_binding(
    const ObservationTargetBindingV1& value) {
  Json result = Json::object();
  result["target_id"] = encode_typed_label(value.target_id.label());
  result["target_index"] = value.target_index;
  result["maxweight_multiplier"] =
      encode_exact_rational(value.maxweight_multiplier);
  return result;
}

[[nodiscard]] ObservationTargetBindingV1 decode_target_binding(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(value, path,
                       {"target_id", "target_index", "maxweight_multiplier"});
  return ObservationTargetBindingV1{
      QueueId(decode_typed_label(required_member(value, "target_id", path),
                                 child_pointer(path, "target_id"), limits)),
      decode_u64(required_member(value, "target_index", path),
                 child_pointer(path, "target_index")),
      decode_exact_rational(required_member(value, "maxweight_multiplier", path),
                            child_pointer(path, "maxweight_multiplier"),
                            limits)};
}

[[nodiscard]] Json encode_bindings(
    const ObservationScientificBindingsV1& value) {
  Json result = Json::object();
  result["request_digest"] = encode_digest(value.request_digest);
  result["problem_digest"] = encode_digest(value.problem_digest);
  result["experiment_digest"] = encode_digest(value.experiment_digest);
  result["target"] = encode_target_binding(value.target);
  result["arrival"] = encode_arrival_binding(value.arrival);
  result["topology_digest"] = encode_digest(value.topology_digest);
  result["scheduler_digest"] = encode_digest(value.scheduler_digest);
  result["optimizer_digest"] = encode_digest(value.optimizer_digest);
  result["primary_objective_digest"] =
      encode_digest(value.primary_objective_digest);
  result["priority_digest"] = encode_digest(value.priority_digest);
  result["tie_policy_digest"] = encode_digest(value.tie_policy_digest);
  return result;
}

[[nodiscard]] ObservationScientificBindingsV1 decode_bindings(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(
      value, path,
      {"request_digest", "problem_digest", "experiment_digest", "target",
       "arrival", "topology_digest", "scheduler_digest", "optimizer_digest",
       "primary_objective_digest", "priority_digest", "tie_policy_digest"});
  return ObservationScientificBindingsV1{
      decode_digest(required_member(value, "request_digest", path),
                    child_pointer(path, "request_digest")),
      decode_digest(required_member(value, "problem_digest", path),
                    child_pointer(path, "problem_digest")),
      decode_digest(required_member(value, "experiment_digest", path),
                    child_pointer(path, "experiment_digest")),
      decode_target_binding(required_member(value, "target", path),
                            child_pointer(path, "target"), limits),
      decode_arrival_binding(required_member(value, "arrival", path),
                             child_pointer(path, "arrival"), limits),
      decode_digest(required_member(value, "topology_digest", path),
                    child_pointer(path, "topology_digest")),
      decode_digest(required_member(value, "scheduler_digest", path),
                    child_pointer(path, "scheduler_digest")),
      decode_digest(required_member(value, "optimizer_digest", path),
                    child_pointer(path, "optimizer_digest")),
      decode_digest(required_member(value, "primary_objective_digest", path),
                    child_pointer(path, "primary_objective_digest")),
      decode_digest(required_member(value, "priority_digest", path),
                    child_pointer(path, "priority_digest")),
      decode_digest(required_member(value, "tie_policy_digest", path),
                    child_pointer(path, "tie_policy_digest"))};
}

[[nodiscard]] Json encode_slot_convention(
    const ObservationSlotConventionV1& value) {
  Json result = Json::object();
  result["row_phase"] = "pre_service";
  result["service_mark"] = "actual_binary_departure";
  result["arrival_phase"] = "fresh_late_after_service";
  result["boundary_phase"] = "committed_post_slot_pre_service";
  result["step_order"] = encode_array(
      value.step_order,
      [](const ObservationSlotStageV1 stage) {
        return Json(std::string(encode_slot_stage(stage)));
      });
  result["convention_digest"] = encode_digest(value.convention_digest);
  return result;
}

[[nodiscard]] ObservationSlotConventionV1 decode_slot_convention(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"row_phase", "service_mark", "arrival_phase",
                        "boundary_phase", "step_order", "convention_digest"});
  if (decode_string(required_member(value, "row_phase", path),
                    child_pointer(path, "row_phase")) != "pre_service" ||
      decode_string(required_member(value, "service_mark", path),
                    child_pointer(path, "service_mark")) !=
          "actual_binary_departure" ||
      decode_string(required_member(value, "arrival_phase", path),
                    child_pointer(path, "arrival_phase")) !=
          "fresh_late_after_service" ||
      decode_string(required_member(value, "boundary_phase", path),
                    child_pointer(path, "boundary_phase")) !=
          "committed_post_slot_pre_service") {
    decode_fail("observation_wire_slot_convention",
                "observation-v1 requires pre-service rows, actual service, "
                "fresh late arrivals and committed post-slot boundaries",
                path);
  }
  return ObservationSlotConventionV1{
      decode_array<ObservationSlotStageV1>(
          required_member(value, "step_order", path),
          child_pointer(path, "step_order"), 8U,
          [](const Json& stage, const std::string& stage_path) {
            return decode_slot_stage(stage, stage_path);
          },
          "observation_parse_step_order_limit"),
      decode_digest(required_member(value, "convention_digest", path),
                    child_pointer(path, "convention_digest"))};
}

[[nodiscard]] Json encode_initialization(
    const ObservationInitializationV1& value) {
  Json result = Json::object();
  result["initial_law_id"] = value.initial_law_id;
  result["initial_law_digest"] = encode_digest(value.initial_law_digest);
  return result;
}

[[nodiscard]] ObservationInitializationV1 decode_initialization(
    const Json& value, const std::string& path) {
  require_object_shape(value, path, {"initial_law_id", "initial_law_digest"});
  return ObservationInitializationV1{
      decode_string(required_member(value, "initial_law_id", path),
                    child_pointer(path, "initial_law_id")),
      decode_digest(required_member(value, "initial_law_digest", path),
                    child_pointer(path, "initial_law_digest"))};
}

[[nodiscard]] Json encode_rng(const ObservationRngBindingV1& value) {
  Json result = Json::object();
  result["rng_abi_id"] = value.rng_abi_id;
  result["rng_abi_version"] = value.rng_abi_version;
  result["construction_seed_policy_digest"] =
      encode_digest(value.construction_seed_policy_digest);
  return result;
}

[[nodiscard]] ObservationRngBindingV1 decode_rng(const Json& value,
                                                 const std::string& path) {
  require_object_shape(value, path,
                       {"rng_abi_id", "rng_abi_version",
                        "construction_seed_policy_digest"});
  return ObservationRngBindingV1{
      decode_string(required_member(value, "rng_abi_id", path),
                    child_pointer(path, "rng_abi_id")),
      decode_u32(required_member(value, "rng_abi_version", path),
                 child_pointer(path, "rng_abi_version")),
      decode_digest(
          required_member(value, "construction_seed_policy_digest", path),
          child_pointer(path, "construction_seed_policy_digest"))};
}

[[nodiscard]] Json encode_capability(
    const ObservationCapabilityStateV1& value) {
  Json result = Json::object();
  result["available"] = value.available;
  result["unavailable_reason_code"] =
      value.unavailable_reason_code.has_value()
          ? Json(*value.unavailable_reason_code)
          : Json(nullptr);
  return result;
}

[[nodiscard]] ObservationCapabilityStateV1 decode_capability(
    const Json& value, const std::string& path) {
  require_object_shape(value, path,
                       {"available", "unavailable_reason_code"});
  std::optional<std::string> reason;
  const Json& reason_json =
      required_member(value, "unavailable_reason_code", path);
  if (!reason_json.is_null()) {
    reason = decode_string(reason_json,
                           child_pointer(path, "unavailable_reason_code"));
  }
  return ObservationCapabilityStateV1{
      decode_bool(required_member(value, "available", path),
                  child_pointer(path, "available")),
      std::move(reason)};
}

[[nodiscard]] Json encode_capabilities(
    const ObservationCapabilitiesV1& value) {
  Json result = Json::object();
  result["iid_fresh_arrivals"] = encode_capability(value.iid_fresh_arrivals);
  result["finite_arrival_second_moment"] =
      encode_capability(value.finite_arrival_second_moment);
  result["exact_target_arrival_marginal"] =
      encode_capability(value.exact_target_arrival_marginal);
  result["no_target_drops"] = encode_capability(value.no_target_drops);
  result["exact_primary_maxweight"] =
      encode_capability(value.exact_primary_maxweight);
  result["unit_target_multiplier"] =
      encode_capability(value.unit_target_multiplier);
  result["certified_gap_probe"] =
      encode_capability(value.certified_gap_probe);
  return result;
}

[[nodiscard]] ObservationCapabilitiesV1 decode_capabilities(
    const Json& value, const std::string& path) {
  require_object_shape(
      value, path,
      {"iid_fresh_arrivals", "finite_arrival_second_moment",
       "exact_target_arrival_marginal", "no_target_drops",
       "exact_primary_maxweight", "unit_target_multiplier",
       "certified_gap_probe"});
  return ObservationCapabilitiesV1{
      decode_capability(required_member(value, "iid_fresh_arrivals", path),
                        child_pointer(path, "iid_fresh_arrivals")),
      decode_capability(
          required_member(value, "finite_arrival_second_moment", path),
          child_pointer(path, "finite_arrival_second_moment")),
      decode_capability(
          required_member(value, "exact_target_arrival_marginal", path),
          child_pointer(path, "exact_target_arrival_marginal")),
      decode_capability(required_member(value, "no_target_drops", path),
                        child_pointer(path, "no_target_drops")),
      decode_capability(required_member(value, "exact_primary_maxweight", path),
                        child_pointer(path, "exact_primary_maxweight")),
      decode_capability(required_member(value, "unit_target_multiplier", path),
                        child_pointer(path, "unit_target_multiplier")),
      decode_capability(required_member(value, "certified_gap_probe", path),
                        child_pointer(path, "certified_gap_probe"))};
}

[[nodiscard]] Json encode_bundle_body(
    const ConstructionObservationBundleV1& value) {
  Json result = Json::object();
  result["schema_version"] = value.schema_version;
  result["source_role"] = std::string(encode_source_role(value.source_role));
  result["scalar_representation"] =
      std::string(encode_scalar_representation(value.scalar_representation));
  result["bindings"] = encode_bindings(value.bindings);
  result["slot_convention"] = encode_slot_convention(value.slot_convention);
  result["initialization"] = encode_initialization(value.initialization);
  result["rng"] = encode_rng(value.rng);
  result["warmup_boundary"] = value.warmup_boundary;
  result["end_boundary"] = value.end_boundary;
  result["reporting_block_boundaries"] = encode_array(
      value.reporting_block_boundaries,
      [](const std::uint64_t boundary) { return Json(boundary); });
  result["capabilities"] = encode_capabilities(value.capabilities);
  result["replications"] =
      encode_array(value.replications, encode_replication);
  return result;
}

[[nodiscard]] ConstructionObservationBundleV1 decode_bundle_body(
    const Json& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  require_object_shape(
      value, path,
      {"schema_version", "source_role", "scalar_representation", "bindings",
       "slot_convention", "initialization", "rng", "warmup_boundary",
       "end_boundary", "reporting_block_boundaries", "capabilities",
       "replications"});
  return ConstructionObservationBundleV1{
      decode_u32(required_member(value, "schema_version", path),
                 child_pointer(path, "schema_version")),
      decode_source_role(required_member(value, "source_role", path),
                         child_pointer(path, "source_role")),
      decode_scalar_representation(
          required_member(value, "scalar_representation", path),
          child_pointer(path, "scalar_representation")),
      decode_bindings(required_member(value, "bindings", path),
                      child_pointer(path, "bindings"), limits),
      decode_slot_convention(required_member(value, "slot_convention", path),
                             child_pointer(path, "slot_convention")),
      decode_initialization(required_member(value, "initialization", path),
                            child_pointer(path, "initialization")),
      decode_rng(required_member(value, "rng", path),
                 child_pointer(path, "rng")),
      decode_u64(required_member(value, "warmup_boundary", path),
                 child_pointer(path, "warmup_boundary")),
      decode_u64(required_member(value, "end_boundary", path),
                 child_pointer(path, "end_boundary")),
      decode_array<std::uint64_t>(
          required_member(value, "reporting_block_boundaries", path),
          child_pointer(path, "reporting_block_boundaries"),
          limits.maximum_reporting_boundaries,
          [](const Json& boundary, const std::string& boundary_path) {
            return decode_u64(boundary, boundary_path);
          },
          "observation_parse_reporting_boundary_limit"),
      decode_capabilities(required_member(value, "capabilities", path),
                          child_pointer(path, "capabilities")),
      decode_array<ConstructionObservationReplicationV1>(
          required_member(value, "replications", path),
          child_pointer(path, "replications"), limits.maximum_replications,
          [&](const Json& replication, const std::string& replication_path) {
            return decode_replication(replication, replication_path, limits);
          },
          "observation_parse_replication_limit")};
}

[[nodiscard]] Json encode_envelope(
    const ConstructionObservationEnvelopeV1& value) {
  Json result = Json::object();
  result["observation_bundle"] = encode_bundle_body(value.observation_bundle);
  result["observation_bundle_digest"] =
      encode_digest(value.observation_bundle_digest);
  return result;
}

[[nodiscard]] ConstructionObservationEnvelopeV1 decode_envelope(
    const Json& value, const ObservationParseLimitsV1& limits) {
  require_object_shape(value, "",
                       {"observation_bundle", "observation_bundle_digest"});
  return ConstructionObservationEnvelopeV1{
      decode_bundle_body(required_member(value, "observation_bundle", ""),
                         "/observation_bundle", limits),
      decode_digest(required_member(value, "observation_bundle_digest", ""),
                    "/observation_bundle_digest")};
}

[[nodiscard]] Result<std::vector<std::byte>> json_bytes(
    const Json& value, const std::string_view subject) {
  try {
    const std::string encoded =
        value.dump(-1, ' ', false, Json::error_handler_t::strict);
    std::vector<std::byte> bytes;
    bytes.reserve(encoded.size());
    for (const char character : encoded) {
      bytes.push_back(
          static_cast<std::byte>(static_cast<unsigned char>(character)));
    }
    return Result<std::vector<std::byte>>::success(std::move(bytes));
  } catch (const std::bad_alloc&) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "observation_wire_encode_allocation_failure",
        "allocation failed while encoding the canonical " +
            std::string(subject));
  } catch (const std::length_error&) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "observation_wire_encode_length_failure",
        "the canonical " + std::string(subject) +
            " exceeded the container size range");
  } catch (const nlohmann::json::exception& error) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation,
        "observation_wire_encode_json",
        "the canonical " + std::string(subject) +
            " could not be encoded: " + error.what());
  } catch (const std::exception& error) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal, "observation_wire_encode_exception",
        "unexpected exception while encoding the canonical " +
            std::string(subject) + ": " + error.what());
  } catch (...) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal,
        "observation_wire_encode_unknown_exception",
        "unknown exception while encoding the canonical " +
            std::string(subject));
  }
}

template <typename Encoder>
[[nodiscard]] Result<std::vector<std::byte>> guarded_json_bytes(
    Encoder&& encoder, const std::string_view subject) {
  try {
    return json_bytes(encoder(), subject);
  } catch (const std::bad_alloc&) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "observation_wire_encode_allocation_failure",
        "allocation failed while constructing the canonical " +
            std::string(subject));
  } catch (const std::length_error&) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::resource_limit,
        "observation_wire_encode_length_failure",
        "the canonical " + std::string(subject) +
            " exceeded the container size range");
  } catch (const std::invalid_argument& error) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::input_validation,
        "observation_wire_encode_invalid_value",
        std::string("the observation value is not encodable: ") +
            error.what());
  } catch (const std::exception& error) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal, "observation_wire_encode_exception",
        std::string("unexpected observation encoder exception: ") +
            error.what());
  } catch (...) {
    return wire_failure<std::vector<std::byte>>(
        DiagnosticCategory::internal,
        "observation_wire_encode_unknown_exception",
        "unknown exception while constructing canonical observation JSON");
  }
}

}  // namespace

ObservationParseLimitsV1 default_observation_parse_limits_v1() noexcept {
  return ObservationParseLimitsV1{
      kNonScientificByteCeiling,               // maximum_bytes
      32U,                                    // maximum_nesting_depth
      std::numeric_limits<std::size_t>::max(), // maximum_object_entries
      std::numeric_limits<std::size_t>::max(), // maximum_array_entries
      kNonScientificByteCeiling,               // maximum_string_bytes
      std::numeric_limits<std::size_t>::max(), // maximum_scalar_count
      kNonScientificByteCeiling,               // decoded allocation bytes
      std::numeric_limits<std::size_t>::max(), // maximum_replications
      std::numeric_limits<std::size_t>::max(), // maximum_total_blocks
      std::numeric_limits<std::size_t>::max(), // maximum_total_level_rows
      std::numeric_limits<std::size_t>::max(), // maximum_total_boundary_rows
      std::numeric_limits<std::size_t>::max(), // maximum_arrival_atoms
      std::numeric_limits<std::size_t>::max(), // reporting boundaries
      std::numeric_limits<std::size_t>::max(), // maximum_integer_bits
      std::numeric_limits<std::size_t>::max(), // integer decimal digits
  };
}

Result<std::vector<std::byte>>
canonical_construction_observation_bundle_body_bytes_v1(
    const ConstructionObservationBundleV1& bundle) {
  return guarded_json_bytes([&] { return encode_bundle_body(bundle); },
                            "observation-v1 bundle body");
}

Result<Digest256> construction_observation_bundle_digest_v1(
    const ConstructionObservationBundleV1& bundle) {
  Result<std::vector<std::byte>> bytes =
      canonical_construction_observation_bundle_body_bytes_v1(bundle);
  if (!bytes) {
    return Result<Digest256>::failure(bytes.error());
  }
  return sha256_domain_separated(kObservationDigestDomain, bytes.value());
}

Result<Digest256> registered_empty_backlog_initial_law_digest_v1() {
  constexpr std::string_view kPreimage = "empty_backlog";
  return sha256_domain_separated(
      "mwperf.construction_observation.initial_law.v1",
      std::as_bytes(std::span(kPreimage.data(), kPreimage.size())));
}

Result<std::vector<std::byte>>
canonical_construction_observation_envelope_bytes_v1(
    const ConstructionObservationEnvelopeV1& envelope) {
  return guarded_json_bytes([&] { return encode_envelope(envelope); },
                            "observation-v1 envelope");
}

Result<ConstructionObservationEnvelopeV1>
parse_construction_observation_envelope_v1(
    const ObservationByteSpan bytes, const ObservationParseLimitsV1& limits) {
  try {
    if (bytes.size() > limits.maximum_bytes) {
      return wire_failure<ConstructionObservationEnvelopeV1>(
          DiagnosticCategory::resource_limit,
          "observation_parse_input_bytes_limit",
          "the observation envelope exceeds the configured byte cap");
    }
    if (bytes.empty()) {
      return wire_failure<ConstructionObservationEnvelopeV1>(
          DiagnosticCategory::input_validation,
          "observation_parse_empty_input",
          "the observation envelope is empty");
    }
    if (bytes.size() >= 3U &&
        std::to_integer<unsigned char>(bytes[0]) == 0xefU &&
        std::to_integer<unsigned char>(bytes[1]) == 0xbbU &&
        std::to_integer<unsigned char>(bytes[2]) == 0xbfU) {
      return wire_failure<ConstructionObservationEnvelopeV1>(
          DiagnosticCategory::input_validation,
          "observation_parse_utf8_bom_forbidden",
          "canonical observation-v1 JSON must not begin with a UTF-8 BOM");
    }
    if (first_invalid_utf8(bytes).has_value()) {
      return wire_failure<ConstructionObservationEnvelopeV1>(
          DiagnosticCategory::input_validation,
          "observation_parse_invalid_utf8",
          "the observation envelope is not valid canonical UTF-8");
    }

    const char* const begin = reinterpret_cast<const char*>(bytes.data());
    const char* const end = begin + bytes.size();
    ObservationSaxPreflight preflight(limits);
    if (!Json::sax_parse(begin, end, &preflight, Json::input_format_t::json,
                        true)) {
      if (preflight.diagnostic().has_value()) {
        return Result<ConstructionObservationEnvelopeV1>::failure(
            *preflight.diagnostic());
      }
      return wire_failure<ConstructionObservationEnvelopeV1>(
          DiagnosticCategory::input_validation,
          "observation_parse_invalid_json",
          "the observation envelope is not strict closed JSON");
    }

    const Json document = Json::parse(begin, end, nullptr, true, false);
    ConstructionObservationEnvelopeV1 decoded =
        decode_envelope(document, limits);
    Result<std::vector<std::byte>> canonical =
        canonical_construction_observation_envelope_bytes_v1(decoded);
    if (!canonical) {
      return Result<ConstructionObservationEnvelopeV1>::failure(
          canonical.error());
    }
    if (canonical.value().size() != bytes.size() ||
        !std::equal(canonical.value().begin(), canonical.value().end(),
                    bytes.begin())) {
      return wire_failure<ConstructionObservationEnvelopeV1>(
          DiagnosticCategory::input_validation,
          "observation_parse_noncanonical_json",
          "the observation envelope is valid JSON but not the exact "
          "canonical observation-v1 encoding");
    }
    return Result<ConstructionObservationEnvelopeV1>::success(
        std::move(decoded));
  } catch (const DecodeError& error) {
    return Result<ConstructionObservationEnvelopeV1>::failure(
        error.diagnostic());
  } catch (const std::bad_alloc&) {
    return wire_failure<ConstructionObservationEnvelopeV1>(
        DiagnosticCategory::resource_limit,
        "observation_parse_allocation_failure",
        "allocation failed while parsing the bounded observation envelope");
  } catch (const std::length_error&) {
    return wire_failure<ConstructionObservationEnvelopeV1>(
        DiagnosticCategory::resource_limit,
        "observation_parse_length_failure",
        "an observation-v1 container exceeded its size range");
  } catch (const nlohmann::json::exception& error) {
    return wire_failure<ConstructionObservationEnvelopeV1>(
        DiagnosticCategory::input_validation,
        "observation_parse_json_exception",
        std::string("invalid closed observation-v1 JSON: ") + error.what());
  } catch (const std::exception& error) {
    return wire_failure<ConstructionObservationEnvelopeV1>(
        DiagnosticCategory::internal, "observation_parse_exception",
        std::string("unexpected observation parser exception: ") +
            error.what());
  } catch (...) {
    return wire_failure<ConstructionObservationEnvelopeV1>(
        DiagnosticCategory::internal,
        "observation_parse_unknown_exception",
        "unknown exception while parsing the observation envelope");
  }
}

}  // namespace mwperf
