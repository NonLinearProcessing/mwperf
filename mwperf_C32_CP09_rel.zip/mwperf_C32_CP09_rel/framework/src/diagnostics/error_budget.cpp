#include "mwperf/diagnostics/error_budget.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <set>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic(std::string code, std::string message,
                                    DiagnosticCategory category =
                                        DiagnosticCategory::input_validation) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::nullopt, {}};
}

[[nodiscard]] bool nonzero(const Digest256& digest) noexcept {
  return std::any_of(digest.bytes().begin(), digest.bytes().end(),
                     [](const std::byte value) {
                       return value != std::byte{0};
                     });
}

[[nodiscard]] bool valid_reference(
    const ArtifactObjectReferenceV1& reference) noexcept {
  return nonzero(reference.object_digest);
}

[[nodiscard]] Result<void> canonicalize_declared_references(
    std::vector<ArtifactObjectReferenceV1>& references,
    const std::string_view empty_code, const std::string_view duplicate_code,
    const std::string_view description, const bool require_nonempty) {
  if ((require_nonempty && references.empty()) ||
      std::any_of(references.begin(), references.end(),
                  [](const auto& reference) {
                    return !valid_reference(reference);
                  })) {
    return Result<void>::failure(diagnostic(
        std::string(empty_code),
        std::string("a triangle declaration requires valid ") +
            std::string(description)));
  }
  std::sort(references.begin(), references.end());
  if (std::adjacent_find(references.begin(), references.end()) !=
      references.end()) {
    return Result<void>::failure(diagnostic(
        std::string(duplicate_code),
        std::string("a triangle declaration repeats ") +
            std::string(description)));
  }
  return Result<void>::success();
}

[[nodiscard]] bool finite(const long double value) noexcept {
  return std::isfinite(value);
}

[[nodiscard]] Result<void> validate_response_context(
    const ResponseIdentityContextV1& context) {
  if (context.provider.provider_id.empty() ||
      context.provider.provider_version.empty()) {
    return Result<void>::failure(diagnostic(
        "c25.product_provider_missing",
        "a response product identity requires provider id and version"));
  }
  if (!valid_reference(context.artifact_identity) ||
      !valid_reference(context.payload_identity) ||
      !nonzero(context.build_identity) || !nonzero(context.request_identity) ||
      (context.phase_identity && !nonzero(*context.phase_identity))) {
    return Result<void>::failure(diagnostic(
        "c25.product_identity_incomplete",
        "a response product identity has an empty artifact, payload, build, "
        "request, or phase fingerprint"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_mean_context(
    const MeanIdentityContextV1& context) {
  if (context.provider.provider_id.empty() ||
      context.provider.provider_version.empty()) {
    return Result<void>::failure(diagnostic(
        "c25.product_provider_missing",
        "a mean-stage product identity requires provider id and version"));
  }
  if (!valid_reference(context.artifact_identity) ||
      !valid_reference(context.payload_identity) ||
      !nonzero(context.build_identity) || !nonzero(context.request_identity) ||
      (context.phase_identity && !nonzero(*context.phase_identity))) {
    return Result<void>::failure(diagnostic(
        "c25.product_identity_incomplete",
        "a mean-stage product identity has an empty artifact, payload, build, "
        "request, or phase fingerprint"));
  }
  if (context.ordered_construction_targets.empty()) {
    return Result<void>::failure(diagnostic(
        "c25.product_targets_missing",
        "a mean-stage product identity requires its ordered target vector"));
  }
  for (std::size_t left = 0; left < context.ordered_construction_targets.size();
       ++left) {
    for (std::size_t right = left + 1U;
         right < context.ordered_construction_targets.size(); ++right) {
      if (context.ordered_construction_targets[left] ==
          context.ordered_construction_targets[right]) {
        return Result<void>::failure(diagnostic(
            "c25.product_target_duplicate",
            "a mean-stage ordered target vector contains a duplicate"));
      }
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_value(
    const DiagnosticValueIntervalV1& value) {
  if (value.lower && !finite(*value.lower)) {
    return Result<void>::failure(diagnostic(
        "c25.component_value_nonfinite",
        "a diagnostic interval lower endpoint must be finite when present"));
  }
  if (value.upper && !finite(*value.upper)) {
    return Result<void>::failure(diagnostic(
        "c25.component_value_nonfinite",
        "a diagnostic interval upper endpoint must be finite when present"));
  }
  if ((value.lower && *value.lower < 0.0L) ||
      (value.upper && *value.upper < 0.0L)) {
    return Result<void>::failure(diagnostic(
        "c25.component_value_negative",
        "error-budget interval endpoints must be nonnegative"));
  }
  if (value.lower && value.upper && *value.lower > *value.upper) {
    return Result<void>::failure(diagnostic(
        "c25.component_interval_reversed",
        "a diagnostic interval lower endpoint exceeds its upper endpoint"));
  }

  if (value.claim_state == CertificateClaimStateV1::established) {
    if (value.value_status == BoundValueStatusV1::finite &&
        (!value.lower || !value.upper)) {
      return Result<void>::failure(diagnostic(
          "c25.component_finite_endpoints_missing",
          "an established finite error component requires both endpoints"));
    }
    if (value.value_status == BoundValueStatusV1::infinite && value.upper) {
      return Result<void>::failure(diagnostic(
          "c25.component_infinite_upper_present",
          "an infinite error component must expose an unbounded upper side"));
    }
    if (value.value_status == BoundValueStatusV1::unresolved) {
      return Result<void>::failure(diagnostic(
          "c25.component_established_unresolved",
          "an established component cannot have unresolved numerical status"));
    }
    return Result<void>::success();
  }

  if (value.value_status != BoundValueStatusV1::unresolved || value.lower ||
      value.upper) {
    return Result<void>::failure(diagnostic(
        "c25.component_unproved_numeric",
        "a refuted or not-established component cannot carry a numerical "
        "error bound"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_geometry(const MetricGeometry& geometry) {
  return std::visit(
      [](const auto& value) -> Result<void> {
        if (!nonzero(value.geometry_identity) ||
            !nonzero(value.state_space_identity)) {
          return Result<void>::failure(diagnostic(
              "c25.geometry_identity_missing",
              "a diagnostic geometry requires nonzero geometry and state "
              "identities"));
        }
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, TotalVariationGeometryV1>) {
          if (!nonzero(value.observable_identity) ||
              value.reward_lower.has_value() != value.reward_upper.has_value() ||
              (value.reward_lower &&
               (!finite(*value.reward_lower) || !finite(*value.reward_upper) ||
                *value.reward_lower > *value.reward_upper))) {
            return Result<void>::failure(diagnostic(
                "c25.tv_geometry_invalid",
                "TV geometry requires an observable identity and either no "
                "reward range or one finite ordered range"));
          }
        } else if constexpr (std::is_same_v<T, WassersteinGeometryV1>) {
          if (!nonzero(value.metric_identity) ||
              (value.reward_lipschitz_modulus &&
               (!finite(*value.reward_lipschitz_modulus) ||
                *value.reward_lipschitz_modulus < 0.0L))) {
            return Result<void>::failure(diagnostic(
                "c25.wasserstein_geometry_invalid",
                "Wasserstein geometry requires a metric identity and a "
                "finite nonnegative reward modulus when supplied"));
          }
        } else if constexpr (std::is_same_v<T, WeightedGeometryV1>) {
          if (!nonzero(value.norm_identity) ||
              (value.reward_dual_modulus &&
               (!finite(*value.reward_dual_modulus) ||
                *value.reward_dual_modulus < 0.0L))) {
            return Result<void>::failure(diagnostic(
                "c25.weighted_geometry_invalid",
                "weighted geometry requires a norm identity and finite "
                "nonnegative dual modulus when supplied"));
          }
        } else {
          if (!nonzero(value.norm_identity) || value.weights.empty() ||
              std::any_of(value.weights.begin(), value.weights.end(),
                          [](const ExactRational& weight) {
                            return !weight.is_positive();
                          })) {
            return Result<void>::failure(diagnostic(
                "c25.operator_geometry_invalid",
                "operator geometry requires a norm identity and strictly "
                "positive weights"));
          }
        }
        return Result<void>::success();
      },
      geometry.value);
}

[[nodiscard]] const ArtifactObjectReferenceV1& product_reference(
    const ProductIdentityV1& identity) noexcept {
  return std::visit(
      [](const auto& value) -> const ArtifactObjectReferenceV1& {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, DeployedLawProductIdentityV1>) {
          return deployed_response_product_subject_v1(
              value.law.deployed_product());
        } else {
          return value.product.identity();
        }
      },
      identity);
}

[[nodiscard]] Result<void> validate_product(const ProductIdentityV1& product) {
  return std::visit(
      [](const auto& value) -> Result<void> {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, RawResponseCoefficientIdentityV1> ||
                      std::is_same_v<T,
                                     NominalResponseCoefficientIdentityV1> ||
                      std::is_same_v<
                          T, RecodedResponseCoefficientIdentityV1>) {
          if (auto valid = validate_response_context(value.context); !valid) {
            return valid;
          }
          if (!valid_reference(value.product.identity())) {
            return Result<void>::failure(diagnostic(
                "c25.product_reference_missing",
                "a response coefficient product reference is empty"));
          }
          if constexpr (std::is_same_v<
                            T, RawResponseCoefficientIdentityV1>) {
            if (value.value_form !=
                    ResponseProductValueFormV1::exact_point &&
                value.value_form !=
                    ResponseProductValueFormV1::interval_only) {
              return Result<void>::failure(diagnostic(
                  "c25.raw_response_value_form_invalid",
                  "a raw response identity has an unknown value-form tag"));
            }
          }
        } else if constexpr (std::is_same_v<T, ProjectionCenterIdentityV1> ||
                             std::is_same_v<T, ProjectedMeanIdentityV1>) {
          if (auto valid = validate_mean_context(value.context); !valid) {
            return valid;
          }
          if (!valid_reference(value.product.identity())) {
            return Result<void>::failure(diagnostic(
                "c25.product_reference_missing",
                "a mean-stage product reference is empty"));
          }
        } else {
          if (auto valid = validate_response_context(
                  value.law.response_context());
              !valid) {
            return valid;
          }
          if (!valid_reference(deployed_response_product_subject_v1(
                  value.law.deployed_product()))) {
            return Result<void>::failure(diagnostic(
                "c25.product_reference_missing",
                "a deployed law product reference is empty"));
          }
        }
        return Result<void>::success();
      },
      product);
}

[[nodiscard]] bool common_binding(const ResponseIdentityContextV1& response,
                                  const MeanIdentityContextV1& mean) noexcept {
  if (response.provider != mean.provider ||
      response.artifact_identity != mean.artifact_identity ||
      response.payload_identity != mean.payload_identity ||
      response.build_identity != mean.build_identity ||
      response.request_identity != mean.request_identity ||
      response.phase_identity != mean.phase_identity ||
      response.frozen_input_bank_id != mean.frozen_input_bank_id ||
      response.final_probe_id != mean.final_probe_id) {
    return false;
  }
  return std::find(mean.ordered_construction_targets.begin(),
                   mean.ordered_construction_targets.end(),
                   response.response_target) !=
         mean.ordered_construction_targets.end();
}

template <typename ResponseIdentity>
[[nodiscard]] Result<void> validate_three_bins(
    const std::vector<ResponseIdentity>& identities) {
  if (identities.size() != 3U) {
    return Result<void>::failure(diagnostic(
        "c25.bridge_bin_coverage",
        "a response/mean bridge must name exactly the three response bins"));
  }
  std::array<bool, 3U> seen{false, false, false};
  for (const auto& identity : identities) {
    if (auto valid = validate_product(ProductIdentityV1(identity)); !valid) {
      return valid;
    }
    const auto index = static_cast<std::size_t>(identity.bin);
    if (index >= seen.size() || seen[index]) {
      return Result<void>::failure(diagnostic(
          "c25.bridge_bin_duplicate",
          "a response/mean bridge repeats or mislabels a response bin"));
    }
    seen[index] = true;
  }
  for (std::size_t index = 1U; index < identities.size(); ++index) {
    if (identities[index].context != identities[0].context ||
        identities[index].product != identities[0].product ||
        [&]() {
          if constexpr (std::is_same_v<
                            ResponseIdentity,
                            RawResponseCoefficientIdentityV1>) {
            return identities[index].value_form != identities[0].value_form;
          }
          return false;
        }()) {
      return Result<void>::failure(diagnostic(
          "c25.bridge_mixed_response_product",
          "a response/mean bridge mixes product, value-form, or context "
          "identities"));
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_bridge_common(
    const ArtifactObjectReferenceV1& evidence, std::string_view theorem,
    const std::vector<std::string>& assumptions,
    const std::vector<DiagnosticValueIntervalV1>& intervals) {
  if (!valid_reference(evidence) || theorem.empty() || intervals.empty()) {
    return Result<void>::failure(diagnostic(
        "c25.bridge_evidence_incomplete",
        "a product bridge requires evidence, a theorem/map, and resulting "
        "intervals"));
  }
  if (std::any_of(assumptions.begin(), assumptions.end(),
                  [](const std::string& value) { return value.empty(); })) {
    return Result<void>::failure(diagnostic(
        "c25.bridge_empty_assumption",
        "a product bridge contains an empty assumption"));
  }
  for (const auto& interval : intervals) {
    if (auto valid = validate_value(interval); !valid) {
      return valid;
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_bridge(const ProductBridgeV1& bridge) {
  return std::visit(
      [](const auto& value) -> Result<void> {
        if (auto common = validate_bridge_common(
                value.evidence_identity, value.theorem_or_map,
                value.assumptions, value.resulting_intervals);
            !common) {
          return common;
        }
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T,
                                     ResponseToProjectionCenterBridgeV1>) {
          if (auto valid =
                  validate_product(ProductIdentityV1(value.destination));
              !valid) {
            return valid;
          }
          if (value.resulting_intervals.size() !=
              value.destination.context.ordered_construction_targets.size()) {
            return Result<void>::failure(diagnostic(
                "c25.bridge_result_dimension",
                "a response-to-center bridge result does not match the "
                "ordered mean-vector dimension"));
          }
          return std::visit(
              [&value](const auto& sources) -> Result<void> {
                if (auto valid = validate_three_bins(sources); !valid) {
                  return valid;
                }
                if (!common_binding(sources.front().context,
                                    value.destination.context)) {
                  return Result<void>::failure(diagnostic(
                      "c25.bridge_cross_fingerprint",
                      "a response-to-center bridge crosses artifact, build, "
                      "request, phase, run, or target identities"));
                }
                return Result<void>::success();
              },
              value.sources);
        } else if constexpr (
            std::is_same_v<T, ProjectionCenterToProjectedMeanBridgeV1>) {
          if (auto valid = validate_product(ProductIdentityV1(value.source));
              !valid) {
            return valid;
          }
          if (auto valid =
                  validate_product(ProductIdentityV1(value.destination));
              !valid) {
            return valid;
          }
          if (value.source.context != value.destination.context) {
            return Result<void>::failure(diagnostic(
                "c25.bridge_cross_fingerprint",
                "a center-to-projected-mean bridge crosses its exact context"));
          }
          if (value.resulting_intervals.size() !=
              value.destination.context.ordered_construction_targets.size()) {
            return Result<void>::failure(diagnostic(
                "c25.bridge_result_dimension",
                "a center-to-projected-mean bridge result has the wrong "
                "vector dimension"));
          }
          return Result<void>::success();
        } else {
          if (auto valid = validate_product(ProductIdentityV1(value.source));
              !valid) {
            return valid;
          }
          if (auto valid = validate_three_bins(value.destinations); !valid) {
            return valid;
          }
          if (!common_binding(value.destinations.front().context,
                              value.source.context)) {
            return Result<void>::failure(diagnostic(
                "c25.bridge_cross_fingerprint",
                "a projected-mean-to-recoded bridge crosses artifact, build, "
                "request, phase, run, or target identities"));
          }
          if (value.resulting_intervals.size() != 3U) {
            return Result<void>::failure(diagnostic(
                "c25.bridge_result_dimension",
                "a mean-to-recoded bridge must return exactly three "
                "coefficient intervals"));
          }
          return Result<void>::success();
        }
      },
      bridge);
}

[[nodiscard]] bool bridge_attaches(
    const ProductBridgeV1& bridge, const ProductIdentityV1& source,
    const ProductIdentityV1& destination) noexcept {
  return std::visit(
      [&source, &destination](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T,
                                     ResponseToProjectionCenterBridgeV1>) {
          const auto* target =
              std::get_if<ProjectionCenterIdentityV1>(&destination);
          if (target == nullptr || *target != value.destination) {
            return false;
          }
          return std::visit(
              [&source](const auto& sources) {
                using I = typename std::decay_t<decltype(sources)>::value_type;
                const auto* candidate = std::get_if<I>(&source);
                return candidate != nullptr &&
                       std::find(sources.begin(), sources.end(), *candidate) !=
                           sources.end();
              },
              value.sources);
        } else if constexpr (
            std::is_same_v<T, ProjectionCenterToProjectedMeanBridgeV1>) {
          const auto* from = std::get_if<ProjectionCenterIdentityV1>(&source);
          const auto* to = std::get_if<ProjectedMeanIdentityV1>(&destination);
          return from != nullptr && to != nullptr && *from == value.source &&
                 *to == value.destination;
        } else {
          const auto* from = std::get_if<ProjectedMeanIdentityV1>(&source);
          const auto* to =
              std::get_if<RecodedResponseCoefficientIdentityV1>(&destination);
          return from != nullptr && to != nullptr && *from == value.source &&
                 std::find(value.destinations.begin(), value.destinations.end(),
                           *to) != value.destinations.end();
        }
      },
      bridge);
}

[[nodiscard]] bool bridge_has_owning_scope(
    const ProductBridgeV1& bridge, const ComponentScopeV1 scope) noexcept {
  return std::visit(
      [scope](const auto& value) noexcept {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T,
                                     ResponseToProjectionCenterBridgeV1>) {
          return scope == ComponentScopeV1::coefficient_sampling ||
                 scope == ComponentScopeV1::compression;
        } else if constexpr (
            std::is_same_v<T, ProjectionCenterToProjectedMeanBridgeV1>) {
          return scope == ComponentScopeV1::projection;
        } else {
          return scope == ComponentScopeV1::recode;
        }
      },
      bridge);
}

[[nodiscard]] const LawIdentityV1* deployed_law(
    const ProductIdentityV1& product) noexcept {
  const auto* deployed =
      std::get_if<DeployedLawProductIdentityV1>(&product);
  return deployed == nullptr ? nullptr : &deployed->law;
}

[[nodiscard]] std::string product_sort_key(const ProductIdentityV1& product) {
  std::string key = std::to_string(static_cast<unsigned>(product_kind_v1(product)));
  key.push_back(':');
  key += product_reference(product).object_digest.hex();
  key.push_back(':');
  key += std::visit(
      [](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, DeployedLawProductIdentityV1>) {
          return value.law.response_context().artifact_identity.object_digest
                     .hex() +
                 value.law.configured_arrival_law().hex() +
                 value.law.execution_identity().hex() +
                 value.law.metric_target_identity().hex();
        } else {
          return value.context.artifact_identity.object_digest.hex() +
                 value.context.payload_identity.object_digest.hex() +
                 value.context.build_identity.hex() +
                 value.context.request_identity.hex();
        }
      },
      product);
  return key;
}

[[nodiscard]] std::string component_sort_key(
    const DiagnosticComponent& component) {
  std::string key =
      component.component_identity().object_id.stable_hash() == 0U
          ? std::string("0")
          : std::to_string(
                component.component_identity().object_id.stable_hash());
  key += component.component_identity().object_digest.hex();
  key += std::to_string(static_cast<unsigned>(component.scope()));
  key += product_sort_key(component.source_product());
  if (component.destination_product()) {
    key += product_sort_key(*component.destination_product());
  }
  key += component.metric();
  key += component.provenance_identity().object_digest.hex();
  key += component.theorem_or_method();
  for (const auto& evidence : component.evidence_references()) {
    key += evidence.object_digest.hex();
  }
  for (const auto& assumption : component.assumptions()) {
    key += assumption;
    key.push_back('\0');
  }
  if (component.value().lower) {
    key += std::to_string(*component.value().lower);
  }
  if (component.value().upper) {
    key += std::to_string(*component.value().upper);
  }
  return key;
}

[[nodiscard]] bool same_deployed_product(
    const RawResponseCoefficientIdentityV1& product,
    const LawIdentityV1& law) noexcept {
  const auto* selected =
      std::get_if<RawResponseProductRef>(&law.deployed_product());
  return selected != nullptr && product.value_form ==
                                    ResponseProductValueFormV1::exact_point &&
         selected->value_form == ResponseProductValueFormV1::exact_point &&
         product.context == law.response_context() &&
         product.product.identity() == selected->identity;
}

[[nodiscard]] bool same_deployed_product(
    const NominalResponseCoefficientIdentityV1& product,
    const LawIdentityV1& law) noexcept {
  const auto* selected =
      std::get_if<NominalResponseProductRef>(&law.deployed_product());
  return selected != nullptr && product.context == law.response_context() &&
         product.product.identity() == selected->identity;
}

[[nodiscard]] bool same_deployed_product(
    const RecodedResponseCoefficientIdentityV1& product,
    const LawIdentityV1& law) noexcept {
  const auto* selected =
      std::get_if<RecodedResponseProductRef>(&law.deployed_product());
  return selected != nullptr && product.context == law.response_context() &&
         product.product.identity() == selected->identity;
}

[[nodiscard]] bool established_finite(
    const DiagnosticValueIntervalV1& value) noexcept {
  return value.claim_state == CertificateClaimStateV1::established &&
         value.value_status == BoundValueStatusV1::finite &&
         value.lower.has_value() && value.upper.has_value();
}

[[nodiscard]] bool bridge_results_established_finite(
    const ProductBridgeV1& bridge) noexcept {
  return std::visit(
      [](const auto& value) {
        return std::all_of(value.resulting_intervals.begin(),
                           value.resulting_intervals.end(),
                           established_finite);
      },
      bridge);
}

[[nodiscard]] std::vector<const ProductBridgeV1*> collect_bridges(
    const std::vector<const DiagnosticComponent*>& components) {
  std::vector<const ProductBridgeV1*> bridges;
  for (const auto* component : components) {
    if (component->bridge() && established_finite(component->value()) &&
        bridge_results_established_finite(*component->bridge())) {
      bridges.push_back(&*component->bridge());
    }
  }
  return bridges;
}

template <typename Identity>
[[nodiscard]] bool response_to_center(
    const Identity& identity, const ProjectionCenterIdentityV1& center,
    const std::vector<const ProductBridgeV1*>& bridges) {
  for (const auto* bridge : bridges) {
    const auto* typed =
        std::get_if<ResponseToProjectionCenterBridgeV1>(bridge);
    if (typed == nullptr || typed->destination != center) {
      continue;
    }
    const auto* sources =
        std::get_if<std::vector<Identity>>(&typed->sources);
    if (sources != nullptr &&
        std::find(sources->begin(), sources->end(), identity) !=
            sources->end()) {
      return true;
    }
  }
  return false;
}

[[nodiscard]] bool reaches_law(
    const ProductIdentityV1& product, const LawIdentityV1& law,
    const std::vector<const ProductBridgeV1*>& bridges) {
  return std::visit(
      [&](const auto& value) -> bool {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, DeployedLawProductIdentityV1>) {
          return value.law == law;
        } else if constexpr (
            std::is_same_v<T, RecodedResponseCoefficientIdentityV1>) {
          return same_deployed_product(value, law);
        } else if constexpr (
            std::is_same_v<T, ProjectedMeanIdentityV1>) {
          if (!std::holds_alternative<RecodedResponseProductRef>(
                  law.deployed_product())) {
            return false;
          }
          for (const auto* bridge : bridges) {
            const auto* typed =
                std::get_if<ProjectedMeanToRecodedResponseBridgeV1>(bridge);
            if (typed != nullptr && typed->source == value &&
                std::any_of(typed->destinations.begin(),
                            typed->destinations.end(), [&](const auto& output) {
                              return same_deployed_product(output, law);
                            })) {
              return true;
            }
          }
          return false;
        } else if constexpr (
            std::is_same_v<T, ProjectionCenterIdentityV1>) {
          for (const auto* bridge : bridges) {
            const auto* typed =
                std::get_if<ProjectionCenterToProjectedMeanBridgeV1>(bridge);
            if (typed != nullptr && typed->source == value &&
                reaches_law(ProductIdentityV1(typed->destination), law,
                            bridges)) {
              return true;
            }
          }
          return false;
        } else {
          if (same_deployed_product(value, law)) {
            return true;
          }
          for (const auto* bridge : bridges) {
            const auto* typed =
                std::get_if<ResponseToProjectionCenterBridgeV1>(bridge);
            if (typed == nullptr ||
                !response_to_center(value, typed->destination, bridges)) {
              continue;
            }
            if (reaches_law(ProductIdentityV1(typed->destination), law,
                            bridges)) {
              return true;
            }
          }
          return false;
        }
      },
      product);
}

[[nodiscard]] ArtifactObjectReferenceV1 bridge_evidence(
    const ProductBridgeV1& bridge) {
  return std::visit(
      [](const auto& value) { return value.evidence_identity; }, bridge);
}

struct TotalGroup final {
  TriangleContributionV1 declaration;
  std::vector<const DiagnosticComponent*> components;
  bool declaration_conflict{false};
  bool duplicate_component{false};
};

[[nodiscard]] BudgetConclusionV1 unavailable_conclusion() {
  return BudgetConclusionV1{CertificateClaimStateV1::not_established,
                            BoundValueStatusV1::unresolved, std::nullopt,
                            std::nullopt};
}

}  // namespace

LawIdentityV1::LawIdentityV1(LawIdentitySpecV1 spec)
    : spec_(std::move(spec)) {}

Result<LawIdentityV1> LawIdentityV1::make(LawIdentitySpecV1 spec) {
  if (auto valid = validate_response_context(spec.response); !valid) {
    return Result<LawIdentityV1>::failure(valid.error());
  }
  if (!valid_reference(
          deployed_response_product_subject_v1(spec.deployed_product)) ||
      !nonzero(spec.configured_arrival_law) ||
      !nonzero(spec.execution_identity) ||
      !nonzero(spec.metric_target_identity)) {
    return Result<LawIdentityV1>::failure(diagnostic(
        "c25.law_identity_incomplete",
        "a deployed law identity requires product, arrival, execution, and "
        "metric fingerprints"));
  }
  if (!is_point_valued_deployed_response_product_v1(
          spec.deployed_product)) {
    return Result<LawIdentityV1>::failure(diagnostic(
        "c25.interval_raw_not_deployable",
        "an interval-only response product cannot identify a deployed law"));
  }
  return Result<LawIdentityV1>::success(LawIdentityV1(std::move(spec)));
}

const ResponseIdentityContextV1& LawIdentityV1::response_context()
    const noexcept {
  return spec_.response;
}

const DeployedResponseProductReferenceV1& LawIdentityV1::deployed_product()
    const noexcept {
  return spec_.deployed_product;
}

const Digest256& LawIdentityV1::configured_arrival_law() const noexcept {
  return spec_.configured_arrival_law;
}

const Digest256& LawIdentityV1::execution_identity() const noexcept {
  return spec_.execution_identity;
}

const Digest256& LawIdentityV1::metric_target_identity() const noexcept {
  return spec_.metric_target_identity;
}

ProductKindV1 LawIdentityV1::product_kind() const noexcept {
  return std::visit(
      [](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, RawResponseProductRef>) {
          return ProductKindV1::raw_response;
        } else if constexpr (std::is_same_v<T, NominalResponseProductRef>) {
          return ProductKindV1::nominal_response;
        } else {
          return ProductKindV1::recoded_response;
        }
      },
      spec_.deployed_product);
}

ProductKindV1 product_kind_v1(const ProductIdentityV1& identity) noexcept {
  return std::visit(
      [](const auto& value) {
        using T = std::decay_t<decltype(value)>;
        if constexpr (std::is_same_v<T, RawResponseCoefficientIdentityV1>) {
          return ProductKindV1::raw_response;
        } else if constexpr (
            std::is_same_v<T, NominalResponseCoefficientIdentityV1>) {
          return ProductKindV1::nominal_response;
        } else if constexpr (std::is_same_v<T, ProjectionCenterIdentityV1>) {
          return ProductKindV1::projection_center;
        } else if constexpr (std::is_same_v<T, ProjectedMeanIdentityV1>) {
          return ProductKindV1::projected_mean;
        } else if constexpr (
            std::is_same_v<T, RecodedResponseCoefficientIdentityV1>) {
          return ProductKindV1::recoded_response;
        } else {
          return value.law.product_kind();
        }
      },
      identity);
}

bool product_identity_is_deployable_law_v1(
    const ProductIdentityV1& identity) noexcept {
  return std::holds_alternative<DeployedLawProductIdentityV1>(identity);
}

DiagnosticComponent::DiagnosticComponent(DiagnosticComponentSpecV1 spec)
    : spec_(std::move(spec)) {}

Result<DiagnosticComponent> DiagnosticComponent::make(
    DiagnosticComponentSpecV1 spec) {
  if (!valid_reference(spec.component_identity) ||
      !valid_reference(spec.provenance_identity) || spec.metric.empty() ||
      spec.theorem_or_method.empty()) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.component_identity_or_scope_missing",
        "a diagnostic component requires identity, provenance, metric, and "
        "theorem/method fields"));
  }
  if (auto valid = validate_product(spec.source_product); !valid) {
    return Result<DiagnosticComponent>::failure(valid.error());
  }
  if (spec.destination_product) {
    if (auto valid = validate_product(*spec.destination_product); !valid) {
      return Result<DiagnosticComponent>::failure(valid.error());
    }
  }
  if (auto valid = validate_geometry(spec.geometry); !valid) {
    return Result<DiagnosticComponent>::failure(valid.error());
  }
  if (auto valid = validate_value(spec.value); !valid) {
    return Result<DiagnosticComponent>::failure(valid.error());
  }
  if (spec.evidence_references.empty() ||
      std::any_of(spec.evidence_references.begin(),
                  spec.evidence_references.end(), [](const auto& reference) {
                    return !valid_reference(reference);
                  })) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.component_evidence_missing",
        "a diagnostic component requires nonempty exact evidence references"));
  }
  std::sort(spec.evidence_references.begin(), spec.evidence_references.end());
  if (std::adjacent_find(spec.evidence_references.begin(),
                         spec.evidence_references.end()) !=
      spec.evidence_references.end()) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.component_evidence_duplicate",
        "a diagnostic component repeats an evidence reference"));
  }
  if (std::any_of(spec.assumptions.begin(), spec.assumptions.end(),
                  [](const std::string& value) { return value.empty(); })) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.component_empty_assumption",
        "a diagnostic component contains an empty assumption"));
  }
  std::sort(spec.assumptions.begin(), spec.assumptions.end());
  spec.assumptions.erase(
      std::unique(spec.assumptions.begin(), spec.assumptions.end()),
      spec.assumptions.end());

  if (spec.confidence) {
    if (!finite(spec.confidence->confidence_level) ||
        spec.confidence->confidence_level <= 0.0L ||
        spec.confidence->confidence_level >= 1.0L ||
        spec.confidence->method.empty() ||
        spec.confidence->coverage_family.empty()) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.component_confidence_invalid",
          "confidence metadata requires a level in (0,1), method, and "
          "coverage family"));
    }
  }
  if (spec.deterministic_tolerance &&
      (!finite(*spec.deterministic_tolerance) ||
       *spec.deterministic_tolerance < 0.0L)) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.component_tolerance_invalid",
        "a deterministic tolerance must be finite and nonnegative"));
  }
  if (spec.confidence && spec.deterministic_tolerance) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.component_uncertainty_kind_ambiguous",
        "one diagnostic component cannot be both a statistical confidence "
        "statement and a deterministic tolerance"));
  }

  if (spec.bridge) {
    if (!spec.destination_product) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.bridge_destination_missing",
          "a product bridge component requires an exact destination product"));
    }
    if (auto valid = validate_bridge(*spec.bridge); !valid) {
      return Result<DiagnosticComponent>::failure(valid.error());
    }
    if (!bridge_attaches(*spec.bridge, spec.source_product,
                         *spec.destination_product)) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.bridge_attachment_mismatch",
          "the bridge endpoints do not equal the component's exact source "
          "and destination products"));
    }
    if (!bridge_has_owning_scope(*spec.bridge, spec.scope)) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.bridge_scope_owner_mismatch",
          "a product bridge may be carried only by its closed construction, "
          "projection, or recode diagnostic owner"));
    }
  } else if (spec.destination_product &&
             *spec.destination_product != spec.source_product) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.cross_product_transfer_missing",
        "different source and destination products require a typed bridge"));
  }

  if (spec.scope == ComponentScopeV1::physical_fidelity) {
    const LawIdentityV1* law = deployed_law(spec.source_product);
    if (spec.destination_product) {
      const LawIdentityV1* destination =
          deployed_law(*spec.destination_product);
      if (law != nullptr && destination != nullptr && *law != *destination) {
        return Result<DiagnosticComponent>::failure(diagnostic(
            "c25.physical_fidelity_law_mismatch",
            "physical-fidelity source and destination name different "
            "deployed laws"));
      }
      if (law == nullptr) {
        law = destination;
      }
    }
    if (law == nullptr) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.physical_fidelity_law_missing",
          "physical-fidelity evidence must name the exact deployed surrogate "
          "law it compares"));
    }
    if (!spec.physical_fidelity_anchor) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.physical_fidelity_anchor_missing",
          "physical-fidelity scope requires an opaque anchor issued by the "
          "matching validated certificate bundle"));
    }
    const auto& anchor = *spec.physical_fidelity_anchor;
    if (anchor.subject_product_identity() !=
            deployed_response_product_subject_v1(law->deployed_product())
                .object_digest ||
        anchor.subject_law_identity() != law->execution_identity() ||
        anchor.metric_identity() != law->metric_target_identity()) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.physical_fidelity_anchor_mismatch",
          "the physical-fidelity anchor does not match the component's exact "
          "deployed product, law, and metric identities"));
    }
    if (anchor.kind() == PhysicalFidelityKindV1::bounded) {
      if (!anchor.finite_bound() || !established_finite(spec.value) ||
          *spec.value.upper != *anchor.finite_bound()) {
        return Result<DiagnosticComponent>::failure(diagnostic(
            "c25.physical_fidelity_bound_mismatch",
            "a bounded physical-fidelity component must expose the exact "
            "finite bound carried by its validated anchor"));
      }
    } else if (anchor.kind() == PhysicalFidelityKindV1::exact) {
      if (!established_finite(spec.value) || *spec.value.lower != 0.0L ||
          *spec.value.upper != 0.0L) {
        return Result<DiagnosticComponent>::failure(diagnostic(
            "c25.physical_fidelity_exact_nonzero",
            "an exact physical-fidelity anchor permits only the zero error "
            "interval"));
      }
    } else if (established_finite(spec.value)) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.physical_fidelity_nonbound_numeric",
          "empirical-only or not-established physical fidelity cannot "
          "authorize a finite mathematical error bound"));
    }
  } else if (spec.physical_fidelity_anchor) {
    return Result<DiagnosticComponent>::failure(diagnostic(
        "c25.physical_fidelity_anchor_scope_mismatch",
        "a physical-fidelity anchor may appear only on its owning scope"));
  }

  if (spec.triangle_contribution) {
    auto& declaration = *spec.triangle_contribution;
    if (!valid_reference(declaration.total_identity)) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.triangle_identity_missing",
          "an explicitly declared triangle total requires an identity"));
    }
    if (auto valid = canonicalize_declared_references(
            declaration.required_component_identities,
            "c25.triangle_component_set_missing",
            "c25.triangle_component_set_duplicate",
            "required component identities", true);
        !valid) {
      return Result<DiagnosticComponent>::failure(valid.error());
    }
    if (auto valid = canonicalize_declared_references(
            declaration.required_bridge_evidence_identities,
            "c25.triangle_bridge_set_invalid",
            "c25.triangle_bridge_set_duplicate",
            "required bridge evidence identities", false);
        !valid) {
      return Result<DiagnosticComponent>::failure(valid.error());
    }
    if (declaration.required &&
        !std::binary_search(declaration.required_component_identities.begin(),
                            declaration.required_component_identities.end(),
                            spec.component_identity)) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.triangle_required_component_undeclared",
          "a required triangle contributor must occur in the declaration's "
          "closed component set"));
    }
    if (declaration.combination_rule ==
            TriangleCombinationRuleV1::deterministic &&
        spec.confidence) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.triangle_confidence_rule_mismatch",
          "a statistical component cannot enter a deterministic-only total"));
    }
  }

  if (spec.evaluated_transfer_bound) {
    const auto& bound = *spec.evaluated_transfer_bound;
    if (bound.theorem_id.empty() || bound.geometry != spec.geometry ||
        !valid_reference(bound.reference_law) ||
        !valid_reference(bound.approximate_law)) {
      return Result<DiagnosticComponent>::failure(diagnostic(
          "c25.transfer_bound_attachment_mismatch",
          "an evaluated transfer bound must retain its theorem, exact laws, "
          "and the component's tagged geometry"));
    }
  }

  return Result<DiagnosticComponent>::success(
      DiagnosticComponent(std::move(spec)));
}

const ArtifactObjectReferenceV1& DiagnosticComponent::component_identity()
    const noexcept {
  return spec_.component_identity;
}
ComponentScopeV1 DiagnosticComponent::scope() const noexcept {
  return spec_.scope;
}
const ProductIdentityV1& DiagnosticComponent::source_product() const noexcept {
  return spec_.source_product;
}
const std::optional<ProductIdentityV1>&
DiagnosticComponent::destination_product() const noexcept {
  return spec_.destination_product;
}
const std::string& DiagnosticComponent::metric() const noexcept {
  return spec_.metric;
}
const MetricGeometry& DiagnosticComponent::geometry() const noexcept {
  return spec_.geometry;
}
const DiagnosticValueIntervalV1& DiagnosticComponent::value() const noexcept {
  return spec_.value;
}
const std::optional<DiagnosticConfidenceV1>&
DiagnosticComponent::confidence() const noexcept {
  return spec_.confidence;
}
const std::optional<long double>& DiagnosticComponent::deterministic_tolerance()
    const noexcept {
  return spec_.deterministic_tolerance;
}
const std::string& DiagnosticComponent::theorem_or_method() const noexcept {
  return spec_.theorem_or_method;
}
const std::vector<std::string>& DiagnosticComponent::assumptions()
    const noexcept {
  return spec_.assumptions;
}
const std::vector<ArtifactObjectReferenceV1>&
DiagnosticComponent::evidence_references() const noexcept {
  return spec_.evidence_references;
}
const ArtifactObjectReferenceV1& DiagnosticComponent::provenance_identity()
    const noexcept {
  return spec_.provenance_identity;
}
const std::optional<ProductBridgeV1>& DiagnosticComponent::bridge()
    const noexcept {
  return spec_.bridge;
}
const std::optional<TriangleContributionV1>&
DiagnosticComponent::triangle_contribution() const noexcept {
  return spec_.triangle_contribution;
}
const std::optional<PhysicalFidelityAnchor>&
DiagnosticComponent::physical_fidelity_anchor() const noexcept {
  return spec_.physical_fidelity_anchor;
}
const std::optional<ErrorBound>& DiagnosticComponent::evaluated_transfer_bound()
    const noexcept {
  return spec_.evaluated_transfer_bound;
}

std::span<const DiagnosticComponent> DiagnosticBundle::ordered_components()
    const noexcept {
  return ordered_components_;
}
std::span<const Diagnostic> DiagnosticBundle::validation_diagnostics()
    const noexcept {
  return validation_diagnostics_;
}
std::span<const TriangleTotalV1> DiagnosticBundle::triangle_totals()
    const noexcept {
  return triangle_totals_;
}
const BudgetConclusionV1& DiagnosticBundle::final_law_total() const noexcept {
  return final_law_total_;
}
const BudgetConclusionV1& DiagnosticBundle::physical_total() const noexcept {
  return physical_total_;
}
bool DiagnosticBundle::valid() const noexcept {
  return std::none_of(validation_diagnostics_.begin(),
                      validation_diagnostics_.end(), [](const Diagnostic& item) {
                        return item.category == DiagnosticCategory::input_validation ||
                               item.category == DiagnosticCategory::internal;
                      });
}

DiagnosticBundle compose_diagnostic_and_error_budget(
    std::span<const DiagnosticComponent> components) {
  DiagnosticBundle bundle;
  bundle.final_law_total_ = unavailable_conclusion();
  bundle.physical_total_ = unavailable_conclusion();
  bundle.ordered_components_.assign(components.begin(), components.end());
  std::sort(bundle.ordered_components_.begin(), bundle.ordered_components_.end(),
            [](const auto& left, const auto& right) {
              return component_sort_key(left) < component_sort_key(right);
            });

  std::set<std::size_t> duplicate_indices;
  for (std::size_t left = 0; left < bundle.ordered_components_.size(); ++left) {
    for (std::size_t right = left + 1U;
         right < bundle.ordered_components_.size(); ++right) {
      if (bundle.ordered_components_[left].component_identity().object_id ==
          bundle.ordered_components_[right].component_identity().object_id) {
        duplicate_indices.insert(left);
        duplicate_indices.insert(right);
        bundle.validation_diagnostics_.push_back(diagnostic(
            "c25.component_identity_overwrite",
            "two ledger entries use the same component object identity; both "
            "remain visible but neither may enter an aggregate"));
      }
    }
  }

  std::vector<TotalGroup> groups;
  for (std::size_t index = 0; index < bundle.ordered_components_.size();
       ++index) {
    const auto& component = bundle.ordered_components_[index];
    if (!component.triangle_contribution()) {
      continue;
    }
    const auto& declaration = *component.triangle_contribution();
    auto found = std::find_if(groups.begin(), groups.end(), [&](const auto& group) {
      return group.declaration.total_identity.object_id ==
             declaration.total_identity.object_id;
    });
    if (found == groups.end()) {
      groups.push_back(TotalGroup{declaration, {&component}, false,
                                  duplicate_indices.contains(index)});
      continue;
    }
    if (found->declaration != declaration) {
      found->declaration_conflict = true;
    }
    found->duplicate_component =
        found->duplicate_component || duplicate_indices.contains(index);
    found->components.push_back(&component);
  }

  std::size_t final_count = 0U;
  std::size_t physical_count = 0U;
  for (const auto& group : groups) {
    TriangleTotalV1 total{group.declaration.total_identity,
                          group.declaration.total_kind,
                          group.declaration.total_product,
                          CertificateClaimStateV1::established,
                          BoundValueStatusV1::finite,
                          0.0L,
                          {},
                          {},
                          group.declaration.required_component_identities,
                          group.declaration
                              .required_bridge_evidence_identities,
                          {}};
    bool unavailable = group.declaration_conflict || group.duplicate_component;
    bool infinite_total = false;
    bool has_physical_fidelity = false;
    long double sum = 0.0L;
    std::optional<std::string> simultaneous_family;
    long double union_failure_probability = 0.0L;
    const auto bridges = collect_bridges(group.components);
    std::vector<ArtifactObjectReferenceV1> usable_bridge_identities;
    usable_bridge_identities.reserve(bridges.size());
    for (const auto* bridge : bridges) {
      usable_bridge_identities.push_back(bridge_evidence(*bridge));
    }
    std::sort(usable_bridge_identities.begin(),
              usable_bridge_identities.end());
    usable_bridge_identities.erase(
        std::unique(usable_bridge_identities.begin(),
                    usable_bridge_identities.end()),
        usable_bridge_identities.end());

    if (group.declaration_conflict) {
      bundle.validation_diagnostics_.push_back(diagnostic(
          "c25.triangle_declaration_overwrite",
          "contributors reuse one triangle-total identity with different "
          "declarations"));
    }

    for (const auto* component : group.components) {
      total.component_identities.push_back(component->component_identity());
      total.assumptions.insert(total.assumptions.end(),
                               component->assumptions().begin(),
                               component->assumptions().end());
      if (component->bridge()) {
        total.bridge_evidence_identities.push_back(
            bridge_evidence(*component->bridge()));
      }
      has_physical_fidelity =
          has_physical_fidelity ||
          component->scope() == ComponentScopeV1::physical_fidelity;

      if (component->metric() != group.components.front()->metric() ||
          component->geometry() != group.components.front()->geometry()) {
        unavailable = true;
        bundle.validation_diagnostics_.push_back(diagnostic(
            "c25.triangle_metric_geometry_mismatch",
            "a triangle total mixes metric or geometry identities"));
      }
      const bool attached =
          reaches_law(component->source_product(),
                      group.declaration.total_product.law, bridges) ||
          (component->destination_product() &&
           reaches_law(*component->destination_product(),
                       group.declaration.total_product.law, bridges));
      if (!attached) {
        unavailable = true;
        bundle.validation_diagnostics_.push_back(diagnostic(
            "c25.final_law_bridge_not_established",
            "a triangle contributor has no exact typed path to the declared "
            "deployed law",
            DiagnosticCategory::unavailable));
      }

      if (component->confidence()) {
        if (group.declaration.combination_rule ==
            TriangleCombinationRuleV1::deterministic) {
          unavailable = true;
        } else if (group.declaration.combination_rule ==
                   TriangleCombinationRuleV1::simultaneous_confidence) {
          if (!component->confidence()->simultaneous ||
              (simultaneous_family &&
               *simultaneous_family !=
                   component->confidence()->coverage_family)) {
            unavailable = true;
          } else {
            simultaneous_family = component->confidence()->coverage_family;
          }
        } else {
          union_failure_probability +=
              1.0L - component->confidence()->confidence_level;
          if (!finite(union_failure_probability) ||
              union_failure_probability >= 1.0L) {
            unavailable = true;
          }
        }
      }

      const auto& value = component->value();
      if (value.claim_state != CertificateClaimStateV1::established ||
          value.value_status == BoundValueStatusV1::unresolved) {
        unavailable = true;
        continue;
      }
      if (value.value_status == BoundValueStatusV1::infinite) {
        infinite_total = true;
        continue;
      }
      if (!value.upper) {
        unavailable = true;
        continue;
      }
      const long double next = sum + *value.upper;
      if (!finite(next) || next < sum) {
        infinite_total = true;
      } else {
        sum = next;
      }
    }

    if (group.declaration.total_kind == TriangleTotalKindV1::physical_error &&
        !has_physical_fidelity) {
      unavailable = true;
      bundle.validation_diagnostics_.push_back(diagnostic(
          "c25.physical_total_fidelity_missing",
          "a physical total requires a separate physical-fidelity component",
          DiagnosticCategory::unavailable));
    }

    std::sort(total.component_identities.begin(),
              total.component_identities.end());
    std::sort(total.bridge_evidence_identities.begin(),
              total.bridge_evidence_identities.end());
    total.bridge_evidence_identities.erase(
        std::unique(total.bridge_evidence_identities.begin(),
                    total.bridge_evidence_identities.end()),
        total.bridge_evidence_identities.end());
    if (total.component_identities !=
        group.declaration.required_component_identities) {
      unavailable = true;
      bundle.validation_diagnostics_.push_back(diagnostic(
          "c25.triangle_component_set_incomplete",
          "the supplied triangle contributors do not equal the explicitly "
          "declared complete component set",
          DiagnosticCategory::unavailable));
    }
    if (total.bridge_evidence_identities !=
        group.declaration.required_bridge_evidence_identities) {
      unavailable = true;
      bundle.validation_diagnostics_.push_back(diagnostic(
          "c25.triangle_bridge_set_incomplete",
          "the supplied triangle bridge records do not equal the explicitly "
          "declared complete bridge set",
          DiagnosticCategory::unavailable));
    }
    if (usable_bridge_identities !=
        group.declaration.required_bridge_evidence_identities) {
      unavailable = true;
      bundle.validation_diagnostics_.push_back(diagnostic(
          "c25.triangle_bridge_result_not_established",
          "every declared triangle bridge must be carried by a component and "
          "have established finite component and result intervals",
          DiagnosticCategory::unavailable));
    }
    std::sort(total.assumptions.begin(), total.assumptions.end());
    total.assumptions.erase(
        std::unique(total.assumptions.begin(), total.assumptions.end()),
        total.assumptions.end());

    if (unavailable) {
      total.claim_state = CertificateClaimStateV1::not_established;
      total.value_status = BoundValueStatusV1::unresolved;
      total.upper_bound.reset();
    } else if (infinite_total) {
      total.value_status = BoundValueStatusV1::infinite;
      total.upper_bound.reset();
    } else {
      total.upper_bound = sum;
    }

    bundle.triangle_totals_.push_back(total);
    BudgetConclusionV1 conclusion{total.claim_state, total.value_status,
                                  total.total_identity, total.upper_bound};
    if (total.total_kind == TriangleTotalKindV1::final_law_error) {
      ++final_count;
      bundle.final_law_total_ = conclusion;
    } else {
      ++physical_count;
      bundle.physical_total_ = conclusion;
    }
  }

  std::sort(bundle.triangle_totals_.begin(), bundle.triangle_totals_.end(),
            [](const auto& left, const auto& right) {
              return left.total_identity < right.total_identity;
            });
  if (final_count > 1U) {
    bundle.final_law_total_ = unavailable_conclusion();
    bundle.validation_diagnostics_.push_back(diagnostic(
        "c25.final_total_ambiguous",
        "more than one final-law total was declared",
        DiagnosticCategory::unavailable));
  }
  if (physical_count > 1U) {
    bundle.physical_total_ = unavailable_conclusion();
    bundle.validation_diagnostics_.push_back(diagnostic(
        "c25.physical_total_ambiguous",
        "more than one physical total was declared",
        DiagnosticCategory::unavailable));
  }
  return bundle;
}

}  // namespace mwperf
