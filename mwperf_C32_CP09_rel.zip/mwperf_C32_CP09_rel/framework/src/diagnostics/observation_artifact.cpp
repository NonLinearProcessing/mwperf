#include "mwperf/diagnostics/observation_artifact.hpp"

#include <string>
#include <utility>

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic(std::string code, std::string message) {
  return Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                    std::move(message), std::nullopt, std::nullopt, {}};
}

}  // namespace

Result<CanonicalObservationArtifactV1> canonical_observation_artifact_v1(
    const ValidatedConstructionObservationBundleV1& observation) {
  ConstructionObservationEnvelopeV1 envelope{observation.value(),
                                             observation.digest()};
  auto encoded =
      canonical_construction_observation_envelope_bytes_v1(envelope);
  if (!encoded) {
    return Result<CanonicalObservationArtifactV1>::failure(encoded.error());
  }
  std::vector<std::byte> bytes = std::move(encoded).value();
  return Result<CanonicalObservationArtifactV1>::success(
      CanonicalObservationArtifactV1{
          ObservationArtifactReferenceV1{observation.digest(), bytes.size()},
          std::move(bytes)});
}

Result<ValidatedConstructionObservationBundleV1>
parse_and_validate_observation_artifact_v1(
    const std::span<const std::byte> bytes,
    const ObservationParseLimitsV1& limits,
    const std::optional<ObservationArtifactReferenceV1>& expected_reference) {
  if (expected_reference &&
      expected_reference->canonical_byte_count != bytes.size()) {
    return Result<ValidatedConstructionObservationBundleV1>::failure(
        diagnostic("observation_artifact.byte_count_mismatch",
                   "the standalone observation artifact byte count does not "
                   "match its bound reference"));
  }
  auto envelope = parse_construction_observation_envelope_v1(bytes, limits);
  if (!envelope) {
    return Result<ValidatedConstructionObservationBundleV1>::failure(
        envelope.error());
  }
  if (expected_reference &&
      envelope.value().observation_bundle_digest !=
          expected_reference->observation_bundle_digest) {
    return Result<ValidatedConstructionObservationBundleV1>::failure(
        diagnostic("observation_artifact.digest_mismatch",
                   "the standalone observation artifact digest does not "
                   "match its bound reference"));
  }
  return validate_construction_observation_envelope_v1(
      std::move(envelope).value(), limits);
}

}  // namespace mwperf
