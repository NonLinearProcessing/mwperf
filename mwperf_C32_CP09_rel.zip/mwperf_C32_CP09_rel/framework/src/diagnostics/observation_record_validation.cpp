#include "mwperf/diagnostics/observation_record.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <optional>
#include <ranges>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/diagnostic.hpp"

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic validation_diagnostic(
    const DiagnosticCategory category, std::string code, std::string message,
    std::optional<std::string> pointer = std::nullopt) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::move(pointer), {}};
}

template <typename T>
[[nodiscard]] Result<T> validation_failure(
    std::string code, std::string message, std::string pointer,
    const DiagnosticCategory category = DiagnosticCategory::input_validation) {
  return Result<T>::failure(validation_diagnostic(
      category, std::move(code), std::move(message), std::move(pointer)));
}

[[nodiscard]] std::string child_pointer(const std::string_view base,
                                        const std::string_view child) {
  return std::string(base) + "/" + std::string(child);
}

[[nodiscard]] std::string index_pointer(const std::string_view base,
                                        const std::size_t index) {
  return std::string(base) + "/" + std::to_string(index);
}

struct ExactEnclosure final {
  ExactRational center;
  ExactRational radius;
};

[[nodiscard]] Result<void> validate_exact_rational_bounds(
    const ExactRational& value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  BigInt numerator_magnitude = value.numerator();
  if (numerator_magnitude < 0) {
    numerator_magnitude = -numerator_magnitude;
  }
  Result<BigNat> numerator =
      BigNat::from_big_int(std::move(numerator_magnitude));
  Result<BigNat> denominator = BigNat::from_big_int(value.denominator());
  if (!numerator || !denominator) {
    return validation_failure<void>(
        "observation_rational_component",
        "an exact rational has an invalid integer component", path,
        DiagnosticCategory::internal);
  }
  if (numerator.value().bit_length() > limits.maximum_integer_bits ||
      denominator.value().bit_length() > limits.maximum_integer_bits) {
    return validation_failure<void>(
        "observation_integer_bit_limit",
        "an exact-rational component exceeds the configured bit cap", path,
        DiagnosticCategory::resource_limit);
  }
  std::string numerator_decimal = value.numerator_decimal();
  if (!numerator_decimal.empty() && numerator_decimal.front() == '-') {
    numerator_decimal.erase(numerator_decimal.begin());
  }
  if (numerator_decimal.size() > limits.maximum_integer_decimal_digits ||
      value.denominator_decimal().size() >
          limits.maximum_integer_decimal_digits) {
    return validation_failure<void>(
        "observation_integer_decimal_digit_limit",
        "an exact-rational component exceeds the configured decimal-digit "
        "cap",
        path, DiagnosticCategory::resource_limit);
  }
  return Result<void>::success();
}

[[nodiscard]] ExactRational scalar_exact_value(
    const PortableScientificScalar& value) {
  if (value.kind() == PortableScientificScalarKind::rational) {
    return value.rational_value();
  }
  return binary64_as_exact_rational(value);
}

[[nodiscard]] bool is_negative_zero(
    const PortableScientificScalar& value) noexcept {
  return value.kind() == PortableScientificScalarKind::binary64 &&
         value.binary64_bits() == UINT64_C(0x8000000000000000);
}

[[nodiscard]] Result<ExactEnclosure> validate_scalar_contract(
    const ObservationScalarV1& scalar,
    const ObservationScalarRepresentationV1 representation,
    const std::string& path, const ObservationParseLimitsV1& limits,
    const bool require_nonnegative) {
  if (representation == ObservationScalarRepresentationV1::exact_rational) {
    if (scalar.value.kind() != PortableScientificScalarKind::rational ||
        scalar.enclosure.has_value()) {
      return validation_failure<ExactEnclosure>(
          "observation_scalar_contract_mismatch",
          "an exact-rational observation requires a rational value and no "
          "numerical enclosure",
          path);
    }
    const ExactRational center = scalar.value.rational_value();
    Result<void> bounded = validate_exact_rational_bounds(center, path, limits);
    if (!bounded) {
      return Result<ExactEnclosure>::failure(bounded.error());
    }
    if (require_nonnegative && !center.is_nonnegative()) {
      return validation_failure<ExactEnclosure>(
          "observation_negative_mass",
          "an observation mass or magnitude must be nonnegative", path);
    }
    return Result<ExactEnclosure>::success(
        ExactEnclosure{center, ExactRational::zero()});
  }

  if (scalar.value.kind() != PortableScientificScalarKind::binary64 ||
      !scalar.enclosure.has_value() ||
      scalar.enclosure->absolute_error.kind() !=
          PortableScientificScalarKind::binary64 ||
      scalar.enclosure->l1_norm.kind() !=
          PortableScientificScalarKind::binary64) {
    return validation_failure<ExactEnclosure>(
        "observation_scalar_contract_mismatch",
        "an enclosed-binary64 observation requires binary64 value, absolute "
        "error and L1-norm bit patterns",
        path);
  }
  if (is_negative_zero(scalar.value) ||
      is_negative_zero(scalar.enclosure->absolute_error) ||
      is_negative_zero(scalar.enclosure->l1_norm)) {
    return validation_failure<ExactEnclosure>(
        "observation_negative_zero_forbidden",
        "negative-zero binary64 encodings are not canonical observation "
        "scalars",
        path);
  }

  const ExactRational center = scalar_exact_value(scalar.value);
  const ExactRational radius =
      scalar_exact_value(scalar.enclosure->absolute_error);
  const ExactRational l1 = scalar_exact_value(scalar.enclosure->l1_norm);
  if (!radius.is_nonnegative() || !l1.is_nonnegative()) {
    return validation_failure<ExactEnclosure>(
        "observation_invalid_enclosure",
        "an observation enclosure radius and L1 norm must be nonnegative",
        path);
  }
  if (l1 < absolute_value(center)) {
    return validation_failure<ExactEnclosure>(
        "observation_invalid_l1_norm",
        "an observation accumulator L1 norm cannot be smaller than the "
        "absolute recorded value",
        path);
  }
  if (l1 < radius) {
    return validation_failure<ExactEnclosure>(
        "observation_invalid_error_bound",
        "an observation accumulator absolute-error radius cannot exceed its "
        "L1 norm",
        path);
  }
  if (require_nonnegative && !center.is_nonnegative()) {
    return validation_failure<ExactEnclosure>(
        "observation_negative_mass",
        "a serialized observation mass or magnitude must be nonnegative",
        path);
  }
  return Result<ExactEnclosure>::success(ExactEnclosure{center, radius});
}

[[nodiscard]] ExactEnclosure add_enclosures(const ExactEnclosure& lhs,
                                            const ExactEnclosure& rhs) {
  return ExactEnclosure{lhs.center + rhs.center, lhs.radius + rhs.radius};
}

[[nodiscard]] bool encloses_zero(const ExactEnclosure& value) {
  return absolute_value(value.center) <= value.radius;
}

[[nodiscard]] bool enclosures_can_be_equal(const ExactEnclosure& lhs,
                                           const ExactEnclosure& rhs) {
  return absolute_value(lhs.center - rhs.center) <=
         lhs.radius + rhs.radius;
}

[[nodiscard]] bool enclosed_less_equal(const ExactEnclosure& lhs,
                                       const ExactEnclosure& rhs) {
  // Establishes that at least one pair of true values inside the declared
  // enclosures respects lhs <= rhs.  Exact records reduce to exact order.
  return lhs.center - lhs.radius <= rhs.center + rhs.radius;
}

[[nodiscard]] Result<void> require_size_at_most(
    const std::size_t actual, const std::size_t maximum, std::string code,
    std::string message, std::string pointer) {
  if (actual > maximum) {
    return validation_failure<void>(std::move(code), std::move(message),
                                    std::move(pointer),
                                    DiagnosticCategory::resource_limit);
  }
  return Result<void>::success();
}

[[nodiscard]] bool checked_increment(std::size_t& total,
                                     const std::size_t addition,
                                     const std::size_t maximum) noexcept {
  if (addition > maximum || total > maximum - addition) {
    return false;
  }
  total += addition;
  return true;
}

[[nodiscard]] Result<void> validate_identifier(
    const std::string_view value, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  if (value.empty()) {
    return validation_failure<void>(
        "observation_empty_identifier",
        "an observation identity string must be nonempty", path);
  }
  if (value.size() > limits.maximum_string_bytes) {
    return validation_failure<void>(
        "observation_identifier_limit",
        "an observation identity string exceeds the configured cap", path,
        DiagnosticCategory::resource_limit);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_typed_label_bounds(
    const TypedLabel& label, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  if (label.is_numeric()) {
    if (label.numeric_value()->bit_length() > limits.maximum_integer_bits ||
        label.numeric_value()->to_decimal_string().size() >
            limits.maximum_integer_decimal_digits) {
      return validation_failure<void>(
          "observation_typed_label_limit",
          "a numeric typed label exceeds the configured integer cap", path,
          DiagnosticCategory::resource_limit);
    }
    return Result<void>::success();
  }
  return validate_identifier(*label.text_value(), path, limits);
}

[[nodiscard]] bool valid_reason_code(const std::string_view code) noexcept {
  if (code.empty()) {
    return false;
  }
  return std::ranges::all_of(code, [](const char character) {
    const unsigned char byte = static_cast<unsigned char>(character);
    return (byte >= static_cast<unsigned char>('a') &&
            byte <= static_cast<unsigned char>('z')) ||
           (byte >= static_cast<unsigned char>('0') &&
            byte <= static_cast<unsigned char>('9')) ||
           character == '_';
  });
}

[[nodiscard]] Result<void> validate_capability(
    const ObservationCapabilityStateV1& capability, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  if (capability.available) {
    if (capability.unavailable_reason_code.has_value()) {
      return validation_failure<void>(
          "observation_capability_reason_on_available",
          "an available observation capability cannot carry an unavailable "
          "reason",
          child_pointer(path, "unavailable_reason_code"));
    }
    return Result<void>::success();
  }
  if (!capability.unavailable_reason_code.has_value() ||
      !valid_reason_code(*capability.unavailable_reason_code)) {
    return validation_failure<void>(
        "observation_capability_reason_required",
        "an unavailable observation capability requires a nonempty "
        "lowercase reason code",
        child_pointer(path, "unavailable_reason_code"));
  }
  return validate_identifier(*capability.unavailable_reason_code,
                             child_pointer(path, "unavailable_reason_code"),
                             limits);
}

[[nodiscard]] Result<void> validate_all_capabilities(
    const ObservationCapabilitiesV1& capabilities,
    const ObservationScientificBindingsV1& bindings,
    const std::string& path, const ObservationParseLimitsV1& limits) {
  const std::array<std::pair<const ObservationCapabilityStateV1*,
                             std::string_view>,
                   7U>
      entries{{
          {&capabilities.iid_fresh_arrivals, "iid_fresh_arrivals"},
          {&capabilities.finite_arrival_second_moment,
           "finite_arrival_second_moment"},
          {&capabilities.exact_target_arrival_marginal,
           "exact_target_arrival_marginal"},
          {&capabilities.no_target_drops, "no_target_drops"},
          {&capabilities.exact_primary_maxweight,
           "exact_primary_maxweight"},
          {&capabilities.unit_target_multiplier, "unit_target_multiplier"},
          {&capabilities.certified_gap_probe, "certified_gap_probe"},
      }};
  for (const auto& [capability, name] : entries) {
    Result<void> valid =
        validate_capability(*capability, child_pointer(path, name), limits);
    if (!valid) {
      return valid;
    }
  }

  const bool exact_marginal =
      std::holds_alternative<ExactTargetArrivalMarginalV1>(
          bindings.arrival.target_arrival);
  if (capabilities.exact_target_arrival_marginal.available != exact_marginal) {
    return validation_failure<void>(
        "observation_arrival_capability_mismatch",
        "the exact-target-marginal capability must agree with the selected "
        "target-arrival representation",
        child_pointer(path, "exact_target_arrival_marginal"));
  }
  if (exact_marginal &&
      !capabilities.finite_arrival_second_moment.available) {
    return validation_failure<void>(
        "observation_second_moment_capability_mismatch",
        "a finite exact target-arrival marginal necessarily supplies a finite "
        "second moment",
        child_pointer(path, "finite_arrival_second_moment"));
  }
  if (capabilities.unit_target_multiplier.available !=
      (bindings.target.maxweight_multiplier == ExactRational::one())) {
    return validation_failure<void>(
        "observation_multiplier_capability_mismatch",
        "the unit-target-multiplier capability must agree with the bound "
        "MaxWeight multiplier",
        child_pointer(path, "unit_target_multiplier"));
  }
  if (capabilities.certified_gap_probe.available &&
      (!capabilities.exact_primary_maxweight.available ||
       !capabilities.unit_target_multiplier.available)) {
    return validation_failure<void>(
        "observation_gap_capability_mismatch",
        "a certified gap probe requires an exact primary MaxWeight solve and "
        "unit target multiplier",
        child_pointer(path, "certified_gap_probe"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_arrival(
    const ObservationArrivalBindingV1& arrival, const std::string& path,
    const ObservationParseLimitsV1& limits) {
  Result<void> family = validate_identifier(
      arrival.arrival_family_id, child_pointer(path, "arrival_family_id"),
      limits);
  if (!family) {
    return family;
  }
  if (!arrival.mean.is_nonnegative() ||
      !arrival.second_moment.is_nonnegative()) {
    return validation_failure<void>(
        "observation_negative_arrival_moment",
        "arrival mean and second moment must be nonnegative", path);
  }
  Result<void> mean_bounded = validate_exact_rational_bounds(
      arrival.mean, child_pointer(path, "mean"), limits);
  if (!mean_bounded) {
    return mean_bounded;
  }
  Result<void> second_bounded = validate_exact_rational_bounds(
      arrival.second_moment, child_pointer(path, "second_moment"), limits);
  if (!second_bounded) {
    return second_bounded;
  }

  if (const auto* marginal =
          std::get_if<ExactTargetArrivalMarginalV1>(&arrival.target_arrival)) {
    Result<void> bounded = require_size_at_most(
        marginal->atoms.size(), limits.maximum_arrival_atoms,
        "observation_arrival_atom_limit",
        "the exact target marginal exceeds the arrival-atom cap",
        child_pointer(path, "target_arrival/atoms"));
    if (!bounded) {
      return bounded;
    }
    if (marginal->atoms.empty()) {
      return validation_failure<void>(
          "observation_empty_arrival_marginal",
          "an exact target arrival marginal requires at least one atom",
          child_pointer(path, "target_arrival/atoms"));
    }

    ExactRational probability_sum = ExactRational::zero();
    ExactRational recomputed_mean = ExactRational::zero();
    ExactRational recomputed_second = ExactRational::zero();
    const BigNat* previous = nullptr;
    for (std::size_t index = 0U; index < marginal->atoms.size(); ++index) {
      const ExactTargetArrivalAtomV1& atom = marginal->atoms[index];
      const std::string atom_path =
          index_pointer(child_pointer(path, "target_arrival/atoms"), index);
      if (atom.batch_size.bit_length() > limits.maximum_integer_bits) {
        return validation_failure<void>(
            "observation_integer_bit_limit",
            "an arrival batch size exceeds the configured bit cap",
            child_pointer(atom_path, "batch_size"),
            DiagnosticCategory::resource_limit);
      }
      if (previous != nullptr && !(*previous < atom.batch_size)) {
        return validation_failure<void>(
            "observation_unsorted_arrival_atoms",
            "exact arrival atoms must have strictly increasing unique batch "
            "sizes",
            child_pointer(atom_path, "batch_size"));
      }
      if (!atom.probability.is_positive()) {
        return validation_failure<void>(
            "observation_invalid_arrival_probability",
            "an exact arrival atom probability must be positive",
            child_pointer(atom_path, "probability"));
      }
      Result<void> probability_bounded = validate_exact_rational_bounds(
          atom.probability, child_pointer(atom_path, "probability"), limits);
      if (!probability_bounded) {
        return probability_bounded;
      }
      previous = &atom.batch_size;
      probability_sum = probability_sum + atom.probability;
      const auto batch_rational = ExactRational::make(
          atom.batch_size.value(), BigInt(1));
      if (!batch_rational) {
        return validation_failure<void>(
            "observation_arrival_batch_conversion",
            "an exact arrival batch size could not be converted", atom_path,
            DiagnosticCategory::internal);
      }
      recomputed_mean = recomputed_mean +
                        batch_rational.value() * atom.probability;
      recomputed_second =
          recomputed_second + batch_rational.value() *
                                  batch_rational.value() * atom.probability;
    }
    if (probability_sum != ExactRational::one()) {
      return validation_failure<void>(
          "observation_arrival_probability_mass",
          "the exact target arrival marginal probabilities must sum to one",
          child_pointer(path, "target_arrival/atoms"));
    }
    if (recomputed_mean != arrival.mean ||
        recomputed_second != arrival.second_moment) {
      return validation_failure<void>(
          "observation_arrival_moment_mismatch",
          "the bound arrival moments do not equal the exact target marginal "
          "moments",
          path);
    }
    return Result<void>::success();
  }

  const auto& descriptor =
      std::get<TargetArrivalOvershootDescriptorV1>(arrival.target_arrival);
  Result<void> descriptor_id = validate_identifier(
      descriptor.descriptor_id,
      child_pointer(path, "target_arrival/descriptor_id"), limits);
  if (!descriptor_id) {
    return descriptor_id;
  }
  if (descriptor.descriptor_version == 0U) {
    return validation_failure<void>(
        "observation_invalid_descriptor_version",
        "an overshoot descriptor version must be positive",
        child_pointer(path, "target_arrival/descriptor_version"));
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_slot_order(
    const ConstructionObservationBundleV1& bundle) {
  static const std::vector<ObservationSlotStageV1> kWeightedOrder{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service,
      ObservationSlotStageV1::classify_and_resample,
      ObservationSlotStageV1::allocate_child_lineage,
      ObservationSlotStageV1::apply_fresh_late_arrival,
      ObservationSlotStageV1::commit_post_slot_state,
      ObservationSlotStageV1::emit_committed_observation,
  };
  static const std::vector<ObservationSlotStageV1> kDirectOrder{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service,
      ObservationSlotStageV1::apply_fresh_late_arrival,
      ObservationSlotStageV1::commit_post_slot_state,
      ObservationSlotStageV1::emit_committed_observation,
  };
  const auto& required =
      bundle.source_role == ObservationSourceRoleV1::weighted_ensemble
          ? kWeightedOrder
          : kDirectOrder;
  if (bundle.slot_convention.step_order != required) {
    return validation_failure<void>(
        "observation_slot_order_mismatch",
        "the declared step order does not match the source role's exact "
        "observation-v1 timing contract",
        "/observation_bundle/slot_convention/step_order");
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ExactEnclosure> validate_nonnegative_scalar(
    const ObservationScalarV1& scalar,
    const ObservationScalarRepresentationV1 representation,
    const std::string& path, const ObservationParseLimitsV1& limits) {
  return validate_scalar_contract(scalar, representation, path, limits, true);
}

[[nodiscard]] Result<ExactEnclosure> validate_signed_scalar(
    const ObservationScalarV1& scalar,
    const ObservationScalarRepresentationV1 representation,
    const std::string& path, const ObservationParseLimitsV1& limits) {
  return validate_scalar_contract(scalar, representation, path, limits,
                                  false);
}

[[nodiscard]] Result<void> validate_mass_balance(
    const ObservationMassBalanceV1& balance,
    const ExactEnclosure& recomputed_mass,
    const ExactRational& expected_mass,
    const ObservationScalarRepresentationV1 representation,
    const std::string& path, const ObservationParseLimitsV1& limits) {
  Result<ExactEnclosure> recorded = validate_nonnegative_scalar(
      balance.recorded_mass, representation,
      child_pointer(path, "recorded_mass"), limits);
  if (!recorded) {
    return Result<void>::failure(recorded.error());
  }
  Result<ExactEnclosure> defect = validate_signed_scalar(
      balance.signed_mass_defect, representation,
      child_pointer(path, "signed_mass_defect"), limits);
  if (!defect) {
    return Result<void>::failure(defect.error());
  }
  if (!enclosures_can_be_equal(recorded.value(), recomputed_mass)) {
    return validation_failure<void>(
        "observation_recorded_mass_mismatch",
        "the recorded mass is inconsistent with the sparse-row sum",
        child_pointer(path, "recorded_mass"));
  }
  const ExactEnclosure expected_defect{
      recorded.value().center - expected_mass, recorded.value().radius};
  if (!enclosures_can_be_equal(defect.value(), expected_defect)) {
    return validation_failure<void>(
        "observation_mass_defect_mismatch",
        "the signed mass defect is inconsistent with recorded minus expected "
        "mass",
        child_pointer(path, "signed_mass_defect"));
  }

  if (balance.claim == ObservationNormalizationClaimV1::exact) {
    if (!recorded.value().radius.is_zero() ||
        !defect.value().radius.is_zero() ||
        recorded.value().center != expected_mass ||
        !defect.value().center.is_zero()) {
      return validation_failure<void>(
          "observation_false_exact_normalization_claim",
          "an exact normalization claim requires bit/exact equality to the "
          "expected mass and a zero defect",
          path);
    }
  } else if (balance.claim == ObservationNormalizationClaimV1::enclosed) {
    if (representation !=
            ObservationScalarRepresentationV1::enclosed_binary64 ||
        !encloses_zero(defect.value())) {
      return validation_failure<void>(
          "observation_false_enclosed_normalization_claim",
          "an enclosed normalization claim requires a binary64 enclosure "
          "containing zero mass defect",
          path);
    }
  }
  return Result<void>::success();
}

[[nodiscard]] Result<ExactEnclosure> validate_boundary_law(
    const BoundaryBacklogLawV1& law,
    const ObservationScalarRepresentationV1 representation,
    const std::string& path, const ObservationParseLimitsV1& limits,
    std::size_t& boundary_row_count) {
  if (!checked_increment(boundary_row_count, law.rows.size(),
                         limits.maximum_total_boundary_rows)) {
    return validation_failure<ExactEnclosure>(
        "observation_boundary_row_limit",
        "the observation exceeds the total boundary-row cap", path,
        DiagnosticCategory::resource_limit);
  }
  if (law.rows.empty()) {
    return validation_failure<ExactEnclosure>(
        "observation_empty_boundary_law",
        "a committed boundary law requires at least one sparse row", path);
  }

  ExactEnclosure sum{ExactRational::zero(), ExactRational::zero()};
  const BigNat* previous = nullptr;
  for (std::size_t index = 0U; index < law.rows.size(); ++index) {
    const BoundaryBacklogMassV1& row = law.rows[index];
    const std::string row_path =
        index_pointer(child_pointer(path, "rows"), index);
    if (row.backlog_level.bit_length() > limits.maximum_integer_bits) {
      return validation_failure<ExactEnclosure>(
          "observation_integer_bit_limit",
          "a boundary backlog level exceeds the configured bit cap",
          child_pointer(row_path, "backlog_level"),
          DiagnosticCategory::resource_limit);
    }
    if (previous != nullptr && !(*previous < row.backlog_level)) {
      return validation_failure<ExactEnclosure>(
          "observation_unsorted_boundary_rows",
          "boundary rows must have strictly increasing unique backlog levels",
          child_pointer(row_path, "backlog_level"));
    }
    Result<ExactEnclosure> mass = validate_nonnegative_scalar(
        row.mass, representation, child_pointer(row_path, "mass"), limits);
    if (!mass) {
      return mass;
    }
    if (!mass.value().center.is_positive()) {
      return validation_failure<ExactEnclosure>(
          "observation_zero_sparse_boundary_row",
          "a sparse boundary row must carry positive recorded mass",
          child_pointer(row_path, "mass"));
    }
    sum = add_enclosures(sum, mass.value());
    previous = &row.backlog_level;
  }

  Result<void> balance = validate_mass_balance(
      law.mass_balance, sum, ExactRational::one(), representation,
      child_pointer(path, "mass_balance"), limits);
  if (!balance) {
    return Result<ExactEnclosure>::failure(balance.error());
  }
  return Result<ExactEnclosure>::success(std::move(sum));
}

[[nodiscard]] Result<ExactEnclosure> validate_gap_cell(
    const ObservationGapCellV1& gap, const ExactEnclosure& exposure,
    const ExactEnclosure& served, const BigNat& level,
    const ConstructionObservationBundleV1& bundle,
    const std::string& path, const ObservationParseLimitsV1& limits) {
  const auto representation = bundle.scalar_representation;
  Result<ExactEnclosure> negative = validate_nonnegative_scalar(
      gap.negative_mass, representation,
      child_pointer(path, "negative_mass"), limits);
  Result<ExactEnclosure> tie = validate_nonnegative_scalar(
      gap.tie_mass, representation, child_pointer(path, "tie_mass"), limits);
  Result<ExactEnclosure> positive = validate_nonnegative_scalar(
      gap.positive_mass, representation,
      child_pointer(path, "positive_mass"), limits);
  Result<ExactEnclosure> tied_served = validate_nonnegative_scalar(
      gap.tied_and_served_mass, representation,
      child_pointer(path, "tied_and_served_mass"), limits);
  Result<ExactEnclosure> positive_magnitude = validate_nonnegative_scalar(
      gap.positive_magnitude_mass, representation,
      child_pointer(path, "positive_magnitude_mass"), limits);
  Result<ExactEnclosure> negative_magnitude = validate_nonnegative_scalar(
      gap.negative_magnitude_mass, representation,
      child_pointer(path, "negative_magnitude_mass"), limits);
  const std::array<const Result<ExactEnclosure>*, 6U> results{
      &negative, &tie, &positive, &tied_served, &positive_magnitude,
      &negative_magnitude};
  for (const Result<ExactEnclosure>* result : results) {
    if (!*result) {
      return Result<ExactEnclosure>::failure(result->error());
    }
  }

  const auto exact_zero = [](const ExactEnclosure& value) {
    return value.center.is_zero() && value.radius.is_zero();
  };
  if (exact_zero(positive.value()) &&
      !encloses_zero(positive_magnitude.value())) {
    return validation_failure<ExactEnclosure>(
        "observation_positive_gap_magnitude_without_sign_mass",
        "an exactly zero positive-gap sign mass requires its accumulated "
        "positive magnitude to enclose zero",
        child_pointer(path, "positive_magnitude_mass"));
  }
  if (exact_zero(negative.value()) &&
      !encloses_zero(negative_magnitude.value())) {
    return validation_failure<ExactEnclosure>(
        "observation_negative_gap_magnitude_without_sign_mass",
        "an exactly zero negative-gap sign mass requires its accumulated "
        "negative magnitude to enclose zero",
        child_pointer(path, "negative_magnitude_mass"));
  }

  if (bundle.capabilities.exact_primary_maxweight.available &&
      bundle.capabilities.unit_target_multiplier.available) {
    // A positive target gap at backlog n is at most n.  Use compatibility of
    // the declared enclosures rather than comparing centers.  There is no
    // corresponding magnitude >= sign-mass check: unit_target_multiplier
    // certifies only the selected target, and rational competitor multipliers
    // can produce a strict exact gap in (0,1).
    const ExactRational level_factor =
        std::move(ExactRational::make(level.value(), BigInt{1})).value();
    const ExactEnclosure maximum_positive_magnitude{
        positive.value().center * level_factor,
        positive.value().radius * level_factor};
    if (!enclosed_less_equal(positive_magnitude.value(),
                             maximum_positive_magnitude)) {
      return validation_failure<ExactEnclosure>(
          "observation_positive_gap_magnitude_above_backlog_bound",
          "a certified positive target gap cannot exceed target backlog "
          "times positive sign mass",
          child_pointer(path, "positive_magnitude_mass"));
    }
  }

  const ExactEnclosure partition = add_enclosures(
      add_enclosures(negative.value(), tie.value()), positive.value());
  if (!enclosures_can_be_equal(partition, exposure)) {
    return validation_failure<ExactEnclosure>(
        "observation_gap_partition_mismatch",
        "negative, tie and positive gap masses do not partition exposure",
        path);
  }
  if (!enclosed_less_equal(tied_served.value(), tie.value())) {
    return validation_failure<ExactEnclosure>(
        "observation_tied_service_exceeds_ties",
        "tied-and-served mass cannot exceed tie mass",
        child_pointer(path, "tied_and_served_mass"));
  }
  if (!level.is_zero() &&
      bundle.capabilities.exact_primary_maxweight.available &&
      bundle.capabilities.unit_target_multiplier.available) {
    const ExactEnclosure reconstructed =
        add_enclosures(positive.value(), tied_served.value());
    if (!enclosures_can_be_equal(reconstructed, served)) {
      return validation_failure<ExactEnclosure>(
          "observation_gap_service_reconstruction_mismatch",
          "at positive backlog an exact primary MaxWeight gap requires "
          "served mass to equal positive-gap plus tied-and-served mass",
          path);
    }
  }
  return Result<ExactEnclosure>::success(partition);
}

[[nodiscard]] Result<ExactEnclosure> validate_levels(
    const ConstructionObservationBlockV1& block,
    const ConstructionObservationBundleV1& bundle,
    const std::string& path, const ObservationParseLimitsV1& limits,
    std::size_t& level_row_count) {
  if (!checked_increment(level_row_count, block.levels.size(),
                         limits.maximum_total_level_rows)) {
    return validation_failure<ExactEnclosure>(
        "observation_level_row_limit",
        "the observation exceeds the total exact-level row cap",
        child_pointer(path, "levels"), DiagnosticCategory::resource_limit);
  }

  const bool require_gap = bundle.capabilities.certified_gap_probe.available;
  ExactEnclosure exposure_sum{ExactRational::zero(), ExactRational::zero()};
  const BigNat* previous = nullptr;
  for (std::size_t index = 0U; index < block.levels.size(); ++index) {
    const ExactLevelObservationV1& row = block.levels[index];
    const std::string row_path =
        index_pointer(child_pointer(path, "levels"), index);
    if (row.backlog_level.bit_length() > limits.maximum_integer_bits) {
      return validation_failure<ExactEnclosure>(
          "observation_integer_bit_limit",
          "an exact backlog level exceeds the configured bit cap",
          child_pointer(row_path, "backlog_level"),
          DiagnosticCategory::resource_limit);
    }
    if (previous != nullptr && !(*previous < row.backlog_level)) {
      return validation_failure<ExactEnclosure>(
          "observation_unsorted_level_rows",
          "exact-level rows must have strictly increasing unique backlog "
          "levels",
          child_pointer(row_path, "backlog_level"));
    }
    Result<ExactEnclosure> exposure = validate_nonnegative_scalar(
        row.exposure_mass, bundle.scalar_representation,
        child_pointer(row_path, "exposure_mass"), limits);
    if (!exposure) {
      return exposure;
    }
    if (!exposure.value().center.is_positive()) {
      return validation_failure<ExactEnclosure>(
          "observation_zero_sparse_level_row",
          "a sparse exact-level row must carry positive recorded exposure",
          child_pointer(row_path, "exposure_mass"));
    }
    Result<ExactEnclosure> served = validate_nonnegative_scalar(
        row.served_mass, bundle.scalar_representation,
        child_pointer(row_path, "served_mass"), limits);
    if (!served) {
      return served;
    }
    if (!enclosed_less_equal(served.value(), exposure.value())) {
      return validation_failure<ExactEnclosure>(
          "observation_served_exceeds_exposure",
          "served mass cannot exceed exposure mass",
          child_pointer(row_path, "served_mass"));
    }
    if (row.backlog_level.is_zero() && !encloses_zero(served.value())) {
      return validation_failure<ExactEnclosure>(
          "observation_service_at_zero_backlog",
          "actual departure mass at zero backlog must enclose zero",
          child_pointer(row_path, "served_mass"));
    }
    if (row.gap.has_value() != require_gap) {
      return validation_failure<ExactEnclosure>(
          "observation_gap_presence_mismatch",
          "gap cells must be present exactly when a certified gap probe is "
          "available",
          child_pointer(row_path, "gap"));
    }
    if (row.gap.has_value()) {
      Result<ExactEnclosure> gap = validate_gap_cell(
          *row.gap, exposure.value(), served.value(), row.backlog_level, bundle,
          child_pointer(row_path, "gap"), limits);
      if (!gap) {
        return gap;
      }
    }
    exposure_sum = add_enclosures(exposure_sum, exposure.value());
    previous = &row.backlog_level;
  }
  return Result<ExactEnclosure>::success(std::move(exposure_sum));
}

[[nodiscard]] Result<void> validate_block(
    const ConstructionObservationBlockV1& block,
    const ConstructionObservationBundleV1& bundle,
    const std::uint64_t expected_begin, const std::uint64_t expected_end,
    const bool must_be_last, const std::string& path,
    const ObservationParseLimitsV1& limits, std::size_t& level_row_count,
    std::size_t& boundary_row_count) {
  if (block.begin_boundary != expected_begin ||
      block.end_boundary != expected_end ||
      block.begin_boundary >= block.end_boundary) {
    return validation_failure<void>(
        "observation_block_plan_mismatch",
        "a block must match the next ordered requested reporting interval",
        path);
  }
  if (block.committed_through_boundary < block.begin_boundary ||
      block.committed_through_boundary > block.end_boundary) {
    return validation_failure<void>(
        "observation_block_commit_range",
        "a block's committed boundary must lie in its requested interval",
        child_pointer(path, "committed_through_boundary"));
  }
  if (block.completeness == ObservationCompletenessV1::complete) {
    if (block.committed_through_boundary != block.end_boundary) {
      return validation_failure<void>(
          "observation_false_complete_block",
          "a complete block must commit through its requested end boundary",
          path);
    }
  } else {
    if (block.committed_through_boundary == block.end_boundary ||
        !must_be_last) {
      return validation_failure<void>(
          "observation_invalid_partial_block",
          "only the final block may be partial and it must stop before its "
          "requested end boundary",
          path);
    }
  }
  if (block.initial_boundary_law.boundary != block.begin_boundary ||
      block.committed_boundary_law.boundary !=
          block.committed_through_boundary) {
    return validation_failure<void>(
        "observation_boundary_phase_mismatch",
        "block boundary laws must be recorded at begin and actual committed "
        "boundaries",
        path);
  }

  Result<ExactEnclosure> exposure = validate_levels(
      block, bundle, path, limits, level_row_count);
  if (!exposure) {
    return Result<void>::failure(exposure.error());
  }
  const std::uint64_t observed_slots =
      block.committed_through_boundary - block.begin_boundary;
  if (observed_slots == 0U &&
      !(block.initial_boundary_law == block.committed_boundary_law)) {
    return validation_failure<void>(
        "observation_zero_length_boundary_mismatch",
        "a zero-length committed prefix must repeat the identical boundary "
        "law",
        child_pointer(path, "committed_boundary_law"));
  }
  if (observed_slots != 0U && block.levels.empty()) {
    return validation_failure<void>(
        "observation_missing_level_rows",
        "a nonempty committed block cannot omit all exact-level rows",
        child_pointer(path, "levels"));
  }
  auto expected_mass = ExactRational::make(BigInt(observed_slots), BigInt(1));
  if (!expected_mass) {
    return validation_failure<void>(
        "observation_block_length_conversion",
        "a block length could not be represented exactly", path,
        DiagnosticCategory::internal);
  }
  Result<void> exposure_balance = validate_mass_balance(
      block.exposure_mass_balance, exposure.value(), expected_mass.value(),
      bundle.scalar_representation,
      child_pointer(path, "exposure_mass_balance"), limits);
  if (!exposure_balance) {
    return exposure_balance;
  }
  Result<ExactEnclosure> initial = validate_boundary_law(
      block.initial_boundary_law, bundle.scalar_representation,
      child_pointer(path, "initial_boundary_law"), limits,
      boundary_row_count);
  if (!initial) {
    return Result<void>::failure(initial.error());
  }
  Result<ExactEnclosure> committed = validate_boundary_law(
      block.committed_boundary_law, bundle.scalar_representation,
      child_pointer(path, "committed_boundary_law"), limits,
      boundary_row_count);
  if (!committed) {
    return Result<void>::failure(committed.error());
  }
  if (bundle.source_role != ObservationSourceRoleV1::weighted_ensemble &&
      (block.exposure_mass_balance.claim !=
           ObservationNormalizationClaimV1::exact ||
       block.initial_boundary_law.mass_balance.claim !=
           ObservationNormalizationClaimV1::exact ||
       block.committed_boundary_law.mass_balance.claim !=
           ObservationNormalizationClaimV1::exact)) {
    return validation_failure<void>(
        "observation_reference_normalization_claim",
        "ordinary trajectory blocks and boundary laws must claim exact "
        "normalization",
        path);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_replication(
    const ConstructionObservationReplicationV1& replication,
    const ConstructionObservationBundleV1& bundle, const std::string& path,
    const ObservationParseLimitsV1& limits, std::size_t& block_count,
    std::size_t& level_row_count, std::size_t& boundary_row_count) {
  if (!checked_increment(block_count, replication.blocks.size(),
                         limits.maximum_total_blocks)) {
    return validation_failure<void>(
        "observation_block_limit",
        "the observation exceeds the total block cap",
        child_pointer(path, "blocks"), DiagnosticCategory::resource_limit);
  }
  Result<void> replication_id = validate_typed_label_bounds(
      replication.replication_id, child_pointer(path, "replication_id"),
      limits);
  if (!replication_id) {
    return replication_id;
  }
  if (bundle.source_role == ObservationSourceRoleV1::weighted_ensemble) {
    if (!replication.lineage_arrival_identity.has_value()) {
      return validation_failure<void>(
          "observation_lineage_identity_required",
          "a weighted-ensemble replication requires a lineage-arrival "
          "identity",
          child_pointer(path, "lineage_arrival_identity"));
    }
  } else if (replication.lineage_arrival_identity.has_value()) {
    return validation_failure<void>(
        "observation_lineage_identity_forbidden",
        "an ordinary reference replication must not claim a particle-lineage "
        "arrival identity",
        child_pointer(path, "lineage_arrival_identity"));
  }

  if (replication.completeness == ObservationCompletenessV1::complete) {
    if (replication.committed_through_boundary != bundle.end_boundary ||
        replication.blocks.size() !=
            bundle.reporting_block_boundaries.size() - 1U) {
      return validation_failure<void>(
          "observation_false_complete_replication",
          "a complete replication must contain the complete requested block "
          "plan and commit through T",
          path);
    }
  } else if (replication.committed_through_boundary < bundle.warmup_boundary ||
             replication.committed_through_boundary >= bundle.end_boundary) {
    return validation_failure<void>(
        "observation_partial_replication_boundary",
        "a partial replication must stop in [W,T)",
        child_pointer(path, "committed_through_boundary"));
  }

  if (replication.blocks.empty()) {
    if (replication.completeness != ObservationCompletenessV1::partial ||
        replication.committed_through_boundary != bundle.warmup_boundary) {
      return validation_failure<void>(
          "observation_empty_replication",
          "only a partial replication stopped exactly at W may have no "
          "committed blocks",
          child_pointer(path, "blocks"));
    }
    return Result<void>::success();
  }

  if (replication.blocks.size() >=
      bundle.reporting_block_boundaries.size()) {
    return validation_failure<void>(
        "observation_block_plan_overrun",
        "a replication contains more blocks than the requested block plan",
        child_pointer(path, "blocks"));
  }
  for (std::size_t index = 0U; index < replication.blocks.size(); ++index) {
    const ConstructionObservationBlockV1& block = replication.blocks[index];
    const bool final = index + 1U == replication.blocks.size();
    const std::string block_path =
        index_pointer(child_pointer(path, "blocks"), index);
    Result<void> valid = validate_block(
        block, bundle, bundle.reporting_block_boundaries[index],
        bundle.reporting_block_boundaries[index + 1U], final, block_path,
        limits, level_row_count, boundary_row_count);
    if (!valid) {
      return valid;
    }
    if (!final) {
      if (block.completeness != ObservationCompletenessV1::complete) {
        return validation_failure<void>(
            "observation_partial_block_not_final",
            "a partial observation block must be the final block",
            block_path);
      }
      if (!(block.committed_boundary_law ==
            replication.blocks[index + 1U].initial_boundary_law)) {
        return validation_failure<void>(
            "observation_adjacent_boundary_mismatch",
            "adjacent block endpoint laws must be byte/representation equal",
            child_pointer(block_path, "committed_boundary_law"));
      }
    }
  }
  const ConstructionObservationBlockV1& final = replication.blocks.back();
  if (replication.committed_through_boundary !=
      final.committed_through_boundary) {
    return validation_failure<void>(
        "observation_replication_commit_mismatch",
        "the replication committed boundary must equal its final block's "
        "committed boundary",
        child_pointer(path, "committed_through_boundary"));
  }
  if (replication.completeness == ObservationCompletenessV1::partial &&
      final.completeness == ObservationCompletenessV1::complete &&
      replication.blocks.size() ==
          bundle.reporting_block_boundaries.size() - 1U) {
    return validation_failure<void>(
        "observation_false_partial_replication",
        "a replication that completed the full block plan cannot be marked "
        "partial",
        path);
  }
  return Result<void>::success();
}

[[nodiscard]] Result<void> validate_bundle_semantics(
    const ConstructionObservationBundleV1& bundle,
    const ObservationParseLimitsV1& limits) {
  if (bundle.schema_version != 1U) {
    return validation_failure<void>(
        "observation_schema_version",
        "ConstructionObservationBundleV1 requires schema_version 1",
        "/observation_bundle/schema_version");
  }
  if (bundle.warmup_boundary >= bundle.end_boundary) {
    return validation_failure<void>(
        "observation_invalid_window", "the observation window requires W<T",
        "/observation_bundle/end_boundary");
  }
  Result<void> boundary_cap = require_size_at_most(
      bundle.reporting_block_boundaries.size(),
      limits.maximum_reporting_boundaries,
      "observation_reporting_boundary_limit",
      "the requested reporting-boundary plan exceeds its cap",
      "/observation_bundle/reporting_block_boundaries");
  if (!boundary_cap) {
    return boundary_cap;
  }
  if (bundle.reporting_block_boundaries.size() < 2U ||
      bundle.reporting_block_boundaries.front() != bundle.warmup_boundary ||
      bundle.reporting_block_boundaries.back() != bundle.end_boundary) {
    return validation_failure<void>(
        "observation_invalid_block_plan",
        "reporting boundaries must be strictly increasing and start at W and "
        "end at T",
        "/observation_bundle/reporting_block_boundaries");
  }
  for (std::size_t index = 1U;
       index < bundle.reporting_block_boundaries.size(); ++index) {
    if (bundle.reporting_block_boundaries[index - 1U] >=
        bundle.reporting_block_boundaries[index]) {
      return validation_failure<void>(
          "observation_invalid_block_plan",
          "reporting boundaries must be strictly increasing and unique",
          index_pointer("/observation_bundle/reporting_block_boundaries",
                        index));
    }
  }

  Result<void> replication_cap = require_size_at_most(
      bundle.replications.size(), limits.maximum_replications,
      "observation_replication_limit",
      "the observation exceeds the replication cap",
      "/observation_bundle/replications");
  if (!replication_cap) {
    return replication_cap;
  }
  if (bundle.replications.empty()) {
    return validation_failure<void>(
        "observation_empty_replication_set",
        "an observation bundle requires at least one independent replication",
        "/observation_bundle/replications");
  }

  Result<void> initial_id = validate_identifier(
      bundle.initialization.initial_law_id,
      "/observation_bundle/initialization/initial_law_id", limits);
  if (!initial_id) {
    return initial_id;
  }
  Result<void> rng_id = validate_identifier(
      bundle.rng.rng_abi_id, "/observation_bundle/rng/rng_abi_id", limits);
  if (!rng_id) {
    return rng_id;
  }
  Result<void> target_id = validate_typed_label_bounds(
      bundle.bindings.target.target_id.label(),
      "/observation_bundle/bindings/target/target_id", limits);
  if (!target_id) {
    return target_id;
  }
  if (bundle.rng.rng_abi_version == 0U) {
    return validation_failure<void>(
        "observation_invalid_rng_abi_version",
        "the RNG ABI version must be positive",
        "/observation_bundle/rng/rng_abi_version");
  }
  if (!bundle.bindings.target.maxweight_multiplier.is_positive()) {
    return validation_failure<void>(
        "observation_invalid_target_multiplier",
        "the target MaxWeight multiplier must be positive",
        "/observation_bundle/bindings/target/maxweight_multiplier");
  }
  Result<void> multiplier_bounded = validate_exact_rational_bounds(
      bundle.bindings.target.maxweight_multiplier,
      "/observation_bundle/bindings/target/maxweight_multiplier", limits);
  if (!multiplier_bounded) {
    return multiplier_bounded;
  }
  Result<void> arrival = validate_arrival(
      bundle.bindings.arrival, "/observation_bundle/bindings/arrival", limits);
  if (!arrival) {
    return arrival;
  }
  Result<void> capabilities = validate_all_capabilities(
      bundle.capabilities, bundle.bindings,
      "/observation_bundle/capabilities", limits);
  if (!capabilities) {
    return capabilities;
  }
  if (bundle.capabilities.finite_arrival_second_moment.available) {
    const ExactRational& mean = bundle.bindings.arrival.mean;
    const ExactRational& second = bundle.bindings.arrival.second_moment;
    if (second < mean || second < mean * mean) {
      return validation_failure<void>(
          "observation_invalid_arrival_moments",
          "a nonnegative integer arrival with an available second moment "
          "requires m2 >= lambda and m2 >= lambda^2",
          "/observation_bundle/bindings/arrival/second_moment");
    }
  }
  Result<void> timing = validate_slot_order(bundle);
  if (!timing) {
    return timing;
  }
  if (bundle.source_role != ObservationSourceRoleV1::weighted_ensemble &&
      bundle.scalar_representation !=
          ObservationScalarRepresentationV1::exact_rational) {
    return validation_failure<void>(
        "observation_reference_scalar_contract",
        "ordinary reference observations must retain exact rational/count "
        "masses",
        "/observation_bundle/scalar_representation");
  }

  std::size_t block_count = 0U;
  std::size_t level_row_count = 0U;
  std::size_t boundary_row_count = 0U;
  std::vector<Digest256> replay_identities;
  replay_identities.reserve(bundle.replications.size());
  for (std::size_t index = 0U; index < bundle.replications.size(); ++index) {
    const ConstructionObservationReplicationV1& replication =
        bundle.replications[index];
    if (index != 0U &&
        !(bundle.replications[index - 1U].replication_id <
          replication.replication_id)) {
      return validation_failure<void>(
          "observation_unsorted_replication_ids",
          "independent replication IDs must be strictly increasing and "
          "unique",
          child_pointer(index_pointer("/observation_bundle/replications",
                                      index),
                        "replication_id"));
    }
    replay_identities.push_back(replication.replay_identity);
    Result<void> valid = validate_replication(
        replication, bundle,
        index_pointer("/observation_bundle/replications", index), limits,
        block_count, level_row_count, boundary_row_count);
    if (!valid) {
      return valid;
    }
  }
  std::ranges::sort(replay_identities);
  if (std::ranges::adjacent_find(replay_identities) !=
      replay_identities.end()) {
    return validation_failure<void>(
        "observation_duplicate_replay_identity",
        "independent replications must have distinct replay identities",
        "/observation_bundle/replications");
  }
  return Result<void>::success();
}

}  // namespace

Result<ValidatedConstructionObservationBundleV1>
validate_construction_observation_envelope_v1(
    ConstructionObservationEnvelopeV1 envelope,
    const ObservationParseLimitsV1& limits) {
  Result<std::vector<std::byte>> canonical =
      canonical_construction_observation_envelope_bytes_v1(envelope);
  if (!canonical) {
    return Result<ValidatedConstructionObservationBundleV1>::failure(
        canonical.error());
  }
  if (canonical.value().size() > limits.maximum_bytes) {
    return validation_failure<ValidatedConstructionObservationBundleV1>(
        "observation_encoded_bytes_limit",
        "the canonical observation envelope exceeds the configured byte cap",
        "", DiagnosticCategory::resource_limit);
  }

  Result<Digest256> recomputed = construction_observation_bundle_digest_v1(
      envelope.observation_bundle);
  if (!recomputed) {
    return Result<ValidatedConstructionObservationBundleV1>::failure(
        recomputed.error());
  }
  if (recomputed.value() != envelope.observation_bundle_digest) {
    return validation_failure<ValidatedConstructionObservationBundleV1>(
        "observation_bundle_digest_mismatch",
        "the observation bundle digest does not authenticate the canonical "
        "body",
        "/observation_bundle_digest");
  }

  Result<void> semantics =
      validate_bundle_semantics(envelope.observation_bundle, limits);
  if (!semantics) {
    return Result<ValidatedConstructionObservationBundleV1>::failure(
        semantics.error());
  }
  return Result<ValidatedConstructionObservationBundleV1>::success(
      ValidatedConstructionObservationBundleV1(
          std::move(envelope.observation_bundle),
          std::move(envelope.observation_bundle_digest)));
}

}  // namespace mwperf
