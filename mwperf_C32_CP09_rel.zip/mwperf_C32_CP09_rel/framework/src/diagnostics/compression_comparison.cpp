#include "mwperf/diagnostics/compression_comparison.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <optional>
#include <string>
#include <utility>

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic(std::string code, std::string message) {
  return Diagnostic{DiagnosticCategory::input_validation, std::move(code),
                    std::move(message), std::nullopt, std::nullopt, {}};
}

template <typename Code>
void append_unique(std::vector<Code>& values, const Code value) {
  if (std::find(values.begin(), values.end(), value) == values.end()) {
    values.push_back(value);
  }
}

void add_reason(CompressionMetricStatusV1& status,
                const CompressionUnavailableReasonV1 reason) {
  append_unique(status.unavailable_reasons, reason);
}

void add_warning(CompressionMetricStatusV1& status,
                 const CompressionWarningCodeV1 warning) {
  append_unique(status.warnings, warning);
}

void merge_status(CompressionMetricStatusV1& destination,
                  const CompressionMetricStatusV1& source) {
  for (const auto reason : source.unavailable_reasons) {
    add_reason(destination, reason);
  }
  for (const auto warning : source.warnings) {
    add_warning(destination, warning);
  }
}

[[nodiscard]] CompressionQuantityV1 available(
    CompressionNumericalValueV1 value) {
  CompressionMetricStatusV1 status;
  if (!value.absolute_error_bound.is_zero()) {
    add_warning(status,
                CompressionWarningCodeV1::numerical_enclosure_required);
  }
  return CompressionQuantityV1{std::move(value), std::move(status)};
}

[[nodiscard]] CompressionQuantityV1 exact_value(ExactRational value) {
  return available(CompressionNumericalValueV1{
      std::move(value), ExactRational::zero()});
}

[[nodiscard]] ExactRational count_rational(const std::uint64_t value) {
  return std::move(ExactRational::make(BigInt{value}, BigInt{1})).value();
}

[[nodiscard]] CompressionQuantityV1 unavailable(
    const CompressionUnavailableReasonV1 reason) {
  CompressionMetricStatusV1 status;
  add_reason(status, reason);
  return CompressionQuantityV1{std::nullopt, std::move(status)};
}

[[nodiscard]] CompressionNumericalValueV1 add_values(
    const CompressionNumericalValueV1& left,
    const CompressionNumericalValueV1& right) {
  return CompressionNumericalValueV1{
      left.value + right.value,
      left.absolute_error_bound + right.absolute_error_bound};
}

[[nodiscard]] CompressionNumericalValueV1 subtract_values(
    const CompressionNumericalValueV1& left,
    const CompressionNumericalValueV1& right) {
  return CompressionNumericalValueV1{
      left.value - right.value,
      left.absolute_error_bound + right.absolute_error_bound};
}

[[nodiscard]] CompressionQuantityV1 add_quantities(
    const CompressionQuantityV1& left, const CompressionQuantityV1& right) {
  if (!left.available() || !right.available()) {
    CompressionMetricStatusV1 status;
    merge_status(status, left.status);
    merge_status(status, right.status);
    add_reason(status,
               CompressionUnavailableReasonV1::intermediate_fit_unavailable);
    return CompressionQuantityV1{std::nullopt, std::move(status)};
  }
  return available(add_values(*left.estimate, *right.estimate));
}

[[nodiscard]] CompressionQuantityV1 subtract_quantities(
    const CompressionQuantityV1& left, const CompressionQuantityV1& right) {
  if (!left.available() || !right.available()) {
    CompressionMetricStatusV1 status;
    merge_status(status, left.status);
    merge_status(status, right.status);
    add_reason(status,
               CompressionUnavailableReasonV1::intermediate_fit_unavailable);
    return CompressionQuantityV1{std::nullopt, std::move(status)};
  }
  return available(subtract_values(*left.estimate, *right.estimate));
}

[[nodiscard]] CompressionQuantityV1 fit_mean(
    const CompressionCutoffAnalysisV1& cutoff) {
  return cutoff.diagnostic_fitted_mean;
}

[[nodiscard]] CompressionQuantityV1 transformed_fit_mean(
    const DecoderTransformedFitPointV1* cutoff,
    const bool contract_matches) {
  if (!contract_matches || cutoff == nullptr || !cutoff->fit ||
      !cutoff->fit->fitted_mean_backlog) {
    return unavailable(
        CompressionUnavailableReasonV1::transformed_profile_unavailable);
  }
  return exact_value(*cutoff->fit->fitted_mean_backlog);
}

[[nodiscard]] bool transformed_point_contract_matches(
    const DecoderTransformedFitPointV1* point,
    const DecoderTransformedProfileV1& profile,
    const CompressionAnalysisResultV1& weighted_ensemble) {
  if (point == nullptr || point->fit.has_value() ==
                              point->fit_failure.has_value()) {
    return false;
  }
  if (!point->fit) {
    // A typed fit failure is a structurally valid row; its transformed mean is
    // unavailable below without invalidating the independent three-term sum.
    return true;
  }
  const FinitePrefixFitResultV1& fit = *point->fit;
  return !fit.consumed_service_by_level.empty() &&
         point->cutoff.value() ==
             BigInt{static_cast<std::uint64_t>(
                 fit.consumed_service_by_level.size() - 1U)} &&
         fit.binding.coefficient_source_digest ==
             profile.provider_result_digest &&
         fit.binding.arrival_law_digest ==
             weighted_ensemble.bindings.arrival.configured_law_digest;
}

[[nodiscard]] CompressionQuantityV1 observed_mean(
    const CompressionAnalysisResultV1& analysis) {
  return analysis.pooled.observed_mean;
}

[[nodiscard]] bool canonical_late_arrival_order(
    const CompressionAnalysisResultV1& analysis) {
  static constexpr std::array<ObservationSlotStageV1, 6U> direct{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service,
      ObservationSlotStageV1::apply_fresh_late_arrival,
      ObservationSlotStageV1::commit_post_slot_state,
      ObservationSlotStageV1::emit_committed_observation};
  static constexpr std::array<ObservationSlotStageV1, 8U> weighted{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service,
      ObservationSlotStageV1::classify_and_resample,
      ObservationSlotStageV1::allocate_child_lineage,
      ObservationSlotStageV1::apply_fresh_late_arrival,
      ObservationSlotStageV1::commit_post_slot_state,
      ObservationSlotStageV1::emit_committed_observation};
  if (analysis.source_role == ObservationSourceRoleV1::weighted_ensemble) {
    return analysis.slot_convention.step_order.size() == weighted.size() &&
           std::equal(analysis.slot_convention.step_order.begin(),
                      analysis.slot_convention.step_order.end(),
                      weighted.begin());
  }
  return analysis.slot_convention.step_order.size() == direct.size() &&
         std::equal(analysis.slot_convention.step_order.begin(),
                    analysis.slot_convention.step_order.end(), direct.begin());
}

[[nodiscard]] bool scientific_context_matches(
    const CompressionAnalysisResultV1& left,
    const CompressionAnalysisResultV1& right) {
  const auto& a = left.bindings;
  const auto& b = right.bindings;
  return a.problem_digest == b.problem_digest &&
         a.experiment_digest == b.experiment_digest &&
         a.target == b.target && a.arrival == b.arrival &&
         a.topology_digest == b.topology_digest &&
         a.scheduler_digest == b.scheduler_digest &&
         a.optimizer_digest == b.optimizer_digest &&
         a.primary_objective_digest == b.primary_objective_digest &&
         a.priority_digest == b.priority_digest &&
         a.tie_policy_digest == b.tie_policy_digest &&
         left.slot_convention.convention_digest ==
             right.slot_convention.convention_digest &&
         canonical_late_arrival_order(left) &&
         canonical_late_arrival_order(right);
}

[[nodiscard]] const CompressionCutoffAnalysisV1* find_cutoff(
    const CompressionAnalysisResultV1& analysis, const BigNat& cutoff) {
  const auto found = std::lower_bound(
      analysis.cutoffs.begin(), analysis.cutoffs.end(), cutoff,
      [](const CompressionCutoffAnalysisV1& row, const BigNat& wanted) {
        return row.cutoff < wanted;
      });
  return found != analysis.cutoffs.end() && found->cutoff == cutoff
             ? &*found
             : nullptr;
}

[[nodiscard]] const DecoderTransformedFitPointV1* find_transformed_cutoff(
    const DecoderTransformedProfileV1& profile, const BigNat& cutoff) {
  const auto found = std::lower_bound(
      profile.cutoffs.begin(), profile.cutoffs.end(), cutoff,
      [](const DecoderTransformedFitPointV1& row, const BigNat& wanted) {
        return row.cutoff < wanted;
      });
  return found != profile.cutoffs.end() && found->cutoff == cutoff
             ? &*found
             : nullptr;
}

[[nodiscard]] CompressionQuantityV1 squared_error(
    const std::optional<CompressionCutoffJackknifeV1>& jackknife,
    const bool prediction_error) {
  if (!jackknife) {
    return unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
  }
  return prediction_error
             ? jackknife->fitted_minus_observed_mean.squared_standard_error
             : jackknife->fitted_mean.squared_standard_error;
}

[[nodiscard]] CompressionQuantityV1 transformed_squared_error(
    const DecoderTransformedFitPointV1* point,
    const bool contract_matches) {
  if (!contract_matches || point == nullptr || !point->fit ||
      !point->fit->fitted_mean_backlog ||
      !point->transformation_jackknife) {
    return unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
  }
  return point->transformation_jackknife->squared_standard_error;
}

[[nodiscard]] bool add_fit_resample_counts(
    FitResampleCountsV1& destination, const FitResampleCountsV1* source) {
  if (source == nullptr) {
    return false;
  }
  const auto add = [](std::uint64_t& output, const std::uint64_t value) {
    if (value > std::numeric_limits<std::uint64_t>::max() - output) {
      return false;
    }
    output += value;
    return true;
  };
  return add(destination.eligible_fit_resamples,
             source->eligible_fit_resamples) &&
         add(destination.failed_fit_resamples,
             source->failed_fit_resamples) &&
         add(destination.unavailable_fit_resamples,
             source->unavailable_fit_resamples) &&
         add(destination.unavailable_estimate_resamples,
             source->unavailable_estimate_resamples);
}

[[nodiscard]] std::optional<FitResampleCountsV1> aggregate_fit_resamples(
    const CompressionCutoffAnalysisV1& stationary,
    const CompressionCutoffAnalysisV1& finite_window,
    const CompressionCutoffAnalysisV1& ensemble) {
  FitResampleCountsV1 result{};
  bool complete = add_fit_resample_counts(
      result, stationary.jackknife
                  ? &stationary.jackknife->fit_resamples
                  : nullptr);
  complete = add_fit_resample_counts(
                 result, finite_window.jackknife
                             ? &finite_window.jackknife->fit_resamples
                             : nullptr) &&
             complete;
  complete = add_fit_resample_counts(
                 result, ensemble.jackknife
                             ? &ensemble.jackknife->fit_resamples
                             : nullptr) &&
             complete;
  return complete ? std::optional<FitResampleCountsV1>(result)
                  : std::nullopt;
}

[[nodiscard]] CompressionQuantityV1 fit_resample_failure_rate(
    const std::optional<FitResampleCountsV1>& counts) {
  if (!counts || counts->eligible_fit_resamples == 0U) {
    return unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
  }
  auto ratio = checked_divide(
      count_rational(counts->failed_fit_resamples),
      count_rational(counts->eligible_fit_resamples));
  return ratio ? exact_value(std::move(ratio).value())
               : unavailable(CompressionUnavailableReasonV1::
                                 insufficient_independent_replications);
}

[[nodiscard]] ErrorSeparationCutoffV1 unavailable_row(
    const BigNat& cutoff, const CompressionUnavailableReasonV1 reason,
    const bool transformation_zero) {
  const auto missing = [reason]() { return unavailable(reason); };
  ErrorSeparationUncertaintyV1 uncertainty{
      missing(), missing(), missing(), missing(), {}};
  add_reason(uncertainty.status, reason);
  CompressionMetricStatusV1 status;
  add_reason(status, reason);
  return ErrorSeparationCutoffV1{
      cutoff,
      missing(),
      missing(),
      missing(),
      transformation_zero ? exact_value(ExactRational::zero()) : missing(),
      missing(),
      missing(),
      missing(),
      missing(),
      missing(),
      missing(),
      missing(),
      {},
      missing(),
      std::move(uncertainty),
      transformation_zero,
      std::move(status)};
}

[[nodiscard]] bool strictly_sorted_unique(
    const std::vector<DecoderTransformedFitPointV1>& values) {
  for (std::size_t index = 1U; index < values.size(); ++index) {
    if (!(values[index - 1U].cutoff < values[index].cutoff)) {
      return false;
    }
  }
  return true;
}

}  // namespace

Result<ThreeRecordErrorSeparationV1> compare_compression_profiles_v1(
    const CompressionAnalysisResultV1& stationary_reference,
    const CompressionAnalysisResultV1& finite_window_reference,
    const CompressionAnalysisResultV1& weighted_ensemble,
    const CompressionComparisonOptionsV1& options) {
  if (options.decoder_consumed_empirical_profile_unchanged &&
      options.transformed_profile) {
    return Result<ThreeRecordErrorSeparationV1>::failure(diagnostic(
        "compression_comparison.ambiguous_transformation",
        "a comparison cannot declare the decoder profile unchanged and also "
        "supply a transformed profile"));
  }
  if (options.transformed_profile &&
      !strictly_sorted_unique(options.transformed_profile->cutoffs)) {
    return Result<ThreeRecordErrorSeparationV1>::failure(diagnostic(
        "compression_comparison.transformed_cutoffs_not_canonical",
        "transformed decoder cutoffs must be strictly increasing and unique"));
  }

  CompressionMetricStatusV1 overall_status;
  if (stationary_reference.source_role !=
          ObservationSourceRoleV1::long_stationary_reference ||
      finite_window_reference.source_role !=
          ObservationSourceRoleV1::short_restart_reference ||
      weighted_ensemble.source_role !=
          ObservationSourceRoleV1::weighted_ensemble) {
    add_reason(overall_status,
               CompressionUnavailableReasonV1::source_role_mismatch);
  }
  if (!scientific_context_matches(stationary_reference,
                                  finite_window_reference) ||
      !scientific_context_matches(stationary_reference, weighted_ensemble) ||
      stationary_reference.initialization !=
          finite_window_reference.initialization ||
      finite_window_reference.initialization != weighted_ensemble.initialization ||
      finite_window_reference.warmup_boundary !=
          weighted_ensemble.warmup_boundary ||
      finite_window_reference.end_boundary != weighted_ensemble.end_boundary) {
    add_reason(overall_status,
               CompressionUnavailableReasonV1::context_mismatch);
  }
  if (options.transformed_profile &&
      (options.transformed_profile->experiment_digest !=
           weighted_ensemble.bindings.experiment_digest ||
       options.transformed_profile->source_observation_digest !=
           weighted_ensemble.observation_digest ||
       options.transformed_profile->decoder_semantics_digest !=
           options.decoder_semantics_digest)) {
    add_reason(overall_status,
               CompressionUnavailableReasonV1::context_mismatch);
  }

  ThreeRecordErrorSeparationV1 result{
      stationary_reference.bindings.experiment_digest,
      options.decoder_semantics_digest,
      stationary_reference.observation_digest,
      finite_window_reference.observation_digest,
      weighted_ensemble.observation_digest,
      stationary_reference.analysis_digest,
      finite_window_reference.analysis_digest,
      weighted_ensemble.analysis_digest,
      options.transformed_profile
          ? std::optional<Digest256>(
                options.transformed_profile->provider_result_digest)
          : std::nullopt,
      {},
      overall_status};

  std::vector<BigNat> requested_cutoffs;
  requested_cutoffs.reserve(stationary_reference.cutoffs.size() +
                            finite_window_reference.cutoffs.size() +
                            weighted_ensemble.cutoffs.size() +
                            (options.transformed_profile
                                 ? options.transformed_profile->cutoffs.size()
                                 : 0U));
  for (const auto& row : stationary_reference.cutoffs) {
    requested_cutoffs.push_back(row.cutoff);
  }
  for (const auto& row : finite_window_reference.cutoffs) {
    requested_cutoffs.push_back(row.cutoff);
  }
  for (const auto& row : weighted_ensemble.cutoffs) {
    requested_cutoffs.push_back(row.cutoff);
  }
  if (options.transformed_profile) {
    for (const auto& row : options.transformed_profile->cutoffs) {
      requested_cutoffs.push_back(row.cutoff);
    }
  }
  std::sort(requested_cutoffs.begin(), requested_cutoffs.end());
  requested_cutoffs.erase(
      std::unique(requested_cutoffs.begin(), requested_cutoffs.end()),
      requested_cutoffs.end());

  for (const BigNat& cutoff : requested_cutoffs) {
    const CompressionCutoffAnalysisV1* stationary_cutoff =
        find_cutoff(stationary_reference, cutoff);
    const CompressionCutoffAnalysisV1* finite_cutoff =
        find_cutoff(finite_window_reference, cutoff);
    const CompressionCutoffAnalysisV1* ensemble_cutoff =
        find_cutoff(weighted_ensemble, cutoff);
    if (stationary_cutoff == nullptr || finite_cutoff == nullptr ||
        ensemble_cutoff == nullptr) {
      result.cutoffs.push_back(unavailable_row(
          cutoff,
          CompressionUnavailableReasonV1::intermediate_fit_unavailable,
          options.decoder_consumed_empirical_profile_unchanged));
      continue;
    }
    const DecoderTransformedFitPointV1* transformed_cutoff =
        options.transformed_profile
            ? find_transformed_cutoff(*options.transformed_profile,
                                      cutoff)
            : nullptr;
    const bool transformation_zero =
        options.decoder_consumed_empirical_profile_unchanged;
    const bool transformed_contract_matches =
        !options.transformed_profile ||
        transformed_point_contract_matches(
            transformed_cutoff, *options.transformed_profile,
            weighted_ensemble);
    if (!overall_status.available()) {
      const auto reason =
          std::find(overall_status.unavailable_reasons.begin(),
                    overall_status.unavailable_reasons.end(),
                    CompressionUnavailableReasonV1::source_role_mismatch) !=
                  overall_status.unavailable_reasons.end()
              ? CompressionUnavailableReasonV1::source_role_mismatch
              : CompressionUnavailableReasonV1::context_mismatch;
      result.cutoffs.push_back(unavailable_row(
          cutoff, reason, transformation_zero));
      continue;
    }

    const CompressionQuantityV1 stationary_fit = fit_mean(*stationary_cutoff);
    const CompressionQuantityV1 finite_fit = fit_mean(*finite_cutoff);
    const CompressionQuantityV1 ensemble_fit = fit_mean(*ensemble_cutoff);
    const CompressionQuantityV1 stationary_mean_value =
        observed_mean(stationary_reference);

    CompressionQuantityV1 compression =
        subtract_quantities(stationary_fit, stationary_mean_value);
    const CompressionQuantityV1 construction =
        subtract_quantities(finite_fit, stationary_fit);
    const CompressionQuantityV1 sampling =
        subtract_quantities(ensemble_fit, finite_fit);
    CompressionQuantityV1 transformation;
    CompressionQuantityV1 deployed_fit;
    if (transformation_zero) {
      transformation = exact_value(ExactRational::zero());
      deployed_fit = ensemble_fit;
    } else if (options.transformed_profile) {
      deployed_fit = transformed_fit_mean(transformed_cutoff,
                                           transformed_contract_matches);
      transformation = subtract_quantities(deployed_fit, ensemble_fit);
    } else {
      transformation = unavailable(
          CompressionUnavailableReasonV1::transformed_profile_unavailable);
      deployed_fit = unavailable(
          CompressionUnavailableReasonV1::transformed_profile_unavailable);
    }

    const CompressionQuantityV1 first_two =
        add_quantities(compression, construction);
    const CompressionQuantityV1 three_sum =
        add_quantities(first_two, sampling);
    const CompressionQuantityV1 three_target =
        subtract_quantities(ensemble_fit, stationary_mean_value);
    const CompressionQuantityV1 three_closure =
        subtract_quantities(three_target, three_sum);
    const CompressionQuantityV1 four_sum =
        add_quantities(three_sum, transformation);
    const CompressionQuantityV1 four_target =
        subtract_quantities(deployed_fit, stationary_mean_value);
    const CompressionQuantityV1 four_closure =
        subtract_quantities(four_target, four_sum);

    CompressionQuantityV1 stationary_crosscheck;
    if (stationary_cutoff->tail.stationary_compression_defect.available()) {
      stationary_crosscheck = subtract_quantities(
          compression, stationary_cutoff->tail.stationary_compression_defect);
    } else {
      stationary_crosscheck = unavailable(
          CompressionUnavailableReasonV1::stationary_hypotheses_unavailable);
    }

    const std::optional<FitResampleCountsV1> aggregated_fit_resamples =
        aggregate_fit_resamples(
            *stationary_cutoff, *finite_cutoff, *ensemble_cutoff);
    const CompressionQuantityV1 fit_failure_rate =
        fit_resample_failure_rate(aggregated_fit_resamples);

    ErrorSeparationUncertaintyV1 uncertainty;
    uncertainty.compression_squared_standard_error =
        squared_error(stationary_cutoff->jackknife, true);
    uncertainty.finite_window_squared_standard_error = add_quantities(
        squared_error(finite_cutoff->jackknife, false),
        squared_error(stationary_cutoff->jackknife, false));
    uncertainty.sampling_squared_standard_error = add_quantities(
        squared_error(ensemble_cutoff->jackknife, false),
        squared_error(finite_cutoff->jackknife, false));
    uncertainty.transformation_squared_standard_error =
        transformation_zero
            ? exact_value(ExactRational::zero())
            : transformed_squared_error(transformed_cutoff,
                                        transformed_contract_matches);
    if (!uncertainty.compression_squared_standard_error.available() ||
        !uncertainty.finite_window_squared_standard_error.available() ||
        !uncertainty.sampling_squared_standard_error.available() ||
        ((transformation_zero || options.transformed_profile.has_value()) &&
         !uncertainty.transformation_squared_standard_error.available())) {
      add_reason(uncertainty.status,
                 CompressionUnavailableReasonV1::insufficient_independent_replications);
    }

    CompressionMetricStatusV1 row_status;
    if (!compression.available() || !construction.available() ||
        !sampling.available()) {
      add_reason(row_status,
                 CompressionUnavailableReasonV1::intermediate_fit_unavailable);
    }
    if (!transformation_zero && !deployed_fit.available()) {
      add_reason(row_status,
                 CompressionUnavailableReasonV1::transformed_profile_unavailable);
    }
    add_warning(compression.status,
                CompressionWarningCodeV1::stationary_interpretation_is_estimated);
    result.cutoffs.push_back(ErrorSeparationCutoffV1{
        cutoff,
        compression,
        construction,
        sampling,
        transformation,
        three_sum,
        three_target,
        three_closure,
        four_sum,
        four_target,
        four_closure,
        stationary_crosscheck,
        aggregated_fit_resamples.value_or(FitResampleCountsV1{}),
        fit_failure_rate,
        std::move(uncertainty),
        transformation_zero,
        std::move(row_status)});
  }
  if (result.cutoffs.empty()) {
    add_reason(result.status,
               CompressionUnavailableReasonV1::intermediate_fit_unavailable);
  }
  return Result<ThreeRecordErrorSeparationV1>::success(std::move(result));
}

}  // namespace mwperf
