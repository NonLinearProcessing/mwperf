#include "mwperf/diagnostics/compression_analysis.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <initializer_list>
#include <limits>
#include <new>
#include <optional>
#include <queue>
#include <string>
#include <string_view>
#include <tuple>
#include <utility>

namespace mwperf {
namespace {

[[nodiscard]] Diagnostic diagnostic(std::string code, std::string message,
                                    DiagnosticCategory category =
                                        DiagnosticCategory::input_validation) {
  return Diagnostic{category, std::move(code), std::move(message),
                    std::nullopt, std::nullopt, {}};
}

class AnalysisIdentityEncoder final {
 public:
  void u64(const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      bytes_.push_back(static_cast<std::byte>(value >> (shift - 8U)));
    }
  }

  void boolean(const bool value) {
    bytes_.push_back(value ? std::byte{1} : std::byte{0});
  }

  void framed(const std::span<const std::byte> value) {
    u64(static_cast<std::uint64_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
  }

  void text(const std::string& value) {
    framed(std::as_bytes(std::span(value.data(), value.size())));
  }

  void digest(const Digest256& value) { framed(value.bytes()); }

  void rational(const ExactRational& value) {
    text(value.numerator_decimal());
    text(value.denominator_decimal());
  }

  [[nodiscard]] Result<Digest256> finish(
      const std::string_view domain = "mwperf.compression.analysis.v1") const {
    return sha256_domain_separated(domain, bytes_);
  }

 private:
  std::vector<std::byte> bytes_;
};

[[nodiscard]] std::vector<FinitePrefixFitSelectionSeedAtomV1>
canonical_identity_selection_seed(
    std::vector<FinitePrefixFitSelectionSeedAtomV1> seed) {
  std::sort(seed.begin(), seed.end(), [](const auto& left,
                                         const auto& right) {
    return left.backlog < right.backlog;
  });
  std::vector<FinitePrefixFitSelectionSeedAtomV1> canonical;
  canonical.reserve(seed.size());
  for (auto& atom : seed) {
    if (!canonical.empty() && canonical.back().backlog == atom.backlog) {
      canonical.back().selection_mass =
          canonical.back().selection_mass + atom.selection_mass;
    } else {
      canonical.push_back(std::move(atom));
    }
  }
  std::erase_if(canonical, [](const auto& atom) {
    return atom.selection_mass.is_zero();
  });
  return canonical;
}

[[nodiscard]] Result<Digest256> compression_analysis_digest(
    const Digest256& observation_digest,
    const CompressionAnalysisOptionsV1& options) {
  std::vector<BigNat> cutoffs = options.cutoffs;
  std::sort(cutoffs.begin(), cutoffs.end());
  const auto seed = canonical_identity_selection_seed(options.selection_seed);
  std::vector<const SuppliedResponseProfileV1*> supplied;
  supplied.reserve(options.provider_supplied_profiles.size());
  for (const auto& profile : options.provider_supplied_profiles) {
    supplied.push_back(&profile);
  }
  std::sort(supplied.begin(), supplied.end(), [](const auto* left,
                                                  const auto* right) {
    return left->cutoff < right->cutoff;
  });

  AnalysisIdentityEncoder encoder;
  encoder.digest(observation_digest);
  encoder.u64(static_cast<std::uint64_t>(cutoffs.size()));
  for (const BigNat& cutoff : cutoffs) {
    encoder.text(cutoff.to_decimal_string());
  }
  encoder.u64(static_cast<std::uint64_t>(options.fit_limits.maximum_cutoff));
  encoder.u64(
      static_cast<std::uint64_t>(options.fit_limits.maximum_arrival_atoms));
  encoder.u64(static_cast<std::uint64_t>(
      options.fit_limits.maximum_selection_seed_atoms));
  encoder.u64(static_cast<std::uint64_t>(
      options.fit_limits.maximum_closure_states));
  encoder.u64(static_cast<std::uint64_t>(seed.size()));
  for (const auto& atom : seed) {
    encoder.text(atom.backlog.to_decimal_string());
    encoder.rational(atom.selection_mass);
  }
  encoder.u64(static_cast<std::uint64_t>(supplied.size()));
  for (const SuppliedResponseProfileV1* profile : supplied) {
    encoder.text(profile->cutoff.to_decimal_string());
    encoder.u64(
        static_cast<std::uint64_t>(profile->service_by_level.size()));
    for (const auto& value : profile->service_by_level) {
      encoder.rational(value);
    }
    encoder.rational(profile->constant_tail_service);
    encoder.u64(
        static_cast<std::uint64_t>(profile->prefix_exposure_mass.size()));
    for (const auto& value : profile->prefix_exposure_mass) {
      encoder.rational(value);
    }
    encoder.u64(
        static_cast<std::uint64_t>(profile->prefix_served_mass.size()));
    for (const auto& value : profile->prefix_served_mass) {
      encoder.rational(value);
    }
    encoder.rational(profile->tail_exposure_mass);
    encoder.rational(profile->tail_served_mass);
  }
  encoder.boolean(options.ill_conditioned_slack_threshold.has_value());
  if (options.ill_conditioned_slack_threshold) {
    encoder.rational(*options.ill_conditioned_slack_threshold);
  }
  encoder.boolean(options.run_diagnostic_fits);
  encoder.boolean(options.compute_delete_one_replication_jackknife);
  encoder.boolean(options.stationary_coefficients_established);
  encoder.boolean(options.prefix_preservation_established);
  if (options.projection_mode ==
      CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response) {
    encoder.text("empirical_finite_window_response_v1");
    encoder.boolean(options.ensemble_population_size.has_value());
    if (options.ensemble_population_size) {
      encoder.text(options.ensemble_population_size->to_decimal_string());
    }
    encoder.boolean(options.poisson_overshoot.has_value());
    if (options.poisson_overshoot) {
      const auto& overshoot = *options.poisson_overshoot;
      encoder.text(overshoot.descriptor_id);
      encoder.u64(overshoot.descriptor_version);
      encoder.digest(overshoot.operational_parameter_digest);
      encoder.digest(overshoot.descriptor_digest);
      encoder.rational(overshoot.omitted_tail_tolerance);
      encoder.u64(overshoot.maximum_recurrence_steps);
      encoder.u64(static_cast<std::uint64_t>(overshoot.components.size()));
      for (const auto& component : overshoot.components) {
        encoder.rational(component.weight);
        encoder.rational(component.component_rate);
        encoder.u64(component.operational_rate_bits);
      }
    }
    return encoder.finish("mwperf.compression.analysis.v2");
  }
  return encoder.finish();
}

[[nodiscard]] bool valid_supplied_profile_semantics(
    const SuppliedResponseProfileV1& profile) {
  if (profile.service_by_level.empty() ||
      profile.service_by_level.size() != profile.prefix_exposure_mass.size() ||
      profile.service_by_level.size() != profile.prefix_served_mass.size() ||
      profile.cutoff.value() !=
          BigInt{static_cast<std::uint64_t>(
              profile.service_by_level.size() - 1U)} ||
      profile.service_by_level.front() != ExactRational::zero()) {
    return false;
  }
  const auto probability = [](const ExactRational& candidate) {
    return candidate >= ExactRational::zero() &&
           candidate <= ExactRational::one();
  };
  if (!probability(profile.constant_tail_service) ||
      profile.tail_exposure_mass < ExactRational::zero() ||
      profile.tail_served_mass < ExactRational::zero() ||
      profile.tail_served_mass > profile.tail_exposure_mass) {
    return false;
  }
  for (std::size_t index = 0U; index < profile.service_by_level.size();
       ++index) {
    if (!probability(profile.service_by_level[index]) ||
        profile.prefix_exposure_mass[index] < ExactRational::zero() ||
        profile.prefix_served_mass[index] < ExactRational::zero() ||
        profile.prefix_served_mass[index] >
            profile.prefix_exposure_mass[index]) {
      return false;
    }
  }
  // The provider-authored coefficients and supporting masses are independent
  // observables.  In particular, do not require coefficient == served /
  // exposure: preserving that mismatch is part of the transformation audit.
  return true;
}

[[nodiscard]] ExactRational integer_rational(const BigInt& value) {
  return std::move(ExactRational::make(value, BigInt{1})).value();
}

[[nodiscard]] ExactRational natural_rational(const BigNat& value) {
  return integer_rational(value.value());
}

[[nodiscard]] ExactRational size_rational(const std::size_t value) {
  return integer_rational(BigInt{value});
}

[[nodiscard]] ExactRational uint_rational(const std::uint64_t value) {
  return integer_rational(BigInt{value});
}

[[nodiscard]] const ExactRational& two() {
  static const ExactRational value = integer_rational(BigInt{2});
  return value;
}

[[nodiscard]] const ExactRational& cp09_poisson_omitted_tail_tolerance() {
  static const ExactRational value = []() {
    BigInt denominator = 1;
    for (std::size_t digit = 0U; digit < 45U; ++digit) denominator *= 10;
    return std::move(ExactRational::make(BigInt{1}, denominator)).value();
  }();
  return value;
}

[[nodiscard]] ExactRational scalar_exact_value(
    const PortableScientificScalar& scalar) {
  return scalar.kind() == PortableScientificScalarKind::rational
             ? scalar.rational_value()
             : binary64_as_exact_rational(scalar);
}

struct Enclosed final {
  ExactRational value;
  ExactRational error;
};

[[nodiscard]] Enclosed exact(ExactRational value) {
  return Enclosed{std::move(value), ExactRational::zero()};
}

[[nodiscard]] Enclosed zero() { return exact(ExactRational::zero()); }

[[nodiscard]] Enclosed one() { return exact(ExactRational::one()); }

[[nodiscard]] bool provably_zero(const Enclosed& value) {
  return value.value.is_zero() && value.error.is_zero();
}

[[nodiscard]] bool excludes_zero(const Enclosed& value) {
  return value.value - value.error > ExactRational::zero() ||
         value.value + value.error < ExactRational::zero();
}

[[nodiscard]] Enclosed scalar_value(const ObservationScalarV1& scalar) {
  ExactRational error = ExactRational::zero();
  if (scalar.enclosure) {
    error = scalar_exact_value(scalar.enclosure->absolute_error);
  }
  return Enclosed{scalar_exact_value(scalar.value), std::move(error)};
}

[[nodiscard]] ExactRational minimum(const ExactRational& left,
                                    const ExactRational& right) {
  return right < left ? right : left;
}

[[nodiscard]] ExactRational maximum(const ExactRational& left,
                                    const ExactRational& right) {
  return left < right ? right : left;
}

[[nodiscard]] Enclosed add(const Enclosed& left, const Enclosed& right) {
  return Enclosed{left.value + right.value, left.error + right.error};
}

[[nodiscard]] Enclosed subtract(const Enclosed& left, const Enclosed& right) {
  return Enclosed{left.value - right.value, left.error + right.error};
}

[[nodiscard]] Enclosed negate(const Enclosed& value) {
  return Enclosed{-value.value, value.error};
}

[[nodiscard]] Enclosed multiply(const Enclosed& left,
                                const Enclosed& right) {
  const ExactRational left_low = left.value - left.error;
  const ExactRational left_high = left.value + left.error;
  const ExactRational right_low = right.value - right.error;
  const ExactRational right_high = right.value + right.error;
  const std::array<ExactRational, 4U> products{
      left_low * right_low, left_low * right_high,
      left_high * right_low, left_high * right_high};
  ExactRational low = products.front();
  ExactRational high = products.front();
  for (const ExactRational& product : products) {
    low = minimum(low, product);
    high = maximum(high, product);
  }
  const ExactRational center = left.value * right.value;
  const ExactRational lower_distance = absolute_value(center - low);
  const ExactRational upper_distance = absolute_value(high - center);
  return Enclosed{center, maximum(lower_distance, upper_distance)};
}

[[nodiscard]] Enclosed scale(const Enclosed& value,
                             const ExactRational& factor) {
  return multiply(value, exact(factor));
}

[[nodiscard]] Enclosed enclose_center_with_bounds(
    ExactRational center, const ExactRational& lower,
    const ExactRational& upper) {
  const ExactRational lower_distance = absolute_value(center - lower);
  const ExactRational upper_distance = absolute_value(upper - center);
  return Enclosed{std::move(center),
                  maximum(lower_distance, upper_distance)};
}

// The fitted prefix probabilities themselves depend nonlinearly on all
// response coefficients.  For a normalized law, however, C_fit is a convex
// combination of {0, n(c-mu_n)}.  Widening the exact center-fit correction to
// that complete convex hull is conservative across every admissible law in
// the input coefficient box, including changes in the fitted probabilities.
[[nodiscard]] Enclosed conservative_fitted_correction(
    Enclosed center_correction, const Enclosed& tail_service,
    const std::vector<Enclosed>& service_by_level) {
  const bool uncertain = !tail_service.error.is_zero() ||
                         std::any_of(
                             service_by_level.begin(),
                             service_by_level.end(),
                             [](const Enclosed& coefficient) {
                               return !coefficient.error.is_zero();
                             });
  if (!uncertain) {
    return center_correction;
  }
  ExactRational lower = ExactRational::zero();
  ExactRational upper = ExactRational::zero();
  for (std::size_t level = 0U; level < service_by_level.size(); ++level) {
    const Enclosed contribution = scale(
        subtract(tail_service, service_by_level[level]),
        size_rational(level));
    lower = minimum(lower, contribution.value - contribution.error);
    upper = maximum(upper, contribution.value + contribution.error);
  }
  const Enclosed hull = enclose_center_with_bounds(
      center_correction.value, lower, upper);
  center_correction.error =
      maximum(center_correction.error, hull.error);
  return center_correction;
}

[[nodiscard]] std::optional<Enclosed> divide(const Enclosed& numerator,
                                             const Enclosed& denominator) {
  const ExactRational denominator_low = denominator.value - denominator.error;
  const ExactRational denominator_high = denominator.value + denominator.error;
  if ((denominator_low <= ExactRational::zero() &&
       denominator_high >= ExactRational::zero()) ||
      denominator.value.is_zero()) {
    return std::nullopt;
  }
  auto center_result = checked_divide(numerator.value, denominator.value);
  if (!center_result) {
    return std::nullopt;
  }
  const ExactRational numerator_low = numerator.value - numerator.error;
  const ExactRational numerator_high = numerator.value + numerator.error;
  std::array<ExactRational, 4U> quotients{
      std::move(checked_divide(numerator_low, denominator_low)).value(),
      std::move(checked_divide(numerator_low, denominator_high)).value(),
      std::move(checked_divide(numerator_high, denominator_low)).value(),
      std::move(checked_divide(numerator_high, denominator_high)).value()};
  ExactRational low = quotients.front();
  ExactRational high = quotients.front();
  for (const ExactRational& quotient : quotients) {
    low = minimum(low, quotient);
    high = maximum(high, quotient);
  }
  ExactRational center = std::move(center_result).value();
  const ExactRational lower_distance = absolute_value(center - low);
  const ExactRational upper_distance = absolute_value(high - center);
  return Enclosed{std::move(center),
                  maximum(lower_distance, upper_distance)};
}

[[nodiscard]] CompressionNumericalValueV1 public_value(const Enclosed& value) {
  return CompressionNumericalValueV1{value.value, value.error};
}

template <typename Code>
void append_unique(std::vector<Code>& values, const Code value) {
  if (std::find(values.begin(), values.end(), value) == values.end()) {
    values.push_back(value);
  }
}

void add_reason(CompressionMetricStatusV1& status,
                const CompressionUnavailableReasonV1 reason) {
  append_unique(status.unavailable_reasons, reason);
}

void add_warning(CompressionMetricStatusV1& status,
                 const CompressionWarningCodeV1 warning) {
  append_unique(status.warnings, warning);
}

void merge_status(CompressionMetricStatusV1& destination,
                  const CompressionMetricStatusV1& source) {
  for (const auto reason : source.unavailable_reasons) {
    add_reason(destination, reason);
  }
  for (const auto warning : source.warnings) {
    add_warning(destination, warning);
  }
}

void saturating_add(std::uint64_t& destination, const std::uint64_t value) {
  destination = value > std::numeric_limits<std::uint64_t>::max() - destination
                    ? std::numeric_limits<std::uint64_t>::max()
                    : destination + value;
}

[[nodiscard]] std::uint64_t saturated_sum(const std::uint64_t left,
                                          const std::uint64_t right) {
  std::uint64_t result = left;
  saturating_add(result, right);
  return result;
}

[[nodiscard]] std::uint64_t saturated_product(const std::uint64_t left,
                                              const std::uint64_t right) {
  if (left == 0U || right == 0U) {
    return 0U;
  }
  return right > std::numeric_limits<std::uint64_t>::max() / left
             ? std::numeric_limits<std::uint64_t>::max()
             : left * right;
}

void saturating_increment(std::uint64_t& value) {
  saturating_add(value, 1U);
}

[[nodiscard]] std::uint64_t bounded_u64(const std::size_t value) {
  if constexpr (sizeof(std::size_t) > sizeof(std::uint64_t)) {
    if (value > static_cast<std::size_t>(
                    std::numeric_limits<std::uint64_t>::max())) {
      return std::numeric_limits<std::uint64_t>::max();
    }
  }
  return static_cast<std::uint64_t>(value);
}

void record_allocation_events(CompressionAnalysisWorkCountersV1& work,
                              const std::uint64_t count = 1U) {
  saturating_add(work.top_level_reservation_events, count);
  saturating_add(work.analysis_allocation_events, count);
}

void record_retained(CompressionAnalysisWorkCountersV1& work,
                     const std::size_t objects, const std::size_t bytes) {
  work.peak_retained_top_level_objects =
      std::max(work.peak_retained_top_level_objects, bounded_u64(objects));
  work.estimated_peak_retained_bytes =
      std::max(work.estimated_peak_retained_bytes, bounded_u64(bytes));
}

void add_work(CompressionAnalysisWorkCountersV1& destination,
              const CompressionAnalysisWorkCountersV1& source) {
  saturating_add(destination.input_level_rows, source.input_level_rows);
  saturating_add(destination.input_boundary_rows,
                 source.input_boundary_rows);
  saturating_add(destination.input_row_bytes, source.input_row_bytes);
  saturating_add(destination.merged_level_rows, source.merged_level_rows);
  saturating_add(destination.merged_boundary_rows,
                 source.merged_boundary_rows);
  saturating_add(destination.merge_key_comparisons,
                 source.merge_key_comparisons);
  saturating_add(destination.merge_heap_operations,
                 source.merge_heap_operations);
  saturating_add(destination.point_fit_invocations,
                 source.point_fit_invocations);
  saturating_add(destination.jackknife_fit_invocations,
                 source.jackknife_fit_invocations);
  saturating_add(destination.top_level_reservation_events,
                 source.top_level_reservation_events);
  saturating_add(destination.analysis_allocation_events,
                 source.analysis_allocation_events);
  destination.peak_retained_top_level_objects =
      std::max(destination.peak_retained_top_level_objects,
               source.peak_retained_top_level_objects);
  destination.estimated_peak_retained_bytes =
      std::max(destination.estimated_peak_retained_bytes,
               source.estimated_peak_retained_bytes);
}

[[nodiscard]] CompressionQuantityV1 available(
    const Enclosed& value,
    std::vector<CompressionWarningCodeV1> warnings = {}) {
  CompressionMetricStatusV1 status;
  status.warnings = std::move(warnings);
  if (!value.error.is_zero()) {
    add_warning(status,
                CompressionWarningCodeV1::numerical_enclosure_required);
  }
  return CompressionQuantityV1{public_value(value), std::move(status)};
}

[[nodiscard]] CompressionQuantityV1 unavailable(
    const CompressionUnavailableReasonV1 reason) {
  CompressionMetricStatusV1 status;
  add_reason(status, reason);
  return CompressionQuantityV1{std::nullopt, std::move(status)};
}

[[nodiscard]] CompressionQuantityV1 divided_quantity(
    const Enclosed& numerator, const Enclosed& denominator,
    const CompressionUnavailableReasonV1 zero_reason) {
  if (provably_zero(denominator)) {
    return unavailable(zero_reason);
  }
  auto quotient = divide(numerator, denominator);
  if (!quotient) {
    return unavailable(
        CompressionUnavailableReasonV1::denominator_enclosure_contains_zero);
  }
  return available(*quotient);
}

[[nodiscard]] Enclosed enclosed(const CompressionQuantityV1& quantity) {
  return Enclosed{quantity.estimate->value,
                  quantity.estimate->absolute_error_bound};
}

[[nodiscard]] Result<std::size_t> native_cutoff(
    const BigNat& cutoff, const std::size_t maximum) {
  if (cutoff.value() > BigInt{maximum} ||
      cutoff.value() == BigInt{std::numeric_limits<std::size_t>::max()}) {
    return Result<std::size_t>::failure(diagnostic(
        "compression.cutoff_limit",
        "a diagnostic cutoff exceeds the configured admission limit or "
        "cannot support the required cutoff-plus-one allocation",
        DiagnosticCategory::resource_limit));
  }
  return Result<std::size_t>::success(
      cutoff.value().convert_to<std::size_t>());
}

[[nodiscard]] bool expected_slot_convention(
    const ObservationSlotConventionV1& convention,
    const ObservationSourceRoleV1 source_role) {
  static constexpr std::array<ObservationSlotStageV1, 8U> weighted_expected{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service,
      ObservationSlotStageV1::classify_and_resample,
      ObservationSlotStageV1::allocate_child_lineage,
      ObservationSlotStageV1::apply_fresh_late_arrival,
      ObservationSlotStageV1::commit_post_slot_state,
      ObservationSlotStageV1::emit_committed_observation};
  static constexpr std::array<ObservationSlotStageV1, 6U> direct_expected{
      ObservationSlotStageV1::solve_primary_maxweight,
      ObservationSlotStageV1::observe_pre_service,
      ObservationSlotStageV1::apply_actual_service,
      ObservationSlotStageV1::apply_fresh_late_arrival,
      ObservationSlotStageV1::commit_post_slot_state,
      ObservationSlotStageV1::emit_committed_observation};
  if (source_role == ObservationSourceRoleV1::weighted_ensemble) {
    return convention.step_order.size() == weighted_expected.size() &&
           std::equal(convention.step_order.begin(),
                      convention.step_order.end(), weighted_expected.begin());
  }
  return convention.step_order.size() == direct_expected.size() &&
         std::equal(convention.step_order.begin(), convention.step_order.end(),
                    direct_expected.begin());
}

struct AggregateGap final {
  Enclosed negative;
  Enclosed tie;
  Enclosed positive;
  Enclosed tied_and_served;
  Enclosed positive_magnitude;
  Enclosed negative_magnitude;
};

[[nodiscard]] AggregateGap zero_gap() {
  return AggregateGap{zero(), zero(), zero(), zero(), zero(), zero()};
}

void add_gap(AggregateGap& destination, const ObservationGapCellV1& source) {
  destination.negative = add(destination.negative,
                             scalar_value(source.negative_mass));
  destination.tie = add(destination.tie, scalar_value(source.tie_mass));
  destination.positive = add(destination.positive,
                             scalar_value(source.positive_mass));
  destination.tied_and_served =
      add(destination.tied_and_served,
          scalar_value(source.tied_and_served_mass));
  destination.positive_magnitude =
      add(destination.positive_magnitude,
          scalar_value(source.positive_magnitude_mass));
  destination.negative_magnitude =
      add(destination.negative_magnitude,
          scalar_value(source.negative_magnitude_mass));
}

struct AggregateLevel final {
  BigNat backlog;
  Enclosed exposure;
  Enclosed served;
  AggregateGap gap;
  bool gap_seen;
  bool gap_missing;
};

struct LevelCursor final {
  const std::vector<ExactLevelObservationV1>* rows;
  std::size_t index;
};

struct LevelCursorGreater final {
  std::uint64_t* comparison_count;

  bool operator()(const LevelCursor& left,
                  const LevelCursor& right) const noexcept {
    saturating_increment(*comparison_count);
    return (*left.rows)[left.index].backlog_level >
           (*right.rows)[right.index].backlog_level;
  }
};

[[nodiscard]] std::vector<std::size_t> complete_replication_indices(
    const ConstructionObservationBundleV1& bundle,
    const std::optional<std::size_t> omitted_replication) {
  std::vector<std::size_t> indices;
  indices.reserve(bundle.replications.size());
  for (std::size_t index = 0U; index < bundle.replications.size(); ++index) {
    const auto& replication = bundle.replications[index];
    if (replication.completeness == ObservationCompletenessV1::complete &&
        replication.committed_through_boundary == bundle.end_boundary &&
        (!omitted_replication || *omitted_replication != index)) {
      indices.push_back(index);
    }
  }
  return indices;
}

[[nodiscard]] std::vector<AggregateLevel> pool_levels(
    const ConstructionObservationBundleV1& bundle,
    const std::vector<std::size_t>& replications,
    CompressionAnalysisWorkCountersV1& work,
    const bool count_input_rows) {
  std::priority_queue<LevelCursor, std::vector<LevelCursor>,
                      LevelCursorGreater>
      heap(LevelCursorGreater{&work.merge_key_comparisons});
  for (const std::size_t replication_index : replications) {
    for (const auto& block : bundle.replications[replication_index].blocks) {
      if (count_input_rows) {
        saturating_add(work.input_level_rows,
                       bounded_u64(block.levels.size()));
        saturating_add(
            work.input_row_bytes,
            saturated_product(bounded_u64(block.levels.size()),
                              bounded_u64(sizeof(ExactLevelObservationV1))));
      }
      if (!block.levels.empty()) {
        heap.push(LevelCursor{&block.levels, 0U});
        saturating_increment(work.merge_heap_operations);
      }
    }
  }

  std::vector<AggregateLevel> pooled;
  record_allocation_events(work);
  while (!heap.empty()) {
    LevelCursor cursor = heap.top();
    heap.pop();
    saturating_increment(work.merge_heap_operations);
    const auto& row = (*cursor.rows)[cursor.index];
    const BigNat level = row.backlog_level;
    AggregateLevel aggregate{level, zero(), zero(), zero_gap(), false, false};

    const auto consume = [&aggregate, &heap, &work](LevelCursor current) {
      const auto& source = (*current.rows)[current.index];
      aggregate.exposure =
          add(aggregate.exposure, scalar_value(source.exposure_mass));
      aggregate.served =
          add(aggregate.served, scalar_value(source.served_mass));
      if (source.gap) {
        aggregate.gap_seen = true;
        add_gap(aggregate.gap, *source.gap);
      } else {
        aggregate.gap_missing = true;
      }
      ++current.index;
      if (current.index < current.rows->size()) {
        heap.push(current);
        saturating_increment(work.merge_heap_operations);
      }
    };
    consume(cursor);
    while (!heap.empty() &&
           (*heap.top().rows)[heap.top().index].backlog_level == level) {
      LevelCursor equal = heap.top();
      heap.pop();
      saturating_increment(work.merge_heap_operations);
      consume(equal);
    }
    pooled.push_back(std::move(aggregate));
  }
  saturating_add(work.merged_level_rows, bounded_u64(pooled.size()));
  return pooled;
}

struct BoundaryCursor final {
  const std::vector<BoundaryBacklogMassV1>* rows;
  std::size_t index;
};

struct BoundaryCursorGreater final {
  std::uint64_t* comparison_count;

  bool operator()(const BoundaryCursor& left,
                  const BoundaryCursor& right) const noexcept {
    saturating_increment(*comparison_count);
    return (*left.rows)[left.index].backlog_level >
           (*right.rows)[right.index].backlog_level;
  }
};

struct AggregateBoundaryLevel final {
  BigNat backlog;
  Enclosed mass;
};

[[nodiscard]] std::vector<AggregateBoundaryLevel> pool_boundaries(
    const ConstructionObservationBundleV1& bundle,
    const std::vector<std::size_t>& replications, const bool terminal,
    CompressionAnalysisWorkCountersV1& work,
    const bool count_input_rows) {
  std::priority_queue<BoundaryCursor, std::vector<BoundaryCursor>,
                      BoundaryCursorGreater>
      heap(BoundaryCursorGreater{&work.merge_key_comparisons});
  for (const std::size_t replication_index : replications) {
    const auto& blocks = bundle.replications[replication_index].blocks;
    if (blocks.empty()) {
      continue;
    }
    const auto& rows = terminal ? blocks.back().committed_boundary_law.rows
                                : blocks.front().initial_boundary_law.rows;
    if (count_input_rows) {
      saturating_add(work.input_boundary_rows, bounded_u64(rows.size()));
      saturating_add(
          work.input_row_bytes,
          saturated_product(bounded_u64(rows.size()),
                            bounded_u64(sizeof(BoundaryBacklogMassV1))));
    }
    if (!rows.empty()) {
      heap.push(BoundaryCursor{&rows, 0U});
      saturating_increment(work.merge_heap_operations);
    }
  }
  std::vector<AggregateBoundaryLevel> pooled;
  record_allocation_events(work);
  while (!heap.empty()) {
    BoundaryCursor cursor = heap.top();
    heap.pop();
    saturating_increment(work.merge_heap_operations);
    const BigNat level = (*cursor.rows)[cursor.index].backlog_level;
    Enclosed mass = zero();
    const auto consume = [&mass, &heap, &work](BoundaryCursor current) {
      mass = add(mass, scalar_value((*current.rows)[current.index].mass));
      ++current.index;
      if (current.index < current.rows->size()) {
        heap.push(current);
        saturating_increment(work.merge_heap_operations);
      }
    };
    consume(cursor);
    while (!heap.empty() &&
           (*heap.top().rows)[heap.top().index].backlog_level == level) {
      BoundaryCursor equal = heap.top();
      heap.pop();
      saturating_increment(work.merge_heap_operations);
      consume(equal);
    }
    pooled.push_back(AggregateBoundaryLevel{level, std::move(mass)});
  }
  saturating_add(work.merged_boundary_rows, bounded_u64(pooled.size()));
  return pooled;
}

[[nodiscard]] Enclosed weighted_level_sum(
    const std::vector<AggregateBoundaryLevel>& rows,
    const bool squared) {
  Enclosed total = zero();
  for (const auto& row : rows) {
    const ExactRational level = natural_rational(row.backlog);
    const ExactRational reward = squared ? level * level : level;
    total = add(total, scale(row.mass, reward));
  }
  return total;
}

[[nodiscard]] std::vector<Enclosed> boundary_hinge_rewards(
    const std::vector<AggregateBoundaryLevel>& rows,
    const std::vector<BigNat>& cutoffs) {
  std::vector<Enclosed> result(cutoffs.size(), zero());
  Enclosed suffix_mass = zero();
  Enclosed suffix_reward = zero();
  std::size_t row_index = rows.size();
  for (std::size_t reverse = cutoffs.size(); reverse > 0U; --reverse) {
    const std::size_t cutoff_index = reverse - 1U;
    const BigNat& cutoff = cutoffs[cutoff_index];
    while (row_index > 0U && cutoff < rows[row_index - 1U].backlog) {
      --row_index;
      suffix_mass = add(suffix_mass, rows[row_index].mass);
      suffix_reward =
          add(suffix_reward,
              scale(rows[row_index].mass,
                    natural_rational(rows[row_index].backlog)));
    }
    result[cutoff_index] =
        subtract(suffix_reward,
                 scale(suffix_mass, natural_rational(cutoff)));
  }
  return result;
}

[[nodiscard]] PooledGapCellV1 public_gap(const AggregateGap& gap) {
  return PooledGapCellV1{
      public_value(gap.negative), public_value(gap.tie),
      public_value(gap.positive), public_value(gap.tied_and_served),
      public_value(gap.positive_magnitude),
      public_value(gap.negative_magnitude)};
}

[[nodiscard]] const AggregateLevel* find_level(
    const std::vector<AggregateLevel>& rows, const BigNat& level) {
  const auto found = std::lower_bound(
      rows.begin(), rows.end(), level,
      [](const AggregateLevel& row, const BigNat& wanted) {
        return row.backlog < wanted;
      });
  return found != rows.end() && found->backlog == level ? &*found : nullptr;
}

[[nodiscard]] bool has_numerical_error(
    const std::vector<AggregateLevel>& rows) {
  return std::any_of(rows.begin(), rows.end(), [](const AggregateLevel& row) {
    const bool base = !row.exposure.error.is_zero() ||
                      !row.served.error.is_zero();
    if (base || !row.gap_seen || row.gap_missing) {
      return base;
    }
    return !row.gap.negative.error.is_zero() ||
           !row.gap.tie.error.is_zero() ||
           !row.gap.positive.error.is_zero() ||
           !row.gap.tied_and_served.error.is_zero() ||
           !row.gap.positive_magnitude.error.is_zero() ||
           !row.gap.negative_magnitude.error.is_zero();
  });
}

struct ArrivalData final {
  std::vector<FinitePrefixFitArrivalAtomV1> atoms;
  ExactRational mean;
  ExactRational second_moment;
  bool exact_marginal;
  bool second_moment_available;
  const CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1*
      poisson_overshoot;
};

[[nodiscard]] Result<ArrivalData> arrival_data(
    const ConstructionObservationBundleV1& bundle,
    const CompressionAnalysisOptionsV1& options) {
  const auto& binding = bundle.bindings.arrival;
  ArrivalData data{{}, binding.mean, binding.second_moment, false,
                   bundle.capabilities.finite_arrival_second_moment.available,
                   nullptr};
  const auto* marginal =
      std::get_if<ExactTargetArrivalMarginalV1>(&binding.target_arrival);
  if (!marginal) {
    const auto* descriptor =
        std::get_if<TargetArrivalOvershootDescriptorV1>(
            &binding.target_arrival);
    if (descriptor == nullptr || !options.poisson_overshoot) {
      return Result<ArrivalData>::success(std::move(data));
    }
    const auto& evaluator = *options.poisson_overshoot;
    if (descriptor->descriptor_id != evaluator.descriptor_id ||
        descriptor->descriptor_version != evaluator.descriptor_version ||
        descriptor->descriptor_digest != evaluator.descriptor_digest ||
        (evaluator.descriptor_id !=
             "iid_independent_poisson_overshoot_v1" &&
         evaluator.descriptor_id != "iid_mixed_poisson_overshoot_v1") ||
        evaluator.descriptor_version != 1U || evaluator.components.empty() ||
        !evaluator.omitted_tail_tolerance.is_positive() ||
        evaluator.maximum_recurrence_steps == 0U) {
      return Result<ArrivalData>::success(std::move(data));
    }

    ExactRational total_weight = ExactRational::zero();
    ExactRational mean = ExactRational::zero();
    ExactRational second = ExactRational::zero();
    for (const auto& component : evaluator.components) {
      if (!component.weight.is_nonnegative() ||
          !component.component_rate.is_nonnegative()) {
        return Result<ArrivalData>::success(std::move(data));
      }
      total_weight = total_weight + component.weight;
      mean = mean + component.weight * component.component_rate;
      second = second +
               component.weight *
                   (component.component_rate +
                    component.component_rate * component.component_rate);
    }
    if (total_weight != ExactRational::one() || mean != binding.mean ||
        (data.second_moment_available && second != binding.second_moment) ||
        (evaluator.descriptor_id ==
             "iid_independent_poisson_overshoot_v1" &&
         (evaluator.components.size() != 1U ||
          evaluator.components.front().weight != ExactRational::one()))) {
      return Result<ArrivalData>::success(std::move(data));
    }
    data.poisson_overshoot = &evaluator;
    return Result<ArrivalData>::success(std::move(data));
  }
  data.exact_marginal =
      bundle.capabilities.exact_target_arrival_marginal.available;
  data.atoms.reserve(marginal->atoms.size());
  ExactRational total = ExactRational::zero();
  ExactRational mean = ExactRational::zero();
  ExactRational second = ExactRational::zero();
  for (const auto& atom : marginal->atoms) {
    const ExactRational count = natural_rational(atom.batch_size);
    total = total + atom.probability;
    mean = mean + count * atom.probability;
    second = second + count * count * atom.probability;
    data.atoms.push_back(
        FinitePrefixFitArrivalAtomV1{atom.batch_size, atom.probability});
  }
  if (total != ExactRational::one() || mean != binding.mean ||
      (data.second_moment_available && second != binding.second_moment)) {
    return Result<ArrivalData>::failure(diagnostic(
        "compression.arrival_binding_mismatch",
        "the authenticated target-arrival atoms disagree with their bound "
        "normalization or moments"));
  }
  return Result<ArrivalData>::success(std::move(data));
}

[[nodiscard]] bool iid_balance_supported(
    const ConstructionObservationBundleV1& bundle) {
  return bundle.capabilities.iid_fresh_arrivals.available &&
         bundle.capabilities.no_target_drops.available &&
         expected_slot_convention(bundle.slot_convention, bundle.source_role);
}

struct ArrivalOvershootProfile final {
  const std::vector<FinitePrefixFitArrivalAtomV1>* atoms;
  std::vector<ExactRational> suffix_probability;
  std::vector<ExactRational> suffix_first_moment;
  std::vector<BigInt> poisson_thresholds;
  std::vector<std::optional<Enclosed>> poisson_values;
  std::vector<CompressionUnavailableReasonV1> poisson_unavailable_reasons;
  std::optional<ExactRational> poisson_mean;
  std::optional<PoissonOvershootEvaluationReportV1> poisson_report;
  std::optional<CompressionUnavailableReasonV1> poisson_global_failure;

  [[nodiscard]] bool available() const noexcept {
    return atoms != nullptr || poisson_report.has_value();
  }
};

// For phi_K(n,d)=E[(n-d+A-K)^+], exact finite arrival atoms need only two
// suffix sums.  Every sparse row/cutoff query is then one binary search plus
// constant exact arithmetic; no table proportional to the numerical value of
// K is ever materialized.
[[nodiscard]] ArrivalOvershootProfile make_arrival_overshoot_profile(
    const std::vector<FinitePrefixFitArrivalAtomV1>& atoms) {
  std::vector<ExactRational> suffix_probability(
      atoms.size(), ExactRational::zero());
  std::vector<ExactRational> suffix_first_moment(
      atoms.size(), ExactRational::zero());
  ExactRational probability = ExactRational::zero();
  ExactRational first_moment = ExactRational::zero();
  for (std::size_t index = atoms.size(); index-- > 0U;) {
    probability = probability + atoms[index].mass;
    first_moment =
        first_moment + natural_rational(atoms[index].count) * atoms[index].mass;
    suffix_probability[index] = probability;
    suffix_first_moment[index] = first_moment;
  }
  return ArrivalOvershootProfile{&atoms, std::move(suffix_probability),
                                 std::move(suffix_first_moment), {}, {}, {},
                                 std::nullopt, std::nullopt, std::nullopt};
}

struct PoissonExpMinusInterval final {
  ExactRational lower;
  ExactRational upper;
  std::uint64_t recurrence_steps;
};

[[nodiscard]] Result<PoissonExpMinusInterval> poisson_exp_minus_interval(
    const ExactRational& theta, const ExactRational& maximum_multiplier,
    const ExactRational& tolerance, const std::uint64_t maximum_steps) {
  if (theta.is_zero()) {
    return Result<PoissonExpMinusInterval>::success(
        {ExactRational::one(), ExactRational::one(), 0U});
  }

  ExactRational sum = ExactRational::one();
  ExactRational term = ExactRational::one();
  for (std::uint64_t degree = 0U; degree < maximum_steps; ++degree) {
    const auto next_degree = degree + 1U;
    term = term * theta *
           std::move(checked_divide(ExactRational::one(),
                                    uint_rational(next_degree)))
               .value();
    sum = sum + term;

    // S_degree is a lower bound for exp(theta).  Once the remaining Taylor
    // terms have a geometric ratio below one, their exact rational envelope
    // yields reciprocal outward bounds for exp(-theta).
    const auto following_degree = next_degree ==
                                          std::numeric_limits<std::uint64_t>::max()
                                      ? std::optional<std::uint64_t>{}
                                      : std::optional<std::uint64_t>{next_degree + 1U};
    if (!following_degree) break;
    const ExactRational following_denominator =
        uint_rational(*following_degree);
    if (theta >= following_denominator) continue;
    const ExactRational following =
        term * theta *
        std::move(checked_divide(ExactRational::one(),
                                 following_denominator))
            .value();
    if (*following_degree == std::numeric_limits<std::uint64_t>::max()) break;
    const ExactRational ratio =
        theta *
        std::move(checked_divide(
                      ExactRational::one(),
                      uint_rational(*following_degree + 1U)))
            .value();
    const ExactRational one_minus_ratio = ExactRational::one() - ratio;
    const ExactRational remainder =
        following *
        std::move(checked_divide(ExactRational::one(), one_minus_ratio))
            .value();
    const ExactRational lower =
        std::move(checked_divide(ExactRational::one(), sum + remainder))
            .value();
    const ExactRational upper =
        std::move(checked_divide(ExactRational::one(), sum)).value();
    if ((upper - lower) * maximum_multiplier <= two() * tolerance) {
      return Result<PoissonExpMinusInterval>::success(
          {lower, upper, next_degree});
    }
  }
  return Result<PoissonExpMinusInterval>::failure(diagnostic(
      "compression.poisson_overshoot_work_limit",
      "the certified Poisson exponential enclosure exhausted its explicit recurrence limit",
      DiagnosticCategory::resource_limit));
}

struct PoissonFitProjection final {
  std::vector<FinitePrefixFitArrivalAtomV1> atoms;
  FinitePrefixFitArrivalMomentsV1 analytic_moments;
  bool support_extends_beyond_projection;
  FrameworkPoissonArrivalReconstructionV1 report;
};

[[nodiscard]] Enclosed midpoint_enclosure(const ExactRational& lower,
                                          const ExactRational& upper) {
  const ExactRational center =
      (lower + upper) *
      std::move(checked_divide(ExactRational::one(), two())).value();
  return Enclosed{
      center,
      (upper - lower) *
          std::move(checked_divide(ExactRational::one(), two())).value()};
}

// Builds exactly the finite information consumed by the SF.19 recurrence.
// The synthetic atom at H+1 is an aggregate survival bucket, not a
// truncation of the Poisson law.  Analytic moments from the Poisson PGF are
// supplied separately and the true omitted mass/moments retain certified
// enclosures in the public report.
[[nodiscard]] Result<PoissonFitProjection> make_poisson_fit_projection(
    const CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1& law,
    const std::size_t represented_through) {
  try {
    const std::size_t prefix_size = represented_through + 1U;
    std::vector<ExactRational> probability_lower(
        prefix_size, ExactRational::zero());
    std::vector<ExactRational> probability_upper(
        prefix_size, ExactRational::zero());
    ExactRational first = ExactRational::zero();
    ExactRational second = ExactRational::zero();
    ExactRational third = ExactRational::zero();
    bool unbounded = false;
    std::uint64_t recurrence_steps = 0U;

    for (const auto& component : law.components) {
      if (component.weight.is_zero()) continue;
      const ExactRational& theta = component.component_rate;
      const ExactRational theta_squared = theta * theta;
      const ExactRational theta_cubed = theta_squared * theta;
      first = first + component.weight * theta;
      second = second + component.weight * (theta + theta_squared);
      third = third +
              component.weight *
                  (theta + uint_rational(3U) * theta_squared + theta_cubed);
      unbounded |= theta.is_positive();

      std::vector<ExactRational> coefficients(prefix_size,
                                               ExactRational::one());
      ExactRational precision_multiplier = ExactRational::one();
      for (std::size_t count = 1U; count < prefix_size; ++count) {
        coefficients[count] =
            coefficients[count - 1U] * theta *
            std::move(checked_divide(
                          ExactRational::one(),
                          size_rational(count)))
                .value();
      }
      ExactRational aggregate_multiplier = ExactRational::zero();
      for (std::size_t count = 0U; count < prefix_size; ++count) {
        const ExactRational native = size_rational(count);
        aggregate_multiplier =
            aggregate_multiplier +
            component.weight * coefficients[count] *
                (ExactRational::one() + native + native * native +
                 native * native * native);
      }
      precision_multiplier =
          maximum(precision_multiplier, aggregate_multiplier);
      auto exponential = poisson_exp_minus_interval(
          theta, precision_multiplier, law.omitted_tail_tolerance,
          law.maximum_recurrence_steps - recurrence_steps);
      if (!exponential) {
        return Result<PoissonFitProjection>::failure(exponential.error());
      }
      saturating_add(recurrence_steps,
                     exponential.value().recurrence_steps);
      if (prefix_size - 1U >
          law.maximum_recurrence_steps - recurrence_steps) {
        return Result<PoissonFitProjection>::failure(diagnostic(
            "compression.poisson_prediction_work_limit",
            "the certified Poisson prediction projection exhausted its explicit recurrence limit",
            DiagnosticCategory::resource_limit));
      }
      saturating_add(recurrence_steps,
                     static_cast<std::uint64_t>(prefix_size - 1U));
      for (std::size_t count = 0U; count < prefix_size; ++count) {
        probability_lower[count] =
            probability_lower[count] +
            component.weight * coefficients[count] *
                exponential.value().lower;
        probability_upper[count] =
            probability_upper[count] +
            component.weight * coefficients[count] *
                exponential.value().upper;
      }
    }

    std::array<ExactRational, 4U> exact_moments{
        ExactRational::one(), first, second, third};
    std::array<ExactRational, 4U> retained_lower{
        ExactRational::zero(), ExactRational::zero(),
        ExactRational::zero(), ExactRational::zero()};
    std::array<ExactRational, 4U> retained_upper = retained_lower;
    for (std::size_t count = 0U; count < prefix_size; ++count) {
      if (probability_upper[count] < probability_lower[count] ||
          !probability_lower[count].is_nonnegative()) {
        return Result<PoissonFitProjection>::failure(diagnostic(
            "compression.poisson_prediction_enclosure_invalid",
            "the certified Poisson prefix enclosure is invalid",
            DiagnosticCategory::internal));
      }
      ExactRational power = ExactRational::one();
      const ExactRational native = size_rational(count);
      for (std::size_t order = 0U; order < exact_moments.size(); ++order) {
        retained_lower[order] =
            retained_lower[order] + power * probability_lower[count];
        retained_upper[order] =
            retained_upper[order] + power * probability_upper[count];
        power = power * native;
      }
    }

    std::array<Enclosed, 4U> omitted{
        zero(), zero(), zero(), zero()};
    for (std::size_t order = 0U; order < omitted.size(); ++order) {
      const ExactRational lower = maximum(
          ExactRational::zero(),
          exact_moments[order] - retained_upper[order]);
      const ExactRational upper = maximum(
          lower, exact_moments[order] - retained_lower[order]);
      omitted[order] = midpoint_enclosure(lower, upper);
    }

    // Choose one normalized rational representative from the certified
    // coordinate intervals.  Interpolating every prefix coordinate by the
    // same fraction makes its total exactly one minus the midpoint of the
    // certified omitted-mass interval.  This remains well-defined when a
    // high-resolution prefix is narrower than the exponential enclosure and
    // avoids a spurious sum-of-midpoints-above-one refusal.
    const ExactRational representative_tail = omitted[0].value;
    const ExactRational representative_prefix =
        ExactRational::one() - representative_tail;
    const ExactRational prefix_lower = retained_lower[0];
    const ExactRational prefix_upper = retained_upper[0];
    if (representative_prefix < prefix_lower ||
        representative_prefix > prefix_upper) {
      return Result<PoissonFitProjection>::failure(diagnostic(
          "compression.poisson_prediction_representative_invalid",
          "the certified Poisson intervals do not contain a normalized recurrence representative",
          DiagnosticCategory::internal));
    }
    ExactRational interpolation = ExactRational::zero();
    if (prefix_upper != prefix_lower) {
      interpolation =
          std::move(checked_divide(representative_prefix - prefix_lower,
                                   prefix_upper - prefix_lower))
              .value();
    } else if (representative_prefix != prefix_lower) {
      return Result<PoissonFitProjection>::failure(diagnostic(
          "compression.poisson_prediction_representative_invalid",
          "the exact Poisson prefix total disagrees with its omitted mass",
          DiagnosticCategory::internal));
    }

    std::vector<FrameworkPoissonArrivalPointV1> public_prefix;
    public_prefix.reserve(prefix_size);
    std::vector<FinitePrefixFitArrivalAtomV1> atoms;
    atoms.reserve(prefix_size + 1U);
    ExactRational represented_total = ExactRational::zero();
    for (std::size_t count = 0U; count < prefix_size; ++count) {
      const ExactRational representative =
          probability_lower[count] +
          interpolation *
              (probability_upper[count] - probability_lower[count]);
      const ExactRational enclosure_radius = maximum(
          representative - probability_lower[count],
          probability_upper[count] - representative);
      public_prefix.push_back(FrameworkPoissonArrivalPointV1{
          BigNat{static_cast<std::uint64_t>(count)},
          public_value(Enclosed{representative, enclosure_radius})});
      atoms.push_back(FinitePrefixFitArrivalAtomV1{
          BigNat{static_cast<std::uint64_t>(count)}, representative});
      represented_total = represented_total + representative;
    }
    if (represented_total != representative_prefix) {
      return Result<PoissonFitProjection>::failure(diagnostic(
          "compression.poisson_prediction_representative_invalid",
          "the rational Poisson recurrence representative is not normalized",
          DiagnosticCategory::internal));
    }
    if (representative_tail.is_positive()) {
      atoms.push_back(FinitePrefixFitArrivalAtomV1{
          BigNat{static_cast<std::uint64_t>(prefix_size)},
          representative_tail});
    }

    return Result<PoissonFitProjection>::success(PoissonFitProjection{
        std::move(atoms),
        FinitePrefixFitArrivalMomentsV1{first, second, third},
        unbounded,
        FrameworkPoissonArrivalReconstructionV1{
            "certified_rational_poisson_prefix_v1",
            1U,
            law.descriptor_digest,
            unbounded,
            BigNat{static_cast<std::uint64_t>(represented_through)},
            std::move(public_prefix),
            public_value(omitted[0]),
            public_value(omitted[1]),
            public_value(omitted[2]),
            public_value(omitted[3]),
            first,
            second,
            third,
            law.omitted_tail_tolerance,
            recurrence_steps}});
  } catch (const std::bad_alloc&) {
    return Result<PoissonFitProjection>::failure(diagnostic(
        "compression.poisson_prediction_allocation_failed",
        "the finite Poisson decoder projection could not be allocated",
        DiagnosticCategory::resource_limit));
  }
}

[[nodiscard]] bool positive_threshold_within_limit(
    const BigInt& threshold, const std::uint64_t maximum_steps,
    std::uint64_t& native) {
  if (threshold <= 0 || threshold > BigInt{maximum_steps}) return false;
  native = threshold.convert_to<std::uint64_t>();
  return true;
}

[[nodiscard]] ArrivalOvershootProfile unavailable_poisson_overshoot_profile(
    const CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1& law,
    const CompressionUnavailableReasonV1 reason,
    const std::uint64_t recurrence_steps = 0U) {
  ExactRational mean = ExactRational::zero();
  for (const auto& component : law.components) {
    mean = mean + component.weight * component.component_rate;
  }
  CompressionMetricStatusV1 status;
  add_reason(status, reason);
  return ArrivalOvershootProfile{
      nullptr,
      {},
      {},
      {},
      {},
      {},
      std::move(mean),
      PoissonOvershootEvaluationReportV1{
          "certified_rational_poisson_overshoot_v1", 1U,
          law.descriptor_digest, law.omitted_tail_tolerance,
          law.maximum_recurrence_steps, recurrence_steps, std::move(status)},
      reason};
}

[[nodiscard]] ArrivalOvershootProfile make_poisson_overshoot_profile(
    const CompressionAnalysisOptionsV1::PoissonMixtureOvershootV1& law,
    const std::vector<AggregateLevel>& rows,
    const std::vector<BigNat>& cutoffs) {
  const std::uint64_t query_limit = law.maximum_recurrence_steps;
  if (rows.size() > query_limit || cutoffs.size() > query_limit ||
      (!rows.empty() && !cutoffs.empty() &&
       (cutoffs.size() > query_limit / 2U ||
        rows.size() > query_limit / (cutoffs.size() * 2U)))) {
    return unavailable_poisson_overshoot_profile(
        law, CompressionUnavailableReasonV1::arrival_overshoot_work_limit);
  }
  const std::size_t maximum_queries = rows.size() * cutoffs.size() * 2U;
  try {
    std::vector<BigInt> thresholds;
    thresholds.reserve(maximum_queries);
    for (const BigNat& cutoff : cutoffs) {
      for (const auto& row : rows) {
        if (cutoff < row.backlog) break;
        const BigInt unserved = cutoff.value() - row.backlog.value();
        if (unserved > 0) thresholds.push_back(unserved);
        thresholds.push_back(unserved + 1);
      }
    }
    std::sort(thresholds.begin(), thresholds.end());
    thresholds.erase(std::unique(thresholds.begin(), thresholds.end()),
                     thresholds.end());

    std::vector<std::optional<Enclosed>> values(thresholds.size());
    std::vector<CompressionUnavailableReasonV1> reasons(
        thresholds.size(),
        CompressionUnavailableReasonV1::arrival_overshoot_work_limit);
    std::uint64_t reported_steps = 0U;
    CompressionMetricStatusV1 report_status;

    std::vector<std::uint64_t> native_thresholds(thresholds.size(), 0U);
    std::vector<bool> admitted(thresholds.size(), false);
    for (std::size_t index = 0U; index < thresholds.size(); ++index) {
      admitted[index] = positive_threshold_within_limit(
          thresholds[index], law.maximum_recurrence_steps,
          native_thresholds[index]);
    }

    std::vector<Enclosed> mixture_values(thresholds.size(), zero());
    std::vector<bool> mixture_available(thresholds.size(), true);
    ExactRational mixture_mean = ExactRational::zero();
    for (const auto& component : law.components) {
      if (component.weight.is_zero()) continue;
      mixture_mean = mixture_mean +
                     component.weight * component.component_rate;

      std::vector<bool> recurrence(thresholds.size(), false);
      std::uint64_t largest_component_threshold = 0U;
      for (std::size_t index = 0U; index < thresholds.size(); ++index) {
        const bool small_rate_tail_certificate =
            component.component_rate <= ExactRational::one() &&
            thresholds[index] >= BigInt{256};
        recurrence[index] = admitted[index] && !small_rate_tail_certificate;
        if (recurrence[index]) {
          largest_component_threshold =
              std::max(largest_component_threshold, native_thresholds[index]);
        }
      }
      if (largest_component_threshold >
          law.maximum_recurrence_steps - reported_steps) {
        for (std::size_t index = 0U; index < recurrence.size(); ++index) {
          if (recurrence[index]) {
            recurrence[index] = false;
          }
        }
        largest_component_threshold = 0U;
        add_reason(report_status,
                   CompressionUnavailableReasonV1::arrival_overshoot_work_limit);
      }

      std::vector<ExactRational> multipliers(
          thresholds.size(), ExactRational::zero());
      ExactRational term = ExactRational::one();
      ExactRational prefix_mass = ExactRational::zero();
      ExactRational prefix_first = ExactRational::zero();
      std::size_t next_query = 0U;
      for (std::uint64_t count = 0U;
           count < largest_component_threshold; ++count) {
        prefix_mass = prefix_mass + term;
        prefix_first =
            prefix_first + uint_rational(count) * term;
        const std::uint64_t threshold = count + 1U;
        while (next_query < thresholds.size() &&
               (!recurrence[next_query] ||
                native_thresholds[next_query] < threshold)) {
          ++next_query;
        }
        while (next_query < thresholds.size() && recurrence[next_query] &&
               native_thresholds[next_query] == threshold) {
          multipliers[next_query] =
              uint_rational(threshold) * prefix_mass - prefix_first;
          ++next_query;
        }
        if (threshold < largest_component_threshold) {
          term = term * component.component_rate *
                 std::move(checked_divide(ExactRational::one(),
                                          uint_rational(threshold)))
                     .value();
        }
      }
      saturating_add(reported_steps, largest_component_threshold);

      ExactRational maximum_multiplier = ExactRational::zero();
      for (std::size_t index = 0U; index < thresholds.size(); ++index) {
        if (recurrence[index]) {
          maximum_multiplier =
              maximum(maximum_multiplier, multipliers[index]);
        }
      }
      if (largest_component_threshold == 0U) {
        for (std::size_t index = 0U; index < thresholds.size(); ++index) {
          if (!mixture_available[index]) continue;
          if (component.component_rate <= ExactRational::one() &&
              thresholds[index] >= BigInt{256}) {
            const ExactRational half_tolerance =
                law.omitted_tail_tolerance *
                std::move(checked_divide(ExactRational::one(), two())).value();
            mixture_values[index] =
                add(mixture_values[index],
                    scale(Enclosed{half_tolerance, half_tolerance},
                          component.weight));
          } else {
            mixture_available[index] = false;
            reasons[index] =
                CompressionUnavailableReasonV1::arrival_overshoot_work_limit;
            add_reason(report_status, reasons[index]);
          }
        }
        continue;
      }
      const std::uint64_t remaining_recurrence_steps =
          law.maximum_recurrence_steps - reported_steps;
      auto exponential = poisson_exp_minus_interval(
          component.component_rate, maximum_multiplier,
          law.omitted_tail_tolerance, remaining_recurrence_steps);
      if (!exponential) {
        // The certified exponential evaluator has only one failure mode: it
        // consumed the admitted recurrence window without reaching the target
        // enclosure.  Account that work even though no value is published.
        saturating_add(reported_steps, remaining_recurrence_steps);
        add_reason(report_status,
                   CompressionUnavailableReasonV1::arrival_overshoot_work_limit);
        for (std::size_t index = 0U; index < mixture_available.size(); ++index) {
          if (recurrence[index]) mixture_available[index] = false;
          if (!recurrence[index] && mixture_available[index]) {
            if (component.component_rate <= ExactRational::one() &&
                thresholds[index] >= BigInt{256}) {
              const ExactRational half_tolerance =
                  law.omitted_tail_tolerance *
                  std::move(checked_divide(ExactRational::one(), two())).value();
              mixture_values[index] =
                  add(mixture_values[index],
                      scale(Enclosed{half_tolerance, half_tolerance},
                            component.weight));
            } else {
              mixture_available[index] = false;
              reasons[index] = CompressionUnavailableReasonV1::
                  arrival_overshoot_work_limit;
            }
          }
        }
        continue;
      }
      saturating_add(reported_steps,
                     exponential.value().recurrence_steps);
      for (std::size_t index = 0U; index < thresholds.size(); ++index) {
        if (!recurrence[index] || !mixture_available[index]) continue;
        const ExactRational threshold =
            integer_rational(thresholds[index]);
        ExactRational lower =
            component.component_rate - threshold +
            exponential.value().lower * multipliers[index];
        ExactRational upper =
            component.component_rate - threshold +
            exponential.value().upper * multipliers[index];
        lower = maximum(ExactRational::zero(), lower);
        upper = minimum(component.component_rate, upper);
        if (upper < lower) {
          mixture_available[index] = false;
          reasons[index] = CompressionUnavailableReasonV1::
              arrival_overshoot_numerically_unresolved;
          add_reason(report_status, reasons[index]);
          continue;
        }
        const ExactRational center =
            (lower + upper) *
            std::move(checked_divide(ExactRational::one(), two())).value();
        const ExactRational error =
            (upper - lower) *
            std::move(checked_divide(ExactRational::one(), two())).value();
        mixture_values[index] =
            add(mixture_values[index],
                scale(Enclosed{center, error}, component.weight));
      }

      // For the campaign's small Poisson rates, an arbitrary numerical cutoff
      // must not turn into an arbitrary native allocation or scan.  If r>=256
      // and theta<=1, the first omitted reward term is at most 1/(r+1)! and
      // subsequent reward-term ratios are below 2/(r+2).  Hence the complete
      // reward is below 2^(1-r), which at r=256 is already below 1e-45.  The
      // declared tolerance is therefore a certified outward enclosure for all
      // such larger thresholds without converting r to a machine integer.
      for (std::size_t index = 0U; index < thresholds.size(); ++index) {
        if (recurrence[index] || !mixture_available[index]) continue;
        if (component.component_rate <= ExactRational::one() &&
            thresholds[index] >= BigInt{256}) {
          const ExactRational half_tolerance =
              law.omitted_tail_tolerance *
              std::move(checked_divide(ExactRational::one(), two())).value();
          mixture_values[index] =
              add(mixture_values[index],
                  scale(Enclosed{half_tolerance, half_tolerance},
                        component.weight));
        } else {
          mixture_available[index] = false;
          reasons[index] =
              CompressionUnavailableReasonV1::arrival_overshoot_work_limit;
          add_reason(report_status, reasons[index]);
        }
      }
    }

    for (std::size_t index = 0U; index < thresholds.size(); ++index) {
      if (mixture_available[index]) {
        values[index] = mixture_values[index];
        reasons[index] = CompressionUnavailableReasonV1::
            arrival_overshoot_numerically_unresolved;
      }
    }
    return ArrivalOvershootProfile{
        nullptr,
        {},
        {},
        std::move(thresholds),
        std::move(values),
        std::move(reasons),
        std::move(mixture_mean),
        PoissonOvershootEvaluationReportV1{
            "certified_rational_poisson_overshoot_v1", 1U,
            law.descriptor_digest, law.omitted_tail_tolerance,
            law.maximum_recurrence_steps, reported_steps,
            std::move(report_status)},
        std::nullopt};
  } catch (const std::bad_alloc&) {
    return unavailable_poisson_overshoot_profile(
        law, CompressionUnavailableReasonV1::arrival_overshoot_work_limit);
  }
}

[[nodiscard]] std::optional<Enclosed> arrival_overshoot(
    const ArrivalOvershootProfile& profile, const BigNat& level,
    const BigNat& cutoff, const bool served,
    CompressionUnavailableReasonV1& unavailable_reason) {
  if (profile.atoms == nullptr) {
    if (profile.poisson_global_failure) {
      unavailable_reason = *profile.poisson_global_failure;
      return std::nullopt;
    }
    const BigInt threshold =
        cutoff.value() + (served ? 1 : 0) - level.value();
    if (threshold <= 0) {
      if (!profile.poisson_mean) {
        unavailable_reason = CompressionUnavailableReasonV1::
            arrival_overshoot_numerically_unresolved;
        return std::nullopt;
      }
      return exact(*profile.poisson_mean - integer_rational(threshold));
    }
    const auto found =
        std::lower_bound(profile.poisson_thresholds.begin(),
                         profile.poisson_thresholds.end(), threshold);
    if (found == profile.poisson_thresholds.end() || *found != threshold) {
      unavailable_reason = CompressionUnavailableReasonV1::
          arrival_overshoot_numerically_unresolved;
      return std::nullopt;
    }
    const std::size_t index = static_cast<std::size_t>(
        std::distance(profile.poisson_thresholds.begin(), found));
    if (!profile.poisson_values[index]) {
      unavailable_reason = profile.poisson_unavailable_reasons[index];
      return std::nullopt;
    }
    return *profile.poisson_values[index];
  }
  const BigInt threshold =
      cutoff.value() + (served ? 1 : 0) - level.value();
  const auto first = std::upper_bound(
      profile.atoms->begin(), profile.atoms->end(), threshold,
      [](const BigInt& value, const FinitePrefixFitArrivalAtomV1& atom) {
        return value < atom.count.value();
      });
  if (first == profile.atoms->end()) {
    return zero();
  }
  const std::size_t index =
      static_cast<std::size_t>(std::distance(profile.atoms->begin(), first));
  const BigInt offset =
      level.value() - cutoff.value() - (served ? 1 : 0);
  return exact(profile.suffix_first_moment[index] +
               integer_rational(offset) *
                   profile.suffix_probability[index]);
}

// For a finite arrival law, beta_K is a sum over the two moving windows
//
//   K-A < n <= K       and       K+1-A < n <= K.
//
// Sweeping the already sorted cutoffs once per arrival atom evaluates those
// windows in O(|A| (|levels| + |cutoffs|)) rather than rescanning every level
// for every cutoff.  The removable accumulator keeps centers and radii
// separately: removing a row must remove its already-accounted uncertainty,
// not widen the interval as generic interval subtraction would do.
struct RemovableWeightedMass final {
  ExactRational mass_value{ExactRational::zero()};
  ExactRational mass_error{ExactRational::zero()};
  ExactRational level_value{ExactRational::zero()};
  ExactRational level_error{ExactRational::zero()};

  void add_row(const Enclosed& mass, const BigNat& level) {
    const ExactRational coordinate = natural_rational(level);
    mass_value = mass_value + mass.value;
    mass_error = mass_error + mass.error;
    level_value = level_value + coordinate * mass.value;
    level_error = level_error + coordinate * mass.error;
  }

  void remove_row(const Enclosed& mass, const BigNat& level) {
    const ExactRational coordinate = natural_rational(level);
    mass_value = mass_value - mass.value;
    mass_error = mass_error - mass.error;
    level_value = level_value - coordinate * mass.value;
    level_error = level_error - coordinate * mass.error;
  }

  [[nodiscard]] Enclosed shifted_reward(const BigInt& offset) const {
    const ExactRational shift = integer_rational(offset);
    // Every retained coordinate has level + offset > 0.  Consequently the
    // same linear expression applies to both the center and its absolute
    // error sum, with no interval dependency or cancellation penalty.
    return Enclosed{level_value + shift * mass_value,
                    level_error + shift * mass_error};
  }
};

[[nodiscard]] std::vector<Enclosed> finite_arrival_beta_rewards(
    const std::vector<AggregateLevel>& rows,
    const std::vector<BigNat>& cutoffs,
    const std::vector<FinitePrefixFitArrivalAtomV1>& atoms) {
  std::vector<Enclosed> rewards(cutoffs.size(), zero());
  for (const auto& atom : atoms) {
    if (atom.mass.is_zero()) continue;

    std::size_t upper = 0U;
    std::size_t unserved_first = 0U;
    std::size_t served_first = 0U;
    RemovableWeightedMass unserved;
    RemovableWeightedMass served;
    for (std::size_t cutoff_index = 0U; cutoff_index < cutoffs.size();
         ++cutoff_index) {
      const BigNat& cutoff = cutoffs[cutoff_index];
      while (upper < rows.size() && rows[upper].backlog <= cutoff) {
        unserved.add_row(subtract(rows[upper].exposure, rows[upper].served),
                         rows[upper].backlog);
        served.add_row(rows[upper].served, rows[upper].backlog);
        ++upper;
      }

      const BigInt unserved_lower =
          cutoff.value() - atom.count.value();
      while (unserved_first < upper &&
             rows[unserved_first].backlog.value() <= unserved_lower) {
        unserved.remove_row(
            subtract(rows[unserved_first].exposure,
                     rows[unserved_first].served),
            rows[unserved_first].backlog);
        ++unserved_first;
      }
      const BigInt served_lower = unserved_lower + 1;
      while (served_first < upper &&
             rows[served_first].backlog.value() <= served_lower) {
        served.remove_row(rows[served_first].served,
                          rows[served_first].backlog);
        ++served_first;
      }

      const Enclosed atom_reward = add(
          unserved.shifted_reward(atom.count.value() - cutoff.value()),
          served.shifted_reward(atom.count.value() - cutoff.value() - 1));
      rewards[cutoff_index] =
          add(rewards[cutoff_index], scale(atom_reward, atom.mass));
    }
  }
  return rewards;
}

[[nodiscard]] std::optional<std::size_t> supplied_profile_index(
    const std::vector<SuppliedResponseProfileV1>& profiles,
    const BigNat& cutoff) {
  for (std::size_t index = 0U; index < profiles.size(); ++index) {
    if (profiles[index].cutoff == cutoff) {
      return index;
    }
  }
  return std::nullopt;
}

struct TailAccumulator final {
  Enclosed exposure;
  Enclosed served;
  Enclosed backlog_exposure;
  Enclosed backlog_served;
  Enclosed positive_gap;
  Enclosed negative_gap;
};

[[nodiscard]] TailAccumulator zero_tail() {
  return TailAccumulator{zero(), zero(), zero(), zero(), zero(), zero()};
}

void add_tail(TailAccumulator& destination,
              const TailAccumulator& source) {
  destination.exposure = add(destination.exposure, source.exposure);
  destination.served = add(destination.served, source.served);
  destination.backlog_exposure =
      add(destination.backlog_exposure, source.backlog_exposure);
  destination.backlog_served =
      add(destination.backlog_served, source.backlog_served);
  destination.positive_gap =
      add(destination.positive_gap, source.positive_gap);
  destination.negative_gap =
      add(destination.negative_gap, source.negative_gap);
}

struct ReplicationTailBucket final {
  TailAccumulator value;
  std::size_t missing_gap_rows;
};

[[nodiscard]] std::pair<Enclosed, Enclosed> boundary_moments(
    const BoundaryBacklogLawV1& law) {
  Enclosed first = zero();
  Enclosed second = zero();
  for (const BoundaryBacklogMassV1& row : law.rows) {
    const ExactRational level = natural_rational(row.backlog_level);
    const Enclosed mass = scalar_value(row.mass);
    first = add(first, scale(mass, level));
    second = add(second, scale(mass, level * level));
  }
  return {std::move(first), std::move(second)};
}

[[nodiscard]] CompressionReplicationInclusionV1 replication_inclusion(
    const ConstructionObservationReplicationV1& replication,
    const ConstructionObservationBundleV1& bundle) noexcept {
  if (replication.completeness == ObservationCompletenessV1::complete &&
      replication.committed_through_boundary == bundle.end_boundary) {
    return CompressionReplicationInclusionV1::included_complete;
  }
  if (replication.completeness == ObservationCompletenessV1::partial) {
    return CompressionReplicationInclusionV1::excluded_incomplete;
  }
  // This state is unreachable for a validated V1 observation, but retaining
  // it in the publication model prevents completeness and endpoint agreement
  // from being silently conflated if a later validated carrier widens the
  // admissible states.
  return CompressionReplicationInclusionV1::excluded_boundary_mismatch;
}

// Produce independently attributable raw summaries for every wire
// replication, including partial records.  Each already-sorted block and the
// sorted cutoff vector are traversed in reverse together.  This is
// O(rows + blocks*K), keeps memory O(K), and is independent of the largest
// numerical cutoff.  No per-replication division or fit is performed.
[[nodiscard]] std::vector<CompressionReplicationSummaryV1>
summarize_replications(
    const ConstructionObservationBundleV1& bundle,
    const std::vector<BigNat>& cutoffs,
    CompressionAnalysisWorkCountersV1& work) {
  const std::size_t cutoff_count = cutoffs.size();
  std::vector<CompressionReplicationSummaryV1> summaries;
  summaries.reserve(bundle.replications.size());
  record_allocation_events(work);
  std::size_t retained_cutoff_rows = 0U;
  std::size_t retained_cutoff_capacity = 0U;
  for (const ConstructionObservationReplicationV1& replication :
       bundle.replications) {
    TailAccumulator totals = zero_tail();
    std::vector<ReplicationTailBucket> cutoff_tails(
        cutoff_count,
        ReplicationTailBucket{zero_tail(), 0U});
    record_allocation_events(work);

    for (const ConstructionObservationBlockV1& block : replication.blocks) {
      saturating_add(work.input_level_rows,
                     bounded_u64(block.levels.size()));
      saturating_add(
          work.input_row_bytes,
          saturated_product(bounded_u64(block.levels.size()),
                            bounded_u64(sizeof(ExactLevelObservationV1))));
      for (const ExactLevelObservationV1& row : block.levels) {
        const Enclosed row_exposure = scalar_value(row.exposure_mass);
        const Enclosed row_served = scalar_value(row.served_mass);
        const ExactRational level = natural_rational(row.backlog_level);
        const Enclosed row_backlog_exposure = scale(row_exposure, level);
        const Enclosed row_backlog_served = scale(row_served, level);
        totals.exposure = add(totals.exposure, row_exposure);
        totals.served = add(totals.served, row_served);
        totals.backlog_exposure =
            add(totals.backlog_exposure, row_backlog_exposure);
        totals.backlog_served =
            add(totals.backlog_served, row_backlog_served);

      }

      TailAccumulator suffix = zero_tail();
      std::size_t missing_gap_rows = 0U;
      std::size_t row_index = block.levels.size();
      for (std::size_t reverse = cutoff_count; reverse > 0U; --reverse) {
        const std::size_t cutoff_index = reverse - 1U;
        while (row_index > 0U &&
               cutoffs[cutoff_index] <
                   block.levels[row_index - 1U].backlog_level) {
          --row_index;
          const ExactLevelObservationV1& row = block.levels[row_index];
          const Enclosed row_exposure = scalar_value(row.exposure_mass);
          const Enclosed row_served = scalar_value(row.served_mass);
          const ExactRational level = natural_rational(row.backlog_level);
          suffix.exposure = add(suffix.exposure, row_exposure);
          suffix.served = add(suffix.served, row_served);
          suffix.backlog_exposure =
              add(suffix.backlog_exposure, scale(row_exposure, level));
          suffix.backlog_served =
              add(suffix.backlog_served, scale(row_served, level));
          if (row.gap) {
            suffix.positive_gap =
                add(suffix.positive_gap,
                    scalar_value(row.gap->positive_magnitude_mass));
            suffix.negative_gap =
                add(suffix.negative_gap,
                    scalar_value(row.gap->negative_magnitude_mass));
          } else {
            ++missing_gap_rows;
          }
        }
        add_tail(cutoff_tails[cutoff_index].value, suffix);
        cutoff_tails[cutoff_index].missing_gap_rows += missing_gap_rows;
      }
    }

    std::optional<CompressionNumericalValueV1> initial_first;
    std::optional<CompressionNumericalValueV1> committed_first;
    std::optional<CompressionNumericalValueV1> initial_second;
    std::optional<CompressionNumericalValueV1> committed_second;
    if (!replication.blocks.empty()) {
      const BoundaryBacklogLawV1& initial =
          replication.blocks.front().initial_boundary_law;
      const BoundaryBacklogLawV1& committed =
          replication.blocks.back().committed_boundary_law;
      saturating_add(work.input_boundary_rows,
                     bounded_u64(initial.rows.size()));
      saturating_add(work.input_boundary_rows,
                     bounded_u64(committed.rows.size()));
      saturating_add(
          work.input_row_bytes,
          saturated_product(
              saturated_sum(bounded_u64(initial.rows.size()),
                            bounded_u64(committed.rows.size())),
              bounded_u64(sizeof(BoundaryBacklogMassV1))));
      auto [first_initial, second_initial] = boundary_moments(initial);
      auto [first_committed, second_committed] =
          boundary_moments(committed);
      initial_first = public_value(first_initial);
      committed_first = public_value(first_committed);
      initial_second = public_value(second_initial);
      committed_second = public_value(second_committed);
    }

    std::vector<CompressionReplicationCutoffSummaryV1> cutoff_summaries;
    cutoff_summaries.reserve(cutoff_count);
    record_allocation_events(work);
    const bool certified_gap_telemetry =
        bundle.capabilities.certified_gap_probe.available;
    for (std::size_t cutoff_index = 0U; cutoff_index < cutoff_count;
         ++cutoff_index) {
      const ReplicationTailBucket& tail = cutoff_tails[cutoff_index];
      cutoff_summaries.push_back(CompressionReplicationCutoffSummaryV1{
          cutoffs[cutoff_index],
          public_value(tail.value.exposure),
          public_value(tail.value.served),
          public_value(tail.value.backlog_exposure),
          public_value(tail.value.backlog_served),
          certified_gap_telemetry && tail.missing_gap_rows == 0U
              ? std::optional<CompressionNumericalValueV1>(
                    public_value(tail.value.positive_gap))
              : std::nullopt,
          certified_gap_telemetry && tail.missing_gap_rows == 0U
              ? std::optional<CompressionNumericalValueV1>(
                    public_value(tail.value.negative_gap))
              : std::nullopt});
    }

    const std::uint64_t measured_slots =
        replication.committed_through_boundary - bundle.warmup_boundary;
    retained_cutoff_rows += cutoff_summaries.size();
    summaries.push_back(CompressionReplicationSummaryV1{
        replication.replication_id,
        replication.completeness,
        replication_inclusion(replication, bundle),
        BigNat{measured_slots},
        public_value(totals.exposure),
        public_value(totals.served),
        public_value(totals.backlog_exposure),
        public_value(totals.backlog_served),
        std::move(initial_first),
        std::move(committed_first),
        std::move(initial_second),
        std::move(committed_second),
        std::move(cutoff_summaries)});
    retained_cutoff_capacity += summaries.back().cutoffs.capacity();
    record_retained(
        work,
        cutoff_tails.size() + summaries.size() + retained_cutoff_rows,
        cutoff_tails.capacity() * sizeof(ReplicationTailBucket) +
            summaries.capacity() * sizeof(CompressionReplicationSummaryV1) +
            retained_cutoff_capacity *
                sizeof(CompressionReplicationCutoffSummaryV1));
  }
  return summaries;
}

struct CoreAnalysis final {
  CompressionAnalysisResultV1 result;
  std::vector<std::size_t> included_replication_indices;
};

[[nodiscard]] Result<CoreAnalysis> analyze_core(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisOptionsV1& options,
    const Digest256& analysis_digest,
    const std::optional<std::size_t> omitted_replication);

[[nodiscard]] CompressionMetricStatusV1 iid_unavailable_status(
    const ConstructionObservationBundleV1& bundle) {
  CompressionMetricStatusV1 status;
  if (!bundle.capabilities.iid_fresh_arrivals.available) {
    add_reason(status,
               CompressionUnavailableReasonV1::unsupported_arrival_identity);
  }
  if (!expected_slot_convention(bundle.slot_convention, bundle.source_role)) {
    add_reason(status,
               CompressionUnavailableReasonV1::unsupported_slot_convention);
  }
  if (!bundle.capabilities.no_target_drops.available) {
    add_reason(status, CompressionUnavailableReasonV1::target_drop_possible);
  }
  return status;
}

[[nodiscard]] CompressionQuantityV1 unavailable_from_status(
    CompressionMetricStatusV1 status) {
  if (status.unavailable_reasons.empty()) {
    add_reason(status,
               CompressionUnavailableReasonV1::fitted_law_unavailable);
  }
  return CompressionQuantityV1{std::nullopt, std::move(status)};
}

[[nodiscard]] CompressionMetricStatusV1 gap_unavailable_status(
    const ConstructionObservationBundleV1& bundle,
    const bool complete_gap_rows) {
  CompressionMetricStatusV1 status;
  if (!complete_gap_rows) {
    add_reason(status,
               CompressionUnavailableReasonV1::gap_telemetry_unavailable);
  }
  if (!bundle.capabilities.exact_primary_maxweight.available) {
    add_reason(status,
               CompressionUnavailableReasonV1::inexact_primary_optimizer);
  }
  if (!bundle.capabilities.unit_target_multiplier.available ||
      bundle.bindings.target.maxweight_multiplier != ExactRational::one()) {
    add_reason(status,
               CompressionUnavailableReasonV1::unsupported_target_multiplier);
  }
  if (!bundle.capabilities.certified_gap_probe.available) {
    add_reason(status,
               CompressionUnavailableReasonV1::unsupported_gap_topology);
  }
  return status;
}

[[nodiscard]] CompressionQuantityV1 fit_mean_quantity(
    const CompressionCutoffAnalysisV1& cutoff) {
  return cutoff.diagnostic_fitted_mean;
}

[[nodiscard]] Result<CoreAnalysis> analyze_core(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisOptionsV1& options,
    const Digest256& analysis_digest,
    const std::optional<std::size_t> omitted_replication) {
  const ConstructionObservationBundleV1& bundle = observation.value();
  if (options.cutoffs.empty()) {
    return Result<CoreAnalysis>::failure(diagnostic(
        "compression.cutoff_empty",
        "compression analysis requires at least one diagnostic cutoff"));
  }

  std::vector<BigNat> cutoffs = options.cutoffs;
  std::sort(cutoffs.begin(), cutoffs.end());
  if (std::adjacent_find(cutoffs.begin(), cutoffs.end()) != cutoffs.end()) {
    return Result<CoreAnalysis>::failure(diagnostic(
        "compression.cutoff_duplicate",
        "compression analysis cutoffs must be unique"));
  }
  const bool sparse_empirical_mode =
      options.projection_mode ==
      CompressionAnalysisOptionsV1::ProjectionMode::
          empirical_finite_window_response;
  std::vector<std::size_t> native_cutoffs;
  CompressionAnalysisWorkCountersV1 work{};
  if (!sparse_empirical_mode) {
    native_cutoffs.reserve(cutoffs.size());
    record_allocation_events(work);
    for (const BigNat& cutoff : cutoffs) {
      auto native = native_cutoff(cutoff, options.fit_limits.maximum_cutoff);
      if (!native) {
        return Result<CoreAnalysis>::failure(native.error());
      }
      native_cutoffs.push_back(native.value());
    }
  }

  // Delete-one cores are transient estimator inputs; publishing their raw
  // summaries would add O(R^2*K) retained data without changing a resample.
  // The point analysis publishes every wire replication exactly once.
  std::vector<CompressionReplicationSummaryV1> replication_summaries;
  if (!omitted_replication) {
    replication_summaries =
        summarize_replications(bundle, cutoffs, work);
  }
  std::size_t replication_summary_cutoff_objects = 0U;
  std::size_t replication_summary_bytes =
      replication_summaries.capacity() *
      sizeof(CompressionReplicationSummaryV1);
  for (const CompressionReplicationSummaryV1& summary :
       replication_summaries) {
    replication_summary_cutoff_objects += summary.cutoffs.size();
    replication_summary_bytes +=
        summary.cutoffs.capacity() *
        sizeof(CompressionReplicationCutoffSummaryV1);
  }
  const std::size_t replication_summary_objects =
      replication_summaries.size() + replication_summary_cutoff_objects;

  const std::vector<std::size_t> replication_indices =
      complete_replication_indices(bundle, omitted_replication);
  record_allocation_events(work);
  const std::size_t complete_total = static_cast<std::size_t>(std::count_if(
      bundle.replications.begin(), bundle.replications.end(),
      [&bundle](const ConstructionObservationReplicationV1& replication) {
        return replication.completeness ==
                   ObservationCompletenessV1::complete &&
               replication.committed_through_boundary == bundle.end_boundary;
      }));
  const std::size_t partial_total =
      bundle.replications.size() - complete_total;

  std::vector<AggregateLevel> rows =
      pool_levels(bundle, replication_indices, work,
                  omitted_replication.has_value());
  Enclosed exposure = zero();
  Enclosed served = zero();
  Enclosed backlog_exposure = zero();
  Enclosed backlog_served = zero();
  AggregateGap gap_total = zero_gap();
  bool complete_gap_rows = !rows.empty();
  std::vector<PooledObservationLevelV1> public_levels;
  public_levels.reserve(rows.size());
  record_allocation_events(work);
  for (const auto& row : rows) {
    exposure = add(exposure, row.exposure);
    served = add(served, row.served);
    const ExactRational level = natural_rational(row.backlog);
    backlog_exposure = add(backlog_exposure, scale(row.exposure, level));
    backlog_served = add(backlog_served, scale(row.served, level));
    if (row.gap_seen && !row.gap_missing) {
      gap_total.negative = add(gap_total.negative, row.gap.negative);
      gap_total.tie = add(gap_total.tie, row.gap.tie);
      gap_total.positive = add(gap_total.positive, row.gap.positive);
      gap_total.tied_and_served =
          add(gap_total.tied_and_served, row.gap.tied_and_served);
      gap_total.positive_magnitude =
          add(gap_total.positive_magnitude, row.gap.positive_magnitude);
      gap_total.negative_magnitude =
          add(gap_total.negative_magnitude, row.gap.negative_magnitude);
    } else {
      complete_gap_rows = false;
    }
    public_levels.push_back(PooledObservationLevelV1{
        row.backlog, public_value(row.exposure), public_value(row.served),
        row.gap_seen && !row.gap_missing
            ? std::optional<PooledGapCellV1>(public_gap(row.gap))
            : std::nullopt});
  }
  record_retained(
      work,
      replication_summary_objects + rows.size() + public_levels.size(),
      replication_summary_bytes +
      rows.capacity() * sizeof(AggregateLevel) +
          public_levels.capacity() * sizeof(PooledObservationLevelV1));

  BigInt slot_count_value = 0;
  for (const std::size_t ignored : replication_indices) {
    static_cast<void>(ignored);
    slot_count_value += BigInt{bundle.end_boundary - bundle.warmup_boundary};
  }
  auto slot_count_result = BigNat::from_big_int(slot_count_value);
  if (!slot_count_result) {
    return Result<CoreAnalysis>::failure(slot_count_result.error());
  }
  BigNat slot_count = std::move(slot_count_result).value();
  const Enclosed slot_count_scalar = exact(natural_rational(slot_count));

  CompressionMetricStatusV1 pooled_status;
  if (replication_indices.empty() || slot_count.is_zero()) {
    add_reason(pooled_status,
               CompressionUnavailableReasonV1::no_complete_replication);
  }
  if (provably_zero(exposure)) {
    add_reason(pooled_status, CompressionUnavailableReasonV1::no_exposure);
  }
  if (partial_total != 0U) {
    add_warning(pooled_status,
                CompressionWarningCodeV1::partial_replications_excluded);
  }
  if (has_numerical_error(rows)) {
    add_warning(pooled_status,
                CompressionWarningCodeV1::numerical_enclosure_required);
  }

  const auto mass_per_slot = divide(exposure, slot_count_scalar);
  const std::optional<Enclosed> mass_defect =
      mass_per_slot
          ? std::optional<Enclosed>(subtract(*mass_per_slot, one()))
          : std::nullopt;
  if (mass_defect && excludes_zero(*mass_defect)) {
    add_warning(pooled_status,
                CompressionWarningCodeV1::nonunit_recorded_mass);
  }

  const auto departure_rate = divide(served, exposure);
  const auto observed_mean = divide(backlog_exposure, exposure);
  const auto service_moment = divide(backlog_served, exposure);
  const auto departure_rate_star = divide(served, slot_count_scalar);
  const auto observed_mean_star = divide(backlog_exposure, slot_count_scalar);
  const auto service_moment_star = divide(backlog_served, slot_count_scalar);
  const bool normalized_moments_available =
      departure_rate && observed_mean && service_moment;
  if (!provably_zero(exposure) && !normalized_moments_available) {
    add_reason(
        pooled_status,
        CompressionUnavailableReasonV1::denominator_enclosure_contains_zero);
  }

  const auto normalized_reason =
      provably_zero(exposure)
          ? CompressionUnavailableReasonV1::no_exposure
          : CompressionUnavailableReasonV1::
                denominator_enclosure_contains_zero;
  const auto per_slot_reason =
      CompressionUnavailableReasonV1::no_complete_replication;

  std::optional<EmpiricalFiniteWindowResponseV1> raw_response;
  std::size_t raw_response_point_capacity = 0U;
  if (sparse_empirical_mode && !omitted_replication) {
    std::vector<EmpiricalFiniteWindowResponsePointV1> observed_levels;
    observed_levels.reserve(rows.size());
    record_allocation_events(work);
    std::optional<BigNat> complete_through;
    BigInt next_complete_level = 0;
    bool complete_prefix_open = true;
    for (const AggregateLevel& row : rows) {
      EmpiricalFiniteWindowPointStatusV1 point_status;
      CompressionQuantityV1 response;
      const bool exposure_separated_from_zero =
          row.exposure.value - row.exposure.error > ExactRational::zero();
      if (row.backlog.is_zero()) {
        point_status =
            EmpiricalFiniteWindowPointStatusV1::structural_zero;
        CompressionMetricStatusV1 response_status;
        add_warning(response_status,
                    CompressionWarningCodeV1::structural_zero_response);
        if (!exposure_separated_from_zero) {
          add_reason(response_status,
                     CompressionUnavailableReasonV1::no_exposure);
        }
        response = CompressionQuantityV1{public_value(zero()),
                                         std::move(response_status)};
      } else if (provably_zero(row.exposure)) {
        point_status = EmpiricalFiniteWindowPointStatusV1::no_exposure;
        response = unavailable(CompressionUnavailableReasonV1::no_exposure);
      } else {
        auto ratio = divide(row.served, row.exposure);
        if (!ratio) {
          point_status = EmpiricalFiniteWindowPointStatusV1::
              denominator_enclosure_contains_zero;
          response = unavailable(CompressionUnavailableReasonV1::
                                     denominator_enclosure_contains_zero);
        } else {
          point_status = EmpiricalFiniteWindowPointStatusV1::available;
          response = available(*ratio);
          if (provably_zero(row.served)) {
            add_warning(response.status,
                        CompressionWarningCodeV1::
                            exposure_without_observed_service);
          }
        }
      }
      if (complete_prefix_open) {
        if (row.backlog.value() == next_complete_level &&
            exposure_separated_from_zero) {
          complete_through = row.backlog;
          ++next_complete_level;
        } else if (row.backlog.value() >= next_complete_level) {
          complete_prefix_open = false;
        }
      }
      observed_levels.push_back(EmpiricalFiniteWindowResponsePointV1{
          row.backlog, public_value(row.exposure), public_value(row.served),
          point_status, std::move(response)});
    }
    std::optional<BigNat> highest_observed_level;
    std::optional<BigNat> coordinate_extent;
    if (!rows.empty()) {
      highest_observed_level = rows.back().backlog;
      coordinate_extent = rows.back().backlog;
      ++*coordinate_extent;
    }
    raw_response_point_capacity = observed_levels.capacity();
    raw_response.emplace(EmpiricalFiniteWindowResponseV1{
        observation.digest(),
        bundle.source_role,
        bundle.bindings,
        bundle.warmup_boundary,
        bundle.end_boundary,
        bundle.reporting_block_boundaries,
        options.ensemble_population_size,
        bundle.replications.size(),
        replication_indices.size(),
        partial_total,
        std::move(observed_levels),
        BigNat{rows.size()},
        std::move(highest_observed_level),
        std::move(coordinate_extent),
        std::move(complete_through),
        public_value(exposure),
        mass_per_slot ? available(*mass_per_slot)
                      : unavailable(per_slot_reason),
        mass_defect ? available(*mass_defect) : unavailable(per_slot_reason),
        EmpiricalFiniteWindowInterpretationV1::finite_window,
        EmpiricalFiniteWindowTailCompletionV1::none,
        pooled_status});
  }

  PooledObservationMomentsV1 pooled{
      slot_count,
      replication_indices.size(),
      partial_total,
      std::move(public_levels),
      public_value(exposure),
      mass_per_slot ? available(*mass_per_slot)
                    : unavailable(per_slot_reason),
      mass_defect ? available(*mass_defect) : unavailable(per_slot_reason),
      departure_rate ? available(*departure_rate)
                     : unavailable(normalized_reason),
      observed_mean ? available(*observed_mean)
                    : unavailable(normalized_reason),
      service_moment ? available(*service_moment)
                     : unavailable(normalized_reason),
      departure_rate_star ? available(*departure_rate_star)
                          : unavailable(per_slot_reason),
      observed_mean_star ? available(*observed_mean_star)
                         : unavailable(per_slot_reason),
      service_moment_star ? available(*service_moment_star)
                          : unavailable(per_slot_reason),
      pooled_status};

  auto arrival = arrival_data(bundle, options);
  if (!arrival) {
    return Result<CoreAnalysis>::failure(arrival.error());
  }
  ArrivalData arrivals = std::move(arrival).value();
  const ArrivalOvershootProfile arrival_overshoots =
      arrivals.poisson_overshoot != nullptr
          ? make_poisson_overshoot_profile(*arrivals.poisson_overshoot, rows,
                                           cutoffs)
          : make_arrival_overshoot_profile(arrivals.atoms);
  const bool arrival_overshoot_available =
      arrivals.exact_marginal || arrivals.poisson_overshoot != nullptr;
  const std::size_t overshoot_entries =
      arrival_overshoots.suffix_probability.size() +
      arrival_overshoots.suffix_first_moment.size() +
      arrival_overshoots.poisson_thresholds.size() +
      arrival_overshoots.poisson_values.size();
  if (overshoot_entries != 0U) {
    record_allocation_events(work, 2U);
  }
  const bool iid_supported = iid_balance_supported(bundle);
  std::optional<std::vector<Enclosed>> finite_beta_rewards;
  // Choose the atom sweep only when it cannot do more row passes than the
  // cutoff-oriented evaluator.  Larger count tables retain the existing
  // cutoff sweep, whose per-row overshoot lookup is logarithmic in atoms.
  if (iid_supported && arrivals.exact_marginal &&
      arrivals.atoms.size() <= cutoffs.size()) {
    finite_beta_rewards =
        finite_arrival_beta_rewards(rows, cutoffs, arrivals.atoms);
    record_allocation_events(work);
  }
  const std::size_t finite_beta_entries =
      finite_beta_rewards ? finite_beta_rewards->size() : 0U;
  const bool second_moment_supported =
      iid_supported && arrivals.second_moment_available;
  const bool normalized_second_moment_supported =
      second_moment_supported && normalized_moments_available;
  const ExactRational lambda = arrivals.mean;
  const ExactRational one_minus_two_lambda =
      ExactRational::one() - two() * lambda;
  const Enclosed lambda_value = exact(lambda);
  const Enclosed second_moment_value = exact(arrivals.second_moment);
  const Enclosed balance_constant =
      second_moment_supported
          ? scale(add(add(second_moment_value, lambda_value),
                      negate(scale(multiply(lambda_value, lambda_value), two()))),
                  std::move(checked_divide(ExactRational::one(), two())).value())
          : zero();

  const Enclosed normalized_mean = observed_mean.value_or(zero());
  const Enclosed normalized_service_moment = service_moment.value_or(zero());
  const Enclosed starred_departure = departure_rate_star.value_or(zero());
  const Enclosed starred_mean = observed_mean_star.value_or(zero());
  const Enclosed starred_service_moment = service_moment_star.value_or(zero());
  const Enclosed empirical_z =
      second_moment_supported && normalized_moments_available
          ? subtract(subtract(normalized_service_moment,
                              multiply(lambda_value, normalized_mean)),
                     balance_constant)
          : zero();
  const Enclosed starred_z =
      second_moment_supported
          ? subtract(subtract(starred_service_moment,
                              multiply(lambda_value, starred_mean)),
                     balance_constant)
          : zero();

  std::vector<AggregateBoundaryLevel> start_boundary;
  std::vector<AggregateBoundaryLevel> end_boundary;
  bool boundaries_available =
      !replication_indices.empty() && !slot_count.is_zero();
  for (const std::size_t index : replication_indices) {
    if (bundle.replications[index].blocks.empty()) {
      boundaries_available = false;
      break;
    }
  }
  if (boundaries_available) {
    start_boundary =
        pool_boundaries(bundle, replication_indices, false, work,
                        omitted_replication.has_value());
    end_boundary =
        pool_boundaries(bundle, replication_indices, true, work,
                        omitted_replication.has_value());
  }
  record_retained(
      work,
      replication_summary_objects + rows.size() + public_levels.size() +
          raw_response_point_capacity + start_boundary.size() +
          end_boundary.size(),
      replication_summary_bytes + rows.capacity() * sizeof(AggregateLevel) +
          public_levels.capacity() * sizeof(PooledObservationLevelV1) +
          raw_response_point_capacity *
              sizeof(EmpiricalFiniteWindowResponsePointV1) +
          start_boundary.capacity() * sizeof(AggregateBoundaryLevel) +
          end_boundary.capacity() * sizeof(AggregateBoundaryLevel));
  const Enclosed start_first =
      boundaries_available ? weighted_level_sum(start_boundary, false) : zero();
  const Enclosed end_first =
      boundaries_available ? weighted_level_sum(end_boundary, false) : zero();
  const Enclosed start_second =
      boundaries_available ? weighted_level_sum(start_boundary, true) : zero();
  const Enclosed end_second =
      boundaries_available ? weighted_level_sum(end_boundary, true) : zero();
  const auto eta_one = boundaries_available
                           ? divide(subtract(end_first, start_first),
                                    slot_count_scalar)
                           : std::nullopt;
  const auto eta_two = boundaries_available
                           ? divide(subtract(end_second, start_second),
                                    slot_count_scalar)
                           : std::nullopt;
  const std::vector<Enclosed> start_hinges =
      boundaries_available
          ? boundary_hinge_rewards(start_boundary, cutoffs)
          : std::vector<Enclosed>(cutoffs.size(), zero());
  const std::vector<Enclosed> end_hinges =
      boundaries_available
          ? boundary_hinge_rewards(end_boundary, cutoffs)
          : std::vector<Enclosed>(cutoffs.size(), zero());

  std::vector<TailAccumulator> tail_accumulators(cutoffs.size(), zero_tail());
  record_allocation_events(work);
  std::size_t row_index = rows.size();
  TailAccumulator running_tail = zero_tail();
  for (std::size_t reverse = cutoffs.size(); reverse > 0U; --reverse) {
    const std::size_t cutoff_index = reverse - 1U;
    while (row_index > 0U && cutoffs[cutoff_index] < rows[row_index - 1U].backlog) {
      --row_index;
      const auto& row = rows[row_index];
      const ExactRational level = natural_rational(row.backlog);
      running_tail.exposure = add(running_tail.exposure, row.exposure);
      running_tail.served = add(running_tail.served, row.served);
      running_tail.backlog_exposure =
          add(running_tail.backlog_exposure, scale(row.exposure, level));
      running_tail.backlog_served =
          add(running_tail.backlog_served, scale(row.served, level));
      if (row.gap_seen && !row.gap_missing) {
        running_tail.positive_gap =
            add(running_tail.positive_gap, row.gap.positive_magnitude);
        running_tail.negative_gap =
            add(running_tail.negative_gap, row.gap.negative_magnitude);
      }
    }
    tail_accumulators[cutoff_index] = running_tail;
  }

  std::vector<CompressionCutoffAnalysisV1> cutoff_results;
  cutoff_results.reserve(cutoffs.size());
  std::vector<FiniteWindowCutoffAnalysisV1> finite_cutoffs;
  finite_cutoffs.reserve(cutoffs.size());
  std::vector<CompetitionCutoffAnalysisV1> competition_cutoffs;
  competition_cutoffs.reserve(cutoffs.size());
  record_allocation_events(work, 3U);

  const CompressionMetricStatusV1 iid_failure = iid_unavailable_status(bundle);
  const CompressionMetricStatusV1 gap_failure =
      gap_unavailable_status(bundle, complete_gap_rows);
  std::size_t retained_prefix_rows = 0U;

  for (std::size_t cutoff_index = 0U; cutoff_index < cutoffs.size();
       ++cutoff_index) {
    const BigNat& cutoff = cutoffs[cutoff_index];
    const std::optional<std::size_t> cutoff_native =
        sparse_empirical_mode
            ? std::nullopt
            : std::optional<std::size_t>(native_cutoffs[cutoff_index]);
    const TailAccumulator& raw_tail = tail_accumulators[cutoff_index];

    const auto tau = divide(raw_tail.exposure, exposure);
    const auto b = divide(raw_tail.served, exposure);
    const auto u = divide(raw_tail.backlog_exposure, exposure);
    const auto v = divide(raw_tail.backlog_served, exposure);
    const auto tau_star = divide(raw_tail.exposure, slot_count_scalar);
    const auto normalized_reason =
        provably_zero(exposure)
            ? CompressionUnavailableReasonV1::no_exposure
            : CompressionUnavailableReasonV1::
                  denominator_enclosure_contains_zero;

    FourTailRewardsV1 tail;
    tail.tail_probability =
        tau ? available(*tau)
            : unavailable(normalized_reason);
    tail.tail_service_mass =
        b ? available(*b)
          : unavailable(normalized_reason);
    tail.backlog_tail_reward =
        u ? available(*u)
          : unavailable(normalized_reason);
    tail.backlog_service_tail_reward =
        v ? available(*v)
          : unavailable(normalized_reason);

    std::optional<Enclosed> c;
    std::optional<Enclosed> delta;
    std::optional<Enclosed> association;
    CompressionUnavailableReasonV1 coefficient_absence_reason =
        !tau ? normalized_reason
             : (provably_zero(*tau)
                    ? CompressionUnavailableReasonV1::no_tail_exposure
                    : CompressionUnavailableReasonV1::
                          denominator_enclosure_contains_zero);
    if (!tau) {
      tail.constant_tail_response = unavailable(normalized_reason);
      tail.tail_slack = unavailable(normalized_reason);
      tail.discarded_association_reward = unavailable(normalized_reason);
      tail.tail_association_ratio = unavailable(normalized_reason);
      tail.stationary_compression_defect = unavailable(normalized_reason);
      add_reason(tail.status, normalized_reason);
    } else if (provably_zero(*tau)) {
      tail.constant_tail_response =
          unavailable(CompressionUnavailableReasonV1::no_tail_exposure);
      tail.tail_slack =
          unavailable(CompressionUnavailableReasonV1::no_tail_exposure);
      tail.discarded_association_reward =
          unavailable(CompressionUnavailableReasonV1::no_tail_exposure);
      tail.tail_association_ratio =
          unavailable(CompressionUnavailableReasonV1::no_tail_exposure);
      tail.stationary_compression_defect =
          unavailable(CompressionUnavailableReasonV1::no_tail_exposure);
      add_reason(tail.status,
                 CompressionUnavailableReasonV1::no_tail_exposure);
    } else {
      c = divide(*b, *tau);
      if (!c) {
        const auto reason =
            CompressionUnavailableReasonV1::denominator_enclosure_contains_zero;
        tail.constant_tail_response = unavailable(reason);
        tail.tail_slack = unavailable(reason);
        tail.discarded_association_reward = unavailable(reason);
        tail.tail_association_ratio = unavailable(reason);
        tail.stationary_compression_defect = unavailable(reason);
        add_reason(tail.status,
                   reason);
      } else {
        delta = subtract(*c, lambda_value);
        association = subtract(*v, multiply(*c, *u));
        tail.constant_tail_response = available(*c);
        tail.tail_slack = available(*delta);
        tail.discarded_association_reward = available(*association);
        if (provably_zero(*delta)) {
          tail.tail_association_ratio =
              unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
        } else {
          tail.tail_association_ratio = divided_quantity(
              *association, *delta,
              CompressionUnavailableReasonV1::zero_tail_slack);
        }

        CompressionMetricStatusV1 stationary_status;
        if (!options.stationary_coefficients_established) {
          add_reason(stationary_status,
                     CompressionUnavailableReasonV1::stationary_hypotheses_unavailable);
        }
        if (!options.prefix_preservation_established) {
          add_reason(stationary_status,
                     CompressionUnavailableReasonV1::prefix_preservation_unavailable);
        }
        if (!delta->value.is_positive() ||
            delta->value - delta->error <= ExactRational::zero()) {
          add_reason(stationary_status,
                     provably_zero(*delta)
                         ? CompressionUnavailableReasonV1::zero_tail_slack
                         : (delta->value.is_positive()
                                ? CompressionUnavailableReasonV1::
                                      denominator_enclosure_contains_zero
                                : CompressionUnavailableReasonV1::
                                      nonpositive_tail_slack));
        }
        if (stationary_status.available()) {
          tail.stationary_compression_defect = divided_quantity(
              *association, *delta,
              CompressionUnavailableReasonV1::zero_tail_slack);
          add_warning(tail.stationary_compression_defect.status,
                      CompressionWarningCodeV1::stationary_interpretation_is_estimated);
        } else {
          tail.stationary_compression_defect =
              unavailable_from_status(std::move(stationary_status));
        }
        if (options.ill_conditioned_slack_threshold &&
            delta->value.is_positive() &&
            delta->value - delta->error > ExactRational::zero() &&
            delta->value <= *options.ill_conditioned_slack_threshold) {
          add_warning(tail.tail_slack.status,
                      CompressionWarningCodeV1::ill_conditioned_tail_slack);
          add_warning(tail.status,
                      CompressionWarningCodeV1::ill_conditioned_tail_slack);
        }
      }
    }
    if (observed_mean && !provably_zero(*observed_mean) && u) {
      tail.tail_mean_fraction = divided_quantity(
          *u, *observed_mean,
          CompressionUnavailableReasonV1::zero_observed_mean);
    } else {
      tail.tail_mean_fraction = unavailable(
          observed_mean
              ? CompressionUnavailableReasonV1::zero_observed_mean
              : CompressionUnavailableReasonV1::
                    denominator_enclosure_contains_zero);
    }

    std::vector<EmpiricalResponsePointV1> prefix;
    CompressionMetricStatusV1 profile_status;
    std::vector<ExactRational> fit_services;
    std::vector<Enclosed> fit_service_enclosures;
    bool fit_profile_complete = c.has_value() && cutoff_native.has_value();
    if (cutoff_native) {
      prefix.reserve(*cutoff_native + 1U);
      fit_services.reserve(*cutoff_native + 1U);
      fit_service_enclosures.reserve(*cutoff_native + 1U);
      record_allocation_events(work, 3U);
      for (std::size_t level_index = 0U; level_index <= *cutoff_native;
           ++level_index) {
        const BigNat level{static_cast<std::uint64_t>(level_index)};
        const AggregateLevel* row = find_level(rows, level);
        const Enclosed row_exposure = row ? row->exposure : zero();
        const Enclosed row_served = row ? row->served : zero();
        const auto probability = divide(row_exposure, exposure);
        const auto service_mass = divide(row_served, exposure);
        if (!probability || !service_mass) {
          add_reason(profile_status, normalized_reason);
        }
        CompressionQuantityV1 response;
        if (level_index == 0U) {
          CompressionMetricStatusV1 structural_status;
          add_warning(structural_status,
                      CompressionWarningCodeV1::structural_zero_response);
          if (!row || provably_zero(row_exposure)) {
            // The decoder coefficient is structurally zero even when p_0 is
            // unobserved.  Preserve both facts instead of manufacturing an
            // empirical ratio or preventing the structural fit input.
            add_reason(structural_status,
                       CompressionUnavailableReasonV1::no_exposure);
          }
          response = CompressionQuantityV1{public_value(zero()),
                                           std::move(structural_status)};
          fit_services.push_back(ExactRational::zero());
          fit_service_enclosures.push_back(zero());
        } else if (!row || provably_zero(row_exposure)) {
          response = unavailable(CompressionUnavailableReasonV1::no_exposure);
          add_reason(profile_status,
                     CompressionUnavailableReasonV1::no_exposure);
          fit_profile_complete = false;
        } else {
          auto ratio = divide(row_served, row_exposure);
          if (!ratio) {
            response = unavailable(
                CompressionUnavailableReasonV1::denominator_enclosure_contains_zero);
            add_reason(profile_status,
                       CompressionUnavailableReasonV1::denominator_enclosure_contains_zero);
            fit_profile_complete = false;
          } else {
            response = available(*ratio);
            if (provably_zero(row_served)) {
              add_warning(
                  response.status,
                  CompressionWarningCodeV1::exposure_without_observed_service);
            }
            fit_services.push_back(ratio->value);
            fit_service_enclosures.push_back(*ratio);
          }
        }
        prefix.push_back(EmpiricalResponsePointV1{
            level,
            probability ? available(*probability)
                        : unavailable(normalized_reason),
            service_mass ? available(*service_mass)
                         : unavailable(normalized_reason),
            std::move(response),
            row && !provably_zero(row_exposure),
            level_index == 0U});
      }
    }
    EmpiricalResponseProfileV1 empirical_profile{
        cutoff, std::move(prefix), tail.constant_tail_response,
        profile_status,
        sparse_empirical_mode
            ? EmpiricalResponseProfileRepresentationV1::
                  sparse_profile_reference
            : EmpiricalResponseProfileRepresentationV1::
                  dense_finite_prefix};
    const bool fit_coefficients_have_enclosure =
        (c && !c->error.is_zero()) ||
        std::any_of(fit_service_enclosures.begin(),
                    fit_service_enclosures.end(),
                    [](const Enclosed& coefficient) {
                      return !coefficient.error.is_zero();
                    });

    std::optional<FinitePrefixFitResultV1> fit;
    std::optional<Diagnostic> fit_failure;
    CompressionMetricStatusV1 fit_status;
    if (options.run_diagnostic_fits && cutoff_native) {
      CompressionMetricStatusV1 fit_gate;
      merge_status(fit_gate, iid_failure);
      if (!arrivals.exact_marginal) {
        add_reason(fit_gate,
                   CompressionUnavailableReasonV1::unsupported_arrival_identity);
      }
      if (!fit_profile_complete || !c) {
        merge_status(fit_gate, profile_status);
        if (!c) {
          add_reason(fit_gate, coefficient_absence_reason);
        }
      }
      if (fit_gate.available()) {
        FinitePrefixFitInputV1 fit_input{
            arrivals.atoms,
            arrivals.second_moment_available,
            arrivals.exact_marginal && arrivals.second_moment_available,
            options.selection_seed,
            std::move(fit_services),
            c->value,
            FinitePrefixFitBindingV1{observation.digest(),
                                    bundle.bindings.arrival.configured_law_digest},
            options.fit_limits,
            std::nullopt,
            false};
        if (omitted_replication) {
          saturating_increment(work.jackknife_fit_invocations);
        } else {
          saturating_increment(work.point_fit_invocations);
        }
        auto fitted = fit_finite_prefix_constant_tail(std::move(fit_input));
        if (!fitted) {
          fit_failure = fitted.error();
          add_reason(fit_status,
                     CompressionUnavailableReasonV1::decoder_rejected);
        } else {
          fit = std::move(fitted).value();
          if (fit_coefficients_have_enclosure) {
            add_warning(fit_status,
                        CompressionWarningCodeV1::
                            numerical_enclosure_required);
          }
          if (!fit->normalized_law_established()) {
            add_reason(fit_status,
                       fit->status ==
                               FinitePrefixFitStatusV1::outside_strict_tail_profile
                           ? CompressionUnavailableReasonV1::outside_decoder_profile
                           : CompressionUnavailableReasonV1::fitted_law_unavailable);
          }
          if (fit->status ==
                  FinitePrefixFitStatusV1::finite_closed_tail_unreachable &&
              delta &&
              delta->value - delta->error <= ExactRational::zero()) {
            add_warning(fit_status,
                        CompressionWarningCodeV1::finite_closure_with_nonpositive_slack);
          }
        }
      } else {
        merge_status(fit_status, fit_gate);
      }
    } else {
      add_reason(fit_status,
                 CompressionUnavailableReasonV1::fitted_law_unavailable);
    }

    CompressionQuantityV1 reported_fit_mean =
        unavailable(CompressionUnavailableReasonV1::fitted_law_unavailable);
    EmpiricalCompressionDecompositionV1 decomposition;
    if (c && u && v) {
      const Enclosed prefix_mean = subtract(normalized_mean, *u);
      const Enclosed prefix_service =
          subtract(normalized_service_moment, *v);
      const Enclosed c_observed =
          subtract(multiply(*c, prefix_mean), prefix_service);
      decomposition.observed_prefix_correction = available(c_observed);
      if (normalized_second_moment_supported) {
        decomposition.arrival_balance_constant = available(balance_constant);
        decomposition.empirical_balance_residual = available(empirical_z);
        const Enclosed observation_lhs = multiply(*delta, normalized_mean);
        const Enclosed observation_rhs =
            subtract(add(add(balance_constant, empirical_z), c_observed),
                     *association);
        decomposition.observation_balance_lhs = available(observation_lhs);
        decomposition.observation_balance_rhs = available(observation_rhs);
        decomposition.observation_balance_closure =
            available(subtract(observation_lhs, observation_rhs));
      } else {
        CompressionMetricStatusV1 unavailable_status = iid_failure;
        if (!arrivals.second_moment_available) {
          add_reason(unavailable_status,
                     CompressionUnavailableReasonV1::missing_second_moment);
        }
        if (second_moment_supported && !normalized_moments_available) {
          add_reason(
              unavailable_status,
              CompressionUnavailableReasonV1::
                  denominator_enclosure_contains_zero);
        }
        decomposition.arrival_balance_constant =
            unavailable_from_status(unavailable_status);
        decomposition.empirical_balance_residual =
            unavailable_from_status(unavailable_status);
        decomposition.observation_balance_lhs = available(
            multiply(delta.value_or(zero()), normalized_mean));
        decomposition.observation_balance_rhs =
            unavailable_from_status(unavailable_status);
        decomposition.observation_balance_closure =
            unavailable_from_status(std::move(unavailable_status));
      }

      bool fit_shape_valid = false;
      Enclosed c_fit = zero();
      bool consumed_coefficients_match =
          fit && fit->consumed_service_by_level.size() ==
                     fit_service_enclosures.size();
      if (consumed_coefficients_match) {
        for (std::size_t level_index = 0U;
             level_index < fit_service_enclosures.size(); ++level_index) {
          if (fit->consumed_service_by_level[level_index] !=
              fit_service_enclosures[level_index].value) {
            consumed_coefficients_match = false;
            break;
          }
        }
      }
      if (fit && fit->normalized_law_established() &&
          fit->fitted_prefix_probabilities &&
          fit->fitted_prefix_probabilities->size() == *cutoff_native + 1U &&
          fit->consumed_service_by_level.size() == *cutoff_native + 1U &&
          fit->consumed_constant_tail_service == c->value &&
          consumed_coefficients_match) {
        fit_shape_valid = true;
        c_fit = zero();
        for (std::size_t level_index = 0U; level_index <= *cutoff_native;
             ++level_index) {
          const Enclosed level =
              exact(uint_rational(static_cast<std::uint64_t>(level_index)));
          const Enclosed mass =
              exact((*fit->fitted_prefix_probabilities)[level_index]);
          const Enclosed correction =
              subtract(*c, fit_service_enclosures[level_index]);
          c_fit = add(c_fit, multiply(level, multiply(mass, correction)));
        }
        c_fit = conservative_fitted_correction(
            std::move(c_fit), *c, fit_service_enclosures);
        decomposition.fitted_prefix_correction = available(c_fit);
        if (fit->fitted_mean_backlog) {
          if (fit->status ==
              FinitePrefixFitStatusV1::finite_closed_tail_unreachable) {
            // Finite closure is proved only for the serialized coefficient
            // centers.  A nonzero coefficient enclosure may open an escape
            // edge, change the selected class, or move the perturbed law onto
            // a non-finite (possibly unstable) branch.  The interval [0,K]
            // is therefore not a sound enclosure for that perturbed fit.
            // Publish the exact center result above, but do not manufacture a
            // reporting mean until robust closure is separately established.
            reported_fit_mean =
                fit_coefficients_have_enclosure
                    ? unavailable(CompressionUnavailableReasonV1::
                                      fitted_law_unavailable)
                    : available(exact(*fit->fitted_mean_backlog));
          } else if (second_moment_supported) {
            const auto mean_from_identity =
                divide(add(balance_constant, c_fit), *delta);
            if (mean_from_identity &&
                mean_from_identity->value == *fit->fitted_mean_backlog) {
              reported_fit_mean = available(*mean_from_identity);
            } else {
              reported_fit_mean = unavailable(
                  mean_from_identity
                      ? CompressionUnavailableReasonV1::invalid_fit_shape
                      : CompressionUnavailableReasonV1::
                            denominator_enclosure_contains_zero);
            }
          }
        }
      } else {
        decomposition.fitted_prefix_correction = unavailable(
            fit ? CompressionUnavailableReasonV1::invalid_fit_shape
                : CompressionUnavailableReasonV1::fitted_law_unavailable);
      }

      if (fit_shape_valid && reported_fit_mean.available() &&
          normalized_second_moment_supported) {
        const Enclosed fitted_mean = enclosed(reported_fit_mean);
        const Enclosed prediction_error =
            subtract(fitted_mean, normalized_mean);
        const Enclosed numerator_lhs = multiply(*delta, prediction_error);
        const Enclosed numerator_rhs =
            subtract(add(add(*association, c_fit), negate(c_observed)),
                     empirical_z);
        decomposition.fitted_minus_observed_mean =
            available(prediction_error);
        decomposition.numerator_lhs = available(numerator_lhs);
        decomposition.numerator_rhs = available(numerator_rhs);
        decomposition.numerator_closure =
            available(subtract(numerator_lhs, numerator_rhs));
        if (provably_zero(*delta)) {
          decomposition.compression_term =
              unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
          decomposition.fitted_prefix_term =
              unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
          decomposition.finite_window_balance_term =
              unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
          decomposition.divided_term_sum =
              unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
          decomposition.divided_closure =
              unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
        } else {
          decomposition.compression_term = divided_quantity(
              *association, *delta,
              CompressionUnavailableReasonV1::zero_tail_slack);
          decomposition.fitted_prefix_term = divided_quantity(
              subtract(c_fit, c_observed), *delta,
              CompressionUnavailableReasonV1::zero_tail_slack);
          decomposition.finite_window_balance_term = divided_quantity(
              negate(empirical_z), *delta,
              CompressionUnavailableReasonV1::zero_tail_slack);
          if (decomposition.compression_term.available() &&
              decomposition.fitted_prefix_term.available() &&
              decomposition.finite_window_balance_term.available()) {
            const Enclosed divided_sum =
                add(add(enclosed(decomposition.compression_term),
                        enclosed(decomposition.fitted_prefix_term)),
                    enclosed(decomposition.finite_window_balance_term));
            decomposition.divided_term_sum = available(divided_sum);
            decomposition.divided_closure =
                available(subtract(prediction_error, divided_sum));
          }
        }
      } else {
        const auto reason =
            !normalized_second_moment_supported
                ? (second_moment_supported
                       ? CompressionUnavailableReasonV1::
                             denominator_enclosure_contains_zero
                       : CompressionUnavailableReasonV1::missing_second_moment)
                : (fit_shape_valid && !reported_fit_mean.available()
                       ? (reported_fit_mean.status.unavailable_reasons.empty()
                              ? CompressionUnavailableReasonV1::
                                    fitted_law_unavailable
                              : reported_fit_mean.status.unavailable_reasons
                                    .front())
                       : CompressionUnavailableReasonV1::
                             fitted_law_unavailable);
        decomposition.fitted_minus_observed_mean = unavailable(reason);
        decomposition.numerator_lhs = unavailable(reason);
        decomposition.numerator_rhs = unavailable(reason);
        decomposition.numerator_closure = unavailable(reason);
        decomposition.compression_term =
            delta && !provably_zero(*delta)
                ? divided_quantity(*association, *delta,
                                   CompressionUnavailableReasonV1::zero_tail_slack)
                : unavailable(CompressionUnavailableReasonV1::zero_tail_slack);
        decomposition.fitted_prefix_term = unavailable(reason);
        decomposition.finite_window_balance_term =
            normalized_second_moment_supported && delta &&
                    !provably_zero(*delta)
                ? divided_quantity(negate(empirical_z), *delta,
                                   CompressionUnavailableReasonV1::zero_tail_slack)
                : unavailable(reason);
        decomposition.divided_term_sum = unavailable(reason);
        decomposition.divided_closure = unavailable(reason);
      }
    } else {
      add_reason(decomposition.status, coefficient_absence_reason);
      decomposition.observed_prefix_correction =
          unavailable(coefficient_absence_reason);
      decomposition.arrival_balance_constant =
          normalized_second_moment_supported
              ? available(balance_constant)
              : unavailable(
                    second_moment_supported
                        ? CompressionUnavailableReasonV1::
                              denominator_enclosure_contains_zero
                        : CompressionUnavailableReasonV1::
                              missing_second_moment);
      decomposition.empirical_balance_residual =
          normalized_second_moment_supported
              ? available(empirical_z)
              : unavailable(
                    second_moment_supported
                        ? CompressionUnavailableReasonV1::
                              denominator_enclosure_contains_zero
                        : CompressionUnavailableReasonV1::
                              missing_second_moment);
      decomposition.observation_balance_lhs =
          unavailable(coefficient_absence_reason);
      decomposition.observation_balance_rhs =
          unavailable(coefficient_absence_reason);
      decomposition.observation_balance_closure =
          unavailable(coefficient_absence_reason);
      decomposition.fitted_prefix_correction =
          unavailable(coefficient_absence_reason);
      decomposition.fitted_minus_observed_mean =
          unavailable(coefficient_absence_reason);
      decomposition.numerator_lhs =
          unavailable(coefficient_absence_reason);
      decomposition.numerator_rhs =
          unavailable(coefficient_absence_reason);
      decomposition.numerator_closure =
          unavailable(coefficient_absence_reason);
      decomposition.compression_term =
          unavailable(coefficient_absence_reason);
      decomposition.fitted_prefix_term =
          unavailable(coefficient_absence_reason);
      decomposition.finite_window_balance_term =
          unavailable(coefficient_absence_reason);
      decomposition.divided_term_sum =
          unavailable(coefficient_absence_reason);
      decomposition.divided_closure =
          unavailable(coefficient_absence_reason);
    }

    const auto supplied_index =
        supplied_profile_index(options.provider_supplied_profiles, cutoff);
    std::optional<SuppliedResponseProfileV1> supplied;
    if (supplied_index) {
      supplied = options.provider_supplied_profiles[*supplied_index];
    }

    cutoff_results.push_back(CompressionCutoffAnalysisV1{
        cutoff,
        std::move(empirical_profile),
        std::move(supplied),
        std::move(tail),
        std::move(fit),
        std::move(fit_failure),
        std::move(fit_status),
        std::move(reported_fit_mean),
        std::move(decomposition),
        std::nullopt,
        {}});

    if (cutoff_native) {
      retained_prefix_rows += *cutoff_native + 1U;
    }
    const std::size_t retained_objects =
        replication_summary_objects + rows.size() + public_levels.size() +
        raw_response_point_capacity + start_boundary.size() +
        end_boundary.size() +
        tail_accumulators.size() + overshoot_entries + cutoff_results.size() +
        retained_prefix_rows + finite_beta_entries;
    const std::size_t retained_bytes =
        replication_summary_bytes + rows.capacity() * sizeof(AggregateLevel) +
        public_levels.capacity() * sizeof(PooledObservationLevelV1) +
        raw_response_point_capacity *
            sizeof(EmpiricalFiniteWindowResponsePointV1) +
        start_boundary.capacity() * sizeof(AggregateBoundaryLevel) +
        end_boundary.capacity() * sizeof(AggregateBoundaryLevel) +
        tail_accumulators.capacity() * sizeof(TailAccumulator) +
        overshoot_entries * sizeof(ExactRational) +
        finite_beta_entries * sizeof(Enclosed) +
        cutoff_results.capacity() * sizeof(CompressionCutoffAnalysisV1) +
        retained_prefix_rows * sizeof(EmpiricalResponsePointV1);
    record_retained(work, retained_objects, retained_bytes);

    // Aggregate initialization is delayed until every independently gated
    // quantity has been computed below.
    const auto eta_hinge_value =
        boundaries_available
            ? divide(subtract(end_hinges[cutoff_index],
                              start_hinges[cutoff_index]),
                     slot_count_scalar)
            : std::nullopt;
    CompressionQuantityV1 eta_hinge =
        eta_hinge_value
            ? available(*eta_hinge_value)
            : unavailable(
                  CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    CompressionQuantityV1 tau_per_slot =
        tau_star ? available(*tau_star)
                 : unavailable(CompressionUnavailableReasonV1::no_complete_replication);
    CompressionQuantityV1 beta_normalized;
    CompressionQuantityV1 beta_per_slot;
    CompressionQuantityV1 hinge_innovation;
    CompressionQuantityV1 hinge_expectation_residual;
    CompressionQuantityV1 hinge_closure;
    CompressionMetricStatusV1 finite_cutoff_status;
    const bool raw_beta_inputs_available =
        sparse_empirical_mode && iid_supported && arrival_overshoot_available;
    const bool legacy_hinge_inputs_available =
        iid_supported && arrival_overshoot_available && c && delta &&
        boundaries_available;
    if (!raw_beta_inputs_available && !legacy_hinge_inputs_available) {
      CompressionMetricStatusV1 unavailable_status = iid_failure;
      if (!arrival_overshoot_available) {
        add_reason(unavailable_status,
                   CompressionUnavailableReasonV1::missing_arrival_overshoot);
      }
      if (!boundaries_available) {
        add_reason(unavailable_status,
                   CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
      }
      if (!c) {
        add_reason(unavailable_status,
                   CompressionUnavailableReasonV1::no_tail_exposure);
      }
      beta_normalized = unavailable_from_status(unavailable_status);
      beta_per_slot = unavailable_from_status(unavailable_status);
      hinge_innovation = unavailable_from_status(unavailable_status);
      hinge_expectation_residual = unavailable_from_status(unavailable_status);
      hinge_closure = unavailable_from_status(unavailable_status);
      finite_cutoff_status = std::move(unavailable_status);
    } else {
      Enclosed beta_raw = zero();
      bool beta_available = true;
      CompressionUnavailableReasonV1 overshoot_failure =
          CompressionUnavailableReasonV1::
              arrival_overshoot_numerically_unresolved;
      if (finite_beta_rewards) {
        beta_raw = (*finite_beta_rewards)[cutoff_index];
      } else {
        for (const auto& row : rows) {
          if (cutoff < row.backlog) {
            break;
          }
          const auto phi_zero = arrival_overshoot(
              arrival_overshoots, row.backlog, cutoff, false,
              overshoot_failure);
          const auto phi_one = arrival_overshoot(
              arrival_overshoots, row.backlog, cutoff, true,
              overshoot_failure);
          if (!phi_zero || !phi_one) {
            beta_available = false;
            break;
          }
          beta_raw = add(
              beta_raw,
              add(multiply(subtract(row.exposure, row.served), *phi_zero),
                  multiply(row.served, *phi_one)));
        }
      }
      if (!beta_available) {
        CompressionMetricStatusV1 unavailable_status = iid_failure;
        add_reason(unavailable_status, overshoot_failure);
        beta_normalized = unavailable_from_status(unavailable_status);
        beta_per_slot = unavailable_from_status(unavailable_status);
        hinge_innovation = unavailable_from_status(unavailable_status);
        hinge_expectation_residual =
            unavailable_from_status(unavailable_status);
        hinge_closure = unavailable_from_status(unavailable_status);
        finite_cutoff_status = std::move(unavailable_status);
      } else {
      const auto beta_norm_value = divide(beta_raw, exposure);
      const auto beta_star_value = divide(beta_raw, slot_count_scalar);
      beta_normalized = beta_norm_value
                            ? available(*beta_norm_value)
                            : unavailable(CompressionUnavailableReasonV1::no_exposure);
      beta_per_slot = beta_star_value
                          ? available(*beta_star_value)
                          : unavailable(CompressionUnavailableReasonV1::no_complete_replication);
      if (eta_hinge.available() && tau_star && beta_star_value && delta) {
        const Enclosed lhs = multiply(*tau_star, *delta);
        const Enclosed innovation =
            add(subtract(lhs, *beta_star_value), enclosed(eta_hinge));
        hinge_innovation = available(innovation);
        hinge_expectation_residual = available(innovation);
        hinge_closure = available(subtract(
            lhs, add(subtract(*beta_star_value, enclosed(eta_hinge)),
                     innovation)));
      } else {
        CompressionMetricStatusV1 innovation_status;
        if (sparse_empirical_mode) {
          if (!delta) {
            add_reason(innovation_status, coefficient_absence_reason);
          }
          if (!boundaries_available || !eta_hinge.available()) {
            add_reason(innovation_status,
                       CompressionUnavailableReasonV1::
                           incomplete_or_missing_boundary);
          }
          if (!tau_star || !beta_star_value) {
            add_reason(innovation_status,
                       CompressionUnavailableReasonV1::
                           no_complete_replication);
          }
          merge_status(finite_cutoff_status, innovation_status);
        } else {
          add_reason(innovation_status,
                     CompressionUnavailableReasonV1::
                         incomplete_or_missing_boundary);
        }
        hinge_innovation = unavailable_from_status(innovation_status);
        hinge_expectation_residual =
            unavailable_from_status(innovation_status);
        hinge_closure =
            unavailable_from_status(std::move(innovation_status));
      }
      }
    }
    finite_cutoffs.push_back(FiniteWindowCutoffAnalysisV1{
        cutoff,
        std::move(eta_hinge),
        std::move(tau_per_slot),
        std::move(beta_normalized),
        std::move(beta_per_slot),
        std::move(hinge_innovation),
        std::move(hinge_expectation_residual),
        std::move(hinge_closure),
        std::move(finite_cutoff_status)});

    std::optional<CompetitionCutoffAnalysisV1> competition_cutoff;
    if (gap_failure.available() && c && association && u && v) {
      const auto positive_gap = divide(raw_tail.positive_gap, exposure);
      const auto negative_gap = divide(raw_tail.negative_gap, exposure);
      if (positive_gap && negative_gap) {
        const Enclosed gap_reward =
            add(multiply(subtract(one(), *c), *positive_gap),
                multiply(*c, *negative_gap));
        const Enclosed competition_reward =
            subtract(*association, gap_reward);
        const Enclosed competition_backlog =
            add(subtract(*u, *positive_gap), *negative_gap);
        const Enclosed competition_service = subtract(*v, *positive_gap);
        const Enclosed direct = subtract(
            competition_service, multiply(*c, competition_backlog));
        competition_cutoff = CompetitionCutoffAnalysisV1{
            cutoff,
            available(*positive_gap),
            available(*negative_gap),
            available(gap_reward),
            available(competition_reward),
            available(competition_backlog),
            available(competition_service),
            available(direct),
            available(subtract(*association, add(direct, gap_reward))),
            {}};
      } else {
        CompressionMetricStatusV1 status;
        add_reason(status, CompressionUnavailableReasonV1::no_exposure);
        competition_cutoff = CompetitionCutoffAnalysisV1{
            cutoff,
            unavailable_from_status(status), unavailable_from_status(status),
            unavailable_from_status(status), unavailable_from_status(status),
            unavailable_from_status(status), unavailable_from_status(status),
            unavailable_from_status(status), unavailable_from_status(status),
            status};
      }
    } else {
      CompressionMetricStatusV1 status = gap_failure;
      if (!c) {
        add_reason(status, CompressionUnavailableReasonV1::no_tail_exposure);
      }
      competition_cutoff = CompetitionCutoffAnalysisV1{
          cutoff,
          unavailable_from_status(status), unavailable_from_status(status),
          unavailable_from_status(status), unavailable_from_status(status),
          unavailable_from_status(status), unavailable_from_status(status),
          unavailable_from_status(status), unavailable_from_status(status),
          status};
    }
    competition_cutoffs.push_back(std::move(*competition_cutoff));
  }

  record_retained(
      work,
      replication_summary_objects + rows.size() + public_levels.size() +
          raw_response_point_capacity + start_boundary.size() +
          end_boundary.size() +
          tail_accumulators.size() + overshoot_entries + cutoff_results.size() +
          finite_cutoffs.size() + competition_cutoffs.size() +
          retained_prefix_rows + finite_beta_entries,
      replication_summary_bytes + rows.capacity() * sizeof(AggregateLevel) +
          public_levels.capacity() * sizeof(PooledObservationLevelV1) +
          raw_response_point_capacity *
              sizeof(EmpiricalFiniteWindowResponsePointV1) +
          start_boundary.capacity() * sizeof(AggregateBoundaryLevel) +
          end_boundary.capacity() * sizeof(AggregateBoundaryLevel) +
          tail_accumulators.capacity() * sizeof(TailAccumulator) +
          overshoot_entries * sizeof(ExactRational) +
          finite_beta_entries * sizeof(Enclosed) +
          cutoff_results.capacity() * sizeof(CompressionCutoffAnalysisV1) +
          finite_cutoffs.capacity() * sizeof(FiniteWindowCutoffAnalysisV1) +
          competition_cutoffs.capacity() *
              sizeof(CompetitionCutoffAnalysisV1) +
          retained_prefix_rows * sizeof(EmpiricalResponsePointV1));

  FiniteWindowAnalysisV1 finite_window;
  finite_window.cutoffs = std::move(finite_cutoffs);
  if (boundaries_available && eta_one && eta_two) {
    finite_window.first_moment_endpoint_drift = available(*eta_one);
    finite_window.second_moment_endpoint_drift = available(*eta_two);
  } else {
    finite_window.first_moment_endpoint_drift = unavailable(
        CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    finite_window.second_moment_endpoint_drift = unavailable(
        CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    add_reason(finite_window.status,
               CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
  }
  if (iid_supported && mass_per_slot) {
    const Enclosed expected_first =
        subtract(multiply(lambda_value, *mass_per_slot), starred_departure);
    finite_window.first_moment_expected_increment = available(expected_first);
    finite_window.first_moment_innovation = boundaries_available && eta_one
        ? available(subtract(*eta_one, expected_first))
        : unavailable(
              CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
  } else {
    CompressionMetricStatusV1 status = iid_failure;
    if (!boundaries_available) {
      add_reason(status,
                 CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    }
    if (slot_count.is_zero()) {
      add_reason(status,
                 CompressionUnavailableReasonV1::no_complete_replication);
    }
    finite_window.first_moment_expected_increment =
        unavailable_from_status(status);
    finite_window.first_moment_innovation =
        unavailable_from_status(std::move(status));
  }
  if (second_moment_supported && mass_per_slot && mass_defect) {
    const Enclosed expected_second = add(
        add(subtract(scale(multiply(lambda_value, starred_mean), two()),
                     scale(starred_service_moment, two())),
            scale(starred_departure, one_minus_two_lambda)),
        multiply(second_moment_value, *mass_per_slot));
    finite_window.second_moment_expected_increment =
        available(expected_second);
    finite_window.second_moment_innovation = boundaries_available && eta_two
        ? available(subtract(*eta_two, expected_second))
        : unavailable(
              CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    finite_window.starred_balance_residual = available(starred_z);
    auto corrected_z = divide(
        subtract(starred_z, multiply(balance_constant, *mass_defect)),
        *mass_per_slot);
    finite_window.mass_defect_corrected_balance_residual =
        corrected_z
            ? available(*corrected_z)
            : unavailable(CompressionUnavailableReasonV1::no_exposure);
    if (boundaries_available && eta_one && eta_two &&
        finite_window.first_moment_innovation.available() &&
        finite_window.second_moment_innovation.available()) {
      const Enclosed drift_part = scale(
          add(scale(*eta_one, one_minus_two_lambda), *eta_two),
          std::move(checked_divide(ExactRational::one(), two())).value());
      const Enclosed innovation_part = scale(
          add(scale(enclosed(finite_window.first_moment_innovation),
                    one_minus_two_lambda),
              enclosed(finite_window.second_moment_innovation)),
          std::move(checked_divide(ExactRational::one(), two())).value());
      const Enclosed identity_rhs = add(
          multiply(balance_constant, *mass_defect),
          add(negate(drift_part), innovation_part));
      finite_window.moment_identity_closure =
          available(subtract(starred_z, identity_rhs));
    } else {
      finite_window.moment_identity_closure = unavailable(
          CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    }
  } else {
    CompressionMetricStatusV1 status = iid_failure;
    if (!arrivals.second_moment_available) {
      add_reason(status,
                 CompressionUnavailableReasonV1::missing_second_moment);
    }
    if (!boundaries_available) {
      add_reason(status,
                 CompressionUnavailableReasonV1::incomplete_or_missing_boundary);
    }
    if (slot_count.is_zero()) {
      add_reason(status,
                 CompressionUnavailableReasonV1::no_complete_replication);
    }
    finite_window.second_moment_innovation =
        unavailable_from_status(status);
    finite_window.second_moment_expected_increment =
        unavailable_from_status(status);
    finite_window.starred_balance_residual =
        unavailable_from_status(status);
    finite_window.mass_defect_corrected_balance_residual =
        unavailable_from_status(status);
    finite_window.moment_identity_closure =
        unavailable_from_status(std::move(status));
  }

  CompetitionAnalysisV1 competition;
  competition.cutoffs = std::move(competition_cutoffs);
  if (gap_failure.available() && observed_mean) {
    const auto mean_gap = divide(
        subtract(gap_total.positive_magnitude,
                 gap_total.negative_magnitude),
        exposure);
    const auto mean_absolute_gap = divide(
        add(gap_total.positive_magnitude, gap_total.negative_magnitude),
        exposure);
    if (mean_gap && mean_absolute_gap) {
      const Enclosed scale_value = subtract(normalized_mean, *mean_gap);
      competition.mean_gap = available(*mean_gap);
      competition.mean_absolute_gap = available(*mean_absolute_gap);
      competition.mean_competition_scale = available(scale_value);
      if (provably_zero(scale_value)) {
        competition.normalized_gap_scale = unavailable(
            CompressionUnavailableReasonV1::zero_competition_scale);
      } else if (!scale_value.value.is_positive()) {
        competition.normalized_gap_scale = unavailable(
            scale_value.value.is_zero()
                ? CompressionUnavailableReasonV1::
                      denominator_enclosure_contains_zero
                : CompressionUnavailableReasonV1::
                      nonpositive_competition_scale);
      } else if (scale_value.value - scale_value.error <=
                 ExactRational::zero()) {
        competition.normalized_gap_scale = unavailable(
            CompressionUnavailableReasonV1::
                denominator_enclosure_contains_zero);
      } else {
        competition.normalized_gap_scale = divided_quantity(
            *mean_absolute_gap, scale_value,
            CompressionUnavailableReasonV1::zero_competition_scale);
      }
    } else {
      CompressionMetricStatusV1 status;
      add_reason(
          status,
          CompressionUnavailableReasonV1::denominator_enclosure_contains_zero);
      competition.status = status;
      competition.mean_gap = unavailable_from_status(status);
      competition.mean_absolute_gap = unavailable_from_status(status);
      competition.mean_competition_scale = unavailable_from_status(status);
      competition.normalized_gap_scale =
          unavailable_from_status(std::move(status));
    }
  } else {
    CompressionMetricStatusV1 status = gap_failure;
    if (gap_failure.available() && !observed_mean) {
      add_reason(status, provably_zero(exposure)
                             ? CompressionUnavailableReasonV1::no_exposure
                             : CompressionUnavailableReasonV1::
                                   denominator_enclosure_contains_zero);
    }
    competition.status = status;
    competition.mean_gap = unavailable_from_status(status);
    competition.mean_absolute_gap = unavailable_from_status(status);
    competition.mean_competition_scale = unavailable_from_status(status);
    competition.normalized_gap_scale =
        unavailable_from_status(std::move(status));
  }

  TieAnalysisV1 ties;
  if (gap_failure.available() && observed_mean) {
    Enclosed strict_loss = zero();
    Enclosed lost_tie = zero();
    ties.response_by_level.reserve(rows.size());
    for (const auto& row : rows) {
      if (!row.gap_seen || row.gap_missing) {
        continue;
      }
      const ExactRational level = natural_rational(row.backlog);
      strict_loss = add(strict_loss, scale(row.gap.negative, level));
      lost_tie = add(
          lost_tie,
          scale(subtract(row.gap.tie, row.gap.tied_and_served), level));
      CompressionQuantityV1 strict_component;
      CompressionQuantityV1 tie_component;
      CompressionQuantityV1 reconstructed;
      CompressionQuantityV1 observed;
      CompressionQuantityV1 reconstruction_closure;
      if (row.backlog.is_zero()) {
        strict_component = available(zero());
        tie_component = available(zero());
        reconstructed = available(
            zero(), {CompressionWarningCodeV1::structural_zero_response});
        observed = available(
            zero(), {CompressionWarningCodeV1::structural_zero_response});
        reconstruction_closure = available(zero());
      } else if (provably_zero(row.exposure)) {
        strict_component =
            unavailable(CompressionUnavailableReasonV1::no_exposure);
        tie_component =
            unavailable(CompressionUnavailableReasonV1::no_exposure);
        reconstructed =
            unavailable(CompressionUnavailableReasonV1::no_exposure);
        observed = unavailable(CompressionUnavailableReasonV1::no_exposure);
        reconstruction_closure =
            unavailable(CompressionUnavailableReasonV1::no_exposure);
      } else {
        strict_component = divided_quantity(
            row.gap.positive, row.exposure,
            CompressionUnavailableReasonV1::no_exposure);
        tie_component = divided_quantity(
            row.gap.tied_and_served, row.exposure,
            CompressionUnavailableReasonV1::no_exposure);
        reconstructed = divided_quantity(
            add(row.gap.positive, row.gap.tied_and_served), row.exposure,
            CompressionUnavailableReasonV1::no_exposure);
        observed = divided_quantity(
            row.served, row.exposure,
            CompressionUnavailableReasonV1::no_exposure);
        reconstruction_closure =
            reconstructed.available() && observed.available()
                ? available(subtract(enclosed(observed),
                                     enclosed(reconstructed)))
                : unavailable(CompressionUnavailableReasonV1::no_exposure);
      }
      ties.response_by_level.push_back(TieResponsePointV1{
          row.backlog, std::move(strict_component), std::move(tie_component),
          std::move(reconstructed), std::move(observed),
          std::move(reconstruction_closure)});
    }
    const auto strict_loss_normalized = divide(strict_loss, exposure);
    const auto lost_tie_normalized = divide(lost_tie, exposure);
    ties.strict_loss_backlog_reward =
        strict_loss_normalized
            ? available(*strict_loss_normalized)
            : unavailable(CompressionUnavailableReasonV1::no_exposure);
    ties.lost_tie_backlog_reward =
        lost_tie_normalized
            ? available(*lost_tie_normalized)
            : unavailable(CompressionUnavailableReasonV1::no_exposure);
    if (normalized_second_moment_supported && strict_loss_normalized &&
        lost_tie_normalized) {
      const Enclosed lhs =
          multiply(subtract(one(), lambda_value), normalized_mean);
      const Enclosed rhs = add(
          add(add(balance_constant, *strict_loss_normalized),
              *lost_tie_normalized),
          empirical_z);
      ties.empirical_identity_lhs = available(lhs);
      ties.empirical_identity_rhs = available(rhs);
      ties.empirical_identity_closure = available(subtract(lhs, rhs));
      if (options.stationary_coefficients_established &&
          lambda < ExactRational::one()) {
        const Enclosed denominator = subtract(one(), lambda_value);
        ties.isolated_server_baseline = divided_quantity(
            balance_constant, denominator,
            CompressionUnavailableReasonV1::zero_tail_slack);
        ties.strict_loss_mean_contribution = divided_quantity(
            *strict_loss_normalized, denominator,
            CompressionUnavailableReasonV1::zero_tail_slack);
        ties.lost_tie_mean_contribution = divided_quantity(
            *lost_tie_normalized, denominator,
            CompressionUnavailableReasonV1::zero_tail_slack);
        if (ties.isolated_server_baseline.available() &&
            ties.strict_loss_mean_contribution.available() &&
            ties.lost_tie_mean_contribution.available()) {
          ties.stationary_mean_reconstruction = available(add(
              add(enclosed(ties.isolated_server_baseline),
                  enclosed(ties.strict_loss_mean_contribution)),
              enclosed(ties.lost_tie_mean_contribution)));
        }
      } else {
        CompressionMetricStatusV1 status;
        add_reason(status,
                   CompressionUnavailableReasonV1::stationary_hypotheses_unavailable);
        ties.isolated_server_baseline = unavailable_from_status(status);
        ties.strict_loss_mean_contribution = unavailable_from_status(status);
        ties.lost_tie_mean_contribution = unavailable_from_status(status);
        ties.stationary_mean_reconstruction =
            unavailable_from_status(std::move(status));
      }
    } else {
      CompressionMetricStatusV1 status = iid_failure;
      if (!arrivals.second_moment_available) {
        add_reason(status,
                   CompressionUnavailableReasonV1::missing_second_moment);
      }
      ties.empirical_identity_lhs = unavailable_from_status(status);
      ties.empirical_identity_rhs = unavailable_from_status(status);
      ties.empirical_identity_closure = unavailable_from_status(status);
      ties.isolated_server_baseline = unavailable_from_status(status);
      ties.strict_loss_mean_contribution = unavailable_from_status(status);
      ties.lost_tie_mean_contribution = unavailable_from_status(status);
      ties.stationary_mean_reconstruction =
          unavailable_from_status(std::move(status));
    }
  } else {
    CompressionMetricStatusV1 status = gap_failure;
    if (gap_failure.available() && !observed_mean) {
      add_reason(status, provably_zero(exposure)
                             ? CompressionUnavailableReasonV1::no_exposure
                             : CompressionUnavailableReasonV1::
                                   denominator_enclosure_contains_zero);
    }
    ties.status = status;
    ties.strict_loss_backlog_reward = unavailable_from_status(status);
    ties.lost_tie_backlog_reward = unavailable_from_status(status);
    ties.empirical_identity_lhs = unavailable_from_status(status);
    ties.empirical_identity_rhs = unavailable_from_status(status);
    ties.empirical_identity_closure = unavailable_from_status(status);
    ties.isolated_server_baseline = unavailable_from_status(status);
    ties.strict_loss_mean_contribution = unavailable_from_status(status);
    ties.lost_tie_mean_contribution = unavailable_from_status(status);
    ties.stationary_mean_reconstruction =
        unavailable_from_status(std::move(status));
  }

  CompressionMetricStatusV1 overall_status = pooled_status;
  CompressionAnalysisResultV1 result{
      observation.digest(),
      analysis_digest,
      bundle.source_role,
      bundle.bindings,
      bundle.slot_convention,
      bundle.initialization,
      bundle.warmup_boundary,
      bundle.end_boundary,
      std::move(pooled),
      std::move(raw_response),
      std::move(replication_summaries),
      std::move(cutoff_results),
      std::move(finite_window),
      std::move(competition),
      std::move(ties),
      work,
      std::move(overall_status),
      options.projection_mode,
      arrival_overshoots.poisson_report};
  return Result<CoreAnalysis>::success(
      CoreAnalysis{std::move(result), replication_indices});
}

}  // namespace

Result<DeleteOneReplicationJackknifeV1>
summarize_delete_one_replication_jackknife_v1(
    CompressionQuantityV1 point_estimate,
    const std::span<const JackknifeReplicationEstimateV1> leave_one_out) {
  DeleteOneReplicationJackknifeV1 result;
  result.point_estimate = std::move(point_estimate);
  result.leave_one_out_estimates.assign(leave_one_out.begin(),
                                        leave_one_out.end());

  const std::size_t count = leave_one_out.size();
  const bool point_invalid = !result.point_estimate.available();
  std::size_t invalid = 0U;
  for (const auto& sample : leave_one_out) {
    if (!sample.estimate.available()) {
      ++invalid;
    }
  }
  if (count == 0U) {
    result.invalid_resample_rate =
        unavailable(CompressionUnavailableReasonV1::insufficient_independent_replications);
  } else {
    result.invalid_resample_rate = available(exact(
        std::move(checked_divide(size_rational(invalid), size_rational(count)))
            .value()));
  }

  if (count < 2U) {
    add_reason(result.status,
               CompressionUnavailableReasonV1::insufficient_independent_replications);
    result.leave_one_out_mean = unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
    result.estimated_bias = unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
    result.bias_corrected_estimate = unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
    result.squared_standard_error = unavailable(
        CompressionUnavailableReasonV1::insufficient_independent_replications);
    return Result<DeleteOneReplicationJackknifeV1>::success(
        std::move(result));
  }
  if (point_invalid || invalid != 0U) {
    add_reason(result.status,
               CompressionUnavailableReasonV1::invalid_jackknife_resample);
    add_warning(result.status,
                CompressionWarningCodeV1::invalid_jackknife_resamples_present);
    result.leave_one_out_mean = unavailable(
        CompressionUnavailableReasonV1::invalid_jackknife_resample);
    result.estimated_bias = unavailable(
        CompressionUnavailableReasonV1::invalid_jackknife_resample);
    result.bias_corrected_estimate = unavailable(
        CompressionUnavailableReasonV1::invalid_jackknife_resample);
    result.squared_standard_error = unavailable(
        CompressionUnavailableReasonV1::invalid_jackknife_resample);
    return Result<DeleteOneReplicationJackknifeV1>::success(
        std::move(result));
  }

  Enclosed mean = zero();
  for (const auto& sample : leave_one_out) {
    mean = add(mean, enclosed(sample.estimate));
  }
  const auto divided_mean = divide(mean, exact(size_rational(count)));
  if (!divided_mean) {
    return Result<DeleteOneReplicationJackknifeV1>::failure(diagnostic(
        "compression.jackknife_mean_denominator",
        "a nonempty delete-one replication set produced an invalid mean "
        "denominator",
        DiagnosticCategory::internal));
  }
  mean = *divided_mean;
  const Enclosed count_minus_one = exact(size_rational(count - 1U));
  const Enclosed bias = multiply(
      count_minus_one, subtract(mean, enclosed(result.point_estimate)));
  const Enclosed corrected = subtract(enclosed(result.point_estimate), bias);
  Enclosed squared_deviations = zero();
  for (const auto& sample : leave_one_out) {
    const Enclosed difference = subtract(enclosed(sample.estimate), mean);
    squared_deviations =
        add(squared_deviations, multiply(difference, difference));
  }
  const Enclosed variance_factor = exact(
      std::move(checked_divide(size_rational(count - 1U),
                               size_rational(count)))
          .value());
  result.leave_one_out_mean = available(mean);
  result.estimated_bias = available(bias);
  result.bias_corrected_estimate = available(corrected);
  result.squared_standard_error =
      available(multiply(variance_factor, squared_deviations));
  return Result<DeleteOneReplicationJackknifeV1>::success(std::move(result));
}

Result<CompressionAnalysisOptionsV1>
effective_compression_analysis_options_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    CompressionAnalysisOptionsV1 requested) {
  if (!requested.selection_seed.empty()) {
    return Result<CompressionAnalysisOptionsV1>::success(
        std::move(requested));
  }

  const ConstructionObservationBundleV1& bundle = observation.value();
  if (bundle.initialization.initial_law_id != "empty_backlog_v1") {
    return Result<CompressionAnalysisOptionsV1>::success(
        std::move(requested));
  }
  auto registered_digest = registered_empty_backlog_initial_law_digest_v1();
  if (!registered_digest) {
    return Result<CompressionAnalysisOptionsV1>::failure(
        registered_digest.error());
  }
  if (bundle.initialization.initial_law_digest == registered_digest.value()) {
    requested.selection_seed.push_back(
        FinitePrefixFitSelectionSeedAtomV1{BigNat{0U},
                                          ExactRational::one()});
  }
  return Result<CompressionAnalysisOptionsV1>::success(
      std::move(requested));
}

Result<Digest256> compression_analysis_identity_digest_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisOptionsV1& requested) {
  auto effective =
      effective_compression_analysis_options_v1(observation, requested);
  if (!effective) {
    return Result<Digest256>::failure(effective.error());
  }
  return compression_analysis_digest(observation.digest(), effective.value());
}

Result<CompressionAnalysisResultV1> analyze_compression_observations_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisOptionsV1& options) {
  auto resolved_options =
      effective_compression_analysis_options_v1(observation, options);
  if (!resolved_options) {
    return Result<CompressionAnalysisResultV1>::failure(
        resolved_options.error());
  }
  const CompressionAnalysisOptionsV1& effective_options =
      resolved_options.value();
  if (effective_options.projection_mode !=
          CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response &&
      effective_options.poisson_overshoot.has_value()) {
    return Result<CompressionAnalysisResultV1>::failure(diagnostic(
        "compression.poisson_overshoot_requires_empirical_mode",
        "the CP09 Poisson overshoot evaluator is not an input to frozen finite-prefix analysis"));
  }
  if (effective_options.projection_mode ==
          CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response &&
      (effective_options.run_diagnostic_fits ||
       !effective_options.provider_supplied_profiles.empty())) {
    return Result<CompressionAnalysisResultV1>::failure(diagnostic(
        "compression.empirical_finite_window_fit_forbidden",
        "empirical finite-window response mode cannot fit or consume a completed surrogate profile"));
  }
  if (effective_options.poisson_overshoot) {
    const auto& evaluator = *effective_options.poisson_overshoot;
    if ((evaluator.descriptor_id !=
             "iid_independent_poisson_overshoot_v1" &&
         evaluator.descriptor_id != "iid_mixed_poisson_overshoot_v1") ||
        evaluator.descriptor_version != 1U || evaluator.components.empty() ||
        evaluator.omitted_tail_tolerance !=
            cp09_poisson_omitted_tail_tolerance() ||
        evaluator.maximum_recurrence_steps == 0U) {
      return Result<CompressionAnalysisResultV1>::failure(diagnostic(
          "compression.poisson_overshoot_policy_invalid",
          "the CP09 Poisson evaluator requires its registered descriptor, 1e-45 enclosure target, and a positive reported recurrence budget"));
    }
    ExactRational weight = ExactRational::zero();
    for (const auto& component : evaluator.components) {
      const double operational =
          std::bit_cast<double>(component.operational_rate_bits);
      if (!component.weight.is_nonnegative() ||
          !component.component_rate.is_nonnegative() ||
          !std::isfinite(operational) || operational < 0.0 ||
          (component.component_rate.is_zero() != (operational == 0.0))) {
        return Result<CompressionAnalysisResultV1>::failure(diagnostic(
            "compression.poisson_overshoot_component_invalid",
            "a Poisson mixture component has an invalid weight, declarative rate, or operational binary64 binding"));
      }
      weight = weight + component.weight;
    }
    if (weight != ExactRational::one()) {
      return Result<CompressionAnalysisResultV1>::failure(diagnostic(
          "compression.poisson_overshoot_weights_invalid",
          "Poisson mixture component weights must sum exactly to one"));
    }
  }
  std::vector<BigNat> supplied_cutoffs;
  supplied_cutoffs.reserve(
      effective_options.provider_supplied_profiles.size());
  for (const auto& profile : effective_options.provider_supplied_profiles) {
    if (!valid_supplied_profile_semantics(profile)) {
      return Result<CompressionAnalysisResultV1>::failure(diagnostic(
          "compression.supplied_profile_invalid",
          "a provider-supplied diagnostic profile has invalid arity, range, "
          "or supporting-mass semantics"));
    }
    supplied_cutoffs.push_back(profile.cutoff);
  }
  std::sort(supplied_cutoffs.begin(), supplied_cutoffs.end());
  if (std::adjacent_find(supplied_cutoffs.begin(), supplied_cutoffs.end()) !=
      supplied_cutoffs.end()) {
    return Result<CompressionAnalysisResultV1>::failure(diagnostic(
        "compression.supplied_profile_duplicate",
        "provider-supplied diagnostic profiles must have unique cutoffs"));
  }
  auto digest =
      compression_analysis_digest(observation.digest(), effective_options);
  if (!digest) {
    return Result<CompressionAnalysisResultV1>::failure(digest.error());
  }
  auto point = analyze_core(observation, effective_options, digest.value(),
                            std::nullopt);
  if (!point) {
    return Result<CompressionAnalysisResultV1>::failure(point.error());
  }
  CoreAnalysis point_analysis = std::move(point).value();
  if (!effective_options.compute_delete_one_replication_jackknife) {
    return Result<CompressionAnalysisResultV1>::success(
        std::move(point_analysis.result));
  }

  const ConstructionObservationBundleV1& bundle = observation.value();
  const std::size_t cutoff_count = point_analysis.result.cutoffs.size();
  const std::size_t replication_count =
      point_analysis.included_replication_indices.size();
  const std::uint64_t point_peak_objects =
      point_analysis.result.work.peak_retained_top_level_objects;
  const std::uint64_t point_peak_bytes =
      point_analysis.result.work.estimated_peak_retained_bytes;
  std::vector<std::vector<JackknifeReplicationEstimateV1>> fit_samples(
      cutoff_count);
  std::vector<std::vector<JackknifeReplicationEstimateV1>> error_samples(
      cutoff_count);
  std::vector<std::vector<JackknifeReplicationEstimateV1>>
      association_samples(cutoff_count);
  std::vector<FitResampleCountsV1> fit_resample_counts(cutoff_count,
                                                        FitResampleCountsV1{});
  record_allocation_events(point_analysis.result.work, 4U);
  for (std::size_t cutoff_index = 0U; cutoff_index < cutoff_count;
       ++cutoff_index) {
    fit_samples[cutoff_index].reserve(replication_count);
    error_samples[cutoff_index].reserve(replication_count);
    association_samples[cutoff_index].reserve(replication_count);
    record_allocation_events(point_analysis.result.work, 3U);
  }

  for (const std::size_t omitted :
       point_analysis.included_replication_indices) {
    const TypedLabel& id = bundle.replications[omitted].replication_id;
    auto sample = analyze_core(observation, effective_options, digest.value(),
                               omitted);
    if (!sample) {
      const CompressionQuantityV1 invalid = unavailable(
          CompressionUnavailableReasonV1::invalid_jackknife_resample);
      for (std::size_t cutoff_index = 0U; cutoff_index < cutoff_count;
           ++cutoff_index) {
        saturating_increment(
            fit_resample_counts[cutoff_index].unavailable_fit_resamples);
        fit_samples[cutoff_index].push_back(
            JackknifeReplicationEstimateV1{id, invalid});
        error_samples[cutoff_index].push_back(
            JackknifeReplicationEstimateV1{id, invalid});
        association_samples[cutoff_index].push_back(
            JackknifeReplicationEstimateV1{id, invalid});
      }
      continue;
    }

    CoreAnalysis sample_analysis = std::move(sample).value();
    point_analysis.result.work.peak_retained_top_level_objects = std::max(
        point_analysis.result.work.peak_retained_top_level_objects,
        saturated_sum(point_peak_objects,
                      sample_analysis.result.work
                          .peak_retained_top_level_objects));
    point_analysis.result.work.estimated_peak_retained_bytes = std::max(
        point_analysis.result.work.estimated_peak_retained_bytes,
        saturated_sum(
            point_peak_bytes,
            sample_analysis.result.work.estimated_peak_retained_bytes));
    add_work(point_analysis.result.work, sample_analysis.result.work);
    for (std::size_t cutoff_index = 0U; cutoff_index < cutoff_count;
         ++cutoff_index) {
      const CompressionCutoffAnalysisV1& sample_cutoff =
          sample_analysis.result.cutoffs[cutoff_index];
      FitResampleCountsV1& counts = fit_resample_counts[cutoff_index];
      if (sample_cutoff.diagnostic_fit ||
          sample_cutoff.diagnostic_fit_failure) {
        saturating_increment(counts.eligible_fit_resamples);
        if (sample_cutoff.diagnostic_fit_failure ||
            !sample_cutoff.diagnostic_fit ||
            !sample_cutoff.diagnostic_fit->fitted_mean_backlog) {
          saturating_increment(counts.failed_fit_resamples);
        } else if (!sample_cutoff.diagnostic_fitted_mean.available()) {
          saturating_increment(counts.unavailable_estimate_resamples);
        }
      } else {
        saturating_increment(counts.unavailable_fit_resamples);
      }
      fit_samples[cutoff_index].push_back(JackknifeReplicationEstimateV1{
          id, fit_mean_quantity(sample_cutoff)});
      error_samples[cutoff_index].push_back(JackknifeReplicationEstimateV1{
          id, sample_cutoff.decomposition.fitted_minus_observed_mean});
      association_samples[cutoff_index].push_back(
          JackknifeReplicationEstimateV1{
              id, sample_cutoff.tail.tail_association_ratio});
    }
  }

  const std::uint64_t retained_jackknife_vectors =
      saturated_product(3U, bounded_u64(cutoff_count));
  const std::uint64_t retained_jackknife_rows = saturated_product(
      retained_jackknife_vectors, bounded_u64(replication_count));
  const std::uint64_t retained_jackknife_estimates = saturated_sum(
      saturated_sum(retained_jackknife_vectors, retained_jackknife_rows),
      bounded_u64(cutoff_count));
  point_analysis.result.work.peak_retained_top_level_objects = std::max(
      point_analysis.result.work.peak_retained_top_level_objects,
      saturated_sum(point_peak_objects, retained_jackknife_estimates));
  point_analysis.result.work.estimated_peak_retained_bytes = std::max(
      point_analysis.result.work.estimated_peak_retained_bytes,
      saturated_sum(
          point_peak_bytes,
          saturated_sum(
              saturated_product(
                  retained_jackknife_vectors,
                  sizeof(std::vector<JackknifeReplicationEstimateV1>)),
              saturated_sum(
                  saturated_product(
                      retained_jackknife_rows,
                      sizeof(JackknifeReplicationEstimateV1)),
                  saturated_product(bounded_u64(cutoff_count),
                                    sizeof(FitResampleCountsV1))))));

  for (std::size_t cutoff_index = 0U; cutoff_index < cutoff_count;
       ++cutoff_index) {
    CompressionCutoffAnalysisV1& point_cutoff =
        point_analysis.result.cutoffs[cutoff_index];
    auto fit_summary = summarize_delete_one_replication_jackknife_v1(
        fit_mean_quantity(point_cutoff), fit_samples[cutoff_index]);
    auto error_summary = summarize_delete_one_replication_jackknife_v1(
        point_cutoff.decomposition.fitted_minus_observed_mean,
        error_samples[cutoff_index]);
    auto association_summary = summarize_delete_one_replication_jackknife_v1(
        point_cutoff.tail.tail_association_ratio,
        association_samples[cutoff_index]);
    if (!fit_summary || !error_summary || !association_summary) {
      return Result<CompressionAnalysisResultV1>::failure(
          !fit_summary ? fit_summary.error()
                       : (!error_summary ? error_summary.error()
                                         : association_summary.error()));
    }
    point_cutoff.jackknife = CompressionCutoffJackknifeV1{
        std::move(fit_summary).value(), std::move(error_summary).value(),
        std::move(association_summary).value(),
        fit_resample_counts[cutoff_index]};
  }
  return Result<CompressionAnalysisResultV1>::success(
      std::move(point_analysis.result));
}

FrameworkEmpiricalPredictionV1 derive_framework_empirical_prediction_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisResultV1& analysis,
    const CompressionAnalysisOptionsV1& options) {
  const auto unavailable_quantity = [](std::string reason) {
    return FrameworkPredictionQuantityV1{
        FrameworkPredictionAvailabilityV1::unavailable, std::nullopt,
        std::move(reason)};
  };
  const auto available_quantity = [](ExactRational value) {
    return FrameworkPredictionQuantityV1{
        FrameworkPredictionAvailabilityV1::available,
        std::optional<ExactRational>(std::move(value)), std::nullopt};
  };
  const auto status_reason = [](const FinitePrefixFitStatusV1 status) {
    switch (status) {
      case FinitePrefixFitStatusV1::strict_tail_stable:
      case FinitePrefixFitStatusV1::finite_closed_tail_unreachable:
        return std::string("stationary_quantity_unavailable");
      case FinitePrefixFitStatusV1::outside_strict_tail_profile:
        return std::string("constant_tail_not_strictly_stable");
      case FinitePrefixFitStatusV1::degenerate_or_selected_closed_class:
        return std::string("selected_closed_class_not_resolved");
      case FinitePrefixFitStatusV1::required_moment_unavailable:
        return std::string("required_arrival_moment_unavailable");
      case FinitePrefixFitStatusV1::unsupported_assumptions:
        return std::string("finite_prefix_assumptions_unsupported");
    }
    return std::string("stationary_quantity_unavailable");
  };

  constexpr std::string_view not_reached = "calculation_not_reached";
  FrameworkEmpiricalPredictionV1 result{
      observation.digest(),
      analysis.analysis_digest,
      observation.value().bindings.target.target_id,
      FrameworkPredictionAvailabilityV1::unavailable,
      std::string(not_reached),
      std::nullopt,
      std::nullopt,
      std::nullopt,
      {},
      false,
      std::nullopt,
      {},
      unavailable_quantity(std::string(not_reached)),
      unavailable_quantity(std::string(not_reached)),
      unavailable_quantity(std::string(not_reached)),
      unavailable_quantity(std::string(not_reached)),
      unavailable_quantity(std::string(not_reached)),
      available_quantity(observation.value().bindings.arrival.mean)};

  const auto fail_all = [&](std::string reason) {
    result.calculation_status =
        FrameworkPredictionAvailabilityV1::unavailable;
    result.calculation_reason_code = reason;
    result.stationary_pmf.clear();
    result.remaining_tail_probability = unavailable_quantity(reason);
    result.empty_probability = unavailable_quantity(reason);
    result.first_backlog_moment = unavailable_quantity(reason);
    result.second_backlog_moment = unavailable_quantity(reason);
    result.mean_sojourn = unavailable_quantity(std::move(reason));
  };

  if (analysis.observation_digest != observation.digest() ||
      analysis.bindings != observation.value().bindings ||
      analysis.projection_mode !=
          CompressionAnalysisOptionsV1::ProjectionMode::
              empirical_finite_window_response ||
      !analysis.empirical_finite_window_response) {
    fail_all("empirical_analysis_binding_mismatch");
    return result;
  }
  auto effective =
      effective_compression_analysis_options_v1(observation, options);
  if (!effective) {
    fail_all(effective.error().code);
    return result;
  }
  auto expected_analysis_digest =
      compression_analysis_identity_digest_v1(observation,
                                              effective.value());
  if (!expected_analysis_digest ||
      expected_analysis_digest.value() != analysis.analysis_digest) {
    fail_all("empirical_analysis_options_mismatch");
    return result;
  }
  const EmpiricalFiniteWindowResponseV1& profile =
      *analysis.empirical_finite_window_response;
  if (!profile.complete_through.has_value() ||
      profile.complete_through->is_zero()) {
    fail_all("contiguous_response_requires_positive_anchor");
    return result;
  }
  if (profile.complete_through->value() >
      BigInt{std::numeric_limits<std::size_t>::max() - 1U}) {
    fail_all("contiguous_response_not_addressable");
    return result;
  }

  const std::size_t complete_through =
      profile.complete_through->value().convert_to<std::size_t>();
  result.observed_complete_through = *profile.complete_through;
  result.prefix_cutoff = *profile.complete_through;
  BigNat constant_tail_from = *profile.complete_through;
  ++constant_tail_from;
  result.constant_tail_from = std::move(constant_tail_from);
  result.response_points.reserve(complete_through + 1U);
  std::vector<ExactRational> service_by_level;
  service_by_level.reserve(complete_through + 1U);

  std::size_t source_index = 0U;
  for (std::size_t level = 0U; level <= complete_through; ++level) {
    while (source_index < profile.observed_levels.size() &&
           profile.observed_levels[source_index].backlog_level.value() <
               BigInt{level}) {
      ++source_index;
    }
    if (source_index == profile.observed_levels.size() ||
        profile.observed_levels[source_index].backlog_level.value() !=
            BigInt{level}) {
      fail_all("contiguous_response_level_missing");
      return result;
    }
    const EmpiricalFiniteWindowResponsePointV1& point =
        profile.observed_levels[source_index];
    if (!point.response.estimate.has_value() ||
        !point.response.status.available()) {
      fail_all("contiguous_response_coefficient_unavailable");
      return result;
    }
    result.response_has_numerical_enclosures |=
        !point.response.estimate->absolute_error_bound.is_zero();
    result.response_points.push_back(FrameworkPredictionResponsePointV1{
        point.backlog_level, *point.response.estimate,
        point.response_status, level == complete_through});
    service_by_level.push_back(point.response.estimate->value);
    ++source_index;
  }
  const ExactRational constant_tail_service =
      result.response_points.back().observed_response.value;

  std::vector<FinitePrefixFitArrivalAtomV1> arrival_atoms;
  std::optional<FinitePrefixFitArrivalMomentsV1> analytic_arrival_moments;
  bool arrival_support_extends_beyond_projection = false;
  const auto* exact_arrival = std::get_if<ExactTargetArrivalMarginalV1>(
      &observation.value().bindings.arrival.target_arrival);
  if (exact_arrival != nullptr) {
    arrival_atoms.reserve(exact_arrival->atoms.size());
    for (const ExactTargetArrivalAtomV1& atom : exact_arrival->atoms) {
      arrival_atoms.push_back(
          FinitePrefixFitArrivalAtomV1{atom.batch_size, atom.probability});
    }
  } else {
    auto decoded_arrival = arrival_data(observation.value(), effective.value());
    if (!decoded_arrival) {
      fail_all(decoded_arrival.error().code);
      return result;
    }
    if (decoded_arrival.value().poisson_overshoot == nullptr) {
      fail_all("exact_target_arrival_marginal_unavailable");
      return result;
    }
    auto projection = make_poisson_fit_projection(
        *decoded_arrival.value().poisson_overshoot, complete_through);
    if (!projection) {
      fail_all(projection.error().code);
      return result;
    }
    arrival_atoms = std::move(projection.value().atoms);
    analytic_arrival_moments =
        std::move(projection.value().analytic_moments);
    arrival_support_extends_beyond_projection =
        projection.value().support_extends_beyond_projection;
    result.poisson_arrival_reconstruction =
        std::move(projection.value().report);
  }

  const std::size_t no_artificial_limit =
      std::numeric_limits<std::size_t>::max();
  FinitePrefixFitInputV1 input{
      std::move(arrival_atoms),
      true,
      true,
      effective.value().selection_seed,
      std::move(service_by_level),
      constant_tail_service,
      FinitePrefixFitBindingV1{
          observation.digest(),
          observation.value().bindings.arrival.configured_law_digest},
      FinitePrefixFitLimitsV1{no_artificial_limit - 1U,
                             no_artificial_limit,
                             no_artificial_limit,
                             no_artificial_limit},
      std::move(analytic_arrival_moments),
      arrival_support_extends_beyond_projection};
  auto fitted = fit_finite_prefix_constant_tail(std::move(input));
  if (!fitted) {
    fail_all(fitted.error().code);
    return result;
  }
  FinitePrefixFitResultV1 fit = std::move(fitted).value();
  if (!fit.normalized_law_established()) {
    fail_all(status_reason(fit.status));
    return result;
  }

  result.stationary_pmf.reserve(fit.fitted_prefix_probabilities->size());
  for (std::size_t level = 0U;
       level < fit.fitted_prefix_probabilities->size(); ++level) {
    result.stationary_pmf.push_back(FrameworkPredictionPmfPointV1{
        BigNat{level},
        available_quantity((*fit.fitted_prefix_probabilities)[level])});
  }
  result.remaining_tail_probability =
      available_quantity(*fit.fitted_tail_mass);
  result.empty_probability =
      result.stationary_pmf.empty()
          ? unavailable_quantity("stationary_empty_probability_unavailable")
          : result.stationary_pmf.front().probability;
  result.first_backlog_moment =
      fit.fitted_mean_backlog
          ? available_quantity(*fit.fitted_mean_backlog)
          : unavailable_quantity("stationary_first_moment_unavailable");
  result.second_backlog_moment =
      fit.fitted_second_backlog_moment
          ? available_quantity(*fit.fitted_second_backlog_moment)
          : unavailable_quantity(
                fit.arrival_third_moment
                    ? "stationary_second_moment_unavailable"
                    : "arrival_third_moment_unavailable");
  if (!observation.value().bindings.arrival.mean.is_positive()) {
    result.mean_sojourn =
        unavailable_quantity("positive_arrival_mean_required");
  } else if (!fit.fitted_mean_backlog) {
    result.mean_sojourn =
        unavailable_quantity("stationary_first_moment_unavailable");
  } else {
    auto sojourn = checked_divide(
        *fit.fitted_mean_backlog,
        observation.value().bindings.arrival.mean);
    result.mean_sojourn =
        sojourn ? available_quantity(std::move(sojourn).value())
                : unavailable_quantity("mean_sojourn_division_failed");
  }

  const bool all_required_available =
      result.remaining_tail_probability.available() &&
      result.empty_probability.available() &&
      result.first_backlog_moment.available() &&
      result.second_backlog_moment.available() &&
      result.mean_sojourn.available();
  result.calculation_status =
      all_required_available
          ? FrameworkPredictionAvailabilityV1::available
          : FrameworkPredictionAvailabilityV1::unavailable;
  result.calculation_reason_code = std::nullopt;
  if (!all_required_available) {
    for (const FrameworkPredictionQuantityV1* quantity : {
             &result.remaining_tail_probability,
             &result.empty_probability,
             &result.first_backlog_moment,
             &result.second_backlog_moment,
             &result.mean_sojourn}) {
      if (!quantity->available() && quantity->reason_code.has_value()) {
        result.calculation_reason_code = quantity->reason_code;
        break;
      }
    }
    if (!result.calculation_reason_code.has_value()) {
      result.calculation_reason_code =
          "one_or_more_requested_predictions_unavailable";
    }
  }
  return result;
}

}  // namespace mwperf
