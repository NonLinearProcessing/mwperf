#pragma once

#include <span>
#include <utility>
#include <vector>

#include "mwperf/arrival/types.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class NonnegativeIntegralDirection final {
 public:
  NonnegativeIntegralDirection() = delete;
  NonnegativeIntegralDirection(const NonnegativeIntegralDirection&) = default;
  NonnegativeIntegralDirection(NonnegativeIntegralDirection&&) noexcept =
      default;
  NonnegativeIntegralDirection& operator=(
      const NonnegativeIntegralDirection&) = default;
  NonnegativeIntegralDirection& operator=(
      NonnegativeIntegralDirection&&) noexcept = default;

  [[nodiscard]] static Result<NonnegativeIntegralDirection> from_values(
      QueueDimensionToken dimension, std::vector<BigNat> values);

  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return dimension_;
  }
  [[nodiscard]] std::span<const BigNat> values() const noexcept {
    return values_;
  }
  [[nodiscard]] const Digest256& identity_digest() const noexcept {
    return identity_digest_;
  }

  friend bool operator==(const NonnegativeIntegralDirection&,
                         const NonnegativeIntegralDirection&) = default;

 private:
  NonnegativeIntegralDirection(QueueDimensionToken dimension,
                               std::vector<BigNat> values,
                               Digest256 identity_digest)
      : dimension_(std::move(dimension)),
        values_(std::move(values)),
        identity_digest_(std::move(identity_digest)) {}

  QueueDimensionToken dimension_;
  std::vector<BigNat> values_;
  Digest256 identity_digest_;
};

class ResourceCoordinate final {
 public:
  ResourceCoordinate() = delete;
  ResourceCoordinate(const ResourceCoordinate&) = default;
  ResourceCoordinate(ResourceCoordinate&&) noexcept = default;
  ResourceCoordinate& operator=(const ResourceCoordinate&) = default;
  ResourceCoordinate& operator=(ResourceCoordinate&&) noexcept = default;

  [[nodiscard]] static Result<ResourceCoordinate> make(
      NonnegativeIntegralDirection direction, BigNat capacity,
      BigNat workload, BigNat unused_capacity, BigNat lower_queue,
      bool lower_domination_declared);

  [[nodiscard]] const NonnegativeIntegralDirection& direction() const noexcept {
    return direction_;
  }
  [[nodiscard]] const BigNat& capacity() const noexcept { return capacity_; }
  [[nodiscard]] const BigNat& workload() const noexcept { return workload_; }
  [[nodiscard]] const BigNat& unused_capacity() const noexcept {
    return unused_capacity_;
  }
  [[nodiscard]] const BigNat& lower_queue() const noexcept {
    return lower_queue_;
  }
  [[nodiscard]] bool lower_domination_declared() const noexcept {
    return lower_domination_declared_;
  }

  friend bool operator==(const ResourceCoordinate&,
                         const ResourceCoordinate&) = default;

 private:
  ResourceCoordinate(NonnegativeIntegralDirection direction,
                     BigNat capacity, BigNat workload,
                     BigNat unused_capacity, BigNat lower_queue,
                     bool lower_domination_declared)
      : direction_(std::move(direction)),
        capacity_(std::move(capacity)),
        workload_(std::move(workload)),
        unused_capacity_(std::move(unused_capacity)),
        lower_queue_(std::move(lower_queue)),
        lower_domination_declared_(lower_domination_declared) {}

  NonnegativeIntegralDirection direction_;
  BigNat capacity_;
  BigNat workload_;
  BigNat unused_capacity_;
  BigNat lower_queue_;
  bool lower_domination_declared_;

  friend Result<class ResourceState> update_resource_coordinates(
      const class ResourceState&, const Schedule&, const ArrivalBatch&);
};

class ResourceState final {
 public:
  ResourceState() = delete;
  ResourceState(const ResourceState&) = default;
  ResourceState(ResourceState&&) noexcept = default;
  ResourceState& operator=(const ResourceState&) = default;
  ResourceState& operator=(ResourceState&&) noexcept = default;

  [[nodiscard]] static Result<ResourceState> from_coordinates(
      std::vector<ResourceCoordinate> coordinates);

  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return coordinates_.front().direction().dimension();
  }
  [[nodiscard]] std::span<const ResourceCoordinate> coordinates()
      const noexcept {
    return coordinates_;
  }

  friend bool operator==(const ResourceState&, const ResourceState&) = default;

 private:
  explicit ResourceState(std::vector<ResourceCoordinate> coordinates)
      : coordinates_(std::move(coordinates)) {}

  std::vector<ResourceCoordinate> coordinates_;

  friend Result<ResourceState> update_resource_coordinates(
      const ResourceState&, const Schedule&, const ArrivalBatch&);
};

// F-C13-03
[[nodiscard]] Result<BigNat> compute_resource_capacity(
    const ResolvedInstance& instance,
    const NonnegativeIntegralDirection& direction,
    OptimizerExecutionContext& optimizer_context);

// F-C13-04. schedule is the common actual departure vector, never an
// unpruned attempted-service vector.
[[nodiscard]] Result<ResourceState> update_resource_coordinates(
    const ResourceState& state, const Schedule& schedule,
    const ArrivalBatch& arrival_batch);

}  // namespace mwperf
