#pragma once

#include <cstdint>
#include <utility>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/forced_target.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

enum class AlgebraicTargetClass : std::uint8_t {
  forced_out,
  tie,
  forced_in,
};

struct CrossClassOutcome final {
  AlgebraicTargetClass algebraic_class;
  // This is the eligibility at the evaluated physical boundary. When false,
  // configured_winning_side/schedule remain algebraic forced-face evidence;
  // they are not permission to depart from an empty target queue.
  bool target_eligible;
  ForcedTargetBit configured_winning_side;
  Schedule configured_winning_schedule;
  BigNat forced_out_complete_objective;
  BigNat forced_in_complete_objective;
  BigNat configured_winning_secondary_code;

  friend bool operator==(const CrossClassOutcome&,
                         const CrossClassOutcome&) = default;
};

struct EqualityWinnerEvidence final {
  ForcedTargetBit winning_side;
  Schedule winning_schedule;
  BigNat common_primary_objective;
  BigNat winning_secondary_code;

  friend bool operator==(const EqualityWinnerEvidence&,
                         const EqualityWinnerEvidence&) = default;
};

class TargetBacklog final {
 public:
  explicit TargetBacklog(BigNat value) : value_(std::move(value)) {}

  [[nodiscard]] const BigNat& value() const noexcept { return value_; }

  friend bool operator==(const TargetBacklog&, const TargetBacklog&) = default;

 private:
  BigNat value_;
};

struct TargetClass final {
  AlgebraicTargetClass algebraic_class;
  bool eligible;
  BigInt algebraic_margin;

  friend bool operator==(const TargetClass&, const TargetClass&) = default;
};

// One complete exact certificate for the two target-constrained optimizer
// faces at a particular backlog. The stored margin is an exact signed integer;
// the configured secondary priority appears only as witness provenance.
class Opportunity final {
 public:
  Opportunity() = delete;
  Opportunity(const Opportunity&) = default;
  Opportunity(Opportunity&&) noexcept = default;
  Opportunity& operator=(const Opportunity&) = default;
  Opportunity& operator=(Opportunity&&) noexcept = default;

  [[nodiscard]] const TargetIndex& target() const noexcept { return target_; }
  [[nodiscard]] const Backlog& evaluation_backlog() const noexcept {
    return evaluation_backlog_;
  }
  // Canonical semantic-result digest. Process-local backend accounting and
  // call ordinals are deliberately retained in the two certificates instead
  // of entering this replay-stable mathematical identity.
  [[nodiscard]] const Digest256& certificate_digest() const noexcept {
    return certificate_digest_;
  }
  [[nodiscard]] const BigNat& psi0() const noexcept { return psi0_; }
  [[nodiscard]] const BigNat& psi1() const noexcept { return psi1_; }
  [[nodiscard]] const BigNat& theta() const noexcept { return theta_; }
  [[nodiscard]] const BigInt& margin() const noexcept { return margin_; }
  [[nodiscard]] const CrossClassOutcome& cross_class_outcome() const noexcept {
    return cross_class_outcome_;
  }
  [[nodiscard]] const EqualityWinnerEvidence&
  equality_winner_if_qe_eq_theta() const noexcept {
    return equality_winner_if_qe_eq_theta_;
  }
  [[nodiscard]] const PrimaryOptimum& forced_out_certificate() const noexcept {
    return forced_out_certificate_;
  }
  [[nodiscard]] const PrimaryOptimum& forced_in_certificate() const noexcept {
    return forced_in_certificate_;
  }

 private:
  Opportunity(TargetIndex target, Backlog evaluation_backlog,
              Digest256 certificate_digest, BigNat psi0, BigNat psi1,
              BigNat theta, BigInt margin,
              CrossClassOutcome cross_class_outcome,
              EqualityWinnerEvidence equality_winner_if_qe_eq_theta,
              PrimaryOptimum forced_out_certificate,
              PrimaryOptimum forced_in_certificate)
      : target_(std::move(target)),
        evaluation_backlog_(std::move(evaluation_backlog)),
        certificate_digest_(std::move(certificate_digest)),
        psi0_(std::move(psi0)),
        psi1_(std::move(psi1)),
        theta_(std::move(theta)),
        margin_(std::move(margin)),
        cross_class_outcome_(std::move(cross_class_outcome)),
        equality_winner_if_qe_eq_theta_(
            std::move(equality_winner_if_qe_eq_theta)),
        forced_out_certificate_(std::move(forced_out_certificate)),
        forced_in_certificate_(std::move(forced_in_certificate)) {}

  TargetIndex target_;
  Backlog evaluation_backlog_;
  Digest256 certificate_digest_;
  BigNat psi0_;
  BigNat psi1_;
  BigNat theta_;
  BigInt margin_;
  CrossClassOutcome cross_class_outcome_;
  EqualityWinnerEvidence equality_winner_if_qe_eq_theta_;
  PrimaryOptimum forced_out_certificate_;
  PrimaryOptimum forced_in_certificate_;

  friend Result<Opportunity> compute_target_opportunity(
      const ResolvedInstance&, const Backlog&, TargetIndex,
      OptimizerExecutionContext&);
};

// F-C13-01
[[nodiscard]] Result<Opportunity> compute_target_opportunity(
    const ResolvedInstance& instance, const Backlog& backlog,
    TargetIndex target, OptimizerExecutionContext& optimizer_context);

// F-C13-02
[[nodiscard]] TargetClass classify_target_decision(
    const Opportunity& opportunity, TargetBacklog target_backlog);

}  // namespace mwperf
