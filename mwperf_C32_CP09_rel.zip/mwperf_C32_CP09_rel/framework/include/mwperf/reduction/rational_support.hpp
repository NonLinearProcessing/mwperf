#pragma once

#include <cstddef>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct RationalSupportRepresentationBudget final {
  std::optional<std::size_t> maximum_clearing_denominator_bits;
  std::optional<std::size_t> maximum_cleared_weight_bits;

  [[nodiscard]] static RationalSupportRepresentationBudget unbounded() {
    return {};
  }

  friend bool operator==(const RationalSupportRepresentationBudget&,
                         const RationalSupportRepresentationBudget&) =
      default;
};

class ExactNonnegativeRationalWeights final {
 public:
  ExactNonnegativeRationalWeights() = delete;
  ExactNonnegativeRationalWeights(
      const ExactNonnegativeRationalWeights&) = default;
  ExactNonnegativeRationalWeights(
      ExactNonnegativeRationalWeights&&) noexcept = default;
  ExactNonnegativeRationalWeights& operator=(
      const ExactNonnegativeRationalWeights&) = default;
  ExactNonnegativeRationalWeights& operator=(
      ExactNonnegativeRationalWeights&&) noexcept = default;

  [[nodiscard]] static Result<ExactNonnegativeRationalWeights> from_values(
      QueueDimensionToken dimension, std::vector<ExactRational> values,
      RationalSupportRepresentationBudget representation_budget);

  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return dimension_;
  }
  [[nodiscard]] std::span<const ExactRational> values() const noexcept {
    return values_;
  }
  [[nodiscard]] const RationalSupportRepresentationBudget&
  representation_budget() const noexcept {
    return representation_budget_;
  }
  [[nodiscard]] const Digest256& identity_digest() const noexcept {
    return identity_digest_;
  }

  // Equality is mathematical vector identity. Representation limits govern
  // one request's clearing work and do not alter the represented weights.
  friend bool operator==(const ExactNonnegativeRationalWeights& left,
                         const ExactNonnegativeRationalWeights& right) {
    return left.dimension_ == right.dimension_ &&
           left.values_ == right.values_;
  }

 private:
  ExactNonnegativeRationalWeights(
      QueueDimensionToken dimension, std::vector<ExactRational> values,
      RationalSupportRepresentationBudget representation_budget,
      Digest256 identity_digest)
      : dimension_(std::move(dimension)),
        values_(std::move(values)),
        representation_budget_(std::move(representation_budget)),
        identity_digest_(std::move(identity_digest)) {}

  QueueDimensionToken dimension_;
  std::vector<ExactRational> values_;
  RationalSupportRepresentationBudget representation_budget_;
  // Mathematical vector identity only; representation_budget_ is operational
  // request metadata and is deliberately excluded from this digest.
  Digest256 identity_digest_;
};

class RationalSupportCertificate final {
 public:
  RationalSupportCertificate() = delete;
  RationalSupportCertificate(const RationalSupportCertificate&) = default;
  RationalSupportCertificate(RationalSupportCertificate&&) noexcept = default;
  RationalSupportCertificate& operator=(
      const RationalSupportCertificate&) = default;
  RationalSupportCertificate& operator=(
      RationalSupportCertificate&&) noexcept = default;

  [[nodiscard]] const ExactNonnegativeRationalWeights& original_weights()
      const noexcept {
    return original_weights_;
  }
  [[nodiscard]] const Digest256& original_weights_digest() const noexcept {
    return original_weights_.identity_digest();
  }
  [[nodiscard]] const BigNat& clearing_denominator() const noexcept {
    return clearing_denominator_;
  }
  [[nodiscard]] const PrimaryWeights& cleared_integral_weights()
      const noexcept {
    return cleared_integral_weights_;
  }
  [[nodiscard]] const Digest256& cleared_integral_weights_digest()
      const noexcept {
    return cleared_integral_weights_digest_;
  }
  [[nodiscard]] const ExactRational& support_value() const noexcept {
    return support_value_;
  }
  [[nodiscard]] const Schedule& selected_witness() const noexcept {
    return optimizer_certificate_.schedule();
  }
  [[nodiscard]] const OptimizerSolution& optimizer_certificate()
      const noexcept {
    return optimizer_certificate_;
  }
  [[nodiscard]] const Digest256& deterministic_priority_identity()
      const noexcept {
    return deterministic_priority_identity_;
  }
  [[nodiscard]] const Digest256& combined_input_identity() const noexcept {
    return combined_input_identity_;
  }
  [[nodiscard]] ServiceFamily family() const noexcept { return family_; }

 private:
  RationalSupportCertificate(
      ExactNonnegativeRationalWeights original_weights,
      BigNat clearing_denominator, PrimaryWeights cleared_integral_weights,
      Digest256 cleared_integral_weights_digest,
      ExactRational support_value, OptimizerSolution optimizer_certificate,
      Digest256 deterministic_priority_identity,
      Digest256 combined_input_identity, ServiceFamily family)
      : original_weights_(std::move(original_weights)),
        clearing_denominator_(std::move(clearing_denominator)),
        cleared_integral_weights_(std::move(cleared_integral_weights)),
        cleared_integral_weights_digest_(
            std::move(cleared_integral_weights_digest)),
        support_value_(std::move(support_value)),
        optimizer_certificate_(std::move(optimizer_certificate)),
        deterministic_priority_identity_(
            std::move(deterministic_priority_identity)),
        combined_input_identity_(std::move(combined_input_identity)),
        family_(family) {}

  ExactNonnegativeRationalWeights original_weights_;
  BigNat clearing_denominator_;
  PrimaryWeights cleared_integral_weights_;
  Digest256 cleared_integral_weights_digest_;
  ExactRational support_value_;
  OptimizerSolution optimizer_certificate_;
  Digest256 deterministic_priority_identity_;
  Digest256 combined_input_identity_;
  ServiceFamily family_;

  friend Result<RationalSupportCertificate> compute_rational_support(
      const ResolvedInstance&, const ExactNonnegativeRationalWeights&,
      OptimizerExecutionContext&);
};

// F-C13-07
[[nodiscard]] Result<RationalSupportCertificate> compute_rational_support(
    const ResolvedInstance& instance,
    const ExactNonnegativeRationalWeights& weights,
    OptimizerExecutionContext& optimizer_context);

}  // namespace mwperf
