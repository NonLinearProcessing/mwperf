#pragma once

#include <cstdint>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/physical/physical_edge.hpp"
#include "mwperf/reduction/opportunity.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class SchedulePair final {
 public:
  SchedulePair() = delete;
  SchedulePair(const SchedulePair&) = default;
  SchedulePair(SchedulePair&&) noexcept = default;
  SchedulePair& operator=(const SchedulePair&) = default;
  SchedulePair& operator=(SchedulePair&&) noexcept = default;

  [[nodiscard]] static Result<SchedulePair> make(
      const ResolvedInstance& instance, TargetIndex target,
      Schedule forced_out_representative,
      Schedule forced_in_representative);

  [[nodiscard]] const TargetIndex& target() const noexcept { return target_; }
  [[nodiscard]] const Schedule& forced_out_representative() const noexcept {
    return forced_out_representative_;
  }
  [[nodiscard]] const Schedule& forced_in_representative() const noexcept {
    return forced_in_representative_;
  }
  [[nodiscard]] std::span<const std::int8_t> signature() const noexcept {
    return signature_;
  }
  [[nodiscard]] const Digest256& identity_digest() const noexcept {
    return identity_digest_;
  }

  friend bool operator==(const SchedulePair&, const SchedulePair&) = default;

 private:
  SchedulePair(TargetIndex target, Schedule forced_out_representative,
               Schedule forced_in_representative,
               std::vector<std::int8_t> signature,
               Digest256 identity_digest)
      : target_(std::move(target)),
        forced_out_representative_(
            std::move(forced_out_representative)),
        forced_in_representative_(std::move(forced_in_representative)),
        signature_(std::move(signature)),
        identity_digest_(std::move(identity_digest)) {}

  TargetIndex target_;
  Schedule forced_out_representative_;
  Schedule forced_in_representative_;
  std::vector<std::int8_t> signature_;
  Digest256 identity_digest_;
};

struct RepresentativeSelectionEvidence final {
  AlgebraicTargetClass algebraic_class;
  ForcedTargetBit configured_winning_side;
  Schedule configured_winning_schedule;
  bool configured_winner_matches_pair_endpoint;
  bool strict_class_comparison;

  friend bool operator==(const RepresentativeSelectionEvidence&,
                         const RepresentativeSelectionEvidence&) = default;
};

class PairMargin final {
 public:
  PairMargin() = delete;
  PairMargin(const PairMargin&) = default;
  PairMargin(PairMargin&&) noexcept = default;
  PairMargin& operator=(const PairMargin&) = default;
  PairMargin& operator=(PairMargin&&) noexcept = default;

  [[nodiscard]] const SchedulePair& pair() const noexcept { return pair_; }
  [[nodiscard]] const Backlog& evaluation_backlog() const noexcept {
    return evaluation_backlog_;
  }
  [[nodiscard]] const Digest256& opportunity_certificate_digest()
      const noexcept {
    return opportunity_certificate_digest_;
  }
  [[nodiscard]] const BigInt& old_pair_linear_coordinate() const noexcept {
    return old_pair_linear_coordinate_;
  }
  [[nodiscard]] const BigInt& reoptimized_margin() const noexcept {
    return reoptimized_margin_;
  }
  [[nodiscard]] const BigNat& fixed_out_objective() const noexcept {
    return fixed_out_objective_;
  }
  [[nodiscard]] const BigNat& fixed_in_objective() const noexcept {
    return fixed_in_objective_;
  }
  [[nodiscard]] const BigNat& regret0() const noexcept { return regret0_; }
  [[nodiscard]] const BigNat& regret1() const noexcept { return regret1_; }
  [[nodiscard]] bool forced_out_valid() const noexcept {
    return forced_out_valid_;
  }
  [[nodiscard]] bool forced_in_valid() const noexcept {
    return forced_in_valid_;
  }
  [[nodiscard]] bool pair_valid() const noexcept { return pair_valid_; }
  [[nodiscard]] bool target_eligible() const noexcept {
    return target_eligible_;
  }
  [[nodiscard]] const RepresentativeSelectionEvidence&
  representative_selection() const noexcept {
    return representative_selection_;
  }

  friend bool operator==(const PairMargin&, const PairMargin&) = default;

 private:
  PairMargin(SchedulePair pair, Backlog evaluation_backlog,
             Digest256 opportunity_certificate_digest,
             BigInt old_pair_linear_coordinate, BigInt reoptimized_margin,
             BigNat fixed_out_objective, BigNat fixed_in_objective,
             BigNat regret0, BigNat regret1, bool forced_out_valid,
             bool forced_in_valid, bool pair_valid, bool target_eligible,
             RepresentativeSelectionEvidence representative_selection)
      : pair_(std::move(pair)),
        evaluation_backlog_(std::move(evaluation_backlog)),
        opportunity_certificate_digest_(
            std::move(opportunity_certificate_digest)),
        old_pair_linear_coordinate_(
            std::move(old_pair_linear_coordinate)),
        reoptimized_margin_(std::move(reoptimized_margin)),
        fixed_out_objective_(std::move(fixed_out_objective)),
        fixed_in_objective_(std::move(fixed_in_objective)),
        regret0_(std::move(regret0)),
        regret1_(std::move(regret1)),
        forced_out_valid_(forced_out_valid),
        forced_in_valid_(forced_in_valid),
        pair_valid_(pair_valid),
        target_eligible_(target_eligible),
        representative_selection_(std::move(representative_selection)) {}

  SchedulePair pair_;
  Backlog evaluation_backlog_;
  Digest256 opportunity_certificate_digest_;
  BigInt old_pair_linear_coordinate_;
  BigInt reoptimized_margin_;
  BigNat fixed_out_objective_;
  BigNat fixed_in_objective_;
  BigNat regret0_;
  BigNat regret1_;
  bool forced_out_valid_;
  bool forced_in_valid_;
  bool pair_valid_;
  bool target_eligible_;
  RepresentativeSelectionEvidence representative_selection_;

  friend Result<PairMargin> evaluate_margin_pair(
      const Backlog&, const SchedulePair&, const Opportunity&);
};

// The exact edge coordinates used by equation (5.22). This non-owning view
// lets a reduced-edge update reuse F-C13-06 without constructing a physical
// edge or introducing a second margin recursion.
class ExactMarginEdgeInputs final {
 public:
  ExactMarginEdgeInputs(const Backlog& pre_backlog,
                        const Schedule& departure,
                        const ArrivalBatch& arrival_batch,
                        const Backlog& post_backlog) noexcept
      : pre_backlog_(pre_backlog),
        departure_(departure),
        arrival_batch_(arrival_batch),
        post_backlog_(post_backlog) {}

  [[nodiscard]] const Backlog& pre_backlog() const noexcept {
    return pre_backlog_;
  }
  [[nodiscard]] const Schedule& departure() const noexcept {
    return departure_;
  }
  [[nodiscard]] const ArrivalBatch& arrival_batch() const noexcept {
    return arrival_batch_;
  }
  [[nodiscard]] const Backlog& post_backlog() const noexcept {
    return post_backlog_;
  }

 private:
  const Backlog& pre_backlog_;
  const Schedule& departure_;
  const ArrivalBatch& arrival_batch_;
  const Backlog& post_backlog_;
};

class MarginTransition final {
 public:
  MarginTransition() = delete;
  MarginTransition(const MarginTransition&) = default;
  MarginTransition(MarginTransition&&) noexcept = default;
  MarginTransition& operator=(const MarginTransition&) = default;
  MarginTransition& operator=(MarginTransition&&) noexcept = default;

  [[nodiscard]] const PairMargin& previous() const noexcept {
    return previous_;
  }
  [[nodiscard]] const PairMargin& next() const noexcept { return next_; }
  [[nodiscard]] const Opportunity& successor_opportunity() const noexcept {
    return successor_opportunity_;
  }
  [[nodiscard]] const BigInt& old_pair_increment() const noexcept {
    return old_pair_increment_;
  }
  [[nodiscard]] const BigInt& old_linear_next() const noexcept {
    return old_linear_next_;
  }
  [[nodiscard]] const BigInt& reoptimized_next() const noexcept {
    return reoptimized_next_;
  }
  [[nodiscard]] const BigNat& a0() const noexcept { return a0_; }
  [[nodiscard]] const BigNat& a1() const noexcept { return a1_; }
  [[nodiscard]] const BigInt& signed_exit_correction() const noexcept {
    return signed_exit_correction_;
  }
  [[nodiscard]] bool next_pair_valid() const noexcept {
    return next_pair_valid_;
  }
  [[nodiscard]] bool reoptimization_performed() const noexcept {
    return reoptimization_performed_;
  }
  [[nodiscard]] bool used_linear_endpoint() const noexcept {
    return used_linear_endpoint_;
  }
  [[nodiscard]] bool representative_mismatch() const noexcept {
    return representative_mismatch_;
  }
  // Edge event: the current point was inside the eligible pair residence and
  // the successor either lost pair validity or target eligibility.
  [[nodiscard]] bool pair_cell_exit() const noexcept {
    return pair_cell_exit_;
  }
  // Edge event, not a successor level: false for a pre-existing 0 -> 0 target.
  [[nodiscard]] bool target_became_ineligible() const noexcept {
    return target_became_ineligible_;
  }

 private:
  MarginTransition(PairMargin previous, PairMargin next,
                   Opportunity successor_opportunity,
                   BigInt old_pair_increment, BigInt old_linear_next,
                   BigInt reoptimized_next, BigNat a0, BigNat a1,
                   BigInt signed_exit_correction, bool next_pair_valid,
                   bool reoptimization_performed, bool used_linear_endpoint,
                   bool representative_mismatch, bool pair_cell_exit,
                   bool target_became_ineligible)
      : previous_(std::move(previous)),
        next_(std::move(next)),
        successor_opportunity_(std::move(successor_opportunity)),
        old_pair_increment_(std::move(old_pair_increment)),
        old_linear_next_(std::move(old_linear_next)),
        reoptimized_next_(std::move(reoptimized_next)),
        a0_(std::move(a0)),
        a1_(std::move(a1)),
        signed_exit_correction_(std::move(signed_exit_correction)),
        next_pair_valid_(next_pair_valid),
        reoptimization_performed_(reoptimization_performed),
        used_linear_endpoint_(used_linear_endpoint),
        representative_mismatch_(representative_mismatch),
        pair_cell_exit_(pair_cell_exit),
        target_became_ineligible_(target_became_ineligible) {}

  PairMargin previous_;
  PairMargin next_;
  Opportunity successor_opportunity_;
  BigInt old_pair_increment_;
  BigInt old_linear_next_;
  BigInt reoptimized_next_;
  BigNat a0_;
  BigNat a1_;
  BigInt signed_exit_correction_;
  bool next_pair_valid_;
  bool reoptimization_performed_;
  bool used_linear_endpoint_;
  bool representative_mismatch_;
  bool pair_cell_exit_;
  bool target_became_ineligible_;

  friend Result<MarginTransition> update_or_reoptimize_margin(
      const PairMargin&, const PhysicalEdge&, const ResolvedInstance&,
      OptimizerExecutionContext&);
  friend Result<MarginTransition> update_margin_from_exact_edge(
      const PairMargin&, const ExactMarginEdgeInputs&,
      const ResolvedInstance&, OptimizerExecutionContext&);
};

// F-C13-05
[[nodiscard]] Result<PairMargin> evaluate_margin_pair(
    const Backlog& backlog, const SchedulePair& pair,
    const Opportunity& opportunity);

// F-C13-06
[[nodiscard]] Result<MarginTransition> update_or_reoptimize_margin(
    const PairMargin& margin, const PhysicalEdge& edge,
    const ResolvedInstance& instance,
    OptimizerExecutionContext& optimizer_context);

// F-C13-06 reduced-edge seam: identical equation and validation, with only
// the four physical-edge coordinates used by the exact recursion.
[[nodiscard]] Result<MarginTransition> update_margin_from_exact_edge(
    const PairMargin& margin, const ExactMarginEdgeInputs& edge,
    const ResolvedInstance& instance,
    OptimizerExecutionContext& optimizer_context);

}  // namespace mwperf
