#pragma once

#include <memory>
#include <optional>
#include <utility>

#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/reduction/local_margin.hpp"
#include "mwperf/reduction/opportunity.hpp"
#include "mwperf/reduction/rational_support.hpp"
#include "mwperf/reduction/resource_coordinates.hpp"

namespace mwperf {

class ConstructionExactQueryServices;

namespace detail {
class ConstructionExactQueryBindingAccess;
}

#if defined(MWPERF_C13_TEST_SEAMS)
namespace testing {
class C13ConstructionServiceAccess;
}
#endif

// Process-local scope capability. It has no wire encoding and its anchor is
// meaningful only inside the BuildExecutionContext that minted it.
class ConstructionScopeToken final {
 public:
  ConstructionScopeToken() = delete;
  ConstructionScopeToken(const ConstructionScopeToken&) = default;
  ConstructionScopeToken(ConstructionScopeToken&&) noexcept = default;
  ConstructionScopeToken& operator=(const ConstructionScopeToken&) = default;
  ConstructionScopeToken& operator=(ConstructionScopeToken&&) noexcept =
      default;

  [[nodiscard]] const BuildIdentityDigest& build_identity() const noexcept {
    return build_identity_;
  }

 private:
  ConstructionScopeToken(BuildIdentityDigest build_identity,
                         QueueDimensionToken dimension,
                         TimingConvention timing,
                         Digest256 priority_identity,
                         std::shared_ptr<const void> anchor)
      : build_identity_(std::move(build_identity)),
        dimension_(std::move(dimension)),
        timing_(timing),
        priority_identity_(std::move(priority_identity)),
        anchor_(std::move(anchor)) {}

  BuildIdentityDigest build_identity_;
  QueueDimensionToken dimension_;
  TimingConvention timing_;
  Digest256 priority_identity_;
  std::shared_ptr<const void> anchor_;

  friend class ConstructionExactQueryServices;
  friend class detail::ConstructionExactQueryBindingAccess;
#if defined(MWPERF_C13_TEST_SEAMS)
  friend class testing::C13ConstructionServiceAccess;
#endif
};

// Read-only construction facade over the three catalogued C13 exact-query
// functions. It borrows one caller-owned C05 context and enforces a private
// construction window within that single ledger. It owns no cache or backend.
class ConstructionExactQueryServices final {
 public:
  ConstructionExactQueryServices() = delete;
  ConstructionExactQueryServices(const ConstructionExactQueryServices&) =
      delete;
  ConstructionExactQueryServices& operator=(
      const ConstructionExactQueryServices&) = delete;
  ConstructionExactQueryServices(ConstructionExactQueryServices&&) noexcept;
  ConstructionExactQueryServices& operator=(
      ConstructionExactQueryServices&&) noexcept;

  [[nodiscard]] const ConstructionScopeToken& scope_token() const noexcept {
    return scope_token_;
  }
  [[nodiscard]] OptimizerCallLedgerSnapshot ledger_snapshot() const;

  [[nodiscard]] Result<Opportunity> query_opportunity(
      const ConstructionScopeToken& scope, const Backlog& backlog,
      TargetIndex target);
  [[nodiscard]] Result<BigNat> query_integral_capacity(
      const ConstructionScopeToken& scope,
      const NonnegativeIntegralDirection& direction);
  [[nodiscard]] Result<RationalSupportCertificate> query_rational_support(
      const ConstructionScopeToken& scope,
      const ExactNonnegativeRationalWeights& weights);

 private:
  ConstructionExactQueryServices(
      ResolvedInstance instance, ConstructionScopeToken scope_token,
      OptimizerExecutionContext& optimizer_context,
      BigNat baseline_calls_reserved,
      std::optional<BigNat> construction_max_calls)
      : instance_(std::move(instance)),
        scope_token_(std::move(scope_token)),
        optimizer_context_(&optimizer_context),
        baseline_calls_reserved_(std::move(baseline_calls_reserved)),
        construction_max_calls_(std::move(construction_max_calls)) {}

  [[nodiscard]] static Result<ConstructionExactQueryServices> bind(
      const ResolvedInstance& instance, BuildIdentityDigest build_identity,
      OptimizerExecutionContext& optimizer_context,
      std::optional<BigNat> construction_max_calls);
  [[nodiscard]] Result<void> validate_query(
      const ConstructionScopeToken& scope, const QueueDimensionToken& input,
      const BigNat& required_calls) const;

  ResolvedInstance instance_;
  ConstructionScopeToken scope_token_;
  OptimizerExecutionContext* optimizer_context_;
  BigNat baseline_calls_reserved_;
  std::optional<BigNat> construction_max_calls_;

  friend class detail::ConstructionExactQueryBindingAccess;
#if defined(MWPERF_C13_TEST_SEAMS)
  friend class testing::C13ConstructionServiceAccess;
#endif
};

namespace detail {

// Fixed process-local binding route for C16's future BuildExecutionContext.
// C13 validates the already-supplied opaque build identity and ledger window;
// construction of the canonical C15 identity remains a later checkpoint.
class ConstructionExactQueryBindingAccess final {
 public:
  ConstructionExactQueryBindingAccess() = delete;

  [[nodiscard]] static Result<ConstructionExactQueryServices> bind(
      const ResolvedInstance& instance, BuildIdentityDigest build_identity,
      OptimizerExecutionContext& optimizer_context,
      std::optional<BigNat> construction_max_calls);

  // C16's execution-context factory uses only this read-only audit surface.
  // It cannot mint a service, alter the borrowed ledger, reset its baseline,
  // or replace the resolved-instance binding.
  [[nodiscard]] static bool is_live(
      const ConstructionExactQueryServices& services) noexcept;
  [[nodiscard]] static const ResolvedInstance* bound_instance(
      const ConstructionExactQueryServices& services) noexcept;
  [[nodiscard]] static const std::optional<BigNat>& construction_subgrant(
      const ConstructionExactQueryServices& services) noexcept;
  [[nodiscard]] static Result<BigNat> calls_consumed(
      const ConstructionExactQueryServices& services);
};

}  // namespace detail

#if defined(MWPERF_C13_TEST_SEAMS)
namespace testing {

enum class ConstructionTokenMutation {
  scope,
  instance,
  tie,
};

class C13ConstructionServiceAccess final {
 public:
  C13ConstructionServiceAccess() = delete;

  [[nodiscard]] static Result<ConstructionExactQueryServices> bind(
      const ResolvedInstance& instance, BuildIdentityDigest build_identity,
      OptimizerExecutionContext& optimizer_context,
      std::optional<BigNat> construction_max_calls);
  [[nodiscard]] static ConstructionScopeToken mutated_token(
      const ConstructionExactQueryServices& services,
      ConstructionTokenMutation mutation,
      const ResolvedInstance* foreign_instance = nullptr);
};

}  // namespace testing
#endif

}  // namespace mwperf
