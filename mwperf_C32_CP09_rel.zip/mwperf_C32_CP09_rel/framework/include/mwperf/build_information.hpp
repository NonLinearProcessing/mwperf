#pragma once

#include <string>

namespace mwperf {

struct BuildInformation {
  std::string program_version;
  std::string source_tree_version;
  std::string compiler_id;
  std::string compiler_version;
  std::string enabled_features;
  std::string physical_schema_version;
  std::string analysis_schema_version;
  std::string rng_algorithm_version;
  std::string function_interface_manifest_version;

  friend bool operator==(const BuildInformation&, const BuildInformation&) =
      default;
};

[[nodiscard]] BuildInformation build_information();

}  // namespace mwperf
