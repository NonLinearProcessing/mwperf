#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/random/rng_stage.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class NormalizedPmf;
class TypedLabel;

class MasterSeed final {
 public:
  explicit constexpr MasterSeed(std::uint64_t value) noexcept : value_(value) {}

  [[nodiscard]] constexpr std::uint64_t value() const noexcept { return value_; }

  friend constexpr bool operator==(MasterSeed, MasterSeed) = default;

 private:
  std::uint64_t value_;
};

// C15 supplies this opaque digest after canonicalizing BuildIdentityV1. C02
// deliberately knows neither that record nor any of its fields.
class BuildIdentityDigest final {
 public:
  explicit BuildIdentityDigest(Digest256 digest) : digest_(std::move(digest)) {}

  [[nodiscard]] const Digest256& digest() const noexcept { return digest_; }

  friend bool operator==(const BuildIdentityDigest&,
                         const BuildIdentityDigest&) = default;

 private:
  Digest256 digest_;
};

// An immutable seed-tree root. It contains no engine state and no request
// digest, callback, counter, or deployed stream cursor.
class BuildSeed final {
 public:
  BuildSeed(MasterSeed master_seed, BuildIdentityDigest build_identity_digest)
      : master_seed_(master_seed),
        build_identity_digest_(std::move(build_identity_digest)) {}

  [[nodiscard]] constexpr std::uint32_t rng_version() const noexcept {
    return kRngVersion;
  }
  [[nodiscard]] MasterSeed master_seed() const noexcept { return master_seed_; }
  [[nodiscard]] const BuildIdentityDigest& build_identity_digest() const noexcept {
    return build_identity_digest_;
  }
  [[nodiscard]] bool is_bound_to(const BuildIdentityDigest& digest) const noexcept {
    return build_identity_digest_ == digest;
  }
  [[nodiscard]] std::array<std::byte, 44> canonical_bytes() const noexcept;

  friend bool operator==(const BuildSeed&, const BuildSeed&) = default;

 private:
  MasterSeed master_seed_;
  BuildIdentityDigest build_identity_digest_;
};

class InstanceKeyFactory;

// InstanceKey construction is intentionally closed. A caller can inspect an
// already-derived key, but can obtain one only through a fixed route factory.
// Version 1 hashes:
//   ASCII("mwperf.rng.instance") || 0x00 || u32be(1) || components
// Each component is type:u8 || length:u64be || payload. The closed component
// tags are 01 raw digest (32 bytes), 02 validated UTF-8, 03 BigNat magnitude,
// 04 complete tagged TypedLabel bytes, and 05 exact-state digest (32 bytes).
class InstanceKey final {
 public:
  InstanceKey(const InstanceKey&) = default;
  InstanceKey(InstanceKey&&) noexcept = default;
  InstanceKey& operator=(const InstanceKey&) = default;
  InstanceKey& operator=(InstanceKey&&) noexcept = default;

  [[nodiscard]] const Digest256& digest() const noexcept { return digest_; }

  friend bool operator==(const InstanceKey&, const InstanceKey&) = default;

 private:
  friend class InstanceKeyFactory;
  explicit InstanceKey(Digest256 digest) : digest_(std::move(digest)) {}

  Digest256 digest_;
};

// Fixed version-1 route tuples, in declaration order below, are:
//   (combined input digest, "physical_reference", path/replication BigNat)
//   (audited framework digest, reduced-law digest, "temporal_path", path BigNat)
//   (seal digest, exact conditioning-state digest, estimator UTF-8, replication)
//   (seal digest, exact state/cursor digest, branch-address UTF-8)
//   (build-identity digest, provider ID, provider version, target TypedLabel,
//    build replication/probe BigNat)
// All text components are validated UTF-8; empty text is permitted because
// component framing remains unambiguous. No route accepts a horizon or final
// build-request digest.
[[nodiscard]] Result<InstanceKey> make_physical_reference_instance_key(
    const Digest256& combined_input_digest,
    const BigNat& path_or_replication_id);

[[nodiscard]] Result<InstanceKey> make_temporal_path_instance_key(
    const Digest256& audited_framework_digest,
    const Digest256& reduced_initial_law_digest,
    const BigNat& path_or_replication_id);

[[nodiscard]] Result<InstanceKey> make_estimator_instance_key(
    const Digest256& seal_digest,
    const Digest256& conditioning_state_digest,
    std::string_view estimator_id,
    const BigNat& replication_index);

[[nodiscard]] Result<InstanceKey> make_internal_draw_instance_key(
    const Digest256& seal_digest,
    const Digest256& exact_state_or_cursor_digest,
    std::string_view branch_address);

[[nodiscard]] Result<InstanceKey> make_surrogate_build_instance_key(
    const BuildIdentityDigest& build_identity_digest,
    std::string_view provider_id,
    std::string_view provider_version,
    const TypedLabel& target_or_group_identity,
    const BigNat& build_replication_or_probe_id);

class RngCheckpoint final {
 public:
  RngCheckpoint(const RngCheckpoint&) = default;
  RngCheckpoint& operator=(const RngCheckpoint&) = default;
  // Move-as-copy keeps both checkpoints internally consistent. In particular,
  // the source cannot retain state-at-N with a moved-from zero counter.
  RngCheckpoint(RngCheckpoint&& other);
  RngCheckpoint& operator=(RngCheckpoint&& other);

  [[nodiscard]] std::uint32_t rng_version() const noexcept { return rng_version_; }
  [[nodiscard]] const Digest256& stream_identity() const noexcept {
    return stream_identity_;
  }
  [[nodiscard]] const std::array<std::uint64_t, 4>& state_words() const noexcept {
    return state_words_;
  }
  [[nodiscard]] const BigNat& consumed_words() const noexcept {
    return consumed_words_;
  }

 private:
  friend class DeterministicRng;
  friend class DeterministicRngTestAccess;
  RngCheckpoint(std::uint32_t rng_version, Digest256 stream_identity,
                std::array<std::uint64_t, 4> state_words,
                BigNat consumed_words)
      : rng_version_(rng_version),
        stream_identity_(std::move(stream_identity)),
        state_words_(state_words),
        consumed_words_(std::move(consumed_words)) {}

  std::uint32_t rng_version_;
  Digest256 stream_identity_;
  std::array<std::uint64_t, 4> state_words_;
  BigNat consumed_words_;
};

class RngTransaction;
class DeterministicRngTestAccess;

// Version 1 is xoshiro256** over four uint64 words. next_u64() implements the
// published transition exactly; the counter is an unbounded exact BigNat.
class DeterministicRng final {
 public:
  DeterministicRng(const DeterministicRng&) = delete;
  DeterministicRng& operator=(const DeterministicRng&) = delete;
  DeterministicRng(DeterministicRng&& other);
  DeterministicRng& operator=(DeterministicRng&& other);
  ~DeterministicRng() = default;

  [[nodiscard]] std::uint64_t next_u64();
  [[nodiscard]] const Digest256& stream_identity() const noexcept {
    return stream_identity_;
  }
  [[nodiscard]] const BigNat& consumed_words() const noexcept {
    return consumed_words_;
  }
  // The immutable derivation-stage label is retained alongside the one-way
  // stream identity so later typed boundaries can reject a stream from the
  // wrong deterministic-randomness stage without re-deriving it.
  [[nodiscard]] StageTag derivation_stage() const noexcept {
    return derivation_stage_;
  }
  [[nodiscard]] RngCheckpoint checkpoint() const;
  [[nodiscard]] Result<void> restore(const RngCheckpoint& checkpoint);

 private:
  friend class RngTransaction;
  friend class DeterministicRngTestAccess;
  friend DeterministicRng derive_rng_stream(MasterSeed, StageTag,
                                             const InstanceKey&);

  DeterministicRng(std::array<std::uint64_t, 4> state,
                   Digest256 stream_identity, StageTag derivation_stage);
  void restore_unchecked(RngCheckpoint& checkpoint) noexcept;
  void require_active() const;
  static void require_unpinned(const DeterministicRng& rng);
  void begin_transaction();
  void end_transaction() noexcept;

  std::array<std::uint64_t, 4> state_;
  Digest256 stream_identity_;
  BigNat consumed_words_;
  StageTag derivation_stage_;
  bool active_;
  bool transaction_open_;
};

class RngTransaction final {
 public:
  // The transaction pins rng at its current address and stream identity.
  // Draws/checkpoints/restores remain legal, but moving that RNG or opening a
  // nested transaction throws before mutation. Scope exit restores the exact
  // state and word counter unless commit() was called.
  explicit RngTransaction(DeterministicRng& rng);
  RngTransaction(const RngTransaction&) = delete;
  RngTransaction& operator=(const RngTransaction&) = delete;
  RngTransaction(RngTransaction&&) = delete;
  RngTransaction& operator=(RngTransaction&&) = delete;
  ~RngTransaction() noexcept;

  void commit() noexcept { committed_ = true; }

 private:
  DeterministicRng* rng_;
  RngCheckpoint checkpoint_;
  bool committed_;
};

// F-C02-06. Stream derivation hashes exactly:
//   ASCII("mwperf.rng.xoshiro256ss") || 0x00 || u32be(1) ||
//   u64be(master seed) || u16be(stage tag) || 32-byte instance key.
// Its digest is decoded as four successive big-endian words. Stream derivation
// has no ambient state or call-order input.
[[nodiscard]] DeterministicRng derive_rng_stream(
    MasterSeed master_seed, StageTag stage, const InstanceKey& instance_key);

// F-C02-07. Selection uses only the exact primitive integral PMF image. The
// first engine word is the least-significant limb, unused high bits of the last
// limb are masked, and every rejected candidate discards its complete block.
[[nodiscard]] std::size_t sample_categorical(const NormalizedPmf& pmf,
                                             DeterministicRng& rng);

namespace testing {

// Narrow deterministic seams for protocol vectors. They cannot manufacture a
// live production stream or clone one.
[[nodiscard]] std::vector<std::byte>
physical_reference_instance_key_preimage(
    const Digest256& combined_input_digest,
    const BigNat& path_or_replication_id);

[[nodiscard]] std::vector<std::byte> temporal_path_instance_key_preimage(
    const Digest256& audited_framework_digest,
    const Digest256& reduced_initial_law_digest,
    const BigNat& path_or_replication_id);

[[nodiscard]] Result<std::vector<std::byte>> estimator_instance_key_preimage(
    const Digest256& seal_digest,
    const Digest256& conditioning_state_digest,
    std::string_view estimator_id,
    const BigNat& replication_index);

[[nodiscard]] Result<std::vector<std::byte>> internal_draw_instance_key_preimage(
    const Digest256& seal_digest,
    const Digest256& exact_state_or_cursor_digest,
    std::string_view branch_address);

[[nodiscard]] Result<std::vector<std::byte>>
surrogate_build_instance_key_preimage(
    const BuildIdentityDigest& build_identity_digest,
    std::string_view provider_id,
    std::string_view provider_version,
    const TypedLabel& target_or_group_identity,
    const BigNat& build_replication_or_probe_id);

[[nodiscard]] std::vector<std::byte> rng_derivation_preimage(
    MasterSeed master_seed, StageTag stage, const InstanceKey& instance_key);

[[nodiscard]] std::array<std::uint64_t, 4> decode_rng_state(
    const Digest256& digest) noexcept;

// Produces only a version-altered checkpoint for the required negative
// compatibility test; it cannot alter state, identity, or consumption.
[[nodiscard]] RngCheckpoint checkpoint_with_version(
    const RngCheckpoint& checkpoint, std::uint32_t rng_version);

struct ScriptedCategoricalResult {
  std::size_t index;
  std::size_t consumed_words;

  friend bool operator==(const ScriptedCategoricalResult&,
                         const ScriptedCategoricalResult&) = default;
};

[[nodiscard]] Result<ScriptedCategoricalResult>
sample_categorical_with_script(const NormalizedPmf& pmf,
                               std::span<const std::uint64_t> words);

}  // namespace testing

}  // namespace mwperf
