#pragma once

#include <cstdint>

namespace mwperf {

// Version-1 stage tags are part of the reproducibility protocol. Existing
// values are never renumbered; later protocol versions may only append tags.
enum class StageTag : std::uint16_t {
  initial_joint_atom = 0x0001,
  prearrival_closure = 0x0002,
  tie_resolution = 0x0003,
  configured_arrival = 0x0004,
  postarrival_closure = 0x0005,
  controller_post = 0x0006,
  generic_sampling = 0x0007,
  importance_proposal = 0x0008,
  training = 0x0009,
  solver_sampling = 0x000a,
  surrogate_build_input = 0x000b,
  surrogate_build_context = 0x000c,
  surrogate_build_probe = 0x000d,
  surrogate_build_final = 0x000e,
};

inline constexpr std::uint32_t kRngVersion = 1U;

[[nodiscard]] constexpr std::uint16_t stage_tag_value(
    StageTag stage) noexcept {
  return static_cast<std::uint16_t>(stage);
}

static_assert(stage_tag_value(StageTag::initial_joint_atom) == 0x0001U);
static_assert(stage_tag_value(StageTag::solver_sampling) == 0x000aU);
static_assert(stage_tag_value(StageTag::surrogate_build_final) == 0x000eU);

}  // namespace mwperf
