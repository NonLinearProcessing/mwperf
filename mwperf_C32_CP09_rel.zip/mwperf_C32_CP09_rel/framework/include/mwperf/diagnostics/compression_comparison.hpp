#pragma once

#include <cstdint>
#include <optional>
#include <vector>

#include "mwperf/diagnostics/compression_analysis.hpp"

namespace mwperf {

// Optional fourth profile: the exact coefficients consumed by the deployed
// decoder after authorized completion, recoding, projection, or rounding.
// It is bound both to the WE observation and to the provider result that used
// it; it is never inferred from a response summary.
struct DecoderTransformedFitPointV1 final {
  BigNat cutoff;
  std::optional<FinitePrefixFitResultV1> fit;
  std::optional<Diagnostic> fit_failure;
  std::optional<DeleteOneReplicationJackknifeV1> fitted_mean_jackknife;
  // Optional decoder-local resample telemetry.  It is not folded into the
  // comparison's construction fit-failure rate (which covers the three
  // observation-derived profiles); a future schema may expose it separately.
  std::optional<FitResampleCountsV1> fit_resamples;
  // Paired delete-one result for D(C_dec)-D(C_hat_obs).  This, rather than a
  // sum of marginal variances, preserves their shared WE replication noise.
  std::optional<DeleteOneReplicationJackknifeV1> transformation_jackknife;

  friend bool operator==(const DecoderTransformedFitPointV1&,
                         const DecoderTransformedFitPointV1&) = default;
};

struct DecoderTransformedProfileV1 final {
  Digest256 experiment_digest;
  Digest256 source_observation_digest;
  Digest256 provider_result_digest;
  Digest256 decoder_semantics_digest;
  std::vector<DecoderTransformedFitPointV1> cutoffs;

  friend bool operator==(const DecoderTransformedProfileV1&,
                         const DecoderTransformedProfileV1&) = default;
};

struct CompressionComparisonOptionsV1 final {
  Digest256 decoder_semantics_digest;
  // When true, C_dec is definitionally C_hat_obs and the fourth term is
  // emitted as exact zero.  A transformed profile must then be absent.
  bool decoder_consumed_empirical_profile_unchanged{false};
  std::optional<DecoderTransformedProfileV1> transformed_profile;

  friend bool operator==(const CompressionComparisonOptionsV1&,
                         const CompressionComparisonOptionsV1&) = default;
};

struct ErrorSeparationUncertaintyV1 final {
  CompressionQuantityV1 compression_squared_standard_error;
  CompressionQuantityV1 finite_window_squared_standard_error;
  CompressionQuantityV1 sampling_squared_standard_error;
  CompressionQuantityV1 transformation_squared_standard_error;
  CompressionMetricStatusV1 status;

  friend bool operator==(const ErrorSeparationUncertaintyV1&,
                         const ErrorSeparationUncertaintyV1&) = default;
};

struct ErrorSeparationCutoffV1 final {
  BigNat cutoff;
  CompressionQuantityV1 compression;
  CompressionQuantityV1 finite_window_construction;
  CompressionQuantityV1 weighted_ensemble_sampling;
  CompressionQuantityV1 provider_transformation;
  CompressionQuantityV1 three_term_sum;
  CompressionQuantityV1 three_term_target;
  CompressionQuantityV1 three_term_closure;
  CompressionQuantityV1 four_term_sum;
  CompressionQuantityV1 four_term_target;
  CompressionQuantityV1 four_term_closure;
  CompressionQuantityV1 stationary_tail_crosscheck;
  // Counts and rate cover the three construction profiles.  Decoder
  // transformation fit/uncertainty availability is reported independently,
  // so absence of decoder delete-one fits cannot erase valid construction
  // failure telemetry.
  FitResampleCountsV1 fit_resamples;
  CompressionQuantityV1 fit_failure_rate;
  ErrorSeparationUncertaintyV1 uncertainty;
  bool transformation_is_definitionally_zero;
  CompressionMetricStatusV1 status;

  friend bool operator==(const ErrorSeparationCutoffV1&,
                         const ErrorSeparationCutoffV1&) = default;
};

struct ThreeRecordErrorSeparationV1 final {
  Digest256 experiment_digest;
  Digest256 decoder_semantics_digest;
  Digest256 stationary_observation_digest;
  Digest256 finite_window_observation_digest;
  Digest256 weighted_ensemble_observation_digest;
  Digest256 stationary_analysis_digest;
  Digest256 finite_window_analysis_digest;
  Digest256 weighted_ensemble_analysis_digest;
  std::optional<Digest256> provider_result_digest;
  std::vector<ErrorSeparationCutoffV1> cutoffs;
  CompressionMetricStatusV1 status;

  friend bool operator==(const ThreeRecordErrorSeparationV1&,
                         const ThreeRecordErrorSeparationV1&) = default;
};

// The long reference is an estimate, not exact truth.  All three records must
// share the actual initialization descriptor and scientific experiment
// context.  Only the short reference must match the WE measurement interval
// [W,T); the long reference may use a different explicit warmup/window.  All
// three analyses use the same decoder semantics supplied by the caller.
[[nodiscard]] Result<ThreeRecordErrorSeparationV1>
compare_compression_profiles_v1(
    const CompressionAnalysisResultV1& stationary_reference,
    const CompressionAnalysisResultV1& finite_window_reference,
    const CompressionAnalysisResultV1& weighted_ensemble,
    const CompressionComparisonOptionsV1& options);

}  // namespace mwperf
