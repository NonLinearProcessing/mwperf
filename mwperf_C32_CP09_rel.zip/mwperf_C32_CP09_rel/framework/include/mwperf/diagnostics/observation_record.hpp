#pragma once

#include <compare>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// Observation records are descriptive construction telemetry.  They are not
// response artifacts, executable plugs, or evidence that grants a deployed
// metric capability.
enum class ObservationSourceRoleV1 : std::uint8_t {
  weighted_ensemble,
  short_restart_reference,
  long_stationary_reference,
};

enum class ObservationScalarRepresentationV1 : std::uint8_t {
  exact_rational,
  enclosed_binary64,
};

enum class ObservationCompletenessV1 : std::uint8_t {
  complete,
  partial,
};

enum class ObservationNormalizationClaimV1 : std::uint8_t {
  exact,
  enclosed,
  not_claimed,
};

enum class ObservationSlotStageV1 : std::uint8_t {
  solve_primary_maxweight,
  observe_pre_service,
  apply_actual_service,
  classify_and_resample,
  allocate_child_lineage,
  apply_fresh_late_arrival,
  commit_post_slot_state,
  emit_committed_observation,
};

// For a binary64 accumulator, absolute_error is a conservative absolute
// enclosure radius around value and l1_norm is the deterministic sum of the
// absolute addends used by that accumulator.  Exact rational scalars never
// carry this member.
struct ObservationNumericalEnclosureV1 final {
  PortableScientificScalar absolute_error;
  PortableScientificScalar l1_norm;

  friend bool operator==(const ObservationNumericalEnclosureV1&,
                         const ObservationNumericalEnclosureV1&) = default;
};

struct ObservationScalarV1 final {
  PortableScientificScalar value;
  std::optional<ObservationNumericalEnclosureV1> enclosure;

  friend bool operator==(const ObservationScalarV1&,
                         const ObservationScalarV1&) = default;
};

// recorded_mass is recomputed from the corresponding sparse rows.
// signed_mass_defect is recorded_mass minus the expected mass: block length
// for an exposure table and one for a boundary law.  It is never silently
// renormalized away.
struct ObservationMassBalanceV1 final {
  ObservationNormalizationClaimV1 claim;
  ObservationScalarV1 recorded_mass;
  ObservationScalarV1 signed_mass_defect;

  friend bool operator==(const ObservationMassBalanceV1&,
                         const ObservationMassBalanceV1&) = default;
};

struct ObservationGapCellV1 final {
  ObservationScalarV1 negative_mass;
  ObservationScalarV1 tie_mass;
  ObservationScalarV1 positive_mass;
  ObservationScalarV1 tied_and_served_mass;
  ObservationScalarV1 positive_magnitude_mass;
  ObservationScalarV1 negative_magnitude_mass;

  friend bool operator==(const ObservationGapCellV1&,
                         const ObservationGapCellV1&) = default;
};

struct ExactLevelObservationV1 final {
  BigNat backlog_level;
  ObservationScalarV1 exposure_mass;
  ObservationScalarV1 served_mass;
  std::optional<ObservationGapCellV1> gap;

  friend bool operator==(const ExactLevelObservationV1&,
                         const ExactLevelObservationV1&) = default;
};

struct BoundaryBacklogMassV1 final {
  BigNat backlog_level;
  ObservationScalarV1 mass;

  friend bool operator==(const BoundaryBacklogMassV1&,
                         const BoundaryBacklogMassV1&) = default;
};

// Boundary b is the committed state after slot b-1 and therefore the
// pre-service state for slot b.
struct BoundaryBacklogLawV1 final {
  std::uint64_t boundary;
  std::vector<BoundaryBacklogMassV1> rows;
  ObservationMassBalanceV1 mass_balance;

  friend bool operator==(const BoundaryBacklogLawV1&,
                         const BoundaryBacklogLawV1&) = default;
};

// A block's requested interval is [begin_boundary, end_boundary).  A complete
// block commits through end_boundary.  Only a final partial block may stop
// earlier, at committed_through_boundary; its terminal law is at that actual
// committed boundary and its exposure length is the committed prefix.
struct ConstructionObservationBlockV1 final {
  std::uint64_t begin_boundary;
  std::uint64_t end_boundary;
  ObservationCompletenessV1 completeness;
  std::uint64_t committed_through_boundary;
  std::vector<ExactLevelObservationV1> levels;
  ObservationMassBalanceV1 exposure_mass_balance;
  BoundaryBacklogLawV1 initial_boundary_law;
  BoundaryBacklogLawV1 committed_boundary_law;

  friend bool operator==(const ConstructionObservationBlockV1&,
                         const ConstructionObservationBlockV1&) = default;
};

struct ConstructionObservationReplicationV1 final {
  TypedLabel replication_id;
  Digest256 replay_identity;
  std::optional<Digest256> lineage_arrival_identity;
  ObservationCompletenessV1 completeness;
  std::uint64_t committed_through_boundary;
  std::vector<ConstructionObservationBlockV1> blocks;

  friend bool operator==(const ConstructionObservationReplicationV1&,
                         const ConstructionObservationReplicationV1&) =
      default;
};

struct ExactTargetArrivalAtomV1 final {
  BigNat batch_size;
  ExactRational probability;

  friend bool operator==(const ExactTargetArrivalAtomV1&,
                         const ExactTargetArrivalAtomV1&) = default;
};

struct ExactTargetArrivalMarginalV1 final {
  std::vector<ExactTargetArrivalAtomV1> atoms;

  friend bool operator==(const ExactTargetArrivalMarginalV1&,
                         const ExactTargetArrivalMarginalV1&) = default;
};

// A registered descriptor is used when the finite marginal is intentionally
// not repeated on the wire.  Its digest must authenticate all overshoot
// transforms needed by the diagnostic consumer.
struct TargetArrivalOvershootDescriptorV1 final {
  std::string descriptor_id;
  std::uint32_t descriptor_version;
  Digest256 descriptor_digest;

  friend bool operator==(const TargetArrivalOvershootDescriptorV1&,
                         const TargetArrivalOvershootDescriptorV1&) = default;
};

using TargetArrivalDescriptionV1 =
    std::variant<ExactTargetArrivalMarginalV1,
                 TargetArrivalOvershootDescriptorV1>;

struct ObservationArrivalBindingV1 final {
  std::string arrival_family_id;
  Digest256 configured_law_digest;
  TargetArrivalDescriptionV1 target_arrival;
  ExactRational mean;
  ExactRational second_moment;

  friend bool operator==(const ObservationArrivalBindingV1&,
                         const ObservationArrivalBindingV1&) = default;
};

struct ObservationTargetBindingV1 final {
  QueueId target_id;
  std::uint64_t target_index;
  ExactRational maxweight_multiplier;

  friend bool operator==(const ObservationTargetBindingV1&,
                         const ObservationTargetBindingV1&) = default;
};

struct ObservationScientificBindingsV1 final {
  Digest256 request_digest;
  Digest256 problem_digest;
  Digest256 experiment_digest;
  ObservationTargetBindingV1 target;
  ObservationArrivalBindingV1 arrival;
  Digest256 topology_digest;
  Digest256 scheduler_digest;
  Digest256 optimizer_digest;
  Digest256 primary_objective_digest;
  Digest256 priority_digest;
  Digest256 tie_policy_digest;

  friend bool operator==(const ObservationScientificBindingsV1&,
                         const ObservationScientificBindingsV1&) = default;
};

struct ObservationSlotConventionV1 final {
  // V1 fixes rows at the pre-service parent state, service to the actual
  // binary departure, and boundaries at committed post-slot states.
  std::vector<ObservationSlotStageV1> step_order;
  Digest256 convention_digest;

  friend bool operator==(const ObservationSlotConventionV1&,
                         const ObservationSlotConventionV1&) = default;
};

struct ObservationInitializationV1 final {
  std::string initial_law_id;
  Digest256 initial_law_digest;

  friend bool operator==(const ObservationInitializationV1&,
                         const ObservationInitializationV1&) = default;
};

struct ObservationRngBindingV1 final {
  std::string rng_abi_id;
  std::uint32_t rng_abi_version;
  Digest256 construction_seed_policy_digest;

  friend bool operator==(const ObservationRngBindingV1&,
                         const ObservationRngBindingV1&) = default;
};

struct ObservationCapabilityStateV1 final {
  bool available;
  std::optional<std::string> unavailable_reason_code;

  friend bool operator==(const ObservationCapabilityStateV1&,
                         const ObservationCapabilityStateV1&) = default;
};

// These flags describe what may be derived from the record.  They do not
// affect the framework's deployed metric capability resolution.
struct ObservationCapabilitiesV1 final {
  ObservationCapabilityStateV1 iid_fresh_arrivals;
  ObservationCapabilityStateV1 finite_arrival_second_moment;
  ObservationCapabilityStateV1 exact_target_arrival_marginal;
  ObservationCapabilityStateV1 no_target_drops;
  ObservationCapabilityStateV1 exact_primary_maxweight;
  ObservationCapabilityStateV1 unit_target_multiplier;
  ObservationCapabilityStateV1 certified_gap_probe;

  friend bool operator==(const ObservationCapabilitiesV1&,
                         const ObservationCapabilitiesV1&) = default;
};

struct ConstructionObservationBundleV1 final {
  std::uint32_t schema_version;
  ObservationSourceRoleV1 source_role;
  ObservationScalarRepresentationV1 scalar_representation;
  ObservationScientificBindingsV1 bindings;
  ObservationSlotConventionV1 slot_convention;
  ObservationInitializationV1 initialization;
  ObservationRngBindingV1 rng;
  std::uint64_t warmup_boundary;
  std::uint64_t end_boundary;
  std::vector<std::uint64_t> reporting_block_boundaries;
  ObservationCapabilitiesV1 capabilities;
  std::vector<ConstructionObservationReplicationV1> replications;

  friend bool operator==(const ConstructionObservationBundleV1&,
                         const ConstructionObservationBundleV1&) = default;
};

struct ConstructionObservationEnvelopeV1 final {
  ConstructionObservationBundleV1 observation_bundle;
  Digest256 observation_bundle_digest;

  friend bool operator==(const ConstructionObservationEnvelopeV1&,
                         const ConstructionObservationEnvelopeV1&) = default;
};

using ObservationByteSpan = std::span<const std::byte>;

// Parser caps are trusted caller policy, never authored fields.  The SAX
// preflight enforces byte/container/cardinality caps before the DOM and typed
// vectors are allocated.  Decimal components are bounded before conversion
// to multiprecision integers.
struct ObservationParseLimitsV1 final {
  std::size_t maximum_bytes;
  std::size_t maximum_nesting_depth;
  std::size_t maximum_object_entries;
  std::size_t maximum_array_entries;
  std::size_t maximum_string_bytes;
  std::size_t maximum_scalar_count;
  std::size_t maximum_total_decoded_allocation_bytes;
  std::size_t maximum_replications;
  std::size_t maximum_total_blocks;
  std::size_t maximum_total_level_rows;
  std::size_t maximum_total_boundary_rows;
  std::size_t maximum_arrival_atoms;
  std::size_t maximum_reporting_boundaries;
  std::size_t maximum_integer_bits;
  std::size_t maximum_integer_decimal_digits;

  friend bool operator==(const ObservationParseLimitsV1&,
                         const ObservationParseLimitsV1&) = default;
};

[[nodiscard]] ObservationParseLimitsV1
default_observation_parse_limits_v1() noexcept;

// Registered semantic identity for the Full Orbit construction law that
// starts every lineage at backlog zero.  Consumers compare both the authored
// identifier ("empty_backlog_v1") and this digest before using that law to
// select a finite closed class; an arbitrary or altered initialization must
// never acquire an implicit selection seed.
[[nodiscard]] Result<Digest256>
registered_empty_backlog_initial_law_digest_v1();

// The body codec has no digest field.  The envelope codec is exactly
// {"observation_bundle": <body>, "observation_bundle_digest": <hex>} in
// this member order.  Both codecs use compact UTF-8 JSON with the fixed member
// order documented by the implementation; noncanonical input is rejected.
[[nodiscard]] Result<std::vector<std::byte>>
canonical_construction_observation_bundle_body_bytes_v1(
    const ConstructionObservationBundleV1& bundle);

[[nodiscard]] Result<Digest256> construction_observation_bundle_digest_v1(
    const ConstructionObservationBundleV1& bundle);

[[nodiscard]] Result<std::vector<std::byte>>
canonical_construction_observation_envelope_bytes_v1(
    const ConstructionObservationEnvelopeV1& envelope);

[[nodiscard]] Result<ConstructionObservationEnvelopeV1>
parse_construction_observation_envelope_v1(
    ObservationByteSpan bytes, const ObservationParseLimitsV1& limits);

class ValidatedConstructionObservationBundleV1 final {
 public:
  ValidatedConstructionObservationBundleV1(
      const ValidatedConstructionObservationBundleV1&) = default;
  ValidatedConstructionObservationBundleV1(
      ValidatedConstructionObservationBundleV1&&) noexcept = default;
  ValidatedConstructionObservationBundleV1& operator=(
      const ValidatedConstructionObservationBundleV1&) = default;
  ValidatedConstructionObservationBundleV1& operator=(
      ValidatedConstructionObservationBundleV1&&) noexcept = default;

  [[nodiscard]] const ConstructionObservationBundleV1& value() const noexcept {
    return value_;
  }
  [[nodiscard]] const Digest256& digest() const noexcept { return digest_; }

 private:
  ValidatedConstructionObservationBundleV1(
      ConstructionObservationBundleV1 value, Digest256 digest)
      : value_(std::move(value)), digest_(std::move(digest)) {}

  ConstructionObservationBundleV1 value_;
  Digest256 digest_;

  friend Result<ValidatedConstructionObservationBundleV1>
  validate_construction_observation_envelope_v1(
      ConstructionObservationEnvelopeV1,
      const ObservationParseLimitsV1&);
};

// Semantic validation recomputes the digest, exact sparse sums, normalization
// defects, block/boundary continuity, completeness, timing, scalar contract,
// gap partitions and service reconstruction.  It performs no normalization
// and no optimizer call.
[[nodiscard]] Result<ValidatedConstructionObservationBundleV1>
validate_construction_observation_envelope_v1(
    ConstructionObservationEnvelopeV1 envelope,
    const ObservationParseLimitsV1& limits);

}  // namespace mwperf
