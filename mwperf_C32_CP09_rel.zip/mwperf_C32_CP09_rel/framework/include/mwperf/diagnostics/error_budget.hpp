#pragma once

#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <variant>
#include <vector>

#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/certificates/transfer_bounds.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf {

// These are the nine disjoint top-level scopes in the C25 wire contract.
// Provider-specific subordinate labels belong in DiagnosticComponent metadata;
// they may not replace or merge one of these owners.
enum class ComponentScopeV1 : std::uint8_t {
  construction_integration,
  input_bank_initialization,
  optimizer,
  coefficient_sampling,
  compression,
  projection,
  recode,
  solver,
  physical_fidelity,
};

enum class ProductKindV1 : std::uint8_t {
  raw_response,
  nominal_response,
  projection_center,
  projected_mean,
  recoded_response,
};

struct ResponseIdentityContextV1 final {
  ProviderIdentityV1 provider;
  ArtifactObjectReferenceV1 artifact_identity;
  ArtifactObjectReferenceV1 payload_identity;
  Digest256 build_identity;
  Digest256 request_identity;
  QueueId response_target;
  std::optional<Digest256> phase_identity;
  std::optional<TypedLabel> frozen_input_bank_id;
  std::optional<TypedLabel> final_probe_id;

  friend bool operator==(const ResponseIdentityContextV1&,
                         const ResponseIdentityContextV1&) = default;
};

struct MeanIdentityContextV1 final {
  ProviderIdentityV1 provider;
  ArtifactObjectReferenceV1 artifact_identity;
  ArtifactObjectReferenceV1 payload_identity;
  Digest256 build_identity;
  Digest256 request_identity;
  std::vector<QueueId> ordered_construction_targets;
  std::optional<Digest256> phase_identity;
  std::optional<TypedLabel> frozen_input_bank_id;
  std::optional<TypedLabel> final_probe_id;

  friend bool operator==(const MeanIdentityContextV1&,
                         const MeanIdentityContextV1&) = default;
};

struct RawResponseCoefficientIdentityV1 final {
  ResponseIdentityContextV1 context;
  RawResponseProductId product;
  ResponseProductValueFormV1 value_form;
  ThreeBinCoefficientV1 bin;

  friend bool operator==(const RawResponseCoefficientIdentityV1&,
                         const RawResponseCoefficientIdentityV1&) = default;
};

struct NominalResponseCoefficientIdentityV1 final {
  ResponseIdentityContextV1 context;
  NominalResponseProductId product;
  ThreeBinCoefficientV1 bin;

  friend bool operator==(const NominalResponseCoefficientIdentityV1&,
                         const NominalResponseCoefficientIdentityV1&) =
      default;
};

struct ProjectionCenterIdentityV1 final {
  MeanIdentityContextV1 context;
  ProjectionCenterProductId product;

  friend bool operator==(const ProjectionCenterIdentityV1&,
                         const ProjectionCenterIdentityV1&) = default;
};

struct ProjectedMeanIdentityV1 final {
  MeanIdentityContextV1 context;
  ProjectedMeanProductId product;

  friend bool operator==(const ProjectedMeanIdentityV1&,
                         const ProjectedMeanIdentityV1&) = default;
};

struct RecodedResponseCoefficientIdentityV1 final {
  ResponseIdentityContextV1 context;
  RecodedResponseProductId product;
  ThreeBinCoefficientV1 bin;

  friend bool operator==(const RecodedResponseCoefficientIdentityV1&,
                         const RecodedResponseCoefficientIdentityV1&) =
      default;
};

struct LawIdentitySpecV1 final {
  ResponseIdentityContextV1 response;
  // Reuse the C14/C15 deployed-product reference.  Its raw alternative owns
  // the value-form tag, so a caller cannot pair an interval-only raw identity
  // with a separately asserted exact-point flag here.
  DeployedResponseProductReferenceV1 deployed_product;
  Digest256 configured_arrival_law;
  // Exact identity of the deployed surrogate law/run.  This is the
  // subject_law_identity matched by a PhysicalFidelityAnchor; it is not an
  // interchangeable build, product, or configured-arrival digest.
  Digest256 execution_identity;
  Digest256 metric_target_identity;

  friend bool operator==(const LawIdentitySpecV1&,
                         const LawIdentitySpecV1&) = default;
};

// A LawIdentityV1 is issued only for an exact, point-valued deployed response.
// In particular an interval-only raw product and either mean-stage product can
// never inhabit this type.
class LawIdentityV1 final {
 public:
  LawIdentityV1(const LawIdentityV1&) = default;
  LawIdentityV1(LawIdentityV1&&) noexcept = default;
  LawIdentityV1& operator=(const LawIdentityV1&) = default;
  LawIdentityV1& operator=(LawIdentityV1&&) noexcept = default;

  [[nodiscard]] static Result<LawIdentityV1> make(LawIdentitySpecV1 spec);

  [[nodiscard]] const ResponseIdentityContextV1& response_context()
      const noexcept;
  [[nodiscard]] const DeployedResponseProductReferenceV1& deployed_product()
      const noexcept;
  [[nodiscard]] const Digest256& configured_arrival_law() const noexcept;
  [[nodiscard]] const Digest256& execution_identity() const noexcept;
  [[nodiscard]] const Digest256& metric_target_identity() const noexcept;
  [[nodiscard]] ProductKindV1 product_kind() const noexcept;

  friend bool operator==(const LawIdentityV1&,
                         const LawIdentityV1&) = default;

 private:
  explicit LawIdentityV1(LawIdentitySpecV1 spec);
  LawIdentitySpecV1 spec_;
};

struct DeployedLawProductIdentityV1 final {
  LawIdentityV1 law;

  friend bool operator==(const DeployedLawProductIdentityV1&,
                         const DeployedLawProductIdentityV1&) = default;
};

using ProductIdentityV1 =
    std::variant<RawResponseCoefficientIdentityV1,
                 NominalResponseCoefficientIdentityV1,
                 ProjectionCenterIdentityV1, ProjectedMeanIdentityV1,
                 RecodedResponseCoefficientIdentityV1,
                 DeployedLawProductIdentityV1>;

// Product kind is derived from the closed alternative.  No caller-writable
// kind tag exists, so a mean vector cannot be relabelled as coefficients.
[[nodiscard]] ProductKindV1 product_kind_v1(
    const ProductIdentityV1& identity) noexcept;
[[nodiscard]] bool product_identity_is_deployable_law_v1(
    const ProductIdentityV1& identity) noexcept;

struct DiagnosticValueIntervalV1 final {
  CertificateClaimStateV1 claim_state;
  BoundValueStatusV1 value_status;
  std::optional<long double> lower;
  std::optional<long double> upper;

  friend bool operator==(const DiagnosticValueIntervalV1&,
                         const DiagnosticValueIntervalV1&) = default;
};

struct DiagnosticConfidenceV1 final {
  long double confidence_level;
  std::string method;
  std::string coverage_family;
  bool simultaneous;

  friend bool operator==(const DiagnosticConfidenceV1&,
                         const DiagnosticConfidenceV1&) = default;
};

using ResponseCoefficientIdentitySetV1 =
    std::variant<std::vector<RawResponseCoefficientIdentityV1>,
                 std::vector<NominalResponseCoefficientIdentityV1>,
                 std::vector<RecodedResponseCoefficientIdentityV1>>;

// Bridge ownership is closed: response-to-center construction maps belong to
// coefficient_sampling or compression, center-to-mean maps belong to
// projection, and mean-to-response maps belong to recode.  A component in any
// other top-level scope cannot authorize the bridge even when its endpoints
// and numerical values happen to match.
struct ResponseToProjectionCenterBridgeV1 final {
  ResponseCoefficientIdentitySetV1 sources;
  ProjectionCenterIdentityV1 destination;
  ArtifactObjectReferenceV1 evidence_identity;
  std::string theorem_or_map;
  std::vector<std::string> assumptions;
  std::vector<DiagnosticValueIntervalV1> resulting_intervals;
};

struct ProjectionCenterToProjectedMeanBridgeV1 final {
  ProjectionCenterIdentityV1 source;
  ProjectedMeanIdentityV1 destination;
  ArtifactObjectReferenceV1 evidence_identity;
  std::string theorem_or_map;
  std::vector<std::string> assumptions;
  std::vector<DiagnosticValueIntervalV1> resulting_intervals;
};

struct ProjectedMeanToRecodedResponseBridgeV1 final {
  ProjectedMeanIdentityV1 source;
  std::vector<RecodedResponseCoefficientIdentityV1> destinations;
  ArtifactObjectReferenceV1 evidence_identity;
  std::string theorem_or_map;
  std::vector<std::string> assumptions;
  std::vector<DiagnosticValueIntervalV1> resulting_intervals;
};

using ProductBridgeV1 =
    std::variant<ResponseToProjectionCenterBridgeV1,
                 ProjectionCenterToProjectedMeanBridgeV1,
                 ProjectedMeanToRecodedResponseBridgeV1>;

enum class TriangleTotalKindV1 : std::uint8_t {
  final_law_error,
  physical_error,
};

enum class TriangleCombinationRuleV1 : std::uint8_t {
  deterministic,
  simultaneous_confidence,
  union_bound_confidence,
};

// A total exists only when contributors explicitly name the same declaration.
// Merely placing components in a bundle never authorizes their addition.
struct TriangleContributionV1 final {
  ArtifactObjectReferenceV1 total_identity;
  TriangleTotalKindV1 total_kind;
  DeployedLawProductIdentityV1 total_product;
  TriangleCombinationRuleV1 combination_rule;
  bool required;
  // A finite triangle total requires an explicit closed declaration of every
  // required summand and every bridge used to reach the deployed law.  These
  // lists are part of the declaration repeated by each contributor; omitting
  // a declared item therefore leaves the total not established.
  std::vector<ArtifactObjectReferenceV1> required_component_identities;
  std::vector<ArtifactObjectReferenceV1> required_bridge_evidence_identities;

  friend bool operator==(const TriangleContributionV1&,
                         const TriangleContributionV1&) = default;
};

struct DiagnosticComponentSpecV1 final {
  ArtifactObjectReferenceV1 component_identity;
  ComponentScopeV1 scope;
  ProductIdentityV1 source_product;
  std::optional<ProductIdentityV1> destination_product;
  std::string metric;
  MetricGeometry geometry;
  DiagnosticValueIntervalV1 value;
  std::optional<DiagnosticConfidenceV1> confidence;
  std::optional<long double> deterministic_tolerance;
  std::string theorem_or_method;
  std::vector<std::string> assumptions;
  std::vector<ArtifactObjectReferenceV1> evidence_references;
  ArtifactObjectReferenceV1 provenance_identity;
  std::optional<ProductBridgeV1> bridge;
  std::optional<TriangleContributionV1> triangle_contribution;
  // Capability issued only by F-C25-01 for independently established
  // physical-fidelity evidence.  Required exactly for physical_fidelity
  // components and checked against their deployed product/law/metric.
  std::optional<PhysicalFidelityAnchor> physical_fidelity_anchor;
  std::optional<ErrorBound> evaluated_transfer_bound;
};

// Only make() can produce a component.  It validates the exact source and
// destination identities, interval shape, provenance, and any bridge/total.
class DiagnosticComponent final {
 public:
  DiagnosticComponent() = delete;
  DiagnosticComponent(const DiagnosticComponent&) = default;
  DiagnosticComponent(DiagnosticComponent&&) noexcept = default;
  DiagnosticComponent& operator=(const DiagnosticComponent&) = default;
  DiagnosticComponent& operator=(DiagnosticComponent&&) noexcept = default;

  [[nodiscard]] static Result<DiagnosticComponent> make(
      DiagnosticComponentSpecV1 spec);

  [[nodiscard]] const ArtifactObjectReferenceV1& component_identity()
      const noexcept;
  [[nodiscard]] ComponentScopeV1 scope() const noexcept;
  [[nodiscard]] const ProductIdentityV1& source_product() const noexcept;
  [[nodiscard]] const std::optional<ProductIdentityV1>& destination_product()
      const noexcept;
  [[nodiscard]] const std::string& metric() const noexcept;
  [[nodiscard]] const MetricGeometry& geometry() const noexcept;
  [[nodiscard]] const DiagnosticValueIntervalV1& value() const noexcept;
  [[nodiscard]] const std::optional<DiagnosticConfidenceV1>& confidence()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& deterministic_tolerance()
      const noexcept;
  [[nodiscard]] const std::string& theorem_or_method() const noexcept;
  [[nodiscard]] const std::vector<std::string>& assumptions() const noexcept;
  [[nodiscard]] const std::vector<ArtifactObjectReferenceV1>&
  evidence_references() const noexcept;
  [[nodiscard]] const ArtifactObjectReferenceV1& provenance_identity()
      const noexcept;
  [[nodiscard]] const std::optional<ProductBridgeV1>& bridge() const noexcept;
  [[nodiscard]] const std::optional<TriangleContributionV1>&
  triangle_contribution() const noexcept;
  [[nodiscard]] const std::optional<PhysicalFidelityAnchor>&
  physical_fidelity_anchor() const noexcept;
  [[nodiscard]] const std::optional<ErrorBound>& evaluated_transfer_bound()
      const noexcept;

 private:
  explicit DiagnosticComponent(DiagnosticComponentSpecV1 spec);
  DiagnosticComponentSpecV1 spec_;
};

struct TriangleTotalV1 final {
  ArtifactObjectReferenceV1 total_identity;
  TriangleTotalKindV1 total_kind;
  DeployedLawProductIdentityV1 total_product;
  CertificateClaimStateV1 claim_state;
  BoundValueStatusV1 value_status;
  std::optional<long double> upper_bound;
  std::vector<ArtifactObjectReferenceV1> component_identities;
  std::vector<ArtifactObjectReferenceV1> bridge_evidence_identities;
  std::vector<ArtifactObjectReferenceV1> required_component_identities;
  std::vector<ArtifactObjectReferenceV1>
      required_bridge_evidence_identities;
  std::vector<std::string> assumptions;
};

struct BudgetConclusionV1 final {
  CertificateClaimStateV1 claim_state;
  BoundValueStatusV1 value_status;
  std::optional<ArtifactObjectReferenceV1> total_identity;
  std::optional<long double> upper_bound;
};

class DiagnosticBundle final {
 public:
  [[nodiscard]] std::span<const DiagnosticComponent> ordered_components()
      const noexcept;
  [[nodiscard]] std::span<const Diagnostic> validation_diagnostics()
      const noexcept;
  [[nodiscard]] std::span<const TriangleTotalV1> triangle_totals()
      const noexcept;
  [[nodiscard]] const BudgetConclusionV1& final_law_total() const noexcept;
  [[nodiscard]] const BudgetConclusionV1& physical_total() const noexcept;
  [[nodiscard]] bool valid() const noexcept;

 private:
  std::vector<DiagnosticComponent> ordered_components_;
  std::vector<Diagnostic> validation_diagnostics_;
  std::vector<TriangleTotalV1> triangle_totals_;
  BudgetConclusionV1 final_law_total_;
  BudgetConclusionV1 physical_total_;

  friend DiagnosticBundle compose_diagnostic_and_error_budget(
      std::span<const DiagnosticComponent> components);
};

// F-C25-07.  The ledger is canonicalized by immutable identities.  Equal
// numeric values are never keys and never cause component coalescing.
[[nodiscard]] DiagnosticBundle compose_diagnostic_and_error_budget(
    std::span<const DiagnosticComponent> components);

}  // namespace mwperf
