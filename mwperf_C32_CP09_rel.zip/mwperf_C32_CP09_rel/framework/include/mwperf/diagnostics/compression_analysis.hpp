#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <vector>

#include "mwperf/diagnostics/observation_record.hpp"
#include "mwperf/stationary/finite_prefix_fit.hpp"

namespace mwperf {

// Compression diagnostics are descriptive accounts.  These codes deliberately
// do not reuse metric-capability or provider-outcome statuses: an unavailable
// diagnostic must never change the deployed metric result.
enum class CompressionUnavailableReasonV1 : std::uint8_t {
  no_complete_replication,
  no_exposure,
  no_tail_exposure,
  zero_observed_mean,
  zero_tail_slack,
  nonpositive_tail_slack,
  stationary_hypotheses_unavailable,
  prefix_preservation_unavailable,
  unsupported_arrival_identity,
  unsupported_slot_convention,
  target_drop_possible,
  missing_second_moment,
  missing_arrival_overshoot,
  incomplete_or_missing_boundary,
  gap_telemetry_unavailable,
  inexact_primary_optimizer,
  unsupported_gap_topology,
  unsupported_target_multiplier,
  zero_competition_scale,
  nonpositive_competition_scale,
  fitted_law_unavailable,
  outside_decoder_profile,
  decoder_rejected,
  invalid_fit_shape,
  denominator_enclosure_contains_zero,
  insufficient_independent_replications,
  invalid_jackknife_resample,
  context_mismatch,
  source_role_mismatch,
  intermediate_fit_unavailable,
  transformed_profile_unavailable,
  arrival_overshoot_numerically_unresolved,
  arrival_overshoot_work_limit,
};

enum class CompressionWarningCodeV1 : std::uint8_t {
  structural_zero_response,
  exposure_without_observed_service,
  nonunit_recorded_mass,
  numerical_enclosure_required,
  ill_conditioned_tail_slack,
  finite_closure_with_nonpositive_slack,
  stationary_interpretation_is_estimated,
  partial_replications_excluded,
  invalid_jackknife_resamples_present,
};

struct CompressionMetricStatusV1 final {
  std::vector<CompressionUnavailableReasonV1> unavailable_reasons;
  std::vector<CompressionWarningCodeV1> warnings;

  [[nodiscard]] bool available() const noexcept {
    return unavailable_reasons.empty();
  }

  friend bool operator==(const CompressionMetricStatusV1&,
                         const CompressionMetricStatusV1&) = default;
};

// A binary64 cell is treated as the exact dyadic represented by its bits and
// carries the producer's absolute accumulation enclosure separately.  Derived
// enclosures use outward exact-rational interval arithmetic.
struct CompressionNumericalValueV1 final {
  ExactRational value;
  ExactRational absolute_error_bound;

  [[nodiscard]] bool exact() const noexcept {
    return absolute_error_bound.is_zero();
  }

  friend bool operator==(const CompressionNumericalValueV1&,
                         const CompressionNumericalValueV1&) = default;
};

struct CompressionQuantityV1 final {
  std::optional<CompressionNumericalValueV1> estimate;
  CompressionMetricStatusV1 status;

  [[nodiscard]] bool available() const noexcept {
    return estimate.has_value() && status.available();
  }

  friend bool operator==(const CompressionQuantityV1&,
                         const CompressionQuantityV1&) = default;
};

struct PooledGapCellV1 final {
  CompressionNumericalValueV1 negative_mass;
  CompressionNumericalValueV1 tie_mass;
  CompressionNumericalValueV1 positive_mass;
  CompressionNumericalValueV1 tied_and_served_mass;
  CompressionNumericalValueV1 positive_magnitude_mass;
  CompressionNumericalValueV1 negative_magnitude_mass;

  friend bool operator==(const PooledGapCellV1&,
                         const PooledGapCellV1&) = default;
};

struct PooledObservationLevelV1 final {
  BigNat backlog_level;
  CompressionNumericalValueV1 exposure_mass;
  CompressionNumericalValueV1 served_mass;
  std::optional<PooledGapCellV1> gap;

  friend bool operator==(const PooledObservationLevelV1&,
                         const PooledObservationLevelV1&) = default;
};

struct PooledObservationMomentsV1 final {
  BigNat measured_slot_count;
  std::size_t included_complete_replications;
  std::size_t excluded_partial_replications;
  std::vector<PooledObservationLevelV1> levels;
  CompressionNumericalValueV1 recorded_exposure_mass;
  CompressionQuantityV1 mass_per_slot;
  CompressionQuantityV1 signed_mass_defect;
  CompressionQuantityV1 departure_rate;
  CompressionQuantityV1 observed_mean;
  CompressionQuantityV1 service_moment;
  CompressionQuantityV1 departure_rate_per_slot;
  CompressionQuantityV1 observed_mean_per_slot;
  CompressionQuantityV1 service_moment_per_slot;
  CompressionMetricStatusV1 status;

  friend bool operator==(const PooledObservationMomentsV1&,
                         const PooledObservationMomentsV1&) = default;
};

struct EmpiricalResponsePointV1 final {
  BigNat backlog_level;
  CompressionQuantityV1 occupation_probability;
  CompressionQuantityV1 service_probability_mass;
  CompressionQuantityV1 response;
  bool observed_exposure;
  bool decoder_structural_zero;

  friend bool operator==(const EmpiricalResponsePointV1&,
                         const EmpiricalResponsePointV1&) = default;
};

enum class EmpiricalResponseProfileRepresentationV1 : std::uint8_t {
  dense_finite_prefix,
  sparse_profile_reference,
};

// CP09 treats the observed finite-window response as a scientific result in
// its own right.  It is neither a stationary response law nor a silently
// completed constant-tail surrogate.  The point status is explicit so a
// missing/indeterminate ratio cannot be confused with an empirical zero.
enum class EmpiricalFiniteWindowPointStatusV1 : std::uint8_t {
  structural_zero,
  available,
  no_exposure,
  denominator_enclosure_contains_zero,
};

enum class EmpiricalFiniteWindowInterpretationV1 : std::uint8_t {
  finite_window,
};

enum class EmpiricalFiniteWindowTailCompletionV1 : std::uint8_t {
  none,
};

struct EmpiricalFiniteWindowResponsePointV1 final {
  BigNat backlog_level;
  CompressionNumericalValueV1 exposure_mass;
  CompressionNumericalValueV1 served_mass;
  EmpiricalFiniteWindowPointStatusV1 response_status;
  CompressionQuantityV1 response;

  friend bool operator==(const EmpiricalFiniteWindowResponsePointV1&,
                         const EmpiricalFiniteWindowResponsePointV1&) =
      default;
};

// A single sparse profile is retained for the whole authenticated
// observation.  Arbitrary cutoffs are views over this vector; they never
// allocate or materialize the coordinate interval [0,K].
struct EmpiricalFiniteWindowResponseV1 final {
  Digest256 source_observation_digest;
  ObservationSourceRoleV1 source_role;
  ObservationScientificBindingsV1 bindings;
  std::uint64_t warmup_boundary;
  std::uint64_t end_boundary;
  std::vector<std::uint64_t> reporting_block_boundaries;
  std::optional<BigNat> ensemble_population_size;
  std::size_t configured_replications;
  std::size_t included_complete_replications;
  std::size_t excluded_partial_replications;
  std::vector<EmpiricalFiniteWindowResponsePointV1> observed_levels;
  BigNat observed_point_count;
  std::optional<BigNat> highest_observed_level;
  std::optional<BigNat> coordinate_extent;
  std::optional<BigNat> complete_through;
  CompressionNumericalValueV1 recorded_exposure_mass;
  CompressionQuantityV1 mass_per_slot;
  CompressionQuantityV1 signed_mass_defect;
  EmpiricalFiniteWindowInterpretationV1 interpretation;
  EmpiricalFiniteWindowTailCompletionV1 tail_completion;
  CompressionMetricStatusV1 status;

  friend bool operator==(const EmpiricalFiniteWindowResponseV1&,
                         const EmpiricalFiniteWindowResponseV1&) = default;
};

struct EmpiricalResponseProfileV1 final {
  BigNat cutoff;
  std::vector<EmpiricalResponsePointV1> prefix;
  CompressionQuantityV1 constant_tail_response;
  CompressionMetricStatusV1 status;
  EmpiricalResponseProfileRepresentationV1 representation{
      EmpiricalResponseProfileRepresentationV1::dense_finite_prefix};

  friend bool operator==(const EmpiricalResponseProfileV1&,
                         const EmpiricalResponseProfileV1&) = default;
};

// Optional provider-authored profile retained beside the empirical ratios.
// Supporting masses remain visible so a mismatch cannot be mislabeled as
// empirical tail association.
struct SuppliedResponseProfileV1 final {
  BigNat cutoff;
  std::vector<ExactRational> service_by_level;
  ExactRational constant_tail_service;
  std::vector<ExactRational> prefix_exposure_mass;
  std::vector<ExactRational> prefix_served_mass;
  ExactRational tail_exposure_mass;
  ExactRational tail_served_mass;

  friend bool operator==(const SuppliedResponseProfileV1&,
                         const SuppliedResponseProfileV1&) = default;
};

struct FourTailRewardsV1 final {
  CompressionQuantityV1 tail_probability;
  CompressionQuantityV1 tail_service_mass;
  CompressionQuantityV1 backlog_tail_reward;
  CompressionQuantityV1 backlog_service_tail_reward;
  CompressionQuantityV1 constant_tail_response;
  CompressionQuantityV1 tail_slack;
  CompressionQuantityV1 discarded_association_reward;
  CompressionQuantityV1 tail_mean_fraction;
  // Arithmetic ratio whenever delta != 0; it is not automatically a
  // stationary compression interpretation.
  CompressionQuantityV1 tail_association_ratio;
  // Available only under stationary/prefix-preservation hypotheses and
  // positive reachable-tail slack.
  CompressionQuantityV1 stationary_compression_defect;
  CompressionMetricStatusV1 status;

  friend bool operator==(const FourTailRewardsV1&,
                         const FourTailRewardsV1&) = default;
};

struct EmpiricalCompressionDecompositionV1 final {
  CompressionQuantityV1 arrival_balance_constant;
  CompressionQuantityV1 empirical_balance_residual;
  CompressionQuantityV1 observed_prefix_correction;
  CompressionQuantityV1 observation_balance_lhs;
  CompressionQuantityV1 observation_balance_rhs;
  CompressionQuantityV1 observation_balance_closure;
  CompressionQuantityV1 fitted_prefix_correction;
  CompressionQuantityV1 fitted_minus_observed_mean;
  CompressionQuantityV1 numerator_lhs;
  CompressionQuantityV1 numerator_rhs;
  CompressionQuantityV1 numerator_closure;
  CompressionQuantityV1 compression_term;
  CompressionQuantityV1 fitted_prefix_term;
  CompressionQuantityV1 finite_window_balance_term;
  CompressionQuantityV1 divided_term_sum;
  CompressionQuantityV1 divided_closure;
  CompressionMetricStatusV1 status;

  friend bool operator==(const EmpiricalCompressionDecompositionV1&,
                         const EmpiricalCompressionDecompositionV1&) =
      default;
};

struct FiniteWindowCutoffAnalysisV1 final {
  BigNat cutoff;
  CompressionQuantityV1 hinge_endpoint_drift;
  CompressionQuantityV1 tail_probability_per_slot;
  CompressionQuantityV1 overshoot_reward_normalized;
  CompressionQuantityV1 overshoot_reward_per_slot;
  CompressionQuantityV1 innovation;
  CompressionQuantityV1 expectation_level_residual;
  CompressionQuantityV1 realized_identity_closure;
  CompressionMetricStatusV1 status;

  friend bool operator==(const FiniteWindowCutoffAnalysisV1&,
                         const FiniteWindowCutoffAnalysisV1&) = default;
};

struct FiniteWindowAnalysisV1 final {
  CompressionQuantityV1 first_moment_endpoint_drift;
  CompressionQuantityV1 second_moment_endpoint_drift;
  CompressionQuantityV1 first_moment_expected_increment;
  CompressionQuantityV1 second_moment_expected_increment;
  CompressionQuantityV1 first_moment_innovation;
  CompressionQuantityV1 second_moment_innovation;
  CompressionQuantityV1 starred_balance_residual;
  CompressionQuantityV1 mass_defect_corrected_balance_residual;
  CompressionQuantityV1 moment_identity_closure;
  std::vector<FiniteWindowCutoffAnalysisV1> cutoffs;
  CompressionMetricStatusV1 status;

  friend bool operator==(const FiniteWindowAnalysisV1&,
                         const FiniteWindowAnalysisV1&) = default;
};

struct CompetitionCutoffAnalysisV1 final {
  BigNat cutoff;
  CompressionQuantityV1 positive_gap_tail_reward;
  CompressionQuantityV1 negative_gap_tail_reward;
  CompressionQuantityV1 gap_association_reward;
  CompressionQuantityV1 competition_association_reward;
  CompressionQuantityV1 competition_backlog_tail_reward;
  CompressionQuantityV1 competition_service_tail_reward;
  CompressionQuantityV1 direct_competition_association_reward;
  CompressionQuantityV1 association_split_closure;
  CompressionMetricStatusV1 status;

  friend bool operator==(const CompetitionCutoffAnalysisV1&,
                         const CompetitionCutoffAnalysisV1&) = default;
};

struct CompetitionAnalysisV1 final {
  CompressionQuantityV1 mean_gap;
  CompressionQuantityV1 mean_absolute_gap;
  CompressionQuantityV1 mean_competition_scale;
  CompressionQuantityV1 normalized_gap_scale;
  std::vector<CompetitionCutoffAnalysisV1> cutoffs;
  CompressionMetricStatusV1 status;

  friend bool operator==(const CompetitionAnalysisV1&,
                         const CompetitionAnalysisV1&) = default;
};

struct TieResponsePointV1 final {
  BigNat backlog_level;
  CompressionQuantityV1 strict_win_response_component;
  CompressionQuantityV1 tied_service_response_component;
  CompressionQuantityV1 reconstructed_response;
  CompressionQuantityV1 observed_response;
  CompressionQuantityV1 response_reconstruction_closure;

  friend bool operator==(const TieResponsePointV1&,
                         const TieResponsePointV1&) = default;
};

struct TieAnalysisV1 final {
  std::vector<TieResponsePointV1> response_by_level;
  CompressionQuantityV1 strict_loss_backlog_reward;
  CompressionQuantityV1 lost_tie_backlog_reward;
  CompressionQuantityV1 empirical_identity_lhs;
  CompressionQuantityV1 empirical_identity_rhs;
  CompressionQuantityV1 empirical_identity_closure;
  CompressionQuantityV1 isolated_server_baseline;
  CompressionQuantityV1 strict_loss_mean_contribution;
  CompressionQuantityV1 lost_tie_mean_contribution;
  CompressionQuantityV1 stationary_mean_reconstruction;
  CompressionMetricStatusV1 status;

  friend bool operator==(const TieAnalysisV1&, const TieAnalysisV1&) =
      default;
};

struct JackknifeReplicationEstimateV1 final {
  TypedLabel omitted_replication_id;
  CompressionQuantityV1 estimate;

  friend bool operator==(const JackknifeReplicationEstimateV1&,
                         const JackknifeReplicationEstimateV1&) = default;
};

struct DeleteOneReplicationJackknifeV1 final {
  CompressionQuantityV1 point_estimate;
  std::vector<JackknifeReplicationEstimateV1> leave_one_out_estimates;
  CompressionQuantityV1 leave_one_out_mean;
  CompressionQuantityV1 estimated_bias;
  CompressionQuantityV1 bias_corrected_estimate;
  CompressionQuantityV1 squared_standard_error;
  CompressionQuantityV1 invalid_resample_rate;
  CompressionMetricStatusV1 status;

  friend bool operator==(const DeleteOneReplicationJackknifeV1&,
                         const DeleteOneReplicationJackknifeV1&) = default;
};

struct FitResampleCountsV1 final {
  std::uint64_t eligible_fit_resamples;
  std::uint64_t failed_fit_resamples;
  std::uint64_t unavailable_fit_resamples;
  std::uint64_t unavailable_estimate_resamples;

  friend bool operator==(const FitResampleCountsV1&,
                         const FitResampleCountsV1&) = default;
};

struct CompressionCutoffJackknifeV1 final {
  DeleteOneReplicationJackknifeV1 fitted_mean;
  DeleteOneReplicationJackknifeV1 fitted_minus_observed_mean;
  DeleteOneReplicationJackknifeV1 tail_association_ratio;
  FitResampleCountsV1 fit_resamples;

  friend bool operator==(const CompressionCutoffJackknifeV1&,
                         const CompressionCutoffJackknifeV1&) = default;
};

struct CompressionCutoffAnalysisV1 final {
  BigNat cutoff;
  EmpiricalResponseProfileV1 empirical_profile;
  std::optional<SuppliedResponseProfileV1> provider_supplied_profile;
  FourTailRewardsV1 tail;
  std::optional<FinitePrefixFitResultV1> diagnostic_fit;
  std::optional<Diagnostic> diagnostic_fit_failure;
  CompressionMetricStatusV1 diagnostic_fit_status;
  // The pure fit above is the exact result for serialized coefficient
  // centers.  This quantity is the reporting value: it conservatively
  // propagates observation accumulation enclosures through the nonlinear
  // prediction (or is explicitly unavailable).
  CompressionQuantityV1 diagnostic_fitted_mean;
  EmpiricalCompressionDecompositionV1 decomposition;
  std::optional<CompressionCutoffJackknifeV1> jackknife;
  CompressionMetricStatusV1 status;

  friend bool operator==(const CompressionCutoffAnalysisV1&,
                         const CompressionCutoffAnalysisV1&) = default;
};

// Raw, independently attributable replication telemetry. These carriers
// deliberately retain numerators rather than per-replication ratios or fits:
// pooling remains the scientific point estimator, while the raw summaries
// make replication inclusion and uncertainty provenance auditable.  Their
// reverse-scan construction is bounded O(rows + blocks*K), where K here is
// the number of requested cutoff views.  Its memory is O(K), independent of
// the numerical magnitude of any cutoff.
enum class CompressionReplicationInclusionV1 : std::uint8_t {
  included_complete,
  excluded_incomplete,
  excluded_boundary_mismatch,
};

struct CompressionReplicationCutoffSummaryV1 final {
  BigNat cutoff;
  // Raw tau, b, u and v numerators.  They are not divided by this
  // replication's exposure mass.
  CompressionNumericalValueV1 tail_exposure_mass;
  CompressionNumericalValueV1 tail_service_mass;
  CompressionNumericalValueV1 backlog_tail_exposure_mass;
  CompressionNumericalValueV1 backlog_tail_service_mass;
  std::optional<CompressionNumericalValueV1>
      positive_gap_tail_magnitude_mass;
  std::optional<CompressionNumericalValueV1>
      negative_gap_tail_magnitude_mass;

  friend bool operator==(const CompressionReplicationCutoffSummaryV1&,
                         const CompressionReplicationCutoffSummaryV1&) =
      default;
};

struct CompressionReplicationSummaryV1 final {
  TypedLabel replication_id;
  ObservationCompletenessV1 completeness;
  CompressionReplicationInclusionV1 inclusion;
  BigNat measured_slot_count;
  // P, S, M_num and H_num respectively; all remain raw masses.
  CompressionNumericalValueV1 exposure_mass;
  CompressionNumericalValueV1 service_mass;
  CompressionNumericalValueV1 backlog_exposure_mass;
  CompressionNumericalValueV1 backlog_service_mass;
  std::optional<CompressionNumericalValueV1> initial_first_moment;
  std::optional<CompressionNumericalValueV1> committed_first_moment;
  std::optional<CompressionNumericalValueV1> initial_second_moment;
  std::optional<CompressionNumericalValueV1> committed_second_moment;
  std::vector<CompressionReplicationCutoffSummaryV1> cutoffs;

  friend bool operator==(const CompressionReplicationSummaryV1&,
                         const CompressionReplicationSummaryV1&) = default;
};

// Deterministic framework work counters.  Point-analysis row/byte totals
// count every all-wire raw-summary row once (including partial records), and
// also include delete-one re-analysis when enabled.  `input_row_bytes` is the
// fixed C++ record footprint of validated level/boundary rows visited by analysis;
// `analysis_allocation_events` counts explicit top-level capacity-acquisition
// sites, not implementation-specific multiprecision/allocator internals.
// Retained-object and byte estimates likewise cover framework-owned top-level
// vector elements; allocator overhead and dynamic multiprecision storage are
// deliberately excluded rather than guessed.
struct CompressionAnalysisWorkCountersV1 final {
  std::uint64_t input_level_rows;
  std::uint64_t input_boundary_rows;
  std::uint64_t input_row_bytes;
  std::uint64_t merged_level_rows;
  std::uint64_t merged_boundary_rows;
  std::uint64_t merge_key_comparisons;
  std::uint64_t merge_heap_operations;
  std::uint64_t point_fit_invocations;
  std::uint64_t jackknife_fit_invocations;
  std::uint64_t top_level_reservation_events;
  std::uint64_t analysis_allocation_events;
  std::uint64_t peak_retained_top_level_objects;
  std::uint64_t estimated_peak_retained_bytes;

  friend bool operator==(const CompressionAnalysisWorkCountersV1&,
                         const CompressionAnalysisWorkCountersV1&) = default;
};

struct CompressionAnalysisOptionsV1 final {
  std::vector<BigNat> cutoffs{BigNat{4U}, BigNat{8U}, BigNat{12U}};
  FinitePrefixFitLimitsV1 fit_limits;
  std::vector<FinitePrefixFitSelectionSeedAtomV1> selection_seed;
  std::vector<SuppliedResponseProfileV1> provider_supplied_profiles;
  std::optional<ExactRational> ill_conditioned_slack_threshold;
  bool run_diagnostic_fits{true};
  bool compute_delete_one_replication_jackknife{false};
  bool stationary_coefficients_established{false};
  bool prefix_preservation_established{false};
  enum class ProjectionMode : std::uint8_t {
    // Frozen C30/C31 behavior: materialize every coordinate 0..K and admit K
    // against the finite-prefix fit limits.
    finite_prefix_constant_tail,
    // CP09 behavior: retain one sparse finite-window profile and compute all
    // cutoff rewards as non-owning mathematical views of those rows.
    empirical_finite_window_response,
  };
  ProjectionMode projection_mode{ProjectionMode::finite_prefix_constant_tail};
  std::optional<BigNat> ensemble_population_size;

  // CP09's infinite-support arrival law remains compact.  These are the
  // exact declarative mixture components used by the analytical g_K
  // evaluator; the binary64 bits authenticate (but do not replace) the
  // operational sampling parameters.  Legacy finite-marginal routes leave
  // this absent.
  struct PoissonOvershootComponentV1 final {
    ExactRational weight;
    ExactRational component_rate;
    std::uint64_t operational_rate_bits;

    friend bool operator==(const PoissonOvershootComponentV1&,
                           const PoissonOvershootComponentV1&) = default;
  };

  struct PoissonMixtureOvershootV1 final {
    std::string descriptor_id;
    std::uint32_t descriptor_version;
    std::vector<PoissonOvershootComponentV1> components;
    Digest256 operational_parameter_digest;
    Digest256 descriptor_digest;
    ExactRational omitted_tail_tolerance;
    std::uint64_t maximum_recurrence_steps;

    friend bool operator==(const PoissonMixtureOvershootV1&,
                           const PoissonMixtureOvershootV1&) = default;
  };

  std::optional<PoissonMixtureOvershootV1> poisson_overshoot;

  friend bool operator==(const CompressionAnalysisOptionsV1&,
                         const CompressionAnalysisOptionsV1&) = default;
};

struct PoissonOvershootEvaluationReportV1 final {
  std::string algorithm_id;
  std::uint32_t algorithm_version;
  Digest256 descriptor_digest;
  ExactRational omitted_tail_tolerance;
  std::uint64_t maximum_recurrence_steps;
  std::uint64_t recurrence_steps;
  CompressionMetricStatusV1 status;

  friend bool operator==(const PoissonOvershootEvaluationReportV1&,
                         const PoissonOvershootEvaluationReportV1&) = default;
};

struct CompressionAnalysisResultV1 final {
  Digest256 observation_digest;
  // Domain-separated identity of the observation plus canonical analysis
  // options.  Work counters are deliberately excluded.
  Digest256 analysis_digest;
  ObservationSourceRoleV1 source_role;
  ObservationScientificBindingsV1 bindings;
  ObservationSlotConventionV1 slot_convention;
  ObservationInitializationV1 initialization;
  std::uint64_t warmup_boundary;
  std::uint64_t end_boundary;
  PooledObservationMomentsV1 pooled;
  std::optional<EmpiricalFiniteWindowResponseV1>
      empirical_finite_window_response;
  std::vector<CompressionReplicationSummaryV1> replications;
  std::vector<CompressionCutoffAnalysisV1> cutoffs;
  FiniteWindowAnalysisV1 finite_window;
  CompetitionAnalysisV1 competition;
  TieAnalysisV1 ties;
  CompressionAnalysisWorkCountersV1 work;
  CompressionMetricStatusV1 status;
  CompressionAnalysisOptionsV1::ProjectionMode projection_mode;
  std::optional<PoissonOvershootEvaluationReportV1>
      poisson_overshoot_evaluation;

  friend bool operator==(const CompressionAnalysisResultV1&,
                         const CompressionAnalysisResultV1&) = default;
};

// Framework-owned stationary predictions derived from a CP09 raw response.
// These are deliberately separate from both the authenticated observation and
// a provider-authored surrogate: the response points remain empirical, while
// the completion rule and every fitted quantity are explicit framework
// calculations.  An unavailable field always carries a stable reason code;
// absence is never interpreted as numerical zero.
enum class FrameworkPredictionAvailabilityV1 : std::uint8_t {
  available,
  unavailable,
};

struct FrameworkPredictionQuantityV1 final {
  FrameworkPredictionAvailabilityV1 availability;
  std::optional<ExactRational> value;
  std::optional<std::string> reason_code;

  [[nodiscard]] bool available() const noexcept {
    return availability == FrameworkPredictionAvailabilityV1::available &&
           value.has_value() && !reason_code.has_value();
  }

  friend bool operator==(const FrameworkPredictionQuantityV1&,
                         const FrameworkPredictionQuantityV1&) = default;
};

struct FrameworkPredictionResponsePointV1 final {
  BigNat backlog_level;
  CompressionNumericalValueV1 observed_response;
  EmpiricalFiniteWindowPointStatusV1 observation_status;
  bool constant_tail_anchor;

  friend bool operator==(const FrameworkPredictionResponsePointV1&,
                         const FrameworkPredictionResponsePointV1&) = default;
};

struct FrameworkPredictionPmfPointV1 final {
  BigNat backlog_level;
  FrameworkPredictionQuantityV1 probability;

  friend bool operator==(const FrameworkPredictionPmfPointV1&,
                         const FrameworkPredictionPmfPointV1&) = default;
};

struct FrameworkPoissonArrivalPointV1 final {
  BigNat arrival_count;
  CompressionNumericalValueV1 probability;

  friend bool operator==(const FrameworkPoissonArrivalPointV1&,
                         const FrameworkPoissonArrivalPointV1&) = default;
};

// Decoder-only finite representation of an authenticated analytic Poisson
// law.  The arrival law itself remains infinite: prefix probability
// enclosures and the omitted mass/moments are retained explicitly, while the
// stationary drift identities consume the exact analytic raw moments.
struct FrameworkPoissonArrivalReconstructionV1 final {
  std::string algorithm_id;
  std::uint32_t algorithm_version;
  Digest256 descriptor_digest;
  bool support_unbounded;
  BigNat represented_through;
  std::vector<FrameworkPoissonArrivalPointV1> probability_prefix;
  CompressionNumericalValueV1 omitted_probability;
  CompressionNumericalValueV1 omitted_first_raw_moment;
  CompressionNumericalValueV1 omitted_second_raw_moment;
  CompressionNumericalValueV1 omitted_third_raw_moment;
  ExactRational exact_first_raw_moment;
  ExactRational exact_second_raw_moment;
  ExactRational exact_third_raw_moment;
  ExactRational exponential_absolute_tolerance;
  std::uint64_t recurrence_steps;

  friend bool operator==(const FrameworkPoissonArrivalReconstructionV1&,
                         const FrameworkPoissonArrivalReconstructionV1&) =
      default;
};

struct FrameworkEmpiricalPredictionV1 final {
  Digest256 observation_digest;
  Digest256 analysis_digest;
  QueueId target_id;
  FrameworkPredictionAvailabilityV1 calculation_status;
  std::optional<std::string> calculation_reason_code;

  // The maximal positive-exposure interval is 0..H.  Every coefficient 0..H
  // is retained in the finite prefix, and the observed coefficient at H is
  // also extended as the constant response for every n > H.  Thus neither
  // response nor stationary-PMF resolution discards an observed level.
  std::optional<BigNat> observed_complete_through;
  std::optional<BigNat> prefix_cutoff;
  std::optional<BigNat> constant_tail_from;
  std::vector<FrameworkPredictionResponsePointV1> response_points;
  bool response_has_numerical_enclosures;
  std::optional<FrameworkPoissonArrivalReconstructionV1>
      poisson_arrival_reconstruction;

  std::vector<FrameworkPredictionPmfPointV1> stationary_pmf;
  FrameworkPredictionQuantityV1 remaining_tail_probability;
  FrameworkPredictionQuantityV1 empty_probability;
  FrameworkPredictionQuantityV1 first_backlog_moment;
  FrameworkPredictionQuantityV1 second_backlog_moment;
  FrameworkPredictionQuantityV1 mean_sojourn;
  FrameworkPredictionQuantityV1 arrival_mean;

  friend bool operator==(const FrameworkEmpiricalPredictionV1&,
                         const FrameworkEmpiricalPredictionV1&) = default;
};

// Deterministically interprets the complete contiguous portion of CP09's raw
// response using the registered constant-last-observed completion.  Exact
// stationary quantities are published only when the authenticated target
// arrival marginal and the finite-prefix fit establish them.  Scientific
// non-applicability is returned in-band in the per-field statuses.
[[nodiscard]] FrameworkEmpiricalPredictionV1
derive_framework_empirical_prediction_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisResultV1& analysis,
    const CompressionAnalysisOptionsV1& options);

// Resolve observation-bound defaults before either fitting or hashing the
// analysis options.  V1 has exactly one registered implicit seed: a validated
// record whose initialization descriptor is the registered Full Orbit
// empty-backlog law selects backlog zero with exact mass one.  The descriptor
// names actual run initialization for every source role; a later warmup does
// not erase finite-class reachability from that initial state.
// Unknown/altered descriptors leave an empty requested seed empty.  An
// explicitly supplied seed is never replaced.
[[nodiscard]] Result<CompressionAnalysisOptionsV1>
effective_compression_analysis_options_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    CompressionAnalysisOptionsV1 requested);

// Cheap publication-time binding check for a retained typed analysis.  The
// returned digest uses the same effective-option resolution and canonical
// identity preimage as analyze_compression_observations_v1, without rerunning
// the numerical analysis.
[[nodiscard]] Result<Digest256> compression_analysis_identity_digest_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisOptionsV1& requested);

// The fit is run from empirical mass ratios and the authenticated exact target
// arrival marginal.  The observed mean is not part of FinitePrefixFitInputV1
// and therefore cannot leak into the prediction.
[[nodiscard]] Result<CompressionAnalysisResultV1>
analyze_compression_observations_v1(
    const ValidatedConstructionObservationBundleV1& observation,
    const CompressionAnalysisOptionsV1& options);

// Public separately because comparison/reporting code may summarize a
// nonlinear statistic produced outside the main cutoff table.  Invalid
// resamples are reported; they are never silently conditioned away.
[[nodiscard]] Result<DeleteOneReplicationJackknifeV1>
summarize_delete_one_replication_jackknife_v1(
    CompressionQuantityV1 point_estimate,
    std::span<const JackknifeReplicationEstimateV1> leave_one_out);

}  // namespace mwperf
