#pragma once

#include <cstddef>
#include <optional>
#include <span>
#include <vector>

#include "mwperf/diagnostics/observation_record.hpp"

namespace mwperf {

// Content-addressed reference used when a result atomically externalizes the
// complete observation body.  A digest plus summaries is not itself an
// observation; the referenced canonical envelope must still be retrieved and
// validated before analysis.
struct ObservationArtifactReferenceV1 final {
  Digest256 observation_bundle_digest;
  std::size_t canonical_byte_count;

  friend bool operator==(const ObservationArtifactReferenceV1&,
                         const ObservationArtifactReferenceV1&) = default;
};

struct CanonicalObservationArtifactV1 final {
  ObservationArtifactReferenceV1 reference;
  std::vector<std::byte> bytes;

  friend bool operator==(const CanonicalObservationArtifactV1&,
                         const CanonicalObservationArtifactV1&) = default;
};

// Re-encodes the already validated bundle as the canonical envelope used by
// both provider sidecars and standalone ordinary-reference artifacts.
[[nodiscard]] Result<CanonicalObservationArtifactV1>
canonical_observation_artifact_v1(
    const ValidatedConstructionObservationBundleV1& observation);

// Bounded parse, canonical-wire verification, digest recomputation, and full
// semantic validation.  expected_reference is optional because a standalone
// artifact may be self-authenticating; when supplied, both digest and byte
// count must match before the value is returned.
[[nodiscard]] Result<ValidatedConstructionObservationBundleV1>
parse_and_validate_observation_artifact_v1(
    std::span<const std::byte> bytes,
    const ObservationParseLimitsV1& limits,
    const std::optional<ObservationArtifactReferenceV1>& expected_reference =
        std::nullopt);

}  // namespace mwperf
