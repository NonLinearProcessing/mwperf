#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/app/resolved_request.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/random/rng_stage.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf {

#if defined(MWPERF_C27_TEST_SEAMS)
namespace testing {
class C27ExecutionPlanFixtureFactory;
}
#endif

// The alternatives below are deliberately closed over the ten C14 backend
// routes.  Construction method is absent: how a provider produced an
// artifact cannot select or strengthen the runtime metric route.
enum class StationaryProofBackendV1 : std::uint8_t {
  c19_scalar_iid_summary,
  c18_selected_finite_invariant,
};

// A stationary flow identity is an output mapping, not a proof that an
// invariant probability law exists.  The dependency below freezes the exact
// C19 theorem input selected during planning.  Execution must obtain a proper
// normalized phase-free scalar IID summary before it may publish the identity.
struct StationaryProofDependencyV1 final {
  StationaryProofBackendV1 backend;
  PayloadClassV1 payload_class;
  SelectionSupportV1 selection_support;
  MetricSelectionRegimeV1 selected_regime;
  PhaseSupportV1 phase_support;
  TailSupportV1 tail_support;
  std::vector<ArrivalAssumptionV1> arrival_assumptions;
  std::vector<HypothesisClaimV1> hypotheses;
  AccuracyContractV1 accuracy;
  // The exact temporal-IID joint law may be supplied either by the compact
  // factorized generator or by the legacy explicit joint-vector table.
  bool requires_exact_iid_law;
  bool requires_proper_normalized_invariant;

  friend bool operator==(const StationaryProofDependencyV1&,
                         const StationaryProofDependencyV1&) = default;
};

struct FrameworkScalarIdentityBackendPlanV1 final {
  // Freeze the exact framework-derived scalar law selected by C14.  The
  // backend route tag alone is not a semantic contract and must never make
  // execution infer a scalar from MetricKindV1.
  FrameworkScalarKindV1 scalar;
  StationaryProofDependencyV1 stationary_proof;

  friend bool operator==(const FrameworkScalarIdentityBackendPlanV1&,
                         const FrameworkScalarIdentityBackendPlanV1&) =
      default;
};

struct StationaryInvariantBackendPlanV1 final {
  SelectionSupportV1 selection;
  TailSupportV1 tail;

  friend bool operator==(const StationaryInvariantBackendPlanV1&,
                         const StationaryInvariantBackendPlanV1&) = default;
};

struct StationaryEdgeRewardBackendPlanV1 final {
  SelectionSupportV1 selection;
  std::vector<MarkDescriptorV1> marks;

  friend bool operator==(const StationaryEdgeRewardBackendPlanV1&,
                         const StationaryEdgeRewardBackendPlanV1&) = default;
};

struct FiniteTemporalCylinderBackendPlanV1 final {
  PhaseSupportV1 phase;
  std::vector<MarkDescriptorV1> marks;

  friend bool operator==(const FiniteTemporalCylinderBackendPlanV1&,
                         const FiniteTemporalCylinderBackendPlanV1&) =
      default;
};

struct AnalyticMetricFamilyBackendPlanV1 final {
  AccuracyContractV1 accuracy;

  friend bool operator==(const AnalyticMetricFamilyBackendPlanV1&,
                         const AnalyticMetricFamilyBackendPlanV1&) = default;
};

struct ResidenceOrStoppedLawBackendPlanV1 final {
  SelectionSupportV1 selection;
  PhaseSupportV1 phase;
  TailSupportV1 tail;
  std::vector<MarkDescriptorV1> marks;

  friend bool operator==(const ResidenceOrStoppedLawBackendPlanV1&,
                         const ResidenceOrStoppedLawBackendPlanV1&) = default;
};

struct PalmOrFifoLawBackendPlanV1 final {
  SelectionSupportV1 selection;
  std::vector<MarkDescriptorV1> marks;

  friend bool operator==(const PalmOrFifoLawBackendPlanV1&,
                         const PalmOrFifoLawBackendPlanV1&) = default;
};

struct ConditionalRowMonteCarloBackendPlanV1 final {
  MonteCarloAccuracyV1 accuracy;
  // C24 v1 performs one conditional-generator call per authored
  // replication.  This is an a-priori count, never observed early stopping.
  BigNat worst_case_generator_draws;

  friend bool operator==(const ConditionalRowMonteCarloBackendPlanV1&,
                         const ConditionalRowMonteCarloBackendPlanV1&) =
      default;
};

struct ConditionalRewardMonteCarloBackendPlanV1 final {
  MonteCarloAccuracyV1 accuracy;
  BigNat worst_case_generator_draws;

  friend bool operator==(const ConditionalRewardMonteCarloBackendPlanV1&,
                         const ConditionalRewardMonteCarloBackendPlanV1&) =
      default;
};

struct ExactDirectBackendPlanV1 final {
  ExactMetricDecoderKeyV1 decoder_key;
  MetricRequestParametersV1 exact_parameters;

  friend bool operator==(const ExactDirectBackendPlanV1&,
                         const ExactDirectBackendPlanV1&) = default;
};

using MetricBackendPlanV1 =
    std::variant<FrameworkScalarIdentityBackendPlanV1,
                 StationaryInvariantBackendPlanV1,
                 StationaryEdgeRewardBackendPlanV1,
                 FiniteTemporalCylinderBackendPlanV1,
                 AnalyticMetricFamilyBackendPlanV1,
                 ResidenceOrStoppedLawBackendPlanV1,
                 PalmOrFifoLawBackendPlanV1,
                 ConditionalRowMonteCarloBackendPlanV1,
                 ConditionalRewardMonteCarloBackendPlanV1,
                 ExactDirectBackendPlanV1>;

static_assert(std::variant_size_v<MetricBackendPlanV1> == 10U);

[[nodiscard]] BackendRouteKindV1 backend_route_kind(
    const MetricBackendPlanV1& backend) noexcept;

// One authored metric and the exact accepted C14 route remain adjacent for
// the whole execution.  Later dispatch must visit backend(), never repeat a
// capability choice from the metric kind alone.
class PlannedMetricV1 final {
 public:
  PlannedMetricV1() = delete;
  PlannedMetricV1(const PlannedMetricV1&) = default;
  PlannedMetricV1(PlannedMetricV1&&) noexcept = default;
  PlannedMetricV1& operator=(const PlannedMetricV1&) = default;
  PlannedMetricV1& operator=(PlannedMetricV1&&) noexcept = default;

  [[nodiscard]] const MetricRequest& request() const noexcept {
    return request_;
  }
  [[nodiscard]] const ResolvedMetricContractV1& contract() const noexcept {
    return contract_;
  }
  [[nodiscard]] const MetricBackendPlanV1& backend() const noexcept {
    return backend_;
  }
  [[nodiscard]] BackendRouteKindV1 route_kind() const noexcept {
    return backend_route_kind(backend_);
  }

 private:
  PlannedMetricV1(MetricRequest request,
                  ResolvedMetricContractV1 contract,
                  MetricBackendPlanV1 backend)
      : request_(std::move(request)),
        contract_(std::move(contract)),
        backend_(std::move(backend)) {}

  MetricRequest request_;
  ResolvedMetricContractV1 contract_;
  MetricBackendPlanV1 backend_;

  friend Result<class ExecutionPlan> build_execution_plan(
      const ResolvedRequest& request);
#if defined(MWPERF_C27_TEST_SEAMS)
  friend class testing::C27ExecutionPlanFixtureFactory;
#endif
};

enum class SharedDependencyKindV1 : std::uint8_t {
  c19_scalar_iid_stationary_summary,
  stationary_invariant,
  stationary_edge_law,
  finite_temporal_kernel,
  analytic_metric_family,
  residence_or_stopped_law,
  palm_or_fifo_law,
  conditional_row_sampler,
  conditional_reward_sampler,
  exact_direct_decoder,
};

// Dependency sharing is keyed by the complete mathematical conditioning
// identity available before execution.  In particular, equal route enums do
// not authorize sharing across another configured arrival, target,
// selection, numerical policy, request parameter, or frozen plug law.
struct SharedDependencyIdentityV1 final {
  Digest256 descriptor_core_digest;
  ArrivalBinding configured_arrival;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  MetricSelectionRegimeV1 selection_regime;
  MetricSolverRegimeV1 solver_regime;
  MetricKindV1 metric_kind;
  MetricRequestParametersV1 exact_parameters;
  MetricBackendPlanV1 backend;

  friend bool operator==(const SharedDependencyIdentityV1&,
                         const SharedDependencyIdentityV1&) = default;
};

struct DependencySharingGroupV1 final {
  SharedDependencyKindV1 kind;
  SharedDependencyIdentityV1 identity;
  // Authored metric indices, in increasing authored order.  Equal route
  // kinds alone never share; equal identities share only the named
  // intermediate, never a metric value.
  std::vector<std::size_t> authored_metric_indices;

  friend bool operator==(const DependencySharingGroupV1&,
                         const DependencySharingGroupV1&) = default;
};

struct PlannedWorkBoundsV1 final {
  // Null means no finite reportable a-priori bound is asserted.  F-C27-03
  // permits that when the corresponding authored global cap is absent or
  // when an explicitly recognized route validates the work category as
  // NotApplicable.
  std::optional<BigNat> optimizer_calls;
  std::optional<BigNat> optimizer_search_states;
  std::optional<BigNat> construction_generator_draws;
  BigNat metric_generator_draws;
  std::optional<BigNat> total_generator_draws;

  friend bool operator==(const PlannedWorkBoundsV1&,
                         const PlannedWorkBoundsV1&) = default;
};

// C02 cannot mint the final estimator InstanceKey until C17 supplies the seal
// and exact conditioning-state identities.  Planning nevertheless freezes the
// remaining route tuple so execution cannot choose a new estimator address or
// RNG stage after inspecting a realized framework.
enum class RngInstanceKeyRouteV1 : std::uint8_t {
  conditional_estimator,
};

struct RngAddressTemplateV1 final {
  std::uint32_t schema_version;
  std::size_t authored_metric_index;
  MetricClauseIdV1 clause_id;
  BackendRouteKindV1 backend_route;
  RngInstanceKeyRouteV1 instance_key_route;
  StageTag stage;
  std::string estimator_id;
  Digest256 metric_target_digest;
  BigNat replications;
  // The callback-free statistical procedure is part of the immutable plan,
  // not a choice made after the runtime sampler or decoder is observed.
  ConditionalSampleDependenceV1 sampler_dependence;
  ConditionalEstimatorProcedureV1 estimator_procedure;
  std::optional<ConditionalRewardPremisesV1> reward_premises;

  friend bool operator==(const RngAddressTemplateV1&,
                         const RngAddressTemplateV1&) = default;
};

// Immutable planning handoff.  It owns an immutable ResolvedRequest snapshot
// and every callback-free value used by C15/C16 execution.  It deliberately
// contains no provider result, BuildIdentityDigest, BuildSeed, or final build
// request digest; C15 alone creates those after planning succeeds.
class ExecutionPlan final {
 public:
  ExecutionPlan() = delete;
  ExecutionPlan(const ExecutionPlan&) = default;
  ExecutionPlan(ExecutionPlan&&) noexcept = default;
  ExecutionPlan& operator=(const ExecutionPlan&) = default;
  ExecutionPlan& operator=(ExecutionPlan&&) noexcept = default;

  [[nodiscard]] const ResolvedRequest& resolved_request() const noexcept {
    return resolved_request_;
  }
  [[nodiscard]] const ResolvedInstance& resolved_instance() const noexcept {
    return resolved_request_.instance();
  }
  [[nodiscard]] const CompiledArrivalLaw& compiled_arrival_law()
      const noexcept {
    return resolved_request_.compiled_arrival();
  }
  [[nodiscard]] const SelectionSpec& selection_spec() const noexcept {
    return resolved_request_.instance().analysis_spec().context->selection;
  }
  [[nodiscard]] const std::optional<InitialPhysicalLaw>&
  initial_physical_law() const noexcept {
    return resolved_request_.initial_physical_law();
  }
  [[nodiscard]] MasterSeed master_seed() const noexcept {
    return resolved_request_.master_seed();
  }
  [[nodiscard]] const FrameworkProblemView& problem_view() const noexcept {
    return problem_view_;
  }
  [[nodiscard]] std::span<const MetricRequest> metric_requests()
      const noexcept {
    return metric_requests_;
  }
  [[nodiscard]] const MetricRequirements& requirements() const noexcept {
    return requirements_;
  }
  [[nodiscard]] const SurrogateProvider& provider() const noexcept {
    return provider_;
  }
  [[nodiscard]] const ValidatedProviderManifest& provider_manifest()
      const noexcept {
    return provider_.manifest();
  }
  [[nodiscard]] const ValidatedSurrogateParameters& validated_parameters()
      const noexcept {
    return parameters_;
  }
  [[nodiscard]] const PlugDescriptorPreview& preview() const noexcept {
    return preview_;
  }
  [[nodiscard]] const AcceptedCapabilityContract& capability_contract()
      const noexcept {
    return capability_contract_;
  }
  [[nodiscard]] const ConstructionBudget& construction_budget()
      const noexcept {
    return construction_budget_;
  }
  [[nodiscard]] ConstructionMethodV1 construction_method() const noexcept {
    return preview_.construction_method;
  }
  [[nodiscard]] ProducerModeV1 producer_mode() const noexcept {
    return preview_.producer_mode;
  }
  [[nodiscard]] MetricSelectionRegimeV1 selection_regime() const noexcept {
    return selection_regime_;
  }
  [[nodiscard]] MetricSolverRegimeV1 solver_regime() const noexcept {
    return solver_regime_;
  }
  [[nodiscard]] const std::optional<RegisteredExecutableSpec>&
  registered_executable() const noexcept {
    return registered_executable_;
  }
  [[nodiscard]] std::span<const PlannedMetricV1> metric_plans()
      const noexcept {
    return metric_plans_;
  }
  [[nodiscard]] const PlannedWorkBoundsV1& work_bounds() const noexcept {
    return work_bounds_;
  }
  [[nodiscard]] std::span<const RngAddressTemplateV1> rng_address_templates()
      const noexcept {
    return rng_address_templates_;
  }
  [[nodiscard]] std::span<const DependencySharingGroupV1>
  dependency_schedule() const noexcept {
    return dependency_schedule_;
  }

 private:
  ExecutionPlan(
      ResolvedRequest resolved_request, FrameworkProblemView problem_view,
      std::vector<MetricRequest> metric_requests,
      MetricRequirements requirements, SurrogateProvider provider,
      ValidatedSurrogateParameters parameters, PlugDescriptorPreview preview,
      AcceptedCapabilityContract capability_contract,
      ConstructionBudget construction_budget,
      MetricSelectionRegimeV1 selection_regime,
      MetricSolverRegimeV1 solver_regime,
      std::optional<RegisteredExecutableSpec> registered_executable,
      std::vector<PlannedMetricV1> metric_plans,
      PlannedWorkBoundsV1 work_bounds,
      std::vector<RngAddressTemplateV1> rng_address_templates,
      std::vector<DependencySharingGroupV1> dependency_schedule)
      : resolved_request_(std::move(resolved_request)),
        problem_view_(std::move(problem_view)),
        metric_requests_(std::move(metric_requests)),
        requirements_(std::move(requirements)),
        provider_(std::move(provider)),
        parameters_(std::move(parameters)),
        preview_(std::move(preview)),
        capability_contract_(std::move(capability_contract)),
        construction_budget_(std::move(construction_budget)),
        selection_regime_(selection_regime),
        solver_regime_(solver_regime),
        registered_executable_(std::move(registered_executable)),
        metric_plans_(std::move(metric_plans)),
        work_bounds_(std::move(work_bounds)),
        rng_address_templates_(std::move(rng_address_templates)),
        dependency_schedule_(std::move(dependency_schedule)) {}

  ResolvedRequest resolved_request_;
  FrameworkProblemView problem_view_;
  std::vector<MetricRequest> metric_requests_;
  MetricRequirements requirements_;
  SurrogateProvider provider_;
  ValidatedSurrogateParameters parameters_;
  PlugDescriptorPreview preview_;
  AcceptedCapabilityContract capability_contract_;
  ConstructionBudget construction_budget_;
  MetricSelectionRegimeV1 selection_regime_;
  MetricSolverRegimeV1 solver_regime_;
  std::optional<RegisteredExecutableSpec> registered_executable_;
  std::vector<PlannedMetricV1> metric_plans_;
  PlannedWorkBoundsV1 work_bounds_;
  std::vector<RngAddressTemplateV1> rng_address_templates_;
  std::vector<DependencySharingGroupV1> dependency_schedule_;

  friend Result<ExecutionPlan> build_execution_plan(
      const ResolvedRequest& request);
  friend Result<void> validate_execution_plan(const ExecutionPlan& plan);
#if defined(MWPERF_C27_TEST_SEAMS)
  friend class testing::C27ExecutionPlanFixtureFactory;
#endif
};

// F-C27-02
[[nodiscard]] Result<ExecutionPlan> build_execution_plan(
    const ResolvedRequest& request);

// F-C27-03
[[nodiscard]] Result<void> validate_execution_plan(
    const ExecutionPlan& plan);

}  // namespace mwperf
