#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>

#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/arrival/registry.hpp"
#include "mwperf/cli.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {
struct ResolvedRequestBuilder;
}

// The concrete seed is deliberately separate from the authored-input
// fingerprint.  In particular, resolving the -1 sentinel never mutates or
// recanonicalizes the authored model.
enum class ResolvedSeedSource : std::uint8_t {
  authored_fixed,
  replay_actual,
  operating_system_entropy,
};

// Normalization diagnostics remain individually identified.  A configured
// arrival stationary-phase law and the complete coupled transient initializer
// are different categorical products even when their exact deltas coincide.
enum class PmfNormalizationKind : std::uint8_t {
  configured_arrival_stationary_phase,
  transient_initial_law,
  configured_arrival_categorical_row,
};

struct PmfNormalizationRecord final {
  PmfNormalizationKind kind;
  std::string identity;
  ExactRational authored_sum;
  ExactRational normalization_delta;
  // Present only for configured_arrival_categorical_row.  The typed row
  // coordinates avoid treating a display string as scientific provenance.
  std::optional<ArrivalCategoricalRowKind> arrival_row_kind{};
  std::optional<std::size_t> source_ordinal{};
  std::optional<std::size_t> state_ordinal{};

  friend bool operator==(const PmfNormalizationRecord&,
                         const PmfNormalizationRecord&) = default;
};

// Immutable application handoff from input resolution to planning.  Copies
// share one const storage snapshot, including the opaque C09 product origins.
// A move is intentionally copy-like so no published request acquires an empty
// or partially valid state.
class ResolvedRequest final {
 public:
  ResolvedRequest() = delete;
  ResolvedRequest(const ResolvedRequest&) noexcept = default;
  ResolvedRequest(ResolvedRequest&& other) noexcept;
  ResolvedRequest& operator=(const ResolvedRequest&) noexcept = default;
  ResolvedRequest& operator=(ResolvedRequest&& other) noexcept;
  ~ResolvedRequest() = default;

  [[nodiscard]] const Analyze& analyze() const noexcept;
  [[nodiscard]] const CliPath& model_path() const noexcept;
  [[nodiscard]] const CliPath& analysis_path() const noexcept;
  [[nodiscard]] const CliPath& output_path() const noexcept;
  [[nodiscard]] const CanonicalInputPair& canonical_inputs() const noexcept;
  [[nodiscard]] const InputFingerprintBundle& fingerprints() const noexcept;
  [[nodiscard]] MasterSeed master_seed() const noexcept;
  [[nodiscard]] ResolvedSeedSource seed_source() const noexcept;
  [[nodiscard]] const ResolvedInstance& instance() const noexcept;
  [[nodiscard]] const CompiledArrivalLaw& compiled_arrival() const noexcept;
  [[nodiscard]] const std::optional<InitialPhysicalLaw>&
  initial_physical_law() const noexcept;
  [[nodiscard]] std::span<const PmfNormalizationRecord>
  normalization_diagnostics() const noexcept;

  // In-memory ownership identity for later cross-plan binding checks.  This
  // is intentionally not serialized and is never a substitute for C03/C15
  // scientific digests.
  [[nodiscard]] bool shares_resolution_owner_with(
      const ResolvedRequest& other) const noexcept;

 private:
  struct Storage;
  explicit ResolvedRequest(std::shared_ptr<const Storage> storage) noexcept;

  std::shared_ptr<const Storage> storage_;

  friend struct detail::ResolvedRequestBuilder;
};

// F-C27-01
[[nodiscard]] Result<ResolvedRequest> load_and_resolve_request(
    const CliRequest& request);

#if defined(MWPERF_C27_TEST_SEAMS)
namespace testing {

using SeedEntropySource = std::function<Result<std::uint64_t>()>;

// Per-call injection only: no mutable process-global entropy hook exists.
[[nodiscard]] Result<ResolvedRequest> load_and_resolve_request_with_entropy(
    const CliRequest& request, const SeedEntropySource& entropy_source);

// Runner-local C27 integration seam.  It accepts only a completed immutable
// resolution and rebinds it through C19's checked exact-arrival fixture
// authority.  For a transient selection it recompiles the already-resolved
// authored initializer against that replacement law; caller-authored binding
// metadata is never accepted.
[[nodiscard]] Result<ResolvedRequest>
rebind_resolved_request_arrival_for_testing(
    const ResolvedRequest& source,
    std::shared_ptr<const CompiledArrivalLaw> configured_arrival);

}  // namespace testing
#endif

}  // namespace mwperf
