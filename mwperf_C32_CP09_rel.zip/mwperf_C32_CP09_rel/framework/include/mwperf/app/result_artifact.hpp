#pragma once

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/build_information.hpp"
#include "mwperf/certificates/certificate_bundle.hpp"
#include "mwperf/cli.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf {

class ResolvedRequest;
class ExecutionPlan;
class AnalysisBundle;
class AnalysisDiagnosticSupplementV2;
class ValidatedConstructionObservationBundleV1;
struct SuppliedResponseProfileV1;
struct CompressionAnalysisOptionsV1;
struct CompressionAnalysisResultV1;
struct FrameworkEmpiricalPredictionV1;
struct ThreeRecordErrorSeparationV1;
class PublishedResultArtifact;
enum class ComponentScopeV1 : std::uint8_t;
enum class ProductKindV1 : std::uint8_t;

enum class ResultStatusV1 : std::uint8_t {
  success,
  unavailable,
  failed,
};

// Publication is deliberately absent.  A publication failure cannot be
// truthfully recorded in the file whose publication failed.
enum class ResultFailureStageV1 : std::uint8_t {
  request_construction,
  producer_execution,
  wire_parse,
  build_contract_validation,
  payload_adaptation,
  plug_binding,
  v0_audit,
  initial_law,
  backend,
  certificate,
  result_assembly,
};

struct ResultFailureV1 final {
  ResultFailureStageV1 stage;
  std::string code;
  std::vector<std::string> diagnostic_refs;

  friend bool operator==(const ResultFailureV1&,
                         const ResultFailureV1&) = default;
};

struct PositiveInfinityV1 final {
  friend bool operator==(PositiveInfinityV1, PositiveInfinityV1) = default;
};

struct ResultScalarVectorV1 final {
  std::vector<PortableScientificScalar> values;

  friend bool operator==(const ResultScalarVectorV1&,
                         const ResultScalarVectorV1&) = default;
};

struct ResultTableEntryV1 final {
  std::vector<TypedLabel> coordinates;
  PortableScientificScalar value;

  friend bool operator==(const ResultTableEntryV1&,
                         const ResultTableEntryV1&) = default;
};

struct ResultTableV1 final {
  std::vector<std::string> coordinate_names;
  std::vector<ResultTableEntryV1> entries;

  friend bool operator==(const ResultTableV1&, const ResultTableV1&) =
      default;
};

struct ResultProbabilityAtomV1 final {
  std::vector<TypedLabel> outcome;
  PortableScientificScalar mass;

  friend bool operator==(const ResultProbabilityAtomV1&,
                         const ResultProbabilityAtomV1&) = default;
};

// A defective law remains an established law.  defective_mass_proven
// distinguishes a proved defect from a truncated or unresolved remainder.
struct ResultProbabilityLawV1 final {
  std::vector<std::string> coordinate_names;
  std::vector<ResultProbabilityAtomV1> atoms;
  PortableScientificScalar defective_mass;
  bool defective_mass_proven;

  friend bool operator==(const ResultProbabilityLawV1&,
                         const ResultProbabilityLawV1&) = default;
};

struct ResultCanonicalValueV1 final {
  CodecIdentityV1 codec;
  std::vector<std::byte> canonical_value;

  friend bool operator==(const ResultCanonicalValueV1&,
                         const ResultCanonicalValueV1&) = default;
};

using ResultMetricValueV1 =
    std::variant<PortableScientificScalar, PositiveInfinityV1,
                 ResultScalarVectorV1, ResultTableV1,
                 ResultProbabilityLawV1, ResultCanonicalValueV1>;

struct ResultMetricHeaderV1 final {
  std::string metric_id;
  MetricKindV1 kind;
  std::vector<QueueId> ordered_targets;
  std::string units;
  std::string convention;
  Digest256 law_identity;
  MetricResultScopeV1 scientific_scope;
  std::vector<std::string> assumptions;
  std::vector<std::string> error_refs;
  std::vector<std::string> residual_refs;

  friend bool operator==(const ResultMetricHeaderV1&,
                         const ResultMetricHeaderV1&) = default;
};

struct EstablishedResultMetricV1 final {
  ResultMetricHeaderV1 header;
  ResultMetricValueV1 value;

  friend bool operator==(const EstablishedResultMetricV1&,
                         const EstablishedResultMetricV1&) = default;
};

struct UnavailableResultMetricV1 final {
  ResultMetricHeaderV1 header;
  std::string reason_code;
  std::vector<std::string> diagnostic_refs;

  friend bool operator==(const UnavailableResultMetricV1&,
                         const UnavailableResultMetricV1&) = default;
};

using ResultMetricV1 =
    std::variant<EstablishedResultMetricV1, UnavailableResultMetricV1>;

enum class ResultDiagnosticKindV1 : std::uint8_t {
  component,
  truncation_tail,
  stationary_residual,
  numerical_conditioning,
  budget_termination,
  execution,
};

struct ResultDiagnosticIntervalV1 final {
  CertificateClaimStateV1 claim_state;
  BoundValueStatusV1 value_status;
  std::optional<PortableScientificScalar> lower;
  std::optional<PortableScientificScalar> upper;

  friend bool operator==(const ResultDiagnosticIntervalV1&,
                         const ResultDiagnosticIntervalV1&) = default;
};

struct ResultLawIdentityV1 final {
  Digest256 configured_arrival_law;
  Digest256 execution_identity;
  Digest256 metric_target_identity;

  friend bool operator==(const ResultLawIdentityV1&,
                         const ResultLawIdentityV1&) = default;
};

struct ResultProductBindingV1 final {
  ProductKindV1 product_kind;
  ProviderIdentityV1 provider;
  // C15 does not require a portable identity for the complete artifact
  // envelope.  Retain it when the provider reports one, but never synthesize
  // it from the payload or another component identity.
  std::optional<ArtifactObjectReferenceV1> artifact_identity;
  ArtifactObjectReferenceV1 payload_identity;
  Digest256 build_identity;
  Digest256 request_identity;
  ArtifactObjectReferenceV1 product_identity;
  std::optional<QueueId> response_target;
  std::vector<QueueId> ordered_construction_targets;
  std::optional<Digest256> phase_identity;
  std::optional<TypedLabel> frozen_input_bank_id;
  std::optional<TypedLabel> final_probe_id;
  std::optional<ResponseProductValueFormV1> raw_value_form;
  std::optional<ThreeBinCoefficientV1> response_bin;
  std::optional<ResultLawIdentityV1> law_identity;

  friend bool operator==(const ResultProductBindingV1&,
                         const ResultProductBindingV1&) = default;
};

struct ResultDiagnosticV1 final {
  std::string diagnostic_id;
  DiagnosticCategory category;
  std::string code;
  std::string message;
  std::optional<ComponentScopeV1> component_scope;
  ResultDiagnosticKindV1 kind;
  std::optional<ResultProductBindingV1> product;
  std::optional<ResultDiagnosticIntervalV1> value;
  std::vector<std::string> assumptions;
  std::vector<std::string> evidence_refs;

  friend bool operator==(const ResultDiagnosticV1&,
                         const ResultDiagnosticV1&) = default;
};

struct ResultCertificateV1 final {
  std::string certificate_id;
  CertificateClaimKindV1 kind;
  CertificateClaimStateV1 claim_state;
  std::vector<std::string> assumptions;
  std::vector<std::string> evidence_refs;
  std::vector<std::string> diagnostic_refs;

  friend bool operator==(const ResultCertificateV1&,
                         const ResultCertificateV1&) = default;
};

enum class ResultBudgetApplicabilityV1 : std::uint8_t {
  not_applicable,
  applicable,
};

struct ResultBudgetUsageV1 final {
  std::string name;
  ResultBudgetApplicabilityV1 applicability;
  std::optional<BigNat> granted;
  BigNat used;
  std::string unit;

  friend bool operator==(const ResultBudgetUsageV1&,
                         const ResultBudgetUsageV1&) = default;
};

// A C15 artifact reports construction consumption by its typed instance ID.
// Artifact-v1 does not carry the derived stream digest, so result-v1 must not
// invent one.
struct ResultConstructionReplayStreamV1 final {
  StageTag stage_tag;
  TypedLabel stream_instance_id;
  BigNat draws;

  friend bool operator==(const ResultConstructionReplayStreamV1&,
                         const ResultConstructionReplayStreamV1&) = default;
};

// Runtime streams are derived inside the framework after their complete route
// identity exists, so their real one-way stream identity can be retained.
struct ResultRuntimeReplayStreamV1 final {
  StageTag stage_tag;
  Digest256 stream_identity;
  BigNat draws;

  friend bool operator==(const ResultRuntimeReplayStreamV1&,
                         const ResultRuntimeReplayStreamV1&) = default;
};

using ResultReplayStreamV1 =
    std::variant<ResultConstructionReplayStreamV1,
                 ResultRuntimeReplayStreamV1>;

struct ResultBuildProvenanceV1 final {
  std::string core;
  std::string rng;
  std::string interfaces;

  friend bool operator==(const ResultBuildProvenanceV1&,
                         const ResultBuildProvenanceV1&) = default;
};

struct ResultBuildRequestIdentityV1 final {
  BuildIdentityDigest build_identity_digest;
  BuildSeed build_seed;
  SurrogateBuildRequestDigest build_request_digest;

  friend bool operator==(const ResultBuildRequestIdentityV1&,
                         const ResultBuildRequestIdentityV1&) = default;
};

struct ResultExecutionProvenanceV1 final {
  MasterSeed actual_seed;
  // Absent only when pre-request execution setup or F-C15-03 failed after a
  // valid plan began, before C15 could mint the three mutually bound
  // identities.
  std::optional<ResultBuildRequestIdentityV1> build_request_identity;
  std::vector<ResultReplayStreamV1> replay_streams;
  std::vector<ResultBudgetUsageV1> budget_usage;
  std::optional<Digest256> execution_seal_digest;

  friend bool operator==(const ResultExecutionProvenanceV1&,
                         const ResultExecutionProvenanceV1&) = default;
};

struct ResultModelProvenanceV1 final {
  std::string schema_version;
  Digest256 fingerprint;

  friend bool operator==(const ResultModelProvenanceV1&,
                         const ResultModelProvenanceV1&) = default;
};

struct ResultAnalysisProvenanceV1 final {
  std::string schema_version;
  Digest256 fingerprint;
  std::vector<QueueId> ordered_targets;
  std::vector<std::string> metric_ids;
  PortableAnalysisSelectionV1 selection;
  MetricSolverRegimeV1 solver_regime;

  friend bool operator==(const ResultAnalysisProvenanceV1&,
                         const ResultAnalysisProvenanceV1&) = default;
};

struct ResultSurrogateProvenanceV1 final {
  ProviderIdentityV1 provider;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  ProviderScientificContractDigest provider_digest;
  std::optional<Digest256> payload_digest;
  std::optional<std::string> plug_kind;

  friend bool operator==(const ResultSurrogateProvenanceV1&,
                         const ResultSurrogateProvenanceV1&) = default;
};

struct ResultResponseCurveV1 final {
  QueueId target;
  PortableScientificScalar backlog_zero;
  PortableScientificScalar backlog_one;
  PortableScientificScalar backlog_two;
  PortableScientificScalar backlog_at_least_three;

  friend bool operator==(const ResultResponseCurveV1&,
                         const ResultResponseCurveV1&) = default;
};

enum class ResultKBinCoordinateKindV1 : std::uint8_t {
  structural_level_zero,
  exact_level,
  constant_tail,
};

// Compact construction evidence for one coordinate of the native K-wide
// response.  The two pooled masses remain separate so a positive exposure
// with zero observed service cannot be confused with a coordinate that was
// never visited.
struct ResultKBinCoefficientDiagnosticV1 final {
  ResultKBinCoordinateKindV1 coordinate_kind;
  BigNat level_or_tail_from;
  PortableScientificScalar pooled_unserved_mass;
  PortableScientificScalar pooled_served_mass;
  PortableScientificScalar nominal_service_probability;
  std::optional<PortableScientificScalar> construction_interval_lower;
  std::optional<PortableScientificScalar> construction_interval_upper;

  friend bool operator==(const ResultKBinCoefficientDiagnosticV1&,
                         const ResultKBinCoefficientDiagnosticV1&) = default;
};

struct ResultC19UnavailableDiagnosticsV1 final {
  std::string analytic_status;
  PortableScientificScalar arrival_mean;
  std::vector<PortableScientificScalar> service_by_level;
  BigNat tail_from;
  PortableScientificScalar tail_service;
  PortableScientificScalar tail_slack;
  std::string tail_slack_applicability;
  PortableScientificScalar normalization_residual;
  PortableScientificScalar invariance_residual;
  std::optional<PortableScientificScalar> tail_remainder_bound;
  std::optional<BigNat> terms_evaluated;

  friend bool operator==(const ResultC19UnavailableDiagnosticsV1&,
                         const ResultC19UnavailableDiagnosticsV1&) = default;
};

struct ResultUnavailableCauseV1 final {
  std::string code;
  std::string message;
  std::optional<std::string> metric_id;

  friend bool operator==(const ResultUnavailableCauseV1&,
                         const ResultUnavailableCauseV1&) = default;
};

// Retained internally for every native K-wide Unavailable result.  The
// response cutoff is always published beside the error code; the remaining
// evidence is serialized only under the explicit CLI publication flag.
struct ResultUnavailableDiagnosticsV1 final {
  BigNat response_cutoff;
  std::vector<ResultUnavailableCauseV1> causes;
  std::vector<ResultKBinCoefficientDiagnosticV1> coefficient_diagnostics;
  std::optional<ResultC19UnavailableDiagnosticsV1> c19;

  friend bool operator==(const ResultUnavailableDiagnosticsV1&,
                         const ResultUnavailableDiagnosticsV1&) = default;
};

struct ResultWallClockTimesV1 final {
  std::chrono::nanoseconds end_to_end;
  std::chrono::nanoseconds sampler;
  std::chrono::nanoseconds framework;

  friend bool operator==(const ResultWallClockTimesV1&,
                         const ResultWallClockTimesV1&) = default;
};

struct ResultArtifactDataV1 final {
  ResultStatusV1 status;
  std::optional<ResultFailureV1> failure;
  InputFingerprintBundle input_fingerprints;
  ResultBuildProvenanceV1 build;
  ResultExecutionProvenanceV1 execution;
  ResultModelProvenanceV1 model;
  ResultAnalysisProvenanceV1 analysis;
  ResultSurrogateProvenanceV1 surrogate;
  std::vector<ResultMetricV1> metrics;
  std::vector<ResultCertificateV1> certificates;
  std::vector<ResultDiagnosticV1> diagnostics;
  std::vector<ResultBudgetUsageV1> budgets_used;
  std::string config_name{};
  std::optional<ResultResponseCurveV1> response_curve{};
  std::optional<ResultUnavailableDiagnosticsV1> unavailable_diagnostics{};
  ResultWallClockTimesV1 wall_clock_times{
      std::chrono::nanoseconds::zero(), std::chrono::nanoseconds::zero(),
      std::chrono::nanoseconds::zero()};
  bool output_resources{false};
  bool report_unavailable_diagnostics{false};
  std::uint32_t worker_count{1U};
  BigNat optimizer_calls_observed{0U};
  BigNat optimizer_search_states_observed{0U};

  friend bool operator==(const ResultArtifactDataV1&,
                         const ResultArtifactDataV1&) = default;
};

enum class ResultArtifactVersionV1 : std::uint8_t {
  v1 = 1U,
  v2 = 2U,
  v3 = 3U,
};

// Result-v2 is a separate publication contract.  Keeping the complete v1
// main-result carrier nested (rather than appending fields to it) preserves
// the frozen v1 validator, serializer, bytes, and fixture API.  The shared
// supplement prevents the potentially large validated observation body from
// being copied during result assembly.
struct ResultArtifactDataV2 final {
  ResultArtifactDataV1 main;
  std::shared_ptr<const AnalysisDiagnosticSupplementV2>
      diagnostic_supplement;
};

// Result-v3 is the CP09 empirical publication.  It has no deployed
// ResultArtifactDataV1 surrogate main, but a verified empirical analysis also
// carries a framework-owned plug-in prediction whose response completion and
// calculation status are explicit.  Completed provider terminals retain the
// authenticated diagnostic supplement; failures before any provider result
// retain only the provenance that truly exists.  Neither branch invents a
// provider payload or execution seal.
struct ResultArtifactDataV3 final {
  ResultStatusV1 status;
  std::optional<ResultFailureV1> failure;
  InputFingerprintBundle input_fingerprints;
  ProviderIdentityV1 provider;
  ProviderScientificContractDigest provider_digest;
  // Absent only when execution failed before a complete provider-result-v3
  // envelope could be authenticated.  A retained observation always carries
  // (and is checked against) the source provider-result digest.
  std::optional<Digest256> provider_result_digest;
  MasterSeed master_seed;
  std::optional<ResultBuildRequestIdentityV1> build_request_identity;
  ResultModelProvenanceV1 model;
  ResultAnalysisProvenanceV1 analysis;
  std::string config_name;
  ResultWallClockTimesV1 wall_clock_times;
  std::uint32_t worker_count;
  std::shared_ptr<const AnalysisDiagnosticSupplementV2>
      diagnostic_supplement;
  // Present whenever a verified empirical analysis exists.  This is a
  // framework derivation over the authenticated raw response, never a
  // provider-authored surrogate or a mutation of the observation sidecar.
  std::shared_ptr<const FrameworkEmpiricalPredictionV1>
      framework_prediction;
};

class ResultArtifact final {
 public:
  ResultArtifact() = delete;
  ResultArtifact(const ResultArtifact&) = default;
  ResultArtifact(ResultArtifact&&) noexcept = default;
  ResultArtifact& operator=(const ResultArtifact&) = default;
  ResultArtifact& operator=(ResultArtifact&&) noexcept = default;

  [[nodiscard]] const ResultArtifactDataV1& value() const noexcept {
    return value_;
  }
  [[nodiscard]] ResultStatusV1 status() const noexcept {
    return value_.status;
  }

  friend bool operator==(const ResultArtifact&,
                         const ResultArtifact&) = default;

 private:
  explicit ResultArtifact(ResultArtifactDataV1 value)
      : value_(std::move(value)) {}

  [[nodiscard]] static Result<ResultArtifact> make_checked(
      ResultArtifactDataV1 value);

  ResultArtifactDataV1 value_;

  friend Result<ResultArtifact> assemble_result_artifact(
      const ResolvedRequest&, const ExecutionPlan&, const AnalysisBundle&);
  friend Result<PublishedResultArtifact> assemble_selected_result_artifact(
      const ResolvedRequest&, const ExecutionPlan&, const AnalysisBundle&,
      ResultVersionSelectionV1);
#if defined(MWPERF_C27_TEST_SEAMS)
  friend Result<ResultArtifact> make_result_artifact_for_test(
      ResultArtifactDataV1);
#endif
};

class ResultArtifactV2 final {
 public:
  ResultArtifactV2() = delete;
  ResultArtifactV2(const ResultArtifactV2&) = default;
  ResultArtifactV2(ResultArtifactV2&&) noexcept = default;
  ResultArtifactV2& operator=(const ResultArtifactV2&) = default;
  ResultArtifactV2& operator=(ResultArtifactV2&&) noexcept = default;

  [[nodiscard]] const ResultArtifactDataV2& value() const noexcept {
    return value_;
  }
  [[nodiscard]] ResultStatusV1 status() const noexcept {
    return value_.main.status;
  }

 private:
  explicit ResultArtifactV2(ResultArtifactDataV2 value)
      : value_(std::move(value)) {}

  [[nodiscard]] static Result<ResultArtifactV2> make_checked(
      ResultArtifactDataV2 value);
  // Production-only construction from AnalysisBundle.  AnalysisBundle itself
  // has a private execute_analysis mint and holds the analyzer output through
  // immutable shared ownership, so this path validates all bindings without
  // rerunning nonlinear fits.  The arbitrary test constructor above performs
  // full scientific recomputation.
  [[nodiscard]] static Result<ResultArtifactV2> make_from_trusted_execution(
      ResultArtifactDataV2 value);

  ResultArtifactDataV2 value_;

  friend Result<PublishedResultArtifact>
  assemble_selected_result_artifact(
      const ResolvedRequest&, const ExecutionPlan&, const AnalysisBundle&,
      ResultVersionSelectionV1);
#if defined(MWPERF_C27_TEST_SEAMS)
  friend Result<ResultArtifactV2> make_result_artifact_v2_for_test(
      ResultArtifactDataV2);
#endif
};

class ResultArtifactV3 final {
 public:
  ResultArtifactV3() = delete;
  ResultArtifactV3(const ResultArtifactV3&) = default;
  ResultArtifactV3(ResultArtifactV3&&) noexcept = default;
  ResultArtifactV3& operator=(const ResultArtifactV3&) = default;
  ResultArtifactV3& operator=(ResultArtifactV3&&) noexcept = default;

  [[nodiscard]] const ResultArtifactDataV3& value() const noexcept {
    return value_;
  }
  [[nodiscard]] ResultStatusV1 status() const noexcept {
    return value_.status;
  }

 private:
  explicit ResultArtifactV3(ResultArtifactDataV3 value)
      : value_(std::move(value)) {}

  [[nodiscard]] static Result<ResultArtifactV3> make_from_trusted_execution(
      ResultArtifactDataV3 value);

  ResultArtifactDataV3 value_;

  friend Result<PublishedResultArtifact>
  assemble_selected_result_artifact(
      const ResolvedRequest&, const ExecutionPlan&, const AnalysisBundle&,
      ResultVersionSelectionV1);
#if defined(MWPERF_C27_TEST_SEAMS)
  friend Result<ResultArtifactV3> make_result_artifact_v3_for_test(
      ResultArtifactDataV3);
#endif
};

// Closed final-publication union used by the executable.  The legacy typed
// ResultArtifact remains available unchanged to all existing callers.
class PublishedResultArtifact final {
 public:
  PublishedResultArtifact() = delete;
  PublishedResultArtifact(const PublishedResultArtifact&) = default;
  PublishedResultArtifact(PublishedResultArtifact&&) noexcept = default;
  PublishedResultArtifact& operator=(const PublishedResultArtifact&) = default;
  PublishedResultArtifact& operator=(PublishedResultArtifact&&) noexcept =
      default;

  [[nodiscard]] ResultArtifactVersionV1 version() const noexcept;
  [[nodiscard]] ResultStatusV1 status() const noexcept;
  [[nodiscard]] const
  std::variant<ResultArtifact, ResultArtifactV2, ResultArtifactV3>& value()
      const noexcept {
    return value_;
  }

 private:
  explicit PublishedResultArtifact(ResultArtifact value)
      : value_(std::move(value)) {}
  explicit PublishedResultArtifact(ResultArtifactV2 value)
      : value_(std::move(value)) {}
  explicit PublishedResultArtifact(ResultArtifactV3 value)
      : value_(std::move(value)) {}

  std::variant<ResultArtifact, ResultArtifactV2, ResultArtifactV3> value_;

  friend Result<PublishedResultArtifact> assemble_selected_result_artifact(
      const ResolvedRequest&, const ExecutionPlan&, const AnalysisBundle&,
      ResultVersionSelectionV1);
};

struct ResultArtifactParseLimitsV2 final {
  std::size_t maximum_bytes;
  std::size_t maximum_nesting_depth;
  std::size_t maximum_object_entries;
  std::size_t maximum_array_entries;
  std::size_t maximum_string_bytes;
  std::size_t maximum_total_decoded_allocation_bytes;
};

[[nodiscard]] ResultArtifactParseLimitsV2
default_result_artifact_parse_limits_v2() noexcept;

// Purpose-built, immutable reader product.  Standalone comparison needs the
// authenticated observation, provider-supplied profile, decoder-consumed
// profile, and their distinct bindings.  The analysis is a recomputed typed
// value, not a mutable reconstruction of display-only JSON members.
class ParsedResultArtifactV2 final {
 public:
  ParsedResultArtifactV2(const ParsedResultArtifactV2&) = default;
  ParsedResultArtifactV2(ParsedResultArtifactV2&&) noexcept = default;
  ParsedResultArtifactV2& operator=(const ParsedResultArtifactV2&) = default;
  ParsedResultArtifactV2& operator=(ParsedResultArtifactV2&&) noexcept =
      default;

  [[nodiscard]] ResultStatusV1 status() const noexcept { return status_; }
  [[nodiscard]] const std::optional<ResultFailureV1>& failure()
      const noexcept {
    return failure_;
  }
  [[nodiscard]] const std::shared_ptr<
      const ValidatedConstructionObservationBundleV1>&
  observation() const noexcept {
    return observation_;
  }
  [[nodiscard]] const std::optional<Digest256>& analysis_digest()
      const noexcept {
    return analysis_digest_;
  }
  // Non-null only after the reader has recomputed the analysis from the
  // authenticated observation and serialized canonical option preimage and
  // proved byte-for-byte equality with the published analysis projection.
  [[nodiscard]] const std::shared_ptr<const CompressionAnalysisResultV1>&
  analysis() const noexcept {
    return analysis_;
  }
  [[nodiscard]] const std::shared_ptr<const CompressionAnalysisOptionsV1>&
  analysis_options() const noexcept {
    return analysis_options_;
  }
  [[nodiscard]] const std::shared_ptr<const SuppliedResponseProfileV1>&
  provider_supplied_profile() const noexcept {
    return provider_supplied_profile_;
  }
  [[nodiscard]] const std::optional<Digest256>&
  provider_supplied_result_digest() const noexcept {
    return provider_supplied_result_digest_;
  }
  [[nodiscard]] const std::optional<Digest256>& provider_payload_digest()
      const noexcept {
    return provider_payload_digest_;
  }
  [[nodiscard]] const std::shared_ptr<const SuppliedResponseProfileV1>&
  decoder_profile() const noexcept {
    return decoder_profile_;
  }
  [[nodiscard]] const std::optional<Digest256>& provider_result_digest()
      const noexcept {
    return provider_result_digest_;
  }
  [[nodiscard]] const std::optional<Digest256>& decoder_semantics_digest()
      const noexcept {
    return decoder_semantics_digest_;
  }
  [[nodiscard]] std::span<const std::byte> canonical_bytes() const noexcept {
    return canonical_bytes_;
  }

 private:
  ParsedResultArtifactV2(
      ResultStatusV1 status, std::optional<ResultFailureV1> failure,
      std::shared_ptr<const ValidatedConstructionObservationBundleV1>
          observation,
      std::optional<Digest256> analysis_digest,
      std::shared_ptr<const CompressionAnalysisResultV1> analysis,
      std::shared_ptr<const CompressionAnalysisOptionsV1> analysis_options,
      std::shared_ptr<const SuppliedResponseProfileV1>
          provider_supplied_profile,
      std::optional<Digest256> provider_supplied_result_digest,
      std::optional<Digest256> provider_payload_digest,
      std::shared_ptr<const SuppliedResponseProfileV1> decoder_profile,
      std::optional<Digest256> provider_result_digest,
      std::optional<Digest256> decoder_semantics_digest,
      std::vector<std::byte> canonical_bytes)
      : status_(status),
        failure_(std::move(failure)),
        observation_(std::move(observation)),
        analysis_digest_(std::move(analysis_digest)),
        analysis_(std::move(analysis)),
        analysis_options_(std::move(analysis_options)),
        provider_supplied_profile_(std::move(provider_supplied_profile)),
        provider_supplied_result_digest_(
            std::move(provider_supplied_result_digest)),
        provider_payload_digest_(std::move(provider_payload_digest)),
        decoder_profile_(std::move(decoder_profile)),
        provider_result_digest_(std::move(provider_result_digest)),
        decoder_semantics_digest_(std::move(decoder_semantics_digest)),
        canonical_bytes_(std::move(canonical_bytes)) {}

  ResultStatusV1 status_;
  std::optional<ResultFailureV1> failure_;
  std::shared_ptr<const ValidatedConstructionObservationBundleV1>
      observation_;
  std::optional<Digest256> analysis_digest_;
  std::shared_ptr<const CompressionAnalysisResultV1> analysis_;
  std::shared_ptr<const CompressionAnalysisOptionsV1> analysis_options_;
  std::shared_ptr<const SuppliedResponseProfileV1> provider_supplied_profile_;
  std::optional<Digest256> provider_supplied_result_digest_;
  std::optional<Digest256> provider_payload_digest_;
  std::shared_ptr<const SuppliedResponseProfileV1> decoder_profile_;
  std::optional<Digest256> provider_result_digest_;
  std::optional<Digest256> decoder_semantics_digest_;
  std::vector<std::byte> canonical_bytes_;

  friend Result<ParsedResultArtifactV2> parse_result_artifact_v2(
      std::span<const std::byte>, const ResultArtifactParseLimitsV2&);
};

// Purpose-built result-v3 reader product.  The CP09 envelope has no deployed
// response/profile projection.  It retains the authenticated observation,
// the deterministically reverified empirical analysis and framework plug-in
// prediction, and the provider-result binding retained by outer provenance.
class ParsedResultArtifactV3 final {
 public:
  ParsedResultArtifactV3(const ParsedResultArtifactV3&) = default;
  ParsedResultArtifactV3(ParsedResultArtifactV3&&) noexcept = default;
  ParsedResultArtifactV3& operator=(const ParsedResultArtifactV3&) = default;
  ParsedResultArtifactV3& operator=(ParsedResultArtifactV3&&) noexcept =
      default;

  [[nodiscard]] ResultStatusV1 status() const noexcept { return status_; }
  [[nodiscard]] const std::optional<ResultFailureV1>& failure()
      const noexcept {
    return failure_;
  }
  [[nodiscard]] const std::shared_ptr<
      const ValidatedConstructionObservationBundleV1>&
  observation() const noexcept {
    return observation_;
  }
  [[nodiscard]] const std::optional<Digest256>& analysis_digest()
      const noexcept {
    return analysis_digest_;
  }
  [[nodiscard]] const std::shared_ptr<const CompressionAnalysisResultV1>&
  analysis() const noexcept {
    return analysis_;
  }
  [[nodiscard]] const std::shared_ptr<const CompressionAnalysisOptionsV1>&
  analysis_options() const noexcept {
    return analysis_options_;
  }
  [[nodiscard]] const std::shared_ptr<const FrameworkEmpiricalPredictionV1>&
  framework_prediction() const noexcept {
    return framework_prediction_;
  }
  [[nodiscard]] const std::optional<Digest256>& provider_result_digest()
      const noexcept {
    return provider_result_digest_;
  }
  [[nodiscard]] std::span<const std::byte> canonical_bytes() const noexcept {
    return canonical_bytes_;
  }

 private:
  ParsedResultArtifactV3(
      ResultStatusV1 status, std::optional<ResultFailureV1> failure,
      std::shared_ptr<const ValidatedConstructionObservationBundleV1>
          observation,
      std::optional<Digest256> analysis_digest,
      std::shared_ptr<const CompressionAnalysisResultV1> analysis,
      std::shared_ptr<const CompressionAnalysisOptionsV1> analysis_options,
      std::shared_ptr<const FrameworkEmpiricalPredictionV1>
          framework_prediction,
      std::optional<Digest256> provider_result_digest,
      std::vector<std::byte> canonical_bytes)
      : status_(status),
        failure_(std::move(failure)),
        observation_(std::move(observation)),
        analysis_digest_(std::move(analysis_digest)),
        analysis_(std::move(analysis)),
        analysis_options_(std::move(analysis_options)),
        framework_prediction_(std::move(framework_prediction)),
        provider_result_digest_(std::move(provider_result_digest)),
        canonical_bytes_(std::move(canonical_bytes)) {}

  ResultStatusV1 status_;
  std::optional<ResultFailureV1> failure_;
  std::shared_ptr<const ValidatedConstructionObservationBundleV1>
      observation_;
  std::optional<Digest256> analysis_digest_;
  std::shared_ptr<const CompressionAnalysisResultV1> analysis_;
  std::shared_ptr<const CompressionAnalysisOptionsV1> analysis_options_;
  std::shared_ptr<const FrameworkEmpiricalPredictionV1>
      framework_prediction_;
  std::optional<Digest256> provider_result_digest_;
  std::vector<std::byte> canonical_bytes_;

  friend Result<ParsedResultArtifactV3> parse_result_artifact_v3(
      std::span<const std::byte>, const ResultArtifactParseLimitsV2&);
};

// F-C27-05
[[nodiscard]] Result<ResultArtifact> assemble_result_artifact(
    const ResolvedRequest& request, const ExecutionPlan& plan,
    const AnalysisBundle& analysis);

// Selects the independently versioned final publication contract.  Automatic
// selection keeps legacy routes on v1 and upgrades any authenticated
// observation supplement to v2.  An explicit v1 selection is rejected when
// it would discard that supplement.
[[nodiscard]] Result<PublishedResultArtifact>
assemble_selected_result_artifact(
    const ResolvedRequest& request, const ExecutionPlan& plan,
    const AnalysisBundle& analysis, ResultVersionSelectionV1 selection);

// F-C27-06
[[nodiscard]] Result<void> write_result_artifact(
    const ResultArtifact& artifact, const std::filesystem::path& path);

[[nodiscard]] Result<void> write_published_result_artifact(
    const PublishedResultArtifact& artifact,
    const std::filesystem::path& path);

// Separate standalone F7 artifact; it is never nested into a provider-run
// result-v2 or used as a surrogate/capability input.
[[nodiscard]] Result<void> write_compression_comparison_artifact_v1(
    const ThreeRecordErrorSeparationV1& comparison,
    const std::filesystem::path& path);

// Closed bounded result-v2 reader used by standalone comparison tooling.  It
// validates the embedded observation digest and all typed result invariants;
// result-v1 remains intentionally outside this new parser API.
[[nodiscard]] Result<ParsedResultArtifactV2> parse_result_artifact_v2(
    std::span<const std::byte> bytes,
    const ResultArtifactParseLimitsV2& limits);

// Closed bounded result-v3 reader.  A pre-observation failure is returned as
// a typed terminal with no observation; an observed terminal is exposed only
// after the embedded analysis has been recomputed from the authenticated
// observation and complete effective option preimage.
[[nodiscard]] Result<ParsedResultArtifactV3> parse_result_artifact_v3(
    std::span<const std::byte> bytes,
    const ResultArtifactParseLimitsV2& limits);

#if defined(MWPERF_C27_TEST_SEAMS)
enum class ResultPublicationFailurePointV1 : std::uint8_t {
  none,
  open,
  write,
  flush,
  close,
  rename,
};

// Fixture-only entry points.  The production writer always uses `none` and
// exposes no ambient/global fault switch.
[[nodiscard]] Result<ResultArtifact> make_result_artifact_for_test(
    ResultArtifactDataV1 value);
[[nodiscard]] Result<ResultArtifactV2> make_result_artifact_v2_for_test(
    ResultArtifactDataV2 value);
[[nodiscard]] Result<ResultArtifactV3> make_result_artifact_v3_for_test(
    ResultArtifactDataV3 value);
[[nodiscard]] Result<std::string>
canonical_result_artifact_v2_json_for_test(
    const ResultArtifactV2& artifact);
[[nodiscard]] Result<std::string>
canonical_result_artifact_v3_json_for_test(
    const ResultArtifactV3& artifact);
[[nodiscard]] Result<void> validate_result_v2_json_schema_for_test(
    std::string_view document);
[[nodiscard]] Result<void> validate_result_v3_json_schema_for_test(
    std::string_view document);
[[nodiscard]] Result<void>
validate_compression_comparison_v1_json_schema_for_test(
    std::string_view document);
[[nodiscard]] Result<void> write_result_artifact_with_failure_for_test(
    const ResultArtifact& artifact, const std::filesystem::path& path,
    ResultPublicationFailurePointV1 failure_point);
#endif

}  // namespace mwperf
