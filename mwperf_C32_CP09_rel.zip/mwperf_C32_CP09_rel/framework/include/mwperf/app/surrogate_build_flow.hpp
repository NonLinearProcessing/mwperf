#pragma once

#include <chrono>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/app/result_artifact.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/diagnostics/compression_analysis.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf {

class ExecutionPlan;
class AnalysisBundle;

namespace detail {
[[nodiscard]] AnalysisBundle execute_analysis_from(
    const ExecutionPlan& plan,
    std::chrono::steady_clock::time_point invocation_started_at);
}

#if defined(MWPERF_C27_TEST_SEAMS)
namespace testing {
class C27AnalysisBundleFixtureFactory;
}
#endif

// C15 is the sole issuer of these three correlated values.  Keeping them in
// one optional aggregate makes the sole pre-request failure state explicit;
// no caller can accidentally combine a build identity with a seed or final
// request digest minted by another invocation.
struct AnalysisBuildRequestIdentityV1 final {
  BuildIdentityDigest build_identity_digest;
  BuildSeed build_seed;
  SurrogateBuildRequestDigest build_request_digest;

  friend bool operator==(const AnalysisBuildRequestIdentityV1&,
                         const AnalysisBuildRequestIdentityV1&) = default;
};

// Immutable cross-boundary identity copied only from the frozen plan and the
// one C15 request returned during execution.  Payload fields remain absent on
// a validated wire Unavailable/Failed branch.
struct AnalysisExecutionIdentityV1 final {
  InputFingerprintBundle fingerprints;
  ProviderIdentityV1 provider;
  ProviderScientificContractDigest provider_digest;
  Digest256 accepted_contract_digest;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  MasterSeed master_seed;
  std::optional<AnalysisBuildRequestIdentityV1> request_identity;
  std::optional<Digest256> payload_digest;
  std::optional<std::string> plug_kind;
  std::vector<QueueId> ordered_targets;
  PortableAnalysisSelectionV1 selection;
  MetricSolverRegimeV1 solver_regime;
  std::vector<std::string> metric_ids;
  std::vector<BackendRouteKindV1> backend_routes;
  std::optional<Digest256> execution_seal_digest;

  friend bool operator==(const AnalysisExecutionIdentityV1&,
                         const AnalysisExecutionIdentityV1&) = default;
};

struct AnalysisWallClockTimesV1 final {
  std::chrono::nanoseconds end_to_end;
  std::chrono::nanoseconds sampler;
  std::chrono::nanoseconds framework;

  friend bool operator==(const AnalysisWallClockTimesV1&,
                         const AnalysisWallClockTimesV1&) = default;
};

// The deployed scalar response used by the analytic queue solver.  Keeping
// the four conditioning regions together prevents the constant-tail
// coefficient from being lost when no individual metric requests level 3.
struct AnalysisResponseCurveV1 final {
  QueueId target;
  ExactRational backlog_zero;
  ExactRational backlog_one;
  ExactRational backlog_two;
  ExactRational backlog_at_least_three;

  friend bool operator==(const AnalysisResponseCurveV1&,
                         const AnalysisResponseCurveV1&) = default;
};

// The observation plane is descriptive and cannot strengthen the deployed
// metric result.  This status records only how far the deployed decoder path
// progressed, so an absent decoder profile is never confused with an
// empirical zero response.
enum class AnalysisDecoderProfileStatusV2 : std::uint8_t {
  not_applicable,
  not_reached,
  available,
  rejected,
};

// The provider-authored finite-prefix profile is retained before any
// framework payload adaptation.  It is deliberately distinct from the
// decoder-consumed profile below: an adapter is allowed to reject or
// transform the provider payload, and result-v2 must make that gap visible.
enum class AnalysisProviderSuppliedProfileStatusV2 : std::uint8_t {
  not_applicable,
  not_reached,
  available,
  rejected,
};

struct AnalysisProviderSuppliedProfileV2 final {
  AnalysisProviderSuppliedProfileStatusV2 status;
  std::optional<SuppliedResponseProfileV1> profile;
  std::optional<std::string> reason_code;
  // Present exactly with an available raw profile.  These bind the profile
  // to its authenticated observation, exact canonical provider-result-v2
  // bytes, and validated Built payload respectively.
  std::optional<Digest256> observation_digest{};
  std::optional<Digest256> provider_result_digest{};
  std::optional<Digest256> payload_digest{};

  friend bool operator==(const AnalysisProviderSuppliedProfileV2&,
                         const AnalysisProviderSuppliedProfileV2&) = default;
};

struct AnalysisDecoderProfileV2 final {
  AnalysisDecoderProfileStatusV2 status;
  std::optional<SuppliedResponseProfileV1> profile;
  std::optional<std::string> reason_code;
  // Present exactly with an available decoder-consumed profile.  The first
  // binds the exact canonical provider-result-v2 bytes; the second is the
  // accepted provider scientific-contract digest whose transform semantics
  // the deployed decoder consumed.
  std::optional<Digest256> provider_result_digest{};
  std::optional<Digest256> decoder_semantics_digest{};

  friend bool operator==(const AnalysisDecoderProfileV2&,
                         const AnalysisDecoderProfileV2&) = default;
};

// Terminal context is intentionally separate from the diagnostic analysis.
// It explains why a valid observation may accompany an Unavailable or Failed
// main result without allowing that observation to alter the main status.
struct AnalysisDiagnosticTerminalV2 final {
  ResultStatusV1 main_status;
  std::optional<ResultFailureStageV1> failure_stage;
  std::optional<std::string> code;

  friend bool operator==(const AnalysisDiagnosticTerminalV2&,
                         const AnalysisDiagnosticTerminalV2&) = default;
};

// Immutable, shared F6 carrier.  The validated body and successful analysis
// each have one owner irrespective of how many terminal-path/result wrappers
// are copied.  A local analysis failure is retained instead of suppressing
// the observation or changing the main metric status.  AnalysisBundle stores
// no instance at all when diagnostics were not requested or no authenticated
// observation envelope was established.
class AnalysisDiagnosticSupplementV2 final {
 public:
  AnalysisDiagnosticSupplementV2(
      std::shared_ptr<const ValidatedConstructionObservationBundleV1>
          observation,
      std::shared_ptr<const CompressionAnalysisResultV1> analysis,
      std::optional<Diagnostic> analysis_failure,
      AnalysisProviderSuppliedProfileV2 provider_supplied_profile,
      AnalysisDecoderProfileV2 decoder_profile,
      AnalysisDiagnosticTerminalV2 terminal,
      CompressionAnalysisOptionsV1 analysis_options = {},
      std::optional<Digest256> source_provider_result_digest = std::nullopt)
      : observation_(std::move(observation)),
        analysis_(std::move(analysis)),
        analysis_failure_(std::move(analysis_failure)),
        provider_supplied_profile_(std::move(provider_supplied_profile)),
        decoder_profile_(std::move(decoder_profile)),
        terminal_(std::move(terminal)),
        analysis_options_(std::move(analysis_options)),
        source_provider_result_digest_(
            std::move(source_provider_result_digest)) {}

  [[nodiscard]] const std::shared_ptr<
      const ValidatedConstructionObservationBundleV1>&
  observation() const noexcept {
    return observation_;
  }
  [[nodiscard]] const std::shared_ptr<const CompressionAnalysisResultV1>&
  analysis() const noexcept {
    return analysis_;
  }
  [[nodiscard]] const std::optional<Diagnostic>& analysis_failure()
      const noexcept {
    return analysis_failure_;
  }
  [[nodiscard]] const AnalysisProviderSuppliedProfileV2&
  provider_supplied_profile() const noexcept {
    return provider_supplied_profile_;
  }
  [[nodiscard]] const AnalysisDecoderProfileV2& decoder_profile()
      const noexcept {
    return decoder_profile_;
  }
  [[nodiscard]] const AnalysisDiagnosticTerminalV2& terminal()
      const noexcept {
    return terminal_;
  }
  // Requested options are retained with the in-process result.  Publication
  // resolves these against the authenticated initialization descriptor and
  // serializes the canonical effective options used by the analysis digest.
  [[nodiscard]] const CompressionAnalysisOptionsV1& analysis_options()
      const noexcept {
    return analysis_options_;
  }
  [[nodiscard]] const std::optional<Digest256>& source_provider_result_digest()
      const noexcept {
    return source_provider_result_digest_;
  }

 private:
  std::shared_ptr<const ValidatedConstructionObservationBundleV1>
      observation_;
  std::shared_ptr<const CompressionAnalysisResultV1> analysis_;
  std::optional<Diagnostic> analysis_failure_;
  AnalysisProviderSuppliedProfileV2 provider_supplied_profile_;
  AnalysisDecoderProfileV2 decoder_profile_;
  AnalysisDiagnosticTerminalV2 terminal_;
  CompressionAnalysisOptionsV1 analysis_options_;
  std::optional<Digest256> source_provider_result_digest_;
};

// Transactional F-C27-04 result.  Numeric metric values can inhabit only a
// success bundle.  A failed bundle retains its evidence ledger but never the
// locally staged values from an earlier backend, while an unavailable bundle
// carries only unavailable metric entries.
class AnalysisBundle final {
 public:
  AnalysisBundle() = delete;
  AnalysisBundle(const AnalysisBundle&) = default;
  AnalysisBundle(AnalysisBundle&&) noexcept = default;
  AnalysisBundle& operator=(const AnalysisBundle&) = default;
  AnalysisBundle& operator=(AnalysisBundle&&) noexcept = default;

  [[nodiscard]] ResultStatusV1 status() const noexcept { return status_; }
  [[nodiscard]] const std::optional<ResultFailureV1>& failure() const
      noexcept {
    return failure_;
  }
  [[nodiscard]] const AnalysisExecutionIdentityV1& execution_identity()
      const noexcept {
    return execution_identity_;
  }
  [[nodiscard]] const std::optional<CommonBuildReportV1>& build_report()
      const noexcept {
    return build_report_;
  }
  [[nodiscard]] std::span<const ResultMetricV1> metrics() const noexcept {
    return metrics_;
  }
  [[nodiscard]] const std::optional<AnalysisResponseCurveV1>& response_curve()
      const noexcept {
    return response_curve_;
  }
  [[nodiscard]] const std::optional<ResultUnavailableDiagnosticsV1>&
  unavailable_diagnostics() const noexcept {
    return unavailable_diagnostics_;
  }
  [[nodiscard]] std::span<const ResultCertificateV1> certificates() const
      noexcept {
    return certificates_;
  }
  [[nodiscard]] std::span<const ResultDiagnosticV1> diagnostics() const
      noexcept {
    return diagnostics_;
  }
  [[nodiscard]] std::span<const ResultBudgetUsageV1>
  execution_budget_usage() const noexcept {
    return execution_budget_usage_;
  }
  [[nodiscard]] std::span<const ResultBudgetUsageV1>
  backend_budget_usage() const noexcept {
    return backend_budget_usage_;
  }
  [[nodiscard]] std::span<const ResultReplayStreamV1> replay_streams() const
      noexcept {
    return replay_streams_;
  }
  [[nodiscard]] const AnalysisWallClockTimesV1& wall_clock_times() const
      noexcept {
    return wall_clock_times_;
  }
  [[nodiscard]] const BigNat& optimizer_calls_observed() const noexcept {
    return optimizer_calls_observed_;
  }
  [[nodiscard]] const BigNat& optimizer_search_states_observed()
      const noexcept {
    return optimizer_search_states_observed_;
  }
  [[nodiscard]] const std::shared_ptr<const AnalysisDiagnosticSupplementV2>&
  diagnostic_supplement() const noexcept {
    return diagnostic_supplement_;
  }

 private:
  AnalysisBundle(
      ResultStatusV1 status, std::optional<ResultFailureV1> failure,
      AnalysisExecutionIdentityV1 execution_identity,
      std::optional<CommonBuildReportV1> build_report,
      std::optional<AnalysisResponseCurveV1> response_curve,
      std::optional<ResultUnavailableDiagnosticsV1> unavailable_diagnostics,
      std::vector<ResultMetricV1> metrics,
      std::vector<ResultCertificateV1> certificates,
      std::vector<ResultDiagnosticV1> diagnostics,
      std::vector<ResultBudgetUsageV1> execution_budget_usage,
      std::vector<ResultBudgetUsageV1> backend_budget_usage,
      std::vector<ResultReplayStreamV1> replay_streams,
      AnalysisWallClockTimesV1 wall_clock_times,
      BigNat optimizer_calls_observed,
      BigNat optimizer_search_states_observed,
      std::shared_ptr<const AnalysisDiagnosticSupplementV2>
          diagnostic_supplement = {})
      : status_(status),
        failure_(std::move(failure)),
        execution_identity_(std::move(execution_identity)),
        build_report_(std::move(build_report)),
        response_curve_(std::move(response_curve)),
        unavailable_diagnostics_(std::move(unavailable_diagnostics)),
        metrics_(std::move(metrics)),
        certificates_(std::move(certificates)),
        diagnostics_(std::move(diagnostics)),
        execution_budget_usage_(std::move(execution_budget_usage)),
        backend_budget_usage_(std::move(backend_budget_usage)),
        replay_streams_(std::move(replay_streams)),
        wall_clock_times_(wall_clock_times),
        optimizer_calls_observed_(std::move(optimizer_calls_observed)),
        optimizer_search_states_observed_(
            std::move(optimizer_search_states_observed)),
        diagnostic_supplement_(std::move(diagnostic_supplement)) {}

  ResultStatusV1 status_;
  std::optional<ResultFailureV1> failure_;
  AnalysisExecutionIdentityV1 execution_identity_;
  std::optional<CommonBuildReportV1> build_report_;
  std::optional<AnalysisResponseCurveV1> response_curve_;
  std::optional<ResultUnavailableDiagnosticsV1> unavailable_diagnostics_;
  std::vector<ResultMetricV1> metrics_;
  std::vector<ResultCertificateV1> certificates_;
  std::vector<ResultDiagnosticV1> diagnostics_;
  std::vector<ResultBudgetUsageV1> execution_budget_usage_;
  std::vector<ResultBudgetUsageV1> backend_budget_usage_;
  std::vector<ResultReplayStreamV1> replay_streams_;
  AnalysisWallClockTimesV1 wall_clock_times_;
  BigNat optimizer_calls_observed_;
  BigNat optimizer_search_states_observed_;
  std::shared_ptr<const AnalysisDiagnosticSupplementV2>
      diagnostic_supplement_;

  friend AnalysisBundle execute_analysis(const ExecutionPlan& plan);
  friend AnalysisBundle detail::execute_analysis_from(
      const ExecutionPlan& plan,
      std::chrono::steady_clock::time_point invocation_started_at);
#if defined(MWPERF_C27_TEST_SEAMS)
  friend class testing::C27AnalysisBundleFixtureFactory;
#endif
};

// F-C27-04.  All ordinary post-plan failures are represented by the returned
// closed bundle; the function never publishes a partially successful metric
// set.
[[nodiscard]] AnalysisBundle execute_analysis(const ExecutionPlan& plan);

#if defined(MWPERF_C27_TEST_SEAMS)
namespace testing {

// Read-only classifier seam. It cannot construct a bundle or alter execution;
// it exists so C27 can lock the fail-closed terminal boundary independently
// of any one backend fixture.
[[nodiscard]] bool is_permitted_backend_scientific_unavailability(
    const Diagnostic& diagnostic) noexcept;

}  // namespace testing
#endif

}  // namespace mwperf
