#pragma once

#include <array>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class MetricSupportManifest;

// These are the nine mathematical objects admitted by the version-1
// surrogate boundary.  A finite-cylinder view is deliberately absent: it is
// a bounded view derived from temporal_one_slot_continuation, not a tenth
// provider semantic.
enum class SemanticTagV1 : std::uint8_t {
  scalar_backlog_response,
  stationary_marked_edge,
  staged_opportunity_flux_law,
  temporal_one_slot_continuation,
  romr_residence_word_law,
  stopped_path_law,
  coupled_target_schedule_law,
  direct_metric_decoder,
  response_envelope_law,
};

inline constexpr std::array<SemanticTagV1, 9U> kSemanticTagsV1{
    SemanticTagV1::scalar_backlog_response,
    SemanticTagV1::stationary_marked_edge,
    SemanticTagV1::staged_opportunity_flux_law,
    SemanticTagV1::temporal_one_slot_continuation,
    SemanticTagV1::romr_residence_word_law,
    SemanticTagV1::stopped_path_law,
    SemanticTagV1::coupled_target_schedule_law,
    SemanticTagV1::direct_metric_decoder,
    SemanticTagV1::response_envelope_law,
};

[[nodiscard]] constexpr std::span<const SemanticTagV1, 9U>
all_semantic_tags_v1() noexcept {
  return kSemanticTagsV1;
}

// Runtime representation is independent of the semantic object and of the
// scientific procedure used to construct it.
enum class RuntimeAccessTagV1 : std::uint8_t {
  finite_enumerated_row,
  sparse_row,
  normalized_conditional_sampler,
  analytic_transform,
  finite_parameter_analytic_family,
  procedural_residence_generator,
  direct_metric_decoder,
};

inline constexpr std::array<RuntimeAccessTagV1, 7U> kRuntimeAccessTagsV1{
    RuntimeAccessTagV1::finite_enumerated_row,
    RuntimeAccessTagV1::sparse_row,
    RuntimeAccessTagV1::normalized_conditional_sampler,
    RuntimeAccessTagV1::analytic_transform,
    RuntimeAccessTagV1::finite_parameter_analytic_family,
    RuntimeAccessTagV1::procedural_residence_generator,
    RuntimeAccessTagV1::direct_metric_decoder,
};

[[nodiscard]] constexpr std::span<const RuntimeAccessTagV1, 7U>
all_runtime_access_tags_v1() noexcept {
  return kRuntimeAccessTagsV1;
}

// These two axes are retained here because a callback-free C14 preview must
// bind them before C15/C16 exist.  Neither enum is convertible to a semantic
// or runtime-access tag.
enum class ConstructionMethodV1 : std::uint8_t {
  closed_form,
  engineered_deterministic,
  engineered_hybrid,
  sampled_offline,
  precomputed,
};

enum class ProducerModeV1 : std::uint8_t {
  inline_immediate,
  in_process_builder,
  local_executable_builder,
};

enum class PayloadClassTagV1 : std::uint8_t {
  three_bin_scalar_response_v1,
  finite_parameter_analytic_data_v1,
  finite_law_tables_v1,
  registered_runtime_recipe_v1,
  response_envelope_evidence_v1,
  direct_metric_payload_v1,
  finite_prefix_constant_tail_response_v1,
  // Observation-only CP09 response profile.  This is deliberately distinct
  // from a deployable finite-prefix payload: provider-result-v3 may report it
  // only through the successful Observed terminal.
  empirical_finite_window_response_v1,
};

struct PayloadClassV1 final {
  PayloadClassTagV1 tag;
  std::uint32_t version;

  friend bool operator==(const PayloadClassV1&,
                         const PayloadClassV1&) = default;
};

struct ProviderIdentityV1 final {
  std::string provider_id;
  std::string provider_version;

  friend bool operator==(const ProviderIdentityV1&,
                         const ProviderIdentityV1&) = default;
};

enum class TargetCouplingV1 : std::uint8_t {
  scalar_target,
  common_schedule_projection,
  full_schedule_identity,
};

// C14's metric reveal vocabulary is intentionally distinct from C12's
// three-stage PhysicalEdge::RevealStage.  entrance_label is not ordered with
// the ordinary within-slot stages and must be matched explicitly.
enum class MetricRevealStageV1 : std::uint8_t {
  predecision,
  decision,
  arrival,
  postarrival,
  completed_edge,
  entrance_label,
};

enum class MetricMarkKindV1 : std::uint8_t {
  target_backlog,
  predictive_phase,
  opportunity,
  actual_departure,
  arrival_batch,
  successor_backlog,
  schedule_projection,
  full_schedule,
  edge_increment,
  event_indicator,
  predicate,
  predicate_start,
  active_component,
  within_batch_rank,
  batch_size,
  class_label,
  phase_label,
  counterfactual_permission,
};

enum class StateFieldKindV1 : std::uint8_t {
  target_backlog,
  configured_arrival_predictive_phase,
  surrogate_phase,
  controller_memory,
  resource_coordinate,
  local_margin,
  event_state,
  entrance_label_state,
};

enum class FieldOwnershipV1 : std::uint8_t {
  framework_exact,
  surrogate_owned,
};

struct CodecIdentityV1 final {
  std::string id;
  std::uint32_t version;

  friend bool operator==(const CodecIdentityV1&,
                         const CodecIdentityV1&) = default;
};

struct StateFieldDescriptorV1 final {
  StateFieldKindV1 kind;
  FieldOwnershipV1 ownership;
  CodecIdentityV1 codec;

  friend bool operator==(const StateFieldDescriptorV1&,
                         const StateFieldDescriptorV1&) = default;
};

struct MarkDescriptorV1 final {
  MetricMarkKindV1 kind;
  MetricRevealStageV1 reveal_stage;
  CodecIdentityV1 codec;
  // Equal nonempty groups assert that several marks are decoded from one
  // common slot/entrance realization.  The identifier has descriptor-local
  // scope and is never an artifact/product identity.
  std::string common_realization_group;

  friend bool operator==(const MarkDescriptorV1&,
                         const MarkDescriptorV1&) = default;
};

enum class SelectionKindV1 : std::uint8_t {
  transient_initial,
  stationary_unique,
  stationary_class,
  stationary_mixture,
  fixed_point_unique,
  fixed_point_id,
  prescribed_entrance,
  event_palm,
  start_palm,
  admission_palm,
  threshold_crossing_palm,
};

struct SelectionSupportV1 final {
  std::vector<SelectionKindV1> kinds;
  // Named values are a finite descriptor domain, not a fallback selection.
  std::vector<TypedLabel> named_classes;
  std::vector<TypedLabel> named_fixed_points;

  friend bool operator==(const SelectionSupportV1&,
                         const SelectionSupportV1&) = default;
};

enum class PayloadPhaseKindV1 : std::uint8_t {
  phase_free,
  predictive_phase_indexed,
};

enum class ConfiguredArrivalCompositionV1 : std::uint8_t {
  no_arrival_composition,
  iid_late_arrival,
  finite_enumerated_predictive_phase,
  sequential_predictive_phase,
};

enum class FiniteHorizonCoverageKindV1 : std::uint8_t {
  none,
  bounded,
  every_finite_horizon,
};

struct PhaseSupportV1 final {
  PayloadPhaseKindV1 payload_phase;
  ConfiguredArrivalCompositionV1 arrival_composition;
  bool retains_configured_predictive_phase;
  std::optional<CodecIdentityV1> predictive_phase_codec;
  FiniteHorizonCoverageKindV1 finite_horizon_coverage;
  std::optional<BigNat> maximum_finite_horizon;

  friend bool operator==(const PhaseSupportV1&,
                         const PhaseSupportV1&) = default;
};

enum class TailRepresentationKindV1 : std::uint8_t {
  none,
  finite_closed,
  constant_response,
  certified_truncation,
  exact_unbounded,
};

struct TailSupportV1 final {
  TailRepresentationKindV1 kind;
  std::optional<BigNat> boundary;
  std::optional<ExactRational> certified_tail_mass;

  friend bool operator==(const TailSupportV1&,
                         const TailSupportV1&) = default;
};

enum class ArrivalNeedKindV1 : std::uint8_t {
  target_intensity,
  arrival_moment,
  full_common_batch,
  predictive_phase,
  sequential_law,
  entrance_labels,
  finite_support,
  transform,
  exact_iid_late,
};

enum class ArrivalCapabilityUseV1 : std::uint8_t {
  runtime,
  construction,
};

enum class CapabilityProvisionNeedV1 : std::uint8_t {
  any,
  portable,
  process_local,
};

struct ArrivalAssumptionV1 final {
  ArrivalNeedKindV1 kind;
  ArrivalCapabilityUseV1 use;
  CapabilityProvisionNeedV1 provision;
  std::optional<BigNat> moment_order;
  bool joint;
  bool phase_conditioned;
  std::optional<TransformKind> transform_kind;
  std::optional<DistributionScope> distribution_scope;
  std::optional<ExactArgumentDomain> argument_domain;

  friend bool operator==(const ArrivalAssumptionV1&,
                         const ArrivalAssumptionV1&) = default;
};

enum class HypothesisKindV1 : std::uint8_t {
  proper_stationary,
  invariant_selected,
  stable,
  recurrent,
  lossless,
  unit_packets,
  fifo,
  eventual_departure_or_accessible_class,
  positive_finite_intensity,
  positive_event_intensity,
  positive_start_intensity,
  positive_conditioning_mass,
  moment_finite,
  reward_integrable,
  little_law,
  finite_start_component,
  absorption,
  nondefective,
  common_schedule,
  predictive_phase,
  iid_late_arrival,
  counterfactual_empty_convention,
  counterfactual_no_controller_mutation,
  c21_suspension_inversion,
};

enum class MomentVariableV1 : std::uint8_t {
  arrival,
  backlog,
  departure,
  edge_reward,
  fifo_delay,
  event_gap,
  binary_run,
  stopped_time,
};

struct HypothesisClaimV1 final {
  HypothesisKindV1 kind;
  std::optional<MomentVariableV1> variable;
  std::optional<BigNat> order;
  std::optional<TypedLabel> convention_or_class;

  friend bool operator==(const HypothesisClaimV1&,
                         const HypothesisClaimV1&) = default;
};

enum class SolverRegimeV1 : std::uint8_t {
  enumerated,
  analytic,
  monte_carlo,
  direct,
};

enum class DeterministicToleranceKindV1 : std::uint8_t {
  linear_residual_abs,
  integration_abs,
  tail_abs,
  fixed_point_abs,
};

struct DeterministicToleranceV1 final {
  DeterministicToleranceKindV1 kind;
  ExactRational maximum_absolute_error;

  friend bool operator==(const DeterministicToleranceV1&,
                         const DeterministicToleranceV1&) = default;
};

enum class StatisticalIntervalKindV1 : std::uint8_t {
  exact_binomial,
  hoeffding,
  none,
};

enum class StatisticalEstimandKindV1 : std::uint8_t {
  binary_proportion,
  bounded_iid,
  point_with_variance_diagnostics,
};

struct EnumeratedAccuracyV1 final {
  std::vector<DeterministicToleranceV1> tolerances;

  friend bool operator==(const EnumeratedAccuracyV1&,
                         const EnumeratedAccuracyV1&) = default;
};

struct AnalyticAccuracyV1 final {
  BigNat precision_bits;
  std::vector<DeterministicToleranceV1> tolerances;

  friend bool operator==(const AnalyticAccuracyV1&,
                         const AnalyticAccuracyV1&) = default;
};

struct MonteCarloAccuracyV1 final {
  BigNat replications;
  ExactRational confidence_level;
  StatisticalIntervalKindV1 interval;
  StatisticalEstimandKindV1 estimand;
  std::optional<ExactRational> almost_sure_lower;
  std::optional<ExactRational> almost_sure_upper;

  friend bool operator==(const MonteCarloAccuracyV1&,
                         const MonteCarloAccuracyV1&) = default;
};

struct DirectExactAccuracyV1 final {
  friend bool operator==(const DirectExactAccuracyV1&,
                         const DirectExactAccuracyV1&) = default;
};

using AccuracyContractV1 =
    std::variant<EnumeratedAccuracyV1, AnalyticAccuracyV1,
                 MonteCarloAccuracyV1, DirectExactAccuracyV1>;

enum class V0DeclarationKindV1 : std::uint8_t {
  absent,
  structural_witness_required,
};

struct V0DeclarationV1 final {
  V0DeclarationKindV1 kind;
  std::string factor_schema_id;
  std::uint32_t factor_schema_version;

  friend bool operator==(const V0DeclarationV1&,
                         const V0DeclarationV1&) = default;
};

enum class OptionalReportedEvidenceKindV1 : std::uint8_t {
  v1_fibre_realizability,
  v2_dynamic_lift,
  physical_fidelity,
  empirical_validation,
};

struct OptionalReportedEvidenceV1 final {
  OptionalReportedEvidenceKindV1 kind;
  std::string witness_schema_id;
  std::uint32_t witness_schema_version;

  friend bool operator==(const OptionalReportedEvidenceV1&,
                         const OptionalReportedEvidenceV1&) = default;
};

// Every policy is an explicit closed value.  In particular, not_applicable is
// a real alternative and is never represented by an absent field or ambient
// provider default.
enum class PointDeploymentPolicyV1 : std::uint8_t {
  not_applicable,
  deploy_raw_point,
  deploy_nominal_point,
  deploy_recoded_point,
};

enum class CoefficientCompletionPolicyV1 : std::uint8_t {
  not_applicable,
  require_complete_raw_points,
  declared_nominal_completion,
  authorized_endpoint_completion,
};

enum class ProjectionPolicyV1 : std::uint8_t {
  not_applicable,
  identity,
  convex_feasible_mean,
};

enum class RecodingPolicyV1 : std::uint8_t {
  not_applicable,
  identity,
  mean_inversion,
};

enum class EvidenceRolePolicyV1 : std::uint8_t {
  not_applicable,
  exact_manifest_roles,
};

struct PreviewPoliciesV1 final {
  PointDeploymentPolicyV1 point_deployment;
  CoefficientCompletionPolicyV1 coefficient_completion;
  ProjectionPolicyV1 projection;
  RecodingPolicyV1 recoding;
  EvidenceRolePolicyV1 evidence_roles;

  friend bool operator==(const PreviewPoliciesV1&,
                         const PreviewPoliciesV1&) = default;
};

struct ConstructionPrerequisitesV1 final {
  std::vector<ArrivalAssumptionV1> arrival;
  std::optional<BigNat> required_optimizer_calls;
  std::optional<BigNat> required_generator_draws;
  std::optional<BigNat> required_search_states_per_call;

  friend bool operator==(const ConstructionPrerequisitesV1&,
                         const ConstructionPrerequisitesV1&) = default;
};

struct SchedulerConstraintPairV1 final {
  ServiceFamily service_family;
  OptimizerId optimizer;

  friend bool operator==(const SchedulerConstraintPairV1&,
                         const SchedulerConstraintPairV1&) = default;
};

// The pair list is canonical and preserves the fact that applicability is a
// relation, not the Cartesian product of two independently advertised sets.
// Timing values are a separate closed axis because the same pair may be
// registered only for a subset of framework timing conventions.
struct SchedulerConstraintApplicabilityV1 final {
  std::vector<SchedulerConstraintPairV1> scheduler_optimizer_pairs;
  std::vector<TimingConvention> timing_conventions;

  friend bool operator==(const SchedulerConstraintApplicabilityV1&,
                         const SchedulerConstraintApplicabilityV1&) = default;
};

enum class ConstructionResultScopeV1 : std::uint8_t {
  not_applicable,
  not_a_metric_result,
  surrogate_law,
  proposal_raw,
  response_envelope,
  physical_bound,
};

enum class ConstructionErrorScopeV1 : std::uint8_t {
  none,
  raw_static_proposal,
  nominal_static_proposal,
  projection_center,
  projected_surrogate_mean,
  recoded_static_proposal,
  optimizer_interval_raw,
  deployed_surrogate_law,
  numerical_result,
  validity_or_lift,
  physical_system,
};

struct ConstructionScopeClaimV1 final {
  ConstructionResultScopeV1 result_scope;
  ConstructionErrorScopeV1 error_scope;

  friend bool operator==(const ConstructionScopeClaimV1&,
                         const ConstructionScopeClaimV1&) = default;
};

// Callback-free structural descriptor shared by planning, artifact
// validation, and the later callback-bearing C16 plug.  The manifest is kept
// outside this record to avoid a schema include cycle; its digest is included
// here and PlugDescriptorPreview retains the immutable value itself.
struct PlugDescriptorCore final {
  std::uint32_t schema_version;
  ProviderIdentityV1 provider;
  SchedulerConstraintApplicabilityV1 applicability;
  PayloadClassV1 payload_class;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  std::vector<QueueId> deployed_targets;
  TargetCouplingV1 target_coupling;
  std::vector<StateFieldDescriptorV1> state_fields;
  std::vector<MarkDescriptorV1> marks;
  SelectionSupportV1 selection;
  PhaseSupportV1 phase;
  TailSupportV1 tail;
  std::vector<ArrivalAssumptionV1> arrival_assumptions;
  std::vector<HypothesisClaimV1> hypothesis_claims;
  V0DeclarationV1 mandatory_v0;
  std::vector<OptionalReportedEvidenceV1> optional_reported_evidence;
  std::vector<AccuracyContractV1> accuracy_support;
  ConstructionScopeClaimV1 construction_scope;
  Digest256 metric_support_manifest_digest;
  Digest256 core_digest;

  friend bool operator==(const PlugDescriptorCore&,
                         const PlugDescriptorCore&) = default;
};

// Parameter-resolved planning value.  It owns the manifest through immutable
// shared backing so the descriptor vocabulary can remain acyclic; snapshots
// and accepted contracts copy the manifest value, never the pointer identity.
struct PlugDescriptorPreview final {
  std::uint32_t schema_version;
  PlugDescriptorCore core;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  std::vector<QueueId> construction_target_scope;
  PreviewPoliciesV1 policies;
  ConstructionPrerequisitesV1 construction_prerequisites;
  std::shared_ptr<const MetricSupportManifest> metric_support_manifest;
  Digest256 problem_view_digest;
  Digest256 parameter_digest;
  Digest256 budget_digest;
  Digest256 preview_digest;

  // Defined where MetricSupportManifest is complete so equality compares the
  // canonical manifest value, never shared_ptr ownership or digest alone.
  friend bool operator==(const PlugDescriptorPreview&,
                         const PlugDescriptorPreview&);
};

// Canonical construction helpers deliberately recompute the corresponding
// public integrity fields rather than trusting core_digest or preview_digest.
// The core digest binds metric_support_manifest_digest; the preview digest
// additionally binds the complete canonical manifest value through that
// digest and all parameter-resolved preview fields.
[[nodiscard]] Result<Digest256> canonical_plug_descriptor_core_digest_v1(
    const PlugDescriptorCore& core);
[[nodiscard]] Result<Digest256> canonical_plug_descriptor_preview_digest_v1(
    const PlugDescriptorPreview& preview);
[[nodiscard]] Result<Digest256> canonical_arrival_capabilities_digest_v1(
    const ArrivalCapabilities& capabilities);

}  // namespace mwperf
