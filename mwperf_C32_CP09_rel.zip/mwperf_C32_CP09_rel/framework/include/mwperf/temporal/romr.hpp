#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/causal_kernel_compiler.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf/surrogate/reduced_initial_law.hpp"

namespace mwperf {

namespace temporal::detail {
struct SealedRomrOpsCore;
struct ResidenceCursorCore;
struct ResidenceStepCore;
struct StopDecisionCore;
struct ResidenceWordCore;
struct ResidenceWordRowCore;
struct FiniteEventStateDomainCore;
struct EmbeddedKernelCore;
struct TemporalPathCore;
}  // namespace temporal::detail

namespace detail {
class C20CoreAccess;
}

class ResidenceCursor;
class ResidenceStep;
class StopDecision;
class ResidenceWord;
class ResidenceWordRow;
class FiniteEventStateDomain;
class EmbeddedKernel;
class TemporalPath;

// The C17-minted, immutable authority for iota, beta, terminal re-entry,
// and the two causal word projections.  It deliberately exposes neither a
// raw callback nor a constructor from a C16 descriptor/access value.
class SealedRomrOpsHandle final {
 public:
  SealedRomrOpsHandle() = delete;
  SealedRomrOpsHandle(const SealedRomrOpsHandle&) = default;
  SealedRomrOpsHandle(SealedRomrOpsHandle&&) noexcept = default;
  SealedRomrOpsHandle& operator=(const SealedRomrOpsHandle&) = default;
  SealedRomrOpsHandle& operator=(SealedRomrOpsHandle&&) noexcept = default;

  [[nodiscard]] const Digest256& identity() const noexcept;

 private:
  explicit SealedRomrOpsHandle(
      std::shared_ptr<const temporal::detail::SealedRomrOpsCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::SealedRomrOpsCore> core_;
  friend class detail::C20CoreAccess;
};

enum class ResidenceLifecycleV1 : std::uint8_t {
  open,
  step_pending_validation,
  stopped,
  finalized,
  failed,
};

enum class StopDispositionV1 : std::uint8_t {
  continue_residence,
  stop_residence,
};

// Mutable value cursor for one revealed residence prefix.  Copy construction
// makes an independent branch cursor while retaining the immutable ops
// handle; it never aliases mutable lifecycle state.
class ResidenceCursor final {
 public:
  ResidenceCursor() = delete;
  ResidenceCursor(const ResidenceCursor&);
  ResidenceCursor(ResidenceCursor&&) noexcept;
  ResidenceCursor& operator=(const ResidenceCursor&);
  ResidenceCursor& operator=(ResidenceCursor&&) noexcept;
  ~ResidenceCursor();

  [[nodiscard]] ResidenceLifecycleV1 lifecycle() const noexcept;
  [[nodiscard]] const BigNat& offset() const noexcept;
  [[nodiscard]] const BigNat& version() const noexcept;
  [[nodiscard]] const ReducedStateV1& event_entry() const noexcept;
  [[nodiscard]] const ReducedStateV1& current_state() const noexcept;
  [[nodiscard]] const CanonicalRuntimeValueV1&
  raw_continuation() const noexcept;
  [[nodiscard]] const Digest256& audited_view_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& residence_identity() const noexcept;
  [[nodiscard]] const SealedRomrOpsHandle& ops_handle() const noexcept;
  [[nodiscard]] std::span<const CompletedReducedEdge> edges() const noexcept;

 private:
  explicit ResidenceCursor(
      std::unique_ptr<temporal::detail::ResidenceCursorCore> core);

  std::unique_ptr<temporal::detail::ResidenceCursorCore> core_;
  friend class detail::C20CoreAccess;
  friend Result<ResidenceCursor> begin_residence(const AuditedRomrView&,
                                                  const ReducedStateV1&);
  friend Result<ResidenceStep> advance_residence(
      ResidenceCursor&, const AuditedSlotExecutor&, RngBank&);
  friend Result<StopDecision> validate_residence_stop(
      ResidenceCursor&, const ResidenceStep&);
  friend Result<ResidenceWord> finalize_residence_word(ResidenceCursor&);
};

// One and only one completed C17 edge, bound to the precise cursor transition
// that appended it.  It contains no stop claim.
class ResidenceStep final {
 public:
  ResidenceStep() = delete;
  ResidenceStep(const ResidenceStep&) = default;
  ResidenceStep(ResidenceStep&&) noexcept = default;
  ResidenceStep& operator=(const ResidenceStep&) = default;
  ResidenceStep& operator=(ResidenceStep&&) noexcept = default;

  [[nodiscard]] const CompletedReducedEdge& edge() const noexcept;
  [[nodiscard]] const CanonicalRuntimeValueV1&
  predecision_projection() const noexcept;
  [[nodiscard]] const CanonicalRuntimeValueV1&
  completed_edge_projection() const noexcept;
  [[nodiscard]] const BigNat& offset() const noexcept;
  [[nodiscard]] const BigNat& input_version() const noexcept;
  [[nodiscard]] const BigNat& output_version() const noexcept;
  [[nodiscard]] const Digest256& completed_edge_digest() const noexcept;

 private:
  explicit ResidenceStep(
      std::shared_ptr<const temporal::detail::ResidenceStepCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::ResidenceStepCore> core_;
  friend class detail::C20CoreAccess;
};

class StopDecision final {
 public:
  StopDecision() = delete;
  StopDecision(const StopDecision&) = default;
  StopDecision(StopDecision&&) noexcept = default;
  StopDecision& operator=(const StopDecision&) = default;
  StopDecision& operator=(StopDecision&&) noexcept = default;

  [[nodiscard]] StopDispositionV1 disposition() const noexcept;
  [[nodiscard]] bool stops() const noexcept {
    return disposition() == StopDispositionV1::stop_residence;
  }
  [[nodiscard]] const BigNat& offset() const noexcept;
  [[nodiscard]] const BigNat& cursor_version() const noexcept;
  [[nodiscard]] const Digest256& completed_edge_digest() const noexcept;

 private:
  explicit StopDecision(
      std::shared_ptr<const temporal::detail::StopDecisionCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::StopDecisionCore> core_;
  friend class detail::C20CoreAccess;
};

// Immutable equation-(12.7) word.  The full C17 edge is the single source of
// truth for each a/d/omega/xi tuple; no independently writable scalar
// projection can disagree with the configured joint arrival or common action.
class ResidenceWord final {
 public:
  ResidenceWord() = delete;
  ResidenceWord(const ResidenceWord&) = default;
  ResidenceWord(ResidenceWord&&) noexcept = default;
  ResidenceWord& operator=(const ResidenceWord&) = default;
  ResidenceWord& operator=(ResidenceWord&&) noexcept = default;

  [[nodiscard]] const BigNat& length() const noexcept;
  [[nodiscard]] const ReducedStateV1& entry_state() const noexcept;
  [[nodiscard]] const ReducedStateV1& event_endpoint() const noexcept;
  [[nodiscard]] const CanonicalRuntimeValueV1& raw_terminal_state()
      const noexcept;
  [[nodiscard]] std::span<const CanonicalRuntimeValueV1>
  continuation_path() const noexcept;
  [[nodiscard]] std::span<const CompletedReducedEdge> edges() const noexcept;
  [[nodiscard]] std::span<const CanonicalRuntimeValueV1>
  predecision_projections() const noexcept;
  [[nodiscard]] std::span<const CanonicalRuntimeValueV1>
  completed_edge_projections() const noexcept;
  [[nodiscard]] const Digest256& word_digest() const noexcept;
  [[nodiscard]] const Digest256& audited_view_fingerprint() const noexcept;

 private:
  explicit ResidenceWord(
      std::shared_ptr<const temporal::detail::ResidenceWordCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::ResidenceWordCore> core_;
  friend class detail::C20CoreAccess;
};

struct ResidenceWordRowAtomV1 final {
  ResidenceWord word;
  ExactRational exact_mass;
  bool structural_support;
  long double numerical_image;
  NumericalProbabilityImageStatusV1 numerical_image_status;
  ExactRational exact_cumulative_mass;
};

class ResidenceWordRow final {
 public:
  ResidenceWordRow() = delete;
  ResidenceWordRow(const ResidenceWordRow&) = default;
  ResidenceWordRow(ResidenceWordRow&&) noexcept = default;
  ResidenceWordRow& operator=(const ResidenceWordRow&) = default;
  ResidenceWordRow& operator=(ResidenceWordRow&&) noexcept = default;

  [[nodiscard]] const ReducedStateV1& entry_state() const noexcept;
  [[nodiscard]] std::span<const ResidenceWordRowAtomV1> atoms() const noexcept;
  [[nodiscard]] const ExactRational& exact_total_mass() const noexcept;
  [[nodiscard]] const CompensatedNumericalRowImageV1&
  numerical_row_image() const noexcept;
  [[nodiscard]] const PmfRepresentationBudget& representation_budget()
      const noexcept;
  [[nodiscard]] const Digest256& provider_fingerprint() const noexcept;

 private:
  explicit ResidenceWordRow(
      std::shared_ptr<const temporal::detail::ResidenceWordRowCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::ResidenceWordRowCore> core_;
  friend class detail::C20CoreAccess;
};

// Exact ordered C14/C17 event domain.  The provider factory carries its
// unforgeable seal identity, so an equal-looking list from another framework
// is still foreign.  Reordering also changes the canonical fingerprint.
class FiniteEventStateDomain final {
 public:
  FiniteEventStateDomain() = delete;
  FiniteEventStateDomain(const FiniteEventStateDomain&) = default;
  FiniteEventStateDomain(FiniteEventStateDomain&&) noexcept = default;
  FiniteEventStateDomain& operator=(const FiniteEventStateDomain&) = default;
  FiniteEventStateDomain& operator=(FiniteEventStateDomain&&) noexcept =
      default;

  [[nodiscard]] static Result<FiniteEventStateDomain> from_audited_provider(
      const AuditedResidenceProvider& provider);

  [[nodiscard]] std::span<const ReducedStateV1> states() const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;
  [[nodiscard]] std::optional<std::size_t> index_of(
      const ReducedStateV1& state) const noexcept;

 private:
  explicit FiniteEventStateDomain(
      std::shared_ptr<const temporal::detail::FiniteEventStateDomainCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::FiniteEventStateDomainCore> core_;
  friend class detail::C20CoreAccess;
};

struct EmbeddedKernelAtomV1 final {
  std::size_t endpoint_index;
  ExactRational exact_mass;
  long double numerical_image;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

struct EmbeddedKernelRowV1 final {
  ResidenceWordRow word_row;
  std::vector<EmbeddedKernelAtomV1> endpoint_atoms;
  ExactRational exact_total_mass;
  CompensatedNumericalRowImageV1 numerical_row_image;
};

class EmbeddedKernel final {
 public:
  EmbeddedKernel() = delete;
  EmbeddedKernel(const EmbeddedKernel&) = default;
  EmbeddedKernel(EmbeddedKernel&&) noexcept = default;
  EmbeddedKernel& operator=(const EmbeddedKernel&) = default;
  EmbeddedKernel& operator=(EmbeddedKernel&&) noexcept = default;

  [[nodiscard]] const FiniteEventStateDomain& domain() const noexcept;
  [[nodiscard]] std::span<const EmbeddedKernelRowV1> rows() const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;

 private:
  explicit EmbeddedKernel(
      std::shared_ptr<const temporal::detail::EmbeddedKernelCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::EmbeddedKernelCore> core_;
  friend class detail::C20CoreAccess;
};

struct TemporalSlotV1 final {
  BigNat global_offset;
  BigNat event_index;
  BigNat residence_offset;
  CompletedReducedEdge edge;
  CanonicalRuntimeValueV1 predecision_projection;
  CanonicalRuntimeValueV1 completed_edge_projection;
};

struct UnfinishedResidenceV1 final {
  ResidenceCursor cursor;
  RngBankSnapshot rng_snapshot;
  Digest256 audited_view_fingerprint;
  Digest256 ops_handle_identity;
};

class TemporalPath final {
 public:
  TemporalPath() = delete;
  TemporalPath(const TemporalPath&) = default;
  TemporalPath(TemporalPath&&) noexcept = default;
  TemporalPath& operator=(const TemporalPath&) = default;
  TemporalPath& operator=(TemporalPath&&) noexcept = default;

  [[nodiscard]] const BigNat& horizon() const noexcept;
  [[nodiscard]] const ReducedStateV1& initial_state() const noexcept;
  [[nodiscard]] const ReducedStateV1& final_state() const noexcept;
  [[nodiscard]] std::span<const TemporalSlotV1> slots() const noexcept;
  [[nodiscard]] std::span<const ResidenceWord> completed_words()
      const noexcept;
  [[nodiscard]] std::span<const BigNat> event_epochs() const noexcept;
  [[nodiscard]] const std::optional<UnfinishedResidenceV1>& unfinished()
      const noexcept;
  [[nodiscard]] const Digest256& framework_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& reduced_initial_law_digest() const noexcept;
  [[nodiscard]] const Digest256& path_stream_identity() const noexcept;

 private:
  explicit TemporalPath(
      std::shared_ptr<const temporal::detail::TemporalPathCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const temporal::detail::TemporalPathCore> core_;
  friend class detail::C20CoreAccess;
};

// F-C20-01
[[nodiscard]] Result<ResidenceCursor> begin_residence(
    const AuditedRomrView& view, const ReducedStateV1& state);

// F-C20-02
[[nodiscard]] Result<ResidenceStep> advance_residence(
    ResidenceCursor& cursor, const AuditedSlotExecutor& executor,
    RngBank& rng_bank);

// F-C20-03.  On success the returned decision is atomically recorded in the
// supplied cursor; no separate public lifecycle mutator exists.
[[nodiscard]] Result<StopDecision> validate_residence_stop(
    ResidenceCursor& cursor, const ResidenceStep& step);

// F-C20-04
[[nodiscard]] Result<ResidenceWord> finalize_residence_word(
    ResidenceCursor& cursor);

// F-C20-05
[[nodiscard]] Result<EmbeddedKernel> assemble_embedded_event_kernel(
    const FiniteEventStateDomain& domain,
    const AuditedResidenceProvider& provider);

// F-C20-06.  The public single-path signature has path/replication ID zero.
[[nodiscard]] Result<TemporalPath> execute_temporal_path(
    const AuditedTemporalFramework& framework,
    const ReducedInitialLaw& initial_law, const BigNat& horizon,
    MasterSeed seed);

// F-C20-07
[[nodiscard]] Result<ResidenceWordRow> enumerate_residence_word_row(
    const AuditedResidenceProvider& provider, const ReducedStateV1& state,
    PmfRepresentationBudget representation_budget);

#if defined(MWPERF_C20_TEST_SEAMS)
namespace testing {

// Narrow fixtures for exercising the production-only temporal-bank and
// sealed-domain invariants without making either value constructible in the
// installed API.
class C20FixtureAccess final {
 public:
  C20FixtureAccess() = delete;

  [[nodiscard]] static Result<RngBank> initialized_temporal_bank(
      const AuditedRomrView& view, const ResolvedInstance& instance,
      MasterSeed seed);

  [[nodiscard]] static Result<RngBank> restore_temporal_bank(
      const RngBankSnapshot& snapshot);

  [[nodiscard]] static Result<FiniteEventStateDomain>
  finite_domain_from_states_for_testing(
      const AuditedResidenceProvider& provider,
      std::vector<ReducedStateV1> states);

  // Exercises the exact production predicate used at both residence entry
  // and terminal re-entry.  The seam returns only the verdict: it grants no
  // way to construct a cursor, handle, or altered audited framework.
  [[nodiscard]] static bool reset_preserves_persistent_coordinates_for_testing(
      const ExactReducedCoordinatesV1& before,
      const ExactReducedCoordinatesV1& after,
      std::span<const RuntimeFieldIdV1> residence_local_reset_fields);
};

}  // namespace testing
#endif

}  // namespace mwperf
