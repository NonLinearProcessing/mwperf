#pragma once

#include <optional>
#include <utility>
#include <variant>

#include "mwperf/diagnostic.hpp"

namespace mwperf {

template <typename T>
class [[nodiscard]] Result {
 public:
  [[nodiscard]] static Result success(T value) {
    return Result(Storage(std::in_place_index<0>, std::move(value)));
  }

  [[nodiscard]] static Result failure(Diagnostic diagnostic) {
    return Result(Storage(std::in_place_index<1>, std::move(diagnostic)));
  }

  [[nodiscard]] bool has_value() const noexcept {
    return storage_.index() == 0;
  }

  explicit operator bool() const noexcept { return has_value(); }

  [[nodiscard]] T& value() & { return std::get<0>(storage_); }
  [[nodiscard]] const T& value() const& { return std::get<0>(storage_); }
  [[nodiscard]] T&& value() && { return std::get<0>(std::move(storage_)); }

  [[nodiscard]] Diagnostic& error() & { return std::get<1>(storage_); }
  [[nodiscard]] const Diagnostic& error() const& {
    return std::get<1>(storage_);
  }

 private:
  using Storage = std::variant<T, Diagnostic>;

  explicit Result(Storage storage) : storage_(std::move(storage)) {}

  Storage storage_;
};

template <>
class [[nodiscard]] Result<void> {
 public:
  [[nodiscard]] static Result success() { return Result(std::nullopt); }

  [[nodiscard]] static Result failure(Diagnostic diagnostic) {
    return Result(std::move(diagnostic));
  }

  [[nodiscard]] bool has_value() const noexcept { return !error_.has_value(); }

  explicit operator bool() const noexcept { return has_value(); }

  [[nodiscard]] Diagnostic& error() & { return error_.value(); }
  [[nodiscard]] const Diagnostic& error() const& { return error_.value(); }

 private:
  explicit Result(std::optional<Diagnostic> error) : error_(std::move(error)) {}
  explicit Result(Diagnostic error) : error_(std::move(error)) {}

  std::optional<Diagnostic> error_;
};

}  // namespace mwperf
