#pragma once

#include <memory>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/physical/slot_engine.hpp"
#include "mwperf/surrogate/kernel_access.hpp"

namespace mwperf {

using ConditioningState = CanonicalRuntimeValueV1;
using Sample = KernelTransitionV1;

class SamplingPlan;

namespace sampling::detail {
struct NormalizedSamplerCore;
class C24CoreAccess;
}

// Immutable projection of the exact C14 clause/route retained by the C17
// seal.  The support-clause digest is the canonical C24 metric-target
// identity. C24 must reproduce the retained Monte Carlo accuracy contract;
// only the estimator/RNG address and estimator-specific options are local.
struct AcceptedSamplingClauseV1 final {
  MetricClauseIdV1 clause_id;
  Digest256 metric_target_digest;
  BackendRouteKindV1 backend_route;
  MonteCarloAccuracyV1 accepted_accuracy;

  friend bool operator==(const AcceptedSamplingClauseV1&,
                         const AcceptedSamplingClauseV1&) = default;
};

// Immutable post-V0 operational handle. It owns fresh sealed operation
// copies; it does not retain or expose the C16 raw access carrier.
class NormalizedSamplerAccess final {
 public:
  NormalizedSamplerAccess() = delete;
  NormalizedSamplerAccess(const NormalizedSamplerAccess&) = default;
  NormalizedSamplerAccess(NormalizedSamplerAccess&&) noexcept = default;
  NormalizedSamplerAccess& operator=(const NormalizedSamplerAccess&) =
      default;
  NormalizedSamplerAccess& operator=(NormalizedSamplerAccess&&) noexcept =
      default;

  [[nodiscard]] const Digest256& seal_digest() const noexcept;
  [[nodiscard]] const TransitionKernelAccessShapeV1& shape() const noexcept;
  [[nodiscard]] const ConditionalSamplerContractV1& contract() const noexcept;
  [[nodiscard]] const Digest256& accepted_contract_digest() const noexcept;
  [[nodiscard]] std::span<const AcceptedSamplingClauseV1>
  accepted_sampling_clauses() const noexcept;
  [[nodiscard]] bool target_density_ratio_available() const noexcept;
  [[nodiscard]] bool exact_innovation_available() const noexcept;

  [[nodiscard]] Result<AuditedTargetDensityRatio>
  bind_target_density_ratio(const ConditioningState& row,
                            const SamplingPlan& plan) const;
  [[nodiscard]] Result<AuditedExactInnovationKernel>
  bind_exact_innovation_kernel(const ConditioningState& row,
                               const SamplingPlan& plan) const;

 private:
  explicit NormalizedSamplerAccess(
      std::shared_ptr<const sampling::detail::NormalizedSamplerCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const sampling::detail::NormalizedSamplerCore> core_;
  friend class sampling::detail::C24CoreAccess;
  friend Result<NormalizedSamplerAccess> validate_conditional_generator(
      const AuditedSamplerDescriptor& descriptor);
  friend Result<Sample> draw_conditional_sample(
      const NormalizedSamplerAccess& access,
      const ConditioningState& state, RngBank& rng_bank);
};

// F-C24-01
[[nodiscard]] Result<NormalizedSamplerAccess>
validate_conditional_generator(const AuditedSamplerDescriptor& descriptor);

// F-C24-02
[[nodiscard]] Result<Sample> draw_conditional_sample(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    RngBank& rng_bank);

}  // namespace mwperf
