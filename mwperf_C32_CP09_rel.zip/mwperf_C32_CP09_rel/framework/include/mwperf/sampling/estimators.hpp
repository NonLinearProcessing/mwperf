#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/sampling/conditional_generator.hpp"
#include "mwperf/stationary/reward_types.hpp"

namespace mwperf {

enum class SamplingClaimScopeV1 : std::uint8_t {
  row_conditional_surrogate,
  self_normalized_target_row,
  rao_blackwell_row,
};

struct TotalVariationRequestV1 final {
  long double epsilon;
  long double alpha;
  std::size_t simultaneous_rows{1U};
};

struct SamplingPlanSpecV1 final {
  MonteCarloAccuracyV1 accuracy;
  MasterSeed seed;
  std::string estimator_id;
  Digest256 metric_target_digest;
  BigNat draw_cap;
  StageTag stage{StageTag::generic_sampling};
  bool fixed_budget{true};
  bool request_rao_blackwellization{false};
  std::optional<TotalVariationRequestV1> total_variation;
};

namespace sampling::detail {
struct SamplingPlanCore;
struct EmpiricalResidualCore;
struct SamplingExecutionState;
class C24CoreAccess;
}

class SamplingPlan final {
 public:
  SamplingPlan() = delete;
  SamplingPlan(const SamplingPlan&) = default;
  SamplingPlan(SamplingPlan&&) noexcept = default;
  SamplingPlan& operator=(const SamplingPlan&) = default;
  SamplingPlan& operator=(SamplingPlan&&) noexcept = default;

  [[nodiscard]] static Result<SamplingPlan> from_accepted_clause(
      const NormalizedSamplerAccess& access, SamplingPlanSpecV1 spec);
  [[nodiscard]] static Result<BigNat> sufficient_iid_tv_budget(
      std::size_t support_cardinality, long double epsilon,
      long double alpha, std::size_t simultaneous_rows = 1U);

  [[nodiscard]] const MonteCarloAccuracyV1& accuracy() const noexcept;
  [[nodiscard]] MasterSeed seed() const noexcept;
  [[nodiscard]] std::string_view estimator_id() const noexcept;
  [[nodiscard]] const Digest256& metric_target_digest() const noexcept;
  [[nodiscard]] const Digest256& plan_digest() const noexcept;
  [[nodiscard]] const Digest256& seal_digest() const noexcept;
  [[nodiscard]] const Digest256& accepted_contract_digest() const noexcept;
  [[nodiscard]] const MetricClauseIdV1& accepted_clause_id() const noexcept;
  [[nodiscard]] BackendRouteKindV1 accepted_backend_route() const noexcept;
  [[nodiscard]] const MonteCarloAccuracyV1& accepted_clause_accuracy()
      const noexcept;
  [[nodiscard]] const BigNat& replications() const noexcept;
  [[nodiscard]] const BigNat& draw_cap() const noexcept;
  [[nodiscard]] StageTag stage() const noexcept;
  [[nodiscard]] bool requests_rao_blackwellization() const noexcept;
  [[nodiscard]] const std::optional<TotalVariationRequestV1>&
  total_variation_request() const noexcept;

 private:
  explicit SamplingPlan(
      std::shared_ptr<const sampling::detail::SamplingPlanCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const sampling::detail::SamplingPlanCore> core_;
  friend class sampling::detail::C24CoreAccess;
};

struct EmpiricalRowAtomV1 final {
  Sample sample;
  BigNat count;
  ExactRational probability;
};

struct TotalVariationBoundV1 final {
  std::size_t support_cardinality;
  long double epsilon;
  long double alpha;
  std::size_t simultaneous_rows;
  long double advertised_failure_bound;
  bool iid_premise;
  bool fixed_sample_size;
  SamplingClaimScopeV1 controls;
};

struct FixedSampleIntervalV1 final {
  StatisticalIntervalKindV1 method;
  long double confidence_level;
  long double lower;
  long double upper;
  BigNat sample_size;
  ConditionalSampleDependenceV1 dependence;
  bool iid_premise;
  bool fixed_sample_size;
  SamplingClaimScopeV1 controls;
  std::string coverage_statement;
  std::optional<long double> almost_sure_lower;
  std::optional<long double> almost_sure_upper;
};

// Immutable copy of the C17-sealed sampler provenance carried by each C24
// publication.  These fields are preserved claims, not claims established or
// upgraded by sampling.
struct SamplingEvidenceSnapshotV1 final {
  RuntimeSamplingProvenanceV1 runtime_provenance;
  SamplerEvidenceScopeV1 normalization_evidence;
  SamplerEvidenceScopeV1 termination_evidence;
  SamplerV1EvidenceScopeV1 v1_evidence_scope;
  std::optional<Digest256> v1_evidence_reference;
  SamplerV2EvidenceScopeV1 v2_evidence_scope;
  std::optional<Digest256> v2_evidence_reference;
  std::optional<Digest256> foreign_construction_evidence;

  friend bool operator==(const SamplingEvidenceSnapshotV1&,
                         const SamplingEvidenceSnapshotV1&) = default;
};

struct SamplingCostCountersV1 final {
  BigNat draws;
  BigNat failed_draws;
  BigNat exact_innovation_atoms;
  BigNat optimizer_probes;
  BigNat canonical_bytes;

  friend bool operator==(const SamplingCostCountersV1&,
                         const SamplingCostCountersV1&) = default;
};

// Immutable publication of one addressed replication stream after its draw
// completed.  The sequence carried by an empirical row or estimate is in
// replication-index order and retains the stream's actual RNG consumption;
// in particular, zero-word and multiword draws are not rewritten.
struct SamplingReplicationReplayV1 final {
  Digest256 stream_identity;
  BigNat consumed_words;

  friend bool operator==(const SamplingReplicationReplayV1&,
                         const SamplingReplicationReplayV1&) = default;
};

// Read-only execution-local accounting for one invocation of a C24 estimator.
// The estimator is the only writer.  Keeping this observer outside Result<T>
// lets an orchestrator retain the exact consumed draw count and addressed RNG
// streams when a generator, decoder, or post-draw numerical check fails.
class SamplingExecutionObserverV1 final {
 public:
  SamplingExecutionObserverV1() = delete;
  SamplingExecutionObserverV1(const SamplingExecutionObserverV1&) = default;
  SamplingExecutionObserverV1(SamplingExecutionObserverV1&&) noexcept =
      default;
  SamplingExecutionObserverV1& operator=(
      const SamplingExecutionObserverV1&) = default;
  SamplingExecutionObserverV1& operator=(
      SamplingExecutionObserverV1&&) noexcept = default;
  ~SamplingExecutionObserverV1() = default;

  [[nodiscard]] static Result<SamplingExecutionObserverV1> for_plan(
      const SamplingPlan& plan);

  [[nodiscard]] const Digest256& plan_digest() const noexcept;
  [[nodiscard]] StageTag stage() const noexcept;
  [[nodiscard]] const BigNat& draw_cap() const noexcept;
  [[nodiscard]] const BigNat& generator_draws() const noexcept;
  [[nodiscard]] const BigNat& failed_draws() const noexcept;
  [[nodiscard]] std::span<const SamplingReplicationReplayV1> replay_streams()
      const noexcept;

 private:
  explicit SamplingExecutionObserverV1(
      std::shared_ptr<sampling::detail::SamplingExecutionState> state)
      : state_(std::move(state)) {}

  std::shared_ptr<sampling::detail::SamplingExecutionState> state_;
  friend class sampling::detail::C24CoreAccess;
};

class EmpiricalRow final {
 public:
  EmpiricalRow() = delete;
  [[nodiscard]] const BigNat& total() const noexcept { return total_; }
  [[nodiscard]] std::span<const EmpiricalRowAtomV1> atoms() const noexcept {
    return atoms_;
  }
  [[nodiscard]] bool iid_replications() const noexcept {
    return iid_replications_;
  }
  [[nodiscard]] const Digest256& seal_digest() const noexcept {
    return seal_digest_;
  }
  [[nodiscard]] const Digest256& conditioning_row_digest() const noexcept {
    return row_digest_;
  }
  [[nodiscard]] const Digest256& plan_digest() const noexcept {
    return plan_digest_;
  }
  [[nodiscard]] const Digest256& metric_target_digest() const noexcept {
    return metric_target_digest_;
  }
  [[nodiscard]] const std::optional<long double>&
  advertised_tv_failure_bound() const noexcept {
    return advertised_tv_failure_bound_;
  }
  [[nodiscard]] const std::optional<TotalVariationBoundV1>&
  total_variation_bound() const noexcept {
    return total_variation_bound_;
  }
  [[nodiscard]] std::size_t failed_draws() const noexcept {
    return failed_draws_;
  }
  [[nodiscard]] const SamplingEvidenceSnapshotV1& sampling_evidence()
      const noexcept {
    return sampling_evidence_;
  }
  [[nodiscard]] const SamplingCostCountersV1& costs() const noexcept {
    return costs_;
  }
  [[nodiscard]] std::span<const SamplingReplicationReplayV1> replay_streams()
      const noexcept {
    return replay_streams_;
  }

 private:
  EmpiricalRow(BigNat total, std::vector<EmpiricalRowAtomV1> atoms,
               bool iid_replications, Digest256 seal_digest,
               Digest256 row_digest, Digest256 plan_digest,
               Digest256 metric_target_digest,
               SamplingEvidenceSnapshotV1 sampling_evidence,
               SamplingCostCountersV1 costs,
               std::vector<SamplingReplicationReplayV1> replay_streams,
               std::optional<TotalVariationBoundV1> tv_bound,
               std::size_t failed_draws)
      : total_(std::move(total)),
        atoms_(std::move(atoms)),
        iid_replications_(iid_replications),
        seal_digest_(std::move(seal_digest)),
        row_digest_(std::move(row_digest)),
        plan_digest_(std::move(plan_digest)),
        metric_target_digest_(std::move(metric_target_digest)),
        sampling_evidence_(std::move(sampling_evidence)),
        costs_(std::move(costs)),
        replay_streams_(std::move(replay_streams)),
        advertised_tv_failure_bound_(
            tv_bound.has_value()
                ? std::optional<long double>{
                      tv_bound->advertised_failure_bound}
                : std::nullopt),
        total_variation_bound_(std::move(tv_bound)),
        failed_draws_(failed_draws) {}

  BigNat total_;
  std::vector<EmpiricalRowAtomV1> atoms_;
  bool iid_replications_;
  Digest256 seal_digest_;
  Digest256 row_digest_;
  Digest256 plan_digest_;
  Digest256 metric_target_digest_;
  SamplingEvidenceSnapshotV1 sampling_evidence_;
  SamplingCostCountersV1 costs_;
  std::vector<SamplingReplicationReplayV1> replay_streams_;
  std::optional<long double> advertised_tv_failure_bound_;
  std::optional<TotalVariationBoundV1> total_variation_bound_;
  std::size_t failed_draws_;
  friend class sampling::detail::C24CoreAccess;
};

struct ConditionalSamplingRewardV1 final {
  std::string decoder_id;
  Digest256 decoder_digest;
  Digest256 metric_target_digest;
  Digest256 output_schema;
  StationaryRewardIntegrabilityV1 integrability;
  bool binary_indicator{false};
  std::optional<ExactRational> almost_sure_lower;
  std::optional<ExactRational> almost_sure_upper;
  std::function<Result<long double>(const ConditioningState&,
                                    const Sample&)>
      decode;
  // Required by Rao--Blackwell's population-variance statement unless a
  // finite almost-sure range above already supplies the stronger witness.
  bool finite_second_moment{false};
};

struct ImportanceDiagnosticsV1 final {
  long double effective_sample_size;
  long double maximum_normalized_weight;
  std::size_t zero_weight_count;
  long double positive_log_weight_dynamic_range;
  bool zero_weights_present;
  bool full_log_weight_dynamic_range_infinite;
  bool finite_sample_biased;
  bool consistency_claim;
  bool weighted_second_moment_claim;
};

struct ImportanceWeightRecordV1 final {
  ImportanceWeightRepresentationV1 representation;
  long double authored_value;
  long double common_scaled_weight;
};

class EmpiricalResidual;

class Estimate final {
 public:
  Estimate() = delete;
  [[nodiscard]] long double value() const noexcept { return value_; }
  [[nodiscard]] const std::optional<long double>& sample_variance()
      const noexcept {
    return sample_variance_;
  }
  [[nodiscard]] const std::optional<FixedSampleIntervalV1>& interval()
      const noexcept {
    return interval_;
  }
  [[nodiscard]] SamplingClaimScopeV1 claim_scope() const noexcept {
    return claim_scope_;
  }
  [[nodiscard]] const BigNat& replications() const noexcept {
    return replications_;
  }
  [[nodiscard]] std::span<const long double> raw_rewards() const noexcept {
    return raw_rewards_;
  }
  [[nodiscard]] std::span<const ImportanceWeightRecordV1> raw_weights()
      const noexcept {
    return raw_weights_;
  }
  [[nodiscard]] const std::optional<ImportanceDiagnosticsV1>&
  importance_diagnostics() const noexcept {
    return importance_diagnostics_;
  }
  [[nodiscard]] const std::optional<long double>&
  exact_integration_absolute_error() const noexcept {
    return exact_integration_absolute_error_;
  }
  [[nodiscard]] const SamplingCostCountersV1& costs() const noexcept {
    return costs_;
  }
  [[nodiscard]] const SamplingEvidenceSnapshotV1& sampling_evidence()
      const noexcept {
    return sampling_evidence_;
  }
  [[nodiscard]] std::span<const SamplingReplicationReplayV1> replay_streams()
      const noexcept {
    return replay_streams_;
  }
  [[nodiscard]] const Digest256& seal_digest() const noexcept {
    return seal_digest_;
  }
  [[nodiscard]] const Digest256& conditioning_row_digest() const noexcept {
    return row_digest_;
  }
  [[nodiscard]] const Digest256& plan_digest() const noexcept {
    return plan_digest_;
  }
  [[nodiscard]] const Digest256& metric_target_digest() const noexcept {
    return metric_target_digest_;
  }
  [[nodiscard]] const std::optional<Digest256>& proposal_law_identity()
      const noexcept {
    return proposal_law_identity_;
  }
  [[nodiscard]] const std::optional<Digest256>& target_law_identity()
      const noexcept {
    return target_law_identity_;
  }
  [[nodiscard]] bool has_empirical_residual() const noexcept {
    return static_cast<bool>(empirical_residual_);
  }
  [[nodiscard]] EmpiricalResidual empirical_residual() const;

 private:
  Estimate(long double value, std::optional<long double> sample_variance,
           std::optional<FixedSampleIntervalV1> interval,
           SamplingClaimScopeV1 claim_scope, BigNat replications,
           std::vector<long double> raw_rewards,
           std::vector<ImportanceWeightRecordV1> raw_weights,
           std::optional<ImportanceDiagnosticsV1> importance_diagnostics,
           std::optional<long double> exact_integration_absolute_error,
           SamplingCostCountersV1 costs,
           SamplingEvidenceSnapshotV1 sampling_evidence,
           std::vector<SamplingReplicationReplayV1> replay_streams,
           Digest256 seal_digest, Digest256 row_digest,
           Digest256 plan_digest, Digest256 metric_target_digest,
           std::optional<Digest256> proposal_law_identity,
           std::optional<Digest256> target_law_identity,
           std::shared_ptr<const sampling::detail::EmpiricalResidualCore>
               empirical_residual = {})
      : value_(value),
        sample_variance_(sample_variance),
        interval_(std::move(interval)),
        claim_scope_(claim_scope),
        replications_(std::move(replications)),
        raw_rewards_(std::move(raw_rewards)),
        raw_weights_(std::move(raw_weights)),
        importance_diagnostics_(std::move(importance_diagnostics)),
        exact_integration_absolute_error_(
            exact_integration_absolute_error),
        costs_(std::move(costs)),
        sampling_evidence_(std::move(sampling_evidence)),
        replay_streams_(std::move(replay_streams)),
        seal_digest_(std::move(seal_digest)),
        row_digest_(std::move(row_digest)),
        plan_digest_(std::move(plan_digest)),
        metric_target_digest_(std::move(metric_target_digest)),
        proposal_law_identity_(std::move(proposal_law_identity)),
        target_law_identity_(std::move(target_law_identity)),
        empirical_residual_(std::move(empirical_residual)) {}

  long double value_;
  std::optional<long double> sample_variance_;
  std::optional<FixedSampleIntervalV1> interval_;
  SamplingClaimScopeV1 claim_scope_;
  BigNat replications_;
  std::vector<long double> raw_rewards_;
  std::vector<ImportanceWeightRecordV1> raw_weights_;
  std::optional<ImportanceDiagnosticsV1> importance_diagnostics_;
  std::optional<long double> exact_integration_absolute_error_;
  SamplingCostCountersV1 costs_;
  SamplingEvidenceSnapshotV1 sampling_evidence_;
  std::vector<SamplingReplicationReplayV1> replay_streams_;
  Digest256 seal_digest_;
  Digest256 row_digest_;
  Digest256 plan_digest_;
  Digest256 metric_target_digest_;
  std::optional<Digest256> proposal_law_identity_;
  std::optional<Digest256> target_law_identity_;
  std::shared_ptr<const sampling::detail::EmpiricalResidualCore>
      empirical_residual_;
  friend class sampling::detail::C24CoreAccess;
};

class EmpiricalResidual final {
 public:
  EmpiricalResidual() = delete;
  EmpiricalResidual(const EmpiricalResidual&) = default;
  EmpiricalResidual(EmpiricalResidual&&) noexcept = default;
  EmpiricalResidual& operator=(const EmpiricalResidual&) = default;
  EmpiricalResidual& operator=(EmpiricalResidual&&) noexcept = default;
  [[nodiscard]] std::span<const Sample> samples() const noexcept;
  [[nodiscard]] const Digest256& seal_digest() const noexcept;
  [[nodiscard]] const Digest256& conditioning_row_digest() const noexcept;
  [[nodiscard]] const Digest256& plan_digest() const noexcept;
  [[nodiscard]] const Digest256& metric_target_digest() const noexcept;

 private:
  explicit EmpiricalResidual(
      std::shared_ptr<const sampling::detail::EmpiricalResidualCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const sampling::detail::EmpiricalResidualCore> core_;
  friend class sampling::detail::C24CoreAccess;
};

// F-C24-03
[[nodiscard]] Result<EmpiricalRow> estimate_discrete_kernel_row(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const SamplingPlan& plan);

// Accounting-preserving orchestration entry point.  It is deliberately not
// an overload of F-C24-03: the frozen C24 catalog owns exactly one definition
// of that operation.  The observer must have been minted from this exact plan
// and may be consumed by only one estimator invocation.
[[nodiscard]] Result<EmpiricalRow> estimate_discrete_kernel_row_observed(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const SamplingPlan& plan, SamplingExecutionObserverV1& observer);

// F-C24-04
[[nodiscard]] Result<Estimate> estimate_reward_expectation(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const RewardDecoder& reward, const SamplingPlan& plan);

[[nodiscard]] Result<Estimate> estimate_reward_expectation_observed(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const RewardDecoder& reward, const SamplingPlan& plan,
    SamplingExecutionObserverV1& observer);

// F-C24-05
[[nodiscard]] Result<Estimate> estimate_importance_weighted(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const AuditedTargetDensityRatio& ratio, const RewardDecoder& reward,
    const SamplingPlan& plan);

[[nodiscard]] Result<Estimate> estimate_importance_weighted_observed(
    const NormalizedSamplerAccess& access, const ConditioningState& state,
    const AuditedTargetDensityRatio& ratio, const RewardDecoder& reward,
    const SamplingPlan& plan, SamplingExecutionObserverV1& observer);

// F-C24-06
[[nodiscard]] Result<Estimate> rao_blackwellize_known_innovation(
    const EmpiricalResidual& residual,
    const AuditedExactInnovationKernel& innovation,
    const RewardDecoder& reward);

}  // namespace mwperf
