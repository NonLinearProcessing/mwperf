#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/certificates/transfer_bounds.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/v0_witness.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf {

namespace certificates::detail {
struct ValidatedCertificateCore;
struct EvidenceGraphSealIdentity final {};
class C25CoreAccess;
}  // namespace certificates::detail

struct CertificateBundle;

// Optional certificate claims have three truth states.  In particular,
// absence of evidence is not a refutation and is never serialized as false.
enum class CertificateCoverageV1 : std::uint8_t {
  not_applicable,
  global_declared_domain,
  forward_invariant_domain,
  finite_complete_domain,
  selected_stationary_integrated,
  sampled_only,
};

enum class CertificateEvidenceOriginV1 : std::uint8_t {
  independent_a_priori,
  independent_experiment,
  provider_report,
  stationary_oracle_benchmark,
};

enum class CertificateClaimKindV1 : std::uint8_t {
  v1_fibre_geometry,
  v2_dynamic_lift,
  stationary_integrated_fidelity,
  physical_fidelity,
  stability,
  finite_horizon_transfer,
  contraction_transfer,
  stopped_resolvent_transfer,
  response_envelope,
  response_product_transfer,
  decision_sensitivity,
  poisson_reward,
  numerics,
  complexity,
  validation,
  provenance,
  // Internal graph leaf used to support a selected claim.  Premise nodes are
  // never themselves selectable certificate claims.
  premise,
};

using CertificateEvidenceIdV1 = ArtifactObjectReferenceV1;

enum class PhysicalFidelityKindV1 : std::uint8_t {
  exact,
  bounded,
  empirical_only,
  not_established,
};

enum class RowErrorKindV1 : std::uint8_t {
  marked_residence_event_row,
  approximate_relational_slot_row,
  stationary_uniform_total_variation,
  stationary_wasserstein_occupation,
  stationary_weighted_norm,
};

enum class TransferOrientationV1 : std::uint8_t {
  reference_to_approximate,
  approximate_to_reference,
};

enum class RewardGeometryKindV1 : std::uint8_t {
  event_indicator,
  bounded_range,
  metric_lipschitz,
  unbounded,
};

struct RewardGeometryEvidenceV1 final {
  RewardGeometryKindV1 kind;
  std::optional<long double> lower;
  std::optional<long double> upper;
  std::optional<long double> lipschitz_modulus;
  bool required_moments_established;
};

// V1 proves only current-row MaxWeight fibre geometry.  These identities name
// the relation, lift, complete decision mark, and exact subject law; booleans
// are accepted only when their evidence dependencies are present in the same
// acyclic graph.
struct V1GeometryEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CodecIdentityV1 witness_schema;
  Digest256 framework_fingerprint;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 compatibility_relation_identity;
  Digest256 lifting_kernel_identity;
  Digest256 physical_state_schema_identity;
  Digest256 reduced_state_schema_identity;
  Digest256 complete_decision_mark_identity;
  CertificateCoverageV1 coverage;
  bool compatible_support_established;
  bool current_decision_mixture_identity_established;
  bool common_feasible_schedule_established;
  bool exact_tie_and_lattice_semantics_established;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

// V2 is deliberately a separate node.  A row intertwining may be established
// without a path claim; the latter additionally requires the lifted initial
// law named here.
struct V2DynamicLiftEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CodecIdentityV1 witness_schema;
  Digest256 framework_fingerprint;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 compatibility_relation_identity;
  Digest256 lifting_kernel_identity;
  Digest256 marked_decoder_identity;
  Digest256 configured_arrival_identity;
  CertificateCoverageV1 coverage;
  bool row_intertwining_established;
  bool claims_path_identity;
  std::optional<Digest256> lifted_initial_law_identity;
  bool initial_support_established;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct StationaryIntegratedFidelityEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CodecIdentityV1 witness_schema;
  Digest256 framework_fingerprint;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 surrogate_invariant_law_identity;
  Digest256 lifting_kernel_identity;
  Digest256 common_decoder_identity;
  Digest256 physical_invariant_selection_identity;
  CertificateEvidenceOriginV1 origin;
  bool uses_requested_unknown_physical_stationary_law;
  bool selected_surrogate_invariant_established;
  bool integrated_invariance_established;
  bool physical_selection_and_uniqueness_established;
  bool marked_edge_identity_established;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct PhysicalFidelityEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CodecIdentityV1 witness_schema;
  Digest256 framework_fingerprint;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 physical_reference_law_identity;
  Digest256 metric_identity;
  Digest256 regime_identity;
  Digest256 comparison_theorem_identity;
  PhysicalFidelityKindV1 kind;
  CertificateEvidenceOriginV1 origin;
  bool uses_requested_unknown_physical_stationary_law;
  std::optional<long double> finite_bound;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct RowErrorEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  ArtifactObjectReferenceV1 reference_law;
  ArtifactObjectReferenceV1 approximate_law;
  RowErrorKindV1 kind;
  HorizonDomainV1 horizon_domain;
  Digest256 consequence_domain;
  MetricGeometry geometry;
  long double row_defect;
  std::optional<long double> initial_defect;
  bool equal_initial_law;
  bool common_refinement_established;
  TransferOrientationV1 orientation;
  RewardGeometryEvidenceV1 reward;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct ContractionEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CertificateEvidenceIdV1 row_error_id;
  ArtifactObjectReferenceV1 reference_kernel;
  ArtifactObjectReferenceV1 approximate_kernel;
  ArtifactObjectReferenceV1 reference_invariant_law;
  ArtifactObjectReferenceV1 approximate_invariant_law;
  MetricGeometry geometry;
  long double coefficient;
  bool invariant_laws_established;
  bool reference_first_moment_finite;
  bool approximate_first_moment_finite;
  bool shared_foster_lyapunov_tail;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct ExactDenseMatrixV1 final {
  std::size_t rows;
  std::size_t columns;
  std::vector<ExactRational> entries;

  [[nodiscard]] const ExactRational& at(std::size_t row,
                                        std::size_t column) const;
};

struct KilledKernelPairEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  ArtifactObjectReferenceV1 reference_law;
  ArtifactObjectReferenceV1 approximate_law;
  Digest256 state_order_identity;
  Digest256 stopping_event_identity;
  Digest256 common_lift_identity;
  ExactDenseMatrixV1 reference_killed_kernel;
  ExactDenseMatrixV1 approximate_killed_kernel;
  std::optional<std::vector<ExactRational>> reference_entrance_law;
  std::optional<std::vector<ExactRational>> approximate_entrance_law;
  std::optional<ArtifactObjectReferenceV1> reference_c23_entrance;
  std::optional<ArtifactObjectReferenceV1> approximate_c23_entrance;
  bool common_state_and_lift_established;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct ResolventEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CertificateEvidenceIdV1 killed_pair_id;
  OperatorNormGeometryV1 norm;
  ExactDenseMatrixV1 reference_resolvent;
  ExactDenseMatrixV1 approximate_resolvent;
  bool bounded_neumann_resolvents;
  bool space_contains_one;
  bool minimal_potentials_finite;
  std::optional<long double> certified_inverse_residual_conversion;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct DriftRowEvidenceV1 final {
  long double h_capacity;
  long double expected_q_dot_service;
  long double backlog_l1;
  bool common_feasible_schedule;
};

struct DriftWitnessEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  Digest256 framework_fingerprint;
  Digest256 configured_arrival_fingerprint;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 declared_domain_identity;
  Digest256 common_joint_schedule_law_identity;
  CertificateCoverageV1 domain_coverage;
  bool retains_full_physical_backlog;
  bool iid_across_slots_exact_joint;
  bool capacity_interior_verified;
  bool declared_domain_forward_invariant;
  bool all_declared_domain_rows_verified;
  bool common_joint_schedule_law_established;
  bool initial_support_contained;
  bool initial_quadratic_backlog_moment_finite;
  long double epsilon;
  long double b;
  long double delta;
  long double deterministic_row_tolerance;
  long double arrival_second_norm_moment;
  long double max_schedule_squared_norm;
  std::vector<DriftRowEvidenceV1> rows;
  bool irreducible;
  bool petite_set;
  bool norm_like_all_unbounded_phases;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct ScalarBatchMassV1 final {
  std::uint64_t batch;
  long double probability;
};

struct ScalarResponseCoefficientsV1 final {
  long double one;
  long double two;
  long double tail;
};

// Exact closure decisions never use rounded coefficient or probability
// images.  These values are a separately typed proof payload for the finite
// transition construction; the long-double response above remains the
// presentation/runtime payload used by the other envelope routes.
struct ExactScalarResponseCoefficientsV1 final {
  ExactRational one;
  ExactRational two;
  ExactRational tail;
};

struct ExactScalarBatchMassV1 final {
  std::uint64_t batch;
  ExactRational probability;
};

struct ExactFiniteEnvelopeInputsV1 final {
  ExactScalarResponseCoefficientsV1 mu_minus;
  ExactScalarResponseCoefficientsV1 mu_point;
  ExactScalarResponseCoefficientsV1 mu_plus;
  std::vector<ExactScalarBatchMassV1> iid_target_marginal;
};

// A response envelope joins products by immutable typed identity, never by
// equal coefficient values.  Mean-stage products and interval-only raw
// products cannot be evaluated as point response laws.
struct EnvelopeResponseProductBindingV1 final {
  Digest256 identity;
  ResponseProductStageV1 stage;
  RawValueStatusV1 raw_value_status;
  Digest256 law_identity;
  bool designated_deployed_point;
  bool validated_cross_product_transfer;
  std::optional<CertificateEvidenceIdV1> transfer_evidence;
};

enum class ResponseProductTransferDirectionV1 : std::uint8_t {
  source_to_destination,
  destination_to_source,
};

// Each response coefficient is transferred separately.  Retaining both the
// certified source interval and the resulting destination interval prevents
// an interval on a raw proposal from being silently relabelled as a bound on
// a deployed response product.
struct ResponseCoefficientTransferIntervalV1 final {
  ThreeBinCoefficientV1 coefficient;
  long double source_lower;
  long double source_upper;
  long double result_lower;
  long double result_upper;
};

struct EnvelopeResponseProductTransferEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CertificateEvidenceIdV1 source_evidence;
  ArtifactObjectReferenceV1 source_reference;
  Digest256 source_product_identity;
  ResponseProductStageV1 source_stage;
  RawValueStatusV1 source_value_status;
  Digest256 source_law_identity;
  Digest256 destination_product_identity;
  ResponseProductStageV1 destination_stage;
  RawValueStatusV1 destination_value_status;
  Digest256 destination_law_identity;
  Digest256 theorem_or_map_identity;
  ResponseProductTransferDirectionV1 direction;
  std::array<ResponseCoefficientTransferIntervalV1, 3U>
      coefficient_intervals;
  std::vector<std::string> assumptions;
  bool direction_and_assumptions_validated;
  bool destination_is_designated_deployed_point;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

enum class EnvelopeArrivalSemanticsV1 : std::uint8_t {
  iid_across_slots,
  temporal_augmented,
};

enum class EnvelopeClosureRouteV1 : std::uint8_t {
  exact_finite_closure,
  reachable_tail_strict_slack,
  temporal_backend,
};

struct ExactFiniteClosureEvidenceV1 final {
  bool established;
  std::uint64_t boundary;
  std::vector<std::uint64_t> initial_support;
  std::vector<std::uint64_t> selected_accessible_class;
  Digest256 bound_slow_product_identity;
  bool exact_reachability;
  bool unique_reachable_closed_class;
  // Required when `established` is evaluated.  The exact arrival marginal is
  // checked against the sealed C09 joint law before any closure decision.
  std::optional<ExactFiniteEnvelopeInputsV1> exact_inputs{std::nullopt};
};

struct ReachableTailEvidenceV1 final {
  bool boundary_order_certified;
  bool tail_order_certified;
  bool finite_second_moment;
};

struct TemporalEnvelopeMetricIntervalV1 final {
  MetricKindV1 metric_kind;
  std::string metric_id;
  // Digest of C14's canonical one-clause MetricRequirements.  It binds the
  // exact parameters, ordered targets, selection and solver context, not
  // merely a human-readable metric id and kind.
  Digest256 normalized_request_digest;
  BoundValueStatusV1 lower_status;
  std::optional<long double> lower;
  BoundValueStatusV1 upper_status;
  std::optional<long double> upper;
};

struct TemporalEnvelopeBackendEvidenceV1 final {
  bool accepted;
  CertificateEvidenceIdV1 evidence_dependency;
  Digest256 accepted_contract_digest;
  Digest256 backend_identity;
  Digest256 theorem_identity;
  Digest256 configured_arrival_identity;
  Digest256 slow_product_identity;
  Digest256 fast_product_identity;
  std::vector<TemporalEnvelopeMetricIntervalV1> metric_intervals;
  bool common_arrival_phase_coupling;
  bool service_independent_phase;
  bool invariant_exists;
  bool convergence_established;
};

struct ResponseEnvelopeCertificateEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  Digest256 framework_fingerprint;
  Digest256 configured_arrival_identity;
  QueueId target;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 slow_product_identity;
  Digest256 fast_product_identity;
  EnvelopeResponseProductBindingV1 subject_product;
  EnvelopeResponseProductBindingV1 slow_product;
  EnvelopeResponseProductBindingV1 fast_product;
  ScalarResponseCoefficientsV1 mu_minus;
  ScalarResponseCoefficientsV1 mu_point;
  ScalarResponseCoefficientsV1 mu_plus;
  bool pointwise_order_independently_certified;
  EnvelopeArrivalSemanticsV1 arrival_semantics;
  EnvelopeClosureRouteV1 requested_route;
  std::vector<ScalarBatchMassV1> iid_target_marginal;
  long double lambda;
  long double arrival_second_moment;
  bool arrival_second_moment_finite;
  ExactFiniteClosureEvidenceV1 closure;
  ReachableTailEvidenceV1 tail;
  std::optional<TemporalEnvelopeBackendEvidenceV1> temporal_backend;
  bool stationary_existence_convergence;
  bool little_lossless;
  bool little_unit_packets;
  bool little_eventual_departure;
  bool little_positive_finite_intensity;
  bool little_finite_backlog_first_moment;
  bool little_law;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct DecisionSensitivityEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 coupling_identity;
  long double eta;
  std::optional<long double> near_boundary_probability;
  std::optional<long double> reconstruction_probability;
  std::optional<long double> eligibility_probability;
  std::optional<long double> tie_probability;
  bool every_term_independently_bounded;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

struct PoissonDefectEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 reward_identity;
  Digest256 corrector_identity;
  CertificateCoverageV1 coverage;
  long double delta;
  long double moment_bound;
  bool invariant_law_established;
  bool invariant_coboundary_identity_justified;
  bool domain_and_integrability_established;
  bool global_residual_established;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

// A premise is an independently identified graph leaf for one exact claim
// type and subject.  It prevents theorem hypotheses represented by booleans
// in the compact wire structures above from becoming self-certifying.  The
// referenced provenance is part of the premise identity; equal values or a
// generic validation record are not substitutes for this typed edge.
struct CertificatePremiseEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CertificateClaimKindV1 supported_claim;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 premise_identity;
  ArtifactObjectReferenceV1 provenance_identity;
  CertificateCoverageV1 coverage;
  CertificateEvidenceOriginV1 origin;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

enum class ComplexityCostCategoryV1 : std::uint8_t {
  construction,
  calibration,
  representation,
  surrogate_solve,
  optimizer_calls,
  storage,
  trace_warmup_and_dependence,
  proposal_generation,
  tail_proof,
  certificate_evaluation,
};

enum class ComplexityCostUnitV1 : std::uint8_t {
  wall_clock_seconds,
  cpu_seconds,
  bytes,
  calls,
  samples,
  states,
  scalar_coefficients,
  dimensionless_work_units,
};

// Complexity is quantitative evidence, rather than a generic scoped marker.
// Each entry owns exactly one cost category so certificate/tail work and the
// deployed surrogate solve remain independently reportable.
struct ComplexityCostEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  ComplexityCostCategoryV1 category;
  long double amount;
  ComplexityCostUnitV1 unit;
  std::string convention;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  ArtifactObjectReferenceV1 provenance_identity;
  CertificateCoverageV1 coverage;
  CertificateEvidenceOriginV1 origin;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

// This record carries independently scoped numerics, validation, or
// provenance evidence without pretending that it is a transfer theorem or a
// quantitative complexity cost.
struct ScopedCertificateRecordEvidenceV1 final {
  CertificateEvidenceIdV1 evidence_id;
  CertificateClaimKindV1 kind;
  Digest256 subject_product_identity;
  Digest256 subject_law_identity;
  Digest256 statement_identity;
  CertificateCoverageV1 coverage;
  CertificateEvidenceOriginV1 origin;
  std::vector<CertificateEvidenceIdV1> dependencies;
};

using CertificateEvidenceNodeV1 =
    std::variant<V1GeometryEvidenceV1, V2DynamicLiftEvidenceV1,
                 StationaryIntegratedFidelityEvidenceV1,
                 PhysicalFidelityEvidenceV1, RowErrorEvidenceV1,
                 ContractionEvidenceV1, KilledKernelPairEvidenceV1,
                 ResolventEvidenceV1, DriftWitnessEvidenceV1,
                 ResponseEnvelopeCertificateEvidenceV1,
                 EnvelopeResponseProductTransferEvidenceV1,
                 DecisionSensitivityEvidenceV1, PoissonDefectEvidenceV1,
                 CertificatePremiseEvidenceV1, ComplexityCostEvidenceV1,
                 ScopedCertificateRecordEvidenceV1>;

// Raw authorable evidence is still bound to the exact post-V0 carrier and to
// a canonical order-independent graph digest.  It cannot construct any of the
// theorem views below.
class Evidence final {
 public:
  Evidence() = delete;
  Evidence(const Evidence&) = default;
  Evidence(Evidence&&) noexcept = default;
  Evidence& operator=(const Evidence&) = default;
  Evidence& operator=(Evidence&&) noexcept = default;

  [[nodiscard]] std::uint32_t schema_version() const noexcept {
    return schema_version_;
  }
  [[nodiscard]] const V0WitnessBindingsV1& v0_bindings() const noexcept {
    return v0_bindings_;
  }
  [[nodiscard]] const AuditedFrameworkBindingsV1& framework_bindings()
      const noexcept {
    return framework_bindings_;
  }
  [[nodiscard]] const Digest256& graph_digest() const noexcept {
    return graph_digest_;
  }
  [[nodiscard]] std::span<const CertificateEvidenceNodeV1> nodes()
      const noexcept {
    return nodes_;
  }

  // Safe authoring path: copies only immutable bindings from the already
  // V0-audited carrier and computes the canonical graph digest.
  [[nodiscard]] static Result<Evidence> bind(
      const AuditedCompiledFramework& framework,
      std::vector<CertificateEvidenceNodeV1> nodes);
  [[nodiscard]] static Result<Digest256> canonical_graph_digest(
      std::span<const CertificateEvidenceNodeV1> nodes);

 private:
  Evidence(
      std::uint32_t schema_version, V0WitnessBindingsV1 v0_bindings,
      AuditedFrameworkBindingsV1 framework_bindings, Digest256 graph_digest,
      std::vector<CertificateEvidenceNodeV1> nodes,
      std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
          framework_seal,
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework_core,
      std::shared_ptr<const certificates::detail::EvidenceGraphSealIdentity>
          graph_seal)
      : schema_version_(schema_version),
        v0_bindings_(std::move(v0_bindings)),
        framework_bindings_(std::move(framework_bindings)),
        graph_digest_(std::move(graph_digest)),
        nodes_(std::move(nodes)),
        framework_seal_(std::move(framework_seal)),
        framework_core_(std::move(framework_core)),
        graph_seal_(std::move(graph_seal)) {}

  std::uint32_t schema_version_;
  V0WitnessBindingsV1 v0_bindings_;
  AuditedFrameworkBindingsV1 framework_bindings_;
  Digest256 graph_digest_;
  std::vector<CertificateEvidenceNodeV1> nodes_;
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
      framework_seal_;
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> framework_core_;
  std::shared_ptr<const certificates::detail::EvidenceGraphSealIdentity>
      graph_seal_;

  friend struct CertificateBundle;
  friend class certificates::detail::C25CoreAccess;
};

struct CertificateBundle final {
 public:
  CertificateBundle() = delete;
  CertificateBundle(const CertificateBundle&) = default;
  CertificateBundle(CertificateBundle&&) noexcept = default;
  CertificateBundle& operator=(const CertificateBundle&) = default;
  CertificateBundle& operator=(CertificateBundle&&) noexcept = default;

  std::uint32_t schema_version;
  V0WitnessBindingsV1 v0_bindings;
  AuditedFrameworkBindingsV1 framework_bindings;
  Digest256 evidence_graph_digest;
  std::optional<CertificateEvidenceIdV1> v1_geometry;
  std::optional<CertificateEvidenceIdV1> v2_dynamic_lift;
  std::optional<CertificateEvidenceIdV1> stationary_integrated_fidelity;
  std::optional<CertificateEvidenceIdV1> physical_fidelity;
  std::optional<CertificateEvidenceIdV1> stability;
  std::vector<CertificateEvidenceIdV1> transfer_claims;
  std::vector<CertificateEvidenceIdV1> response_envelopes;
  std::vector<CertificateEvidenceIdV1> decision_diagnostics;
  std::vector<CertificateEvidenceIdV1> poisson_rewards;
  std::vector<CertificateEvidenceIdV1> numerics;
  std::vector<CertificateEvidenceIdV1> complexity;
  std::vector<CertificateEvidenceIdV1> validation;
  std::vector<CertificateEvidenceIdV1> provenance;

  // Produces the V0-only baseline.  Callers then opt in to stronger evidence
  // by filling the independently typed optional/vector fields above.
  [[nodiscard]] static CertificateBundle v0_only(const Evidence& evidence);

 private:
  CertificateBundle(
      std::uint32_t version, V0WitnessBindingsV1 bindings,
      AuditedFrameworkBindingsV1 audited_bindings, Digest256 graph_digest,
      std::shared_ptr<const certificates::detail::EvidenceGraphSealIdentity>
          graph_seal)
      : schema_version(version),
        v0_bindings(std::move(bindings)),
        framework_bindings(std::move(audited_bindings)),
        evidence_graph_digest(std::move(graph_digest)),
        v1_geometry(std::nullopt),
        v2_dynamic_lift(std::nullopt),
        stationary_integrated_fidelity(std::nullopt),
        physical_fidelity(std::nullopt),
        stability(std::nullopt),
        transfer_claims(),
        response_envelopes(),
        decision_diagnostics(),
        poisson_rewards(),
        numerics(),
        complexity(),
        validation(),
        provenance(),
        graph_seal_(std::move(graph_seal)) {}

  std::shared_ptr<const certificates::detail::EvidenceGraphSealIdentity>
      graph_seal_;
  friend class certificates::detail::C25CoreAccess;
};

struct ValidatedClaimV1 final {
  CertificateClaimStateV1 state;
  CertificateClaimKindV1 kind;
  std::optional<CertificateEvidenceIdV1> evidence;
  CertificateCoverageV1 coverage;
  std::vector<CertificateEvidenceIdV1> dependency_closure;
  std::vector<std::string> diagnostics;
  BoundValueStatusV1 result_value_status;
  std::optional<long double> raw_result_value;
  std::optional<long double> presented_result_value;
};

class RowErrorBound final {
 public:
  RowErrorBound() = delete;
  RowErrorBound(const RowErrorBound&) = default;
  RowErrorBound(RowErrorBound&&) noexcept = default;
  RowErrorBound& operator=(const RowErrorBound&) = default;
  RowErrorBound& operator=(RowErrorBound&&) noexcept = default;

 private:
  RowErrorBound(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}

  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

class ContractionWitness final {
 public:
  ContractionWitness() = delete;
  ContractionWitness(const ContractionWitness&) = default;
  ContractionWitness(ContractionWitness&&) noexcept = default;
  ContractionWitness& operator=(const ContractionWitness&) = default;
  ContractionWitness& operator=(ContractionWitness&&) noexcept = default;

 private:
  ContractionWitness(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

class KilledKernelPair final {
 public:
  KilledKernelPair() = delete;
  KilledKernelPair(const KilledKernelPair&) = default;
  KilledKernelPair(KilledKernelPair&&) noexcept = default;
  KilledKernelPair& operator=(const KilledKernelPair&) = default;
  KilledKernelPair& operator=(KilledKernelPair&&) noexcept = default;

 private:
  KilledKernelPair(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

class ResolventWitness final {
 public:
  ResolventWitness() = delete;
  ResolventWitness(const ResolventWitness&) = default;
  ResolventWitness(ResolventWitness&&) noexcept = default;
  ResolventWitness& operator=(const ResolventWitness&) = default;
  ResolventWitness& operator=(ResolventWitness&&) noexcept = default;

 private:
  ResolventWitness(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

class DriftWitness final {
 public:
  DriftWitness() = delete;
  DriftWitness(const DriftWitness&) = default;
  DriftWitness(DriftWitness&&) noexcept = default;
  DriftWitness& operator=(const DriftWitness&) = default;
  DriftWitness& operator=(DriftWitness&&) noexcept = default;

 private:
  DriftWitness(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

class ResponseEnvelope final {
 public:
  ResponseEnvelope() = delete;
  ResponseEnvelope(const ResponseEnvelope&) = default;
  ResponseEnvelope(ResponseEnvelope&&) noexcept = default;
  ResponseEnvelope& operator=(const ResponseEnvelope&) = default;
  ResponseEnvelope& operator=(ResponseEnvelope&&) noexcept = default;

 private:
  ResponseEnvelope(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

// Arrival authority paired with a validated envelope.  This is intentionally
// not constructible from a one-slot marginal: it retains the exact configured
// arrival identity and the IID/temporal semantics validated by F-C25-01.
class CertificateArrivalLaw final {
 public:
  CertificateArrivalLaw() = delete;
  CertificateArrivalLaw(const CertificateArrivalLaw&) = default;
  CertificateArrivalLaw(CertificateArrivalLaw&&) noexcept = default;
  CertificateArrivalLaw& operator=(const CertificateArrivalLaw&) = default;
  CertificateArrivalLaw& operator=(CertificateArrivalLaw&&) noexcept =
      default;

 private:
  CertificateArrivalLaw(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

// Capability token for an independently established physical comparison.
// Merely carrying V0, feasible schedules, exact optimizers, or successful
// construction cannot mint this anchor.
class PhysicalFidelityAnchor final {
 public:
  PhysicalFidelityAnchor() = delete;
  PhysicalFidelityAnchor(const PhysicalFidelityAnchor&) = default;
  PhysicalFidelityAnchor(PhysicalFidelityAnchor&&) noexcept = default;
  PhysicalFidelityAnchor& operator=(const PhysicalFidelityAnchor&) = default;
  PhysicalFidelityAnchor& operator=(PhysicalFidelityAnchor&&) noexcept =
      default;

  [[nodiscard]] const Digest256& subject_product_identity() const noexcept;
  [[nodiscard]] const Digest256& subject_law_identity() const noexcept;
  [[nodiscard]] const Digest256& physical_reference_law_identity()
      const noexcept;
  [[nodiscard]] const Digest256& metric_identity() const noexcept;
  [[nodiscard]] const Digest256& regime_identity() const noexcept;
  [[nodiscard]] const Digest256& comparison_theorem_identity() const noexcept;
  [[nodiscard]] PhysicalFidelityKindV1 kind() const noexcept;
  [[nodiscard]] CertificateEvidenceOriginV1 origin() const noexcept;
  [[nodiscard]] const std::optional<long double>& finite_bound()
      const noexcept;

 private:
  PhysicalFidelityAnchor(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core,
      std::size_t index)
      : core_(std::move(core)), index_(index) {}
  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  std::size_t index_;
  friend class certificates::detail::C25CoreAccess;
};

class ValidatedCertificates final {
 public:
  ValidatedCertificates() = delete;
  ValidatedCertificates(const ValidatedCertificates&) = default;
  ValidatedCertificates(ValidatedCertificates&&) noexcept = default;
  ValidatedCertificates& operator=(const ValidatedCertificates&) = default;
  ValidatedCertificates& operator=(ValidatedCertificates&&) noexcept =
      default;

  [[nodiscard]] const V0WitnessReport& v0_report() const noexcept;
  [[nodiscard]] const Digest256& graph_digest() const noexcept;
  [[nodiscard]] const ValidatedClaimV1& v1_geometry() const noexcept;
  [[nodiscard]] const ValidatedClaimV1& v2_dynamic_lift() const noexcept;
  [[nodiscard]] const ValidatedClaimV1& stationary_integrated_fidelity()
      const noexcept;
  [[nodiscard]] const ValidatedClaimV1& physical_fidelity() const noexcept;
  [[nodiscard]] const ValidatedClaimV1& stability() const noexcept;
  [[nodiscard]] std::span<const ValidatedClaimV1> claims() const noexcept;
  [[nodiscard]] std::vector<ComplexityCostEvidenceV1> complexity_costs()
      const;

  [[nodiscard]] Result<RowErrorBound> row_error_bound(
      const CertificateEvidenceIdV1& evidence) const;
  [[nodiscard]] Result<ContractionWitness> contraction_witness(
      const CertificateEvidenceIdV1& evidence) const;
  [[nodiscard]] Result<KilledKernelPair> killed_kernel_pair(
      const CertificateEvidenceIdV1& evidence) const;
  [[nodiscard]] Result<ResolventWitness> resolvent_witness(
      const CertificateEvidenceIdV1& evidence) const;
  [[nodiscard]] Result<DriftWitness> drift_witness(
      const CertificateEvidenceIdV1& evidence) const;
  [[nodiscard]] Result<ResponseEnvelope> response_envelope(
      const CertificateEvidenceIdV1& evidence) const;
  [[nodiscard]] Result<CertificateArrivalLaw> certificate_arrival_law(
      const CertificateEvidenceIdV1& envelope_evidence) const;
  [[nodiscard]] Result<PhysicalFidelityAnchor> physical_fidelity_anchor()
      const;

 private:
  explicit ValidatedCertificates(
      std::shared_ptr<const certificates::detail::ValidatedCertificateCore>
          core)
      : core_(std::move(core)) {}

  std::shared_ptr<const certificates::detail::ValidatedCertificateCore> core_;
  friend class certificates::detail::C25CoreAccess;
};

// F-C25-01.  The carrier's successful V0 report is authoritative.  Every
// stronger claim remains optional and is evaluated independently.
[[nodiscard]] Result<ValidatedCertificates> validate_certificate_bundle(
    const CertificateBundle& bundle,
    const AuditedCompiledFramework& framework,
    const Evidence& evidence);

}  // namespace mwperf
