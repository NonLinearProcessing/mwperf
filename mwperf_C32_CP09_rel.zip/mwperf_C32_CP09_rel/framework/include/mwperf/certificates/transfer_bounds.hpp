#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// C22 uses the same public spelling for a nonnegative, arbitrary-precision
// horizon.  Repeating the alias here keeps C25's transfer API independent of
// a temporal backend: certificate evaluation consumes evidence, not a live
// C22 solver.
using Horizon = BigNat;

enum class CertificateClaimStateV1 : std::uint8_t {
  established,
  refuted,
  not_established,
};

enum class BoundValueStatusV1 : std::uint8_t {
  finite,
  infinite,
  unresolved,
};

enum class TransferGeometryKindV1 : std::uint8_t {
  total_variation,
  wasserstein_metric,
  weighted_total_variation,
  operator_norm,
};

enum class TvConventionV1 : std::uint8_t {
  supremum_event_difference,
};

enum class TransferScopeV1 : std::uint8_t {
  finite_residence_words,
  finite_relational_slots,
  stationary_law,
  stopped_potential,
  entrance_averaged_stopped_potential,
};

enum class HorizonDomainV1 : std::uint8_t {
  complete_residence_words,
  relational_slots,
};

// TV rewards must have a finite, explicitly supplied range.  Omitting both
// endpoints means that only event/[0,1]-reward consequences are requested.
struct TotalVariationGeometryV1 final {
  Digest256 geometry_identity;
  Digest256 state_space_identity;
  Digest256 observable_identity;
  TvConventionV1 convention;
  std::optional<long double> reward_lower;
  std::optional<long double> reward_upper;

  friend bool operator==(const TotalVariationGeometryV1&,
                         const TotalVariationGeometryV1&) = default;
};

// These booleans are validated evidence statements, not knobs that make a
// cost into a metric.  C25 rejects the geometry unless every required metric
// and moment premise is independently established.
struct WassersteinGeometryV1 final {
  Digest256 geometry_identity;
  Digest256 state_space_identity;
  Digest256 metric_identity;
  bool lower_semicontinuous;
  bool triangle_inequality;
  bool generates_borel_sigma_field;
  bool reference_first_moment_finite;
  bool approximate_first_moment_finite;
  std::optional<long double> reward_lipschitz_modulus;
  bool reward_expectations_exist;

  friend bool operator==(const WassersteinGeometryV1&,
                         const WassersteinGeometryV1&) = default;
};

struct WeightedGeometryV1 final {
  Digest256 geometry_identity;
  Digest256 state_space_identity;
  Digest256 norm_identity;
  bool complete_normed_space;
  bool shared_foster_lyapunov_tail;
  std::optional<long double> reward_dual_modulus;

  friend bool operator==(const WeightedGeometryV1&,
                         const WeightedGeometryV1&) = default;
};

enum class OperatorNormKindV1 : std::uint8_t {
  weighted_supremum,
};

struct OperatorNormGeometryV1 final {
  Digest256 geometry_identity;
  Digest256 state_space_identity;
  Digest256 norm_identity;
  OperatorNormKindV1 kind;
  // For ||x||_w=max_i |x_i|/w_i.  Every weight must be strictly positive.
  std::vector<ExactRational> weights;
  bool complete_normed_space;
  bool contains_constant_one;

  friend bool operator==(const OperatorNormGeometryV1&,
                         const OperatorNormGeometryV1&) = default;
};

using TransferGeometryV1 =
    std::variant<TotalVariationGeometryV1, WassersteinGeometryV1,
                 WeightedGeometryV1, OperatorNormGeometryV1>;

struct MetricGeometry final {
  TransferGeometryV1 value;

  [[nodiscard]] TransferGeometryKindV1 kind() const noexcept;

  friend bool operator==(const MetricGeometry&,
                         const MetricGeometry&) = default;
};

enum class ErrorBoundComponentKindV1 : std::uint8_t {
  finite_row_compounding,
  initial_relation_defect,
  contraction_amplification,
  killed_kernel,
  entrance_law,
  potential_numerical_residual,
};

// Raw theorem inputs are serialized independently of the resulting bound.
// This is intentionally a closed vocabulary: consumers can display
// conditioning and near-critical constants without parsing labels or
// reverse-engineering a multiplied total.
enum class ErrorBoundConstantKindV1 : std::uint8_t {
  horizon,
  initial_defect,
  row_defect,
  reward_scale,
  contraction_coefficient,
  contraction_gap,
  conditioning_factor,
  reference_resolvent_norm,
  killed_kernel_defect_norm,
  approximate_potential_norm,
  reference_entrance_dual_norm,
  entrance_defect_dual_norm,
  inverse_residual_conversion,
};

struct ErrorBoundConstantV1 final {
  ErrorBoundConstantKindV1 kind;
  std::optional<BigNat> natural_value;
  std::optional<ExactRational> exact_value;
  std::optional<long double> numerical_value;
  std::string label;

  friend bool operator==(const ErrorBoundConstantV1&,
                         const ErrorBoundConstantV1&) = default;
};

struct ErrorBoundComponentV1 final {
  ErrorBoundComponentKindV1 kind;
  BoundValueStatusV1 value_status;
  std::optional<ExactRational> exact_value;
  std::optional<long double> numerical_value;
  std::string label;
  std::vector<std::string> assumptions;

  friend bool operator==(const ErrorBoundComponentV1&,
                         const ErrorBoundComponentV1&) = default;
};

// A presentation cap is never allowed to overwrite raw_value.  In
// particular, stationary TV retains epsilon/(1-c) even when the displayed TV
// distance is capped at one.  Components remain ordered and individually
// visible to F-C25-07.
struct ErrorBound final {
  CertificateClaimStateV1 claim_state;
  BoundValueStatusV1 value_status;
  std::string theorem_id;
  TransferScopeV1 scope;
  MetricGeometry geometry;
  std::optional<ExactRational> exact_raw_value;
  std::optional<long double> raw_value;
  std::optional<long double> presented_value;
  std::optional<long double> union_bound;
  std::optional<long double> conditioning_factor;
  bool presentation_capped;
  ArtifactObjectReferenceV1 reference_law;
  ArtifactObjectReferenceV1 approximate_law;
  std::vector<ErrorBoundConstantV1> raw_constants;
  std::vector<ErrorBoundComponentV1> components;
  std::vector<std::string> assumptions;
  std::string numerical_method;

  friend bool operator==(const ErrorBound&, const ErrorBound&) = default;
};

// Nonconstructible validated views.  Their definitions live in
// certificate_bundle.hpp; raw evidence cannot call these theorem evaluators.
class RowErrorBound;
class ContractionWitness;
class KilledKernelPair;
class ResolventWitness;

// F-C25-02
[[nodiscard]] Result<ErrorBound> compute_finite_horizon_tv_transfer(
    const RowErrorBound& row_error, const Horizon& horizon);

// F-C25-03
[[nodiscard]] Result<ErrorBound> compute_contraction_transfer(
    const RowErrorBound& row_error, const ContractionWitness& contraction,
    const MetricGeometry& geometry);

// F-C25-04
[[nodiscard]] Result<ErrorBound> compute_stopped_resolvent_transfer(
    const KilledKernelPair& kernels, const ResolventWitness& resolvent);

// F-C25-05/F-C25-06 consume only views issued by F-C25-01.  In particular,
// neither raw provider evidence nor an arrival marginal supplied by a caller
// can be passed directly to a theorem evaluator.
class AuditedCompiledFramework;
class DriftWitness;
class ResponseEnvelope;
class CertificateArrivalLaw;

enum class StabilityConclusionV1 : std::uint8_t {
  none,
  time_average_drift,
  recurrence,
  positive_recurrence,
  selected_invariant_law,
};

struct StabilityCertificate final {
  CertificateClaimStateV1 claim_state;
  StabilityConclusionV1 strongest_conclusion;
  CertificateClaimStateV1 time_average_claim;
  CertificateClaimStateV1 recurrence_claim;
  CertificateClaimStateV1 positive_recurrence_claim;
  BoundValueStatusV1 time_average_bound_status;
  std::optional<long double> epsilon;
  std::optional<long double> approximation_slope_delta;
  std::optional<long double> additive_gap_b;
  std::optional<long double> deterministic_row_tolerance;
  std::optional<long double> arrival_second_norm_moment;
  std::optional<long double> maximum_schedule_squared_norm;
  std::optional<Digest256> common_joint_schedule_law_identity;
  std::optional<long double> drift_constant_c0;
  std::optional<long double> negative_drift_coefficient;
  std::optional<long double> time_average_backlog_bound;
  std::string theorem_id;
  std::vector<std::string> assumptions;
  std::vector<std::string> diagnostics;
  std::string numerical_method;
};

enum class EnvelopeEvaluationRouteV1 : std::uint8_t {
  exact_finite_closure,
  reachable_tail_strict_slack,
  augmented_temporal_backend,
  unavailable,
};

enum class ResponseOrderStrengthV1 : std::uint8_t {
  pathwise_stochastic,
  stationary_stochastic,
  stationary_mlr_and_stochastic,
  unavailable,
};

enum class EnvelopeTailSlackStatusV1 : std::uint8_t {
  applicable,
  not_applicable_off_class,
  not_established,
};

// `infinite` is an exposed unbounded side, while `unresolved` together with a
// not-established claim records theorem unavailability.  They must not be
// serialized as the same outcome.
struct MetricIntervalEndpointV1 final {
  BoundValueStatusV1 value_status;
  CertificateClaimStateV1 claim_state;
  std::optional<ExactRational> exact_value;
  std::optional<long double> numerical_value;
  std::string source_label;
  std::vector<std::string> assumptions;
};

struct MetricInterval final {
  CertificateClaimStateV1 claim_state;
  MetricKindV1 metric_kind;
  EnvelopeEvaluationRouteV1 route;
  ResponseOrderStrengthV1 order_strength;
  EnvelopeTailSlackStatusV1 tail_slack_status;
  MetricIntervalEndpointV1 lower;
  MetricIntervalEndpointV1 upper;
  CertificateClaimStateV1 physical_transfer_claim;
  std::optional<long double> arrival_intensity;
  std::optional<long double> slow_tail_service;
  std::optional<long double> fast_tail_service;
  std::optional<long double> slow_tail_slack;
  std::optional<long double> fast_tail_slack;
  std::string theorem_id;
  std::vector<std::string> assumptions;
  std::vector<std::string> diagnostics;
  std::string numerical_method;
};

// F-C25-05
[[nodiscard]] Result<StabilityCertificate>
validate_drift_stability_witness(
    const DriftWitness& witness,
    const AuditedCompiledFramework& framework);

// F-C25-06
[[nodiscard]] Result<MetricInterval> evaluate_response_envelope(
    const ResponseEnvelope& envelope, const CertificateArrivalLaw& arrival,
    const MetricRequest& request);

}  // namespace mwperf
