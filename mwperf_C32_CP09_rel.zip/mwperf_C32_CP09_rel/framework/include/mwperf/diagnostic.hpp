#pragma once

#include <optional>
#include <string>
#include <vector>

namespace mwperf {

enum class DiagnosticCategory {
  cli_usage,
  input_validation,
  resource_limit,
  unavailable,
  internal,
  information,
};

struct Diagnostic {
  DiagnosticCategory category;
  std::string code;
  std::string message;
  std::optional<std::string> authored_path;
  std::optional<std::string> json_pointer;
  std::vector<std::string> notes;

  friend bool operator==(const Diagnostic&, const Diagnostic&) = default;
};

[[nodiscard]] std::string render_cli_diagnostic(const Diagnostic& diagnostic);

}  // namespace mwperf
