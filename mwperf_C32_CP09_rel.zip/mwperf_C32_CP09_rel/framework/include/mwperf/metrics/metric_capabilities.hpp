#pragma once

#include <span>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// F-C14-01
[[nodiscard]] Result<MetricRequest> parse_metric_request(
    const MetricNode& node, const QueueCatalog& queue_catalog);

// F-C14-02 is declared in metric_requirements.hpp.
// F-C14-03 is declared in metric_requirements.hpp.

// F-C14-04
[[nodiscard]] CapabilityDecision negotiate_capabilities(
    const MetricRequirements& requirements,
    const PlugDescriptorPreview& preview,
    const ArrivalCapabilities& arrival_capabilities);

// F-C14-05
[[nodiscard]] Diagnostic explain_capability_failure(
    const CapabilityDecision& decision);

}  // namespace mwperf
