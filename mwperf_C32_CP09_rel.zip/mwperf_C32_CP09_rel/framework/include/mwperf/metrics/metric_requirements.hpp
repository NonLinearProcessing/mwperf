#pragma once

#include <compare>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// Stable structural identity for one requirement clause.  metric_id remains
// the authored identity; authored_index makes diagnostics deterministic even
// when callers aggregate an equivalent request list in another traversal
// order.  This is not an artifact or product identity.
struct MetricClauseIdV1 final {
  std::string metric_id;
  std::size_t authored_index;

  friend bool operator==(const MetricClauseIdV1&,
                         const MetricClauseIdV1&) = default;
  friend std::strong_ordering operator<=>(const MetricClauseIdV1&,
                                           const MetricClauseIdV1&) = default;
};

// A requirement clause retains a source-independent exact projection of the
// request as well as the immutable contextual object.  The context is needed
// because transient initial coupling, a named invariant selection, and the
// complete accuracy/resolution policy must never be reconstructed from a
// coarser enum.  Canonical comparison/digest functions below compare context
// values, not shared_ptr ownership.
struct MetricClauseOriginV1 final {
  MetricClauseIdV1 clause_id;
  MetricKindV1 kind;
  MetricRequestParametersV1 parameters;
  MetricTargetCouplingV1 wire_coupling;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  MetricSelectionRegimeV1 selection_regime;
  MetricSolverRegimeV1 solver_regime;
  std::shared_ptr<const AnalysisContext> context;
  SourceProvenance provenance;
};

// These are requirement-side law forms, not the nine deployed provider
// semantic tags.  In particular, a finite cylinder is a view derived by the
// framework from a temporal one-slot continuation; it is never a tenth
// SemanticTagV1.
enum class ReusableMetricLawKindV1 : std::uint8_t {
  framework_derived_scalar,
  selected_invariant_marginal,
  stationary_marked_edge,
  finite_cylinder_from_temporal_continuation,
  exact_point_response,
  pushforward_count_law,
  residence_word,
  stopped_path,
  exact_request_decoder,
};

enum class FrameworkScalarKindV1 : std::uint8_t {
  arrival_intensity,
  stationary_backlog_mean,
  event_intensity_active_fraction,
  binary_occupation_start_ratio,
};

struct FrameworkDerivedScalarRequirementV1 final {
  FrameworkScalarKindV1 scalar;

  friend bool operator==(const FrameworkDerivedScalarRequirementV1&,
                         const FrameworkDerivedScalarRequirementV1&) =
      default;
};

struct SelectedInvariantMarginalRequirementV1 final {
  bool retain_predictive_phase;

  friend bool operator==(const SelectedInvariantMarginalRequirementV1&,
                         const SelectedInvariantMarginalRequirementV1&) =
      default;
};

struct StationaryMarkedEdgeRequirementV1 final {
  // Completion-bound marks must be decoded from the same immutable edge.
  bool completion_bound;

  friend bool operator==(const StationaryMarkedEdgeRequirementV1&,
                         const StationaryMarkedEdgeRequirementV1&) = default;
};

enum class FiniteCylinderFamilyV1 : std::uint8_t {
  target_backlog,
  target_departure,
  target_predicate,
  coupled_backlog,
  coupled_schedule,
  generic_marked_word,
};

struct ExplicitCylinderOffsetsV1 final {
  // Canonically sorted, duplicate-free, and nonempty.
  std::vector<BigNat> offsets;

  friend bool operator==(const ExplicitCylinderOffsetsV1&,
                         const ExplicitCylinderOffsetsV1&) = default;
};

struct InclusiveCylinderThroughV1 final {
  // Represents every offset 0,1,...,maximum_offset symbolically.  It must
  // never be expanded merely to form a requirement or aggregate summary.
  BigNat maximum_offset;

  friend bool operator==(const InclusiveCylinderThroughV1&,
                         const InclusiveCylinderThroughV1&) = default;
};

struct InclusiveCylinderThroughWithExtraOffsetsV1 final {
  // Canonical join form when an inclusive range is conjoined with explicit
  // offsets beyond that range.  extra_offsets contains only values strictly
  // greater than maximum_offset and is sorted and duplicate-free.
  BigNat maximum_offset;
  std::vector<BigNat> extra_offsets;

  friend bool operator==(
      const InclusiveCylinderThroughWithExtraOffsetsV1&,
      const InclusiveCylinderThroughWithExtraOffsetsV1&) = default;
};

using FiniteCylinderCoverageV1 =
    std::variant<ExplicitCylinderOffsetsV1, InclusiveCylinderThroughV1,
                 InclusiveCylinderThroughWithExtraOffsetsV1>;

struct FiniteCylinderRequirementV1 final {
  FiniteCylinderFamilyV1 family;
  // An autocovariance request uses explicit offsets; a rectangularly
  // truncated spectrum uses an inclusive range through L.  Keeping those
  // forms distinct prevents the latter from being weakened to {L} and avoids
  // O(L) materialization for an arbitrary-precision L.
  FiniteCylinderCoverageV1 coverage;
  bool ordered_word_sufficient;

  friend bool operator==(const FiniteCylinderRequirementV1&,
                         const FiniteCylinderRequirementV1&) = default;
};

struct ExactPointResponseRequirementV1 final {
  std::vector<BigNat> represented_levels;
  bool require_positive_stationary_conditioning_mass;
  bool permit_declared_off_support_convention;

  friend bool operator==(const ExactPointResponseRequirementV1&,
                         const ExactPointResponseRequirementV1&) = default;
};

struct PushforwardCountLawRequirementV1 final {
  BigNat width;

  friend bool operator==(const PushforwardCountLawRequirementV1&,
                         const PushforwardCountLawRequirementV1&) = default;
};

enum class StoppingObservableKindV1 : std::uint8_t {
  next_event,
  predicate_exit,
  backlog_set_hit,
  threshold_return,
  tagged_packet_departure,
  counterfactual_mark,
};

struct ResidenceWordRequirementV1 final {
  StoppingObservableKindV1 stop;
  std::optional<BigNat> output_horizon;
  bool retain_terminal_and_reentry;

  friend bool operator==(const ResidenceWordRequirementV1&,
                         const ResidenceWordRequirementV1&) = default;
};

struct StoppedPathRequirementV1 final {
  StoppingObservableKindV1 stop;
  std::optional<BigNat> output_horizon;
  bool may_be_defective;
  bool finite_mean_requested;

  friend bool operator==(const StoppedPathRequirementV1&,
                         const StoppedPathRequirementV1&) = default;
};

struct ExactRequestDecoderRequirementV1 final {
  // The surrounding clause origin supplies the exact request, target,
  // selection, arrival, parameter-domain, and accuracy key.  This marker is
  // deliberately not a wildcard or a nearby-request decoder.
  bool exact_match_only;

  friend bool operator==(const ExactRequestDecoderRequirementV1&,
                         const ExactRequestDecoderRequirementV1&) = default;
};

using ReusableMetricLawRequirementV1 = std::variant<
    FrameworkDerivedScalarRequirementV1,
    SelectedInvariantMarginalRequirementV1,
    StationaryMarkedEdgeRequirementV1, FiniteCylinderRequirementV1,
    ExactPointResponseRequirementV1, PushforwardCountLawRequirementV1,
    ResidenceWordRequirementV1, StoppedPathRequirementV1,
    ExactRequestDecoderRequirementV1>;

enum class EntranceLawRequirementV1 : std::uint8_t {
  none,
  configured_transient_initial,
  prescribed_entrance,
  event_palm,
  run_start_palm,
  admission_palm,
  threshold_crossing_palm,
};

// Alternatives are disjunctive within one metric clause.  Their fields are
// conjunctive: e.g. FIFO is admission_palm + stopped_path, and joint FIFO is
// additionally common-schedule coupled.
struct SemanticContractAlternativeV1 final {
  ReusableMetricLawRequirementV1 law;
  EntranceLawRequirementV1 entrance;
  TargetCouplingV1 coupling;
  bool require_temporal_one_slot_source;
  bool require_full_history_predictive_sufficiency;

  friend bool operator==(const SemanticContractAlternativeV1&,
                         const SemanticContractAlternativeV1&) = default;
};

enum class MarkRelationRequirementV1 : std::uint8_t {
  individual,
  same_completed_edge,
  same_arrival_realization,
  ordered_temporal_word,
  common_feasible_schedule,
  entrance_bound,
};

enum class MarkTargetScopeRequirementV1 : std::uint8_t {
  singleton_target,
  every_ordered_metric_target,
  ordered_metric_target_vector,
  full_schedule_catalog,
};

struct MarkRequirementV1 final {
  MetricMarkKindV1 kind;
  // This is the latest causally valid stage.  A provider may offer a genuine
  // decoder at the same or an earlier ordinary slot stage.  entrance_label is
  // incomparable and must match explicitly.
  MetricRevealStageV1 latest_reveal_stage;
  MarkRelationRequirementV1 relation;
  MarkTargetScopeRequirementV1 target_scope;

  friend bool operator==(const MarkRequirementV1&,
                         const MarkRequirementV1&) = default;
};

struct SelectionRequirementV1 final {
  // Only the six configured analysis selection kinds occur here.  Palm and
  // prescribed entrances are represented separately above and cannot replace
  // the selected initial/invariant regime.
  std::vector<SelectionKindV1> accepted_analysis_selections;
  EntranceLawRequirementV1 entrance;
  bool require_unique_or_explicit_selection;

  friend bool operator==(const SelectionRequirementV1&,
                         const SelectionRequirementV1&) = default;
};

using ArrivalRequirementV1 = ArrivalAssumptionV1;

// Every member of one alternative is required; alternatives are disjunctive.
// This is essential for a phase-free response that may use either an IID-late
// analytic shortcut or a composed sequential predictive-phase backend.  The
// two routes must not be accidentally conjoined or freely cross-combined.
struct ArrivalRequirementAlternativeV1 final {
  std::vector<ArrivalRequirementV1> all_of;

  friend bool operator==(const ArrivalRequirementAlternativeV1&,
                         const ArrivalRequirementAlternativeV1&) = default;
};

struct ArrivalRequirementSetV1 final {
  std::vector<ArrivalRequirementAlternativeV1> alternatives;

  friend bool operator==(const ArrivalRequirementSetV1&,
                         const ArrivalRequirementSetV1&) = default;
};

enum class HypothesisSatisfactionKindV1 : std::uint8_t {
  required_evidence,
  required_or_declared_off_support_convention,
  theorem_or_separate_evidence,
};

struct HypothesisRequirementV1 final {
  HypothesisClaimV1 claim;
  HypothesisSatisfactionKindV1 satisfaction;

  friend bool operator==(const HypothesisRequirementV1&,
                         const HypothesisRequirementV1&) = default;
};

enum class MomentConditioningV1 : std::uint8_t {
  unconditioned,
  stationary,
  queried_backlog_level,
  event_palm,
  admission_palm,
  stopped_entrance,
};

// Kept separately from generic hypotheses so aggregation can take the maximum
// order only for the same variable, target scope, and conditioning law.
struct MomentRequirementV1 final {
  MomentVariableV1 variable;
  BigNat order;
  MomentConditioningV1 conditioning;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  bool joint;

  friend bool operator==(const MomentRequirementV1&,
                         const MomentRequirementV1&) = default;
};

enum class BackendRouteKindV1 : std::uint8_t {
  framework_scalar_identity,
  stationary_invariant,
  stationary_edge_reward,
  finite_temporal_cylinder,
  analytic_metric_family,
  residence_or_stopped_law,
  palm_or_fifo_law,
  conditional_row_monte_carlo,
  conditional_reward_monte_carlo,
  exact_direct,
};

struct AccessAlternativeV1 final {
  RuntimeAccessTagV1 runtime_access;
  BackendRouteKindV1 backend_route;
  // C24 v1 is row/reward conditional only.  It is never a generic temporal,
  // stopped, Palm, or FIFO estimator.
  bool c24_row_or_reward_only;
  bool exact_request_only;

  friend bool operator==(const AccessAlternativeV1&,
                         const AccessAlternativeV1&) = default;
};

struct AccessRequirementV1 final {
  SolverRegimeV1 solver_regime;
  std::vector<AccessAlternativeV1> alternatives;

  friend bool operator==(const AccessRequirementV1&,
                         const AccessRequirementV1&) = default;
};

// One complete admissible route.  The semantic law, runtime representation,
// configured-arrival assumptions, and route-specific mathematical premises
// are correlated and must be matched as this tuple.  Negotiation must never
// choose each axis independently from the summary disjunctions below.
struct MetricRouteAlternativeV1 final {
  SemanticContractAlternativeV1 semantic;
  AccessAlternativeV1 access;
  ArrivalRequirementAlternativeV1 arrival;
  std::vector<MarkRequirementV1> marks;
  std::vector<HypothesisRequirementV1> hypotheses;

  friend bool operator==(const MetricRouteAlternativeV1&,
                         const MetricRouteAlternativeV1&) = default;
};

struct AccuracyRequirementV1 final {
  SolverRegimeV1 solver_regime;
  AccuracyContractV1 contract;
  bool require_declared_error_or_certificate;

  friend bool operator==(const AccuracyRequirementV1&,
                         const AccuracyRequirementV1&) = default;
};

struct ValidityRequirementV1 final {
  // Always true for analysis-v1.  Keeping it explicit prevents optional V1,
  // V2, fidelity, or empirical evidence from being substituted for V0.
  bool mandatory_v0;

  friend bool operator==(const ValidityRequirementV1&,
                         const ValidityRequirementV1&) = default;
};

struct MetricRequirementClause final {
  MetricClauseOriginV1 origin;
  // This list is the authoritative disjunction of complete valid routes.
  std::vector<MetricRouteAlternativeV1> route_alternatives;
  // The following fields are canonical acceleration projections of the route
  // list.  They are useful for diagnostics but cannot authorize an axis-wise
  // cross product or require a mark that is absent from the selected complete
  // route.
  std::vector<SemanticContractAlternativeV1> semantic_alternatives;
  std::vector<MarkRequirementV1> marks;
  TargetCouplingV1 coupling;
  SelectionRequirementV1 selection;
  ArrivalRequirementSetV1 arrival;
  AccessRequirementV1 access;
  std::vector<HypothesisRequirementV1> hypotheses;
  std::vector<MomentRequirementV1> moments;
  AccuracyRequirementV1 accuracy;
  ValidityRequirementV1 validity;
};

enum class RegimeCompatibilityKindV1 : std::uint8_t {
  invalid_empty_request_set,
  compatible,
  incompatible_selection,
  incompatible_solver,
  incompatible_selection_and_solver,
};

struct RegimeCompatibilityV1 final {
  RegimeCompatibilityKindV1 kind;
  std::optional<MetricSelectionRegimeV1> common_selection;
  std::optional<MetricSolverRegimeV1> common_solver;
  // Canonically ordered participating clauses make a rejection deterministic.
  std::vector<MetricClauseIdV1> conflicting_clauses;

  friend bool operator==(const RegimeCompatibilityV1&,
                         const RegimeCompatibilityV1&) = default;
};

// Only cylinders in the same family, target order, coupling, and entrance law
// are nested.  Stopped and Palm laws are intentionally absent from this
// summary because generally they are incomparable.
struct CylinderRequirementSummaryV1 final {
  FiniteCylinderFamilyV1 family;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  TargetCouplingV1 coupling;
  EntranceLawRequirementV1 entrance;
  FiniteCylinderCoverageV1 coverage;
  BigNat maximum_offset;

  friend bool operator==(const CylinderRequirementSummaryV1&,
                         const CylinderRequirementSummaryV1&) = default;
};

struct MomentRequirementSummaryV1 final {
  MomentVariableV1 variable;
  MomentConditioningV1 conditioning;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  bool joint;
  BigNat maximum_order;

  friend bool operator==(const MomentRequirementSummaryV1&,
                         const MomentRequirementSummaryV1&) = default;
};

// The clauses are authoritative.  Every following field is a canonical
// acceleration index and must be derivable without loss from those clauses.
// authored_diagnostic_order is intentionally excluded from semantic equality
// and digest so a join remains commutative while diagnostics retain source
// order in the ordinary orchestration path.
class MetricRequirementsAccess;

class MetricRequirements final {
 public:
  MetricRequirements(const MetricRequirements&) = default;
  MetricRequirements(MetricRequirements&&) noexcept = default;
  MetricRequirements& operator=(const MetricRequirements&) = default;
  MetricRequirements& operator=(MetricRequirements&&) noexcept = default;

  [[nodiscard]] std::uint32_t schema_version() const noexcept {
    return schema_version_;
  }
  [[nodiscard]] std::span<const MetricRequirementClause> clauses() const
      noexcept {
    return clauses_;
  }
  [[nodiscard]] std::span<const MetricClauseIdV1> authored_diagnostic_order()
      const noexcept {
    return authored_diagnostic_order_;
  }
  [[nodiscard]] std::span<const ResolvedMetricTargetV1> target_union() const
      noexcept {
    return target_union_;
  }
  [[nodiscard]] std::span<const MarkRequirementV1> mark_union() const
      noexcept {
    return mark_union_;
  }
  // Arrival alternatives remain conjunctive per clause; flattening their
  // atoms into a union would destroy the IID-versus-temporal disjunction.
  [[nodiscard]] std::span<const ArrivalRequirementSetV1>
  arrival_conjunction() const noexcept {
    return arrival_conjunction_;
  }
  // Canonically deduplicated per-clause route sets.  Like clauses themselves,
  // these sets are conjunctive across metrics and disjunctive within a metric.
  [[nodiscard]] const std::vector<std::vector<MetricRouteAlternativeV1>>&
  route_conjunction() const noexcept {
    return route_conjunction_;
  }
  [[nodiscard]] std::span<const HypothesisRequirementV1> hypothesis_union()
      const noexcept {
    return hypothesis_union_;
  }
  [[nodiscard]] std::span<const CylinderRequirementSummaryV1>
  cylinder_summaries() const noexcept {
    return cylinder_summaries_;
  }
  [[nodiscard]] std::span<const MomentRequirementSummaryV1> moment_summaries()
      const noexcept {
    return moment_summaries_;
  }
  [[nodiscard]] std::span<const AccuracyRequirementV1> accuracy_conjunction()
      const noexcept {
    return accuracy_conjunction_;
  }
  [[nodiscard]] const RegimeCompatibilityV1& regime_compatibility() const
      noexcept {
    return regime_compatibility_;
  }
  [[nodiscard]] bool mandatory_v0() const noexcept { return mandatory_v0_; }

 private:
  MetricRequirements(
      std::uint32_t schema_version,
      std::vector<MetricRequirementClause> clauses,
      std::vector<MetricClauseIdV1> authored_diagnostic_order,
      std::vector<ResolvedMetricTargetV1> target_union,
      std::vector<MarkRequirementV1> mark_union,
      std::vector<ArrivalRequirementSetV1> arrival_conjunction,
      std::vector<std::vector<MetricRouteAlternativeV1>> route_conjunction,
      std::vector<HypothesisRequirementV1> hypothesis_union,
      std::vector<CylinderRequirementSummaryV1> cylinder_summaries,
      std::vector<MomentRequirementSummaryV1> moment_summaries,
      std::vector<AccuracyRequirementV1> accuracy_conjunction,
      RegimeCompatibilityV1 regime_compatibility, bool mandatory_v0)
      : schema_version_(schema_version),
        clauses_(std::move(clauses)),
        authored_diagnostic_order_(std::move(authored_diagnostic_order)),
        target_union_(std::move(target_union)),
        mark_union_(std::move(mark_union)),
        arrival_conjunction_(std::move(arrival_conjunction)),
        route_conjunction_(std::move(route_conjunction)),
        hypothesis_union_(std::move(hypothesis_union)),
        cylinder_summaries_(std::move(cylinder_summaries)),
        moment_summaries_(std::move(moment_summaries)),
        accuracy_conjunction_(std::move(accuracy_conjunction)),
        regime_compatibility_(std::move(regime_compatibility)),
        mandatory_v0_(mandatory_v0) {}

  std::uint32_t schema_version_;
  std::vector<MetricRequirementClause> clauses_;
  std::vector<MetricClauseIdV1> authored_diagnostic_order_;
  std::vector<ResolvedMetricTargetV1> target_union_;
  std::vector<MarkRequirementV1> mark_union_;
  std::vector<ArrivalRequirementSetV1> arrival_conjunction_;
  std::vector<std::vector<MetricRouteAlternativeV1>> route_conjunction_;
  std::vector<HypothesisRequirementV1> hypothesis_union_;
  std::vector<CylinderRequirementSummaryV1> cylinder_summaries_;
  std::vector<MomentRequirementSummaryV1> moment_summaries_;
  std::vector<AccuracyRequirementV1> accuracy_conjunction_;
  RegimeCompatibilityV1 regime_compatibility_;
  bool mandatory_v0_;

  friend class MetricRequirementsAccess;
};

// Value comparison and digest use canonical exact context values and ignore
// only authored_diagnostic_order.  Neither function compares shared_ptr
// ownership, source byte offsets, or optional reported V1/V2 evidence.
[[nodiscard]] bool equivalent_metric_requirements(
    const MetricRequirements& left, const MetricRequirements& right);

[[nodiscard]] Result<Digest256> canonical_metric_requirements_digest(
    const MetricRequirements& requirements);

// F-C14-02.  Returns a one-clause requirements aggregate.
[[nodiscard]] MetricRequirements requirements_for_metric(
    const MetricRequest& request);

// F-C14-03.  The analysis-v1 parser rejects an empty metric array.  Defensive
// direct use with an empty span returns an aggregate tagged
// invalid_empty_request_set; it is never a vacuous accepted analysis.  Every
// nonempty join is conjunctive, monotone, associative, commutative, and
// idempotent in the semantic comparison above.
[[nodiscard]] MetricRequirements aggregate_metric_requirements(
    std::span<const MetricRequest> requests);

}  // namespace mwperf
