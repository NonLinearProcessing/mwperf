#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <variant>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/temporal_contract.hpp"
#include "mwperf/stationary/flux.hpp"

namespace mwperf {

namespace metrics::detail {
struct KilledKernelCore;
struct KilledPotentialCore;
}

namespace detail {
class TemporalContractCoreAccess;
}

using Horizon = BigNat;

enum class BacklogRelationV1 : std::uint8_t {
  equal,
  at_or_above,
  at_or_below,
};

struct AnyStatePredicateV1 final {
  friend bool operator==(const AnyStatePredicateV1&,
                         const AnyStatePredicateV1&) = default;
};

struct ExactStatePredicateV1 final {
  ReducedStateV1 state;
  friend bool operator==(const ExactStatePredicateV1&,
                         const ExactStatePredicateV1&) = default;
};

struct TargetBacklogPredicateV1 final {
  std::size_t target_ordinal;
  BacklogRelationV1 relation;
  BigNat level;
  friend bool operator==(const TargetBacklogPredicateV1&,
                         const TargetBacklogPredicateV1&) = default;
};

struct BinaryStatePredicateV1 final {
  std::size_t target_ordinal;
  BinaryPredicateV1 predicate;
  friend bool operator==(const BinaryStatePredicateV1&,
                         const BinaryStatePredicateV1&) = default;
};

struct TargetBacklogOutsideHitSetPredicateV1 final {
  std::size_t target_ordinal;
  MetricHitSetV1 hit_set;
  friend bool operator==(const TargetBacklogOutsideHitSetPredicateV1&,
                         const TargetBacklogOutsideHitSetPredicateV1&) =
      default;
};

using TemporalStatePredicateV1 =
    std::variant<AnyStatePredicateV1, ExactStatePredicateV1,
                 TargetBacklogPredicateV1, BinaryStatePredicateV1,
                 TargetBacklogOutsideHitSetPredicateV1>;

struct AnyEdgePredicateV1 final {
  friend bool operator==(const AnyEdgePredicateV1&,
                         const AnyEdgePredicateV1&) = default;
};

struct TargetDeparturePredicateV1 final {
  std::size_t target_ordinal;
  bool value;
  friend bool operator==(const TargetDeparturePredicateV1&,
                         const TargetDeparturePredicateV1&) = default;
};

struct PositiveTargetArrivalPredicateV1 final {
  std::size_t target_ordinal;
  friend bool operator==(const PositiveTargetArrivalPredicateV1&,
                         const PositiveTargetArrivalPredicateV1&) = default;
};

struct BusyDenialEdgePredicateV1 final {
  std::size_t target_ordinal;
  friend bool operator==(const BusyDenialEdgePredicateV1&,
                         const BusyDenialEdgePredicateV1&) = default;
};

struct ExactRuntimeMarkPredicateV1 final {
  RuntimeMarkIdV1 mark_id;
  CodecIdentityV1 codec;
  std::vector<std::byte> canonical_value;
  friend bool operator==(const ExactRuntimeMarkPredicateV1&,
                         const ExactRuntimeMarkPredicateV1&) = default;
};

using TemporalEdgePredicateV1 =
    std::variant<AnyEdgePredicateV1, TargetDeparturePredicateV1,
                 PositiveTargetArrivalPredicateV1,
                 BusyDenialEdgePredicateV1, ExactRuntimeMarkPredicateV1>;

struct StateAtV1 final {
  BigNat offset;
  TemporalStatePredicateV1 predicate;
  friend bool operator==(const StateAtV1&, const StateAtV1&) = default;
};

struct EdgeMarkAtV1 final {
  BigNat offset;
  TemporalEdgePredicateV1 predicate;
  friend bool operator==(const EdgeMarkAtV1&, const EdgeMarkAtV1&) = default;
};

using CylinderObservationV1 = std::variant<StateAtV1, EdgeMarkAtV1>;

// A conjunction in authored output order.  C22 canonicalizes only a working
// copy of typed offsets and never changes this sequence.
struct CylinderEvent final {
  std::vector<CylinderObservationV1> observations;
};

struct SafeSet final {
  TemporalStatePredicateV1 predicate;
};

struct TypedAbsorptionMarkV1 final {
  std::string type_id;
  TemporalStatePredicateV1 successor_predicate;
  TemporalEdgePredicateV1 edge_predicate;
};

struct AbsorptionMarks final {
  std::vector<TypedAbsorptionMarkV1> types;
};

struct KilledRowDiagnosticsV1 final {
  std::size_t state_index;
  // For an exact source this is the exact unit row mass. For a certified
  // analytic source it is the exactly represented nominal atom mass; the
  // separate source-error enclosure below certifies the omitted numerical
  // source-law error and is never reclassified as physical absorption.
  ExactRational exact_source_mass;
  ExactRational exact_survivor_mass;
  std::vector<ExactRational> exact_typed_exit_masses;
  ExactRational exact_balance_residual;
  long double numerical_source_mass;
  long double numerical_survivor_mass;
  long double numerical_typed_exit_mass;
  long double numerical_balance_residual;
  // Exact finite rows carry the degenerate enclosure [0,0].  It remains a
  // distinct field and is never added to physical absorption.
  ExactRational source_error_lower;
  ExactRational source_error_upper;
};

struct TemporalBudgetReportV1 final {
  std::size_t requested_horizon;
  std::size_t state_count;
  std::size_t row_atom_count;
  std::size_t iterations;
  std::optional<std::size_t> maximum_states;
  std::optional<std::size_t> maximum_row_atoms;
  std::optional<std::size_t> maximum_iterations;
  // Retain the exact authored budget even when it is larger than size_t.
  // maximum_iterations is only its addressable diagnostic image.
  std::optional<BigNat> authored_maximum_iterations;
  ExactRational absolute_residual_tolerance;
  ExactRational relative_residual_tolerance;
  bool budget_stop;
};

class KilledKernel final {
 public:
  KilledKernel() = delete;
  KilledKernel(const KilledKernel&) = default;
  KilledKernel(KilledKernel&&) noexcept = default;
  KilledKernel& operator=(const KilledKernel&) = default;
  KilledKernel& operator=(KilledKernel&&) noexcept = default;

  [[nodiscard]] AuditedTemporalSourceKindV1 source_kind() const noexcept;
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept;
  [[nodiscard]] std::span<const std::string> exit_type_ids() const noexcept;
  [[nodiscard]] std::span<const KilledRowDiagnosticsV1> row_diagnostics()
      const noexcept;
  [[nodiscard]] std::size_t state_count() const noexcept;

 private:
  explicit KilledKernel(
      std::shared_ptr<const metrics::detail::KilledKernelCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::KilledKernelCore> core_;
  friend class detail::TemporalContractCoreAccess;
};

enum class ExtendedNonnegativeStatusV1 : std::uint8_t {
  finite,
  positive_infinity,
  not_established,
  numerically_unresolved,
};

struct ExtendedNonnegativeV1 final {
  ExtendedNonnegativeStatusV1 status;
  std::optional<ExactRational> exact_value;
};

struct PotentialCoordinateV1 final {
  std::size_t state_index;
  ExtendedNonnegativeV1 value;
  std::optional<ExactRational> exact_equation_residual;
};

struct PotentialSolveDiagnosticsV1 final {
  std::vector<std::vector<std::size_t>> closed_survivor_classes;
  std::size_t finite_dimension;
  std::size_t exact_rank;
  long double reciprocal_condition_estimate;
  long double condition_warning_threshold;
  bool condition_warning;
  std::string method;
  std::size_t zero_start_iterations;
  std::optional<BigNat> authored_maximum_iterations;
  std::optional<std::size_t> maximum_iterations;
  ExactRational absolute_residual_tolerance;
  ExactRational relative_residual_tolerance;
  bool budget_stop;
};

class KilledPotential final {
 public:
  KilledPotential() = delete;
  KilledPotential(const KilledPotential&) = default;
  KilledPotential(KilledPotential&&) noexcept = default;
  KilledPotential& operator=(const KilledPotential&) = default;
  KilledPotential& operator=(KilledPotential&&) noexcept = default;

  [[nodiscard]] std::span<const PotentialCoordinateV1> coordinates()
      const noexcept;
  [[nodiscard]] const PotentialSolveDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept;

 private:
  explicit KilledPotential(
      std::shared_ptr<const metrics::detail::KilledPotentialCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::KilledPotentialCore> core_;
  friend class detail::TemporalContractCoreAccess;
};

struct HorizonSpec final {
  BigNat maximum_tail_index;
  bool include_infinite_horizon_mean;
  bool include_eventual_typed_exit_probabilities;
};

struct SurvivalTailV1 final {
  BigNat index;
  ExactRational exact_probability;
};

struct TypedAbsorptionMassV1 final {
  BigNat hitting_time;
  std::string type_id;
  ExactRational exact_probability;
};

enum class AbsorptionStatusV1 : std::uint8_t {
  nondefective,
  defective,
  not_established,
};

struct EventualTypedExitProbabilityV1 final {
  std::string type_id;
  ExactRational exact_probability;
};

enum class StoppedSolveStatusV1 : std::uint8_t {
  established,
  unavailable,
  budget_stopped,
};

// Additive diagnostics for one infinite-horizon stopped solve.  Exact finite
// routes publish one residual per solved equation; a null entry denotes a
// coordinate whose finite equation is inapplicable (for example, a proven
// infinite potential).  auxiliary residuals carry the defect harmonic
// equations for the typed-exit solve and remain empty for the potential.
struct StoppedSolveDiagnosticsV1 final {
  StoppedSolveStatusV1 status;
  std::size_t iterations;
  std::optional<std::size_t> system_dimension;
  std::optional<std::size_t> exact_rank;
  std::vector<std::optional<ExactRational>> exact_equation_residuals;
  std::vector<std::optional<ExactRational>> exact_auxiliary_residuals;
  std::optional<long double> reciprocal_condition_estimate;
  std::optional<long double> condition_warning_threshold;
  bool condition_warning;
  std::string method;
};

struct StoppedMetricBundle final {
  Digest256 source_fingerprint;
  InitialLawKindV1 initial_law_kind;
  std::vector<SurvivalTailV1> survival_tails;
  std::vector<TypedAbsorptionMassV1> absorption_masses;
  std::vector<EventualTypedExitProbabilityV1>
      eventual_typed_exit_probabilities;
  ExactRational exact_defect_probability;
  AbsorptionStatusV1 absorption_status;
  ExtendedNonnegativeV1 mean_stopping_time;
  TemporalBudgetReportV1 budget;
  bool finite_results_preserved_when_mean_unavailable;
  // Typed-exit/defect classification is attempted for every successful F04
  // call.  Potential diagnostics are present only when the mean/potential was
  // requested.  An unavailable or budget-stopped solve still publishes its
  // typed status rather than being confused with an unrequested component.
  std::optional<StoppedSolveDiagnosticsV1>
      typed_exit_defect_solve_diagnostics;
  std::optional<StoppedSolveDiagnosticsV1> potential_solve_diagnostics;
};

enum class BinaryMarkKindV1 : std::uint8_t {
  target_departure,
  positive_target_arrival,
  busy_denial,
  state_predicate,
};

struct BinaryMark final {
  BinaryMarkKindV1 kind;
  std::size_t target_ordinal;
  std::optional<TemporalStatePredicateV1> state_predicate;
};

enum class TemporalStatisticKindV1 : std::uint8_t {
  service_persistence,
  autocovariance,
  service_window_count,
  service_spectrum,
  mean_event_gap,
  mean_binary_run,
};

struct LagSpec final {
  TemporalStatisticKindV1 statistic;
  std::vector<BigNat> lags;
  std::optional<BigNat> window_width;
  std::optional<BigNat> truncation_lag;
  std::vector<ExactRational> angular_frequencies_radians;
};

// Deterministic execution-budget record carried by every generic C22
// MetricValue envelope.  requested_horizon is the largest completed-slot
// horizon mathematically needed by the returned statistic; permitted_horizon
// is present only when the caller supplied a distinct finite Horizon cap.
// The authorized typed offsets remain separate because StateAt(k) and
// EdgeMarkAt(k) have different completed-slot requirements.  Exact finite
// enumeration is not reported as a numerical fixed-point iteration: its
// solver iteration count is zero and its solver limit/tolerances are absent.
struct TemporalMetricBudgetReportV1 final {
  std::size_t actual_state_count;
  std::size_t actual_row_atom_count;
  std::size_t requested_horizon;
  std::optional<std::size_t> permitted_horizon;
  std::size_t authorized_maximum_state_offset;
  std::optional<std::size_t> authorized_maximum_edge_offset;
  std::optional<std::size_t> maximum_states;
  std::optional<std::size_t> maximum_row_atoms;
  std::size_t solver_iterations;
  std::optional<BigNat> authored_maximum_solver_iterations;
  std::optional<std::size_t> maximum_solver_iterations;
  std::optional<ExactRational> absolute_residual_tolerance;
  std::optional<ExactRational> relative_residual_tolerance;
  bool budget_stop;
};

// F-C22-01
[[nodiscard]] Result<MetricValue> evaluate_finite_cylinder(
    const AuditedCylinderLaw& law, const CylinderEvent& event,
    const Horizon& horizon);

// F-C22-02
[[nodiscard]] Result<KilledKernel> construct_killed_kernel(
    const AuditedTemporalKernel& kernel, const SafeSet& safe_set,
    const AbsorptionMarks& absorption_marks);

// F-C22-03
[[nodiscard]] Result<KilledPotential> compute_minimal_killed_potential(
    const KilledKernel& kernel, const SolverPolicy& policy);

// F-C22-04
[[nodiscard]] Result<StoppedMetricBundle> evaluate_hit_survival_absorption(
    const KilledKernel& kernel, const InitialLaw& initial_law,
    const HorizonSpec& horizon, const SolverPolicy& policy);

// F-C22-05
[[nodiscard]] Result<MetricValue> evaluate_runs_gaps_autocorrelation(
    const AuditedTemporalLaw& law, const BinaryMark& mark,
    const LagSpec& lags);

// F-C22-06
[[nodiscard]] Result<MetricValue> evaluate_transient_metric(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law, const MetricRequest& request);

namespace detail {

// C27 must consume the exact typed restriction named by its frozen backend
// route. This narrow adapter evaluates only bounded service statistics from
// an AuditedCylinderLaw; the retained offset budget and request-bound F05
// authorization still gate every traversal.
[[nodiscard]] Result<MetricValue> evaluate_finite_cylinder_statistic(
    const AuditedCylinderLaw& law, const BinaryMark& mark,
    const LagSpec& lags);

// C27 needs the same truthful budget report that F-C22-06 seals into its
// canonical MetricValue.  This internal carrier avoids decoding that opaque
// value or recomputing/inventing usage while leaving the public F-C22-06
// contract unchanged.
struct TransientMetricEvaluationV1 final {
  MetricValue value;
  TemporalMetricBudgetReportV1 budget;
  // C03 max_row_atoms is a per-row allocation grant. Keep the public C22
  // total-row-atom counter unchanged and carry the actual peak row width
  // separately for C27 result accounting.
  std::size_t actual_maximum_row_atoms;
};

[[nodiscard]] Result<TransientMetricEvaluationV1>
evaluate_transient_metric_with_budget(
    const AuditedCompiledFramework& framework,
    const ReducedInitialLaw& initial_law, const MetricRequest& request);

}  // namespace detail

#if defined(MWPERF_C22_TEST_SEAMS)
namespace testing {

struct C22SyntheticTransitionV1 final {
  std::size_t successor_index;
  MarkedFluxEdgeV1 edge;
  ExactRational exact_mass;
};

struct C22SyntheticNodeV1 final {
  ReducedStateV1 state;
  std::vector<C22SyntheticTransitionV1> transitions;
  std::optional<std::size_t> invariant_component;
};

struct C22SyntheticRowErrorEnclosureV1 final {
  ExactRational lower;
  ExactRational upper;
};

struct C22SyntheticEntranceV1 final {
  std::size_t node_index;
  ExactRational exact_mass;
};

// Explicit nonproduction authorization for one F-C22-05 readout.  Synthetic
// sources receive no implicit or wildcard temporal-statistic authority.
struct C22SyntheticF05AuthorizationV1 final {
  MetricKindV1 request_kind;
  std::size_t target_ordinal;
  MetricRequestParametersV1 parameters;
};

// A complete explicit identity for nonproduction C22 graph fixtures.  No
// normalizer, Palm tilt, FIFO lift, or sampler is present in this seam.
struct C22SyntheticSourceIdentityV1 final {
  Digest256 source_fingerprint;
  std::optional<Digest256> projection_fingerprint;
  Digest256 accepted_contract_identity;
  Digest256 normalized_requirements_identity;
  Digest256 authored_analysis_identity;
  Digest256 resolved_instance_identity;
  Digest256 target_selection_identity;
  Digest256 configured_arrival_identity;
  Digest256 selection_identity;
  Digest256 exact_state_schema_identity;
  Digest256 reduced_state_schema_identity;
  Digest256 mark_schema_identity;
  Digest256 continuation_schema_identity;
  Digest256 target_service_schema_identity;
  Digest256 timing_identity;
  CodecIdentityV1 state_codec;
};

struct C22SyntheticViewsV1 final {
  std::optional<AuditedCylinderLaw> cylinder;
  std::optional<AuditedTemporalKernel> kernel;
  std::optional<AuditedTemporalLaw> law;
  std::optional<InitialLaw> entrance;
};

struct C22MetricEnvelopeInspectionV1 final {
  std::string kind;
  Digest256 source_fingerprint;
  std::vector<ExactRational> exact_values;
  std::vector<long double> numerical_values;
  std::vector<BigNat> indices;
  bool rectangular_truncation;
  bool angular_radians;
  long double transcendental_error_bound;
  std::size_t completed_steps;
  // Service-spectrum values remain in the authored frequency order.  Keep
  // the exact decimal rationals beside their numerical images so the output
  // does not depend on the caller retaining an external positional map.
  std::vector<ExactRational> authored_angular_frequencies_radians;
  // True only when transcendental_error_bound is an enclosing radius, not a
  // floating-point error estimate.
  bool transcendental_error_certified;
  // Spectrum error sources remain orthogonal.  The current exact temporal
  // route has zero probability/kernel error and no authored numerical
  // tolerance, while the transcendental field is a conservative enclosing
  // radius for the whole exact range.
  std::optional<ExactRational> authored_absolute_tolerance;
  ExactRational exact_probability_kernel_error;
  long double conservative_transcendental_enclosure_radius;
  bool transcendental_enclosure_is_whole_range;
  // F-C22-06 stopped outputs retain their full extended statuses and
  // diagnostics instead of flattening infinity or an unavailable solve into
  // an unlabeled rational vector.  Exact killed-row balance residuals remain
  // separate from physical absorption mass.
  std::optional<StoppedMetricBundle> stopped_metric;
  std::vector<ExactRational> exact_killed_row_balance_residuals;
  TemporalMetricBudgetReportV1 temporal_budget;
};

class C22FixtureAccess final {
 public:
  C22FixtureAccess() = delete;

  [[nodiscard]] static Result<C22SyntheticViewsV1> mint_exact_source(
      AuditedTemporalSourceKindV1 source_kind,
      std::optional<InitialLawKindV1> entrance_kind,
      C22SyntheticSourceIdentityV1 identity,
      std::vector<C22SyntheticNodeV1> nodes,
      std::vector<C22SyntheticEntranceV1> entrance,
      std::size_t maximum_state_offset,
      std::optional<std::size_t> maximum_edge_offset,
      std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations = {},
      bool projectively_consistent = true);

  [[nodiscard]] static Result<C22SyntheticViewsV1> mint_analytic_source(
      AuditedTemporalSourceKindV1 source_kind,
      std::optional<InitialLawKindV1> entrance_kind,
      C22SyntheticSourceIdentityV1 identity,
      std::vector<C22SyntheticNodeV1> nodes,
      std::vector<C22SyntheticEntranceV1> entrance,
      std::vector<C22SyntheticRowErrorEnclosureV1> row_error_enclosures,
      std::size_t maximum_state_offset,
      std::optional<std::size_t> maximum_edge_offset,
      std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations = {},
      bool projectively_consistent = true);

  [[nodiscard]] static Result<C22MetricEnvelopeInspectionV1>
  decode_metric_value(const MetricValue& value);

  [[nodiscard]] static Result<KilledKernel> construct_exact_killed_fixture(
      C22SyntheticSourceIdentityV1 identity,
      std::vector<C22SyntheticNodeV1> nodes,
      std::vector<C22SyntheticEntranceV1> entrance,
      SafeSet safe_set, AbsorptionMarks absorption_marks);

 private:
  [[nodiscard]] static Result<C22SyntheticViewsV1> mint_source(
      AuditedTemporalSourceKindV1 source_kind,
      std::optional<InitialLawKindV1> entrance_kind,
      C22SyntheticSourceIdentityV1 identity,
      std::vector<C22SyntheticNodeV1> nodes,
      std::vector<C22SyntheticEntranceV1> entrance,
      std::vector<C22SyntheticRowErrorEnclosureV1> row_error_enclosures,
      std::size_t maximum_state_offset,
      std::optional<std::size_t> maximum_edge_offset,
      bool exact_rows,
      std::vector<C22SyntheticF05AuthorizationV1> f05_authorizations,
      bool projectively_consistent);
};

}  // namespace testing
#endif

}  // namespace mwperf
