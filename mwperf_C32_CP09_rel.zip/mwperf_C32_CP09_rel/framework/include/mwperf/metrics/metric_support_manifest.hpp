#pragma once

#include <array>
#include <compare>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// The order and explicit values below are part of the v1 canonical wire
// contract.  They are the rows of C14's authoritative role table, not a set of
// provider-defined strings.
enum class MetricSupportRoleV1 : std::uint8_t {
  deployed_payload = 0U,
  deployed_response = 1U,
  raw_response = 2U,
  nominal_response = 3U,
  projection_center = 4U,
  projected_mean = 5U,
  recoded_response = 6U,
  stationary_marked_edge_law = 7U,
  staged_opportunity_flux_law = 8U,
  temporal_continuation_law = 9U,
  residence_word_law = 10U,
  stopped_path_law = 11U,
  coupled_schedule_law = 12U,
  direct_metric_value = 13U,
  response_envelope = 14U,
  raw_response_bound_evidence = 15U,
  response_order_evidence = 16U,
  optimizer_evidence = 17U,
  statistical_evidence = 18U,
  numerical_evidence = 19U,
  calibration_evidence = 20U,
  compression_evidence = 21U,
  stability_certificate = 22U,
  reported_validity_or_lift_evidence = 23U,
  physical_transfer_evidence = 24U,
};

inline constexpr std::array<MetricSupportRoleV1, 25U>
    kMetricSupportRolesV1{
        MetricSupportRoleV1::deployed_payload,
        MetricSupportRoleV1::deployed_response,
        MetricSupportRoleV1::raw_response,
        MetricSupportRoleV1::nominal_response,
        MetricSupportRoleV1::projection_center,
        MetricSupportRoleV1::projected_mean,
        MetricSupportRoleV1::recoded_response,
        MetricSupportRoleV1::stationary_marked_edge_law,
        MetricSupportRoleV1::staged_opportunity_flux_law,
        MetricSupportRoleV1::temporal_continuation_law,
        MetricSupportRoleV1::residence_word_law,
        MetricSupportRoleV1::stopped_path_law,
        MetricSupportRoleV1::coupled_schedule_law,
        MetricSupportRoleV1::direct_metric_value,
        MetricSupportRoleV1::response_envelope,
        MetricSupportRoleV1::raw_response_bound_evidence,
        MetricSupportRoleV1::response_order_evidence,
        MetricSupportRoleV1::optimizer_evidence,
        MetricSupportRoleV1::statistical_evidence,
        MetricSupportRoleV1::numerical_evidence,
        MetricSupportRoleV1::calibration_evidence,
        MetricSupportRoleV1::compression_evidence,
        MetricSupportRoleV1::stability_certificate,
        MetricSupportRoleV1::reported_validity_or_lift_evidence,
        MetricSupportRoleV1::physical_transfer_evidence,
    };

[[nodiscard]] constexpr std::span<const MetricSupportRoleV1, 25U>
all_metric_support_roles_v1() noexcept {
  return kMetricSupportRolesV1;
}

[[nodiscard]] constexpr std::uint8_t metric_support_role_rank_v1(
    const MetricSupportRoleV1 role) noexcept {
  return static_cast<std::uint8_t>(role);
}

enum class MetricTargetScopeV1 : std::uint8_t {
  payload_targets,
  deployed_singleton_target,
  ordered_metric_targets,
  ordered_construction_targets,
  exact_request_targets,
};

enum class MetricResultScopeV1 : std::uint8_t {
  not_a_metric_result,
  surrogate_law,
  proposal_raw,
  response_envelope,
  physical_bound,
};

enum class MetricEvidenceScopeV1 : std::uint8_t {
  none,
  raw_static_proposal,
  nominal_static_proposal,
  projection_center,
  projected_surrogate_mean,
  recoded_static_proposal,
  optimizer_interval_raw,
  deployed_surrogate_law,
  numerical_result,
  validity_or_lift,
  physical_system,
};

// This tag identifies the active C++ alternative in RealizedReferenceV1.  It
// remains separate from MetricSupportRoleV1 so a malformed role/reference
// pairing can be represented long enough to receive a deterministic
// validation diagnostic.
enum class RealizedReferenceAlternativeV1 : std::uint8_t {
  deployed_payload_reference,
  deployed_response_reference,
  raw_response_product_reference,
  nominal_response_product_reference,
  projection_center_product_reference,
  projected_mean_product_reference,
  recoded_response_product_reference,
  stationary_marked_edge_law_reference,
  staged_opportunity_flux_law_reference,
  temporal_continuation_law_reference,
  residence_word_law_reference,
  stopped_path_law_reference,
  coupled_schedule_law_reference,
  direct_metric_value_reference,
  response_envelope_reference,
  raw_response_bound_evidence_reference,
  response_order_evidence_reference,
  optimizer_evidence_reference,
  statistical_evidence_reference,
  numerical_evidence_reference,
  calibration_evidence_reference,
  compression_evidence_reference,
  stability_certificate_reference,
  reported_validity_or_lift_evidence_reference,
  physical_transfer_evidence_reference,
};

enum class MetricRoleRelationKindV1 : std::uint8_t {
  // Only lineage_parent edges participate in the acyclicity check.  Evidence
  // and subject cross-references are identity-bearing but are not derivation
  // parents; keeping them distinct avoids a false cycle between a raw product
  // and the bound evidence that covers it.
  lineage_parent,
  binding,
  evidence,
  subject,
};

// Internal objects do not acquire symbolic metric roles.  Their purpose is a
// closed tag, so a provider cannot smuggle a generic or unknown evidence name
// through this relation list.  C15 will later resolve these references against
// the artifact ledger; C14 checks only their closed structural relation.
enum class InternalReferencePurposeV1 : std::uint8_t {
  artifact_payload,
  coefficient_origin,
  completion_source,
  completion_policy,
  projection_source,
  projection_policy,
  recoding_policy,
  state_codec,
  mark_codec,
  configured_arrival_binding,
  selection_binding,
  initial_binding,
  stage_law,
  reveal_order,
  entrance,
  one_slot_continuation,
  adapted_positive_stop,
  word,
  terminal,
  reentry,
  killed_projection,
  projected_schedule,
  feasibility_domain_codec,
  full_schedule,
  normalized_request,
  validity_basis,
  lower_response_product,
  upper_response_product,
  comparison_domain,
  evaluation_identity,
  proposal_identity,
  exact_population,
  solver_identity,
  constraint_identity,
  call_report_identity,
  certified_product_or_envelope,
  estimand,
  sampling_bank,
  sampling_probe,
  coverage_family,
  algorithm_tolerance_policy,
  residual_or_enclosure,
  representation_domain,
  calibration_source,
  calibration_rule,
  compression_source,
  compression_destination,
  compression_rule,
  deployed_law,
  law_or_result,
  state_domain,
  class_domain,
  stability_statement,
  coordinate_codec,
  timing_binding,
  validity_witness,
  physical_model,
  physical_metric,
  transfer_theorem,
  transfer_assumption,
  transfer_direction,
  surrogate_source,
  error_object,
};

static_assert(static_cast<std::uint8_t>(
                  InternalReferencePurposeV1::error_object) < 64U,
              "v1 internal-reference purposes must fit the role-table mask");

using ExactMetricDecoderKeyV1 = StrongId<"exact_metric_decoder_v1">;

// A parameter-resolved preview normally uses a singleton exact set.  A finite
// set lets one structural clause cover several explicitly listed levels,
// points, lags, or horizons without turning the manifest into a string option
// bag.  Direct decoders use a distinct key and still retain their exact
// parameter point.
struct ExactMetricParameterSetV1 final {
  std::vector<MetricRequestParametersV1> values;

  friend bool operator==(const ExactMetricParameterSetV1&,
                         const ExactMetricParameterSetV1&) = default;
};

struct ExactMetricDecoderDomainV1 final {
  ExactMetricDecoderKeyV1 decoder_key;
  MetricRequestParametersV1 exact_parameters;

  friend bool operator==(const ExactMetricDecoderDomainV1&,
                         const ExactMetricDecoderDomainV1&) = default;
};

using MetricParameterDomainV1 =
    std::variant<ExactMetricParameterSetV1, ExactMetricDecoderDomainV1>;

enum class StructuralErrorFormV1 : std::uint8_t {
  none,
  exact,
  deterministic_enclosure,
  statistical_interval,
  numerical_residual,
  validity_witness,
  physical_transfer_bound,
};

struct StructuralErrorPromiseV1 final {
  StructuralErrorFormV1 form;
  MetricEvidenceScopeV1 scope;
  std::optional<ExactRational> maximum_error;

  friend bool operator==(const StructuralErrorPromiseV1&,
                         const StructuralErrorPromiseV1&) = default;
};

struct MetricRoleRelationRequirementV1 final {
  MetricRoleRelationKindV1 relation;
  MetricSupportRoleV1 other_role;

  friend bool operator==(const MetricRoleRelationRequirementV1&,
                         const MetricRoleRelationRequirementV1&) = default;
  friend std::strong_ordering operator<=> (
      const MetricRoleRelationRequirementV1&,
      const MetricRoleRelationRequirementV1&) = default;
};

struct InternalRelationRequirementV1 final {
  MetricRoleRelationKindV1 relation;
  InternalReferencePurposeV1 purpose;

  friend bool operator==(const InternalRelationRequirementV1&,
                         const InternalRelationRequirementV1&) = default;
  friend std::strong_ordering operator<=>(
      const InternalRelationRequirementV1&,
      const InternalRelationRequirementV1&) = default;
};

struct MetricSupportRoleRequirementV1 final {
  MetricSupportRoleV1 role;
  MetricTargetScopeV1 target_scope;
  MetricResultScopeV1 result_scope;
  MetricEvidenceScopeV1 evidence_scope;
  // These lists are canonical sets.  They refine only the fixed v1 role table
  // (for example, the stability and physical-transfer conditional edges) and
  // may never remove a relation mandatory in that table.
  std::vector<MetricRoleRelationRequirementV1> role_relations;
  std::vector<InternalRelationRequirementV1> internal_relations;

  friend bool operator==(const MetricSupportRoleRequirementV1&,
                         const MetricSupportRoleRequirementV1&) = default;
};

// One structural clause contains no provider, request, build, payload/product,
// evidence-instance, or report identity.  It is therefore safe to echo before
// and after construction.  Concrete identities live only in the separate
// RealizedMetricBindingsV1 value below.
struct MetricSupportClauseV1 final {
  MetricClauseIdV1 clause_id;
  MetricKindV1 metric_kind;
  MetricParameterDomainV1 parameter_domain;
  std::vector<QueueId> ordered_targets;
  TargetCouplingV1 target_coupling;
  std::vector<StateFieldDescriptorV1> state_fields;
  std::vector<MarkDescriptorV1> marks;
  SelectionSupportV1 selection_domain;
  PhaseSupportV1 phase_domain;
  PayloadClassV1 payload_class;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  std::vector<ArrivalAssumptionV1> arrival_assumptions;
  std::vector<HypothesisClaimV1> hypotheses;
  SolverRegimeV1 solver_route;
  AccuracyContractV1 requested_accuracy;
  StructuralErrorPromiseV1 error_promise;
  MetricResultScopeV1 result_scope;
  V0DeclarationV1 mandatory_v0;
  std::vector<MetricSupportRoleRequirementV1> required_roles;

  friend bool operator==(const MetricSupportClauseV1&,
                         const MetricSupportClauseV1&) = default;
};

class MetricSupportManifest final {
 public:
  MetricSupportManifest() = delete;
  MetricSupportManifest(const MetricSupportManifest&) = default;
  MetricSupportManifest(MetricSupportManifest&&) noexcept = default;
  MetricSupportManifest& operator=(const MetricSupportManifest&) = default;
  MetricSupportManifest& operator=(MetricSupportManifest&&) noexcept = default;

  // Input order is not identity.  The factory canonicalizes clauses by
  // clause_id, role requirements by the fixed role-table order, and every
  // set-like nested collection, rejecting duplicate or contradictory entries.
  [[nodiscard]] static Result<MetricSupportManifest> from_clauses(
      std::vector<MetricSupportClauseV1> clauses);

  [[nodiscard]] std::span<const MetricSupportClauseV1> clauses() const
      noexcept {
    return clauses_;
  }
  [[nodiscard]] const Digest256& canonical_digest() const noexcept {
    return canonical_digest_;
  }

  friend bool operator==(const MetricSupportManifest& left,
                         const MetricSupportManifest& right) noexcept {
    return left.clauses_ == right.clauses_;
  }

 private:
  MetricSupportManifest(std::vector<MetricSupportClauseV1> clauses,
                        Digest256 canonical_digest)
      : clauses_(std::move(clauses)),
        canonical_digest_(std::move(canonical_digest)) {}

  std::vector<MetricSupportClauseV1> clauses_;
  // Derived integrity aid.  Semantic equality remains exact value equality,
  // never digest equality alone.
  Digest256 canonical_digest_;
};

[[nodiscard]] inline bool operator==(const PlugDescriptorPreview& left,
                                     const PlugDescriptorPreview& right) {
  const bool manifests_equal =
      (!left.metric_support_manifest && !right.metric_support_manifest) ||
      (left.metric_support_manifest && right.metric_support_manifest &&
       *left.metric_support_manifest == *right.metric_support_manifest);
  return left.schema_version == right.schema_version &&
         left.core == right.core &&
         left.construction_method == right.construction_method &&
         left.producer_mode == right.producer_mode &&
         left.construction_target_scope == right.construction_target_scope &&
         left.policies == right.policies &&
         left.construction_prerequisites ==
             right.construction_prerequisites &&
         manifests_equal &&
         left.problem_view_digest == right.problem_view_digest &&
         left.parameter_digest == right.parameter_digest &&
         left.budget_digest == right.budget_digest &&
         left.preview_digest == right.preview_digest;
}

[[nodiscard]] Result<std::vector<std::byte>>
canonical_metric_support_manifest_bytes_v1(
    const MetricSupportManifest& manifest);

// A stable concrete artifact-object reference.  Its role-specific type is the
// enclosing TypedArtifactReferenceV1 specialization; this common value merely
// supplies canonical object identity and content identity.
struct ArtifactObjectReferenceV1 final {
  TypedLabel object_id;
  Digest256 object_digest;

  friend bool operator==(const ArtifactObjectReferenceV1&,
                         const ArtifactObjectReferenceV1&) = default;
  friend std::strong_ordering operator<=> (
      const ArtifactObjectReferenceV1&,
      const ArtifactObjectReferenceV1&) = default;
};

enum class ArtifactReferenceKindV1 : std::uint8_t {
  artifact_payload,
  raw_response_product,
  nominal_response_product,
  projection_center_product,
  projected_mean_product,
  recoded_response_product,
  stationary_marked_edge_law,
  staged_opportunity_flux_law,
  temporal_continuation_law,
  residence_word_law,
  stopped_path_law,
  coupled_schedule_law,
  direct_metric_value,
  response_envelope,
  raw_response_bound_evidence,
  response_order_evidence,
  optimizer_evidence,
  statistical_evidence,
  numerical_evidence,
  calibration_evidence,
  compression_evidence,
  stability_certificate,
  reported_validity_or_lift_evidence,
  physical_transfer_evidence,
};

template <ArtifactReferenceKindV1 Kind>
struct TypedArtifactReferenceV1 final {
  static constexpr ArtifactReferenceKindV1 kind = Kind;
  ArtifactObjectReferenceV1 identity;

  friend bool operator==(const TypedArtifactReferenceV1&,
                         const TypedArtifactReferenceV1&) = default;
};

using ArtifactPayloadRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::artifact_payload>;

enum class ResponseProductValueFormV1 : std::uint8_t {
  exact_point,
  interval_only,
};

// Raw construction output may be either a deployable exact point or an
// interval-only proposal.  Keeping this distinction on the same typed product
// reference lets deployed_response reuse the ledger identity while rejecting
// interval-only raw output.  Nominal and recoded response references are
// point-valued by their closed types.
struct RawResponseProductRef final {
  static constexpr ArtifactReferenceKindV1 kind =
      ArtifactReferenceKindV1::raw_response_product;
  ArtifactObjectReferenceV1 identity;
  ResponseProductValueFormV1 value_form;

  friend bool operator==(const RawResponseProductRef&,
                         const RawResponseProductRef&) = default;
};
using NominalResponseProductRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::nominal_response_product>;
using ProjectionCenterProductRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::projection_center_product>;
using ProjectedMeanProductRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::projected_mean_product>;
using RecodedResponseProductRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::recoded_response_product>;
using StationaryMarkedEdgeLawRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::stationary_marked_edge_law>;
using StagedOpportunityFluxLawRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::staged_opportunity_flux_law>;
using TemporalContinuationLawRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::temporal_continuation_law>;
using ResidenceWordLawRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::residence_word_law>;
using StoppedPathLawRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::stopped_path_law>;
using CoupledScheduleLawRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::coupled_schedule_law>;
using DirectMetricValueRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::direct_metric_value>;
using ResponseEnvelopeRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::response_envelope>;
using RawResponseBoundEvidenceRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::raw_response_bound_evidence>;
using ResponseOrderEvidenceRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::response_order_evidence>;
using OptimizerEvidenceRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::optimizer_evidence>;
using StatisticalEvidenceRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::statistical_evidence>;
using NumericalEvidenceRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::numerical_evidence>;
using CalibrationEvidenceRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::calibration_evidence>;
using CompressionEvidenceRef =
    TypedArtifactReferenceV1<ArtifactReferenceKindV1::compression_evidence>;
using StabilityCertificateRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::stability_certificate>;
using ReportedValidityOrLiftEvidenceRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::reported_validity_or_lift_evidence>;
using PhysicalTransferEvidenceRef = TypedArtifactReferenceV1<
    ArtifactReferenceKindV1::physical_transfer_evidence>;

using DeployedResponseProductReferenceV1 =
    std::variant<RawResponseProductRef, NominalResponseProductRef,
                 RecodedResponseProductRef>;

struct MetricRoleKeyV1 final {
  MetricClauseIdV1 clause_id;
  MetricSupportRoleV1 role;

  friend bool operator==(const MetricRoleKeyV1&,
                         const MetricRoleKeyV1&) = default;
  friend std::strong_ordering operator<=>(const MetricRoleKeyV1&,
                                           const MetricRoleKeyV1&) = default;
};

struct RealizedRoleRelationV1 final {
  MetricRoleRelationKindV1 relation;
  MetricRoleKeyV1 key;
  ArtifactObjectReferenceV1 referenced_object;

  friend bool operator==(const RealizedRoleRelationV1&,
                         const RealizedRoleRelationV1&) = default;
  friend std::strong_ordering operator<=>(const RealizedRoleRelationV1&,
                                           const RealizedRoleRelationV1&) =
      default;
};

struct RealizedInternalReferenceV1 final {
  MetricRoleRelationKindV1 relation;
  InternalReferencePurposeV1 purpose;
  ArtifactObjectReferenceV1 referenced_object;

  friend bool operator==(const RealizedInternalReferenceV1&,
                         const RealizedInternalReferenceV1&) = default;
  friend std::strong_ordering operator<=>(const RealizedInternalReferenceV1&,
                                           const RealizedInternalReferenceV1&) =
      default;
};

struct RealizedReferenceCoreV1 final {
  std::vector<QueueId> ordered_targets;
  MetricTargetScopeV1 target_scope;
  MetricResultScopeV1 result_scope;
  MetricEvidenceScopeV1 evidence_scope;
  std::vector<RealizedRoleRelationV1> role_relations;
  std::vector<RealizedInternalReferenceV1> internal_relations;

  friend bool operator==(const RealizedReferenceCoreV1&,
                         const RealizedReferenceCoreV1&) = default;
};

struct DeployedPayloadReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ArtifactPayloadRef payload;
  friend bool operator==(const DeployedPayloadReferenceV1&,
                         const DeployedPayloadReferenceV1&) = default;
};

struct DeployedResponseReferenceV1 final {
  RealizedReferenceCoreV1 core;
  DeployedResponseProductReferenceV1 selected_product;
  friend bool operator==(const DeployedResponseReferenceV1&,
                         const DeployedResponseReferenceV1&) = default;
};

struct RawResponseProductReferenceV1 final {
  RealizedReferenceCoreV1 core;
  RawResponseProductRef product;
  friend bool operator==(const RawResponseProductReferenceV1&,
                         const RawResponseProductReferenceV1&) = default;
};

struct NominalResponseProductReferenceV1 final {
  RealizedReferenceCoreV1 core;
  NominalResponseProductRef product;
  friend bool operator==(const NominalResponseProductReferenceV1&,
                         const NominalResponseProductReferenceV1&) = default;
};

struct ProjectionCenterProductReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ProjectionCenterProductRef product;
  friend bool operator==(const ProjectionCenterProductReferenceV1&,
                         const ProjectionCenterProductReferenceV1&) = default;
};

struct ProjectedMeanProductReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ProjectedMeanProductRef product;
  friend bool operator==(const ProjectedMeanProductReferenceV1&,
                         const ProjectedMeanProductReferenceV1&) = default;
};

struct RecodedResponseProductReferenceV1 final {
  RealizedReferenceCoreV1 core;
  RecodedResponseProductRef product;
  friend bool operator==(const RecodedResponseProductReferenceV1&,
                         const RecodedResponseProductReferenceV1&) = default;
};

struct StationaryMarkedEdgeLawReferenceV1 final {
  RealizedReferenceCoreV1 core;
  StationaryMarkedEdgeLawRef law;
  friend bool operator==(const StationaryMarkedEdgeLawReferenceV1&,
                         const StationaryMarkedEdgeLawReferenceV1&) = default;
};

struct StagedOpportunityFluxLawReferenceV1 final {
  RealizedReferenceCoreV1 core;
  StagedOpportunityFluxLawRef law;
  friend bool operator==(const StagedOpportunityFluxLawReferenceV1&,
                         const StagedOpportunityFluxLawReferenceV1&) = default;
};

struct TemporalContinuationLawReferenceV1 final {
  RealizedReferenceCoreV1 core;
  TemporalContinuationLawRef law;
  friend bool operator==(const TemporalContinuationLawReferenceV1&,
                         const TemporalContinuationLawReferenceV1&) = default;
};

struct ResidenceWordLawReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ResidenceWordLawRef law;
  friend bool operator==(const ResidenceWordLawReferenceV1&,
                         const ResidenceWordLawReferenceV1&) = default;
};

struct StoppedPathLawReferenceV1 final {
  RealizedReferenceCoreV1 core;
  StoppedPathLawRef law;
  friend bool operator==(const StoppedPathLawReferenceV1&,
                         const StoppedPathLawReferenceV1&) = default;
};

struct CoupledScheduleLawReferenceV1 final {
  RealizedReferenceCoreV1 core;
  CoupledScheduleLawRef law;
  friend bool operator==(const CoupledScheduleLawReferenceV1&,
                         const CoupledScheduleLawReferenceV1&) = default;
};

struct DirectMetricValueReferenceV1 final {
  RealizedReferenceCoreV1 core;
  DirectMetricValueRef value;
  friend bool operator==(const DirectMetricValueReferenceV1&,
                         const DirectMetricValueReferenceV1&) = default;
};

struct ResponseEnvelopeReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ResponseEnvelopeRef envelope;
  friend bool operator==(const ResponseEnvelopeReferenceV1&,
                         const ResponseEnvelopeReferenceV1&) = default;
};

struct RawResponseBoundEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  RawResponseBoundEvidenceRef evidence;
  friend bool operator==(const RawResponseBoundEvidenceReferenceV1&,
                         const RawResponseBoundEvidenceReferenceV1&) = default;
};

struct ResponseOrderEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ResponseOrderEvidenceRef evidence;
  friend bool operator==(const ResponseOrderEvidenceReferenceV1&,
                         const ResponseOrderEvidenceReferenceV1&) = default;
};

struct OptimizerEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  OptimizerEvidenceRef evidence;
  friend bool operator==(const OptimizerEvidenceReferenceV1&,
                         const OptimizerEvidenceReferenceV1&) = default;
};

struct StatisticalEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  StatisticalEvidenceRef evidence;
  friend bool operator==(const StatisticalEvidenceReferenceV1&,
                         const StatisticalEvidenceReferenceV1&) = default;
};

struct NumericalEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  NumericalEvidenceRef evidence;
  friend bool operator==(const NumericalEvidenceReferenceV1&,
                         const NumericalEvidenceReferenceV1&) = default;
};

struct CalibrationEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  CalibrationEvidenceRef evidence;
  friend bool operator==(const CalibrationEvidenceReferenceV1&,
                         const CalibrationEvidenceReferenceV1&) = default;
};

struct CompressionEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  CompressionEvidenceRef evidence;
  friend bool operator==(const CompressionEvidenceReferenceV1&,
                         const CompressionEvidenceReferenceV1&) = default;
};

struct StabilityCertificateReferenceV1 final {
  RealizedReferenceCoreV1 core;
  StabilityCertificateRef certificate;
  friend bool operator==(const StabilityCertificateReferenceV1&,
                         const StabilityCertificateReferenceV1&) = default;
};

struct ReportedValidityOrLiftEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  ReportedValidityOrLiftEvidenceRef evidence;
  friend bool operator==(
      const ReportedValidityOrLiftEvidenceReferenceV1&,
      const ReportedValidityOrLiftEvidenceReferenceV1&) = default;
};

struct PhysicalTransferEvidenceReferenceV1 final {
  RealizedReferenceCoreV1 core;
  PhysicalTransferEvidenceRef evidence;
  friend bool operator==(const PhysicalTransferEvidenceReferenceV1&,
                         const PhysicalTransferEvidenceReferenceV1&) = default;
};

using RealizedReferenceV1 = std::variant<
    DeployedPayloadReferenceV1, DeployedResponseReferenceV1,
    RawResponseProductReferenceV1, NominalResponseProductReferenceV1,
    ProjectionCenterProductReferenceV1, ProjectedMeanProductReferenceV1,
    RecodedResponseProductReferenceV1,
    StationaryMarkedEdgeLawReferenceV1,
    StagedOpportunityFluxLawReferenceV1,
    TemporalContinuationLawReferenceV1, ResidenceWordLawReferenceV1,
    StoppedPathLawReferenceV1, CoupledScheduleLawReferenceV1,
    DirectMetricValueReferenceV1, ResponseEnvelopeReferenceV1,
    RawResponseBoundEvidenceReferenceV1,
    ResponseOrderEvidenceReferenceV1, OptimizerEvidenceReferenceV1,
    StatisticalEvidenceReferenceV1, NumericalEvidenceReferenceV1,
    CalibrationEvidenceReferenceV1, CompressionEvidenceReferenceV1,
    StabilityCertificateReferenceV1,
    ReportedValidityOrLiftEvidenceReferenceV1,
    PhysicalTransferEvidenceReferenceV1>;

static_assert(std::variant_size_v<RealizedReferenceV1> == 25U);

[[nodiscard]] MetricSupportRoleV1 realized_reference_role_v1(
    const RealizedReferenceV1& reference) noexcept;
[[nodiscard]] RealizedReferenceAlternativeV1
realized_reference_alternative_v1(
    const RealizedReferenceV1& reference) noexcept;
[[nodiscard]] const RealizedReferenceCoreV1& realized_reference_core_v1(
    const RealizedReferenceV1& reference) noexcept;
[[nodiscard]] const ArtifactObjectReferenceV1&
realized_reference_subject_v1(const RealizedReferenceV1& reference) noexcept;

enum class MetricRoleConditionalRuleV1 : std::uint8_t {
  none = 0U,
  selected_response_product_must_match_deployment_policy = 1U << 0U,
  interval_raw_requires_bound_evidence = 1U << 1U,
  policy_selected_derivation_parents = 1U << 2U,
  stationary_hypothesis_requires_stability = 1U << 3U,
  physical_scope_requires_transfer = 1U << 4U,
  full_schedule_when_projection_is_not_sufficient = 1U << 5U,
  calibration_input_must_be_sampling_or_population = 1U << 6U,
};

struct MetricSupportRoleSchemaV1 final {
  MetricSupportRoleV1 role;
  RealizedReferenceAlternativeV1 reference_alternative;
  std::uint32_t allowed_target_scopes;
  std::uint32_t allowed_result_scopes;
  std::uint32_t allowed_evidence_scopes;
  // Required masks encode the unconditional edges in the fixed v1 table.
  // Allowed masks additionally admit only the table's explicitly conditional
  // or clause-selected edges.  Validation rejects every relation outside an
  // allowed mask and then checks that all required/selected edges are present.
  std::uint32_t allowed_lineage_parent_roles;
  std::uint32_t allowed_binding_roles;
  std::uint32_t allowed_evidence_roles;
  std::uint32_t allowed_subject_roles;
  std::uint32_t required_lineage_parent_roles;
  std::uint32_t required_binding_roles;
  std::uint32_t required_evidence_roles;
  std::uint32_t required_subject_roles;
  std::uint64_t allowed_internal_lineage_parents;
  std::uint64_t allowed_internal_bindings;
  std::uint64_t allowed_internal_evidence;
  std::uint64_t allowed_internal_subjects;
  std::uint64_t required_internal_lineage_parents;
  std::uint64_t required_internal_bindings;
  std::uint64_t required_internal_evidence;
  std::uint64_t required_internal_subjects;
  std::uint8_t conditional_rules;

  friend bool operator==(const MetricSupportRoleSchemaV1&,
                         const MetricSupportRoleSchemaV1&) = default;
};

[[nodiscard]] constexpr std::uint32_t metric_target_scope_bit_v1(
    const MetricTargetScopeV1 value) noexcept {
  const auto rank = static_cast<std::uint8_t>(value);
  return rank < 5U ? std::uint32_t{1U} << rank : 0U;
}
[[nodiscard]] constexpr std::uint32_t metric_result_scope_bit_v1(
    const MetricResultScopeV1 value) noexcept {
  const auto rank = static_cast<std::uint8_t>(value);
  return rank < 5U ? std::uint32_t{1U} << rank : 0U;
}
[[nodiscard]] constexpr std::uint32_t metric_evidence_scope_bit_v1(
    const MetricEvidenceScopeV1 value) noexcept {
  const auto rank = static_cast<std::uint8_t>(value);
  return rank < 11U ? std::uint32_t{1U} << rank : 0U;
}
[[nodiscard]] constexpr std::uint32_t metric_support_role_bit_v1(
    const MetricSupportRoleV1 value) noexcept {
  const auto rank = metric_support_role_rank_v1(value);
  return rank < kMetricSupportRolesV1.size()
             ? std::uint32_t{1U} << rank
             : 0U;
}
[[nodiscard]] constexpr std::uint64_t internal_reference_purpose_bit_v1(
    const InternalReferencePurposeV1 value) noexcept {
  const auto rank = static_cast<std::uint8_t>(value);
  return rank <= static_cast<std::uint8_t>(
                     InternalReferencePurposeV1::error_object)
             ? std::uint64_t{1U} << rank
             : 0U;
}
[[nodiscard]] constexpr std::uint8_t metric_role_conditional_bit_v1(
    const MetricRoleConditionalRuleV1 value) noexcept {
  return static_cast<std::uint8_t>(value);
}

// Returns null only for an invalid value manufactured by an unchecked cast.
// Valid v1 roles always resolve to exactly one immutable table row.
[[nodiscard]] const MetricSupportRoleSchemaV1*
metric_support_role_schema_v1(MetricSupportRoleV1 role) noexcept;

[[nodiscard]] constexpr bool metric_role_relation_mask_contains_v1(
    const std::uint32_t mask, const MetricSupportRoleV1 role) noexcept {
  const std::uint32_t bit = metric_support_role_bit_v1(role);
  return bit != 0U && (mask & bit) != 0U;
}

[[nodiscard]] constexpr bool internal_relation_mask_contains_v1(
    const std::uint64_t mask,
    const InternalReferencePurposeV1 purpose) noexcept {
  const std::uint64_t bit = internal_reference_purpose_bit_v1(purpose);
  return bit != 0U && (mask & bit) != 0U;
}

[[nodiscard]] constexpr std::uint32_t allowed_role_relation_mask_v1(
    const MetricSupportRoleSchemaV1& schema,
    const MetricRoleRelationKindV1 relation) noexcept {
  switch (relation) {
    case MetricRoleRelationKindV1::lineage_parent:
      return schema.allowed_lineage_parent_roles;
    case MetricRoleRelationKindV1::binding:
      return schema.allowed_binding_roles;
    case MetricRoleRelationKindV1::evidence:
      return schema.allowed_evidence_roles;
    case MetricRoleRelationKindV1::subject:
      return schema.allowed_subject_roles;
  }
  return 0U;
}

[[nodiscard]] constexpr std::uint32_t required_role_relation_mask_v1(
    const MetricSupportRoleSchemaV1& schema,
    const MetricRoleRelationKindV1 relation) noexcept {
  switch (relation) {
    case MetricRoleRelationKindV1::lineage_parent:
      return schema.required_lineage_parent_roles;
    case MetricRoleRelationKindV1::binding:
      return schema.required_binding_roles;
    case MetricRoleRelationKindV1::evidence:
      return schema.required_evidence_roles;
    case MetricRoleRelationKindV1::subject:
      return schema.required_subject_roles;
  }
  return 0U;
}

[[nodiscard]] constexpr std::uint64_t allowed_internal_relation_mask_v1(
    const MetricSupportRoleSchemaV1& schema,
    const MetricRoleRelationKindV1 relation) noexcept {
  switch (relation) {
    case MetricRoleRelationKindV1::lineage_parent:
      return schema.allowed_internal_lineage_parents;
    case MetricRoleRelationKindV1::binding:
      return schema.allowed_internal_bindings;
    case MetricRoleRelationKindV1::evidence:
      return schema.allowed_internal_evidence;
    case MetricRoleRelationKindV1::subject:
      return schema.allowed_internal_subjects;
  }
  return 0U;
}

[[nodiscard]] constexpr std::uint64_t required_internal_relation_mask_v1(
    const MetricSupportRoleSchemaV1& schema,
    const MetricRoleRelationKindV1 relation) noexcept {
  switch (relation) {
    case MetricRoleRelationKindV1::lineage_parent:
      return schema.required_internal_lineage_parents;
    case MetricRoleRelationKindV1::binding:
      return schema.required_internal_bindings;
    case MetricRoleRelationKindV1::evidence:
      return schema.required_internal_evidence;
    case MetricRoleRelationKindV1::subject:
      return schema.required_internal_subjects;
  }
  return 0U;
}

// A deployed response may reuse only a point-valued raw, nominal, or recoded
// product.  This closed helper centralizes the sole non-type-level restriction
// on DeployedResponseProductReferenceV1: an interval-only RawResponseProductRef
// is structurally valid as raw_response but can never become deployed_response.
[[nodiscard]] bool is_point_valued_deployed_response_product_v1(
    const DeployedResponseProductReferenceV1& product) noexcept;
[[nodiscard]] const ArtifactObjectReferenceV1&
deployed_response_product_subject_v1(
    const DeployedResponseProductReferenceV1& product) noexcept;

struct RealizedMetricBindingV1 final {
  MetricRoleKeyV1 key;
  RealizedReferenceV1 reference;

  friend bool operator==(const RealizedMetricBindingV1&,
                         const RealizedMetricBindingV1&) = default;
};

// Target values selected outside the structural manifest are supplied to
// validation but are never stored in RealizedMetricBindingsV1.  Ordered metric
// and exact-request targets are read directly from the matching manifest
// clause.
struct RealizedBindingTargetContextV1 final {
  std::vector<QueueId> payload_targets;
  std::optional<QueueId> deployed_singleton_target;
  std::vector<QueueId> construction_targets;

  friend bool operator==(const RealizedBindingTargetContextV1&,
                         const RealizedBindingTargetContextV1&) = default;
};

struct RealizedBindingValidationContextV1 final {
  RealizedBindingTargetContextV1 targets;
  PreviewPoliciesV1 policies;

  friend bool operator==(const RealizedBindingValidationContextV1&,
                         const RealizedBindingValidationContextV1&) = default;
};

// Artifact data contains only the key/reference list.  In particular, the v1
// C14 contract intentionally does not place request_digest or payload_digest
// fields here; those are enclosing artifact/accepted-contract guards owned by
// later checkpoints.
class RealizedMetricBindingsV1 final {
 public:
  RealizedMetricBindingsV1() = delete;
  RealizedMetricBindingsV1(const RealizedMetricBindingsV1&) = default;
  RealizedMetricBindingsV1(RealizedMetricBindingsV1&&) noexcept = default;
  RealizedMetricBindingsV1& operator=(const RealizedMetricBindingsV1&) =
      default;
  RealizedMetricBindingsV1& operator=(RealizedMetricBindingsV1&&) noexcept =
      default;

  [[nodiscard]] std::span<const RealizedMetricBindingV1> bindings() const
      noexcept {
    return bindings_;
  }

  friend bool operator==(const RealizedMetricBindingsV1&,
                         const RealizedMetricBindingsV1&) = default;

 private:
  explicit RealizedMetricBindingsV1(
      std::vector<RealizedMetricBindingV1> bindings)
      : bindings_(std::move(bindings)) {}

  std::vector<RealizedMetricBindingV1> bindings_;

  friend Result<RealizedMetricBindingsV1>
  validate_realized_metric_bindings_v1(
      const MetricSupportManifest&,
      const RealizedBindingValidationContextV1&,
      std::vector<RealizedMetricBindingV1>);
};

// Canonicalization sorts by (clause_id, fixed role-table rank), but duplicate,
// missing, and extra keys remain errors.  Validation also checks exact
// alternative/scope/target order, fixed and clause-selected relations, frozen
// deployed-response policy, and cycles among lineage_parent edges.  It does
// not resolve an artifact object ledger or validate provider mathematics;
// those are C15 obligations.
[[nodiscard]] Result<RealizedMetricBindingsV1>
validate_realized_metric_bindings_v1(
    const MetricSupportManifest& manifest,
    const RealizedBindingValidationContextV1& context,
    std::vector<RealizedMetricBindingV1> bindings);

[[nodiscard]] Result<std::vector<std::byte>>
canonical_realized_metric_bindings_bytes_v1(
    const RealizedMetricBindingsV1& bindings);
[[nodiscard]] Result<Digest256> digest_realized_metric_bindings_v1(
    const RealizedMetricBindingsV1& bindings);

}  // namespace mwperf
