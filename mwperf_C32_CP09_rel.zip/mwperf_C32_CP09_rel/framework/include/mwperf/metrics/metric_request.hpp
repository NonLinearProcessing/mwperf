#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/model/typed_label.hpp"

namespace mwperf {

// The analysis-v1 metric vocabulary is closed.  These values are semantic
// request tags; C03's similarly named records remain source-wire carriers.
enum class MetricKindV1 : std::uint8_t {
  stationary_throughput,
  stationary_empty_probability,
  mean_sojourn,
  service_persistence,
  joint_backlog_covariance,
  stationary_backlog_pmf,
  stationary_backlog_pgf,
  stationary_backlog_moment,
  stationary_backlog_quantile,
  stationary_backlog_tail,
  backlog_conditioned_service,
  stationary_edge_reward,
  service_autocovariance,
  lagged_cross_queue_covariance,
  service_spectrum,
  service_window_count,
  mean_event_gap,
  event_gap_distribution,
  mean_binary_run,
  binary_run_distribution,
  first_hit,
  threshold_excursion,
  transient_backlog_law,
  fifo_delay,
  fifo_delay_conditioned,
  counterfactual_opportunity_gap,
  joint_backlog_event,
  joint_delay,
  ordered_schedule_sequence,
};

static_assert(static_cast<std::uint8_t>(
                  MetricKindV1::ordered_schedule_sequence) == 28U,
              "MetricKindV1 order is the closed request-variant order");

enum class MetricTargetCouplingV1 : std::uint8_t {
  scalar_singleton,
  common_schedule_coupled,
};

enum class MetricSelectionRegimeV1 : std::uint8_t {
  transient,
  stationary_unique,
  stationary_class,
  stationary_mixture,
  fixed_point_unique,
  fixed_point_id,
};

enum class MetricSolverRegimeV1 : std::uint8_t {
  enumerated,
  analytic,
  monte_carlo,
  direct,
};

enum class DiscreteQuantileConventionV1 : std::uint8_t {
  lower_inverse_cdf,
};

enum class SpectrumWindowV1 : std::uint8_t {
  rectangular_truncation,
};

// Both identities are retained.  The QueueId prevents a dense ordinal from
// being confused with the same ordinal in a different authored catalog; the
// DenseQueueIndex is the one checked coordinate used by later computation.
struct ResolvedMetricTargetV1 final {
  QueueId queue_id;
  DenseQueueIndex dense_index;

  friend bool operator==(const ResolvedMetricTargetV1&,
                         const ResolvedMetricTargetV1&) = default;
};

// Every alternative below carries this common immutable-by-value header.
// context is the exact shared const context supplied by C03; it preserves the
// complete selection, solver and resolution identity without reconstructing
// an opaque transient initializer.  provenance is diagnostic metadata and is
// not a second source of semantic values.
struct MetricRequestHeader final {
  std::string metric_id;
  std::size_t authored_index;
  MetricKindV1 kind;
  MetricTargetCouplingV1 coupling;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  MetricSelectionRegimeV1 selection_regime;
  MetricSolverRegimeV1 solver_regime;
  std::shared_ptr<const AnalysisContext> context;
  SourceProvenance provenance;
};

struct CompletePmfDomainV1 final {
  friend bool operator==(const CompletePmfDomainV1&,
                         const CompletePmfDomainV1&) = default;
};

struct PmfThroughLevelV1 final {
  BigNat max_level;

  friend bool operator==(const PmfThroughLevelV1&,
                         const PmfThroughLevelV1&) = default;
};

using StationaryBacklogPmfDomainV1 =
    std::variant<CompletePmfDomainV1, PmfThroughLevelV1>;

enum class BasicBinaryPredicateV1 : std::uint8_t {
  busy,
  idle,
  busy_denial,
};

struct ThresholdAbovePredicateV1 final {
  BigNat threshold;

  friend bool operator==(const ThresholdAbovePredicateV1&,
                         const ThresholdAbovePredicateV1&) = default;
};

using BinaryPredicateV1 =
    std::variant<BasicBinaryPredicateV1, ThresholdAbovePredicateV1>;

struct FifoDelayPmfOutputV1 final {
  BigNat horizon;

  friend bool operator==(const FifoDelayPmfOutputV1&,
                         const FifoDelayPmfOutputV1&) = default;
};

struct FifoDelayTailOutputV1 final {
  BigNat horizon;

  friend bool operator==(const FifoDelayTailOutputV1&,
                         const FifoDelayTailOutputV1&) = default;
};

struct FifoDelayQuantileOutputV1 final {
  ExactRational probability;
  DiscreteQuantileConventionV1 convention{
      DiscreteQuantileConventionV1::lower_inverse_cdf};

  friend bool operator==(const FifoDelayQuantileOutputV1&,
                         const FifoDelayQuantileOutputV1&) = default;
};

struct FifoDelayMomentOutputV1 final {
  BigNat order;

  friend bool operator==(const FifoDelayMomentOutputV1&,
                         const FifoDelayMomentOutputV1&) = default;
};

using FifoDelayOutputV1 =
    std::variant<FifoDelayPmfOutputV1, FifoDelayTailOutputV1,
                 FifoDelayQuantileOutputV1, FifoDelayMomentOutputV1>;

struct FifoRankConditionV1 final {
  BigNat one_based_rank;

  friend bool operator==(const FifoRankConditionV1&,
                         const FifoRankConditionV1&) = default;
};

struct FifoBatchConditionV1 final {
  BigNat batch_size;

  friend bool operator==(const FifoBatchConditionV1&,
                         const FifoBatchConditionV1&) = default;
};

struct FifoClassConditionV1 final {
  TypedLabel class_id;

  friend bool operator==(const FifoClassConditionV1&,
                         const FifoClassConditionV1&) = default;
};

struct FifoPhaseConditionV1 final {
  TypedLabel phase_id;

  friend bool operator==(const FifoPhaseConditionV1&,
                         const FifoPhaseConditionV1&) = default;
};

using FifoConditionV1 =
    std::variant<FifoRankConditionV1, FifoBatchConditionV1,
                 FifoClassConditionV1, FifoPhaseConditionV1>;

struct CoincidentPalmSamplingV1 final {
  friend bool operator==(const CoincidentPalmSamplingV1&,
                         const CoincidentPalmSamplingV1&) = default;
};

struct IndependentPalmSamplingV1 final {
  friend bool operator==(const IndependentPalmSamplingV1&,
                         const IndependentPalmSamplingV1&) = default;
};

struct LaggedPalmSamplingV1 final {
  BigNat lag;

  friend bool operator==(const LaggedPalmSamplingV1&,
                         const LaggedPalmSamplingV1&) = default;
};

using JointDelaySamplingV1 =
    std::variant<CoincidentPalmSamplingV1, IndependentPalmSamplingV1,
                 LaggedPalmSamplingV1>;

struct MetricHitSetV1 final {
  HitSetKind kind;
  BigNat level;

  friend bool operator==(const MetricHitSetV1&,
                         const MetricHitSetV1&) = default;
};

// Parameter records are deliberately separate from the common header.  They
// form a closed, exact value projection that manifests and requirement joins
// can compare without consulting source text or a string option bag.
struct StationaryThroughputParametersV1 final {
  friend bool operator==(const StationaryThroughputParametersV1&,
                         const StationaryThroughputParametersV1&) = default;
};
struct StationaryEmptyProbabilityParametersV1 final {
  friend bool operator==(const StationaryEmptyProbabilityParametersV1&,
                         const StationaryEmptyProbabilityParametersV1&) =
      default;
};
struct MeanSojournParametersV1 final {
  friend bool operator==(const MeanSojournParametersV1&,
                         const MeanSojournParametersV1&) = default;
};
struct ServicePersistenceParametersV1 final {
  friend bool operator==(const ServicePersistenceParametersV1&,
                         const ServicePersistenceParametersV1&) = default;
};
struct JointBacklogCovarianceParametersV1 final {
  friend bool operator==(const JointBacklogCovarianceParametersV1&,
                         const JointBacklogCovarianceParametersV1&) = default;
};

struct StationaryBacklogPmfParametersV1 final {
  StationaryBacklogPmfDomainV1 domain;
  friend bool operator==(const StationaryBacklogPmfParametersV1&,
                         const StationaryBacklogPmfParametersV1&) = default;
};
struct StationaryBacklogPgfParametersV1 final {
  std::vector<ExactRational> points;
  friend bool operator==(const StationaryBacklogPgfParametersV1&,
                         const StationaryBacklogPgfParametersV1&) = default;
};
struct StationaryBacklogMomentParametersV1 final {
  BigNat order;
  friend bool operator==(const StationaryBacklogMomentParametersV1&,
                         const StationaryBacklogMomentParametersV1&) = default;
};
struct StationaryBacklogQuantileParametersV1 final {
  ExactRational probability;
  DiscreteQuantileConventionV1 convention{
      DiscreteQuantileConventionV1::lower_inverse_cdf};
  friend bool operator==(const StationaryBacklogQuantileParametersV1&,
                         const StationaryBacklogQuantileParametersV1&) =
      default;
};
struct StationaryBacklogTailParametersV1 final {
  BigNat threshold;
  friend bool operator==(const StationaryBacklogTailParametersV1&,
                         const StationaryBacklogTailParametersV1&) = default;
};
struct BacklogConditionedServiceParametersV1 final {
  std::vector<BigNat> levels;
  friend bool operator==(const BacklogConditionedServiceParametersV1&,
                         const BacklogConditionedServiceParametersV1&) =
      default;
};
struct StationaryEdgeRewardParametersV1 final {
  EdgeRewardKind reward;
  BigNat moment_order;
  friend bool operator==(const StationaryEdgeRewardParametersV1&,
                         const StationaryEdgeRewardParametersV1&) = default;
};
struct ServiceAutocovarianceParametersV1 final {
  std::vector<BigNat> lags;
  friend bool operator==(const ServiceAutocovarianceParametersV1&,
                         const ServiceAutocovarianceParametersV1&) = default;
};
struct LaggedCrossQueueCovarianceParametersV1 final {
  std::vector<BigNat> lags;
  friend bool operator==(const LaggedCrossQueueCovarianceParametersV1&,
                         const LaggedCrossQueueCovarianceParametersV1&) =
      default;
};
struct ServiceSpectrumParametersV1 final {
  std::vector<ExactRational> frequencies;
  BigNat truncation_lag;
  SpectrumWindowV1 window{SpectrumWindowV1::rectangular_truncation};
  friend bool operator==(const ServiceSpectrumParametersV1&,
                         const ServiceSpectrumParametersV1&) = default;
};
struct ServiceWindowCountParametersV1 final {
  BigNat width;
  friend bool operator==(const ServiceWindowCountParametersV1&,
                         const ServiceWindowCountParametersV1&) = default;
};
struct MeanEventGapParametersV1 final {
  GapEventKind event;
  friend bool operator==(const MeanEventGapParametersV1&,
                         const MeanEventGapParametersV1&) = default;
};
struct EventGapDistributionParametersV1 final {
  GapEventKind event;
  BigNat horizon;
  friend bool operator==(const EventGapDistributionParametersV1&,
                         const EventGapDistributionParametersV1&) = default;
};
struct MeanBinaryRunParametersV1 final {
  BinaryPredicateV1 predicate;
  friend bool operator==(const MeanBinaryRunParametersV1&,
                         const MeanBinaryRunParametersV1&) = default;
};
struct BinaryRunDistributionParametersV1 final {
  BinaryPredicateV1 predicate;
  BigNat horizon;
  friend bool operator==(const BinaryRunDistributionParametersV1&,
                         const BinaryRunDistributionParametersV1&) = default;
};
struct FirstHitParametersV1 final {
  MetricHitSetV1 set;
  BigNat horizon;
  bool include_mean;
  friend bool operator==(const FirstHitParametersV1&,
                         const FirstHitParametersV1&) = default;
};
struct ThresholdExcursionParametersV1 final {
  MetricHitSetV1 set;
  BigNat horizon;
  bool include_mean;
  friend bool operator==(const ThresholdExcursionParametersV1&,
                         const ThresholdExcursionParametersV1&) = default;
};
struct TransientBacklogLawParametersV1 final {
  std::vector<BigNat> horizons;
  friend bool operator==(const TransientBacklogLawParametersV1&,
                         const TransientBacklogLawParametersV1&) = default;
};
struct FifoDelayParametersV1 final {
  FifoDelayOutputV1 output;
  friend bool operator==(const FifoDelayParametersV1&,
                         const FifoDelayParametersV1&) = default;
};
struct FifoDelayConditionedParametersV1 final {
  FifoDelayOutputV1 output;
  FifoConditionV1 condition;
  friend bool operator==(const FifoDelayConditionedParametersV1&,
                         const FifoDelayConditionedParametersV1&) = default;
};
struct CounterfactualOpportunityGapParametersV1 final {
  TypedLabel convention_id;
  BigNat horizon;
  friend bool operator==(const CounterfactualOpportunityGapParametersV1&,
                         const CounterfactualOpportunityGapParametersV1&) =
      default;
};
struct JointBacklogEventParametersV1 final {
  JointBacklogRelation relation;
  std::vector<BigNat> thresholds;
  friend bool operator==(const JointBacklogEventParametersV1&,
                         const JointBacklogEventParametersV1&) = default;
};
struct JointDelayParametersV1 final {
  JointDelaySamplingV1 sampling;
  BigNat horizon;
  friend bool operator==(const JointDelayParametersV1&,
                         const JointDelayParametersV1&) = default;
};
struct OrderedScheduleSequenceParametersV1 final {
  BigNat horizon;
  bool retain_full_schedule;
  friend bool operator==(const OrderedScheduleSequenceParametersV1&,
                         const OrderedScheduleSequenceParametersV1&) = default;
};

using MetricRequestParametersV1 = std::variant<
    StationaryThroughputParametersV1,
    StationaryEmptyProbabilityParametersV1, MeanSojournParametersV1,
    ServicePersistenceParametersV1, JointBacklogCovarianceParametersV1,
    StationaryBacklogPmfParametersV1, StationaryBacklogPgfParametersV1,
    StationaryBacklogMomentParametersV1,
    StationaryBacklogQuantileParametersV1,
    StationaryBacklogTailParametersV1,
    BacklogConditionedServiceParametersV1,
    StationaryEdgeRewardParametersV1, ServiceAutocovarianceParametersV1,
    LaggedCrossQueueCovarianceParametersV1, ServiceSpectrumParametersV1,
    ServiceWindowCountParametersV1, MeanEventGapParametersV1,
    EventGapDistributionParametersV1, MeanBinaryRunParametersV1,
    BinaryRunDistributionParametersV1, FirstHitParametersV1,
    ThresholdExcursionParametersV1, TransientBacklogLawParametersV1,
    FifoDelayParametersV1, FifoDelayConditionedParametersV1,
    CounterfactualOpportunityGapParametersV1,
    JointBacklogEventParametersV1, JointDelayParametersV1,
    OrderedScheduleSequenceParametersV1>;

static_assert(std::variant_size_v<MetricRequestParametersV1> == 29U);

namespace detail {

template <typename Needle, typename Variant>
struct MetricParameterVariantIndex;

template <typename Needle, typename First, typename... Rest>
struct MetricParameterVariantIndex<Needle, std::variant<First, Rest...>> {
  static constexpr std::size_t value =
      std::is_same_v<Needle, First>
          ? 0U
          : 1U + MetricParameterVariantIndex<
                      Needle, std::variant<Rest...>>::value;
};

template <typename Needle>
struct MetricParameterVariantIndex<Needle, std::variant<>> {
  // A deliberately out-of-range sentinel makes an unsupported parameter type
  // fail the MetricRequestValueV1 static assertion below.
  static constexpr std::size_t value = 29U;
};

template <typename Parameters>
inline constexpr std::size_t kMetricParameterVariantIndex =
    MetricParameterVariantIndex<Parameters, MetricRequestParametersV1>::value;

template <typename Parameters>
inline constexpr bool kCoupledMetricParameters =
    std::is_same_v<Parameters, JointBacklogCovarianceParametersV1> ||
    std::is_same_v<Parameters, LaggedCrossQueueCovarianceParametersV1> ||
    std::is_same_v<Parameters, JointBacklogEventParametersV1> ||
    std::is_same_v<Parameters, JointDelayParametersV1> ||
    std::is_same_v<Parameters, OrderedScheduleSequenceParametersV1>;

}  // namespace detail

// A parsed request is an immutable value.  Keeping the header and parameters
// behind const accessors prevents a caller from changing the redundant kind
// tag independently of the active MetricRequest alternative, or from
// changing an exact parameter after requirements have been derived from it.
class MetricRequestAccess;

template <typename Parameters>
class MetricRequestValueV1 final {
 public:
  static_assert(detail::kMetricParameterVariantIndex<Parameters> < 29U,
                "MetricRequestValueV1 requires a closed v1 parameter type");

  [[nodiscard]] const MetricRequestHeader& header() const noexcept {
    return header_;
  }
  [[nodiscard]] const Parameters& parameters() const noexcept {
    return parameters_;
  }

  friend bool operator==(const MetricRequestValueV1&,
                         const MetricRequestValueV1&) = default;

 private:
  MetricRequestValueV1(MetricRequestHeader header, Parameters parameters)
      : header_(canonical_header(std::move(header))),
        parameters_(std::move(parameters)) {}

  [[nodiscard]] static MetricRequestHeader canonical_header(
      MetricRequestHeader header) {
    // The active C++ alternative, not a caller-writable duplicate tag, is the
    // authority for kind and coupling.
    header.kind = static_cast<MetricKindV1>(
        detail::kMetricParameterVariantIndex<Parameters>);
    header.coupling = detail::kCoupledMetricParameters<Parameters>
                          ? MetricTargetCouplingV1::common_schedule_coupled
                          : MetricTargetCouplingV1::scalar_singleton;
    return header;
  }

  MetricRequestHeader header_;
  Parameters parameters_;

  friend class MetricRequestAccess;
};

using StationaryThroughputRequestV1 =
    MetricRequestValueV1<StationaryThroughputParametersV1>;
using StationaryEmptyProbabilityRequestV1 =
    MetricRequestValueV1<StationaryEmptyProbabilityParametersV1>;
using MeanSojournRequestV1 = MetricRequestValueV1<MeanSojournParametersV1>;
using ServicePersistenceRequestV1 =
    MetricRequestValueV1<ServicePersistenceParametersV1>;
using JointBacklogCovarianceRequestV1 =
    MetricRequestValueV1<JointBacklogCovarianceParametersV1>;
using StationaryBacklogPmfRequestV1 =
    MetricRequestValueV1<StationaryBacklogPmfParametersV1>;
using StationaryBacklogPgfRequestV1 =
    MetricRequestValueV1<StationaryBacklogPgfParametersV1>;
using StationaryBacklogMomentRequestV1 =
    MetricRequestValueV1<StationaryBacklogMomentParametersV1>;
using StationaryBacklogQuantileRequestV1 =
    MetricRequestValueV1<StationaryBacklogQuantileParametersV1>;
using StationaryBacklogTailRequestV1 =
    MetricRequestValueV1<StationaryBacklogTailParametersV1>;
using BacklogConditionedServiceRequestV1 =
    MetricRequestValueV1<BacklogConditionedServiceParametersV1>;
using StationaryEdgeRewardRequestV1 =
    MetricRequestValueV1<StationaryEdgeRewardParametersV1>;
using ServiceAutocovarianceRequestV1 =
    MetricRequestValueV1<ServiceAutocovarianceParametersV1>;
using LaggedCrossQueueCovarianceRequestV1 =
    MetricRequestValueV1<LaggedCrossQueueCovarianceParametersV1>;
using ServiceSpectrumRequestV1 =
    MetricRequestValueV1<ServiceSpectrumParametersV1>;
using ServiceWindowCountRequestV1 =
    MetricRequestValueV1<ServiceWindowCountParametersV1>;
using MeanEventGapRequestV1 =
    MetricRequestValueV1<MeanEventGapParametersV1>;
using EventGapDistributionRequestV1 =
    MetricRequestValueV1<EventGapDistributionParametersV1>;
using MeanBinaryRunRequestV1 =
    MetricRequestValueV1<MeanBinaryRunParametersV1>;
using BinaryRunDistributionRequestV1 =
    MetricRequestValueV1<BinaryRunDistributionParametersV1>;
using FirstHitRequestV1 = MetricRequestValueV1<FirstHitParametersV1>;
using ThresholdExcursionRequestV1 =
    MetricRequestValueV1<ThresholdExcursionParametersV1>;
using TransientBacklogLawRequestV1 =
    MetricRequestValueV1<TransientBacklogLawParametersV1>;
using FifoDelayRequestV1 = MetricRequestValueV1<FifoDelayParametersV1>;
using FifoDelayConditionedRequestV1 =
    MetricRequestValueV1<FifoDelayConditionedParametersV1>;
using CounterfactualOpportunityGapRequestV1 =
    MetricRequestValueV1<CounterfactualOpportunityGapParametersV1>;
using JointBacklogEventRequestV1 =
    MetricRequestValueV1<JointBacklogEventParametersV1>;
using JointDelayRequestV1 = MetricRequestValueV1<JointDelayParametersV1>;
using OrderedScheduleSequenceRequestV1 =
    MetricRequestValueV1<OrderedScheduleSequenceParametersV1>;

using MetricRequest = std::variant<
    StationaryThroughputRequestV1, StationaryEmptyProbabilityRequestV1,
    MeanSojournRequestV1, ServicePersistenceRequestV1,
    JointBacklogCovarianceRequestV1, StationaryBacklogPmfRequestV1,
    StationaryBacklogPgfRequestV1, StationaryBacklogMomentRequestV1,
    StationaryBacklogQuantileRequestV1, StationaryBacklogTailRequestV1,
    BacklogConditionedServiceRequestV1, StationaryEdgeRewardRequestV1,
    ServiceAutocovarianceRequestV1,
    LaggedCrossQueueCovarianceRequestV1, ServiceSpectrumRequestV1,
    ServiceWindowCountRequestV1, MeanEventGapRequestV1,
    EventGapDistributionRequestV1, MeanBinaryRunRequestV1,
    BinaryRunDistributionRequestV1, FirstHitRequestV1,
    ThresholdExcursionRequestV1, TransientBacklogLawRequestV1,
    FifoDelayRequestV1, FifoDelayConditionedRequestV1,
    CounterfactualOpportunityGapRequestV1, JointBacklogEventRequestV1,
    JointDelayRequestV1, OrderedScheduleSequenceRequestV1>;

static_assert(std::variant_size_v<MetricRequest> == 29U);

[[nodiscard]] inline const MetricRequestHeader& metric_request_header(
    const MetricRequest& request) noexcept {
  return std::visit(
      [](const auto& typed) -> const MetricRequestHeader& {
        return typed.header();
      },
      request);
}

[[nodiscard]] inline MetricKindV1 metric_request_kind(
    const MetricRequest& request) noexcept {
  return static_cast<MetricKindV1>(request.index());
}

[[nodiscard]] inline MetricRequestParametersV1 metric_request_parameters(
    const MetricRequest& request) {
  return std::visit(
      [](const auto& typed) -> MetricRequestParametersV1 {
        return typed.parameters();
      },
      request);
}

}  // namespace mwperf
