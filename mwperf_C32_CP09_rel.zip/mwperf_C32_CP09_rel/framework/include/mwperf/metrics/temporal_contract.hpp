#pragma once

#include <cstdint>
#include <memory>
#include <optional>
#include <utility>

#include "mwperf/core/sha256.hpp"

namespace mwperf {

namespace detail {
class C21CoreAccess;
class C23CoreAccess;
class TemporalContractCoreAccess;
}  // namespace detail

namespace metrics::detail {
struct InitialLawCore;
}  // namespace metrics::detail

// The analysis-v1 stopped entrance vocabulary is deliberately closed.  The
// tag is semantic: equal state shapes never permit one alternative to stand
// in for another.
enum class InitialLawKindV1 : std::uint8_t {
  stationary,
  transient,
  event_palm,
  fifo_tag,
};

// A normalized predictive entrance bound to one audited temporal source.
// Construction authority is split between C21 (stationary), C22 (transient),
// and C23 (Palm/FIFO); this public value exposes no raw source or callback.
class InitialLaw final {
 public:
  InitialLaw() = delete;
  InitialLaw(const InitialLaw&) = default;
  InitialLaw(InitialLaw&&) noexcept = default;
  InitialLaw& operator=(const InitialLaw&) = default;
  InitialLaw& operator=(InitialLaw&&) noexcept = default;

  [[nodiscard]] InitialLawKindV1 kind() const noexcept;
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept;
  // Preserved for the C21/C23 stationary-projection handoff.  A transient
  // entrance returns its source fingerprint here and is distinguished by
  // kind plus has_projection_binding().
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] bool has_projection_binding() const noexcept;

 private:
  explicit InitialLaw(
      std::shared_ptr<const metrics::detail::InitialLawCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const metrics::detail::InitialLawCore> core_;
  friend class detail::C21CoreAccess;
  friend class detail::C23CoreAccess;
  friend class detail::TemporalContractCoreAccess;
};

}  // namespace mwperf
