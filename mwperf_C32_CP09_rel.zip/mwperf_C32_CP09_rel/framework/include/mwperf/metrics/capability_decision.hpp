#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/model/typed_label.hpp"

namespace mwperf {

#ifdef MWPERF_C15_TEST_SEAMS
namespace testing {
class C15ProtocolFixtureFactory;
}
#endif

// Ordering is contractual: failures are reported by authored metric index and
// then by this field order.  Append-only changes require a capability-schema
// version change rather than reordering these values.
enum class CapabilityAxisV1 : std::uint8_t {
  regime,
  preview_integrity,
  manifest,
  semantic,
  runtime_access,
  target_scope,
  target_coupling,
  phase,
  mark,
  selection,
  arrival,
  hypothesis,
  moment,
  mandatory_v0,
  accuracy,
  construction_prerequisite,
  budget,
  policy,
};

enum class CapabilityFailureKindV1 : std::uint8_t {
  incompatible_regime,
  malformed_preview,
  unsupported_manifest_clause,
  missing_semantic_contract,
  incompatible_runtime_access,
  target_not_supported,
  target_order_mismatch,
  scalar_coupling_only,
  schedule_identity_not_retained,
  predictive_phase_not_retained,
  finite_horizon_too_short,
  missing_mark,
  reveal_stage_too_late,
  marks_not_from_common_realization,
  selection_not_supported,
  stationary_selection_missing,
  arrival_capability_missing,
  arrival_provision_incompatible,
  arrival_transform_domain_mismatch,
  arrival_moment_order_insufficient,
  hypothesis_evidence_missing,
  moment_evidence_missing,
  v0_not_declared,
  solver_regime_mismatch,
  deterministic_accuracy_missing,
  statistical_accuracy_mismatch,
  construction_prerequisite_missing,
  construction_budget_insufficient,
  policy_incomplete,
};

struct CapabilityFailureV1 final {
  std::size_t authored_metric_index;
  MetricClauseIdV1 clause_id;
  std::string metric_id;
  CapabilityAxisV1 axis;
  CapabilityFailureKindV1 kind;
  // Stable symbolic descriptions for diagnostics.  They are explanatory
  // renderings of the typed comparison, never inputs to negotiation.
  std::string provided;
  std::string required;
  std::optional<std::string> authored_path;
  std::optional<std::string> json_pointer;

  friend bool operator==(const CapabilityFailureV1&,
                         const CapabilityFailureV1&) = default;
};

struct ResolvedMetricContractV1 final {
  std::size_t authored_metric_index;
  MetricClauseIdV1 clause_id;
  std::string metric_id;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  TargetCouplingV1 target_coupling;
  SolverRegimeV1 solver_regime;
  BackendRouteKindV1 backend_route;
  Digest256 support_clause_digest;

  friend bool operator==(const ResolvedMetricContractV1&,
                         const ResolvedMetricContractV1&) = default;
};

enum class AlternativeRelationshipV1 : std::uint8_t {
  weaker_parameter_domain,
  weaker_temporal_contract,
  scalar_instead_of_coupled,
  stationary_summary_instead_of_path_law,
  different_supported_metric,
};

// Alternatives are informational only.  They deliberately contain no
// rewritten request, provider choice, callback, or construction instruction.
struct CapabilityAlternativeV1 final {
  std::size_t source_authored_metric_index;
  std::string source_metric_id;
  AlternativeRelationshipV1 relationship;
  MetricClauseIdV1 supported_clause_id;
  std::string description;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  std::vector<ResolvedMetricTargetV1> ordered_targets;

  friend bool operator==(const CapabilityAlternativeV1&,
                         const CapabilityAlternativeV1&) = default;
};

// Immutable planning handoff.  All policy/scope values are copied from the
// exact accepted preview.  Digests are integrity guards, not replacements for
// those canonical values.  The manifest uses immutable shared backing only to
// keep the public header dependency graph acyclic; it is owned by the
// contract, never borrowed from ambient preview state.
class CapabilityContractAccess;

// A successful preconstruction decision is an immutable snapshot.  It is
// privately constructed by F-C14-04's implementation and exposes only const
// views, so later preview mutation or caller-side field assignment cannot
// weaken the frozen contract.
class AcceptedCapabilityContract final {
 public:
  AcceptedCapabilityContract(const AcceptedCapabilityContract&) = default;
  AcceptedCapabilityContract(AcceptedCapabilityContract&&) noexcept = default;
  AcceptedCapabilityContract& operator=(const AcceptedCapabilityContract&) =
      default;
  AcceptedCapabilityContract& operator=(AcceptedCapabilityContract&&) noexcept =
      default;

  [[nodiscard]] std::uint32_t schema_version() const noexcept {
    return schema_version_;
  }
  [[nodiscard]] const ProviderIdentityV1& provider() const noexcept {
    return provider_;
  }
  [[nodiscard]] ConstructionMethodV1 construction_method() const noexcept {
    return construction_method_;
  }
  [[nodiscard]] ProducerModeV1 producer_mode() const noexcept {
    return producer_mode_;
  }
  [[nodiscard]] const PayloadClassV1& payload_class() const noexcept {
    return payload_class_;
  }
  [[nodiscard]] SemanticTagV1 semantic() const noexcept { return semantic_; }
  [[nodiscard]] RuntimeAccessTagV1 runtime_access() const noexcept {
    return runtime_access_;
  }
  [[nodiscard]] const PlugDescriptorCore& descriptor_core() const noexcept {
    return descriptor_core_;
  }
  [[nodiscard]] const MetricSupportManifest& structural_manifest() const
      noexcept {
    return structural_manifest_;
  }
  [[nodiscard]] const MetricRequirements& requirements() const noexcept {
    return requirements_;
  }
  [[nodiscard]] const ArrivalCapabilities& arrival_capabilities() const
      noexcept {
    return arrival_capabilities_;
  }
  [[nodiscard]] std::span<const ResolvedMetricContractV1> metric_contracts()
      const noexcept {
    return metric_contracts_;
  }
  [[nodiscard]] std::span<const QueueId> construction_target_scope() const
      noexcept {
    return construction_target_scope_;
  }
  [[nodiscard]] const PreviewPoliciesV1& policies() const noexcept {
    return policies_;
  }
  [[nodiscard]] const ConstructionPrerequisitesV1&
  construction_prerequisites() const noexcept {
    return construction_prerequisites_;
  }
  [[nodiscard]] const Digest256& requirements_digest() const noexcept {
    return requirements_digest_;
  }
  [[nodiscard]] const Digest256& arrival_capabilities_digest() const noexcept {
    return arrival_capabilities_digest_;
  }
  [[nodiscard]] const Digest256& preview_digest() const noexcept {
    return preview_digest_;
  }
  [[nodiscard]] const Digest256& parameter_digest() const noexcept {
    return parameter_digest_;
  }
  [[nodiscard]] const Digest256& budget_digest() const noexcept {
    return budget_digest_;
  }
  [[nodiscard]] const Digest256& contract_digest() const noexcept {
    return contract_digest_;
  }

 private:
  AcceptedCapabilityContract(
      std::uint32_t schema_version, ProviderIdentityV1 provider,
      ConstructionMethodV1 construction_method, ProducerModeV1 producer_mode,
      PayloadClassV1 payload_class, SemanticTagV1 semantic,
      RuntimeAccessTagV1 runtime_access, PlugDescriptorCore descriptor_core,
      MetricSupportManifest structural_manifest,
      MetricRequirements requirements,
      ArrivalCapabilities arrival_capabilities,
      std::vector<ResolvedMetricContractV1> metric_contracts,
      std::vector<QueueId> construction_target_scope,
      PreviewPoliciesV1 policies,
      ConstructionPrerequisitesV1 construction_prerequisites,
      Digest256 requirements_digest, Digest256 arrival_capabilities_digest,
      Digest256 preview_digest, Digest256 parameter_digest,
      Digest256 budget_digest, Digest256 contract_digest)
      : schema_version_(schema_version),
        provider_(std::move(provider)),
        construction_method_(construction_method),
        producer_mode_(producer_mode),
        payload_class_(std::move(payload_class)),
        semantic_(semantic),
        runtime_access_(runtime_access),
        descriptor_core_(std::move(descriptor_core)),
        structural_manifest_(std::move(structural_manifest)),
        requirements_(std::move(requirements)),
        arrival_capabilities_(std::move(arrival_capabilities)),
        metric_contracts_(std::move(metric_contracts)),
        construction_target_scope_(std::move(construction_target_scope)),
        policies_(std::move(policies)),
        construction_prerequisites_(std::move(construction_prerequisites)),
        requirements_digest_(std::move(requirements_digest)),
        arrival_capabilities_digest_(
            std::move(arrival_capabilities_digest)),
        preview_digest_(std::move(preview_digest)),
        parameter_digest_(std::move(parameter_digest)),
        budget_digest_(std::move(budget_digest)),
        contract_digest_(std::move(contract_digest)) {}

  std::uint32_t schema_version_;
  ProviderIdentityV1 provider_;
  ConstructionMethodV1 construction_method_;
  ProducerModeV1 producer_mode_;
  PayloadClassV1 payload_class_;
  SemanticTagV1 semantic_;
  RuntimeAccessTagV1 runtime_access_;
  PlugDescriptorCore descriptor_core_;
  MetricSupportManifest structural_manifest_;
  MetricRequirements requirements_;
  ArrivalCapabilities arrival_capabilities_;
  std::vector<ResolvedMetricContractV1> metric_contracts_;
  std::vector<QueueId> construction_target_scope_;
  PreviewPoliciesV1 policies_;
  ConstructionPrerequisitesV1 construction_prerequisites_;
  Digest256 requirements_digest_;
  Digest256 arrival_capabilities_digest_;
  Digest256 preview_digest_;
  Digest256 parameter_digest_;
  Digest256 budget_digest_;
  Digest256 contract_digest_;

  friend class CapabilityContractAccess;
#ifdef MWPERF_C15_TEST_SEAMS
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

struct AcceptedCapabilityDecision final {
  AcceptedCapabilityContract contract;
};

struct RejectedCapabilityDecision final {
  // Canonical order: authored metric index, CapabilityAxisV1, then the
  // deterministic local comparison order used by F-C14-04.
  std::vector<CapabilityFailureV1> ordered_failures;
  // Canonically ordered maximal valid alternatives under the metric-specific
  // explanatory partial order.  These never modify ordered_failures.
  std::vector<CapabilityAlternativeV1> alternatives;
  Digest256 requirements_digest;
  Digest256 arrival_capabilities_digest;
  Digest256 preview_digest;
};

using CapabilityDecision =
    std::variant<AcceptedCapabilityDecision, RejectedCapabilityDecision>;

[[nodiscard]] inline bool capability_decision_is_accepted(
    const CapabilityDecision& decision) noexcept {
  return std::holds_alternative<AcceptedCapabilityDecision>(decision);
}

[[nodiscard]] inline const AcceptedCapabilityContract*
accepted_capability_contract(const CapabilityDecision& decision) noexcept {
  const auto* accepted =
      std::get_if<AcceptedCapabilityDecision>(&decision);
  return accepted == nullptr ? nullptr : &accepted->contract;
}

[[nodiscard]] inline const RejectedCapabilityDecision*
rejected_capability_decision(const CapabilityDecision& decision) noexcept {
  return std::get_if<RejectedCapabilityDecision>(&decision);
}

}  // namespace mwperf
