#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/metrics/temporal.hpp"
#include "mwperf/stationary/suspension.hpp"

namespace mwperf {

namespace metrics::detail {
struct PalmLawCore;
struct AdmissionRateCore;
struct StationaryQueueLawCore;
struct AdmissionPalmLawCore;
struct TagInitialLawCore;
struct DelayLawCore;
}  // namespace metrics::detail

namespace detail {
class C23CoreAccess;
}  // namespace detail

// F-C23-01 supports both a genuinely binary event and a retained target
// arrival count.  The latter is deliberately a count, rather than the
// predicate A>0, so a batch contributes one Palm label per packet.
struct BinaryEventCountV1 final {
  TemporalEdgePredicateV1 predicate;
  friend bool operator==(const BinaryEventCountV1&,
                         const BinaryEventCountV1&) = default;
};

struct TargetArrivalEventCountV1 final {
  std::size_t target_ordinal;
  friend bool operator==(const TargetArrivalEventCountV1&,
                         const TargetArrivalEventCountV1&) = default;
};

using EventCountRuleV1 =
    std::variant<BinaryEventCountV1, TargetArrivalEventCountV1>;

struct EventIndicator final {
  std::string event_type_id;
  std::string label_schema_id;
  EventCountRuleV1 count_rule;
};

struct PalmAtomV1 final {
  std::size_t continuation_index;
  ReducedStateV1 event_entry_state;
  BigNat event_label;
  ExactRational exact_mass;
  long double numerical_mass;
};

struct PalmNumericalDiagnosticsV1 final {
  long double numerical_intensity;
  long double intensity_correction;
  long double numerical_total_mass;
  long double normalization_residual;
};

class PalmLaw final {
 public:
  PalmLaw() = delete;
  PalmLaw(const PalmLaw&) = default;
  PalmLaw(PalmLaw&&) noexcept = default;
  PalmLaw& operator=(const PalmLaw&) = default;
  PalmLaw& operator=(PalmLaw&&) noexcept = default;

  [[nodiscard]] const ExactRational& exact_event_intensity() const noexcept;
  [[nodiscard]] const PalmNumericalDiagnosticsV1& diagnostics() const
      noexcept;
  [[nodiscard]] std::span<const PalmAtomV1> atoms() const noexcept;
  [[nodiscard]] const std::string& event_type_id() const noexcept;
  [[nodiscard]] const std::string& label_schema_id() const noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& source_law_identity() const noexcept;
  [[nodiscard]] const Digest256& timing_identity() const noexcept;
  [[nodiscard]] const InitialLaw& initial_law() const noexcept;

 private:
  explicit PalmLaw(
      std::shared_ptr<const metrics::detail::PalmLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::PalmLawCore> core_;
  friend class detail::C23CoreAccess;
};

enum class AdmissionCountingSemanticsV1 : std::uint8_t {
  retained_edge_packet_labels,
  nonempty_slot_conditioning,
  independently_redrawn_batch,
};

struct ArrivalCountMark final {
  std::size_t target_ordinal;
  AdmissionCountingSemanticsV1 semantics;
};

struct AdmissionPalmAtomV1 final {
  std::size_t edge_atom_index;
  BigNat batch_size;
  BigNat within_batch_rank;
  BigNat prearrival_backlog;
  std::uint8_t actual_departure;
  BigNat first_eligible_backlog;
  ArrivalPhaseIdentityV1 first_eligible_phase;
  std::vector<CausalMarkV1> retained_edge_marks;
  std::vector<RuntimeDecodedMarkV1> entrance_labels;
  ExactRational exact_mass;
  long double numerical_mass;
};

struct StationaryQueueMassV1 final {
  BigNat backlog;
  ExactRational exact_mass;
  long double numerical_mass;
};

class AdmissionRate final {
 public:
  AdmissionRate() = delete;
  AdmissionRate(const AdmissionRate&) = default;
  AdmissionRate(AdmissionRate&&) noexcept = default;
  AdmissionRate& operator=(const AdmissionRate&) = default;
  AdmissionRate& operator=(AdmissionRate&&) noexcept = default;

  [[nodiscard]] const ExactRational& exact_value() const noexcept;
  [[nodiscard]] long double numerical_value() const noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;
  [[nodiscard]] std::size_t target_ordinal() const noexcept;

 private:
  explicit AdmissionRate(
      std::shared_ptr<const metrics::detail::AdmissionRateCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::AdmissionRateCore> core_;
  friend class detail::C23CoreAccess;
};

struct LabelledOccupancyEvidenceV1 final {
  bool two_sided_stationary;
  bool finite_slot_occupancy_almost_surely;
  bool occupancy_equals_admitted_not_departed;
  bool every_present_label_has_finite_admission_epoch;
  bool lossless;
  bool unit_packets;
};

class StationaryQueueLaw final {
 public:
  StationaryQueueLaw() = delete;
  StationaryQueueLaw(const StationaryQueueLaw&) = default;
  StationaryQueueLaw(StationaryQueueLaw&&) noexcept = default;
  StationaryQueueLaw& operator=(const StationaryQueueLaw&) = default;
  StationaryQueueLaw& operator=(StationaryQueueLaw&&) noexcept = default;

  [[nodiscard]] std::span<const StationaryQueueMassV1> atoms() const
      noexcept;
  [[nodiscard]] const ExtendedNonnegativeV1& mean_backlog() const noexcept;
  [[nodiscard]] const LabelledOccupancyEvidenceV1& labelled_evidence() const
      noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;
  [[nodiscard]] std::size_t target_ordinal() const noexcept;

 private:
  explicit StationaryQueueLaw(
      std::shared_ptr<const metrics::detail::StationaryQueueLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::StationaryQueueLawCore> core_;
  friend class detail::C23CoreAccess;
};

class AdmissionPalmLaw final {
 public:
  AdmissionPalmLaw() = delete;
  AdmissionPalmLaw(const AdmissionPalmLaw&) = default;
  AdmissionPalmLaw(AdmissionPalmLaw&&) noexcept = default;
  AdmissionPalmLaw& operator=(const AdmissionPalmLaw&) = default;
  AdmissionPalmLaw& operator=(AdmissionPalmLaw&&) noexcept = default;

  [[nodiscard]] std::span<const AdmissionPalmAtomV1> atoms() const noexcept;
  [[nodiscard]] const AdmissionRate& admission_rate() const noexcept;
  [[nodiscard]] const StationaryQueueLaw& stationary_queue_law() const
      noexcept;
  [[nodiscard]] const PalmNumericalDiagnosticsV1& diagnostics() const
      noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& marked_edge_identity() const noexcept;
  [[nodiscard]] const Digest256& timing_identity() const noexcept;
  [[nodiscard]] std::size_t target_ordinal() const noexcept;

 private:
  explicit AdmissionPalmLaw(
      std::shared_ptr<const metrics::detail::AdmissionPalmLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::AdmissionPalmLawCore> core_;
  friend class detail::C23CoreAccess;
};

struct TagState final {
  ReducedStateV1 untagged_state;
  BigNat predecessors;

  friend bool operator==(const TagState&, const TagState&) = default;
};

struct TagEntranceLabelV1 final {
  BigNat batch_size;
  BigNat within_batch_rank;
  ArrivalPhaseIdentityV1 phase;
  std::vector<CausalMarkV1> retained_edge_marks;
  std::vector<RuntimeDecodedMarkV1> entrance_labels;

  friend bool operator==(const TagEntranceLabelV1&,
                         const TagEntranceLabelV1&) = default;
};

struct TagInitialAtomV1 final {
  TagState state;
  std::size_t continuation_index;
  TagEntranceLabelV1 label;
  ExactRational exact_mass;
  long double numerical_mass;
};

struct FifoTagAssumptionsV1 final {
  bool global_fifo;
  bool unit_packets;
  bool lossless;
  bool finite_batches_almost_surely;
  bool positive_finite_admission_intensity;
  bool full_history_predictive_service;
  bool passive_tag;
};

struct RankPalmConditionV1 final {
  BigNat rank;
  friend bool operator==(const RankPalmConditionV1&,
                         const RankPalmConditionV1&) = default;
};

struct BatchPalmConditionV1 final {
  BigNat batch_size;
  friend bool operator==(const BatchPalmConditionV1&,
                         const BatchPalmConditionV1&) = default;
};

struct PhasePalmConditionV1 final {
  ArrivalPhaseIdentityV1 phase;
  friend bool operator==(const PhasePalmConditionV1&,
                         const PhasePalmConditionV1&) = default;
};

struct RetainedMarkPalmConditionV1 final {
  RuntimeMarkIdV1 mark_id;
  CodecIdentityV1 codec;
  std::vector<std::byte> canonical_value;
  friend bool operator==(const RetainedMarkPalmConditionV1&,
                         const RetainedMarkPalmConditionV1&) = default;
};

using PalmConditionV1 =
    std::variant<RankPalmConditionV1, BatchPalmConditionV1,
                 PhasePalmConditionV1, RetainedMarkPalmConditionV1>;

class TagInitialLaw final {
 public:
  TagInitialLaw() = delete;
  TagInitialLaw(const TagInitialLaw&) = default;
  TagInitialLaw(TagInitialLaw&&) noexcept = default;
  TagInitialLaw& operator=(const TagInitialLaw&) = default;
  TagInitialLaw& operator=(TagInitialLaw&&) noexcept = default;

  [[nodiscard]] std::span<const TagInitialAtomV1> atoms() const noexcept;
  [[nodiscard]] const AdmissionRate& admission_rate() const noexcept;
  [[nodiscard]] const StationaryQueueLaw& stationary_queue_law() const
      noexcept;
  [[nodiscard]] const FifoTagAssumptionsV1& assumptions() const noexcept;
  [[nodiscard]] const std::optional<PalmConditionV1>& conditioning() const
      noexcept;
  [[nodiscard]] bool is_unconditioned_all_admissions() const noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& entrance_identity() const noexcept;
  [[nodiscard]] std::size_t target_ordinal() const noexcept;

 private:
  explicit TagInitialLaw(
      std::shared_ptr<const metrics::detail::TagInitialLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::TagInitialLawCore> core_;
  friend class detail::C23CoreAccess;
};

struct TemporalServiceStep final {
  ReducedStateV1 successor_untagged_state;
  BigNat successor_total_backlog;
  std::uint8_t actual_target_departure;
};

struct TagTransition final {
  bool tag_departed;
  std::optional<TagState> survivor;
};

struct DelayTailV1 final {
  BigNat completed_eligible_slots;
  ExactRational exact_probability;
};

struct DelayMassV1 final {
  BigNat sojourn_slots;
  ExactRational exact_probability;
};

enum class DelayQuantileStatusV1 : std::uint8_t {
  established,
  beyond_defective_mass,
  unresolved_horizon,
};

struct DelayQuantileV1 final {
  DelayQuantileStatusV1 status;
  ExactRational requested_probability;
  std::optional<BigNat> sojourn_slots;
  ExactRational exact_cdf_below;
  ExactRational exact_cdf_at;
};

enum class DelayMomentStatusV1 : std::uint8_t {
  established,
  positive_infinity,
  unresolved,
};

struct DelayMomentV1 final {
  BigNat order;
  DelayMomentStatusV1 status;
  std::optional<ExactRational> exact_value;
};

struct DelayLawDiagnosticsV1 final {
  ExactRational exact_entrance_mass_residual;
  ExactRational exact_maximum_killed_row_residual;
  std::size_t lifted_state_count;
  std::size_t lifted_row_atom_count;
  std::size_t maximum_initial_rank;
  std::size_t requested_horizon;
  bool coefficient_crosscheck_performed;
  bool coefficient_crosscheck_exact;
  // The coefficient propagation is an optional acceleration/cross-check.
  // When it cannot be run, the explicit passive-tag/C22 result remains
  // authoritative and this field states the typed reason for the loss of
  // coefficient access.
  std::optional<Diagnostic> coefficient_crosscheck_diagnostic;
  bool conditioned_entrance;
  std::string timing_convention;
};

class DelayLaw final {
 public:
  DelayLaw() = delete;
  DelayLaw(const DelayLaw&) = default;
  DelayLaw(DelayLaw&&) noexcept = default;
  DelayLaw& operator=(const DelayLaw&) = default;
  DelayLaw& operator=(DelayLaw&&) noexcept = default;

  [[nodiscard]] std::span<const DelayTailV1> tails() const noexcept;
  [[nodiscard]] std::span<const DelayMassV1> finite_pmf() const noexcept;
  [[nodiscard]] const ExactRational& unresolved_tail_mass() const noexcept;
  [[nodiscard]] const ExactRational& proven_defective_mass() const noexcept;
  [[nodiscard]] AbsorptionStatusV1 absorption_status() const noexcept;
  [[nodiscard]] const ExtendedNonnegativeV1& mean_sojourn() const noexcept;
  [[nodiscard]] const HorizonSpec& horizon() const noexcept;
  [[nodiscard]] const DelayLawDiagnosticsV1& diagnostics() const noexcept;
  [[nodiscard]] const StoppedMetricBundle& stopped_backend_result() const
      noexcept;
  [[nodiscard]] const AdmissionRate& admission_rate() const noexcept;
  [[nodiscard]] const StationaryQueueLaw& stationary_queue_law() const
      noexcept;
  [[nodiscard]] const std::optional<PalmConditionV1>& conditioning() const
      noexcept;
  [[nodiscard]] bool is_unconditioned_all_admissions() const noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept;
  [[nodiscard]] std::size_t target_ordinal() const noexcept;
  [[nodiscard]] Result<DelayQuantileV1> quantile(
      const ExactRational& probability) const;
  // Order one delegates to C22's minimal nonnegative potential.  Authorized
  // higher orders solve the exact stopped-time recurrence on the same killed
  // kernel.  A positive infinite first moment makes every positive order
  // infinite; unavailable first-moment classification remains unresolved.
  [[nodiscard]] Result<DelayMomentV1> moment(const BigNat& order) const;

 private:
  explicit DelayLaw(
      std::shared_ptr<const metrics::detail::DelayLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const metrics::detail::DelayLawCore> core_;
  friend class detail::C23CoreAccess;
};

// F-C23-01
[[nodiscard]] Result<PalmLaw> construct_event_palm_law(
    const StationaryTemporalLaw& law, const EventIndicator& indicator);

// F-C23-02
[[nodiscard]] Result<AdmissionPalmLaw> construct_admission_palm_law(
    const StationaryMarkedEdge& edge, const ArrivalCountMark& mark);

// F-C23-03
[[nodiscard]] Result<TagInitialLaw> lift_fifo_tag_state(
    const AdmissionPalmLaw& law, const PredictiveServiceSplit& split);

// Select one accepted entrance condition from a TagInitialLaw that retains
// more than one accepted FIFO request.  This is an entrance readout helper,
// not an additional catalog/DAG node: it only filters and exactly
// renormalizes the F-C23-03 Palm entrance and never touches service rows.
[[nodiscard]] Result<TagInitialLaw> condition_tag_initial_law(
    const TagInitialLaw& law, const PalmConditionV1& condition);
[[nodiscard]] Result<TagInitialLaw> condition_tag_initial_law(
    const TagInitialLaw& law, const FifoConditionV1& condition);

// F-C23-04
[[nodiscard]] Result<TagTransition> advance_passive_fifo_tag(
    const TagState& state, const TemporalServiceStep& step);

// F-C23-05
[[nodiscard]] Result<DelayLaw> evaluate_fifo_delay_distribution(
    const TagInitialLaw& initial_law,
    const TemporalServiceKernel& service_kernel,
    const HorizonSpec& horizon, const SolverPolicy& policy);

// F-C23-06.  An informational category with code
// c23.little_identity_verified is a successful finite numerical comparison;
// unavailable codes are scoped non-applicability diagnostics.
[[nodiscard]] Diagnostic verify_little_identity(
    const StationaryQueueLaw& queue_law, const AdmissionRate& rate,
    const DelayLaw& delay_law);

#if defined(MWPERF_C23_TEST_SEAMS)
namespace testing {

struct C23SyntheticAdmissionEdgeV1 final {
  ExactRational exact_slot_mass;
  BigNat prearrival_backlog;
  std::uint8_t actual_departure;
  BigNat arrival_batch;
};

struct C23SyntheticPalmAtomInspectionV1 final {
  std::size_t edge_index;
  BigNat batch_size;
  BigNat rank;
  BigNat first_eligible_backlog;
  BigNat predecessors;
  ExactRational exact_mass;
};

struct C23SyntheticAdmissionPalmInspectionV1 final {
  ExactRational exact_intensity;
  std::vector<C23SyntheticPalmAtomInspectionV1> atoms;
  ExactRational exact_total_mass;
};

struct C23SyntheticServiceTransitionV1 final {
  std::size_t successor_index;
  std::uint8_t departure;
  ExactRational exact_mass;
};

struct C23SyntheticServiceStateV1 final {
  std::vector<C23SyntheticServiceTransitionV1> transitions;
};

struct C23SyntheticPolynomialEntranceV1 final {
  std::size_t state_index;
  std::size_t predecessors;
  ExactRational exact_mass;
};

struct C23SyntheticFifoNodeV1 final {
  BigNat total_backlog;
  ArrivalPhaseIdentityV1 phase;
  std::vector<C23SyntheticServiceTransitionV1> transitions;
};

struct C23SyntheticFifoEntranceV1 final {
  std::size_t state_index;
  BigNat predecessors;
  ExactRational exact_mass;
};

enum class C23PredictiveSplitFaultV1 : std::uint8_t {
  conditional_mass_mismatch,
  incomplete_partition,
  service_schema_mismatch,
  successor_phase_schema_mismatch,
};

enum class C23AdmissionPalmFaultV1 : std::uint8_t {
  rank_zero,
  rank_above_batch,
  departure_exceeds_backlog,
};

enum class C23ExecutionStageV1 : std::uint8_t {
  passive_tag_adapter_advance,
  construct_killed_kernel,
  evaluate_hit_survival_absorption,
  coefficient_backend,
};

class C23FixtureAccess final {
 public:
  C23FixtureAccess() = delete;

  [[nodiscard]] static Result<C23SyntheticAdmissionPalmInspectionV1>
  inspect_admission_palm(
      std::vector<C23SyntheticAdmissionEdgeV1> edges);

  // Replaces copied C21 stationary source atoms while preserving the real
  // closed carrier and accepted binding.  The caller then invokes the public
  // F-C23-02 implementation, so this seam is fixture preparation rather than
  // a second Palm-law oracle.
  [[nodiscard]] static Result<StationaryMarkedEdge>
  with_synthetic_admission_edges(
      const StationaryMarkedEdge& seed,
      std::vector<C23SyntheticAdmissionEdgeV1> edges);

  [[nodiscard]] static Result<std::vector<ExactRational>>
  departure_polynomial_tails(
      std::vector<C23SyntheticServiceStateV1> states,
      std::vector<C23SyntheticPolynomialEntranceV1> entrance,
      std::size_t maximum_tail_index);

  [[nodiscard]] static Result<StationaryQueueLaw>
  with_labelled_occupancy_evidence(
      const StationaryQueueLaw& law,
      LabelledOccupancyEvidenceV1 evidence);

  [[nodiscard]] static Result<AdmissionRate> with_exact_admission_rate(
      const AdmissionRate& rate, ExactRational exact_value);

  // Closed-carrier negative-test mutations.  These helpers deliberately
  // preserve the original source owner and every unrelated field so tests
  // reach the production F-C23-03/F-C23-05 validation boundary instead of
  // manufacturing a second service model.
  [[nodiscard]] static Result<PredictiveServiceSplit>
  with_predictive_split_fault(
      const PredictiveServiceSplit& split,
      C23PredictiveSplitFaultV1 fault);

  [[nodiscard]] static Result<AdmissionPalmLaw> with_admission_palm_fault(
      const AdmissionPalmLaw& law, C23AdmissionPalmFaultV1 fault);

  [[nodiscard]] static Result<TagInitialLaw> with_fifo_assumptions(
      const TagInitialLaw& law, FifoTagAssumptionsV1 assumptions);

  // Reuses a real passing C21 projection solely as the closed authority and
  // identity seed, replaces its finite value-only service table and tag
  // entrance, then invokes the production F-C23-05 implementation.  This
  // permits exact adversarial graph tests without exposing a public tag- or
  // service-kernel constructor.
  [[nodiscard]] static Result<DelayLaw> evaluate_synthetic_fifo_delay(
      const TagInitialLaw& seed_initial,
      const TemporalServiceKernel& seed_service,
      std::vector<C23SyntheticFifoNodeV1> nodes,
      std::vector<C23SyntheticFifoEntranceV1> entrance,
      std::vector<FifoDelayOutputV1> authorized_outputs,
      const HorizonSpec& horizon, const SolverPolicy& policy);

  // The override is thread-local and consumed by the next F-C23-05 call.
  // Zero is accepted so a small fixture can prove optional-backend fallback
  // without constructing an enormous coefficient frontier.
  static void limit_next_coefficient_backend(
      std::size_t maximum_frontier_states,
      std::size_t maximum_transition_work) noexcept;

  // Forces the next F-C23-05 coefficient comparison to report disagreement
  // after both exact backends have completed.  This proves that a loss of the
  // optional cross-check cannot discard the authoritative explicit C22 law.
  static void mismatch_next_coefficient_crosscheck() noexcept;

  [[nodiscard]] static std::vector<C23ExecutionStageV1>
  last_fifo_execution_trace();
};

}  // namespace testing
#endif

}  // namespace mwperf
