#pragma once

#include <cstdint>
#include <filesystem>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <variant>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// Final framework-result publication is an independent version axis from
// the provider result, surrogate artifact, payload, and observation record.
// `automatic` preserves result-v1 for legacy routes and selects result-v2
// whenever the frozen provider route requires the diagnostic data plane.
enum class ResultVersionSelectionV1 : std::uint8_t {
  automatic,
  v1,
  v2,
  v3,
};

struct CliPath {
  std::string authored;
  std::filesystem::path path;

  friend bool operator==(const CliPath&, const CliPath&) = default;
};

struct Help {
  friend bool operator==(Help, Help) = default;
};

struct Version {
  friend bool operator==(Version, Version) = default;
};

struct Analyze {
  CliPath model_path;
  CliPath analysis_path;
  CliPath output_path;
  // When present, C27 constructs the versioned built-in Full Orbit analysis
  // profile in memory.  analysis_path is empty in this mode.  Its field
  // position preserves source compatibility for existing aggregate initializers.
  std::optional<std::string> target_queue{};

  // Provider execution controls are host/runtime policy, not authored model
  // data and not part of any scientific or request identity.  Defaults retain
  // the former single-worker, one-hour behavior while allowing expensive
  // exact scenarios to opt into CP06's deterministic parallel coordinator
  // and a longer bounded runner deadline.
  std::uint32_t worker_count{1U};
  std::uint64_t timeout_seconds{3600U};
  bool output_resources{false};
  // Publication policy only.  This flag is deliberately excluded from every
  // scientific identity, provider request, and deterministic RNG address.
  bool report_unavailable_diagnostics{false};
  ResultVersionSelectionV1 result_version{ResultVersionSelectionV1::automatic};

  friend bool operator==(const Analyze&, const Analyze&) = default;
};

struct CompareCompression final {
  CliPath stationary_reference;
  CliPath finite_window_reference;
  CliPath weighted_ensemble;
  std::optional<CliPath> decoder_result;
  // Cutoffs are mathematical queue levels, not allocation sizes.  Retain
  // them as arbitrary-precision naturals all the way to the compression
  // analyzer so CP09 empirical projections never acquire a native-width or
  // finite-prefix cutoff limit at the CLI boundary.
  std::vector<BigNat> cutoffs{BigNat{4U}, BigNat{8U}, BigNat{12U}};
  CliPath output_path;

  friend bool operator==(const CompareCompression&,
                         const CompareCompression&) = default;
};

using CliMode = std::variant<Help, Version, Analyze, CompareCompression>;

struct CliRequest {
  CliMode mode;

  friend bool operator==(const CliRequest&, const CliRequest&) = default;
};

[[nodiscard]] Result<CliRequest> parse_cli(
    std::span<const std::string_view> arguments);

}  // namespace mwperf
