#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// Exact target-coordinate arrival atom consumed by the phase-free fit.  This
// type is intentionally independent of ArrivalLaw and AuditedResponseLaw: a
// diagnostic fit is bound to validated observations, not to a fabricated
// surrogate or C19 flux facade.
struct FinitePrefixFitArrivalAtomV1 final {
  BigNat count;
  ExactRational mass;

  friend bool operator==(const FinitePrefixFitArrivalAtomV1&,
                         const FinitePrefixFitArrivalAtomV1&) = default;
};

// Exact initial-selection support used only by the finite-closure proof.  An
// empty seed means that selected-class closure is unavailable; it never means
// an implicit point mass at zero.
struct FinitePrefixFitSelectionSeedAtomV1 final {
  BigNat backlog;
  ExactRational selection_mass;

  friend bool operator==(const FinitePrefixFitSelectionSeedAtomV1&,
                         const FinitePrefixFitSelectionSeedAtomV1&) = default;
};

// The coefficient source is the observation-record digest on the diagnostic
// route and the deployed response-product digest on the compatibility route.
// Keeping the two axes typed and adjacent prevents a fit from being joined to
// a different configured arrival law.
struct FinitePrefixFitBindingV1 final {
  Digest256 coefficient_source_digest;
  Digest256 arrival_law_digest;

  friend bool operator==(const FinitePrefixFitBindingV1&,
                         const FinitePrefixFitBindingV1&) = default;
};

// Admission checks happen before any cutoff-sized allocation.  Production
// callers may use tighter limits; these defaults comfortably cover the
// diagnostic K={4,8,12} sweep without making the API unbounded.
struct FinitePrefixFitLimitsV1 final {
  std::size_t maximum_cutoff{64U};
  std::size_t maximum_arrival_atoms{65536U};
  std::size_t maximum_selection_seed_atoms{65U};
  std::size_t maximum_closure_states{65U};

  friend bool operator==(const FinitePrefixFitLimitsV1&,
                         const FinitePrefixFitLimitsV1&) = default;
};

// Some infinite-support IID laws have a compact analytic moment description
// even though the cut recurrence consumes only a finite probability prefix.
// When present, these moments replace moments of the finite recurrence
// projection.  This keeps a collapsed residual tail from changing the drift
// identities used for E[Q] and E[Q^2].
struct FinitePrefixFitArrivalMomentsV1 final {
  ExactRational mean;
  ExactRational second;
  ExactRational third;

  friend bool operator==(const FinitePrefixFitArrivalMomentsV1&,
                         const FinitePrefixFitArrivalMomentsV1&) = default;
};

// Pure finite-prefix/constant-tail input.  In particular, there is no field
// for an observed occupation mean (or any other observed stationary moment),
// so empirical data cannot be used to correct the prediction being tested.
struct FinitePrefixFitInputV1 final {
  std::vector<FinitePrefixFitArrivalAtomV1> target_arrival_atoms;
  bool second_arrival_moment_available;
  // A finite exact target marginal determines every polynomial moment, but
  // callers still state which moments their scientific contract permits the
  // fit to publish.  The third arrival moment is the additional premise
  // needed by the stationary third-power drift identity that determines
  // E[N^2] on the strict constant-tail branch.
  bool third_arrival_moment_available;
  std::vector<FinitePrefixFitSelectionSeedAtomV1> selection_seed;
  std::vector<ExactRational> service_by_level;
  ExactRational constant_tail_service;
  FinitePrefixFitBindingV1 binding;
  FinitePrefixFitLimitsV1 limits;
  std::optional<FinitePrefixFitArrivalMomentsV1> analytic_arrival_moments;
  bool arrival_support_extends_beyond_projection{false};
};

enum class FinitePrefixFitStatusV1 : std::uint8_t {
  strict_tail_stable,
  finite_closed_tail_unreachable,
  outside_strict_tail_profile,
  degenerate_or_selected_closed_class,
  required_moment_unavailable,
  unsupported_assumptions,
};

enum class FinitePrefixFitSlackApplicabilityV1 : std::uint8_t {
  applicable,
  not_applicable_off_class,
  stationary_law_not_established,
};

// Residuals are present only when their exact identity is applicable.  A
// missing residual is not encoded as zero: that distinction matters on
// unavailable and finite-closure branches.
struct FinitePrefixFitClosureResidualsV1 final {
  std::optional<ExactRational> normalization;
  std::optional<ExactRational> invariance;
  std::optional<ExactRational> mean_identity;

  friend bool operator==(const FinitePrefixFitClosureResidualsV1&,
                         const FinitePrefixFitClosureResidualsV1&) = default;
};

struct FinitePrefixFitResultV1 final {
  FinitePrefixFitStatusV1 status;
  FinitePrefixFitBindingV1 binding;
  std::vector<ExactRational> consumed_service_by_level;
  ExactRational consumed_constant_tail_service;
  ExactRational arrival_mean;
  std::optional<ExactRational> arrival_second_moment;
  std::optional<ExactRational> arrival_third_moment;
  std::optional<std::vector<ExactRational>> fitted_prefix_probabilities;
  std::optional<ExactRational> fitted_tail_mass;
  std::optional<ExactRational> fitted_mean_backlog;
  std::optional<ExactRational> fitted_second_backlog_moment;
  FinitePrefixFitSlackApplicabilityV1 tail_slack_applicability;
  std::optional<ExactRational> tail_slack;
  FinitePrefixFitClosureResidualsV1 residuals;
  BigNat terms_evaluated;
  std::vector<BigNat> finite_reachable_support;

  [[nodiscard]] bool normalized_law_established() const noexcept {
    return fitted_prefix_probabilities.has_value() &&
           fitted_tail_mass.has_value();
  }
};

// Computes the exact phase-free finite-prefix/constant-tail fit for any
// admitted K.  Input vectors are canonicalized locally and the result reports
// the coefficients actually consumed by the recurrence.
[[nodiscard]] Result<FinitePrefixFitResultV1>
fit_finite_prefix_constant_tail(FinitePrefixFitInputV1 input);

}  // namespace mwperf
