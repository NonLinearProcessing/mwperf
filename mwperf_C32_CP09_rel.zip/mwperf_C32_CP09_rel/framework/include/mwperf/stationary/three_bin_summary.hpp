#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <utility>

#include "mwperf/stationary/analytic.hpp"

namespace mwperf {

#if defined(MWPERF_C19_TEST_SEAMS)
namespace testing {
class C19ThreeBinFixtureAccess;
}
#endif

namespace stationary::detail {
struct StationaryConditioningMassCore;
struct ThreeBinIidSummaryCore;
}  // namespace stationary::detail

enum class StationaryConditioningRegionV1 : std::uint8_t {
  backlog_zero,
  backlog_one,
  backlog_two,
  backlog_at_least_three,
};

enum class StationaryConditioningMassKindV1 : std::uint8_t {
  established_positive,
  established_zero,
  aggregate_only,
  stationary_law_not_established,
};

// This solver-owned status has no wire/proposal constructor: C15 proposal
// conditioning cannot be upgraded into a stationary conditioning fact.
class StationaryConditioningMassStatus final {
 public:
  StationaryConditioningMassStatus() = delete;
  StationaryConditioningMassStatus(
      const StationaryConditioningMassStatus&) = default;
  StationaryConditioningMassStatus(
      StationaryConditioningMassStatus&&) noexcept = default;
  StationaryConditioningMassStatus& operator=(
      const StationaryConditioningMassStatus&) = default;
  StationaryConditioningMassStatus& operator=(
      StationaryConditioningMassStatus&&) noexcept = default;
  [[nodiscard]] StationaryConditioningMassKindV1 kind() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& mass() const noexcept;
  [[nodiscard]] const std::optional<StationaryConditioningRegionV1>& region()
      const noexcept;
  friend bool operator==(const StationaryConditioningMassStatus&,
                         const StationaryConditioningMassStatus&);

 private:
  explicit StationaryConditioningMassStatus(
      std::shared_ptr<const
                      stationary::detail::StationaryConditioningMassCore>
          core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::StationaryConditioningMassCore>
      core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
  friend class testing::C19ThreeBinFixtureAccess;
#endif
};

struct ThreeBinStationaryAtomV1 final {
  StationaryConditioningRegionV1 region;
  ExactRational response;
  StationaryConditioningMassStatus conditioning_mass;
};

enum class TailSlackApplicabilityV1 : std::uint8_t {
  applicable,
  not_applicable_off_class,
  stationary_law_not_established,
};

enum class MeanSojournCountingConventionV1 : std::uint8_t {
  includes_departure_slot,
};

class ThreeBinIidSummary final {
 public:
  ThreeBinIidSummary() = delete;
  ThreeBinIidSummary(const ThreeBinIidSummary&) = default;
  ThreeBinIidSummary(ThreeBinIidSummary&&) noexcept = default;
  ThreeBinIidSummary& operator=(const ThreeBinIidSummary&) = default;
  ThreeBinIidSummary& operator=(ThreeBinIidSummary&&) noexcept = default;

  [[nodiscard]] std::span<const ThreeBinStationaryAtomV1, 4> bins()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& pi_zero() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& pi_one() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& pi_two() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& tail_mass_from_three()
      const noexcept;
  [[nodiscard]] const ExactRational& mu_zero() const noexcept;
  [[nodiscard]] const ExactRational& mu_one() const noexcept;
  [[nodiscard]] const ExactRational& mu_two() const noexcept;
  [[nodiscard]] const ExactRational& mu_tail_from_three() const noexcept;
  [[nodiscard]] const ExactRational& arrival_mean() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_mean_backlog()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& numerical_mean_backlog()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_mean_sojourn()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& numerical_mean_sojourn()
      const noexcept;
  [[nodiscard]] MeanSojournCountingConventionV1 sojourn_counting_convention()
      const noexcept;
  [[nodiscard]] TailSlackApplicabilityV1 tail_slack_applicability()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& tail_slack()
      const noexcept;
  [[nodiscard]] AnalyticStationaryStatusV1 status() const noexcept;
  [[nodiscard]] const AnalyticStationaryDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& law_identity()
      const noexcept;

 private:
  explicit ThreeBinIidSummary(
      std::shared_ptr<const stationary::detail::ThreeBinIidSummaryCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::ThreeBinIidSummaryCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
  friend class testing::C19ThreeBinFixtureAccess;
#endif
};

[[nodiscard]] Result<ThreeBinIidSummary> summarize_three_bin_iid_response(
    const AuditedThreeBinResponse& response, const ArrivalLaw& arrival);

// Solver-owned stationary-unique route.  Unlike ArrivalLaw::from_audited,
// this entry point does not consume an initial-class mapper or treat its
// uniqueness authority as theorem evidence.  It is available only for an
// audited stationary_unique ThreeBin/IID analysis and returns success only
// when C19 itself establishes a normalized unique invariant law.
[[nodiscard]] Result<ThreeBinIidSummary>
summarize_three_bin_iid_stationary_unique(
    const AuditedThreeBinResponse& response);

#if defined(MWPERF_C19_TEST_SEAMS)
namespace testing {

struct ExactLittleLawPremisesFixtureV1 final {
  bool lossless;
  bool unit_packets;
  bool eventual_departure;
  bool positive_finite_intensity;
  bool finite_first_backlog_moment;
  bool little_law;
};

class C19ThreeBinFixtureAccess final {
 public:
  [[nodiscard]] static Result<ThreeBinIidSummary> summarize(
      const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response,
      ExactLittleLawPremisesFixtureV1 little_law);
};

}  // namespace testing
#endif

}  // namespace mwperf
