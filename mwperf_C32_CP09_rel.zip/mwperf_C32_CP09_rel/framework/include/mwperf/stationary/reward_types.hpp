#pragma once

#include <cstdint>
#include <functional>
#include <memory>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/kernel/stage_context.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct ConditionalSamplingRewardV1;
struct MarkedFluxEdgeV1;

// Shared reward vocabulary. Keeping these definitions independent of the
// stationary backend lets sampling contracts retain their source-compatible
// RewardDecoder surface without importing C18's diagnostic types.
enum class StationaryRewardDomainV1 : std::uint8_t {
  state,
  one_edge,
};

enum class StationaryRewardIntegrabilityV1 : std::uint8_t {
  finite_absolute,
  nonnegative_extended_real,
};

struct StationaryRewardArgumentV1 final {
  const ReducedStateV1& state;
  const MarkedFluxEdgeV1* edge;
};

using DecodeStationaryRewardV1 =
    std::function<Result<long double>(const StationaryRewardArgumentV1&)>;

struct RequiredStationaryMarkV1 final {
  RuntimeMarkIdV1 mark;
  CodecIdentityV1 value_codec;
  CausalStageV1 latest_reveal_stage;
};

struct RewardDecoder final {
  StationaryRewardDomainV1 domain;
  StationaryRewardIntegrabilityV1 integrability;
  bool requires_temporal_continuation;
  std::vector<RequiredStationaryMarkV1> required_marks;
  DecodeStationaryRewardV1 decode;
  CodecIdentityV1 result_codec;
  // Empty for all C18--C23 stationary decoders. C24 requires this separately
  // bound row-conditional branch and never reinterprets the stationary edge
  // callback as a residual-sample decoder.
  std::shared_ptr<const ConditionalSamplingRewardV1> conditional_sampling{};
};

}  // namespace mwperf
