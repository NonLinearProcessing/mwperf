#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/marked_kernel_row.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/result.hpp"
#include "mwperf/stationary/reward_types.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"

namespace mwperf {

class ClassDecomposition;
class InvariantLaw;
class InvariantSelection;
class SolverPolicy;
class TransitionMatrix;
struct DiagnosticBundle;

namespace detail {
class C18CoreAccess;
}

namespace stationary::detail {
struct EndpointRowCore;
struct CompletionBoundMarkedFluxCore;
struct TransitionMatrixCore;
struct ClassDecompositionCore;
struct InvariantSelectionCore;
struct InvariantLawCore;
}

#if defined(MWPERF_C18_TEST_SEAMS)
namespace testing {
class C18FixtureAccess;
}
#endif

// The numerical solver policy accepted from Analysis-v1.  Version 1 has no
// authored relative residual field, hence relative_residual_tolerance must be
// exactly zero.  analysis_fingerprint keeps an otherwise equal policy from a
// foreign request from entering a solve.
struct SolverPolicy final {
  LinearMethod linear_method;
  std::optional<BigNat> max_iterations;
  ExactRational absolute_residual_tolerance;
  ExactRational relative_residual_tolerance;
  Digest256 analysis_fingerprint;

  friend bool operator==(const SolverPolicy&, const SolverPolicy&) = default;
};

// An input enumeration.  F-C18-02 validates and indexes these exact runtime
// values in canonical byte order; input order carries no mathematical role.
struct StateDomain final {
  std::vector<ReducedStateV1> states;
};

struct ArrivalPhaseIdentityV1 final {
  ArrivalFamily family;
  std::vector<std::byte> canonical_state;

  friend bool operator==(const ArrivalPhaseIdentityV1&,
                         const ArrivalPhaseIdentityV1&) = default;
};

// The completion-bound one-edge datum used in SF.4/SF.10.  Queue vectors are
// in the accepted target order.  The endpoint is still carried explicitly so
// F-C18-02 can compare the exact n-d+a/phase reconstruction with it.
struct MarkedFluxEdgeV1 final {
  ReducedStateV1 pre_state;
  ReducedStateV1 successor_state;
  std::vector<BigNat> prearrival_target_backlog;
  std::vector<std::uint8_t> target_departures;
  std::vector<BigNat> target_arrivals;
  ArrivalPhaseIdentityV1 phase_before;
  ArrivalPhaseIdentityV1 phase_after;
  std::vector<CausalMarkV1> marks;

  friend bool operator==(const MarkedFluxEdgeV1&,
                         const MarkedFluxEdgeV1&) = default;
};

struct MarkedFluxAtomV1 final {
  MarkedFluxEdgeV1 edge;
  ExactRational exact_mass;
  bool structural_support;
  long double numerical_image;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

struct EndpointRowAtomV1 final {
  ReducedStateV1 successor_state;
  ExactRational exact_mass;
  bool exact_positive_support;
  long double numerical_image;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

class EndpointRow final {
 public:
  EndpointRow() = delete;
  EndpointRow(const EndpointRow&) = default;
  EndpointRow(EndpointRow&&) noexcept = default;
  EndpointRow& operator=(const EndpointRow&) = default;
  EndpointRow& operator=(EndpointRow&&) noexcept = default;

  [[nodiscard]] std::span<const EndpointRowAtomV1> atoms() const noexcept;
  [[nodiscard]] std::span<const MarkedFluxAtomV1> marked_atoms() const
      noexcept;
  [[nodiscard]] const ExactRational& exact_total_mass() const noexcept;
  [[nodiscard]] long double numerical_total_mass() const noexcept;
  [[nodiscard]] long double numerical_residual_from_one() const noexcept;

 private:
  explicit EndpointRow(
      std::shared_ptr<const stationary::detail::EndpointRowCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::EndpointRowCore> core_;
  friend class detail::C18CoreAccess;
#if defined(MWPERF_C18_TEST_SEAMS)
  friend class testing::C18FixtureAccess;
#endif
};

enum class BoundaryCompletionKindV1 : std::uint8_t {
  exact_closed,
  marked_completion,
  state_only_completion,
};

// Each returned weight is conditional on the one leaking source atom.  The
// weights must be nonnegative and total exactly one; C18 never normalizes
// them.  marked_completion requires transformed_edge on every positive
// image, while state_only_completion forbids it.
struct BoundaryCompletionAtomV1 final {
  ReducedStateV1 successor_state;
  ExactRational conditional_mass;
  std::optional<MarkedFluxEdgeV1> transformed_edge;
};

using ApplyBoundaryCompletionV1 = std::function<
    Result<std::vector<BoundaryCompletionAtomV1>>(
        const MarkedFluxAtomV1& leaking_atom)>;

struct BoundaryRule final {
  BoundaryCompletionKindV1 kind;
  std::optional<Digest256> completion_identity;
  bool physical_mark_preserving;
  ApplyBoundaryCompletionV1 apply;
};

struct CompletionBoundMarkedAtomV1 final {
  std::size_t successor_index;
  ExactRational exact_mass;
  long double numerical_image;
  bool completed_from_leakage;
  std::optional<MarkedFluxEdgeV1> edge;
};

struct CompletionBoundMarkedRowV1 final {
  std::vector<CompletionBoundMarkedAtomV1> atoms;
};

struct LeakageRecordV1 final {
  std::size_t source_index;
  ReducedStateV1 original_successor;
  ExactRational exact_mass;
  std::optional<MarkedFluxEdgeV1> original_edge{};
};

class CompletionBoundMarkedFlux final {
 public:
  CompletionBoundMarkedFlux() = delete;
  CompletionBoundMarkedFlux(const CompletionBoundMarkedFlux&) = default;
  CompletionBoundMarkedFlux(CompletionBoundMarkedFlux&&) noexcept = default;
  CompletionBoundMarkedFlux& operator=(const CompletionBoundMarkedFlux&) =
      default;
  CompletionBoundMarkedFlux& operator=(CompletionBoundMarkedFlux&&) noexcept =
      default;

  [[nodiscard]] BoundaryCompletionKindV1 completion_kind() const noexcept;
  [[nodiscard]] const std::optional<Digest256>& completion_identity() const
      noexcept;
  [[nodiscard]] bool physical_mark_preserving() const noexcept;
  [[nodiscard]] std::span<const CompletionBoundMarkedRowV1> rows() const
      noexcept;
  [[nodiscard]] std::span<const LeakageRecordV1> leakage() const noexcept;
  [[nodiscard]] const ExactRational& exact_completed_mass() const noexcept;

 private:
  explicit CompletionBoundMarkedFlux(
      std::shared_ptr<const
          stationary::detail::CompletionBoundMarkedFluxCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::CompletionBoundMarkedFluxCore>
      core_;
  friend class detail::C18CoreAccess;
#if defined(MWPERF_C18_TEST_SEAMS)
  friend class testing::C18FixtureAccess;
#endif
};

struct MatrixRowDiagnosticV1 final {
  std::size_t state_index;
  ExactRational exact_total_mass;
  long double numerical_total_mass;
  long double numerical_residual_from_one;
  long double residual_bound;
};

class TransitionMatrix final {
 public:
  TransitionMatrix() = delete;
  TransitionMatrix(const TransitionMatrix&) = default;
  TransitionMatrix(TransitionMatrix&&) noexcept = default;
  TransitionMatrix& operator=(const TransitionMatrix&) = default;
  TransitionMatrix& operator=(TransitionMatrix&&) noexcept = default;

  [[nodiscard]] std::size_t size() const noexcept;
  [[nodiscard]] std::span<const ReducedStateV1> states() const noexcept;
  [[nodiscard]] const ExactRational& exact_entry(std::size_t row,
                                                  std::size_t column) const;
  [[nodiscard]] long double numerical_entry(std::size_t row,
                                             std::size_t column) const;
  [[nodiscard]] bool exact_positive_support(std::size_t row,
                                             std::size_t column) const;
  [[nodiscard]] std::size_t nonzero_count() const noexcept;
  [[nodiscard]] std::span<const MatrixRowDiagnosticV1> row_diagnostics() const
      noexcept;
  [[nodiscard]] const CompletionBoundMarkedFlux& marked_flux() const noexcept;
  [[nodiscard]] const Digest256& matrix_identity() const noexcept;
  [[nodiscard]] const SolverPolicy& bound_solver_policy() const noexcept;

 private:
  explicit TransitionMatrix(
      std::shared_ptr<const stationary::detail::TransitionMatrixCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::TransitionMatrixCore> core_;
  friend class detail::C18CoreAccess;
#if defined(MWPERF_C18_TEST_SEAMS)
  friend class testing::C18FixtureAccess;
#endif
};

struct CommunicatingClassV1 final {
  TypedLabel class_id;
  std::vector<std::size_t> member_indices;
  std::vector<TypedLabel> outgoing_class_ids;
  bool closed;
};

class ClassDecomposition final {
 public:
  ClassDecomposition() = delete;
  ClassDecomposition(const ClassDecomposition&) = default;
  ClassDecomposition(ClassDecomposition&&) noexcept = default;
  ClassDecomposition& operator=(const ClassDecomposition&) = default;
  ClassDecomposition& operator=(ClassDecomposition&&) noexcept = default;

  [[nodiscard]] std::span<const CommunicatingClassV1> classes() const noexcept;
  [[nodiscard]] std::span<const std::size_t> closed_class_indices() const
      noexcept;
  [[nodiscard]] std::span<const std::size_t> transient_state_indices() const
      noexcept;
  [[nodiscard]] const Digest256& matrix_identity() const noexcept;

 private:
  explicit ClassDecomposition(
      std::shared_ptr<const stationary::detail::ClassDecompositionCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::ClassDecompositionCore> core_;
  friend class detail::C18CoreAccess;
};

struct SelectedInvariantClassV1 final {
  TypedLabel class_id;
  std::size_t class_index;
  ExactRational exact_weight;
  long double numerical_weight;
};

class InvariantSelection final {
 public:
  InvariantSelection() = delete;
  InvariantSelection(const InvariantSelection&) = default;
  InvariantSelection(InvariantSelection&&) noexcept = default;
  InvariantSelection& operator=(const InvariantSelection&) = default;
  InvariantSelection& operator=(InvariantSelection&&) noexcept = default;

  [[nodiscard]] std::span<const SelectedInvariantClassV1> selected_classes()
      const noexcept;
  [[nodiscard]] const Digest256& matrix_identity() const noexcept;
  [[nodiscard]] const Digest256& selector_digest() const noexcept;

 private:
  explicit InvariantSelection(
      std::shared_ptr<const stationary::detail::InvariantSelectionCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::InvariantSelectionCore> core_;
  friend class detail::C18CoreAccess;
};

enum class StationaryLinearSolveStatusV1 : std::uint8_t {
  solved,
  numerically_unresolved,
};

struct ClassSolveDiagnosticV1 final {
  TypedLabel class_id;
  std::size_t dimension;
  std::size_t rank;
  long double rank_threshold_eta;
  long double reciprocal_condition_estimate;
  long double condition_warning_threshold;
  bool condition_warning;
  long double normalization_residual;
  long double normalization_bound;
  long double l1_invariance_residual;
  long double l1_invariance_bound;
  long double maximum_invariance_residual;
  long double maximum_invariance_bound;
  bool finite_nonnegative;
  StationaryLinearSolveStatusV1 status;
};

struct InvariantSolveDiagnosticsV1 final {
  LinearMethod method;
  ExactRational absolute_residual_tolerance;
  ExactRational relative_residual_tolerance;
  std::vector<SelectedInvariantClassV1> selected_classes;
  std::vector<ClassSolveDiagnosticV1> class_solves;
  long double normalization_residual;
  long double normalization_bound;
  long double l1_invariance_residual;
  long double l1_invariance_bound;
  long double maximum_invariance_residual;
  long double maximum_invariance_bound;
};

class InvariantLaw final {
 public:
  InvariantLaw() = delete;
  InvariantLaw(const InvariantLaw&) = default;
  InvariantLaw(InvariantLaw&&) noexcept = default;
  InvariantLaw& operator=(const InvariantLaw&) = default;
  InvariantLaw& operator=(InvariantLaw&&) noexcept = default;

  [[nodiscard]] std::span<const long double> masses() const noexcept;
  [[nodiscard]] std::span<const SelectedInvariantClassV1> selected_classes()
      const noexcept;
  [[nodiscard]] const InvariantSolveDiagnosticsV1& solve_diagnostics() const
      noexcept;
  [[nodiscard]] const TransitionMatrix& transition_matrix() const noexcept;
  [[nodiscard]] const CompletionBoundMarkedFlux& marked_flux() const noexcept;
  [[nodiscard]] const Digest256& matrix_identity() const noexcept;

 private:
  explicit InvariantLaw(
      std::shared_ptr<const stationary::detail::InvariantLawCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::InvariantLawCore> core_;
  friend class detail::C18CoreAccess;
};

struct PhaseMarginalAtomV1 final {
  ArrivalPhaseIdentityV1 phase;
  long double invariant_mass;
  long double configured_mass;
  long double residual;
  long double residual_bound;
};

struct DiagnosticBundle final {
  bool instance_binding_matches{false};
  bool fatal{false};
  bool publication_allowed{false};
  std::size_t state_count{0U};
  std::size_t nonzero_count{0U};
  std::size_t class_count{0U};
  std::size_t closed_class_count{0U};
  BoundaryCompletionKindV1 completion_kind{
      BoundaryCompletionKindV1::exact_closed};
  bool completion_mark_scope_available{false};
  bool mark_to_endpoint_consistent{false};
  long double completed_mass{0.0L};
  std::optional<ExactRational> exact_completed_mass;
  std::vector<MatrixRowDiagnosticV1> row_diagnostics;
  std::vector<CommunicatingClassV1> classes;
  std::vector<LeakageRecordV1> leakage;
  InvariantSolveDiagnosticsV1 invariant;
  bool arrival_phase_marginal_available{false};
  bool arrival_phase_marginal_matches{false};
  std::vector<PhaseMarginalAtomV1> arrival_phase_marginal;
  std::optional<long double> expected_departures;
  std::optional<long double> expected_arrivals;
  std::optional<long double> flow_difference;
  std::vector<std::optional<long double>> expected_target_departures;
  std::vector<std::optional<long double>> expected_target_arrivals;
  std::vector<std::optional<long double>> target_flow_differences;
  std::vector<Diagnostic> findings;
};

// F-C18-01
[[nodiscard]] Result<EndpointRow> project_marked_row_to_endpoint(
    const MarkedKernelRow& row);

// F-C18-02
[[nodiscard]] Result<TransitionMatrix> assemble_finite_transition_matrix(
    const StateDomain& domain, const AuditedRowProvider& provider,
    const BoundaryRule& boundary);

// F-C18-03
[[nodiscard]] ClassDecomposition analyze_communicating_classes(
    const TransitionMatrix& matrix);

// F-C18-04
[[nodiscard]] Result<InvariantSelection> select_invariant_class(
    const ClassDecomposition& decomposition, const SelectionSpec& selection);

// F-C18-05
[[nodiscard]] Result<InvariantLaw> solve_invariant_distribution(
    const TransitionMatrix& matrix, const InvariantSelection& selection,
    const SolverPolicy& policy);

// F-C18-06
[[nodiscard]] Result<MetricValue> evaluate_stationary_edge_reward(
    const InvariantLaw& law, const RewardDecoder& decoder);

// F-C18-07
[[nodiscard]] DiagnosticBundle compute_stationary_flux_diagnostics(
    const InvariantLaw& law, const ResolvedInstance& instance);

#if defined(MWPERF_C18_TEST_SEAMS)

// A direct rational equation fixture.  It exists only in the C18 test graph;
// it imports no future oracle type and does not add a production constructor.
struct C18ExactMatrixFixtureV1 final {
  std::vector<ReducedStateV1> states;
  // Dense row-major, exactly states.size() squared.
  std::vector<ExactRational> exact_entries;
  SelectionSpec bound_selection;
  SolverPolicy bound_solver_policy;
  // Optional independent images exercise the specified numerical-drift
  // checks while exact_entries remain the support and mass authority.
  std::optional<std::vector<long double>> numerical_entries;
  std::vector<CompletionBoundMarkedRowV1> marked_rows;
  BoundaryCompletionKindV1 completion_kind{
      BoundaryCompletionKindV1::exact_closed};
  std::optional<Digest256> completion_identity;
  bool physical_mark_preserving{true};
  // A bound fixture supplies instance and targets together, plus exactly one
  // phase-transition authority: CompiledArrivalLaw or the exact K_A below.
  std::optional<ResolvedInstance> bound_instance;
  std::optional<CompiledArrivalLaw> bound_configured_arrival;
  std::optional<TargetSelection> bound_target_selection;
  std::optional<Digest256> exact_state_schema_digest;
  std::optional<Digest256> reduced_state_schema_digest;
  std::vector<ArrivalPhaseIdentityV1> configured_phase_states;
  std::vector<ExactRational> configured_phase_masses;
  // Optional dense row-major K_A over configured_phase_states.  This is the
  // exact SF.6 authority when a direct fixture has no CompiledArrivalLaw.
  std::optional<std::vector<ExactRational>> configured_phase_kernel;
  std::vector<ArrivalPhaseIdentityV1> state_phases;
};

namespace testing {

class C18FixtureAccess final {
 public:
  C18FixtureAccess() = delete;

  [[nodiscard]] static Result<TransitionMatrix> transition_matrix(
      C18ExactMatrixFixtureV1 fixture);
  [[nodiscard]] static Result<long double> decode_metric_scalar(
      const MetricValue& value);
};

}  // namespace testing
#endif

}  // namespace mwperf
