#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/temporal_contract.hpp"
#include "mwperf/stationary/flux.hpp"
#include "mwperf/temporal/romr.hpp"

namespace mwperf {

class EventInvariantLaw;
class PositiveFiniteMean;
class StationaryTemporalLaw;
class StationaryMarkedEdge;
class PredictiveServiceSplit;
class TemporalServiceKernel;
class StationaryTemporalProjection;

namespace detail {
class C20CoreAccess;
class C21CoreAccess;
class C23CoreAccess;
}

namespace stationary::detail {
struct EventInvariantLawCore;
struct PositiveFiniteMeanCore;
struct StationaryTemporalLawCore;
struct StationaryMarkedEdgeCore;
struct PredictiveServiceSplitCore;
struct TemporalServiceKernelCore;
struct StationaryTemporalProjectionCore;
// The common immutable source retained privately by every C21-minted
// restriction.  It is intentionally incomplete in the installed API.
struct StationaryProjectionSourceCore;
}  // namespace stationary::detail

#if defined(MWPERF_C21_TEST_SEAMS)
namespace testing {
class C21FixtureAccess;
}
#endif

// The event-state masses are retained exactly as well as in the numerical
// representation used by the pivoted solve.  Structural support is decided
// from the exact mass; a small positive atom is never thresholded away.
struct EventInvariantMassV1 final {
  std::size_t state_index;
  ExactRational exact_mass;
  long double numerical_mass;
  NumericalProbabilityImageStatusV1 numerical_image_status;

  friend bool operator==(const EventInvariantMassV1&,
                         const EventInvariantMassV1&) = default;
};

struct EventInvariantDiagnosticsV1 final {
  std::vector<CommunicatingClassV1> classes;
  std::vector<std::size_t> closed_class_indices;
  std::vector<std::size_t> transient_state_indices;
  InvariantSolveDiagnosticsV1 solve;
  ExactRational exact_normalization_residual;
  std::vector<ExactRational> exact_invariance_residuals;
  bool exact_nonnegative;
  bool exact_normalized;
  bool exact_invariant;
};

// The selected event-epoch invariant probability.  It names the precise C20
// kernel and provider provenance internally; it is not an ordinary-slot law.
class EventInvariantLaw final {
 public:
  EventInvariantLaw() = delete;
  EventInvariantLaw(const EventInvariantLaw&) = default;
  EventInvariantLaw(EventInvariantLaw&&) noexcept = default;
  EventInvariantLaw& operator=(const EventInvariantLaw&) = default;
  EventInvariantLaw& operator=(EventInvariantLaw&&) noexcept = default;

  [[nodiscard]] const EmbeddedKernel& embedded_kernel() const noexcept;
  [[nodiscard]] const FiniteEventStateDomain& domain() const noexcept;
  [[nodiscard]] std::span<const EventInvariantMassV1> masses() const noexcept;
  [[nodiscard]] std::span<const SelectedInvariantClassV1> selected_classes()
      const noexcept;
  [[nodiscard]] const EventInvariantDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;

 private:
  explicit EventInvariantLaw(
      std::shared_ptr<const stationary::detail::EventInvariantLawCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::EventInvariantLawCore> core_;
  friend class detail::C21CoreAccess;
};

enum class ResidenceExpectationMethodV1 : std::uint8_t {
  finite_exact_enumeration,
  analytic_certified_expectation,
  certified_tail_summation,
};

enum class ResidenceRangeStatusV1 : std::uint8_t {
  finite_native_range,
  finite_promoted_range,
  overflow,
  numerically_unresolved,
};

// Exact fields describe the evaluated part and certified enclosure.  For a
// completely enumerated finite law, exact_value is present and all tail
// bounds are exactly zero.  The remaining method/enclosure vocabulary is
// reserved for a future C20 provider that can carry analytic expectations or
// certified infinite-support tails.  The inherited C20 v1 route exposes only
// finite exact complete-word rows, so C21 cannot mint a denominator from
// those reserved diagnostics or from test evidence alone.
struct PositiveFiniteMeanDiagnosticsV1 final {
  ResidenceExpectationMethodV1 method;
  std::optional<ExactRational> exact_value;
  ExactRational exact_evaluated_sum;
  ExactRational exact_lower_bound;
  ExactRational exact_upper_bound;
  ExactRational exact_tail_lower_bound;
  ExactRational exact_tail_upper_bound;
  long double numerical_value;
  long double numerical_correction;
  long double numerical_lower_bound;
  long double numerical_upper_bound;
  long double numerical_condition_estimate;
  ResidenceRangeStatusV1 range_status;
  std::size_t event_states_visited;
  std::size_t words_visited;
  std::size_t offsets_certified;
  bool support_complete;
  bool tail_certified;
};

// A proof-carrying positive finite residence denominator.  Its constructor is
// private so neither a sample maximum nor a truncated partial sum can be
// promoted to a stationary suspension denominator.
class PositiveFiniteMean final {
 public:
  PositiveFiniteMean() = delete;
  PositiveFiniteMean(const PositiveFiniteMean&) = default;
  PositiveFiniteMean(PositiveFiniteMean&&) noexcept = default;
  PositiveFiniteMean& operator=(const PositiveFiniteMean&) = default;
  PositiveFiniteMean& operator=(PositiveFiniteMean&&) noexcept = default;

  [[nodiscard]] const std::optional<ExactRational>& exact_value()
      const noexcept;
  [[nodiscard]] long double numerical_value() const noexcept;
  [[nodiscard]] const ExactRational& exact_lower_bound() const noexcept;
  [[nodiscard]] const ExactRational& exact_upper_bound() const noexcept;
  [[nodiscard]] const PositiveFiniteMeanDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const Digest256& event_law_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& provider_fingerprint() const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;

 private:
  explicit PositiveFiniteMean(
      std::shared_ptr<const stationary::detail::PositiveFiniteMeanCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::PositiveFiniteMeanCore> core_;
  friend class detail::C21CoreAccess;
};

struct StationaryPhaseOccupationAtomV1 final {
  ArrivalPhaseIdentityV1 phase;
  ExactRational exact_slot_mass;
  long double numerical_slot_mass;
  std::optional<ExactRational> configured_exact_mass;
  std::optional<long double> configured_numerical_mass;
  long double numerical_residual;
  long double residual_bound;

  friend bool operator==(const StationaryPhaseOccupationAtomV1&,
                         const StationaryPhaseOccupationAtomV1&) = default;
};

struct StationaryTemporalDiagnosticsV1 final {
  ExactRational exact_total_mass;
  long double numerical_total_mass;
  long double numerical_mass_correction;
  long double numerical_mass_residual;
  std::vector<StationaryPhaseOccupationAtomV1> phase_occupation;
  bool configured_phase_identity_available;
  bool configured_phase_identity_matches;
  bool cross_residence_continuation_retained;
  bool signed_absolute_integrability_available;
};

// The latent (Y,W,J) suspension and every cross-residence continuation are
// intentionally private.  In particular this type exposes no word, suffix,
// slot executor, or conditional-row callback to a controller.
class StationaryTemporalLaw final {
 public:
  StationaryTemporalLaw() = delete;
  StationaryTemporalLaw(const StationaryTemporalLaw&) = default;
  StationaryTemporalLaw(StationaryTemporalLaw&&) noexcept = default;
  StationaryTemporalLaw& operator=(const StationaryTemporalLaw&) = default;
  StationaryTemporalLaw& operator=(StationaryTemporalLaw&&) noexcept =
      default;

  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;
  [[nodiscard]] const StationaryTemporalDiagnosticsV1& diagnostics()
      const noexcept;

 private:
  explicit StationaryTemporalLaw(
      std::shared_ptr<const stationary::detail::StationaryTemporalLawCore>
          core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::StationaryTemporalLawCore> core_;
  friend class detail::C21CoreAccess;
  friend class detail::C23CoreAccess;
#if defined(MWPERF_C21_TEST_SEAMS)
  friend class testing::C21FixtureAccess;
#endif
};

// The stationary left/right states are the exact audited observable images.
// On a permitted time-homogeneous quotient route they omit only the absolute
// physical clock.  raw_edge retains that clock and all C17 marks/provenance;
// it is never the key used for stationary marginal coalescing.
struct StationaryMarkedEdgeAtomV1 final {
  ReducedStateV1 stationary_left_state;
  CompletedReducedEdge raw_edge;
  ReducedStateV1 stationary_right_state;
  ExactRational exact_mass;
  long double numerical_mass;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

struct StationaryStateMassV1 final {
  ReducedStateV1 state;
  ExactRational exact_mass;
  long double numerical_mass;
  NumericalProbabilityImageStatusV1 numerical_image_status;

  friend bool operator==(const StationaryStateMassV1&,
                         const StationaryStateMassV1&) = default;
};

struct StationaryConditionalMarkedAtomV1 final {
  std::size_t edge_atom_index;
  ExactRational exact_conditional_mass;
  long double numerical_conditional_mass;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

// Only positive-pi rows are represented.  Absence is the required meaning
// for a zero-mass state; there is no implicit self-loop or empty-row
// normalization.
struct StationaryConditionalMarkedRowV1 final {
  ReducedStateV1 stationary_left_state;
  ExactRational exact_left_mass;
  long double numerical_left_mass;
  std::vector<StationaryConditionalMarkedAtomV1> atoms;
  ExactRational exact_total_conditional_mass;
  long double numerical_total_conditional_mass;
};

struct StationaryEndpointAtomV1 final {
  ReducedStateV1 stationary_right_state;
  ExactRational exact_conditional_mass;
  long double numerical_conditional_mass;
  NumericalProbabilityImageStatusV1 numerical_image_status;
};

struct StationaryEndpointRowV1 final {
  ReducedStateV1 stationary_left_state;
  ExactRational exact_left_mass;
  long double numerical_left_mass;
  std::vector<StationaryEndpointAtomV1> atoms;
  ExactRational exact_total_conditional_mass;
  long double numerical_total_conditional_mass;
};

struct StationaryMarkedEdgeDiagnosticsV1 final {
  ExactRational exact_total_mass;
  long double numerical_total_mass;
  long double numerical_mass_correction;
  long double numerical_mass_residual;
  long double maximum_left_right_residual;
  long double maximum_endpoint_invariance_residual;
  bool exact_left_right_marginals_equal;
  bool exact_queue_updates_hold;
  bool exact_endpoint_invariance_holds;
  bool zero_mass_rows_left_undefined;
  std::optional<Digest256> explicit_completion_identity;
};

// The one-edge image remains distinct from StationaryTemporalLaw.  It has no
// operation that advances, powers, samples, or reconstructs temporal state.
class StationaryMarkedEdge final {
 public:
  StationaryMarkedEdge() = delete;
  StationaryMarkedEdge(const StationaryMarkedEdge&) = default;
  StationaryMarkedEdge(StationaryMarkedEdge&&) noexcept = default;
  StationaryMarkedEdge& operator=(const StationaryMarkedEdge&) = default;
  StationaryMarkedEdge& operator=(StationaryMarkedEdge&&) noexcept = default;

  [[nodiscard]] std::span<const StationaryMarkedEdgeAtomV1> atoms()
      const noexcept;
  [[nodiscard]] std::span<const StationaryStateMassV1> left_marginal()
      const noexcept;
  [[nodiscard]] std::span<const StationaryStateMassV1> right_marginal()
      const noexcept;
  [[nodiscard]] std::span<const StationaryConditionalMarkedRowV1>
  positive_conditional_rows() const noexcept;
  [[nodiscard]] std::span<const StationaryEndpointRowV1> endpoint_rows()
      const noexcept;
  [[nodiscard]] const StationaryMarkedEdgeDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;

 private:
  explicit StationaryMarkedEdge(
      std::shared_ptr<const stationary::detail::StationaryMarkedEdgeCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::StationaryMarkedEdgeCore> core_;
  friend class detail::C21CoreAccess;
  friend class detail::C23CoreAccess;
};

enum class StationaryProjectionUnavailableKindV1 : std::uint8_t {
  unrequested,
  capability_not_accepted,
  contract_unsupported,
  missing_mark,
  missing_temporal_continuation,
  integrability_not_established,
  executable_conditional_law_unavailable,
};

struct StationaryProjectionUnavailableV1 final {
  StationaryProjectionUnavailableKindV1 kind;
  std::string code;
  std::string message;

  friend bool operator==(const StationaryProjectionUnavailableV1&,
                         const StationaryProjectionUnavailableV1&) = default;
};

template <typename T>
using StationaryProjectionSlotV1 =
    std::variant<T, StationaryProjectionUnavailableV1>;

// The actual-departure split P=P0+P1 of the same predictive continuation.
class PredictiveServiceSplit final {
 public:
  PredictiveServiceSplit() = delete;
  PredictiveServiceSplit(const PredictiveServiceSplit&) = default;
  PredictiveServiceSplit(PredictiveServiceSplit&&) noexcept = default;
  PredictiveServiceSplit& operator=(const PredictiveServiceSplit&) = default;
  PredictiveServiceSplit& operator=(PredictiveServiceSplit&&) noexcept =
      default;

  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;

 private:
  explicit PredictiveServiceSplit(
      std::shared_ptr<const stationary::detail::PredictiveServiceSplitCore>
          core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::PredictiveServiceSplitCore> core_;
  friend class detail::C21CoreAccess;
  friend class detail::C23CoreAccess;
};

// Matching service-marked chronological continuation for passive FIFO use.
class TemporalServiceKernel final {
 public:
  TemporalServiceKernel() = delete;
  TemporalServiceKernel(const TemporalServiceKernel&) = default;
  TemporalServiceKernel(TemporalServiceKernel&&) noexcept = default;
  TemporalServiceKernel& operator=(const TemporalServiceKernel&) = default;
  TemporalServiceKernel& operator=(TemporalServiceKernel&&) noexcept =
      default;

  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept;

 private:
  explicit TemporalServiceKernel(
      std::shared_ptr<const stationary::detail::TemporalServiceKernelCore>
          core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::TemporalServiceKernelCore> core_;
  friend class detail::C21CoreAccess;
  friend class detail::C20CoreAccess;
  friend class detail::C23CoreAccess;
};

struct StationaryProjectionDiagnosticsV1 final {
  Digest256 event_law_fingerprint;
  Digest256 residence_provider_fingerprint;
  Digest256 denominator_fingerprint;
  ExactRational exact_length_biased_mass;
  long double numerical_length_biased_mass;
  bool three_way_identity_matches;
  bool phase_occupation_matches;
  bool edge_mass_is_one;
  bool edge_marginals_match;
  bool endpoint_is_invariant;
  bool constructed_in_one_residence_pass;
};

// One atomic, fingerprint-bound handoff.  The temporal law and marked edge
// are required and noninterchangeable.  Each remaining member is a closed
// typed availability slot; an unsupported optional member does not broaden
// another member and does not invalidate unrelated C21 rewards.
class StationaryTemporalProjection final {
 public:
  StationaryTemporalProjection() = delete;
  StationaryTemporalProjection(const StationaryTemporalProjection&) = default;
  StationaryTemporalProjection(StationaryTemporalProjection&&) noexcept =
      default;
  StationaryTemporalProjection& operator=(
      const StationaryTemporalProjection&) = default;
  StationaryTemporalProjection& operator=(
      StationaryTemporalProjection&&) noexcept = default;

  [[nodiscard]] const StationaryTemporalLaw& temporal_law() const noexcept;
  [[nodiscard]] const StationaryMarkedEdge& marked_edge() const noexcept;
  [[nodiscard]] const StationaryProjectionSlotV1<AuditedCylinderLaw>&
  cylinder_law() const noexcept;
  [[nodiscard]] const StationaryProjectionSlotV1<AuditedTemporalLaw>&
  audited_temporal_law() const noexcept;
  [[nodiscard]] const StationaryProjectionSlotV1<AuditedTemporalKernel>&
  temporal_kernel() const noexcept;
  [[nodiscard]] const StationaryProjectionSlotV1<InitialLaw>& initial_law()
      const noexcept;
  [[nodiscard]] const StationaryProjectionSlotV1<PredictiveServiceSplit>&
  predictive_service_split() const noexcept;
  [[nodiscard]] const StationaryProjectionSlotV1<TemporalServiceKernel>&
  temporal_service_kernel() const noexcept;
  [[nodiscard]] const Digest256& fingerprint() const noexcept;
  [[nodiscard]] const StationaryProjectionDiagnosticsV1& diagnostics()
      const noexcept;

 private:
  explicit StationaryTemporalProjection(
      std::shared_ptr<const
                      stationary::detail::StationaryTemporalProjectionCore>
          core)
      : core_(std::move(core)) {}

  std::shared_ptr<const stationary::detail::StationaryTemporalProjectionCore>
      core_;
  friend class detail::C21CoreAccess;
};

// F-C21-01
[[nodiscard]] Result<EventInvariantLaw> select_event_invariant_law(
    const EmbeddedKernel& kernel, const SelectionSpec& selection,
    const SolverPolicy& policy);

// F-C21-02
[[nodiscard]] Result<PositiveFiniteMean> compute_mean_residence(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider);

// F-C21-03
[[nodiscard]] Result<MetricValue> suspend_event_law_to_slots(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean, const RewardDecoder& decoder);

// F-C21-04
[[nodiscard]] Result<StationaryTemporalProjection>
build_stationary_temporal_projection(
    const EventInvariantLaw& law,
    const AuditedResidenceProvider& provider,
    const PositiveFiniteMean& mean);

// F-C21-05
[[nodiscard]] Result<MetricValue> evaluate_stationary_temporal_metric(
    const StationaryTemporalLaw& law, const MetricRequest& request);

#if defined(MWPERF_C21_TEST_SEAMS)
namespace testing {

// Inspection copies exist only in the checkpoint-local test graph.  They do
// not expose a production constructor or an executable continuation.
struct StationaryTemporalAtomInspectionV1 final {
  std::size_t event_state_index;
  std::size_t word_index;
  BigNat residence_offset;
  ReducedStateV1 stationary_left_state;
  CompletedReducedEdge raw_edge;
  ReducedStateV1 stationary_right_state;
  ExactRational exact_mass;
  long double numerical_mass;
};

struct StationaryMetricEnvelopeInspectionV1 final {
  Digest256 source_fingerprint;
  std::optional<ExactRational> exact_numerator;
  ExactRational exact_denominator;
  std::optional<ExactRational> exact_ratio;
  long double numerical_numerator;
  long double numerical_denominator;
  long double numerical_ratio;
  long double absolute_numerator_sum;
  long double ratio_residual_bound;
  bool positive_infinity;
};

// Closed test-only decoders for the versioned F-C21-05 distributional
// result codecs.  Production callers continue to receive only MetricValue;
// these records do not expose the latent suspension or any continuation.
struct StationaryBacklogPmfAtomInspectionV1 final {
  BigNat level;
  ExactRational exact_mass;
};

struct StationaryBacklogPmfInspectionV1 final {
  Digest256 source_fingerprint;
  bool complete_domain;
  std::optional<BigNat> max_level;
  std::vector<StationaryBacklogPmfAtomInspectionV1> atoms;
  ExactRational exact_returned_mass;
  ExactRational exact_omitted_tail_mass;
};

struct StationaryBacklogPgfAtomInspectionV1 final {
  ExactRational point;
  ExactRational exact_value;
};

struct StationaryBacklogPgfInspectionV1 final {
  Digest256 source_fingerprint;
  std::vector<StationaryBacklogPgfAtomInspectionV1> atoms;
};

struct StationaryBacklogQuantileInspectionV1 final {
  Digest256 source_fingerprint;
  ExactRational probability;
  DiscreteQuantileConventionV1 convention;
  BigNat quantile;
  ExactRational exact_cdf_below;
  ExactRational exact_cdf_at_quantile;
};

// Declarative one-edge fixture input.  It contains only the already decoded
// C18-compatible mathematical edge and exact mass; it grants no callback,
// carrier, conditional-row operation, or stationary-object constructor.
struct C21MarkedEdgeFixtureAtomV1 final {
  MarkedFluxEdgeV1 edge;
  ExactRational exact_mass;
};

struct C21MarkedEdgeCoalescingInspectionV1 final {
  std::size_t retained_marked_atom_count;
  std::size_t endpoint_pushforward_atom_count;
  ExactRational exact_total_mass;
  ExactRational exact_departure_mass;
  ExactRational exact_arrival_mass;
  bool exact_queue_updates_hold;
  bool exact_left_right_marginals_equal;
  bool exact_endpoint_invariance_holds;
};

enum class C21MeanEvidenceKindV1 : std::uint8_t {
  finite_exact,
  certified_finite_enclosure,
  positive_infinity,
  uncertified_tail,
  arithmetic_overflow,
};

// Declarative evidence-validator fixture.  It cannot mint a denominator or
// acquire provider authority; it only exercises the same acceptance predicate
// used before PositiveFiniteMean construction.
struct C21MeanEvidenceFixtureV1 final {
  C21MeanEvidenceKindV1 kind;
  ExactRational evaluated_sum;
  ExactRational lower_bound;
  std::optional<ExactRational> upper_bound;
  ExactRational tail_lower;
  std::optional<ExactRational> tail_upper;
  bool support_complete;
  bool tail_certified;
};

class C21FixtureAccess final {
 public:
  C21FixtureAccess() = delete;

  [[nodiscard]] static std::vector<StationaryTemporalAtomInspectionV1>
  temporal_atoms(const StationaryTemporalLaw& law);
  [[nodiscard]] static Result<StationaryMetricEnvelopeInspectionV1>
  decode_metric_envelope(const MetricValue& value);
  [[nodiscard]] static Result<StationaryBacklogPmfInspectionV1>
  decode_stationary_backlog_pmf(const MetricValue& value);
  [[nodiscard]] static Result<StationaryBacklogPgfInspectionV1>
  decode_stationary_backlog_pgf(const MetricValue& value);
  [[nodiscard]] static Result<StationaryBacklogQuantileInspectionV1>
  decode_stationary_backlog_quantile(const MetricValue& value);
  [[nodiscard]] static Result<C21MarkedEdgeCoalescingInspectionV1>
  inspect_marked_edge_coalescing(
      std::vector<C21MarkedEdgeFixtureAtomV1> atoms);
  [[nodiscard]] static Result<PositiveFiniteMeanDiagnosticsV1>
  inspect_positive_finite_mean_evidence(C21MeanEvidenceFixtureV1 evidence);
  [[nodiscard]] static Result<void>
  inspect_missing_configured_phase_law_requirement();
};

}  // namespace testing
#endif

}  // namespace mwperf
