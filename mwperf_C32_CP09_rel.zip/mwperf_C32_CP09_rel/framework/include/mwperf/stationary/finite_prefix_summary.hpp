#pragma once

#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/stationary/three_bin_summary.hpp"

namespace mwperf {

namespace stationary::detail {
struct FinitePrefixIidSummaryCore;
}  // namespace stationary::detail

// The tail coefficient is deliberately typed and kept separate from the
// exact finite prefix: its service value applies first at tail_from=K+1.
struct FinitePrefixConstantTailCoefficientV1 final {
  BigNat tail_from;
  ExactRational service_probability;

  friend bool operator==(const FinitePrefixConstantTailCoefficientV1&,
                         const FinitePrefixConstantTailCoefficientV1&) =
      default;
};

// Solver-owned C19 summary for one phase-free finite-prefix/constant-tail
// response under the exact scalar factorized-IID projection.  Prefix masses
// and aggregate tail mass are present only when C19 establishes a normalized
// law; moment readouts retain their existing solver and Little-law premises.
class FinitePrefixIidSummary final {
 public:
  FinitePrefixIidSummary() = delete;
  FinitePrefixIidSummary(const FinitePrefixIidSummary&) = default;
  FinitePrefixIidSummary(FinitePrefixIidSummary&&) noexcept = default;
  FinitePrefixIidSummary& operator=(const FinitePrefixIidSummary&) = default;
  FinitePrefixIidSummary& operator=(FinitePrefixIidSummary&&) noexcept =
      default;

  [[nodiscard]] const BigNat& cutoff() const noexcept;
  [[nodiscard]] std::span<const ExactRational> service_by_level()
      const noexcept;
  [[nodiscard]] const FinitePrefixConstantTailCoefficientV1& tail_coefficient()
      const noexcept;
  [[nodiscard]] const std::optional<std::vector<ExactRational>>& prefix_masses()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& aggregate_tail_mass()
      const noexcept;
  [[nodiscard]] const ExactRational& arrival_mean() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_mean_backlog()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& numerical_mean_backlog()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_mean_sojourn()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& numerical_mean_sojourn()
      const noexcept;
  [[nodiscard]] MeanSojournCountingConventionV1 sojourn_counting_convention()
      const noexcept;
  [[nodiscard]] TailSlackApplicabilityV1 tail_slack_applicability()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& tail_slack() const noexcept;
  [[nodiscard]] AnalyticStationaryStatusV1 status() const noexcept;
  [[nodiscard]] const AnalyticStationaryDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const ArtifactObjectReferenceV1& response_identity()
      const noexcept;
  [[nodiscard]] const ArtifactObjectReferenceV1& response_product_identity()
      const noexcept;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& law_identity()
      const noexcept;

 private:
  explicit FinitePrefixIidSummary(
      std::shared_ptr<const stationary::detail::FinitePrefixIidSummaryCore>
          core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::FinitePrefixIidSummaryCore> core_;
  friend class detail::C19CoreAccess;
};

[[nodiscard]] Result<FinitePrefixIidSummary>
summarize_finite_prefix_iid_response(const AuditedResponseLaw& response,
                                     const ArrivalLaw& arrival);

// This entry point consumes no class selector and does not mint a second
// response facade.  Unsupported/non-normalized analytic branches remain
// successful summaries carrying their existing C19 status and diagnostics.
[[nodiscard]] Result<FinitePrefixIidSummary>
summarize_finite_prefix_iid_stationary_unique(
    const AuditedResponseLaw& response);

}  // namespace mwperf
