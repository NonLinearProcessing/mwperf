#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/stationary/flux.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf {

class ArrivalLaw;
class ArrivalPmf;
class ArrivalTransform;
class BernoulliRate;
class BlockFluxOperator;
class CompiledArrivalLaw;
class FixedPointLaw;
class PhaseArrivalKernel;
class PhaseStationaryLaw;
class ResolvedInstance;
class ScalarFluxOperator;
class ScalarFiniteClosureProofV1;
class ScalarStationaryLaw;
class StationaryAnalyticLawIdentityV1;
class TransformReadout;

namespace stationary::detail {
struct ArrivalLawCore;
struct ArrivalPmfCore;
struct ArrivalTransformCore;
struct BernoulliRateCore;
struct BlockFluxOperatorCore;
struct FixedPointLawCore;
struct PhaseArrivalKernelCore;
struct PhaseStationaryLawCore;
struct ScalarFluxOperatorCore;
struct ScalarStationaryLawCore;
struct StationaryAnalyticLawIdentityCore;
struct TransformReadoutCore;
}  // namespace stationary::detail

namespace detail {
class C19CoreAccess;
}

#if defined(MWPERF_C19_TEST_SEAMS)
namespace testing {
class C19FixtureAccess;
}
#endif

// An exact atom of the selected queue's finite IID arrival marginal.
struct ScalarArrivalMassV1 final {
  BigNat count;
  ExactRational mass;

  friend bool operator==(const ScalarArrivalMassV1&,
                         const ScalarArrivalMassV1&) = default;
};

// The arrival identity is copied from the same sealed C17 framework as the
// audited response.  There is no public constructor accepting an IID claim.
class ArrivalLaw final {
 public:
  ArrivalLaw() = delete;
  ArrivalLaw(const ArrivalLaw&) = default;
  ArrivalLaw(ArrivalLaw&&) noexcept = default;
  ArrivalLaw& operator=(const ArrivalLaw&) = default;
  ArrivalLaw& operator=(ArrivalLaw&&) noexcept = default;

  [[nodiscard]] static Result<ArrivalLaw> from_audited(
      const AuditedResponseLaw& response);
  [[nodiscard]] static Result<ArrivalLaw> from_audited(
      const AuditedThreeBinResponse& response);
  [[nodiscard]] std::span<const ScalarArrivalMassV1> atoms() const noexcept;
  [[nodiscard]] const ExactRational& mean() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& second_moment()
      const noexcept;
  [[nodiscard]] const ArrivalBinding& configured_arrival() const noexcept;
  [[nodiscard]] const QueueId& target() const noexcept;
  [[nodiscard]] const Digest256& identity_digest() const noexcept;

 private:
  explicit ArrivalLaw(
      std::shared_ptr<const stationary::detail::ArrivalLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::ArrivalLawCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class ArrivalPmf final {
 public:
  ArrivalPmf() = delete;
  ArrivalPmf(const ArrivalPmf&) = default;
  ArrivalPmf(ArrivalPmf&&) noexcept = default;
  ArrivalPmf& operator=(const ArrivalPmf&) = default;
  ArrivalPmf& operator=(ArrivalPmf&&) noexcept = default;

  [[nodiscard]] static ArrivalPmf from(const ArrivalLaw& law);
  [[nodiscard]] std::span<const ScalarArrivalMassV1> atoms() const noexcept;
  [[nodiscard]] Result<ExactRational> probability(const BigNat& count) const;
  [[nodiscard]] Result<ExactRational> survival(const BigNat& count) const;
  [[nodiscard]] const Digest256& identity_digest() const noexcept;

 private:
  explicit ArrivalPmf(
      std::shared_ptr<const stationary::detail::ArrivalPmfCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::ArrivalPmfCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class BernoulliRate final {
 public:
  BernoulliRate() = delete;
  BernoulliRate(const BernoulliRate&) = default;
  BernoulliRate(BernoulliRate&&) noexcept = default;
  BernoulliRate& operator=(const BernoulliRate&) = default;
  BernoulliRate& operator=(BernoulliRate&&) noexcept = default;

  [[nodiscard]] static Result<BernoulliRate> from(const ArrivalLaw& law);
  [[nodiscard]] const ExactRational& value() const noexcept;
  [[nodiscard]] const Digest256& identity_digest() const noexcept;

 private:
  explicit BernoulliRate(
      std::shared_ptr<const stationary::detail::BernoulliRateCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::BernoulliRateCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class ArrivalTransform final {
 public:
  ArrivalTransform() = delete;
  ArrivalTransform(const ArrivalTransform&) = default;
  ArrivalTransform(ArrivalTransform&&) noexcept = default;
  ArrivalTransform& operator=(const ArrivalTransform&) = default;
  ArrivalTransform& operator=(ArrivalTransform&&) noexcept = default;

  [[nodiscard]] static ArrivalTransform from(const ArrivalLaw& law);
  [[nodiscard]] const Digest256& identity_digest() const noexcept;

 private:
  explicit ArrivalTransform(
      std::shared_ptr<const stationary::detail::ArrivalTransformCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::ArrivalTransformCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class EvaluationPoint final {
 public:
  EvaluationPoint() = delete;
  [[nodiscard]] static Result<EvaluationPoint> make(ExactRational z);
  [[nodiscard]] const ExactRational& value() const noexcept { return value_; }

 private:
  explicit EvaluationPoint(ExactRational value) : value_(std::move(value)) {}
  ExactRational value_;
};

class Cutoff final {
 public:
  Cutoff() = delete;
  explicit Cutoff(BigNat value) : value_(std::move(value)) {}
  [[nodiscard]] const BigNat& value() const noexcept { return value_; }

 private:
  BigNat value_;
};

class TailService final {
 public:
  TailService() = delete;
  [[nodiscard]] static Result<TailService> make(ExactRational value);
  [[nodiscard]] const ExactRational& value() const noexcept { return value_; }

 private:
  explicit TailService(ExactRational value) : value_(std::move(value)) {}
  ExactRational value_;
};

enum class ScalarTailCompletionKindV1 : std::uint8_t {
  exact_finite_closure,
  constant_response,
  certified_truncation,
  no_completion,
};

class TailPolicy final {
 public:
  TailPolicy() = delete;
  [[nodiscard]] static TailPolicy exact_finite_closure(Cutoff cutoff);
  [[nodiscard]] static TailPolicy constant_response(Cutoff cutoff,
                                                    TailService service);
  [[nodiscard]] static TailPolicy certified_truncation(
      Cutoff cutoff, ExactRational tail_mass_bound);
  [[nodiscard]] static TailPolicy no_completion(BigNat maximum_terms);
  [[nodiscard]] ScalarTailCompletionKindV1 kind() const noexcept;
  [[nodiscard]] const std::optional<Cutoff>& cutoff() const noexcept;
  [[nodiscard]] const std::optional<TailService>& tail_service()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& tail_mass_bound()
      const noexcept;
  [[nodiscard]] const std::optional<BigNat>& maximum_terms() const noexcept;

 private:
  TailPolicy(ScalarTailCompletionKindV1 kind, std::optional<Cutoff> cutoff,
             std::optional<TailService> service,
             std::optional<ExactRational> tail_mass_bound,
             std::optional<BigNat> maximum_terms)
      : kind_(kind),
        cutoff_(std::move(cutoff)),
        service_(std::move(service)),
        tail_mass_bound_(std::move(tail_mass_bound)),
        maximum_terms_(std::move(maximum_terms)) {}
  ScalarTailCompletionKindV1 kind_;
  std::optional<Cutoff> cutoff_;
  std::optional<TailService> service_;
  std::optional<ExactRational> tail_mass_bound_;
  std::optional<BigNat> maximum_terms_;
};

enum class AnalyticStationaryStatusV1 : std::uint8_t {
  finite,
  infinite,
  not_established,
  strict_tail_stable,
  finite_closed_tail_unreachable,
  outside_strict_tail_profile,
  degenerate_or_selected_closed_class,
  required_moment_unavailable,
  not_summable,
  incomplete_tail,
  multiple_classes_or_roots,
  unsupported_assumptions,
  numerically_unresolved,
};

struct AnalyticStationaryDiagnosticsV1 final {
  ExactRational normalization_residual;
  ExactRational invariance_residual;
  std::optional<ExactRational> tail_remainder_bound;
  std::optional<ExactRational> tail_slack;
  std::optional<BigNat> terms_evaluated;
  long double numerical_condition_estimate;
};

// A closed copy of the C17/C15 lineage used unchanged by every C19 output.
class StationaryAnalyticLawIdentityV1 final {
 public:
  StationaryAnalyticLawIdentityV1() = delete;
  StationaryAnalyticLawIdentityV1(const StationaryAnalyticLawIdentityV1&) =
      default;
  StationaryAnalyticLawIdentityV1(StationaryAnalyticLawIdentityV1&&) noexcept =
      default;
  StationaryAnalyticLawIdentityV1& operator=(
      const StationaryAnalyticLawIdentityV1&) = default;
  StationaryAnalyticLawIdentityV1& operator=(
      StationaryAnalyticLawIdentityV1&&) noexcept = default;
  [[nodiscard]] const AuditedFrameworkBindingsV1& framework() const noexcept;
  [[nodiscard]] const ArtifactValidationBindingsV1& artifact() const noexcept;
  [[nodiscard]] const Digest256& execution_seal_digest() const noexcept;
  [[nodiscard]] const std::optional<Digest256>& carrier_snapshot_digest()
      const noexcept;
  [[nodiscard]] const ArtifactObjectReferenceV1& payload() const noexcept;
  [[nodiscard]] const std::optional<MetricClauseIdV1>&
  accepted_metric_clause() const noexcept;
  [[nodiscard]] const std::optional<RealizedMetricBindingV1>&
  realized_metric_binding() const noexcept;
  [[nodiscard]] PayloadPhaseKindV1 payload_phase() const noexcept;
  [[nodiscard]] const std::optional<ResponseProductStageV1>& response_stage()
      const noexcept;
  [[nodiscard]] const std::optional<ArtifactObjectReferenceV1>&
  response_product() const noexcept;
  [[nodiscard]] const std::optional<ArtifactObjectReferenceV1>& derivation()
      const noexcept;
  [[nodiscard]] const std::optional<BigNat>& cutoff() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& tail_service()
      const noexcept;
  [[nodiscard]] const ArrivalBinding& configured_arrival() const noexcept;
  [[nodiscard]] const PortableAnalysisSelectionV1& selection() const noexcept;
  [[nodiscard]] const QueueId& target() const noexcept;
  [[nodiscard]] std::span<const QueueId> construction_targets() const noexcept;
  [[nodiscard]] MetricResultScopeV1 result_scope() const noexcept;
  friend bool operator==(const StationaryAnalyticLawIdentityV1&,
                         const StationaryAnalyticLawIdentityV1&);

 private:
  explicit StationaryAnalyticLawIdentityV1(
      std::shared_ptr<const
                      stationary::detail::StationaryAnalyticLawIdentityCore>
          core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::StationaryAnalyticLawIdentityCore>
      core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class ScalarFluxOperator final {
 public:
  ScalarFluxOperator() = delete;
  ScalarFluxOperator(const ScalarFluxOperator&) = default;
  ScalarFluxOperator(ScalarFluxOperator&&) noexcept = default;
  ScalarFluxOperator& operator=(const ScalarFluxOperator&) = default;
  ScalarFluxOperator& operator=(ScalarFluxOperator&&) noexcept = default;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& identity()
      const noexcept;
  [[nodiscard]] Result<ExactRational> arrival_probability(
      const BigNat& count) const;
  [[nodiscard]] Result<ExactRational> arrival_survival(
      const BigNat& count) const;
  [[nodiscard]] Result<ExactRational> service_probability(
      const BigNat& backlog) const;
  [[nodiscard]] Result<ExactRational> transition_probability(
      const BigNat& source, const BigNat& destination) const;

 private:
  explicit ScalarFluxOperator(
      std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::ScalarFluxOperatorCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

// Solver-owned evidence that the exact positive deployed transitions from
// the selected scalar seed close on the listed finite support.  There is no
// public constructor: only the C19 closure proof may issue this record.
class ScalarFiniteClosureProofV1 final {
 public:
  ScalarFiniteClosureProofV1() = delete;
  ScalarFiniteClosureProofV1(const ScalarFiniteClosureProofV1&) = default;
  ScalarFiniteClosureProofV1(ScalarFiniteClosureProofV1&&) noexcept = default;
  ScalarFiniteClosureProofV1& operator=(const ScalarFiniteClosureProofV1&) =
      default;
  ScalarFiniteClosureProofV1& operator=(
      ScalarFiniteClosureProofV1&&) noexcept = default;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& law_identity()
      const noexcept;
  [[nodiscard]] std::span<const BigNat> reachable_support() const noexcept;

 private:
  ScalarFiniteClosureProofV1(StationaryAnalyticLawIdentityV1 law_identity,
                             std::vector<BigNat> reachable_support)
      : law_identity_(std::move(law_identity)),
        reachable_support_(std::move(reachable_support)) {}
  StationaryAnalyticLawIdentityV1 law_identity_;
  std::vector<BigNat> reachable_support_;
  friend class detail::C19CoreAccess;
};

class ScalarStationaryLaw final {
 public:
  ScalarStationaryLaw() = delete;
  ScalarStationaryLaw(const ScalarStationaryLaw&) = default;
  ScalarStationaryLaw(ScalarStationaryLaw&&) noexcept = default;
  ScalarStationaryLaw& operator=(const ScalarStationaryLaw&) = default;
  ScalarStationaryLaw& operator=(ScalarStationaryLaw&&) noexcept = default;
  [[nodiscard]] AnalyticStationaryStatusV1 status() const noexcept;
  [[nodiscard]] bool normalized_law_established() const noexcept;
  [[nodiscard]] Result<ExactRational> mass(const BigNat& backlog) const;
  [[nodiscard]] const std::optional<ExactRational>& exact_tail_mass()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_mean_backlog()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& numerical_mean_backlog()
      const noexcept;
  [[nodiscard]] const AnalyticStationaryDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const std::optional<ScalarFiniteClosureProofV1>&
  finite_closure_proof() const noexcept;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& identity()
      const noexcept;

 private:
  explicit ScalarStationaryLaw(
      std::shared_ptr<const stationary::detail::ScalarStationaryLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::ScalarStationaryLawCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class TransformReadout final {
 public:
  TransformReadout() = delete;
  TransformReadout(const TransformReadout&) = default;
  TransformReadout(TransformReadout&&) noexcept = default;
  TransformReadout& operator=(const TransformReadout&) = default;
  TransformReadout& operator=(TransformReadout&&) noexcept = default;
  [[nodiscard]] AnalyticStationaryStatusV1 status() const noexcept;
  [[nodiscard]] const EvaluationPoint& point() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_pgf()
      const noexcept;
  [[nodiscard]] const std::optional<long double>& numerical_pgf()
      const noexcept;
  [[nodiscard]] const std::optional<ExactRational>&
  exact_response_weighted_pgf() const noexcept;
  [[nodiscard]] const std::optional<long double>&
  numerical_response_weighted_pgf() const noexcept;
  [[nodiscard]] const std::optional<ExactRational>& exact_mean_backlog()
      const noexcept;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& identity()
      const noexcept;

 private:
  explicit TransformReadout(
      std::shared_ptr<const stationary::detail::TransformReadoutCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::TransformReadoutCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

struct ExactPhaseArrivalBlockV1 final {
  BigNat arrival_count;
  std::vector<ExactRational> row_major;
};

enum class PhaseLevelCompletionKindV1 : std::uint8_t {
  exact_closed,
  additive_completion,
};

struct PhaseCompletionAtomV1 final {
  std::size_t source_flat_index;
  std::size_t successor_flat_index;
  ExactRational mass;
};

struct PhaseLevelCompletionV1 final {
  PhaseLevelCompletionKindV1 kind;
  BigNat maximum_level;
  std::optional<Digest256> completion_identity;
  std::vector<PhaseCompletionAtomV1> additive_atoms;
};

class PhaseArrivalKernel final {
 public:
  PhaseArrivalKernel() = delete;
  PhaseArrivalKernel(const PhaseArrivalKernel&) = default;
  PhaseArrivalKernel(PhaseArrivalKernel&&) noexcept = default;
  PhaseArrivalKernel& operator=(const PhaseArrivalKernel&) = default;
  PhaseArrivalKernel& operator=(PhaseArrivalKernel&&) noexcept = default;
  [[nodiscard]] static Result<PhaseArrivalKernel> from_audited(
      const AuditedPhaseResponse& response);
  [[nodiscard]] std::span<const ArrivalPhaseIdentityV1> phases()
      const noexcept;
  [[nodiscard]] std::span<const ExactPhaseArrivalBlockV1> blocks()
      const noexcept;
  [[nodiscard]] std::span<const ExactRational> configured_phase_marginal()
      const noexcept;
  [[nodiscard]] const PhaseLevelCompletionV1& completion() const noexcept;

 private:
  explicit PhaseArrivalKernel(
      std::shared_ptr<const stationary::detail::PhaseArrivalKernelCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::PhaseArrivalKernelCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class BlockFluxOperator final {
 public:
  BlockFluxOperator() = delete;
  BlockFluxOperator(const BlockFluxOperator&) = default;
  BlockFluxOperator(BlockFluxOperator&&) noexcept = default;
  BlockFluxOperator& operator=(const BlockFluxOperator&) = default;
  BlockFluxOperator& operator=(BlockFluxOperator&&) noexcept = default;
  [[nodiscard]] std::size_t phase_count() const noexcept;
  [[nodiscard]] const BigNat& maximum_level() const noexcept;
  [[nodiscard]] Result<ExactRational> transition_probability(
      const BigNat& source_level, std::size_t source_phase,
      const BigNat& destination_level, std::size_t destination_phase) const;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& identity()
      const noexcept;

 private:
  explicit BlockFluxOperator(
      std::shared_ptr<const stationary::detail::BlockFluxOperatorCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::BlockFluxOperatorCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

class PhaseStationaryLaw final {
 public:
  PhaseStationaryLaw() = delete;
  PhaseStationaryLaw(const PhaseStationaryLaw&) = default;
  PhaseStationaryLaw(PhaseStationaryLaw&&) noexcept = default;
  PhaseStationaryLaw& operator=(const PhaseStationaryLaw&) = default;
  PhaseStationaryLaw& operator=(PhaseStationaryLaw&&) noexcept = default;
  [[nodiscard]] AnalyticStationaryStatusV1 status() const noexcept;
  [[nodiscard]] Result<long double> mass(const BigNat& level,
                                         std::size_t phase) const;
  [[nodiscard]] std::span<const SelectedInvariantClassV1> selected_classes()
      const noexcept;
  [[nodiscard]] std::span<const PhaseMarginalAtomV1> phase_marginal()
      const noexcept;
  [[nodiscard]] const InvariantSolveDiagnosticsV1& diagnostics()
      const noexcept;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& identity()
      const noexcept;

 private:
  explicit PhaseStationaryLaw(
      std::shared_ptr<const stationary::detail::PhaseStationaryLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::PhaseStationaryLawCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

enum class FixedPointTerminationV1 : std::uint8_t {
  converged,
  iteration_budget_exhausted,
  selected_root_unavailable,
  unsupported_assumptions,
  numerically_unresolved,
  evaluation_budget_exhausted,
};

class FixedPointLaw final {
 public:
  FixedPointLaw() = delete;
  FixedPointLaw(const FixedPointLaw&) = default;
  FixedPointLaw(FixedPointLaw&&) noexcept = default;
  FixedPointLaw& operator=(const FixedPointLaw&) = default;
  FixedPointLaw& operator=(FixedPointLaw&&) noexcept = default;
  [[nodiscard]] FixedPointTerminationV1 termination() const noexcept;
  [[nodiscard]] std::span<const ExactRational> parameters() const noexcept;
  [[nodiscard]] const ExactRational& iterate_difference() const noexcept;
  [[nodiscard]] const ExactRational& fixed_point_residual() const noexcept;
  [[nodiscard]] const BigNat& iteration_count() const noexcept;
  [[nodiscard]] const BigNat& evaluation_count() const noexcept;
  [[nodiscard]] const Digest256& selector_digest() const noexcept;
  [[nodiscard]] const StationaryAnalyticLawIdentityV1& identity()
      const noexcept;

 private:
  explicit FixedPointLaw(
      std::shared_ptr<const stationary::detail::FixedPointLawCore> core)
      : core_(std::move(core)) {}
  std::shared_ptr<const stationary::detail::FixedPointLawCore> core_;
  friend class detail::C19CoreAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
};

[[nodiscard]] Result<ScalarFluxOperator> assemble_iid_scalar_flux(
    const AuditedResponseLaw& response, const ArrivalPmf& arrival);
[[nodiscard]] Result<ScalarStationaryLaw> solve_scalar_cut_recursion(
    const ScalarFluxOperator& flux, const TailPolicy& tail_policy);
[[nodiscard]] Result<TransformReadout> evaluate_scalar_pgf_and_moments(
    const ScalarStationaryLaw& law, const ArrivalTransform& arrival_transform,
    const EvaluationPoint& point);
[[nodiscard]] Result<ScalarStationaryLaw> solve_bernoulli_birth_death(
    const AuditedResponseLaw& response, const BernoulliRate& arrival);
[[nodiscard]] Result<ScalarStationaryLaw> solve_constant_tail_response(
    const AuditedResponseLaw& response, const ArrivalLaw& arrival,
    const Cutoff& cutoff, const TailService& tail_service);
[[nodiscard]] Result<BlockFluxOperator> assemble_markov_additive_blocks(
    const PhaseArrivalKernel& arrival, const AuditedPhaseResponse& response);
[[nodiscard]] Result<PhaseStationaryLaw> solve_markov_additive_stationary(
    const BlockFluxOperator& flux, const SelectionSpec& selection,
    const SolverPolicy& policy);
[[nodiscard]] Result<FixedPointLaw> solve_declared_fixed_point(
    const AuditedFixedPointFamily& family, const SelectionSpec& selection,
    const SolverPolicy& policy);

#if defined(MWPERF_C19_TEST_SEAMS)
namespace testing {

struct ExactScalarResponseFixtureV1 final {
  std::vector<ExactRational> service_by_level;
  std::optional<BigNat> constant_tail_from;
  std::optional<ExactRational> constant_tail_service;
};

struct ExactPhaseResponseFixtureV1 final {
  std::vector<ArrivalPhaseIdentityV1> phases;
  std::vector<ExactPhaseArrivalBlockV1> arrival_blocks;
  std::vector<ExactRational> configured_phase_marginal;
  std::vector<ExactRational> service_row_major;
  PhaseLevelCompletionV1 completion;
};

using ExactFixedPointMapV1 = std::function<Result<std::vector<ExactRational>>(
    std::span<const ExactRational>)>;
struct ExactNamedFixedPointSolutionV1 final {
  TypedLabel id;
  std::vector<ExactRational> parameters;
};

struct ExactFixedPointFixtureV1 final {
  std::vector<ExactRational> lower;
  std::vector<ExactRational> upper;
  std::vector<ExactRational> cold_initial;
  bool uniqueness_declared;
  std::vector<ExactNamedFixedPointSolutionV1> named_solutions;
  ExactFixedPointMapV1 map;
};

class C19FixtureAccess final {
 public:
  [[nodiscard]] static Result<ResolvedInstance>
  bind_resolved_arrival_for_testing(
      const ResolvedInstance& source,
      std::shared_ptr<const CompiledArrivalLaw> configured_arrival);
  [[nodiscard]] static Result<ArrivalLaw> arrival_law(
      std::vector<ScalarArrivalMassV1> atoms);
  [[nodiscard]] static Result<ArrivalLaw> arrival_law_without_second_moment(
      std::vector<ScalarArrivalMassV1> atoms);
  [[nodiscard]] static Result<ArrivalLaw> arrival_law(
      const AuditedResponseLaw& response,
      std::vector<ScalarArrivalMassV1> atoms);
  [[nodiscard]] static Result<ArrivalLaw> arrival_law(
      const AuditedThreeBinResponse& response,
      std::vector<ScalarArrivalMassV1> atoms);
  [[nodiscard]] static Result<ScalarFluxOperator> scalar_flux(
      const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response);
  [[nodiscard]] static Result<ScalarStationaryLaw> solve_bernoulli(
      const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response);
  [[nodiscard]] static Result<ScalarStationaryLaw> solve_constant_tail(
      const ArrivalLaw& arrival, ExactScalarResponseFixtureV1 response,
      const Cutoff& cutoff, const TailService& tail_service);
  [[nodiscard]] static Result<PhaseArrivalKernel> phase_arrival_kernel(
      ExactPhaseResponseFixtureV1 fixture);
  [[nodiscard]] static Result<PhaseArrivalKernel> phase_arrival_kernel(
      const AuditedPhaseResponse& response,
      ExactPhaseResponseFixtureV1 fixture);
  [[nodiscard]] static Result<BlockFluxOperator> phase_flux(
      ExactPhaseResponseFixtureV1 fixture);
  [[nodiscard]] static Result<BlockFluxOperator> phase_flux(
      const PhaseArrivalKernel& arrival,
      ExactPhaseResponseFixtureV1 fixture);
  [[nodiscard]] static Result<FixedPointLaw> fixed_point_law(
      ExactFixedPointFixtureV1 fixture, const SelectionSpec& selection,
      const SolverPolicy& policy);
};

}  // namespace testing
#endif

}  // namespace mwperf
