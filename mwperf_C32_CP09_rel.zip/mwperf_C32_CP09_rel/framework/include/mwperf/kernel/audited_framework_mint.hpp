#pragma once

#include <cstddef>
#include <functional>
#include <optional>
#include <utility>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/framework_activation.hpp"
#include "mwperf/kernel/marked_kernel_row.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/surrogate/plug_contract.hpp"

namespace mwperf {

class DirectMetricCompositeCandidateV1;

namespace detail {
// Narrow C27 adapter: C17 remains the sole implementation of the canonical
// raw-access identity.  This free function exposes only the immutable digest;
// unlike a friend class it cannot reach sealing or callable ownership.
[[nodiscard]] Result<Digest256> canonical_kernel_access_identity_for_candidate(
    const KernelAccess& access);
// Narrow C27 post-V0 identity adapter.  It returns only the immutable seal
// digest and exposes neither the sealed core nor any executable operation.
[[nodiscard]] Result<Digest256> audited_framework_execution_seal_digest(
    const AuditedCompiledFramework& framework);
}

#if defined(MWPERF_C17_TEST_SEAMS)
namespace testing {
class C17FixtureAccess;
}
#endif

// Immutable projection of a passing factor audit.  It contains all bindings
// needed to validate and cite the factor but deliberately retains no raw
// access, callback, executable core, or optimizer context.
class DirectFactorWitnessV1 final {
 public:
  DirectFactorWitnessV1() = delete;
  DirectFactorWitnessV1(const DirectFactorWitnessV1&) = default;
  DirectFactorWitnessV1(DirectFactorWitnessV1&&) noexcept = default;
  DirectFactorWitnessV1& operator=(const DirectFactorWitnessV1&) = default;
  DirectFactorWitnessV1& operator=(DirectFactorWitnessV1&&) noexcept =
      default;

  [[nodiscard]] const Digest256& execution_seal_digest() const noexcept {
    return execution_seal_digest_;
  }
  [[nodiscard]] const V0WitnessReport& report() const noexcept {
    return report_;
  }
  [[nodiscard]] const AuditedFrameworkBindingsV1& framework_bindings()
      const noexcept {
    return framework_bindings_;
  }
  [[nodiscard]] const TargetSelection& target_selection() const noexcept {
    return target_selection_;
  }
  [[nodiscard]] const std::vector<QueueId>& deployed_targets()
      const noexcept {
    return deployed_targets_;
  }
  [[nodiscard]] const Digest256& ownership_schema_digest() const noexcept {
    return ownership_schema_digest_;
  }
  [[nodiscard]] const Digest256& exact_update_schema_digest() const noexcept {
    return exact_update_schema_digest_;
  }
  [[nodiscard]] const ArrivalBinding& configured_arrival_binding()
      const noexcept {
    return configured_arrival_binding_;
  }
  [[nodiscard]] ExactCausalProgramModeV1 causal_program_mode()
      const noexcept {
    return causal_program_mode_;
  }
  [[nodiscard]] RuntimeAccessTagV1 runtime_access() const noexcept {
    return runtime_access_;
  }
  [[nodiscard]] bool row_available() const noexcept {
    return row_available_;
  }

 private:
  DirectFactorWitnessV1(
      Digest256 execution_seal_digest, V0WitnessReport report,
      AuditedFrameworkBindingsV1 framework_bindings,
      TargetSelection target_selection,
      std::vector<QueueId> deployed_targets,
      Digest256 ownership_schema_digest,
      Digest256 exact_update_schema_digest,
      ArrivalBinding configured_arrival_binding,
      ExactCausalProgramModeV1 causal_program_mode,
      RuntimeAccessTagV1 runtime_access, bool row_available)
      : execution_seal_digest_(std::move(execution_seal_digest)),
        report_(std::move(report)),
        framework_bindings_(std::move(framework_bindings)),
        target_selection_(std::move(target_selection)),
        deployed_targets_(std::move(deployed_targets)),
        ownership_schema_digest_(std::move(ownership_schema_digest)),
        exact_update_schema_digest_(std::move(exact_update_schema_digest)),
        configured_arrival_binding_(
            std::move(configured_arrival_binding)),
        causal_program_mode_(causal_program_mode),
        runtime_access_(runtime_access),
        row_available_(row_available) {}

  Digest256 execution_seal_digest_;
  V0WitnessReport report_;
  AuditedFrameworkBindingsV1 framework_bindings_;
  TargetSelection target_selection_;
  std::vector<QueueId> deployed_targets_;
  Digest256 ownership_schema_digest_;
  Digest256 exact_update_schema_digest_;
  ArrivalBinding configured_arrival_binding_;
  ExactCausalProgramModeV1 causal_program_mode_;
  RuntimeAccessTagV1 runtime_access_;
  bool row_available_;

  friend class C17AuditedFrameworkMint;
  friend class detail::C17CoreAccess;
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
};

// Post-composite-audit direct metadata.  Every executable direct operation is
// still extracted from the owner-matched moved raw access; the factor is an
// immutable witness only.
class DirectMetricSealServicesV1 final {
 public:
  DirectMetricSealServicesV1() = delete;
  DirectMetricSealServicesV1(const DirectMetricSealServicesV1&) = default;
  DirectMetricSealServicesV1(DirectMetricSealServicesV1&&) noexcept =
      default;
  DirectMetricSealServicesV1& operator=(
      const DirectMetricSealServicesV1&) = default;
  DirectMetricSealServicesV1& operator=(
      DirectMetricSealServicesV1&&) noexcept = default;

  [[nodiscard]] const DirectMetricRequestDomainV1& domain() const noexcept {
    return domain_;
  }
  [[nodiscard]] const DirectFactorWitnessV1& factor_witness()
      const noexcept {
    return factor_witness_;
  }

 private:
  DirectMetricSealServicesV1(DirectMetricRequestDomainV1 domain,
                             DirectFactorWitnessV1 factor_witness)
      : domain_(std::move(domain)),
        factor_witness_(std::move(factor_witness)) {}

  DirectMetricRequestDomainV1 domain_;
  DirectFactorWitnessV1 factor_witness_;

  friend class C17AuditedFrameworkMint;
  friend class detail::C17CoreAccess;
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
};

struct CompiledFrameworkCandidateInputsV1 final {
  BuildIdentityDigest build_identity;
  Digest256 final_request_identity;
  ResolvedInstance instance;
  CompiledArrivalLaw configured_arrival;
  AcceptedCapabilityContract accepted_contract;
  RealizedMetricBindingsV1 realized_metric_bindings;
  ExactReducedStateSchemaV1 exact_state_schema;
  ExactCausalProgramV1 causal_program;
  std::optional<DirectMetricSealServicesV1> direct_metric_services;
  OptimizerExecutionContext optimizer_context;
  AuditedFrameworkSeedV1 framework_seed;
};

class CompiledFrameworkCandidate final {
 public:
  CompiledFrameworkCandidate() = delete;
  CompiledFrameworkCandidate(const CompiledFrameworkCandidate&) = delete;
  CompiledFrameworkCandidate& operator=(const CompiledFrameworkCandidate&) =
      delete;
  CompiledFrameworkCandidate(CompiledFrameworkCandidate&&) noexcept = default;
  CompiledFrameworkCandidate& operator=(CompiledFrameworkCandidate&&) =
      delete;

 private:
  CompiledFrameworkCandidate(
      SurrogatePlug plug,
      Digest256 validated_descriptor_digest,
      ArtifactValidationBindingsV1 artifact_bindings,
      Digest256 validated_contract_digest,
      MetricSupportManifest validated_structural_manifest,
      CompiledFrameworkCandidateInputsV1 inputs)
      : plug_(std::move(plug)),
        validated_descriptor_digest_(
            std::move(validated_descriptor_digest)),
        artifact_bindings_(std::move(artifact_bindings)),
        validated_contract_digest_(std::move(validated_contract_digest)),
        validated_structural_manifest_(
            std::move(validated_structural_manifest)),
        inputs_(std::move(inputs)) {}

  SurrogatePlug plug_;
  Digest256 validated_descriptor_digest_;
  ArtifactValidationBindingsV1 artifact_bindings_;
  Digest256 validated_contract_digest_;
  MetricSupportManifest validated_structural_manifest_;
  CompiledFrameworkCandidateInputsV1 inputs_;

  friend class C17AuditedFrameworkMint;
  friend class detail::C17CoreAccess;
};

// The only pre-V0 carrier permitted for a direct decoder.  It owns the one
// request-local optimizer context while holding one C16-validated direct
// candidate and one fresh, private raw-factor recipe.  The public type exposes
// no accessor and can be consumed only by the composite audit below.
class DirectMetricCompositeCandidateV1 final {
 public:
  DirectMetricCompositeCandidateV1() = delete;
  DirectMetricCompositeCandidateV1(
      const DirectMetricCompositeCandidateV1&) = delete;
  DirectMetricCompositeCandidateV1& operator=(
      const DirectMetricCompositeCandidateV1&) = delete;
  DirectMetricCompositeCandidateV1(
      DirectMetricCompositeCandidateV1&&) noexcept = default;
  DirectMetricCompositeCandidateV1& operator=(
      DirectMetricCompositeCandidateV1&&) = delete;

 private:
  DirectMetricCompositeCandidateV1(
      ValidatedSurrogatePlug direct_validated_plug,
      KernelAccess direct_kernel_access,
      OptimizerFreeFrameworkCandidateInputsV1 direct_inputs,
      RuntimeDirectMetricActivationV1 direct_activation,
      OptimizerExecutionContext optimizer_context,
      BigNat maximum_factor_optimizer_calls)
      : direct_validated_plug_(std::move(direct_validated_plug)),
        direct_kernel_access_(std::move(direct_kernel_access)),
        direct_inputs_(std::move(direct_inputs)),
        direct_activation_(std::move(direct_activation)),
        optimizer_context_(std::move(optimizer_context)),
        maximum_factor_optimizer_calls_(
            std::move(maximum_factor_optimizer_calls)) {}

  ValidatedSurrogatePlug direct_validated_plug_;
  KernelAccess direct_kernel_access_;
  OptimizerFreeFrameworkCandidateInputsV1 direct_inputs_;
  RuntimeDirectMetricActivationV1 direct_activation_;
  OptimizerExecutionContext optimizer_context_;
  BigNat maximum_factor_optimizer_calls_;

  friend class C17AuditedFrameworkMint;
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
};

// Sole production friend of the C16 raw plug/access and audited consumer
// constructors. Candidate creation consumes the validated carrier; sealing is
// callable only through F-C17-07 after its V0 report passes.
class C17AuditedFrameworkMint final {
 public:
  C17AuditedFrameworkMint() = delete;

  [[nodiscard]] static CompiledFrameworkCandidate make_candidate(
      ValidatedSurrogatePlug&& validated_plug,
      CompiledFrameworkCandidateInputsV1 inputs) {
    Digest256 validated_descriptor_digest =
        validated_plug.descriptor_.descriptor_digest;
    return CompiledFrameworkCandidate(
        std::move(validated_plug.plug_),
        std::move(validated_descriptor_digest),
        std::move(validated_plug.artifact_bindings_),
        std::move(validated_plug.accepted_contract_digest_),
        std::move(validated_plug.accepted_structural_manifest_),
        std::move(inputs));
  }

  [[nodiscard]] static DirectMetricCompositeCandidateV1
  make_direct_composite_candidate(
      ValidatedSurrogatePlug&& direct_validated_plug,
      KernelAccess direct_kernel_access,
      OptimizerFreeFrameworkCandidateInputsV1 direct_inputs,
      RuntimeDirectMetricActivationV1 direct_activation,
      OptimizerExecutionContext optimizer_context,
      BigNat maximum_factor_optimizer_calls) {
    return DirectMetricCompositeCandidateV1(
        std::move(direct_validated_plug),
        std::move(direct_kernel_access), std::move(direct_inputs),
        std::move(direct_activation), std::move(optimizer_context),
        std::move(maximum_factor_optimizer_calls));
  }

  // Safe adapters over C16's private raw closure prototypes. They return only
  // opaque prepared stage laws; no callback or RNG reference escapes.
  [[nodiscard]] static Result<OpportunityLaw> prepare_cminus_law(
      const SurrogatePlug& plug, const ReducedStateV1& state);
  [[nodiscard]] static Result<PostClosureLaw> prepare_cplus_law(
      const SurrogatePlug& plug, const ReducedStateV1& state,
      const OpportunityMark& opportunity, const ResolvedAction& action,
      const ArrivalTransition& arrival);
  [[nodiscard]] static Result<DirectMetricAccess> issue_direct_metric_access(
      const AuditedCompiledFramework& framework);

 private:
  [[nodiscard]] static Result<AuditedCompiledFramework> seal(
      CompiledFrameworkCandidate candidate, PlugDescriptor descriptor,
      KernelAccess access, V0WitnessReport report,
      Digest256 execution_seal_digest);
  [[nodiscard]] static bool same_raw_access(
      const SurrogatePlug& plug, const KernelAccess& supplied) noexcept;
  [[nodiscard]] static Result<Digest256> canonical_raw_access_identity(
      const KernelAccess& access);
  [[nodiscard]] static Result<DirectFactorWitnessV1>
  audit_direct_factor_recipe(
      RuntimePlugCandidateV1 raw_candidate,
      CompiledFrameworkCandidateInputsV1& inputs,
      const ValidatedSurrogatePlug& direct_validated_plug);
  // Called only after same_raw_access succeeds. The detached embedded alias
  // is destroyed; the separately supplied access is the seal's sole callable
  // owner.
  static void detach_raw_access(SurrogatePlug& plug);

  friend class detail::C17CoreAccess;
  friend Result<Digest256>
  detail::canonical_kernel_access_identity_for_candidate(
      const KernelAccess& access);
#if defined(MWPERF_C17_TEST_SEAMS)
  [[nodiscard]] static ValidatedSurrogatePlug validated_plug_for_testing(
      PlugDescriptor descriptor, SurrogatePlug plug,
      ArtifactValidationBindingsV1 artifact_bindings,
      Digest256 accepted_contract_digest,
      MetricSupportManifest accepted_structural_manifest) {
    return ValidatedSurrogatePlug(
        std::move(descriptor), std::move(plug),
        std::move(artifact_bindings),
        std::move(accepted_contract_digest),
        std::move(accepted_structural_manifest));
  }
  friend class testing::C17FixtureAccess;
#endif
  friend Result<AuditedCompiledFramework> audit_v0_causality(
      CompiledFrameworkCandidate, PlugDescriptor, KernelAccess);
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
};

}  // namespace mwperf
