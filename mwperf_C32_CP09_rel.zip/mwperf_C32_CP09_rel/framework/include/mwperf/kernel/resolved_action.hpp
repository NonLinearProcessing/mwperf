#pragma once

#include <cstddef>
#include <optional>
#include <utility>
#include <vector>

#include "mwperf/kernel/stage_context.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/reduction/opportunity.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
}

enum class ActionResolutionKindV1 : std::uint8_t {
  configured_maxweight,
  emitted_schedule_face,
  three_bin_forced_out,
  three_bin_forced_in,
};

// For one target e, these values are the exact maxima of
//   rho(s) + sum_{f in T\{e}} N_f s_f
// on the two schedule faces s_e=0 and s_e=1.  The signed margin is
// N_e + forced_in_residual_max - forced_out_residual_max.  Thus sign and tie
// syntax are checked relative to the emitted V0 face without asserting a
// physical backlog completion.
struct EmittedTargetFaceEvidenceV1 final {
  TargetIndex target;
  ExactRational forced_out_residual_max;
  ExactRational forced_in_residual_max;
  ExactRational algebraic_margin;
  AlgebraicTargetClass exact_class;
  bool target_eligible;

  friend bool operator==(const EmittedTargetFaceEvidenceV1&,
                         const EmittedTargetFaceEvidenceV1&) = default;
};

struct EmittedScheduleFaceDecisionV1 final {
  std::vector<EmittedTargetFaceEvidenceV1> ordered_target_faces;
  ExactRational selected_primary_score;
  BigNat configured_secondary_code;

  friend bool operator==(const EmittedScheduleFaceDecisionV1&,
                         const EmittedScheduleFaceDecisionV1&) = default;
};

// Exact evidence retained with the selected common action.  ThreeBin is the
// sole singleton exemption: it carries only its forced class and makes no
// common multi-target schedule/optimizer claim.
struct ResolvedActionEvidenceV1 final {
  ActionResolutionKindV1 resolution_kind;
  bool common_feasible_schedule;
  std::optional<AlgebraicTargetClass> exact_target_class;
  std::optional<EmittedScheduleFaceDecisionV1> emitted_face;

  friend bool operator==(const ResolvedActionEvidenceV1&,
                         const ResolvedActionEvidenceV1&) = default;
};

struct ResolvedAction final {
  CausalBranchIdentityV1 branch;
  // The complete feasible attempted schedule and D=s 1{N>0}, respectively.
  Schedule schedule;
  Schedule actual_departure;
  Digest256 schedule_identity;
  ResolvedActionEvidenceV1 evidence;
  CanonicalRuntimeValueV1 decision;
  std::optional<CanonicalRuntimeValueV1> interim_controller;
  std::optional<CanonicalRuntimeValueV1> postupdate_controller_tape;
  std::vector<RuntimeDecodedMarkV1> marks;

  friend bool operator==(const ResolvedAction&,
                         const ResolvedAction&) = default;
};

struct ActionLawAtomV1 final {
  ResolvedAction outcome;
  ExactRational raw_mass;
  bool structural_support;

  friend bool operator==(const ActionLawAtomV1&,
                         const ActionLawAtomV1&) = default;
};

using PreparedActionSamplerV1 =
    std::function<Result<ResolvedAction>(DeterministicRng&)>;

class ActionLaw final {
 public:
  ActionLaw() = delete;
  ActionLaw(const ActionLaw&) = default;
  ActionLaw(ActionLaw&&) noexcept = default;
  ActionLaw& operator=(const ActionLaw&) = default;
  ActionLaw& operator=(ActionLaw&&) noexcept = default;

  [[nodiscard]] std::size_t support_size() const noexcept {
    return atoms_.size();
  }
  [[nodiscard]] bool enumerable() const noexcept { return pmf_.has_value(); }
  [[nodiscard]] bool realizable() const noexcept {
    return static_cast<bool>(sampler_) || pmf_.has_value();
  }
  [[nodiscard]] const ExactRational* raw_sum() const noexcept {
    return pmf_ ? &pmf_->authored_sum() : nullptr;
  }
  [[nodiscard]] const ExactRational* signed_delta_from_one() const noexcept {
    return pmf_ ? &pmf_->normalization_delta() : nullptr;
  }

 private:
  ActionLaw(std::vector<ActionLawAtomV1> atoms,
            std::optional<NormalizedPmf> pmf,
            PreparedActionSamplerV1 sampler)
      : atoms_(std::move(atoms)),
        pmf_(std::move(pmf)),
        sampler_(std::move(sampler)) {}

  std::vector<ActionLawAtomV1> atoms_;
  std::optional<NormalizedPmf> pmf_;
  PreparedActionSamplerV1 sampler_;

  friend class detail::C17CoreAccess;
};

}  // namespace mwperf
