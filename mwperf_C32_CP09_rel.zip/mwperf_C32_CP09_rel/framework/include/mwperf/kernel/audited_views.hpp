#pragma once

#include <cstdint>
#include <memory>
#include <utility>

#include "mwperf/kernel/marked_kernel_row.hpp"
#include "mwperf/kernel/v0_witness.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
class C18CoreAccess;
class C19CoreAccess;
class C20CoreAccess;
class C23CoreAccess;
}

namespace kernel::detail {
class C17TemporalBridgeAccess;
}

namespace surrogate::detail {
class SealedFrameworkCore;
}

namespace stationary::detail {
struct AuditedScalarResponseCarrierCore;
struct AuditedPhaseResponseCarrierCore;
struct AuditedFixedPointCarrierCore;
struct StationaryProjectionSourceCore;
}

namespace metrics::detail {
struct TemporalSourceCore;
}

namespace sampling::detail {
class C24CoreAccess;
struct ExactInnovationCore;
struct TargetRatioCore;
}

#if defined(MWPERF_C22_TEST_SEAMS)
namespace testing {
class C22FixtureAccess;
}
#endif

enum class AuditedTemporalSourceKindV1 : std::uint8_t {
  framework_v0,
  stationary_projection,
  transient_dispatch,
  passive_fifo_tag,
};

class AuditedInitialMapper final {
 public:
  AuditedInitialMapper() = delete;
  AuditedInitialMapper(const AuditedInitialMapper&) = default;
  AuditedInitialMapper(AuditedInitialMapper&&) noexcept = default;
  AuditedInitialMapper& operator=(const AuditedInitialMapper&) = default;
  AuditedInitialMapper& operator=(AuditedInitialMapper&&) noexcept = default;

 private:
  explicit AuditedInitialMapper(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
};

class AuditedRowProvider final {
 public:
  AuditedRowProvider() = delete;
  AuditedRowProvider(const AuditedRowProvider&) = default;
  AuditedRowProvider(AuditedRowProvider&&) noexcept = default;
  AuditedRowProvider& operator=(const AuditedRowProvider&) = default;
  AuditedRowProvider& operator=(AuditedRowProvider&&) noexcept = default;

 private:
  explicit AuditedRowProvider(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
  friend class detail::C18CoreAccess;
};

class AuditedSlotExecutor final {
 public:
  AuditedSlotExecutor() = delete;
  AuditedSlotExecutor(const AuditedSlotExecutor&) = default;
  AuditedSlotExecutor(AuditedSlotExecutor&&) noexcept = default;
  AuditedSlotExecutor& operator=(const AuditedSlotExecutor&) = default;
  AuditedSlotExecutor& operator=(AuditedSlotExecutor&&) noexcept = default;

 private:
  explicit AuditedSlotExecutor(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
};

class AuditedResponseLaw final {
 public:
  AuditedResponseLaw() = delete;
  AuditedResponseLaw(const AuditedResponseLaw&) = default;
  AuditedResponseLaw(AuditedResponseLaw&&) noexcept = default;
  AuditedResponseLaw& operator=(const AuditedResponseLaw&) = default;
  AuditedResponseLaw& operator=(AuditedResponseLaw&&) noexcept = default;

 private:
  explicit AuditedResponseLaw(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}
  AuditedResponseLaw(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::AuditedScalarResponseCarrierCore>
          carrier)
      : core_(std::move(core)), c19_carrier_(std::move(carrier)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::AuditedScalarResponseCarrierCore>
      c19_carrier_;
  friend class detail::C17CoreAccess;
  friend class detail::C19CoreAccess;
};

class AuditedThreeBinResponse final {
 public:
  AuditedThreeBinResponse() = delete;
  AuditedThreeBinResponse(const AuditedThreeBinResponse&) = default;
  AuditedThreeBinResponse(AuditedThreeBinResponse&&) noexcept = default;
  AuditedThreeBinResponse& operator=(const AuditedThreeBinResponse&) = default;
  AuditedThreeBinResponse& operator=(AuditedThreeBinResponse&&) noexcept =
      default;

  // mu(0)=0, mu(1)=s1, mu(2)=s2, and mu(n)=c for n>=3.
  [[nodiscard]] Result<ExactRational> service_probability(
      const BigNat& target_backlog) const;

 private:
  explicit AuditedThreeBinResponse(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}
  AuditedThreeBinResponse(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::AuditedScalarResponseCarrierCore>
          carrier)
      : core_(std::move(core)), c19_carrier_(std::move(carrier)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::AuditedScalarResponseCarrierCore>
      c19_carrier_;
  friend class detail::C17CoreAccess;
  friend class detail::C19CoreAccess;
};

class AuditedFinitePrefixConstantTailResponse final {
 public:
  AuditedFinitePrefixConstantTailResponse() = delete;
  AuditedFinitePrefixConstantTailResponse(
      const AuditedFinitePrefixConstantTailResponse&) = default;
  AuditedFinitePrefixConstantTailResponse(
      AuditedFinitePrefixConstantTailResponse&&) noexcept = default;
  AuditedFinitePrefixConstantTailResponse& operator=(
      const AuditedFinitePrefixConstantTailResponse&) = default;
  AuditedFinitePrefixConstantTailResponse& operator=(
      AuditedFinitePrefixConstantTailResponse&&) noexcept = default;

  // mu(0)=0, mu(n)=s_n for 1<=n<=K, and mu(n)=c for n>=K+1.
  [[nodiscard]] Result<ExactRational> service_probability(
      const BigNat& target_backlog) const;

 private:
  explicit AuditedFinitePrefixConstantTailResponse(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
};

class AuditedPhaseResponse final {
 public:
  AuditedPhaseResponse() = delete;
  AuditedPhaseResponse(const AuditedPhaseResponse&) = default;
  AuditedPhaseResponse(AuditedPhaseResponse&&) noexcept = default;
  AuditedPhaseResponse& operator=(const AuditedPhaseResponse&) = default;
  AuditedPhaseResponse& operator=(AuditedPhaseResponse&&) noexcept = default;

 private:
  explicit AuditedPhaseResponse(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}
  AuditedPhaseResponse(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::AuditedPhaseResponseCarrierCore>
          carrier)
      : core_(std::move(core)), c19_carrier_(std::move(carrier)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::AuditedPhaseResponseCarrierCore>
      c19_carrier_;
  friend class detail::C17CoreAccess;
  friend class detail::C19CoreAccess;
};

class AuditedFixedPointFamily final {
 public:
  AuditedFixedPointFamily() = delete;
  AuditedFixedPointFamily(const AuditedFixedPointFamily&) = default;
  AuditedFixedPointFamily(AuditedFixedPointFamily&&) noexcept = default;
  AuditedFixedPointFamily& operator=(const AuditedFixedPointFamily&) = default;
  AuditedFixedPointFamily& operator=(AuditedFixedPointFamily&&) noexcept =
      default;

 private:
  explicit AuditedFixedPointFamily(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}
  AuditedFixedPointFamily(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const stationary::detail::AuditedFixedPointCarrierCore>
          carrier)
      : core_(std::move(core)), c19_carrier_(std::move(carrier)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::AuditedFixedPointCarrierCore>
      c19_carrier_;
  friend class detail::C17CoreAccess;
  friend class detail::C19CoreAccess;
};

// The seal-bound C20 ROMR bridge.  Its operations remain opaque until C20
// installs them in a cursor that can enforce entry-domain, offset, edge, and
// seal identity.  For a composed three-bin route those operations are the
// framework-owned unit residence; otherwise they are the already V0-audited
// event operations retained by the same seal.  Row enumeration and slot
// realization remain separate powers of AuditedRowProvider and
// AuditedSlotExecutor.
class AuditedRomrView final {
 public:
  AuditedRomrView() = delete;
  AuditedRomrView(const AuditedRomrView&) = default;
  AuditedRomrView(AuditedRomrView&&) noexcept = default;
  AuditedRomrView& operator=(const AuditedRomrView&) = default;
  AuditedRomrView& operator=(AuditedRomrView&&) noexcept = default;

 private:
  explicit AuditedRomrView(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
};

// C20 consumes these two capability-preserving branches separately.  They
// carry no public raw callback or conversion to the root framework.
class AuditedResidenceProvider final {
 public:
  AuditedResidenceProvider() = delete;
  AuditedResidenceProvider(const AuditedResidenceProvider&) = default;
  AuditedResidenceProvider(AuditedResidenceProvider&&) noexcept = default;
  AuditedResidenceProvider& operator=(const AuditedResidenceProvider&) =
      default;
  AuditedResidenceProvider& operator=(AuditedResidenceProvider&&) noexcept =
      default;

 private:
  explicit AuditedResidenceProvider(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
};

class AuditedTemporalFramework final {
 public:
  AuditedTemporalFramework() = delete;
  AuditedTemporalFramework(const AuditedTemporalFramework&) = default;
  AuditedTemporalFramework(AuditedTemporalFramework&&) noexcept = default;
  AuditedTemporalFramework& operator=(const AuditedTemporalFramework&) =
      default;
  AuditedTemporalFramework& operator=(AuditedTemporalFramework&&) noexcept =
      default;

 private:
  explicit AuditedTemporalFramework(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
};

// These stationary restrictions remain opaque until C21 supplies the
// matching invariant law, positive finite residence mean, and projection
// identity.  Their private binding cannot be minted from the root alone.
class AuditedCylinderLaw final {
 public:
  AuditedCylinderLaw() = delete;
  AuditedCylinderLaw(const AuditedCylinderLaw&) = default;
  AuditedCylinderLaw(AuditedCylinderLaw&&) noexcept = default;
  AuditedCylinderLaw& operator=(const AuditedCylinderLaw&) = default;
  AuditedCylinderLaw& operator=(AuditedCylinderLaw&&) noexcept = default;

  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept {
    return projection_binding_;
  }
  [[nodiscard]] AuditedTemporalSourceKindV1 source_kind() const noexcept {
    return source_kind_;
  }
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept {
    return source_fingerprint_;
  }

 private:
  AuditedCylinderLaw(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      AuditedTemporalSourceKindV1 source_kind,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 source_fingerprint, Digest256 projection_binding)
      : core_(std::move(core)),
        temporal_source_(std::move(temporal_source)),
        source_kind_(source_kind),
        source_fingerprint_(std::move(source_fingerprint)),
        projection_binding_(std::move(projection_binding)) {}
  AuditedCylinderLaw(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::StationaryProjectionSourceCore>
          stationary_source,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 source_fingerprint, Digest256 projection_binding)
      : core_(std::move(core)),
        stationary_source_(std::move(stationary_source)),
        temporal_source_(std::move(temporal_source)),
        source_kind_(AuditedTemporalSourceKindV1::stationary_projection),
        source_fingerprint_(std::move(source_fingerprint)),
        projection_binding_(std::move(projection_binding)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      stationary_source_;
  std::shared_ptr<const metrics::detail::TemporalSourceCore> temporal_source_;
  AuditedTemporalSourceKindV1 source_kind_;
  Digest256 source_fingerprint_;
  Digest256 projection_binding_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
  friend class kernel::detail::C17TemporalBridgeAccess;
#if defined(MWPERF_C22_TEST_SEAMS)
  friend class testing::C22FixtureAccess;
#endif
};

class AuditedTemporalKernel final {
 public:
  AuditedTemporalKernel() = delete;
  AuditedTemporalKernel(const AuditedTemporalKernel&) = default;
  AuditedTemporalKernel(AuditedTemporalKernel&&) noexcept = default;
  AuditedTemporalKernel& operator=(const AuditedTemporalKernel&) = default;
  AuditedTemporalKernel& operator=(AuditedTemporalKernel&&) noexcept =
      default;

  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept {
    return projection_binding_;
  }
  [[nodiscard]] AuditedTemporalSourceKindV1 source_kind() const noexcept {
    return source_kind_;
  }
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept {
    return source_fingerprint_;
  }

 private:
  AuditedTemporalKernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      AuditedTemporalSourceKindV1 source_kind,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 source_fingerprint, Digest256 projection_binding)
      : core_(std::move(core)),
        temporal_source_(std::move(temporal_source)),
        source_kind_(source_kind),
        source_fingerprint_(std::move(source_fingerprint)),
        projection_binding_(std::move(projection_binding)) {}
  AuditedTemporalKernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::StationaryProjectionSourceCore>
          stationary_source,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 source_fingerprint, Digest256 projection_binding)
      : core_(std::move(core)),
        stationary_source_(std::move(stationary_source)),
        temporal_source_(std::move(temporal_source)),
        source_kind_(AuditedTemporalSourceKindV1::stationary_projection),
        source_fingerprint_(std::move(source_fingerprint)),
        projection_binding_(std::move(projection_binding)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      stationary_source_;
  std::shared_ptr<const metrics::detail::TemporalSourceCore> temporal_source_;
  AuditedTemporalSourceKindV1 source_kind_;
  Digest256 source_fingerprint_;
  Digest256 projection_binding_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
  friend class detail::C23CoreAccess;
  friend class kernel::detail::C17TemporalBridgeAccess;
#if defined(MWPERF_C22_TEST_SEAMS)
  friend class testing::C22FixtureAccess;
#endif
};

class AuditedTemporalLaw final {
 public:
  AuditedTemporalLaw() = delete;
  AuditedTemporalLaw(const AuditedTemporalLaw&) = default;
  AuditedTemporalLaw(AuditedTemporalLaw&&) noexcept = default;
  AuditedTemporalLaw& operator=(const AuditedTemporalLaw&) = default;
  AuditedTemporalLaw& operator=(AuditedTemporalLaw&&) noexcept = default;

  [[nodiscard]] const Digest256& projection_fingerprint() const noexcept {
    return projection_binding_;
  }
  [[nodiscard]] AuditedTemporalSourceKindV1 source_kind() const noexcept {
    return source_kind_;
  }
  [[nodiscard]] const Digest256& source_fingerprint() const noexcept {
    return source_fingerprint_;
  }

 private:
  AuditedTemporalLaw(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      AuditedTemporalSourceKindV1 source_kind,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 source_fingerprint, Digest256 projection_binding)
      : core_(std::move(core)),
        temporal_source_(std::move(temporal_source)),
        source_kind_(source_kind),
        source_fingerprint_(std::move(source_fingerprint)),
        projection_binding_(std::move(projection_binding)) {}
  AuditedTemporalLaw(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      std::shared_ptr<const
                      stationary::detail::StationaryProjectionSourceCore>
          stationary_source,
      std::shared_ptr<const metrics::detail::TemporalSourceCore>
          temporal_source,
      Digest256 source_fingerprint, Digest256 projection_binding)
      : core_(std::move(core)),
        stationary_source_(std::move(stationary_source)),
        temporal_source_(std::move(temporal_source)),
        source_kind_(AuditedTemporalSourceKindV1::stationary_projection),
        source_fingerprint_(std::move(source_fingerprint)),
        projection_binding_(std::move(projection_binding)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  std::shared_ptr<const stationary::detail::StationaryProjectionSourceCore>
      stationary_source_;
  std::shared_ptr<const metrics::detail::TemporalSourceCore> temporal_source_;
  AuditedTemporalSourceKindV1 source_kind_;
  Digest256 source_fingerprint_;
  Digest256 projection_binding_;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
  friend class kernel::detail::C17TemporalBridgeAccess;
#if defined(MWPERF_C22_TEST_SEAMS)
  friend class testing::C22FixtureAccess;
#endif
};

class AuditedSamplerDescriptor final {
 public:
  AuditedSamplerDescriptor() = delete;
  AuditedSamplerDescriptor(const AuditedSamplerDescriptor&) = default;
  AuditedSamplerDescriptor(AuditedSamplerDescriptor&&) noexcept = default;
  AuditedSamplerDescriptor& operator=(const AuditedSamplerDescriptor&) =
      default;
  AuditedSamplerDescriptor& operator=(AuditedSamplerDescriptor&&) noexcept =
      default;

 private:
  explicit AuditedSamplerDescriptor(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core)
      : core_(std::move(core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  friend class detail::C17CoreAccess;
  friend class sampling::detail::C24CoreAccess;
};

// Optional sampling views need bindings not defined until C24.  Declaring
// them here does not make them available: no public root-only issuer exists.
class AuditedExactInnovationKernel final {
 public:
  AuditedExactInnovationKernel() = delete;
  AuditedExactInnovationKernel(const AuditedExactInnovationKernel&) = default;
  AuditedExactInnovationKernel(AuditedExactInnovationKernel&&) noexcept =
      default;
  AuditedExactInnovationKernel& operator=(
      const AuditedExactInnovationKernel&) = default;
  AuditedExactInnovationKernel& operator=(
      AuditedExactInnovationKernel&&) noexcept = default;

 private:
  AuditedExactInnovationKernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      Digest256 representation_binding)
      : core_(std::move(core)),
        representation_binding_(std::move(representation_binding)) {}
  AuditedExactInnovationKernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      Digest256 representation_binding,
      std::shared_ptr<const sampling::detail::ExactInnovationCore>
          sampling_core)
      : core_(std::move(core)),
        representation_binding_(std::move(representation_binding)),
        sampling_core_(std::move(sampling_core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  Digest256 representation_binding_;
  std::shared_ptr<const sampling::detail::ExactInnovationCore>
      sampling_core_;
  friend class detail::C17CoreAccess;
  friend class sampling::detail::C24CoreAccess;
};

class AuditedTargetDensityRatio final {
 public:
  AuditedTargetDensityRatio() = delete;
  AuditedTargetDensityRatio(const AuditedTargetDensityRatio&) = default;
  AuditedTargetDensityRatio(AuditedTargetDensityRatio&&) noexcept = default;
  AuditedTargetDensityRatio& operator=(const AuditedTargetDensityRatio&) =
      default;
  AuditedTargetDensityRatio& operator=(AuditedTargetDensityRatio&&) noexcept =
      default;

 private:
  AuditedTargetDensityRatio(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      Digest256 plan_binding)
      : core_(std::move(core)), plan_binding_(std::move(plan_binding)) {}
  AuditedTargetDensityRatio(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      Digest256 plan_binding,
      std::shared_ptr<const sampling::detail::TargetRatioCore> sampling_core)
      : core_(std::move(core)),
        plan_binding_(std::move(plan_binding)),
        sampling_core_(std::move(sampling_core)) {}

  std::shared_ptr<surrogate::detail::SealedFrameworkCore> core_;
  Digest256 plan_binding_;
  std::shared_ptr<const sampling::detail::TargetRatioCore> sampling_core_;
  friend class detail::C17CoreAccess;
  friend class sampling::detail::C24CoreAccess;
};

[[nodiscard]] Result<AuditedInitialMapper> audited_initial_mapper(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedRowProvider> audited_row_provider(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedSlotExecutor> audited_slot_executor(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedResponseLaw> audited_response_law(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedThreeBinResponse> audited_three_bin_response(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedFinitePrefixConstantTailResponse>
audited_finite_prefix_constant_tail_response(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedPhaseResponse> audited_phase_response(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedFixedPointFamily> audited_fixed_point_family(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedRomrView> audited_romr_view(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedResidenceProvider> audited_residence_provider(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedTemporalFramework> audited_temporal_framework(
    const AuditedCompiledFramework& framework);
[[nodiscard]] Result<AuditedSamplerDescriptor> audited_sampler_descriptor(
    const AuditedCompiledFramework& framework);

// The only public restrictions between C17 views.  They retain the same core
// and cannot recover or broaden to AuditedCompiledFramework.
[[nodiscard]] Result<AuditedRowProvider> audited_row_provider(
    const AuditedResidenceProvider& provider);
[[nodiscard]] Result<AuditedRomrView> audited_romr_view(
    const AuditedResidenceProvider& provider);
[[nodiscard]] Result<AuditedSlotExecutor> audited_slot_executor(
    const AuditedTemporalFramework& framework);
[[nodiscard]] Result<AuditedRomrView> audited_romr_view(
    const AuditedTemporalFramework& framework);

[[nodiscard]] Result<DirectMetricAccess> audited_direct_metric_access(
    const AuditedCompiledFramework& framework);
[[nodiscard]] const V0WitnessReport& v0_witness_report(
    const AuditedCompiledFramework& framework);

}  // namespace mwperf
