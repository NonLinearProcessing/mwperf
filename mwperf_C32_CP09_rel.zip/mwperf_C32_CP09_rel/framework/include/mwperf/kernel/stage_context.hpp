#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/kernel/target_backlog.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/reduction/opportunity.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/reduced_initial_law.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
}

// The order is the factorization in (8.2a), not a logging convention.
enum class CausalStageV1 : std::uint8_t {
  c_minus,
  resolver,
  arrival,
  c_plus,
  psi,
};

inline constexpr std::array<CausalStageV1, 5U> kCausalStageOrderV1{
    CausalStageV1::c_minus, CausalStageV1::resolver,
    CausalStageV1::arrival, CausalStageV1::c_plus,
    CausalStageV1::psi};

// Canonical atom-path identity for one branch of a composed row.  It is
// independent of callback addresses and retained on every realized record.
struct CausalBranchIdentityV1 final {
  Digest256 state_identity;
  std::vector<std::size_t> atom_path;

  friend bool operator==(const CausalBranchIdentityV1&,
                         const CausalBranchIdentityV1&) = default;
};

struct StageMassDiagnosticV1 final {
  CausalStageV1 stage;
  CausalBranchIdentityV1 upstream_branch;
  std::vector<ExactRational> raw_masses;
  std::vector<std::uint8_t> structural_support;
  ExactRational raw_sum;
  ExactRational signed_delta_from_one;

  friend bool operator==(const StageMassDiagnosticV1&,
                         const StageMassDiagnosticV1&) = default;
};

[[nodiscard]] bool same_exact_opportunity_evidence(
    const std::optional<Opportunity>& left,
    const std::optional<Opportunity>& right);

// A C-minus outcome contains only pre-arrival information.  In particular,
// no ArrivalTransition or arrival-use capability is nameable from this type.
struct OpportunityMark final {
  CausalBranchIdentityV1 branch;
  // The closed/program composer always supplies this exact coordinate. A raw
  // C16 sampler-only preparer cannot decode opaque ReducedStateV1 and leaves
  // it absent; F-C17-02 rejects such a law rather than guessing.
  std::optional<TargetBacklogV1> prearrival_backlog;
  // The V0 execution datum.  Generic bound-operation programs must carry a
  // finite common schedule face; only the closed ThreeBin adapter may omit
  // it and use its private singleton forced-class action adapter.
  std::optional<V0EmittedOpportunityFaceV1> resolver_face;
  // Optional stronger C13/full-physical witness.  It may corroborate a
  // singleton emitted face but is never required or replayed by V0.
  std::optional<Opportunity> exact_opportunity_evidence;
  CanonicalRuntimeValueV1 opportunity;
  std::vector<RuntimeDecodedMarkV1> marks;

  friend bool operator==(const OpportunityMark& left,
                         const OpportunityMark& right) {
    return left.branch == right.branch &&
           left.prearrival_backlog == right.prearrival_backlog &&
           left.resolver_face == right.resolver_face &&
           same_exact_opportunity_evidence(
               left.exact_opportunity_evidence,
               right.exact_opportunity_evidence) &&
           left.opportunity == right.opportunity &&
           left.marks == right.marks;
  }
};

[[nodiscard]] inline bool same_exact_opportunity_evidence(
    const std::optional<Opportunity>& left,
    const std::optional<Opportunity>& right) {
  if (left.has_value() != right.has_value()) {
    return false;
  }
  if (!left) {
    return true;
  }
  return left->target() == right->target() &&
         left->evaluation_backlog() == right->evaluation_backlog() &&
         left->certificate_digest() == right->certificate_digest() &&
         left->psi0() == right->psi0() && left->psi1() == right->psi1() &&
         left->theta() == right->theta() &&
         left->margin() == right->margin() &&
         left->cross_class_outcome() == right->cross_class_outcome() &&
         left->equality_winner_if_qe_eq_theta() ==
             right->equality_winner_if_qe_eq_theta() &&
         left->forced_out_certificate() == right->forced_out_certificate() &&
         left->forced_in_certificate() == right->forced_in_certificate();
}

struct OpportunityLawAtomV1 final {
  OpportunityMark outcome;
  ExactRational raw_mass;
  bool structural_support;

  friend bool operator==(const OpportunityLawAtomV1&,
                         const OpportunityLawAtomV1&) = default;
};

using PreparedOpportunitySamplerV1 =
    std::function<Result<OpportunityMark>(DeterministicRng&)>;
using PreparedOpportunityEnumeratorV1 = std::function<
    Result<std::vector<OpportunityLawAtomV1>>() >;

class PreArrivalContext final {
 public:
  [[nodiscard]] const ReducedStateV1& state() const noexcept {
    return *state_;
  }
  [[nodiscard]] const CausalBranchIdentityV1& branch() const noexcept {
    return branch_;
  }

 private:
  PreArrivalContext(const ReducedStateV1& state,
                    CausalBranchIdentityV1 branch)
      : state_(&state), branch_(std::move(branch)) {}

  const ReducedStateV1* state_;
  CausalBranchIdentityV1 branch_;

  friend class detail::C17CoreAccess;
};

class ResolverContext final {
 public:
  [[nodiscard]] const ReducedStateV1& state() const noexcept {
    return *state_;
  }
  [[nodiscard]] const OpportunityMark& opportunity() const noexcept {
    return *opportunity_;
  }

 private:
  ResolverContext(const ReducedStateV1& state,
                  const OpportunityMark& opportunity)
      : state_(&state), opportunity_(&opportunity) {}

  const ReducedStateV1* state_;
  const OpportunityMark* opportunity_;

  friend class detail::C17CoreAccess;
};

// Opaque prepared conditional law.  Its public surface deliberately has no
// enumerate or sample operation; only the audit/seal composer has atom access.
class OpportunityLaw final {
 public:
  OpportunityLaw() = delete;
  OpportunityLaw(const OpportunityLaw&) = default;
  OpportunityLaw(OpportunityLaw&&) noexcept = default;
  OpportunityLaw& operator=(const OpportunityLaw&) = default;
  OpportunityLaw& operator=(OpportunityLaw&&) noexcept = default;

  [[nodiscard]] std::size_t support_size() const noexcept {
    return atoms_.size();
  }
  [[nodiscard]] bool enumerable() const noexcept {
    return state_ == State::prepared
               ? static_cast<bool>(enumerator_)
               : pmf_.has_value();
  }
  [[nodiscard]] bool realizable() const noexcept {
    return state_ == State::prepared
               ? static_cast<bool>(enumerator_) ||
                     static_cast<bool>(sampler_)
               : pmf_.has_value();
  }
  [[nodiscard]] const ExactRational* raw_sum() const noexcept {
    return pmf_ ? &pmf_->authored_sum() : nullptr;
  }
  [[nodiscard]] const ExactRational* signed_delta_from_one() const noexcept {
    return pmf_ ? &pmf_->normalization_delta() : nullptr;
  }

 private:
  enum class State : std::uint8_t {
    prepared,
    applied,
  };

  OpportunityLaw(PreparedOpportunityEnumeratorV1 enumerator,
                 PreparedOpportunitySamplerV1 sampler)
      : state_(State::prepared),
        atoms_(),
        pmf_(std::nullopt),
        enumerator_(std::move(enumerator)),
        sampler_(std::move(sampler)) {}

  OpportunityLaw(std::vector<OpportunityLawAtomV1> atoms,
                 NormalizedPmf pmf)
      : state_(State::applied),
        atoms_(std::move(atoms)),
        pmf_(std::move(pmf)),
        enumerator_(),
        sampler_() {}

  State state_;
  std::vector<OpportunityLawAtomV1> atoms_;
  std::optional<NormalizedPmf> pmf_;
  PreparedOpportunityEnumeratorV1 enumerator_;
  PreparedOpportunitySamplerV1 sampler_;

  friend class detail::C17CoreAccess;
};

}  // namespace mwperf
