#pragma once

#include <algorithm>
#include <cstddef>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// Exact N_T coordinates in the semantic target order.  Every TargetIndex is
// bound to the same resolved physical instance, while the values remain
// target-projected rather than padded to the physical queue cardinality.
class TargetBacklogV1 final {
 public:
  TargetBacklogV1() = delete;
  TargetBacklogV1(const TargetBacklogV1&) = default;
  TargetBacklogV1(TargetBacklogV1&&) noexcept = default;
  TargetBacklogV1& operator=(const TargetBacklogV1&) = default;
  TargetBacklogV1& operator=(TargetBacklogV1&&) noexcept = default;

  [[nodiscard]] static Result<TargetBacklogV1> from_values(
      const ResolvedInstance& instance,
      const std::span<const QueueId> ordered_target_ids,
      std::vector<BigNat> values) {
    if (ordered_target_ids.size() != values.size()) {
      return Result<TargetBacklogV1>::failure(Diagnostic{
          .category = DiagnosticCategory::input_validation,
          .code = "c17.target_backlog_cardinality_mismatch",
          .message = "target backlog values do not match the ordered target "
                     "coordinates",
          .authored_path = std::nullopt,
          .json_pointer = std::nullopt,
          .notes = {"expected " + std::to_string(ordered_target_ids.size()) +
                    " values; received " + std::to_string(values.size())},
      });
    }

    std::vector<TargetIndex> ordered_targets;
    ordered_targets.reserve(ordered_target_ids.size());
    const auto entries = instance.queues().entries();
    for (std::size_t target_ordinal = 0;
         target_ordinal < ordered_target_ids.size(); ++target_ordinal) {
      const QueueId& target_id = ordered_target_ids[target_ordinal];
      if (std::find(ordered_target_ids.begin(),
                    ordered_target_ids.begin() + target_ordinal,
                    target_id) !=
          ordered_target_ids.begin() + target_ordinal) {
        return Result<TargetBacklogV1>::failure(Diagnostic{
            .category = DiagnosticCategory::input_validation,
            .code = "c17.target_backlog_duplicate_target",
            .message = "target backlog coordinates contain a duplicate "
                       "target identity",
            .authored_path = std::nullopt,
            .json_pointer = std::nullopt,
            .notes = {"duplicate target at ordered position " +
                      std::to_string(target_ordinal)},
        });
      }

      std::optional<std::size_t> physical_ordinal;
      for (std::size_t queue = 0; queue < entries.size(); ++queue) {
        if (entries[queue].id == target_id) {
          physical_ordinal = queue;
          break;
        }
      }
      if (!physical_ordinal.has_value()) {
        return Result<TargetBacklogV1>::failure(Diagnostic{
            .category = DiagnosticCategory::input_validation,
            .code = "c17.target_backlog_unknown_target",
            .message = "a target backlog coordinate is not present in the "
                       "resolved instance",
            .authored_path = std::nullopt,
            .json_pointer = std::nullopt,
            .notes = {"unknown target at ordered position " +
                      std::to_string(target_ordinal)},
        });
      }
      auto target_index =
          TargetIndex::from_instance(instance, *physical_ordinal);
      if (!target_index) {
        return Result<TargetBacklogV1>::failure(target_index.error());
      }
      ordered_targets.push_back(std::move(target_index).value());
    }

    return Result<TargetBacklogV1>::success(TargetBacklogV1(
        QueueDimensionToken::from_instance(instance),
        std::move(ordered_targets), std::move(values)));
  }

  [[nodiscard]] bool matches(const ResolvedInstance& instance) const {
    return instance_binding_.matches(instance);
  }
  [[nodiscard]] bool has_target_order(
      const std::span<const TargetIndex> ordered_targets) const noexcept {
    return std::equal(ordered_targets_.begin(), ordered_targets_.end(),
                      ordered_targets.begin(), ordered_targets.end());
  }
  [[nodiscard]] bool matches_full_backlog_projection(
      const Backlog& full_backlog) const {
    if (!(full_backlog.dimension() == instance_binding_)) {
      return false;
    }
    for (std::size_t target_ordinal = 0;
         target_ordinal < ordered_targets_.size(); ++target_ordinal) {
      if (!(values_[target_ordinal] ==
            full_backlog.values()[ordered_targets_[target_ordinal]
                                      .ordinal()])) {
        return false;
      }
    }
    return true;
  }
  [[nodiscard]] Result<TargetBacklogV1> with_values(
      std::vector<BigNat> values) const {
    if (values.size() != ordered_targets_.size()) {
      return Result<TargetBacklogV1>::failure(Diagnostic{
          .category = DiagnosticCategory::input_validation,
          .code = "c17.target_backlog_cardinality_mismatch",
          .message = "successor target backlog values do not match the "
                     "ordered target coordinates",
          .authored_path = std::nullopt,
          .json_pointer = std::nullopt,
          .notes = {"expected " + std::to_string(ordered_targets_.size()) +
                    " values; received " + std::to_string(values.size())},
      });
    }
    return Result<TargetBacklogV1>::success(TargetBacklogV1(
        instance_binding_, ordered_targets_, std::move(values)));
  }
  [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
  [[nodiscard]] std::span<const TargetIndex> ordered_targets() const noexcept {
    return ordered_targets_;
  }
  [[nodiscard]] std::span<const BigNat> values() const noexcept {
    return values_;
  }
  [[nodiscard]] const TargetIndex& target_at_target_ordinal(
      const std::size_t target_ordinal) const {
    return ordered_targets_.at(target_ordinal);
  }
  [[nodiscard]] const BigNat& value_at_target_ordinal(
      const std::size_t target_ordinal) const {
    return values_.at(target_ordinal);
  }

  friend bool operator==(const TargetBacklogV1&,
                         const TargetBacklogV1&) = default;

 private:
  TargetBacklogV1(QueueDimensionToken instance_binding,
                  std::vector<TargetIndex> ordered_targets,
                  std::vector<BigNat> values)
      : instance_binding_(std::move(instance_binding)),
        ordered_targets_(std::move(ordered_targets)),
        values_(std::move(values)) {}

  QueueDimensionToken instance_binding_;
  std::vector<TargetIndex> ordered_targets_;
  std::vector<BigNat> values_;
};

}  // namespace mwperf
