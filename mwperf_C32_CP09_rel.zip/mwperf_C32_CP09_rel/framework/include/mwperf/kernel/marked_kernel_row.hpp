#pragma once

#include <cstddef>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/kernel/reduced_edge.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
}

enum class NumericalProbabilityImageStatusV1 : std::uint8_t {
  finite,
  positive_underflow,
  overflow,
};

// A descriptive long-double image of the final exact unit row.  The total is
// a compensated sum of the direct per-atom images, and the signed residual is
// exactly compensated_total - 1.0L.  Neither field is a normalization input.
struct CompensatedNumericalRowImageV1 final {
  long double compensated_total;
  long double signed_residual_from_one;
  NumericalProbabilityImageStatusV1 status;

  friend bool operator==(const CompensatedNumericalRowImageV1&,
                         const CompensatedNumericalRowImageV1&) = default;
};

struct MarkedKernelRowAtomV1 final {
  CompletedReducedEdge edge;
  ExactRational exact_mass;
  bool structural_support;
  // Derived only after exact aggregation; never used as a transition weight.
  long double numerical_image;
  NumericalProbabilityImageStatusV1 numerical_image_status;
  ExactRational exact_cumulative_mass;
};

// C02-compatible categorical integers derived directly from a final exact
// unit-mass row.  Construction verifies the common denominator representation
// but performs no scaling by a row sum.
struct ExactCategoricalImageV1 final {
  BigNat integral_denominator;
  std::vector<BigNat> integral_masses;
  std::vector<BigNat> cumulative_masses;
  std::size_t sampling_bit_width;

  friend bool operator==(const ExactCategoricalImageV1&,
                         const ExactCategoricalImageV1&) = default;
};

// One immutable exact row.  exact_cumulative_mass is the categorical
// representation built directly from the already-unit exact branch masses;
// the final row is never passed through a second normalization.
class MarkedKernelRow final {
 public:
  MarkedKernelRow() = delete;
  MarkedKernelRow(const MarkedKernelRow&) = default;
  MarkedKernelRow(MarkedKernelRow&&) noexcept = default;
  MarkedKernelRow& operator=(const MarkedKernelRow&) = default;
  MarkedKernelRow& operator=(MarkedKernelRow&&) noexcept = default;

  [[nodiscard]] std::span<const MarkedKernelRowAtomV1> atoms() const noexcept {
    return atoms_;
  }
  [[nodiscard]] const ExactRational& exact_total_mass() const noexcept {
    return exact_total_mass_;
  }
  [[nodiscard]] std::span<const StageMassDiagnosticV1>
  stage_mass_diagnostics() const noexcept {
    return stage_mass_diagnostics_;
  }
  [[nodiscard]] const ExactCategoricalImageV1& categorical() const noexcept {
    return categorical_;
  }
  [[nodiscard]] const CompensatedNumericalRowImageV1&
  numerical_row_image() const noexcept {
    return numerical_row_image_;
  }
 private:
  MarkedKernelRow(std::vector<MarkedKernelRowAtomV1> atoms,
                  ExactRational exact_total_mass,
                  std::vector<StageMassDiagnosticV1> stage_mass_diagnostics,
                  ExactCategoricalImageV1 categorical,
                  CompensatedNumericalRowImageV1 numerical_row_image)
      : atoms_(std::move(atoms)),
        exact_total_mass_(std::move(exact_total_mass)),
        stage_mass_diagnostics_(std::move(stage_mass_diagnostics)),
        categorical_(std::move(categorical)),
        numerical_row_image_(std::move(numerical_row_image)) {}

  std::vector<MarkedKernelRowAtomV1> atoms_;
  ExactRational exact_total_mass_;
  std::vector<StageMassDiagnosticV1> stage_mass_diagnostics_;
  ExactCategoricalImageV1 categorical_;
  CompensatedNumericalRowImageV1 numerical_row_image_;

  friend class detail::C17CoreAccess;
};

}  // namespace mwperf
