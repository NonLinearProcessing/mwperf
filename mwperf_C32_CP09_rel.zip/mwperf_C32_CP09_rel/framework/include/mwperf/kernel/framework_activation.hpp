#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <utility>
#include <vector>

#include "mwperf/kernel/audited_views.hpp"
#include "mwperf/kernel/marked_kernel_row.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/surrogate/plug_contract.hpp"

namespace mwperf {

class C17AuditedFrameworkMint;
class DirectMetricCompositeCandidateV1;

enum class ExactCausalProgramModeV1 : std::uint8_t {
  generic_bound_operations,
  closed_three_bin_scalar,
  bound_direct_decoder,
  // The K-wide response has the same singleton scalar causal mechanics as
  // the closed three-bin adapter, but retains a distinct program identity so
  // a native finite-prefix response cannot be mistaken for its K=2
  // compatibility fold.
  closed_finite_prefix_constant_tail_scalar,
};

[[nodiscard]] constexpr bool closed_scalar_response_mode_v1(
    const ExactCausalProgramModeV1 mode) noexcept {
  return mode == ExactCausalProgramModeV1::closed_three_bin_scalar ||
         mode == ExactCausalProgramModeV1::
                     closed_finite_prefix_constant_tail_scalar;
}

// The physical slot is always retained by C09/C17 execution and by every
// completed edge.  The second alternative is a narrower, row-only authority:
// provider C-minus/C-plus callbacks receive the unique zero-clock
// representative with the same finite predictive phase and every other exact
// coordinate.  The framework-owned resolver remains bound to the raw branch
// identity and is structurally clock-blind.  C20 may use the quotient after a
// complete raw residence, while C18 may use it only for an accepted
// finite/sparse stationary marked-edge scalar route whose finite closure it
// independently verifies.  It is never an authority to reset a realized path
// or an RNG address.
enum class EventClockSemanticsV1 : std::uint8_t {
  absolute_physical_slot,
  finite_phase_time_homogeneous_quotient,
};

// Production causal authority is carried only by the moved C16 plug, the
// configured C05 resolver, and the bound C09 arrival law.  This record is
// callback-free so a candidate cannot substitute executable stage behavior.
struct ExactCausalProgramV1 final {
  ExactCausalProgramModeV1 mode;
  ExactRational conditional_row_tolerance;
  PmfRepresentationBudget representation_budget;
  std::vector<ReducedStateV1> reachable_audit_states;
  // A finite construction-time certificate for temporal enumeration.  An
  // absent value leaves realized execution available but cannot certify a
  // finite residence-word expansion.
  std::optional<std::size_t> maximum_residence_slots = std::nullopt;
  // A declared finite event-entry domain is distinct from the C17 probe set.
  // Absence denotes a countable/procedural entry domain: realized C20 paths
  // remain possible, but finite exact embedded-matrix assembly does not.
  std::optional<std::vector<ReducedStateV1>> finite_event_domain_states =
      std::nullopt;
  // For a countable/procedural event domain, this declaration binds event
  // membership to the sealed exact reduced-state domain validator.  It is
  // false when the event domain is a strict subset represented by the finite
  // certificate above.  C20 never guesses this equality from equal codecs.
  bool event_entry_domain_is_exact_state_domain = false;
  EventClockSemanticsV1 event_clock_semantics =
      EventClockSemanticsV1::absolute_physical_slot;
};

struct AuditedFrameworkSeedV1 final {
  AuditedFrameworkBindingsV1 bindings;
  TargetSelection target_selection;
  CodecIdentityV1 reduced_state_codec;
  SelectionSupportV1 selection_support;
  InitialSelectionAuthorityV1 initial_selection_authority;
  ReducedInitialMapperV1 initial_mapper;
  SealedExactStateSchemaValidatorV1 exact_state_schema_validator;
  SealedReducedStateDomainValidatorV1 reduced_state_domain_validator;
  SealedPhysicalAtomProjectionValidatorV1 physical_atom_projection_validator;
};

// The common C17 inputs carried by a direct-factor recipe deliberately omit
// both mutable optimizer authority and direct-decoder services.  The recipe
// is request-bound data produced by a registered activation; only the
// composite C17 audit may join it to the outer request's sole optimizer
// context.
struct OptimizerFreeFrameworkCandidateInputsV1 final {
  BuildIdentityDigest build_identity;
  Digest256 final_request_identity;
  ResolvedInstance instance;
  CompiledArrivalLaw configured_arrival;
  AcceptedCapabilityContract accepted_contract;
  RealizedMetricBindingsV1 realized_metric_bindings;
  ExactReducedStateSchemaV1 exact_state_schema;
  ExactCausalProgramV1 causal_program;
  AuditedFrameworkSeedV1 framework_seed;
};

// A fresh, unpublished causal-factor recipe.  Copying is forbidden so a
// provider activation cannot cache or replay a factor across requests.  The
// raw candidate is deliberately not promoted through C16's artifact mint:
// it is auxiliary request-local code registration, not a second provider
// result.  Only the composite C17 audit may inspect, validate, or execute it.
class RuntimeDirectFactorRecipeV1 final {
 public:
  RuntimeDirectFactorRecipeV1() = delete;
  RuntimeDirectFactorRecipeV1(const RuntimeDirectFactorRecipeV1&) = delete;
  RuntimeDirectFactorRecipeV1& operator=(
      const RuntimeDirectFactorRecipeV1&) = delete;
  RuntimeDirectFactorRecipeV1(RuntimeDirectFactorRecipeV1&&) noexcept =
      default;
  RuntimeDirectFactorRecipeV1& operator=(
      RuntimeDirectFactorRecipeV1&&) noexcept = default;

  RuntimeDirectFactorRecipeV1(
      RuntimePlugCandidateV1 raw_candidate,
      OptimizerFreeFrameworkCandidateInputsV1 inputs)
      : raw_candidate_(std::move(raw_candidate)),
        inputs_(std::move(inputs)) {}

 private:
  RuntimePlugCandidateV1 raw_candidate_;
  OptimizerFreeFrameworkCandidateInputsV1 inputs_;

  friend class C17AuditedFrameworkMint;
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
};

// Provider activation may supply only this fresh recipe and the exact direct
// request domain.  It cannot carry a pre-audited framework, executable row
// provider, optimizer context, or mutable ledger.
class RuntimeDirectMetricActivationV1 final {
 public:
  RuntimeDirectMetricActivationV1() = delete;
  RuntimeDirectMetricActivationV1(
      const RuntimeDirectMetricActivationV1&) = delete;
  RuntimeDirectMetricActivationV1& operator=(
      const RuntimeDirectMetricActivationV1&) = delete;
  RuntimeDirectMetricActivationV1(
      RuntimeDirectMetricActivationV1&&) noexcept = default;
  RuntimeDirectMetricActivationV1& operator=(
      RuntimeDirectMetricActivationV1&&) noexcept = default;

  RuntimeDirectMetricActivationV1(
      DirectMetricRequestDomainV1 domain,
      RuntimeDirectFactorRecipeV1 factor_recipe)
      : domain_(std::move(domain)),
        factor_recipe_(std::move(factor_recipe)) {}

 private:
  DirectMetricRequestDomainV1 domain_;
  RuntimeDirectFactorRecipeV1 factor_recipe_;

  friend class C17AuditedFrameworkMint;
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
};

}  // namespace mwperf
