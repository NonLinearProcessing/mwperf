#pragma once

#include <cstdint>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/core/sha256.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
}

enum class V0ObligationV1 : std::uint8_t {
  normalized_typed_laws,
  causal_factorization,
  configured_arrival_exactly_once,
  common_action_feasibility,
  empty_queue_eligibility,
  exact_sign_and_tie_resolution,
  exact_update_and_ownership,
  reduced_state_domain_closure,
  row_concatenation,
  requested_mark_observability,
  framework_unit_residence,
};

enum class V0EvidenceScopeV1 : std::uint8_t {
  not_applicable,
  exhaustive,
  reachable_enumerated,
  construction_enforced,
  declared,
};

struct V0WitnessEntryV1 final {
  V0ObligationV1 obligation;
  V0EvidenceScopeV1 evidence_scope;
  bool passed;
  std::vector<std::string> notes;

  friend bool operator==(const V0WitnessEntryV1&,
                         const V0WitnessEntryV1&) = default;
};

struct V0WitnessBindingsV1 final {
  Digest256 resolved_instance;
  Digest256 descriptor;
  Digest256 access;
  Digest256 ownership_schema;
  Digest256 exact_update_schema;

  friend bool operator==(const V0WitnessBindingsV1&,
                         const V0WitnessBindingsV1&) = default;
};

// This report intentionally has no V1/V2, fidelity, stability, moment, or
// approximation field.  Its truth value is exactly the conjunction of the
// applicable Definition 8.1 obligations above.
class V0WitnessReport final {
 public:
  V0WitnessReport() = delete;
  V0WitnessReport(const V0WitnessReport&) = default;
  V0WitnessReport(V0WitnessReport&&) noexcept = default;
  V0WitnessReport& operator=(const V0WitnessReport&) = default;
  V0WitnessReport& operator=(V0WitnessReport&&) noexcept = default;

  [[nodiscard]] bool passed() const noexcept { return passed_; }
  [[nodiscard]] const V0WitnessBindingsV1& bindings() const noexcept {
    return bindings_;
  }
  [[nodiscard]] std::span<const V0WitnessEntryV1> entries() const noexcept {
    return entries_;
  }

 private:
  V0WitnessReport(V0WitnessBindingsV1 bindings,
                  std::vector<V0WitnessEntryV1> entries, bool passed)
      : bindings_(std::move(bindings)),
        entries_(std::move(entries)),
        passed_(passed) {}

  V0WitnessBindingsV1 bindings_;
  std::vector<V0WitnessEntryV1> entries_;
  bool passed_;

  friend class detail::C17CoreAccess;
};

}  // namespace mwperf
