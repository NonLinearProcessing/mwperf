#pragma once

#include <span>

#include "mwperf/kernel/audited_framework_mint.hpp"
#include "mwperf/physical/slot_engine.hpp"

namespace mwperf {

namespace kernel::detail {
class C17TemporalBridgeAccess;
}

// F-C17-01
[[nodiscard]] Result<OpportunityLaw> prepare_prearrival_closure(
    const SurrogatePlug& plug, const ReducedStateV1& state);

// F-C17-02
[[nodiscard]] Result<ActionLaw> prepare_reduced_action_law(
    const ResolvedInstance& instance, const ReducedStateV1& state,
    const OpportunityMark& opportunity,
    OptimizerExecutionContext& optimizer_context);

// F-C17-03
[[nodiscard]] Result<ArrivalTransitionLaw> prepare_configured_arrival_law(
    const CompiledArrivalLaw& arrival, const ArrivalPhase& phase);

// F-C17-04
[[nodiscard]] Result<PostClosureLaw> prepare_postarrival_closure(
    const SurrogatePlug& plug, const ReducedStateV1& state,
    const OpportunityMark& opportunity, const ResolvedAction& action,
    const ArrivalTransition& arrival);

// F-C17-05
[[nodiscard]] Result<CompletedReducedEdge> apply_exact_reduced_update(
    ResolvedStateInputs inputs);

// F-C17-06
[[nodiscard]] Result<MarkedKernelRow> compile_reduced_kernel_row(
    const AuditedRowProvider& provider, const ReducedStateV1& state);

// F-C17-07
[[nodiscard]] Result<AuditedCompiledFramework> audit_v0_causality(
    CompiledFrameworkCandidate candidate, PlugDescriptor descriptor,
    KernelAccess access);

// Direct decoders require one fresh causal-factor candidate and one outer
// decoder candidate to cross V0 as a single transaction over the same
// execution-local optimizer ledger.  No factor core or callable escapes.
[[nodiscard]] Result<AuditedCompiledFramework> audit_v0_direct_composite(
    DirectMetricCompositeCandidateV1 candidate);

// F-C17-08
[[nodiscard]] Result<CompletedReducedEdge> execute_reduced_slot(
    const AuditedSlotExecutor& executor, const ReducedStateV1& state,
    RngBank& rng_bank);

#if defined(MWPERF_C17_TEST_SEAMS)
using EnumeratePreArrivalV1 = std::function<
    Result<std::vector<OpportunityLawAtomV1>>(const PreArrivalContext&)>;
using RealizePreArrivalV1 = std::function<Result<OpportunityMark>(
    const PreArrivalContext&, DeterministicRng&)>;
using EnumerateResolvedActionV1 = std::function<
    Result<std::vector<ActionLawAtomV1>>(const ResolverContext&,
                                         OptimizerExecutionContext&)>;
using RealizeResolvedActionV1 = std::function<Result<ResolvedAction>(
    const ResolverContext&, OptimizerExecutionContext&, DeterministicRng&)>;
using EnumeratePostArrivalV1 = std::function<
    Result<std::vector<PostClosureCandidateLawAtomV1>>(
        const PostArrivalContext&)>;
using RealizePostArrivalV1 = std::function<Result<PostClosureCandidateV1>(
    const PostArrivalContext&, DeterministicRng&)>;

struct C17GenericCallbackProgramV1 final {
  EnumeratePreArrivalV1 enumerate_prearrival;
  RealizePreArrivalV1 realize_prearrival;
  EnumerateResolvedActionV1 enumerate_action;
  RealizeResolvedActionV1 realize_action;
  EnumeratePostArrivalV1 enumerate_postarrival;
  RealizePostArrivalV1 realize_postarrival;
};

// Direct equation fixture for the five-stage generic composer. It contains
// exactly the mathematical execution inputs and none of the C14--C16 artifact
// scaffolding independently tested by those checkpoints.
struct C17GenericComposerFixtureV1 final {
  ResolvedInstance instance;
  CompiledArrivalLaw configured_arrival;
  ExactReducedStateSchemaV1 exact_state_schema;
  ExactCausalProgramV1 causal_program;
  C17GenericCallbackProgramV1 callbacks;
  OptimizerExecutionContext optimizer_context;
};
#endif

namespace detail {

// Private implementation bridge. Its operations are callable only by the
// eight catalog functions, the sole production mint, the two fixed audited
// view methods, and the separately linked C17 test seam.
class C17CoreAccess final {
 public:
  C17CoreAccess() = delete;

 private:
  [[nodiscard]] static PreArrivalContext prearrival_context(
      const ReducedStateV1& state, CausalBranchIdentityV1 branch);
  [[nodiscard]] static ResolverContext resolver_context(
      const ReducedStateV1& state, const OpportunityMark& opportunity);
  [[nodiscard]] static PostArrivalContext postarrival_context(
      const ReducedStateV1& state, const OpportunityMark& opportunity,
      const ResolvedAction& action, const ArrivalTransition& arrival);

  [[nodiscard]] static Result<OpportunityLaw> opportunity_law(
      std::vector<OpportunityLawAtomV1> atoms,
      const ExactRational& tolerance, PmfRepresentationBudget budget);
  [[nodiscard]] static OpportunityLaw prepared_opportunity_law(
      PreparedOpportunityEnumeratorV1 enumerator,
      PreparedOpportunitySamplerV1 sampler);
  [[nodiscard]] static Result<ActionLaw> action_law(
      std::vector<ActionLawAtomV1> atoms, const ExactRational& tolerance,
      PmfRepresentationBudget budget,
      PreparedActionSamplerV1 sampler = {});
  [[nodiscard]] static Result<ArrivalTransitionLaw> arrival_law(
      std::vector<ArrivalTransitionLawAtomV1> atoms,
      const ExactRational& tolerance, PmfRepresentationBudget budget);
  [[nodiscard]] static ArrivalTransitionLaw prepared_arrival_law(
      PreparedArrivalEnumeratorV1 enumerator,
      PreparedArrivalSamplerV1 sampler);
  [[nodiscard]] static Result<PostClosureLaw> postclosure_law(
      std::vector<PostClosureCandidateLawAtomV1> atoms,
      const PlugDescriptor& descriptor, const ExactRational& tolerance,
      PmfRepresentationBudget budget);
  [[nodiscard]] static PostClosureLaw prepared_postclosure_law(
      PreparedPostClosureEnumeratorV1 enumerator,
      PreparedPostClosureSamplerV1 sampler);
  [[nodiscard]] static ActionLaw action_sampler(
      PreparedActionSamplerV1 sampler);

  [[nodiscard]] static std::span<const OpportunityLawAtomV1> atoms(
      const OpportunityLaw& law) noexcept;
  [[nodiscard]] static std::span<const ActionLawAtomV1> atoms(
      const ActionLaw& law) noexcept;
  [[nodiscard]] static std::span<const ArrivalTransitionLawAtomV1> atoms(
      const ArrivalTransitionLaw& law) noexcept;
  [[nodiscard]] static std::span<const PostClosureLawAtomV1> atoms(
      const PostClosureLaw& law) noexcept;
  [[nodiscard]] static const NormalizedPmf* pmf(
      const OpportunityLaw& law) noexcept;
  [[nodiscard]] static const NormalizedPmf* pmf(
      const ActionLaw& law) noexcept;
  [[nodiscard]] static const NormalizedPmf* pmf(
      const ArrivalTransitionLaw& law) noexcept;
  [[nodiscard]] static const NormalizedPmf* pmf(
      const PostClosureLaw& law) noexcept;
  [[nodiscard]] static Result<OpportunityLaw>
  apply_opportunity_enumeration(
      const OpportunityLaw& law,
      const TargetBacklogV1& exact_prearrival_backlog,
      const ExactRational& tolerance, PmfRepresentationBudget budget);
  [[nodiscard]] static Result<OpportunityMark>
  apply_opportunity_realization(
      const OpportunityLaw& law,
      const TargetBacklogV1& exact_prearrival_backlog,
      DeterministicRng& rng, const ExactRational& tolerance,
      PmfRepresentationBudget budget);
  [[nodiscard]] static Result<ResolvedAction> realize(
      const ActionLaw& law, DeterministicRng& rng);
  [[nodiscard]] static Result<ArrivalTransitionLaw>
  apply_arrival_enumeration(
      const ArrivalTransitionLaw& law, ArrivalCapability capability,
      const ExactRational& tolerance, PmfRepresentationBudget budget);
  [[nodiscard]] static Result<ArrivalTransition> apply_arrival_realization(
      const ArrivalTransitionLaw& law, ArrivalCapability capability,
      DeterministicRng& rng, const ExactRational& tolerance,
      PmfRepresentationBudget budget);
  [[nodiscard]] static Result<PostClosureLaw>
  apply_postclosure_enumeration(
      const PostClosureLaw& law, const PlugDescriptor& descriptor,
      const ExactRational& tolerance, PmfRepresentationBudget budget);
  [[nodiscard]] static Result<PostClosure> apply_postclosure_realization(
      const PostClosureLaw& law, const PlugDescriptor& descriptor,
      DeterministicRng& rng, const ExactRational& tolerance,
      PmfRepresentationBudget budget);

  [[nodiscard]] static ArrivalCapability arrival_capability(
      CausalBranchIdentityV1 branch);
  [[nodiscard]] static Result<void> consume_arrival_capability(
      ArrivalCapability& capability,
      const CausalBranchIdentityV1& branch);

  [[nodiscard]] static ResolvedStateInputs resolved_state_inputs(
      const ResolvedInstance& instance, ReducedStateV1 pre_state,
      OpportunityMark opportunity, ResolvedAction action,
      ArrivalTransition arrival, PostClosure postclosure,
      const PlugDescriptor& descriptor,
      ExactReducedStateSchemaV1 state_schema,
      OptimizerExecutionContext& optimizer_context);
  [[nodiscard]] static CompletedReducedEdge completed_edge(
      ReducedStateV1 pre_state, ReducedStateV1 successor_state,
      OpportunityMark opportunity, ResolvedAction action,
      ArrivalTransition arrival, PostClosure postclosure,
      std::vector<CausalMarkV1> marks);
  [[nodiscard]] static MarkedKernelRow marked_row(
      std::vector<MarkedKernelRowAtomV1> atoms,
      ExactRational exact_total_mass,
      std::vector<StageMassDiagnosticV1> stage_mass_diagnostics,
      ExactCategoricalImageV1 categorical);
  [[nodiscard]] static V0WitnessReport v0_report(
      V0WitnessBindingsV1 bindings,
      std::vector<V0WitnessEntryV1> entries, bool passed);
  [[nodiscard]] static const SurrogatePlug& plug(
      const CompiledFrameworkCandidate& candidate) noexcept;
  [[nodiscard]] static const Digest256& validated_descriptor_digest(
      const CompiledFrameworkCandidate& candidate) noexcept;
  [[nodiscard]] static CompiledFrameworkCandidateInputsV1& inputs(
      CompiledFrameworkCandidate& candidate) noexcept;
  [[nodiscard]] static const CompiledFrameworkCandidateInputsV1& inputs(
      const CompiledFrameworkCandidate& candidate) noexcept;
  [[nodiscard]] static const ArtifactValidationBindingsV1& artifact_bindings(
      const CompiledFrameworkCandidate& candidate) noexcept;
  [[nodiscard]] static const Digest256& validated_contract_digest(
      const CompiledFrameworkCandidate& candidate) noexcept;
  [[nodiscard]] static const MetricSupportManifest& structural_manifest(
      const CompiledFrameworkCandidate& candidate) noexcept;

  [[nodiscard]] static Result<MarkedKernelRow> compose_for_audit(
      CompiledFrameworkCandidate& candidate,
      const PlugDescriptor& descriptor, const ReducedStateV1& state);
  [[nodiscard]] static Result<MarkedKernelRow> compose_for_audit_probe(
      CompiledFrameworkCandidate& candidate,
      const PlugDescriptor& descriptor, const ReducedStateV1& state);
  [[nodiscard]] static Result<MarkedKernelRow> compose_candidate_row(
      const SurrogatePlug& plug, const PlugDescriptor& descriptor,
      CompiledFrameworkCandidateInputsV1& inputs,
      const ReducedStateV1& state);
  [[nodiscard]] static Result<MarkedKernelRow> compose_program_row(
      const SurrogatePlug* plug, const PlugDescriptor& descriptor,
      ResolvedInstance& instance, CompiledArrivalLaw& configured_arrival,
      ExactReducedStateSchemaV1& exact_state_schema,
      ExactCausalProgramV1& causal_program,
      OptimizerExecutionContext& optimizer_context,
      const ReducedStateV1& state
#if defined(MWPERF_C17_TEST_SEAMS)
      , const C17GenericCallbackProgramV1* test_callbacks = nullptr
#endif
      );
  [[nodiscard]] static Result<CompletedReducedEdge> execute_candidate_slot(
      surrogate::detail::SealedFrameworkCore& core,
      const ReducedStateV1& state, RngBank& rng_bank);
  [[nodiscard]] static Result<ExactRational> three_bin_service_probability(
      const surrogate::detail::SealedFrameworkCore& core,
      const BigNat& backlog);
  [[nodiscard]] static Result<ExactRational>
  finite_prefix_constant_tail_service_probability(
      const surrogate::detail::SealedFrameworkCore& core,
      const BigNat& backlog);
  [[nodiscard]] static Digest256 schedule_identity(
      const ResolvedInstance& instance, const Schedule& schedule);
#if defined(MWPERF_C17_TEST_SEAMS)
  [[nodiscard]] static Result<MarkedKernelRow> compose_generic_for_testing(
      C17GenericComposerFixtureV1& fixture,
      const PlugDescriptor& descriptor, const ReducedStateV1& state);
#endif

  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedCompiledFramework& framework) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedInitialMapper& mapper) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedRowProvider& provider) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedSlotExecutor& executor) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedResponseLaw& response) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedThreeBinResponse& response) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedFinitePrefixConstantTailResponse& response) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedPhaseResponse& response) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedFixedPointFamily& family) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedRomrView& view) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedResidenceProvider& provider) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedTemporalFramework& framework) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedCylinderLaw& law) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedTemporalKernel& kernel) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedTemporalLaw& law) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedSamplerDescriptor& descriptor) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedExactInnovationKernel& kernel) noexcept;
  [[nodiscard]] static std::shared_ptr<surrogate::detail::SealedFrameworkCore>
  core(const AuditedTargetDensityRatio& ratio) noexcept;

  [[nodiscard]] static AuditedInitialMapper initial_mapper(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedRowProvider row_provider(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedSlotExecutor slot_executor(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedResponseLaw response_law(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedThreeBinResponse three_bin_response(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedFinitePrefixConstantTailResponse
  finite_prefix_constant_tail_response(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedPhaseResponse phase_response(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedFixedPointFamily fixed_point_family(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedRomrView romr_view(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedResidenceProvider residence_provider(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedTemporalFramework temporal_framework(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedSamplerDescriptor sampler_descriptor(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core);
  [[nodiscard]] static AuditedExactInnovationKernel exact_innovation_kernel(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      Digest256 representation_binding);
  [[nodiscard]] static AuditedTargetDensityRatio target_density_ratio(
      std::shared_ptr<surrogate::detail::SealedFrameworkCore> core,
      Digest256 plan_binding);

  friend class ::mwperf::C17AuditedFrameworkMint;
  friend class ::mwperf::kernel::detail::C17TemporalBridgeAccess;
  friend class ::mwperf::AuditedThreeBinResponse;
  friend class ::mwperf::AuditedFinitePrefixConstantTailResponse;
  friend class ::mwperf::AuditedRomrView;
  friend auto ::mwperf::prepare_prearrival_closure(
      const SurrogatePlug&, const ReducedStateV1&) -> Result<OpportunityLaw>;
  friend auto ::mwperf::prepare_reduced_action_law(
      const ResolvedInstance&, const ReducedStateV1&,
      const OpportunityMark&, OptimizerExecutionContext&) -> Result<ActionLaw>;
  friend auto ::mwperf::prepare_configured_arrival_law(
      const CompiledArrivalLaw&, const ArrivalPhase&)
      -> Result<ArrivalTransitionLaw>;
  friend auto ::mwperf::prepare_postarrival_closure(
      const SurrogatePlug&, const ReducedStateV1&,
      const OpportunityMark&, const ResolvedAction&,
      const ArrivalTransition&) -> Result<PostClosureLaw>;
  friend auto ::mwperf::apply_exact_reduced_update(ResolvedStateInputs)
      -> Result<CompletedReducedEdge>;
  friend auto ::mwperf::compile_reduced_kernel_row(
      const AuditedRowProvider&, const ReducedStateV1&)
      -> Result<MarkedKernelRow>;
  friend auto ::mwperf::audit_v0_causality(
      CompiledFrameworkCandidate, PlugDescriptor, KernelAccess)
      -> Result<AuditedCompiledFramework>;
  friend auto ::mwperf::audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1)
      -> Result<AuditedCompiledFramework>;
  friend auto ::mwperf::execute_reduced_slot(
      const AuditedSlotExecutor&, const ReducedStateV1&, RngBank&)
      -> Result<CompletedReducedEdge>;
  friend auto ::mwperf::audited_row_provider(
      const AuditedCompiledFramework&) -> Result<AuditedRowProvider>;
  friend auto ::mwperf::audited_initial_mapper(
      const AuditedCompiledFramework&) -> Result<AuditedInitialMapper>;
  friend auto ::mwperf::audited_slot_executor(
      const AuditedCompiledFramework&) -> Result<AuditedSlotExecutor>;
  friend auto ::mwperf::audited_response_law(
      const AuditedCompiledFramework&) -> Result<AuditedResponseLaw>;
  friend auto ::mwperf::audited_three_bin_response(
      const AuditedCompiledFramework&) -> Result<AuditedThreeBinResponse>;
  friend auto ::mwperf::audited_finite_prefix_constant_tail_response(
      const AuditedCompiledFramework&)
      -> Result<AuditedFinitePrefixConstantTailResponse>;
  friend auto ::mwperf::audited_phase_response(
      const AuditedCompiledFramework&) -> Result<AuditedPhaseResponse>;
  friend auto ::mwperf::audited_fixed_point_family(
      const AuditedCompiledFramework&) -> Result<AuditedFixedPointFamily>;
  friend auto ::mwperf::audited_romr_view(
      const AuditedCompiledFramework&) -> Result<AuditedRomrView>;
  friend auto ::mwperf::audited_residence_provider(
      const AuditedCompiledFramework&) -> Result<AuditedResidenceProvider>;
  friend auto ::mwperf::audited_temporal_framework(
      const AuditedCompiledFramework&) -> Result<AuditedTemporalFramework>;
  friend auto ::mwperf::audited_sampler_descriptor(
      const AuditedCompiledFramework&) -> Result<AuditedSamplerDescriptor>;
  friend auto ::mwperf::audited_row_provider(
      const AuditedResidenceProvider&) -> Result<AuditedRowProvider>;
  friend auto ::mwperf::audited_romr_view(
      const AuditedResidenceProvider&) -> Result<AuditedRomrView>;
  friend auto ::mwperf::audited_slot_executor(
      const AuditedTemporalFramework&) -> Result<AuditedSlotExecutor>;
  friend auto ::mwperf::audited_romr_view(
      const AuditedTemporalFramework&) -> Result<AuditedRomrView>;
  friend auto ::mwperf::v0_witness_report(
      const AuditedCompiledFramework&) -> const V0WitnessReport&;
#if defined(MWPERF_C17_TEST_SEAMS)
  friend class ::mwperf::testing::C17FixtureAccess;
#endif
};

}  // namespace detail

#if defined(MWPERF_C17_TEST_SEAMS)
namespace testing {

class C17FixtureAccess final {
 public:
  C17FixtureAccess() = delete;

  [[nodiscard]] static CompiledFrameworkCandidate make_candidate(
      ValidatedSurrogatePlug&& plug,
      CompiledFrameworkCandidateInputsV1 inputs) {
    return C17AuditedFrameworkMint::make_candidate(
        std::move(plug), std::move(inputs));
  }
  [[nodiscard]] static ValidatedSurrogatePlug validated_plug(
      PlugDescriptor descriptor, SurrogatePlug plug,
      ArtifactValidationBindingsV1 artifact_bindings,
      Digest256 accepted_contract_digest,
      MetricSupportManifest accepted_structural_manifest) {
    return C17AuditedFrameworkMint::validated_plug_for_testing(
        std::move(descriptor), std::move(plug),
        std::move(artifact_bindings),
        std::move(accepted_contract_digest),
        std::move(accepted_structural_manifest));
  }
  [[nodiscard]] static Result<Digest256> canonical_raw_access_identity(
      const KernelAccess& access) {
    return C17AuditedFrameworkMint::canonical_raw_access_identity(access);
  }
  [[nodiscard]] static PreArrivalContext prearrival_context(
      const ReducedStateV1& state, CausalBranchIdentityV1 branch) {
    return detail::C17CoreAccess::prearrival_context(state,
                                                     std::move(branch));
  }
  [[nodiscard]] static ResolverContext resolver_context(
      const ReducedStateV1& state, const OpportunityMark& opportunity) {
    return detail::C17CoreAccess::resolver_context(state, opportunity);
  }
  [[nodiscard]] static PostArrivalContext postarrival_context(
      const ReducedStateV1& state, const OpportunityMark& opportunity,
      const ResolvedAction& action, const ArrivalTransition& arrival) {
    return detail::C17CoreAccess::postarrival_context(
        state, opportunity, action, arrival);
  }
  [[nodiscard]] static Result<OpportunityLaw> opportunity_law(
      std::vector<OpportunityLawAtomV1> atoms,
      const ExactRational& tolerance, PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::opportunity_law(
        std::move(atoms), tolerance, std::move(budget));
  }
  [[nodiscard]] static OpportunityLaw prepared_opportunity_law(
      PreparedOpportunityEnumeratorV1 enumerator,
      PreparedOpportunitySamplerV1 sampler) {
    return detail::C17CoreAccess::prepared_opportunity_law(
        std::move(enumerator), std::move(sampler));
  }
  [[nodiscard]] static Result<ActionLaw> action_law(
      std::vector<ActionLawAtomV1> atoms, const ExactRational& tolerance,
      PmfRepresentationBudget budget,
      PreparedActionSamplerV1 sampler = {}) {
    return detail::C17CoreAccess::action_law(
        std::move(atoms), tolerance, std::move(budget), std::move(sampler));
  }
  [[nodiscard]] static Result<ArrivalTransitionLaw> arrival_law(
      std::vector<ArrivalTransitionLawAtomV1> atoms,
      const ExactRational& tolerance, PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::arrival_law(
        std::move(atoms), tolerance, std::move(budget));
  }
  [[nodiscard]] static ArrivalTransitionLaw prepared_arrival_law(
      PreparedArrivalEnumeratorV1 enumerator,
      PreparedArrivalSamplerV1 sampler) {
    return detail::C17CoreAccess::prepared_arrival_law(
        std::move(enumerator), std::move(sampler));
  }
  [[nodiscard]] static Result<PostClosureLaw> postclosure_law(
      std::vector<PostClosureCandidateLawAtomV1> atoms,
      const PlugDescriptor& descriptor, const ExactRational& tolerance,
      PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::postclosure_law(
        std::move(atoms), descriptor, tolerance, std::move(budget));
  }
  [[nodiscard]] static PostClosureLaw prepared_postclosure_law(
      PreparedPostClosureEnumeratorV1 enumerator,
      PreparedPostClosureSamplerV1 sampler) {
    return detail::C17CoreAccess::prepared_postclosure_law(
        std::move(enumerator), std::move(sampler));
  }
  [[nodiscard]] static std::span<const OpportunityLawAtomV1> atoms(
      const OpportunityLaw& law) noexcept {
    return detail::C17CoreAccess::atoms(law);
  }
  [[nodiscard]] static std::span<const ActionLawAtomV1> atoms(
      const ActionLaw& law) noexcept {
    return detail::C17CoreAccess::atoms(law);
  }
  [[nodiscard]] static std::span<const ArrivalTransitionLawAtomV1> atoms(
      const ArrivalTransitionLaw& law) noexcept {
    return detail::C17CoreAccess::atoms(law);
  }
  [[nodiscard]] static std::span<const PostClosureLawAtomV1> atoms(
      const PostClosureLaw& law) noexcept {
    return detail::C17CoreAccess::atoms(law);
  }
  template <typename Law>
  [[nodiscard]] static const NormalizedPmf* pmf(
      const Law& law) noexcept {
    return detail::C17CoreAccess::pmf(law);
  }
  [[nodiscard]] static Result<OpportunityLaw>
  apply_opportunity_enumeration(
      const OpportunityLaw& law,
      const TargetBacklogV1& exact_prearrival_backlog,
      const ExactRational& tolerance, PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::apply_opportunity_enumeration(
        law, exact_prearrival_backlog, tolerance, std::move(budget));
  }
  [[nodiscard]] static Result<OpportunityMark>
  apply_opportunity_realization(
      const OpportunityLaw& law,
      const TargetBacklogV1& exact_prearrival_backlog,
      DeterministicRng& rng, const ExactRational& tolerance,
      PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::apply_opportunity_realization(
        law, exact_prearrival_backlog, rng, tolerance, std::move(budget));
  }
  [[nodiscard]] static Result<PostClosureLaw>
  apply_postclosure_enumeration(
      const PostClosureLaw& law, const PlugDescriptor& descriptor,
      const ExactRational& tolerance, PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::apply_postclosure_enumeration(
        law, descriptor, tolerance, std::move(budget));
  }
  [[nodiscard]] static Result<PostClosure> apply_postclosure_realization(
      const PostClosureLaw& law, const PlugDescriptor& descriptor,
      DeterministicRng& rng, const ExactRational& tolerance,
      PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::apply_postclosure_realization(
        law, descriptor, rng, tolerance, std::move(budget));
  }
  [[nodiscard]] static ArrivalCapability arrival_capability(
      CausalBranchIdentityV1 branch) {
    return detail::C17CoreAccess::arrival_capability(std::move(branch));
  }
  [[nodiscard]] static Result<void> consume_arrival_capability(
      ArrivalCapability& capability,
      const CausalBranchIdentityV1& branch) {
    return detail::C17CoreAccess::consume_arrival_capability(capability,
                                                            branch);
  }
  [[nodiscard]] static Result<ArrivalTransitionLaw>
  apply_arrival_enumeration(
      const ArrivalTransitionLaw& law, ArrivalCapability capability,
      const ExactRational& tolerance, PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::apply_arrival_enumeration(
        law, std::move(capability), tolerance, std::move(budget));
  }
  [[nodiscard]] static Result<ArrivalTransition> apply_arrival_realization(
      const ArrivalTransitionLaw& law, ArrivalCapability capability,
      DeterministicRng& rng, const ExactRational& tolerance,
      PmfRepresentationBudget budget) {
    return detail::C17CoreAccess::apply_arrival_realization(
        law, std::move(capability), rng, tolerance, std::move(budget));
  }
  [[nodiscard]] static Digest256 schedule_identity(
      const ResolvedInstance& instance, const Schedule& schedule) {
    return detail::C17CoreAccess::schedule_identity(instance, schedule);
  }
  [[nodiscard]] static ResolvedStateInputs resolved_state_inputs(
      const ResolvedInstance& instance, ReducedStateV1 pre_state,
      OpportunityMark opportunity, ResolvedAction action,
      ArrivalTransition arrival, PostClosure postclosure,
      const PlugDescriptor& descriptor,
      ExactReducedStateSchemaV1 state_schema,
      OptimizerExecutionContext& optimizer_context) {
    return detail::C17CoreAccess::resolved_state_inputs(
        instance, std::move(pre_state), std::move(opportunity),
        std::move(action), std::move(arrival), std::move(postclosure),
        descriptor, std::move(state_schema), optimizer_context);
  }
  [[nodiscard]] static CompletedReducedEdge completed_edge(
      ReducedStateV1 pre_state, ReducedStateV1 successor_state,
      OpportunityMark opportunity, ResolvedAction action,
      ArrivalTransition arrival, PostClosure postclosure,
      std::vector<CausalMarkV1> marks) {
    return detail::C17CoreAccess::completed_edge(
        std::move(pre_state), std::move(successor_state),
        std::move(opportunity), std::move(action), std::move(arrival),
        std::move(postclosure), std::move(marks));
  }
  [[nodiscard]] static MarkedKernelRow marked_row(
      std::vector<MarkedKernelRowAtomV1> atoms,
      ExactRational exact_total_mass,
      std::vector<StageMassDiagnosticV1> diagnostics,
      ExactCategoricalImageV1 categorical) {
    return detail::C17CoreAccess::marked_row(
        std::move(atoms), std::move(exact_total_mass),
        std::move(diagnostics), std::move(categorical));
  }
  [[nodiscard]] static V0WitnessReport v0_report(
      V0WitnessBindingsV1 bindings,
      std::vector<V0WitnessEntryV1> entries, bool passed) {
    return detail::C17CoreAccess::v0_report(
        std::move(bindings), std::move(entries), passed);
  }
  [[nodiscard]] static Result<MarkedKernelRow> compose_for_audit(
      CompiledFrameworkCandidate& candidate,
      const PlugDescriptor& descriptor, const ReducedStateV1& state) {
    return detail::C17CoreAccess::compose_for_audit(candidate, descriptor,
                                                    state);
  }
  [[nodiscard]] static Result<MarkedKernelRow> compose_generic(
      C17GenericComposerFixtureV1& fixture,
      const PlugDescriptor& descriptor, const ReducedStateV1& state) {
    return detail::C17CoreAccess::compose_generic_for_testing(
        fixture, descriptor, state);
  }
  [[nodiscard]] static Result<AuditedCompiledFramework> seal_for_testing(
      CompiledFrameworkCandidate candidate, PlugDescriptor descriptor,
      KernelAccess access, V0WitnessReport report,
      Digest256 execution_seal_digest) {
    return C17AuditedFrameworkMint::seal(
        std::move(candidate), std::move(descriptor), std::move(access),
        std::move(report), std::move(execution_seal_digest));
  }
};

}  // namespace testing
#endif

}  // namespace mwperf
