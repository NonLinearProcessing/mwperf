#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/kernel/arrival_capability.hpp"
#include "mwperf/kernel/resolved_action.hpp"
#include "mwperf/kernel/target_backlog.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/reduction/local_margin.hpp"
#include "mwperf/reduction/resource_coordinates.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
class C20CoreAccess;
}

class UnresolvedPatch final {
 public:
  UnresolvedPatch() = delete;
  UnresolvedPatch(const UnresolvedPatch&) = default;
  UnresolvedPatch(UnresolvedPatch&&) noexcept = default;
  UnresolvedPatch& operator=(const UnresolvedPatch&) = default;
  UnresolvedPatch& operator=(UnresolvedPatch&&) noexcept = default;

  [[nodiscard]] std::span<const RuntimeFieldPatchV1> fields() const noexcept {
    return fields_;
  }

  friend bool operator==(const UnresolvedPatch&,
                         const UnresolvedPatch&) = default;

 private:
  explicit UnresolvedPatch(std::vector<RuntimeFieldPatchV1> fields)
      : fields_(std::move(fields)) {}

  std::vector<RuntimeFieldPatchV1> fields_;

  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
  friend class C17AuditedFrameworkMint;
};

// Raw callback result.  C17 converts this to UnresolvedPatch only after every
// field is proved surrogate_unresolved by the sealed C16 ownership table.
struct PostClosureCandidateV1 final {
  CausalBranchIdentityV1 branch;
  std::vector<RuntimeFieldPatchV1> unresolved_patch;
  std::vector<RuntimeDecodedMarkV1> marks;

  friend bool operator==(const PostClosureCandidateV1&,
                         const PostClosureCandidateV1&) = default;
};

struct PostClosure final {
  CausalBranchIdentityV1 branch;
  UnresolvedPatch unresolved_patch;
  std::vector<RuntimeDecodedMarkV1> marks;

  friend bool operator==(const PostClosure&,
                         const PostClosure&) = default;
};

struct PostClosureCandidateLawAtomV1 final {
  PostClosureCandidateV1 outcome;
  ExactRational raw_mass;
  bool structural_support;

  friend bool operator==(const PostClosureCandidateLawAtomV1&,
                         const PostClosureCandidateLawAtomV1&) = default;
};

struct PostClosureLawAtomV1 final {
  PostClosure outcome;
  ExactRational raw_mass;
  bool structural_support;

  friend bool operator==(const PostClosureLawAtomV1&,
                         const PostClosureLawAtomV1&) = default;
};

using PreparedPostClosureSamplerV1 =
    std::function<Result<PostClosure>(DeterministicRng&)>;
using PreparedPostClosureEnumeratorV1 = std::function<
    Result<std::vector<PostClosureCandidateLawAtomV1>>() >;

class PostArrivalContext final {
 public:
  [[nodiscard]] const ReducedStateV1& state() const noexcept {
    return *state_;
  }
  [[nodiscard]] const OpportunityMark& opportunity() const noexcept {
    return *opportunity_;
  }
  [[nodiscard]] const ResolvedAction& action() const noexcept {
    return *action_;
  }
  [[nodiscard]] const ArrivalTransition& arrival() const noexcept {
    return *arrival_;
  }

 private:
  PostArrivalContext(const ReducedStateV1& state,
                     const OpportunityMark& opportunity,
                     const ResolvedAction& action,
                     const ArrivalTransition& arrival)
      : state_(&state),
        opportunity_(&opportunity),
        action_(&action),
        arrival_(&arrival) {}

  const ReducedStateV1* state_;
  const OpportunityMark* opportunity_;
  const ResolvedAction* action_;
  const ArrivalTransition* arrival_;

  friend class detail::C17CoreAccess;
};

class PostClosureLaw final {
 public:
  PostClosureLaw() = delete;
  PostClosureLaw(const PostClosureLaw&) = default;
  PostClosureLaw(PostClosureLaw&&) noexcept = default;
  PostClosureLaw& operator=(const PostClosureLaw&) = default;
  PostClosureLaw& operator=(PostClosureLaw&&) noexcept = default;

  [[nodiscard]] std::size_t support_size() const noexcept {
    return atoms_.size();
  }
  [[nodiscard]] bool enumerable() const noexcept {
    return state_ == State::prepared
               ? static_cast<bool>(enumerator_)
               : pmf_.has_value();
  }
  [[nodiscard]] bool realizable() const noexcept {
    return state_ == State::prepared
               ? static_cast<bool>(enumerator_) ||
                     static_cast<bool>(sampler_)
               : pmf_.has_value();
  }
  [[nodiscard]] const ExactRational* raw_sum() const noexcept {
    return pmf_ ? &pmf_->authored_sum() : nullptr;
  }
  [[nodiscard]] const ExactRational* signed_delta_from_one() const noexcept {
    return pmf_ ? &pmf_->normalization_delta() : nullptr;
  }

 private:
  enum class State : std::uint8_t {
    prepared,
    applied,
  };

  PostClosureLaw(PreparedPostClosureEnumeratorV1 enumerator,
                 PreparedPostClosureSamplerV1 sampler)
      : state_(State::prepared),
        atoms_(),
        pmf_(std::nullopt),
        enumerator_(std::move(enumerator)),
        sampler_(std::move(sampler)) {}

  PostClosureLaw(std::vector<PostClosureLawAtomV1> atoms,
                 NormalizedPmf pmf)
      : state_(State::applied),
        atoms_(std::move(atoms)),
        pmf_(std::move(pmf)),
        enumerator_(),
        sampler_() {}

  State state_;
  std::vector<PostClosureLawAtomV1> atoms_;
  std::optional<NormalizedPmf> pmf_;
  PreparedPostClosureEnumeratorV1 enumerator_;
  PreparedPostClosureSamplerV1 sampler_;

  friend class detail::C17CoreAccess;
  friend class C17AuditedFrameworkMint;
};

// Typed decomposition of R=(N_T,H^A,Z) and the explicitly declared exact
// controller/resource/margin coordinates.  The first four causal stages see
// this only through an immutable ReducedStateV1; Psi alone rebuilds it.
struct ExactReducedCoordinatesV1 final {
  TargetBacklogV1 backlog;
  ArrivalPhase arrival_phase;
  BigNat boundary_index;
  std::optional<ResourceState> resources;
  std::vector<PairMargin> margins;
  std::optional<CanonicalRuntimeValueV1> controller;
  std::vector<RuntimeFieldPatchV1> unresolved_fields;
};

using DecodeExactReducedStateV1 = std::function<Result<ExactReducedCoordinatesV1>(
    const ReducedStateV1&)>;
using RebuildExactReducedStateV1 = std::function<Result<ReducedStateV1>(
    const ExactReducedCoordinatesV1&, const UnresolvedPatch&)>;
using ValidateReducedStateDomainV1 =
    std::function<Result<void>(const ReducedStateV1&)>;
using DecodeExactPostarrivalMarksV1 = std::function<
    Result<std::vector<RuntimeDecodedMarkV1>>(
        const ExactReducedCoordinatesV1&,
        const ExactReducedCoordinatesV1&, const ResolvedAction&,
        const ArrivalTransition&)>;
using DecodeExactCompletedEdgeMarksV1 = std::function<
    Result<std::vector<RuntimeDecodedMarkV1>>(
        const ExactReducedCoordinatesV1&,
        const ExactReducedCoordinatesV1&, const OpportunityMark&,
        const ResolvedAction&, const ArrivalTransition&,
        const PostClosure&)>;

// The aggregate typed decoders retain the exact descriptor schemas of every
// mark they emit.  The callback arguments keep their mathematical source
// typed, while the ordered schemas bind decoder identity and the declared
// source/input/output codecs before V0 can invoke either operation.
struct ExactPostarrivalMarkDecoderOperationV1 final {
  std::vector<DeterministicRuntimeMarkDecoderSchemaV1> ordered_mark_schemas;
  DecodeExactPostarrivalMarksV1 decode;
};

struct ExactCompletedEdgeMarkDecoderOperationV1 final {
  std::vector<DeterministicRuntimeMarkDecoderSchemaV1> ordered_mark_schemas;
  DecodeExactCompletedEdgeMarksV1 decode;
};

struct ExactReducedStateSchemaV1 final {
  CodecIdentityV1 reduced_state_codec;
  Digest256 exact_state_schema_digest;
  Digest256 reduced_state_schema_digest;
  Digest256 ownership_schema_digest;
  Digest256 exact_update_schema_digest;
  DecodeExactReducedStateV1 decode;
  RebuildExactReducedStateV1 rebuild;
  ValidateReducedStateDomainV1 validate_domain;
  // Framework-owned deterministic readouts. The first carrier binds exact
  // predecision/action/arrival/entrance source codecs. The two typed maps
  // separate C-plus-measurable postarrival coordinates from the complete
  // Psi edge so neither can inspect a later source.
  std::vector<DeterministicRuntimeMarkDecoderOperationV1>
      framework_mark_decoders;
  ExactPostarrivalMarkDecoderOperationV1 postarrival_mark_decoder;
  ExactCompletedEdgeMarkDecoderOperationV1 completed_edge_mark_decoder;
};

// Complete inputs to delta_Psi.  The optimizer ledger is borrowed so a C13
// margin reoptimization cannot reset or fork accounting.
class ResolvedStateInputs final {
 public:
  ResolvedStateInputs() = delete;
  ResolvedStateInputs(const ResolvedStateInputs&) = delete;
  ResolvedStateInputs& operator=(const ResolvedStateInputs&) = delete;
  ResolvedStateInputs(ResolvedStateInputs&&) noexcept = default;
  ResolvedStateInputs& operator=(ResolvedStateInputs&&) = delete;

 private:
  ResolvedStateInputs(ResolvedInstance instance, ReducedStateV1 pre_state,
                      OpportunityMark opportunity, ResolvedAction action,
                      ArrivalTransition arrival, PostClosure postclosure,
                      const PlugDescriptor& descriptor,
                      ExactReducedStateSchemaV1 state_schema,
                      OptimizerExecutionContext& optimizer_context)
      : instance_(std::move(instance)),
        pre_state_(std::move(pre_state)),
        opportunity_(std::move(opportunity)),
        action_(std::move(action)),
        arrival_(std::move(arrival)),
        postclosure_(std::move(postclosure)),
        descriptor_(&descriptor),
        state_schema_(std::move(state_schema)),
        optimizer_context_(&optimizer_context) {}

  ResolvedInstance instance_;
  ReducedStateV1 pre_state_;
  OpportunityMark opportunity_;
  ResolvedAction action_;
  ArrivalTransition arrival_;
  PostClosure postclosure_;
  const PlugDescriptor* descriptor_;
  ExactReducedStateSchemaV1 state_schema_;
  OptimizerExecutionContext* optimizer_context_;

  friend class detail::C17CoreAccess;
  friend Result<class CompletedReducedEdge> apply_exact_reduced_update(
      ResolvedStateInputs);
};

struct CausalMarkV1 final {
  RuntimeDecodedMarkV1 mark;
  CausalStageV1 reveal_stage;

  friend bool operator==(const CausalMarkV1&,
                         const CausalMarkV1&) = default;
};

class CompletedReducedEdge final {
 public:
  CompletedReducedEdge() = delete;
  CompletedReducedEdge(const CompletedReducedEdge&) = default;
  CompletedReducedEdge(CompletedReducedEdge&&) noexcept = default;
  CompletedReducedEdge& operator=(const CompletedReducedEdge&) = default;
  CompletedReducedEdge& operator=(CompletedReducedEdge&&) noexcept = default;

  [[nodiscard]] const ReducedStateV1& pre_state() const noexcept {
    return pre_state_;
  }
  [[nodiscard]] const ReducedStateV1& successor_state() const noexcept {
    return successor_state_;
  }
  [[nodiscard]] const OpportunityMark& opportunity() const noexcept {
    return opportunity_;
  }
  [[nodiscard]] const ResolvedAction& action() const noexcept {
    return action_;
  }
  [[nodiscard]] const ArrivalTransition& arrival() const noexcept {
    return arrival_;
  }
  [[nodiscard]] const PostClosure& postclosure() const noexcept {
    return postclosure_;
  }
  [[nodiscard]] std::span<const CausalMarkV1> marks() const noexcept {
    return marks_;
  }
  [[nodiscard]] const std::array<CausalStageV1, 5U>& stage_trace()
      const noexcept {
    return stage_trace_;
  }

  friend bool operator==(const CompletedReducedEdge&,
                         const CompletedReducedEdge&) = default;

 private:
  CompletedReducedEdge(ReducedStateV1 pre_state,
                       ReducedStateV1 successor_state,
                       OpportunityMark opportunity, ResolvedAction action,
                       ArrivalTransition arrival, PostClosure postclosure,
                       std::vector<CausalMarkV1> marks)
      : pre_state_(std::move(pre_state)),
        successor_state_(std::move(successor_state)),
        opportunity_(std::move(opportunity)),
        action_(std::move(action)),
        arrival_(std::move(arrival)),
        postclosure_(std::move(postclosure)),
        marks_(std::move(marks)),
        stage_trace_(kCausalStageOrderV1) {}

  ReducedStateV1 pre_state_;
  ReducedStateV1 successor_state_;
  OpportunityMark opportunity_;
  ResolvedAction action_;
  ArrivalTransition arrival_;
  PostClosure postclosure_;
  std::vector<CausalMarkV1> marks_;
  std::array<CausalStageV1, 5U> stage_trace_;

  friend class detail::C17CoreAccess;
  friend Result<CompletedReducedEdge> apply_exact_reduced_update(
      ResolvedStateInputs);
};

// Duplicate aggregation uses the complete mathematical/observable outcome,
// while deliberately ignoring only internal atom-path/stream provenance.
[[nodiscard]] inline bool same_completed_reduced_outcome(
    const CompletedReducedEdge& left, const CompletedReducedEdge& right) {
  const OpportunityMark& left_opportunity = left.opportunity();
  const OpportunityMark& right_opportunity = right.opportunity();
  const ResolvedAction& left_action = left.action();
  const ResolvedAction& right_action = right.action();
  const PostClosure& left_post = left.postclosure();
  const PostClosure& right_post = right.postclosure();
  return left.pre_state() == right.pre_state() &&
         left.successor_state() == right.successor_state() &&
         left_opportunity.prearrival_backlog ==
             right_opportunity.prearrival_backlog &&
         left_opportunity.resolver_face ==
             right_opportunity.resolver_face &&
         same_exact_opportunity_evidence(
             left_opportunity.exact_opportunity_evidence,
             right_opportunity.exact_opportunity_evidence) &&
         left_opportunity.opportunity == right_opportunity.opportunity &&
         left_opportunity.marks == right_opportunity.marks &&
         left_action.schedule == right_action.schedule &&
         left_action.actual_departure == right_action.actual_departure &&
         left_action.schedule_identity == right_action.schedule_identity &&
         left_action.evidence == right_action.evidence &&
         left_action.decision == right_action.decision &&
         left_action.interim_controller ==
             right_action.interim_controller &&
         left_action.postupdate_controller_tape ==
             right_action.postupdate_controller_tape &&
         left_action.marks == right_action.marks &&
         same_arrival_transition_value(left.arrival(), right.arrival()) &&
         left_post.unresolved_patch == right_post.unresolved_patch &&
         left_post.marks == right_post.marks &&
         left.marks().size() == right.marks().size() &&
         std::equal(left.marks().begin(), left.marks().end(),
                    right.marks().begin(), right.marks().end()) &&
         left.stage_trace() == right.stage_trace();
}

}  // namespace mwperf
