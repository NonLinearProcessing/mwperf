#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <utility>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/kernel/stage_context.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
}

// The complete configured joint transition selected for one upstream branch.
// Queue projections are intentionally absent: every consumer retains the same
// batch and predictive-phase transition.
struct ArrivalTransition final {
  CausalBranchIdentityV1 branch;
  BigNat authored_slot;
  ArrivalBatch batch;
  ArrivalPhase phase_before;
  ArrivalPhase phase_after;
  ArrivalLawDigest law_digest;
  Digest256 realization_identity;
  // The sole C17 ABI projection of this transition.  Its fixed v1 preimage
  // contains authored_slot, the full bound sparse batch, the complete C09
  // binding, before/after phase family + canonical state + next-slot
  // lineage, law identity, and realization identity.  Branch provenance and
  // decoded marks are deliberately excluded.  C-plus and every
  // configured-arrival mark decoder receive this same immutable value.
  CanonicalRuntimeValueV1 canonical_source;
  std::vector<RuntimeDecodedMarkV1> marks;

  friend bool operator==(const ArrivalTransition& left,
                         const ArrivalTransition& right) {
    const auto same_phase = [](const ArrivalPhase& a,
                               const ArrivalPhase& b) {
      const auto a_bytes = arrival_phase_canonical_state(a);
      const auto b_bytes = arrival_phase_canonical_state(b);
      return arrival_phase_family(a) == arrival_phase_family(b) &&
             a_bytes.size() == b_bytes.size() &&
             std::equal(a_bytes.begin(), a_bytes.end(), b_bytes.begin());
    };
    return left.branch == right.branch &&
           left.authored_slot == right.authored_slot &&
           left.batch == right.batch &&
           same_phase(left.phase_before, right.phase_before) &&
           same_phase(left.phase_after, right.phase_after) &&
           left.law_digest == right.law_digest &&
           left.realization_identity == right.realization_identity &&
           left.canonical_source == right.canonical_source &&
           left.marks == right.marks;
  }
};

// Equality of the mathematical transition value used by duplicate-row merge;
// atom-path and realized-stream provenance do not change the transition.
[[nodiscard]] inline bool same_arrival_transition_value(
    const ArrivalTransition& left, const ArrivalTransition& right) {
  ArrivalTransition left_without_provenance = left;
  ArrivalTransition right_without_provenance = right;
  left_without_provenance.branch = right_without_provenance.branch;
  left_without_provenance.realization_identity =
      right_without_provenance.realization_identity;
  return left_without_provenance == right_without_provenance;
}

struct ArrivalTransitionLawAtomV1 final {
  ArrivalTransition outcome;
  ExactRational raw_mass;
  bool structural_support;

  friend bool operator==(const ArrivalTransitionLawAtomV1&,
                         const ArrivalTransitionLawAtomV1&) = default;
};

// F-C17-03 captures the configured C09 law and current predictive phase but
// invokes neither operation.  The private composer supplies the selected
// resolver branch only when it consumes the one-use ArrivalCapability.
using PreparedArrivalEnumeratorV1 = std::function<
    Result<std::vector<ArrivalTransitionLawAtomV1>>(
        const CausalBranchIdentityV1&)>;
using PreparedArrivalSamplerV1 = std::function<Result<ArrivalTransition>(
    const CausalBranchIdentityV1&, DeterministicRng&)>;

class ArrivalTransitionLaw final {
 public:
  ArrivalTransitionLaw() = delete;
  ArrivalTransitionLaw(const ArrivalTransitionLaw&) = default;
  ArrivalTransitionLaw(ArrivalTransitionLaw&&) noexcept = default;
  ArrivalTransitionLaw& operator=(const ArrivalTransitionLaw&) = default;
  ArrivalTransitionLaw& operator=(ArrivalTransitionLaw&&) noexcept = default;

  [[nodiscard]] std::size_t support_size() const noexcept {
    return atoms_.size();
  }
  [[nodiscard]] bool enumerable() const noexcept {
    return state_ == State::prepared
               ? static_cast<bool>(enumerator_)
               : pmf_.has_value();
  }
  [[nodiscard]] bool realizable() const noexcept {
    return state_ == State::prepared
               ? static_cast<bool>(enumerator_) ||
                     static_cast<bool>(sampler_)
               : pmf_.has_value();
  }
  [[nodiscard]] const ExactRational* raw_sum() const noexcept {
    return pmf_ ? &pmf_->authored_sum() : nullptr;
  }
  [[nodiscard]] const ExactRational* signed_delta_from_one() const noexcept {
    return pmf_ ? &pmf_->normalization_delta() : nullptr;
  }

 private:
  enum class State : std::uint8_t {
    prepared,
    applied,
  };

  ArrivalTransitionLaw(PreparedArrivalEnumeratorV1 enumerator,
                       PreparedArrivalSamplerV1 sampler)
      : state_(State::prepared),
        atoms_(),
        pmf_(std::nullopt),
        enumerator_(std::move(enumerator)),
        sampler_(std::move(sampler)) {}

  ArrivalTransitionLaw(std::vector<ArrivalTransitionLawAtomV1> atoms,
                       NormalizedPmf pmf)
      : state_(State::applied),
        atoms_(std::move(atoms)),
        pmf_(std::move(pmf)),
        enumerator_(),
        sampler_() {}

  State state_;
  std::vector<ArrivalTransitionLawAtomV1> atoms_;
  std::optional<NormalizedPmf> pmf_;
  PreparedArrivalEnumeratorV1 enumerator_;
  PreparedArrivalSamplerV1 sampler_;

  friend class detail::C17CoreAccess;
};

// One token is minted after resolver selection.  Enumeration consumes it once
// to obtain the whole row; realization consumes it once to obtain one atom.
class ArrivalCapability final {
 public:
  ArrivalCapability() = delete;
  ArrivalCapability(const ArrivalCapability&) = delete;
  ArrivalCapability& operator=(const ArrivalCapability&) = delete;
  ArrivalCapability(ArrivalCapability&& other) noexcept
      : branch_(std::move(other.branch_)), available_(other.available_) {
    other.available_ = false;
  }
  ArrivalCapability& operator=(ArrivalCapability&&) = delete;

 private:
  explicit ArrivalCapability(CausalBranchIdentityV1 branch)
      : branch_(std::move(branch)), available_(true) {}

  CausalBranchIdentityV1 branch_;
  bool available_;

  friend class detail::C17CoreAccess;
};

}  // namespace mwperf
