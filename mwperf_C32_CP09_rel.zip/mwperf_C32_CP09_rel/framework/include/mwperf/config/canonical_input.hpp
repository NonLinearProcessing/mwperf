#pragma once

#include <string>

#include "mwperf/core/sha256.hpp"

namespace mwperf {

struct AuthoredModelConfig;
struct AnalysisSpec;

// Canonical physical and analysis documents remain separate throughout input
// identity construction.  Each member is a complete, reparsable, whitespace-
// free UTF-8 JSON document.
struct CanonicalInputPair final {
  std::string model;
  std::string analysis;

  friend bool operator==(const CanonicalInputPair&,
                         const CanonicalInputPair&) = default;
};

// These digests identify the resolved authored inputs only.  They do not
// identify a source file, a surrogate artifact, or a service model.
struct InputFingerprintBundle final {
  Digest256 model;
  Digest256 analysis;
  Digest256 combined;

  friend bool operator==(const InputFingerprintBundle&,
                         const InputFingerprintBundle&) = default;
};

// F-C03-06
[[nodiscard]] CanonicalInputPair canonicalize_authored_inputs(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis);

// F-C03-07
[[nodiscard]] InputFingerprintBundle fingerprint_inputs(
    const CanonicalInputPair& inputs);

}  // namespace mwperf
