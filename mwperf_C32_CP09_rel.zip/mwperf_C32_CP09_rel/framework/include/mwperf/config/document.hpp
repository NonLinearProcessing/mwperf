#pragma once

#include <filesystem>
#include <span>
#include <string>
#include <string_view>

#include "mwperf/config/source_node.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

enum class DocumentSyntax {
  json,
  yaml,
};

struct ParsedDocument final {
  DocumentSyntax syntax;
  std::string authored_path;
  SourceNode root;
};

struct ModelNode final {
  SourceNode node;
};

using KeySet = std::span<const std::string_view>;

// F-C03-01
[[nodiscard]] Result<ParsedDocument> load_document(
    const std::filesystem::path& path);

// F-C03-02
[[nodiscard]] Result<ModelNode> extract_executable_model(
    const ParsedDocument& document);

// F-C03-03. This enforces the closed allowed-key set; required-key checks are
// owned by the caller because C03 objects have field-specific optionality.
[[nodiscard]] Result<void> validate_exact_keys(
    const SourceNode& node, KeySet allowed_keys, std::string_view json_pointer);

}  // namespace mwperf
