#pragma once

#include <string_view>

namespace mwperf {

// The unqualified name remains the schema-3 constant so released callers that
// compiled against C31 keep their existing default.  New code should dispatch
// explicitly between the two physical schemas.
inline constexpr std::string_view kPhysicalSchemaVersionV3 = "3.0.0";
inline constexpr std::string_view kPhysicalSchemaVersionV4 = "4.0.0";
inline constexpr std::string_view kPhysicalSchemaVersion =
    kPhysicalSchemaVersionV3;
inline constexpr std::string_view kAnalysisSchemaVersion = "1.0.0";

}  // namespace mwperf
