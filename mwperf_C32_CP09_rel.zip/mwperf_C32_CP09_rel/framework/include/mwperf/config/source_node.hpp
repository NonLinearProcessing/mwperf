#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace mwperf {

// Source positions are byte-oriented and stable across locales. Lines and
// columns are one-based; byte_offset is zero-based from the beginning of the
// decoded UTF-8 file.
struct SourceLocation final {
  std::string authored_path;
  std::size_t line;
  std::size_t column;
  std::size_t byte_offset;

  friend bool operator==(const SourceLocation&, const SourceLocation&) =
      default;
};

// Provenance for values materialized by the typed C03 parsers. A parser
// default has no authored location, retains its intended canonical pointer,
// and sets defaulted=true.
struct SourceProvenance final {
  std::optional<SourceLocation> location;
  std::string json_pointer;
  bool defaulted;

  friend bool operator==(const SourceProvenance&, const SourceProvenance&) =
      default;
};

template <typename T>
struct AuthoredValue final {
  T value;
  SourceProvenance provenance;

  friend bool operator==(const AuthoredValue&, const AuthoredValue&) = default;
};

enum class SourceNodeKind {
  null_value,
  boolean,
  number,
  string,
  array,
  object,
};

struct SourceObjectMember;

// Immutable, source-preserving JSON data model. Numbers are stored as their
// original source lexemes and are never routed through a binary floating type.
// Objects retain authored member order. A successfully loaded object is known
// to contain no duplicate decoded member names.
class SourceNode final {
 public:
  SourceNode() = delete;
  SourceNode(const SourceNode&) noexcept = default;
  SourceNode(SourceNode&&) noexcept = default;
  SourceNode& operator=(const SourceNode&) noexcept = default;
  SourceNode& operator=(SourceNode&&) noexcept = default;
  ~SourceNode() = default;

  [[nodiscard]] static SourceNode make_null(SourceLocation location,
                                             std::string json_pointer);
  [[nodiscard]] static SourceNode make_boolean(bool value,
                                                SourceLocation location,
                                                std::string json_pointer);
  [[nodiscard]] static SourceNode make_number(std::string lexeme,
                                               SourceLocation location,
                                               std::string json_pointer);
  [[nodiscard]] static SourceNode make_string(std::string value,
                                               SourceLocation location,
                                               std::string json_pointer);
  [[nodiscard]] static SourceNode make_array(
      std::vector<SourceNode> items, SourceLocation location,
      std::string json_pointer);
  [[nodiscard]] static SourceNode make_object(
      std::vector<SourceObjectMember> members, SourceLocation location,
      std::string json_pointer);

  [[nodiscard]] SourceNodeKind kind() const noexcept;
  [[nodiscard]] const SourceLocation& location() const noexcept;
  [[nodiscard]] std::string_view json_pointer() const noexcept;

  [[nodiscard]] const bool* boolean_value() const noexcept;
  [[nodiscard]] const std::string* number_lexeme() const noexcept;
  [[nodiscard]] const std::string* string_value() const noexcept;
  [[nodiscard]] std::span<const SourceNode> array_items() const noexcept;
  [[nodiscard]] std::span<const SourceObjectMember> object_members() const
      noexcept;
  [[nodiscard]] const SourceObjectMember* find_member(
      std::string_view key) const noexcept;
  [[nodiscard]] const SourceNode* find(std::string_view key) const noexcept;

 private:
  struct Storage;
  explicit SourceNode(std::shared_ptr<const Storage> storage) noexcept;

  std::shared_ptr<const Storage> storage_;
};

struct SourceObjectMember final {
  std::string key;
  SourceLocation key_location;
  SourceNode value;
};

using Node = SourceNode;

[[nodiscard]] SourceProvenance authored_provenance(const SourceNode& node);
[[nodiscard]] SourceProvenance defaulted_provenance(
    std::string canonical_json_pointer);

// RFC 6901 escaping for a single decoded object-key token.
[[nodiscard]] std::string escape_json_pointer_token(std::string_view token);

}  // namespace mwperf
