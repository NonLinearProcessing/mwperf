#pragma once

#include <memory>
#include <optional>
#include <string>
#include <variant>
#include <vector>

#include "mwperf/config/document.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// C03 deliberately keeps these identifiers unresolved.  C04 is the sole
// boundary that maps an authored TypedLabel to a dense queue index.
struct TargetSet final {
  std::vector<TypedLabel> queue_ids;
  SourceNode source;
};

struct LevelResolution final {
  std::optional<BigNat> max_states;
  std::optional<BigNat> max_row_atoms;
  SourceNode source;
};

struct NoTailResolution final {
  SourceNode source;
};

struct FiniteClosedTailResolution final {
  BigNat max_level;
  SourceNode source;
};

struct ConstantResponseTailResolution final {
  BigNat cutoff;
  SourceNode source;
};

struct CertifiedTruncationTailResolution final {
  BigNat max_level;
  ExactRational max_tail_mass;
  SourceNode source;
};

using TailResolution =
    std::variant<NoTailResolution, FiniteClosedTailResolution,
                 ConstantResponseTailResolution,
                 CertifiedTruncationTailResolution>;

struct PhaseResolution final {
  std::optional<BigNat> max_phase_states;
  SourceNode source;
};

struct OptimizerResolution final {
  std::optional<BigNat> max_calls;
  std::optional<BigNat> max_search_states_per_call;
  SourceNode source;
};

struct SamplingResolution final {
  std::optional<BigNat> max_generator_draws;
  SourceNode source;
};

struct ToleranceResolution final {
  std::optional<ExactRational> linear_residual_abs;
  std::optional<ExactRational> integration_abs;
  std::optional<ExactRational> tail_abs;
  std::optional<ExactRational> fixed_point_abs;
  SourceNode source;
};

struct ResolutionEnvelope final {
  LevelResolution level;
  TailResolution tail;
  PhaseResolution phase;
  OptimizerResolution optimizer;
  SamplingResolution sampling;
  ToleranceResolution tolerance;
  SourceNode source;
};

struct TraceOrigin final {};
struct GlobalPeriodicOrigin final {};
struct SourceDelayOrigin final {};
struct RenewalOrigin final {};

struct PrivateMarkovState final {
  std::string source_id;
  std::string state;
  SourceNode source;
};

struct PrivateMarkovStates final {
  std::vector<PrivateMarkovState> states;
};

struct SharedRoundState final {
  std::string state;
};

using ArrivalInitialState =
    std::variant<TraceOrigin, GlobalPeriodicOrigin, SourceDelayOrigin,
                 RenewalOrigin, PrivateMarkovStates, SharedRoundState>;

struct InitialBacklogEntry final {
  TypedLabel queue_id;
  BigNat value;
  SourceNode source;
};

struct TransientInitialAtom final {
  AuthoredProbability probability;
  std::vector<InitialBacklogEntry> backlog;
  ArrivalInitialState arrival_state;
  // These are retained as authored source objects.  controller_state and
  // static_context have already been proved empty by C03.  Only
  // surrogate_initial is provider-owned and receives deferred closed-schema
  // validation at C16.
  SourceNode controller_state;
  SourceNode static_context;
  SourceNode surrogate_initial;
  SourceNode source;
};

struct TransientSelection final {
  std::vector<TransientInitialAtom> atoms;
  SourceNode source;
};

struct StationaryUniqueSelection final {
  SourceNode source;
};

struct StationaryClassSelection final {
  TypedLabel class_id;
  SourceNode source;
};

struct StationaryMixtureComponent final {
  TypedLabel class_id;
  AuthoredProbability probability;
  SourceNode source;
};

struct StationaryMixtureSelection final {
  std::vector<StationaryMixtureComponent> components;
  SourceNode source;
};

struct FixedPointUniqueSelection final {
  SourceNode source;
};

struct FixedPointIdSelection final {
  TypedLabel solution_id;
  SourceNode source;
};

using FixedPointSelection =
    std::variant<FixedPointUniqueSelection, FixedPointIdSelection>;

using SelectionSpec =
    std::variant<TransientSelection, StationaryUniqueSelection,
                 StationaryClassSelection, StationaryMixtureSelection,
                 FixedPointSelection>;

enum class LinearMethod { dense_pivoted, sparse_iterative };

struct EnumeratedSolver final {
  LinearMethod linear_method;
  std::optional<BigNat> max_iterations;
  SourceNode source;
};

struct AnalyticSolver final {
  BigNat precision_bits;
  std::optional<BigNat> max_iterations;
  SourceNode source;
};

enum class MonteCarloIntervalMethod { exact_binomial, hoeffding, none };

struct MonteCarloSolver final {
  BigNat replications;
  ExactRational confidence_level;
  MonteCarloIntervalMethod interval_method;
  SourceNode source;
};

struct DirectSolver final {
  SourceNode source;
};

using SolverSpec =
    std::variant<EnumeratedSolver, AnalyticSolver, MonteCarloSolver,
                 DirectSolver>;

struct AnalysisContext final {
  TargetSet targets;
  ResolutionEnvelope resolution;
  SelectionSpec selection;
  SolverSpec solver;
};

// Metric wire alternatives.  These records validate only the frozen v1 wire
// shape.  C14, and only C14, maps one of them to mathematical requirements.
struct StationaryThroughputMetric final {};
struct StationaryEmptyProbabilityMetric final {};
struct MeanSojournMetric final {};
struct ServicePersistenceMetric final {};
struct JointBacklogCovarianceMetric final {};

struct StationaryBacklogPmfMetric final {
  std::optional<BigNat> max_level;
};

struct StationaryBacklogPgfMetric final {
  std::vector<ExactRational> points;
};

struct StationaryBacklogMomentMetric final {
  BigNat order;
};

struct StationaryBacklogQuantileMetric final {
  ExactRational probability;
};

struct StationaryBacklogTailMetric final {
  BigNat threshold;
};

struct BacklogConditionedServiceMetric final {
  std::vector<BigNat> levels;
};

enum class EdgeRewardKind { increment, departure, arrival };

struct StationaryEdgeRewardMetric final {
  EdgeRewardKind reward;
  BigNat moment_order;
};

struct ServiceAutocovarianceMetric final {
  std::vector<BigNat> lags;
};

struct LaggedCrossQueueCovarianceMetric final {
  std::vector<BigNat> lags;
};

struct ServiceSpectrumMetric final {
  std::vector<ExactRational> frequencies;
  BigNat truncation_lag;
};

struct ServiceWindowCountMetric final {
  BigNat width;
};

enum class GapEventKind { departure, admission, busy_denial };

struct MeanEventGapMetric final {
  GapEventKind event;
};

struct EventGapDistributionMetric final {
  GapEventKind event;
  BigNat horizon;
};

enum class BinaryPredicateKind { busy, idle, busy_denial, threshold_above };

struct MeanBinaryRunMetric final {
  BinaryPredicateKind predicate;
  std::optional<BigNat> threshold;
};

struct BinaryRunDistributionMetric final {
  BinaryPredicateKind predicate;
  std::optional<BigNat> threshold;
  BigNat horizon;
};

enum class HitSetKind { at_or_above, at_or_below, equal };

struct HitSet final {
  HitSetKind kind;
  BigNat level;
};

struct FirstHitMetric final {
  HitSet set;
  BigNat horizon;
  bool include_mean;
};

struct ThresholdExcursionMetric final {
  HitSet set;
  BigNat horizon;
  bool include_mean;
};

struct TransientBacklogLawMetric final {
  std::vector<BigNat> horizons;
};

struct FifoDelayPmfMetric final {
  BigNat horizon;
};

struct FifoDelayTailMetric final {
  BigNat horizon;
};

struct FifoDelayQuantileMetric final {
  ExactRational probability;
};

struct FifoDelayMomentMetric final {
  BigNat order;
};

using FifoDelayWire =
    std::variant<FifoDelayPmfMetric, FifoDelayTailMetric,
                 FifoDelayQuantileMetric, FifoDelayMomentMetric>;

struct RankCondition final {
  BigNat value;
};
struct BatchCondition final {
  BigNat value;
};
struct ClassCondition final {
  TypedLabel value;
};
struct PhaseCondition final {
  TypedLabel value;
};
using FifoCondition =
    std::variant<RankCondition, BatchCondition, ClassCondition, PhaseCondition>;

struct FifoDelayMetric final {
  FifoDelayWire request;
};

struct FifoDelayConditionedMetric final {
  FifoDelayWire request;
  FifoCondition condition;
};

struct CounterfactualOpportunityGapMetric final {
  TypedLabel convention_id;
  BigNat horizon;
};

enum class JointBacklogRelation { all_at_or_above, any_at_or_above };

struct JointBacklogEventMetric final {
  JointBacklogRelation relation;
  std::vector<BigNat> thresholds;
};

enum class JointDelaySampling { coincident, independent_palm, lagged };

struct JointDelayMetric final {
  JointDelaySampling sampling;
  std::optional<BigNat> lag;
  BigNat horizon;
};

struct OrderedScheduleSequenceMetric final {
  BigNat horizon;
  bool retain_full_schedule;
};

using MetricWire = std::variant<
    StationaryThroughputMetric, StationaryEmptyProbabilityMetric,
    MeanSojournMetric, ServicePersistenceMetric,
    JointBacklogCovarianceMetric, StationaryBacklogPmfMetric,
    StationaryBacklogPgfMetric, StationaryBacklogMomentMetric,
    StationaryBacklogQuantileMetric, StationaryBacklogTailMetric,
    BacklogConditionedServiceMetric, StationaryEdgeRewardMetric,
    ServiceAutocovarianceMetric, LaggedCrossQueueCovarianceMetric,
    ServiceSpectrumMetric, ServiceWindowCountMetric, MeanEventGapMetric,
    EventGapDistributionMetric, MeanBinaryRunMetric,
    BinaryRunDistributionMetric, FirstHitMetric, ThresholdExcursionMetric,
    TransientBacklogLawMetric, FifoDelayMetric,
    FifoDelayConditionedMetric, CounterfactualOpportunityGapMetric,
    JointBacklogEventMetric, JointDelayMetric,
    OrderedScheduleSequenceMetric>;

struct MetricNode final {
  std::string id;
  MetricWire metric;
  SourceNode source;
  std::shared_ptr<const AnalysisContext> context;
};

struct SurrogateSelection final {
  std::string id;
  std::optional<std::string> version;
  // Opaque means deferred typed validation, never an executable transport.
  SourceNode parameters;
  SourceNode source;
};

struct AnalysisSpec final {
  std::string analysis_schema_version;
  std::shared_ptr<const AnalysisContext> context;
  std::vector<MetricNode> metrics;
  SurrogateSelection surrogate;
  SourceNode source;
};

// F-C03-05.  This performs only C03 wire-shape and local scalar validation.
// C14's parse_metric_request is deliberately not declared or defined here.
[[nodiscard]] Result<AnalysisSpec> parse_analysis_spec_v1(
    const ParsedDocument& document);

}  // namespace mwperf
