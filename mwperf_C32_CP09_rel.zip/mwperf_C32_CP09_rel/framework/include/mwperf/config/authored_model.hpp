#pragma once

#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <variant>
#include <vector>

#include "mwperf/config/document.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

using ModelProvenance = SourceProvenance;

template <typename T>
using AuthoredField = AuthoredValue<T>;

// Metadata is behavioral inert source data.  A missing node means the exact
// parser default {}, never an absent semantic metadata value.
using AuthoredMetadata = AuthoredField<std::optional<SourceNode>>;

struct NormalizedToken final {
  std::string value;
  std::string authored;
  ModelProvenance provenance;

  friend bool operator==(const NormalizedToken&,
                         const NormalizedToken&) = default;
};

// Shared C03 source/state token rule.  Analysis transient arrival-state
// references call this same helper; no parser may implement a competing
// normalization.
[[nodiscard]] Result<NormalizedToken> normalize_source_state_token(
    const SourceNode& node, std::string_view role);

enum class SeedMode : std::uint8_t { automatic, fixed };

struct SeedSpec final {
  SeedMode mode;
  std::uint64_t fixed_value;

  [[nodiscard]] static SeedSpec automatic() noexcept {
    return SeedSpec{SeedMode::automatic, 0U};
  }
  [[nodiscard]] static SeedSpec fixed(std::uint64_t value) noexcept {
    return SeedSpec{SeedMode::fixed, value};
  }

  friend bool operator==(const SeedSpec&, const SeedSpec&) = default;
};

enum class TerminationPolicy : std::uint8_t {
  fixed_slots,
  fixed_slots_then_drain,
};

struct AuthoredRunConfig final {
  AuthoredField<SeedSpec> seed;
  AuthoredField<BigNat> slots;
  AuthoredField<BigNat> warmup_slots;
  AuthoredField<TerminationPolicy> termination;
  AuthoredField<std::optional<std::string>> output_dir;
  AuthoredField<std::optional<SeedSpec>> requested_seed;
  AuthoredField<std::optional<std::uint64_t>> actual_seed;
  ModelProvenance provenance;

  friend bool operator==(const AuthoredRunConfig&,
                         const AuthoredRunConfig&) = default;
};

struct LegacyVoqCoordinate final {
  AuthoredField<BigNat> source;
  AuthoredField<BigNat> destination;
  ModelProvenance provenance;

  friend bool operator==(const LegacyVoqCoordinate&,
                         const LegacyVoqCoordinate&) = default;
};

struct AuthoredQueue final {
  AuthoredField<QueueId> id;
  AuthoredField<std::optional<LegacyVoqCoordinate>> legacy_voq;
  ModelProvenance provenance;

  friend bool operator==(const AuthoredQueue&, const AuthoredQueue&) = default;
};

struct GeneralizedSwitchConfig final {
  // nullopt is the lossless queue law.  Schema 3 spells it `null`; schema 4
  // spells the same physical law `"NoDrop"`.  The enclosing schema version
  // preserves that authored distinction for canonical identity.
  AuthoredField<std::optional<BigNat>> queue_capacity;
  AuthoredField<std::vector<AuthoredQueue>> queues;
  AuthoredField<std::optional<BigNat>> legacy_n_ports;
  ModelProvenance provenance;

  friend bool operator==(const GeneralizedSwitchConfig&,
                         const GeneralizedSwitchConfig&) = default;
};

struct LegacyCrossbarSwitchConfig final {
  AuthoredField<BigNat> n_ports;
  AuthoredField<BigNat> voq_capacity;
  AuthoredField<bool> allow_self_traffic;
  ModelProvenance provenance;

  friend bool operator==(const LegacyCrossbarSwitchConfig&,
                         const LegacyCrossbarSwitchConfig&) = default;
};

using AuthoredSwitchConfig =
    std::variant<GeneralizedSwitchConfig, LegacyCrossbarSwitchConfig>;

using AuthoredPriority =
    AuthoredField<std::optional<std::vector<AuthoredField<QueueId>>>>;

struct CrossbarEdge final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<PortId> input;
  AuthoredField<PortId> output;
  ModelProvenance provenance;

  friend bool operator==(const CrossbarEdge&, const CrossbarEdge&) = default;
};

struct CrossbarConstraint final {
  AuthoredField<std::vector<AuthoredField<PortId>>> inputs;
  AuthoredField<std::vector<AuthoredField<PortId>>> outputs;
  AuthoredField<std::vector<CrossbarEdge>> edges;
  ModelProvenance provenance;

  friend bool operator==(const CrossbarConstraint&,
                         const CrossbarConstraint&) = default;
};

struct IntervalRecord final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<ExactRational> left;
  AuthoredField<ExactRational> right;
  ModelProvenance provenance;

  friend bool operator==(const IntervalRecord&,
                         const IntervalRecord&) = default;
};

struct IntervalConstraint final {
  AuthoredField<std::vector<IntervalRecord>> intervals;
  ModelProvenance provenance;

  friend bool operator==(const IntervalConstraint&,
                         const IntervalConstraint&) = default;
};

struct NodeExclusiveLink final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<VertexId> u;
  AuthoredField<VertexId> v;
  ModelProvenance provenance;

  friend bool operator==(const NodeExclusiveLink&,
                         const NodeExclusiveLink&) = default;
};

struct NodeExclusiveConstraint final {
  AuthoredField<std::vector<AuthoredField<VertexId>>> vertices;
  AuthoredField<std::vector<NodeExclusiveLink>> links;
  ModelProvenance provenance;

  friend bool operator==(const NodeExclusiveConstraint&,
                         const NodeExclusiveConstraint&) = default;
};

struct ConflictPair final {
  AuthoredField<QueueId> first;
  AuthoredField<QueueId> second;
  ModelProvenance provenance;

  friend bool operator==(const ConflictPair&, const ConflictPair&) = default;
};

struct ConflictConstraint final {
  AuthoredField<std::vector<ConflictPair>> conflicts;
  ModelProvenance provenance;

  friend bool operator==(const ConflictConstraint&,
                         const ConflictConstraint&) = default;
};

struct PackingDemand final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<std::vector<AuthoredField<BigNat>>> demand;
  ModelProvenance provenance;

  friend bool operator==(const PackingDemand&, const PackingDemand&) = default;
};

struct PackingConstraint final {
  AuthoredField<std::vector<AuthoredField<ResourceId>>> resources;
  AuthoredField<std::vector<AuthoredField<BigNat>>> capacity;
  AuthoredField<std::vector<PackingDemand>> demands;
  ModelProvenance provenance;

  friend bool operator==(const PackingConstraint&,
                         const PackingConstraint&) = default;
};

struct CrossbarMaxWeightScheduler final {
  // Generalized form has a constraint.  Legacy form deliberately does not;
  // C03 never synthesizes generalized geometry from a legacy switch.
  AuthoredField<std::optional<CrossbarConstraint>> constraint;
  AuthoredPriority priority;
  bool legacy_form;
  ModelProvenance provenance;

  friend bool operator==(const CrossbarMaxWeightScheduler&,
                         const CrossbarMaxWeightScheduler&) = default;
};

struct IntervalMaxWeightScheduler final {
  AuthoredField<IntervalConstraint> constraint;
  AuthoredPriority priority;
  ModelProvenance provenance;

  friend bool operator==(const IntervalMaxWeightScheduler&,
                         const IntervalMaxWeightScheduler&) = default;
};

struct NodeExclusiveMaxWeightScheduler final {
  AuthoredField<NodeExclusiveConstraint> constraint;
  AuthoredPriority priority;
  ModelProvenance provenance;

  friend bool operator==(const NodeExclusiveMaxWeightScheduler&,
                         const NodeExclusiveMaxWeightScheduler&) = default;
};

struct ConflictGraphMaxWeightScheduler final {
  AuthoredField<ConflictConstraint> constraint;
  AuthoredPriority priority;
  AuthoredField<std::optional<BigNat>> max_search_states;
  ModelProvenance provenance;

  friend bool operator==(const ConflictGraphMaxWeightScheduler&,
                         const ConflictGraphMaxWeightScheduler&) = default;
};

struct ResourcePackingMaxWeightScheduler final {
  AuthoredField<PackingConstraint> constraint;
  AuthoredPriority priority;
  AuthoredField<std::optional<BigNat>> max_search_states;
  ModelProvenance provenance;

  friend bool operator==(const ResourcePackingMaxWeightScheduler&,
                         const ResourcePackingMaxWeightScheduler&) = default;
};

enum class CompatibilitySchedulerKind : std::uint8_t {
  random_maximal,
  round_robin,
  islip_rga,
  islip_canonical,
};

struct RandomMaximalCompatibilityParams final {
  ModelProvenance provenance;
};

struct RoundRobinCompatibilityParams final {
  AuthoredField<BigNat> input_offset;
  AuthoredField<BigNat> output_offset;
  ModelProvenance provenance;
};

struct IslipRgaCompatibilityParams final {
  AuthoredField<BigNat> k;
  ModelProvenance provenance;
};

struct IslipCanonicalCompatibilityParams final {
  AuthoredField<BigNat> k;
  AuthoredField<std::optional<std::vector<AuthoredField<BigNat>>>>
      initial_grant_pointers;
  AuthoredField<std::optional<std::vector<AuthoredField<BigNat>>>>
      initial_accept_pointers;
  ModelProvenance provenance;
};

using CompatibilitySchedulerParams =
    std::variant<RandomMaximalCompatibilityParams,
                 RoundRobinCompatibilityParams, IslipRgaCompatibilityParams,
                 IslipCanonicalCompatibilityParams>;

// Compatibility schedulers are parsed to resolved typed defaults solely so
// canonical identity is stable before C04's scope gate.  They never enter a
// preferred exact scheduler alternative and have no execution semantics.
struct UnsupportedCompatibilityScheduler final {
  CompatibilitySchedulerKind kind;
  // The discriminator may be parser-defaulted independently of an authored
  // scheduler wrapper, so its provenance cannot be represented by the
  // wrapper provenance alone.
  ModelProvenance name_provenance;
  CompatibilitySchedulerParams params;
  SourceNode authored_params;
  ModelProvenance provenance;
};

using AuthoredSchedulerVariant =
    std::variant<CrossbarMaxWeightScheduler, IntervalMaxWeightScheduler,
                 NodeExclusiveMaxWeightScheduler,
                 ConflictGraphMaxWeightScheduler,
                 ResourcePackingMaxWeightScheduler,
                 UnsupportedCompatibilityScheduler>;

struct AuthoredSchedulerConfig final {
  AuthoredSchedulerVariant value;
  ModelProvenance provenance;
};

struct DestinationProbability final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;

  friend bool operator==(const DestinationProbability&,
                         const DestinationProbability&) = default;
};

struct StateProbability final {
  NormalizedToken state;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;

  friend bool operator==(const StateProbability&,
                         const StateProbability&) = default;
};

struct InitialExactState final {
  NormalizedToken state;
  ModelProvenance provenance;

  friend bool operator==(const InitialExactState&,
                         const InitialExactState&) = default;
};

struct InitialStateDistribution final {
  AuthoredField<std::vector<StateProbability>> distribution;
  ModelProvenance provenance;

  friend bool operator==(const InitialStateDistribution&,
                         const InitialStateDistribution&) = default;
};

using AuthoredInitialState =
    std::variant<InitialExactState, InitialStateDistribution>;

struct DeterministicInterarrival final {
  AuthoredField<BigNat> d;
  ModelProvenance provenance;

  friend bool operator==(const DeterministicInterarrival&,
                         const DeterministicInterarrival&) = default;
};

struct GapProbability final {
  AuthoredField<BigNat> d;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;

  friend bool operator==(const GapProbability&, const GapProbability&) = default;
};

struct FinitePmfInterarrival final {
  AuthoredField<std::vector<GapProbability>> outcomes;
  ModelProvenance provenance;

  friend bool operator==(const FinitePmfInterarrival&,
                         const FinitePmfInterarrival&) = default;
};

struct GeometricGridInterarrival final {
  AuthoredField<BigNat> d_min;
  AuthoredField<BigNat> delta;
  AuthoredField<AuthoredProbability> p;
  ModelProvenance provenance;

  friend bool operator==(const GeometricGridInterarrival&,
                         const GeometricGridInterarrival&) = default;
};

using AuthoredInterarrival =
    std::variant<DeterministicInterarrival, FinitePmfInterarrival,
                 GeometricGridInterarrival>;

struct TraceEvent final {
  AuthoredField<BigNat> slot;
  AuthoredField<QueueId> queue_id;
  AuthoredField<BigNat> count;
  ModelProvenance provenance;

  friend bool operator==(const TraceEvent&, const TraceEvent&) = default;
};

struct DeterministicTraceArrival final {
  AuthoredField<std::vector<TraceEvent>> events;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct PeriodicEntry final {
  AuthoredField<BigNat> offset;
  AuthoredField<QueueId> queue_id;
  AuthoredField<BigNat> count;
  ModelProvenance provenance;

  friend bool operator==(const PeriodicEntry&, const PeriodicEntry&) = default;
};

struct GlobalPhaseSource final {
  NormalizedToken id;
  AuthoredField<std::vector<PeriodicEntry>> entries;
  ModelProvenance provenance;
};

struct PeriodicGlobalPhaseArrival final {
  AuthoredField<BigNat> period;
  AuthoredField<BigNat> phase;
  AuthoredField<std::vector<GlobalPhaseSource>> sources;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct DelayedPeriodicSource final {
  NormalizedToken id;
  AuthoredField<BigNat> delay;
  AuthoredField<std::vector<PeriodicEntry>> entries;
  ModelProvenance provenance;
};

struct PeriodicSourceDelaysArrival final {
  AuthoredField<BigNat> period;
  AuthoredField<std::vector<DelayedPeriodicSource>> sources;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct FactorizedRenewalSource final {
  NormalizedToken id;
  AuthoredField<AuthoredInterarrival> interarrival;
  AuthoredField<std::vector<DestinationProbability>> destination_pmf;
  ModelProvenance provenance;
};

struct JointRenewalMass final {
  AuthoredField<BigNat> d;
  AuthoredField<QueueId> queue_id;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;

  friend bool operator==(const JointRenewalMass&,
                         const JointRenewalMass&) = default;
};

struct JointRenewalSource final {
  NormalizedToken id;
  AuthoredField<std::vector<JointRenewalMass>> joint_pmf;
  ModelProvenance provenance;
};

using MarkedRenewalSource =
    std::variant<FactorizedRenewalSource, JointRenewalSource>;

struct IndependentMarkedRenewalArrival final {
  AuthoredField<std::vector<MarkedRenewalSource>> sources;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct StateGap final {
  NormalizedToken state;
  AuthoredField<BigNat> d;
  ModelProvenance provenance;

  friend bool operator==(const StateGap&, const StateGap&) = default;
};

struct StateTransition final {
  NormalizedToken state;
  NormalizedToken next_state;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;

  friend bool operator==(const StateTransition&,
                         const StateTransition&) = default;
};

struct PrivateMarkovRenewalSource final {
  NormalizedToken id;
  AuthoredField<std::vector<NormalizedToken>> states;
  AuthoredField<AuthoredInitialState> initial;
  AuthoredField<std::vector<StateGap>> gaps;
  AuthoredField<std::vector<StateTransition>> transitions;
  AuthoredField<std::vector<DestinationProbability>> destination_pmf;
  ModelProvenance provenance;
};

struct IndependentPrivateMarkovRenewalArrival final {
  AuthoredField<std::vector<PrivateMarkovRenewalSource>> sources;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct SharedRenewalSource final {
  NormalizedToken id;
  ModelProvenance provenance;

  friend bool operator==(const SharedRenewalSource&,
                         const SharedRenewalSource&) = default;
};

struct SharedEmission final {
  NormalizedToken source_id;
  AuthoredField<BigNat> d;
  AuthoredField<QueueId> queue_id;
  ModelProvenance provenance;

  friend bool operator==(const SharedEmission&, const SharedEmission&) = default;
};

struct SharedOutcome final {
  NormalizedToken state;
  NormalizedToken next_state;
  AuthoredField<AuthoredProbability> probability;
  AuthoredField<std::vector<SharedEmission>> emissions;
  ModelProvenance provenance;
};

struct SharedJointRoundMarkovRenewalArrival final {
  AuthoredField<std::vector<SharedRenewalSource>> sources;
  AuthoredField<std::vector<NormalizedToken>> states;
  AuthoredField<AuthoredInitialState> initial;
  AuthoredField<std::vector<SharedOutcome>> outcomes;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

// Schema-4 IID laws -------------------------------------------------------

struct QueueRateOverride final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<ExactRational> rate;
  ModelProvenance provenance;

  friend bool operator==(const QueueRateOverride&,
                         const QueueRateOverride&) = default;
};

struct ExactQueueRates final {
  AuthoredField<ExactRational> default_rate;
  AuthoredField<std::vector<QueueRateOverride>> overrides;
  ModelProvenance provenance;

  friend bool operator==(const ExactQueueRates&, const ExactQueueRates&) =
      default;
};

struct IidIndependentBernoulliArrival final {
  ExactQueueRates rates;
  AuthoredMetadata metadata;
  ModelProvenance provenance;

  friend bool operator==(const IidIndependentBernoulliArrival&,
                         const IidIndependentBernoulliArrival&) = default;
};

struct IidCountEntry final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<BigNat> count;
  ModelProvenance provenance;

  friend bool operator==(const IidCountEntry&, const IidCountEntry&) = default;
};

struct IidCountOutcome final {
  NormalizedToken id;
  AuthoredField<AuthoredProbability> probability;
  AuthoredField<std::vector<IidCountEntry>> counts;
  ModelProvenance provenance;

  friend bool operator==(const IidCountOutcome&,
                         const IidCountOutcome&) = default;
};

struct IidCountTableArrival final {
  AuthoredField<std::vector<IidCountOutcome>> outcomes;
  AuthoredMetadata metadata;
  ModelProvenance provenance;

  friend bool operator==(const IidCountTableArrival&,
                         const IidCountTableArrival&) = default;
};

struct IidIndependentPoissonArrival final {
  ExactQueueRates rates;
  AuthoredMetadata metadata;
  ModelProvenance provenance;

  friend bool operator==(const IidIndependentPoissonArrival&,
                         const IidIndependentPoissonArrival&) = default;
};

enum class MixedPoissonScope : std::uint8_t {
  shared,
  independent_queue,
};

struct MixedPoissonState final {
  NormalizedToken id;
  AuthoredField<AuthoredProbability> probability;
  AuthoredField<ExactRational> multiplier;
  ModelProvenance provenance;

  friend bool operator==(const MixedPoissonState&,
                         const MixedPoissonState&) = default;
};

struct MixedPoissonModulation final {
  AuthoredField<MixedPoissonScope> scope;
  AuthoredField<std::vector<MixedPoissonState>> states;
  // These are always populated.  When omitted in source they are exact
  // parser-derived values with defaulted provenance.
  AuthoredField<ExactRational> mean_multiplier;
  AuthoredField<ExactRational> second_moment_multiplier;
  ModelProvenance provenance;

  friend bool operator==(const MixedPoissonModulation&,
                         const MixedPoissonModulation&) = default;
};

struct IidMixedPoissonArrival final {
  ExactQueueRates rates;
  MixedPoissonModulation modulation;
  AuthoredMetadata metadata;
  ModelProvenance provenance;

  friend bool operator==(const IidMixedPoissonArrival&,
                         const IidMixedPoissonArrival&) = default;
};

enum class CompatibilityArrivalKind : std::uint8_t {
  iid_table,
  markov_kernel,
  factorized_bernoulli,
};

struct LegacyEdgeCoordinate final {
  AuthoredField<BigNat> source;
  AuthoredField<BigNat> destination;
  ModelProvenance provenance;
};

enum class AllowedEdgesMode : std::uint8_t { full, explicit_list };

struct CompatibilityAllowedEdges final {
  AuthoredField<AllowedEdgesMode> mode;
  AuthoredField<std::vector<LegacyEdgeCoordinate>> edges;
  ModelProvenance provenance;
};

enum class AlphabetConstraintMode : std::uint8_t {
  unrestricted,
  per_input_line_rate,
  global_one_hot,
};

struct CompatibilityArrivalCommon final {
  CompatibilityAllowedEdges allowed_edges;
  AuthoredField<AlphabetConstraintMode> alphabet_constraint;
};

struct IidTableAtom final {
  AuthoredField<std::optional<NormalizedToken>> id;
  AuthoredField<std::vector<LegacyEdgeCoordinate>> edges;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;
};

struct IidTableCompatibilityArrival final {
  CompatibilityArrivalCommon common;
  AuthoredField<std::vector<IidTableAtom>> alphabet;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct MarkovKernelMask final {
  NormalizedToken id;
  AuthoredField<std::vector<LegacyEdgeCoordinate>> edges;
  ModelProvenance provenance;
};

struct MarkovKernelRow final {
  NormalizedToken state;
  NormalizedToken mask_id;
  NormalizedToken next_state;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;
};

struct MarkovKernelCompatibilityArrival final {
  CompatibilityArrivalCommon common;
  AuthoredField<std::vector<NormalizedToken>> states;
  AuthoredField<std::vector<MarkovKernelMask>> alphabet;
  AuthoredField<std::vector<MarkovKernelRow>> kernel;
  AuthoredField<AuthoredInitialState> initial;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

struct BernoulliOverride final {
  AuthoredField<BigNat> source;
  AuthoredField<BigNat> destination;
  AuthoredField<AuthoredProbability> probability;
  ModelProvenance provenance;
};

struct FactorizedBernoulliCompatibilityArrival final {
  CompatibilityArrivalCommon common;
  AuthoredField<AuthoredProbability> default_probability;
  AuthoredField<std::vector<BernoulliOverride>> overrides;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

using CompatibilityArrivalPayload =
    std::variant<IidTableCompatibilityArrival,
                 MarkovKernelCompatibilityArrival,
                 FactorizedBernoulliCompatibilityArrival>;

// As with compatibility schedulers, the closed source object is retained for
// diagnostics while resolved typed values (including defaults and normalized
// tokens) determine canonical identity.  C04 rejects this alternative before
// any arrival compiler is selected.
struct UnsupportedCompatibilityArrival final {
  CompatibilityArrivalKind kind;
  CompatibilityArrivalPayload value;
  SourceNode authored_object;
  ModelProvenance provenance;
};

using AuthoredArrivalVariant =
    std::variant<DeterministicTraceArrival, PeriodicGlobalPhaseArrival,
                 PeriodicSourceDelaysArrival,
                 IndependentMarkedRenewalArrival,
                 IndependentPrivateMarkovRenewalArrival,
                 SharedJointRoundMarkovRenewalArrival,
                 IidIndependentBernoulliArrival, IidCountTableArrival,
                 IidIndependentPoissonArrival, IidMixedPoissonArrival,
                 UnsupportedCompatibilityArrival>;

struct AuthoredArrivalConfig final {
  AuthoredArrivalVariant value;
  ModelProvenance provenance;
};

enum class QueueSnapshotMode : std::uint8_t {
  dense,
  sparse_nonzero,
  disabled,
};

enum class ObservationGapMode : std::uint8_t {
  none,
  exact,
};

struct AuthoredObservationTarget final {
  AuthoredField<QueueId> queue_id;
  AuthoredField<ObservationGapMode> gap;
  ModelProvenance provenance;

  friend bool operator==(const AuthoredObservationTarget&,
                         const AuthoredObservationTarget&) = default;
};

struct AuthoredObservationTelemetry final {
  AuthoredField<bool> enabled;
  AuthoredField<std::optional<BigNat>> block_slots;
  AuthoredField<std::vector<AuthoredObservationTarget>> targets;
  ModelProvenance provenance;

  friend bool operator==(const AuthoredObservationTelemetry&,
                         const AuthoredObservationTelemetry&) = default;
};

struct AuthoredTelemetryConfig final {
  AuthoredField<std::string> format;
  AuthoredField<QueueSnapshotMode> queue_snapshot;
  AuthoredField<bool> include_packet_events;
  AuthoredField<bool> include_scheduler_state;
  AuthoredField<bool> write_slot_trace;
  ModelProvenance provenance;
  // Absent for schema 3.  Schema 4 always materializes a typed observation
  // declaration, including the disabled/default case.
  std::optional<AuthoredObservationTelemetry> observation = std::nullopt;

  friend bool operator==(const AuthoredTelemetryConfig&,
                         const AuthoredTelemetryConfig&) = default;
};

struct AuthoredModelConfig final {
  AuthoredField<std::string> schema_version;
  AuthoredRunConfig run;
  AuthoredSwitchConfig switch_config;
  AuthoredSchedulerConfig scheduler;
  AuthoredArrivalConfig arrival;
  AuthoredTelemetryConfig telemetry;
  AuthoredMetadata metadata;
  ModelProvenance provenance;
};

// F-C03-04
[[nodiscard]] Result<AuthoredModelConfig> parse_model_config_v3(
    const ModelNode& model);

// Native schema-4 parser.  It never rewrites the source into schema 3.
[[nodiscard]] Result<AuthoredModelConfig> parse_model_config_v4(
    const ModelNode& model);

// Closed version dispatcher used by the application boundary.  A missing
// version retains the released schema-3 default; an authored 4.0.0 document
// selects the native schema-4 path.
[[nodiscard]] Result<AuthoredModelConfig> parse_model_config(
    const ModelNode& model);

}  // namespace mwperf
