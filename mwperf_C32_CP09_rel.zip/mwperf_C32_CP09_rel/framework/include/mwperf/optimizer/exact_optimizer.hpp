#pragma once

#include <functional>
#include <optional>
#include <string>
#include <vector>

#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// F-C05-03.  budget must have been obtained from begin_search_budget and may
// authorize exactly this one cold dispatch. C08 registers all five preferred
// exact families. No family may fall back to another optimizer or publish an
// incumbent when its exact recursive search budget is exhausted.
[[nodiscard]] Result<OptimizerSolution> solve_exact(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget);

// F-C05-06.  Defined in maxweight_resolver.cpp; declared here because this is
// the stable public exact-optimizer boundary rather than a process/CLI API.
[[nodiscard]] Result<ScheduleDecision> resolve_maxweight_schedule(
    const ResolvedInstance& instance, const Backlog& backlog,
    const TieContext& tie_context, OptimizerExecutionContext& context);

namespace detail {

// A forced side is not represented by a weight perturbation. This private
// carrier is delivered to the selected exact backend, which must condition
// its family geometry on that side.
struct ForcedTargetCondition final {
  TargetIndex target;
  ForcedTargetBit bit;

  friend bool operator==(const ForcedTargetCondition&,
                         const ForcedTargetCondition&) = default;
};

// A callback may return this type only from its explicitly named exact-success
// path. Partial/incumbent state has no conversion to it. Dispatch still treats
// every field as untrusted data and publishes no OptimizerSolution until the
// common boundary checks have passed transactionally.
class ExactBackendCandidate final {
 public:
  ExactBackendCandidate() = delete;
  ExactBackendCandidate(const ExactBackendCandidate&) = default;
  ExactBackendCandidate(ExactBackendCandidate&&) noexcept = default;
  ExactBackendCandidate& operator=(const ExactBackendCandidate&) = default;
  ExactBackendCandidate& operator=(ExactBackendCandidate&&) noexcept = default;

  [[nodiscard]] const Schedule& schedule() const noexcept { return schedule_; }
  [[nodiscard]] const BigNat& composite_objective() const noexcept {
    return composite_objective_;
  }
  [[nodiscard]] ServiceFamily family() const noexcept { return family_; }
  [[nodiscard]] OptimizerId backend_id() const noexcept { return backend_id_; }
  [[nodiscard]] const SearchAccounting& accounting() const noexcept {
    return accounting_;
  }
  [[nodiscard]] const std::vector<std::string>& proof_notes() const noexcept {
    return proof_notes_;
  }

 private:
  ExactBackendCandidate(Schedule schedule, BigNat composite_objective,
                        ServiceFamily family, OptimizerId backend_id,
                        SearchAccounting accounting,
                        std::vector<std::string> proof_notes)
      : schedule_(std::move(schedule)),
        composite_objective_(std::move(composite_objective)),
        family_(family),
        backend_id_(backend_id),
        accounting_(std::move(accounting)),
        proof_notes_(std::move(proof_notes)) {}

  Schedule schedule_;
  BigNat composite_objective_;
  ServiceFamily family_;
  OptimizerId backend_id_;
  SearchAccounting accounting_;
  std::vector<std::string> proof_notes_;

  friend class ExactBackendAuthority;
  friend class ExactDispatchAccess;
};

// Dispatch creates this noncopyable, nonmovable capability for one backend
// invocation and passes it by const reference. A registered exact backend may
// package its claimed exact-success data only while it holds that capability;
// no macro or public constructor can manufacture one. The candidate remains
// unproven until the dispatch boundary checks and promotes it.
class ExactBackendAuthority final {
 public:
  ExactBackendAuthority() = delete;
  ExactBackendAuthority(const ExactBackendAuthority&) = delete;
  ExactBackendAuthority(ExactBackendAuthority&&) = delete;
  ExactBackendAuthority& operator=(const ExactBackendAuthority&) = delete;
  ExactBackendAuthority& operator=(ExactBackendAuthority&&) = delete;

  [[nodiscard]] ExactBackendCandidate make_candidate(
      Schedule schedule, BigNat composite_objective, ServiceFamily family,
      OptimizerId backend_id, SearchAccounting accounting,
      std::vector<std::string> proof_notes = {}) const;

 private:
  explicit ExactBackendAuthority(const SearchBudget& budget) noexcept
      : budget_(&budget) {}

  const SearchBudget* budget_;

  friend class ExactDispatchAccess;
};

// Incumbents and partial recursion products are intentionally a different,
// nonconvertible type. Exhaustion code can destroy one without any API route
// to ExactBackendCandidate, OptimizerSolution, or ProvenOptimal.
struct PartialOptimizerCandidate final {
  Schedule schedule;
  BigNat composite_objective;
};

// Private condition-aware route used by F-C05-04.  It is the same F-C05-03
// dispatch core: the additional value cannot select a backend and exists only
// to require one exact forced side from that family's adapter.
[[nodiscard]] Result<OptimizerSolution> solve_exact_conditioned(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    std::optional<ForcedTargetCondition> condition);

#if defined(MWPERF_C05_TEST_SEAMS)

// Per-call test injection for the common contract suite.  It is deliberately
// absent from production translation units: there is no mutable/global
// registry, dynamic ABI, or fallback backend.  Each callback is statically
// tied to one concrete C04 descriptor and receives the opaque compiled-product
// lifetime token plus a typed optional forced-side condition.
template <typename Constraint>
using ExactBackend = std::function<Result<ExactBackendCandidate>(
    const Constraint&, const CompiledConstraintProduct&,
    const EligibilityMask&, const LexWeights&, SearchBudget&,
    const std::optional<ForcedTargetCondition>&,
    const ExactBackendAuthority&)>;

struct ExactOptimizerBackendServices final {
  ExactBackend<ResolvedCrossbarConstraint> crossbar;
  ExactBackend<ResolvedIntervalConstraint> intervals;
  ExactBackend<ResolvedNodeExclusiveConstraint> node_exclusive;
  ExactBackend<ResolvedConflictConstraint> conflicts;
  ExactBackend<ResolvedPackingConstraint> packing;
};

[[nodiscard]] Result<OptimizerSolution> solve_exact_with_backend_services(
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility, const LexWeights& weights,
    SearchBudget& budget,
    std::optional<ForcedTargetCondition> condition,
    const ExactOptimizerBackendServices& services);

// Test-only full-resolver route defined beside F-C05-06. It threads the same
// per-call services into one cold dispatch and cannot retain or register them.
[[nodiscard]] Result<ScheduleDecision>
resolve_maxweight_schedule_with_backend_services(
    const ResolvedInstance& instance, const Backlog& backlog,
    const TieContext& tie_context, OptimizerExecutionContext& context,
    const ExactOptimizerBackendServices& services);

#endif

}  // namespace detail
}  // namespace mwperf
