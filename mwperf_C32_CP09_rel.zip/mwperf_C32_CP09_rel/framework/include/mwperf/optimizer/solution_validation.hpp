#pragma once

#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {

// Shared implementation for trusted C05 entry points whose DAG edge is to the
// validation semantics but not to the public catalog function.  This is not a
// relaxed validator: forced-query code must pass the exact conditioned query
// mask and weights and then check its requested target bit separately.
[[nodiscard]] Result<void> validate_optimizer_solution_core(
    const OptimizerSolution& solution,
    const ConstraintDescriptor& constraint,
    const EligibilityMask& eligibility, const LexWeights& weights);

}  // namespace detail

// F-C05-05. This independently validates the exact-success carrier at the
// common optimizer boundary. It verifies the returned witness, not optimality;
// only the statically linked exact backend is authorized to create the
// ProvenOptimal tag.
[[nodiscard]] Result<void> validate_optimizer_solution(
    const OptimizerSolution& solution,
    const ConstraintDescriptor& constraint,
    const EligibilityMask& eligibility, const LexWeights& weights);

}  // namespace mwperf
