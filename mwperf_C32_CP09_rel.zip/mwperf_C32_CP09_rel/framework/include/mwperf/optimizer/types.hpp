#pragma once

#include <concepts>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/canonical_input.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class SearchBudget;
class OptimizerSolution;
class PriorityOrder;
class QueueDimensionToken;
class LexWeights;

namespace detail {

struct BacklogDomain final {
  static constexpr std::string_view name = "backlog";
};
struct PrimaryWeightsDomain final {
  static constexpr std::string_view name = "primary_weights";
};
struct EligibilityDomain final {
  static constexpr std::string_view name = "eligibility";
};
struct ScheduleDomain final {
  static constexpr std::string_view name = "schedule";
};

[[nodiscard]] inline Diagnostic optimizer_type_diagnostic(
    std::string code, std::string message,
    std::vector<std::string> notes = {}) {
  return Diagnostic{
      .category = DiagnosticCategory::internal,
      .code = std::move(code),
      .message = std::move(message),
      .authored_path = std::nullopt,
      .json_pointer = std::nullopt,
      .notes = std::move(notes),
  };
}

class ExactBackendCandidate;
struct ForcedTargetCondition;
struct ExactOptimizerBackendServices;
class ExactDispatchAccess;
class LexWeightsAccess;

}  // namespace detail

// Dense vectors from two resolved requests are noninterchangeable even when
// they happen to have the same length. The portable input digest is combined
// with process-local compiled-geometry ownership, the exact configured
// priority permutation, and the immutable optimizer policy. Consequently a
// vector cannot silently cross either a physical/request boundary or a local
// accounting-policy boundary.
class QueueDimensionToken final {
 public:
  QueueDimensionToken() = delete;
  QueueDimensionToken(const QueueDimensionToken&) = default;
  QueueDimensionToken(QueueDimensionToken&&) noexcept = default;
  QueueDimensionToken& operator=(const QueueDimensionToken&) = default;
  QueueDimensionToken& operator=(QueueDimensionToken&&) noexcept = default;

  [[nodiscard]] static QueueDimensionToken from_instance(
      const ResolvedInstance& instance);

  [[nodiscard]] const Digest256& combined_input() const noexcept {
    return combined_input_;
  }
  [[nodiscard]] std::size_t cardinality() const noexcept {
    return cardinality_;
  }
  [[nodiscard]] ServiceFamily family() const noexcept { return family_; }
  [[nodiscard]] const PriorityOrder& configured_priority() const noexcept {
    return *configured_priority_;
  }
  [[nodiscard]] const OptimizerBudgetPolicy& base_optimizer_policy()
      const noexcept {
    return base_optimizer_policy_;
  }

  [[nodiscard]] bool matches(const ResolvedInstance& instance) const;
  [[nodiscard]] bool matches(const ConstraintDescriptor& descriptor) const;
  [[nodiscard]] bool matches_priority(const PriorityOrder& priority) const
      noexcept;
  [[nodiscard]] bool matches_optimizer_policy(
      const OptimizerBudgetPolicy& policy) const noexcept;

#if defined(MWPERF_C05_TEST_SEAMS)
  [[nodiscard]] static QueueDimensionToken for_fixture(
      Digest256 combined_input, std::size_t cardinality,
      const ConstraintDescriptor& descriptor,
      const PriorityOrder& configured_priority,
      const OptimizerBudgetPolicy& base_optimizer_policy);
#endif

  friend bool operator==(const QueueDimensionToken& lhs,
                         const QueueDimensionToken& rhs) noexcept {
    return lhs.combined_input_ == rhs.combined_input_ &&
           lhs.cardinality_ == rhs.cardinality_ &&
           lhs.family_ == rhs.family_ &&
           lhs.configured_priority_ && rhs.configured_priority_ &&
           same_priority(*lhs.configured_priority_,
                         *rhs.configured_priority_) &&
           same_policy(lhs.base_optimizer_policy_,
                       rhs.base_optimizer_policy_) &&
           lhs.owner_ && rhs.owner_ &&
           !lhs.owner_.owner_before(rhs.owner_) &&
           !rhs.owner_.owner_before(lhs.owner_);
  }

 private:
  QueueDimensionToken(Digest256 combined_input, std::size_t cardinality,
                      ServiceFamily family,
                      std::shared_ptr<const PriorityOrder> configured_priority,
                      OptimizerBudgetPolicy base_optimizer_policy,
                      std::shared_ptr<const void> owner)
      : combined_input_(std::move(combined_input)),
        cardinality_(cardinality),
        family_(family),
        configured_priority_(std::move(configured_priority)),
        base_optimizer_policy_(std::move(base_optimizer_policy)),
        owner_(std::move(owner)) {}

  [[nodiscard]] static bool same_priority(
      const PriorityOrder& lhs, const PriorityOrder& rhs) noexcept {
    if (lhs.size() != rhs.size() ||
        lhs.queue_to_rank().size() != rhs.queue_to_rank().size()) {
      return false;
    }
    for (std::size_t rank = 0; rank < lhs.size(); ++rank) {
      if (lhs.rank_to_queue()[rank].ordinal() !=
          rhs.rank_to_queue()[rank].ordinal()) {
        return false;
      }
    }
    for (std::size_t queue = 0; queue < lhs.queue_to_rank().size(); ++queue) {
      if (lhs.queue_to_rank()[queue] != rhs.queue_to_rank()[queue]) {
        return false;
      }
    }
    return true;
  }

  [[nodiscard]] static bool same_policy(
      const OptimizerBudgetPolicy& lhs,
      const OptimizerBudgetPolicy& rhs) noexcept {
    return lhs.physical_per_call == rhs.physical_per_call &&
           lhs.analysis_per_call == rhs.analysis_per_call &&
           lhs.effective_per_call == rhs.effective_per_call &&
           lhs.max_calls == rhs.max_calls;
  }

  [[nodiscard]] static std::size_t descriptor_cardinality(
      const ConstraintDescriptor& descriptor) noexcept {
    return std::visit(
        [](const auto& constraint) -> std::size_t {
          using Constraint = std::decay_t<decltype(constraint)>;
          if constexpr (std::same_as<Constraint,
                                     ResolvedCrossbarConstraint>) {
            return constraint.edges.size();
          } else if constexpr (std::same_as<Constraint,
                                            ResolvedIntervalConstraint>) {
            return constraint.intervals.size();
          } else if constexpr (std::same_as<
                                   Constraint,
                                   ResolvedNodeExclusiveConstraint>) {
            return constraint.links.size();
          } else if constexpr (std::same_as<Constraint,
                                            ResolvedConflictConstraint>) {
            return constraint.adjacency.size();
          } else {
            return constraint.demands.size();
          }
        },
        descriptor.value());
  }

  Digest256 combined_input_;
  std::size_t cardinality_;
  ServiceFamily family_;
  std::shared_ptr<const PriorityOrder> configured_priority_;
  OptimizerBudgetPolicy base_optimizer_policy_;
  std::shared_ptr<const void> owner_;
};

inline QueueDimensionToken QueueDimensionToken::from_instance(
    const ResolvedInstance& instance) {
  const CompiledConstraintProduct& product =
      instance.constraint().compiled_product();
  return QueueDimensionToken(
      instance.fingerprints().combined, instance.queues().size(),
      instance.constraint().family(),
      std::make_shared<const PriorityOrder>(instance.priority()),
      instance.optimizer_budget(), product.owner_);
}

inline bool QueueDimensionToken::matches(
    const ResolvedInstance& instance) const {
  return *this == from_instance(instance);
}

inline bool QueueDimensionToken::matches(
    const ConstraintDescriptor& descriptor) const {
  const CompiledConstraintProduct& product = descriptor.compiled_product();
  return family_ == descriptor.family() &&
         product.family_ == descriptor.family() && owner_ && product.owner_ &&
         cardinality_ == descriptor_cardinality(descriptor) &&
         !owner_.owner_before(product.owner_) &&
         !product.owner_.owner_before(owner_);
}

inline bool QueueDimensionToken::matches_priority(
    const PriorityOrder& priority) const noexcept {
  return configured_priority_ && same_priority(*configured_priority_, priority);
}

inline bool QueueDimensionToken::matches_optimizer_policy(
    const OptimizerBudgetPolicy& policy) const noexcept {
  return same_policy(base_optimizer_policy_, policy);
}

template <typename Domain>
class DenseBigNatVector final {
 public:
  DenseBigNatVector() = delete;
  DenseBigNatVector(const DenseBigNatVector&) = default;
  DenseBigNatVector(DenseBigNatVector&&) noexcept = default;
  DenseBigNatVector& operator=(const DenseBigNatVector&) = default;
  DenseBigNatVector& operator=(DenseBigNatVector&&) noexcept = default;

  [[nodiscard]] static Result<DenseBigNatVector> from_values(
      QueueDimensionToken dimension, std::vector<BigNat> values) {
    if (values.size() != dimension.cardinality()) {
      return Result<DenseBigNatVector>::failure(
          detail::optimizer_type_diagnostic(
              std::string(Domain::name) + "_dimension_mismatch",
              std::string(Domain::name) +
                  " does not match its queue-dimension token",
              {"expected " + std::to_string(dimension.cardinality()) +
               " entries; received " + std::to_string(values.size())}));
    }
    return Result<DenseBigNatVector>::success(
        DenseBigNatVector(std::move(dimension), std::move(values)));
  }

  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return dimension_;
  }
  [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
  [[nodiscard]] std::span<const BigNat> values() const noexcept {
    return values_;
  }
  [[nodiscard]] const BigNat& at(DenseQueueIndex queue) const {
    return values_.at(queue.ordinal());
  }

  friend bool operator==(const DenseBigNatVector&,
                         const DenseBigNatVector&) = default;

 private:
  DenseBigNatVector(QueueDimensionToken dimension,
                    std::vector<BigNat> values)
      : dimension_(std::move(dimension)), values_(std::move(values)) {}

  QueueDimensionToken dimension_;
  std::vector<BigNat> values_;
};

using Backlog = DenseBigNatVector<detail::BacklogDomain>;
using PrimaryWeights = DenseBigNatVector<detail::PrimaryWeightsDomain>;
using NonnegativeIntegralWeights = PrimaryWeights;

template <typename Domain>
class DenseBinaryVector final {
 public:
  DenseBinaryVector() = delete;
  DenseBinaryVector(const DenseBinaryVector&) = default;
  DenseBinaryVector(DenseBinaryVector&&) noexcept = default;
  DenseBinaryVector& operator=(const DenseBinaryVector&) = default;
  DenseBinaryVector& operator=(DenseBinaryVector&&) noexcept = default;

  [[nodiscard]] static Result<DenseBinaryVector> from_bytes(
      QueueDimensionToken dimension, std::vector<std::uint8_t> values) {
    if (values.size() != dimension.cardinality()) {
      return Result<DenseBinaryVector>::failure(
          detail::optimizer_type_diagnostic(
              std::string(Domain::name) + "_dimension_mismatch",
              std::string(Domain::name) +
                  " does not match its queue-dimension token",
              {"expected " + std::to_string(dimension.cardinality()) +
               " entries; received " + std::to_string(values.size())}));
    }
    for (std::size_t index = 0; index < values.size(); ++index) {
      if (values[index] > 1U) {
        return Result<DenseBinaryVector>::failure(
            detail::optimizer_type_diagnostic(
                std::string(Domain::name) + "_not_binary",
                std::string(Domain::name) +
                    " contains a value outside the binary domain",
                {"entry " + std::to_string(index) + " has value " +
                 std::to_string(values[index])}));
      }
    }
    return Result<DenseBinaryVector>::success(
        DenseBinaryVector(std::move(dimension), std::move(values)));
  }

  [[nodiscard]] static DenseBinaryVector all(QueueDimensionToken dimension) {
    std::vector<std::uint8_t> values(dimension.cardinality(), 1U);
    return DenseBinaryVector(std::move(dimension), std::move(values));
  }

  [[nodiscard]] static DenseBinaryVector none(QueueDimensionToken dimension) {
    std::vector<std::uint8_t> values(dimension.cardinality(), 0U);
    return DenseBinaryVector(std::move(dimension), std::move(values));
  }

  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return dimension_;
  }
  [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
  [[nodiscard]] std::span<const std::uint8_t> bytes() const noexcept {
    return values_;
  }
  [[nodiscard]] bool at(DenseQueueIndex queue) const {
    return values_.at(queue.ordinal()) != 0U;
  }

  friend bool operator==(const DenseBinaryVector&,
                         const DenseBinaryVector&) = default;

 private:
  DenseBinaryVector(QueueDimensionToken dimension,
                    std::vector<std::uint8_t> values)
      : dimension_(std::move(dimension)), values_(std::move(values)) {}

  QueueDimensionToken dimension_;
  std::vector<std::uint8_t> values_;
};

using EligibilityMask = DenseBinaryVector<detail::EligibilityDomain>;
using Schedule = DenseBinaryVector<detail::ScheduleDomain>;

// A target coordinate is not merely a native/dense ordinal. It retains the
// complete optimizer-domain identity, so an equal ordinal from another
// resolved instance, compiled product, priority, or base policy cannot be
// substituted accidentally. There is deliberately no DenseQueueIndex or
// native-integer conversion operator.
class TargetIndex final {
 public:
  TargetIndex() = delete;
  TargetIndex(const TargetIndex&) = default;
  TargetIndex(TargetIndex&&) noexcept = default;
  TargetIndex& operator=(const TargetIndex&) = default;
  TargetIndex& operator=(TargetIndex&&) noexcept = default;

  [[nodiscard]] static Result<TargetIndex> from_dimension(
      QueueDimensionToken dimension, std::size_t ordinal) {
    if (ordinal >= dimension.cardinality()) {
      return Result<TargetIndex>::failure(
          detail::optimizer_type_diagnostic(
              "target_index_out_of_range",
              "the target index lies outside its queue dimension",
              {"target index: " + std::to_string(ordinal),
               "queue dimension: " +
                   std::to_string(dimension.cardinality())}));
    }
    return Result<TargetIndex>::success(
        TargetIndex(std::move(dimension), ordinal));
  }

  [[nodiscard]] static Result<TargetIndex> from_instance(
      const ResolvedInstance& instance, const std::size_t ordinal) {
    return from_dimension(QueueDimensionToken::from_instance(instance),
                          ordinal);
  }

  [[nodiscard]] std::size_t ordinal() const noexcept { return ordinal_; }
  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return dimension_;
  }
  [[nodiscard]] bool matches(
      const QueueDimensionToken& dimension) const noexcept {
    return dimension_ == dimension;
  }
  [[nodiscard]] bool matches(const ResolvedInstance& instance) const {
    return dimension_.matches(instance);
  }

  friend bool operator==(const TargetIndex&, const TargetIndex&) = default;

 private:
  TargetIndex(QueueDimensionToken dimension, const std::size_t ordinal)
      : dimension_(std::move(dimension)), ordinal_(ordinal) {}

  QueueDimensionToken dimension_;
  std::size_t ordinal_;
};

// Composite weights retain the exact B=2^m scale and each queue's secondary
// priority bit. Eligibility is copied as a separately typed mask: ineligible
// coordinates are never represented by modifying their mathematical weight.
class LexWeights final {
 public:
  LexWeights() = delete;
  LexWeights(const LexWeights&) = default;
  LexWeights(LexWeights&&) noexcept = default;
  LexWeights& operator=(const LexWeights&) = default;
  LexWeights& operator=(LexWeights&&) noexcept = default;

  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return primary_.dimension();
  }
  [[nodiscard]] std::size_t size() const noexcept { return primary_.size(); }
  [[nodiscard]] const PrimaryWeights& primary() const noexcept {
    return primary_;
  }
  [[nodiscard]] const BigNat& primary_weight(DenseQueueIndex queue) const {
    return primary_.at(queue);
  }
  [[nodiscard]] std::span<const BigNat> values() const noexcept {
    return values_;
  }
  [[nodiscard]] const BigNat& at(DenseQueueIndex queue) const {
    return values_.at(queue.ordinal());
  }
  [[nodiscard]] const BigNat& primary_scale() const noexcept {
    return primary_scale_;
  }
  [[nodiscard]] std::span<const BigNat> secondary_weights() const noexcept {
    return secondary_weights_;
  }
  [[nodiscard]] const BigNat& secondary_weight(DenseQueueIndex queue) const {
    return secondary_weights_.at(queue.ordinal());
  }
  [[nodiscard]] const EligibilityMask& eligibility() const noexcept {
    return eligibility_;
  }

  friend bool operator==(const LexWeights&, const LexWeights&) = default;

 private:
  LexWeights(PrimaryWeights primary, std::vector<BigNat> values,
             BigNat primary_scale, std::vector<BigNat> secondary_weights,
             EligibilityMask eligibility)
      : primary_(std::move(primary)),
        values_(std::move(values)),
        primary_scale_(std::move(primary_scale)),
        secondary_weights_(std::move(secondary_weights)),
        eligibility_(std::move(eligibility)) {}

  PrimaryWeights primary_;
  std::vector<BigNat> values_;
  BigNat primary_scale_;
  std::vector<BigNat> secondary_weights_;
  EligibilityMask eligibility_;

  friend class detail::LexWeightsAccess;
};

namespace detail {

// The complete access type is intentionally present in every consumer
// translation unit.  A caller therefore cannot complete an opaque friend with
// additional construction authority.  Its sole operation performs the full
// F-C05-01 validation and composition transaction; raw LexWeights fields are
// never accepted from a caller.
class LexWeightsAccess final {
 public:
  LexWeightsAccess() = delete;

  [[nodiscard]] static Result<LexWeights> compose(
      const NonnegativeIntegralWeights& primary,
      const PriorityOrder& priority, const EligibilityMask& eligibility);
};

}  // namespace detail

enum class OptimizerQueryKind : std::uint8_t {
  ordinary,
  forced_zero,
  forced_one,
  integral_support,
  rational_support,
  generic_exact,
};

[[nodiscard]] constexpr std::string_view to_string(
    const OptimizerQueryKind kind) noexcept {
  switch (kind) {
    case OptimizerQueryKind::ordinary:
      return "ordinary";
    case OptimizerQueryKind::forced_zero:
      return "forced_zero";
    case OptimizerQueryKind::forced_one:
      return "forced_one";
    case OptimizerQueryKind::integral_support:
      return "integral_support";
    case OptimizerQueryKind::rational_support:
      return "rational_support";
    case OptimizerQueryKind::generic_exact:
      return "generic_exact";
  }
  return "unknown";
}

// Immutable report of one process-local reservation and solve. It is evidence
// only: no execution context accepts a SearchAccounting value as input, so an
// external report cannot recreate or reset locally charged calls.
class SearchAccounting final {
 public:
  SearchAccounting() = delete;
  SearchAccounting(const SearchAccounting&) = default;
  SearchAccounting(SearchAccounting&&) noexcept = default;
  SearchAccounting& operator=(const SearchAccounting&) = default;
  SearchAccounting& operator=(SearchAccounting&&) noexcept = default;

  [[nodiscard]] const BigNat& call_ordinal() const noexcept {
    return call_ordinal_;
  }
  [[nodiscard]] const std::optional<BigNat>& effective_per_call_limit()
      const noexcept {
    return effective_per_call_limit_;
  }
  [[nodiscard]] const BigNat& completed_expansions() const noexcept {
    return completed_expansions_;
  }
  [[nodiscard]] OptimizerQueryKind query_kind() const noexcept {
    return query_kind_;
  }
  [[nodiscard]] const std::optional<ServiceFamily>& family() const noexcept {
    return family_;
  }
  [[nodiscard]] const std::optional<TargetIndex>& target() const noexcept {
    return target_;
  }
  [[nodiscard]] bool exhausted() const noexcept { return exhausted_; }

  friend bool operator==(const SearchAccounting&,
                         const SearchAccounting&) = default;

#if defined(MWPERF_C05_TEST_SEAMS)
  [[nodiscard]] static SearchAccounting for_fixture(
      BigNat call_ordinal, std::optional<BigNat> effective_per_call_limit,
      BigNat completed_expansions, OptimizerQueryKind query_kind,
      std::optional<ServiceFamily> family, bool exhausted,
      std::optional<TargetIndex> target = std::nullopt);
#endif

 private:
  SearchAccounting(BigNat call_ordinal,
                   std::optional<BigNat> effective_per_call_limit,
                   BigNat completed_expansions,
                   OptimizerQueryKind query_kind,
                   std::optional<ServiceFamily> family, bool exhausted,
                   std::optional<TargetIndex> target = std::nullopt)
      : call_ordinal_(std::move(call_ordinal)),
        effective_per_call_limit_(std::move(effective_per_call_limit)),
        completed_expansions_(std::move(completed_expansions)),
        query_kind_(query_kind),
        family_(family),
        target_(target),
        exhausted_(exhausted) {}

  BigNat call_ordinal_;
  std::optional<BigNat> effective_per_call_limit_;
  BigNat completed_expansions_;
  OptimizerQueryKind query_kind_;
  std::optional<ServiceFamily> family_;
  std::optional<TargetIndex> target_;
  bool exhausted_;

  friend class SearchBudget;
};

// This witness has no public constructor. Only the exact backend factory can
// place it inside an OptimizerSolution; a partial/incumbent type has no
// conversion path to this tag or to OptimizerSolution.
class ProvenOptimal final {
 public:
  ProvenOptimal(const ProvenOptimal&) = default;
  ProvenOptimal(ProvenOptimal&&) noexcept = default;
  ProvenOptimal& operator=(const ProvenOptimal&) = default;
  ProvenOptimal& operator=(ProvenOptimal&&) noexcept = default;

  friend bool operator==(const ProvenOptimal&, const ProvenOptimal&) = default;

 private:
  struct ExactBackendTag final {};
  explicit ProvenOptimal(ExactBackendTag) noexcept {}

  friend class detail::ExactDispatchAccess;
};

class OptimizerSolution final {
 public:
  OptimizerSolution() = delete;
  OptimizerSolution(const OptimizerSolution&) = default;
  OptimizerSolution(OptimizerSolution&&) noexcept = default;
  OptimizerSolution& operator=(const OptimizerSolution&) = default;
  OptimizerSolution& operator=(OptimizerSolution&&) noexcept = default;

  [[nodiscard]] const Schedule& schedule() const noexcept { return schedule_; }
  [[nodiscard]] const BigNat& composite_objective() const noexcept {
    return composite_objective_;
  }
  [[nodiscard]] ServiceFamily family() const noexcept { return family_; }
  [[nodiscard]] OptimizerId backend_id() const noexcept { return backend_id_; }
  [[nodiscard]] const ProvenOptimal& proof() const noexcept { return proof_; }
  [[nodiscard]] const SearchAccounting& accounting() const noexcept {
    return accounting_;
  }
  [[nodiscard]] std::span<const std::string> proof_notes() const noexcept {
    return proof_notes_;
  }

  friend bool operator==(const OptimizerSolution&,
                         const OptimizerSolution&) = default;

 private:
  OptimizerSolution(Schedule schedule, BigNat composite_objective,
                    ServiceFamily family, OptimizerId backend_id,
                    ProvenOptimal proof, SearchAccounting accounting,
                    std::vector<std::string> proof_notes)
      : schedule_(std::move(schedule)),
        composite_objective_(std::move(composite_objective)),
        family_(family),
        backend_id_(backend_id),
        proof_(std::move(proof)),
        accounting_(std::move(accounting)),
        proof_notes_(std::move(proof_notes)) {}

  Schedule schedule_;
  BigNat composite_objective_;
  ServiceFamily family_;
  OptimizerId backend_id_;
  ProvenOptimal proof_;
  SearchAccounting accounting_;
  std::vector<std::string> proof_notes_;

  friend class detail::ExactDispatchAccess;
};

namespace detail {

// This fixed, non-augmentable access class is the only route from an internal
// exact-backend candidate to the public proven-success carrier.  The callable
// operation performs dispatch identity, live-accounting, forced-side, common
// feasibility, and exact-objective validation before promotion.  The raw
// promoter remains private.  Public solve functions are ordinary wrappers and
// receive no friendship.
class ExactDispatchAccess final {
 public:
  ExactDispatchAccess() = delete;

  // Safe production entry: it accepts only a fully bound exact query and
  // dispatches through the closed C05 family table. Candidate ingestion and
  // proof promotion remain private members of this complete, non-augmentable
  // access class.
  [[nodiscard]] static Result<OptimizerSolution> dispatch(
      const ConstraintDescriptor& descriptor,
      const EligibilityMask& eligibility, const LexWeights& weights,
      SearchBudget& budget,
      const ForcedTargetCondition* condition);

#if defined(MWPERF_C05_TEST_SEAMS)
  [[nodiscard]] static Result<OptimizerSolution>
  dispatch_with_backend_services(
      const ConstraintDescriptor& descriptor,
      const EligibilityMask& eligibility, const LexWeights& weights,
      SearchBudget& budget, const ForcedTargetCondition* condition,
      const ExactOptimizerBackendServices& services);
#endif

 private:
  [[nodiscard]] static Result<OptimizerSolution> validate_and_promote(
      ExactBackendCandidate candidate,
      const ConstraintDescriptor& descriptor,
      const EligibilityMask& eligibility, const LexWeights& weights,
      const SearchBudget& budget,
      const ForcedTargetCondition* condition);

  [[nodiscard]] static OptimizerSolution promote(
      ExactBackendCandidate candidate);
};

}  // namespace detail

enum class ForcedTargetBit : std::uint8_t {
  zero = 0U,
  one = 1U,
};

[[nodiscard]] constexpr std::string_view to_string(
    const ForcedTargetBit bit) noexcept {
  switch (bit) {
    case ForcedTargetBit::zero:
      return "zero";
    case ForcedTargetBit::one:
      return "one";
  }
  return "unknown";
}

struct PrimaryOptimum final {
  BigNat value;
  Schedule witness;
  BigNat secondary_code;
  TargetIndex target;
  ForcedTargetBit side;
  ServiceFamily family;
  OptimizerId backend_id;
  SearchAccounting accounting;

  friend bool operator==(const PrimaryOptimum&, const PrimaryOptimum&) =
      default;
};

enum class TiePolicy : std::uint8_t {
  configured_priority,
  random,
  sticky,
  round_robin,
  arrival_observing,
};

// Unsupported alternatives carry no state and exist only so callers receive a
// typed rejection instead of a stringly or stochastic fallback.
class TieContext final {
 public:
  TieContext() = delete;
  explicit TieContext(TiePolicy policy) noexcept : policy_(policy) {}

  [[nodiscard]] static TieContext configured_priority() noexcept {
    return TieContext(TiePolicy::configured_priority);
  }
  [[nodiscard]] TiePolicy policy() const noexcept { return policy_; }

  friend bool operator==(const TieContext&, const TieContext&) = default;

 private:
  TiePolicy policy_;
};

struct ScheduleDecision final {
  Schedule schedule;
  BigNat primary_objective;
  BigNat composite_objective;
  BigNat priority_code;
  EligibilityMask eligibility;
  ServiceFamily family;
  OptimizerId backend_id;
  SearchAccounting accounting;

  friend bool operator==(const ScheduleDecision&, const ScheduleDecision&) =
      default;
};

}  // namespace mwperf
