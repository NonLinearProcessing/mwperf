#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <new>
#include <optional>
#include <set>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {

// A process-local type discriminator for the otherwise opaque C04 compiled
// product. It grants no construction or recovery authority to callers.
inline constexpr std::uint8_t crossbar_problem_type_tag = 0U;

}  // namespace detail

struct CrossbarQueueEdge final {
  DenseQueueIndex queue;
  std::size_t input;
  std::size_t output;

  friend bool operator==(const CrossbarQueueEdge&,
                         const CrossbarQueueEdge&) = default;
};

// Immutable, backlog-independent geometry for F-C06-01. The sparse row
// adjacency retains structural absence explicitly; padding indices are
// derived from the declared real-port counts and never stored as weighted
// real arcs.
class CrossbarProblem final {
 public:
  CrossbarProblem() = delete;
  CrossbarProblem(const CrossbarProblem&) = default;
  CrossbarProblem(CrossbarProblem&&) noexcept = default;
  CrossbarProblem& operator=(const CrossbarProblem&) = default;
  CrossbarProblem& operator=(CrossbarProblem&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_edges_.size();
  }
  [[nodiscard]] std::size_t input_count() const noexcept {
    return input_count_;
  }
  [[nodiscard]] std::size_t output_count() const noexcept {
    return output_count_;
  }
  [[nodiscard]] std::size_t padded_dimension() const noexcept {
    return input_count_ + output_count_;
  }
  [[nodiscard]] std::size_t own_dummy_column(
      const std::size_t input) const noexcept {
    return output_count_ + input;
  }
  [[nodiscard]] std::size_t own_dummy_row(
      const std::size_t output) const noexcept {
    return input_count_ + output;
  }
  [[nodiscard]] std::span<const CrossbarQueueEdge> queue_edges() const
      noexcept {
    return queue_edges_;
  }
  [[nodiscard]] const std::vector<std::vector<std::size_t>>& row_edge_queues()
      const noexcept {
    return row_edge_queues_;
  }
  [[nodiscard]] static const void* compiled_type_tag() noexcept {
    return &detail::crossbar_problem_type_tag;
  }

#if defined(MWPERF_C06_TEST_SEAMS)
  [[nodiscard]] static CrossbarProblem for_test(
      std::size_t input_count, std::size_t output_count,
      std::vector<CrossbarQueueEdge> queue_edges,
      std::vector<std::vector<std::size_t>> row_edge_queues) {
    return CrossbarProblem(input_count, output_count,
                           std::move(queue_edges),
                           std::move(row_edge_queues));
  }
#endif

 private:
  CrossbarProblem(std::size_t input_count, std::size_t output_count,
                  std::vector<CrossbarQueueEdge> queue_edges,
                  std::vector<std::vector<std::size_t>> row_edge_queues)
      : input_count_(input_count),
        output_count_(output_count),
        queue_edges_(std::move(queue_edges)),
        row_edge_queues_(std::move(row_edge_queues)) {}

  std::size_t input_count_;
  std::size_t output_count_;
  // Dense by queue ordinal so reconstruction never depends on authored order.
  std::vector<CrossbarQueueEdge> queue_edges_;
  // Sparse structural adjacency: queue ordinals, grouped by real input.
  std::vector<std::vector<std::size_t>> row_edge_queues_;

  friend Result<CrossbarProblem> compile_crossbar_problem(
      const ResolvedCrossbarConstraint&);
};

// F-C06-01. C04 has already resolved labels; this child defensively rechecks
// dense coverage, port ranges, and endpoint uniqueness before publishing the
// immutable sparse reconstruction maps.
[[nodiscard]] inline Result<CrossbarProblem> compile_crossbar_problem(
    const ResolvedCrossbarConstraint& constraint) {
  const auto failure = [](std::string code, std::string message,
                          std::vector<std::string> notes = {}) {
    return Result<CrossbarProblem>::failure(Diagnostic{
        .category = DiagnosticCategory::internal,
        .code = std::move(code),
        .message = std::move(message),
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = std::move(notes),
    });
  };

  try {
    const std::size_t input_count = constraint.inputs.size();
    const std::size_t output_count = constraint.outputs.size();
    const std::size_t queue_count = constraint.edges.size();
    if (input_count == 0U || output_count == 0U || queue_count == 0U) {
      return failure("crossbar_compiled_geometry_empty",
                     "a compiled crossbar requires nonempty input, output, "
                     "and queue sets");
    }
    if (input_count >
            std::numeric_limits<std::size_t>::max() - output_count ||
        input_count + output_count ==
            std::numeric_limits<std::size_t>::max()) {
      return failure("crossbar_compiled_padded_dimension_overflow",
                     "the padded crossbar dimension exceeds the host index "
                     "range");
    }

    std::vector<std::uint8_t> seen_inputs(input_count, 0U);
    for (const ResolvedInputPort& input : constraint.inputs) {
      const std::size_t ordinal = input.index.ordinal();
      if (ordinal >= input_count || seen_inputs[ordinal] != 0U) {
        return failure("crossbar_compiled_input_index_invalid",
                       "the bound crossbar input indices are not a dense "
                       "permutation");
      }
      seen_inputs[ordinal] = 1U;
    }
    std::vector<std::uint8_t> seen_outputs(output_count, 0U);
    for (const ResolvedOutputPort& output : constraint.outputs) {
      const std::size_t ordinal = output.index.ordinal();
      if (ordinal >= output_count || seen_outputs[ordinal] != 0U) {
        return failure("crossbar_compiled_output_index_invalid",
                       "the bound crossbar output indices are not a dense "
                       "permutation");
      }
      seen_outputs[ordinal] = 1U;
    }

    std::vector<std::optional<CrossbarQueueEdge>> by_queue(queue_count);
    std::vector<std::vector<std::size_t>> row_edges(input_count);
    std::set<std::pair<std::size_t, std::size_t>> endpoint_pairs;
    for (const ResolvedCrossbarEdge& edge : constraint.edges) {
      const std::size_t queue = edge.queue.ordinal();
      const std::size_t input = edge.input.ordinal();
      const std::size_t output = edge.output.ordinal();
      if (queue >= queue_count || by_queue[queue].has_value()) {
        return failure("crossbar_compiled_queue_coverage_invalid",
                       "the bound crossbar edges do not cover each dense "
                       "queue exactly once");
      }
      if (input >= input_count || output >= output_count) {
        return failure("crossbar_compiled_endpoint_out_of_range",
                       "a bound crossbar edge has an out-of-range port "
                       "index");
      }
      if (!endpoint_pairs.emplace(input, output).second) {
        return failure("crossbar_compiled_endpoint_duplicate",
                       "two bound queues occupy the same crossbar endpoint "
                       "pair");
      }
      by_queue[queue] = CrossbarQueueEdge{edge.queue, input, output};
      row_edges[input].push_back(queue);
    }

    std::vector<CrossbarQueueEdge> queue_edges;
    queue_edges.reserve(queue_count);
    for (std::size_t queue = 0U; queue < queue_count; ++queue) {
      if (!by_queue[queue].has_value()) {
        return failure("crossbar_compiled_queue_coverage_invalid",
                       "the bound crossbar edges omit a dense queue",
                       {"missing dense queue index: " +
                        std::to_string(queue)});
      }
      queue_edges.push_back(std::move(*by_queue[queue]));
    }
    for (std::vector<std::size_t>& row : row_edges) {
      std::ranges::sort(row, [&queue_edges](const std::size_t lhs,
                                           const std::size_t rhs) {
        const CrossbarQueueEdge& left = queue_edges[lhs];
        const CrossbarQueueEdge& right = queue_edges[rhs];
        if (left.output != right.output) {
          return left.output < right.output;
        }
        return lhs < rhs;
      });
    }

    return Result<CrossbarProblem>::success(CrossbarProblem(
        input_count, output_count, std::move(queue_edges),
        std::move(row_edges)));
  } catch (const std::bad_alloc&) {
    return Result<CrossbarProblem>::failure(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "crossbar_compile_allocation_failure",
        .message = "allocation failed while compiling immutable crossbar "
                   "geometry",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  } catch (const std::length_error&) {
    return Result<CrossbarProblem>::failure(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "crossbar_compile_representation_failure",
        .message = "immutable crossbar geometry exceeds a host container "
                   "limit",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  }
}

namespace detail {

// F-C06-02 produces this unpromoted exact witness. The closed C05 dispatcher
// alone can attach its live accounting and ProvenOptimal capability.
struct CrossbarExactWitness final {
  Schedule schedule;
  BigNat composite_objective;
  std::vector<std::string> proof_notes;
};

enum class CrossbarTestFault : std::uint8_t {
  none,
  force_forbidden_assignment,
};

[[nodiscard]] Result<CrossbarExactWitness> solve_crossbar_exact(
    const CrossbarProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition);

#if defined(MWPERF_C06_TEST_SEAMS)
[[nodiscard]] Result<CrossbarExactWitness> solve_crossbar_exact_with_fault(
    const CrossbarProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition,
    CrossbarTestFault fault);
#endif

}  // namespace detail
}  // namespace mwperf
