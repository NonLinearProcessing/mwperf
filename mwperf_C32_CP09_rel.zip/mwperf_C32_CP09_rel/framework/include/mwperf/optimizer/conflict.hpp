#pragma once

#include <compare>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class ConflictProblem;

namespace detail {

// Process-local discriminator for C04's opaque compiled-product owner. It
// conveys neither construction nor recovery authority.
inline constexpr std::uint8_t conflict_problem_type_tag = 0U;

struct ConflictExactWitness;

[[nodiscard]] Result<void> validate_conflict_problem(
    const ConflictProblem& problem);

}  // namespace detail

// Canonical dynamic bitset shared by the two C08 recursive families. The
// logical length participates in equality and ordering, and unused high bits
// in the final word are always zero. Consequently two catalogs with equal
// stored words but different cardinalities cannot alias as memo keys.
class QueueSubset final {
 public:
  QueueSubset() = delete;
  QueueSubset(const QueueSubset&) = default;
  QueueSubset(QueueSubset&&) noexcept = default;
  QueueSubset& operator=(const QueueSubset&) = default;
  QueueSubset& operator=(QueueSubset&&) noexcept = default;

  [[nodiscard]] static QueueSubset none(std::size_t logical_size);
  [[nodiscard]] static Result<QueueSubset> from_bytes(
      std::span<const std::uint8_t> bytes);

  [[nodiscard]] std::size_t size() const noexcept { return logical_size_; }
  [[nodiscard]] bool empty() const noexcept;
  [[nodiscard]] bool test(std::size_t index) const noexcept;
  [[nodiscard]] std::optional<std::size_t> first_set() const noexcept;
  [[nodiscard]] std::span<const std::uint64_t> words() const noexcept {
    return words_;
  }
  [[nodiscard]] bool canonical() const noexcept;

  // Mutations retain canonical form. A false result means that the supplied
  // coordinate or other subset belongs to another logical dimension.
  [[nodiscard]] bool set(std::size_t index) noexcept;
  [[nodiscard]] bool reset(std::size_t index) noexcept;
  [[nodiscard]] bool subtract(const QueueSubset& other) noexcept;
  [[nodiscard]] bool intersect(const QueueSubset& other) noexcept;
  [[nodiscard]] bool unite(const QueueSubset& other) noexcept;

  friend bool operator==(const QueueSubset&, const QueueSubset&) = default;
  friend std::strong_ordering operator<=>(const QueueSubset& lhs,
                                           const QueueSubset& rhs) noexcept;

#if defined(MWPERF_C08_TEST_SEAMS)
  // Allows negative tests to establish that malformed memo/subset carriers
  // are rejected before recursion. Production construction is canonical.
  [[nodiscard]] static QueueSubset for_test_unchecked(
      std::size_t logical_size, std::vector<std::uint64_t> words) {
    return QueueSubset(logical_size, std::move(words));
  }
#endif

 private:
  QueueSubset(std::size_t logical_size, std::vector<std::uint64_t> words)
      : logical_size_(logical_size), words_(std::move(words)) {}

  std::size_t logical_size_;
  std::vector<std::uint64_t> words_;
};

struct ConflictEdge final {
  DenseQueueIndex first;
  DenseQueueIndex second;

  friend bool operator==(const ConflictEdge&, const ConflictEdge&) = default;
};

// Immutable, backlog-independent F-C08-01 result. Every adjacency and closed
// neighborhood is indexed by the dense queue catalog, including isolates.
// Eligibility, weights, memo state, and the search counter remain solve-local.
class ConflictProblem final {
 public:
  ConflictProblem() = delete;
  ConflictProblem(const ConflictProblem&) = default;
  ConflictProblem(ConflictProblem&&) noexcept = default;
  ConflictProblem& operator=(const ConflictProblem&) = default;
  ConflictProblem& operator=(ConflictProblem&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return adjacency_.size();
  }
  [[nodiscard]] std::span<const QueueSubset> adjacency() const noexcept {
    return adjacency_;
  }
  [[nodiscard]] std::span<const QueueSubset> closed_neighborhoods()
      const noexcept {
    return closed_neighborhoods_;
  }
  [[nodiscard]] std::span<const ConflictEdge> edges() const noexcept {
    return edges_;
  }
  [[nodiscard]] std::span<const std::size_t> isolated_queues() const
      noexcept {
    return isolated_queues_;
  }
  [[nodiscard]] static const void* compiled_type_tag() noexcept {
    return &detail::conflict_problem_type_tag;
  }

#if defined(MWPERF_C08_TEST_SEAMS)
  [[nodiscard]] static ConflictProblem for_test(
      std::vector<QueueSubset> adjacency,
      std::vector<QueueSubset> closed_neighborhoods,
      std::vector<ConflictEdge> edges,
      std::vector<std::size_t> isolated_queues) {
    return ConflictProblem(std::move(adjacency),
                           std::move(closed_neighborhoods),
                           std::move(edges), std::move(isolated_queues));
  }
#endif

 private:
  ConflictProblem(std::vector<QueueSubset> adjacency,
                  std::vector<QueueSubset> closed_neighborhoods,
                  std::vector<ConflictEdge> edges,
                  std::vector<std::size_t> isolated_queues)
      : adjacency_(std::move(adjacency)),
        closed_neighborhoods_(std::move(closed_neighborhoods)),
        edges_(std::move(edges)),
        isolated_queues_(std::move(isolated_queues)) {}

  std::vector<QueueSubset> adjacency_;
  std::vector<QueueSubset> closed_neighborhoods_;
  // Strict canonical (first, second) order with first < second.
  std::vector<ConflictEdge> edges_;
  std::vector<std::size_t> isolated_queues_;

  friend Result<ConflictProblem> compile_conflict_problem(
      const ResolvedConflictConstraint&);
};

// F-C08-01. C04 has already bound typed queue labels. C08 nevertheless
// rechecks dense ranges, self/duplicate pairs, and the complete symmetric
// adjacency before publishing reusable immutable geometry.
[[nodiscard]] Result<ConflictProblem> compile_conflict_problem(
    const ResolvedConflictConstraint& constraint);

namespace detail {

// Internal exact-success carrier. Only the C05 dispatch authority may promote
// it into the public OptimizerSolution type after common validation.
struct ConflictExactWitness final {
  Schedule schedule;
  BigNat composite_objective;
  std::vector<std::string> proof_notes;
};

// F-C08-02 implementation and private forced-target adapter. The memo and all
// component/branch work records are created inside this call and destroyed on
// either success or failure. SearchBudget is charged only for a new, nonbase
// canonical subset key.
[[nodiscard]] Result<ConflictExactWitness> solve_mwis_exact(
    const ConflictProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition = nullptr);

#if defined(MWPERF_C08_TEST_SEAMS)
enum class MwisTestFault : std::uint8_t {
  none,
  force_distinct_branch_equality,
};

struct MwisTestTrace final {
  std::vector<QueueSubset> expanded_keys;
  std::size_t base_calls = 0U;
  std::size_t memo_hits = 0U;
  // One entry per expanded state, listing induced-component minima in the
  // exact order in which those components were considered.
  std::vector<std::vector<std::size_t>> component_minima;
};

[[nodiscard]] Result<ConflictExactWitness> solve_mwis_exact_with_test_control(
    const ConflictProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition, MwisTestFault fault,
    MwisTestTrace& trace);
#endif

}  // namespace detail
}  // namespace mwperf
