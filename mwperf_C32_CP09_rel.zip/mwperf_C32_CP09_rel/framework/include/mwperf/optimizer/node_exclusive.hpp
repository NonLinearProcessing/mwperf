#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class NodeExclusiveProblem;
class RepresentativeGraph;
class RepresentativeMatching;

namespace detail {

// A process-local discriminator for the otherwise opaque C04 compiled
// product. It conveys no construction or recovery authority.
inline constexpr std::uint8_t node_exclusive_problem_type_tag = 0U;

struct NodeExclusiveExactWitness;

[[nodiscard]] Result<RepresentativeGraph>
select_parallel_link_representatives_active(
    const NodeExclusiveProblem& problem,
    std::span<const std::uint8_t> active,
    const LexWeights& weights);

[[nodiscard]] Result<RepresentativeMatching> solve_blossom_exact(
    const RepresentativeGraph& graph);

#if defined(MWPERF_C07_TEST_SEAMS)
enum class BlossomTestFault : std::uint8_t;
[[nodiscard]] Result<RepresentativeMatching> solve_blossom_exact_with_fault(
    const RepresentativeGraph& graph, BlossomTestFault fault);
#endif

}  // namespace detail

// One immutable vertex record. The C04 dense index is retained even for an
// isolated vertex; incidence is held separately in CSR form.
struct NodeExclusiveVertex final {
  DenseVertexIndex index;
  bool isolated;

  friend bool operator==(const NodeExclusiveVertex&,
                         const NodeExclusiveVertex&) = default;
};

// Every queue-labelled link is retained. first/second are the canonical
// unordered endpoint ordinals, with first < second. `queue` remains the
// original dense queue identity used for reconstruction.
struct NodeExclusiveLabelledLink final {
  DenseQueueIndex queue;
  std::size_t first;
  std::size_t second;

  friend bool operator==(const NodeExclusiveLabelledLink&,
                         const NodeExclusiveLabelledLink&) = default;
};

// An incidence record points to a position in NodeExclusiveProblem::links().
// `opposite` permits deterministic validation and endpoint-neighborhood scans
// without consulting authored labels.
struct NodeExclusiveIncidence final {
  std::size_t link;
  std::size_t opposite;

  friend bool operator==(const NodeExclusiveIncidence&,
                         const NodeExclusiveIncidence&) = default;
};

// Half-open range into links(). Groups are ordered by (first, second), are
// nonempty, and partition the complete labelled-link array.
struct NodeExclusiveParallelGroup final {
  std::size_t first;
  std::size_t second;
  std::size_t begin;
  std::size_t end;

  friend bool operator==(const NodeExclusiveParallelGroup&,
                         const NodeExclusiveParallelGroup&) = default;
};

// Immutable, backlog-independent F-C07-01 product. Query eligibility,
// representative choices, Blossom workspaces, duals, and matchings never
// enter this object.
class NodeExclusiveProblem final {
 public:
  NodeExclusiveProblem() = delete;
  NodeExclusiveProblem(const NodeExclusiveProblem&) = default;
  NodeExclusiveProblem(NodeExclusiveProblem&&) noexcept = default;
  NodeExclusiveProblem& operator=(const NodeExclusiveProblem&) = default;
  NodeExclusiveProblem& operator=(NodeExclusiveProblem&&) noexcept = default;

  [[nodiscard]] std::size_t vertex_count() const noexcept {
    return vertices_.size();
  }
  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_to_link_.size();
  }
  [[nodiscard]] std::span<const NodeExclusiveVertex> vertices() const
      noexcept {
    return vertices_;
  }
  [[nodiscard]] std::span<const NodeExclusiveLabelledLink> links() const
      noexcept {
    return links_;
  }
  [[nodiscard]] std::span<const std::size_t> incidence_offsets() const
      noexcept {
    return incidence_offsets_;
  }
  [[nodiscard]] std::span<const NodeExclusiveIncidence> incidence() const
      noexcept {
    return incidence_;
  }
  [[nodiscard]] std::span<const NodeExclusiveParallelGroup> parallel_groups()
      const noexcept {
    return parallel_groups_;
  }
  [[nodiscard]] std::span<const std::size_t> queue_to_link() const noexcept {
    return queue_to_link_;
  }
  [[nodiscard]] std::span<const std::size_t> isolated_vertices() const
      noexcept {
    return isolated_vertices_;
  }
  [[nodiscard]] static const void* compiled_type_tag() noexcept {
    return &detail::node_exclusive_problem_type_tag;
  }

#if defined(MWPERF_C07_TEST_SEAMS)
  [[nodiscard]] static NodeExclusiveProblem for_test(
      std::vector<NodeExclusiveVertex> vertices,
      std::vector<NodeExclusiveLabelledLink> links,
      std::vector<std::size_t> incidence_offsets,
      std::vector<NodeExclusiveIncidence> incidence,
      std::vector<NodeExclusiveParallelGroup> parallel_groups,
      std::vector<std::size_t> queue_to_link,
      std::vector<std::size_t> isolated_vertices) {
    return NodeExclusiveProblem(
        std::move(vertices), std::move(links),
        std::move(incidence_offsets), std::move(incidence),
        std::move(parallel_groups), std::move(queue_to_link),
        std::move(isolated_vertices));
  }
#endif

 private:
  NodeExclusiveProblem(
      std::vector<NodeExclusiveVertex> vertices,
      std::vector<NodeExclusiveLabelledLink> links,
      std::vector<std::size_t> incidence_offsets,
      std::vector<NodeExclusiveIncidence> incidence,
      std::vector<NodeExclusiveParallelGroup> parallel_groups,
      std::vector<std::size_t> queue_to_link,
      std::vector<std::size_t> isolated_vertices)
      : vertices_(std::move(vertices)),
        links_(std::move(links)),
        incidence_offsets_(std::move(incidence_offsets)),
        incidence_(std::move(incidence)),
        parallel_groups_(std::move(parallel_groups)),
        queue_to_link_(std::move(queue_to_link)),
        isolated_vertices_(std::move(isolated_vertices)) {}

  std::vector<NodeExclusiveVertex> vertices_;
  // Canonical (first, second, queue) order. Parallel groups are contiguous.
  std::vector<NodeExclusiveLabelledLink> links_;
  // Vertex v owns incidence_[offsets_[v]..offsets_[v+1]).
  std::vector<std::size_t> incidence_offsets_;
  std::vector<NodeExclusiveIncidence> incidence_;
  std::vector<NodeExclusiveParallelGroup> parallel_groups_;
  // Dense queue ordinal -> canonical position in links_.
  std::vector<std::size_t> queue_to_link_;
  std::vector<std::size_t> isolated_vertices_;

  friend Result<NodeExclusiveProblem> compile_node_exclusive_problem(
      const ResolvedNodeExclusiveConstraint&);
};

// F-C07-01. C04 has already resolved labels; C07 defensively rechecks dense
// vertex and queue coverage, distinct/range-checked endpoints, and every
// reconstruction invariant before publishing immutable geometry.
[[nodiscard]] Result<NodeExclusiveProblem> compile_node_exclusive_problem(
    const ResolvedNodeExclusiveConstraint& constraint);

// A solve-local simple edge produced only after eligibility-first parallel
// reduction. `weight` is the supplied complete exact composite weight.
struct RepresentativeEdge final {
  std::size_t first;
  std::size_t second;
  DenseQueueIndex queue;
  BigNat weight;

  friend bool operator==(const RepresentativeEdge&,
                         const RepresentativeEdge&) = default;
};

class RepresentativeGraph final {
 public:
  RepresentativeGraph() = delete;
  RepresentativeGraph(const RepresentativeGraph&) = default;
  RepresentativeGraph(RepresentativeGraph&&) noexcept = default;
  RepresentativeGraph& operator=(const RepresentativeGraph&) = default;
  RepresentativeGraph& operator=(RepresentativeGraph&&) noexcept = default;

  [[nodiscard]] std::size_t vertex_count() const noexcept {
    return vertex_count_;
  }
  [[nodiscard]] std::size_t queue_count() const noexcept {
    return dimension_.cardinality();
  }
  [[nodiscard]] const QueueDimensionToken& dimension() const noexcept {
    return dimension_;
  }
  [[nodiscard]] std::span<const RepresentativeEdge> edges() const noexcept {
    return edges_;
  }

#if defined(MWPERF_C07_TEST_SEAMS)
  [[nodiscard]] static RepresentativeGraph for_test(
      std::size_t vertex_count, QueueDimensionToken dimension,
      std::vector<RepresentativeEdge> edges) {
    return RepresentativeGraph(vertex_count, std::move(dimension),
                               std::move(edges));
  }
#endif

 private:
  RepresentativeGraph(std::size_t vertex_count,
                      QueueDimensionToken dimension,
                      std::vector<RepresentativeEdge> edges)
      : vertex_count_(vertex_count),
        dimension_(std::move(dimension)),
        edges_(std::move(edges)) {}

  std::size_t vertex_count_;
  QueueDimensionToken dimension_;
  // Strict canonical endpoint-pair order; at most one edge per pair.
  std::vector<RepresentativeEdge> edges_;

  friend Result<RepresentativeGraph> select_parallel_link_representatives(
      const NodeExclusiveProblem&, const EligibilityMask&,
      const LexWeights&);
  friend Result<RepresentativeGraph>
  detail::select_parallel_link_representatives_active(
      const NodeExclusiveProblem&, std::span<const std::uint8_t>,
      const LexWeights&);
};

// F-C07-02. The checked Result spelling refines the catalog's conceptual
// value return so malformed dimensions/compiled data and allocation failure
// remain transactional diagnostics.
[[nodiscard]] Result<RepresentativeGraph>
select_parallel_link_representatives(
    const NodeExclusiveProblem& problem,
    const EligibilityMask& eligibility, const LexWeights& weights);

// Exact F-C07-03 primal result. Selected values are representative-edge
// indices, not endpoint pairs, so F-C07-04 can map losslessly to queue labels.
class RepresentativeMatching final {
 public:
  RepresentativeMatching() = delete;
  RepresentativeMatching(const RepresentativeMatching&) = default;
  RepresentativeMatching(RepresentativeMatching&&) noexcept = default;
  RepresentativeMatching& operator=(const RepresentativeMatching&) = default;
  RepresentativeMatching& operator=(RepresentativeMatching&&) noexcept =
      default;

  [[nodiscard]] std::span<const std::size_t> selected_edges() const noexcept {
    return selected_edges_;
  }
  [[nodiscard]] std::span<const std::optional<std::size_t>> vertex_mates()
      const noexcept {
    return vertex_mates_;
  }
  [[nodiscard]] const BigNat& objective() const noexcept { return objective_; }

#if defined(MWPERF_C07_TEST_SEAMS)
  [[nodiscard]] static RepresentativeMatching for_test(
      std::vector<std::size_t> selected_edges,
      std::vector<std::optional<std::size_t>> vertex_mates,
      BigNat objective) {
    return RepresentativeMatching(
        std::move(selected_edges), std::move(vertex_mates),
        std::move(objective));
  }
#endif

 private:
  RepresentativeMatching(
      std::vector<std::size_t> selected_edges,
      std::vector<std::optional<std::size_t>> vertex_mates,
      BigNat objective)
      : selected_edges_(std::move(selected_edges)),
        vertex_mates_(std::move(vertex_mates)),
        objective_(std::move(objective)) {}

  std::vector<std::size_t> selected_edges_;
  std::vector<std::optional<std::size_t>> vertex_mates_;
  BigNat objective_;

  friend Result<RepresentativeMatching> detail::solve_blossom_exact(
      const RepresentativeGraph&);
#if defined(MWPERF_C07_TEST_SEAMS)
  friend Result<RepresentativeMatching>
  detail::solve_blossom_exact_with_fault(
      const RepresentativeGraph&, detail::BlossomTestFault);
#endif
};

namespace detail {

// F-C07-02's private subset form is used only after a forced-one target has
// been committed and its endpoint neighborhoods removed. `active` must be a
// subset of the eligibility carried by `weights`.
[[nodiscard]] Result<RepresentativeGraph>
select_parallel_link_representatives_active(
    const NodeExclusiveProblem& problem,
    std::span<const std::uint8_t> active,
    const LexWeights& weights);

enum class BlossomTestFault : std::uint8_t {
  none,
  force_certificate_mismatch,
};

// F-C07-03. Its cold arena and exact certificate remain implementation-only.
[[nodiscard]] Result<RepresentativeMatching> solve_blossom_exact(
    const RepresentativeGraph& graph);

#if defined(MWPERF_C07_TEST_SEAMS)
[[nodiscard]] Result<RepresentativeMatching> solve_blossom_exact_with_fault(
    const RepresentativeGraph& graph, BlossomTestFault fault);
[[nodiscard]] Result<bool>
blossom_observed_negative_internal_raw_slack_for_test(
    const RepresentativeGraph& graph);
#endif

// Unpromoted F-C07-04 value. The C05 dispatch-created authority is still the
// only operation that may package and promote it as an OptimizerSolution.
struct NodeExclusiveExactWitness final {
  Schedule schedule;
  BigNat composite_objective;
  std::vector<std::string> proof_notes;
};

[[nodiscard]] Result<NodeExclusiveExactWitness>
expand_representative_matching(
    const RepresentativeMatching& matching,
    const RepresentativeGraph& graph);

// Private C05 conditioning adapter. It calls F-C07-02 -> F-C07-03 ->
// F-C07-04, committing a forced-one target outside the residual graph exactly
// as the C06 family adapters do.
[[nodiscard]] Result<NodeExclusiveExactWitness> solve_node_exclusive_exact(
    const NodeExclusiveProblem& problem,
    const EligibilityMask& eligibility, const LexWeights& weights,
    const ForcedTargetCondition* condition);

}  // namespace detail
}  // namespace mwperf
