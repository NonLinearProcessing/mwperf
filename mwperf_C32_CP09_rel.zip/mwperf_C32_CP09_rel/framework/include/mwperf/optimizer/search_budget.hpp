#pragma once

#include <memory>
#include <optional>
#include <utility>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class SearchBudget;

namespace detail {
class C17CoreAccess;
class OptimizerCallLedgerState;
class OptimizerCallLedgerTransaction;
class SearchBudgetAccess;
}

class OptimizerCallLedgerObserver;

// An accessor-only copy of the process-local call ledger.  It can be retained
// for provenance/reconciliation, but there is deliberately no operation that
// imports it into a context, merges it with another ledger, or resets a live
// context from it.
class OptimizerCallLedgerSnapshot final {
 public:
  OptimizerCallLedgerSnapshot() = delete;
  OptimizerCallLedgerSnapshot(const OptimizerCallLedgerSnapshot&) = default;
  OptimizerCallLedgerSnapshot(OptimizerCallLedgerSnapshot&&) noexcept =
      default;
  OptimizerCallLedgerSnapshot& operator=(
      const OptimizerCallLedgerSnapshot&) = delete;
  OptimizerCallLedgerSnapshot& operator=(
      OptimizerCallLedgerSnapshot&&) = delete;
  ~OptimizerCallLedgerSnapshot() = default;

  [[nodiscard]] const std::optional<BigNat>& assigned_max_calls()
      const noexcept {
    return assigned_max_calls_;
  }
  [[nodiscard]] const BigNat& calls_reserved() const noexcept {
    return calls_reserved_;
  }
  [[nodiscard]] const std::optional<BigNat>& assigned_max_search_states()
      const noexcept {
    return assigned_max_search_states_;
  }
  [[nodiscard]] const BigNat& search_states_expanded() const noexcept {
    return search_states_expanded_;
  }
  [[nodiscard]] bool context_active() const noexcept {
    return context_active_;
  }
  [[nodiscard]] bool has_remaining_capacity() const noexcept;

  friend bool operator==(const OptimizerCallLedgerSnapshot&,
                         const OptimizerCallLedgerSnapshot&) = default;

 private:
  OptimizerCallLedgerSnapshot(std::optional<BigNat> assigned_max_calls,
                              BigNat calls_reserved,
                              std::optional<BigNat> assigned_max_search_states,
                              BigNat search_states_expanded,
                              bool context_active)
      : assigned_max_calls_(std::move(assigned_max_calls)),
        calls_reserved_(std::move(calls_reserved)),
        assigned_max_search_states_(
            std::move(assigned_max_search_states)),
        search_states_expanded_(std::move(search_states_expanded)),
        context_active_(context_active) {}

  std::optional<BigNat> assigned_max_calls_;
  BigNat calls_reserved_;
  std::optional<BigNat> assigned_max_search_states_;
  BigNat search_states_expanded_;
  bool context_active_;

  friend class OptimizerExecutionContext;
  friend class OptimizerCallLedgerObserver;
};

// Read-only lifetime extension for one execution-local optimizer ledger.
// The observer follows the same private backing state across context moves and
// remains readable after the sole mutable context is destroyed.  It exposes
// only detached snapshots: it cannot reserve, reset, import, merge, or mint a
// new execution context.
class OptimizerCallLedgerObserver final {
 public:
  OptimizerCallLedgerObserver() = delete;
  OptimizerCallLedgerObserver(const OptimizerCallLedgerObserver&) = default;
  OptimizerCallLedgerObserver(OptimizerCallLedgerObserver&&) noexcept =
      default;
  OptimizerCallLedgerObserver& operator=(
      const OptimizerCallLedgerObserver&) = default;
  OptimizerCallLedgerObserver& operator=(
      OptimizerCallLedgerObserver&&) noexcept = default;
  ~OptimizerCallLedgerObserver() = default;

  [[nodiscard]] OptimizerCallLedgerSnapshot snapshot() const;

 private:
  explicit OptimizerCallLedgerObserver(
      std::shared_ptr<const detail::OptimizerCallLedgerState> state)
      : state_(std::move(state)) {}

  std::shared_ptr<const detail::OptimizerCallLedgerState> state_;

  friend class OptimizerExecutionContext;
};

// One mutable solve-call ledger for one in-process execution portion.  The
// context owns a copy of C04's immutable base policy and a separately resolved
// process-local call subgrant. Production construction requires a resolved
// instance; a context cannot be seeded from a ledger snapshot or provider work
// report. Moving transfers the sole live ledger and leaves the source inert.
class OptimizerExecutionContext final {
 public:
  OptimizerExecutionContext() = delete;
  OptimizerExecutionContext(const OptimizerExecutionContext&) = delete;
  OptimizerExecutionContext(OptimizerExecutionContext&& other) noexcept;
  OptimizerExecutionContext& operator=(const OptimizerExecutionContext&) =
      delete;
  OptimizerExecutionContext& operator=(OptimizerExecutionContext&&) = delete;
  ~OptimizerExecutionContext() noexcept;

  [[nodiscard]] static Result<OptimizerExecutionContext>
  from_resolved_instance(
      const ResolvedInstance& instance,
      std::optional<BigNat> assigned_max_calls = std::nullopt);

#if defined(MWPERF_C05_TEST_SEAMS)
  // Tests may manufacture a base policy without constructing a full C04
  // instance, but it passes the identical minimum/subgrant validation used by
  // production and cannot import prior accounting.
  [[nodiscard]] static Result<OptimizerExecutionContext> for_fixture(
      OptimizerBudgetPolicy base_policy,
      std::optional<BigNat> assigned_max_calls = std::nullopt,
      std::optional<QueueDimensionToken> instance_binding = std::nullopt);
#endif

  [[nodiscard]] const OptimizerBudgetPolicy& base_policy() const noexcept {
    return base_policy_;
  }
  [[nodiscard]] const std::optional<BigNat>& assigned_max_calls()
      const noexcept;
  [[nodiscard]] bool active() const noexcept;
  [[nodiscard]] const std::optional<QueueDimensionToken>& instance_binding()
      const noexcept {
    return instance_binding_;
  }
  [[nodiscard]] bool matches_dimension(
      const QueueDimensionToken& dimension) const noexcept;
  [[nodiscard]] OptimizerCallLedgerSnapshot ledger_snapshot() const;
  [[nodiscard]] OptimizerCallLedgerObserver ledger_observer() const;

 private:
  OptimizerExecutionContext(OptimizerBudgetPolicy base_policy,
                            std::optional<BigNat> assigned_max_calls,
                            std::optional<QueueDimensionToken> instance_binding);

  [[nodiscard]] static Result<OptimizerExecutionContext> from_policy(
      OptimizerBudgetPolicy base_policy,
      std::optional<BigNat> assigned_max_calls,
      std::optional<QueueDimensionToken> instance_binding);

  OptimizerBudgetPolicy base_policy_;
  std::optional<QueueDimensionToken> instance_binding_;
  std::shared_ptr<detail::OptimizerCallLedgerState> ledger_state_;

  friend class detail::OptimizerCallLedgerTransaction;
  friend class detail::SearchBudgetAccess;
};

namespace detail {

// C17's row/slot scope retains attempted exact optimizer calls even when a
// later causal validation fails.  Only C17CoreAccess can open or close this
// scope; the public C05 context accepts neither a ledger snapshot nor a reset
// value.  This preserves truthful C27 terminal accounting.
class OptimizerCallLedgerTransaction final {
 public:
  OptimizerCallLedgerTransaction(const OptimizerCallLedgerTransaction&) =
      delete;
  OptimizerCallLedgerTransaction& operator=(
      const OptimizerCallLedgerTransaction&) = delete;
  OptimizerCallLedgerTransaction(OptimizerCallLedgerTransaction&&) = delete;
  OptimizerCallLedgerTransaction& operator=(
      OptimizerCallLedgerTransaction&&) = delete;
  ~OptimizerCallLedgerTransaction() noexcept;

 private:
  explicit OptimizerCallLedgerTransaction(
      OptimizerExecutionContext& context);
  void commit() noexcept {}

  friend class C17CoreAccess;
};

}  // namespace detail

// A single cold solve's recursive-state counter.  Moving transfers the sole
// authorization; the moved-from object becomes inert.  C08 calls
// charge_expansion exactly after it has ruled out a base case and a memo hit.
// This keeps those two cases at zero without giving them a second accounting
// path.
class SearchBudget final {
 public:
  SearchBudget() = delete;
  SearchBudget(const SearchBudget&) = delete;
  SearchBudget(SearchBudget&& other) noexcept;
  SearchBudget& operator=(const SearchBudget&) = delete;
  SearchBudget& operator=(SearchBudget&&) = delete;
  ~SearchBudget() = default;

  [[nodiscard]] const BigNat& call_ordinal() const noexcept {
    return call_ordinal_;
  }
  [[nodiscard]] const std::optional<BigNat>& effective_limit() const noexcept {
    return effective_limit_;
  }
  [[nodiscard]] const BigNat& completed_expansions() const noexcept {
    return completed_expansions_;
  }
  [[nodiscard]] OptimizerQueryKind query_kind() const noexcept {
    return query_kind_;
  }
  [[nodiscard]] const std::optional<TargetIndex>& query_target()
      const noexcept {
    return query_target_;
  }
  [[nodiscard]] const std::optional<ServiceFamily>& claimed_family()
      const noexcept {
    return claimed_family_;
  }
  [[nodiscard]] bool dispatch_claimed() const noexcept {
    return dispatch_claimed_;
  }
  [[nodiscard]] bool exhausted() const noexcept { return exhausted_; }
  [[nodiscard]] const std::optional<QueueDimensionToken>& instance_binding()
      const noexcept {
    return instance_binding_;
  }
  [[nodiscard]] bool matches_dimension(
      const QueueDimensionToken& dimension) const noexcept;

  // A caller may classify its reservation once before solve_exact claims it.
  // Leaving it unset deliberately records generic_exact. Target-conditioned
  // kinds must use set_query_identity so diagnostics cannot lose the target.
  [[nodiscard]] Result<void> set_query_kind(OptimizerQueryKind kind);
  [[nodiscard]] Result<void> set_query_identity(
      OptimizerQueryKind kind, std::optional<TargetIndex> target);

  // The returned value is a detached immutable accounting record; it cannot
  // be turned back into a budget or ledger reservation.
  [[nodiscard]] SearchAccounting accounting() const;

 private:
  SearchBudget(BigNat call_ordinal, std::optional<BigNat> effective_limit,
               std::optional<QueueDimensionToken> instance_binding,
               std::shared_ptr<detail::OptimizerCallLedgerState>
                   ledger_state);
  [[nodiscard]] Result<void> claim_dispatch(ServiceFamily family);
  // C08's only recursive-expansion primitive. A finite limit L permits
  // exactly L successful charges and fails the next one before incrementing.
  [[nodiscard]] Result<void> charge_expansion();
  [[nodiscard]] bool has_live_context() const noexcept;
  [[nodiscard]] Diagnostic inactive_diagnostic() const;

  BigNat call_ordinal_;
  std::optional<BigNat> effective_limit_;
  BigNat completed_expansions_;
  std::optional<QueueDimensionToken> instance_binding_;
  std::shared_ptr<detail::OptimizerCallLedgerState> ledger_state_;
  OptimizerQueryKind query_kind_;
  std::optional<TargetIndex> query_target_;
  std::optional<ServiceFamily> claimed_family_;
  bool query_kind_explicit_;
  bool dispatch_claimed_;
  bool exhausted_;
  bool active_;

  friend class detail::SearchBudgetAccess;
};

namespace detail {

// Complete, non-augmentable bridge for the three safe budget transitions.
// Keeping the type complete in every translation unit prevents a consumer
// from completing an opaque friend with a budget factory or arbitrary state
// mutation. Each exposed operation enforces the same one-way state machine;
// none accepts imported accounting or raw counter values.
class SearchBudgetAccess final {
 public:
  SearchBudgetAccess() = delete;

  [[nodiscard]] static Result<SearchBudget> begin(
      OptimizerExecutionContext& context);
  [[nodiscard]] static Result<void> claim_dispatch(SearchBudget& budget,
                                                   ServiceFamily family);
  [[nodiscard]] static Result<void> charge_expansion(SearchBudget& budget);
};

}  // namespace detail

// F-C05-02
[[nodiscard]] Result<SearchBudget> begin_search_budget(
    OptimizerExecutionContext& context);

}  // namespace mwperf
