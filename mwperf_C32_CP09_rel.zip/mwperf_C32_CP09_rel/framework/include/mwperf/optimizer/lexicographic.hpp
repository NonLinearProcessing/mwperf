#pragma once

#include "mwperf/model/priority_order.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {
#if defined(MWPERF_C05_TEST_SEAMS)
// Declaration only: the implementation is linked exclusively by the guarded
// optimizer-test target, so defining the macro in a consumer is insufficient
// to manufacture a PriorityOrder.
struct LexicographicTestAccess final {
  [[nodiscard]] static PriorityOrder make_priority_for_fixture(
      std::vector<DenseQueueIndex> rank_to_queue,
      std::vector<std::size_t> queue_to_rank);
};
#endif

}  // namespace detail

// F-C05-01. Returns a diagnostic only for a mismatched/corrupt dimension or
// priority carrier; all arithmetic in a valid query is total and exact.
[[nodiscard]] Result<LexWeights> compose_lexicographic_weights(
    const NonnegativeIntegralWeights& primary,
    const PriorityOrder& priority, const EligibilityMask& eligibility);

}  // namespace mwperf
