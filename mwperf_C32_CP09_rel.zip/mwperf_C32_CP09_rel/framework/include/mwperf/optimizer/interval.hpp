#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <new>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/diagnostic.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {

inline constexpr std::uint8_t interval_problem_type_tag = 0U;

}  // namespace detail

struct ExactInterval final {
  DenseQueueIndex queue;
  ExactRational left;
  ExactRational right;

  friend bool operator==(const ExactInterval&, const ExactInterval&) = default;
};

// F-C06-04. Input is the trusted right/left/queue ordering constructed by
// F-C06-03. The search is restricted to indices preceding j and uses exact
// half-open right <= left compatibility.
[[nodiscard]] inline std::vector<std::optional<std::size_t>>
find_interval_predecessors(const std::span<const ExactInterval> intervals) {
  std::vector<std::optional<std::size_t>> predecessors(intervals.size());
  for (std::size_t current = 0U; current < intervals.size(); ++current) {
    std::size_t first = 0U;
    std::size_t last = current;
    while (first < last) {
      const std::size_t middle = first + (last - first) / 2U;
      if (intervals[middle].right <= intervals[current].left) {
        first = middle + 1U;
      } else {
        last = middle;
      }
    }
    if (first != 0U) {
      predecessors[current] = first - 1U;
    }
  }
  return predecessors;
}

class IntervalProblem final {
 public:
  IntervalProblem() = delete;
  IntervalProblem(const IntervalProblem&) = default;
  IntervalProblem(IntervalProblem&&) noexcept = default;
  IntervalProblem& operator=(const IntervalProblem&) = default;
  IntervalProblem& operator=(IntervalProblem&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_to_ordered_.size();
  }
  [[nodiscard]] std::span<const ExactInterval> intervals() const noexcept {
    return intervals_;
  }
  [[nodiscard]] std::span<const std::optional<std::size_t>> predecessors()
      const noexcept {
    return predecessors_;
  }
  [[nodiscard]] std::span<const std::size_t> queue_to_ordered() const
      noexcept {
    return queue_to_ordered_;
  }
  [[nodiscard]] static const void* compiled_type_tag() noexcept {
    return &detail::interval_problem_type_tag;
  }

#if defined(MWPERF_C06_TEST_SEAMS)
  [[nodiscard]] static IntervalProblem for_test(
      std::vector<ExactInterval> intervals,
      std::vector<std::optional<std::size_t>> predecessors,
      std::vector<std::size_t> queue_to_ordered) {
    return IntervalProblem(std::move(intervals), std::move(predecessors),
                           std::move(queue_to_ordered));
  }
#endif

 private:
  IntervalProblem(
      std::vector<ExactInterval> intervals,
      std::vector<std::optional<std::size_t>> predecessors,
      std::vector<std::size_t> queue_to_ordered)
      : intervals_(std::move(intervals)),
        predecessors_(std::move(predecessors)),
        queue_to_ordered_(std::move(queue_to_ordered)) {}

  std::vector<ExactInterval> intervals_;
  std::vector<std::optional<std::size_t>> predecessors_;
  // Dense queue ordinal -> position in intervals_.
  std::vector<std::size_t> queue_to_ordered_;

  friend Result<IntervalProblem> compile_interval_problem(
      const ResolvedIntervalConstraint&);
};

// F-C06-03. Priority and backlog never enter this static exact geometry.
[[nodiscard]] inline Result<IntervalProblem> compile_interval_problem(
    const ResolvedIntervalConstraint& constraint) {
  const auto failure = [](std::string code, std::string message,
                          std::vector<std::string> notes = {}) {
    return Result<IntervalProblem>::failure(Diagnostic{
        .category = DiagnosticCategory::internal,
        .code = std::move(code),
        .message = std::move(message),
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = std::move(notes),
    });
  };

  try {
    const std::size_t queue_count = constraint.intervals.size();
    if (queue_count == 0U) {
      return failure("interval_compiled_geometry_empty",
                     "a compiled interval family requires at least one "
                     "queue interval");
    }

    std::vector<std::uint8_t> seen(queue_count, 0U);
    std::vector<ExactInterval> ordered;
    ordered.reserve(queue_count);
    for (const ResolvedInterval& interval : constraint.intervals) {
      const std::size_t queue = interval.queue.ordinal();
      if (queue >= queue_count || seen[queue] != 0U) {
        return failure("interval_compiled_queue_coverage_invalid",
                       "the bound intervals do not cover every dense queue "
                       "exactly once");
      }
      if (!(interval.left < interval.right)) {
        return failure("interval_compiled_bounds_invalid",
                       "a bound interval must satisfy exact left < right",
                       {"dense queue index: " + std::to_string(queue)});
      }
      seen[queue] = 1U;
      ordered.push_back(
          ExactInterval{interval.queue, interval.left, interval.right});
    }
    if (std::ranges::find(seen, std::uint8_t{0U}) != seen.end()) {
      return failure("interval_compiled_queue_coverage_invalid",
                     "the bound intervals omit a dense queue");
    }

    std::stable_sort(ordered.begin(), ordered.end(),
                     [](const ExactInterval& lhs, const ExactInterval& rhs) {
                       if (lhs.right != rhs.right) {
                         return lhs.right < rhs.right;
                       }
                       if (lhs.left != rhs.left) {
                         return lhs.left < rhs.left;
                       }
                       return lhs.queue < rhs.queue;
                     });
    std::vector<std::optional<std::size_t>> predecessors =
        find_interval_predecessors(ordered);
    std::vector<std::size_t> queue_to_ordered(queue_count, queue_count);
    for (std::size_t index = 0U; index < ordered.size(); ++index) {
      const std::size_t queue = ordered[index].queue.ordinal();
      queue_to_ordered[queue] = index;
      const std::optional<std::size_t> predecessor = predecessors[index];
      if (predecessor.has_value()) {
        if (*predecessor >= index ||
            !(ordered[*predecessor].right <= ordered[index].left)) {
          return failure("interval_predecessor_invariant",
                         "exact interval predecessor construction produced "
                         "an incompatible or non-earlier index");
        }
        if (*predecessor + 1U < index &&
            ordered[*predecessor + 1U].right <= ordered[index].left) {
          return failure("interval_predecessor_not_maximal",
                         "exact interval predecessor construction did not "
                         "return the latest compatible earlier interval");
        }
      } else if (index != 0U &&
                 ordered.front().right <= ordered[index].left) {
        return failure("interval_predecessor_missing",
                       "exact interval predecessor construction omitted a "
                       "compatible earlier interval");
      }
    }

    return Result<IntervalProblem>::success(IntervalProblem(
        std::move(ordered), std::move(predecessors),
        std::move(queue_to_ordered)));
  } catch (const std::bad_alloc&) {
    return Result<IntervalProblem>::failure(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "interval_compile_allocation_failure",
        .message = "allocation failed while compiling immutable interval "
                   "geometry",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  } catch (const std::length_error&) {
    return Result<IntervalProblem>::failure(Diagnostic{
        .category = DiagnosticCategory::resource_limit,
        .code = "interval_compile_representation_failure",
        .message = "immutable interval geometry exceeds a host container "
                   "limit",
        .authored_path = std::nullopt,
        .json_pointer = std::nullopt,
        .notes = {},
    });
  }
}

namespace detail {

struct IntervalExactWitness final {
  Schedule schedule;
  BigNat composite_objective;
  std::vector<std::string> proof_notes;
};

enum class IntervalTestFault : std::uint8_t {
  none,
  force_equal_transition,
};

// F-C06-05. The result remains unpromoted until the C05 dispatcher performs
// its common family, eligibility, feasibility, objective, and accounting
// checks.
[[nodiscard]] Result<IntervalExactWitness> solve_interval_exact(
    const IntervalProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition);

#if defined(MWPERF_C06_TEST_SEAMS)
[[nodiscard]] Result<IntervalExactWitness> solve_interval_exact_with_fault(
    const IntervalProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, const ForcedTargetCondition* condition,
    IntervalTestFault fault);
#endif

}  // namespace detail
}  // namespace mwperf
