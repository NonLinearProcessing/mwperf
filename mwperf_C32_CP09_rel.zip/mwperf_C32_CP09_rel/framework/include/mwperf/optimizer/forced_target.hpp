#pragma once

#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// F-C05-04. The target coordinate is excluded from the reported primary
// objective. Its requested bit nevertheless participates in the exact
// priority code, so equality between the two forced faces can later be
// resolved with precisely the configured physical tie order.
[[nodiscard]] Result<PrimaryOptimum> solve_forced_target(
    OptimizerExecutionContext& context,
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility,
    const PrimaryWeights& primary,
    TargetIndex target,
    ForcedTargetBit bit,
    const PriorityOrder& priority);

#if defined(MWPERF_C05_TEST_SEAMS)
namespace detail {

struct ExactOptimizerBackendServices;

// Per-call test/future-child injection. It exercises the identical forced
// orchestration, call reservation, condition, validation, and objective
// stripping as F-C05-04; only the statically linked backend table differs.
[[nodiscard]] Result<PrimaryOptimum>
solve_forced_target_with_backend_services(
    OptimizerExecutionContext& context,
    const ConstraintDescriptor& descriptor,
    const EligibilityMask& eligibility,
    const PrimaryWeights& primary,
    TargetIndex target,
    ForcedTargetBit bit,
    const PriorityOrder& priority,
    const ExactOptimizerBackendServices& services);

}  // namespace detail
#endif

}  // namespace mwperf
