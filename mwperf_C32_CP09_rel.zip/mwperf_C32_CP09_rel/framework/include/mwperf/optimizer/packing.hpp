#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/optimizer/conflict.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/optimizer/search_budget.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {

inline constexpr std::uint8_t packing_problem_type_tag = 0U;

}  // namespace detail

// One immutable resource coordinate retained in the C04 dense order. Labels
// are preserved so C08's typed compiled-product binding can compare the
// static problem with the resolved descriptor without relying on position
// alone.
struct PackingResource final {
  DenseResourceIndex index;
  ResourceId id;

  friend bool operator==(const PackingResource&,
                         const PackingResource&) = default;
};

// Exact residual capacities are value objects. In particular, an empty
// vector is a valid zero-dimensional resource space, not a missing value.
class CapacityVector final {
 public:
  CapacityVector(const CapacityVector&) = default;
  CapacityVector(CapacityVector&&) noexcept = default;
  CapacityVector& operator=(const CapacityVector&) = default;
  CapacityVector& operator=(CapacityVector&&) noexcept = default;

  [[nodiscard]] static CapacityVector from_values(
      std::vector<BigNat> values) {
    return CapacityVector(std::move(values));
  }

  [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
  [[nodiscard]] bool empty() const noexcept { return values_.empty(); }
  [[nodiscard]] std::span<const BigNat> values() const noexcept {
    return values_;
  }
  [[nodiscard]] const BigNat& operator[](const std::size_t index) const {
    return values_.at(index);
  }

  friend bool operator==(const CapacityVector&,
                         const CapacityVector&) = default;

 private:
  explicit CapacityVector(std::vector<BigNat> values)
      : values_(std::move(values)) {}

  std::vector<BigNat> values_;
};

struct CompiledPackingDemand final {
  DenseQueueIndex queue;
  std::vector<BigNat> demand;

  friend bool operator==(const CompiledPackingDemand&,
                         const CompiledPackingDemand&) = default;
};

// Immutable, backlog-independent F-C08-03 product. Queue records are stored
// in dense queue order; resource records and every capacity/demand coordinate
// are stored in the declared dense resource order. No memo, residual
// capacity, eligibility, or score is retained across calls.
class PackingProblem final {
 public:
  PackingProblem() = delete;
  PackingProblem(const PackingProblem&) = default;
  PackingProblem(PackingProblem&&) noexcept = default;
  PackingProblem& operator=(const PackingProblem&) = default;
  PackingProblem& operator=(PackingProblem&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return demands_.size();
  }
  [[nodiscard]] std::size_t resource_count() const noexcept {
    return resources_.size();
  }
  [[nodiscard]] std::span<const PackingResource> resources() const noexcept {
    return resources_;
  }
  [[nodiscard]] const CapacityVector& capacity() const noexcept {
    return capacity_;
  }
  [[nodiscard]] std::span<const CompiledPackingDemand> demands()
      const noexcept {
    return demands_;
  }
  [[nodiscard]] static const void* compiled_type_tag() noexcept {
    return &detail::packing_problem_type_tag;
  }

#if defined(MWPERF_C08_TEST_SEAMS)
  [[nodiscard]] static PackingProblem for_test(
      std::vector<PackingResource> resources, CapacityVector capacity,
      std::vector<CompiledPackingDemand> demands) {
    return PackingProblem(std::move(resources), std::move(capacity),
                          std::move(demands));
  }
#endif

 private:
  PackingProblem(std::vector<PackingResource> resources,
                 CapacityVector capacity,
                 std::vector<CompiledPackingDemand> demands)
      : resources_(std::move(resources)),
        capacity_(std::move(capacity)),
        demands_(std::move(demands)) {}

  std::vector<PackingResource> resources_;
  CapacityVector capacity_;
  // Dense queue ordinal -> demand record at the same position.
  std::vector<CompiledPackingDemand> demands_;

  friend Result<PackingProblem> compile_packing_problem(
      const ResolvedPackingConstraint&);
};

// F-C08-03. C04 has already parsed nonnegative integers and resolved typed
// identities. C08 defensively rechecks dense resource/queue coverage and all
// exact vector dimensions before publishing immutable geometry.
[[nodiscard]] Result<PackingProblem> compile_packing_problem(
    const ResolvedPackingConstraint& constraint);

// The exact memo key deliberately retains the complete, unchanged residual
// capacity vector as well as the logical-length-bearing queue bitset. This
// does not cap capacity or identify states through an unproved equivalence.
class PackingMemoKey final {
 public:
  PackingMemoKey(const PackingMemoKey&) = default;
  PackingMemoKey(PackingMemoKey&&) noexcept = default;
  PackingMemoKey& operator=(const PackingMemoKey&) = default;
  PackingMemoKey& operator=(PackingMemoKey&&) noexcept = default;

  [[nodiscard]] const QueueSubset& queues() const noexcept { return queues_; }
  [[nodiscard]] const CapacityVector& remaining_capacity() const noexcept {
    return remaining_capacity_;
  }

  friend bool operator==(const PackingMemoKey&,
                         const PackingMemoKey&) = default;

#if defined(MWPERF_C08_TEST_SEAMS)
  [[nodiscard]] static PackingMemoKey for_test(
      QueueSubset queues, CapacityVector remaining_capacity) {
    return PackingMemoKey(std::move(queues),
                          std::move(remaining_capacity));
  }
#endif

 private:
  PackingMemoKey(QueueSubset queues, CapacityVector remaining_capacity)
      : queues_(std::move(queues)),
        remaining_capacity_(std::move(remaining_capacity)) {}

  QueueSubset queues_;
  CapacityVector remaining_capacity_;

  friend Result<PackingMemoKey> normalize_packing_subproblem(
      const PackingProblem&, QueueSubset, CapacityVector);
};

// F-C08-04. The catalog's conceptual two-value slice is refined with the
// immutable problem carrying Gamma; without that read-only argument it is
// impossible to decide which queues fit. The function removes exactly the
// currently capacity-infeasible coordinates and retains the capacity
// unchanged. Dimension corruption is a checked transactional failure.
[[nodiscard]] Result<PackingMemoKey> normalize_packing_subproblem(
    const PackingProblem& problem, QueueSubset queues,
    CapacityVector remaining_capacity);

namespace detail {

struct PackingExactWitness final {
  Schedule schedule;
  BigNat composite_objective;
  std::vector<std::string> proof_notes;
};

// F-C08-05's family primitive. Dispatch supplies the already-claimed live
// budget. A forced side is geometry conditioning, never a score penalty.
[[nodiscard]] Result<PackingExactWitness> solve_packing_exact(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    const ForcedTargetCondition* condition = nullptr);

#if defined(MWPERF_C08_TEST_SEAMS)

enum class PackingSolveFault : std::uint8_t {
  none,
  force_distinct_branch_score_equality,
};

// Per-call instrumentation only. It is caller-owned, has no global registry,
// and is absent from production translation units. Counts observe calls,
// while expanded_keys contains exactly the successfully charged new nonbase
// keys in deterministic depth-first order.
struct PackingSolveInstrumentation final {
  std::vector<PackingMemoKey> expanded_keys;
  std::size_t base_calls{0U};
  std::size_t memo_hits{0U};
};

[[nodiscard]] Result<PackingExactWitness>
solve_packing_exact_with_instrumentation(
    const PackingProblem& problem, const EligibilityMask& eligibility,
    const LexWeights& weights, SearchBudget& budget,
    PackingSolveInstrumentation& instrumentation,
    PackingSolveFault fault = PackingSolveFault::none,
    const ForcedTargetCondition* condition = nullptr);

#endif

}  // namespace detail

}  // namespace mwperf
