#pragma once

#include <functional>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <utility>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

#if defined(MWPERF_C04_TEST_SEAMS)
namespace detail {

// Opaque identity for one successful C09 compile invocation. Support receives
// this exact owner token, and the owner is retained in ConfiguredArrivalBinding.
class ArrivalCompilationToken final {
 public:
  ArrivalCompilationToken() = delete;
  ArrivalCompilationToken(const ArrivalCompilationToken&) = default;
  ArrivalCompilationToken(ArrivalCompilationToken&& other) noexcept
      : binding_(other.binding_), owner_(other.owner_) {}
  ArrivalCompilationToken& operator=(const ArrivalCompilationToken&) = default;
  ArrivalCompilationToken& operator=(ArrivalCompilationToken&& other) noexcept {
    if (this != &other) {
      binding_ = other.binding_;
      owner_ = other.owner_;
    }
    return *this;
  }

  [[nodiscard]] static Result<ArrivalCompilationToken> for_fixture(
      PhysicalBindingIdentity binding, std::shared_ptr<const void> owner);
  [[nodiscard]] const PhysicalBindingIdentity& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] bool shares_owner_with(
      const ArrivalCompilationToken& other) const noexcept {
    return !owner_.owner_before(other.owner_) &&
           !other.owner_.owner_before(owner_);
  }
  [[nodiscard]] const std::shared_ptr<const void>& owner_for_adapter()
      const noexcept {
    return owner_;
  }

 private:
  ArrivalCompilationToken(PhysicalBindingIdentity binding,
                          std::shared_ptr<const void> owner)
      : binding_(std::move(binding)), owner_(std::move(owner)) {}

  PhysicalBindingIdentity binding_;
  std::shared_ptr<const void> owner_;
};

// A distinct product proves that the family-specific transient initializer ran
// after support was computed from the same compiled arrival law.
class InitialCompilationToken final {
 public:
  InitialCompilationToken() = delete;
  InitialCompilationToken(const InitialCompilationToken&) = default;
  InitialCompilationToken(InitialCompilationToken&& other) noexcept
      : binding_(other.binding_), owner_(other.owner_) {}
  InitialCompilationToken& operator=(const InitialCompilationToken&) = default;
  InitialCompilationToken& operator=(InitialCompilationToken&& other) noexcept {
    if (this != &other) {
      binding_ = other.binding_;
      owner_ = other.owner_;
    }
    return *this;
  }

  [[nodiscard]] static Result<InitialCompilationToken> for_fixture(
      PhysicalBindingIdentity binding, std::shared_ptr<const void> owner);
  [[nodiscard]] const PhysicalBindingIdentity& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] const std::shared_ptr<const void>& owner_for_adapter()
      const noexcept {
    return owner_;
  }

 private:
  InitialCompilationToken(PhysicalBindingIdentity binding,
                          std::shared_ptr<const void> owner)
      : binding_(std::move(binding)), owner_(std::move(owner)) {}

  PhysicalBindingIdentity binding_;
  std::shared_ptr<const void> owner_;
};

// Explicit, immutable test/future-child fixture. It is passed per call and
// therefore introduces no process-global registry, mutable ambient backend,
// fallback algorithm, or hidden execution state.
struct ResolutionChildServices final {
  using ConstraintCompiler = std::function<Result<ConstraintDescriptor>(
      const AuthoredSchedulerConfig&, const QueueCatalog&)>;
  using ArrivalCompiler = std::function<Result<ArrivalCompilationToken>(
      const AuthoredArrivalConfig&, const PhysicalBindingIdentity&,
      std::span<const BoundQueueReference>,
      const QueueCatalog&)>;
  using SupportCompiler = std::function<Result<QueueMask>(
      const ArrivalCompilationToken&, const PhysicalBindingIdentity&,
      std::span<const BoundQueueReference>,
      const QueueCatalog&)>;
  using InitialCompiler = std::function<Result<InitialCompilationToken>(
      const ArrivalCompilationToken&, const ResolvedTransientInitialLaw&,
      const PhysicalBindingIdentity&, std::span<const BoundQueueReference>,
      const QueueCatalog&)>;

  ConstraintCompiler constraint;
  ArrivalCompiler arrival;
  SupportCompiler support;
  InitialCompiler initial;
};

// Internal C04 integration seam. It is not a catalog function and is
// exercised only by tests. All production C06--C08 constraint children are
// now registered; the C09 arrival children remain future work.
[[nodiscard]] Result<ResolvedInstance>
resolve_physical_instance_with_child_services(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis,
    const InputFingerprintBundle& fingerprints,
    const ResolutionChildServices& children);

}  // namespace detail
#endif

// F-C04-05. The public path compiles all preferred exact-family geometries and
// enters the fixed append-only arrival registry.
[[nodiscard]] Result<ResolvedInstance> resolve_physical_instance(
    const AuthoredModelConfig& model, const AnalysisSpec& analysis,
    const InputFingerprintBundle& fingerprints);

}  // namespace mwperf
