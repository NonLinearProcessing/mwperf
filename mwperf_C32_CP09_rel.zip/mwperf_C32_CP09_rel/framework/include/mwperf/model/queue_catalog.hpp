#pragma once

#include <compare>
#include <cstddef>
#include <map>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// A dense queue index can only be obtained from a successfully constructed
// QueueCatalog.  The explicit ordinal accessor makes every use as an array
// subscript visible at the call site; there is no implicit native conversion.
class DenseQueueIndex final {
 public:
  DenseQueueIndex() = delete;
  DenseQueueIndex(const DenseQueueIndex&) = default;
  DenseQueueIndex(DenseQueueIndex&&) noexcept = default;
  DenseQueueIndex& operator=(const DenseQueueIndex&) = default;
  DenseQueueIndex& operator=(DenseQueueIndex&&) noexcept = default;
  ~DenseQueueIndex() = default;

  [[nodiscard]] std::size_t ordinal() const noexcept { return ordinal_; }

  friend bool operator==(const DenseQueueIndex&,
                         const DenseQueueIndex&) = default;
  friend std::strong_ordering operator<=>(const DenseQueueIndex&,
                                           const DenseQueueIndex&) = default;

 private:
  explicit DenseQueueIndex(std::size_t ordinal) noexcept : ordinal_(ordinal) {}

  std::size_t ordinal_;

  friend class QueueCatalog;
};

// Exact legacy VOQ coordinates are diagnostic metadata only.  They neither
// define queue identity nor participate in dense indexing.
struct QueueCatalogEntry final {
  QueueId id;
  std::optional<LegacyVoqCoordinate> legacy_voq;
  ModelProvenance provenance;
};

struct LegacyPortExtent final {
  BigNat value;
  bool derived;
  ModelProvenance provenance;
};

class QueueCatalog final {
 public:
  QueueCatalog() = delete;
  QueueCatalog(const QueueCatalog&) = default;
  QueueCatalog(QueueCatalog&&) noexcept = default;
  QueueCatalog& operator=(const QueueCatalog&) = default;
  QueueCatalog& operator=(QueueCatalog&&) noexcept = default;
  ~QueueCatalog() = default;

  [[nodiscard]] std::size_t size() const noexcept { return entries_.size(); }
  [[nodiscard]] bool empty() const noexcept { return entries_.empty(); }
  [[nodiscard]] std::span<const QueueCatalogEntry> entries() const noexcept {
    return entries_;
  }

  // index must originate from this catalog (or another catalog with the same
  // dense cardinality/ordering).  External code cannot forge an index.
  [[nodiscard]] const QueueCatalogEntry& entry(DenseQueueIndex index) const;
  [[nodiscard]] const QueueId& queue_id(DenseQueueIndex index) const;

  // Converts a checked native traversal position into the strong dense type.
  // This is intentionally fallible and is the only public native-to-dense
  // boundary.
  [[nodiscard]] Result<DenseQueueIndex> index_at(
      std::size_t ordinal) const;

  // Resolves an authored typed identity.  Failure is reported at reference,
  // rather than declaration, provenance.
  [[nodiscard]] Result<DenseQueueIndex> resolve(
      const QueueId& id, const ModelProvenance& reference) const;

  [[nodiscard]] const std::optional<LegacyPortExtent>& legacy_n_ports()
      const noexcept {
    return legacy_n_ports_;
  }

 private:
  [[nodiscard]] static DenseQueueIndex make_dense_index(
      std::size_t ordinal) noexcept {
    return DenseQueueIndex(ordinal);
  }

  QueueCatalog(std::vector<QueueCatalogEntry> entries,
               std::map<QueueId, DenseQueueIndex> reverse,
               std::optional<LegacyPortExtent> legacy_n_ports)
      : entries_(std::move(entries)),
        reverse_(std::move(reverse)),
        legacy_n_ports_(std::move(legacy_n_ports)) {}

  std::vector<QueueCatalogEntry> entries_;
  std::map<QueueId, DenseQueueIndex> reverse_;
  std::optional<LegacyPortExtent> legacy_n_ports_;

  friend Result<QueueCatalog> build_queue_catalog(
      const AuthoredSwitchConfig& authored_switch);
};

// F-C04-01
[[nodiscard]] Result<QueueCatalog> build_queue_catalog(
    const AuthoredSwitchConfig& authored_switch);

}  // namespace mwperf
