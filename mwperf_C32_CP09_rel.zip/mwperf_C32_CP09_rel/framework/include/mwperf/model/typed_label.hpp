#pragma once

#include <compare>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// A deliberately small carrier for the JSON value presented to
// parse_typed_label.  It preserves the number lexeme and never applies JSON's
// usual bool-to-integer or number-to-string coercions.  C03 remains responsible
// for the complete, source-located document representation.
class JsonValue final {
 public:
  enum class Kind {
    number,
    string,
    boolean,
    null_value,
    array,
    object,
  };

  // bound_policy is supplied by the trusted C03 parsing context; it is not a
  // field authored inside the model document.
  [[nodiscard]] static JsonValue number(
      std::string lexeme,
      BoundPolicy bound_policy = BoundPolicy::unbounded());
  [[nodiscard]] static JsonValue string(std::string utf8);
  [[nodiscard]] static JsonValue boolean(bool value);
  [[nodiscard]] static JsonValue null();
  [[nodiscard]] static JsonValue array();
  [[nodiscard]] static JsonValue object();

  JsonValue(const JsonValue&) = default;
  JsonValue(JsonValue&&) noexcept = default;
  JsonValue& operator=(const JsonValue&) = default;
  JsonValue& operator=(JsonValue&&) noexcept = default;
  ~JsonValue() = default;

  [[nodiscard]] Kind kind() const noexcept;
  [[nodiscard]] const std::string* number_lexeme() const noexcept;
  [[nodiscard]] const BoundPolicy* number_bound_policy() const noexcept;
  [[nodiscard]] const std::string* string_value() const noexcept;
  [[nodiscard]] const bool* boolean_value() const noexcept;

 private:
  struct Number final {
    std::string lexeme;
    BoundPolicy bound_policy;
  };
  struct String final {
    std::string utf8;
  };
  struct Null final {};
  struct Array final {};
  struct Object final {};

  using Storage = std::variant<Number, String, bool, Null, Array, Object>;

  explicit JsonValue(Storage storage);

  Storage storage_;
};

// A label is either an exact nonnegative integer or an already-trimmed UTF-8
// string.  There is intentionally no default construction and no implicit
// conversion between the alternatives.
class TypedLabel final {
 public:
  [[nodiscard]] static TypedLabel numeric(BigNat value);
  [[nodiscard]] static Result<TypedLabel> text(std::string utf8);

  TypedLabel(const TypedLabel&) = default;
  // Moving is deliberately value-preserving for the source as well as the
  // destination.  A default variant move could leave a string alternative
  // empty, which is not a legal TypedLabel.
  TypedLabel(TypedLabel&& other);
  TypedLabel& operator=(const TypedLabel&) = default;
  TypedLabel& operator=(TypedLabel&& other);
  ~TypedLabel() = default;

  [[nodiscard]] bool is_numeric() const noexcept;
  [[nodiscard]] bool is_text() const noexcept;
  [[nodiscard]] const BigNat* numeric_value() const noexcept;
  [[nodiscard]] const std::string* text_value() const noexcept;

  // Version-1 label bytes are exactly:
  //   numeric: 0x00 || minimal unsigned big-endian magnitude
  //   string:  0x01 || the validated, already-trimmed UTF-8 bytes
  // The caller must frame these bytes when composing a larger record.
  [[nodiscard]] std::vector<std::uint8_t> canonical_bytes() const;
  [[nodiscard]] std::uint64_t stable_hash() const;

  friend bool operator==(const TypedLabel&, const TypedLabel&) = default;
  friend std::strong_ordering operator<=>(const TypedLabel& left,
                                           const TypedLabel& right) noexcept;

 private:
  using Storage = std::variant<BigNat, std::string>;

  explicit TypedLabel(Storage storage);

  Storage storage_;
};

[[nodiscard]] Result<TypedLabel> parse_typed_label(const JsonValue& value);
[[nodiscard]] std::vector<std::uint8_t> canonical_typed_label_bytes(
    const TypedLabel& label);

// FNV-1a-64 is used only as a deterministic in-memory container hash.  It is
// not a fingerprint, authentication primitive, or substitute for C02 SHA-256.
[[nodiscard]] std::uint64_t stable_identity_hash(
    std::span<const std::uint8_t> bytes) noexcept;

// The canonical domain spelling is also the C++ type-level tag.  Consequently,
// two aliases that use the same spelling denote the same domain, while two
// different spellings necessarily denote different C++ types and different
// canonical byte encodings.  This prevents distinct tag structs from
// accidentally reusing one serialized domain name.
template <std::size_t Extent>
struct StrongIdDomainName final {
  char bytes[Extent];

  consteval StrongIdDomainName(const char (&source)[Extent]) : bytes{} {
    for (std::size_t index = 0; index < Extent; ++index) {
      bytes[index] = source[index];
    }
  }

  [[nodiscard]] constexpr bool is_valid() const noexcept {
    if (Extent <= 1U || bytes[Extent - 1U] != '\0') {
      return false;
    }
    for (std::size_t index = 0; index + 1U < Extent; ++index) {
      const auto byte = static_cast<unsigned char>(bytes[index]);
      if (byte < 0x21U || byte > 0x7eU) {
        return false;
      }
    }
    return true;
  }

  [[nodiscard]] constexpr std::string_view view() const noexcept {
    return std::string_view(bytes, Extent - 1U);
  }

  friend constexpr bool operator==(const StrongIdDomainName&,
                                   const StrongIdDomainName&) = default;
};

template <StrongIdDomainName DomainName>
class StrongId final {
  static_assert(DomainName.is_valid(),
                "a StrongId domain name must contain one or more printable "
                "non-space ASCII bytes");

 public:
  explicit StrongId(TypedLabel label) : label_(std::move(label)) {
    static_assert(sizeof(std::size_t) <= sizeof(std::uint64_t),
                  "StrongId framing requires size_t to fit in u64");
  }

  StrongId(const StrongId&) = default;
  StrongId(StrongId&&) = default;
  StrongId& operator=(const StrongId&) = default;
  StrongId& operator=(StrongId&&) = default;
  ~StrongId() = default;

  [[nodiscard]] const TypedLabel& label() const noexcept { return label_; }

  // Version-1 generic-ID envelope:
  // ASCII("mwperf.strong_id") || 0x00 || u32be(1) ||
  // u64be(domain-size) || domain || u64be(label-size) || label.
  [[nodiscard]] std::vector<std::uint8_t> canonical_bytes() const {
    constexpr std::string_view prefix{"mwperf.strong_id"};
    constexpr std::string_view domain = DomainName.view();
    const std::vector<std::uint8_t> label_bytes = label_.canonical_bytes();

    std::vector<std::uint8_t> encoded;
    encoded.reserve(prefix.size() + 1U + 4U + 8U + domain.size() + 8U +
                    label_bytes.size());
    encoded.insert(encoded.end(), prefix.begin(), prefix.end());
    encoded.push_back(0U);
    append_u32be(encoded, 1U);
    append_u64be(encoded, static_cast<std::uint64_t>(domain.size()));
    encoded.insert(encoded.end(), domain.begin(), domain.end());
    append_u64be(encoded, static_cast<std::uint64_t>(label_bytes.size()));
    encoded.insert(encoded.end(), label_bytes.begin(), label_bytes.end());
    return encoded;
  }

  [[nodiscard]] std::uint64_t stable_hash() const {
    const std::vector<std::uint8_t> encoded = canonical_bytes();
    return stable_identity_hash(encoded);
  }

  friend bool operator==(const StrongId&, const StrongId&) = default;
  friend std::strong_ordering operator<=>(const StrongId& left,
                                           const StrongId& right) noexcept {
    return left.label_ <=> right.label_;
  }

 private:
  static void append_u32be(std::vector<std::uint8_t>& destination,
                           const std::uint32_t value) {
    for (unsigned int shift = 32U; shift != 0U; shift -= 8U) {
      destination.push_back(
          static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }

  static void append_u64be(std::vector<std::uint8_t>& destination,
                           const std::uint64_t value) {
    for (unsigned int shift = 64U; shift != 0U; shift -= 8U) {
      destination.push_back(
          static_cast<std::uint8_t>(value >> (shift - 8U)));
    }
  }

  TypedLabel label_;
};

template <StrongIdDomainName LeftDomain, StrongIdDomainName RightDomain>
[[nodiscard]] bool same_strong_id(const StrongId<LeftDomain>& left,
                                  const StrongId<RightDomain>& right) noexcept {
  if constexpr (
      std::same_as<StrongId<LeftDomain>, StrongId<RightDomain>>) {
    return left == right;
  }
  static_cast<void>(left);
  static_cast<void>(right);
  return false;
}

using QueueId = StrongId<"queue">;
using PortId = StrongId<"port">;
using VertexId = StrongId<"vertex">;
using ResourceId = StrongId<"resource">;

}  // namespace mwperf

namespace std {

template <>
struct hash<mwperf::TypedLabel> {
  [[nodiscard]] size_t operator()(const mwperf::TypedLabel& label) const {
    return static_cast<size_t>(label.stable_hash());
  }
};

template <mwperf::StrongIdDomainName DomainName>
struct hash<mwperf::StrongId<DomainName>> {
  [[nodiscard]] size_t operator()(
      const mwperf::StrongId<DomainName>& identity) const {
    return static_cast<size_t>(identity.stable_hash());
  }
};

}  // namespace std
