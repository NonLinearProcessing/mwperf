#pragma once

#include <cstddef>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

#if defined(MWPERF_C05_TEST_SEAMS)
namespace detail {
struct LexicographicTestAccess;
}
#endif

// rank_to_queue and queue_to_rank are complete inverse permutations.  The
// class has no mutating accessors, so a published order is safe to share.
class PriorityOrder final {
 public:
  PriorityOrder() = delete;
  PriorityOrder(const PriorityOrder&) = default;
  PriorityOrder(PriorityOrder&&) noexcept = default;
  PriorityOrder& operator=(const PriorityOrder&) = default;
  PriorityOrder& operator=(PriorityOrder&&) noexcept = default;
  ~PriorityOrder() = default;

  [[nodiscard]] std::size_t size() const noexcept {
    return rank_to_queue_.size();
  }
  [[nodiscard]] DenseQueueIndex queue_at_rank(std::size_t rank) const;
  [[nodiscard]] std::size_t rank_of(DenseQueueIndex queue) const;
  [[nodiscard]] std::span<const DenseQueueIndex> rank_to_queue() const noexcept {
    return rank_to_queue_;
  }
  [[nodiscard]] std::span<const std::size_t> queue_to_rank() const noexcept {
    return queue_to_rank_;
  }
  [[nodiscard]] bool is_catalog_order() const noexcept;

 private:
  PriorityOrder(std::vector<DenseQueueIndex> rank_to_queue,
                std::vector<std::size_t> queue_to_rank)
      : rank_to_queue_(std::move(rank_to_queue)),
        queue_to_rank_(std::move(queue_to_rank)) {}

  std::vector<DenseQueueIndex> rank_to_queue_;
  std::vector<std::size_t> queue_to_rank_;

  friend Result<PriorityOrder> resolve_priority(
      const AuthoredSchedulerConfig& authored_scheduler,
      const QueueCatalog& queues);
#if defined(MWPERF_C05_TEST_SEAMS)
  friend struct detail::LexicographicTestAccess;
#endif
};

// F-C04-02
[[nodiscard]] Result<PriorityOrder> resolve_priority(
    const AuthoredSchedulerConfig& authored_scheduler,
    const QueueCatalog& queues);

}  // namespace mwperf
