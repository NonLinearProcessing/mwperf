#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/priority_order.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

#if defined(MWPERF_C19_TEST_SEAMS)
namespace testing {
class C19FixtureAccess;
}
#endif
#if defined(MWPERF_C20_TEST_SEAMS)
namespace testing {
class C20ArrivalFixtureAccess;
}
#endif

namespace detail {
struct ResolutionBuilder;
struct CompiledArrivalAccess;
struct CompiledInitialLawAccess;
}  // namespace detail

// The only timing convention admitted by the analytical framework. Keeping it
// typed in the resolved object prevents a later backend from silently choosing
// another slot boundary.
enum class TimingConvention : std::uint8_t {
  early_service_late_admission,
};

enum class ArrivalFamily : std::uint8_t {
  deterministic_trace,
  periodic_global_phase,
  periodic_source_delays,
  independent_marked_renewal,
  independent_private_markov_renewal,
  shared_joint_round_markov_renewal,
  // Append-only CP09 tags: the released C09 numeric tags above do not move.
  iid_independent_bernoulli,
  iid_count_table,
  iid_independent_poisson,
  iid_mixed_poisson,
};

[[nodiscard]] std::string_view to_string(ArrivalFamily family) noexcept;

// C04 identity for every arrival-related handoff. It is intentionally smaller
// than a future C09 compiled law, but prevents a same-shaped object from a
// different input pair, family, timing convention, or catalog cardinality
// from being treated as interchangeable.
struct PhysicalBindingIdentity final {
  Digest256 combined_input;
  ArrivalFamily arrival_family;
  TimingConvention timing;
  std::size_t queue_cardinality;

  friend bool operator==(const PhysicalBindingIdentity&,
                         const PhysicalBindingIdentity&) = default;
};

// C09's exact identity for the object stored behind C04's erased arrival
// carrier.  Keeping this metadata outside the erased owner lets recovery
// verify both the public physical binding and the immutable law/catalog
// fingerprints before accepting a typed product.
struct ArrivalProductBindingIdentity final {
  ArrivalFamily family;
  TimingConvention timing;
  std::size_t queue_cardinality;
  Digest256 law_digest;
  Digest256 catalog_digest;

  friend bool operator==(const ArrivalProductBindingIdentity&,
                         const ArrivalProductBindingIdentity&) = default;
};

// One source-authored queue reference bound to the catalog. Repeated
// references are retained because arrival row order and multiplicity remain
// semantically significant after C04.
struct BoundQueueReference final {
  DenseQueueIndex queue;
  ModelProvenance provenance;
};

enum class ArrivalCompiledProductKind : std::uint8_t {
  opaque_test_fixture,
  compiled_arrival_law_v1,
};

enum class InitialCompiledProductKind : std::uint8_t {
  opaque_test_fixture,
  initial_physical_law_v1,
};

// C04's stable handoff to C09: the tagged authored law is available through
// ResolvedInstance::authored_model(), while this carrier proves that every
// queue reference has been bound without rewriting authored order.
class ConfiguredArrivalBinding final {
 public:
  ConfiguredArrivalBinding() = delete;
  ConfiguredArrivalBinding(const ConfiguredArrivalBinding&) = default;
  ConfiguredArrivalBinding(ConfiguredArrivalBinding&&) noexcept = default;
  ConfiguredArrivalBinding& operator=(const ConfiguredArrivalBinding&) =
      default;
  ConfiguredArrivalBinding& operator=(ConfiguredArrivalBinding&&) noexcept =
      default;

  [[nodiscard]] ArrivalFamily family() const noexcept {
    return identity_.arrival_family;
  }
  [[nodiscard]] const PhysicalBindingIdentity& identity() const noexcept {
    return identity_;
  }
  [[nodiscard]] std::span<const BoundQueueReference> queue_references()
      const noexcept {
    return queue_references_;
  }
  [[nodiscard]] bool has_compiled_product() const noexcept {
    return static_cast<bool>(compiled_product_owner_);
  }
  [[nodiscard]] ArrivalCompiledProductKind compiled_product_kind()
      const noexcept {
    return compiled_product_kind_;
  }
  [[nodiscard]] bool shares_compiled_product_with(
      const ConfiguredArrivalBinding& other) const noexcept {
    return compiled_product_owner_ && other.compiled_product_owner_ &&
           !compiled_product_owner_.owner_before(other.compiled_product_owner_) &&
           !other.compiled_product_owner_.owner_before(compiled_product_owner_);
  }

 private:
  ConfiguredArrivalBinding(PhysicalBindingIdentity identity,
                           std::vector<BoundQueueReference> queue_references,
                           std::shared_ptr<const void> compiled_product_owner,
                           ArrivalCompiledProductKind compiled_product_kind,
                           std::optional<ArrivalProductBindingIdentity>
                               compiled_product_identity)
      : identity_(std::move(identity)),
        queue_references_(std::move(queue_references)),
        compiled_product_owner_(std::move(compiled_product_owner)),
        compiled_product_kind_(compiled_product_kind),
        compiled_product_identity_(std::move(compiled_product_identity)) {}

  PhysicalBindingIdentity identity_;
  std::vector<BoundQueueReference> queue_references_;
  std::shared_ptr<const void> compiled_product_owner_;
  ArrivalCompiledProductKind compiled_product_kind_;
  std::optional<ArrivalProductBindingIdentity> compiled_product_identity_;

  friend struct detail::ResolutionBuilder;
  friend struct detail::CompiledArrivalAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
#if defined(MWPERF_C20_TEST_SEAMS)
  friend class testing::C20ArrivalFixtureAccess;
#endif
};

// Positive arrival support is a C09 result, but its dense immutable carrier is
// fixed here so ResolvedInstance never exposes a raw queue identity. The
// validating factory is the sole construction boundary used by C09 and C04
// fixture services.
class QueueMask final {
 public:
  QueueMask() = delete;
  QueueMask(const QueueMask&) = default;
  QueueMask(QueueMask&&) noexcept = default;
  QueueMask& operator=(const QueueMask&) = default;
  QueueMask& operator=(QueueMask&&) noexcept = default;

  [[nodiscard]] static Result<QueueMask> from_bytes(
      std::vector<std::uint8_t> values, std::size_t expected_size);

  [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
  [[nodiscard]] bool at(DenseQueueIndex queue) const {
    return values_.at(queue.ordinal()) != 0U;
  }
  [[nodiscard]] const std::vector<std::uint8_t>& bytes() const noexcept {
    return values_;
  }

 private:
  explicit QueueMask(std::vector<std::uint8_t> values)
      : values_(std::move(values)) {}

  std::vector<std::uint8_t> values_;
};

struct ResolvedBacklogEntry final {
  DenseQueueIndex queue;
  BigNat value;
  SourceNode source;
};

struct ResolvedTransientInitialAtom final {
  AuthoredProbability probability;
  SourceNode probability_source;
  // Dense catalog order. This is the unique complete backlog vector; the
  // authored-order records below exist only for source-aware reporting.
  std::vector<BigNat> backlog;
  std::vector<ResolvedBacklogEntry> authored_backlog;
  ArrivalInitialState arrival_state;
  SourceNode arrival_state_source;
  SourceNode controller_state;
  SourceNode static_context;
  SourceNode surrogate_initial;
  SourceNode source;
};

struct ResolvedTransientInitialLaw final {
  std::vector<ResolvedTransientInitialAtom> atoms;
  SourceNode source;
};

// Presence means that C09's family-specific initializer accepted the coupled
// joint atoms. C04 retains the exact atoms; it does not invent a C09 concrete
// state-machine type or normalize their probabilities.
class InitialLawBinding final {
 public:
  InitialLawBinding() = delete;
  InitialLawBinding(const InitialLawBinding&) = default;
  InitialLawBinding(InitialLawBinding&&) noexcept = default;
  InitialLawBinding& operator=(const InitialLawBinding&) = default;
  InitialLawBinding& operator=(InitialLawBinding&&) noexcept = default;

  [[nodiscard]] const ResolvedTransientInitialLaw& law() const noexcept {
    return law_;
  }
  [[nodiscard]] const PhysicalBindingIdentity& identity() const noexcept {
    return identity_;
  }
  [[nodiscard]] bool has_compiled_product() const noexcept {
    return static_cast<bool>(compiled_product_owner_);
  }
  [[nodiscard]] InitialCompiledProductKind compiled_product_kind()
      const noexcept {
    return compiled_product_kind_;
  }
  [[nodiscard]] bool shares_compiled_product_with(
      const InitialLawBinding& other) const noexcept {
    return compiled_product_owner_ && other.compiled_product_owner_ &&
           !compiled_product_owner_.owner_before(other.compiled_product_owner_) &&
           !other.compiled_product_owner_.owner_before(compiled_product_owner_);
  }

 private:
  InitialLawBinding(PhysicalBindingIdentity identity,
                    ResolvedTransientInitialLaw law,
                    std::shared_ptr<const void> compiled_product_owner,
                    InitialCompiledProductKind compiled_product_kind,
                    std::optional<ArrivalProductBindingIdentity>
                        compiled_product_identity)
      : identity_(std::move(identity)),
        law_(std::move(law)),
        compiled_product_owner_(std::move(compiled_product_owner)),
        compiled_product_kind_(compiled_product_kind),
        compiled_product_identity_(std::move(compiled_product_identity)) {}

  PhysicalBindingIdentity identity_;
  ResolvedTransientInitialLaw law_;
  std::shared_ptr<const void> compiled_product_owner_;
  InitialCompiledProductKind compiled_product_kind_;
  std::optional<ArrivalProductBindingIdentity> compiled_product_identity_;

  friend struct detail::ResolutionBuilder;
  friend struct detail::CompiledInitialLawAccess;
#if defined(MWPERF_C19_TEST_SEAMS)
  // C27 reuses C19's narrow exact-arrival fixture authority.  A transient
  // rebind must replace the compiled initializer together with its arrival
  // product; retaining the previous opaque owner would cross law identities.
  friend class testing::C19FixtureAccess;
#endif
#if defined(MWPERF_C20_TEST_SEAMS)
  // The C20 arrival fixture replaces one compiled arrival product with a
  // same-physical-binding exact law.  Its authored transient initializer must
  // be recompiled against that replacement rather than retaining the old
  // C09 product behind this carrier.
  friend class testing::C20ArrivalFixtureAccess;
#endif
};

struct ResolvedTarget final {
  DenseQueueIndex queue;
  ModelProvenance provenance;
};

class ResolvedTargetSet final {
 public:
  ResolvedTargetSet() = delete;
  ResolvedTargetSet(const ResolvedTargetSet&) = default;
  ResolvedTargetSet(ResolvedTargetSet&&) noexcept = default;
  ResolvedTargetSet& operator=(const ResolvedTargetSet&) = default;
  ResolvedTargetSet& operator=(ResolvedTargetSet&&) noexcept = default;

  [[nodiscard]] std::size_t size() const noexcept { return targets_.size(); }
  [[nodiscard]] std::span<const ResolvedTarget> values() const noexcept {
    return targets_;
  }

 private:
  explicit ResolvedTargetSet(std::vector<ResolvedTarget> targets)
      : targets_(std::move(targets)) {}

  std::vector<ResolvedTarget> targets_;

  friend struct detail::ResolutionBuilder;
};

// Immutable grants only. The mutable solve-call ledger belongs to C27.
struct OptimizerBudgetPolicy final {
  std::optional<BigNat> physical_per_call;
  std::optional<BigNat> analysis_per_call;
  std::optional<BigNat> effective_per_call;
  std::optional<BigNat> max_calls;
};

// A published instance is a shared immutable storage snapshot. Copies share
// the same const storage; no cache, solve state, or execution ledger is held.
class ResolvedInstance final {
 public:
  ResolvedInstance() = delete;
  ResolvedInstance(const ResolvedInstance&) noexcept = default;
  ResolvedInstance(ResolvedInstance&&) noexcept = default;
  ResolvedInstance& operator=(const ResolvedInstance&) noexcept = default;
  ResolvedInstance& operator=(ResolvedInstance&&) noexcept = default;
  ~ResolvedInstance();

  [[nodiscard]] const AuthoredModelConfig& authored_model() const noexcept;
  [[nodiscard]] const AnalysisSpec& analysis_spec() const noexcept;
  [[nodiscard]] const InputFingerprintBundle& fingerprints() const noexcept;
  [[nodiscard]] const QueueCatalog& queues() const noexcept;
  [[nodiscard]] const PriorityOrder& priority() const noexcept;
  [[nodiscard]] const ConstraintDescriptor& constraint() const noexcept;
  [[nodiscard]] const DerivedServiceIdentity& service_identity()
      const noexcept;
  [[nodiscard]] const ServiceableMask& serviceable() const noexcept;
  [[nodiscard]] const OptimizerBudgetPolicy& optimizer_budget() const noexcept;
  [[nodiscard]] const ResolvedTargetSet& targets() const noexcept;
  [[nodiscard]] const ConfiguredArrivalBinding& arrival() const noexcept;
  [[nodiscard]] const QueueMask& positive_arrival_support() const noexcept;
  [[nodiscard]] const std::optional<InitialLawBinding>& initial_law()
      const noexcept;
  [[nodiscard]] TimingConvention timing() const noexcept;

  // These accessors make the inert/reference-simulation fields explicit. They
  // are retained verbatim and never become analytical cutoffs or budgets.
  [[nodiscard]] const AuthoredRunConfig& run_provenance() const noexcept;
  [[nodiscard]] const AuthoredTelemetryConfig& telemetry_provenance()
      const noexcept;
  [[nodiscard]] const AuthoredMetadata& metadata_provenance() const noexcept;

 private:
  struct Storage;
  ResolvedInstance(
      AuthoredModelConfig model, AnalysisSpec analysis,
      InputFingerprintBundle fingerprints, QueueCatalog queues,
      PriorityOrder priority, ConstraintDescriptor constraint,
      DerivedServiceIdentity service_identity,
      ServiceableMask serviceable, OptimizerBudgetPolicy optimizer_budget,
      ResolvedTargetSet targets, ConfiguredArrivalBinding arrival,
      QueueMask positive_arrival_support,
      std::optional<InitialLawBinding> initial_law,
      TimingConvention timing);

  std::shared_ptr<const Storage> storage_;

  friend struct detail::ResolutionBuilder;
#if defined(MWPERF_C19_TEST_SEAMS)
  friend class testing::C19FixtureAccess;
#endif
#if defined(MWPERF_C20_TEST_SEAMS)
  friend class testing::C20ArrivalFixtureAccess;
#endif
};

}  // namespace mwperf
