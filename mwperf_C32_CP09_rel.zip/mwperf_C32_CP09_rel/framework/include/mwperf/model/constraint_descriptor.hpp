#pragma once

#include <compare>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class CompiledConstraintProduct;
class CrossbarProblem;
class ConflictProblem;
class IntervalProblem;
class NodeExclusiveProblem;
class PackingProblem;
class QueueDimensionToken;

namespace detail {
struct ConstraintIndexFactory;
struct ConstraintDescriptorFactory;
class ExactBackendAuthority;

// This complete access type is present in every consumer translation unit, so
// a caller cannot complete an opaque friend with broader owner access. Its two
// fixed recovery operations additionally require the unforgeable, per-dispatch
// C05 authority; ordinary callers cannot unwrap the type-erased product.
class C06CompiledProductAccess final {
 public:
  C06CompiledProductAccess() = delete;

  [[nodiscard]] static Result<const CrossbarProblem*> crossbar(
      const CompiledConstraintProduct& product,
      const ExactBackendAuthority& authority);
  [[nodiscard]] static Result<const IntervalProblem*> intervals(
      const CompiledConstraintProduct& product,
      const ExactBackendAuthority& authority);
};

// C07 owns one additional, narrowly scoped recovery operation. As for the
// C06 accessors, the exact-dispatch authority is required before the opaque
// C04 lifetime token can be checked and recovered as its concrete type.
class C07CompiledProductAccess final {
 public:
  C07CompiledProductAccess() = delete;

  [[nodiscard]] static Result<const NodeExclusiveProblem*> node_exclusive(
      const CompiledConstraintProduct& product,
      const ExactBackendAuthority& authority);
};

// C08 owns the final two exact-family recovery operations. The opaque C04
// product remains inaccessible without the dispatch-scoped C05 authority and
// a successful private concrete-type tag check.
class C08CompiledProductAccess final {
 public:
  C08CompiledProductAccess() = delete;

  [[nodiscard]] static Result<const ConflictProblem*> conflicts(
      const CompiledConstraintProduct& product,
      const ExactBackendAuthority& authority);
  [[nodiscard]] static Result<const PackingProblem*> packing(
      const CompiledConstraintProduct& product,
      const ExactBackendAuthority& authority);
};

struct InputIndexTag final {};
struct OutputIndexTag final {};
struct VertexIndexTag final {};
struct ResourceIndexTag final {};
}  // namespace detail

// Constraint-coordinate indices are intentionally distinct from queue indices
// and from one another. Only the validating C04 compiler can create them.
template <typename Domain>
class DenseConstraintIndex final {
 public:
  DenseConstraintIndex() = delete;

  [[nodiscard]] std::size_t ordinal() const noexcept { return ordinal_; }

  friend bool operator==(const DenseConstraintIndex&,
                         const DenseConstraintIndex&) = default;
  friend std::strong_ordering operator<=>(const DenseConstraintIndex&,
                                           const DenseConstraintIndex&) =
      default;

 private:
  explicit DenseConstraintIndex(const std::size_t ordinal) noexcept
      : ordinal_(ordinal) {}

  friend struct detail::ConstraintIndexFactory;

  std::size_t ordinal_;
};

using DenseInputIndex = DenseConstraintIndex<detail::InputIndexTag>;
using DenseOutputIndex = DenseConstraintIndex<detail::OutputIndexTag>;
using DenseVertexIndex = DenseConstraintIndex<detail::VertexIndexTag>;
using DenseResourceIndex = DenseConstraintIndex<detail::ResourceIndexTag>;

enum class ExactSchedulerName : std::uint8_t {
  crossbar_max_weight,
  interval_max_weight,
  node_exclusive_max_weight,
  conflict_graph_max_weight,
  resource_packing_max_weight,
};

enum class ServiceFamily : std::uint8_t {
  crossbar_matching,
  nonoverlapping_intervals,
  node_exclusive_matching,
  pairwise_conflicts,
  resource_packing,
};

enum class OptimizerId : std::uint8_t {
  hungarian_exact,
  weighted_interval_dp_exact,
  edmonds_blossom_exact,
  mwis_branch_memo_exact,
  binary_packing_memo_exact,
};

[[nodiscard]] std::string_view to_string(ExactSchedulerName value) noexcept;
[[nodiscard]] std::string_view to_string(ServiceFamily value) noexcept;
[[nodiscard]] std::string_view to_string(OptimizerId value) noexcept;

struct DerivedServiceIdentity final {
  ExactSchedulerName scheduler;
  ServiceFamily family;
  OptimizerId optimizer;

  friend bool operator==(const DerivedServiceIdentity&,
                         const DerivedServiceIdentity&) = default;
};

// C04 owns only this family-tagged lifetime token. The pointed-to static
// problem has a concrete type owned by C06, C07, or C08; C04 neither inspects
// it nor defines a surrogate/base-class protocol for it. A product is created
// synchronously by the trusted, statically linked child invoked for the bound
// geometry in the same compile call. C04 checks non-null ownership and the
// closed family tag; it intentionally does not invent a second geometry digest
// or accept a caller-supplied reusable product.
class CompiledConstraintProduct final {
 public:
  CompiledConstraintProduct() = delete;
  CompiledConstraintProduct(const CompiledConstraintProduct&) = default;
  CompiledConstraintProduct(CompiledConstraintProduct&&) noexcept = default;
  CompiledConstraintProduct& operator=(
      const CompiledConstraintProduct&) = default;
  CompiledConstraintProduct& operator=(CompiledConstraintProduct&&) noexcept =
      default;

  [[nodiscard]] ServiceFamily family() const noexcept { return family_; }
  [[nodiscard]] bool has_owner() const noexcept {
    return static_cast<bool>(owner_);
  }

#if defined(MWPERF_C04_TEST_SEAMS)
  // C04 tests use an inert owner to exercise the future-child boundary. No
  // production caller can manufacture a compiled product at this checkpoint.
  [[nodiscard]] static Result<CompiledConstraintProduct> for_fixture(
      ServiceFamily family, std::shared_ptr<const void> owner);
#endif

 private:
  CompiledConstraintProduct(ServiceFamily family,
                            std::shared_ptr<const void> owner,
                            const void* compiled_type_tag = nullptr)
      : family_(family),
        owner_(std::move(owner)),
        compiled_type_tag_(compiled_type_tag) {}

  friend struct detail::ConstraintDescriptorFactory;
  friend class detail::C06CompiledProductAccess;
  friend class detail::C07CompiledProductAccess;
  friend class detail::C08CompiledProductAccess;
  // C05 may retain the exact ownership identity in its queue-dimension token.
  // Typed backend recovery remains deferred to each owning C06--C08 checkpoint;
  // C04 exposes no raw owner or general cloning interface.
  friend class QueueDimensionToken;

  ServiceFamily family_;
  std::shared_ptr<const void> owner_;
  // Null is reserved for the C04/C05 injected fixture products. Concrete
  // family checkpoints attach a private process-local type tag so a backend
  // can reject a mismatched opaque owner before any cast or dereference.
  const void* compiled_type_tag_;
};

struct ResolvedInputPort final {
  DenseInputIndex index;
  PortId id;
  ModelProvenance provenance;
};

struct ResolvedOutputPort final {
  DenseOutputIndex index;
  PortId id;
  ModelProvenance provenance;
};

struct ResolvedCrossbarEdge final {
  DenseQueueIndex queue;
  DenseInputIndex input;
  DenseOutputIndex output;
  ModelProvenance provenance;
};

struct ResolvedCrossbarConstraint final {
  std::vector<ResolvedInputPort> inputs;
  std::vector<ResolvedOutputPort> outputs;
  std::vector<ResolvedCrossbarEdge> edges;
  ModelProvenance provenance;
};

struct ResolvedInterval final {
  DenseQueueIndex queue;
  ExactRational left;
  ExactRational right;
  ModelProvenance provenance;
};

struct ResolvedIntervalConstraint final {
  // Authored record order is significant and remains unchanged here.
  std::vector<ResolvedInterval> intervals;
  ModelProvenance provenance;
};

struct ResolvedVertex final {
  DenseVertexIndex index;
  VertexId id;
  ModelProvenance provenance;
};

struct ResolvedNodeExclusiveLink final {
  DenseQueueIndex queue;
  DenseVertexIndex u;
  DenseVertexIndex v;
  ModelProvenance provenance;
};

struct ResolvedNodeExclusiveConstraint final {
  std::vector<ResolvedVertex> vertices;
  std::vector<ResolvedNodeExclusiveLink> links;
  ModelProvenance provenance;
};

struct ResolvedConflictPair final {
  // Canonical dense order: first.ordinal() < second.ordinal(). The authored
  // pair's source provenance is retained even when its orientation is reversed.
  DenseQueueIndex first;
  DenseQueueIndex second;
  ModelProvenance provenance;
};

struct ResolvedConflictConstraint final {
  std::vector<ResolvedConflictPair> conflicts;
  // One row per catalog queue. Isolated queues therefore remain explicit.
  std::vector<std::vector<DenseQueueIndex>> adjacency;
  ModelProvenance provenance;
};

struct ResolvedResource final {
  DenseResourceIndex index;
  ResourceId id;
  ModelProvenance provenance;
};

struct ResolvedPackingDemand final {
  DenseQueueIndex queue;
  std::vector<BigNat> demand;
  ModelProvenance provenance;
};

struct ResolvedPackingConstraint final {
  std::vector<ResolvedResource> resources;
  std::vector<BigNat> capacity;
  // Authored demand order is retained; every queue appears exactly once.
  std::vector<ResolvedPackingDemand> demands;
  ModelProvenance provenance;
};

using ConstraintVariant =
    std::variant<ResolvedCrossbarConstraint, ResolvedIntervalConstraint,
                 ResolvedNodeExclusiveConstraint, ResolvedConflictConstraint,
                 ResolvedPackingConstraint>;

// A descriptor can be constructed only by compile_constraint_descriptor. Its
// value is immutable through this interface and contains no solve-local cache.
class ConstraintDescriptor final {
 public:
  ConstraintDescriptor() = delete;
  ConstraintDescriptor(const ConstraintDescriptor&) = default;
  ConstraintDescriptor(ConstraintDescriptor&&) noexcept = default;
  ConstraintDescriptor& operator=(const ConstraintDescriptor&) = default;
  ConstraintDescriptor& operator=(ConstraintDescriptor&&) noexcept = default;

  [[nodiscard]] const ConstraintVariant& value() const noexcept {
    return value_;
  }
  [[nodiscard]] ServiceFamily family() const noexcept;
  [[nodiscard]] DerivedServiceIdentity identity() const noexcept;
  [[nodiscard]] const CompiledConstraintProduct& compiled_product()
      const noexcept {
    return compiled_product_;
  }
  [[nodiscard]] bool downward_closed() const noexcept { return true; }
  [[nodiscard]] std::string summary() const;

 private:
  ConstraintDescriptor(ConstraintVariant value,
                       CompiledConstraintProduct compiled_product)
      : value_(std::move(value)),
        compiled_product_(std::move(compiled_product)) {}

  friend Result<ConstraintDescriptor> compile_constraint_descriptor(
      const AuthoredSchedulerConfig&, const QueueCatalog&);
  friend struct detail::ConstraintDescriptorFactory;

  ConstraintVariant value_;
  CompiledConstraintProduct compiled_product_;
};

// Immutable byte mask with one entry per dense queue. Bytes are used instead
// of vector<bool> so representation and reads have ordinary value semantics.
class ServiceableMask final {
 public:
  ServiceableMask() = delete;

  [[nodiscard]] std::size_t size() const noexcept { return values_.size(); }
  [[nodiscard]] bool at(DenseQueueIndex queue) const {
    return values_.at(queue.ordinal()) != 0U;
  }
  [[nodiscard]] bool all() const noexcept;
  [[nodiscard]] const std::vector<std::uint8_t>& bytes() const noexcept {
    return values_;
  }

 private:
  explicit ServiceableMask(std::vector<std::uint8_t> values)
      : values_(std::move(values)) {}

  friend ServiceableMask compute_individual_serviceability(
      const ConstraintDescriptor&);

  std::vector<std::uint8_t> values_;
};

// F-C04-03. This binds static geometry and invokes the exact family compiler
// child. At C08 all five preferred exact-family children are registered. No
// alternate algorithm, optimization call, or feasible-schedule enumeration
// occurs here.
[[nodiscard]] Result<ConstraintDescriptor> compile_constraint_descriptor(
    const AuthoredSchedulerConfig& scheduler, const QueueCatalog& catalog);

#if defined(MWPERF_C04_TEST_SEAMS)
namespace detail {

// Per-call test/future-child injection. Each function is statically typed to
// its bound family, returns a non-null ownership token, and carries no global
// registry, fallback algorithm, or solve state.
struct ConstraintCompilerServices final {
  using CrossbarCompiler = std::function<Result<CompiledConstraintProduct>(
      const ResolvedCrossbarConstraint&)>;
  using IntervalCompiler = std::function<Result<CompiledConstraintProduct>(
      const ResolvedIntervalConstraint&)>;
  using NodeExclusiveCompiler =
      std::function<Result<CompiledConstraintProduct>(
          const ResolvedNodeExclusiveConstraint&)>;
  using ConflictCompiler = std::function<Result<CompiledConstraintProduct>(
      const ResolvedConflictConstraint&)>;
  using PackingCompiler = std::function<Result<CompiledConstraintProduct>(
      const ResolvedPackingConstraint&)>;

  CrossbarCompiler crossbar;
  IntervalCompiler intervals;
  NodeExclusiveCompiler node_exclusive;
  ConflictCompiler conflicts;
  PackingCompiler packing;
};

[[nodiscard]] Result<ConstraintDescriptor>
compile_constraint_descriptor_with_child_services(
    const AuthoredSchedulerConfig& scheduler, const QueueCatalog& catalog,
    const ConstraintCompilerServices& children);

}  // namespace detail
#endif

// F-C04-04.
[[nodiscard]] ServiceableMask compute_individual_serviceability(
    const ConstraintDescriptor& descriptor);

}  // namespace mwperf
