#pragma once

#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/optimizer/exact_optimizer.hpp"
#include "mwperf/physical/physical_edge.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
struct C20RngAccess;
struct PhysicalEngineAccess;
struct PhysicalRunOwner;
struct RngBankSnapshotState;
}  // namespace detail

namespace sampling::detail {
struct C24RngAccess;
}

class RngBankSnapshot final {
 public:
  // Preserve C12's three-field brace construction for diagnostic callers.
  // Such a legacy value has no owned restore record; C20 restoration accepts
  // only snapshots minted by RngBank::snapshot().
  RngBankSnapshot(BigNat initial_words, BigNat tie_words,
                  const bool is_initialized)
      : initial_joint_atom_words(std::move(initial_words)),
        tie_resolution_words(std::move(tie_words)),
        initialized(is_initialized),
        state_(nullptr) {}
  RngBankSnapshot(const RngBankSnapshot&) = default;
  RngBankSnapshot(RngBankSnapshot&&) noexcept = default;
  RngBankSnapshot& operator=(const RngBankSnapshot&) = default;
  RngBankSnapshot& operator=(RngBankSnapshot&&) noexcept = default;
  ~RngBankSnapshot() = default;

  // Retained for the C12 diagnostic surface.  The complete, versioned RNG
  // checkpoints and route binding are owned privately by this value as well.
  BigNat initial_joint_atom_words;
  BigNat tie_resolution_words;
  bool initialized;

  friend bool operator==(const RngBankSnapshot&,
                         const RngBankSnapshot&);

 private:
  RngBankSnapshot(BigNat initial_words, BigNat tie_words, bool is_initialized,
                  std::shared_ptr<const detail::RngBankSnapshotState> state)
      : initial_joint_atom_words(std::move(initial_words)),
        tie_resolution_words(std::move(tie_words)),
        initialized(is_initialized),
        state_(std::move(state)) {}

  std::shared_ptr<const detail::RngBankSnapshotState> state_;

  friend class RngBank;
  friend struct detail::C20RngAccess;
};

// C12's closed physical-reference stage bank. All streams are derived from
// one C02 physical-reference instance key. The configured-arrival stream is
// deployed exactly once into ArrivalProcess; no generic stream is exposed.
class RngBank final {
 public:
  RngBank() = delete;
  RngBank(const RngBank&) = delete;
  RngBank& operator=(const RngBank&) = delete;
  RngBank(RngBank&&) noexcept = default;
  RngBank& operator=(RngBank&&) = delete;
  ~RngBank() = default;

  [[nodiscard]] static Result<RngBank> for_physical_reference(
      const ResolvedInstance& instance, MasterSeed seed);

  [[nodiscard]] const Digest256& combined_input() const noexcept {
    return combined_input_;
  }
  [[nodiscard]] MasterSeed seed() const noexcept { return seed_; }
  [[nodiscard]] const InstanceKey& instance_key() const noexcept {
    return instance_key_;
  }
  [[nodiscard]] const Digest256& configured_arrival_stream_identity()
      const noexcept {
    return configured_arrival_stream_identity_;
  }
  [[nodiscard]] RngBankSnapshot snapshot() const;

 private:
  struct TemporalAdvanceAddress final {
    Digest256 cursor_digest;
    BigNat residence_index;
    BigNat slot_offset;

    friend bool operator==(const TemporalAdvanceAddress&,
                           const TemporalAdvanceAddress&) = default;
  };

  RngBank(Digest256 combined_input, MasterSeed seed,
          InstanceKey instance_key, DeterministicRng initial_joint_atom,
          DeterministicRng tie_resolution,
          Digest256 configured_arrival_stream_identity,
          std::shared_ptr<const detail::PhysicalRunOwner> run_owner,
          bool temporal_path,
          std::optional<Digest256> temporal_framework_digest,
          std::optional<Digest256> reduced_initial_law_digest,
          bool estimator_purpose = false,
          std::optional<StageTag> estimator_stage = std::nullopt)
      : combined_input_(std::move(combined_input)),
        seed_(seed),
        instance_key_(std::move(instance_key)),
        initial_joint_atom_(std::move(initial_joint_atom)),
        tie_resolution_(std::move(tie_resolution)),
        configured_arrival_stream_identity_(
            std::move(configured_arrival_stream_identity)),
        run_owner_(std::move(run_owner)),
        initialized_(false),
        temporal_path_(temporal_path),
        temporal_framework_digest_(std::move(temporal_framework_digest)),
        reduced_initial_law_digest_(std::move(reduced_initial_law_digest)),
        estimator_purpose_(estimator_purpose),
        estimator_stage_(estimator_stage),
        estimator_draw_consumed_(false) {}

  Digest256 combined_input_;
  MasterSeed seed_;
  InstanceKey instance_key_;
  DeterministicRng initial_joint_atom_;
  DeterministicRng tie_resolution_;
  Digest256 configured_arrival_stream_identity_;
  std::shared_ptr<const detail::PhysicalRunOwner> run_owner_;
  bool initialized_;
  bool temporal_path_;
  std::optional<Digest256> temporal_framework_digest_;
  std::optional<Digest256> reduced_initial_law_digest_;
  std::optional<TemporalAdvanceAddress> temporal_advance_address_;
  bool estimator_purpose_;
  std::optional<StageTag> estimator_stage_;
  bool estimator_draw_consumed_;

  friend class detail::C17CoreAccess;
  friend struct detail::C20RngAccess;
  friend struct detail::PhysicalEngineAccess;
  friend struct sampling::detail::C24RngAccess;
};

namespace detail {

// Narrow C20-only access to the shared C02/C12 bank.  The temporal module
// owns the cursor and calls bind/clear around exactly one C17 slot advance;
// C17 may inspect the private address but no plug callback can recover it.
struct C20RngAccess final {
  [[nodiscard]] static Result<RngBank> make_temporal_bank(
      const ResolvedInstance& instance,
      const Digest256& audited_framework_digest,
      const Digest256& reduced_initial_law_digest, MasterSeed seed);

  [[nodiscard]] static Result<RngBank> restore_temporal_bank(
      const RngBankSnapshot& snapshot);

  [[nodiscard]] static DeterministicRng& initial_joint_atom(
      RngBank& bank) noexcept;
  [[nodiscard]] static bool initialized(const RngBank& bank) noexcept;
  [[nodiscard]] static Result<void> mark_initialized(RngBank& bank);

  [[nodiscard]] static Result<void> bind_advance_address(
      RngBank& bank, const Digest256& cursor_digest,
      const BigNat& residence_index, const BigNat& slot_offset);
  static void clear_advance_address(RngBank& bank) noexcept;

  [[nodiscard]] static const Digest256& temporal_root_fingerprint(
      const RngBank& bank) noexcept;
};

}  // namespace detail

class InitializedPhysicalRun final {
 public:
  InitializedPhysicalRun() = delete;
  InitializedPhysicalRun(const InitializedPhysicalRun&) = delete;
  InitializedPhysicalRun& operator=(const InitializedPhysicalRun&) = delete;
  InitializedPhysicalRun(InitializedPhysicalRun&&) noexcept = default;
  InitializedPhysicalRun& operator=(InitializedPhysicalRun&&) = delete;
  ~InitializedPhysicalRun() = default;

  [[nodiscard]] PhysicalState& state() noexcept { return state_; }
  [[nodiscard]] const PhysicalState& state() const noexcept { return state_; }
  [[nodiscard]] ArrivalProcess& arrival_process() noexcept { return process_; }
  [[nodiscard]] const ArrivalProcess& arrival_process() const noexcept {
    return process_;
  }

 private:
  InitializedPhysicalRun(PhysicalState state, ArrivalProcess process)
      : state_(std::move(state)), process_(std::move(process)) {}

  PhysicalState state_;
  ArrivalProcess process_;

  friend struct detail::PhysicalEngineAccess;
  friend Result<class PhysicalPath> execute_reference_path(
      const ResolvedInstance&, const CompiledArrivalLaw&,
      const InitialPhysicalLaw&, const BigNat&, MasterSeed,
      OptimizerExecutionContext&);
};

class PhysicalPath final {
 public:
  PhysicalPath() = delete;
  PhysicalPath(const PhysicalPath&) = default;
  PhysicalPath(PhysicalPath&&) noexcept = default;
  PhysicalPath& operator=(const PhysicalPath&) = default;
  PhysicalPath& operator=(PhysicalPath&&) noexcept = default;
  ~PhysicalPath() = default;

  [[nodiscard]] const PhysicalState& initial_state() const noexcept {
    return initial_state_;
  }
  [[nodiscard]] const PhysicalState& final_state() const noexcept {
    return final_state_;
  }
  [[nodiscard]] std::span<const PhysicalEdge> edges() const noexcept {
    return edges_;
  }
  [[nodiscard]] std::span<const QueueId> queue_ids() const noexcept {
    return queue_ids_;
  }

 private:
  PhysicalPath(PhysicalState initial_state, PhysicalState final_state,
               std::vector<PhysicalEdge> edges,
               std::vector<QueueId> queue_ids)
      : initial_state_(std::move(initial_state)),
        final_state_(std::move(final_state)),
        edges_(std::move(edges)),
        queue_ids_(std::move(queue_ids)) {}

  PhysicalState initial_state_;
  PhysicalState final_state_;
  std::vector<PhysicalEdge> edges_;
  std::vector<QueueId> queue_ids_;

  friend struct detail::PhysicalEngineAccess;
};

// F-C12-01
[[nodiscard]] Result<InitializedPhysicalRun> initialize_physical_run(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival_law,
    const InitialPhysicalLaw& initial_law, RngBank& rng_bank);

// Exact D=s*1{Q>0}; exposed so downstream exact-reduction code and tests use
// the same checked departure semantics as F-C12-02.
[[nodiscard]] Result<Schedule> compute_actual_departure(
    const Backlog& backlog, const Schedule& schedule);

// F-C12-02
[[nodiscard]] Result<Backlog> apply_queue_recursion(
    const Backlog& backlog, const Schedule& schedule,
    const ArrivalBatch& arrival_batch);

// F-C12-03
[[nodiscard]] Result<PhysicalEdge> execute_physical_slot(
    const ResolvedInstance& instance, PhysicalState& state,
    ArrivalProcess& arrival_process, RngBank& rng_bank,
    OptimizerExecutionContext& optimizer_context);

// F-C12-05. The public reference path always uses replication/path ID zero.
[[nodiscard]] Result<PhysicalPath> execute_reference_path(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival_law,
    const InitialPhysicalLaw& initial_law, const BigNat& horizon,
    MasterSeed seed, OptimizerExecutionContext& optimizer_context);

[[nodiscard]] bool same_physical_path(const PhysicalPath& left,
                                      const PhysicalPath& right) noexcept;

// Deterministic C12 fixture/debug representation. Exact naturals are emitted
// as decimal strings and queue labels retain their numeric-vs-text tag.
[[nodiscard]] std::string serialize_physical_path(const PhysicalPath& path);

#if defined(MWPERF_C12_TEST_SEAMS)
namespace testing {

struct PhysicalSlotServices final {
  std::function<Result<ScheduleDecision>(
      const ResolvedInstance&, const Backlog&, const TieContext&,
      OptimizerExecutionContext&)>
      resolve;
  std::function<Result<ArrivalStep>(ArrivalProcess&, const BigNat&)> arrival;
  std::function<Result<void>(const ArrivalStep&)> post_arrival_validate;
};

[[nodiscard]] Result<PhysicalEdge> execute_physical_slot_with_services(
    const ResolvedInstance& instance, PhysicalState& state,
    ArrivalProcess& arrival_process, RngBank& rng_bank,
    OptimizerExecutionContext& optimizer_context,
    const PhysicalSlotServices& services);

}  // namespace testing
#endif

}  // namespace mwperf
