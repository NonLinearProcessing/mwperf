#pragma once

#include <cstdint>
#include <memory>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/arrival/types.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/physical/physical_state.hpp"

namespace mwperf {

namespace detail {
struct PhysicalEngineAccess;
}  // namespace detail

enum class RevealStage : std::uint8_t {
  boundary_observation,
  decision_completed,
  late_admission,
};

enum class PhysicalMarkKind : std::uint8_t {
  controller_memory_before,
  controller_memory_after,
  static_context,
  predictive_phase_before,
  predictive_phase_after,
  schedule,
  departure,
  arrival_batch,
};

// The payload for each mark remains in the typed state/decision/arrival field;
// this record says when that already-retained payload becomes observable.
struct PhysicalMarkEvidence final {
  PhysicalMarkKind kind;
  RevealStage stage;

  friend bool operator==(const PhysicalMarkEvidence&,
                         const PhysicalMarkEvidence&) = default;
};

class PhysicalEdge final {
 public:
  PhysicalEdge() = delete;
  PhysicalEdge(const PhysicalEdge&) = default;
  PhysicalEdge(PhysicalEdge&&) noexcept = default;
  PhysicalEdge& operator=(const PhysicalEdge&) = default;
  PhysicalEdge& operator=(PhysicalEdge&&) noexcept = default;
  ~PhysicalEdge() = default;

  [[nodiscard]] const BigNat& slot_index() const noexcept {
    return slot_index_;
  }
  [[nodiscard]] const PhysicalState& pre_state() const noexcept {
    return pre_state_;
  }
  [[nodiscard]] const ScheduleDecision& decision() const noexcept {
    return decision_;
  }
  [[nodiscard]] const Schedule& departure() const noexcept {
    return departure_;
  }
  [[nodiscard]] const ArrivalStep& arrival_step() const noexcept {
    return *arrival_step_;
  }
  [[nodiscard]] const PhysicalState& post_state() const noexcept {
    return post_state_;
  }
  [[nodiscard]] std::span<const PhysicalMarkEvidence> marks() const noexcept {
    return marks_;
  }

 private:
  PhysicalEdge(BigNat slot_index, PhysicalState pre_state,
               ScheduleDecision decision, Schedule departure,
               std::shared_ptr<const ArrivalStep> arrival_step,
               PhysicalState post_state,
               std::vector<PhysicalMarkEvidence> marks)
      : slot_index_(std::move(slot_index)),
        pre_state_(std::move(pre_state)),
        decision_(std::move(decision)),
        departure_(std::move(departure)),
        arrival_step_(std::move(arrival_step)),
        post_state_(std::move(post_state)),
        marks_(std::move(marks)) {}

  BigNat slot_index_;
  PhysicalState pre_state_;
  ScheduleDecision decision_;
  Schedule departure_;
  std::shared_ptr<const ArrivalStep> arrival_step_;
  PhysicalState post_state_;
  std::vector<PhysicalMarkEvidence> marks_;

  friend struct detail::PhysicalEngineAccess;
};

[[nodiscard]] bool same_physical_edge(const PhysicalEdge& left,
                                      const PhysicalEdge& right) noexcept;

// F-C12-04. Inputs are required to be a validated candidate transition. The
// function only derives D and packages immutable evidence; it never solves,
// samples, or mutates either endpoint.
[[nodiscard]] PhysicalEdge make_physical_edge(
    const PhysicalState& pre_state, const ScheduleDecision& decision,
    const ArrivalStep& arrival_step, const PhysicalState& post_state);

}  // namespace mwperf
