#pragma once

#include <cstddef>
#include <memory>
#include <utility>

#include "mwperf/arrival/types.hpp"
#include "mwperf/config/source_node.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/optimizer/types.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace mwperf {

namespace detail {
struct PhysicalEngineAccess;
struct PhysicalRunOwner;
}  // namespace detail

// Reproducibility and ownership evidence common to every boundary state in
// one cold physical-reference path.  The process-local owner token used by the
// engine is deliberately not part of this portable value: equal cold replays
// have equal identities even though their mutable cursors are independent.
struct PhysicalRunIdentity final {
  Digest256 combined_input;
  ArrivalBinding arrival_binding;
  MasterSeed seed;
  BigNat path_or_replication_id;
  Digest256 instance_key;
  Digest256 initial_stream_identity;
  Digest256 tie_stream_identity;
  Digest256 configured_arrival_stream_identity;
  Digest256 arrival_realization_identity;
  std::size_t initial_original_row_index;
  std::size_t initial_coalesced_atom_index;

  friend bool operator==(const PhysicalRunIdentity&,
                         const PhysicalRunIdentity&) = default;
};

// Completed boundary state (Q(t), M(t), H(t)).  Public code receives value
// semantics and read-only access; only the physical engine can construct a
// new boundary or commit it to a live run.
class PhysicalState final {
 public:
  PhysicalState() = delete;
  PhysicalState(const PhysicalState&) = default;
  PhysicalState(PhysicalState&&) noexcept = default;
  PhysicalState& operator=(const PhysicalState&) = default;
  PhysicalState& operator=(PhysicalState&&) noexcept = default;
  ~PhysicalState() = default;

  [[nodiscard]] const Backlog& backlog() const noexcept { return backlog_; }
  [[nodiscard]] const BigNat& boundary_index() const noexcept {
    return boundary_index_;
  }
  [[nodiscard]] const SourceNode& controller_memory() const noexcept {
    return controller_memory_;
  }
  [[nodiscard]] const SourceNode& static_context() const noexcept {
    return static_context_;
  }
  [[nodiscard]] const ArrivalPhase& arrival_phase() const noexcept {
    return arrival_phase_;
  }
  [[nodiscard]] const PhysicalRunIdentity& run_identity() const noexcept {
    return run_identity_;
  }

 private:
  PhysicalState(Backlog backlog, BigNat boundary_index,
                SourceNode controller_memory, SourceNode static_context,
                ArrivalPhase arrival_phase,
                PhysicalRunIdentity run_identity,
                std::shared_ptr<const detail::PhysicalRunOwner> run_owner)
      : backlog_(std::move(backlog)),
        boundary_index_(std::move(boundary_index)),
        controller_memory_(std::move(controller_memory)),
        static_context_(std::move(static_context)),
        arrival_phase_(std::move(arrival_phase)),
        run_identity_(std::move(run_identity)),
        run_owner_(std::move(run_owner)) {}

  Backlog backlog_;
  BigNat boundary_index_;
  SourceNode controller_memory_;
  SourceNode static_context_;
  ArrivalPhase arrival_phase_;
  PhysicalRunIdentity run_identity_;
  std::shared_ptr<const detail::PhysicalRunOwner> run_owner_;

  friend struct detail::PhysicalEngineAccess;
  friend bool same_physical_state(const PhysicalState&,
                                  const PhysicalState&) noexcept;
};

// Semantic equality intentionally ignores source locations and the private
// mutable-run owner token.  This makes independent fixed-seed replays directly
// comparable while retaining strict owner checks at execution boundaries.
[[nodiscard]] bool same_physical_state(const PhysicalState& left,
                                       const PhysicalState& right) noexcept;

}  // namespace mwperf
