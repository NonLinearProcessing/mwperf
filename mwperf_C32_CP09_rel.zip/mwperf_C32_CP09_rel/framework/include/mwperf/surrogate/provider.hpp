#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/config/source_node.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/kernel/reduced_edge.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/random/rng_stage.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/build_outcome.hpp"
#include "mwperf/surrogate/audited_consumer_seam.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/plug_contract.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf {

struct ConditionalSamplingRewardV1;
struct ExactCausalProgramV1;
struct AuditedFrameworkSeedV1;
struct ResultEnvelopeV2;
enum class ProviderResultKindV2 : std::uint8_t;
class RuntimeDirectMetricActivationV1;
class CompiledArrivalLaw;
class ResolvedInstance;
class ValidatedConstructionObservationBundleV1;

namespace detail {
class C16ProviderRegistryMint;
}

struct ValidatedParameterPayloadV1 final {
  std::vector<std::byte> canonical_bytes;
  // The provider alone knows this immutable value's concrete type.  It is a
  // process-local convenience and never enters C15 request bytes or identity.
  std::shared_ptr<const void> typed_value;
};

using ParameterValidatorV1 =
    std::function<Result<ValidatedParameterPayloadV1>(const SourceNode&)>;
using DescriptorPreviewerV1 = std::function<Result<PlugDescriptorPreview>(
    const FrameworkProblemView&, const MetricRequirements&,
    const ConstructionBudget&, const ValidatedSurrogateParameters&)>;

struct InlineImmediateProducerV1 final {
  std::function<ProviderExecutionOutcome(const SurrogateBuildRequest&)> invoke;
};
struct InProcessBuilderV1 final {
  std::function<ProviderExecutionOutcome(const SurrogateBuildRequest&,
                                         BuildExecutionContext&)>
      invoke;
};
struct LocalExecutableBuilderV1 final {
  RegisteredExecutableSpec executable;
};

using ProviderProducerV1 =
    std::variant<InlineImmediateProducerV1, InProcessBuilderV1,
                 LocalExecutableBuilderV1>;

using RuntimePlugMaterializerV1 =
    std::function<Result<RuntimePlugCandidateV1>(
        const PortablePlugPayload&, const ValidatedSurrogateArtifact&,
        const AcceptedCapabilityContract&)>;

// Callback-free statistical facts for a registered C24 route.  These typed
// values let C27 select and audit an estimator without executing either the
// stochastic sampler or the provider-owned activation recipe.
enum class ConditionalEstimatorProcedureV1 : std::uint8_t {
  conditional_empirical_row,
  conditional_reward_mean,
  self_normalized_importance,
};

struct ConditionalRewardPremisesV1 final {
  bool binary_indicator{false};
  std::optional<ExactRational> almost_sure_lower;
  std::optional<ExactRational> almost_sure_upper;

  friend bool operator==(const ConditionalRewardPremisesV1&,
                         const ConditionalRewardPremisesV1&) = default;
};

// Callback-free facts about a provider-owned C17 activation recipe.  C27 may
// inspect these flags while constructing a plan, but must not execute the
// recipe until C16 has validated the artifact and materialized its plug.
// These declarations are registry metadata only: they are neither evidence
// of V0 nor a replacement for the exact checks performed by C17/C18/C24.
struct FrameworkActivationCapabilitiesV1 final {
  bool supplies_finite_backend_domain{false};
  // Declares that the supplied finite C18 domain is closed either as the raw
  // exact state law or under C17's audited, mark-preserving stationary clock
  // quotient.  C18 recompiles every row and proves the claimed closure.
  bool proves_exact_closed_boundary{false};
  bool supplies_single_conditioning_state{false};
  bool supplies_direct_factor{false};
  bool supplies_conditional_reward_decoder{false};
  // A C24 plan must freeze its reproducibility stage before executing the
  // provider.  The stage is callback-free registry metadata; the activation
  // recipe cannot select or change it after inspecting a realized artifact.
  std::optional<StageTag> conditional_sampler_rng_stage{};
  // Distinct from the finite C18 invariant domain.  Stationary C20/C21/C22
  // matrix construction requires an explicitly indexed event-entry domain in
  // the sealed causal program; an exact countable event predicate is not a
  // finite-domain certificate.
  bool supplies_finite_event_domain{false};
  // Callback-free hard upper bounds for every allocation-bearing exact
  // activation path.  They are registry declarations, not mathematical
  // cutoffs: C27 compares them with the authored C03 grants before invoking
  // a provider, and the registry checks the realized activation/access shape
  // against the same declarations afterward.
  std::optional<BigNat> maximum_finite_backend_states{};
  std::optional<BigNat> maximum_finite_event_states{};
  std::optional<BigNat> maximum_row_atoms{};
  std::optional<BigNat> maximum_residence_slots{};
  // Present exactly when a fresh direct causal-factor recipe is supplied.
  // Unlike native allocation bounds, zero is a meaningful proof that the
  // composite factor audit cannot invoke the physical optimizer.
  std::optional<BigNat> maximum_direct_factor_optimizer_calls{};
  // Trailing fields preserve the source compatibility of pre-C27 aggregate
  // registrations.  A C24 registration supplies all three typed procedure
  // facts together with its RNG stage.  Reward premises are absent only for
  // the empirical-row procedure; a finite exact range also supplies the
  // moment premise needed by bounded reward diagnostics.
  std::optional<ConditionalSampleDependenceV1>
      conditional_sampler_dependence{};
  std::optional<ConditionalEstimatorProcedureV1>
      conditional_estimator_procedure{};
  std::optional<ConditionalRewardPremisesV1>
      conditional_reward_premises{};

  friend bool operator==(const FrameworkActivationCapabilitiesV1&,
                         const FrameworkActivationCapabilitiesV1&) = default;
};

// The activation callback receives only already validated, immutable inputs.
// This is deliberately a process-local non-owning view: it cannot be encoded
// in a C15 artifact, transported by a provider, or persisted as scientific
// evidence.  The callback is invoked synchronously by
// activate_registered_surrogate_framework.
struct RuntimeFrameworkBindingContextV1 final {
  FrameworkProblemFingerprintsV1 problem_fingerprints;
  FrameworkProblemViewDigest problem_view_digest;
  Digest256 descriptor_digest;
  Digest256 access_digest;
  Digest256 accepted_contract_digest;
  Digest256 normalized_metric_requirements_digest;
  Digest256 ordered_target_digest;
  Digest256 selection_digest;
  Digest256 build_request_digest;
  std::optional<ExactMetricDecoderDomainV1> direct_metric_decoder_domain;

  // Complete the final C17 binding only after the provider-owned exact state
  // schema exists.  This avoids representing an all-zero digest as a
  // provisional schema identity and makes the two-stage dependency explicit.
  [[nodiscard]] AuditedFrameworkBindingsV1 bind_state_schema(
      const ExactReducedStateSchemaV1& schema) const {
    return AuditedFrameworkBindingsV1{
        problem_fingerprints,
        problem_view_digest,
        schema.exact_state_schema_digest,
        schema.reduced_state_schema_digest,
        descriptor_digest,
        access_digest,
        accepted_contract_digest,
        normalized_metric_requirements_digest,
        ordered_target_digest,
        selection_digest,
        build_request_digest,
        direct_metric_decoder_domain};
  }
};

struct RuntimeFrameworkActivationContextV1 final {
  const PortablePlugPayload& portable_payload;
  const ValidatedSurrogateArtifact& artifact;
  const AcceptedCapabilityContract& accepted_contract;
  const FrameworkProblemView& problem_view;
  const ResolvedInstance& resolved_instance;
  const CompiledArrivalLaw& configured_arrival;
  const PlugDescriptor& descriptor;
  const KernelAccess& kernel_access;
  const RealizedMetricBindingsV1& realized_metric_bindings;
  const RuntimeFrameworkBindingContextV1& framework_binding_context;
  const BuildIdentityDigest& build_identity;
  const Digest256& final_request_identity;
};

// Provider-owned inputs required to create C17's unpublished candidate.  The
// finite-domain and conditioning-state fields are retained for later exact
// backends because the corresponding C17 program metadata is intentionally
// sealed after V0.  `exact_closed_boundary_proven` is only a declaration of
// the recipe's scope; C18 must still compile every row and verify raw closure
// or the independently sealed stationary physical-clock quotient.
struct RuntimeFrameworkActivationV1 final {
  RuntimeFrameworkActivationV1() = delete;
  RuntimeFrameworkActivationV1(const RuntimeFrameworkActivationV1&) = delete;
  RuntimeFrameworkActivationV1& operator=(
      const RuntimeFrameworkActivationV1&) = delete;
  RuntimeFrameworkActivationV1(RuntimeFrameworkActivationV1&&) noexcept =
      default;
  RuntimeFrameworkActivationV1& operator=(
      RuntimeFrameworkActivationV1&&) noexcept = default;

  ExactReducedStateSchemaV1 exact_state_schema;
  // These immutable process-local carriers are pointer-owned here so the C16
  // provider header remains independent of C17's mint definition.  C27,
  // which already includes the C17 contract, copies their exact values into
  // the unpublished candidate.
  std::shared_ptr<const ExactCausalProgramV1> causal_program;
  std::shared_ptr<const AuditedFrameworkSeedV1> framework_seed;
  // The pointee is itself move-only and the registry requires unique
  // ownership before returning it.  Pointer indirection keeps this C16
  // header independent of C17's complete recipe definition.
  std::shared_ptr<RuntimeDirectMetricActivationV1>
      direct_metric_activation;
  std::vector<ReducedStateV1> finite_backend_domain_states;
  bool exact_closed_boundary_proven{false};
  // A conditioning state has mathematical meaning only for the one accepted
  // clause/request that authored it.  V1 intentionally carries one such
  // binding rather than a free state that an executor could reuse for a
  // different metric or target.
  struct SingleConditioningStateBindingV1 final {
    MetricClauseIdV1 accepted_clause_id;
    Digest256 support_clause_digest;
    Digest256 normalized_metric_request_digest;
    ReducedStateV1 state;
  };
  std::optional<SingleConditioningStateBindingV1>
      single_conditioning_state;
  // A C24 reward decoder is usable only for the exact accepted support
  // clause and normalized one-metric request named here.  Equal decoder
  // values or output codecs do not bridge these identities.
  struct ConditionalRewardDecoderBindingV1 final {
    MetricClauseIdV1 accepted_clause_id;
    Digest256 support_clause_digest;
    Digest256 normalized_metric_request_digest;
    std::shared_ptr<const ConditionalSamplingRewardV1> decoder;
  };
  std::vector<ConditionalRewardDecoderBindingV1>
      conditional_reward_decoders;

  RuntimeFrameworkActivationV1(
      ExactReducedStateSchemaV1 state_schema,
      std::shared_ptr<const ExactCausalProgramV1> program,
      std::shared_ptr<const AuditedFrameworkSeedV1> seed,
      std::shared_ptr<RuntimeDirectMetricActivationV1> direct_activation,
      std::vector<ReducedStateV1> backend_domain_states,
      bool closed_boundary_proven,
      std::optional<SingleConditioningStateBindingV1> conditioning_state,
      std::vector<ConditionalRewardDecoderBindingV1> reward_decoders)
      : exact_state_schema(std::move(state_schema)),
        causal_program(std::move(program)),
        framework_seed(std::move(seed)),
        direct_metric_activation(std::move(direct_activation)),
        finite_backend_domain_states(std::move(backend_domain_states)),
        exact_closed_boundary_proven(closed_boundary_proven),
        single_conditioning_state(std::move(conditioning_state)),
        conditional_reward_decoders(std::move(reward_decoders)) {}
};

using RuntimeFrameworkActivationFactoryV1 =
    std::function<Result<RuntimeFrameworkActivationV1>(
        const RuntimeFrameworkActivationContextV1&)>;

struct FrameworkActivationRegistrationV1 final {
  FrameworkActivationCapabilitiesV1 capabilities;
  RuntimeFrameworkActivationFactoryV1 activate;
};

// Provider-result protocol selection and observation validation are
// process-local registration facts.  SurrogateProviderManifestV1 has no
// result-protocol field and its frozen v1 digest must not be overloaded.
struct ObservationEnvelopeValidationContextV1 final {
  const ResultEnvelopeV2& envelope;
  // Captured before the raw sidecar is moved into semantic validation.  The
  // provider hook must use `observation` below for body/digest access and may
  // not inspect the moved-from optional payload in `envelope`.
  bool observation_was_present;
  ProviderResultKindV2 declared_kind;
  const SurrogateBuildRequest& request;
  const ValidatedSurrogateParameters& parameters;
  const ResolvedInstance& resolved_instance;
  const CompiledArrivalLaw& compiled_arrival_law;
};

using ObservationEnvelopeValidatorV1 =
    std::function<Result<void>(
        const ObservationEnvelopeValidationContextV1&,
        const ValidatedConstructionObservationBundleV1*)>;

// A registration is inert data plus typed callables.  It is consumed only by
// deterministic registry assembly; it is not a dynamic-registration API and
// no global constructor observes it.
struct SurrogateProviderRegistrationV1 final {
  SurrogateProviderManifest manifest;
  ParameterValidatorV1 parameter_validator;
  DescriptorPreviewerV1 previewer;
  ProviderProducerV1 producer;
  RuntimePlugMaterializerV1 materializer;
  // Optional and trailing to keep every released aggregate registration
  // source-compatible.  The callable is retained only in the immutable
  // process-local registry and is never part of a provider manifest or wire
  // artifact.
  std::optional<FrameworkActivationRegistrationV1> framework_activation;
  // Trailing defaults preserve every released aggregate registration.  A v1
  // registration has no observation hook; a v2 registration must provide
  // one even when its authenticated parameters permit emission to be off.
  std::uint32_t result_protocol_version{1U};
  std::optional<ObservationEnvelopeValidatorV1>
      observation_envelope_validator{};
};

class SurrogateProvider final {
 public:
  SurrogateProvider(const SurrogateProvider&) noexcept = default;
  // A provider is an immutable registry handle.  Preserve the shared state in
  // both operands so every public accessor remains valid after a move.
  SurrogateProvider(SurrogateProvider&& other) noexcept
      : state_(other.state_), registry_provenance_(other.registry_provenance_) {}
  SurrogateProvider& operator=(const SurrogateProvider&) noexcept = default;
  SurrogateProvider& operator=(SurrogateProvider&& other) noexcept {
    if (this != &other) {
      state_ = other.state_;
      registry_provenance_ = other.registry_provenance_;
    }
    return *this;
  }

  [[nodiscard]] const ValidatedProviderManifest& manifest() const noexcept;
  [[nodiscard]] const ProviderIdentityV1& identity() const noexcept;
  [[nodiscard]] bool is_default() const noexcept;
  [[nodiscard]] const RegisteredExecutableSpec* registered_executable()
      const noexcept;
  [[nodiscard]] bool has_framework_activation_factory() const noexcept;
  [[nodiscard]] std::optional<FrameworkActivationCapabilitiesV1>
  framework_activation_capabilities() const;
  [[nodiscard]] std::uint32_t result_protocol_version() const noexcept;
 private:
  struct State;
  explicit SurrogateProvider(std::shared_ptr<const State> state,
                             const void* registry_provenance) noexcept
      : state_(std::move(state)),
        registry_provenance_(registry_provenance) {}

  [[nodiscard]] bool is_statically_registered() const noexcept;
  [[nodiscard]] const ParameterValidatorV1& parameter_validator() const
      noexcept;
  [[nodiscard]] const DescriptorPreviewerV1& previewer() const noexcept;
  [[nodiscard]] const ProviderProducerV1& producer() const noexcept;
  [[nodiscard]] const RuntimePlugMaterializerV1& materializer() const noexcept;
  [[nodiscard]] const std::optional<FrameworkActivationRegistrationV1>&
  framework_activation() const noexcept;
  [[nodiscard]] const std::optional<ObservationEnvelopeValidatorV1>&
  observation_envelope_validator() const noexcept;

  std::shared_ptr<const State> state_;
  // Compared against a translation-unit-private address before any provider
  // callback is observed.  An injected registry may exercise assembly and
  // lookup semantics, but cannot mint an executable production handle.
  const void* registry_provenance_{nullptr};

  friend class detail::C16ProviderRegistryMint;
  friend Result<ValidatedSurrogateParameters> validate_surrogate_parameters(
      const SurrogateProvider&, const SourceNode&);
  friend Result<PlugDescriptorPreview> preview_surrogate_descriptor(
      const SurrogateProvider&, const FrameworkProblemView&,
      const MetricRequirements&, const ConstructionBudget&,
      const ValidatedSurrogateParameters&);
  friend ProviderExecutionOutcome execute_surrogate_provider(
      const SurrogateProvider&, const SurrogateBuildRequest&,
      BuildExecutionContext&, const ProviderExecutionControlsV1&);
  friend Result<ValidatedSurrogatePlug>
  materialize_and_validate_surrogate_plug(
      const PortablePlugPayload&, const ValidatedSurrogateArtifact&,
      const AcceptedCapabilityContract&);
  friend Result<ValidatedSurrogateBuildReport>
  validate_surrogate_build_report(const SurrogateBuildResult&,
                                  const SurrogateBuildRequest&,
                                  const ConstructionBudget&);
  friend Result<RuntimeFrameworkActivationV1>
  activate_registered_surrogate_framework(
      const SurrogateProvider&,
      const RuntimeFrameworkActivationContextV1&);
  friend Result<void> validate_registered_observation_envelope(
      const SurrogateProvider&,
      const ObservationEnvelopeValidationContextV1&,
      const ValidatedConstructionObservationBundleV1*);
};

// F-C16-02.
[[nodiscard]] Result<ValidatedSurrogateParameters>
validate_surrogate_parameters(const SurrogateProvider& provider,
                              const SourceNode& parameters);

// F-C16-03.
[[nodiscard]] ProviderExecutionOutcome execute_surrogate_provider(
    const SurrogateProvider& provider, const SurrogateBuildRequest& request,
    BuildExecutionContext& context,
    const ProviderExecutionControlsV1& controls = {});

// C27-only activation boundary.  This function does not materialize a plug,
// audit V0, or execute a backend.  It invokes the optional provider-owned
// recipe only for an immutable statically registered handle and validates
// that the returned carrier matches the exact already-bound identities.
[[nodiscard]] Result<RuntimeFrameworkActivationV1>
activate_registered_surrogate_framework(
    const SurrogateProvider& provider,
    const RuntimeFrameworkActivationContextV1& context);

// Invokes only the immutable process-local hook selected with the provider.
// The pointer is null exactly when provider-result v2 omitted its optional
// observation pair.  The hook validates both presence/absence and every
// provider-private request binding without changing realized capabilities.
[[nodiscard]] Result<void> validate_registered_observation_envelope(
    const SurrogateProvider& provider,
    const ObservationEnvelopeValidationContextV1& context,
    const ValidatedConstructionObservationBundleV1* observation);

}  // namespace mwperf
