#pragma once

#include <compare>
#include <string>
#include <string_view>
#include <utility>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace surrogate_identity_detail {

[[nodiscard]] inline bool is_portable_provider_identifier(
    const std::string_view value) noexcept {
  if (value.empty()) {
    return false;
  }
  const auto ascii_alphanumeric = [](const char character) noexcept {
    return (character >= '0' && character <= '9') ||
           (character >= 'A' && character <= 'Z') ||
           (character >= 'a' && character <= 'z');
  };
  if (!ascii_alphanumeric(value.front())) {
    return false;
  }
  for (const char character : value) {
    if (!ascii_alphanumeric(character) && character != '.' &&
        character != '_' && character != ':' && character != '+' &&
        character != '-') {
      return false;
    }
  }
  return true;
}

[[nodiscard]] inline Diagnostic identity_diagnostic(
    std::string code, std::string message, std::string json_pointer) {
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    std::move(json_pointer),
                    {}};
}

}  // namespace surrogate_identity_detail

// C16 gives the two textual components of C15's ProviderIdentityV1 distinct
// C++ types.  Their accepted spelling is deliberately identical to C15's
// portable provider-identifier grammar.
class SurrogateId final {
 public:
  SurrogateId() = delete;
  SurrogateId(const SurrogateId&) = default;
  // Preserve the validated invariant in both objects.  Moving a std::string
  // directly could leave an empty (therefore invalid) source ID.
  SurrogateId(SurrogateId&& other) : value_(other.value_) {}
  SurrogateId& operator=(const SurrogateId&) = default;
  SurrogateId& operator=(SurrogateId&& other) {
    if (this != &other) {
      value_ = other.value_;
    }
    return *this;
  }

  [[nodiscard]] static Result<SurrogateId> parse(std::string value) {
    if (!surrogate_identity_detail::is_portable_provider_identifier(value)) {
      return Result<SurrogateId>::failure(
          surrogate_identity_detail::identity_diagnostic(
              "c16.invalid_surrogate_id",
              "a surrogate ID must use the closed portable ASCII provider "
              "identifier grammar",
              "/provider/provider_id"));
    }
    return Result<SurrogateId>::success(SurrogateId(std::move(value)));
  }

  [[nodiscard]] const std::string& value() const noexcept { return value_; }

  friend bool operator==(const SurrogateId&, const SurrogateId&) = default;
  friend std::strong_ordering operator<=>(const SurrogateId&,
                                           const SurrogateId&) = default;

 private:
  explicit SurrogateId(std::string value) : value_(std::move(value)) {}

  std::string value_;
};

class SurrogateVersion final {
 public:
  SurrogateVersion() = delete;
  SurrogateVersion(const SurrogateVersion&) = default;
  // As with SurrogateId, a move is value-preserving so no live typed version
  // ever contains an invalid moved-from spelling.
  SurrogateVersion(SurrogateVersion&& other) : value_(other.value_) {}
  SurrogateVersion& operator=(const SurrogateVersion&) = default;
  SurrogateVersion& operator=(SurrogateVersion&& other) {
    if (this != &other) {
      value_ = other.value_;
    }
    return *this;
  }

  [[nodiscard]] static Result<SurrogateVersion> parse(std::string value) {
    if (!surrogate_identity_detail::is_portable_provider_identifier(value)) {
      return Result<SurrogateVersion>::failure(
          surrogate_identity_detail::identity_diagnostic(
              "c16.invalid_surrogate_version",
              "a surrogate version must use the closed portable ASCII "
              "provider identifier grammar",
              "/provider/provider_version"));
    }
    return Result<SurrogateVersion>::success(
        SurrogateVersion(std::move(value)));
  }

  [[nodiscard]] const std::string& value() const noexcept { return value_; }

  friend bool operator==(const SurrogateVersion&,
                         const SurrogateVersion&) = default;
  friend std::strong_ordering operator<=>(const SurrogateVersion&,
                                           const SurrogateVersion&) = default;

 private:
  explicit SurrogateVersion(std::string value) : value_(std::move(value)) {}

  std::string value_;
};

struct SurrogateIdentityV1 final {
  SurrogateId id;
  SurrogateVersion version;

  friend bool operator==(const SurrogateIdentityV1&,
                         const SurrogateIdentityV1&) = default;
  friend std::strong_ordering operator<=>(const SurrogateIdentityV1&,
                                           const SurrogateIdentityV1&) =
      default;
};

[[nodiscard]] inline Result<SurrogateIdentityV1>
surrogate_identity_from_provider_identity_v1(
    const ProviderIdentityV1& identity) {
  auto id = SurrogateId::parse(identity.provider_id);
  if (!id) {
    return Result<SurrogateIdentityV1>::failure(id.error());
  }
  auto version = SurrogateVersion::parse(identity.provider_version);
  if (!version) {
    return Result<SurrogateIdentityV1>::failure(version.error());
  }
  return Result<SurrogateIdentityV1>::success(
      SurrogateIdentityV1{std::move(id).value(),
                          std::move(version).value()});
}

[[nodiscard]] inline ProviderIdentityV1 provider_identity_v1(
    const SurrogateIdentityV1& identity) {
  return ProviderIdentityV1{identity.id.value(), identity.version.value()};
}

[[nodiscard]] inline ProviderIdentityV1 provider_identity_v1(
    const SurrogateId& id, const SurrogateVersion& version) {
  return ProviderIdentityV1{id.value(), version.value()};
}

}  // namespace mwperf
