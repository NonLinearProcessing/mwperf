#pragma once

#include <compare>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/diagnostics/observation_record.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/random/rng_stage.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/finite_prefix_constant_tail_response.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf {

class SurrogateBuildRequest;
class ValidatedProviderManifest;
class ValidatedSurrogateBuildResult;
class FrameworkProblemView;
struct ConstructionBudget;

#if defined(MWPERF_C15_TEST_SEAMS)
namespace testing {
class C15ProtocolFixtureFactory;
}  // namespace testing
#endif

// The body of a registered analytic family or runtime recipe is data, never
// source text or an evaluator.  Names are closed by the selected validated
// manifest; values retain their exact scalar representation on the wire.
using PortableValueV1 =
    std::variant<PortableScientificScalar,
                 std::vector<PortableScientificScalar>>;

struct NamedPortableValueV1 final {
  std::string name;
  PortableValueV1 value;

  friend bool operator==(const NamedPortableValueV1&,
                         const NamedPortableValueV1&) = default;
};

struct PortableDomainV1 final {
  std::string coordinate_name;
  PortableScientificScalar lower;
  PortableScientificScalar upper;
  bool lower_closed;
  bool upper_closed;

  friend bool operator==(const PortableDomainV1&,
                         const PortableDomainV1&) = default;
};

struct FiniteParameterAnalyticDataV1 final {
  std::uint32_t payload_version;
  std::string registered_family_id;
  std::uint32_t registered_family_version;
  std::string parameter_schema_id;
  std::uint32_t parameter_schema_version;
  std::string domain_schema_id;
  std::uint32_t domain_schema_version;
  ProviderIdentityV1 registered_provider;
  std::vector<QueueId> ordered_deployed_targets;
  std::vector<NamedPortableValueV1> parameters;
  std::vector<NamedPortableValueV1> tables;
  std::vector<PortableDomainV1> mathematical_domain;
  std::vector<StateFieldDescriptorV1> state_and_phase_binding;
  std::vector<ArtifactObjectReferenceV1> transform_or_response_identities;

  friend bool operator==(const FiniteParameterAnalyticDataV1&,
                         const FiniteParameterAnalyticDataV1&) = default;
};

struct PortableFiniteDictionaryEntryV1 final {
  TypedLabel id;
  // Coordinates follow descriptor-field order.  For a coupled common-schedule
  // table, the unique target_backlog state field (and unique
  // actual_departure mark field) expands pointwise to one scalar for each
  // ordered_deployed_targets entry, in that exact target order.  The stable
  // identity of such an element is therefore (field kind, target QueueId);
  // every other descriptor field contributes exactly one scalar.
  std::vector<PortableScientificScalar> coordinates;

  friend bool operator==(const PortableFiniteDictionaryEntryV1&,
                         const PortableFiniteDictionaryEntryV1&) = default;
};

enum class FiniteTableStorageV1 : std::uint8_t {
  dense,
  sparse,
};

enum class FiniteRowConditioningStageV1 : std::uint8_t {
  stationary_edge,
  prearrival,
  postarrival,
  one_slot_current,
  stopped_continuation,
  residence_continuation,
  common_schedule,
};

struct CommonScheduleRealizationV1 final {
  std::vector<QueueId> selected_full_schedule;
  std::vector<BigNat> selected_schedule_backlogs;
  std::vector<BigNat> current_target_backlogs;
  std::vector<BigNat> retained_target_backlogs;
  std::vector<std::uint8_t> joint_target_departures;
  bool structurally_witnessed_projection;
  std::optional<ArtifactObjectReferenceV1> projection_witness;

  friend bool operator==(const CommonScheduleRealizationV1&,
                         const CommonScheduleRealizationV1&) = default;
};

struct FiniteLawAtomV1 final {
  TypedLabel successor_state_id;
  std::vector<TypedLabel> ordered_mark_ids;
  PortableScientificScalar probability;
  std::optional<CommonScheduleRealizationV1> common_schedule;

  friend bool operator==(const FiniteLawAtomV1&,
                         const FiniteLawAtomV1&) = default;
};

struct FiniteLawRowV1 final {
  TypedLabel row_id;
  TypedLabel conditioning_state_id;
  FiniteRowConditioningStageV1 conditioning_stage;
  std::vector<FiniteLawAtomV1> atoms;

  friend bool operator==(const FiniteLawRowV1&,
                         const FiniteLawRowV1&) = default;
};

struct ExplicitOrderedWordV1 final {
  TypedLabel entrance_state_id;
  BigNat duration;
  std::vector<TypedLabel> ordered_mark_ids;
  TypedLabel terminal_id;
  TypedLabel successor_entry_id;
  PortableScientificScalar probability;

  friend bool operator==(const ExplicitOrderedWordV1&,
                         const ExplicitOrderedWordV1&) = default;
};

struct FinitePredictiveStoppingTablesV1 final {
  std::vector<FiniteLawRowV1> continuation_rows;
  std::vector<FiniteLawRowV1> stop_or_event_rows;
  std::vector<FiniteLawRowV1> terminal_or_exit_rows;

  friend bool operator==(const FinitePredictiveStoppingTablesV1&,
                         const FinitePredictiveStoppingTablesV1&) = default;
};

struct StationaryMarkedEdgeTableV1 final {
  std::uint32_t table_schema_version;
  ArtifactObjectReferenceV1 law_id;
  FiniteTableStorageV1 storage;
  std::vector<FiniteLawRowV1> joint_edge_rows;
  CodecIdentityV1 target_backlog_codec;
  CodecIdentityV1 exact_input_phase_codec;
  CodecIdentityV1 actual_departure_mark_codec;
  CodecIdentityV1 retained_mark_codec;
  Digest256 conditioning_binding;

  friend bool operator==(const StationaryMarkedEdgeTableV1&,
                         const StationaryMarkedEdgeTableV1&) = default;
};

struct StagedOpportunityFluxTableV1 final {
  std::uint32_t table_schema_version;
  ArtifactObjectReferenceV1 law_id;
  FiniteTableStorageV1 storage;
  std::vector<TypedLabel> prearrival_state_domain;
  std::vector<TypedLabel> postarrival_state_domain;
  std::vector<FiniteLawRowV1> opportunity_rows;
  std::vector<FiniteLawRowV1> successor_mark_rows;
  Digest256 configured_arrival_reference;
  // V1 appends exactly one fresh configured-arrival innovation coordinate to
  // each postarrival state.  Prearrival states have the common base arity N;
  // postarrival states have arity N+1, with this codec governing the final
  // coordinate.  This makes the causal pre/post split mechanically decidable.
  CodecIdentityV1 configured_innovation_codec;
  ArtifactObjectReferenceV1 deterministic_update_descriptor;
  ArtifactObjectReferenceV1 retained_coordinate_descriptor;
  std::vector<MetricRevealStageV1> reveal_order;

  friend bool operator==(const StagedOpportunityFluxTableV1&,
                         const StagedOpportunityFluxTableV1&) = default;
};

struct TemporalContinuationTableV1 final {
  std::uint32_t table_schema_version;
  ArtifactObjectReferenceV1 law_id;
  FiniteTableStorageV1 storage;
  std::vector<FiniteLawRowV1> continuation_rows;
  std::vector<MetricRevealStageV1> causal_reveal_order;
  CodecIdentityV1 arrival_phase_codec;
  std::optional<CodecIdentityV1> controller_coordinate_codec;

  friend bool operator==(const TemporalContinuationTableV1&,
                         const TemporalContinuationTableV1&) = default;
};

struct StoppedPathTableV1 final {
  std::uint32_t table_schema_version;
  ArtifactObjectReferenceV1 law_id;
  std::string stop_rule_id;
  std::vector<TypedLabel> entrance_state_domain;
  std::vector<TypedLabel> stopped_state_domain;
  std::vector<TypedLabel> stopped_mark_domain;
  bool accepted_defective_hitting_law;
  std::variant<std::vector<ExplicitOrderedWordV1>,
               FinitePredictiveStoppingTablesV1>
      representation;
  PortableScientificScalar nonhit_or_nontermination_probability;
  std::vector<ArtifactObjectReferenceV1> completion_absorption_tail_evidence;

  friend bool operator==(const StoppedPathTableV1&,
                         const StoppedPathTableV1&) = default;
};

struct RomrResidenceWordTableV1 final {
  std::uint32_t table_schema_version;
  ArtifactObjectReferenceV1 law_id;
  std::string event_rule_id;
  std::vector<TypedLabel> entrance_state_domain;
  std::vector<TypedLabel> residence_state_domain;
  std::vector<TypedLabel> residence_mark_domain;
  std::variant<std::vector<ExplicitOrderedWordV1>,
               FinitePredictiveStoppingTablesV1>
      representation;
  PortableScientificScalar nontermination_probability;
  std::vector<ArtifactObjectReferenceV1> complete_mass_termination_evidence;

  friend bool operator==(const RomrResidenceWordTableV1&,
                         const RomrResidenceWordTableV1&) = default;
};

struct CoupledCommonScheduleTableV1 final {
  std::uint32_t table_schema_version;
  ArtifactObjectReferenceV1 law_id;
  FiniteTableStorageV1 storage;
  std::vector<FiniteLawRowV1> common_joint_rows;
  Digest256 constraint_geometry_digest;
  Digest256 tie_phase_arrival_binding;

  friend bool operator==(const CoupledCommonScheduleTableV1&,
                         const CoupledCommonScheduleTableV1&) = default;
};

using FiniteLawTableAlternativeV1 =
    std::variant<StationaryMarkedEdgeTableV1,
                 StagedOpportunityFluxTableV1,
                 TemporalContinuationTableV1, StoppedPathTableV1,
                 RomrResidenceWordTableV1, CoupledCommonScheduleTableV1>;

struct FiniteLawTablesV1 final {
  std::uint32_t payload_version;
  std::vector<QueueId> ordered_deployed_targets;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  Digest256 configured_arrival_binding;
  Digest256 selection_binding;
  std::vector<PortableFiniteDictionaryEntryV1> state_dictionary;
  std::vector<PortableFiniteDictionaryEntryV1> mark_dictionary;
  FiniteLawTableAlternativeV1 table;

  friend bool operator==(const FiniteLawTablesV1&,
                         const FiniteLawTablesV1&) = default;
};

struct RegisteredRuntimeRecipeV1 final {
  std::uint32_t payload_version;
  std::string registered_recipe_id;
  std::uint32_t registered_recipe_version;
  std::string parameter_schema_id;
  std::uint32_t parameter_schema_version;
  std::string state_codec_schema_id;
  std::uint32_t state_codec_schema_version;
  std::string mark_codec_schema_id;
  std::uint32_t mark_codec_schema_version;
  ProviderIdentityV1 registered_provider;
  std::vector<QueueId> ordered_deployed_targets;
  std::vector<NamedPortableValueV1> parameters;
  std::vector<StateFieldDescriptorV1> state_codecs;
  std::vector<MarkDescriptorV1> mark_codecs;

  friend bool operator==(const RegisteredRuntimeRecipeV1&,
                         const RegisteredRuntimeRecipeV1&) = default;
};

struct FamilyEvidenceEnvelopeV1 final {
  std::uint32_t envelope_version;
  ArtifactObjectReferenceV1 evidence_id;
  std::string family_evidence_schema_id;
  std::uint32_t family_evidence_schema_version;
  ProviderConformanceReportRef provider_conformance_report_ref;
  ProviderIdentityV1 provider;
  Digest256 provider_scientific_contract_digest;
  Digest256 request_digest;
  Digest256 payload_digest;
  std::vector<ArtifactObjectReferenceV1> subject_references;
  std::vector<ArtifactObjectReferenceV1> parent_references;
  std::vector<QueueId> construction_target_scope;
  MetricEvidenceScopeV1 evidence_scope_tag;
  std::vector<std::byte> canonical_family_body;
  Digest256 canonical_family_body_digest;

  friend bool operator==(const FamilyEvidenceEnvelopeV1&,
                         const FamilyEvidenceEnvelopeV1&) = default;
};

struct ResponseEnvelopeEvidenceV1 final {
  std::uint32_t payload_version;
  std::vector<QueueId> ordered_deployed_targets;
  MetricResultScopeV1 result_scope;
  MetricEvidenceScopeV1 evidence_scope;
  // Complete product ledgers are retained on both sides.  Typed IDs alone
  // would be dangling because this payload has no ambient response ledger.
  ThreeBinScalarResponseV1 lower_response;
  ThreeBinScalarResponseV1 upper_response;
  DeployedResponseProductIdV1 lower_response_product;
  DeployedResponseProductIdV1 upper_response_product;
  ArtifactObjectReferenceV1 comparison_domain_id;
  std::vector<ArtifactObjectReferenceV1> typed_evidence_components;
  bool authorizes_point_product;
  std::optional<DeployedResponseProductIdV1> authorized_point_product;

  friend bool operator==(const ResponseEnvelopeEvidenceV1&,
                         const ResponseEnvelopeEvidenceV1&) = default;
};

enum class DirectMetricValidityBasisV1 : std::uint8_t {
  exact_closed_form,
  exact_finite_enumeration,
  certified_bound,
};

struct DirectMetricValueV1 final {
  ArtifactObjectReferenceV1 value_id;
  MetricClauseIdV1 metric_clause_id;
  std::vector<QueueId> ordered_targets;
  PortableValueV1 value;
  Digest256 request_digest;
  Digest256 normalized_metric_request_digest;
  Digest256 target_selection_digest;
  Digest256 configured_arrival_digest;
  Digest256 accepted_contract_digest;
  std::vector<SelectionKindV1> selection_assumptions;
  std::vector<ArrivalAssumptionV1> arrival_assumptions;
  MetricResultScopeV1 result_scope;
  DirectMetricValidityBasisV1 validity_basis;
  std::vector<ArtifactObjectReferenceV1> evidence_ids;

  friend bool operator==(const DirectMetricValueV1&,
                         const DirectMetricValueV1&) = default;
};

struct DirectMetricPayloadV1 final {
  std::uint32_t payload_version;
  std::vector<DirectMetricValueV1> values;

  friend bool operator==(const DirectMetricPayloadV1&,
                         const DirectMetricPayloadV1&) = default;
};

using ArtifactPayloadV1 =
    std::variant<ThreeBinScalarResponseV1,
                 FiniteParameterAnalyticDataV1, FiniteLawTablesV1,
                 RegisteredRuntimeRecipeV1, ResponseEnvelopeEvidenceV1,
                 DirectMetricPayloadV1,
                 FinitePrefixConstantTailResponseV1>;
using ArtifactPayload = ArtifactPayloadV1;

[[nodiscard]] PayloadClassV1 artifact_payload_class_v1(
    const ArtifactPayloadV1& payload) noexcept;

struct MetricSupportManifestEchoV1 final {
  std::uint32_t schema_version;
  std::vector<std::byte> canonical_manifest_bytes;
  Digest256 manifest_digest;

  friend bool operator==(const MetricSupportManifestEchoV1&,
                         const MetricSupportManifestEchoV1&) = default;
};

struct BoundRealizedMetricBindingsV1 final {
  Digest256 request_digest;
  Digest256 payload_digest;
  // Raw, untrusted wire entries.  F-C15-06 invokes C14's sole validator with
  // the accepted manifest and frozen target/policy context; F-C15-04 cannot
  // manufacture C14's nonconstructible validated carrier while parsing.
  std::vector<RealizedMetricBindingV1> bindings;

  friend bool operator==(const BoundRealizedMetricBindingsV1&,
                         const BoundRealizedMetricBindingsV1&) = default;
};

struct ScopedArtifactEvidenceV1 final {
  ArtifactObjectReferenceV1 evidence_id;
  ArtifactReferenceKindV1 reference_kind;
  std::vector<QueueId> ordered_targets;
  MetricResultScopeV1 result_scope;
  MetricEvidenceScopeV1 evidence_scope;
  std::vector<ArtifactObjectReferenceV1> subject_references;
  std::vector<ArtifactObjectReferenceV1> parent_references;
  std::vector<ArtifactObjectReferenceV1> family_envelope_ids;
  // An independent, purpose-tagged ledger for every C14 internal relation
  // realized by this evidence object.  F-C15-06 compares this ledger exactly
  // with the selected role alternative instead of accepting a coincidental
  // object-id match elsewhere in the artifact.
  std::vector<RealizedInternalReferenceV1> internal_references;

  friend bool operator==(const ScopedArtifactEvidenceV1&,
                         const ScopedArtifactEvidenceV1&) = default;
};

struct ArtifactComponentDigestV1 final {
  std::string component_name;
  Digest256 component_digest;

  friend bool operator==(const ArtifactComponentDigestV1&,
                         const ArtifactComponentDigestV1&) = default;
};

struct SeedStreamCountV1 final {
  StageTag stage;
  TypedLabel stream_instance_id;
  BigNat draw_count;

  friend bool operator==(const SeedStreamCountV1&,
                         const SeedStreamCountV1&) = default;
};

struct ArtifactProvenanceV1 final {
  std::optional<std::string> source_document_id;
  std::optional<std::string> source_revision_id;
  std::optional<Digest256> provider_source_digest;
  std::optional<Digest256> provider_build_digest;
  std::optional<std::string> compiler_identity;
  std::vector<ArtifactComponentDigestV1> component_digests;
  std::vector<std::string> method_decisions;
  std::vector<SeedStreamCountV1> seed_stream_counts;
  std::optional<TypedLabel> frozen_input_bank_id;
  std::optional<TypedLabel> proposal_id;
  std::optional<TypedLabel> final_evaluation_id;

  friend bool operator==(const ArtifactProvenanceV1&,
                         const ArtifactProvenanceV1&) = default;
};

enum class WorkCounterApplicabilityV1 : std::uint8_t {
  not_applicable,
  applicable,
};

struct CommonWorkCounterV1 final {
  WorkCounterApplicabilityV1 applicability;
  BigNat used;

  friend bool operator==(const CommonWorkCounterV1&,
                         const CommonWorkCounterV1&) = default;
};

struct CommonBuildReportV1 final {
  std::uint32_t report_schema_version;
  TypedLabel report_id;
  Digest256 report_digest;
  Digest256 request_digest;
  Digest256 construction_budget_digest;
  CommonWorkCounterV1 optimizer_calls;
  CommonWorkCounterV1 optimizer_search_states;
  CommonWorkCounterV1 configured_generator_draws;
  std::vector<ArtifactComponentDigestV1> optional_component_digests;
  std::vector<NamedPortableValueV1> optional_method_counters;

  friend bool operator==(const CommonBuildReportV1&,
                         const CommonBuildReportV1&) = default;
};

// Diagnostics are observations, not capability or evidence claims.  The
// closed scope prevents (for example) a solver residual from being presented
// as a physical-fidelity statement merely by changing free text.
enum class ArtifactDiagnosticScopeV1 : std::uint8_t {
  construction_integration,
  input_bank_initialization,
  optimizer_certification,
  coefficient_sampling,
  compression,
  projection,
  recoding,
  solver,
  physical_fidelity,
};

struct ArtifactDiagnosticComponentV1 final {
  std::uint32_t diagnostic_schema_version;
  TypedLabel diagnostic_id;
  ArtifactDiagnosticScopeV1 scope;
  std::string code;
  std::string message;
  std::vector<ArtifactObjectReferenceV1> subject_references;
  std::vector<ArtifactObjectReferenceV1> evidence_references;

  friend bool operator==(const ArtifactDiagnosticComponentV1&,
                         const ArtifactDiagnosticComponentV1&) = default;
};

struct SurrogateArtifactV1 final {
  std::uint32_t artifact_protocol_version;
  Digest256 request_digest;
  ProviderIdentityV1 provider;
  Digest256 provider_scientific_contract_digest;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  SemanticTagV1 deployed_semantic;
  RuntimeAccessTagV1 runtime_access;
  PayloadClassV1 payload_class;
  ArtifactObjectReferenceV1 payload_identity;
  ArtifactPayloadV1 payload;
  Digest256 payload_digest;
  MetricSupportManifestEchoV1 structural_manifest_echo;
  BoundRealizedMetricBindingsV1 realized_metric_bindings;
  PlugDescriptorCore deployed_descriptor;
  CommonBuildReportV1 build_report_echo;
  std::vector<FamilyEvidenceEnvelopeV1> family_evidence;
  std::vector<ScopedArtifactEvidenceV1> scoped_evidence;
  std::vector<ArtifactDiagnosticComponentV1> diagnostic_components;
  ArtifactProvenanceV1 provenance;

  friend bool operator==(const SurrogateArtifactV1&,
                         const SurrogateArtifactV1&) = default;
};

struct ResultEnvelopeV1 final {
  std::uint32_t protocol_version;
  Digest256 request_digest;
  ProviderIdentityV1 provider;
  CommonBuildReportV1 build_report;

  friend bool operator==(const ResultEnvelopeV1&,
                         const ResultEnvelopeV1&) = default;
};

struct BuiltSurrogateResultV1 final {
  ResultEnvelopeV1 envelope;
  SurrogateArtifactV1 artifact;

  friend bool operator==(const BuiltSurrogateResultV1&,
                         const BuiltSurrogateResultV1&) = default;
};

enum class UnavailableReasonKindV1 : std::uint8_t {
  inapplicable_target_structure,
  coefficient_proved_zero,
  coefficient_unresolved,
  interval_only_without_authorized_point,
  unmet_construction_assumption,
  construction_domain_unavailable,
  required_evidence_unavailable,
  realized_capability_narrower_than_accepted,
};

struct UnavailableReasonV1 final {
  UnavailableReasonKindV1 kind;
  std::string code;
  std::string message;
  std::optional<MetricClauseIdV1> metric_clause_id;
  std::optional<ArtifactObjectReferenceV1> subject;

  friend bool operator==(const UnavailableReasonV1&,
                         const UnavailableReasonV1&) = default;
};

struct StrongestTruthfulAlternativeV1 final {
  std::string description;
  std::optional<PayloadClassV1> payload_class;
  std::optional<MetricResultScopeV1> result_scope;

  friend bool operator==(const StrongestTruthfulAlternativeV1&,
                         const StrongestTruthfulAlternativeV1&) = default;
};

struct UnavailableSurrogateResultV1 final {
  ResultEnvelopeV1 envelope;
  std::vector<UnavailableReasonV1> reasons;
  std::optional<StrongestTruthfulAlternativeV1> strongest_truthful_alternative;

  friend bool operator==(const UnavailableSurrogateResultV1&,
                         const UnavailableSurrogateResultV1&) = default;
};

enum class ProviderFailureKindV1 : std::uint8_t {
  construction_failure,
  resource_exhausted,
  invariant_violation,
  provider_internal_error,
};

struct ProviderFailureV1 final {
  ProviderFailureKindV1 kind;
  std::string code;
  std::string message;

  friend bool operator==(const ProviderFailureV1&,
                         const ProviderFailureV1&) = default;
};

struct FailedSurrogateResultV1 final {
  ResultEnvelopeV1 envelope;
  ProviderFailureV1 failure;

  friend bool operator==(const FailedSurrogateResultV1&,
                         const FailedSurrogateResultV1&) = default;
};

using SurrogateBuildResultV1 =
    std::variant<BuiltSurrogateResultV1, UnavailableSurrogateResultV1,
                 FailedSurrogateResultV1>;
using SurrogateBuildResult = SurrogateBuildResultV1;

// Provider-result protocol v2 is an independent outer transport version.
// It deliberately continues to carry artifact-v1, payload-v1 and common
// build-report-v1 values.  The observation sidecar is descriptive telemetry;
// it is not part of the deployed surrogate artifact and cannot grant a
// realized metric capability.
struct ResultEnvelopeV2 final {
  std::uint32_t protocol_version;
  Digest256 request_digest;
  ProviderIdentityV1 provider;
  CommonBuildReportV1 build_report;
  std::optional<ConstructionObservationEnvelopeV1> observation;

  friend bool operator==(const ResultEnvelopeV2&,
                         const ResultEnvelopeV2&) = default;
};

struct BuiltSurrogateResultV2 final {
  ResultEnvelopeV2 envelope;
  SurrogateArtifactV1 artifact;

  friend bool operator==(const BuiltSurrogateResultV2&,
                         const BuiltSurrogateResultV2&) = default;
};

struct UnavailableSurrogateResultV2 final {
  ResultEnvelopeV2 envelope;
  std::vector<UnavailableReasonV1> reasons;
  std::optional<StrongestTruthfulAlternativeV1> strongest_truthful_alternative;

  friend bool operator==(const UnavailableSurrogateResultV2&,
                         const UnavailableSurrogateResultV2&) = default;
};

struct FailedSurrogateResultV2 final {
  ResultEnvelopeV2 envelope;
  ProviderFailureV1 failure;

  friend bool operator==(const FailedSurrogateResultV2&,
                         const FailedSurrogateResultV2&) = default;
};

using SurrogateBuildResultV2 =
    std::variant<BuiltSurrogateResultV2, UnavailableSurrogateResultV2,
                 FailedSurrogateResultV2>;

enum class ProviderResultKindV2 : std::uint8_t {
  built,
  unavailable,
  failed,
  // Used only by the additive provider-result-v3 codec.  The v2 parser keeps
  // its released three-tag vocabulary closed and can never produce this
  // value.
  observed,
};

// The staged parser owns the syntactically decoded common envelope
// independently of the branch.  Its raw observation must still pass the
// separate semantic validator before it is trusted or retained.  A failure
// here is a branch-decode failure, not an outer JSON or common-envelope
// failure.
struct BuiltSurrogateResultBodyV2 final {
  SurrogateArtifactV1 artifact;
  friend bool operator==(const BuiltSurrogateResultBodyV2&,
                         const BuiltSurrogateResultBodyV2&) = default;
};
struct UnavailableSurrogateResultBodyV2 final {
  std::vector<UnavailableReasonV1> reasons;
  std::optional<StrongestTruthfulAlternativeV1> strongest_truthful_alternative;
  friend bool operator==(const UnavailableSurrogateResultBodyV2&,
                         const UnavailableSurrogateResultBodyV2&) = default;
};
struct FailedSurrogateResultBodyV2 final {
  ProviderFailureV1 failure;
  friend bool operator==(const FailedSurrogateResultBodyV2&,
                         const FailedSurrogateResultBodyV2&) = default;
};
using SurrogateBuildResultBranchV2 =
    std::variant<BuiltSurrogateResultBodyV2,
                 UnavailableSurrogateResultBodyV2,
                 FailedSurrogateResultBodyV2>;

struct SurrogateResultBranchDecodeFailureV2 final {
  Diagnostic diagnostic;
};

using SurrogateResultBranchDecodeOutcomeV2 =
    std::variant<SurrogateBuildResultBranchV2,
                 SurrogateResultBranchDecodeFailureV2>;

struct ParsedSurrogateResultFrameV2 final {
  ResultEnvelopeV2 envelope;
  ProviderResultKindV2 declared_kind;
  SurrogateResultBranchDecodeOutcomeV2 branch_decode_outcome;
};

// Provider-result v3 reuses the independently authenticated observation
// envelope introduced by v2 but adds an observation-only success terminal.
// It carries no SurrogateArtifactV1: an empirical finite-window record is not
// silently promoted to a deployable stationary tail.
using ResultEnvelopeV3 = ResultEnvelopeV2;

struct ObservedSurrogateResultBodyV3 final {
  friend bool operator==(const ObservedSurrogateResultBodyV3&,
                         const ObservedSurrogateResultBodyV3&) = default;
};
using SurrogateBuildResultBranchV3 =
    std::variant<ObservedSurrogateResultBodyV3,
                 UnavailableSurrogateResultBodyV2,
                 FailedSurrogateResultBodyV2>;

struct SurrogateResultBranchDecodeFailureV3 final {
  Diagnostic diagnostic;
};
using SurrogateResultBranchDecodeOutcomeV3 =
    std::variant<SurrogateBuildResultBranchV3,
                 SurrogateResultBranchDecodeFailureV3>;

struct ParsedSurrogateResultFrameV3 final {
  ResultEnvelopeV3 envelope;
  ProviderResultKindV2 declared_kind;
  SurrogateResultBranchDecodeOutcomeV3 branch_decode_outcome;
};

class ValidatedSurrogateBuildReport final {
 public:
  ValidatedSurrogateBuildReport(const ValidatedSurrogateBuildReport&) =
      default;
  ValidatedSurrogateBuildReport(ValidatedSurrogateBuildReport&&) noexcept =
      default;
  ValidatedSurrogateBuildReport& operator=(
      const ValidatedSurrogateBuildReport&) = default;
  ValidatedSurrogateBuildReport& operator=(
      ValidatedSurrogateBuildReport&&) noexcept = default;

  [[nodiscard]] const CommonBuildReportV1& value() const noexcept {
    return value_;
  }

 private:
  explicit ValidatedSurrogateBuildReport(CommonBuildReportV1 value)
      : value_(std::move(value)) {}

  CommonBuildReportV1 value_;

  friend Result<ValidatedSurrogateBuildReport>
  validate_surrogate_build_report(
      const SurrogateBuildResult&, const SurrogateBuildRequest&,
      const ConstructionBudget&);
  friend Result<ValidatedSurrogateBuildReport>
  validate_surrogate_build_report_v2(
      const ResultEnvelopeV2&, ProviderResultKindV2,
      const SurrogateBuildRequest&, const ConstructionBudget&);
  friend Result<ValidatedSurrogateBuildReport>
  validate_surrogate_build_report_v3(
      const ResultEnvelopeV3&, ProviderResultKindV2,
      const SurrogateBuildRequest&, const ConstructionBudget&);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

// F-C16-10 is the sole production issuer.  The C15 validation routine below
// remains the shared authority for common report shape and budget accounting.
[[nodiscard]] Result<ValidatedSurrogateBuildReport>
validate_surrogate_build_report(const SurrogateBuildResult&,
                                const SurrogateBuildRequest&,
                                const ConstructionBudget&);

[[nodiscard]] Result<ValidatedSurrogateBuildReport>
validate_surrogate_build_report_v2(const ResultEnvelopeV2&,
                                   ProviderResultKindV2,
                                   const SurrogateBuildRequest&,
                                   const ConstructionBudget&);

[[nodiscard]] Result<ValidatedSurrogateBuildReport>
validate_surrogate_build_report_v3(const ResultEnvelopeV3&,
                                   ProviderResultKindV2,
                                   const SurrogateBuildRequest&,
                                   const ConstructionBudget&);

namespace artifact::detail {

[[nodiscard]] Result<void> validate_common_build_report_v1(
    const CommonBuildReportV1&, const SurrogateBuildRequest&);

}  // namespace artifact::detail

using ByteSpan = std::span<const std::byte>;

struct ArtifactParseLimits final {
  std::size_t maximum_bytes;
  std::size_t maximum_nesting_depth;
  std::size_t maximum_object_entries;
  std::size_t maximum_array_entries;
  std::size_t maximum_string_bytes;
  std::size_t maximum_scalar_count;
  std::size_t maximum_total_decoded_allocation_bytes;

  friend bool operator==(const ArtifactParseLimits&,
                         const ArtifactParseLimits&) = default;
};

// F-C15-04 is implemented by the bounded parser translation unit.
[[nodiscard]] Result<SurrogateBuildResult> parse_surrogate_build_result(
    ByteSpan bytes, const ArtifactParseLimits& limits);

// Provider-result v2 parsing is deliberately staged.  Failure of this outer
// Result means no observation may be trusted.  A malformed branch is instead
// represented by `SurrogateResultBranchDecodeFailureV2` inside the returned
// frame so the already decoded common envelope remains available.
[[nodiscard]] Result<ParsedSurrogateResultFrameV2>
parse_surrogate_build_result_v2(
    ByteSpan bytes, const ArtifactParseLimits& artifact_limits,
    const ObservationParseLimitsV1& observation_limits);

[[nodiscard]] Result<ParsedSurrogateResultFrameV3>
parse_surrogate_build_result_v3(
    ByteSpan bytes, const ArtifactParseLimits& artifact_limits,
    const ObservationParseLimitsV1& observation_limits);

[[nodiscard]] Result<SurrogateBuildResultV2>
assemble_surrogate_build_result_v2(ParsedSurrogateResultFrameV2 frame);

namespace artifact::detail {

// F-C15-04 is the sole production issuer.  Nested private wire helpers may
// use the public instance methods only while F-C15-04 passes this
// unconstructible token through the decode call graph.
class PayloadWireAccess final {
 public:
  [[nodiscard]] RawResponseProductId raw_product_id(
      ArtifactObjectReferenceV1 identity) const {
    return RawResponseProductId(std::move(identity));
  }
  [[nodiscard]] NominalResponseProductId nominal_product_id(
      ArtifactObjectReferenceV1 identity) const {
    return NominalResponseProductId(std::move(identity));
  }
  [[nodiscard]] ProjectionCenterProductId projection_center_product_id(
      ArtifactObjectReferenceV1 identity) const {
    return ProjectionCenterProductId(std::move(identity));
  }
  [[nodiscard]] ProjectedMeanProductId projected_mean_product_id(
      ArtifactObjectReferenceV1 identity) const {
    return ProjectedMeanProductId(std::move(identity));
  }
  [[nodiscard]] RecodedResponseProductId recoded_product_id(
      ArtifactObjectReferenceV1 identity) const {
    return RecodedResponseProductId(std::move(identity));
  }

 private:
  PayloadWireAccess() = default;

  friend Result<SurrogateBuildResult> mwperf::parse_surrogate_build_result(
      ByteSpan, const ArtifactParseLimits&);
  friend Result<ParsedSurrogateResultFrameV2>
  mwperf::parse_surrogate_build_result_v2(
      ByteSpan, const ArtifactParseLimits&,
      const ObservationParseLimitsV1&);
};

}  // namespace artifact::detail

// Immutable lineage retained by the validated artifact carrier.  C15 has
// already proved every member against the request and accepted contract;
// C16 can therefore materialize a plug without reconstructing or weakening
// those bindings from the portable artifact alone.
struct ArtifactValidationBindingsV1 final {
  Digest256 build_identity_digest;
  Digest256 request_digest;
  ProviderIdentityV1 provider;
  std::uint32_t parameter_schema_version;
  Digest256 provider_scientific_contract_digest;
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  PayloadClassV1 payload_class;
  Digest256 framework_problem_view_digest;
  Digest256 analysis_selection_digest;
  Digest256 accepted_contract_digest;
  Digest256 requirements_digest;
  Digest256 arrival_capabilities_digest;
  Digest256 preview_digest;
  Digest256 parameter_digest;
  Digest256 budget_digest;
  Digest256 structural_manifest_digest;

  friend bool operator==(const ArtifactValidationBindingsV1&,
                         const ArtifactValidationBindingsV1&) = default;
};

class ValidatedSurrogateArtifact final {
 public:
  ValidatedSurrogateArtifact(const ValidatedSurrogateArtifact&) = default;
  ValidatedSurrogateArtifact(ValidatedSurrogateArtifact&&) noexcept = default;
  ValidatedSurrogateArtifact& operator=(const ValidatedSurrogateArtifact&) =
      default;
  ValidatedSurrogateArtifact& operator=(ValidatedSurrogateArtifact&&) noexcept =
      default;

  [[nodiscard]] const SurrogateArtifactV1& value() const noexcept {
    return value_;
  }
  [[nodiscard]] const ArtifactValidationBindingsV1& validation_bindings()
      const noexcept {
    return validation_bindings_;
  }

 private:
  ValidatedSurrogateArtifact(SurrogateArtifactV1 value,
                             ArtifactValidationBindingsV1 validation_bindings)
      : value_(std::move(value)),
        validation_bindings_(std::move(validation_bindings)) {}

  SurrogateArtifactV1 value_;
  ArtifactValidationBindingsV1 validation_bindings_;

  friend Result<ValidatedSurrogateBuildResult>
  validate_surrogate_build_result(
      const SurrogateBuildResult&, const SurrogateBuildRequest&,
      const ValidatedProviderManifest&, const AcceptedCapabilityContract&,
      const ValidatedSurrogateBuildReport&);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

struct RealizedBuiltCapabilitiesV1 final {
  ValidatedSurrogateArtifact artifact;
  std::vector<MetricClauseIdV1> satisfied_clauses;
};
struct RealizedUnavailableCapabilitiesV1 final {
  std::vector<UnavailableReasonV1> reasons;
};
struct RealizedFailedCapabilitiesV1 final {
  ProviderFailureV1 failure;
};
using RealizedCapabilityReport =
    std::variant<RealizedBuiltCapabilitiesV1,
                 RealizedUnavailableCapabilitiesV1,
                 RealizedFailedCapabilitiesV1>;

class ValidatedBuiltResultV1 final {
 public:
  ValidatedBuiltResultV1(const ValidatedBuiltResultV1&) = default;
  ValidatedBuiltResultV1(ValidatedBuiltResultV1&&) noexcept = default;
  ValidatedBuiltResultV1& operator=(const ValidatedBuiltResultV1&) = default;
  ValidatedBuiltResultV1& operator=(ValidatedBuiltResultV1&&) noexcept =
      default;

 private:
  explicit ValidatedBuiltResultV1(ValidatedSurrogateArtifact artifact)
      : artifact_(std::move(artifact)) {}

  ValidatedSurrogateArtifact artifact_;

  friend Result<ValidatedSurrogateBuildResult>
  validate_surrogate_build_result(
      const SurrogateBuildResult&, const SurrogateBuildRequest&,
      const ValidatedProviderManifest&, const AcceptedCapabilityContract&,
      const ValidatedSurrogateBuildReport&);
  friend RealizedCapabilityReport resolve_realized_metric_capabilities(
      const ValidatedSurrogateBuildResult&, const MetricRequirements&);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};
struct ValidatedUnavailableResultV1 final {
  UnavailableSurrogateResultV1 result;
};
struct ValidatedFailedResultV1 final {
  FailedSurrogateResultV1 result;
};

using ValidatedSurrogateBuildResultValueV1 =
    std::variant<ValidatedBuiltResultV1, ValidatedUnavailableResultV1,
                 ValidatedFailedResultV1>;

class ValidatedSurrogateBuildResult final {
 public:
  ValidatedSurrogateBuildResult(const ValidatedSurrogateBuildResult&) =
      default;
  ValidatedSurrogateBuildResult(ValidatedSurrogateBuildResult&&) noexcept =
      default;
  ValidatedSurrogateBuildResult& operator=(
      const ValidatedSurrogateBuildResult&) = default;
  ValidatedSurrogateBuildResult& operator=(
      ValidatedSurrogateBuildResult&&) noexcept = default;

  [[nodiscard]] const ValidatedSurrogateBuildResultValueV1& value() const
      noexcept {
    return value_;
  }
  [[nodiscard]] const MetricRequirements& accepted_requirements() const
      noexcept {
    return accepted_requirements_;
  }

 private:
  explicit ValidatedSurrogateBuildResult(
      ValidatedSurrogateBuildResultValueV1 value,
      MetricRequirements accepted_requirements)
      : value_(std::move(value)),
        accepted_requirements_(std::move(accepted_requirements)) {}

  ValidatedSurrogateBuildResultValueV1 value_;
  MetricRequirements accepted_requirements_;

  friend Result<ValidatedSurrogateBuildResult>
  validate_surrogate_build_result(
      const SurrogateBuildResult&, const SurrogateBuildRequest&,
      const ValidatedProviderManifest&, const AcceptedCapabilityContract&,
      const ValidatedSurrogateBuildReport&);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

[[nodiscard]] Result<std::vector<std::byte>>
canonical_artifact_payload_bytes_v1(const ArtifactPayloadV1& payload);
[[nodiscard]] Result<Digest256> canonical_artifact_payload_digest_v1(
    const ArtifactPayloadV1& payload);
[[nodiscard]] Result<std::vector<std::byte>>
canonical_common_build_report_bytes_v1(const CommonBuildReportV1& report,
                                       bool omit_report_digest = false);
[[nodiscard]] Result<Digest256> canonical_common_build_report_digest_v1(
    const CommonBuildReportV1& report);

class ValidatedMetricSupportManifest final {
 public:
  ValidatedMetricSupportManifest(const ValidatedMetricSupportManifest&) =
      default;
  ValidatedMetricSupportManifest(ValidatedMetricSupportManifest&&) noexcept =
      default;
  ValidatedMetricSupportManifest& operator=(
      const ValidatedMetricSupportManifest&) = default;
  ValidatedMetricSupportManifest& operator=(
      ValidatedMetricSupportManifest&&) noexcept = default;

  [[nodiscard]] const MetricSupportManifest& value() const noexcept {
    return value_;
  }

 private:
  explicit ValidatedMetricSupportManifest(MetricSupportManifest value)
      : value_(std::move(value)) {}

  MetricSupportManifest value_;

  friend Result<ValidatedMetricSupportManifest>
  validate_metric_support_manifest(const MetricSupportManifest&,
                                   const ArtifactPayload&,
                                   const PlugDescriptorCore&);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

// F-C15-05.
[[nodiscard]] Result<ValidatedMetricSupportManifest>
validate_metric_support_manifest(const MetricSupportManifest& manifest,
                                 const ArtifactPayload& payload,
                                 const PlugDescriptorCore& descriptor);

// F-C15-06.
[[nodiscard]] Result<ValidatedSurrogateBuildResult>
validate_surrogate_build_result(
    const SurrogateBuildResult& result, const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateBuildReport& validated_build_report);

// V2 validates only the outer transport and terminal branch.  Artifact and
// payload validation continue to use the exact v1 rules and the returned
// capability carrier intentionally has no observation field.
[[nodiscard]] Result<ValidatedSurrogateBuildResult>
validate_surrogate_build_result_v2(
    const ResultEnvelopeV2& envelope,
    const SurrogateBuildResultBranchV2& branch,
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateBuildReport& validated_build_report);

// Provider-result v3 has no deployable Built branch, but its Unavailable and
// Failed terminals retain the exact released v1 terminal semantics.  This
// boundary deliberately validates only that terminal body; the independently
// authenticated v3 envelope and observation are validated by their dedicated
// boundaries before the branch is consumed.
[[nodiscard]] Result<void> validate_surrogate_build_terminal_v3(
    const SurrogateBuildResultBranchV3& branch,
    const AcceptedCapabilityContract& accepted_contract);

// F-C15-07.
[[nodiscard]] RealizedCapabilityReport resolve_realized_metric_capabilities(
    const ValidatedSurrogateBuildResult& result,
    const MetricRequirements& requirements);

namespace artifact::detail {

// Noncatalog canonical fixture/parser helper.  The bounded parser owns the
// implementation of the complete outer wire codec; payload validation owns
// only the closed nested payload codec in payload_wire.hpp.
[[nodiscard]] Result<std::vector<std::byte>>
canonical_surrogate_build_result_bytes_v1(
    const SurrogateBuildResultV1& result);

[[nodiscard]] Result<std::vector<std::byte>>
canonical_surrogate_build_result_bytes_v2(
    const SurrogateBuildResultV2& result);

// Narrow structural predicate used by F-C15-06 and its five-geometry tests.
// It performs no optimizer call and evaluates only the portable descriptor.
[[nodiscard]] Result<void> validate_common_schedule_realization_v1(
    const CommonScheduleRealizationV1& realization,
    std::span<const QueueId> ordered_targets,
    const FrameworkProblemView& problem_view);

// Exact common-law binding over the problem view's tie/timing, target
// selection and configured-arrival fingerprints.  Finite coupled tables must
// carry this value verbatim.
[[nodiscard]] Result<Digest256> coupled_tie_phase_arrival_binding_v1(
    const FrameworkProblemView& problem_view);

// C15-owned content seals used by F-C15-06 and fixture construction.  Each
// digest omits the object_digest of the record's own identity.  A recursively
// applied late-bound evidence/certificate projection also omits only the
// object_digest (never the object_id) of evidence backlinks; ordinary
// content, context, policy, codec and parent-lineage references remain fully
// bound.  F-C15-06 resolves every supplied full backlink after issuance.
[[nodiscard]] Result<Digest256> coefficient_identification_digest_v1(
    const CoefficientIdentificationV1& identification);
[[nodiscard]] Result<Digest256> raw_response_envelope_digest_v1(
    const RawResponseEnvelopeV1& envelope);
[[nodiscard]] Result<Digest256> finite_law_table_digest_v1(
    const FiniteLawTableAlternativeV1& table);
[[nodiscard]] Result<Digest256> direct_metric_value_digest_v1(
    const DirectMetricValueV1& value);
[[nodiscard]] Result<Digest256> family_evidence_envelope_digest_v1(
    const FamilyEvidenceEnvelopeV1& evidence);
[[nodiscard]] Result<Digest256> scoped_artifact_evidence_digest_v1(
    const ScopedArtifactEvidenceV1& evidence);
[[nodiscard]] Result<Digest256> family_evidence_body_digest_v1(
    std::span<const std::byte> canonical_body);

}  // namespace artifact::detail

}  // namespace mwperf
