#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/reduction/opportunity.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/kernel_access.hpp"
#include "mwperf/surrogate/portable_payload_adapter.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf {

namespace detail {
class C17CoreAccess;
class C20CoreAccess;
}

namespace surrogate::detail {
class SealedRomrOpsAuthority;
}

using RuntimeFieldIdV1 = StrongId<"c16_runtime_field_v1">;
using RuntimeMarkIdV1 = StrongId<"c16_runtime_mark_v1">;
using RuntimeOperationIdV1 = StrongId<"c16_runtime_operation_v1">;

struct RuntimeOperationIdentityV1 final {
  RuntimeOperationIdV1 operation_id;
  std::uint32_t operation_version;

  friend bool operator==(const RuntimeOperationIdentityV1&,
                         const RuntimeOperationIdentityV1&) = default;
};

inline constexpr std::string_view kThreeBinResponseFamilyIdV1 =
    "mwperf.c16.three_bin_scalar_response";
inline constexpr std::string_view kThreeBinResponseParameterSchemaIdV1 =
    "mwperf.c16.three_bin_coefficients";
inline constexpr std::string_view kThreeBinServiceResponseCodecIdV1 =
    "mwperf.c16.three_bin_service_response";
inline constexpr std::string_view
    kFinitePrefixConstantTailResponseFamilyIdV1 =
        "mwperf.c16.finite_prefix_constant_tail_response";
inline constexpr std::string_view
    kFinitePrefixConstantTailResponseParameterSchemaIdV1 =
        "mwperf.c16.finite_prefix_constant_tail_coefficients";
inline constexpr std::string_view
    kFinitePrefixConstantTailServiceResponseCodecIdV1 =
        "mwperf.c16.finite_prefix_constant_tail_service_response";
// C17 supplies all three values.  A plug may consume them only through these
// fixed, lossless ABI codecs; a provider-specific digest or schedule-only
// projection is not a substitute for a complete source record.
inline constexpr std::string_view kC17EmittedOpportunityCodecIdV1 =
    "mwperf.c17.emitted_opportunity";
inline constexpr std::uint32_t kC17EmittedOpportunityCodecVersionV1 = 1U;
inline constexpr std::string_view kC17ResolvedActionCodecIdV1 =
    "mwperf.c17.resolved_action";
inline constexpr std::uint32_t kC17ResolvedActionCodecVersionV1 = 1U;
inline constexpr std::string_view kC17ConfiguredArrivalTransitionCodecIdV1 =
    "mwperf.c17.configured_arrival_transition";
inline constexpr std::uint32_t
    kC17ConfiguredArrivalTransitionCodecVersionV1 = 1U;

enum class RuntimeDomainKindV1 : std::uint8_t {
  finite,
  countable,
  standard_borel_procedural,
};

// C14 owns the canonical field declaration.  C16 adds the stable coordinate
// identity and domain class required by executable operations without
// changing the frozen C14 wire record.
struct RuntimeStateFieldV1 final {
  RuntimeFieldIdV1 id;
  StateFieldDescriptorV1 c14_field;
  RuntimeDomainKindV1 domain;

  friend bool operator==(const RuntimeStateFieldV1&,
                         const RuntimeStateFieldV1&) = default;
};

enum class MarkDecoderSourceV1 : std::uint8_t {
  predecision_state,
  c_minus_joint_output,
  decision_schedule,
  configured_arrival,
  c_plus_joint_output,
  postarrival_state,
  completed_edge,
  entrance_realization,
};

struct RuntimeMarkDependencyV1 final {
  RuntimeMarkIdV1 mark;

  friend bool operator==(const RuntimeMarkDependencyV1&,
                         const RuntimeMarkDependencyV1&) = default;
};

struct RuntimeMarkDescriptorV1 final {
  RuntimeMarkIdV1 id;
  MarkDescriptorV1 c14_mark;
  RuntimeDecoderIdV1 decoder_id;
  MarkDecoderSourceV1 decoder_source;
  RuntimeDomainKindV1 domain;
  CodecIdentityV1 decoder_input_codec;
  std::vector<RuntimeFieldIdV1> field_dependencies;
  std::vector<RuntimeMarkDependencyV1> dependencies;

  friend bool operator==(const RuntimeMarkDescriptorV1&,
                         const RuntimeMarkDescriptorV1&) = default;
};

// C-minus is a read-only view.  It names framework/surrogate coordinates but
// grants no write capability and does not carry the configured arrival
// kernel.
struct CMinusOperationSchemaV1 final {
  RuntimeOperationIdV1 operation_id;
  std::uint32_t schema_version;
  CodecIdentityV1 predecision_state_codec;
  CodecIdentityV1 opportunity_codec;
  std::vector<RuntimeFieldIdV1> read_fields;
  std::vector<RuntimeMarkIdV1> jointly_emitted_marks;

  friend bool operator==(const CMinusOperationSchemaV1&,
                         const CMinusOperationSchemaV1&) = default;
};

// C-plus is deliberately a field-ID whitelist.  Descriptor validation admits
// only C14 surrogate_owned fields, so a valid patch cannot express a write to
// backlog, arrival phase, controller state, resources, or exact margins.
struct CPlusOperationSchemaV1 final {
  RuntimeOperationIdV1 operation_id;
  std::uint32_t schema_version;
  CodecIdentityV1 prearrival_state_codec;
  // Must equal the fixed C17 emitted-opportunity codec above.  It is not the
  // provider's raw C-minus opportunity codec.
  CodecIdentityV1 opportunity_codec;
  CodecIdentityV1 decision_codec;
  CodecIdentityV1 configured_arrival_codec;
  CodecIdentityV1 patch_codec;
  std::vector<RuntimeFieldIdV1> writable_unresolved_fields;
  std::vector<RuntimeMarkIdV1> read_marks;
  std::vector<RuntimeMarkIdV1> jointly_emitted_marks;

  friend bool operator==(const CPlusOperationSchemaV1&,
                         const CPlusOperationSchemaV1&) = default;
};

enum class EventContractKindV1 : std::uint8_t {
  one_slot_continuation,
  romr_residence,
  stopped_path,
};

enum class EventFiltrationV1 : std::uint8_t {
  generated_slot_natural_filtration,
};

struct TemporalEventContractV1 final {
  EventContractKindV1 kind;
  RuntimeOperationIdentityV1 event_generator_operation;
  RuntimeOperationIdentityV1 entry_initializer_operation;
  RuntimeOperationIdentityV1 stopping_indicator_operation;
  RuntimeOperationIdentityV1 terminal_reentry_operation;
  RuntimeOperationIdentityV1 predecision_projection_operation;
  RuntimeOperationIdentityV1 completed_edge_projection_operation;
  EventFiltrationV1 stopping_filtration;
  CodecIdentityV1 continuation_space;
  CodecIdentityV1 entrance_space;
  CodecIdentityV1 terminal_space;
  CodecIdentityV1 reentry_space;
  CodecIdentityV1 stopping_indicator;
  CodecIdentityV1 predecision_projection;
  CodecIdentityV1 completed_edge_projection;
  bool stopping_rule_adapted;
  bool first_stop_strictly_positive;
  bool terminal_reentry_exact;
  bool defective_hitting_law;
  // Canonical truth values for beta.  The codec alone cannot identify which
  // opaque byte string denotes false or true, so C20 binds both encodings as
  // part of the audited event contract.  Defaults preserve the v1 binary
  // convention for existing aggregate initializers.
  std::vector<std::byte> stopping_false_value{std::byte{0x00}};
  std::vector<std::byte> stopping_true_value{std::byte{0x01}};
  // Surrogate-owned coordinates explicitly classified as residence-local.
  // Only these fields may change under entry initialization or terminal
  // re-entry; every unlisted surrogate coordinate is persistent.
  std::vector<RuntimeFieldIdV1> residence_local_reset_fields{};

  friend bool operator==(const TemporalEventContractV1&,
                         const TemporalEventContractV1&) = default;
};

enum class CertificateCategoryV1 : std::uint8_t {
  validity,
  geometry,
  lift,
  fidelity,
  stability,
  error,
  numerics,
  complexity,
  validation,
  provenance,
};

enum class CertificateLevelV1 : std::uint8_t {
  declaration,
  v0_shape,
  v1_witness,
  v2_witness,
};

struct RuntimeCertificateClaimV1 final {
  CertificateCategoryV1 category;
  CertificateLevelV1 level;
  std::optional<CodecIdentityV1> witness_schema;

  friend bool operator==(const RuntimeCertificateClaimV1&,
                         const RuntimeCertificateClaimV1&) = default;
};

// The transition carrier has an aggregate conditioning/successor state
// schema in addition to the coordinate-level state-field declarations.  The
// ordered field list prevents two same-shaped aggregate codecs from being
// cross-bound by merely appearing somewhere in state_fields.
struct TransitionStateSchemaV1 final {
  CodecIdentityV1 conditioning_state_codec;
  CodecIdentityV1 successor_state_codec;
  std::vector<RuntimeFieldIdV1> ordered_fields;

  friend bool operator==(const TransitionStateSchemaV1&,
                         const TransitionStateSchemaV1&) = default;
};

enum class ConfiguredArrivalOwnershipV1 : std::uint8_t {
  framework_external_exactly_once,
};

// Callback-free runtime truth shape layered over the exact, immutable C14
// descriptor core.  The core remains the authority for negotiated semantics;
// these fields make operation and dependency topology mechanically explicit.
struct PlugDescriptor final {
  std::uint32_t schema_version;
  PlugDescriptorCore core;
  std::vector<RuntimeStateFieldV1> state_fields;
  std::optional<CMinusOperationSchemaV1> c_minus;
  std::optional<CPlusOperationSchemaV1> c_plus;
  std::vector<RuntimeMarkDescriptorV1> marks;
  std::optional<TemporalEventContractV1> event_contract;
  ConfiguredArrivalOwnershipV1 configured_arrival_ownership;
  std::vector<RuntimeCertificateClaimV1> certificates;
  std::optional<TransitionStateSchemaV1> transition_state_schema;
  Digest256 descriptor_digest;

  friend bool operator==(const PlugDescriptor&,
                         const PlugDescriptor&) = default;
};

[[nodiscard]] Result<Digest256> canonical_plug_descriptor_digest_v1(
    const PlugDescriptor& descriptor);
[[nodiscard]] Result<void> validate_plug_descriptor_v1(
    const PlugDescriptor& descriptor);

struct RuntimeDecodedMarkV1 final {
  RuntimeMarkIdV1 mark;
  CanonicalRuntimeValueV1 value;

  friend bool operator==(const RuntimeDecodedMarkV1&,
                         const RuntimeDecodedMarkV1&) = default;
};

// A deterministic decoder can observe only the one framework-constructed
// canonical source named by its schema.  It returns one value: C17 supplies
// the fixed mark identity and reveal stage, so the operation cannot append a
// different mark or alter any transition coordinate.
struct DeterministicRuntimeMarkDecoderSchemaV1 final {
  // Exact identity from RuntimeMarkDescriptorV1.  This is deliberately the
  // decoder-ID domain rather than the unrelated runtime-operation domain.
  RuntimeDecoderIdV1 decoder_id;
  RuntimeMarkIdV1 mark;
  MarkDecoderSourceV1 source;
  CodecIdentityV1 input_codec;
  CodecIdentityV1 output_codec;

  friend bool operator==(const DeterministicRuntimeMarkDecoderSchemaV1&,
                         const DeterministicRuntimeMarkDecoderSchemaV1&) =
      default;
};

using DeterministicRuntimeMarkDecoderCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const CanonicalRuntimeValueV1&)>;

class DeterministicRuntimeMarkDecoderOperationV1 final {
 public:
  DeterministicRuntimeMarkDecoderOperationV1(
      DeterministicRuntimeMarkDecoderSchemaV1 schema,
      DeterministicRuntimeMarkDecoderCallbackV1 operation)
      : schema_(std::move(schema)), operation_(std::move(operation)) {}

  [[nodiscard]] const DeterministicRuntimeMarkDecoderSchemaV1& schema()
      const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] DeterministicRuntimeMarkDecoderCallbackV1 fresh_operation()
      const {
    return operation_.fresh_copy();
  }

  DeterministicRuntimeMarkDecoderSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      DeterministicRuntimeMarkDecoderCallbackV1>
      operation_;

  friend class C17AuditedFrameworkMint;
  friend class detail::C17CoreAccess;
  friend class detail::C20CoreAccess;
};

struct CMinusInputV1 final {
  CanonicalRuntimeValueV1 predecision_state;
};

// One atom of the opportunity face seen by the configured resolver.  Queue
// identities are stable across materialization; C17 binds them to the one
// resolved queue catalog, requires canonical catalog order, and constructs
// the full Schedule itself.  target_free_primary_score excludes every
// deployed-target backlog term.  non_target_departures supplies exactly the
// omitted coordinates of D needed by framework-exact resource/margin
// updates.  It is a duplicate-free (therefore binary), canonical queue-ID
// list and must be a target-disjoint subset of the selected schedule.
struct V0ScheduleFaceAtomV1 final {
  std::vector<QueueId> selected_full_schedule;
  std::vector<QueueId> non_target_departures;
  ExactRational target_free_primary_score;

  friend bool operator==(const V0ScheduleFaceAtomV1&,
                         const V0ScheduleFaceAtomV1&) = default;
};

// The finite common face is sufficient for both a singleton threshold and a
// coupled target decision.  F-C17-02 adds the exact target terms, applies
// empty-target eligibility, maximizes exactly, and resolves equality only by
// the configured common priority rule.  Alternative order never resolves a
// tie and duplicate schedules are invalid.
struct V0EmittedOpportunityFaceV1 final {
  std::vector<V0ScheduleFaceAtomV1> alternatives;

  friend bool operator==(const V0EmittedOpportunityFaceV1&,
                         const V0EmittedOpportunityFaceV1&) = default;
};

struct CMinusOutputV1 final {
  CanonicalRuntimeValueV1 opportunity;
  std::vector<RuntimeDecodedMarkV1> jointly_emitted_marks;
  // Required by V0 for every generic bound-operation program.  It remains
  // optional in the raw C16 carrier because the closed ThreeBin adapter does
  // not invoke a provider C-minus operation; F-C17-07 rejects any other
  // missing face before sealing.
  std::optional<V0EmittedOpportunityFaceV1> resolver_face;
  // Optional C13 physical-row evidence only.  V0 may compare it with the
  // emitted face, but never requires or replays it; physical realizability
  // begins at V1.
  std::optional<Opportunity> exact_opportunity_evidence;
};

struct RuntimeFieldPatchV1 final {
  RuntimeFieldIdV1 field;
  CanonicalRuntimeValueV1 value;

  friend bool operator==(const RuntimeFieldPatchV1&,
                         const RuntimeFieldPatchV1&) = default;
};

struct CPlusInputV1 final {
  CanonicalRuntimeValueV1 prearrival_state;
  // The fixed lossless C17 record of the raw provider opportunity
  // (its codec identity and canonical bytes) together with the complete
  // typed V0 resolver face.  Branch provenance, prearrival backlog, decoded
  // marks, and optional C13/V1 corroboration are excluded: those are either
  // supplied separately or cannot alter the V0 C-plus law.
  CanonicalRuntimeValueV1 opportunity;
  // This is the lossless encoding of the complete ResolvedAction (schedule,
  // D, canonical schedule identity, exact face/tie evidence, and controller
  // fields), not a schedule-bit projection.
  CanonicalRuntimeValueV1 decision;
  // The single lossless encoding retained by ArrivalTransition and shared
  // verbatim with configured-arrival mark decoders.  It is never merely the
  // realization digest.
  CanonicalRuntimeValueV1 configured_arrival;
  std::vector<RuntimeDecodedMarkV1> available_marks;
};

struct CPlusOutputV1 final {
  std::vector<RuntimeFieldPatchV1> unresolved_patch;
  std::vector<RuntimeDecodedMarkV1> jointly_emitted_marks;
};

using CMinusCallbackV1 =
    std::function<Result<CMinusOutputV1>(const CMinusInputV1&,
                                         DeterministicRng&)>;
using CPlusCallbackV1 =
    std::function<Result<CPlusOutputV1>(const CPlusInputV1&,
                                        DeterministicRng&)>;

// Optional exact enumerable companions remain owned by the same active C16
// operation as the sampler.  ProbabilityMass is the C16 boundary carrier:
// C17 converts its exact rational or canonical binary64 representation to the
// identical exact rational before its single conditional-row normalization.
struct EnumeratedCMinusAtomV1 final {
  CMinusOutputV1 output;
  ProbabilityMass mass;
};

struct EnumeratedCPlusAtomV1 final {
  CPlusOutputV1 output;
  ProbabilityMass mass;
};

using EnumerateCMinusExactLawV1 = std::function<
    Result<std::vector<EnumeratedCMinusAtomV1>>(const CMinusInputV1&)>;
using EnumerateCPlusExactLawV1 = std::function<
    Result<std::vector<EnumeratedCPlusAtomV1>>(const CPlusInputV1&)>;

// Event projection is allowed to retain an observable prefix, but that prefix
// contains only values already revealed before the current decision.  The
// completed-edge projection below receives this predecision projection and
// the matching current transition together, making it impossible for C17 to
// accidentally splice projections from two different generated slots.
struct EventPredecisionProjectionInputV1 final {
  CanonicalRuntimeValueV1 entrance_state;
  std::vector<GeneratedResidenceSlotV1> completed_prefix;
  CanonicalRuntimeValueV1 current_predecision_state;
};

struct EventCompletedEdgeProjectionInputV1 final {
  CanonicalRuntimeValueV1 predecision_projection;
  KernelTransitionV1 completed_edge;
};

// Equation (12.4d) makes terminal re-entry a function of both the exact
// successor coordinates n' and the raw post-update continuation.  Keeping
// them typed and separate prevents an opaque terminal blob from concealing
// an exact-coordinate reset.
struct EventTerminalReentryInputV1 final {
  CanonicalRuntimeValueV1 successor_state;
  CanonicalRuntimeValueV1 raw_postupdate_continuation;
};

struct EventEntryInitializerSchemaV1 final {
  RuntimeOperationIdentityV1 operation;
  CodecIdentityV1 entrance_codec;
  CodecIdentityV1 continuation_codec;

  friend bool operator==(const EventEntryInitializerSchemaV1&,
                         const EventEntryInitializerSchemaV1&) = default;
};

struct EventStoppingIndicatorSchemaV1 final {
  RuntimeOperationIdentityV1 operation;
  EventFiltrationV1 filtration;
  CodecIdentityV1 raw_postupdate_state_codec;
  CodecIdentityV1 indicator_codec;

  friend bool operator==(const EventStoppingIndicatorSchemaV1&,
                         const EventStoppingIndicatorSchemaV1&) = default;
};

struct EventTerminalReentrySchemaV1 final {
  RuntimeOperationIdentityV1 operation;
  CodecIdentityV1 successor_state_codec;
  CodecIdentityV1 raw_postupdate_continuation_codec;
  CodecIdentityV1 reentry_codec;

  friend bool operator==(const EventTerminalReentrySchemaV1&,
                         const EventTerminalReentrySchemaV1&) = default;
};

struct EventPredecisionProjectionSchemaV1 final {
  RuntimeOperationIdentityV1 operation;
  CodecIdentityV1 entrance_codec;
  CodecIdentityV1 continuation_codec;
  CodecIdentityV1 projection_codec;

  friend bool operator==(const EventPredecisionProjectionSchemaV1&,
                         const EventPredecisionProjectionSchemaV1&) = default;
};

struct EventCompletedEdgeProjectionSchemaV1 final {
  RuntimeOperationIdentityV1 operation;
  CodecIdentityV1 predecision_projection_codec;
  CodecIdentityV1 continuation_codec;
  CodecIdentityV1 projection_codec;

  friend bool operator==(const EventCompletedEdgeProjectionSchemaV1&,
                         const EventCompletedEdgeProjectionSchemaV1&) =
      default;
};

using EventEntryInitializerCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const CanonicalRuntimeValueV1&)>;
using EventStoppingIndicatorCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const CanonicalRuntimeValueV1&)>;
using EventTerminalReentryCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const EventTerminalReentryInputV1&)>;
using EventPredecisionProjectionCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const EventPredecisionProjectionInputV1&)>;
using EventCompletedEdgeProjectionCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const EventCompletedEdgeProjectionInputV1&)>;

// These carriers expose only immutable callback-free shape.  Their raw
// operations remain private until the C17 causal audit consumes them.
class CMinusOperationV1 final {
 public:
  CMinusOperationV1(CMinusOperationSchemaV1 schema,
                    CMinusCallbackV1 callback,
                    EnumerateCMinusExactLawV1 exact_enumerator = {})
      : schema_(std::move(schema)),
        operation_(std::move(callback)),
        exact_enumerator_(std::move(exact_enumerator)) {}

  [[nodiscard]] const CMinusOperationSchemaV1& schema() const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }
  [[nodiscard]] bool has_exact_enumerator() const noexcept {
    return exact_enumerator_.present();
  }

 private:
  [[nodiscard]] CMinusCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }
  [[nodiscard]] EnumerateCMinusExactLawV1 fresh_exact_enumerator() const {
    return exact_enumerator_.fresh_copy();
  }

  CMinusOperationSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<CMinusCallbackV1>
      operation_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EnumerateCMinusExactLawV1>
      exact_enumerator_;

  friend class C17AuditedFrameworkMint;
};

class CPlusOperationV1 final {
 public:
  CPlusOperationV1(CPlusOperationSchemaV1 schema, CPlusCallbackV1 callback,
                   EnumerateCPlusExactLawV1 exact_enumerator = {})
      : schema_(std::move(schema)),
        operation_(guard_output_fields(schema_, std::move(callback))),
        exact_enumerator_(guard_enumerated_output_fields(
            schema_, std::move(exact_enumerator))) {}

  [[nodiscard]] const CPlusOperationSchemaV1& schema() const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }
  [[nodiscard]] bool has_exact_enumerator() const noexcept {
    return exact_enumerator_.present();
  }

 private:
  [[nodiscard]] static CPlusCallbackV1 guard_output_fields(
      const CPlusOperationSchemaV1& schema, CPlusCallbackV1 callback);
  [[nodiscard]] static EnumerateCPlusExactLawV1
  guard_enumerated_output_fields(
      const CPlusOperationSchemaV1& schema,
      EnumerateCPlusExactLawV1 enumerator);

  [[nodiscard]] CPlusCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }
  [[nodiscard]] EnumerateCPlusExactLawV1 fresh_exact_enumerator() const {
    return exact_enumerator_.fresh_copy();
  }

  CPlusOperationSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<CPlusCallbackV1>
      operation_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EnumerateCPlusExactLawV1>
      exact_enumerator_;

  friend class C17AuditedFrameworkMint;
};

class EventEntryInitializerOperationV1 final {
 public:
  EventEntryInitializerOperationV1(EventEntryInitializerSchemaV1 schema,
                                   EventEntryInitializerCallbackV1 operation)
      : schema_(std::move(schema)),
        operation_(std::move(operation)) {}

  [[nodiscard]] const EventEntryInitializerSchemaV1& schema() const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EventEntryInitializerCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  EventEntryInitializerSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EventEntryInitializerCallbackV1>
      operation_;

  friend class C17AuditedFrameworkMint;
  friend class surrogate::detail::SealedRomrOpsAuthority;
};

class EventStoppingIndicatorOperationV1 final {
 public:
  EventStoppingIndicatorOperationV1(EventStoppingIndicatorSchemaV1 schema,
                                    EventStoppingIndicatorCallbackV1 operation)
      : schema_(std::move(schema)),
        operation_(std::move(operation)) {}

  [[nodiscard]] const EventStoppingIndicatorSchemaV1& schema() const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EventStoppingIndicatorCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  EventStoppingIndicatorSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EventStoppingIndicatorCallbackV1>
      operation_;

  friend class C17AuditedFrameworkMint;
  friend class surrogate::detail::SealedRomrOpsAuthority;
};

class EventTerminalReentryOperationV1 final {
 public:
  EventTerminalReentryOperationV1(EventTerminalReentrySchemaV1 schema,
                                  EventTerminalReentryCallbackV1 operation)
      : schema_(std::move(schema)),
        operation_(std::move(operation)) {}

  [[nodiscard]] const EventTerminalReentrySchemaV1& schema() const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EventTerminalReentryCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  EventTerminalReentrySchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EventTerminalReentryCallbackV1>
      operation_;

  friend class C17AuditedFrameworkMint;
  friend class surrogate::detail::SealedRomrOpsAuthority;
};

class EventPredecisionProjectionOperationV1 final {
 public:
  EventPredecisionProjectionOperationV1(
      EventPredecisionProjectionSchemaV1 schema,
      EventPredecisionProjectionCallbackV1 operation)
      : schema_(std::move(schema)),
        operation_(std::move(operation)) {}

  [[nodiscard]] const EventPredecisionProjectionSchemaV1& schema()
      const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EventPredecisionProjectionCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  EventPredecisionProjectionSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EventPredecisionProjectionCallbackV1>
      operation_;

  friend class C17AuditedFrameworkMint;
  friend class surrogate::detail::SealedRomrOpsAuthority;
};

class EventCompletedEdgeProjectionOperationV1 final {
 public:
  EventCompletedEdgeProjectionOperationV1(
      EventCompletedEdgeProjectionSchemaV1 schema,
      EventCompletedEdgeProjectionCallbackV1 operation)
      : schema_(std::move(schema)),
        operation_(std::move(operation)) {}

  [[nodiscard]] const EventCompletedEdgeProjectionSchemaV1& schema()
      const noexcept {
    return schema_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EventCompletedEdgeProjectionCallbackV1 fresh_operation()
      const {
    return operation_.fresh_copy();
  }

  EventCompletedEdgeProjectionSchemaV1 schema_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EventCompletedEdgeProjectionCallbackV1>
      operation_;

  friend class C17AuditedFrameworkMint;
  friend class surrogate::detail::SealedRomrOpsAuthority;
};

// The generator itself remains the one active KernelAccess operation.  This
// bundle supplies exactly the five decoder maps from (8.2b): iota, beta,
// terminal re-entry, x-minus, and x.  It is all-or-nothing for a temporal
// semantic and absent for non-temporal alternatives.
struct TemporalEventOperationsV1 final {
  EventEntryInitializerOperationV1 entry_initializer;
  EventStoppingIndicatorOperationV1 stopping_indicator;
  EventTerminalReentryOperationV1 terminal_reentry;
  EventPredecisionProjectionOperationV1 predecision_projection;
  EventCompletedEdgeProjectionOperationV1 completed_edge_projection;
};

struct CausalSurrogateOperationsV1 final {
  std::optional<CMinusOperationV1> c_minus;
  std::optional<CPlusOperationV1> c_plus;
  std::optional<TemporalEventOperationsV1> event;
};

// Each alternative owns only its active semantic object, its single portable
// source, and one orthogonal access alternative.  There are no nullable
// methods for the other eight semantic classes.
struct ScalarBacklogResponsePlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
};
struct StationaryMarkedEdgePlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
  CausalSurrogateOperationsV1 operations;
};
struct StagedOpportunityFluxPlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
  CausalSurrogateOperationsV1 operations;
};
struct TemporalOneSlotContinuationPlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
  CausalSurrogateOperationsV1 operations;
};
struct RomrResidenceWordPlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
  CausalSurrogateOperationsV1 operations;
};
struct StoppedPathPlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
  CausalSurrogateOperationsV1 operations;
};
struct CoupledTargetSchedulePlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
  CausalSurrogateOperationsV1 operations;
};
struct DirectMetricDecoderPlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
};
struct ResponseEnvelopePlugV1 final {
  PortablePlugPayload source;
  KernelAccess access;
};

using SurrogatePlug =
    std::variant<ScalarBacklogResponsePlugV1, StationaryMarkedEdgePlugV1,
                 StagedOpportunityFluxPlugV1,
                 TemporalOneSlotContinuationPlugV1,
                 RomrResidenceWordPlugV1, StoppedPathPlugV1,
                 CoupledTargetSchedulePlugV1, DirectMetricDecoderPlugV1,
                 ResponseEnvelopePlugV1>;

static_assert(std::variant_size_v<SurrogatePlug> == 9U,
              "C16 SurrogatePlug must remain the closed nine-alternative "
              "semantic union");

[[nodiscard]] SemanticTagV1 semantic_tag_v1(
    const SurrogatePlug& plug) noexcept;
[[nodiscard]] const KernelAccess& kernel_access_v1(
    const SurrogatePlug& plug) noexcept;
[[nodiscard]] const PortablePlugPayload& portable_source_v1(
    const SurrogatePlug& plug) noexcept;
[[nodiscard]] const CausalSurrogateOperationsV1* causal_operations_v1(
    const SurrogatePlug& plug) noexcept;

// The registered adapter returns an unpublished candidate.  Only F-C16-04
// can validate every identity and convert it into a public validated carrier.
struct RuntimePlugCandidateV1 final {
  PlugDescriptor descriptor;
  SurrogatePlug plug;
};

class ValidatedSurrogatePlug final {
 public:
  ValidatedSurrogatePlug(const ValidatedSurrogatePlug&) = delete;
  ValidatedSurrogatePlug(ValidatedSurrogatePlug&&) noexcept = default;
  ValidatedSurrogatePlug& operator=(const ValidatedSurrogatePlug&) = delete;
  ValidatedSurrogatePlug& operator=(ValidatedSurrogatePlug&&) noexcept =
      default;

  [[nodiscard]] const PlugDescriptor& descriptor() const noexcept {
    return descriptor_;
  }
  [[nodiscard]] const ArtifactValidationBindingsV1& artifact_bindings()
      const noexcept {
    return artifact_bindings_;
  }
  [[nodiscard]] const Digest256& accepted_contract_digest() const noexcept {
    return accepted_contract_digest_;
  }

 private:
  ValidatedSurrogatePlug(PlugDescriptor descriptor, SurrogatePlug plug,
                         ArtifactValidationBindingsV1 artifact_bindings,
                         Digest256 accepted_contract_digest,
                         MetricSupportManifest accepted_structural_manifest)
      : descriptor_(std::move(descriptor)),
        plug_(std::move(plug)),
        artifact_bindings_(std::move(artifact_bindings)),
        accepted_contract_digest_(std::move(accepted_contract_digest)),
        accepted_structural_manifest_(
            std::move(accepted_structural_manifest)) {}

  PlugDescriptor descriptor_;
  SurrogatePlug plug_;
  ArtifactValidationBindingsV1 artifact_bindings_;
  Digest256 accepted_contract_digest_;
  // F-C16-04 owns the exact decoded structural manifest accepted by C14.
  // F-C16-05 uses this immutable copy for clause-local decoder-domain
  // cross-binding without reparsing bytes or duplicating C15's grammar.
  MetricSupportManifest accepted_structural_manifest_;

  friend Result<ValidatedSurrogatePlug>
  materialize_and_validate_surrogate_plug(
      const PortablePlugPayload&, const ValidatedSurrogateArtifact&,
      const AcceptedCapabilityContract&);
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug&);
  friend class C17AuditedFrameworkMint;
};

// F-C16-04.
[[nodiscard]] Result<ValidatedSurrogatePlug>
materialize_and_validate_surrogate_plug(
    const PortablePlugPayload& portable_payload,
    const ValidatedSurrogateArtifact& artifact,
    const AcceptedCapabilityContract& accepted_contract);

// F-C16-05.  Validation is structural and never invokes the callback.
[[nodiscard]] Result<KernelAccess> validate_kernel_access(
    const ValidatedSurrogatePlug& plug);

}  // namespace mwperf
