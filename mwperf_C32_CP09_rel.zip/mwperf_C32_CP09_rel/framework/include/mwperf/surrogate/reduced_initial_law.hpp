#pragma once

#include <cstddef>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/kernel_access.hpp"

namespace mwperf {

class AuditedCompiledFramework;

namespace detail {
class C20CoreAccess;
}

namespace kernel::detail {
class C17TemporalBridgeAccess;
}

namespace surrogate::detail {
struct AuditedConsumerSealIdentity;
}  // namespace surrogate::detail

// One complete reduced predecision state.  The codec identifies the joint
// representation of (N_T, H^A, framework-retained coordinates, Z); C16 never
// exposes separate coordinate marginals from which a different coupling
// could be reconstructed.
using ReducedStateV1 = CanonicalRuntimeValueV1;

struct ReducedInitialAtomV1 final {
  ReducedStateV1 state;
  ProbabilityMass mass;

  friend bool operator==(const ReducedInitialAtomV1&,
                         const ReducedInitialAtomV1&) = default;
};

// An alpha0 result is deliberately untrusted.  For a transient selection each
// entry names the exact coalesced C09 physical-atom ordinal to which its
// conditional mass belongs.  More than one entry may name an ordinal so alpha0
// can add a conditionally distributed surrogate phase Z.  For a stationary or
// fixed-point selection the ordinal must be absent and conditional_mass is the
// selected law's unconditional mass.  Only F-C16-06 may turn this candidate
// into ReducedInitialLaw.
struct ReducedInitialCandidateAtomV1 final {
  ReducedStateV1 state;
  ProbabilityMass conditional_mass;
  std::optional<std::size_t> physical_atom_ordinal;

  friend bool operator==(const ReducedInitialCandidateAtomV1&,
                         const ReducedInitialCandidateAtomV1&) = default;
};

struct ReducedInitialLawCandidateV1 final {
  CodecIdentityV1 state_codec;
  Digest256 exact_state_schema_digest;
  Digest256 reduced_state_schema_digest;
  Digest256 selection_digest;
  SelectionSupportV1 selection_support;
  std::vector<ReducedInitialCandidateAtomV1> atoms;

  friend bool operator==(const ReducedInitialLawCandidateV1&,
                         const ReducedInitialLawCandidateV1&) = default;
};

// An immutable, exactly normalized finite joint law.  Its private seal keeps
// the result bound to the audited framework that validated the state domain
// and, for transient starts, the exact physical-atom push-forward.  The sole
// mint is F-C16-06; alpha0 cannot construct this type.
class ReducedInitialLaw final {
 public:
  ReducedInitialLaw() = delete;
  ReducedInitialLaw(const ReducedInitialLaw&) = default;
  ReducedInitialLaw(ReducedInitialLaw&&) noexcept = default;
  ReducedInitialLaw& operator=(const ReducedInitialLaw&) = default;
  ReducedInitialLaw& operator=(ReducedInitialLaw&&) noexcept = default;

  [[nodiscard]] const CodecIdentityV1& state_codec() const noexcept {
    return state_codec_;
  }
  [[nodiscard]] const Digest256& exact_state_schema_digest() const noexcept {
    return exact_state_schema_digest_;
  }
  [[nodiscard]] const Digest256& reduced_state_schema_digest() const noexcept {
    return reduced_state_schema_digest_;
  }
  // Compatibility spelling for the previously exposed reduced-state digest.
  [[nodiscard]] const Digest256& state_schema_digest() const noexcept {
    return reduced_state_schema_digest_;
  }
  [[nodiscard]] const Digest256& selection_digest() const noexcept {
    return selection_digest_;
  }
  [[nodiscard]] const SelectionSupportV1& selection_support() const noexcept {
    return selection_support_;
  }
  [[nodiscard]] std::span<const ReducedInitialAtomV1> atoms() const noexcept {
    return atoms_;
  }

 private:
  ReducedInitialLaw(
                    CodecIdentityV1 state_codec,
                    Digest256 exact_state_schema_digest,
                    Digest256 reduced_state_schema_digest,
                    Digest256 selection_digest,
                    SelectionSupportV1 selection_support,
                    std::vector<ReducedInitialAtomV1> atoms,
                    std::shared_ptr<const
                        surrogate::detail::AuditedConsumerSealIdentity> seal)
      : state_codec_(std::move(state_codec)),
        exact_state_schema_digest_(std::move(exact_state_schema_digest)),
        reduced_state_schema_digest_(std::move(reduced_state_schema_digest)),
        selection_digest_(std::move(selection_digest)),
        selection_support_(std::move(selection_support)),
        atoms_(std::move(atoms)),
        seal_(std::move(seal)) {}

  CodecIdentityV1 state_codec_;
  Digest256 exact_state_schema_digest_;
  Digest256 reduced_state_schema_digest_;
  Digest256 selection_digest_;
  SelectionSupportV1 selection_support_;
  std::vector<ReducedInitialAtomV1> atoms_;
  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity> seal_;

  friend Result<ReducedInitialLaw> construct_reduced_initial_law(
      const ResolvedInstance&, const AuditedCompiledFramework&,
      const SelectionSpec&, std::optional<InitialPhysicalLaw>);
  friend Result<void> validate_reduced_initial_law_v1(
      const ReducedInitialLaw&);
  friend class detail::C20CoreAccess;
  friend class kernel::detail::C17TemporalBridgeAccess;
};

[[nodiscard]] Result<void> validate_reduced_initial_law_v1(
    const ReducedInitialLaw& law);

}  // namespace mwperf
