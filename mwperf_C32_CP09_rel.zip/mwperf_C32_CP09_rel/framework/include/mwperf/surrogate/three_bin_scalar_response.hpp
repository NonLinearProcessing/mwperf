#pragma once

#include <array>
#include <compare>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace artifact::detail {
class PayloadWireAccess;
}  // namespace artifact::detail
#if defined(MWPERF_C15_TEST_SEAMS)
namespace testing {
class C15ProtocolFixtureFactory;
}  // namespace testing
#endif

// These values and their order are part of the v1 wire contract.  There is no
// fourth, provider-defined bin: mu(0)=0 is fixed by the protocol and the tail
// starts at backlog three.
enum class ThreeBinCoefficientV1 : std::uint8_t {
  one,
  two,
  tail_from_three,
};

enum class ProposalConditioningSourceV1 : std::uint8_t {
  exact_population,
  empirical_average,
};

enum class PopulationConditioningStatusV1 : std::uint8_t {
  proved_positive,
  proved_zero,
  positive_with_confidence,
  unresolved,
};

enum class RawValueStatusV1 : std::uint8_t {
  exact_point,
  interval_only,
  absent,
};

enum class ResponseProductStageV1 : std::uint8_t {
  raw_response,
  nominal_response,
  projection_center,
  projected_mean,
  recoded_response,
};

enum class ProjectionCenterSourceKindV1 : std::uint8_t {
  decoded_raw_response,
  synthetic_snapshot_mean,
  explicit_fallback,
};

enum class ProductDerivationKindV1 : std::uint8_t {
  nominal_completion,
  admissibility_projection,
  identity_recoding,
  mean_inversion_recoding,
  endpoint_completion,
};

enum class RawEnvelopeScopeV1 : std::uint8_t {
  proposal_raw,
  optimizer_interval_raw,
  deterministic_quadrature_raw,
  physical_response_bound,
};

enum class RawEnvelopeCoverageV1 : std::uint8_t {
  deterministic,
  marginal,
  simultaneous,
};

enum class PopulationConditioningPremiseV1 : std::uint8_t {
  unconditional,
  conditional_on_population_positivity,
};

struct ProviderConformanceReportRef final {
  std::uint32_t report_schema_version;
  TypedLabel report_id;
  Digest256 report_digest;
  ProviderIdentityV1 provider;
  Digest256 provider_scientific_contract_digest;
  std::string family_evidence_schema_id;
  std::uint32_t family_evidence_schema_version;

  friend bool operator==(const ProviderConformanceReportRef&,
                         const ProviderConformanceReportRef&) = default;
};

// A stage is encoded both in the wire tag and the C++ type.  Construction is
// deliberately restricted to the bounded decoder, semantic validator and the
// fixture-only test authority; ordinary callers cannot relabel a product.
template <ResponseProductStageV1 Stage>
class TypedResponseProductIdV1 final {
 public:
  TypedResponseProductIdV1(const TypedResponseProductIdV1&) = default;
  TypedResponseProductIdV1(TypedResponseProductIdV1&&) noexcept = default;
  TypedResponseProductIdV1& operator=(const TypedResponseProductIdV1&) =
      default;
  TypedResponseProductIdV1& operator=(TypedResponseProductIdV1&&) noexcept =
      default;

  [[nodiscard]] const ArtifactObjectReferenceV1& identity() const noexcept {
    return identity_;
  }
  [[nodiscard]] static constexpr ResponseProductStageV1 stage() noexcept {
    return Stage;
  }

  friend bool operator==(const TypedResponseProductIdV1&,
                         const TypedResponseProductIdV1&) = default;
  friend std::strong_ordering operator<=>(const TypedResponseProductIdV1&,
                                           const TypedResponseProductIdV1&) =
      default;

 private:
  explicit TypedResponseProductIdV1(ArtifactObjectReferenceV1 identity)
      : identity_(std::move(identity)) {}

  ArtifactObjectReferenceV1 identity_;

  friend class artifact::detail::PayloadWireAccess;
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

using RawResponseProductId =
    TypedResponseProductIdV1<ResponseProductStageV1::raw_response>;
using NominalResponseProductId =
    TypedResponseProductIdV1<ResponseProductStageV1::nominal_response>;
using ProjectionCenterProductId =
    TypedResponseProductIdV1<ResponseProductStageV1::projection_center>;
using ProjectedMeanProductId =
    TypedResponseProductIdV1<ResponseProductStageV1::projected_mean>;
using RecodedResponseProductId =
    TypedResponseProductIdV1<ResponseProductStageV1::recoded_response>;

struct ProposalConditioningMeasureV1 final {
  ProposalConditioningSourceV1 source;
  PortableScientificScalar observed_nonnegative_value;
  std::optional<TypedLabel> frozen_evaluation_id;

  friend bool operator==(const ProposalConditioningMeasureV1&,
                         const ProposalConditioningMeasureV1&) = default;
};

struct CoefficientStatusV1 final {
  PopulationConditioningStatusV1 population_conditioning_status;
  RawValueStatusV1 raw_value_status;

  friend bool operator==(const CoefficientStatusV1&,
                         const CoefficientStatusV1&) = default;
};

struct CoefficientIdentificationV1 final {
  ArtifactObjectReferenceV1 coefficient_id;
  ProposalConditioningMeasureV1 proposal_conditioning;
  CoefficientStatusV1 coefficient_status;
  std::optional<PortableScientificScalar> raw_point;
  std::vector<ArtifactObjectReferenceV1> family_evidence_envelope_ids;
  ProviderConformanceReportRef provider_conformance_report_ref;
  std::optional<ArtifactObjectReferenceV1> completion_policy_id;
  ThreeBinCoefficientV1 target_bin_binding;

  friend bool operator==(const CoefficientIdentificationV1&,
                         const CoefficientIdentificationV1&) = default;
};

struct ResponseCoefficientV1 final {
  ThreeBinCoefficientV1 bin;
  PortableScientificScalar value;
  ArtifactObjectReferenceV1 origin_coefficient_id;

  friend bool operator==(const ResponseCoefficientV1&,
                         const ResponseCoefficientV1&) = default;
};

using ResponseCoefficientTripleV1 = std::array<ResponseCoefficientV1, 3U>;

struct RawResponseProductV1 final {
  RawResponseProductId product_id;
  ProviderIdentityV1 provider;
  Digest256 request_digest;
  QueueId deployed_target;
  Digest256 configured_arrival_binding;
  Digest256 proposal_law_digest;
  std::array<CoefficientIdentificationV1, 3U> identifications;

  friend bool operator==(const RawResponseProductV1&,
                         const RawResponseProductV1&) = default;
};

struct NominalResponseProductV1 final {
  NominalResponseProductId product_id;
  ProviderIdentityV1 provider;
  Digest256 request_digest;
  QueueId deployed_target;
  ResponseCoefficientTripleV1 coefficients;
  RawResponseProductId raw_parent;
  std::optional<ArtifactObjectReferenceV1> completion_policy_id;
  std::optional<ArtifactObjectReferenceV1> derivation_certificate_id;

  friend bool operator==(const NominalResponseProductV1&,
                         const NominalResponseProductV1&) = default;
};

struct ProjectionCenterProductV1 final {
  ProjectionCenterProductId product_id;
  ProviderIdentityV1 provider;
  Digest256 request_digest;
  std::vector<QueueId> ordered_construction_targets;
  QueueId deployed_target;
  ProjectionCenterSourceKindV1 source_kind;
  std::vector<PortableScientificScalar> mean_vector;
  std::variant<RawResponseProductId, NominalResponseProductId>
      response_source;
  std::optional<ArtifactObjectReferenceV1> completion_policy_id;

  friend bool operator==(const ProjectionCenterProductV1&,
                         const ProjectionCenterProductV1&) = default;
};

struct ProjectedMeanProductV1 final {
  ProjectedMeanProductId product_id;
  ProviderIdentityV1 provider;
  Digest256 request_digest;
  std::vector<QueueId> ordered_construction_targets;
  QueueId deployed_target;
  std::vector<PortableScientificScalar> mean_vector;
  ProjectionCenterProductId center_parent;
  ArtifactObjectReferenceV1 projection_policy_id;
  std::optional<ArtifactObjectReferenceV1> derivation_certificate_id;

  friend bool operator==(const ProjectedMeanProductV1&,
                         const ProjectedMeanProductV1&) = default;
};

struct RecodedResponseProductV1 final {
  RecodedResponseProductId product_id;
  ProviderIdentityV1 provider;
  Digest256 request_digest;
  QueueId deployed_target;
  ResponseCoefficientTripleV1 coefficients;
  ProductDerivationKindV1 derivation_kind;
  std::optional<ProjectedMeanProductId> projected_mean_parent;
  std::variant<std::monostate, RawResponseProductId,
               NominalResponseProductId>
      reference_response_parent;
  std::optional<ArtifactObjectReferenceV1> completion_policy_id;
  ArtifactObjectReferenceV1 recoding_policy_id;
  std::optional<ArtifactObjectReferenceV1> derivation_certificate_id;

  friend bool operator==(const RecodedResponseProductV1&,
                         const RecodedResponseProductV1&) = default;
};

using DeployedResponseProductIdV1 =
    std::variant<RawResponseProductId, NominalResponseProductId,
                 RecodedResponseProductId>;

struct RawResponseEnvelopeV1 final {
  ArtifactObjectReferenceV1 envelope_id;
  RawResponseProductId source_product;
  Digest256 construction_law_digest;
  std::vector<ThreeBinCoefficientV1> covered_bins;
  std::vector<PortableScientificScalar> lower;
  std::vector<PortableScientificScalar> upper;
  std::string certification_method;
  RawEnvelopeCoverageV1 coverage;
  PopulationConditioningPremiseV1 population_conditioning_premise;
  std::optional<TypedLabel> frozen_evaluation_id;
  std::optional<BigNat> sample_size;
  RawEnvelopeScopeV1 scope;
  std::vector<ArtifactObjectReferenceV1> family_evidence_envelope_ids;

  friend bool operator==(const RawResponseEnvelopeV1&,
                         const RawResponseEnvelopeV1&) = default;
};

struct ThreeBinScalarResponseV1 final {
  std::uint32_t payload_version;
  // Identity of this one complete deployed response row.  It is distinct
  // from every stage-specific product identity below and is content-bound by
  // canonical_three_bin_response_row_digest_v1.
  ArtifactObjectReferenceV1 response_row_id;
  QueueId deployed_target;
  Digest256 configured_arrival_binding;
  RawResponseProductV1 raw_response;
  std::optional<NominalResponseProductV1> nominal_response;
  std::optional<ProjectionCenterProductV1> projection_center;
  std::optional<ProjectedMeanProductV1> projected_mean;
  std::optional<RecodedResponseProductV1> recoded_response;
  DeployedResponseProductIdV1 deployed_response_product_id;
  std::vector<RawResponseEnvelopeV1> raw_envelopes;

  friend bool operator==(const ThreeBinScalarResponseV1&,
                         const ThreeBinScalarResponseV1&) = default;
};

[[nodiscard]] Result<Digest256> canonical_three_bin_response_row_digest_v1(
    const ThreeBinScalarResponseV1& response);

// Product identity binds the stage tag, provider/request/target context,
// canonical contents, declared parent lineage and evidence identities.
[[nodiscard]] Result<Digest256> canonical_raw_response_product_digest_v1(
    const RawResponseProductV1& product);
[[nodiscard]] Result<Digest256> canonical_nominal_response_product_digest_v1(
    const NominalResponseProductV1& product);
[[nodiscard]] Result<Digest256>
canonical_projection_center_product_digest_v1(
    const ProjectionCenterProductV1& product);
[[nodiscard]] Result<Digest256> canonical_projected_mean_product_digest_v1(
    const ProjectedMeanProductV1& product);
[[nodiscard]] Result<Digest256> canonical_recoded_response_product_digest_v1(
    const RecodedResponseProductV1& product);

[[nodiscard]] const ArtifactObjectReferenceV1&
deployed_response_product_identity_v1(
    const DeployedResponseProductIdV1& product) noexcept;

}  // namespace mwperf
