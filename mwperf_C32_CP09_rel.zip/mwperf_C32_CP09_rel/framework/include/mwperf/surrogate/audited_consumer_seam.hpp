#pragma once

#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/arrival/initial_law.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/kernel_access.hpp"
#include "mwperf/surrogate/reduced_initial_law.hpp"

namespace mwperf {

class AuditedCompiledFramework;
class DirectMetricCompositeCandidateV1;

namespace detail {
class C17CoreAccess;
[[nodiscard]] Result<Digest256> audited_framework_execution_seal_digest(
    const AuditedCompiledFramework& framework);
}

namespace certificates::detail {
class C25CoreAccess;
}

// C17 is deliberately only forward declared.  It is the sole production
// class permitted to construct either opaque consumer handle after V0.
class C17AuditedFrameworkMint;
class AuditedInitialMapper;
class AuditedRowProvider;
class AuditedSlotExecutor;
class AuditedResponseLaw;
class AuditedThreeBinResponse;
class AuditedFinitePrefixConstantTailResponse;
class AuditedPhaseResponse;
class AuditedFixedPointFamily;
class AuditedRomrView;
class AuditedResidenceProvider;
class AuditedTemporalFramework;
class AuditedCylinderLaw;
class AuditedTemporalKernel;
class AuditedTemporalLaw;
class AuditedSamplerDescriptor;
class AuditedExactInnovationKernel;
class AuditedTargetDensityRatio;
class DirectMetricAccess;
class V0WitnessReport;

namespace surrogate::detail {
struct AuditedConsumerSealIdentity final {};
class SealedFrameworkCore;
}  // namespace surrogate::detail

using MetricValue = CanonicalRuntimeValueV1;

// These are the immutable identities C17 binds while sealing the compiled
// framework.  The complete target-selection fingerprint and the ordered
// target-only execution identity are deliberately noninterchangeable.
struct AuditedFrameworkBindingsV1 final {
  FrameworkProblemFingerprintsV1 problem_fingerprints;
  FrameworkProblemViewDigest problem_view_digest;
  Digest256 exact_state_schema_digest;
  Digest256 reduced_state_schema_digest;
  Digest256 descriptor_digest;
  Digest256 access_digest;
  Digest256 accepted_contract_digest;
  Digest256 normalized_metric_requirements_digest;
  // This digest covers only the ordered QueueId sequence.  It is distinct
  // from FrameworkProblemFingerprintsV1::target_selection, which also binds
  // the construction-group identity.
  Digest256 ordered_target_digest;
  Digest256 selection_digest;
  Digest256 build_request_digest;
  // Present only for the direct semantic.  C17 copies the exact typed domain
  // (including its non-interchangeable decoder key) from the V0-audited raw
  // access before issuing DirectMetricAccess.
  std::optional<ExactMetricDecoderDomainV1> direct_metric_decoder_domain;

  friend bool operator==(const AuditedFrameworkBindingsV1&,
                         const AuditedFrameworkBindingsV1&) = default;
};

// Exact direct-request domain.  The normalized request digest is recomputed
// from C14's canonical one-clause requirements before execution; the typed
// parameters and ordered targets are checked independently so a digest is not
// used to hide a domain mismatch.
struct DirectMetricRequestDomainV1 final {
  ExactMetricDecoderDomainV1 metric_domain;
  // C15 binds every direct payload value to the normalized accepted
  // requirements aggregate.  The following C16 digest independently binds
  // this one callable to the exact one-clause MetricRequest passed to F-C16-08.
  Digest256 normalized_metric_request_digest;
  Digest256 canonical_request_domain_digest;
  std::vector<ResolvedMetricTargetV1> ordered_targets;
  Digest256 ordered_target_digest;
  Digest256 selection_digest;
  MetricSelectionRegimeV1 selection_regime;
  CodecIdentityV1 result_codec;

  friend bool operator==(const DirectMetricRequestDomainV1&,
                         const DirectMetricRequestDomainV1&) = default;
};

// The configured selection and the mathematical authority for using it are
// distinct.  An explicit class, mixture, or fixed-point ID is already carried
// by SelectionSpec; only the two "unique" alternatives require a separately
// sealed nonzero evidence identity.  F-C16-06 validates this record before it
// invokes alpha0, without interpreting or upgrading the evidence itself.
struct InitialSelectionAuthorityV1 final {
  SelectionKindV1 configured_kind;
  std::optional<Digest256> uniqueness_evidence_digest;

  friend bool operator==(const InitialSelectionAuthorityV1&,
                         const InitialSelectionAuthorityV1&) = default;
};

using ReducedInitialMapperV1 = std::function<Result<ReducedInitialLawCandidateV1>(
    const SelectionSpec&,
    const std::optional<InitialPhysicalLaw>&)>;
using SealedExactStateSchemaValidatorV1 = std::function<Result<void>(
    const ResolvedInstance&, const Digest256&)>;
using SealedReducedStateDomainValidatorV1 =
    std::function<Result<void>(const ReducedStateV1&)>;
using SealedPhysicalAtomProjectionValidatorV1 = std::function<Result<void>(
    std::size_t, const InitialPhysicalAtom&, const ReducedStateV1&)>;
using SealedDirectMetricDecoderV1 =
    std::function<Result<MetricValue>(const MetricRequest&)>;
using SealedCanonicalResultBytesValidatorV1 = std::function<Result<void>(
    const ExactMetricDecoderKeyV1&, const CodecIdentityV1&,
    std::span<const std::byte>)>;

// Opaque V0-audited carrier.  It has no public/default/deserializing
// constructor and deliberately exposes no raw plug or callback accessor.
class AuditedCompiledFramework final {
 public:
  AuditedCompiledFramework() = delete;
  AuditedCompiledFramework(const AuditedCompiledFramework&) = delete;
  AuditedCompiledFramework& operator=(const AuditedCompiledFramework&) =
      delete;
  AuditedCompiledFramework(AuditedCompiledFramework&&) noexcept = default;
  AuditedCompiledFramework& operator=(AuditedCompiledFramework&&) noexcept =
      default;
  ~AuditedCompiledFramework() = default;

 private:
  AuditedCompiledFramework(AuditedFrameworkBindingsV1 bindings,
                           TargetSelection target_selection,
                           CodecIdentityV1 reduced_state_codec,
                           SelectionSupportV1 selection_support,
                           InitialSelectionAuthorityV1
                               initial_selection_authority,
                           ReducedInitialMapperV1 initial_mapper,
                           SealedExactStateSchemaValidatorV1
                               exact_state_schema_validator,
                           SealedReducedStateDomainValidatorV1
                               reduced_state_domain_validator,
                           SealedPhysicalAtomProjectionValidatorV1
                               physical_atom_projection_validator)
      : seal_(std::make_shared<
              const surrogate::detail::AuditedConsumerSealIdentity>()),
        bindings_(std::move(bindings)),
        target_selection_(std::move(target_selection)),
        reduced_state_codec_(std::move(reduced_state_codec)),
        selection_support_(std::move(selection_support)),
        initial_selection_authority_(
            std::move(initial_selection_authority)),
        initial_mapper_(std::move(initial_mapper)),
        exact_state_schema_validator_(
            std::move(exact_state_schema_validator)),
        reduced_state_domain_validator_(
            std::move(reduced_state_domain_validator)),
        physical_atom_projection_validator_(
            std::move(physical_atom_projection_validator)),
        c17_core_(nullptr) {}

  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity> seal_;
  AuditedFrameworkBindingsV1 bindings_;
  TargetSelection target_selection_;
  CodecIdentityV1 reduced_state_codec_;
  SelectionSupportV1 selection_support_;
  InitialSelectionAuthorityV1 initial_selection_authority_;
  ReducedInitialMapperV1 initial_mapper_;
  SealedExactStateSchemaValidatorV1 exact_state_schema_validator_;
  SealedReducedStateDomainValidatorV1 reduced_state_domain_validator_;
  SealedPhysicalAtomProjectionValidatorV1
      physical_atom_projection_validator_;
  std::shared_ptr<surrogate::detail::SealedFrameworkCore> c17_core_;

  friend class C17AuditedFrameworkMint;
  friend class detail::C17CoreAccess;
  friend Result<Digest256>
  detail::audited_framework_execution_seal_digest(
      const AuditedCompiledFramework& framework);
  friend class certificates::detail::C25CoreAccess;
  friend Result<AuditedRowProvider> audited_row_provider(
      const AuditedCompiledFramework&);
  friend Result<AuditedCompiledFramework> audit_v0_direct_composite(
      DirectMetricCompositeCandidateV1);
  friend Result<AuditedSlotExecutor> audited_slot_executor(
      const AuditedCompiledFramework&);
  friend Result<AuditedThreeBinResponse> audited_three_bin_response(
      const AuditedCompiledFramework&);
  friend Result<AuditedFinitePrefixConstantTailResponse>
  audited_finite_prefix_constant_tail_response(
      const AuditedCompiledFramework&);
  friend Result<AuditedRomrView> audited_romr_view(
      const AuditedCompiledFramework&);
  friend const V0WitnessReport& v0_witness_report(
      const AuditedCompiledFramework&);
  friend Result<ReducedInitialLaw> construct_reduced_initial_law(
      const ResolvedInstance&, const AuditedCompiledFramework&,
      const SelectionSpec&, std::optional<InitialPhysicalLaw>);
  friend Result<MetricValue> execute_direct_metric_decoder(
      const AuditedCompiledFramework&, const DirectMetricAccess&,
      const MetricRequest&);
};

// A decoder is a distinct post-V0 handle.  It carries the same unforgeable
// in-process seal identity as its issuing AuditedCompiledFramework and no
// public decoder accessor.
class DirectMetricAccess final {
 public:
  DirectMetricAccess() = delete;
  DirectMetricAccess(const DirectMetricAccess&) = delete;
  DirectMetricAccess& operator=(const DirectMetricAccess&) = delete;
  DirectMetricAccess(DirectMetricAccess&&) noexcept = default;
  DirectMetricAccess& operator=(DirectMetricAccess&&) noexcept = default;
  ~DirectMetricAccess() = default;

 private:
  DirectMetricAccess(
      std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity>
          seal,
      AuditedFrameworkBindingsV1 framework_bindings,
      DirectMetricRequestDomainV1 domain,
      SealedDirectMetricDecoderV1 decoder,
      SealedCanonicalResultBytesValidatorV1 result_validator)
      : seal_(std::move(seal)),
        framework_bindings_(std::move(framework_bindings)),
        domain_(std::move(domain)),
        decoder_(std::move(decoder)),
        result_validator_(std::move(result_validator)) {}

  std::shared_ptr<const surrogate::detail::AuditedConsumerSealIdentity> seal_;
  AuditedFrameworkBindingsV1 framework_bindings_;
  DirectMetricRequestDomainV1 domain_;
  SealedDirectMetricDecoderV1 decoder_;
  SealedCanonicalResultBytesValidatorV1 result_validator_;

  friend class C17AuditedFrameworkMint;
  friend Result<MetricValue> execute_direct_metric_decoder(
      const AuditedCompiledFramework&, const DirectMetricAccess&,
      const MetricRequest&);
};

// F-C16-06.  InitialPhysicalLaw copies retain C09's opaque origin token, so
// this catalogued by-value optional preserves request provenance without
// exposing or serializing it.
[[nodiscard]] Result<ReducedInitialLaw> construct_reduced_initial_law(
    const ResolvedInstance& instance,
    const AuditedCompiledFramework& framework,
    const SelectionSpec& selection,
    std::optional<InitialPhysicalLaw> physical_initializer);

// F-C16-08.
[[nodiscard]] Result<MetricValue> execute_direct_metric_decoder(
    const AuditedCompiledFramework& framework,
    const DirectMetricAccess& access,
    const MetricRequest& request);

}  // namespace mwperf
