#pragma once

#include <cstddef>
#include <compare>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

#if defined(MWPERF_C15_TEST_SEAMS)
namespace testing {
class C15ProtocolFixtureFactory;
}
#endif

// One closed provider-owned evidence-body schema.  The body is opaque to the
// framework, but both its schema identity and its maximum canonical size are
// part of the scientific contract.
struct FamilyEvidenceSchemaV1 final {
  std::string schema_id;
  std::uint32_t schema_version;
  std::size_t maximum_canonical_body_bytes;

  friend bool operator==(const FamilyEvidenceSchemaV1&,
                         const FamilyEvidenceSchemaV1&) = default;
  friend std::strong_ordering operator<=>(const FamilyEvidenceSchemaV1&,
                                           const FamilyEvidenceSchemaV1&) =
      default;
};

// Release-time identity of the provider-owned conformance report governing
// one opaque family-evidence schema.  The enclosing full provider manifest
// supplies the provider identity, while its scientific projection supplies
// the scientific-contract digest.  Keeping those derivable fields out of
// this anchor avoids a report/manifest digest cycle.
struct FamilyEvidenceConformanceReportAnchorV1 final {
  std::string family_evidence_schema_id;
  std::uint32_t family_evidence_schema_version;
  std::uint32_t report_schema_version;
  TypedLabel report_id;
  Digest256 report_digest;

  friend bool operator==(
      const FamilyEvidenceConformanceReportAnchorV1&,
      const FamilyEvidenceConformanceReportAnchorV1&) = default;
  friend std::strong_ordering operator<=> (
      const FamilyEvidenceConformanceReportAnchorV1&,
      const FamilyEvidenceConformanceReportAnchorV1&) = default;
};

struct RegisteredAnalyticFamilyContractV1 final {
  std::string family_id;
  std::uint32_t family_version;
  std::string parameter_schema_id;
  std::uint32_t parameter_schema_version;
  std::string domain_schema_id;
  std::uint32_t domain_schema_version;

  friend bool operator==(const RegisteredAnalyticFamilyContractV1&,
                         const RegisteredAnalyticFamilyContractV1&) = default;
  friend std::strong_ordering operator<=>(
      const RegisteredAnalyticFamilyContractV1&,
      const RegisteredAnalyticFamilyContractV1&) = default;
};

struct RegisteredRuntimeRecipeContractV1 final {
  std::string recipe_id;
  std::uint32_t recipe_version;
  std::string parameter_schema_id;
  std::uint32_t parameter_schema_version;
  std::string state_codec_schema_id;
  std::uint32_t state_codec_schema_version;
  std::string mark_codec_schema_id;
  std::uint32_t mark_codec_schema_version;

  friend bool operator==(const RegisteredRuntimeRecipeContractV1&,
                         const RegisteredRuntimeRecipeContractV1&) = default;
  friend std::strong_ordering operator<=>(
      const RegisteredRuntimeRecipeContractV1&,
      const RegisteredRuntimeRecipeContractV1&) = default;
};

// Closed policy domains admitted by one provider version.  Each vector is a
// canonical nonempty set in enum declaration order; preview chooses one value
// from each set and copies it into AcceptedCapabilityContract.
struct ScientificConstructionPolicySchemaV1 final {
  std::uint32_t schema_version;
  std::vector<PointDeploymentPolicyV1> point_deployment;
  std::vector<CoefficientCompletionPolicyV1> coefficient_completion;
  std::vector<ProjectionPolicyV1> projection;
  std::vector<RecodingPolicyV1> recoding;
  std::vector<EvidenceRolePolicyV1> evidence_roles;
  std::vector<RegisteredAnalyticFamilyContractV1>
      registered_analytic_families;
  std::vector<RegisteredRuntimeRecipeContractV1> registered_runtime_recipes;

  friend bool operator==(const ScientificConstructionPolicySchemaV1&,
                         const ScientificConstructionPolicySchemaV1&) =
      default;
};

struct TargetAndArrivalScientificPrerequisitesV1 final {
  std::size_t minimum_deployed_targets;
  std::size_t maximum_deployed_targets;
  std::vector<TargetCouplingV1> permitted_target_couplings;
  std::vector<ArrivalAssumptionV1> arrival_assumptions;

  friend bool operator==(const TargetAndArrivalScientificPrerequisitesV1&,
                         const TargetAndArrivalScientificPrerequisitesV1&) =
      default;
};

// A local executable remains a statically registered identity.  This record
// contains no path and no authored substitution slot.  C16 binds the identity
// to the compiled absolute path and literal argv grammar.
struct LocalExecutableDeclarationV1 final {
  std::string executable_id;
  std::uint32_t argv_grammar_version;
  std::vector<std::string> fixed_argument_template;
  bool externally_reconstructible_arrival;

  friend bool operator==(const LocalExecutableDeclarationV1&,
                         const LocalExecutableDeclarationV1&) = default;
};

struct ProviderTransportLimitsV1 final {
  std::size_t maximum_request_bytes;
  std::size_t maximum_result_bytes;

  friend bool operator==(const ProviderTransportLimitsV1&,
                         const ProviderTransportLimitsV1&) = default;
};

// Provider-specific scientific-work counters whose presence and independently
// known lower bounds are part of the provider's scientific contract.  Common
// optimizer/search/generator minima are carried by the accepted C14
// construction prerequisites instead.
struct RequiredMethodCounterV1 final {
  std::string name;
  BigNat minimum_used;

  friend bool operator==(const RequiredMethodCounterV1&,
                         const RequiredMethodCounterV1&) = default;
};

struct SurrogateProviderManifestV1 final {
  std::uint32_t manifest_schema_version;
  ProviderIdentityV1 provider;
  bool default_selection;
  Digest256 source_build_identity;

  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  SemanticTagV1 deployed_semantic_tag;
  RuntimeAccessTagV1 runtime_access_tag;
  PayloadClassV1 payload_class;

  std::uint32_t parameter_schema_version;
  Digest256 parameter_schema_digest;
  std::vector<std::uint32_t> supported_build_request_versions;
  std::vector<std::uint32_t> supported_artifact_versions;
  std::vector<std::uint32_t> required_build_report_schema_versions;
  std::vector<RequiredMethodCounterV1> required_method_counters;

  SchedulerConstraintApplicabilityV1 optimizer_constraint_applicability;
  TargetAndArrivalScientificPrerequisitesV1
      target_and_arrival_scientific_prerequisites;
  MetricSupportManifest metric_clause_upper_envelope;
  std::vector<MetricSupportRoleV1> allowed_metric_support_roles;
  std::vector<FamilyEvidenceSchemaV1> allowed_family_evidence_schemas;
  std::vector<FamilyEvidenceConformanceReportAnchorV1>
      family_evidence_conformance_report_anchors;
  ScientificConstructionPolicySchemaV1 scientific_construction_policy_schema;

  std::optional<LocalExecutableDeclarationV1> local_executable;
  ProviderTransportLimitsV1 transport_limits;
  Digest256 manifest_digest;

  friend bool operator==(const SurrogateProviderManifestV1&,
                         const SurrogateProviderManifestV1&) = default;
};

using SurrogateProviderManifest = SurrogateProviderManifestV1;

struct ProviderScientificContractProjectionV1 final {
  std::uint32_t projection_version;
  ProviderIdentityV1 provider;
  std::uint32_t parameter_schema_version;
  Digest256 parameter_schema_digest;
  ConstructionMethodV1 construction_method;
  SemanticTagV1 deployed_semantic_tag;
  RuntimeAccessTagV1 runtime_access_tag;
  PayloadClassV1 payload_class;
  std::vector<std::uint32_t> supported_build_request_versions;
  std::vector<std::uint32_t> supported_artifact_versions;
  std::vector<std::uint32_t> required_build_report_schema_versions;
  std::vector<RequiredMethodCounterV1> required_method_counters;
  SchedulerConstraintApplicabilityV1 optimizer_constraint_applicability;
  TargetAndArrivalScientificPrerequisitesV1
      target_and_arrival_scientific_prerequisites;
  MetricSupportManifest metric_clause_upper_envelope;
  std::vector<MetricSupportRoleV1> allowed_metric_support_roles;
  std::vector<FamilyEvidenceSchemaV1> allowed_family_evidence_schemas;
  ScientificConstructionPolicySchemaV1 scientific_construction_policy_schema;

  friend bool operator==(const ProviderScientificContractProjectionV1&,
                         const ProviderScientificContractProjectionV1&) =
      default;
};

class ProviderScientificContractDigest final {
 public:
  explicit ProviderScientificContractDigest(Digest256 value)
      : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const ProviderScientificContractDigest&,
                         const ProviderScientificContractDigest&) = default;

 private:
  Digest256 value_;
};

class ValidatedProviderManifest final {
 public:
  ValidatedProviderManifest(const ValidatedProviderManifest&) = default;
  ValidatedProviderManifest(ValidatedProviderManifest&&) noexcept = default;
  ValidatedProviderManifest& operator=(const ValidatedProviderManifest&) =
      default;
  ValidatedProviderManifest& operator=(ValidatedProviderManifest&&) noexcept =
      default;

  [[nodiscard]] const SurrogateProviderManifestV1& value() const noexcept {
    return value_;
  }
  [[nodiscard]] const ProviderScientificContractProjectionV1&
  scientific_projection() const noexcept {
    return scientific_projection_;
  }
  [[nodiscard]] const ProviderScientificContractDigest&
  scientific_contract_digest() const noexcept {
    return scientific_contract_digest_;
  }

 private:
  ValidatedProviderManifest(
      SurrogateProviderManifestV1 value,
      ProviderScientificContractProjectionV1 scientific_projection,
      ProviderScientificContractDigest scientific_contract_digest)
      : value_(std::move(value)),
        scientific_projection_(std::move(scientific_projection)),
        scientific_contract_digest_(std::move(scientific_contract_digest)) {}

  SurrogateProviderManifestV1 value_;
  ProviderScientificContractProjectionV1 scientific_projection_;
  ProviderScientificContractDigest scientific_contract_digest_;

  friend Result<ValidatedProviderManifest> validate_provider_manifest(
      const SurrogateProviderManifest&);
};

[[nodiscard]] Result<std::vector<std::byte>>
canonical_provider_manifest_bytes_v1(
    const SurrogateProviderManifestV1& manifest);
[[nodiscard]] Result<Digest256> digest_provider_manifest_v1(
    const SurrogateProviderManifestV1& manifest);
[[nodiscard]] Result<std::vector<std::byte>>
canonical_provider_scientific_contract_bytes_v1(
    const ProviderScientificContractProjectionV1& projection);
[[nodiscard]] Result<ProviderScientificContractDigest>
digest_provider_scientific_contract_v1(
    const ProviderScientificContractProjectionV1& projection);

// F-C15-01
[[nodiscard]] Result<ValidatedProviderManifest> validate_provider_manifest(
    const SurrogateProviderManifest& manifest);

}  // namespace mwperf
