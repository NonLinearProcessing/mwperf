#pragma once

#include <compare>
#include <cstdint>
#include <string>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/portable_scientific_scalar.hpp"
#include "mwperf/surrogate/three_bin_scalar_response.hpp"

namespace mwperf {

// The coordinate tag is part of the v1 wire contract.  The numeric member is
// interpreted as level zero, an exact positive level, or the first tail level
// according to the tag; validation closes the three domains below.
enum class FinitePrefixResponseCoordinateKindV1 : std::uint8_t {
  structural_level_zero,
  exact_level,
  constant_tail,
};

struct FinitePrefixResponseCoordinateV1 final {
  FinitePrefixResponseCoordinateKindV1 kind;
  BigNat level_or_tail_from;

  friend bool operator==(const FinitePrefixResponseCoordinateV1&,
                         const FinitePrefixResponseCoordinateV1&) = default;
  friend std::strong_ordering operator<=>(
      const FinitePrefixResponseCoordinateV1&,
      const FinitePrefixResponseCoordinateV1&) = default;
};

// A complete CP07.1 Built coefficient.  All five scientific scalars retain
// their binary64 representation; conversion to exact dyadics belongs to C16.
struct FinitePrefixCoefficientIdentificationV1 final {
  ArtifactObjectReferenceV1 coefficient_id;
  FinitePrefixResponseCoordinateV1 coordinate;
  PortableScientificScalar pooled_unserved_mass;
  PortableScientificScalar pooled_served_mass;
  PortableScientificScalar raw_point;
  std::vector<ArtifactObjectReferenceV1> family_evidence_envelope_ids;
  ProviderConformanceReportRef provider_conformance_report_ref;

  friend bool operator==(const FinitePrefixCoefficientIdentificationV1&,
                         const FinitePrefixCoefficientIdentificationV1&) =
      default;
};

struct FinitePrefixRawResponseProductV1 final {
  RawResponseProductId product_id;
  ProviderIdentityV1 provider;
  Digest256 request_digest;
  QueueId deployed_target;
  Digest256 configured_arrival_binding;
  Digest256 proposal_law_digest;
  BigNat response_cutoff;
  BigNat ensemble_count;
  BigNat window_length;
  std::vector<FinitePrefixCoefficientIdentificationV1> identifications;

  friend bool operator==(const FinitePrefixRawResponseProductV1&,
                         const FinitePrefixRawResponseProductV1&) = default;
};

// CP07.1 emits one simultaneous coefficient family.  The radius and common
// floating-point enclosure are retained verbatim beside the per-coordinate
// intervals and their existing family-evidence references.
struct FinitePrefixRawResponseEnvelopeV1 final {
  ArtifactObjectReferenceV1 envelope_id;
  RawResponseProductId source_product;
  Digest256 construction_law_digest;
  BigNat response_cutoff;
  std::vector<FinitePrefixResponseCoordinateV1> covered_coordinates;
  std::vector<PortableScientificScalar> lower;
  std::vector<PortableScientificScalar> upper;
  PortableScientificScalar concentration_radius_lower;
  PortableScientificScalar concentration_radius_upper;
  PortableScientificScalar floating_point_enclosure;
  std::string certification_method;
  RawEnvelopeCoverageV1 coverage;
  PopulationConditioningPremiseV1 population_conditioning_premise;
  TypedLabel frozen_evaluation_id;
  BigNat sample_size;
  RawEnvelopeScopeV1 scope;
  std::vector<ArtifactObjectReferenceV1> family_evidence_envelope_ids;

  friend bool operator==(const FinitePrefixRawResponseEnvelopeV1&,
                         const FinitePrefixRawResponseEnvelopeV1&) = default;
};

struct FinitePrefixConstantTailResponseV1 final {
  std::uint32_t payload_version;
  ArtifactObjectReferenceV1 response_row_id;
  QueueId deployed_target;
  Digest256 configured_arrival_binding;
  BigNat response_cutoff;
  FinitePrefixRawResponseProductV1 raw_response;
  RawResponseProductId deployed_response_product_id;
  std::vector<FinitePrefixRawResponseEnvelopeV1> raw_envelopes;

  friend bool operator==(const FinitePrefixConstantTailResponseV1&,
                         const FinitePrefixConstantTailResponseV1&) = default;
};

[[nodiscard]] Result<Digest256>
canonical_finite_prefix_constant_tail_response_row_digest_v1(
    const FinitePrefixConstantTailResponseV1& response);
[[nodiscard]] Result<Digest256>
canonical_finite_prefix_coefficient_identification_digest_v1(
    const FinitePrefixCoefficientIdentificationV1& identification);
[[nodiscard]] Result<Digest256>
canonical_finite_prefix_raw_response_product_digest_v1(
    const FinitePrefixRawResponseProductV1& product);
[[nodiscard]] Result<Digest256>
canonical_finite_prefix_raw_response_envelope_digest_v1(
    const FinitePrefixRawResponseEnvelopeV1& envelope);

}  // namespace mwperf
