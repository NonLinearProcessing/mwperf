#pragma once

#include "mwperf/config/source_node.hpp"
#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/metrics/metric_requirements.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf {

class SurrogateProvider;

// C16 deliberately preserves C03's source-aware object rather than exposing
// a third-party JSON value through the provider boundary.  Provider schemas
// must reject a non-object root with the authored pointer retained here.
using JsonObject = SourceNode;

// C14 and C15 already fixed the canonical construction-budget grammar.  The
// representation budget used for preview is that exact value, not a second
// independently hashed budget record.
using RepresentationBudget = ConstructionBudget;

// F-C16-07.  The provider operation is metadata-only: no build, callback,
// optimizer, sampler, decoder, file, or process is reachable through it.
[[nodiscard]] Result<PlugDescriptorPreview> preview_surrogate_descriptor(
    const SurrogateProvider& provider, const FrameworkProblemView& problem,
    const MetricRequirements& requirements,
    const RepresentationBudget& representation_budget,
    const ValidatedSurrogateParameters& parameters);

}  // namespace mwperf
