#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/core/non_scientific_limits.hpp"
#include "mwperf/metrics/capability_decision.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"

namespace mwperf {

class SurrogateBuildRequest;
class SurrogateProvider;
class SourceNode;
class ValidatedSurrogateParameters;

// C16's provider-owned parameter validator is the sole production issuer of
// this C15 carrier.  JsonObject is a C16 alias for SourceNode, so retaining the
// concrete source-node type here avoids introducing a second parameter tree.
[[nodiscard]] Result<ValidatedSurrogateParameters>
validate_surrogate_parameters(const SurrogateProvider&, const SourceNode&);

namespace artifact::detail {
[[nodiscard]] Result<void> verify_request_bindings_v1(
    const SurrogateBuildRequest&, const ValidatedProviderManifest&);
}

#if defined(MWPERF_C15_TEST_SEAMS)
namespace testing {
class C15ProtocolFixtureFactory;
}
#endif

enum class BudgetApplicabilityV1 : std::uint8_t {
  not_applicable,
  applicable,
};

// Presence is deliberately independent of numeric value: applicable zero is
// a real zero grant, while not_applicable carries no amount.
struct CountConstructionGrantV1 final {
  BudgetApplicabilityV1 applicability;
  std::optional<BigNat> amount;

  friend bool operator==(const CountConstructionGrantV1&,
                         const CountConstructionGrantV1&) = default;
};

struct ToleranceConstructionGrantV1 final {
  BudgetApplicabilityV1 applicability;
  std::optional<ExactRational> amount;

  friend bool operator==(const ToleranceConstructionGrantV1&,
                         const ToleranceConstructionGrantV1&) = default;
};

struct ConstructionBudget final {
  std::uint32_t schema_version;
  CountConstructionGrantV1 exact_optimizer_calls;
  CountConstructionGrantV1 optimizer_search_states;
  CountConstructionGrantV1 configured_generator_draws;
  ToleranceConstructionGrantV1 linear_residual_abs;
  ToleranceConstructionGrantV1 integration_abs;
  ToleranceConstructionGrantV1 tail_abs;
  ToleranceConstructionGrantV1 fixed_point_abs;

  friend bool operator==(const ConstructionBudget&,
                         const ConstructionBudget&) = default;
};

// Transport storage is not a scientific model parameter.  Retain one remote
// byte ceiling solely because the file/process APIs require a finite value;
// it is deliberately far above any realizable in-memory experiment and must
// not be used as a planning or scientific admission threshold.
inline constexpr std::size_t kSurrogateBuildProtocolV1MaximumRequestBytes =
    kNonScientificByteCeiling;
inline constexpr std::size_t kSurrogateBuildProtocolV1MaximumResultBytes =
    kNonScientificByteCeiling;

class ValidatedSurrogateParameters final {
 public:
  ValidatedSurrogateParameters(const ValidatedSurrogateParameters&) = default;
  ValidatedSurrogateParameters(ValidatedSurrogateParameters&&) noexcept =
      default;
  ValidatedSurrogateParameters& operator=(
      const ValidatedSurrogateParameters&) = default;
  ValidatedSurrogateParameters& operator=(
      ValidatedSurrogateParameters&&) noexcept = default;

  [[nodiscard]] const ProviderIdentityV1& provider() const noexcept {
    return provider_;
  }
  [[nodiscard]] std::uint32_t parameter_schema_version() const noexcept {
    return parameter_schema_version_;
  }
  [[nodiscard]] const Digest256& parameter_schema_digest() const noexcept {
    return parameter_schema_digest_;
  }
  [[nodiscard]] std::span<const std::byte> canonical_value_bytes()
      const noexcept {
    return canonical_value_bytes_;
  }
  [[nodiscard]] const Digest256& canonical_value_digest() const noexcept {
    return canonical_value_digest_;
  }
  [[nodiscard]] const std::shared_ptr<const void>& typed_value_owner()
      const noexcept {
    return typed_value_owner_;
  }

 private:
  ValidatedSurrogateParameters(ProviderIdentityV1 provider,
                               std::uint32_t parameter_schema_version,
                               Digest256 parameter_schema_digest,
                               std::vector<std::byte> canonical_value_bytes,
                               Digest256 canonical_value_digest,
                               std::shared_ptr<const void> typed_value_owner)
      : provider_(std::move(provider)),
        parameter_schema_version_(parameter_schema_version),
        parameter_schema_digest_(std::move(parameter_schema_digest)),
        canonical_value_bytes_(std::move(canonical_value_bytes)),
        canonical_value_digest_(std::move(canonical_value_digest)),
        typed_value_owner_(std::move(typed_value_owner)) {}

  ProviderIdentityV1 provider_;
  std::uint32_t parameter_schema_version_;
  Digest256 parameter_schema_digest_;
  std::vector<std::byte> canonical_value_bytes_;
  Digest256 canonical_value_digest_;
  std::shared_ptr<const void> typed_value_owner_;

  friend Result<ValidatedSurrogateParameters> validate_surrogate_parameters(
      const SurrogateProvider&, const SourceNode&);

#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

[[nodiscard]] Result<Digest256> digest_surrogate_parameter_values_v1(
    std::span<const std::byte> canonical_value_bytes);

struct BuildProviderBindingV1 final {
  ProviderIdentityV1 provider;
  std::uint32_t parameter_schema_version;
  ProviderScientificContractDigest provider_scientific_contract_digest;

  friend bool operator==(const BuildProviderBindingV1&,
                         const BuildProviderBindingV1&) = default;
};

struct RequestClassificationsV1 final {
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  SemanticTagV1 proposed_semantic_tag;
  RuntimeAccessTagV1 proposed_access_tag;
  PayloadClassTagV1 proposed_payload_tag;

  friend bool operator==(const RequestClassificationsV1&,
                         const RequestClassificationsV1&) = default;
};

struct BuildIdentityClassificationsV1 final {
  ConstructionMethodV1 construction_method;
  ProducerModeV1 producer_mode;
  SemanticTagV1 deployed_semantic_tag;
  RuntimeAccessTagV1 runtime_access_tag;
  PayloadClassTagV1 payload_tag;
  std::uint32_t payload_version;

  friend bool operator==(const BuildIdentityClassificationsV1&,
                         const BuildIdentityClassificationsV1&) = default;
};

// Exact C14 values copied into the request.  Other C14 planning data remains
// bound by the problem view, provider binding, and C14 contract integrity; it
// is not reconstructed from an opaque preview digest.
struct AcceptedCapabilityContractSnapshotV1 final {
  // Providers must be able to echo these C14 identities into direct metric
  // values without being handed the callback-bearing contract object.  They
  // are derived read-only metadata on the in-memory snapshot, not additional
  // fields in C15's frozen v1 canonical request grammar.  C15 validates the
  // source contract before constructing the snapshot, and artifact validation
  // compares each echoed identity with that source contract independently.
  Digest256 accepted_contract_digest;
  Digest256 normalized_metric_requirements_digest;
  MetricSupportManifest structural_metric_support_manifest;
  std::vector<QueueId> construction_target_scope;
  ConstructionPrerequisitesV1 construction_prerequisites;
  PreviewPoliciesV1 accepted_provider_policies;

  friend bool operator==(const AcceptedCapabilityContractSnapshotV1&,
                         const AcceptedCapabilityContractSnapshotV1&) =
      default;
};

struct BuildSubjectV1 final {
  std::uint32_t subject_version;
  std::vector<QueueId> ordered_deployed_targets;
  ConstructionGroupIdV1 construction_group_binding;

  friend bool operator==(const BuildSubjectV1&, const BuildSubjectV1&) =
      default;
};

// Seed-free precursor.  Its canonical form is fixed in the declaration order
// below and intentionally contains no BuildSeed or final request digest.
struct BuildIdentityV1 final {
  std::uint32_t build_identity_version;
  BuildProviderBindingV1 provider_binding;
  BuildIdentityClassificationsV1 classifications;
  FrameworkProblemView framework_problem_view;
  AcceptedCapabilityContractSnapshotV1 accepted_capability_contract;
  std::vector<std::byte> validated_parameter_values;
  ConstructionBudget construction_budget;
  BuildSubjectV1 build_subject;
  std::uint32_t build_request_protocol_version;
  std::uint32_t artifact_protocol_version;
  std::uint32_t required_build_report_schema;

  friend bool operator==(const BuildIdentityV1&, const BuildIdentityV1&) =
      default;
};

class SurrogateBuildRequestDigest final {
 public:
  explicit SurrogateBuildRequestDigest(Digest256 value)
      : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const SurrogateBuildRequestDigest&,
                         const SurrogateBuildRequestDigest&) = default;

 private:
  Digest256 value_;
};

class SurrogateBuildRequest final {
 public:
  SurrogateBuildRequest(const SurrogateBuildRequest&) = default;
  SurrogateBuildRequest(SurrogateBuildRequest&&) noexcept = default;
  SurrogateBuildRequest& operator=(const SurrogateBuildRequest&) = default;
  SurrogateBuildRequest& operator=(SurrogateBuildRequest&&) noexcept = default;

  [[nodiscard]] std::uint32_t protocol_version() const noexcept {
    return protocol_version_;
  }
  [[nodiscard]] const BuildIdentityDigest& build_identity_digest()
      const noexcept {
    return build_identity_digest_;
  }
  [[nodiscard]] const SurrogateBuildRequestDigest& request_digest()
      const noexcept {
    return request_digest_;
  }
  [[nodiscard]] const BuildProviderBindingV1& provider_binding()
      const noexcept {
    return provider_binding_;
  }
  [[nodiscard]] const RequestClassificationsV1& classifications()
      const noexcept {
    return classifications_;
  }
  [[nodiscard]] const FrameworkProblemView& framework_problem_view()
      const noexcept {
    return framework_problem_view_;
  }
  [[nodiscard]] const AcceptedCapabilityContractSnapshotV1&
  accepted_capability_contract() const noexcept {
    return accepted_capability_contract_;
  }
  [[nodiscard]] std::span<const std::byte> validated_parameters()
      const noexcept {
    return validated_parameters_;
  }
  [[nodiscard]] const ConstructionBudget& construction_budget()
      const noexcept {
    return construction_budget_;
  }
  [[nodiscard]] const BuildSeed& build_seed() const noexcept {
    return build_seed_;
  }
  [[nodiscard]] std::uint32_t required_build_report_schema() const noexcept {
    return required_build_report_schema_;
  }

 private:
  SurrogateBuildRequest(
      std::uint32_t protocol_version,
      BuildIdentityDigest build_identity_digest,
      SurrogateBuildRequestDigest request_digest,
      BuildProviderBindingV1 provider_binding,
      RequestClassificationsV1 classifications,
      FrameworkProblemView framework_problem_view,
      AcceptedCapabilityContractSnapshotV1 accepted_capability_contract,
      std::vector<std::byte> validated_parameters,
      ConstructionBudget construction_budget, BuildSeed build_seed,
      std::uint32_t required_build_report_schema)
      : protocol_version_(protocol_version),
        build_identity_digest_(std::move(build_identity_digest)),
        request_digest_(std::move(request_digest)),
        provider_binding_(std::move(provider_binding)),
        classifications_(classifications),
        framework_problem_view_(std::move(framework_problem_view)),
        accepted_capability_contract_(
            std::move(accepted_capability_contract)),
        validated_parameters_(std::move(validated_parameters)),
        construction_budget_(std::move(construction_budget)),
        build_seed_(std::move(build_seed)),
        required_build_report_schema_(required_build_report_schema) {}

  std::uint32_t protocol_version_;
  BuildIdentityDigest build_identity_digest_;
  SurrogateBuildRequestDigest request_digest_;
  BuildProviderBindingV1 provider_binding_;
  RequestClassificationsV1 classifications_;
  FrameworkProblemView framework_problem_view_;
  AcceptedCapabilityContractSnapshotV1 accepted_capability_contract_;
  std::vector<std::byte> validated_parameters_;
  ConstructionBudget construction_budget_;
  BuildSeed build_seed_;
  std::uint32_t required_build_report_schema_;

  friend Result<SurrogateBuildRequest> make_surrogate_build_request(
      const ValidatedProviderManifest&, const FrameworkProblemView&,
      const AcceptedCapabilityContract&,
      const ValidatedSurrogateParameters&, const ConstructionBudget&,
      const MasterSeed&);
  friend Result<void> artifact::detail::verify_request_bindings_v1(
      const SurrogateBuildRequest&, const ValidatedProviderManifest&);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

[[nodiscard]] Result<std::vector<std::byte>>
canonical_construction_budget_bytes_v1(const ConstructionBudget& budget);
[[nodiscard]] Result<Digest256> digest_construction_budget_v1(
    const ConstructionBudget& budget);
[[nodiscard]] Result<std::vector<std::byte>>
canonical_build_identity_bytes_v1(const BuildIdentityV1& identity);
[[nodiscard]] Result<BuildIdentityDigest> digest_build_identity_v1(
    const BuildIdentityV1& identity);
[[nodiscard]] Result<std::vector<std::byte>>
canonical_surrogate_build_request_bytes_v1(
    const SurrogateBuildRequest& request);

// F-C15-03.  The seed-free identity and C02 BuildSeed root are constructed
// internally and the request digest is computed last.
[[nodiscard]] Result<SurrogateBuildRequest> make_surrogate_build_request(
    const ValidatedProviderManifest& manifest,
    const FrameworkProblemView& problem_view,
    const AcceptedCapabilityContract& accepted_contract,
    const ValidatedSurrogateParameters& parameters,
    const ConstructionBudget& construction_budget,
    const MasterSeed& master_seed);

using SurrogateBuildRequestV1 = SurrogateBuildRequest;

}  // namespace mwperf
