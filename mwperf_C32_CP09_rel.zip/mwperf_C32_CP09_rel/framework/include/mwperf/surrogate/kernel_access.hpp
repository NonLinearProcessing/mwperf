#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/contracts/plug_descriptor.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/metrics/metric_support_manifest.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

class C17AuditedFrameworkMint;
class ValidatedSurrogatePlug;

class FiniteEnumeratedRowAccess;
class SparseRowAccess;
class NormalizedConditionalSamplerAccess;
class AnalyticTransformAccess;
class FiniteParameterAnalyticFamilyAccess;
class ProceduralResidenceGeneratorAccess;
class RawDirectDecoderAccess;

namespace sampling::detail {
class C24CoreAccess;
}

// Keep the runtime-access carrier visibly closed while allowing each
// alternative below to name the sole validating boundary as a friend.
using KernelAccess =
    std::variant<FiniteEnumeratedRowAccess, SparseRowAccess,
                 NormalizedConditionalSamplerAccess, AnalyticTransformAccess,
                 FiniteParameterAnalyticFamilyAccess,
                 ProceduralResidenceGeneratorAccess,
                 RawDirectDecoderAccess>;

[[nodiscard]] Result<KernelAccess> validate_kernel_access(
    const ValidatedSurrogatePlug& plug);

enum class ProbabilityMassKindV1 : std::uint8_t {
  exact_rational,
  canonical_binary64_bits,
};

// A binary64 probability retains its representation identity as raw bits.
// Construction is closed so neither double nor long double is an untagged
// route into a runtime row.
class CanonicalBinary64ProbabilityV1 final {
 public:
  CanonicalBinary64ProbabilityV1() = delete;

  [[nodiscard]] std::uint64_t bits() const noexcept { return bits_; }

  friend bool operator==(const CanonicalBinary64ProbabilityV1&,
                         const CanonicalBinary64ProbabilityV1&) = default;

 private:
  explicit CanonicalBinary64ProbabilityV1(const std::uint64_t bits) noexcept
      : bits_(bits) {}

  std::uint64_t bits_;
  friend class ProbabilityMass;
};

// One row mass plus the provider's structural-support assertion.  A zero mass
// may be retained as a non-support table cell, but it cannot claim positive
// structural support.
class ProbabilityMass final {
 public:
  ProbabilityMass() = delete;
  ProbabilityMass(const ProbabilityMass&) = default;
  ProbabilityMass(ProbabilityMass&& other)
      : value_(std::move(other.value_)),
        structural_support_(other.structural_support_) {
    // ExactRational moves leave the source as zero.  Clearing this flag keeps
    // that moved-from representation inside the validated probability domain.
    other.structural_support_ = false;
  }
  ProbabilityMass& operator=(const ProbabilityMass&) = default;
  ProbabilityMass& operator=(ProbabilityMass&& other) {
    if (this != &other) {
      value_ = std::move(other.value_);
      structural_support_ = other.structural_support_;
      other.structural_support_ = false;
    }
    return *this;
  }

  [[nodiscard]] static Result<ProbabilityMass> exact_rational(
      ExactRational value, bool structural_support) {
    if (!value.is_nonnegative() || value > ExactRational::one()) {
      return Result<ProbabilityMass>::failure(probability_diagnostic(
          "c16.probability_mass_out_of_range",
          "an exact row mass must lie in the closed interval [0,1]"));
    }
    if (structural_support && value.is_zero()) {
      return Result<ProbabilityMass>::failure(probability_diagnostic(
          "c16.claimed_positive_zero_mass",
          "a zero row mass cannot claim positive structural support"));
    }
    return Result<ProbabilityMass>::success(ProbabilityMass(
        Storage(std::in_place_type<ExactRational>, std::move(value)),
        structural_support));
  }

  [[nodiscard]] static Result<ProbabilityMass> canonical_binary64_bits(
      const std::uint64_t bits, const bool structural_support) {
    constexpr std::uint64_t sign_mask = UINT64_C(0x8000000000000000);
    constexpr std::uint64_t exponent_mask = UINT64_C(0x7ff0000000000000);
    constexpr std::uint64_t one_bits = UINT64_C(0x3ff0000000000000);

    if ((bits & sign_mask) != 0U) {
      return Result<ProbabilityMass>::failure(probability_diagnostic(
          bits == sign_mask ? "c16.noncanonical_negative_zero_mass"
                            : "c16.negative_binary64_mass",
          "a binary64 row mass must use a canonical nonnegative bit "
          "pattern"));
    }
    if ((bits & exponent_mask) == exponent_mask) {
      return Result<ProbabilityMass>::failure(probability_diagnostic(
          "c16.nonfinite_binary64_mass",
          "a binary64 row mass cannot be NaN or infinity"));
    }
    // Nonnegative finite IEEE-754 encodings are monotonically ordered by
    // their unsigned bit pattern.
    if (bits > one_bits) {
      return Result<ProbabilityMass>::failure(probability_diagnostic(
          "c16.probability_mass_out_of_range",
          "a binary64 row mass must lie in the closed interval [0,1]"));
    }
    if (structural_support && bits == 0U) {
      return Result<ProbabilityMass>::failure(probability_diagnostic(
          "c16.claimed_positive_zero_mass",
          "a zero row mass cannot claim positive structural support"));
    }
    auto binary64 = CanonicalBinary64ProbabilityV1(bits);
    return Result<ProbabilityMass>::success(
        ProbabilityMass(Storage(std::move(binary64)), structural_support));
  }

  [[nodiscard]] ProbabilityMassKindV1 kind() const noexcept {
    return std::holds_alternative<ExactRational>(value_)
               ? ProbabilityMassKindV1::exact_rational
               : ProbabilityMassKindV1::canonical_binary64_bits;
  }
  [[nodiscard]] bool structural_support() const noexcept {
    return structural_support_;
  }
  [[nodiscard]] const ExactRational* exact_rational_value() const noexcept {
    return std::get_if<ExactRational>(&value_);
  }
  [[nodiscard]] const CanonicalBinary64ProbabilityV1*
  binary64_value() const noexcept {
    return std::get_if<CanonicalBinary64ProbabilityV1>(&value_);
  }

  // Binary64 is decoded to the identical dyadic rational; no host floating
  // arithmetic participates in validation or row identity.
  [[nodiscard]] ExactRational exact_value() const {
    if (const auto* rational = std::get_if<ExactRational>(&value_)) {
      return *rational;
    }
    return binary64_bits_as_exact_rational(
        std::get<CanonicalBinary64ProbabilityV1>(value_).bits());
  }

  friend bool operator==(const ProbabilityMass&,
                         const ProbabilityMass&) = default;

 private:
  using Storage =
      std::variant<ExactRational, CanonicalBinary64ProbabilityV1>;

  ProbabilityMass(Storage value, const bool structural_support)
      : value_(std::move(value)), structural_support_(structural_support) {}

  [[nodiscard]] static Diagnostic probability_diagnostic(
      std::string code, std::string message) {
    return Diagnostic{DiagnosticCategory::input_validation,
                      std::move(code),
                      std::move(message),
                      std::nullopt,
                      std::nullopt,
                      {}};
  }

  [[nodiscard]] static ExactRational binary64_bits_as_exact_rational(
      const std::uint64_t bits) {
    constexpr std::uint64_t fraction_mask = UINT64_C(0x000fffffffffffff);
    const std::uint64_t exponent_bits =
        (bits >> 52U) & UINT64_C(0x7ff);
    const std::uint64_t fraction = bits & fraction_mask;
    if (exponent_bits == 0U && fraction == 0U) {
      return ExactRational::zero();
    }

    BigInt significand;
    int binary_exponent;
    if (exponent_bits == 0U) {
      significand = fraction;
      binary_exponent = -1074;
    } else {
      significand = (BigInt(1) << 52U) + fraction;
      binary_exponent = static_cast<int>(exponent_bits) - 1023 - 52;
    }

    BigInt numerator = std::move(significand);
    BigInt denominator = 1;
    if (binary_exponent >= 0) {
      numerator <<= static_cast<unsigned int>(binary_exponent);
    } else {
      denominator <<= static_cast<unsigned int>(-binary_exponent);
    }
    auto exact =
        ExactRational::make(std::move(numerator), std::move(denominator));
    return std::move(exact).value();
  }

  Storage value_;
  bool structural_support_;
};

// Codec-bound, canonical runtime values keep access callbacks independent of
// any later compiled-plug or backend type.
struct CanonicalRuntimeValueV1 final {
  CodecIdentityV1 codec;
  std::vector<std::byte> canonical_value;

  friend bool operator==(const CanonicalRuntimeValueV1&,
                         const CanonicalRuntimeValueV1&) = default;
};

struct KernelTransitionV1 final {
  CanonicalRuntimeValueV1 successor_state;
  std::vector<CanonicalRuntimeValueV1> ordered_marks;

  friend bool operator==(const KernelTransitionV1&,
                         const KernelTransitionV1&) = default;
};

struct KernelRowAtomV1 final {
  KernelTransitionV1 transition;
  ProbabilityMass mass;

  friend bool operator==(const KernelRowAtomV1&,
                         const KernelRowAtomV1&) = default;
};

using KernelOperationIdV1 = StrongId<"c16_kernel_operation_v1">;
using RuntimeDecoderIdV1 = StrongId<"c16_runtime_decoder_v1">;

struct TransitionGeneratorOperationIdentityV1 final {
  KernelOperationIdV1 operation_id;
  std::uint32_t operation_version;

  friend bool operator==(const TransitionGeneratorOperationIdentityV1&,
                         const TransitionGeneratorOperationIdentityV1&) =
      default;
};

// Only row-valued access has a successor-state/mark shape.  Analytic,
// residence-word, and direct-metric operations below deliberately use
// different callback-free shapes so they cannot masquerade as state
// transitions merely to satisfy one generic record.
struct TransitionKernelAccessShapeV1 final {
  CodecIdentityV1 conditioning_state_codec;
  CodecIdentityV1 successor_state_codec;
  std::vector<CodecIdentityV1> ordered_mark_codecs;
  std::optional<std::size_t> maximum_row_atoms;
  // Required exactly when a temporal event contract uses a row/sampler
  // access as its event-word generator.  Non-temporal rows leave it absent.
  std::optional<TransitionGeneratorOperationIdentityV1>
      event_generator_identity;

  friend bool operator==(const TransitionKernelAccessShapeV1&,
                         const TransitionKernelAccessShapeV1&) = default;
};

struct AnalyticTransformAccessShapeV1 final {
  CodecIdentityV1 argument_codec;
  CodecIdentityV1 result_codec;

  friend bool operator==(const AnalyticTransformAccessShapeV1&,
                         const AnalyticTransformAccessShapeV1&) = default;
};

struct FiniteParameterAnalyticFamilyAccessShapeV1 final {
  CodecIdentityV1 argument_codec;
  CodecIdentityV1 response_codec;

  friend bool operator==(
      const FiniteParameterAnalyticFamilyAccessShapeV1&,
      const FiniteParameterAnalyticFamilyAccessShapeV1&) = default;
};

struct ResidenceGeneratorOperationIdentityV1 final {
  KernelOperationIdV1 operation_id;
  std::uint32_t operation_version;
  CodecIdentityV1 event_schema;

  friend bool operator==(const ResidenceGeneratorOperationIdentityV1&,
                         const ResidenceGeneratorOperationIdentityV1&) =
      default;
};

struct ResidenceGeneratorAccessShapeV1 final {
  CodecIdentityV1 entrance_state_codec;
  CodecIdentityV1 continuation_state_codec;
  CodecIdentityV1 terminal_state_codec;
  CodecIdentityV1 reentry_state_codec;
  std::vector<CodecIdentityV1> ordered_mark_codecs;
  std::optional<std::size_t> maximum_residence_slots;

  friend bool operator==(const ResidenceGeneratorAccessShapeV1&,
                         const ResidenceGeneratorAccessShapeV1&) = default;
};

struct GeneratedResidenceSlotV1 final {
  CanonicalRuntimeValueV1 predecision_state;
  KernelTransitionV1 completed_edge;

  friend bool operator==(const GeneratedResidenceSlotV1&,
                         const GeneratedResidenceSlotV1&) = default;
};

// A procedural residence result keeps the complete joint word together.
// C17 can therefore check positive duration, every ordered mark, and the
// terminal/re-entry maps without reconstructing those objects from unrelated
// marginals or an opaque byte string.
struct GeneratedResidenceWordV1 final {
  BigNat duration;
  std::vector<GeneratedResidenceSlotV1> slots;
  CanonicalRuntimeValueV1 terminal_state;
  CanonicalRuntimeValueV1 reentry_state;

  friend bool operator==(const GeneratedResidenceWordV1&,
                         const GeneratedResidenceWordV1&) = default;
};

using EnumeratedRowCallbackV1 =
    std::function<Result<std::vector<KernelRowAtomV1>>(
        const CanonicalRuntimeValueV1&)>;
using ConditionalSamplerCallbackV1 =
    std::function<Result<KernelTransitionV1>(const CanonicalRuntimeValueV1&,
                                             DeterministicRng&)>;
// C17 supplies this authority together with a normalized sampler.  It checks
// semantic properties that cannot be expressed by codec identities alone:
// value domains of decoded marks, exact-coordinate ownership and updates,
// reveal-stage restrictions, and any common projection shared with the
// conditioning row.  C24 invokes a fresh copy before publishing any sampled
// or enumerated atom.
using ConditionalSampleValidatorV1 =
    std::function<Result<void>(const CanonicalRuntimeValueV1&,
                               const KernelTransitionV1&)>;

// C24 consumes these declarations only after C17 has bound them into a V0
// seal. They remain part of the C16 raw access so C17 can reject an
// incomplete generator structurally without ever executing its stochastic
// callback.
enum class ConditionalSamplerRevealStageV1 : std::uint8_t {
  prearrival_residual,
  postarrival_residual,
  generic_row_residual,
};

enum class ConditionalSampleDependenceV1 : std::uint8_t {
  iid_cold_replications,
  correlated_trace,
  iid_proposal,
};

enum class ConditionalSupportKindV1 : std::uint8_t {
  finite_declared,
  membership_query,
};

enum class SamplerEvidenceScopeV1 : std::uint8_t {
  declared,
  construction_enforced,
  independently_audited,
};

// Typed origin of the deployed runtime samples.  This is provenance only:
// no enumerator value upgrades normalization, termination, V1, or V2
// evidence, and C24 preserves it without inferring a stronger claim.
enum class RuntimeSamplingProvenanceV1 : std::uint8_t {
  deployed_generator,
  physical_trace,
  arrival_only_replay,
  modified_compatible_state,
  proposal,
};

// V1 and V2 are deliberately distinct closed scope vocabularies.  A V1
// witness is only a current-row physical-realizability statement; a V2
// witness is a marked-path/dynamic-lift statement.  Neither is established
// by C24 sampling.
enum class SamplerV1EvidenceScopeV1 : std::uint8_t {
  none,
  row_conditional,
};

enum class SamplerV2EvidenceScopeV1 : std::uint8_t {
  none,
  marked_path_dynamic_lift,
};

struct ConditionalSamplerContractV1 final {
  std::uint32_t schema_version{1U};
  ConditionalSamplerRevealStageV1 reveal_stage{
      ConditionalSamplerRevealStageV1::generic_row_residual};
  ConditionalSampleDependenceV1 dependence{
      ConditionalSampleDependenceV1::iid_cold_replications};
  ConditionalSupportKindV1 support_kind{
      ConditionalSupportKindV1::membership_query};
  std::optional<std::size_t> finite_support_cardinality;
  Digest256 persistent_state_schema;
  Digest256 support_identity;
  Digest256 proposal_law_identity;
  Digest256 residual_schema;
  Digest256 output_schema;
  Digest256 configured_arrival_law;
  std::optional<Digest256> common_projection_identity;
  bool normalized_probability_law{false};
  bool almost_sure_return{false};
  bool persistent_memory_is_explicit{false};
  bool no_hidden_warm_state{false};
  bool prearrival_excludes_fresh_arrival{false};
  SamplerEvidenceScopeV1 normalization_evidence{
      SamplerEvidenceScopeV1::declared};
  SamplerEvidenceScopeV1 termination_evidence{
      SamplerEvidenceScopeV1::declared};
  SamplerV1EvidenceScopeV1 v1_evidence_scope{
      SamplerV1EvidenceScopeV1::none};
  std::optional<Digest256> v1_evidence_reference;
  SamplerV2EvidenceScopeV1 v2_evidence_scope{
      SamplerV2EvidenceScopeV1::none};
  std::optional<Digest256> v2_evidence_reference;
  std::optional<Digest256> foreign_construction_evidence;
  RuntimeSamplingProvenanceV1 runtime_provenance{
      RuntimeSamplingProvenanceV1::deployed_generator};

  friend bool operator==(const ConditionalSamplerContractV1&,
                         const ConditionalSamplerContractV1&) = default;
};

using ConditionalSupportEnumeratorV1 =
    std::function<Result<std::vector<KernelTransitionV1>>(
        const CanonicalRuntimeValueV1&)>;
using ConditionalSupportQueryV1 =
    std::function<Result<bool>(const CanonicalRuntimeValueV1&,
                               const KernelTransitionV1&)>;

enum class ImportanceWeightRepresentationV1 : std::uint8_t {
  direct_nonnegative,
  log_nonnegative,
};

enum class ImportanceTargetKindV1 : std::uint8_t {
  transition_row,
  stationary_occupation,
};

struct ImportanceWeightV1 final {
  ImportanceWeightRepresentationV1 representation;
  long double value;
};

struct ConditionalTargetRatioContractV1 final {
  std::uint32_t schema_version{1U};
  ImportanceTargetKindV1 target_kind{
      ImportanceTargetKindV1::transition_row};
  Digest256 target_law_identity;
  Digest256 metric_target_digest;
  Digest256 reward_decoder_digest;
  Digest256 residual_schema;
  Digest256 output_schema;
  bool proposal_dominates_target{false};
  bool positive_finite_weight_mean{false};
  bool weighted_reward_integrable{false};
  bool iid_proposal{false};
  bool weighted_second_moment{false};
  bool transition_ratio_only{true};

  friend bool operator==(const ConditionalTargetRatioContractV1&,
                         const ConditionalTargetRatioContractV1&) = default;
};

using ConditionalTargetRatioCallbackV1 =
    std::function<Result<ImportanceWeightV1>(
        const CanonicalRuntimeValueV1&, const KernelTransitionV1&)>;

struct ExactInnovationAtomV1 final {
  KernelTransitionV1 completed_sample;
  ExactRational probability;

  friend bool operator==(const ExactInnovationAtomV1&,
                         const ExactInnovationAtomV1&) = default;
};

struct ConditionalExactInnovationContractV1 final {
  std::uint32_t schema_version{1U};
  Digest256 representation_identity;
  Digest256 metric_target_digest;
  Digest256 configured_arrival_law;
  Digest256 reward_decoder_digest;
  Digest256 residual_schema;
  Digest256 output_schema;
  bool configured_joint_innovation{false};
  ExactRational maximum_absolute_integration_error;

  friend bool operator==(const ConditionalExactInnovationContractV1&,
                         const ConditionalExactInnovationContractV1&) =
      default;
};

using ConditionalExactInnovationCallbackV1 =
    std::function<Result<std::vector<ExactInnovationAtomV1>>(
        const CanonicalRuntimeValueV1&, const KernelTransitionV1&)>;
using AnalyticTransformCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const RuntimeDecoderIdV1&, const CanonicalRuntimeValueV1&,
        const ExactRational&)>;
using AnalyticFamilyCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const CanonicalRuntimeValueV1&)>;
using ResidenceGeneratorCallbackV1 =
    std::function<Result<GeneratedResidenceWordV1>(
        const CanonicalRuntimeValueV1&, DeterministicRng&)>;
using RawDirectDecoderCallbackV1 =
    std::function<Result<CanonicalRuntimeValueV1>(
        const CanonicalRuntimeValueV1&)>;
using RawDirectRequestEncoderV1 =
    std::function<Result<CanonicalRuntimeValueV1>(const MetricRequest&)>;
using RawDirectResultValidatorV1 = std::function<Result<void>(
    const ExactMetricDecoderKeyV1&, const CodecIdentityV1&,
    std::span<const std::byte>)>;

namespace kernel_access_detail {

// Access values store an immutable, never-invoked operation prototype.
// Copying an access value therefore copies only immutable ownership.  The C17
// friend obtains a fresh std::function copy for its audited seal instead of
// sharing a live mutable callable cursor across access values or invocations.
// A malicious callable can still smuggle mutable state through an external
// pointer; C17's replay audit remains responsible for detecting that behavior.
template <typename Operation>
class ImmutableOperationPrototypeV1 final {
 public:
  explicit ImmutableOperationPrototypeV1(Operation operation)
      : operation_(
            std::make_shared<const Operation>(std::move(operation))) {}

  [[nodiscard]] bool present() const noexcept {
    return operation_ && static_cast<bool>(*operation_);
  }

  [[nodiscard]] Operation fresh_copy() const { return *operation_; }

 private:
  [[nodiscard]] bool shares_operation_with(
      const ImmutableOperationPrototypeV1& other) const noexcept {
    return operation_ && other.operation_ &&
           !operation_.owner_before(other.operation_) &&
           !other.operation_.owner_before(operation_);
  }

  std::shared_ptr<const Operation> operation_;
  friend class ::mwperf::C17AuditedFrameworkMint;
  friend class ::mwperf::sampling::detail::C24CoreAccess;
};

}  // namespace kernel_access_detail

class FiniteEnumeratedRowAccess final {
 public:
  FiniteEnumeratedRowAccess(TransitionKernelAccessShapeV1 shape,
                            EnumeratedRowCallbackV1 row)
      : shape_(std::move(shape)), operation_(std::move(row)) {}
  [[nodiscard]] const TransitionKernelAccessShapeV1& shape() const noexcept {
    return shape_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EnumeratedRowCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  TransitionKernelAccessShapeV1 shape_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EnumeratedRowCallbackV1>
      operation_;
  friend class C17AuditedFrameworkMint;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

class SparseRowAccess final {
 public:
  SparseRowAccess(TransitionKernelAccessShapeV1 shape,
                  EnumeratedRowCallbackV1 row)
      : shape_(std::move(shape)), operation_(std::move(row)) {}
  [[nodiscard]] const TransitionKernelAccessShapeV1& shape() const noexcept {
    return shape_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] EnumeratedRowCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  TransitionKernelAccessShapeV1 shape_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      EnumeratedRowCallbackV1>
      operation_;
  friend class C17AuditedFrameworkMint;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

class NormalizedConditionalSamplerAccess final {
 public:
  NormalizedConditionalSamplerAccess(TransitionKernelAccessShapeV1 shape,
                                     ConditionalSamplerCallbackV1 sampler)
      : shape_(std::move(shape)),
        operation_(std::move(sampler)),
        sample_validator_(ConditionalSampleValidatorV1{}) {}
  NormalizedConditionalSamplerAccess(
      TransitionKernelAccessShapeV1 shape,
      ConditionalSamplerCallbackV1 sampler,
      ConditionalSamplerContractV1 contract,
      ConditionalSampleValidatorV1 sample_validator,
      ConditionalSupportEnumeratorV1 support_enumerator,
      ConditionalSupportQueryV1 support_query,
      std::optional<ConditionalTargetRatioContractV1> ratio_contract =
          std::nullopt,
      ConditionalTargetRatioCallbackV1 ratio = {},
      std::optional<ConditionalExactInnovationContractV1>
          innovation_contract = std::nullopt,
      ConditionalExactInnovationCallbackV1 innovation = {})
      : shape_(std::move(shape)),
        operation_(std::move(sampler)),
        contract_(std::move(contract)),
        sample_validator_(std::move(sample_validator)),
        support_enumerator_(
            kernel_access_detail::ImmutableOperationPrototypeV1<
                ConditionalSupportEnumeratorV1>(
                std::move(support_enumerator))),
        support_query_(
            kernel_access_detail::ImmutableOperationPrototypeV1<
                ConditionalSupportQueryV1>(std::move(support_query))),
        ratio_contract_(std::move(ratio_contract)),
        ratio_(kernel_access_detail::ImmutableOperationPrototypeV1<
               ConditionalTargetRatioCallbackV1>(std::move(ratio))),
        innovation_contract_(std::move(innovation_contract)),
        innovation_(kernel_access_detail::ImmutableOperationPrototypeV1<
                    ConditionalExactInnovationCallbackV1>(
                    std::move(innovation))) {}
  [[nodiscard]] const TransitionKernelAccessShapeV1& shape() const noexcept {
    return shape_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }
  [[nodiscard]] const std::optional<ConditionalSamplerContractV1>&
  contract() const noexcept {
    return contract_;
  }
  [[nodiscard]] const std::optional<ConditionalTargetRatioContractV1>&
  ratio_contract() const noexcept {
    return ratio_contract_;
  }
  [[nodiscard]] const std::optional<ConditionalExactInnovationContractV1>&
  innovation_contract() const noexcept {
    return innovation_contract_;
  }
  [[nodiscard]] bool has_support_enumerator() const noexcept {
    return support_enumerator_.has_value() &&
           support_enumerator_->present();
  }
  [[nodiscard]] bool has_sample_validator() const noexcept {
    return sample_validator_.present();
  }
  [[nodiscard]] bool has_support_query() const noexcept {
    return support_query_.has_value() && support_query_->present();
  }
  [[nodiscard]] bool has_ratio_operation() const noexcept {
    return ratio_.has_value() && ratio_->present();
  }
  [[nodiscard]] bool has_innovation_operation() const noexcept {
    return innovation_.has_value() && innovation_->present();
  }

 private:
  [[nodiscard]] ConditionalSamplerCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  TransitionKernelAccessShapeV1 shape_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      ConditionalSamplerCallbackV1>
      operation_;
  std::optional<ConditionalSamplerContractV1> contract_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      ConditionalSampleValidatorV1>
      sample_validator_;
  std::optional<kernel_access_detail::ImmutableOperationPrototypeV1<
      ConditionalSupportEnumeratorV1>> support_enumerator_;
  std::optional<kernel_access_detail::ImmutableOperationPrototypeV1<
      ConditionalSupportQueryV1>> support_query_;
  std::optional<ConditionalTargetRatioContractV1> ratio_contract_;
  std::optional<kernel_access_detail::ImmutableOperationPrototypeV1<
      ConditionalTargetRatioCallbackV1>> ratio_;
  std::optional<ConditionalExactInnovationContractV1> innovation_contract_;
  std::optional<kernel_access_detail::ImmutableOperationPrototypeV1<
      ConditionalExactInnovationCallbackV1>> innovation_;
  friend class C17AuditedFrameworkMint;
  friend class sampling::detail::C24CoreAccess;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

class AnalyticTransformAccess final {
 public:
  AnalyticTransformAccess(AnalyticTransformAccessShapeV1 shape,
                          std::vector<RuntimeDecoderIdV1> decoder_ids,
                          AnalyticTransformCallbackV1 transform)
      : shape_(std::move(shape)),
        decoder_ids_(std::move(decoder_ids)),
        operation_(std::move(transform)) {}
  [[nodiscard]] const AnalyticTransformAccessShapeV1& shape() const noexcept {
    return shape_;
  }
  [[nodiscard]] std::span<const RuntimeDecoderIdV1> decoder_ids()
      const noexcept {
    return decoder_ids_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] AnalyticTransformCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  AnalyticTransformAccessShapeV1 shape_;
  std::vector<RuntimeDecoderIdV1> decoder_ids_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      AnalyticTransformCallbackV1>
      operation_;
  friend class C17AuditedFrameworkMint;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

struct AnalyticFamilyIdentityV1 final {
  std::string family_id;
  std::uint32_t family_version;
  CodecIdentityV1 parameter_schema;
  CodecIdentityV1 domain_schema;

  friend bool operator==(const AnalyticFamilyIdentityV1&,
                         const AnalyticFamilyIdentityV1&) = default;
};

class FiniteParameterAnalyticFamilyAccess final {
 public:
  FiniteParameterAnalyticFamilyAccess(
      FiniteParameterAnalyticFamilyAccessShapeV1 shape,
      AnalyticFamilyIdentityV1 family,
      AnalyticFamilyCallbackV1 evaluator)
      : shape_(std::move(shape)),
        family_(std::move(family)),
        operation_(std::move(evaluator)) {}
  [[nodiscard]] const FiniteParameterAnalyticFamilyAccessShapeV1& shape()
      const noexcept {
    return shape_;
  }
  [[nodiscard]] const AnalyticFamilyIdentityV1& family() const noexcept {
    return family_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] AnalyticFamilyCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  FiniteParameterAnalyticFamilyAccessShapeV1 shape_;
  AnalyticFamilyIdentityV1 family_;
  kernel_access_detail::ImmutableOperationPrototypeV1<AnalyticFamilyCallbackV1>
      operation_;
  friend class C17AuditedFrameworkMint;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

class ProceduralResidenceGeneratorAccess final {
 public:
  ProceduralResidenceGeneratorAccess(
      ResidenceGeneratorAccessShapeV1 shape,
      ResidenceGeneratorOperationIdentityV1 operation_identity,
      bool positive_residence_declared,
      ResidenceGeneratorCallbackV1 generator)
      : shape_(std::move(shape)),
        operation_identity_(std::move(operation_identity)),
        positive_residence_declared_(positive_residence_declared),
        operation_(std::move(generator)) {}
  [[nodiscard]] const ResidenceGeneratorAccessShapeV1& shape()
      const noexcept {
    return shape_;
  }
  [[nodiscard]] const ResidenceGeneratorOperationIdentityV1&
  operation_identity() const noexcept {
    return operation_identity_;
  }
  [[nodiscard]] bool positive_residence_declared() const noexcept {
    return positive_residence_declared_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return operation_.present();
  }

 private:
  [[nodiscard]] ResidenceGeneratorCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }

  ResidenceGeneratorAccessShapeV1 shape_;
  ResidenceGeneratorOperationIdentityV1 operation_identity_;
  bool positive_residence_declared_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      ResidenceGeneratorCallbackV1>
      operation_;
  friend class C17AuditedFrameworkMint;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

struct RawDirectDecoderDomainV1 final {
  ExactMetricDecoderDomainV1 metric_domain;
  Digest256 canonical_request_domain_digest;
  // Exact identity of the C15 build request that produced the decoder data.
  // A normalized metric domain alone does not bind parameters, budget, seed,
  // or the concrete build attempt.
  Digest256 build_request_digest;
  // C15's TargetSelection identity includes its construction-group binding;
  // the exact ordered targets below are a separate C16 execution-domain
  // identity and must never be substituted for it.
  Digest256 target_selection_digest;
  Digest256 ordered_target_digest;
  Digest256 selection_digest;
  Digest256 configured_arrival_digest;
  Digest256 accepted_contract_digest;
  CodecIdentityV1 request_codec;
  CodecIdentityV1 result_codec;

  friend bool operator==(const RawDirectDecoderDomainV1&,
                         const RawDirectDecoderDomainV1&) = default;
};

// This exact operation triple is deliberately not exposed by an accessor.
// C17 is the sole production consumer and moves fresh immutable copies into a
// V0-audited seal before any direct metric execution is possible.
class RawDirectDecoderAccess final {
 public:
  RawDirectDecoderAccess(RawDirectDecoderDomainV1 domain,
                         RawDirectRequestEncoderV1 request_encoder,
                         RawDirectDecoderCallbackV1 decoder,
                         RawDirectResultValidatorV1 result_validator)
      : domain_(std::move(domain)),
        request_encoder_(std::move(request_encoder)),
        operation_(std::move(decoder)),
        result_validator_(std::move(result_validator)) {}
  [[nodiscard]] const RawDirectDecoderDomainV1& domain() const noexcept {
    return domain_;
  }
  [[nodiscard]] bool has_operation() const noexcept {
    return request_encoder_.present() && operation_.present() &&
           result_validator_.present();
  }

 private:
  [[nodiscard]] RawDirectRequestEncoderV1 fresh_request_encoder() const {
    return request_encoder_.fresh_copy();
  }
  [[nodiscard]] RawDirectDecoderCallbackV1 fresh_operation() const {
    return operation_.fresh_copy();
  }
  [[nodiscard]] RawDirectResultValidatorV1 fresh_result_validator() const {
    return result_validator_.fresh_copy();
  }

  RawDirectDecoderDomainV1 domain_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      RawDirectRequestEncoderV1>
      request_encoder_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      RawDirectDecoderCallbackV1>
      operation_;
  kernel_access_detail::ImmutableOperationPrototypeV1<
      RawDirectResultValidatorV1>
      result_validator_;
  friend class C17AuditedFrameworkMint;
  friend Result<KernelAccess> validate_kernel_access(
      const ValidatedSurrogatePlug& plug);
};

[[nodiscard]] inline RuntimeAccessTagV1 runtime_access_tag_v1(
    const KernelAccess& access) noexcept {
  return std::visit(
      [](const auto& alternative) noexcept {
        using Alternative = std::decay_t<decltype(alternative)>;
        if constexpr (std::is_same_v<Alternative,
                                     FiniteEnumeratedRowAccess>) {
          return RuntimeAccessTagV1::finite_enumerated_row;
        } else if constexpr (std::is_same_v<Alternative, SparseRowAccess>) {
          return RuntimeAccessTagV1::sparse_row;
        } else if constexpr (
            std::is_same_v<Alternative,
                           NormalizedConditionalSamplerAccess>) {
          return RuntimeAccessTagV1::normalized_conditional_sampler;
        } else if constexpr (std::is_same_v<Alternative,
                                            AnalyticTransformAccess>) {
          return RuntimeAccessTagV1::analytic_transform;
        } else if constexpr (
            std::is_same_v<Alternative,
                           FiniteParameterAnalyticFamilyAccess>) {
          return RuntimeAccessTagV1::finite_parameter_analytic_family;
        } else if constexpr (
            std::is_same_v<Alternative,
                           ProceduralResidenceGeneratorAccess>) {
          return RuntimeAccessTagV1::procedural_residence_generator;
        } else {
          return RuntimeAccessTagV1::direct_metric_decoder;
        }
      },
      access);
}

namespace kernel_access_detail {

[[nodiscard]] inline Diagnostic access_diagnostic(std::string code,
                                                  std::string message) {
  return Diagnostic{DiagnosticCategory::input_validation,
                    std::move(code),
                    std::move(message),
                    std::nullopt,
                    std::nullopt,
                    {}};
}

[[nodiscard]] inline bool valid_codec(const CodecIdentityV1& codec) {
  return !codec.id.empty() && codec.version != 0U;
}

[[nodiscard]] inline bool valid_shape(
    const TransitionKernelAccessShapeV1& shape) {
  if (!valid_codec(shape.conditioning_state_codec) ||
      !valid_codec(shape.successor_state_codec) ||
      (shape.maximum_row_atoms.has_value() &&
       *shape.maximum_row_atoms == 0U) ||
      (shape.event_generator_identity.has_value() &&
       shape.event_generator_identity->operation_version == 0U)) {
    return false;
  }
  for (const CodecIdentityV1& codec : shape.ordered_mark_codecs) {
    if (!valid_codec(codec)) {
      return false;
    }
  }
  return true;
}

[[nodiscard]] inline bool valid_shape(
    const AnalyticTransformAccessShapeV1& shape) {
  return valid_codec(shape.argument_codec) && valid_codec(shape.result_codec);
}

[[nodiscard]] inline bool valid_shape(
    const FiniteParameterAnalyticFamilyAccessShapeV1& shape) {
  return valid_codec(shape.argument_codec) &&
         valid_codec(shape.response_codec);
}

[[nodiscard]] inline bool valid_shape(
    const ResidenceGeneratorAccessShapeV1& shape) {
  if (!valid_codec(shape.entrance_state_codec) ||
      !valid_codec(shape.continuation_state_codec) ||
      !valid_codec(shape.terminal_state_codec) ||
      !valid_codec(shape.reentry_state_codec) ||
      (shape.maximum_residence_slots.has_value() &&
       *shape.maximum_residence_slots == 0U)) {
    return false;
  }
  return std::all_of(shape.ordered_mark_codecs.begin(),
                     shape.ordered_mark_codecs.end(), valid_codec);
}

[[nodiscard]] inline bool nonzero_digest(const Digest256& digest) noexcept {
  for (const std::byte value : digest.bytes()) {
    if (value != std::byte{0}) {
      return true;
    }
  }
  return false;
}

}  // namespace kernel_access_detail

// C17 applies this predicate to an operation result before it can enter a
// seal.  It is deliberately callback-free and checks only the complete typed
// residence-word shape supplied by C16.
[[nodiscard]] inline Result<void> validate_generated_residence_word_shape_v1(
    const GeneratedResidenceWordV1& word,
    const ResidenceGeneratorAccessShapeV1& shape) {
  if (!kernel_access_detail::valid_shape(shape) || word.duration.is_zero() ||
      word.duration.value() != BigInt(word.slots.size()) ||
      (shape.maximum_residence_slots.has_value() &&
       word.slots.size() > *shape.maximum_residence_slots)) {
    return Result<void>::failure(kernel_access_detail::access_diagnostic(
        "c16.invalid_generated_residence_duration",
        "a generated residence word must have positive duration equal to "
        "its bounded slot count"));
  }

  for (const GeneratedResidenceSlotV1& slot : word.slots) {
    if (slot.predecision_state.codec != shape.continuation_state_codec ||
        slot.completed_edge.successor_state.codec !=
            shape.continuation_state_codec ||
        slot.completed_edge.ordered_marks.size() !=
            shape.ordered_mark_codecs.size()) {
      return Result<void>::failure(kernel_access_detail::access_diagnostic(
          "c16.invalid_generated_residence_slot",
          "each generated slot must use the declared continuation-state "
          "and ordered-mark codecs"));
    }
    for (std::size_t mark_index = 0U;
         mark_index < shape.ordered_mark_codecs.size(); ++mark_index) {
      if (slot.completed_edge.ordered_marks[mark_index].codec !=
          shape.ordered_mark_codecs[mark_index]) {
        return Result<void>::failure(kernel_access_detail::access_diagnostic(
            "c16.invalid_generated_residence_mark",
            "generated residence marks must match their declared ordered "
            "codecs"));
      }
    }
  }
  if (word.terminal_state.codec != shape.terminal_state_codec ||
      word.reentry_state.codec != shape.reentry_state_codec) {
    return Result<void>::failure(kernel_access_detail::access_diagnostic(
        "c16.invalid_generated_residence_boundary",
        "generated terminal and re-entry values must use their declared "
        "codecs"));
  }
  return Result<void>::success();
}

// This predicate is intentionally structural and side-effect free.  It checks
// std::function presence via operator bool and never invokes a callback,
// normalizes a row, or advances an RNG.
[[nodiscard]] inline Result<void> validate_kernel_access_shape_v1(
    const KernelAccess& access) {
  return std::visit(
      [](const auto& alternative) -> Result<void> {
        using Alternative = std::decay_t<decltype(alternative)>;
        if (!alternative.has_operation()) {
          return Result<void>::failure(
              kernel_access_detail::access_diagnostic(
                  "c16.missing_kernel_access_callback",
                  "the active kernel access alternative requires its "
                  "complete callable set"));
        }

        if constexpr (std::is_same_v<Alternative,
                                     FiniteEnumeratedRowAccess> ||
                      std::is_same_v<Alternative, SparseRowAccess>) {
          if (!kernel_access_detail::valid_shape(alternative.shape())) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_kernel_access_shape",
                    "row access codecs and representation limits must be "
                    "complete and positive"));
          }
          if (!alternative.shape().maximum_row_atoms.has_value()) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.missing_row_representation_limit",
                    "finite and sparse row access require an explicit "
                    "positive atom limit"));
          }
        } else if constexpr (
            std::is_same_v<Alternative,
                           NormalizedConditionalSamplerAccess>) {
          if (!kernel_access_detail::valid_shape(alternative.shape())) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_kernel_access_shape",
                    "sampler access codecs must be complete"));
          }
          if (alternative.shape().maximum_row_atoms.has_value()) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.sampler_advertised_as_finite_row",
                    "conditional sampler access cannot advertise a finite "
                    "row atom limit"));
          }
        } else if constexpr (std::is_same_v<Alternative,
                                            AnalyticTransformAccess>) {
          if (!kernel_access_detail::valid_shape(alternative.shape())) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_kernel_access_shape",
                    "analytic transform argument and result codecs must be "
                    "complete"));
          }
          if (alternative.decoder_ids().empty()) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.missing_transform_decoder_domain",
                    "analytic transform access requires a nonempty closed "
                    "decoder domain"));
          }
          if (!std::is_sorted(alternative.decoder_ids().begin(),
                              alternative.decoder_ids().end()) ||
              std::adjacent_find(alternative.decoder_ids().begin(),
                                 alternative.decoder_ids().end()) !=
                  alternative.decoder_ids().end()) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_transform_decoder_domain",
                    "analytic transform decoder identities must be strictly "
                    "ordered and unique"));
          }
        } else if constexpr (
            std::is_same_v<Alternative,
                           FiniteParameterAnalyticFamilyAccess>) {
          const auto& family = alternative.family();
          if (!kernel_access_detail::valid_shape(alternative.shape()) ||
              family.family_id.empty() || family.family_version == 0U ||
              !kernel_access_detail::valid_codec(family.parameter_schema) ||
              !kernel_access_detail::valid_codec(family.domain_schema)) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_analytic_family_identity",
                    "finite-parameter analytic access requires complete "
                    "family, parameter, and domain identities"));
          }
        } else if constexpr (
            std::is_same_v<Alternative,
                           ProceduralResidenceGeneratorAccess>) {
          const auto& operation = alternative.operation_identity();
          if (!kernel_access_detail::valid_shape(alternative.shape()) ||
              operation.operation_version == 0U ||
              !kernel_access_detail::valid_codec(operation.event_schema) ||
              !alternative.positive_residence_declared()) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_residence_event_contract",
                    "procedural residence access requires event semantics "
                    "and a positive residence declaration"));
          }
        } else if constexpr (std::is_same_v<Alternative,
                                            RawDirectDecoderAccess>) {
          if (!kernel_access_detail::valid_codec(
                  alternative.domain().request_codec) ||
              !kernel_access_detail::valid_codec(
                  alternative.domain().result_codec) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().canonical_request_domain_digest) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().build_request_digest) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().target_selection_digest) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().ordered_target_digest) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().selection_digest) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().configured_arrival_digest) ||
              !kernel_access_detail::nonzero_digest(
                  alternative.domain().accepted_contract_digest)) {
            return Result<void>::failure(
                kernel_access_detail::access_diagnostic(
                    "c16.invalid_direct_decoder_domain",
                    "raw direct access requires nonzero exact target and "
                    "selection domain identities"));
          }
        }
        return Result<void>::success();
      },
      access);
}

static_assert(std::variant_size_v<KernelAccess> == 7U,
              "C16 KernelAccess must remain the closed seven-alternative "
              "runtime-access union");

}  // namespace mwperf
