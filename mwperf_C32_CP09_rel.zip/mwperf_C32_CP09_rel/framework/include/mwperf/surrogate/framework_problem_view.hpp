#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/config/canonical_input.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/model/constraint_descriptor.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/model/typed_label.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"

namespace mwperf {

#if defined(MWPERF_C15_TEST_SEAMS)
namespace testing {
class C15ProtocolFixtureFactory;
}
#endif

using ConstructionGroupIdV1 = StrongId<"surrogate_construction_group_v1">;

// The order is authored target order and is therefore semantic.  The group
// identity is not a display name: it binds singleton or coupled construction
// work to one canonical subject.
struct TargetSelection final {
  std::uint32_t schema_version;
  std::vector<QueueId> ordered_targets;
  ConstructionGroupIdV1 construction_group_binding;

  friend bool operator==(const TargetSelection&, const TargetSelection&) =
      default;
};

struct PortableQueueEntryV1 final {
  QueueId queue_id;
  std::size_t dense_index;
  ExactRational maxweight_multiplier;
  bool selected_target;
  bool individually_serviceable;
  bool positive_arrival_support;

  friend bool operator==(const PortableQueueEntryV1&,
                         const PortableQueueEntryV1&) = default;
};

struct PortableCrossbarEdgeV1 final {
  QueueId queue;
  PortId input;
  PortId output;
  friend bool operator==(const PortableCrossbarEdgeV1&,
                         const PortableCrossbarEdgeV1&) = default;
};
struct PortableCrossbarConstraintV1 final {
  std::vector<PortId> inputs;
  std::vector<PortId> outputs;
  std::vector<PortableCrossbarEdgeV1> edges;
  friend bool operator==(const PortableCrossbarConstraintV1&,
                         const PortableCrossbarConstraintV1&) = default;
};

struct PortableIntervalV1 final {
  QueueId queue;
  ExactRational left;
  ExactRational right;
  friend bool operator==(const PortableIntervalV1&,
                         const PortableIntervalV1&) = default;
};
struct PortableIntervalConstraintV1 final {
  std::vector<PortableIntervalV1> intervals;
  friend bool operator==(const PortableIntervalConstraintV1&,
                         const PortableIntervalConstraintV1&) = default;
};

struct PortableNodeExclusiveLinkV1 final {
  QueueId queue;
  VertexId u;
  VertexId v;
  friend bool operator==(const PortableNodeExclusiveLinkV1&,
                         const PortableNodeExclusiveLinkV1&) = default;
};
struct PortableNodeExclusiveConstraintV1 final {
  std::vector<VertexId> vertices;
  std::vector<PortableNodeExclusiveLinkV1> links;
  friend bool operator==(const PortableNodeExclusiveConstraintV1&,
                         const PortableNodeExclusiveConstraintV1&) = default;
};

struct PortableConflictPairV1 final {
  QueueId first;
  QueueId second;
  friend bool operator==(const PortableConflictPairV1&,
                         const PortableConflictPairV1&) = default;
};
struct PortableConflictConstraintV1 final {
  std::vector<QueueId> queues;
  std::vector<PortableConflictPairV1> conflicts;
  friend bool operator==(const PortableConflictConstraintV1&,
                         const PortableConflictConstraintV1&) = default;
};

struct PortablePackingDemandV1 final {
  QueueId queue;
  std::vector<BigNat> demand;
  friend bool operator==(const PortablePackingDemandV1&,
                         const PortablePackingDemandV1&) = default;
};
struct PortablePackingConstraintV1 final {
  std::vector<ResourceId> resources;
  std::vector<BigNat> capacity;
  std::vector<PortablePackingDemandV1> demands;
  friend bool operator==(const PortablePackingConstraintV1&,
                         const PortablePackingConstraintV1&) = default;
};

using PortableConstraintGeometryV1 =
    std::variant<PortableCrossbarConstraintV1,
                 PortableIntervalConstraintV1,
                 PortableNodeExclusiveConstraintV1,
                 PortableConflictConstraintV1,
                 PortablePackingConstraintV1>;

enum class PortableInitialArrivalStateKindV1 : std::uint8_t {
  trace_origin,
  global_periodic_origin,
  source_delay_origin,
  renewal_origin,
  private_markov_states,
  shared_round_state,
};

struct PortableInitialArrivalCoordinateV1 final {
  std::string source_id;
  std::string state;
  friend bool operator==(const PortableInitialArrivalCoordinateV1&,
                         const PortableInitialArrivalCoordinateV1&) = default;
};

struct PortableInitialArrivalStateV1 final {
  PortableInitialArrivalStateKindV1 kind;
  std::vector<PortableInitialArrivalCoordinateV1> coordinates;
  friend bool operator==(const PortableInitialArrivalStateV1&,
                         const PortableInitialArrivalStateV1&) = default;
};

struct PortableInitialLawAtomV1 final {
  ExactRational probability;
  std::vector<BigNat> dense_backlog;
  PortableInitialArrivalStateV1 arrival_state;
  std::vector<std::byte> canonical_controller_state;
  std::vector<std::byte> canonical_static_context;
  std::vector<std::byte> canonical_surrogate_initial;
  friend bool operator==(const PortableInitialLawAtomV1&,
                         const PortableInitialLawAtomV1&) = default;
};

struct PortableInitialPredictiveLawV1 final {
  std::uint32_t schema_version;
  std::vector<PortableInitialLawAtomV1> atoms;
  friend bool operator==(const PortableInitialPredictiveLawV1&,
                         const PortableInitialPredictiveLawV1&) = default;
};

// Closed, callback-free projection of AnalysisSpec::selection.  A transient
// selection carries its complete normalized physical initial law in the
// adjacent PortableInitialPredictiveLawV1 field; the tag here prevents absence
// of that law from being confused with a stationary selection.  Stationary
// mixture order is authored and therefore remains semantic.
struct PortableTransientSelectionV1 final {
  friend bool operator==(const PortableTransientSelectionV1&,
                         const PortableTransientSelectionV1&) = default;
};
struct PortableStationaryUniqueSelectionV1 final {
  friend bool operator==(const PortableStationaryUniqueSelectionV1&,
                         const PortableStationaryUniqueSelectionV1&) = default;
};
struct PortableStationaryClassSelectionV1 final {
  TypedLabel class_id;
  friend bool operator==(const PortableStationaryClassSelectionV1&,
                         const PortableStationaryClassSelectionV1&) = default;
};
struct PortableStationaryMixtureComponentV1 final {
  TypedLabel class_id;
  ExactRational probability;
  friend bool operator==(const PortableStationaryMixtureComponentV1&,
                         const PortableStationaryMixtureComponentV1&) = default;
};
struct PortableStationaryMixtureSelectionV1 final {
  // SelectionSpec order is retained; class IDs are unique and the exact
  // weights are C02-normalized to total mass one before publication.
  std::vector<PortableStationaryMixtureComponentV1> components;
  friend bool operator==(const PortableStationaryMixtureSelectionV1&,
                         const PortableStationaryMixtureSelectionV1&) = default;
};
struct PortableFixedPointUniqueSelectionV1 final {
  friend bool operator==(const PortableFixedPointUniqueSelectionV1&,
                         const PortableFixedPointUniqueSelectionV1&) = default;
};
struct PortableFixedPointIdSelectionV1 final {
  TypedLabel solution_id;
  friend bool operator==(const PortableFixedPointIdSelectionV1&,
                         const PortableFixedPointIdSelectionV1&) = default;
};

using PortableAnalysisSelectionV1 =
    std::variant<PortableTransientSelectionV1,
                 PortableStationaryUniqueSelectionV1,
                 PortableStationaryClassSelectionV1,
                 PortableStationaryMixtureSelectionV1,
                 PortableFixedPointUniqueSelectionV1,
                 PortableFixedPointIdSelectionV1>;

struct FrameworkProblemFingerprintsV1 final {
  InputFingerprintBundle authored_inputs;
  Digest256 resolved_instance;
  Digest256 constraint;
  Digest256 target_selection;
  Digest256 tie_and_timing;
  Digest256 compiled_arrival;

  friend bool operator==(const FrameworkProblemFingerprintsV1&,
                         const FrameworkProblemFingerprintsV1&) = default;
};

enum class IntegerEncodingV1 : std::uint8_t {
  canonical_decimal_string,
};
enum class ScientificScalarEncodingV1 : std::uint8_t {
  rational_or_binary64_bits,
};

struct PortableUnitAndEncodingContractV1 final {
  std::uint32_t schema_version;
  std::string backlog_unit;
  std::string service_unit;
  std::string time_unit;
  IntegerEncodingV1 integer_encoding;
  ScientificScalarEncodingV1 scientific_scalar_encoding;
  bool unit_packet_service;
  std::optional<BigNat> queue_capacity;

  friend bool operator==(const PortableUnitAndEncodingContractV1&,
                         const PortableUnitAndEncodingContractV1&) = default;
};

class FrameworkProblemViewDigest final {
 public:
  explicit FrameworkProblemViewDigest(Digest256 value)
      : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const FrameworkProblemViewDigest&,
                         const FrameworkProblemViewDigest&) = default;

 private:
  Digest256 value_;
};

class FrameworkProblemView final {
 public:
  FrameworkProblemView(const FrameworkProblemView&) = default;
  FrameworkProblemView(FrameworkProblemView&&) noexcept = default;
  FrameworkProblemView& operator=(const FrameworkProblemView&) = default;
  FrameworkProblemView& operator=(FrameworkProblemView&&) noexcept = default;

  [[nodiscard]] std::uint32_t schema_version() const noexcept {
    return schema_version_;
  }
  [[nodiscard]] const FrameworkProblemFingerprintsV1& fingerprints()
      const noexcept {
    return fingerprints_;
  }
  [[nodiscard]] std::span<const PortableQueueEntryV1> queues() const noexcept {
    return queues_;
  }
  [[nodiscard]] const TargetSelection& target_selection() const noexcept {
    return target_selection_;
  }
  [[nodiscard]] const SchedulerConstraintPairV1& applicability_key()
      const noexcept {
    return applicability_key_;
  }
  [[nodiscard]] const PortableConstraintGeometryV1& constraint_geometry()
      const noexcept {
    return constraint_geometry_;
  }
  [[nodiscard]] std::span<const QueueId> priority_order() const noexcept {
    return priority_order_;
  }
  [[nodiscard]] TimingConvention timing() const noexcept { return timing_; }
  [[nodiscard]] const BuilderArrivalView& configured_arrival() const noexcept {
    return configured_arrival_;
  }
  [[nodiscard]] const PortableAnalysisSelectionV1& analysis_selection()
      const noexcept {
    return analysis_selection_;
  }
  [[nodiscard]] const std::optional<PortableInitialPredictiveLawV1>&
  initial_predictive_law() const noexcept {
    return initial_predictive_law_;
  }
  [[nodiscard]] const PortableUnitAndEncodingContractV1& units_and_encodings()
      const noexcept {
    return units_and_encodings_;
  }
  [[nodiscard]] const FrameworkProblemViewDigest& canonical_digest()
      const noexcept {
    return canonical_digest_;
  }
  friend bool operator==(const FrameworkProblemView& left,
                         const FrameworkProblemView& right) noexcept {
    // Both operands can be created only after full canonical validation, so
    // their whole-value digest is a safe immutable equality accelerator.
    return left.canonical_digest_ == right.canonical_digest_;
  }

 private:
  FrameworkProblemView(
      std::uint32_t schema_version,
      FrameworkProblemFingerprintsV1 fingerprints,
      std::vector<PortableQueueEntryV1> queues,
      TargetSelection target_selection,
      SchedulerConstraintPairV1 applicability_key,
      PortableConstraintGeometryV1 constraint_geometry,
      std::vector<QueueId> priority_order, TimingConvention timing,
      BuilderArrivalView configured_arrival,
      PortableAnalysisSelectionV1 analysis_selection,
      std::optional<PortableInitialPredictiveLawV1> initial_predictive_law,
      PortableUnitAndEncodingContractV1 units_and_encodings,
      FrameworkProblemViewDigest canonical_digest)
      : schema_version_(schema_version),
        fingerprints_(std::move(fingerprints)),
        queues_(std::move(queues)),
        target_selection_(std::move(target_selection)),
        applicability_key_(applicability_key),
        constraint_geometry_(std::move(constraint_geometry)),
        priority_order_(std::move(priority_order)),
        timing_(timing),
        configured_arrival_(std::move(configured_arrival)),
        analysis_selection_(std::move(analysis_selection)),
        initial_predictive_law_(std::move(initial_predictive_law)),
        units_and_encodings_(std::move(units_and_encodings)),
        canonical_digest_(std::move(canonical_digest)) {}

  std::uint32_t schema_version_;
  FrameworkProblemFingerprintsV1 fingerprints_;
  std::vector<PortableQueueEntryV1> queues_;
  TargetSelection target_selection_;
  SchedulerConstraintPairV1 applicability_key_;
  PortableConstraintGeometryV1 constraint_geometry_;
  std::vector<QueueId> priority_order_;
  TimingConvention timing_;
  BuilderArrivalView configured_arrival_;
  PortableAnalysisSelectionV1 analysis_selection_;
  std::optional<PortableInitialPredictiveLawV1> initial_predictive_law_;
  PortableUnitAndEncodingContractV1 units_and_encodings_;
  FrameworkProblemViewDigest canonical_digest_;

  friend Result<FrameworkProblemView> build_framework_problem_view(
      const ResolvedInstance&, const CompiledArrivalLaw&,
      const TargetSelection&);
  friend Result<FrameworkProblemView>
  project_factorized_iid_framework_problem_view(
      const FrameworkProblemView& view);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

[[nodiscard]] Result<std::vector<std::byte>>
canonical_framework_problem_view_bytes_v1(const FrameworkProblemView& view);

// Canonical physical-law projection used by CP09 trajectory and seed
// identities.  Unlike the complete framework-problem digest, this projection
// deliberately excludes authored/analysis fingerprints, the analysis
// selection, and all observation/projection policy.  It contains exactly the
// resolved objects that can change the simulated queueing trajectory.
[[nodiscard]] Result<Digest256>
canonical_physical_trajectory_digest_v1(const FrameworkProblemView& view);

// F-C15-02
[[nodiscard]] Result<FrameworkProblemView> build_framework_problem_view(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival,
    const TargetSelection& targets);

// Provider-scoped compact IID projection.  This preserves the canonical
// configured-law descriptor and law binding, removes only the legacy explicit
// Cartesian IID table/capability, and reseals all affected structural
// fingerprints.  Callers must select this explicitly; the generic problem
// view remains fully backward compatible.
[[nodiscard]] Result<FrameworkProblemView>
project_factorized_iid_framework_problem_view(
    const FrameworkProblemView& view);

// Rebuild the canonical full problem view and select exactly the full or the
// compact factorized-IID structural projection identified by the caller's
// already-bound compiled-arrival fingerprint.  This is used by downstream
// revalidation paths that intentionally do not carry provider metadata.
[[nodiscard]] Result<FrameworkProblemView>
build_framework_problem_view_matching_arrival_projection(
    const ResolvedInstance& instance, const CompiledArrivalLaw& arrival,
    const TargetSelection& targets,
    const Digest256& expected_compiled_arrival);

}  // namespace mwperf
