#pragma once

#include <optional>

#include "mwperf/result.hpp"
#include "mwperf/surrogate/provider.hpp"
#include "mwperf/surrogate/surrogate_id.hpp"

namespace mwperf {

// F-C16-01.
[[nodiscard]] Result<SurrogateProvider> lookup_surrogate_provider(
    const SurrogateId& id,
    const std::optional<SurrogateVersion>& version = std::nullopt);

}  // namespace mwperf
