#pragma once

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/build_services.hpp"
#include "mwperf/diagnostic.hpp"
#include "mwperf/random/deterministic_rng.hpp"
#include "mwperf/reduction/exact_reductions.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/provider_manifest.hpp"
#include "mwperf/surrogate/surrogate_build_protocol.hpp"

namespace mwperf {

class SurrogateProvider;

// The outer provider boundary reports transport/framework completion only.
// Scientific Built/Unavailable/Failed status remains encoded in these bytes
// and is interpreted later by the C15 parser.
struct CompletedProviderExecution final {
  std::vector<std::byte> bytes;

  friend bool operator==(const CompletedProviderExecution&,
                         const CompletedProviderExecution&) = default;
};

struct FailedProviderExecution final {
  Diagnostic diagnostic;

  friend bool operator==(const FailedProviderExecution&,
                         const FailedProviderExecution&) = default;
};

using ProviderExecutionOutcome =
    std::variant<CompletedProviderExecution, FailedProviderExecution>;
static_assert(std::variant_size_v<ProviderExecutionOutcome> == 2U);

namespace detail {
class C16ExecutableSpecMint;

class SingleUseExecutionGate final {
 public:
  SingleUseExecutionGate() noexcept = default;
  SingleUseExecutionGate(const SingleUseExecutionGate&) = delete;
  SingleUseExecutionGate& operator=(const SingleUseExecutionGate&) = delete;
  SingleUseExecutionGate(SingleUseExecutionGate&& other) noexcept
      : attempted_(other.attempted_.exchange(true,
                                             std::memory_order_acq_rel)) {}
  SingleUseExecutionGate& operator=(SingleUseExecutionGate&& other) noexcept {
    if (this != &other) {
      attempted_.store(other.attempted_.exchange(true,
                                                 std::memory_order_acq_rel),
                       std::memory_order_release);
    }
    return *this;
  }

  [[nodiscard]] bool begin() noexcept {
    return !attempted_.exchange(true, std::memory_order_acq_rel);
  }

 private:
  std::atomic_bool attempted_{false};
};
}

// Registry-minted local executable data.  No value is inferred from the
// environment or from authored/provider-controlled request data. Version 1
// always supplies the closed --request/--result argv described by F-C16-09;
// the fixed arguments are additional registry-owned literal tokens appended
// unchanged.
class RegisteredExecutableSpec final {
 public:
  RegisteredExecutableSpec() = delete;
  RegisteredExecutableSpec(const RegisteredExecutableSpec&) = default;
  RegisteredExecutableSpec(RegisteredExecutableSpec&&) noexcept = default;
  RegisteredExecutableSpec& operator=(const RegisteredExecutableSpec&) =
      default;
  RegisteredExecutableSpec& operator=(RegisteredExecutableSpec&&) noexcept =
      default;

  [[nodiscard]] const ProviderIdentityV1& provider_identity() const noexcept {
    return provider_identity_;
  }
  [[nodiscard]] const Digest256& manifest_digest() const noexcept {
    return manifest_digest_;
  }
  [[nodiscard]] const std::string& executable_id() const noexcept {
    return executable_id_;
  }
  [[nodiscard]] const std::filesystem::path& absolute_executable()
      const noexcept {
    return absolute_executable_;
  }
  [[nodiscard]] std::uint32_t argv_grammar_version() const noexcept {
    return argv_grammar_version_;
  }
  [[nodiscard]] const std::vector<std::string>& fixed_arguments()
      const noexcept {
    return fixed_arguments_;
  }
  [[nodiscard]] std::chrono::milliseconds wall_time_limit() const noexcept {
    return wall_time_limit_;
  }
  [[nodiscard]] const std::optional<std::chrono::milliseconds>&
      maximum_wall_time_limit() const noexcept {
    return maximum_wall_time_limit_;
  }
  [[nodiscard]] const std::optional<std::size_t>& maximum_worker_count()
      const noexcept {
    return maximum_worker_count_;
  }
  [[nodiscard]] std::size_t maximum_stderr_bytes() const noexcept {
    return maximum_stderr_bytes_;
  }
  [[nodiscard]] const std::optional<std::size_t>& maximum_request_bytes()
      const noexcept {
    return maximum_request_bytes_;
  }
  [[nodiscard]] const std::optional<std::size_t>& maximum_result_bytes()
      const noexcept {
    return maximum_result_bytes_;
  }

  friend bool operator==(const RegisteredExecutableSpec&,
                         const RegisteredExecutableSpec&) = default;

 private:
  RegisteredExecutableSpec(
      ProviderIdentityV1 provider_identity, Digest256 manifest_digest,
      std::string executable_id,
      std::filesystem::path absolute_executable,
      std::uint32_t argv_grammar_version,
      std::vector<std::string> fixed_arguments,
      std::chrono::milliseconds wall_time_limit,
      std::size_t maximum_stderr_bytes,
      std::optional<std::size_t> maximum_request_bytes,
      std::optional<std::size_t> maximum_result_bytes,
      std::optional<std::size_t> maximum_worker_count,
      std::optional<std::chrono::milliseconds> maximum_wall_time_limit)
      : provider_identity_(std::move(provider_identity)),
        manifest_digest_(std::move(manifest_digest)),
        executable_id_(std::move(executable_id)),
        absolute_executable_(std::move(absolute_executable)),
        argv_grammar_version_(argv_grammar_version),
        fixed_arguments_(std::move(fixed_arguments)),
        wall_time_limit_(wall_time_limit),
        maximum_stderr_bytes_(maximum_stderr_bytes),
        maximum_request_bytes_(maximum_request_bytes),
        maximum_result_bytes_(maximum_result_bytes),
        maximum_worker_count_(maximum_worker_count),
        maximum_wall_time_limit_(maximum_wall_time_limit) {}

  ProviderIdentityV1 provider_identity_;
  Digest256 manifest_digest_;
  std::string executable_id_;
  std::filesystem::path absolute_executable_;
  std::uint32_t argv_grammar_version_;
  std::vector<std::string> fixed_arguments_;
  std::chrono::milliseconds wall_time_limit_;
  std::size_t maximum_stderr_bytes_;
  std::optional<std::size_t> maximum_request_bytes_;
  std::optional<std::size_t> maximum_result_bytes_;
  // Present only when the registered executable accepts the runner-owned
  // literal `--workers <count>` extension.  This is a host ceiling and is
  // deliberately absent from the scientific request identity.
  std::optional<std::size_t> maximum_worker_count_;
  // If present, an invocation may raise the default wall-time limit up to
  // this registered ceiling.  Absence means the default is also the ceiling.
  std::optional<std::chrono::milliseconds> maximum_wall_time_limit_;

  friend class detail::C16ExecutableSpecMint;
};

namespace detail {
// The production registry owns this authorization check.  It performs no
// launch and must compare the minted spec with the exact selected request.
[[nodiscard]] bool is_registered_executable_spec_for_request(
    const RegisteredExecutableSpec& spec,
    const SurrogateBuildRequest& request) noexcept;
}  // namespace detail

// Performs registry-time validation only.  It never invokes the executable.
[[nodiscard]] Result<void> validate_registered_executable_spec(
    const RegisteredExecutableSpec& spec);

struct LocalBuilderTransportAccountingV1 final {
  bool launch_attempted{false};
  bool process_started{false};
  std::size_t request_bytes{0U};
  std::size_t result_bytes{0U};
  std::size_t stderr_bytes{0U};
  bool stdout_was_nonempty{false};
  std::chrono::nanoseconds elapsed_wall_time{0};

  friend bool operator==(const LocalBuilderTransportAccountingV1&,
                         const LocalBuilderTransportAccountingV1&) = default;
};

// Per-invocation host controls.  Neither value is serialized into the build
// request or included in a scientific digest.  An absent value retains the
// immutable registered executable default; a present value may only tighten
// or select within the registered host ceiling.
struct ProviderExecutionControlsV1 final {
  std::optional<std::size_t> worker_count{};
  std::optional<std::chrono::milliseconds> wall_time_limit{};

  friend bool operator==(const ProviderExecutionControlsV1&,
                         const ProviderExecutionControlsV1&) = default;
};

// One request-bound construction scope.  The factory revalidates the C15
// request/manifest binding and the caller-supplied workspace execution root.
// Process-local C09/C13 capabilities are owned here for the in-process route;
// F-C16-09 neither observes nor invokes them.
class BuildExecutionContext final {
 public:
  BuildExecutionContext(const BuildExecutionContext&) = delete;
  BuildExecutionContext& operator=(const BuildExecutionContext&) = delete;
  BuildExecutionContext(BuildExecutionContext&&) noexcept = default;
  BuildExecutionContext& operator=(BuildExecutionContext&&) noexcept =
      default;

  [[nodiscard]] static Result<BuildExecutionContext> create(
      const SurrogateBuildRequest& request,
      const ValidatedProviderManifest& manifest,
      std::filesystem::path workspace_execution_root,
      std::optional<BuilderArrivalServices> arrival_services = std::nullopt,
      std::optional<ConstructionExactQueryServices> exact_query_services =
          std::nullopt);

  [[nodiscard]] const ProviderIdentityV1& provider_identity() const noexcept {
    return provider_identity_;
  }
  [[nodiscard]] const Digest256& manifest_digest() const noexcept {
    return manifest_digest_;
  }
  [[nodiscard]] const SurrogateBuildRequestDigest& request_digest()
      const noexcept {
    return request_digest_;
  }
  [[nodiscard]] const BuildIdentityDigest& build_identity() const noexcept {
    return build_identity_;
  }
  [[nodiscard]] const ProviderTransportLimitsV1& manifest_transport_limits()
      const noexcept {
    return manifest_transport_limits_;
  }
  [[nodiscard]] const std::filesystem::path& workspace_execution_root()
      const noexcept {
    return workspace_execution_root_;
  }
  [[nodiscard]] const AdjacentReplayService* arrival_replay_service()
      const noexcept {
    return arrival_replay_service_ ? &*arrival_replay_service_ : nullptr;
  }
  [[nodiscard]] ConstructionExactQueryServices* exact_query_services()
      noexcept {
    return exact_query_services_ ? &*exact_query_services_ : nullptr;
  }
  [[nodiscard]] const ConstructionExactQueryServices* exact_query_services()
      const noexcept {
    return exact_query_services_ ? &*exact_query_services_ : nullptr;
  }
  [[nodiscard]] const LocalBuilderTransportAccountingV1&
  local_transport_accounting() const noexcept {
    return local_transport_accounting_;
  }

  // Derives only request-bound construction streams.  The BuildSeed remains
  // private, and non-construction stages are rejected before a key or stream
  // is created.
  [[nodiscard]] Result<DeterministicRng> make_construction_rng(
      StageTag stage, const TypedLabel& target_or_group_identity,
      const BigNat& build_replication_or_probe_id) const;

 private:
  BuildExecutionContext(
      ProviderIdentityV1 provider_identity,
      Digest256 manifest_digest,
      SurrogateBuildRequestDigest request_digest,
      BuildIdentityDigest build_identity,
      BuildSeed build_seed,
      ProviderTransportLimitsV1 manifest_transport_limits,
      std::optional<LocalExecutableDeclarationV1> local_executable,
      std::filesystem::path workspace_execution_root,
      std::uintmax_t workspace_execution_root_device,
      std::uintmax_t workspace_execution_root_inode,
      std::optional<AdjacentReplayService> arrival_replay_service,
      std::optional<ConstructionExactQueryServices> exact_query_services)
      : provider_identity_(std::move(provider_identity)),
        manifest_digest_(std::move(manifest_digest)),
        request_digest_(std::move(request_digest)),
        build_identity_(std::move(build_identity)),
        build_seed_(std::move(build_seed)),
        manifest_transport_limits_(manifest_transport_limits),
        local_executable_(std::move(local_executable)),
        workspace_execution_root_(std::move(workspace_execution_root)),
        workspace_execution_root_device_(workspace_execution_root_device),
        workspace_execution_root_inode_(workspace_execution_root_inode),
        arrival_replay_service_(std::move(arrival_replay_service)),
        exact_query_services_(std::move(exact_query_services)) {}

  ProviderIdentityV1 provider_identity_;
  Digest256 manifest_digest_;
  SurrogateBuildRequestDigest request_digest_;
  BuildIdentityDigest build_identity_;
  BuildSeed build_seed_;
  ProviderTransportLimitsV1 manifest_transport_limits_;
  std::optional<LocalExecutableDeclarationV1> local_executable_;
  std::filesystem::path workspace_execution_root_;
  std::uintmax_t workspace_execution_root_device_;
  std::uintmax_t workspace_execution_root_inode_;
  // The provider receives only the request-authorized adjacent replay
  // operation.  The encompassing C09 bundle and its independent unit-cube
  // evaluator never cross the C16 provider boundary.
  std::optional<AdjacentReplayService> arrival_replay_service_;
  std::optional<ConstructionExactQueryServices> exact_query_services_;
  LocalBuilderTransportAccountingV1 local_transport_accounting_;
  detail::SingleUseExecutionGate provider_execution_gate_;
  detail::SingleUseExecutionGate local_execution_gate_;

  [[nodiscard]] bool begin_provider_execution() noexcept {
    return provider_execution_gate_.begin();
  }
  [[nodiscard]] bool begin_local_execution() noexcept {
    return local_execution_gate_.begin();
  }

  friend ProviderExecutionOutcome execute_surrogate_provider(
      const SurrogateProvider&, const SurrogateBuildRequest&,
      BuildExecutionContext&, const ProviderExecutionControlsV1&);
  friend ProviderExecutionOutcome run_local_surrogate_builder(
      const RegisteredExecutableSpec&, const SurrogateBuildRequest&,
      BuildExecutionContext&, const ProviderExecutionControlsV1&);
};

// F-C16-09.  Directly executes one statically registered absolute executable
// with the closed argv grammar and returns bytes without interpreting them.
[[nodiscard]] ProviderExecutionOutcome run_local_surrogate_builder(
    const RegisteredExecutableSpec& spec,
    const SurrogateBuildRequest& request,
    BuildExecutionContext& context,
    const ProviderExecutionControlsV1& controls = {});

}  // namespace mwperf
