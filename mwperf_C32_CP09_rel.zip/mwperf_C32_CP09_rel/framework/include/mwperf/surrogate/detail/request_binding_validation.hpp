#pragma once

#include <optional>
#include <span>

#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/core/sha256.hpp"
#include "mwperf/metrics/metric_request.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/framework_problem_view.hpp"

namespace mwperf {

class SurrogateBuildRequest;
class ValidatedProviderManifest;

namespace artifact::detail {

// Admission and final report validation must agree on the total search-state
// floor induced by a declared per-call minimum.  If the provider also
// declares a minimum call count, every admitted budget must cover their exact
// product.  A per-call-only prerequisite retains its existing single-call
// floor; calls alone do not invent a search-state obligation.
[[nodiscard]] inline bool checked_required_optimizer_search_states_v1(
    const ConstructionPrerequisitesV1& prerequisites,
    std::optional<BigNat>& required_total) noexcept {
  try {
    if (!prerequisites.required_search_states_per_call.has_value()) {
      required_total.reset();
    } else if (!prerequisites.required_optimizer_calls.has_value()) {
      required_total = *prerequisites.required_search_states_per_call;
    } else {
      required_total = *prerequisites.required_optimizer_calls *
                       *prerequisites.required_search_states_per_call;
    }
    return true;
  } catch (...) {
    required_total.reset();
    return false;
  }
}

// Read-only integrity check shared by C15 validation and C16 execution.  This
// helper never creates or repairs a request and never derives or consumes an
// RNG stream.
[[nodiscard]] Result<void> verify_request_bindings_v1(
    const SurrogateBuildRequest& request,
    const ValidatedProviderManifest& manifest);

// C15 is the sole owner of the portable SelectionSpec projection and its
// canonical JSON grammar.  C16 uses these narrow digest helpers rather than
// introducing a second spelling for an accepted analysis selection or an
// ordered metric-target list.
[[nodiscard]] Result<Digest256> canonical_analysis_selection_digest_v1(
    const SelectionSpec& selection);
[[nodiscard]] Result<Digest256> canonical_analysis_selection_digest_v1(
    const PortableAnalysisSelectionV1& selection);
[[nodiscard]] Result<Digest256> canonical_ordered_metric_targets_digest_v1(
    std::span<const QueueId> ordered_targets);
[[nodiscard]] Result<Digest256> canonical_ordered_metric_targets_digest_v1(
    std::span<const ResolvedMetricTargetV1> ordered_targets);
[[nodiscard]] Result<FrameworkProblemViewDigest>
canonical_framework_problem_view_digest_v1(
    const FrameworkProblemView& view);

}  // namespace artifact::detail
}  // namespace mwperf
