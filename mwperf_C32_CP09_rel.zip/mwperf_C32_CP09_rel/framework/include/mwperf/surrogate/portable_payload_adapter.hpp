#pragma once

#include <array>
#include <utility>
#include <variant>

#include "mwperf/math/exact_rational.hpp"
#include "mwperf/result.hpp"
#include "mwperf/surrogate/surrogate_artifact.hpp"

namespace mwperf {

#if defined(MWPERF_C15_TEST_SEAMS)
namespace testing {
class C15ProtocolFixtureFactory;
}  // namespace testing
#endif

struct PortablePayloadContextV1 final {
  PayloadClassV1 payload_class;
  SemanticTagV1 semantic;
  RuntimeAccessTagV1 runtime_access;
  // C15's validated lineage remains explicit after the data-only artifact is
  // adapted.  F-C16-04 compares these immutable values with the artifact
  // carrier before any registered materializer can observe the payload.
  Digest256 build_identity_digest;
  Digest256 request_digest;
  Digest256 framework_problem_view_digest;
  std::vector<QueueId> ordered_deployed_targets;
  ArtifactObjectReferenceV1 payload_identity;
  Digest256 payload_digest;
  MetricSupportManifestEchoV1 structural_manifest_echo;
  BoundRealizedMetricBindingsV1 realized_metric_bindings;
  // Keep evidence as separately scoped value-object ledgers.  In particular,
  // direct-metric evidence IDs must not become dangling merely because the
  // construction-only artifact envelope has crossed the portable boundary.
  std::vector<FamilyEvidenceEnvelopeV1> family_evidence;
  std::vector<ScopedArtifactEvidenceV1> scoped_evidence;

  friend bool operator==(const PortablePayloadContextV1&,
                         const PortablePayloadContextV1&) = default;
};

struct PortableThreeBinScalarResponseV1 final {
  PortablePayloadContextV1 context;
  QueueId deployed_target;
  std::array<ExactRational, 3U> coefficients;
  DeployedResponseProductIdV1 selected_product;
  // The normalized record preserves all typed origin, lineage and envelope
  // data.  Every PortableScientificScalar recursively holds a rational after
  // F-C15-08; binary64 values cannot survive adaptation.
  ThreeBinScalarResponseV1 normalized_record;

  friend bool operator==(const PortableThreeBinScalarResponseV1&,
                         const PortableThreeBinScalarResponseV1&) = default;
};

// Exact C16 normalization of one complete native CP07.1 response.  The
// prefix is indexed by backlog level and therefore contains structural
// mu(0) followed by the K exact positive coefficients.  The separately
// labeled constant tail begins at K+1.  The normalized artifact record keeps
// the complete raw product, interval, mass, and evidence lineage with every
// PortableScientificScalar converted to an identical ExactRational.
struct PortableFinitePrefixConstantTailResponseV1 final {
  PortablePayloadContextV1 context;
  QueueId deployed_target;
  BigNat response_cutoff;
  std::vector<ExactRational> service_by_level;
  BigNat constant_tail_from;
  ExactRational constant_tail_service;
  RawResponseProductId selected_product;
  FinitePrefixConstantTailResponseV1 normalized_record;

  friend bool operator==(
      const PortableFinitePrefixConstantTailResponseV1&,
      const PortableFinitePrefixConstantTailResponseV1&) = default;
};

struct PortableFiniteParameterAnalyticDataV1 final {
  PortablePayloadContextV1 context;
  FiniteParameterAnalyticDataV1 normalized_record;

  friend bool operator==(const PortableFiniteParameterAnalyticDataV1&,
                         const PortableFiniteParameterAnalyticDataV1&) =
      default;
};

struct PortableFiniteLawTablesV1 final {
  PortablePayloadContextV1 context;
  FiniteLawTablesV1 normalized_record;

  friend bool operator==(const PortableFiniteLawTablesV1&,
                         const PortableFiniteLawTablesV1&) = default;
};

struct PortableRegisteredRuntimeRecipeV1 final {
  PortablePayloadContextV1 context;
  RegisteredRuntimeRecipeV1 normalized_record;

  friend bool operator==(const PortableRegisteredRuntimeRecipeV1&,
                         const PortableRegisteredRuntimeRecipeV1&) = default;
};

struct PortableResponseEnvelopeEvidenceV1 final {
  PortablePayloadContextV1 context;
  ResponseEnvelopeEvidenceV1 normalized_record;

  friend bool operator==(const PortableResponseEnvelopeEvidenceV1&,
                         const PortableResponseEnvelopeEvidenceV1&) = default;
};

struct PortableDirectMetricPayloadV1 final {
  PortablePayloadContextV1 context;
  DirectMetricPayloadV1 normalized_record;

  friend bool operator==(const PortableDirectMetricPayloadV1&,
                         const PortableDirectMetricPayloadV1&) = default;
};

using PortablePlugPayloadValueV1 =
    std::variant<PortableThreeBinScalarResponseV1,
                 PortableFinitePrefixConstantTailResponseV1,
                 PortableFiniteParameterAnalyticDataV1,
                 PortableFiniteLawTablesV1,
                 PortableRegisteredRuntimeRecipeV1,
                 PortableResponseEnvelopeEvidenceV1,
                 PortableDirectMetricPayloadV1>;

class PortablePlugPayload final {
 public:
  PortablePlugPayload(const PortablePlugPayload&) = default;
  PortablePlugPayload(PortablePlugPayload&&) noexcept = default;
  PortablePlugPayload& operator=(const PortablePlugPayload&) = default;
  PortablePlugPayload& operator=(PortablePlugPayload&&) noexcept = default;

  [[nodiscard]] const PortablePlugPayloadValueV1& value() const noexcept {
    return value_;
  }

 private:
  explicit PortablePlugPayload(PortablePlugPayloadValueV1 value)
      : value_(std::move(value)) {}

  PortablePlugPayloadValueV1 value_;

  friend Result<PortablePlugPayload> adapt_portable_payload(
      const ValidatedSurrogateArtifact& artifact);
#if defined(MWPERF_C15_TEST_SEAMS)
  friend class testing::C15ProtocolFixtureFactory;
#endif
};

// F-C15-08.
[[nodiscard]] Result<PortablePlugPayload> adapt_portable_payload(
    const ValidatedSurrogateArtifact& artifact);

}  // namespace mwperf
