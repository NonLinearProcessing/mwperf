#pragma once

#include <array>
#include <compare>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>

#include "mwperf/result.hpp"

namespace mwperf {

class Sha256;

// A SHA-256 digest is always exactly 256 bits. Construction from externally
// supplied bytes is validated so a short or overlong digest cannot inhabit the
// type.
class Digest256 final {
 public:
  static constexpr std::size_t kSize = 32U;

  Digest256() = delete;

  [[nodiscard]] static Result<Digest256> from_bytes(
      std::span<const std::byte> bytes);
  [[nodiscard]] static Result<Digest256> from_hex(std::string_view encoded);

  [[nodiscard]] std::span<const std::byte, kSize> bytes() const noexcept;
  [[nodiscard]] std::string hex() const;

  friend bool operator==(const Digest256&, const Digest256&) = default;
  friend std::strong_ordering operator<=>(const Digest256&,
                                           const Digest256&) = default;

 private:
  struct ValidatedTag final {};

  explicit Digest256(std::array<std::byte, kSize> bytes,
                     ValidatedTag) noexcept;

  std::array<std::byte, kSize> bytes_;

  friend class Sha256;
};

// Allocation-bounded incremental SHA-256. finalize() hashes a snapshot, so it
// is deterministic and idempotent and does not prevent subsequent updates.
class Sha256 final {
 public:
  Sha256() noexcept;

  [[nodiscard]] Result<void> update(std::span<const std::byte> bytes);
  [[nodiscard]] Digest256 finalize() const noexcept;

 private:
  static constexpr std::size_t kBlockSize = 64U;

  void compress_block(const std::byte* block) noexcept;

  std::array<std::uint32_t, 8U> state_;
  std::array<std::byte, kBlockSize> buffer_{};
  std::uint64_t total_bytes_{0U};
  std::size_t buffered_bytes_{0U};
};

[[nodiscard]] Result<Digest256> sha256(std::span<const std::byte> bytes);

// Hashes ASCII(domain) || 0x00 || canonical_bytes. A domain must be nonempty
// visible ASCII and cannot contain the separator byte.
[[nodiscard]] Result<Digest256> sha256_domain_separated(
    std::string_view domain, std::span<const std::byte> canonical_bytes);

}  // namespace mwperf
