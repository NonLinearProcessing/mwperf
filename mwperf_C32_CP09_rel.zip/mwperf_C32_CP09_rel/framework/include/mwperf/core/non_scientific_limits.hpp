#pragma once

#include <chrono>
#include <cstddef>
#include <cstdint>

namespace mwperf {

// File/process APIs require a finite bound even though transport size is not
// part of the scientific domain. This remote ceiling must not be used as a
// planning or scientific admission threshold.
static_assert(sizeof(std::size_t) >= sizeof(std::uint64_t),
              "mwperf transport requires a 64-bit address space");
inline constexpr std::size_t kNonScientificByteCeiling =
    100ULL * 1024ULL * 1024ULL * 1024ULL;

// The local process monitor compares its deadline with steady_clock::duration.
// Use the largest millisecond duration that can be represented by that clock,
// rather than imposing an unrelated calendar-time policy ceiling.
inline constexpr std::chrono::milliseconds kNonScientificWallTimeCeiling =
    std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::duration::max());
inline constexpr std::uint64_t kNonScientificTimeoutSecondsCeiling =
    static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::seconds>(
            kNonScientificWallTimeCeiling)
            .count());

}  // namespace mwperf
