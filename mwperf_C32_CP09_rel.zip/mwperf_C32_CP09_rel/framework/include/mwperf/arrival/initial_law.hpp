#pragma once

#include <cstddef>
#include <memory>
#include <span>
#include <vector>

#include "mwperf/arrival/types.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/resolved_instance.hpp"

namespace mwperf {

struct InitialPhysicalAtom final {
  ExactRational probability;
  std::vector<BigNat> backlog;
  ArrivalInitialState arrival_state;
  SourceNode controller_state;
  SourceNode static_context;
  SourceNode surrogate_initial;
  SourceNode source;
};

// The original once-normalized row is retained for exact one-draw C12
// selection. Mapping then coalesces only identical complete joint atoms.
class InitialPhysicalLaw final {
 public:
  InitialPhysicalLaw(const InitialPhysicalLaw&) = default;
  InitialPhysicalLaw(InitialPhysicalLaw&&) noexcept = default;
  InitialPhysicalLaw& operator=(const InitialPhysicalLaw&) = default;
  InitialPhysicalLaw& operator=(InitialPhysicalLaw&&) noexcept = default;

  [[nodiscard]] const ArrivalBinding& arrival_binding() const noexcept {
    return arrival_binding_;
  }
  [[nodiscard]] const ArrivalLawDigest& arrival_law_digest() const noexcept {
    return arrival_binding_.law_digest;
  }
  [[nodiscard]] const NormalizedPmf& original_pmf() const noexcept {
    return original_pmf_;
  }
  [[nodiscard]] const ExactRational& normalization_delta() const noexcept {
    return original_pmf_.normalization_delta();
  }
  [[nodiscard]] std::span<const InitialPhysicalAtom> atoms() const noexcept {
    return atoms_;
  }
  [[nodiscard]] std::span<const std::size_t> original_to_atom() const noexcept {
    return original_to_atom_;
  }

  // Copies of one C09 product share this opaque immutable origin.  Equality
  // of the public mathematical projection is deliberately insufficient:
  // another request can compile a same-shaped law that must not be accepted
  // as this instance's initializer at the C16 audited boundary.
  [[nodiscard]] bool shares_origin_with(
      const InitialPhysicalLaw& other) const noexcept {
    return origin_ && other.origin_ &&
           !origin_.owner_before(other.origin_) &&
           !other.origin_.owner_before(origin_);
  }

 private:
  struct OriginToken final {};

  InitialPhysicalLaw(ArrivalBinding arrival_binding,
                     NormalizedPmf original_pmf,
                     std::vector<InitialPhysicalAtom> atoms,
                     std::vector<std::size_t> original_to_atom,
                     std::shared_ptr<const OriginToken> origin)
      : arrival_binding_(std::move(arrival_binding)),
        original_pmf_(std::move(original_pmf)),
        atoms_(std::move(atoms)),
        original_to_atom_(std::move(original_to_atom)),
        origin_(std::move(origin)) {}

  ArrivalBinding arrival_binding_;
  NormalizedPmf original_pmf_;
  std::vector<InitialPhysicalAtom> atoms_;
  std::vector<std::size_t> original_to_atom_;
  std::shared_ptr<const OriginToken> origin_;

  friend struct detail::ArrivalCoreAccess;
};

// F-C09-06
[[nodiscard]] Result<InitialPhysicalLaw> compile_initial_physical_law(
    const ResolvedTransientInitialLaw& resolved,
    const CompiledArrivalLaw& arrival_law);

namespace detail {

struct CompiledInitialLawAccess final {
  [[nodiscard]] static Result<std::shared_ptr<const InitialPhysicalLaw>> get(
      const InitialLawBinding& binding);
#if defined(MWPERF_C09_TEST_SEAMS)
  [[nodiscard]] static Result<std::shared_ptr<const InitialPhysicalLaw>>
  recover_for_testing(
      PhysicalBindingIdentity physical_identity,
      ArrivalProductBindingIdentity product_identity,
      ResolvedTransientInitialLaw resolved,
      std::shared_ptr<const InitialPhysicalLaw> owner);
#endif
};

}  // namespace detail

}  // namespace mwperf
