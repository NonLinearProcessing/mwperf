#pragma once

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/random/rng_stage.hpp"

namespace mwperf {

namespace detail {
struct BuilderArrivalServicesCore;
}

class BuilderArrivalStreamKey final {
 public:
  BuilderArrivalStreamKey(const BuilderArrivalStreamKey&) = delete;
  BuilderArrivalStreamKey& operator=(const BuilderArrivalStreamKey&) = delete;
  BuilderArrivalStreamKey(BuilderArrivalStreamKey&&) noexcept = default;
  BuilderArrivalStreamKey& operator=(BuilderArrivalStreamKey&&) noexcept =
      default;

  [[nodiscard]] StageTag stage() const noexcept { return stage_; }
  [[nodiscard]] const Digest256& stream_identity() const noexcept;

 private:
  BuilderArrivalStreamKey(ArrivalBinding binding, StageTag stage,
                          std::unique_ptr<DeterministicRng> rng) noexcept
      : binding_(std::move(binding)),
        stage_(stage),
        rng_(std::move(rng)) {}

  ArrivalBinding binding_;
  StageTag stage_;
  std::unique_ptr<DeterministicRng> rng_;
  friend struct detail::ArrivalCoreAccess;
  friend struct detail::BuilderArrivalServicesCore;
  friend class BuilderArrivalServices;
  friend Result<BuilderArrivalStreamKey> make_builder_arrival_stream_key(
      const CompiledArrivalLaw&, StageTag, DeterministicRng);
};

[[nodiscard]] Result<BuilderArrivalStreamKey> make_builder_arrival_stream_key(
    const CompiledArrivalLaw& law, StageTag construction_stage,
    DeterministicRng stream);

enum class ReplayContextStatus : std::uint8_t {
  ordered_dependent_contexts,
};

struct ExplicitReplayInitialState final {
  ArrivalInitialState value;
};

struct ExplicitReplayPhase final {
  ArrivalPhase value;
};

struct NormalizedReplayInitialLaw final {
  std::vector<ArrivalInitialState> states;
  NormalizedPmf probabilities;
};

struct NamedStationaryPhaseLaw final {
  std::string law_id;
};

using ReplayInitialization =
    std::variant<ExplicitReplayInitialState, ExplicitReplayPhase,
                 NormalizedReplayInitialLaw, NamedStationaryPhaseLaw>;

struct AdjacentReplayRequest final {
  BuilderArrivalViewDigest view_digest;
  ReplayInitialization initialization;
  BigNat authored_start_slot;
  BigNat length;
  BuilderArrivalStreamKey stream;
  std::string replay_identity;
};

struct GeneratorDrawAccounting final {
  BigNat transitions;
  BigNat rng_words;
};

struct AdjacentReplayResult final {
  BuilderArrivalViewDigest view_digest;
  std::string replay_identity;
  std::vector<ArrivalStep> steps;
  ReplayContextStatus status;
  GeneratorDrawAccounting accounting;
};

struct UnitCubeRequest final {
  BuilderArrivalViewDigest view_digest;
  BigNat authored_slot;
  std::optional<ArrivalPhase> phase;
  std::vector<ExactRational> coordinates;
};

struct JointArrivalTransition final {
  BuilderArrivalViewDigest view_digest;
  BigNat authored_slot;
  ArrivalBatch batch;
  ArrivalPhase phase_before;
  ArrivalPhase phase_after;
};

class AdjacentReplayService final {
 public:
  [[nodiscard]] Result<AdjacentReplayResult> replay(
      AdjacentReplayRequest request) const;

 private:
  explicit AdjacentReplayService(
      std::shared_ptr<const detail::BuilderArrivalServicesCore> core) noexcept
      : core_(std::move(core)) {}
  std::shared_ptr<const detail::BuilderArrivalServicesCore> core_;
  friend class BuilderArrivalServices;
};

class UnitCubeArrivalService final {
 public:
  [[nodiscard]] Result<JointArrivalTransition> evaluate(
      const UnitCubeRequest& request) const;

 private:
  explicit UnitCubeArrivalService(
      std::shared_ptr<const detail::BuilderArrivalServicesCore> core) noexcept
      : core_(std::move(core)) {}
  std::shared_ptr<const detail::BuilderArrivalServicesCore> core_;
  friend class BuilderArrivalServices;
};

// Process-local read-only services. The pimpl may evaluate registered code,
// but the portable BuilderArrivalView above remains callback-free.
class BuilderArrivalServices final {
 public:
  BuilderArrivalServices(const BuilderArrivalServices&) noexcept = default;
  BuilderArrivalServices(BuilderArrivalServices&&) noexcept = default;
  BuilderArrivalServices& operator=(const BuilderArrivalServices&) noexcept =
      default;
  BuilderArrivalServices& operator=(BuilderArrivalServices&&) noexcept =
      default;

  [[nodiscard]] const BuilderArrivalViewDigest& view_digest() const noexcept;
  [[nodiscard]] bool has_replay() const noexcept;
  [[nodiscard]] bool has_unit_cube() const noexcept;
  [[nodiscard]] std::optional<AdjacentReplayService> replay_service()
      const noexcept;
  [[nodiscard]] std::optional<UnitCubeArrivalService> unit_cube_service()
      const noexcept;

 private:
  explicit BuilderArrivalServices(
      std::shared_ptr<const detail::BuilderArrivalServicesCore> core) noexcept
      : core_(std::move(core)) {}

  std::shared_ptr<const detail::BuilderArrivalServicesCore> core_;
  [[nodiscard]] Result<AdjacentReplayResult> replay_adjacent(
      AdjacentReplayRequest request) const;
  [[nodiscard]] Result<JointArrivalTransition> evaluate_unit_cube(
      const UnitCubeRequest& request) const;
  friend struct detail::ArrivalCoreAccess;
  friend Result<BuilderArrivalServices> make_builder_arrival_services(
      const CompiledArrivalLaw&, const BuilderArrivalView&);
  friend class AdjacentReplayService;
  friend class UnitCubeArrivalService;
};

[[nodiscard]] Result<BuilderArrivalServices> make_builder_arrival_services(
    const CompiledArrivalLaw& law, const BuilderArrivalView& view);

}  // namespace mwperf
