#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/arrival/contract.hpp"

namespace mwperf {

class BuilderArrivalViewDigest final {
 public:
  explicit BuilderArrivalViewDigest(Digest256 value)
      : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const BuilderArrivalViewDigest&,
                         const BuilderArrivalViewDigest&) = default;

 private:
  Digest256 value_;
};

enum class PortableArrivalLawSchema : std::uint8_t {
  deterministic_trace_v1,
  periodic_global_phase_v1,
  periodic_source_delays_v1,
  independent_marked_renewal_v1,
  independent_private_markov_renewal_v1,
  shared_joint_round_markov_renewal_v1,
  // Schema-4 append-only portable IID recipes.  Existing numeric ordinals
  // remain frozen for provider 1.2/1.3 request vectors.
  iid_independent_bernoulli_v1,
  iid_count_table_v1,
  iid_independent_poisson_v1,
  iid_mixed_poisson_v1,
};

struct PortableArrivalLawDescriptor final {
  PortableArrivalLawSchema schema;
  std::uint32_t version;
  std::vector<std::byte> canonical_data;
  Digest256 payload_digest;

  friend bool operator==(const PortableArrivalLawDescriptor&,
                         const PortableArrivalLawDescriptor&) = default;
};

struct ExactJointBatchMass final {
  // Dense queue order; zeros are explicit because this is a portable joint
  // vector table, not the sparse runtime batch carrier.
  std::vector<BigNat> dense_counts;
  ExactRational probability;

  friend bool operator==(const ExactJointBatchMass&,
                         const ExactJointBatchMass&) = default;
};

struct ExactMomentDatum final {
  std::vector<DenseQueueIndex> coordinates;
  BigNat order;
  ExactRational value;

  friend bool operator==(const ExactMomentDatum&,
                         const ExactMomentDatum&) = default;
};

struct PortableTransformDescriptor final {
  TransformCapability capability;
  std::uint32_t codec_version;
  std::vector<std::byte> canonical_parameters;

  friend bool operator==(const PortableTransformDescriptor&,
                         const PortableTransformDescriptor&) = default;
};

struct ReplayCodecDescriptor final {
  std::uint32_t codec_version;
  bool requires_complete_initial_state;
  bool preserves_adjacent_temporal_order;
  std::vector<std::byte> canonical_parameters;

  friend bool operator==(const ReplayCodecDescriptor&,
                         const ReplayCodecDescriptor&) = default;
};

struct UnitCubeCoordinate final {
  std::size_t ordinal;
  std::string role;

  friend bool operator==(const UnitCubeCoordinate&,
                         const UnitCubeCoordinate&) = default;
};

struct UnitCubeDescriptor final {
  UnitCubeCapability capability;
  std::vector<UnitCubeCoordinate> coordinate_order;
  std::uint32_t codec_version;
  std::vector<std::byte> canonical_parameters;

  friend bool operator==(const UnitCubeDescriptor&,
                         const UnitCubeDescriptor&) = default;
};

enum class ArrivalRowClockSemanticsV1 : std::uint8_t {
  authored_slot_conditioned,
  finite_phase_time_homogeneous,
};

struct FinitePhaseDescriptor final {
  std::uint32_t codec_version;
  std::vector<std::vector<std::byte>> canonical_states;
  ArrivalRowClockSemanticsV1 row_clock_semantics{
      ArrivalRowClockSemanticsV1::authored_slot_conditioned};

  friend bool operator==(const FinitePhaseDescriptor&,
                         const FinitePhaseDescriptor&) = default;
};

struct EnumeratedTransitionRowsDescriptor final {
  std::uint32_t codec_version;
  std::vector<std::byte> canonical_rows;

  friend bool operator==(const EnumeratedTransitionRowsDescriptor&,
                         const EnumeratedTransitionRowsDescriptor&) = default;
};

struct StationaryPhaseLawDescriptor final {
  std::string law_id;
  std::uint32_t codec_version;
  std::vector<std::vector<std::byte>> canonical_states;
  NormalizedPmf probabilities;

  friend bool operator==(const StationaryPhaseLawDescriptor&,
                         const StationaryPhaseLawDescriptor&) = default;
};

// Immutable callback-free construction projection. It contains only portable
// values and never a cursor, RNG, function pointer, or implementation handle.
class BuilderArrivalView final {
 public:
  BuilderArrivalView(const BuilderArrivalView&) = default;
  BuilderArrivalView(BuilderArrivalView&&) noexcept = default;
  BuilderArrivalView& operator=(const BuilderArrivalView&) = default;
  BuilderArrivalView& operator=(BuilderArrivalView&&) noexcept = default;

  [[nodiscard]] std::uint32_t version() const noexcept { return version_; }
  [[nodiscard]] const ArrivalBinding& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] const BuilderArrivalViewDigest& digest() const noexcept {
    return digest_;
  }
  [[nodiscard]] const ArrivalCapabilities& capabilities() const noexcept {
    return capabilities_;
  }
  [[nodiscard]] const QueueMask& positive_support() const noexcept {
    return positive_support_;
  }
  [[nodiscard]] const PortableArrivalLawDescriptor& configured_law()
      const noexcept {
    return configured_law_;
  }
  [[nodiscard]] const std::optional<std::vector<ExactJointBatchMass>>&
  iid_joint_table() const noexcept {
    return iid_joint_table_;
  }
  [[nodiscard]] const std::optional<std::vector<ExactMomentDatum>>& moments()
      const noexcept {
    return moments_;
  }
  [[nodiscard]] const std::optional<std::vector<ExactMomentDatum>>&
  covariances() const noexcept {
    return covariances_;
  }
  [[nodiscard]] const std::optional<PortableTransformDescriptor>&
  analytic_transform() const noexcept {
    return analytic_transform_;
  }
  [[nodiscard]] const std::optional<PortableTransformDescriptor>&
  joint_distribution() const noexcept {
    return joint_distribution_;
  }
  [[nodiscard]] const std::optional<PortableTransformDescriptor>&
  coordinate_distributions() const noexcept {
    return coordinate_distributions_;
  }
  [[nodiscard]] const std::optional<ReplayCodecDescriptor>& replay_codec()
      const noexcept {
    return replay_codec_;
  }
  [[nodiscard]] const std::optional<UnitCubeDescriptor>& unit_cube()
      const noexcept {
    return unit_cube_;
  }
  [[nodiscard]] const std::optional<FinitePhaseDescriptor>& finite_phase()
      const noexcept {
    return finite_phase_;
  }
  [[nodiscard]] const std::optional<EnumeratedTransitionRowsDescriptor>&
  transition_rows() const noexcept {
    return transition_rows_;
  }
  [[nodiscard]] const std::optional<StationaryPhaseLawDescriptor>&
  stationary_phase_law() const noexcept {
    return stationary_phase_law_;
  }

 private:
  BuilderArrivalView(
      ArrivalBinding binding, BuilderArrivalViewDigest digest,
      ArrivalCapabilities capabilities, QueueMask positive_support,
      PortableArrivalLawDescriptor configured_law,
      std::optional<std::vector<ExactJointBatchMass>> iid_joint_table,
      std::optional<std::vector<ExactMomentDatum>> moments,
      std::optional<std::vector<ExactMomentDatum>> covariances,
      std::optional<PortableTransformDescriptor> analytic_transform,
      std::optional<PortableTransformDescriptor> joint_distribution,
      std::optional<PortableTransformDescriptor> coordinate_distributions,
      std::optional<ReplayCodecDescriptor> replay_codec,
      std::optional<UnitCubeDescriptor> unit_cube,
      std::optional<FinitePhaseDescriptor> finite_phase,
      std::optional<EnumeratedTransitionRowsDescriptor> transition_rows,
      std::optional<StationaryPhaseLawDescriptor> stationary_phase_law)
      : version_(1U),
        binding_(std::move(binding)),
        digest_(std::move(digest)),
        capabilities_(std::move(capabilities)),
        positive_support_(std::move(positive_support)),
        configured_law_(std::move(configured_law)),
        iid_joint_table_(std::move(iid_joint_table)),
        moments_(std::move(moments)),
        covariances_(std::move(covariances)),
        analytic_transform_(std::move(analytic_transform)),
        joint_distribution_(std::move(joint_distribution)),
        coordinate_distributions_(std::move(coordinate_distributions)),
        replay_codec_(std::move(replay_codec)),
        unit_cube_(std::move(unit_cube)),
        finite_phase_(std::move(finite_phase)),
        transition_rows_(std::move(transition_rows)),
        stationary_phase_law_(std::move(stationary_phase_law)) {}

  std::uint32_t version_;
  ArrivalBinding binding_;
  BuilderArrivalViewDigest digest_;
  ArrivalCapabilities capabilities_;
  QueueMask positive_support_;
  PortableArrivalLawDescriptor configured_law_;
  std::optional<std::vector<ExactJointBatchMass>> iid_joint_table_;
  std::optional<std::vector<ExactMomentDatum>> moments_;
  std::optional<std::vector<ExactMomentDatum>> covariances_;
  std::optional<PortableTransformDescriptor> analytic_transform_;
  std::optional<PortableTransformDescriptor> joint_distribution_;
  std::optional<PortableTransformDescriptor> coordinate_distributions_;
  std::optional<ReplayCodecDescriptor> replay_codec_;
  std::optional<UnitCubeDescriptor> unit_cube_;
  std::optional<FinitePhaseDescriptor> finite_phase_;
  std::optional<EnumeratedTransitionRowsDescriptor> transition_rows_;
  std::optional<StationaryPhaseLawDescriptor> stationary_phase_law_;

  friend struct detail::ArrivalCoreAccess;
  friend Result<BuilderArrivalView>
  project_factorized_iid_builder_arrival_view(
      const BuilderArrivalView& view);
};

[[nodiscard]] BuilderArrivalView builder_arrival_view(
    const CompiledArrivalLaw& law);

// Return the callback-free compact projection used by providers that consume
// the canonical factorized IID recipe directly.  The configured-law binding
// and every portable field are preserved, while the legacy Cartesian table
// and its distinct capability are omitted and the view digest is resealed.
// Generic consumers continue to receive builder_arrival_view(law) unchanged.
[[nodiscard]] Result<BuilderArrivalView>
project_factorized_iid_builder_arrival_view(
    const BuilderArrivalView& view);

}  // namespace mwperf
