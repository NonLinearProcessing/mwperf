#pragma once

#include <cstddef>
#include <span>
#include <string>
#include <variant>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct PreparedArrivalCompilation;

namespace detail {
struct CompiledArrivalProduct;
[[nodiscard]] Result<CompiledArrivalProduct>
compile_marked_renewal_product(
    const PreparedArrivalCompilation& request);
}  // namespace detail

struct DeterministicRenewalGap final {
  BigNat gap;

  friend bool operator==(const DeterministicRenewalGap&,
                         const DeterministicRenewalGap&) = default;
};

struct FiniteRenewalGap final {
  std::vector<BigNat> gaps;
  NormalizedPmf probabilities;

  friend bool operator==(const FiniteRenewalGap&,
                         const FiniteRenewalGap&) = default;
};

// D = d_min + delta F, with F the number of failures before the first
// success. trial_probabilities is the immutable normalized row [p, 1-p];
// index zero is success and index one is failure.
struct GeometricGridRenewalGap final {
  BigNat d_min;
  BigNat delta;
  NormalizedPmf trial_probabilities;

  friend bool operator==(const GeometricGridRenewalGap&,
                         const GeometricGridRenewalGap&) = default;
};

using RenewalGapLaw =
    std::variant<DeterministicRenewalGap, FiniteRenewalGap,
                 GeometricGridRenewalGap>;

struct FactorizedRenewalLawSource final {
  std::string source_id;
  RenewalGapLaw interarrival;
  std::vector<DenseQueueIndex> destinations;
  NormalizedPmf destination_probabilities;
};

struct JointRenewalOutcome final {
  BigNat gap;
  DenseQueueIndex destination;

  friend bool operator==(const JointRenewalOutcome&,
                         const JointRenewalOutcome&) = default;
};

struct JointRenewalLawSource final {
  std::string source_id;
  std::vector<JointRenewalOutcome> outcomes;
  NormalizedPmf probabilities;
};

using RenewalLawSource =
    std::variant<FactorizedRenewalLawSource, JointRenewalLawSource>;

// One atom of the exact one-dimensional IID batch law obtained by projecting
// an independent factorized marked-renewal generator onto a single queue.
// Counts are canonical and strictly increasing in the returned projection;
// zero-mass atoms are omitted.
struct ExactTargetIidBatchMass final {
  BigNat count;
  ExactRational probability;

  friend bool operator==(const ExactTargetIidBatchMass&,
                         const ExactTargetIidBatchMass&) = default;
};

// Immutable, queue-resolved geometry for F-C11-01. Sources and every
// categorical coordinate retain significant authored order.
class RenewalLaw final {
 public:
  RenewalLaw() = delete;
  RenewalLaw(const RenewalLaw&) = default;
  RenewalLaw(RenewalLaw&&) noexcept = default;
  RenewalLaw& operator=(const RenewalLaw&) = default;
  RenewalLaw& operator=(RenewalLaw&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_count_;
  }
  [[nodiscard]] const QueueCatalogDigest& catalog_digest() const noexcept {
    return catalog_digest_;
  }
  [[nodiscard]] std::span<const RenewalLawSource> sources() const noexcept {
    return sources_;
  }

 private:
  RenewalLaw(std::size_t queue_count, QueueCatalogDigest catalog_digest,
             std::vector<RenewalLawSource> sources)
      : queue_count_(queue_count),
        catalog_digest_(std::move(catalog_digest)),
        sources_(std::move(sources)) {}

  std::size_t queue_count_;
  QueueCatalogDigest catalog_digest_;
  std::vector<RenewalLawSource> sources_;

  friend Result<RenewalLaw> compile_marked_renewal(
      const IndependentMarkedRenewalArrival&, const QueueCatalog&);
  friend Result<detail::CompiledArrivalProduct>
  detail::compile_marked_renewal_product(
      const PreparedArrivalCompilation& request);
};

// F-C11-01
[[nodiscard]] Result<RenewalLaw> compile_marked_renewal(
    const IndependentMarkedRenewalArrival& authored,
    const QueueCatalog& queues);

// Exact compact projection for the memoryless unit-grid specialization. If
// source i fires with probability p_i and routes to target e with probability
// r_{i,e}, its target contribution is Bernoulli(theta_i), where
// theta_i = p_i r_{i,e}. This convolves those Bernoulli coordinates directly
// in O(K^2) exact arithmetic and O(K) working memory for the K sources with
// positive target probability, and never materializes the Cartesian joint law.
[[nodiscard]] Result<std::vector<ExactTargetIidBatchMass>>
project_exact_factorized_iid_target_pmf(
    const CompiledArrivalLaw& law, DenseQueueIndex target);

// Family-neutral exact finite target projection. Bernoulli, count-table, and
// the released memoryless marked-renewal specialization return exact atoms.
// Infinite-support Poisson families return a typed unavailable diagnostic;
// their configured-law descriptor and exact target moments remain available.
[[nodiscard]] Result<std::vector<ExactTargetIidBatchMass>>
project_exact_iid_target_pmf(const CompiledArrivalLaw& law,
                             DenseQueueIndex target);

// F-C11-02. The deployed cursor and transaction remain C09's sole process
// boundary; this spelling adds only the family guard.
using RenewalCursor = ArrivalProcess;
[[nodiscard]] Result<ArrivalStep> next_marked_renewal_batch(
    RenewalCursor& cursor, const BigNat& authored_slot);

}  // namespace mwperf
