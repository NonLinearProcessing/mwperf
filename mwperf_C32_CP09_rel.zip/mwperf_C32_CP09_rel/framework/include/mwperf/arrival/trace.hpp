#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <utility>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// One compile-time aggregated trace coordinate.  Records are stored in exact
// authored-slot order and then dense queue order.  The authored slot remains
// unchanged: slot t is the late-admission batch A(t+1).
struct ExactTraceEvent final {
  BigNat slot;
  DenseQueueIndex queue;
  BigNat count;

  friend bool operator==(const ExactTraceEvent&, const ExactTraceEvent&) =
      default;
};

// Immutable sparse payload for F-C10-01.  Its storage is proportional to the
// number and encoded bit lengths of occupied (slot,queue) coordinates, never
// to the numerical value of the greatest authored slot.
class TraceLaw final {
 public:
  TraceLaw() = delete;
  TraceLaw(const TraceLaw&) = default;
  TraceLaw(TraceLaw&&) noexcept = default;
  TraceLaw& operator=(const TraceLaw&) = default;
  TraceLaw& operator=(TraceLaw&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_count_;
  }
  [[nodiscard]] std::span<const ExactTraceEvent> events() const noexcept {
    return events_;
  }
  [[nodiscard]] std::span<const std::uint8_t> positive_support_bytes()
      const noexcept {
    return positive_support_;
  }
  [[nodiscard]] std::span<const std::byte> canonical_law_data()
      const noexcept {
    return canonical_law_data_;
  }
  [[nodiscard]] const QueueCatalogDigest& catalog_digest() const noexcept {
    return catalog_digest_;
  }

 private:
  TraceLaw(std::size_t queue_count, std::vector<ExactTraceEvent> events,
           std::vector<std::uint8_t> positive_support,
           std::vector<std::byte> canonical_law_data,
           QueueCatalogDigest catalog_digest)
      : queue_count_(queue_count),
        events_(std::move(events)),
        positive_support_(std::move(positive_support)),
        canonical_law_data_(std::move(canonical_law_data)),
        catalog_digest_(std::move(catalog_digest)) {}

  std::size_t queue_count_;
  std::vector<ExactTraceEvent> events_;
  std::vector<std::uint8_t> positive_support_;
  std::vector<std::byte> canonical_law_data_;
  QueueCatalogDigest catalog_digest_;

  friend Result<TraceLaw> compile_deterministic_trace(
      const DeterministicTraceArrival&, const QueueCatalog&);
};

// F-C10-01.  Queue labels are resolved through the supplied catalog, duplicate
// (slot,queue) coordinates are aggregated through the C09 checked boundary,
// and the resulting exact sparse geometry is independent of authored row
// order.
[[nodiscard]] Result<TraceLaw> compile_deterministic_trace(
    const DeterministicTraceArrival& authored, const QueueCatalog& queues);

// There is deliberately only one deployed mutable cursor type: the C09
// ArrivalProcess.  This family spelling supplies the catalog function without
// creating a second cursor, transaction, RNG, or sequencing implementation.
using TraceCursor = ArrivalProcess;

// F-C10-02.  Authored slot t returns the physical batch A(t+1).  This thin
// family guard delegates sequencing, aggregation, phase publication, and
// transactional commit to C09's sole transition boundary.
[[nodiscard]] Result<ArrivalStep> next_trace_batch(
    TraceCursor& cursor, const BigNat& authored_slot);

#if defined(MWPERF_C10_TEST_SEAMS)
namespace testing {

// Fault-injection seam for the required stale/unreachable cursor invariant.
// It invokes the production validator and cannot create or mutate a deployed
// ArrivalProcess.
[[nodiscard]] Result<void> validate_trace_cursor_state_for_testing(
    const TraceLaw& law, BigNat next_slot, std::size_t next_event,
    bool exhausted);

}  // namespace testing
#endif

}  // namespace mwperf
