#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <vector>

#include "mwperf/arrival/build_view.hpp"
#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/queue_catalog.hpp"

namespace mwperf {

enum class ArrivalCategoricalRowKind : std::uint8_t {
  finite_interarrival,
  geometric_trial,
  destination,
  joint_gap_destination,
  private_initial_state,
  private_transition,
  shared_initial_state,
  shared_outcome,
  iid_count_outcome,
  mixed_poisson_state,
};

// One exactly-once-normalized categorical row in significant authored order.
struct NormalizedArrivalRow final {
  ArrivalCategoricalRowKind kind;
  std::size_t source_ordinal;
  std::size_t state_ordinal;
  NormalizedPmf pmf;

  [[nodiscard]] const ExactRational& normalization_delta() const noexcept {
    return pmf.normalization_delta();
  }
};

struct PreparedArrivalCompilation final {
  const AuthoredArrivalConfig& authored;
  const QueueCatalog& queues;
  std::span<const NormalizedArrivalRow> normalized_rows;
};

namespace detail {

using ArrivalCursorState = std::shared_ptr<const void>;

struct ArrivalCursorInitialization final {
  ArrivalCursorState state;
};

struct ProposedArrivalTransition final {
  ArrivalCursorState successor_state;
  std::vector<ArrivalAtom> atoms;
  // Optional process-local scratch view.  It lets allocation-sensitive
  // runtimes expose one transaction's atoms without transferring ownership
  // of their reusable capacity.  The common C09 step consumes the span
  // synchronously before the cursor may be advanced again.  Legacy runtimes
  // continue to populate the owning vector above.
  std::optional<std::span<const ArrivalAtom>> borrowed_atoms{};
};

struct UnitCubeProposal final {
  std::vector<ArrivalAtom> atoms;
  std::vector<std::byte> phase_before;
  std::vector<std::byte> phase_after;
};

// One complete atom of an exact configured-arrival transition law.  The
// canonical phases retain the common predictive-state identity on both sides
// of the same arrival application; mass is mathematical authority rather than
// a numerical image.
struct ExactArrivalTransitionAtom final {
  std::vector<ArrivalAtom> atoms;
  std::vector<std::byte> phase_before;
  std::vector<std::byte> phase_after;
  ExactRational mass;
  // Structural membership is distinct from numerical mass.  An enumerator
  // may not turn a structurally absent cell into support merely because a
  // numerical image is positive, nor claim support for exact zero mass.
  bool structural_support;
};

struct ArrivalRuntimeAdapter final {
  using ValidateInitial = std::function<Result<void>(
      const std::shared_ptr<const void>&, const ArrivalInitialState&)>;
  using Instantiate = std::function<Result<ArrivalCursorInitialization>(
      const std::shared_ptr<const void>&, const ArrivalInitialState&,
      DeterministicRng&)>;
  using EncodePhase = std::function<Result<std::vector<std::byte>>(
      const std::shared_ptr<const void>&, const ArrivalCursorState&)>;
  using DecodePhase = std::function<Result<ArrivalCursorState>(
      const std::shared_ptr<const void>&, std::span<const std::byte>)>;
  using Propose = std::function<Result<ProposedArrivalTransition>(
      const std::shared_ptr<const void>&, const ArrivalCursorState&,
      const BigNat&, const ArrivalBinding&, DeterministicRng&)>;
  using UnitCube = std::function<Result<UnitCubeProposal>(
      const std::shared_ptr<const void>&, const BigNat&,
      const std::optional<ArrivalPhase>&, std::span<const ExactRational>,
      const ArrivalBinding&)>;
  using Enumerate =
      std::function<Result<std::vector<ExactArrivalTransitionAtom>>(
          const std::shared_ptr<const void>&, const ArrivalCursorState&,
          const BigNat&, const ArrivalBinding&)>;
  // Stronger than Enumerate: authored time is absent by type.  C17 may use
  // this operation only together with C09's finite phase and exact portable
  // transition-row descriptors.  Its presence is the executable witness
  // needed by C20's finite event-clock quotient.
  using EnumerateTimeHomogeneous =
      std::function<Result<std::vector<ExactArrivalTransitionAtom>>(
          const std::shared_ptr<const void>&, const ArrivalCursorState&,
          const ArrivalBinding&)>;

  ValidateInitial validate_initial;
  Instantiate instantiate;
  EncodePhase encode_phase;
  DecodePhase decode_phase;
  Propose propose;
  UnitCube unit_cube;
  // Empty for sampler-only laws.  No caller may infer an exact row by
  // repeatedly sampling propose/unit_cube.
  Enumerate enumerate;
  EnumerateTimeHomogeneous enumerate_time_homogeneous;
};

struct CompiledArrivalProduct final {
  ArrivalFamily family;
  // Filled by the common C09 registry after the family compiler returns.
  // A child compiler must not be the authority for retaining or reordering
  // the exactly-once-normalized authored rows.
  std::vector<NormalizedArrivalRow> normalized_rows;
  std::vector<std::uint8_t> positive_support;
  ArrivalCapabilities capabilities;
  std::vector<std::byte> canonical_law_data;
  PortableArrivalLawSchema portable_schema;
  std::shared_ptr<const void> payload;
  ArrivalRuntimeAdapter runtime;
  std::optional<std::vector<ExactJointBatchMass>> iid_joint_table;
  std::optional<std::vector<ExactMomentDatum>> moments;
  std::optional<std::vector<ExactMomentDatum>> covariances;
  // These remain independent because their domains, scopes, and closed
  // codecs need not agree. In particular, a joint PGF is not a
  // per-coordinate PGF merely because both are available for one law.
  std::optional<PortableTransformDescriptor> analytic_transform;
  std::optional<PortableTransformDescriptor> joint_distribution;
  std::optional<PortableTransformDescriptor> coordinate_distributions;
  std::optional<ReplayCodecDescriptor> replay_codec;
  std::optional<UnitCubeDescriptor> unit_cube;
  std::optional<FinitePhaseDescriptor> finite_phase;
  std::optional<EnumeratedTransitionRowsDescriptor> transition_rows;
  std::optional<StationaryPhaseLawDescriptor> stationary_phase_law;
};

using ArrivalBackendCompiler = std::function<Result<CompiledArrivalProduct>(
    const PreparedArrivalCompilation&)>;

struct ArrivalBackendSlot final {
  ArrivalFamily family;
  ArrivalBackendCompiler compile;
};

using ArrivalBackendRegistry = std::array<ArrivalBackendSlot, 10U>;

// C10/C11 family compiler seams. They return an unpublished product so the
// C09 boundary remains the sole authority that validates capabilities, binds
// the queue catalog, and computes the immutable law/view fingerprints.
[[nodiscard]] Result<CompiledArrivalProduct>
compile_deterministic_trace_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_global_phase_periodic_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_source_delay_periodic_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_marked_renewal_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_private_markov_renewal_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_shared_round_renewal_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_iid_independent_bernoulli_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct> compile_iid_count_table_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct>
compile_iid_independent_poisson_product(
    const PreparedArrivalCompilation& request);
[[nodiscard]] Result<CompiledArrivalProduct> compile_iid_mixed_poisson_product(
    const PreparedArrivalCompilation& request);

[[nodiscard]] const ArrivalBackendRegistry& c09_pending_arrival_registry();
// Fixed C10 composition is retained for checkpoint conformance and selective
// reversion: its first three slots are concrete; the released C11 and appended
// CP09 slots retain their precise pending diagnostics.
[[nodiscard]] const ArrivalBackendRegistry& c10_arrival_registry();
// Active CP09 composition: the six released families retain their slots and
// the four schema-4 IID families occupy append-only concrete slots.
[[nodiscard]] const ArrivalBackendRegistry& c11_arrival_registry();
[[nodiscard]] Result<CompiledArrivalLaw> compile_arrival_law_with_registry(
    const AuthoredArrivalConfig& authored, const QueueCatalog& queues,
    const ArrivalBackendRegistry& registry);

// Validates capability backing, computes all fingerprints, and freezes the
// immutable compiled product. C10 and C11 compilers use this one boundary.
[[nodiscard]] Result<CompiledArrivalLaw> publish_compiled_arrival_law(
    const QueueCatalog& queues, CompiledArrivalProduct product);

}  // namespace detail

// F-C09-01
[[nodiscard]] Result<CompiledArrivalLaw> compile_arrival_law(
    const AuthoredArrivalConfig& authored, const QueueCatalog& queues);

// Read-only provenance for the categorical rows normalized exactly once by
// the common C09 registry boundary.  Authored order, row coordinates, the raw
// sum, and the signed normalization delta are retained by the immutable law;
// downstream consumers must not renormalize these rows.
[[nodiscard]] std::span<const NormalizedArrivalRow> normalized_arrival_rows(
    const CompiledArrivalLaw& law) noexcept;

#if defined(MWPERF_C09_TEST_SEAMS)
namespace testing {

// Read-only evidence that the immutable compiled law retained the exact rows
// prepared by the common registry boundary. This is deliberately unavailable
// from the installed production ABI.
[[nodiscard]] std::span<const NormalizedArrivalRow>
normalized_arrival_rows_for_testing(const CompiledArrivalLaw& law) noexcept;

}  // namespace testing
#endif

}  // namespace mwperf
