#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/core/sha256.hpp"
#include "mwperf/math/big_nat.hpp"
#include "mwperf/model/resolved_instance.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

namespace detail {
struct CompiledArrivalLawCore;
struct ArrivalProcessCore;
struct ArrivalPhaseCore;
struct ArrivalCoreAccess;
}  // namespace detail

// Typed digests make law, catalog, state, and portable-view bindings
// non-interchangeable even though every value is represented by SHA-256.
class ArrivalLawDigest final {
 public:
  explicit ArrivalLawDigest(Digest256 value) : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const ArrivalLawDigest&, const ArrivalLawDigest&) =
      default;

 private:
  Digest256 value_;
};

class QueueCatalogDigest final {
 public:
  explicit QueueCatalogDigest(Digest256 value) : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const QueueCatalogDigest&, const QueueCatalogDigest&) =
      default;

 private:
  Digest256 value_;
};

class ArrivalStateDigest final {
 public:
  explicit ArrivalStateDigest(Digest256 value) : value_(std::move(value)) {}
  [[nodiscard]] const Digest256& value() const noexcept { return value_; }
  friend bool operator==(const ArrivalStateDigest&, const ArrivalStateDigest&) =
      default;

 private:
  Digest256 value_;
};

struct ArrivalBinding final {
  ArrivalFamily family;
  TimingConvention timing;
  std::size_t queue_cardinality;
  ArrivalLawDigest law_digest;
  QueueCatalogDigest catalog_digest;

  friend bool operator==(const ArrivalBinding&, const ArrivalBinding&) =
      default;
};

// One source contribution before same-slot aggregation. Construction is
// checked and binds the dense index to one exact law/catalog identity.
class ArrivalAtom final {
 public:
  ArrivalAtom() = delete;
  ArrivalAtom(const ArrivalAtom&) = default;
  ArrivalAtom(ArrivalAtom&&) noexcept = default;
  ArrivalAtom& operator=(const ArrivalAtom&) = default;
  ArrivalAtom& operator=(ArrivalAtom&&) noexcept = default;

  [[nodiscard]] static Result<ArrivalAtom> make(
      DenseQueueIndex queue, BigNat count, ArrivalBinding binding);

  [[nodiscard]] DenseQueueIndex queue() const noexcept { return queue_; }
  [[nodiscard]] const BigNat& count() const noexcept { return count_; }
  [[nodiscard]] const ArrivalBinding& binding() const noexcept {
    return binding_;
  }

 private:
  ArrivalAtom(DenseQueueIndex queue, BigNat count, ArrivalBinding binding)
      : queue_(queue), count_(std::move(count)), binding_(std::move(binding)) {}

  DenseQueueIndex queue_;
  BigNat count_;
  ArrivalBinding binding_;
};

struct ArrivalBatchEntry final {
  DenseQueueIndex queue;
  BigNat count;

  friend bool operator==(const ArrivalBatchEntry&,
                         const ArrivalBatchEntry&) = default;
};

// Sparse canonical batch: unique entries in ascending dense queue order.
// Empty input has the unique unbound representation; a process binds that
// representation to its law before publishing an ArrivalStep.
class ArrivalBatch final {
 public:
  ArrivalBatch(const ArrivalBatch&) = default;
  ArrivalBatch(ArrivalBatch&&) noexcept = default;
  ArrivalBatch& operator=(const ArrivalBatch&) = default;
  ArrivalBatch& operator=(ArrivalBatch&&) noexcept = default;

  [[nodiscard]] static ArrivalBatch empty();
  [[nodiscard]] std::span<const ArrivalBatchEntry> entries() const noexcept {
    return entries_;
  }
  [[nodiscard]] const std::optional<ArrivalBinding>& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] bool empty_batch() const noexcept { return entries_.empty(); }

  friend bool operator==(const ArrivalBatch&, const ArrivalBatch&) = default;

 private:
  ArrivalBatch(std::optional<ArrivalBinding> binding,
               std::vector<ArrivalBatchEntry> entries)
      : binding_(std::move(binding)), entries_(std::move(entries)) {}

  std::optional<ArrivalBinding> binding_;
  std::vector<ArrivalBatchEntry> entries_;

  friend Result<ArrivalBatch> aggregate_arrival_batch(
      std::span<const ArrivalAtom> atoms);
  friend struct detail::ArrivalCoreAccess;
};

// F-C09-05. Exact accumulation precedes conversion to the law's runtime count
// carrier.
[[nodiscard]] Result<ArrivalBatch> aggregate_arrival_batch(
    std::span<const ArrivalAtom> atoms);

template <ArrivalFamily Family>
class ArrivalPhaseHandle final {
 public:
  ArrivalPhaseHandle(const ArrivalPhaseHandle&) noexcept = default;
  ArrivalPhaseHandle(ArrivalPhaseHandle&& other) noexcept
      : core_(other.core_) {}
  ArrivalPhaseHandle& operator=(const ArrivalPhaseHandle&) noexcept = default;
  ArrivalPhaseHandle& operator=(ArrivalPhaseHandle&& other) noexcept {
    core_ = other.core_;
    return *this;
  }

  [[nodiscard]] static constexpr ArrivalFamily family() noexcept {
    return Family;
  }

 private:
  explicit ArrivalPhaseHandle(
      std::shared_ptr<const detail::ArrivalPhaseCore> core) noexcept
      : core_(std::move(core)) {}

  std::shared_ptr<const detail::ArrivalPhaseCore> core_;
  friend struct detail::ArrivalCoreAccess;
};

using TraceArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::deterministic_trace>;
using GlobalPeriodicArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::periodic_global_phase>;
using SourceDelayArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::periodic_source_delays>;
using MarkedRenewalArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::independent_marked_renewal>;
using PrivateMarkovArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::independent_private_markov_renewal>;
using SharedRoundArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::shared_joint_round_markov_renewal>;
using IidBernoulliArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::iid_independent_bernoulli>;
using IidCountTableArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::iid_count_table>;
using IidPoissonArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::iid_independent_poisson>;
using IidMixedPoissonArrivalPhase =
    ArrivalPhaseHandle<ArrivalFamily::iid_mixed_poisson>;

using ArrivalPhase =
    std::variant<TraceArrivalPhase, GlobalPeriodicArrivalPhase,
                 SourceDelayArrivalPhase, MarkedRenewalArrivalPhase,
                 PrivateMarkovArrivalPhase, SharedRoundArrivalPhase,
                 IidBernoulliArrivalPhase, IidCountTableArrivalPhase,
                 IidPoissonArrivalPhase, IidMixedPoissonArrivalPhase>;

template <ArrivalFamily Family>
class CompiledArrivalLawHandle final {
 public:
  CompiledArrivalLawHandle(const CompiledArrivalLawHandle&) noexcept = default;
  CompiledArrivalLawHandle(CompiledArrivalLawHandle&& other) noexcept
      : core_(other.core_) {}
  CompiledArrivalLawHandle& operator=(
      const CompiledArrivalLawHandle&) noexcept = default;
  CompiledArrivalLawHandle& operator=(
      CompiledArrivalLawHandle&& other) noexcept {
    core_ = other.core_;
    return *this;
  }

  [[nodiscard]] static constexpr ArrivalFamily family() noexcept {
    return Family;
  }

 private:
  explicit CompiledArrivalLawHandle(
      std::shared_ptr<const detail::CompiledArrivalLawCore> core) noexcept
      : core_(std::move(core)) {}

  std::shared_ptr<const detail::CompiledArrivalLawCore> core_;
  friend struct detail::ArrivalCoreAccess;
};

using CompiledTraceArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::deterministic_trace>;
using CompiledGlobalPeriodicArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::periodic_global_phase>;
using CompiledSourceDelayArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::periodic_source_delays>;
using CompiledMarkedRenewalArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::independent_marked_renewal>;
using CompiledPrivateMarkovArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::independent_private_markov_renewal>;
using CompiledSharedRoundArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::shared_joint_round_markov_renewal>;
using CompiledIidBernoulliArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::iid_independent_bernoulli>;
using CompiledIidCountTableArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::iid_count_table>;
using CompiledIidPoissonArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::iid_independent_poisson>;
using CompiledIidMixedPoissonArrivalLaw =
    CompiledArrivalLawHandle<ArrivalFamily::iid_mixed_poisson>;

using CompiledArrivalVariant =
    std::variant<CompiledTraceArrivalLaw, CompiledGlobalPeriodicArrivalLaw,
                 CompiledSourceDelayArrivalLaw, CompiledMarkedRenewalArrivalLaw,
                 CompiledPrivateMarkovArrivalLaw,
                 CompiledSharedRoundArrivalLaw,
                 CompiledIidBernoulliArrivalLaw,
                 CompiledIidCountTableArrivalLaw,
                 CompiledIidPoissonArrivalLaw,
                 CompiledIidMixedPoissonArrivalLaw>;

class CompiledArrivalLaw final {
 public:
  CompiledArrivalLaw(const CompiledArrivalLaw&) noexcept = default;
  CompiledArrivalLaw(CompiledArrivalLaw&&) noexcept = default;
  CompiledArrivalLaw& operator=(const CompiledArrivalLaw&) noexcept = default;
  CompiledArrivalLaw& operator=(CompiledArrivalLaw&&) noexcept = default;

  [[nodiscard]] ArrivalFamily family() const noexcept;
  [[nodiscard]] const CompiledArrivalVariant& variant() const noexcept {
    return variant_;
  }

 private:
  explicit CompiledArrivalLaw(CompiledArrivalVariant variant) noexcept
      : variant_(std::move(variant)) {}

  CompiledArrivalVariant variant_;
  friend struct detail::ArrivalCoreAccess;
};

template <ArrivalFamily Family>
class ArrivalProcessHandle final {
 public:
  ArrivalProcessHandle(const ArrivalProcessHandle&) = delete;
  ArrivalProcessHandle& operator=(const ArrivalProcessHandle&) = delete;
  ArrivalProcessHandle(ArrivalProcessHandle&&) noexcept = default;
  ArrivalProcessHandle& operator=(ArrivalProcessHandle&&) noexcept = default;

  [[nodiscard]] static constexpr ArrivalFamily family() noexcept {
    return Family;
  }

 private:
  explicit ArrivalProcessHandle(
      std::shared_ptr<detail::ArrivalProcessCore> core) noexcept
      : core_(std::move(core)) {}

  std::shared_ptr<detail::ArrivalProcessCore> core_;
  friend struct detail::ArrivalCoreAccess;
};

using TraceArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::deterministic_trace>;
using GlobalPeriodicArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::periodic_global_phase>;
using SourceDelayArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::periodic_source_delays>;
using MarkedRenewalArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::independent_marked_renewal>;
using PrivateMarkovArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::independent_private_markov_renewal>;
using SharedRoundArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::shared_joint_round_markov_renewal>;
using IidBernoulliArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::iid_independent_bernoulli>;
using IidCountTableArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::iid_count_table>;
using IidPoissonArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::iid_independent_poisson>;
using IidMixedPoissonArrivalProcess =
    ArrivalProcessHandle<ArrivalFamily::iid_mixed_poisson>;

using ArrivalProcessVariant =
    std::variant<TraceArrivalProcess, GlobalPeriodicArrivalProcess,
                 SourceDelayArrivalProcess, MarkedRenewalArrivalProcess,
                 PrivateMarkovArrivalProcess, SharedRoundArrivalProcess,
                 IidBernoulliArrivalProcess, IidCountTableArrivalProcess,
                 IidPoissonArrivalProcess, IidMixedPoissonArrivalProcess>;

class ArrivalProcess final {
 public:
  ArrivalProcess(const ArrivalProcess&) = delete;
  ArrivalProcess& operator=(const ArrivalProcess&) = delete;
  ArrivalProcess(ArrivalProcess&&) noexcept = default;
  ArrivalProcess& operator=(ArrivalProcess&&) noexcept = default;

  [[nodiscard]] ArrivalFamily family() const noexcept;
  [[nodiscard]] const ArrivalProcessVariant& variant() const noexcept {
    return variant_;
  }

 private:
  explicit ArrivalProcess(ArrivalProcessVariant variant) noexcept
      : variant_(std::move(variant)) {}

  ArrivalProcessVariant variant_;
  friend struct detail::ArrivalCoreAccess;
};

struct ArrivalStep final {
  BigNat authored_slot;
  ArrivalBatch batch;
  ArrivalPhase phase_before;
  ArrivalPhase phase_after;
  ArrivalLawDigest law_digest;
  Digest256 realization_identity;

  // This is the framework convention: a request at authored slot t returns
  // the physical late-admission batch A(t+1).
  [[nodiscard]] BigNat physical_arrival_epoch() const {
    BigNat epoch = authored_slot;
    ++epoch;
    return epoch;
  }
};

static_assert(std::variant_size_v<CompiledArrivalVariant> == 10U);
static_assert(std::variant_size_v<ArrivalProcessVariant> == 10U);
static_assert(std::variant_size_v<ArrivalPhase> == 10U);

}  // namespace mwperf
