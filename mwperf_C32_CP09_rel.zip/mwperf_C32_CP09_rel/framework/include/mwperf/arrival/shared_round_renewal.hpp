#pragma once

#include <cstddef>
#include <optional>
#include <span>
#include <string>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct PreparedArrivalCompilation;

namespace detail {
struct CompiledArrivalProduct;
[[nodiscard]] Result<CompiledArrivalProduct>
compile_shared_round_renewal_product(
    const ::mwperf::PreparedArrivalCompilation& request);
}  // namespace detail

struct SharedRoundInitialLaw final {
  std::vector<std::size_t> state_indices;
  std::optional<NormalizedPmf> probabilities;
};

struct SharedRoundEmissionLaw final {
  BigNat gap;
  DenseQueueIndex destination;

  friend bool operator==(const SharedRoundEmissionLaw&,
                         const SharedRoundEmissionLaw&) = default;
};

struct SharedRoundOutcomeLaw final {
  std::size_t next_state;
  // Exactly one coordinate in declared source order.
  std::vector<SharedRoundEmissionLaw> emissions;

  friend bool operator==(const SharedRoundOutcomeLaw&,
                         const SharedRoundOutcomeLaw&) = default;
};

struct SharedRoundStateLaw final {
  std::string state_id;
  std::vector<SharedRoundOutcomeLaw> outcomes;
  NormalizedPmf outcome_probabilities;
};

class SharedRoundLaw final {
 public:
  SharedRoundLaw() = delete;
  SharedRoundLaw(const SharedRoundLaw&) = default;
  SharedRoundLaw(SharedRoundLaw&&) noexcept = default;
  SharedRoundLaw& operator=(const SharedRoundLaw&) = default;
  SharedRoundLaw& operator=(SharedRoundLaw&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_count_;
  }
  [[nodiscard]] const QueueCatalogDigest& catalog_digest() const noexcept {
    return catalog_digest_;
  }
  [[nodiscard]] std::span<const std::string> source_ids() const noexcept {
    return source_ids_;
  }
  [[nodiscard]] const SharedRoundInitialLaw& initial() const noexcept {
    return initial_;
  }
  [[nodiscard]] std::span<const SharedRoundStateLaw> states() const noexcept {
    return states_;
  }
  [[nodiscard]] std::span<const std::uint8_t> positive_support_bytes()
      const noexcept {
    return positive_support_;
  }

 private:
  SharedRoundLaw(std::size_t queue_count, QueueCatalogDigest catalog_digest,
                 std::vector<std::string> source_ids,
                 SharedRoundInitialLaw initial,
                 std::vector<SharedRoundStateLaw> states,
                 std::vector<std::uint8_t> positive_support)
      : queue_count_(queue_count),
        catalog_digest_(std::move(catalog_digest)),
        source_ids_(std::move(source_ids)),
        initial_(std::move(initial)),
        states_(std::move(states)),
        positive_support_(std::move(positive_support)) {}

  std::size_t queue_count_;
  QueueCatalogDigest catalog_digest_;
  std::vector<std::string> source_ids_;
  SharedRoundInitialLaw initial_;
  std::vector<SharedRoundStateLaw> states_;
  std::vector<std::uint8_t> positive_support_;

  friend Result<SharedRoundLaw> compile_shared_round_renewal(
      const SharedJointRoundMarkovRenewalArrival&, const QueueCatalog&);
  friend Result<detail::CompiledArrivalProduct>
  detail::compile_shared_round_renewal_product(
      const PreparedArrivalCompilation& request);
};

// F-C11-05
[[nodiscard]] Result<SharedRoundLaw> compile_shared_round_renewal(
    const SharedJointRoundMarkovRenewalArrival& authored,
    const QueueCatalog& queues);

// F-C11-06
using SharedRoundCursor = ArrivalProcess;
[[nodiscard]] Result<ArrivalStep> next_shared_round_batch(
    SharedRoundCursor& cursor, const BigNat& authored_slot);

#if defined(MWPERF_C11_TEST_SEAMS)
namespace testing {

// Publishes the ordinary shared-round runtime with one post-proposal
// same-queue overflow injected at failure_slot. This can only exercise the
// C09 transaction boundary; it cannot manufacture or mutate cursor state.
[[nodiscard]] Result<CompiledArrivalLaw>
make_shared_round_overflow_fixture_law(
    const SharedJointRoundMarkovRenewalArrival& authored,
    const QueueCatalog& queues, BigNat failure_slot);

}  // namespace testing
#endif

}  // namespace mwperf
