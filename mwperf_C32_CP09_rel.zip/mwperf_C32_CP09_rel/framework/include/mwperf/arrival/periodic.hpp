#pragma once

#include <cstddef>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// One already-resolved, positive count in a sparse periodic residue bucket.
// Counts in a bucket are unique and ordered by dense queue index.
struct PeriodicQueueCount final {
  DenseQueueIndex queue;
  BigNat count;

  friend bool operator==(const PeriodicQueueCount&,
                         const PeriodicQueueCount&) = default;
};

// A sparse exact residue.  No compiled representation contains a vector whose
// length is the numerical period.
struct PeriodicResidueBucket final {
  BigNat residue;
  std::vector<PeriodicQueueCount> counts;

  friend bool operator==(const PeriodicResidueBucket&,
                         const PeriodicResidueBucket&) = default;
};

struct GlobalPhasePeriodicSource final {
  std::string source_id;
  std::vector<PeriodicResidueBucket> shifted_residues;

  friend bool operator==(const GlobalPhasePeriodicSource&,
                         const GlobalPhasePeriodicSource&) = default;
};

// Immutable geometry for F-C10-03.  Sources retain authored order; buckets
// within each source are ordered by the exact shifted residue.
class GlobalPhaseLaw final {
 public:
  GlobalPhaseLaw() = delete;
  GlobalPhaseLaw(const GlobalPhaseLaw&) = default;
  GlobalPhaseLaw(GlobalPhaseLaw&&) noexcept = default;
  GlobalPhaseLaw& operator=(const GlobalPhaseLaw&) = default;
  GlobalPhaseLaw& operator=(GlobalPhaseLaw&&) noexcept = default;

  [[nodiscard]] const BigNat& period() const noexcept { return period_; }
  [[nodiscard]] const BigNat& configured_phase() const noexcept {
    return configured_phase_;
  }
  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_count_;
  }
  [[nodiscard]] const QueueCatalogDigest& catalog_digest() const noexcept {
    return catalog_digest_;
  }
  [[nodiscard]] std::span<const GlobalPhasePeriodicSource> sources()
      const noexcept {
    return sources_;
  }
  [[nodiscard]] std::size_t aggregate_entry_count() const noexcept;

 private:
  GlobalPhaseLaw(BigNat period, BigNat configured_phase,
                 std::size_t queue_count, QueueCatalogDigest catalog_digest,
                 std::vector<GlobalPhasePeriodicSource> sources)
      : period_(std::move(period)),
        configured_phase_(std::move(configured_phase)),
        queue_count_(queue_count),
        catalog_digest_(std::move(catalog_digest)),
        sources_(std::move(sources)) {}

  BigNat period_;
  BigNat configured_phase_;
  std::size_t queue_count_;
  QueueCatalogDigest catalog_digest_;
  std::vector<GlobalPhasePeriodicSource> sources_;

  friend Result<GlobalPhaseLaw> compile_global_phase_periodic(
      const PeriodicGlobalPhaseArrival&, const QueueCatalog&);
};

struct SourceDelayPeriodicSource final {
  std::string source_id;
  BigNat delay;
  std::vector<PeriodicResidueBucket> unshifted_residues;

  friend bool operator==(const SourceDelayPeriodicSource&,
                         const SourceDelayPeriodicSource&) = default;
};

// Immutable geometry for F-C10-04.  Exact one-sided delays are retained; a
// source has no emissions before its delay even when a signed modulo image
// would happen to match one of its residues.
class SourceDelayLaw final {
 public:
  SourceDelayLaw() = delete;
  SourceDelayLaw(const SourceDelayLaw&) = default;
  SourceDelayLaw(SourceDelayLaw&&) noexcept = default;
  SourceDelayLaw& operator=(const SourceDelayLaw&) = default;
  SourceDelayLaw& operator=(SourceDelayLaw&&) noexcept = default;

  [[nodiscard]] const BigNat& period() const noexcept { return period_; }
  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_count_;
  }
  [[nodiscard]] const QueueCatalogDigest& catalog_digest() const noexcept {
    return catalog_digest_;
  }
  [[nodiscard]] std::span<const SourceDelayPeriodicSource> sources()
      const noexcept {
    return sources_;
  }
  [[nodiscard]] std::size_t aggregate_entry_count() const noexcept;

 private:
  SourceDelayLaw(BigNat period, std::size_t queue_count,
                 QueueCatalogDigest catalog_digest,
                 std::vector<SourceDelayPeriodicSource> sources)
      : period_(std::move(period)),
        queue_count_(queue_count),
        catalog_digest_(std::move(catalog_digest)),
        sources_(std::move(sources)) {}

  BigNat period_;
  std::size_t queue_count_;
  QueueCatalogDigest catalog_digest_;
  std::vector<SourceDelayPeriodicSource> sources_;

  friend Result<SourceDelayLaw> compile_source_delay_periodic(
      const PeriodicSourceDelaysArrival&, const QueueCatalog&);
};

// F-C10-03 and F-C10-04.  These public functions compile only immutable,
// queue-resolved family geometry.  The C10 registry adapters place the result
// behind the frozen C09 compiled-law variants.
[[nodiscard]] Result<GlobalPhaseLaw> compile_global_phase_periodic(
    const PeriodicGlobalPhaseArrival& authored, const QueueCatalog& queues);
[[nodiscard]] Result<SourceDelayLaw> compile_source_delay_periodic(
    const PeriodicSourceDelaysArrival& authored, const QueueCatalog& queues);

// F-C10-05 is a guarded family view of C09's sole public transition surface.
// The alias does not introduce another cursor implementation or transaction.
using PeriodicCursor = ArrivalProcess;
[[nodiscard]] Result<ArrivalStep> next_periodic_batch(
    PeriodicCursor& cursor, const BigNat& authored_slot);

}  // namespace mwperf
