#pragma once

#include <cstddef>
#include <optional>
#include <span>
#include <string>
#include <vector>

#include "mwperf/arrival/contract.hpp"
#include "mwperf/config/authored_model.hpp"
#include "mwperf/math/probability.hpp"
#include "mwperf/model/queue_catalog.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct PreparedArrivalCompilation;

namespace detail {
struct CompiledArrivalProduct;
[[nodiscard]] Result<CompiledArrivalProduct>
compile_private_markov_renewal_product(
    const PreparedArrivalCompilation& request);
}  // namespace detail

struct PrivateMarkovInitialLaw final {
  // Coordinates retain authored order. A fixed initial state has one
  // coordinate and no categorical row.
  std::vector<std::size_t> state_indices;
  std::optional<NormalizedPmf> probabilities;
};

struct PrivateMarkovStateLaw final {
  std::string state_id;
  BigNat gap;
  std::vector<std::size_t> next_states;
  NormalizedPmf transition_probabilities;
};

struct PrivateMarkovLawSource final {
  std::string source_id;
  PrivateMarkovInitialLaw initial;
  std::vector<PrivateMarkovStateLaw> states;
  std::vector<DenseQueueIndex> destinations;
  NormalizedPmf destination_probabilities;
};

class PrivateMarkovLaw final {
 public:
  PrivateMarkovLaw() = delete;
  PrivateMarkovLaw(const PrivateMarkovLaw&) = default;
  PrivateMarkovLaw(PrivateMarkovLaw&&) noexcept = default;
  PrivateMarkovLaw& operator=(const PrivateMarkovLaw&) = default;
  PrivateMarkovLaw& operator=(PrivateMarkovLaw&&) noexcept = default;

  [[nodiscard]] std::size_t queue_count() const noexcept {
    return queue_count_;
  }
  [[nodiscard]] const QueueCatalogDigest& catalog_digest() const noexcept {
    return catalog_digest_;
  }
  [[nodiscard]] std::span<const PrivateMarkovLawSource> sources()
      const noexcept {
    return sources_;
  }

 private:
  PrivateMarkovLaw(std::size_t queue_count,
                   QueueCatalogDigest catalog_digest,
                   std::vector<PrivateMarkovLawSource> sources)
      : queue_count_(queue_count),
        catalog_digest_(std::move(catalog_digest)),
        sources_(std::move(sources)) {}

  std::size_t queue_count_;
  QueueCatalogDigest catalog_digest_;
  std::vector<PrivateMarkovLawSource> sources_;

  friend Result<PrivateMarkovLaw> compile_private_markov_renewal(
      const IndependentPrivateMarkovRenewalArrival&, const QueueCatalog&);
  friend Result<detail::CompiledArrivalProduct>
  detail::compile_private_markov_renewal_product(
      const PreparedArrivalCompilation& request);
};

// F-C11-03
[[nodiscard]] Result<PrivateMarkovLaw> compile_private_markov_renewal(
    const IndependentPrivateMarkovRenewalArrival& authored,
    const QueueCatalog& queues);

// F-C11-04
using PrivateMarkovCursor = ArrivalProcess;
[[nodiscard]] Result<ArrivalStep> next_private_markov_batch(
    PrivateMarkovCursor& cursor, const BigNat& authored_slot);

}  // namespace mwperf
