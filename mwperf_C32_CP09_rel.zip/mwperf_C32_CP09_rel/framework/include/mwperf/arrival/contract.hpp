#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "mwperf/arrival/types.hpp"
#include "mwperf/config/analysis_spec.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/random/deterministic_rng.hpp"

namespace mwperf {

enum class CapabilityAvailability : std::uint8_t {
  unavailable,
  available,
};

enum class StationaryPhaseLawStatus : std::uint8_t {
  unavailable,
  supplied,
  selected,
  proved_unique,
};

enum class PhaseArgumentRequirement : std::uint8_t {
  phase_free,
  explicit_phase_required,
};

enum class AccessProvision : std::uint8_t {
  portable_only,
  process_local_only,
  portable_and_process_local,
};

enum class TransformKind : std::uint8_t {
  exact_pmf,
  exact_pgf,
  closed_transform,
};

enum class DistributionScope : std::uint8_t {
  joint_vector,
  per_coordinate,
};

struct ExactArgumentDomain final {
  ExactRational lower;
  ExactRational upper;
  bool lower_inclusive;
  bool upper_inclusive;

  friend bool operator==(const ExactArgumentDomain&,
                         const ExactArgumentDomain&) = default;
};

struct TransformCapability final {
  TransformKind kind;
  DistributionScope scope;
  ExactArgumentDomain domain;
  PhaseArgumentRequirement phase_requirement;
  AccessProvision provision;

  friend bool operator==(const TransformCapability&,
                         const TransformCapability&) = default;
};

struct MomentCapability final {
  // nullopt denotes all nonnegative integral orders, not absence.
  std::optional<BigNat> maximum_order;
  bool joint;
  bool conditioned_on_phase;
  AccessProvision provision;

  friend bool operator==(const MomentCapability&,
                         const MomentCapability&) = default;
};

struct ExactIidJointVectorCapability final {
  bool finite_support;
  AccessProvision provision;

  friend bool operator==(const ExactIidJointVectorCapability&,
                         const ExactIidJointVectorCapability&) = default;
};

// An exact, portable product of independent finite source laws whose complete
// per-slot batch is IID.  This is intentionally distinct from
// ExactIidJointVectorCapability: the configured-law descriptor is the compact
// generator recipe and no Cartesian joint-vector table is implied.
struct ExactFactorizedIidGeneratorCapability final {
  AccessProvision provision;

  friend bool operator==(
      const ExactFactorizedIidGeneratorCapability&,
      const ExactFactorizedIidGeneratorCapability&) = default;
};

// An exact IID late-arrival law carried by a canonical portable configured-law
// recipe.  The recipe may encode dependence within a slot (for example, a
// shared mixed-Poisson state), so this capability deliberately makes no
// factorization or finite-support claim.
struct ExactPortableIidRecipeCapability final {
  AccessProvision provision;

  friend bool operator==(const ExactPortableIidRecipeCapability&,
                         const ExactPortableIidRecipeCapability&) = default;
};

struct ReplayCapability final {
  bool explicit_initial_state;
  bool explicit_phase;
  bool normalized_initial_law;
  bool named_stationary_initialization;
  AccessProvision provision;

  friend bool operator==(const ReplayCapability&, const ReplayCapability&) =
      default;
};

enum class UnitCubeBoundary : std::uint8_t {
  left_closed_right_open,
};

enum class InverseCdfConvention : std::uint8_t {
  first_cumulative_mass_strictly_greater,
};

struct UnitCubeCapability final {
  BigNat dimension;
  UnitCubeBoundary boundary;
  InverseCdfConvention inverse_cdf;
  PhaseArgumentRequirement phase_requirement;
  AccessProvision provision;

  friend bool operator==(const UnitCubeCapability&,
                         const UnitCubeCapability&) = default;
};

// Every field is independent. In particular, a sequential sampler does not
// imply replay, finite phase, a transform, moments, or stationarity.
struct ArrivalCapabilities final {
  std::uint32_t version{1U};
  CapabilityAvailability exact_positive_support{
      CapabilityAvailability::unavailable};
  CapabilityAvailability sequential_normalized_sampler{
      CapabilityAvailability::unavailable};
  CapabilityAvailability finite_enumerated_predictive_phase{
      CapabilityAvailability::unavailable};
  CapabilityAvailability finite_enumerated_transition_row{
      CapabilityAvailability::unavailable};
  std::optional<TransformCapability> analytic_transform;
  std::optional<MomentCapability> analytic_moments;
  StationaryPhaseLawStatus stationary_phase_law{
      StationaryPhaseLawStatus::unavailable};
  std::optional<ExactIidJointVectorCapability> exact_iid_joint_vector;
  std::optional<MomentCapability> exact_joint_moments;
  std::optional<MomentCapability> exact_coordinate_moments;
  CapabilityAvailability exact_covariance{CapabilityAvailability::unavailable};
  CapabilityAvailability exact_cross_moments{
      CapabilityAvailability::unavailable};
  std::optional<TransformCapability> exact_joint_distribution;
  std::optional<TransformCapability> exact_coordinate_distributions;
  std::optional<ReplayCapability> adjacent_batch_replay;
  std::optional<UnitCubeCapability> unit_cube_transform;
  // Append-only capability extensions. Keep these after the frozen v1 fields
  // so existing aggregate field offsets and enumerated capability meanings
  // are not reordered.
  std::optional<ExactFactorizedIidGeneratorCapability>
      exact_factorized_iid_generator;
  std::optional<ExactPortableIidRecipeCapability> exact_portable_iid_recipe;

  friend bool operator==(const ArrivalCapabilities&,
                         const ArrivalCapabilities&) = default;
};

// Move-only ownership of an already-derived configured-arrival stream. This
// type deliberately has no seed or instance-key constructor and F-C09-04 never
// calls derive_rng_stream.
class ArrivalStreamKey final {
 public:
  ArrivalStreamKey(const ArrivalStreamKey&) = delete;
  ArrivalStreamKey& operator=(const ArrivalStreamKey&) = delete;
  ArrivalStreamKey(ArrivalStreamKey&&) noexcept = default;
  ArrivalStreamKey& operator=(ArrivalStreamKey&&) noexcept = default;

  [[nodiscard]] const ArrivalBinding& binding() const noexcept {
    return binding_;
  }
  [[nodiscard]] const Digest256& stream_identity() const noexcept;
  [[nodiscard]] const BigNat& consumed_words() const noexcept;

 private:
  ArrivalStreamKey(ArrivalBinding binding,
                   std::unique_ptr<DeterministicRng> rng) noexcept
      : binding_(std::move(binding)), rng_(std::move(rng)) {}

  ArrivalBinding binding_;
  std::unique_ptr<DeterministicRng> rng_;
  friend struct detail::ArrivalCoreAccess;
  friend Result<ArrivalStreamKey> make_configured_arrival_stream_key(
      const CompiledArrivalLaw&, DeterministicRng);
  friend Result<ArrivalProcess> instantiate_arrival_process(
      const CompiledArrivalLaw&, const ArrivalInitialState&, ArrivalStreamKey);
  friend class BuilderArrivalServices;
};

[[nodiscard]] Result<ArrivalStreamKey> make_configured_arrival_stream_key(
    const CompiledArrivalLaw& law, DeterministicRng stream);

// F-C09-02
[[nodiscard]] ArrivalCapabilities arrival_capabilities(
    const CompiledArrivalLaw& law);

// F-C09-03
[[nodiscard]] QueueMask positive_arrival_support(
    const CompiledArrivalLaw& law);

// F-C09-04
[[nodiscard]] Result<ArrivalProcess> instantiate_arrival_process(
    const CompiledArrivalLaw& law, const ArrivalInitialState& initial_state,
    ArrivalStreamKey stream_key);

// The sole configured transition surface. Authored slot t yields A(t+1).
// Scheduler decisions, backlog, target IDs, and surrogate state are absent by
// type. Calls must be 0,1,2,... on each independent mutable cursor.
[[nodiscard]] Result<ArrivalStep> next_arrival_step(
    ArrivalProcess& process, const BigNat& authored_slot);

[[nodiscard]] ArrivalFamily arrival_phase_family(
    const ArrivalPhase& phase) noexcept;
[[nodiscard]] ArrivalStateDigest arrival_phase_digest(
    const ArrivalPhase& phase);
[[nodiscard]] std::span<const std::byte> arrival_phase_canonical_state(
    const ArrivalPhase& phase) noexcept;
[[nodiscard]] bool arrival_phases_share_cursor(
    const ArrivalPhase& left, const ArrivalPhase& right) noexcept;
[[nodiscard]] const ArrivalBinding& arrival_law_binding(
    const CompiledArrivalLaw& law) noexcept;

// Pure projection of an already-produced joint batch. No random draw occurs.
[[nodiscard]] Result<BigNat> project_arrival_count(
    const ArrivalBatch& batch, DenseQueueIndex queue,
    const ArrivalBinding& expected_binding);

namespace detail {

// Internal C04/C09 boundary helper.  The resolver recomputes this digest from
// its own QueueCatalog instead of trusting metadata returned by an arrival
// child.
[[nodiscard]] Result<QueueCatalogDigest> digest_queue_catalog(
    const QueueCatalog& queues);

// Narrow checked recovery from C04's immutable opaque carrier. The product
// kind and retained C09 product identity are tested before/after the erased
// owner is cast.
struct CompiledArrivalAccess final {
  [[nodiscard]] static Result<std::shared_ptr<const CompiledArrivalLaw>> get(
      const ConfiguredArrivalBinding& binding);
#if defined(MWPERF_C09_TEST_SEAMS)
  [[nodiscard]] static Result<std::shared_ptr<const CompiledArrivalLaw>>
  recover_for_testing(
      PhysicalBindingIdentity physical_identity,
      ArrivalProductBindingIdentity product_identity,
      std::shared_ptr<const CompiledArrivalLaw> owner);
#endif
};

}  // namespace detail

#if defined(MWPERF_C09_TEST_SEAMS)
namespace testing {

enum class FixtureFailureMode : std::uint8_t {
  none,
  overflow_after_draw,
  throwing_initial_validator,
  throwing_unit_cube,
};

enum class FixtureConstructionProfile : std::uint8_t {
  baseline,
  phase_required_unit_cube,
  portable_only_construction_access,
  independent_portable_transforms,
  portable_iid_joint_table,
  portable_moments_and_covariance,
  replay_without_stationary,
  unsupported_process_local_iid,
  unsupported_process_local_moment,
  unsupported_process_local_transform,
  invalid_availability_discriminant,
  invalid_stationary_status_discriminant,
  invalid_access_provision_discriminant,
  invalid_transform_kind_discriminant,
  invalid_distribution_scope_discriminant,
  invalid_phase_requirement_discriminant,
  invalid_cube_boundary_discriminant,
  invalid_inverse_cdf_discriminant,
  partial_sampler_runtime,
  nonfinite_iid_claim,
  iid_support_mismatch,
  noncanonical_moment_table,
  noncanonical_covariance_table,
  invalid_unit_cube_coordinates,
  incomplete_replay_codec,
  empty_transform_domain,
  zero_transform_codec,
  throwing_phase_decoder,
  support_dimension_mismatch,
  unbounded_moment_claim,
  phase_conditioned_moment_claim,
  incomplete_coordinate_moment_table,
  incomplete_covariance_table,
  incomplete_cross_moment_table,
  unit_cube_missing_phase_encoder,
  replay_missing_sequential_sampler,
  portable_iid_bernoulli_joint_table,
  portable_iid_batch_joint_table,
};

[[nodiscard]] Result<CompiledArrivalLaw> make_c09_correlated_fixture_law(
    const QueueCatalog& queues,
    FixtureFailureMode failure_mode = FixtureFailureMode::none,
    FixtureConstructionProfile construction_profile =
        FixtureConstructionProfile::baseline);

// Dedicated stronger C20/C17 fixture: unlike the general C09 failure-mode
// fixture above, this law publishes the audited slot-free finite-phase row
// witness.  Reversing its raw exact row is used to exercise canonical
// branch-frontier ordering without changing the mathematical law identity.
[[nodiscard]] Result<CompiledArrivalLaw>
make_c09_time_homogeneous_correlated_fixture_law(
    const QueueCatalog& queues,
    bool reverse_exact_row_for_testing = false);

// C21 length-bias fixture.  Both finite predictive phases are absorbing,
// while the separately supplied exact mixture is retained as the configured
// ordinary-slot stationary phase law.  This makes a reducible homogeneous
// phase law explicit without promoting either event weights or samples to the
// configured slot-time mixture.
[[nodiscard]] Result<CompiledArrivalLaw>
make_c09_absorbing_two_phase_time_homogeneous_fixture_law(
    const QueueCatalog& queues, ExactRational phase_zero_stationary_mass,
    ExactRational phase_one_stationary_mass);

// C22 transient fixture.  Phase h0 emits one packet to physical queue zero
// and advances to h1; phase h1 emits one packet to physical queue one and
// remains in h1.  The law publishes the same finite, slot-free exact-row
// witness as the C20/C21 homogeneous fixtures so a test can retain predictive
// phase without pretending that the ordinary shared-round compiler exposes
// such a witness.
[[nodiscard]] Result<CompiledArrivalLaw>
make_c09_phase_selective_transient_fixture_law(
    const QueueCatalog& queues);

// C17 numerical-image acceptance fixture.  The two correlated transition
// outcomes have exact masses (first_outcome_mass, 1-first_outcome_mass).
[[nodiscard]] Result<CompiledArrivalLaw>
make_c09_weighted_correlated_fixture_law(
    const QueueCatalog& queues, ExactRational first_outcome_mass,
    FixtureConstructionProfile construction_profile =
        FixtureConstructionProfile::baseline);

struct ArrivalProcessSnapshot final {
  BigNat expected_slot;
  ArrivalStateDigest phase_digest;
  RngCheckpoint rng;
};

[[nodiscard]] Result<ArrivalProcessSnapshot> snapshot_arrival_process(
    const ArrivalProcess& process);

// Builds a value-only phase of the private finite-phase fixture at an explicit
// physical slot.  It exists only so higher-checkpoint tests can encode and
// decode exact clockful reduced states without exposing the production
// ArrivalPhase constructor.  This helper creates no stationarity or
// time-homogeneity evidence; those remain separate properties of the law.
[[nodiscard]] Result<ArrivalPhase> make_c09_fixture_phase_for_testing(
    const CompiledArrivalLaw& law, std::uint8_t canonical_phase,
    BigNat next_authored_slot);

// Re-anchors an immutable fixture phase at an explicit physical slot while
// preserving its predictive state, binding, cursor, and provenance owner.
// Exact-state fixture codecs use this to round-trip their stored boundary.
[[nodiscard]] Result<ArrivalPhase> reanchor_c09_fixture_phase_for_testing(
    const ArrivalPhase& phase, BigNat next_authored_slot);

}  // namespace testing
#endif

}  // namespace mwperf
