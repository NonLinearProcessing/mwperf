#pragma once

#include <cstddef>
#include <optional>
#include <span>
#include <vector>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/math/exact_rational.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

// A probability as authored in an input document.  The exact value is the
// authority; numerical_image() is only a separately derived solver image.
class AuthoredProbability final {
 public:
  AuthoredProbability() = delete;
  AuthoredProbability(const AuthoredProbability&) = default;
  AuthoredProbability(AuthoredProbability&& other) noexcept;
  AuthoredProbability& operator=(const AuthoredProbability&) = default;
  AuthoredProbability& operator=(AuthoredProbability&& other) noexcept;

  [[nodiscard]] static Result<AuthoredProbability> from_exact(
      ExactRational exact_value);

  [[nodiscard]] const ExactRational& exact_value() const noexcept;
  [[nodiscard]] long double numerical_image() const noexcept;

  friend bool operator==(const AuthoredProbability&,
                         const AuthoredProbability&) = default;

 private:
  AuthoredProbability(ExactRational exact_value, long double numerical_image);

  ExactRational exact_value_;
  long double numerical_image_;
};

// A construction/resource envelope, not part of the mathematical PMF
// identity.  When present, the bound applies to the primitive denominator D,
// every integral mass/cumulative total, and LCM scratch values used to build
// them.  C02 retains the declared bound so a later audit can establish which
// envelope was enforced.
struct PmfRepresentationBudget final {
  std::optional<std::size_t> maximum_integral_bits;

  [[nodiscard]] static PmfRepresentationBudget unbounded() { return {}; }

  friend bool operator==(const PmfRepresentationBudget&,
                         const PmfRepresentationBudget&) = default;
};

// Numerical information is deliberately descriptive rather than normative.
// PMF acceptance and categorical sampling never inspect these fields.
struct ProbabilityNumericalDiagnostics final {
  long double authored_mass;
  long double authored_residual;
  long double normalized_mass;
  long double normalized_residual;

  friend bool operator==(const ProbabilityNumericalDiagnostics&,
                         const ProbabilityNumericalDiagnostics&) = default;
};

// An immutable, once-normalized categorical law.  There is no public
// constructor and no mutating accessor: validate_and_normalize_pmf is the only
// way to create one from authored probabilities.
class NormalizedPmf final {
 public:
  NormalizedPmf() = delete;
  NormalizedPmf(const NormalizedPmf&) = default;
  // A move intentionally copies the immutable value.  There is no valid empty
  // PMF state to leave behind, so both objects remain fully usable.
  NormalizedPmf(NormalizedPmf&& other);
  NormalizedPmf& operator=(const NormalizedPmf& other);
  NormalizedPmf& operator=(NormalizedPmf&& other);

  [[nodiscard]] std::size_t size() const noexcept;
  [[nodiscard]] const std::vector<AuthoredProbability>&
  authored_probabilities() const noexcept;
  [[nodiscard]] const ExactRational& authored_sum() const noexcept;
  [[nodiscard]] const ExactRational& normalization_delta() const noexcept;
  [[nodiscard]] const std::vector<ExactRational>& normalized_weights()
      const noexcept;
  [[nodiscard]] const std::vector<BigNat>& integral_masses() const noexcept;
  [[nodiscard]] const std::vector<BigNat>& cumulative_masses() const noexcept;
  [[nodiscard]] const BigNat& integral_denominator() const noexcept;
  [[nodiscard]] std::size_t sampling_bit_width() const noexcept;
  [[nodiscard]] std::size_t sampling_limb_count() const noexcept;
  [[nodiscard]] const PmfRepresentationBudget& representation_budget()
      const noexcept;
  [[nodiscard]] const std::vector<long double>& numerical_image()
      const noexcept;
  [[nodiscard]] const ProbabilityNumericalDiagnostics& numerical_diagnostics()
      const noexcept;

  // Resource budget metadata is deliberately excluded from value identity.
  friend bool operator==(const NormalizedPmf& left,
                         const NormalizedPmf& right);

 private:
  NormalizedPmf(
      std::vector<AuthoredProbability> authored_probabilities,
      ExactRational authored_sum, ExactRational normalization_delta,
      std::vector<ExactRational> normalized_weights,
      std::vector<BigNat> integral_masses,
      std::vector<BigNat> cumulative_masses, BigNat integral_denominator,
      std::size_t sampling_bit_width, std::size_t sampling_limb_count,
      PmfRepresentationBudget representation_budget,
      std::vector<long double> numerical_image,
      ProbabilityNumericalDiagnostics numerical_diagnostics);

  void swap(NormalizedPmf& other) noexcept;

  std::vector<AuthoredProbability> authored_probabilities_;
  ExactRational authored_sum_;
  ExactRational normalization_delta_;
  std::vector<ExactRational> normalized_weights_;
  std::vector<BigNat> integral_masses_;
  std::vector<BigNat> cumulative_masses_;
  BigNat integral_denominator_;
  std::size_t sampling_bit_width_;
  std::size_t sampling_limb_count_;
  PmfRepresentationBudget representation_budget_;
  std::vector<long double> numerical_image_;
  ProbabilityNumericalDiagnostics numerical_diagnostics_;

  friend Result<NormalizedPmf> validate_and_normalize_pmf(
      std::span<const AuthoredProbability> probabilities,
      const ExactRational& tolerance);
  friend Result<NormalizedPmf> validate_and_normalize_pmf_with_budget(
      std::span<const AuthoredProbability> probabilities,
      const ExactRational& tolerance, PmfRepresentationBudget budget);
};

// The sole tolerance used by physical categorical rows: exactly 1/10^9.
[[nodiscard]] const ExactRational& physical_pmf_tolerance();

// F-C02-05.  The supplied tolerance must equal physical_pmf_tolerance(); this
// parameter is explicit so a caller cannot accidentally substitute a solver
// tolerance at the call site.
[[nodiscard]] Result<NormalizedPmf> validate_and_normalize_pmf(
    std::span<const AuthoredProbability> probabilities,
    const ExactRational& tolerance);

// Explicit resource-envelope seam.  It has a distinct name so the catalogued
// F-C02-05 definition remains unique and retains its authoritative two-input
// signature.
[[nodiscard]] Result<NormalizedPmf> validate_and_normalize_pmf_with_budget(
    std::span<const AuthoredProbability> probabilities,
    const ExactRational& tolerance, PmfRepresentationBudget budget);

// Checks an already-normalized value without reconstructing or renormalizing
// it, then returns the exact same immutable representation by value.
[[nodiscard]] Result<NormalizedPmf> revalidate_normalized_pmf(
    const NormalizedPmf& pmf, const ExactRational& tolerance);

}  // namespace mwperf
