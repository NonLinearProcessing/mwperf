#pragma once

#include <compare>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <utility>

#include "mwperf/math/big_nat.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

struct RationalBoundPolicy final {
  std::optional<std::size_t> maximum_bits;
  std::optional<std::size_t> maximum_decimal_digits;

  [[nodiscard]] static RationalBoundPolicy unbounded() { return {}; }
};

class NumericLexeme final {
 public:
  explicit NumericLexeme(
      std::string authored_text,
      RationalBoundPolicy bound_policy = RationalBoundPolicy::unbounded())
      : text_(std::move(authored_text)),
        bound_policy_(std::move(bound_policy)) {}

  [[nodiscard]] std::string_view text() const noexcept { return text_; }
  [[nodiscard]] const RationalBoundPolicy& bound_policy() const noexcept {
    return bound_policy_;
  }

 private:
  std::string text_;
  RationalBoundPolicy bound_policy_;
};

// A reduced arbitrary-precision rational.  Its denominator is always positive
// and zero has the sole representation 0/1.
class ExactRational final {
 public:
  ExactRational() = delete;
  ExactRational(const ExactRational&) = default;
  ExactRational(ExactRational&& other) noexcept;
  ExactRational& operator=(const ExactRational&) = default;
  ExactRational& operator=(ExactRational&& other) noexcept;

  [[nodiscard]] static Result<ExactRational> make(BigInt numerator,
                                                  BigInt denominator);
  [[nodiscard]] static ExactRational zero();
  [[nodiscard]] static ExactRational one();

  [[nodiscard]] const BigInt& numerator() const noexcept { return numerator_; }
  [[nodiscard]] const BigInt& denominator() const noexcept {
    return denominator_;
  }
  [[nodiscard]] bool is_zero() const noexcept { return numerator_ == 0; }
  [[nodiscard]] bool is_nonnegative() const noexcept { return numerator_ >= 0; }
  [[nodiscard]] bool is_positive() const noexcept { return numerator_ > 0; }

  [[nodiscard]] std::string numerator_decimal() const;
  [[nodiscard]] std::string denominator_decimal() const;
  // Convenience display/identity composition as canonical "numerator/denominator".
  // Artifact encoders should normally use the two separately framed fields.
  [[nodiscard]] std::string to_canonical_string() const;
  // Numerical-image policy: retain guarded high bits of numerator and
  // denominator together, divide in the host long-double format, then apply
  // their common binary scale.  Exact identity and acceptance never use this
  // rounded image.
  [[nodiscard]] long double to_long_double() const;
  void swap(ExactRational& other) noexcept {
    numerator_.swap(other.numerator_);
    denominator_.swap(other.denominator_);
  }
  friend void swap(ExactRational& lhs, ExactRational& rhs) noexcept {
    lhs.swap(rhs);
  }

  [[nodiscard]] ExactRational operator-() const;

  friend ExactRational operator+(const ExactRational& lhs,
                                 const ExactRational& rhs);
  friend ExactRational operator-(const ExactRational& lhs,
                                 const ExactRational& rhs);
  friend ExactRational operator*(const ExactRational& lhs,
                                 const ExactRational& rhs);
  friend bool operator==(const ExactRational&, const ExactRational&) = default;
  friend std::strong_ordering operator<=>(const ExactRational& lhs,
                                          const ExactRational& rhs);

 private:
  struct ReducedTag final {};
  ExactRational(BigInt numerator, BigInt denominator, ReducedTag)
      : numerator_(std::move(numerator)), denominator_(std::move(denominator)) {}

  [[nodiscard]] static ExactRational make_reduced(BigInt numerator,
                                                  BigInt denominator);

  BigInt numerator_;
  BigInt denominator_;
};

[[nodiscard]] Result<ExactRational> checked_divide(
    const ExactRational& numerator, const ExactRational& denominator);
[[nodiscard]] ExactRational absolute_value(const ExactRational& value);
[[nodiscard]] std::string to_string(const ExactRational& value);

// F-C02-04
[[nodiscard]] Result<ExactRational> parse_decimal_rational(
    NumericLexeme lexeme);

}  // namespace mwperf
