#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "mwperf/math/exact_rational.hpp"
#include "mwperf/result.hpp"

namespace mwperf {

enum class PortableScientificScalarKind : std::uint8_t {
  rational = 0,
  binary64 = 1,
};

// A representation-preserving scientific scalar.  A binary64 is stored as
// bits (rather than a host floating value), so canonical encoding equality is
// also ordinary value equality for this type.
class PortableScientificScalar final {
 public:
  PortableScientificScalar() = delete;

  [[nodiscard]] static PortableScientificScalar rational(
      ExactRational value);
  [[nodiscard]] static Result<PortableScientificScalar> from_binary64(
      double value);
  // The bound is trusted parser/envelope metadata, never artifact-authored
  // policy.  Preflight rejects oversized canonical integer components before
  // constructing their multiprecision values.
  [[nodiscard]] static Result<PortableScientificScalar> parse_rational(
      std::string_view numerator, std::string_view denominator,
      RationalBoundPolicy bound_policy = RationalBoundPolicy::unbounded());
  [[nodiscard]] static Result<PortableScientificScalar> parse_binary64(
      std::string_view encoded_bits);

  [[nodiscard]] PortableScientificScalarKind kind() const noexcept;
  [[nodiscard]] const ExactRational& rational_value() const;
  [[nodiscard]] std::uint64_t binary64_bits() const;
  [[nodiscard]] double binary64_value() const;

  [[nodiscard]] std::string binary64_encoding() const;
  [[nodiscard]] std::string canonical_tagged_encoding() const;
  // Version-1 identity bytes:
  //   rational: 0x00 || u64be(numerator-size) || numerator-ascii ||
  //             u64be(denominator-size) || denominator-ascii
  //   binary64: 0x01 || the eight IEEE-754 bytes in network byte order
  [[nodiscard]] std::vector<std::uint8_t> canonical_bytes() const;

  friend bool operator==(const PortableScientificScalar&,
                         const PortableScientificScalar&) = default;

 private:
  struct Binary64Bits final {
    std::uint64_t value;
    friend bool operator==(const Binary64Bits&, const Binary64Bits&) = default;
  };

  explicit PortableScientificScalar(ExactRational value)
      : value_(std::move(value)) {}
  explicit PortableScientificScalar(Binary64Bits bits) : value_(bits) {}

  std::variant<ExactRational, Binary64Bits> value_;
};

// This is an explicitly named numerical conversion: it maps the exact IEEE-754
// binary64 bit pattern to the identical dyadic rational.  It does not change a
// scalar's representation identity.
[[nodiscard]] ExactRational binary64_as_exact_rational(
    const PortableScientificScalar& scalar);

[[nodiscard]] Result<void> validate_in_closed_interval(
    const PortableScientificScalar& scalar, const ExactRational& lower,
    const ExactRational& upper);

}  // namespace mwperf
