#pragma once

#include <concepts>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

#include <boost/multiprecision/cpp_int.hpp>

#include "mwperf/result.hpp"

namespace mwperf {

using BigInt = boost::multiprecision::cpp_int;

// A value-semantic arbitrary-precision natural number.  The only constructor
// that accepts a signed multiprecision value is the validating factory.
class BigNat final {
 public:
  BigNat() = delete;
  explicit BigNat(std::uint64_t value);
  template <std::unsigned_integral Integer>
    requires(!std::same_as<std::remove_cv_t<Integer>, bool>)
  explicit BigNat(Integer value) : value_(value) {}
  explicit BigNat(bool) = delete;
  template <std::signed_integral Integer>
  explicit BigNat(Integer) = delete;
  BigNat(const BigNat&) = default;
  BigNat(BigNat&& other) noexcept;
  BigNat& operator=(const BigNat&) = default;
  BigNat& operator=(BigNat&& other) noexcept;

  [[nodiscard]] static Result<BigNat> from_big_int(BigInt value);

  [[nodiscard]] const BigInt& value() const noexcept { return value_; }
  [[nodiscard]] bool is_zero() const noexcept { return value_ == 0; }
  [[nodiscard]] std::size_t bit_length() const noexcept;
  [[nodiscard]] std::string to_decimal_string() const;
  // Minimal unsigned big-endian magnitude; zero is the one byte 0x00.
  [[nodiscard]] std::vector<std::uint8_t> canonical_magnitude_bytes() const;

  BigNat& operator+=(const BigNat& other);
  BigNat& operator*=(const BigNat& other);
  BigNat& operator++();
  void swap(BigNat& other) noexcept { value_.swap(other.value_); }
  friend void swap(BigNat& lhs, BigNat& rhs) noexcept { lhs.swap(rhs); }

  friend BigNat operator+(BigNat lhs, const BigNat& rhs) {
    lhs += rhs;
    return lhs;
  }

  friend BigNat operator*(BigNat lhs, const BigNat& rhs) {
    lhs *= rhs;
    return lhs;
  }

  friend bool operator==(const BigNat&, const BigNat&) = default;
  friend std::strong_ordering operator<=>(const BigNat& lhs,
                                          const BigNat& rhs) noexcept;

 private:
  struct ValidatedTag final {};
  BigNat(BigInt value, ValidatedTag) : value_(std::move(value)) {}

  BigInt value_;
};

[[nodiscard]] Result<BigNat> checked_subtract(const BigNat& lhs,
                                              const BigNat& rhs);
[[nodiscard]] std::string to_string(const BigNat& value);
[[nodiscard]] std::vector<std::uint8_t> canonical_big_nat_bytes(
    const BigNat& value);

enum class JsonNumberKind : std::uint8_t {
  number,
  boolean,
  other,
};

// C03 will construct this carrier directly from a preserved source token.
// Keeping the token kind prevents a boolean DOM value from entering through a
// numeric-looking spelling.
class JsonNumber final {
 public:
  explicit JsonNumber(std::string numeric_lexeme)
      : kind_(JsonNumberKind::number), lexeme_(std::move(numeric_lexeme)) {}

  [[nodiscard]] static JsonNumber boolean(bool value);
  [[nodiscard]] static JsonNumber other(std::string authored_text);

  [[nodiscard]] JsonNumberKind kind() const noexcept { return kind_; }
  [[nodiscard]] std::string_view lexeme() const noexcept { return lexeme_; }

 private:
  JsonNumber(JsonNumberKind kind, std::string lexeme)
      : kind_(kind), lexeme_(std::move(lexeme)) {}

  JsonNumberKind kind_;
  std::string lexeme_;
};

struct BoundPolicy final {
  std::optional<BigNat> mathematical_maximum;
  std::optional<std::size_t> maximum_bits;
  std::optional<std::size_t> maximum_decimal_digits;

  [[nodiscard]] static BoundPolicy unbounded() { return {}; }
};

// F-C02-01
[[nodiscard]] Result<BigNat> parse_exact_nonnegative_integer(
    JsonNumber number, BoundPolicy policy);

// F-C02-02
[[nodiscard]] Result<std::size_t> checked_index(
    const BigNat& value, std::size_t upper_exclusive);

}  // namespace mwperf
