include_guard(GLOBAL)

# The complete dependency set is discovered up front so a missing prerequisite
# fails during configuration. C02 consumes the header-only
# Boost.Multiprecision target. C03 additionally consumes yaml-cpp in the
# restricted document front end and nlohmann-json in schema tests. C18 consumes
# Eigen privately in the finite stationary numerical backend.
find_package(Boost 1.74 CONFIG REQUIRED)
find_package(Eigen3 3.3 CONFIG REQUIRED)
find_package(nlohmann_json 3.9 CONFIG REQUIRED)
find_package(yaml-cpp CONFIG REQUIRED)

if(BUILD_TESTING)
  find_package(Catch2 3 CONFIG REQUIRED)
endif()
