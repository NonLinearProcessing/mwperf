#!/usr/bin/env python3
"""Preflight a SwitchSim v20 schema-4 configuration tree without running slots."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import tempfile


def _bootstrap_simulator() -> Path:
    bootstrap = argparse.ArgumentParser(add_help=False)
    bootstrap.add_argument("--sim-root", default=".")
    args, _unknown = bootstrap.parse_known_args()
    sim_root = Path(args.sim_root).expanduser().resolve()
    if not (sim_root / "voqsim").is_dir():
        bootstrap.error(
            f"--sim-root must name a SwitchSim v20 source tree containing voqsim: {sim_root}"
        )
    sys.path.insert(0, str(sim_root))
    return sim_root


SIM_ROOT = _bootstrap_simulator()

from voqsim.batch import preflight_batch_configs  # noqa: E402
from voqsim.errors import SimError  # noqa: E402


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Parse, resolve, compile, and serviceability-check every config; "
            "the simulation kernel is never run."
        )
    )
    parser.add_argument("config_dir", type=Path, help="root of the schema-4 config tree")
    parser.add_argument(
        "--sim-root",
        type=Path,
        default=SIM_ROOT,
        help="SwitchSim v20 source tree (default: current directory)",
    )
    parser.add_argument(
        "--non-recursive",
        action="store_true",
        help="inspect only config files directly inside config_dir",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    config_dir = args.config_dir.expanduser().resolve()
    try:
        # A temporary, empty output root lets the production preflight validate
        # output-path uniqueness without creating any run artifact or executing
        # even one slot.
        with tempfile.TemporaryDirectory(prefix="switchsim-v20-preflight-") as temporary:
            prepared = preflight_batch_configs(
                config_dir,
                Path(temporary) / "results",
                recursive=not args.non_recursive,
            )
    except (SimError, OSError) as exc:
        sys.stderr.write(f"preflight failed: {exc}\n")
        return 1

    traced = [item.relative_path.as_posix() for item in prepared if item.resolved_config.telemetry.write_slot_trace]
    missing_observations = [
        item.relative_path.as_posix()
        for item in prepared
        if not item.resolved_config.telemetry.observation.enabled
        or not item.resolved_config.telemetry.observation.targets
    ]
    incomplete_exact_gap_targets = [
        item.relative_path.as_posix()
        for item in prepared
        if len(item.resolved_config.telemetry.observation.targets) != 3
        or any(
            target.gap != "exact"
            for target in item.resolved_config.telemetry.observation.targets
        )
    ]
    target_metadata_mismatches: list[str] = []
    for item in prepared:
        queue_ids = [
            target.queue_id
            for target in item.resolved_config.telemetry.observation.targets
        ]
        metadata = item.resolved_config.metadata
        measurement = metadata.get("measurement")
        declared_exact = (
            measurement.get("exact_gap_targets")
            if isinstance(measurement, dict)
            else None
        )
        if metadata.get("analysis_targets") != queue_ids or declared_exact != queue_ids:
            target_metadata_mismatches.append(item.relative_path.as_posix())
    violations: list[str] = []
    if traced:
        violations.append("write_slot_trace must be false: " + ", ".join(traced))
    if missing_observations:
        violations.append(
            "compact observations and at least one target are required: "
            + ", ".join(missing_observations)
        )
    if incomplete_exact_gap_targets:
        violations.append(
            "exactly three observation targets with gap='exact' are required: "
            + ", ".join(incomplete_exact_gap_targets)
        )
    if target_metadata_mismatches:
        violations.append(
            "analysis_targets, exact_gap_targets, and runtime target order must agree: "
            + ", ".join(target_metadata_mismatches)
        )
    if violations:
        sys.stderr.write("preflight policy failed:\n  " + "\n  ".join(violations) + "\n")
        return 1

    print(
        f"validated {len(prepared)} schema-4 configs with three exact-gap "
        "targets each; compiled arrivals and schedulers; executed 0 slots"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
